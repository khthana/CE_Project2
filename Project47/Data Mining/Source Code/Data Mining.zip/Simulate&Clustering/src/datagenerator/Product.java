package datagenerator;

import java.util.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dbswing.*;
import java.sql.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Product extends JFrame {

  private XYLayout xYLayout1 = new XYLayout();
  private JTextField pd_noTextField = new JTextField();
  private JLabel qualityLabel = new JLabel();
  private JLabel air_purifyLabel = new JLabel();
  private JLabel quietLabel = new JLabel();
  private JLabel pd_noLabel = new JLabel();
  private JLabel otherLabel = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private JLabel priceLabel = new JLabel();
  private JLabel en_savLabel = new JLabel();
  private JLabel PointLabel = new JLabel();
  private JTextField price1TextField = new JTextField();
  private JTextField price2TextField = new JTextField();
  private JTextField price3TextField = new JTextField();
  private JTextField price4TextField = new JTextField();
  private JTextField price5TextField = new JTextField();
  private JTextField quality1TextField = new JTextField();
  private JTextField quality5TextField = new JTextField();
  private JTextField quality4TextField = new JTextField();
  private JTextField quality3TextField = new JTextField();
  private JTextField quality2TextField = new JTextField();
  private JTextField en_sav1TextField = new JTextField();
  private JTextField en_sav5TextField = new JTextField();
  private JTextField en_sav4TextField = new JTextField();
  private JTextField en_sav3TextField = new JTextField();
  private JTextField en_sav2TextField = new JTextField();
  private JTextField quiet1TextField = new JTextField();
  private JTextField quiet5TextField = new JTextField();
  private JTextField quiet4TextField = new JTextField();
  private JTextField quiet3TextField = new JTextField();
  private JTextField quiet2TextField = new JTextField();
  private JTextField other2TextField = new JTextField();
  private JTextField other3TextField = new JTextField();
  private JTextField other4TextField = new JTextField();
  private JTextField other5TextField = new JTextField();
  private JTextField other1TextField = new JTextField();
  private JTextField air_purify2TextField = new JTextField();
  private JTextField air_purify3TextField = new JTextField();
  private JTextField air_purify4TextField = new JTextField();
  private JTextField air_purify5TextField = new JTextField();
  private JTextField air_purify1TextField = new JTextField();
  private JLabel conditionLabel = new JLabel();
  private JComboBox lead_conComboBox = new JComboBox();
  private JComboBox lead_pointComboBox = new JComboBox();
  private JLabel lead_conLabel = new JLabel();
  private JLabel lead_pointLabel = new JLabel();
  private JCheckBox con_priceCheckBox = new JCheckBox();
  private JComboBox con_priceComboBox = new JComboBox();
  private JLabel follow_pointLabel = new JLabel();
  private JTextField con_priceTextField = new JTextField();
  private JLabel con_percentLabel = new JLabel();
  private JLabel follow_conLabel = new JLabel();
  private JComboBox con_qualityComboBox = new JComboBox();
  private JCheckBox con_qualityCheckBox = new JCheckBox();
  private JTextField con_qualityTextField = new JTextField();
  private JComboBox con_quietComboBox = new JComboBox();
  private JComboBox con_en_savComboBox = new JComboBox();
  private JTextField con_quietTextField = new JTextField();
  private JCheckBox con_en_savCheckBox = new JCheckBox();
  private JCheckBox con_quietCheckBox = new JCheckBox();
  private JTextField con_en_savTextField = new JTextField();
  private JComboBox con_otherComboBox = new JComboBox();
  private JComboBox con_air_purifyComboBox = new JComboBox();
  private JTextField con_otherTextField = new JTextField();
  private JCheckBox con_air_purifyCheckBox = new JCheckBox();
  private JCheckBox con_otherCheckBox = new JCheckBox();
  private JTextField con_air_purifyTextField = new JTextField();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList conditionJList = new JList();
  private JButton insertButton = new JButton();
  private JButton deleteButton = new JButton();
  private JButton generateDataButton = new JButton();
  private JButton deleteDataButton = new JButton();
  private JButton okButton = new JButton();
  private JButton cancelButton = new JButton();
  private JButton ClusterButton = new JButton();
  private JTextField brand1TextField = new JTextField();
  private JTextField brand2TextField = new JTextField();
  private JTextField brand3TextField = new JTextField();
  private JTextField brand4TextField = new JTextField();
  private JTextField brand5TextField = new JTextField();
  private JLabel brandLabel = new JLabel();
  private JTextField beauty1TextField = new JTextField();
  private JTextField beauty2TextField = new JTextField();
  private JTextField beauty3TextField = new JTextField();
  private JTextField beauty4TextField = new JTextField();
  private JTextField beauty5TextField = new JTextField();
  private JLabel beautyLabel = new JLabel();
  private JTextField service1TextField = new JTextField();
  private JTextField service2TextField = new JTextField();
  private JTextField service3TextField = new JTextField();
  private JTextField service4TextField = new JTextField();
  private JTextField service5TextField = new JTextField();
  private JLabel serviceLabel = new JLabel();

  static final String JDBC_DRIVER = "sun.jdbc.odbc.JdbcOdbcDriver";
  static final String DATABASE_URL = "jdbc:odbc:datamining";
  private QueryExecute queryExecute;
  private String query;
  private Database database1 = new Database();
  private QueryDataSet queryDataSet1 = new QueryDataSet();
  private TableScrollPane tableScrollPane1 = new TableScrollPane();
  private JdbTable productdbTable = new JdbTable();
  private Statement statement;

  public int pd_no;
  static int maxtype = 9;
  static int maxpoint = 5;
  private int limit[][] = new int [maxtype][maxpoint];

  /* Buy cause type
  0.Brand
  1.Quality
  2.Energy saving
  3.Air purify
  4.Quiet
  5.Beauty
  6.Price
  7.Service after sell
  8.Other
  */
  private double inputarr[][] = new double[maxtype][maxpoint]; // [Buy cause type][Point]
  private int currentarr[][] = new int[maxtype][maxpoint];

  private String conditionstr[];
  private List conditionList = new LinkedList();

  private List lead_conList = new LinkedList();
  private List lead_pointList = new LinkedList();

  //Brand ConditionList
  private List con_brand_checkList = new LinkedList();
  private List con_brand_pointList = new LinkedList();
  private List con_brand_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Quality ConditionList
  private List con_quality_checkList = new LinkedList();
  private List con_quality_pointList = new LinkedList();
  private List con_quality_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Energy saving ConditionList
  private List con_en_sav_checkList = new LinkedList();
  private List con_en_sav_pointList = new LinkedList();
  private List con_en_sav_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Air purify ConditionList
  private List con_air_purify_checkList = new LinkedList();
  private List con_air_purify_pointList = new LinkedList();
  private List con_air_purify_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Quiet ConditionList
  private List con_quiet_checkList = new LinkedList();
  private List con_quiet_pointList = new LinkedList();
  private List con_quiet_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Beauty ConditionList
  private List con_beauty_checkList = new LinkedList();
  private List con_beauty_pointList = new LinkedList();
  private List con_beauty_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Price ConditionList
  private List con_price_checkList = new LinkedList();
  private List con_price_pointList = new LinkedList();
  private List con_price_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Service after sell ConditionList
  private List con_service_checkList = new LinkedList();
  private List con_service_pointList = new LinkedList();
  private List con_service_perList = new LinkedList();
  //////////////////////////////////////////////////////
  //Other ConditionList
  private List con_other_checkList = new LinkedList();
  private List con_other_pointList = new LinkedList();
  private List con_other_perList = new LinkedList();
  //////////////////////////////////////////////////////

  private List con_checkList[] = {con_brand_checkList,con_quality_checkList,con_en_sav_checkList,
                                    con_air_purify_checkList,con_quiet_checkList,con_beauty_checkList,
                                    con_price_checkList,con_service_checkList,con_other_checkList};
  private List con_pointList[] = {con_brand_pointList,con_quality_pointList,con_en_sav_pointList,
                                    con_air_purify_pointList,con_quiet_pointList,con_beauty_pointList,
                                    con_price_pointList,con_service_pointList,con_other_pointList};
  private List con_perList[] = {con_brand_perList,con_quality_perList,con_en_sav_perList,
                                    con_air_purify_perList,con_quiet_perList,con_beauty_perList,
                                    con_price_perList,con_service_perList,con_other_perList};

  private String pointstr[] = {"1","2","3","4","5"};
  private String buy_causestr[] = {"Brand","Quality","Energy saving","Air purify","Quiet",
                                   "Beauty","Price","Service after sell","Other"};
  private JTextField con_brandTextField = new JTextField();
  private JComboBox con_brandComboBox = new JComboBox(pointstr);
  private JCheckBox con_brandCheckBox = new JCheckBox();
  private JTextField con_beautyTextField = new JTextField();
  private JComboBox con_beautyComboBox = new JComboBox(pointstr);
  private JCheckBox con_beautyCheckBox = new JCheckBox();
  private JTextField con_serviceTextField = new JTextField();
  private JComboBox con_serviceComboBox = new JComboBox(pointstr);
  private JCheckBox con_serviceCheckBox = new JCheckBox();
  private JButton saveButton = new JButton();


  public Product() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    con_brandComboBox = new JComboBox(pointstr);
    con_beautyComboBox = new JComboBox(pointstr);
    con_serviceComboBox = new JComboBox(pointstr);
    PointLabel.setText("% of Points");
    en_savLabel.setText("3. Energy saving");
    priceLabel.setText("7. Price");
    jLabel1.setText("1");
    jLabel2.setText("2");
    jLabel3.setText("3");
    jLabel4.setText("4");
    jLabel5.setText("5");
    otherLabel.setText("9. Other");
    pd_noLabel.setText("Product SN");
    pd_noLabel.setText("Number of products");
    quietLabel.setText("5. Quiet");
    air_purifyLabel.setText("4. Air purify");
    qualityLabel.setText("1. Quality");
    qualityLabel.setText("2. Quality");
    this.getContentPane().setLayout(xYLayout1);
    conditionLabel.setFont(new java.awt.Font("Dialog", 1, 12));
    conditionLabel.setText("Conditions");
    lead_conLabel.setFont(new java.awt.Font("Dialog", 2, 12));
    lead_conLabel.setText("lead condition");
    lead_pointLabel.setFont(new java.awt.Font("Dialog", 2, 12));
    lead_pointLabel.setText("points");
    con_priceCheckBox.setEnabled(false);
    con_priceCheckBox.setText("Price");
    follow_pointLabel.setText("points");
    follow_pointLabel.setFont(new java.awt.Font("Dialog", 2, 12));
    con_percentLabel.setFont(new java.awt.Font("Dialog", 2, 12));
    con_percentLabel.setText("%");
    follow_conLabel.setFont(new java.awt.Font("Dialog", 2, 12));
    follow_conLabel.setText("follow condition");
    con_qualityCheckBox.setEnabled(false);
    con_qualityCheckBox.setText("Quality");
    xYLayout1.setWidth(1000);
    xYLayout1.setHeight(728);
    con_en_savCheckBox.setEnabled(false);
    con_en_savCheckBox.setText("Energy saving");
    con_quietCheckBox.setEnabled(false);
    con_quietCheckBox.setText("Quiet");
    con_air_purifyCheckBox.setEnabled(false);
    con_air_purifyCheckBox.setText("Air purify");
    con_otherCheckBox.setEnabled(false);
    con_otherCheckBox.setText("Other");
    insertButton.setEnabled(false);
    insertButton.setText("Insert");
    insertButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        insertButton_actionPerformed(e);
      }
    });
    deleteButton.setEnabled(false);
    deleteButton.setText("Delete");
    deleteButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteButton_actionPerformed(e);
      }
    });
    generateDataButton.setEnabled(false);
    generateDataButton.setText("GenerateData");
    generateDataButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        generateDataButton_actionPerformed(e);
      }
    });
    deleteDataButton.setText("DeleteData");
    deleteDataButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteDataButton_actionPerformed(e);
      }
    });
    database1.setConnection(new com.borland.dx.sql.dataset.ConnectionDescriptor("jdbc:odbc:datamining", "", "", false, "sun.jdbc.odbc.JdbcOdbcDriver"));
    database1.setDatabaseName("");
    queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, "SELECT * FROM PRODUCT", null, true, Load.ALL));
    productdbTable.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
    productdbTable.setDataSet(queryDataSet1);
    productdbTable.setEditable(false);
    okButton.setText("OK");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    cancelButton.setText("Cancel");
    cancelButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancelButton_actionPerformed(e);
      }
    });
    this.setTitle("Product");
    lead_conComboBox = new JComboBox(buy_causestr);
    lead_pointComboBox = new JComboBox(pointstr);
    con_priceComboBox = new JComboBox(pointstr);
    con_qualityComboBox = new JComboBox(pointstr);
    con_en_savComboBox = new JComboBox(pointstr);
    con_quietComboBox = new JComboBox(pointstr);
    con_air_purifyComboBox = new JComboBox(pointstr);
    con_otherComboBox = new JComboBox(pointstr);
    lead_conComboBox.setEnabled(false);
    lead_conComboBox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        lead_conComboBox_actionPerformed(e);
      }
    });
    lead_pointComboBox.setEnabled(false);
    con_priceTextField.setEnabled(false);
    con_priceComboBox.setEnabled(false);
    con_qualityComboBox.setEnabled(false);
    con_quietComboBox.setEnabled(false);
    con_en_savComboBox.setEnabled(false);
    con_otherComboBox.setEnabled(false);
    con_air_purifyComboBox.setEnabled(false);
    con_otherTextField.setEnabled(false);
    con_qualityTextField.setEnabled(false);
    con_en_savTextField.setEnabled(false);
    con_quietTextField.setEnabled(false);
    con_air_purifyTextField.setEnabled(false);
    price5TextField.setNextFocusableComponent(service1TextField);
    quality5TextField.setNextFocusableComponent(en_sav1TextField);
    ClusterButton.setText("Cluster");
    ClusterButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ClusterButton_actionPerformed(e);
      }
    });
    brand5TextField.setNextFocusableComponent(quality1TextField);
    brandLabel.setText("1. Brand");
    beauty5TextField.setNextFocusableComponent(price1TextField);
    beautyLabel.setText("6. Beauty");
    service5TextField.setNextFocusableComponent(other1TextField);
    serviceLabel.setText("8. Service after sell");
    con_brandTextField.setEnabled(false);
    con_brandComboBox.setEnabled(false);
    con_brandCheckBox.setText("Brand");
    con_brandCheckBox.setEnabled(false);
    con_beautyTextField.setEnabled(false);
    con_beautyComboBox.setEnabled(false);
    con_beautyCheckBox.setText("Beauty");
    con_beautyCheckBox.setEnabled(false);
    con_serviceTextField.setEnabled(false);
    con_serviceComboBox.setEnabled(false);
    con_serviceCheckBox.setText("Service after sell");
    con_serviceCheckBox.setEnabled(false);
    brand1TextField.setNextFocusableComponent(brand2TextField);
    other5TextField.setNextFocusableComponent(okButton);
    saveButton.setText("SaveConditions");
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        saveButton_actionPerformed(e);
      }
    });
    this.getContentPane().add(pd_noTextField, new XYConstraints(137, 13, 78, 20));
    this.getContentPane().add(pd_noLabel,  new XYConstraints(17, 17, -1, -1));
    this.getContentPane().add(en_savLabel, new XYConstraints(18, 125, -1, -1));
    this.getContentPane().add(qualityLabel, new XYConstraints(18, 100, -1, -1));
    this.getContentPane().add(PointLabel,   new XYConstraints(28, 45, -1, -1));
    this.getContentPane().add(tableScrollPane1,      new XYConstraints(374, 73, 603, 622));
    tableScrollPane1.getViewport().add(productdbTable, null);
    this.getContentPane().add(air_purifyLabel, new XYConstraints(18, 149, -1, -1));
    this.getContentPane().add(brandLabel, new XYConstraints(18, 75, -1, -1));
    this.getContentPane().add(otherLabel, new XYConstraints(18, 271, -1, -1));
    this.getContentPane().add(serviceLabel, new XYConstraints(18, 247, -1, -1));
    this.getContentPane().add(priceLabel, new XYConstraints(18, 223, -1, -1));
    this.getContentPane().add(beautyLabel, new XYConstraints(18, 199, -1, -1));
    this.getContentPane().add(quietLabel, new XYConstraints(18, 174, -1, -1));
    this.getContentPane().add(brand1TextField, new XYConstraints(125, 73, 25, -1));
    this.getContentPane().add(quality5TextField, new XYConstraints(325, 98, 25, -1));
    this.getContentPane().add(jLabel4, new XYConstraints(285, 45, -1, -1));
    this.getContentPane().add(jLabel5, new XYConstraints(335, 45, -1, -1));
    this.getContentPane().add(jLabel3, new XYConstraints(235, 45, -1, -1));
    this.getContentPane().add(jLabel2, new XYConstraints(185, 45, -1, -1));
    this.getContentPane().add(jLabel1, new XYConstraints(135, 45, -1, -1));
    this.getContentPane().add(quality1TextField, new XYConstraints(125, 98, 25, -1));
    this.getContentPane().add(quality2TextField, new XYConstraints(175, 98, 25, -1));
    this.getContentPane().add(quality3TextField, new XYConstraints(225, 98, 25, -1));
    this.getContentPane().add(quality4TextField, new XYConstraints(275, 98, 25, -1));
    this.getContentPane().add(en_sav5TextField, new XYConstraints(325, 123, 25, -1));
    this.getContentPane().add(en_sav1TextField, new XYConstraints(125, 123, 25, -1));
    this.getContentPane().add(en_sav2TextField, new XYConstraints(175, 123, 25, -1));
    this.getContentPane().add(en_sav3TextField, new XYConstraints(225, 123, 25, -1));
    this.getContentPane().add(en_sav4TextField, new XYConstraints(275, 123, 25, -1));
    this.getContentPane().add(air_purify5TextField, new XYConstraints(325, 147, 25, -1));
    this.getContentPane().add(air_purify2TextField, new XYConstraints(175, 147, 25, -1));
    this.getContentPane().add(air_purify3TextField, new XYConstraints(225, 147, 25, -1));
    this.getContentPane().add(air_purify4TextField, new XYConstraints(275, 147, 25, -1));
    this.getContentPane().add(air_purify1TextField, new XYConstraints(125, 147, 25, -1));
    this.getContentPane().add(brand5TextField, new XYConstraints(325, 73, 25, -1));
    this.getContentPane().add(brand2TextField, new XYConstraints(175, 73, 25, -1));
    this.getContentPane().add(brand3TextField, new XYConstraints(225, 73, 25, -1));
    this.getContentPane().add(brand4TextField, new XYConstraints(275, 73, 25, -1));
    this.getContentPane().add(quiet1TextField, new XYConstraints(125, 172, 25, -1));
    this.getContentPane().add(service1TextField, new XYConstraints(125, 245, 25, -1));
    this.getContentPane().add(other5TextField, new XYConstraints(325, 269, 25, -1));
    this.getContentPane().add(other2TextField, new XYConstraints(175, 269, 25, -1));
    this.getContentPane().add(other3TextField, new XYConstraints(225, 269, 25, -1));
    this.getContentPane().add(other4TextField, new XYConstraints(275, 269, 25, -1));
    this.getContentPane().add(other1TextField, new XYConstraints(125, 269, 25, -1));
    this.getContentPane().add(service5TextField, new XYConstraints(325, 245, 25, -1));
    this.getContentPane().add(service2TextField, new XYConstraints(175, 245, 25, -1));
    this.getContentPane().add(service3TextField, new XYConstraints(225, 245, 25, -1));
    this.getContentPane().add(service4TextField, new XYConstraints(275, 245, 25, -1));
    this.getContentPane().add(price1TextField, new XYConstraints(125, 221, 25, -1));
    this.getContentPane().add(price5TextField, new XYConstraints(325, 221, 25, -1));
    this.getContentPane().add(price2TextField, new XYConstraints(175, 221, 25, -1));
    this.getContentPane().add(price3TextField, new XYConstraints(225, 221, 25, -1));
    this.getContentPane().add(price4TextField, new XYConstraints(275, 221, 25, -1));
    this.getContentPane().add(beauty1TextField, new XYConstraints(125, 197, 25, -1));
    this.getContentPane().add(beauty2TextField, new XYConstraints(175, 197, 25, -1));
    this.getContentPane().add(beauty3TextField, new XYConstraints(225, 197, 25, -1));
    this.getContentPane().add(beauty4TextField, new XYConstraints(275, 197, 25, -1));
    this.getContentPane().add(beauty5TextField, new XYConstraints(325, 197, 25, -1));
    this.getContentPane().add(quiet5TextField, new XYConstraints(325, 172, 25, -1));
    this.getContentPane().add(quiet2TextField, new XYConstraints(175, 172, 25, -1));
    this.getContentPane().add(quiet3TextField, new XYConstraints(225, 172, 25, -1));
    this.getContentPane().add(quiet4TextField, new XYConstraints(275, 172, 25, -1));
    this.getContentPane().add(cancelButton, new XYConstraints(79, 295, -1, -1));
    this.getContentPane().add(okButton, new XYConstraints(15, 295, -1, -1));
    this.getContentPane().add(lead_conComboBox, new XYConstraints(15, 358, 105, -1));
    this.getContentPane().add(lead_conLabel, new XYConstraints(15, 344, -1, -1));
    this.getContentPane().add(lead_pointComboBox, new XYConstraints(123, 358, 40, -1));
    this.getContentPane().add(lead_pointLabel, new XYConstraints(123, 344, -1, -1));
    this.getContentPane().add(conditionLabel, new XYConstraints(17, 326, -1, -1));
    this.getContentPane().add(follow_conLabel, new XYConstraints(166, 344, -1, -1));
    this.getContentPane().add(follow_pointLabel, new XYConstraints(274, 344, -1, -1));
    this.getContentPane().add(con_percentLabel, new XYConstraints(317, 344, -1, -1));
    this.getContentPane().add(con_qualityTextField, new XYConstraints(317, 382, 27, -1));
    this.getContentPane().add(con_qualityCheckBox, new XYConstraints(166, 381, -1, -1));
    this.getContentPane().add(con_en_savCheckBox, new XYConstraints(166, 405, -1, -1));
    this.getContentPane().add(con_qualityComboBox, new XYConstraints(274, 382, 40, -1));
    this.getContentPane().add(con_en_savComboBox, new XYConstraints(274, 406, 40, -1));
    this.getContentPane().add(con_en_savTextField, new XYConstraints(317, 406, 27, -1));
    this.getContentPane().add(con_brandTextField,  new XYConstraints(317, 358, 27, -1));
    this.getContentPane().add(con_brandComboBox,  new XYConstraints(274, 358, 40, -1));
    this.getContentPane().add(con_brandCheckBox,  new XYConstraints(166, 358, -1, -1));
    this.getContentPane().add(con_air_purifyTextField, new XYConstraints(317, 429, 27, -1));
    this.getContentPane().add(con_air_purifyCheckBox, new XYConstraints(166, 428, -1, -1));
    this.getContentPane().add(con_air_purifyComboBox, new XYConstraints(274, 429, 40, -1));
    this.getContentPane().add(con_quietTextField, new XYConstraints(317, 452, 27, -1));
    this.getContentPane().add(con_quietCheckBox, new XYConstraints(166, 451, -1, -1));
    this.getContentPane().add(con_quietComboBox, new XYConstraints(274, 452, 40, -1));
    this.getContentPane().add(con_beautyTextField, new XYConstraints(317, 475, 27, -1));
    this.getContentPane().add(con_priceTextField, new XYConstraints(317, 498, 27, -1));
    this.getContentPane().add(con_priceCheckBox, new XYConstraints(166, 497, -1, -1));
    this.getContentPane().add(con_priceComboBox, new XYConstraints(274, 498, 40, -1));
    this.getContentPane().add(con_beautyComboBox, new XYConstraints(274, 475, 40, -1));
    this.getContentPane().add(con_beautyCheckBox, new XYConstraints(166, 474, -1, -1));
    this.getContentPane().add(con_serviceComboBox, new XYConstraints(274, 522, 40, -1));
    this.getContentPane().add(con_serviceTextField, new XYConstraints(317, 522, 27, -1));
    this.getContentPane().add(con_serviceCheckBox, new XYConstraints(166, 521, -1, -1));
    this.getContentPane().add(con_otherComboBox, new XYConstraints(274, 546, 40, -1));
    this.getContentPane().add(con_otherCheckBox, new XYConstraints(166, 545, -1, -1));
    this.getContentPane().add(con_otherTextField, new XYConstraints(317, 546, 27, -1));
    this.getContentPane().add(deleteButton, new XYConstraints(11, 539, 84, -1));
    this.getContentPane().add(jScrollPane1,   new XYConstraints(11, 572, 334, 94));
    this.getContentPane().add(insertButton, new XYConstraints(11, 508, 85, -1));
    this.getContentPane().add(deleteDataButton, new XYConstraints(11, 669, 113, -1));
    this.getContentPane().add(generateDataButton, new XYConstraints(132, 669, 113, -1));
    this.getContentPane().add(ClusterButton, new XYConstraints(255, 669, 113, 26));
    this.getContentPane().add(saveButton,       new XYConstraints(11, 476, 123, -1));
    jScrollPane1.getViewport().add(conditionJList, null);

  }


  void insertButton_actionPerformed(ActionEvent e) {
    int lead_con = lead_conComboBox.getSelectedIndex();
    int lead_point = lead_pointComboBox.getSelectedIndex();
    boolean follow_check[] = {
      con_brandCheckBox.isSelected(), con_qualityCheckBox.isSelected(),
      con_en_savCheckBox.isSelected(), con_air_purifyCheckBox.isSelected(),
      con_quietCheckBox.isSelected(), con_beautyCheckBox.isSelected(),
      con_priceCheckBox.isSelected(), con_serviceCheckBox.isSelected() ,
      con_otherCheckBox.isSelected()
      };
    int follow_point[] = {
      con_brandComboBox.getSelectedIndex() , con_qualityComboBox.getSelectedIndex(),
      con_en_savComboBox.getSelectedIndex(), con_air_purifyComboBox.getSelectedIndex(),
      con_quietComboBox.getSelectedIndex(), con_beautyComboBox.getSelectedIndex() ,
      con_priceComboBox.getSelectedIndex(), con_serviceComboBox.getSelectedIndex() ,
      con_otherComboBox.getSelectedIndex()
      };
    String follow_per[] = {
      con_brandTextField.getText(), con_qualityTextField.getText() ,
      con_en_savTextField.getText(), con_air_purifyTextField.getText(),
      con_quietTextField.getText(), con_beautyTextField.getText() ,
      con_priceTextField.getText(), con_serviceTextField.getText(),
      con_otherTextField.getText()
      };
    int[] tmpint = new int[maxtype];
    for (int ii=0; ii<maxtype; ii++){
      tmpint[ii] = 0;
    }
    boolean isconcorrect = true;
    if (inputarr[lead_con][lead_point] != -1) {
      for (int i=0; i<maxtype; i++){
      if (follow_check[i]){
        if (follow_per[i].length() != 0) {
        if ((inputarr[i][follow_point[i]] != -1)){
          if ((pd_no*inputarr[lead_con][lead_point]/100.0 * Double.parseDouble(follow_per[i])/100.0 + currentarr[i][follow_point[i]]) <= limit[i][follow_point[i]]) {
            tmpint[i] = (int)(pd_no*inputarr[lead_con][lead_point]/100.0 * Double.parseDouble(follow_per[i])/100.0);
          } else {
            isconcorrect = false;
            JOptionPane.showMessageDialog(null,"Percent of follow condition over limit!","Insert error",JOptionPane.ERROR_MESSAGE);
          }
        } else {
          isconcorrect = false;
          JOptionPane.showMessageDialog(null,"Follow condition "+buy_causestr[i]+" at "+(follow_point[i]+1) +" point not have initial percent value!","Insert error",JOptionPane.ERROR_MESSAGE);
        }
        } else {
          isconcorrect = false;
          JOptionPane.showMessageDialog(null,"Follow condition not have percent value!","Insert error",JOptionPane.ERROR_MESSAGE);
        }
      }
      }
    } else {
      isconcorrect = false;
      JOptionPane.showMessageDialog(null,"Lead condition "+buy_causestr[lead_con]+" at "+(lead_point+1)+" point not have initial percent value!","Insert error",JOptionPane.ERROR_MESSAGE);
    }
    if (isconcorrect) {
      for (int iii=0; iii<maxtype; iii++){
        currentarr[iii][follow_point[iii]] += tmpint[iii];
      }
      lead_conList.add(String.valueOf(lead_con));
      lead_pointList.add(String.valueOf(lead_point));
      for (int i=0; i<maxtype; i++){
        con_checkList[i].add(String.valueOf(follow_check[i]));
        con_pointList[i].add(String.valueOf(follow_point[i]));
        con_perList[i].add(follow_per[i]);
      }
      String tmpstr;
      tmpstr = "lead cond = " + buy_causestr[lead_con] + ", " +(lead_point+1)+" points; ";
      tmpstr = tmpstr + "follow condition = ";
      for (int i=0; i<maxtype; i++){
        if (follow_check[i]){
          tmpstr = tmpstr + buy_causestr[i] +", "+ (follow_point[i]+1)+" points; "+follow_per[i]+"%";
        }
      }
      conditionList.add(tmpstr);
      String tmpstr2[] = new String[conditionList.size()];
      for (int i=0; i<conditionList.size(); i++){
        tmpstr2[i] = String.valueOf(conditionList.get(i));
      }
      conditionJList.setListData(tmpstr2);
      conditionJList.repaint();
    }
  }
  void deleteButton_actionPerformed(ActionEvent e) {
    if (!conditionJList.isSelectionEmpty()){
      for (int i=0; i<conditionJList.getHeight(); i++){
        if (conditionJList.isSelectedIndex(i)){
          for (int type=0; type<maxtype; type++){
            if (String.valueOf(con_checkList[type].get(i))=="true"){
              currentarr[type][Integer.parseInt(String.valueOf(con_pointList[type].get(i)))] -=
                        (pd_no*inputarr[Integer.parseInt(String.valueOf(lead_conList.get(i)))][Integer.parseInt(String.valueOf(lead_pointList.get(i)))]/100.0
                        *Double.parseDouble(String.valueOf(con_perList[type].get(i)))/100.0);
            }
            con_checkList[type].remove(i);
            con_pointList[type].remove(i);
            con_perList[type].remove(i);
          }
          conditionList.remove(i);
          lead_conList.remove(i);
          lead_pointList.remove(i);
          String tmpstr2[] = new String[conditionList.size()];
          for (int j=0; j<conditionList.size(); j++){
            tmpstr2[j] = String.valueOf(conditionList.get(j));
          }
          conditionJList.setListData(tmpstr2);
        }
      }
      conditionJList.repaint();
    }
  }
  void generateDataButton_actionPerformed(ActionEvent e) {

    try {
      database1.closeConnection();
      // connect to data base
      queryExecute = new QueryExecute( JDBC_DRIVER, DATABASE_URL);
      int nhadgen=0;
      int tempcurrentarr[][] = new int[maxtype][maxpoint];
      for (int x=0; x<maxtype; x++)
        for (int y=0; y<maxpoint; y++)
          tempcurrentarr[x][y] = currentarr[x][y];

      for (int ncond=0; ncond<conditionList.size(); ncond++){

        int nlimit[] = new int[maxtype];

        for (int xx=0; xx<maxtype; xx++)
          nlimit[xx] = 0;

        int nwillgen;
        int percentmax =0;
        for (int type=0; type<maxtype; type++){
          if (String.valueOf(con_checkList[type].get(ncond))=="true"){
            int tmpper = Integer.parseInt(String.valueOf(con_perList[type].get(ncond)));
            if (tmpper > percentmax) {
              percentmax = tmpper;
            }
            nlimit[type] =(int)(tmpper/100.0*
                   inputarr[Integer.parseInt(String.valueOf(lead_conList.get(ncond)))][Integer.parseInt(String.valueOf(lead_pointList.get(ncond)))]
                   /100*pd_no);
          }
        }
        nwillgen = (int)(percentmax/100.0*
                   inputarr[Integer.parseInt(String.valueOf(lead_conList.get(ncond)))][Integer.parseInt(String.valueOf(lead_pointList.get(ncond)))]
                   /100*pd_no);
        for (int n=1; n<=nwillgen; n++){
          query = "INSERT INTO PRODUCT (BUY_BRAND,BUY_QUALITY,BUY_SAVE_ENERGY,BUY_AIR_PURIFY,BUY_QUIET,BUY_BEAUTY,BUY_PRICE,BUY_SERVICE,BUY_OTHER)";
          query = query+" VALUES (";
          int point[] = new int[maxtype];
          for (int zz=0; zz<maxtype; zz++)
            point[zz]=0;

//////////////////////***************************888
          int temm = Integer.parseInt(String.valueOf(lead_pointList.get(ncond)));
          point[Integer.parseInt(String.valueOf(lead_conList.get(ncond)))] = temm+1;
          currentarr[Integer.parseInt(String.valueOf(lead_conList.get(ncond)))][temm]++;
          for (int type1=0; type1<maxtype; type1++){
            if ((type1!=Integer.parseInt(String.valueOf(lead_conList.get(ncond))))&&(String.valueOf(con_checkList[type1].get(ncond)))=="true"){
              if (n<=nlimit[type1]){
                point[type1] = Integer.parseInt(String.valueOf(con_pointList[type1].get(ncond)))+1;

              }
            }
            if ((type1!=Integer.parseInt(String.valueOf(lead_conList.get(ncond))))&&(point[type1] == 0)) {
              point[type1] = randomPoint(type1);
              currentarr[type1][point[type1]-1]++;
            }
          }

//        query = query + point[0] + "," + point[1] + "," + point[2] + "," + point[3] + "," + point[4] +","+ point[5] + ")";
          for (int zzz=0; zzz<maxtype; zzz++){
            query += point[zzz];
            if (zzz < maxtype-1) query += ",";
          }

//          query.substring(0,query.length()-1);
          query = query + ")";
          queryExecute.setQuery(query);
          nhadgen++;
        } // end for nwillgen
      } // end for ncond

      for(int i=nhadgen;i<pd_no;i++){
        query = "INSERT INTO PRODUCT (BUY_BRAND,BUY_QUALITY,BUY_SAVE_ENERGY,BUY_AIR_PURIFY,BUY_QUIET,BUY_BEAUTY,BUY_PRICE,BUY_SERVICE,BUY_OTHER)";
        query = query+" VALUES (";
        int point[] = new int[maxtype];
        for (int type=0; type<maxtype; type++){
          point[type] = randomPoint(type);
          currentarr[type][point[type]-1]++;
        }
//        query = query + point[0] + "," + point[1] + "," + point[2] + "," + point[3] + "," + point[4] + ","+ point[5] + ")";
        for (int zzzz=0; zzzz<maxtype; zzzz++){
            query += point[zzzz];
            if (zzzz < maxtype-1) query += ",";
        }

//        query.substring(0,query.length()-1);
        query = query + ")";
        queryExecute.setQuery(query);
      }

      queryExecute.disconnectFromDatabase();
      database1.openConnection();
      queryDataSet1.refresh();
      for (int x=0; x<maxtype; x++)
        for (int y=0; y<maxpoint; y++)
          currentarr[x][y] = tempcurrentarr[x][y];
    }// end try

    // detect problems interaction with the database
    catch ( SQLException sqlException ) {
      JOptionPane.showMessageDialog ( null, sqlException.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE );
      queryExecute.disconnectFromDatabase() ;
    }
    // detect problems loading database driver
    catch ( ClassNotFoundException classNotFound ) {
      JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
                                   "Driver Not Found", JOptionPane.ERROR_MESSAGE );
      System.exit( 1 );
    }
    ClusterButton.setEnabled(true);
  }
  void deleteDataButton_actionPerformed(ActionEvent e) {
    try {
              database1.closeConnection();
              queryExecute = new QueryExecute( JDBC_DRIVER, DATABASE_URL);
              query ="DELETE FROM PRODUCT";
              queryExecute.setQuery(query);
              queryExecute.disconnectFromDatabase();
              database1.openConnection();
              queryDataSet1.refresh();
            }
            // detect problems interaction with the database
            catch ( SQLException sqlException ) {
              JOptionPane.showMessageDialog ( null, sqlException.getMessage(),
                                              "Database Error", JOptionPane.ERROR_MESSAGE );
              queryExecute.disconnectFromDatabase() ;

            //  System.exit( 1 );
            }
            // detect problems loading database driver
            catch ( ClassNotFoundException classNotFound ) {
              JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
                                             "Driver Not Found", JOptionPane.ERROR_MESSAGE );
              System.exit( 1 );
    }
  }

  void okButton_actionPerformed(ActionEvent e) {
    if (pd_noTextField.getText().length() != 0){
      pd_no = Integer.parseInt(pd_noTextField.getText());
      boolean isCorrect = true;
      double per=0.0;
      int count=0;
      if ( price1TextField.getText().length() != 0 ){
        per += Integer.parseInt(price1TextField.getText());
        count++;
      }
      if ( price2TextField.getText().length() != 0 ){
        per += Integer.parseInt(price2TextField.getText());
        count++;
      }
      if ( price3TextField.getText().length() != 0 ){
        per += Integer.parseInt(price3TextField.getText());
        count++;
      }
      if ( price4TextField.getText().length() != 0 ){
        per += Integer.parseInt(price4TextField.getText());
        count++;
      }
      if ( price5TextField.getText().length() != 0 ){
        per += Integer.parseInt(price5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      per = 0.0;
      count =0;
      if ( quality1TextField.getText().length() != 0 ){
        per += Integer.parseInt(quality1TextField.getText());
        count++;
      }
      if ( quality2TextField.getText().length() != 0 ){
        per += Integer.parseInt(quality2TextField.getText());
        count++;
      }
      if ( quality3TextField.getText().length() != 0 ){
        per += Integer.parseInt(quality3TextField.getText());
        count++;
      }
      if ( quality4TextField.getText().length() != 0 ){
        per += Integer.parseInt(quality4TextField.getText());
        count++;
      }
      if ( quality5TextField.getText().length() != 0 ){
        per += Integer.parseInt(quality5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      per = 0.0;
      count =0;
      if ( en_sav1TextField.getText().length() != 0 ){
        per += Integer.parseInt(en_sav1TextField.getText());
        count++;
      }
      if ( en_sav2TextField.getText().length() != 0 ){
        per += Integer.parseInt(en_sav2TextField.getText());
        count++;
      }
      if ( en_sav3TextField.getText().length() != 0 ){
        per += Integer.parseInt(en_sav3TextField.getText());
        count++;
      }
      if ( en_sav4TextField.getText().length() != 0 ){
        per += Integer.parseInt(en_sav4TextField.getText());
        count++;
      }
      if ( en_sav5TextField.getText().length() != 0 ){
        per += Integer.parseInt(en_sav5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;
      per = 0.0;
      count =0;
      if ( quiet1TextField.getText().length() != 0 ){
        per += Integer.parseInt(quiet1TextField.getText());
        count++;
      }
      if ( quiet2TextField.getText().length() != 0 ){
        per += Integer.parseInt(quiet2TextField.getText());
        count++;
      }
      if ( quiet3TextField.getText().length() != 0 ){
        per += Integer.parseInt(quiet3TextField.getText());
        count++;
      }
      if ( quiet4TextField.getText().length() != 0 ){
        per += Integer.parseInt(quiet4TextField.getText());
        count++;
      }
      if ( quiet5TextField.getText().length() != 0 ){
        per += Integer.parseInt(quiet5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;
      per = 0.0;
      count =0;
      if ( air_purify1TextField.getText().length() != 0 ){
        per += Integer.parseInt(air_purify1TextField.getText());
        count++;
      }
      if ( air_purify2TextField.getText().length() != 0 ){
        per += Integer.parseInt(air_purify2TextField.getText());
        count++;
      }
      if ( air_purify3TextField.getText().length() != 0 ){
        per += Integer.parseInt(air_purify3TextField.getText());
        count++;
      }
      if ( air_purify4TextField.getText().length() != 0 ){
        per += Integer.parseInt(air_purify4TextField.getText());
        count++;
      }
      if ( air_purify5TextField.getText().length() != 0 ){
        per += Integer.parseInt(air_purify5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      per = 0.0;
      count =0;
      if ( other1TextField.getText().length() != 0 ){
        per += Integer.parseInt(other1TextField.getText());
        count++;
      }
      if ( other2TextField.getText().length() != 0 ){
        per += Integer.parseInt(other2TextField.getText());
        count++;
      }
      if ( other3TextField.getText().length() != 0 ){
        per += Integer.parseInt(other3TextField.getText());
        count++;
      }
      if ( other4TextField.getText().length() != 0 ){
        per += Integer.parseInt(other4TextField.getText());
        count++;
      }
      if ( other5TextField.getText().length() != 0 ){
        per += Integer.parseInt(other5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      per = 0.0;
      count =0;
      if ( brand1TextField.getText().length() != 0 ){
        per += Integer.parseInt(brand1TextField.getText());
        count++;
      }
      if ( brand2TextField.getText().length() != 0 ){
        per += Integer.parseInt(brand2TextField.getText());
        count++;
      }
      if ( brand3TextField.getText().length() != 0 ){
        per += Integer.parseInt(brand3TextField.getText());
        count++;
      }
      if ( brand4TextField.getText().length() != 0 ){
        per += Integer.parseInt(brand4TextField.getText());
        count++;
      }
      if ( brand5TextField.getText().length() != 0 ){
        per += Integer.parseInt(brand5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      per = 0.0;
      count =0;
      if ( beauty1TextField.getText().length() != 0 ){
        per += Integer.parseInt(beauty1TextField.getText());
        count++;
      }
      if ( beauty2TextField.getText().length() != 0 ){
        per += Integer.parseInt(beauty2TextField.getText());
        count++;
      }
      if ( beauty3TextField.getText().length() != 0 ){
        per += Integer.parseInt(beauty3TextField.getText());
        count++;
      }
      if ( beauty4TextField.getText().length() != 0 ){
        per += Integer.parseInt(beauty4TextField.getText());
        count++;
      }
      if ( beauty5TextField.getText().length() != 0 ){
        per += Integer.parseInt(beauty5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      per = 0.0;
      count =0;
      if ( service1TextField.getText().length() != 0 ){
        per += Integer.parseInt(service1TextField.getText());
        count++;
      }
      if ( service2TextField.getText().length() != 0 ){
        per += Integer.parseInt(service2TextField.getText());
        count++;
      }
      if ( service3TextField.getText().length() != 0 ){
        per += Integer.parseInt(service3TextField.getText());
        count++;
      }
      if ( service4TextField.getText().length() != 0 ){
        per += Integer.parseInt(service4TextField.getText());
        count++;
      }
      if ( service5TextField.getText().length() != 0 ){
        per += Integer.parseInt(service5TextField.getText());
        count++;
      }
      if ((per!=100.0)&&(count==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;

      if (isCorrect){

         if (brand1TextField.getText().length() == 0){
           inputarr[0][0] = -1;
           } else inputarr[0][0] = Integer.parseInt(brand1TextField.getText()) ;
         if (brand2TextField.getText().length() == 0){
           inputarr[0][1] = -1;
           } else inputarr[0][1] = Integer.parseInt(brand2TextField.getText()) ;
         if (brand3TextField.getText().length() == 0){
           inputarr[0][2] = -1;
           } else inputarr[0][2] = Integer.parseInt(brand3TextField.getText()) ;
         if (brand4TextField.getText().length() == 0){
           inputarr[0][3] = -1;
           } else inputarr[0][3] = Integer.parseInt(brand4TextField.getText()) ;
         if (brand5TextField.getText().length() == 0){
           inputarr[0][4] = -1;
           } else inputarr[0][4] = Integer.parseInt(brand5TextField.getText()) ;

         if (quality1TextField.getText().length() == 0){
           inputarr[1][0] = -1;
         } else inputarr[1][0] = Integer.parseInt(quality1TextField.getText()) ;
         if (quality2TextField.getText().length() == 0){
           inputarr[1][1] = -1;
         } else inputarr[1][1] = Integer.parseInt(quality2TextField.getText()) ;
         if (quality3TextField.getText().length() == 0){
           inputarr[1][2] = -1;
         } else inputarr[1][2] = Integer.parseInt(quality3TextField.getText()) ;
         if (quality4TextField.getText().length() == 0){
           inputarr[1][3] = -1;
         } else inputarr[1][3] = Integer.parseInt(quality4TextField.getText()) ;
         if (quality5TextField.getText().length() == 0){
           inputarr[1][4] = -1;
         } else inputarr[1][4] = Integer.parseInt(quality5TextField.getText()) ;

         if (en_sav1TextField.getText().length() == 0){
           inputarr[2][0] = -1;
         } else inputarr[2][0] = Integer.parseInt(en_sav1TextField.getText()) ;
         if (en_sav2TextField.getText().length() == 0){
           inputarr[2][1] = -1;
         } else inputarr[2][1] = Integer.parseInt(en_sav2TextField.getText()) ;
         if (en_sav3TextField.getText().length() == 0){
           inputarr[2][2] = -1;
         } else inputarr[2][2] = Integer.parseInt(en_sav3TextField.getText()) ;
         if (en_sav4TextField.getText().length() == 0){
           inputarr[2][3] = -1;
         } else inputarr[2][3] = Integer.parseInt(en_sav4TextField.getText()) ;
         if (en_sav5TextField.getText().length() == 0){
           inputarr[2][4] = -1;
         } else inputarr[2][4] = Integer.parseInt(en_sav5TextField.getText()) ;

         if (air_purify1TextField.getText().length() == 0){
           inputarr[3][0] = -1;
           } else inputarr[3][0] = Integer.parseInt(air_purify1TextField.getText()) ;
         if (air_purify2TextField.getText().length() == 0){
           inputarr[3][1] = -1;
           } else inputarr[3][1] = Integer.parseInt(air_purify2TextField.getText()) ;
         if (air_purify3TextField.getText().length() == 0){
           inputarr[3][2] = -1;
           } else inputarr[3][2] = Integer.parseInt(air_purify3TextField.getText()) ;
         if (air_purify4TextField.getText().length() == 0){
           inputarr[3][3] = -1;
           } else inputarr[3][3] = Integer.parseInt(air_purify4TextField.getText()) ;
         if (air_purify5TextField.getText().length() == 0){
           inputarr[3][4] = -1;
           } else inputarr[3][4] = Integer.parseInt(air_purify5TextField.getText()) ;

         if (quiet1TextField.getText().length() == 0){
           inputarr[4][0] = -1;
         } else inputarr[4][0] = Integer.parseInt(quiet1TextField.getText()) ;
         if (quiet2TextField.getText().length() == 0){
           inputarr[4][1] = -1;
           } else inputarr[4][1] = Integer.parseInt(quiet2TextField.getText()) ;
         if (quiet3TextField.getText().length() == 0){
           inputarr[4][2] = -1;
           } else inputarr[4][2] = Integer.parseInt(quiet3TextField.getText()) ;
         if (quiet4TextField.getText().length() == 0){
           inputarr[4][3] = -1;
           } else inputarr[4][3] = Integer.parseInt(quiet4TextField.getText()) ;
         if (quiet5TextField.getText().length() == 0){
           inputarr[4][4] = -1;
           } else inputarr[4][4] = Integer.parseInt(quiet5TextField.getText()) ;

         if (beauty1TextField.getText().length() == 0){
           inputarr[5][0] = -1;
           } else inputarr[5][0] = Integer.parseInt(beauty1TextField.getText()) ;
         if (beauty2TextField.getText().length() == 0){
           inputarr[5][1] = -1;
           } else inputarr[5][1] = Integer.parseInt(beauty2TextField.getText()) ;
         if (beauty3TextField.getText().length() == 0){
           inputarr[5][2] = -1;
           } else inputarr[5][2] = Integer.parseInt(beauty3TextField.getText()) ;
         if (beauty4TextField.getText().length() == 0){
           inputarr[5][3] = -1;
           } else inputarr[5][3] = Integer.parseInt(beauty4TextField.getText()) ;
         if (beauty5TextField.getText().length() == 0){
           inputarr[5][4] = -1;
           } else inputarr[5][4] = Integer.parseInt(beauty5TextField.getText()) ;

         if (price1TextField.getText().length() == 0){
           inputarr[6][0] = -1;
         } else inputarr[6][0] = Integer.parseInt(price1TextField.getText()) ;
         if (price2TextField.getText().length() == 0){
           inputarr[6][1] = -1;
         } else inputarr[6][1] = Integer.parseInt(price2TextField.getText()) ;
         if (price3TextField.getText().length() == 0){
           inputarr[6][2] = -1;
         } else inputarr[6][2] = Integer.parseInt(price3TextField.getText()) ;
         if (price4TextField.getText().length() == 0){
           inputarr[6][3] = -1;
         } else inputarr[6][3] = Integer.parseInt(price4TextField.getText()) ;
         if (price5TextField.getText().length() == 0){
           inputarr[6][4] = -1;
         } else inputarr[6][4] = Integer.parseInt(price5TextField.getText()) ;

         if (service1TextField.getText().length() == 0){
           inputarr[7][0] = -1;
           } else inputarr[7][0] = Integer.parseInt(service1TextField.getText()) ;
         if (service2TextField.getText().length() == 0){
           inputarr[7][1] = -1;
           } else inputarr[7][1] = Integer.parseInt(service2TextField.getText()) ;
         if (service3TextField.getText().length() == 0){
           inputarr[7][2] = -1;
           } else inputarr[7][2] = Integer.parseInt(service3TextField.getText()) ;
         if (service4TextField.getText().length() == 0){
           inputarr[7][3] = -1;
           } else inputarr[7][3] = Integer.parseInt(service4TextField.getText()) ;
         if (service5TextField.getText().length() == 0){
           inputarr[7][4] = -1;
           } else inputarr[7][4] = Integer.parseInt(service5TextField.getText()) ;

         if (other1TextField.getText().length() == 0){
           inputarr[8][0] = -1;
           } else inputarr[8][0] = Integer.parseInt(other1TextField.getText()) ;
         if (other2TextField.getText().length() == 0){
           inputarr[8][1] = -1;
           } else inputarr[8][1] = Integer.parseInt(other2TextField.getText()) ;
         if (other3TextField.getText().length() == 0){
           inputarr[8][2] = -1;
           } else inputarr[8][2] = Integer.parseInt(other3TextField.getText()) ;
         if (other4TextField.getText().length() == 0){
           inputarr[8][3] = -1;
           } else inputarr[8][3] = Integer.parseInt(other4TextField.getText()) ;
         if (other5TextField.getText().length() == 0){
           inputarr[8][4] = -1;
           } else inputarr[8][4] = Integer.parseInt(other5TextField.getText()) ;

         cancelButton.setEnabled(true);
         insertButton.setEnabled(true);
         deleteButton.setEnabled(true);
         deleteDataButton.setEnabled(true);
         generateDataButton.setEnabled(true);

         okButton.setEnabled(false);


         pd_noTextField.setEnabled(false);
         SetEnableInput(false);
/*
         price1TextField.setEnabled(false);
         price2TextField.setEnabled(false);
         price3TextField.setEnabled(false);
         price4TextField.setEnabled(false);
         price5TextField.setEnabled(false);

         quality1TextField.setEnabled(false);
         quality2TextField.setEnabled(false);
         quality3TextField.setEnabled(false);
         quality4TextField.setEnabled(false);
         quality5TextField.setEnabled(false);

         en_sav1TextField.setEnabled(false);
         en_sav2TextField.setEnabled(false);
         en_sav3TextField.setEnabled(false);
         en_sav4TextField.setEnabled(false);
         en_sav5TextField.setEnabled(false);

         quiet2TextField.setEnabled(false);
         quiet3TextField.setEnabled(false);
         quiet4TextField.setEnabled(false);
         quiet5TextField.setEnabled(false);
         quiet1TextField.setEnabled(false);

         air_purify1TextField.setEnabled(false);
         air_purify2TextField.setEnabled(false);
         air_purify3TextField.setEnabled(false);
         air_purify4TextField.setEnabled(false);
         air_purify5TextField.setEnabled(false);

         other1TextField.setEnabled(false);
         other2TextField.setEnabled(false);
         other3TextField.setEnabled(false);
         other4TextField.setEnabled(false);
         other5TextField.setEnabled(false);

         brand1TextField.setEnabled(false);
         brand2TextField.setEnabled(false);
         brand3TextField.setEnabled(false);
         brand4TextField.setEnabled(false);
         brand5TextField.setEnabled(false);

         beauty1TextField.setEnabled(false);
         beauty2TextField.setEnabled(false);
         beauty3TextField.setEnabled(false);
         beauty4TextField.setEnabled(false);
         beauty5TextField.setEnabled(false);

         service1TextField.setEnabled(false);
         service2TextField.setEnabled(false);
         service3TextField.setEnabled(false);
         service4TextField.setEnabled(false);
         service5TextField.setEnabled(false);
         */
         SetEnableCon(true);

         for (int i=0; i<maxtype; i++){
           for (int j=0; j<maxpoint; j++){
             if (inputarr[i][j] <0) limit[i][j]= -1;
             else
               limit[i][j] = (int)(inputarr[i][j]*pd_no/100.0);
           }
         }
       } else JOptionPane.showMessageDialog( null, "all Percent of each Product's point must not over or less than 100%",
                                                   "Input error", JOptionPane.ERROR_MESSAGE );
    } else JOptionPane.showMessageDialog(null,"Must have number of products",
                                              "Input Error", JOptionPane.ERROR_MESSAGE );

  }

  void cancelButton_actionPerformed(ActionEvent e) {
    for (int i=0; i<maxtype; i++){
      for(int j=0; j<maxpoint; j++){
        currentarr[i][j] =0;
      }
    }
    conditionList.clear();
    conditionJList.removeAll();
    conditionJList.repaint();
    lead_conList.clear();
    lead_pointList.clear();
    con_price_checkList.clear();
    con_price_pointList.clear();
    con_price_perList.clear();
    con_quality_checkList.clear();
    con_quality_pointList.clear();
    con_quality_perList.clear();
    con_en_sav_checkList.clear();
    con_en_sav_pointList.clear();
    con_en_sav_perList.clear();
    con_quiet_checkList.clear();
    con_quiet_pointList.clear();
    con_quiet_perList.clear();
    con_air_purify_checkList.clear();
    con_air_purify_pointList.clear();
    con_air_purify_perList.clear();
    con_other_checkList.clear();
    con_other_pointList.clear();
    con_other_perList.clear();

    con_brand_checkList.clear();
    con_brand_pointList.clear();
    con_brand_perList.clear();

    con_beauty_checkList.clear();
    con_beauty_pointList.clear();
    con_beauty_perList.clear();

    con_service_checkList.clear();
    con_service_pointList.clear();
    con_service_perList.clear();

    String tmpstr2[] = {""};
    conditionJList.setListData(tmpstr2);
    conditionJList.repaint();
    SetEnableCon(false);
/*
    lead_conComboBox.setEnabled(false);
    lead_pointComboBox.setEnabled(false);
    con_priceComboBox.setEnabled(false);
    con_qualityComboBox.setEnabled(false);
    con_en_savComboBox.setEnabled(false);
    con_quietComboBox.setEnabled(false);
    con_air_purifyComboBox.setEnabled(false);
    con_otherComboBox.setEnabled(false);
    con_brandComboBox.setEnabled(false);
    con_beautyComboBox.setEnabled(false);
    con_serviceComboBox.setEnabled(false);

    con_priceCheckBox.setEnabled(false);
    con_qualityCheckBox.setEnabled(false);
    con_en_savCheckBox.setEnabled(false);
    con_quietCheckBox.setEnabled(false);
    con_air_purifyCheckBox.setEnabled(false);
    con_otherCheckBox.setEnabled(false);
    con_brandCheckBox.setEnabled(false);
    con_serviceCheckBox.setEnabled(false);
    con_beautyCheckBox.setEnabled(false);

    con_priceTextField.setEnabled(false);
    con_qualityTextField.setEnabled(false);
    con_en_savTextField.setEnabled(false);
    con_quietTextField.setEnabled(false);
    con_air_purifyTextField.setEnabled(false);
    con_otherTextField.setEnabled(false);
    con_brandTextField.setEnabled(false);
    con_beautyTextField.setEnabled(false);
    con_serviceTextField.setEnabled(false);
*/
    cancelButton.setEnabled(false);
    insertButton.setEnabled(false);
    deleteButton.setEnabled(false);
    generateDataButton.setEnabled(false);

    okButton.setEnabled(true);

    pd_noTextField.setEnabled(true);

    SetEnableInput(true);

    price1TextField.setText("");
    price2TextField.setText("");
    price3TextField.setText("");
    price4TextField.setText("");
    price5TextField.setText("");

    quality1TextField.setText("");
    quality2TextField.setText("");
    quality3TextField.setText("");
    quality4TextField.setText("");
    quality5TextField.setText("");

    en_sav1TextField.setText("");
    en_sav2TextField.setText("");
    en_sav3TextField.setText("");
    en_sav4TextField.setText("");
    en_sav5TextField.setText("");

    quiet2TextField.setText("");
    quiet3TextField.setText("");
    quiet4TextField.setText("");
    quiet5TextField.setText("");
    quiet1TextField.setText("");

    air_purify1TextField.setText("");
    air_purify2TextField.setText("");
    air_purify3TextField.setText("");
    air_purify4TextField.setText("");
    air_purify5TextField.setText("");

    other1TextField.setText("");
    other2TextField.setText("");
    other3TextField.setText("");
    other4TextField.setText("");
    other5TextField.setText("");

    brand1TextField.setText("");
    brand2TextField.setText("");
    brand3TextField.setText("");
    brand4TextField.setText("");
    brand5TextField.setText("");

    beauty1TextField.setText("");
    beauty2TextField.setText("");
    beauty3TextField.setText("");
    beauty4TextField.setText("");
    beauty5TextField.setText("");

    service1TextField.setText("");
    service2TextField.setText("");
    service3TextField.setText("");
    service4TextField.setText("");
    service5TextField.setText("");
  }

  void lead_conComboBox_actionPerformed(ActionEvent e) {
    SetEnableCon(true);
  }
  int randomPoint(int n){
    List ranList = new LinkedList();
    for (int i=0;i<maxpoint;i++){
      if (limit[n][i]>=0){
        if (currentarr[n][i]+1<=limit[n][i]){
          if ((Math.random()*100)<=inputarr[n][i])
            ranList.add(String.valueOf(i+1));
        }
      }
    }
    if (ranList.size()==0){
      for (int i=0;i<maxpoint;i++)
        if (limit[n][i]<0) ranList.add(String.valueOf(i+1));
    }
    int tmp = (int)(Math.random()*ranList.size())  ;
    return Integer.parseInt(String.valueOf(ranList.get(tmp))) ;
  }

  void ClusterButton_actionPerformed(ActionEvent e) {
         Cluster cl = new Cluster();
         cl.setSize( 1000,750 );
         cl.setVisible(true);
  }
  void SetEnableInput(boolean bool){
    price1TextField.setEnabled(bool);
    price2TextField.setEnabled(bool);
    price3TextField.setEnabled(bool);
    price4TextField.setEnabled(bool);
    price5TextField.setEnabled(bool);

    quality1TextField.setEnabled(bool);
    quality2TextField.setEnabled(bool);
    quality3TextField.setEnabled(bool);
    quality4TextField.setEnabled(bool);
    quality5TextField.setEnabled(bool);

    en_sav1TextField.setEnabled(bool);
    en_sav2TextField.setEnabled(bool);
    en_sav3TextField.setEnabled(bool);
    en_sav4TextField.setEnabled(bool);
    en_sav5TextField.setEnabled(bool);

    quiet2TextField.setEnabled(bool);
    quiet3TextField.setEnabled(bool);
    quiet4TextField.setEnabled(bool);
    quiet5TextField.setEnabled(bool);
    quiet1TextField.setEnabled(bool);

    air_purify1TextField.setEnabled(bool);
    air_purify2TextField.setEnabled(bool);
    air_purify3TextField.setEnabled(bool);
    air_purify4TextField.setEnabled(bool);
    air_purify5TextField.setEnabled(bool);

    other1TextField.setEnabled(bool);
    other2TextField.setEnabled(bool);
    other3TextField.setEnabled(bool);
    other4TextField.setEnabled(bool);
    other5TextField.setEnabled(bool);

    brand1TextField.setEnabled(bool);
    brand2TextField.setEnabled(bool);
    brand3TextField.setEnabled(bool);
    brand4TextField.setEnabled(bool);
    brand5TextField.setEnabled(bool);

    beauty1TextField.setEnabled(bool);
    beauty2TextField.setEnabled(bool);
    beauty3TextField.setEnabled(bool);
    beauty4TextField.setEnabled(bool);
    beauty5TextField.setEnabled(bool);

    service1TextField.setEnabled(bool);
    service2TextField.setEnabled(bool);
    service3TextField.setEnabled(bool);
    service4TextField.setEnabled(bool);
    service5TextField.setEnabled(bool);
  }
  void SetEnableCon(boolean bool){
    lead_conComboBox.setEnabled(bool);
    lead_pointComboBox.setEnabled(bool);

    con_priceComboBox.setEnabled(bool) ;
    con_qualityComboBox.setEnabled(bool);
    con_en_savComboBox.setEnabled(bool);
    con_quietComboBox.setEnabled(bool);
    con_air_purifyComboBox.setEnabled(bool);
    con_otherComboBox.setEnabled(bool);
    con_brandComboBox.setEnabled(bool);
    con_beautyComboBox.setEnabled(bool);
    con_serviceComboBox.setEnabled(bool);

    con_priceCheckBox.setEnabled(bool);
    con_qualityCheckBox.setEnabled(bool);
    con_en_savCheckBox.setEnabled(bool);
    con_quietCheckBox.setEnabled(bool);
    con_air_purifyCheckBox.setEnabled(bool);
    con_otherCheckBox.setEnabled(bool);
    con_brandCheckBox.setEnabled(bool);
    con_beautyCheckBox.setEnabled(bool);
    con_serviceCheckBox.setEnabled(bool);

    con_priceTextField.setEnabled(bool);
    con_qualityTextField.setEnabled(bool);
    con_en_savTextField.setEnabled(bool);
    con_quietTextField.setEnabled(bool);
    con_air_purifyTextField.setEnabled(bool);
    con_otherTextField.setEnabled(bool);
    con_brandTextField.setEnabled(bool);
    con_beautyTextField.setEnabled(bool);
    con_serviceTextField.setEnabled(bool);

    if (bool) {
      switch (lead_conComboBox.getSelectedIndex()){
        case 0 :
          con_brandCheckBox.setSelected(false);
          con_brandCheckBox.setEnabled(false);
          con_brandComboBox.setEnabled(false);
          con_brandTextField.setEnabled(false);
          break;
        case 1 :
          con_qualityCheckBox.setSelected(false);
          con_qualityCheckBox.setEnabled(false);
          con_qualityComboBox.setEnabled(false);
          con_qualityTextField.setEnabled(false);
          break;
        case 2 :
          con_en_savCheckBox.setSelected(false);
          con_en_savCheckBox.setEnabled(false);
          con_en_savComboBox.setEnabled(false);
          con_en_savTextField.setEnabled(false);
          break;
        case 3 :
          con_air_purifyCheckBox.setSelected(false);
          con_air_purifyCheckBox.setEnabled(false);
          con_air_purifyComboBox.setEnabled(false);
          con_air_purifyTextField.setEnabled(false);
          break;
        case 4 :
          con_quietCheckBox.setSelected(false);
          con_quietCheckBox.setEnabled(false);
          con_quietComboBox.setEnabled(false);
          con_quietTextField.setEnabled(false);
          break;
        case 5 :
          con_beautyCheckBox.setSelected(false);
          con_beautyCheckBox.setEnabled(false);
          con_beautyComboBox.setEnabled(false);
          con_beautyTextField.setEnabled(false);
          break;
        case 6 :
          con_priceCheckBox.setSelected(false);
          con_priceCheckBox.setEnabled(false);
          con_priceComboBox.setEnabled(false);
          con_priceTextField.setEnabled(false);
          break;
        case 7 :
          con_serviceCheckBox.setSelected(false);
          con_serviceCheckBox.setEnabled(false);
          con_serviceComboBox.setEnabled(false);
          con_serviceTextField.setEnabled(false);
          break;
        case 8 :
          con_otherCheckBox.setSelected(false);
          con_otherCheckBox.setEnabled(false);
          con_otherComboBox.setEnabled(false);
          con_otherTextField.setEnabled(false);
          break;
      }
    }
  }

  void saveButton_actionPerformed(ActionEvent e) {
    FileOutputStream output;
        PrintStream pstream;

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );

        int result = fileChooser.showSaveDialog( this );

        if ( result == JFileChooser.CANCEL_OPTION )
          return;

        File name = fileChooser.getSelectedFile();

        if (name == null || name.getName().equals(""))
          JOptionPane.showMessageDialog( this, "Invalid File Name" , "Invalid File Name",
                                          JOptionPane.ERROR_MESSAGE );
        else {

          try{
            output = new FileOutputStream( name ) ;
            pstream = new PrintStream(output);
            pstream.println("Number of Product = "+pd_noTextField.getText());
            for (int i=0; i < conditionList.size(); i++){
              pstream.println(String.valueOf(conditionList.get(i)));
              pstream.flush();
            }
            pstream.close();
          }

          catch (IOException ioException ){
            JOptionPane.showMessageDialog(this, "Error writing to file", "IO Exception", JOptionPane.ERROR_MESSAGE);
          }
    }
  }
}

