load -ASCII c:\temp\input01.csv;
load -ASCII c:\temp\target01.csv;
T1 = treefit(input01, target01, 'method', 'classification');
treedisp(T1,'names',{'Serv Rate' 'After Setup' 'Not Finish' 'No Year'});
sfit = treeval(T1, input01); 
sfit = T1.classname(sfit);
sfit02 = cell2mat(sfit);
sfit03 = str2num(sfit02);

counter = 0;
for i = 1:1000 
	if (target01(i) == sfit03(i)) 
		counter = counter + 1;
	end
end;
counter = counter/10
