package guidesystem;

import java.sql.*;

public class Road {
	private String Positions = "";
	private double LatitudeLeft = 0.0;
	private double LongitudeLeft = 0.0;
	private double LatitudeRight = 0.0;
	private double LongitudeRight = 0.0;
	
	public void setPositions(String positions) { Positions = positions; }
	public void setLatitudeLeft(double latitudeleft) { LatitudeLeft = latitudeleft; }
	public void setLongitudeLeft(double longitudeleft) { LongitudeLeft = longitudeleft; }
	public void setLatitudeRight(double latituderight) { LatitudeRight = latituderight; }
	public void setLongitudeRight(double longituderight) { LongitudeRight = longituderight; }
			
	public String getPositions() { return Positions; }
	public double getLatitudeLeft() { return LatitudeLeft; }
	public double getLongitudeLeft() { return LongitudeLeft; }
	public double getLatitudeRight() { return LatitudeRight; }
	public double getLongitudeRight() { return LongitudeRight; }
}