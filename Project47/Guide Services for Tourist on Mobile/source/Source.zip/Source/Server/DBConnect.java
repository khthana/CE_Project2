package guidesystem;

import java.sql.*;
import java.util.*;

public class DBConnect {
	private static String url = "jdbc:mysql://161.246.5.103/guidesystem?autoReconnect=true&user=Earth&password=Earth";
    private static String driver = "org.gjt.mm.mysql.Driver";
    
    public DBConnect() {
    }
    
    // Static Method -----------------------------------------------------------------------
    private static double calDistance(double x1, double x2, double y1, double y2) {
		double dist;
		dist = Math.sqrt(Math.pow((x2-x1),2) + Math.pow((y2-y1),2));
		return dist;
	}
	
	private static double calGeometry(double distance) {
		double result;
		result = distance * 109500;
		return result;
	}
	//--------------------------------------------------------------------------------------
	
	//Find Position from user latitude and longitude
	public String findPosition(double userLatitude, double userLongitude) {
		String result = "";
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT POSITIONS FROM position WHERE LATITUDE=? AND LONGITUDE=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, Double.toString(userLatitude));
			stmt.setString(2, Double.toString(userLongitude));
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result = rs.getString("POSITIONS");
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		return result;
	}
	
	//Find user Pos from userPosition
	public Pos findLocation(String userPositions) {
		Pos result = new Pos();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT LATITUDE, LONGITUDE, ROADNAME, POINTID FROM position WHERE POSITIONS=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, userPositions);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				Pos pos = new Pos();
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE")); 
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				String r_roadname = rs.getString("ROADNAME");
				int r_pointid = Integer.parseInt(rs.getString("POINTID"));
				pos.setLatitude(r_latitude);
				pos.setLongitude(r_longitude);
				pos.setRoadName(r_roadname);
				pos.setPointID(r_pointid);
				result = pos;
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		return result;
	}
		
	
	//Find Nearest User Position Method
	public Vector findUserPosition(double realLatitude, double realLongitude) {
		Pos pos = new Pos();
		double shortdist = 10.0;
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT LATITUDE, LONGITUDE, POSITIONS, DESCRIPTION, DESPLACE FROM position";
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE"));
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				String r_positions = rs.getString("POSITIONS");
				String r_description = rs.getString("DESCRIPTION");
				String r_desplace = rs.getString("DESPLACE");
				double distance = calDistance(realLatitude, r_latitude, realLongitude, r_longitude);
				if(shortdist > distance) {
					pos.setLatitude(r_latitude);
					pos.setLongitude(r_longitude);
					pos.setPositions(r_positions);
					pos.setDescription(r_description);
					pos.setDesplace(r_desplace);
					shortdist = distance;
				}
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		Vector result = new Vector();
		result.addElement(pos);
		result.addElement(Double.toString(Math.round(calGeometry(shortdist))));
		return result;
	}
	
	//Check User Position
	public boolean checkUserPosition(String shortdist) {
		boolean result = false;
		if(Double.parseDouble(shortdist)<50) result = true;
		else result = false;
		return result;
	}
	
	//Find Destination Position
	public Vector findDestination(String destinationPlace) {
		Pos pos = new Pos();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT LATITUDE, LONGITUDE, POSITIONS, DESCRIPTION, DESPLACE, ROADNAME, POINTID FROM position WHERE DESPLACE=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, destinationPlace);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE"));
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				String r_positions = rs.getString("POSITIONS");
				String r_description = rs.getString("DESCRIPTION");
				String r_desplace = rs.getString("DESPLACE");
				String r_roadname = rs.getString("ROADNAME");
				int r_pointid = Integer.parseInt(rs.getString("POINTID"));
				pos.setLatitude(r_latitude);
				pos.setLongitude(r_longitude);
				pos.setPositions(r_positions);
				pos.setDescription(r_description);
				pos.setDesplace(r_desplace);
				pos.setRoadName(r_roadname);
				pos.setPointID(r_pointid);
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		Vector result = new Vector();
		result.addElement(pos);
		return result;
	}
	
	//Find Nearest BTS Station 
	public Vector findNearBTS(double latitude, double longitude) {
		BTS bts = new BTS();
		double shortdist = 10.0;
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT BTS_ID, BTS_NAME, LATITUDE, LONGITUDE, BCONNECT FROM bts_station";
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_bts_id = rs.getString("BTS_ID");
				String r_bts_name = rs.getString("BTS_NAME");
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE"));
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				String r_bconnect = rs.getString("BCONNECT");
				double distance = calDistance(latitude, r_latitude, longitude, r_longitude);
				if(shortdist > distance) {
					bts.setBTS_ID(r_bts_id);
					bts.setBTS_NAME(r_bts_name);
					bts.setLatitude(r_latitude);
					bts.setLongitude(r_longitude);
					bts.setBConnect(r_bconnect);
					shortdist = distance;
				}
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		
		Vector result = new Vector();
		result.addElement(bts);
		result.addElement(Long.toString(Math.round(calGeometry(shortdist))));
		return result;
	}
	
	//Find Nearest UG Station
	public Vector findNearUG(double latitude, double longitude) {
		UG ug = new UG();
		double shortdist = 10.0;
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT UG_ID, UG_NAME, LATITUDE, LONGITUDE, UCONNECT FROM ug_station";
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_ug_id = rs.getString("UG_ID");
				String r_ug_name = rs.getString("UG_NAME");
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE"));
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				String r_uconnect = rs.getString("UCONNECT");
				double distance = calDistance(latitude, r_latitude, longitude, r_longitude);
				if(shortdist > distance) {
					ug.setUG_ID(r_ug_id);
					ug.setUG_NAME(r_ug_name);
					ug.setLatitude(r_latitude);
					ug.setLongitude(r_longitude);
					ug.setUConnect(r_uconnect);
					shortdist = distance;
				}
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		
		Vector result = new Vector();
		result.addElement(ug);
		result.addElement(Long.toString(Math.round(calGeometry(shortdist))));
		return result;
	}
	
	//Train Detect for decide Train Way
	public String trainDetect(double latitude, double longitude) {
		String result = "XX";
		String result1 = "XX";
		String result2 = "XX";
		DBConnect db = new DBConnect();
		Vector btsResult = db.findNearBTS(latitude, longitude);
		BTS bts = (BTS)btsResult.elementAt(0);
		double btsShortDist = Double.parseDouble((String)btsResult.elementAt(1));
		Vector ugResult = db.findNearUG(latitude, longitude);
		if(btsShortDist <= 500) result1 = "BTS";
		UG ug = (UG)ugResult.elementAt(0);
		double ugShortDist = Double.parseDouble((String)ugResult.elementAt(1));
		if(ugShortDist <= 500) result2 = "UG";
		//result = Double.toString(btsShortDist);
		//result = Double.toString(ugShortDist);
		
		if((!result1.equals("XX"))||(!result2.equals("XX"))) {
			if((result1.equals("BTS"))&&(result2.equals("UG"))) result = "BU";
			else if((result1.equals("BTS"))&&(result2.equals("XX"))) result = "BTS";
			else if((result1.equals("XX"))&&(result2.equals("UG"))) result = "UG";
		}
		
		//if(btsShortDist<=ugShortDist) {
		//	if(btsShortDist <= 500) {
		//		result = "BTS";
		//	} else result = "XX";			
		//}
		//else {
		//	if(ugShortDist <=500) {
		//		result = "UG";
		//	} else result = "XX";
		//}
		return result;
	}
	
	//Check Line BTS Station
	public boolean checkLineBTS(String userBTS_ID, String desBTS_ID) {
		String user_bts_id = "";
		String user_bts_line = "";
		String des_bts_id = "";
		String des_bts_line = "";
		
		//Query User's BTS-line
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT BTS_ID, LINE FROM bts_station WHERE BTS_ID=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, userBTS_ID);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				user_bts_id = rs.getString("BTS_ID");
				user_bts_line = rs.getString("LINE");
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); }
		catch(SQLException e) { System.out.println(e); }
		
		//Query Destination's BTS-line
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT BTS_ID, LINE FROM bts_station WHERE BTS_ID=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, desBTS_ID);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				des_bts_id = rs.getString("BTS_ID");
				des_bts_line = rs.getString("LINE");
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); }
		catch(SQLException e) { System.out.println(e); }
		
		//checkLine BTS
		boolean result = false;
		if(user_bts_line.equals(des_bts_line)) {
			result = true;
		}
		else {
			if(user_bts_line.equals("Cn") || des_bts_line.equals("Cn")) {
				result =true;
			}
			else result = false;
		}
		return result;
	}
	
	//checkNullBConnect
	public boolean checkNullBConnect(double Latitude, double Longitude) {
		boolean result = false;
		DBConnect db = new DBConnect();
		Vector btsInfo = db.findNearBTS(Latitude, Longitude);
		BTS bts = (BTS)btsInfo.elementAt(0);
		String bconnect = bts.getBConnect();
		if(bconnect==null) result = true;
		return result;
	}
	
	//checkNullUConnect
	public boolean checkNullUConnect(double Latitude, double Longitude) {
		boolean result = false;
		DBConnect db = new DBConnect();
		Vector ugInfo = db.findNearUG(Latitude, Longitude);
		UG ug = (UG)ugInfo.elementAt(0);
		String uconnect = ug.getUConnect();
		if(uconnect==null) result = true;
		return result;
	}
	
	//Find UConnect
	public String findUConnect(String BConnect) {
		String result = "";
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT UCONNECT FROM connect WHERE BCONNECT=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, BConnect);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_connect = rs.getString("UCONNECT");
				result = r_connect;
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); }
		catch(SQLException e) { System.out.println(e); }
		return result;
	}
	
	//Find BConnect
	public String findBConnect(String UConnect) {
		String result = "";
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT BCONNECT FROM connect WHERE UCONNECT=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, UConnect);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_connect = rs.getString("BCONNECT");
				result = r_connect;
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); }
		catch(SQLException e) { System.out.println(e); }
		return result;
	}
	
	//Find Run Bus at Position
	public Vector findRunBus(String RoadName, int PointID) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM run_bus WHERE ROADNAME=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, RoadName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_bus_id = rs.getString("BUS_ID");
				String r_seq = rs.getString("SEQ");
				String r_io = rs.getString("IO");
				String r_roadname = rs.getString("ROADNAME");
				String r_busnum = rs.getString("BUSNUM");
				String r_type = rs.getString("TYPE");
				int r_pointids = Integer.parseInt(rs.getString("POINTIDS"));
				int r_pointide = Integer.parseInt(rs.getString("POINTIDE"));
				String r_userstay = rs.getString("USERSTAY");
				int PointIdStart = 0;
				int PointIdEnd = 0;
				if(r_pointids < r_pointide) {
					PointIdStart = r_pointids;
					PointIdEnd = r_pointide;
				}
				else if(r_pointids > r_pointide) {
					PointIdStart = r_pointide;
					PointIdEnd = r_pointids;
				}
				if((PointIdStart <= PointID)&&(PointIdEnd >= PointID)) {
					runBus runbus = new runBus();
					runbus.setBusID(r_bus_id);
					runbus.setSeq(r_seq);
					runbus.setIo(r_io);
					runbus.setRoadName(r_roadname);
					runbus.setBusNum(r_busnum);
					runbus.setType(r_type);
					runbus.setPointIDS(r_pointids);
					runbus.setPointIDE(r_pointide);
					runbus.setUserStay(r_userstay);
					result.addElement(runbus);
				}
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//Find Run Van at Position
	/*
	public Vector findRunVan(String positions) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM run_van WHERE POSITIONS=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, positions);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_van_id = rs.getString("VAN_ID");
				String r_seq = rs.getString("SEQ");
				String r_io = rs.getString("IO");
				String r_positions = rs.getString("POSITIONS");
				String r_vannum = rs.getString("VANNUM");
				runVan runvan = new runVan();
				runvan.setVanID(r_van_id);
				runvan.setSeq(r_seq);
				runvan.setIo(r_io);
				runvan.setPositions(r_positions);
				runvan.setVanNum(r_vannum);
				result.addElement(runvan);
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	*/
	//Detect Bus Run from Source to Destination
	public Vector detectBus(Vector userBus, Vector desBus, int userPointID, int desPointID) {
		Vector result = new Vector();
		for(int i=0;i<userBus.size();i++) {
			runBus userrunbus = (runBus)userBus.elementAt(i);
			String user_bus_id = userrunbus.getBusID();
			String user_seq = userrunbus.getSeq();
			int userSeq = Integer.parseInt(user_seq);
			String user_io = userrunbus.getIo();
			String user_roadname = userrunbus.getRoadName();
			String user_busnum = userrunbus.getBusNum();
			String user_type = userrunbus.getType();
			int user_pointids = userrunbus.getPointIDS();
			int user_pointide = userrunbus.getPointIDE();
			String user_userstay = userrunbus.getUserStay();
			for(int j=0;j<desBus.size();j++) {
				runBus desrunbus = (runBus)desBus.elementAt(j);
				String des_bus_id = desrunbus.getBusID();
				String des_seq = desrunbus.getSeq();
				int desSeq = Integer.parseInt(des_seq);
				String des_io = desrunbus.getIo();
				String des_roadname = desrunbus.getRoadName();
				String des_busnum = desrunbus.getBusNum();
				String des_type = desrunbus.getType();
				int des_pointids = desrunbus.getPointIDS();
				int des_pointide = desrunbus.getPointIDE();
				String des_userstay = desrunbus.getUserStay();
				if((user_busnum.equals(des_busnum)) && (user_io.equals(des_io))) {
					if(userSeq < desSeq) {
						result.addElement(userrunbus);
						//result.add(desrunbus);
					}
					else if (userSeq==desSeq) {
						//int userPointID = Integer.parseInt(userpointid);
						//int desPointID = Integer.parseInt(despointid);
						if(Math.abs(user_pointids - userPointID) < Math.abs(user_pointids - desPointID)) {
							result.addElement(userrunbus);
							//result.add(desrunbus);
						}
					}
					
				}
			}
		}
		return result;
	}
	/*
	//Detect Van Run from Source to Destination
	public Vector detectVan(Vector userVan, Vector desVan) {
		Vector result = new Vector();
		for(int i=0;i<userVan.size();i++) {
			runVan userrunvan = (runVan)userVan.elementAt(i);
			String user_van_id = userrunvan.getVanID();
			String user_seq = userrunvan.getSeq();
			int userSeq = Integer.parseInt(user_seq);
			String user_io = userrunvan.getIo();
			String user_positions = userrunvan.getPositions();
			String user_vannum = userrunvan.getVanNum();
			for(int j=0;j<desVan.size();j++) {
				runVan desrunvan = (runVan)desVan.elementAt(j);
				String des_van_id = desrunvan.getVanID();
				String des_seq = desrunvan.getSeq();
				int desSeq = Integer.parseInt(des_seq);
				String des_io = desrunvan.getIo();
				String des_positions = desrunvan.getPositions();
				String des_vannum = desrunvan.getVanNum();
				if((user_vannum.equals(des_vannum)) && (user_io.equals(des_io)) && (userSeq < desSeq)) {
					//result.addElement(userrunvan.getVanNum());
					result.addElement(desrunvan);
				}
			}
		}
		return result;
	}
	*/
	//Check Road Path accross or don't accross
	public String checkRoadPath(double realLatitude, double realLongitude, String userPositions) {
		double latitudeLeft = 0.0;
		double longitudeLeft = 0.0;
		double latitudeRight = 0.0;
		double longitudeRight = 0.0;			
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT LatitudeLeft, LongitudeLeft, LatitudeRight, LongitudeRight FROM road WHERE POSITIONS=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, userPositions);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				latitudeLeft = Double.parseDouble(rs.getString("LatitudeLeft"));
				longitudeLeft = Double.parseDouble(rs.getString("LongitudeLeft"));
				latitudeRight = Double.parseDouble(rs.getString("LatitudeRight"));
				longitudeRight = Double.parseDouble(rs.getString("LongitudeRight"));
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		
		double distance1 = calDistance(realLatitude, latitudeLeft, realLongitude, longitudeLeft);
		double distance2 = calDistance(realLatitude, latitudeRight, realLongitude, longitudeRight);
		String result="";
		if(distance1 <= distance2) {
			result = "L";
		}
		else if(distance1 > distance2) {
			result = "R";
		}
		return result;
	}
	
	//Search BTS latitude longitude from BTS_NAME 
	public BTS searchBTSLocation(String BTS_NAME) {
		BTS result = new BTS();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT LATITUDE, LONGITUDE FROM bts_station WHERE BTS_NAME=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, BTS_NAME);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				BTS bts = new BTS();
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE")); 
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				bts.setLatitude(r_latitude);
				bts.setLongitude(r_longitude);
				result = bts;
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		return result;
	}
	
	//Search UG latitude longitude from UG_NAME
	public UG searchUGLocation(String UG_NAME) {
		UG result = new UG();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT LATITUDE, LONGITUDE FROM ug_station WHERE UG_NAME=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, UG_NAME);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				UG ug = new UG();
				double r_latitude = Double.parseDouble(rs.getString("LATITUDE")); 
				double r_longitude = Double.parseDouble(rs.getString("LONGITUDE"));
				ug.setLatitude(r_latitude);
				ug.setLongitude(r_longitude);
				result = ug;
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null;}
		return result;
	}
	
	//------------------------------------------------------------------------------
	
	public Vector createRunBus2(Vector bus1vector, Vector detectbusvector) {
		Vector result = new Vector();
		for(int i=0;i<detectbusvector.size();i++) {
			for(int j=0;j<bus1vector.size();j++) {
				String detectbusnum = ((runBus)detectbusvector.elementAt(i)).getBusNum();
				String bus1num = ((runBus)bus1vector.elementAt(j)).getBusNum();
				if(bus1num.equals(detectbusnum)) {
					bus1vector.removeElementAt(j);
					j--;
				}
			}
		}
		result = bus1vector;
		return result;
	}
	
	public Vector genUserBusSequence(String busNum, String busIO, String busSeq) {
		Vector result = new Vector();
		int busSEQ = Integer.parseInt(busSeq);
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM run_bus WHERE BUSNUM=? AND IO=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, busNum);
			stmt.setString(2, busIO);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_bus_id = rs.getString("BUS_ID");
				int r_seq = Integer.parseInt(rs.getString("SEQ"));
				String r_io = rs.getString("IO");
				String r_roadname = rs.getString("ROADNAME");
				String r_busnum = rs.getString("BUSNUM");
				String r_type = rs.getString("TYPE");
				String r_pointids = rs.getString("POINTIDS");
				String r_pointide = rs.getString("POINTIDE");
				String r_userstay = rs.getString("USERSTAY");
				if(r_seq>busSEQ) {
					runBus runbus = new runBus();
					runbus.setBusID(r_bus_id);
					runbus.setIo(r_io);
					runbus.setSeq(Integer.toString(r_seq));
					runbus.setRoadName(r_roadname);
					runbus.setBusNum(r_busnum);
					runbus.setType(r_type);
					runbus.setPointIDS(Integer.parseInt(r_pointids));
					runbus.setPointIDE(Integer.parseInt(r_pointide));
					runbus.setUserStay(r_userstay);
					result.addElement(runbus);
				}
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }	
		return result;	
	}
	
	public Vector genDestinationBusSequence(String busNum, String busIO, String busSeq) {
		Vector result = new Vector();
		int busSEQ = Integer.parseInt(busSeq);
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM run_bus WHERE BUSNUM=? AND IO=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, busNum);
			stmt.setString(2, busIO);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				String r_bus_id = rs.getString("BUS_ID");
				int r_seq = Integer.parseInt(rs.getString("SEQ"));
				String r_io = rs.getString("IO");
				String r_roadname = rs.getString("ROADNAME");
				String r_busnum = rs.getString("BUSNUM");
				String r_type = rs.getString("TYPE");
				String r_pointids = rs.getString("POINTIDS");
				String r_pointide = rs.getString("POINTIDE");
				String r_userstay = rs.getString("USERSTAY");
				if(r_seq<busSEQ) {
					runBus runbus = new runBus();
					runbus.setBusID(r_bus_id);
					runbus.setIo(r_io);
					runbus.setSeq(Integer.toString(r_seq));
					runbus.setRoadName(r_roadname);
					runbus.setBusNum(r_busnum);
					runbus.setType(r_type);
					runbus.setPointIDS(Integer.parseInt(r_pointids));
					runbus.setPointIDE(Integer.parseInt(r_pointide));
					runbus.setUserStay(r_userstay);
					result.addElement(runbus);
				}
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }	
		return result;	
	}
	
	public Vector detectBus2(Vector userBus, Vector desBus) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		for(int i=0;i<userBus.size();i++) {
			String userbusnum = ((runBus)userBus.elementAt(i)).getBusNum();
			String userbusio = ((runBus)userBus.elementAt(i)).getIo();
			String userbusseq = ((runBus)userBus.elementAt(i)).getSeq();
			Vector genUser = db.genUserBusSequence(userbusnum, userbusio, userbusseq);
			for(int j=0;j<desBus.size();j++) {
				String desbusnum = ((runBus)desBus.elementAt(j)).getBusNum();
				String desbusio = ((runBus)desBus.elementAt(j)).getIo();
				String desbusseq = ((runBus)desBus.elementAt(j)).getSeq();
				Vector genDes = db.genDestinationBusSequence(desbusnum, desbusio, desbusseq);
				for(int k=0;k<genUser.size();k++) {
					runBus userrunbus = (runBus)genUser.elementAt(k);
					String ubusid = userrunbus.getBusID();
					String useq = userrunbus.getSeq();
					String uio = userrunbus.getIo();
					String uroadname = userrunbus.getRoadName();
					String ubusnum = userrunbus.getBusNum();
					String utype = userrunbus.getType();
					int upointids = userrunbus.getPointIDS();
					int upointide = userrunbus.getPointIDE();
					String uuserstay = userrunbus.getUserStay();
					for(int l=0;l<genDes.size();l++) {
						runBus desrunbus = (runBus)genDes.elementAt(l);
						String dbusid = desrunbus.getBusID();
						String dseq = desrunbus.getSeq();
						String dio = desrunbus.getIo();
						String droadname = desrunbus.getRoadName();
						String dbusnum = desrunbus.getBusNum();
						String dtype = desrunbus.getType();
						int dpointids = desrunbus.getPointIDS();
						int dpointide = desrunbus.getPointIDE();
						String duserstay = desrunbus.getUserStay();
						if(uroadname.equals(droadname)) {
							int userMaxPointID = 0;
							int userMinPointID = 0;
							if(upointids>upointide) { userMaxPointID = upointids; userMinPointID = upointide; } else { userMaxPointID = upointide; userMinPointID = upointids; }
							int desMaxPointID = 0;
							int desMinPointID = 0;
							if(dpointids>dpointide) { desMaxPointID = dpointids; desMinPointID = dpointide; } else { desMaxPointID = dpointide; desMinPointID = dpointids; }
							int connectPointID = 0;
							int maxRangeCheckPointID = 0;
							int minRangeCheckPointID = 0;
							if(userMaxPointID>desMaxPointID) {
								connectPointID = desMaxPointID;
								maxRangeCheckPointID = userMaxPointID;
								minRangeCheckPointID = userMinPointID;
							}
							else {
								connectPointID = userMaxPointID;
								maxRangeCheckPointID = desMaxPointID;
								minRangeCheckPointID = desMinPointID;
							}
							
							
							if((minRangeCheckPointID<connectPointID)&&(connectPointID<maxRangeCheckPointID)) {
								Vector elementResult = new Vector();
								elementResult.addElement(((runBus)userBus.elementAt(i)));
								Pos connection = db.searchPos(uroadname, Integer.toString(connectPointID));
								//runBus connection = new runBus();
								//connection.setSeq(useq);
								//connection.setIo(uio);
								//connection.setRoadName(uroadname);
								//connection.setPointIDS(Integer.toString(connectPointID) + " : " + Integer.toString(upointids) + " : " + Integer.toString(upointide));
								//connection.setPointIDE(Integer.toString(connectPointID) + " : " + Integer.toString(dpointids) + " : " + Integer.toString(dpointide));
								elementResult.addElement(connection.getDescription());
								elementResult.addElement(((runBus)desBus.elementAt(j)));
								result.addElement(elementResult);
							}
							
						}
					}
				}
			}
		}
		
		return result;
	}

	public Pos searchPos(String roadName, String pointID) {
		Pos result = new Pos();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM position WHERE ROADNAME=? AND POINTID=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, roadName);
			stmt.setString(2, pointID);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				Pos pos = new Pos();
				pos.setLatitude(Double.parseDouble(rs.getString("LATITUDE")));
				pos.setLongitude(Double.parseDouble(rs.getString("LONGITUDE")));
				pos.setPositions(rs.getString("POSITIONS"));
				pos.setDescription(rs.getString("DESCRIPTION"));
				pos.setDesplace(rs.getString("DESPLACE"));
				pos.setRoadName(rs.getString("ROADNAME"));
				pos.setPointID(Integer.parseInt(rs.getString("POINTID")));
				result = pos;
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	public Vector routingBus2(Vector detectBus2) {
		Vector result = new Vector();
		for(int i=0;i<detectBus2.size();i++) {
			Vector elementBus2i = (Vector)detectBus2.elementAt(i);
			String bus1i = ((runBus)elementBus2i.elementAt(0)).getBusNum();
			String bus2i = ((runBus)elementBus2i.elementAt(2)).getBusNum();
			for(int j=i+1;j<detectBus2.size();j++) {
				Vector elementBus2j = (Vector)detectBus2.elementAt(j);
				String bus1j = ((runBus)elementBus2j.elementAt(0)).getBusNum();
				String bus2j = ((runBus)elementBus2j.elementAt(2)).getBusNum();
				if((bus1i.equals(bus1j))&&(bus2i.equals(bus2j))) {
					detectBus2.removeElementAt(j);
					j--;
				}
			}
		}
		result = detectBus2;
		return result;
	}

//------------------------------------------------------------------------------
}