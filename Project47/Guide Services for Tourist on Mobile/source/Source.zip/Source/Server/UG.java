package guidesystem;

import java.sql.*;

public class UG {
	private String UG_ID = "";
	private String UG_NAME = "";
	private double Latitude = 0.0;
	private double Longitude = 0.0;
	private String UConnect = "";
	private String Place = "";
	
	public void setUG_ID(String ug_id) { UG_ID = ug_id;	}
	public void setUG_NAME(String ug_name) { UG_NAME = ug_name; }
	public void setLatitude(double latitude) { Latitude = latitude; }
	public void setLongitude(double longitude) { Longitude = longitude; }
	public void setUConnect(String uconnect) { UConnect = uconnect; }
	public void setPlace(String place) { Place = place;	}
	
	public String getUG_ID() { return UG_ID; }
	public String getUG_NAME() { return UG_NAME; }
	public double getLatitude() { return Latitude; }
	public double getLongitude() { return Longitude; }
	public String getUConnect() { return UConnect; }
	public String getPlace() { return Place; }
}