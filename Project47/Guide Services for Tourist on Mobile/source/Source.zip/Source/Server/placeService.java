package guidesystem;

import java.sql.*;
import java.util.*;

public class placeService {
	private static String url = "jdbc:mysql://161.246.5.103/guidesystem?autoReconnect=true&user=Earth&password=Earth";
    private static String driver = "org.gjt.mm.mysql.Driver";

	//ListPlace
	public Vector listPlace(int placeType) {
		Vector result = new Vector();
		String getName = "";
		String getTable = "";
		switch(placeType) {
			case 1: getName="TOUR_NAME"; getTable="tourist_attraction"; break;
			case 2: getName="TEMPLE_NAME"; getTable="temple"; break;
			case 3: getName="PARK_NAME"; getTable="park"; break;
			case 4: getName="STADIUM_NAME"; getTable="stadium"; break;
			case 5: getName="TRANS_NAME"; getTable="transport_station"; break;
			case 6: getName="POLICE_NAME"; getTable="tourist_police"; break;
			case 7: getName="SHOP_NAME"; getTable="shopping"; break;
			case 8: getName="BTS_NAME"; getTable="bts_station"; break;
			case 9: getName="UG_NAME"; getTable="ug_station"; break;
		}
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT " + getName + " FROM " +  getTable;
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString(getName));
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowTouristAttraction
	public Vector showTouristAttraction(String tourName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM tourist_attraction WHERE TOUR_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, tourName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("TOUR_ID"));
				result.addElement(rs.getString("TOUR_NAME"));
				result.addElement(rs.getString("TEL"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("URL"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowTemple
	public Vector showTemple(String templeName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM temple WHERE TEMPLE_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, templeName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("TEMPLE_ID"));
				result.addElement(rs.getString("TEMPLE_NAME"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("CHARITY"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowPark
	public Vector showPark(String parkName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM park WHERE PARK_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, parkName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("PARK_ID"));
				result.addElement(rs.getString("PARK_NAME"));
				result.addElement(rs.getString("TEL"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("URL"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("CHARITY"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowStadium
	public Vector showStadium(String stadiumName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM stadium WHERE STADIUM_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, stadiumName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("STADIUM_ID"));
				result.addElement(rs.getString("STADIUM_NAME"));
				result.addElement(rs.getString("TEL"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("URL"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("MATCH"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowStadium
	public Vector showTransportStation(String transportStationName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM transport_station WHERE TRANS_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, transportStationName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("TRANS_ID"));
				result.addElement(rs.getString("TRANS_NAME"));
				result.addElement(rs.getString("TEL"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("URL"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowTouristPolice
	public Vector showTouristPolice(String touristPoliceName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM tourist_police WHERE POLICE_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, touristPoliceName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("POLICE_ID"));
				result.addElement(rs.getString("POLICE_NAME"));
				result.addElement(rs.getString("TEL"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
	
	//ShowShopping
	public Vector showShopping(String shoppingName) {
		Vector result = new Vector();
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM shopping WHERE SHOP_NAME = ?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, shoppingName);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("SHOP_ID"));
				result.addElement(rs.getString("SHOP_NAME"));
				result.addElement(rs.getString("TEL"));
				result.addElement(rs.getString("OPENTIME"));
				result.addElement(rs.getString("CLOSETIME"));
				result.addElement(rs.getString("URL"));
				result.addElement(rs.getString("DESCRIPTION"));
				result.addElement(rs.getString("PROMOTION"));
				result.addElement(rs.getString("LATITUDE"));
				result.addElement(rs.getString("LONGITUDE"));
			}
		}
		catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
	}
}