package guidesystem;

import java.sql.*;

public class runBus {
	private String BusID = "";
	private String Seq = "";
	private String Io = "";
	private String RoadName = "";
	private String BusNum = "";
	private String Type = "";
	private int PointIDS = 0;
	private int PointIDE = 0;
	private String UserStay = "";

	public void setBusID(String busid) { BusID = busid; }
	public void setSeq(String seq) { Seq = seq; }
	public void setIo(String io) { Io = io; }
	public void setRoadName(String roadname) { RoadName = roadname;	}
	public void setBusNum(String busnum) { BusNum = busnum; }
	public void setType(String type) { Type = type; }
	public void setPointIDS(int pointids) { PointIDS = pointids; }
	public void setPointIDE(int pointide) { PointIDE = pointide; }
	public void setUserStay(String userstay) { UserStay = userstay; }
		
	public String getBusID() { return BusID; }
	public String getSeq() { return Seq; }
	public String getIo() { return Io; }
	public String getRoadName() { return RoadName; }
	public String getBusNum() { return BusNum; }
	public String getType() { return Type; }
	public int getPointIDS() { return PointIDS; }	
	public int getPointIDE() { return PointIDE; }
	public String getUserStay() { return UserStay; }
}