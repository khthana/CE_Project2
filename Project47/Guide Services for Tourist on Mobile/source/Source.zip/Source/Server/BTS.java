package guidesystem;

import java.sql.*;

public class BTS {
	private String BTS_ID = "";
	private String BTS_NAME = "";
	private String Lines = "";
	private double Latitude = 0.0;
	private double Longitude = 0.0;
	private String BConnect = "";
	private String Place = "";
	
	public void setBTS_ID(String bts_id) { BTS_ID = bts_id;	}
	public void setBTS_NAME(String bts_name) { BTS_NAME = bts_name; }
	public void setLines(String lines) { Lines = lines; }
	public void setLatitude(double latitude) { Latitude = latitude; }
	public void setLongitude(double longitude) { Longitude = longitude; }
	public void setBConnect(String bconnect) { BConnect = bconnect; }
	public void setPlace(String place) { Place = place; }
	
	public String getBTS_ID() { return BTS_ID; }
	public String getBTS_NAME() { return BTS_NAME; }
	public String getLines() { return Lines; }
	public double getLatitude() { return Latitude; }
	public double getLongitude() { return Longitude; }
	public String getBConnect() { return BConnect; }
	public String getPlace() { return Place; }
}