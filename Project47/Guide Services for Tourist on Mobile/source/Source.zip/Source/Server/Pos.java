package guidesystem;

import java.sql.*;

public class Pos {
	private double Latitude = 0.0;
	private double Longitude = 0.0;
	private String Positions = "";
	private String Description = "";
	private String Desplace = "";
	private String RoadName = "";
	private int PointID = 0;

	public void setLatitude(double latitude) { Latitude = latitude; }
	public void setLongitude(double longitude) { Longitude = longitude; }
	public void setPositions(String positions) { Positions = positions; }
	public void setDescription(String description) { Description = description;	}
	public void setDesplace(String desplace) { Desplace = desplace;	}
	public void setRoadName(String roadname) { RoadName = roadname; }
	public void setPointID(int pointid) { PointID = pointid; }
	
	public double getLatitude() { return Latitude; }
	public double getLongitude() { return Longitude; }
	public String getPositions() { return Positions; }
	public String getDescription() { return Description; }
	public String getDesplace() { return Desplace; }
	public String getRoadName() { return RoadName; }
	public int getPointID() { return PointID; }
}