package guidesystem;

import java.sql.*;
import java.util.*;

public class guideService {
	private static String url = "jdbc:mysql://161.246.5.103/guidesystem?autoReconnect=true&user=Earth&password=Earth";
	private static String driver = "org.gjt.mm.mysql.Driver";
	
	private static double calDistance(double x1, double x2, double y1, double y2) {
		double dist;
		dist = Math.sqrt(Math.pow((x2-x1),2) + Math.pow((y2-y1),2));
		return dist;
	}
	
	private static double calGeometry(double distance) {
		double result;
		result = distance * 109500;
		return result;
	}
   
    public Vector findUserPositionGPS(String Latitude, String Longitude) {
    	Vector result = new Vector();
    	//Convert Input from Mobile
    	double latitude = Double.parseDouble(Latitude);
    	double longitude = Double.parseDouble(Longitude);
    	//Call Method
    	DBConnect db = new DBConnect();
    	Vector output = db.findUserPosition(latitude, longitude);
    	//Convert Output for sent to Mobile
    	Pos pos = (Pos)output.elementAt(0);
    	String  shortdist = (String)output.elementAt(1);
    	//Check Output
		if(db.checkUserPosition(shortdist)) {
			result.addElement(pos.getPositions());
			result.addElement(pos.getDescription());
			result.addElement(shortdist);
		}
		else result = null;
		return result;
	}
	
	public Vector findUserPositionManual(String destinationPlace) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		Vector output = db.findDestination(destinationPlace);
		Pos userInfo = (Pos)output.elementAt(0);
		String userLatitude = Double.toString(userInfo.getLatitude());
		String userLongitude = Double.toString(userInfo.getLongitude());
		String userPositions = userInfo.getPositions();
		String userDescription = userInfo.getDescription();
		result.addElement(userLatitude);
		result.addElement(userLongitude);
		result.addElement(userPositions);
		result.addElement(userDescription);
		return result;
	}
	
	public Vector checkUserNearDestination(String userPositions, String destinationPlace) {
		Vector result = new Vector();
		String result1 = "false";
		String result2 = "";
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
				
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		
		double distance = calGeometry(calDistance(userLatitude, desLatitude, userLongitude, desLongitude));
		if(distance <= 500) result1 = "true";
		result2 = Long.toString(Math.round(distance));
		result.addElement(result1);
		result.addElement(result2);
		return result;
	}

	public Vector decideGuide(String userPositions, String destinationPlace) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		String userRoadName = userLocation.getRoadName();
		int userPointID = userLocation.getPointID();
		
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		String desRoadName = desInfo.getRoadName();
		int desPointID = desInfo.getPointID();
			
		//AI
		String userNearTrain = db.trainDetect(userLatitude, userLongitude);
		String desNearTrain = db.trainDetect(desLatitude, desLongitude);
		//result.addElement(userNearTrain);
		//result.addElement(desNearTrain);
		boolean userNullBConnect = db.checkNullBConnect(userLatitude, userLongitude);
		boolean desNullUConnect = db.checkNullUConnect(desLatitude, desLongitude);
		
		if((!userNearTrain.equals("XX"))&&(!desNearTrain.equals("XX"))) {
			if((userNearTrain.equals("BTS"))&&(desNearTrain.equals("BTS"))) {
				result.addElement("BTS-BTS");
			}
			else if((userNearTrain.equals("UG"))&&(desNearTrain.equals("UG"))) {
				result.addElement("UG-UG");
			}
			else if((userNearTrain.equals("BTS"))&&(desNearTrain.equals("UG"))) {
				if(!db.checkNullBConnect(userLatitude, userLongitude)) result.addElement("BTS-UG");
			}
			else if((userNearTrain.equals("UG"))&&(desNearTrain.equals("BTS"))) {
				if(!db.checkNullUConnect(userLatitude, userLongitude)) result.addElement("UG-BTS");
			}
			else if((userNearTrain.equals("BU"))&&(desNearTrain.equals("BTS"))) {
				result.addElement("BTS-BTS");
				if(!db.checkNullUConnect(userLatitude, userLongitude)) result.addElement("UG-BTS");
			}
			else if((userNearTrain.equals("BTS"))&&(desNearTrain.equals("BU"))) {
				result.addElement("BTS-BTS");
				if(!db.checkNullBConnect(userLatitude, userLongitude)) result.addElement("BTS-UG");
			}
			else if((userNearTrain.equals("BU"))&&(desNearTrain.equals("UG"))) {
				result.addElement("UG-UG");
				if(!db.checkNullBConnect(userLatitude, userLongitude)) result.addElement("BTS-UG");
			}
			else if((userNearTrain.equals("UG"))&&(desNearTrain.equals("BU"))) {
				result.addElement("UG-UG");
				if(!db.checkNullUConnect(userLatitude, userLongitude)) result.addElement("UG-BTS");
			}
			else if((userNearTrain.equals("BU"))&&(desNearTrain.equals("BU"))) {
				result.addElement("BTS-BTS");
				result.addElement("UG-UG");
			}
		}
		
		//Bus and Van Algorithm
		Vector userBus = db.findRunBus(userRoadName, userPointID);
		Vector desBus = db.findRunBus(desRoadName, desPointID);
		Vector busResult = db.detectBus(userBus, desBus, userPointID, desPointID);
		//result.addElement(Integer.toString(userBus.size()));
		//result.addElement(Integer.toString(desBus.size()));
		//result.addElement(Integer.toString(busResult.size()));
				
		if(busResult.size()!=0) {
			for(int i=0;i<busResult.size();i++) result.addElement("BUS " + Integer.toString(i + 1));
		}
		
		//BUS-BUS
		Vector userBus2 = db.createRunBus2(userBus, busResult);
		Vector desBus2 = db.createRunBus2(desBus, busResult);
		Vector busDetect2 = db.detectBus2(userBus2, desBus2);
		Vector busResult2 = db.routingBus2(busDetect2);
		
		if(busResult2.size()!=0) {
			for(int i=0;i<busResult2.size();i++) result.addElement("change BUS " + Integer.toString(i + 1));
		}
		
		
		/*
		Vector userVan = db.findRunVan(userPositions);
		Vector desVan = db.findRunVan(desPositions);
		Vector vanResult = db.detectVan(userVan, desVan);
		if(vanResult.size()!=0) {
			for(int i=0;i<vanResult.size();i++) result.addElement("VAN" + Integer.toString(i + 1));
		}
		*/
		return result;
	}
	
	public Vector BTSBTSService(String userPositions, String destinationPlace) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		
		//BTS-BTS 
		//BTS CheckLine
		Vector userBTS = db.findNearBTS(userLatitude, userLongitude);
		Vector desBTS = db.findNearBTS(desLatitude, desLongitude);
		BTS userBTSresult = (BTS)userBTS.elementAt(0);
		BTS desBTSresult = (BTS)desBTS.elementAt(0);
		boolean checkLine = db.checkLineBTS(userBTSresult.getBTS_ID(), desBTSresult.getBTS_ID());
			
		if(!checkLine) {
			result.addElement(userBTSresult.getBTS_NAME());
			result.addElement("Siam");
			result.addElement(desBTSresult.getBTS_NAME());
			result.addElement((String)userBTS.elementAt(1));
		}
		else {
			result.addElement(userBTSresult.getBTS_NAME());
			result.addElement(desBTSresult.getBTS_NAME());
			result.addElement((String)userBTS.elementAt(1));
		}
		return result;
	}
	
	public Vector BTSUGService(String userPositions, String destinationPlace) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		
		//BTS-UG
		//BTS->UG Result
		Vector userBTS = db.findNearBTS(userLatitude, userLongitude);
		Vector desUG = db.findNearUG(desLatitude, desLongitude);
		BTS userBTSresult = (BTS)userBTS.elementAt(0);
		UG desUGresult = (UG)desUG.elementAt(0);
		String userBConnect = userBTSresult.getBConnect();
		String desUConnect = db.findUConnect(userBConnect);
		
		result.addElement(userBTSresult.getBTS_NAME());
		result.addElement(userBConnect);
		result.addElement(desUConnect);
		result.addElement(desUGresult.getUG_NAME());
		result.addElement((String)userBTS.elementAt(1));
		return result;
	}
	
	public Vector UGUGService(String userPositions, String destinationPlace) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		
		//UG-UG
		//UG Result
		Vector userUG = db.findNearUG(userLatitude, userLongitude);
		Vector desUG = db.findNearUG(desLatitude, desLongitude);
		UG userUGresult = (UG)userUG.elementAt(0);
		UG desUGresult = (UG)desUG.elementAt(0);
		result.addElement(userUGresult.getUG_NAME());
		result.addElement(desUGresult.getUG_NAME());
		result.addElement((String)userUG.elementAt(1));
		//result.addElement(desPositions);
		return result;
	}
	
	public Vector UGBTSService(String userPositions, String destinationPlace) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		
		//UG->BTS Result
		Vector userUG = db.findNearUG(userLatitude, userLongitude);
		Vector desBTS = db.findNearBTS(desLatitude, desLongitude);
		UG userUGresult = (UG)userUG.elementAt(0);
		BTS desBTSresult = (BTS)desBTS.elementAt(0);
		String userUConnect = userUGresult.getUConnect();
		String desBConnect = db.findBConnect(userUConnect);
		result.addElement(userUGresult.getUG_NAME());
		result.addElement(userUConnect);
		result.addElement(desBConnect);
		result.addElement(desBTSresult.getBTS_NAME());
		result.addElement((String)userUG.elementAt(1));
		return result;
	}
	
	public Vector BUSService(String userPositions, String destinationPlace, int i) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		String userRoadName = userLocation.getRoadName();
		int userPointID = userLocation.getPointID();
		
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		String desRoadName = desInfo.getRoadName();
		int desPointID = desInfo.getPointID();
				
		Vector userBus = db.findRunBus(userRoadName, userPointID);
		Vector desBus = db.findRunBus(desRoadName, desPointID);
		Vector busResult = db.detectBus(userBus, desBus, userPointID, desPointID);
		runBus busRunResult = (runBus)busResult.elementAt(i);
		Vector busRealResult = new Vector();
		busRealResult.addElement(busRunResult.getBusNum());
		busRealResult.addElement(busRunResult.getUserStay());
		busRealResult.addElement(busRunResult.getType());
		result.addElement(busRealResult);
		return result;
	}
	
	public Vector BUSBUSService(String userPositions, String destinationPlace, int i) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//result.addElement(userPositions);
		//result.addElement(destinationPlace);
		//result.addElement(Integer.toString(i));
		
		//Get Source & Destination Attribute Value
		Pos userLocation = db.findLocation(userPositions);
		double userLatitude = userLocation.getLatitude();
		double userLongitude = userLocation.getLongitude();
		String userRoadName = userLocation.getRoadName();
		int userPointID = userLocation.getPointID();
		
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		String desRoadName = desInfo.getRoadName();
		int desPointID = desInfo.getPointID();		
					
		Vector userBus = db.findRunBus(userRoadName, userPointID);
		Vector desBus = db.findRunBus(desRoadName, desPointID);
		Vector busResult = db.detectBus(userBus, desBus, userPointID, desPointID);
		Vector userBus2 = db.createRunBus2(userBus, busResult);
		Vector desBus2 = db.createRunBus2(desBus, busResult);
		Vector busDetect2 = db.detectBus2(userBus2, desBus2);
		Vector busResult2 = db.routingBus2(busDetect2);
		
		Vector bus = (Vector)busResult2.elementAt(i);
		runBus bus1 = (runBus)bus.elementAt(0);
		String bus1busnum = bus1.getBusNum();
		String bus1userstay = bus1.getUserStay();
		String bus1type = bus1.getType();
		runBus bus2 = (runBus)bus.elementAt(2);
		String bus2busnum = bus2.getBusNum();
		String bus2userstay = bus2.getUserStay();
		String bus2type = bus1.getType();
		String connection = (String)bus.elementAt(1);
				
		result.addElement(bus1busnum);
		result.addElement(bus1userstay);
		result.addElement(bus1type);
		result.addElement(bus2busnum);
		result.addElement(bus2userstay);
		result.addElement(bus2type);
		result.addElement(connection);
		
		
		return result;
	}
	/*
	public Vector VANService(String userPositions, String destinationPlace, int i) {
		Vector result = new Vector();
		DBConnect db = new DBConnect();
		
		//Get Source & Destination Attribute Value
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		String desPositions = desInfo.getPositions();
				
		Vector userVan = db.findRunVan(userPositions);
		Vector desVan = db.findRunVan(desPositions);
		Vector vanResult = db.detectVan(userVan, desVan);
		runVan vanRunResult = (runVan)vanResult.elementAt(i);
		Vector vanRealResult = new Vector();
		vanRealResult.addElement(vanRunResult.getVanNum());
		vanRealResult.addElement(vanRunResult.getIo());
		vanRealResult.addElement(vanRunResult.getSeq());
		result.addElement(vanRealResult);
		return result;
	}
	*/
	public String checkRoadPath(String reallatitude, String reallongitude, String userPositions) {
		DBConnect db = new DBConnect();
		double realLatitude = Double.parseDouble(reallatitude);
		double realLongitude = Double.parseDouble(reallongitude);
		return db.checkRoadPath(realLatitude, realLongitude, userPositions);
	}
	
	public String checkTrackBTSStation(String BTS_NAME, String userlatitude, String userlongitude) {
		String result = "false";
		DBConnect db = new DBConnect();
		BTS btsResult = db.searchBTSLocation(BTS_NAME);
		double stationLatitude = btsResult.getLatitude();
		double stationLongitude = btsResult.getLongitude();
		double userLatitude = Double.parseDouble(userlatitude);
		double userLongitude = Double.parseDouble(userlongitude);
		double distance = calGeometry(calDistance(userLatitude, stationLatitude, userLongitude, stationLongitude));
		if(distance < 700) result = "true";
		return result;
	}
	
	public String checkTrackUGStation(String UG_NAME, String userlatitude, String userlongitude) {
		String result = "false";
		DBConnect db = new DBConnect();
		UG ugResult = db.searchUGLocation(UG_NAME);
		double stationLatitude = ugResult.getLatitude();
		double stationLongitude = ugResult.getLongitude();
		double userLatitude = Double.parseDouble(userlatitude);
		double userLongitude = Double.parseDouble(userlongitude);
		double distance = calGeometry(calDistance(userLatitude, stationLatitude, userLongitude, stationLongitude));
		if(distance < 700) result = "true";
		return result;
	}
	/*
	public String checkTrackBUSandVAN(String destinationPlace, String userlatitude, String userlongitude) {
		String result = "false";
		DBConnect db = new DBConnect();
		Vector desInfoVec = db.findDestination(destinationPlace);
		Pos desInfo = (Pos)desInfoVec.elementAt(0);
		double desLatitude = desInfo.getLatitude();
		double desLongitude = desInfo.getLongitude();
		double userLatitude = Double.parseDouble(userlatitude);
		double userLongitude = Double.parseDouble(userlongitude);
		double distance = calGeometry(calDistance(userLatitude, desLatitude, userLongitude, desLongitude));
		if(distance < 700) result = "true";
		return result;
	}
	*/
}