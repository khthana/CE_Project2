package guidesystem;

import java.sql.*;
import java.util.*;

public class vehicleService {
	private static String url = "jdbc:mysql://161.246.5.103/guidesystem?autoReconnect=true&user=Earth&password=Earth";
    private static String driver = "org.gjt.mm.mysql.Driver";
    
    public Vector listBTS() {
    	Vector result = new Vector();
    	try {
    		Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM bts_station";
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("BTS_NAME"));
			}
			rs.close();
			stmt.close();
			conn.close();
    	}
    	catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
    }
    
    public Vector showBTS(String bts_name) {
    	Vector result = new Vector();
    	try {
    		Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM bts_station WHERE BTS_NAME=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, bts_name);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("BTS_ID"));
				result.addElement(rs.getString("BTS_NAME"));
				result.addElement(rs.getString("LINE"));
				result.addElement(rs.getString("PLACE"));
			}
			rs.close();
			stmt.close();
			conn.close();
    	}
    	catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
    }
    
    public Vector listUG() {
    	Vector result = new Vector();
    	try {
    		Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT UG_NAME FROM ug_station";
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("UG_NAME"));
			}
			rs.close();
			stmt.close();
			conn.close();
    	}
    	catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
    }
    
    public Vector showUG(String ug_name) {
    	Vector result = new Vector();
    	try {
    		Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM ug_station WHERE UG_NAME=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, ug_name);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("UG_ID"));
				result.addElement(rs.getString("UG_NAME"));
				result.addElement(rs.getString("PLACE"));
			}
			rs.close();
			stmt.close();
			conn.close();
    	}
    	catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
    }
    
    public Vector showBus(String BusType, String BusName) {
    	Vector result = new Vector();
    	try {
    		Class.forName(driver);
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM bus WHERE BUS_NAME=? AND TYPE=?";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, BusName);
			stmt.setString(2, BusType);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				result.addElement(rs.getString("BUS_ID"));
				result.addElement(rs.getString("BUS_NAME"));
				result.addElement(rs.getString("TYPE"));
				result.addElement(rs.getString("ZONE"));
				result.addElement(rs.getString("STIME"));
				result.addElement(rs.getString("ETIME"));
				result.addElement(rs.getString("FROM"));
				result.addElement(rs.getString("TO"));
				result.addElement(rs.getString("INBOUND"));
				result.addElement(rs.getString("OUTBOUND"));
			}
			rs.close();
			stmt.close();
			conn.close();
    	}
    	catch(ClassNotFoundException e) { System.out.println(e); return null; }
		catch(SQLException e) { System.out.println(e); return null; }
		return result;
    }
    
    
}
