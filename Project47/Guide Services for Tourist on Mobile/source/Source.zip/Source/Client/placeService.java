import java.io.*;
import java.util.Vector;
import org.ksoap2.*;
import org.ksoap2.transport.*;
import org.ksoap2.serialization.*;

public class placeService {
	private String url = "http://161.246.5.103:8080/soap/servlet/rpcrouter";
	
	public void setRemote(String remote) { url = remote; }
	public String getRemote() { return url; }
	
	
	public SoapObject listPlace(int placeType) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "listPlace");
			rpc.addProperty("placeType", new Integer(placeType));
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject showTouristAttraction(String tourName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showTouristAttraction");
			rpc.addProperty("tourName", tourName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
	
	public SoapObject showTemple(String templeName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showTemple");
			rpc.addProperty("templeName", templeName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
	
	public SoapObject showPark(String parkName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showPark");
			rpc.addProperty("parkName", parkName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
	
	public SoapObject showStadium(String stadiumName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showStadium");
			rpc.addProperty("stadiumName", stadiumName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
	
	public SoapObject showTransportStation(String transportStationName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showTransportStation");
			rpc.addProperty("transportStationName", transportStationName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
	
	public SoapObject showTouristPolice(String touristPoliceName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showTouristPolice");
			rpc.addProperty("touristPoliceName", touristPoliceName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
	
	public SoapObject showShopping(String shoppingName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:placeService", "showShopping");
			rpc.addProperty("shoppingName", shoppingName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace(); return null; }
		return result;
	}
}