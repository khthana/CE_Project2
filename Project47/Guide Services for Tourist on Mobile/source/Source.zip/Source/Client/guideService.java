import java.io.*;
import java.util.Vector;
import org.ksoap2.*;
import org.ksoap2.transport.*;
import org.ksoap2.serialization.*;

public class guideService {
	private String url = "http://161.246.5.103:8080/soap/servlet/rpcrouter";
	
	public void setRemote(String remote) { url = remote; }
	public String getRemote() { return url; }
	
	public SoapObject findUserPositionGPS(String Latitude, String Longitude) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "findUserPositionGPS");
			rpc.addProperty("Latitude", Latitude);
			rpc.addProperty("Longitude", Longitude);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject findUserPositionManual(String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "findUserPositionManual");
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
/*	
	public SoapObject decisionGuide(String userLatitude, String userLongitude, String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "decisionGuide");
			rpc.addProperty("userlatitude", userLatitude);
			rpc.addProperty("userlongitude", userLongitude);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
*/	
	public SoapObject checkUserNearDestination(String userPositions, String destinationPlace) {
		SoapObject result;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "checkUserNearDestination");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject decideGuide(String userPositions, String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "decideGuide");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject BTSBTSService(String userPositions, String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "BTSBTSService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject BTSUGService(String userPositions, String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "BTSUGService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject UGUGService(String userPositions, String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "UGUGService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject UGBTSService(String userPositions, String destinationPlace) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "UGBTSService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject BUSService(String userPositions, String destinationPlace, int i) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "BUSService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			rpc.addProperty("i", new Integer(i));
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject BUSBUSService(String userPositions, String destinationPlace, int i) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "BUSBUSService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			rpc.addProperty("i", new Integer(i));
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject VANService(String userPositions, String destinationPlace, int i) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "VANService");
			rpc.addProperty("userPositions", userPositions);
			rpc.addProperty("destinationPlace", destinationPlace);
			rpc.addProperty("i", new Integer(i));
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public String checkRoadPath(String realLatitude, String realLongitude, String userPositions) {
		String result = null;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "checkRoadPath");
			rpc.addProperty("realLatitude", realLatitude);
			rpc.addProperty("realLongitude", realLongitude);
			rpc.addProperty("userPositions", userPositions);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (String)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public boolean checkTrackBTSStation(String BTS_NAME, String userlatitude, String userlongitude) {
		boolean result = false;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "checkTrackBTSStation");
			rpc.addProperty("BTS_NAME", BTS_NAME);
			rpc.addProperty("userlatitude", userlatitude);
			rpc.addProperty("userlongitude", userlongitude);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			String resultString = (String)envelope.getResult();
			if(resultString.equals("true")) result = true;
		}
		catch(Exception e) { e.printStackTrace (); return false; }
		return result;
	}
	
	public boolean checkTrackUGStation(String UG_NAME, String userlatitude, String userlongitude) {
		boolean result = false;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "checkTrackUGStation");
			rpc.addProperty("UG_NAME", UG_NAME);
			rpc.addProperty("userlatitude", userlatitude);
			rpc.addProperty("userlongitude", userlongitude);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			String resultString = (String)envelope.getResult();
			if(resultString.equals("true")) result = true;
		}
		catch(Exception e) { e.printStackTrace (); return false; }
		return result;
	}
	
	public boolean checkTrackBUSandVAN(String destinationPlace, String userlatitude, String userlongitude) {
		boolean result = false;
		try {
			SoapObject rpc = new SoapObject("urn:guideService", "checkTrackBUSandVAN");
			rpc.addProperty("destinationPlace", destinationPlace);
			rpc.addProperty("userlatitude", userlatitude);
			rpc.addProperty("userlongitude", userlongitude);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			String resultString = (String)envelope.getResult();
			if(resultString.equals("true")) result = true;
		}
		catch(Exception e) { e.printStackTrace (); return false; }
		return result;
	}
}