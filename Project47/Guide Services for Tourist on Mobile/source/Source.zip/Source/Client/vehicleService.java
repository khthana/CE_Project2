import java.io.*;
import java.util.Vector;
import org.ksoap2.*;
import org.ksoap2.transport.*;
import org.ksoap2.serialization.*;

public class vehicleService {
	private String url = "http://161.246.5.103:8080/soap/servlet/rpcrouter";
	
	public void setRemote(String remote) { url = remote; }
	public String getRemote() { return url; }
	
	public SoapObject listBTS() {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:vehicleService", "listBTS");
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject showBTS(String bts_name) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:vehicleService", "showBTS");
			rpc.addProperty("bts_name", bts_name);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject listUG() {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:vehicleService", "listUG");
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject showUG(String ug_name) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:vehicleService", "showUG");
			rpc.addProperty("ug_name", ug_name);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			//System.out.println("Soap Request");
			//System.out.println(ht.requestDump);
			//System.out.println("Soap Response");
			//System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
	public SoapObject showBus(String BusType, String BusName) {
		SoapObject result = null;
		try {
			SoapObject rpc = new SoapObject("urn:vehicleService", "showBus");
			rpc.addProperty("BusType", BusType);
			rpc.addProperty("BusName", BusName);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.bodyOut = rpc;
			HttpTransport ht = new HttpTransport(url);
			ht.debug = true;
			ht.call(null, envelope);
			System.out.println("Soap Request");
			System.out.println(ht.requestDump);
			System.out.println("Soap Response");
			System.out.println(ht.responseDump);
			result = (SoapObject)envelope.getResult();
		}
		catch(Exception e) { e.printStackTrace (); return null; }
		return result;
	}
	
}