import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import org.ksoap2.*;
import org.ksoap2.transport.*;
import org.ksoap2.serialization.*;
import java.util.Vector;
import java.util.Timer;
import java.util.TimerTask;

public class Guide extends MIDlet implements CommandListener {
	private static final int TOURIST_ATTRACTION = 1;
	private static final int TEMPLE = 2;
	private static final int PARK = 3;
	private static final int STADIUM = 4;
	private static final int TRANSPORT_STATION = 5;
	private static final int TOURIST_POLICE = 6;
	private static final int SHOPPING = 7;
	private int place = 0;
	
	private boolean btsEnable = true;
	private boolean ugEnable = true;
	private boolean btsugEnable = true;
	private boolean bus1Enable = true;
	private boolean bus2Enable = true;
	
	private placeService placeservice;
	private vehicleService vehicleservice;
	private guideService guideservice;
	private String userPosition = "";
	private String userLatitude = "";
	private String userLongitude = "";
	private String userDescription = "";
	private String userRoadName = "";
	private String userPointID = "";
	private String realLatitude = "";
	private String realLongitude = "";
	private String destinationPlace = "";
	private String setAlert = "";
	private int counterAlert = 0;
	
	private Timer timer;
	//BTS->BTS Timer Task
	private btsbtsTimer1 btsbtstimer1;
	private btsbtsTimer2 btsbtstimer2;
	//BTS->UG Timer Task
	private btsugTimer1 btsugtimer1;
	private btsugTimer2 btsugtimer2;
	//UG->UG Timer Task
	private ugugTimer1 ugugtimer1;
	//UG->BTS Timer Task
	private ugbtsTimer1 ugbtstimer1;
	private ugbtsTimer2 ugbtstimer2;
	//BUS Timer Task
	private busTimer1 bustimer1;
	//VAn Timer Task
	private vanTimer1 vantimer1;

	
	private Display display;
	private Command okCommand, backCommand, exitCommand;
	private Command filterCommand;
	
	//WaitForm
	private Form waitForm;
	private Gauge waitGauge;
	
	//GenLocationForm
	private Form genLocationForm;
	private TextField genLocationTF1, genLocationTF2;
	
	//MainForm
	private Form mainForm;
	private ChoiceGroup mainChoiceGroup;
	
	//PlaceForm
	private Form placeForm;
	private ChoiceGroup placeChoiceGroup;
		
	//ListPlaceForm
	private Form listPlaceForm;
	private ChoiceGroup listPlaceChoiceGroup;
	
	//ShowTouristAttraction
	private Form showTouristAttractionForm;
	private StringItem showTouristAttractionSI;
	
	//ShowTemple
	private Form showTempleForm;
	private StringItem showTempleSI;
	
	//ShowPark
	private Form showParkForm;
	private StringItem showParkSI;
	
	//ShowStadium
	private Form showStadiumForm;
	private StringItem showStadiumSI;
	
	//ShowTransportStation
	private Form showTransportStationForm;
	private StringItem showTransportStationSI;
	
	//ShowTouristPolice
	private Form showTouristPoliceForm;
	private StringItem showTouristPoliceSI;
	
	//ShowShopping
	private Form showShoppingForm;
	private StringItem showShoppingSI;
	
	//VehicleForm
	private Form vehicleForm;
	private ChoiceGroup vehicleChoiceGroup;
	
	//btsForm
	private Form btsForm;
	private ChoiceGroup btsChoiceGroup;

	//showbtsForm
	private Form showbtsForm;
	private StringItem showbtsSI;
	
	//ugForm
	private Form ugForm;
	private ChoiceGroup ugChoiceGroup;
	
	//showugForm
	private Form showugForm;
	private StringItem showugSI;
	
	//busForm
	private Form busForm;
	private ChoiceGroup busChoiceGroup;
	private TextField busTF;
	
	//showbusForm
	private Form showbusForm;
	private StringItem showbusSI;
	
	//vanForm
	private Form vanForm;
	private TextField vanTF;
	
	//showvanForm
	private Form showvanForm;
	private StringItem showvanSI;
	
	//GuideForm
	private Form guideForm;
	private ChoiceGroup guideChoiceGroup;
	
	//GPSForm
	private Form gpsForm;
	private TextField latTextField, lonTextField;
	
	//ManualForm
	private Form manualForm;
	private ChoiceGroup manualChoiceGroup;
	
	//ManualListPlaceForm
	private Form manualListPlaceForm;
	private ChoiceGroup manualListPlaceChoiceGroup;
	
	//UserPosForm
	private Form userPosForm;
	private StringItem userPosSI1,userPosSI2;
	
	//DesPlaceForm
	private Form desPlaceForm;
	private ChoiceGroup desPlaceChoiceGroup;
	
	//DesListPlaceForm
	private Form desListPlaceForm;
	private ChoiceGroup desListPlaceChoiceGroup;
	
	//PreGuideForm
	private Form preGuideForm;
	private StringItem preGuideSI;
	
	//ResultGuideForm
	private Form resultGuideForm;
	private ChoiceGroup resultGuideChoiceGroup;
	
	//FilterForm
	private Form filterForm;
	private ChoiceGroup filterChoiceGroup;
	
	private Form userNearDesForm;
	private StringItem userNearDesSI;
	
	//BTSBTSResultForm
	private Form BTSBTSResultForm;
	private StringItem BTSBTSResultSI;
	
	//BTSUGResultForm
	private Form BTSUGResultForm;
	private StringItem BTSUGResultSI;
	
	//UGUGResultForm
	private Form UGUGResultForm;
	private StringItem UGUGResultSI;
	
	//UGBTSResultForm
	private Form UGBTSResultForm;
	private StringItem UGBTSResultSI;
	
	//BUSResultForm
	private Form BUSResultForm;
	private StringItem BUSResultSI;
	
	//BUSBUSResultForm
	private Form BUSBUSResultForm;
	private StringItem BUSBUSResultSI;
	
	//VANResultForm
	private Form VANResultForm;
	private StringItem VANResultSI;
			
	//DebugForm
	private Form debugForm;
	private TextField debugTF1, debugTF2, debugTF3, debugTF4;
	
	//SettingForm
	private Form settingForm;
	private TextField settingTF1;
	private ChoiceGroup settingChoiceGroup;
	
	public Guide() {
		placeservice = new placeService();
		vehicleservice = new vehicleService();
		guideservice = new guideService();
		
		timer = new Timer();
		//BTS->BTS Timer Task
		btsbtstimer1 = new btsbtsTimer1();
		btsbtstimer2 = new btsbtsTimer2();
		//BTS->UG Timer Task
		btsugtimer1 = new btsugTimer1();
		btsugtimer2 = new btsugTimer2();
		//UG->UG Timer Task
		ugugtimer1 = new ugugTimer1();
		//UG->BTS Timer Task
		ugbtstimer1 = new ugbtsTimer1();
		ugbtstimer2 = new ugbtsTimer2();
		//BUS Timer Task
		bustimer1 = new busTimer1();
		//VAN Timer Task
		vantimer1 = new vanTimer1();
						
		okCommand = new Command("Ok", Command.OK, 1);
		backCommand = new Command("Back", Command.BACK, 1);
		exitCommand = new Command("Exit", Command.EXIT, 1);
		filterCommand = new Command("Filter", Command.OK, 1);
		
		//waitForm
		waitForm = new Form("Loading...");
		waitGauge = new Gauge("Waiting for Connect Server", false, Gauge.INDEFINITE , Gauge.CONTINUOUS_RUNNING);
		waitForm.append(waitGauge);
		waitForm.addCommand(exitCommand);
		waitForm.setCommandListener(this);
		
		//genLocationForm
		genLocationForm = new Form("Input Location");
		genLocationTF1 = new TextField("Latitude", "", 10, TextField.ANY);
		genLocationTF2 = new TextField("Longitude", "", 10, TextField.ANY);
		genLocationForm.append(genLocationTF1);
		genLocationForm.append(genLocationTF2);
		genLocationForm.addCommand(okCommand);
		genLocationForm.addCommand(backCommand);
		genLocationForm.addCommand(exitCommand);
		genLocationForm.setCommandListener(this);
		
		//MainForm
		mainForm = new Form("TouristGuide");
		mainChoiceGroup = new ChoiceGroup("Menu", List.EXCLUSIVE);
		mainChoiceGroup.append("Place", null);
		mainChoiceGroup.append("Vehicle", null);
		mainChoiceGroup.append("GuideSystem", null);
		mainChoiceGroup.append("Setting", null);
		mainForm.append(mainChoiceGroup);
		mainForm.addCommand(okCommand);
		mainForm.addCommand(exitCommand);
		mainForm.setCommandListener(this);
		
//Place Services ---------------------------------------------------------------		

		//PlaceForm
		placeForm = new Form("Place");
		placeChoiceGroup = new ChoiceGroup("Place Catagories", List.EXCLUSIVE);
		placeChoiceGroup.append("Tourist Attraction", null);
		placeChoiceGroup.append("Temple", null);
		placeChoiceGroup.append("Park", null);
		placeChoiceGroup.append("Stadium", null);
		placeChoiceGroup.append("Transport Station", null);
		placeChoiceGroup.append("Tourist Police", null);
		placeChoiceGroup.append("Shopping", null);
		placeForm.append(placeChoiceGroup);
		placeForm.addCommand(okCommand);
		placeForm.addCommand(backCommand);
		placeForm.addCommand(exitCommand);
		placeForm.setCommandListener(this);
					
		//ListPlaceForm
		listPlaceForm = new Form("");
		listPlaceChoiceGroup = new ChoiceGroup("Select your place :", List.EXCLUSIVE);
		listPlaceForm.append(listPlaceChoiceGroup);
		listPlaceForm.addCommand(okCommand);
		listPlaceForm.addCommand(backCommand);
		listPlaceForm.addCommand(exitCommand);
		listPlaceForm.setCommandListener(this);
		
		//ShowTouristAttraction
		showTouristAttractionForm = new Form("");
		showTouristAttractionSI = new StringItem("", "");
		showTouristAttractionForm.append(showTouristAttractionSI);
		showTouristAttractionForm.addCommand(okCommand);
		showTouristAttractionForm.addCommand(backCommand);
		showTouristAttractionForm.addCommand(exitCommand);
		showTouristAttractionForm.setCommandListener(this);
		
		//ShowTemple
		showTempleForm = new Form("");
		showTempleSI = new StringItem("", "");
		showTempleForm.append(showTempleSI);
		showTempleForm.addCommand(okCommand);
		showTempleForm.addCommand(backCommand);
		showTempleForm.addCommand(exitCommand);
		showTempleForm.setCommandListener(this);
		
		//ShowPark
		showParkForm = new Form("");
		showParkSI = new StringItem("", "");
		showParkForm.append(showParkSI);
		showParkForm.addCommand(okCommand);
		showParkForm.addCommand(backCommand);
		showParkForm.addCommand(exitCommand);
		showParkForm.setCommandListener(this);
		
		//ShowStadium
		showStadiumForm = new Form("");
		showStadiumSI = new StringItem("", "");
		showStadiumForm.append(showStadiumSI);
		showStadiumForm.addCommand(okCommand);
		showStadiumForm.addCommand(backCommand);
		showStadiumForm.addCommand(exitCommand);
		showStadiumForm.setCommandListener(this);
		
		//ShowTransportStation
		showTransportStationForm = new Form("");
		showTransportStationSI = new StringItem("", "");
		showTransportStationForm.append(showTransportStationSI);
		showTransportStationForm.addCommand(okCommand);
		showTransportStationForm.addCommand(backCommand);
		showTransportStationForm.addCommand(exitCommand);
		showTransportStationForm.setCommandListener(this);
		
		//ShowTouristPolice
		showTouristPoliceForm = new Form("");
		showTouristPoliceSI = new StringItem("", "");
		showTouristPoliceForm.append(showTouristPoliceSI);
		showTouristPoliceForm.addCommand(okCommand);
		showTouristPoliceForm.addCommand(backCommand);
		showTouristPoliceForm.addCommand(exitCommand);
		showTouristPoliceForm.setCommandListener(this);
		
		//ShowShopping
		showShoppingForm = new Form("");
		showShoppingSI = new StringItem("", "");
		showShoppingForm.append(showShoppingSI);
		showShoppingForm.addCommand(okCommand);
		showShoppingForm.addCommand(backCommand);
		showShoppingForm.addCommand(exitCommand);
		showShoppingForm.setCommandListener(this);

//Vehicle Services ---------------------------------------------------------------		
		
		//VehicleForm
		vehicleForm = new Form("Vehicle");
		vehicleChoiceGroup = new ChoiceGroup("Vehicle Catagories", List.EXCLUSIVE);
		vehicleChoiceGroup.append("BTS", null);
		vehicleChoiceGroup.append("MRT", null);
		vehicleChoiceGroup.append("Bus", null);
		//vehicleChoiceGroup.append("Van", null);
		vehicleForm.append(vehicleChoiceGroup);
		vehicleForm.addCommand(okCommand);
		vehicleForm.addCommand(backCommand);
		vehicleForm.addCommand(exitCommand);
		vehicleForm.setCommandListener(this);
		
		//btsForm
		btsForm = new Form("BTS");
		btsChoiceGroup = new ChoiceGroup("Chooce stations", List.EXCLUSIVE);
		btsForm.append(btsChoiceGroup);
		btsForm.addCommand(okCommand);
		btsForm.addCommand(backCommand);
		btsForm.addCommand(exitCommand);
		btsForm.setCommandListener(this);
				
		//showbtsForm
		showbtsForm = new Form("");
		showbtsSI = new StringItem("", "");
		showbtsForm.append(showbtsSI);
		showbtsForm.addCommand(okCommand);
		showbtsForm.addCommand(backCommand);
		showbtsForm.addCommand(exitCommand);
		showbtsForm.setCommandListener(this);
		
		//ugForm
		ugForm = new Form("MRT");
		ugChoiceGroup = new ChoiceGroup("Choose stations", List.EXCLUSIVE);
		ugForm.append(ugChoiceGroup);
		ugForm.addCommand(okCommand);
		ugForm.addCommand(backCommand);
		ugForm.addCommand(exitCommand);
		ugForm.setCommandListener(this);
		
		//showugForm
		showugForm = new Form("");
		showugSI = new StringItem("", "");
		showugForm.append(showugSI);
		showugForm.addCommand(okCommand);
		showugForm.addCommand(backCommand);
		showugForm.addCommand(exitCommand);
		showugForm.setCommandListener(this);
				
		//busForm
		busForm = new Form("Bus");
		busChoiceGroup = new ChoiceGroup("Bus Catagoties", List.EXCLUSIVE);
		busChoiceGroup.append("Ordinary", null);
		busChoiceGroup.append("Air Bus", null);
		busChoiceGroup.append("Euro", null);
		busChoiceGroup.append("MicroBus", null);
		busTF = new TextField("Bus No.", "", 4, TextField.NUMERIC);
		busForm.append(busChoiceGroup);
		busForm.append(busTF);
		busForm.addCommand(okCommand);
		busForm.addCommand(backCommand);
		busForm.addCommand(exitCommand);
		busForm.setCommandListener(this);
		
		//showbusForm
		showbusForm = new Form("");
		showbusSI = new StringItem("", "");
		showbusForm.append(showbusSI);
		showbusForm.addCommand(okCommand);
		showbusForm.addCommand(backCommand);
		showbusForm.addCommand(exitCommand);
		showbusForm.setCommandListener(this);
		
		//vanForm
		vanForm = new Form("Van");
		vanTF = new TextField("Van No.", "", 4, TextField.NUMERIC);
		vanForm.append(vanTF);
		vanForm.addCommand(okCommand);
		vanForm.addCommand(backCommand);
		vanForm.addCommand(exitCommand);
		vanForm.setCommandListener(this);
		
		//showvanForm
		showvanForm =new Form("");
		showvanSI = new StringItem("", "");
		showvanForm.append(showvanSI);
		showvanForm.addCommand(okCommand);
		showvanForm.addCommand(backCommand);
		showvanForm.addCommand(exitCommand);
		showvanForm.setCommandListener(this);

//Guide Services ---------------------------------------------------------------
				
		//GuideForm
		guideForm = new Form("Guide System");
		guideChoiceGroup = new ChoiceGroup("Input Locations", List.EXCLUSIVE);
		guideChoiceGroup.append("GPS", null);
		guideChoiceGroup.append("Manual", null);
		guideForm.append(guideChoiceGroup);
		guideForm.addCommand(okCommand);
		guideForm.addCommand(backCommand);
		guideForm.addCommand(exitCommand);
		guideForm.setCommandListener(this);
		
		//gpsForm
		gpsForm = new Form("Input Your Location");
		latTextField = new TextField("Latitude", "", 10, TextField.ANY);
		lonTextField = new TextField("Longitude", "", 10, TextField.ANY);
		gpsForm.append(latTextField);
		gpsForm.append(lonTextField);
		gpsForm.addCommand(okCommand);
		gpsForm.addCommand(backCommand);
		gpsForm.addCommand(exitCommand);
		gpsForm.setCommandListener(this);
		
		//manualForm
		manualForm = new Form("Input Your Location");
		manualChoiceGroup = new ChoiceGroup("Place Catagories", List.EXCLUSIVE);
		manualChoiceGroup.append("Tourist Attraction", null);
		manualChoiceGroup.append("Temple", null);
		manualChoiceGroup.append("Park", null);
		manualChoiceGroup.append("Stadium", null);
		manualChoiceGroup.append("Transport Station", null);
		manualChoiceGroup.append("Tourist Police", null);
		manualChoiceGroup.append("Shopping", null);
		manualChoiceGroup.append("BTS Station", null);
		manualChoiceGroup.append("MRT Station", null);
		manualForm.append(manualChoiceGroup);
		manualForm.addCommand(okCommand);
		manualForm.addCommand(backCommand);
		manualForm.addCommand(exitCommand);
		manualForm.setCommandListener(this);
		
		//manualListPlaceForm
		manualListPlaceForm = new Form("Choose Your Location");
		manualListPlaceChoiceGroup = new ChoiceGroup("Choose Places", List.EXCLUSIVE);
		manualListPlaceForm.append(manualListPlaceChoiceGroup);
		manualListPlaceForm.addCommand(okCommand);
		manualListPlaceForm.addCommand(backCommand);
		manualListPlaceForm.addCommand(exitCommand);
		manualListPlaceForm.setCommandListener(this);
		
		//userPosForm
		userPosForm = new Form("Your Location");
		userPosSI1 = new StringItem("Your Location : ", "");
		userPosSI2 = new StringItem("Distance from Position : ", "");
		userPosForm.append(userPosSI1);
		userPosForm.append(userPosSI2);
		userPosForm.addCommand(okCommand);
		userPosForm.addCommand(backCommand);
		userPosForm.addCommand(exitCommand);
		userPosForm.setCommandListener(this);
		
		//DesPlaceForm
		desPlaceForm = new Form("Choose Destination");
		desPlaceChoiceGroup = new ChoiceGroup("Place Catagories", List.EXCLUSIVE);
		desPlaceChoiceGroup.append("Tourist Attraction", null);
		desPlaceChoiceGroup.append("Temple", null);
		desPlaceChoiceGroup.append("Park", null);
		desPlaceChoiceGroup.append("Stadium", null);
		desPlaceChoiceGroup.append("Transport Station", null);
		desPlaceChoiceGroup.append("Tourist Police", null);
		desPlaceChoiceGroup.append("Shopping", null);
		desPlaceChoiceGroup.append("BTS Station", null);
		desPlaceChoiceGroup.append("MRT Station", null);
		desPlaceForm.append(desPlaceChoiceGroup);
		desPlaceForm.addCommand(okCommand);
		desPlaceForm.addCommand(backCommand);
		desPlaceForm.addCommand(exitCommand);
		desPlaceForm.setCommandListener(this);
		
		//DesListPlaceForm
		desListPlaceForm = new Form("");
		desListPlaceChoiceGroup = new ChoiceGroup("Select your place :", List.EXCLUSIVE);
		desListPlaceForm.append(desListPlaceChoiceGroup);
		desListPlaceForm.addCommand(okCommand);
		desListPlaceForm.addCommand(backCommand);
		desListPlaceForm.addCommand(exitCommand);
		desListPlaceForm.setCommandListener(this);
		
		//PreGuideForm
		preGuideForm = new Form("Confirm Data to Guide");
		preGuideSI = new StringItem("", "");
		preGuideForm.append(preGuideSI);
		preGuideForm.addCommand(okCommand);
		preGuideForm.addCommand(backCommand);
		preGuideForm.addCommand(exitCommand);
		preGuideForm.setCommandListener(this);
		
		//ResultGuideForm
		resultGuideForm = new Form("Guide Result");
		resultGuideChoiceGroup = new ChoiceGroup("Select GuideLines", List.EXCLUSIVE);
		resultGuideForm.append(resultGuideChoiceGroup);
		resultGuideForm.addCommand(okCommand);
		//resultGuideForm.addCommand(filterCommand);
		resultGuideForm.addCommand(backCommand);
		resultGuideForm.addCommand(exitCommand);
		resultGuideForm.setCommandListener(this);
		
		//FilterForm
		filterForm = new Form("Filter");
		filterChoiceGroup = new ChoiceGroup("Enable service : ", List.MULTIPLE);
		filterChoiceGroup.append("BTS", null);
		filterChoiceGroup.append("MRT", null);
		filterChoiceGroup.append("BTS-MRT or MRT-BTS", null);
		filterChoiceGroup.append("BUS", null);
		filterChoiceGroup.append("BUS-BUS", null);
		//filterChoiceGroup.setSelectedIndex(0, btsEnable);
		//filterChoiceGroup.setSelectedIndex(1, ugEnable);
		//filterChoiceGroup.setSelectedIndex(2, btsugEnable);
		//filterChoiceGroup.setSelectedIndex(3, bus1Enable);
		//filterChoiceGroup.setSelectedIndex(4, bus2Enable);
		filterForm.append(filterChoiceGroup);
		filterForm.addCommand(okCommand);
		filterForm.addCommand(backCommand);
		filterForm.addCommand(exitCommand);
		filterForm.setCommandListener(this);
				
		//userNearDesForm
		userNearDesForm = new Form("User Near Destination");
		userNearDesSI = new StringItem("", "");
		userNearDesForm.append(userNearDesSI);
		userNearDesForm.addCommand(okCommand);
		userNearDesForm.addCommand(backCommand);
		userNearDesForm.addCommand(exitCommand);
		userNearDesForm.setCommandListener(this);
				
		//BTSBTSResultForm
		BTSBTSResultForm = new Form("BTS-BTS Result");
		BTSBTSResultSI = new StringItem("", "");
		BTSBTSResultForm.append(BTSBTSResultSI);
		BTSBTSResultForm.addCommand(okCommand);
		BTSBTSResultForm.addCommand(backCommand);
		BTSBTSResultForm.addCommand(exitCommand);
		BTSBTSResultForm.setCommandListener(this);
		
		//BTSUGResultForm
		BTSUGResultForm = new Form("BTS-MRT Result");
		BTSUGResultSI = new StringItem("", "");
		BTSUGResultForm.append(BTSUGResultSI);
		BTSUGResultForm.addCommand(okCommand);
		BTSUGResultForm.addCommand(backCommand);
		BTSUGResultForm.addCommand(exitCommand);
		BTSUGResultForm.setCommandListener(this);
		
		//UGUGResultForm
		UGUGResultForm = new Form("MRT-MRT Result");
		UGUGResultSI = new StringItem("", "");
		UGUGResultForm.append(UGUGResultSI);
		UGUGResultForm.addCommand(okCommand);
		UGUGResultForm.addCommand(backCommand);
		UGUGResultForm.addCommand(exitCommand);
		UGUGResultForm.setCommandListener(this);
		
		//UGBTSResultForm
		UGBTSResultForm = new Form("MRT-BTS Result");
		UGBTSResultSI = new StringItem("", "");
		UGBTSResultForm.append(UGBTSResultSI);
		UGBTSResultForm.addCommand(okCommand);
		UGBTSResultForm.addCommand(backCommand);
		UGBTSResultForm.addCommand(exitCommand);
		UGBTSResultForm.setCommandListener(this);
		
		//BUSResultForm
		BUSResultForm = new Form("BUS Result");
		BUSResultSI = new StringItem("", "");
		BUSResultForm.append(BUSResultSI);
		BUSResultForm.addCommand(okCommand);
		BUSResultForm.addCommand(backCommand);
		BUSResultForm.addCommand(exitCommand);
		BUSResultForm.setCommandListener(this);
		
		//BUSBUSResultForm
		BUSBUSResultForm = new Form("change BUS Result");
		BUSBUSResultSI = new StringItem("", "");
		BUSBUSResultForm.append(BUSBUSResultSI);
		BUSBUSResultForm.addCommand(okCommand);
		BUSBUSResultForm.addCommand(backCommand);
		BUSBUSResultForm.addCommand(exitCommand);
		BUSBUSResultForm.setCommandListener(this);
		
		//VANResultForm
		VANResultForm = new Form("VAN Result");
		VANResultSI = new StringItem("", "");
		VANResultForm.append(VANResultSI);
		VANResultForm.addCommand(okCommand);
		VANResultForm.addCommand(backCommand);
		VANResultForm.addCommand(exitCommand);
		VANResultForm.setCommandListener(this);
			
		//DebugForm
		debugForm = new Form("Debug");
		debugTF1 = new TextField("Latitude", "", 10, TextField.ANY);
		debugTF2 = new TextField("Longitude", "", 10, TextField.ANY);
		debugTF3 = new TextField("Location", "", 10, TextField.ANY);
		debugTF4 = new TextField("Destination", "", 20, TextField.ANY);
		debugForm.append(debugTF1);
		debugForm.append(debugTF2);
		debugForm.append(debugTF3);
		debugForm.append(debugTF4);
		debugForm.addCommand(okCommand);
		debugForm.addCommand(backCommand);
		debugForm.addCommand(exitCommand);
		debugForm.setCommandListener(this);
		
		//SettingForm
		settingForm = new Form("Setting");
		settingTF1 = new TextField("SOAP Server :" , guideservice.getRemote(), 60, TextField.ANY);
		settingChoiceGroup = new ChoiceGroup("Enable Services :", ChoiceGroup.MULTIPLE);
		settingChoiceGroup.append("BTS", null);
		settingChoiceGroup.append("MRT", null);
		settingChoiceGroup.append("BTS-MRT or MRT-BTS", null);
		settingChoiceGroup.append("BUS", null);
		settingChoiceGroup.append("BUS-BUS", null);
		settingChoiceGroup.setSelectedIndex(0, btsEnable);
		settingChoiceGroup.setSelectedIndex(1, ugEnable);
		settingChoiceGroup.setSelectedIndex(2, btsugEnable);
		settingChoiceGroup.setSelectedIndex(3, bus1Enable);
		settingChoiceGroup.setSelectedIndex(4, bus2Enable);
		
		settingForm.append(settingTF1);
		settingForm.append(settingChoiceGroup);
		settingForm.addCommand(okCommand);
		settingForm.addCommand(backCommand);
		settingForm.addCommand(exitCommand);
		settingForm.setCommandListener(this);
	}
	
	
	public void startApp() {
		display = Display.getDisplay(this);
		display.setCurrent(mainForm);
	}
	
	public void pauseApp() {
	}
	
	public void destroyApp(boolean unconditional) {
	}
	
	public void commandAction(Command command, Displayable screen) {
		if(command==exitCommand) {
			destroyApp(false);
			notifyDestroyed();
		}
		else if(command==backCommand) {
			if((screen==placeForm)||(screen==vehicleForm)||(screen==guideForm)||(screen==debugForm)||(screen==settingForm)) display.setCurrent(mainForm);
			else if(screen==listPlaceForm) display.setCurrent(placeForm);
			else if((screen==showTouristAttractionForm)||(screen==showTempleForm)||(screen==showParkForm)||(screen==showStadiumForm)||(screen==showTransportStationForm)||(screen==showTouristPoliceForm)||(screen==showShoppingForm)) display.setCurrent(listPlaceForm);
			else if((screen==btsForm)||(screen==ugForm)||(screen==busForm)||(screen==vanForm)) display.setCurrent(vehicleForm);
			else if(screen==showbtsForm) display.setCurrent(btsForm);
			else if(screen==showugForm) display.setCurrent(ugForm);
			else if(screen==showbusForm) display.setCurrent(busForm);
			else if((screen==gpsForm)||(screen==manualForm)||(screen==userPosForm)) display.setCurrent(guideForm);
			else if(screen==manualListPlaceForm) display.setCurrent(manualForm);
			else if(screen==desPlaceForm) display.setCurrent(userPosForm);
			else if(screen==desListPlaceForm) display.setCurrent(desPlaceForm);
			else if(screen==preGuideForm) display.setCurrent(desListPlaceForm);
			else if((screen==userNearDesForm)||(screen==resultGuideForm)) display.setCurrent(preGuideForm);
			else if((screen==filterForm)||(screen==BTSBTSResultForm)||(screen==BTSUGResultForm)||(screen==UGUGResultForm)||(screen==UGBTSResultForm)||(screen==BUSResultForm)||(screen==BUSBUSResultForm)||(screen==VANResultForm)) display.setCurrent(resultGuideForm);
		}
		else if((command==filterCommand)&&(screen==resultGuideForm)) {
			filterChoiceGroup.setSelectedIndex(0, btsEnable);
			filterChoiceGroup.setSelectedIndex(1, ugEnable);
			filterChoiceGroup.setSelectedIndex(2, btsugEnable);
			filterChoiceGroup.setSelectedIndex(3, bus1Enable);
			filterChoiceGroup.setSelectedIndex(4, bus2Enable);
			display.setCurrent(filterForm);
		}
		else if(command==okCommand) {
			if(screen==mainForm) {
				int choose = mainChoiceGroup.getSelectedIndex() + 1;
				switch(choose) {
					case 1:display.setCurrent(placeForm);break;
					case 2:display.setCurrent(vehicleForm);break;
					case 3:display.setCurrent(guideForm);break;
					case 4:display.setCurrent(settingForm);break;
				}
			}
			else if(screen==placeForm) {
				display.setCurrent(waitForm);
				listPlaceChoiceGroup.deleteAll();
				int choose = placeChoiceGroup.getSelectedIndex() + 1;
				listPlaceForm.setTitle(placeChoiceGroup.getString(choose-1));
				SoapObject result = placeservice.listPlace(choose);
				for(int i=0;i<result.getPropertyCount();i++)listPlaceChoiceGroup.append((String)result.getProperty(i), null);
				place = choose;
				display.setCurrent(listPlaceForm);
			}
			else if(screen==listPlaceForm) {
				System.out.println("place = " + place);
				display.setCurrent(waitForm);
				String choose = listPlaceChoiceGroup.getString(listPlaceChoiceGroup.getSelectedIndex());
				if(place==TOURIST_ATTRACTION) {
					SoapObject result = placeservice.showTouristAttraction(choose);
					showTouristAttractionForm.setTitle((String)result.getProperty(0));
					showTouristAttractionSI.setLabel((String)result.getProperty(1));
					showTouristAttractionSI.setText("\nTel. : " + (String)result.getProperty(2) + "\nOpen : " + (String)result.getProperty(3) + "-" + (String)result.getProperty(4) + "\nWeb : " + (String)result.getProperty(5) + "\n\nDescription :\n" + (String)result.getProperty(6));
					display.setCurrent(showTouristAttractionForm);				 
				}
				else if(place==TEMPLE) {
					SoapObject result = placeservice.showTemple(choose);
					showTempleForm.setTitle((String)result.getProperty(0));
					showTempleSI.setLabel((String)result.getProperty(1));
					showTempleSI.setText("\nOpen : " + (String)result.getProperty(2) + "-" + (String)result.getProperty(3) + "\nDescription :\n" + (String)result.getProperty(4) + "\nCharity :\n" + (String)result.getProperty(5));
					display.setCurrent(showTempleForm);
				}
				else if(place==PARK) {
					SoapObject result = placeservice.showPark(choose);
					showParkForm.setTitle((String)result.getProperty(0));
					showParkSI.setLabel((String)result.getProperty(1));
					showParkSI.setText("\nTel. : " + (String)result.getProperty(2) + "\nOpen : " + (String)result.getProperty(3) + "-" + (String)result.getProperty(4) + "\nWeb : " + (String)result.getProperty(5) + "\n\nDescription :\n" + (String)result.getProperty(6) + "\nCharity :\n" + (String)result.getProperty(7));
					display.setCurrent(showParkForm);
				}
				else if(place==STADIUM) {
					SoapObject result = placeservice.showStadium(choose);
					showStadiumForm.setTitle((String)result.getProperty(0));
					showStadiumSI.setLabel((String)result.getProperty(1));
					showStadiumSI.setText("\nTel. : " + (String)result.getProperty(2) + "\nOpen : " + (String)result.getProperty(3) + "-" + (String)result.getProperty(4) + "\nWeb : " + (String)result.getProperty(5) + "\n\nDescription :\n" + (String)result.getProperty(6) + "\nMatch :\n" + (String)result.getProperty(7));
					display.setCurrent(showStadiumForm);
				}
				else if(place==TRANSPORT_STATION) {
					SoapObject result = placeservice.showTransportStation(choose);
					showTransportStationForm.setTitle((String)result.getProperty(0));
					showTransportStationSI.setLabel((String)result.getProperty(1));
					showTransportStationSI.setText("\nTel. : " + (String)result.getProperty(2) + "\nOpen : " + (String)result.getProperty(3) + "-" + (String)result.getProperty(4) + "\nWeb : " + (String)result.getProperty(5) + "\n\nDescription :\n" + (String)result.getProperty(6));
					display.setCurrent(showTransportStationForm);
				}
				else if(place==TOURIST_POLICE) {
					SoapObject result = placeservice.showTouristPolice(choose);
					showTouristPoliceForm.setTitle((String)result.getProperty(0));
					showTouristPoliceSI.setLabel((String)result.getProperty(1));
					showTouristPoliceSI.setText("\nTel. : " + (String)result.getProperty(2) + "\nOpen : " + (String)result.getProperty(3) + "-" + (String)result.getProperty(4) + "\n\nDescription :\n" + (String)result.getProperty(5));
					display.setCurrent(showTouristPoliceForm);
				}
				else if(place==SHOPPING) {
					SoapObject result = placeservice.showShopping(choose);
					showShoppingForm.setTitle((String)result.getProperty(0));
					showShoppingSI.setLabel((String)result.getProperty(1));
					showShoppingSI.setText("\nTel. : " + (String)result.getProperty(2) + "\nOpen : " + (String)result.getProperty(3) + "-" + (String)result.getProperty(4) + "\nWeb : " + (String)result.getProperty(5) + "\n\nDescription :\n" + (String)result.getProperty(6) + "\nPromotion :\n" + (String)result.getProperty(7));
					display.setCurrent(showShoppingForm);
				}
			}
			else if(screen==vehicleForm) {
				int choose = vehicleChoiceGroup.getSelectedIndex() + 1;
				switch(choose) {
					case 1: {
						btsChoiceGroup.deleteAll();
						SoapObject result = vehicleservice.listBTS();
						for(int i=0;i<result.getPropertyCount();i++) btsChoiceGroup.append((String)result.getProperty(i), null);
						display.setCurrent(btsForm);
					}break;
					case 2: {
						ugChoiceGroup.deleteAll();
						SoapObject result = vehicleservice.listUG();
						for(int i=0;i<result.getPropertyCount();i++) ugChoiceGroup.append((String)result.getProperty(i), null);
						display.setCurrent(ugForm);
					}break;
					case 3:display.setCurrent(busForm);break;
					case 4:display.setCurrent(vanForm);break;
				}
			}
			else if(screen==btsForm) {
				String bts_name = btsChoiceGroup.getString(btsChoiceGroup.getSelectedIndex());
				System.out.println(bts_name);
				SoapObject result = vehicleservice.showBTS(bts_name);
				showbtsForm.setTitle("BTS");
				showbtsSI.setLabel("BTS Station " + (String)result.getProperty(0));
				showbtsSI.setText("Station : " + (String)result.getProperty(1) + "\nLine : " + (String)result.getProperty(2) + "\nNear Places :\n" + (String)result.getProperty(3));
				display.setCurrent(showbtsForm);
			}
			else if(screen==ugForm) {
				String ug_name = ugChoiceGroup.getString(ugChoiceGroup.getSelectedIndex());
				System.out.println(ug_name);
				SoapObject result = vehicleservice.showUG(ug_name);
				showugForm.setTitle("MRT");
				showugSI.setLabel("MRT Station " + (String)result.getProperty(0));
				showugSI.setText("Station : " + (String)result.getProperty(1) + "\nNear Places :\n" + (String)result.getProperty(2));
				display.setCurrent(showugForm);
			}
			else if(screen==busForm) {
				String BusType = busChoiceGroup.getString(busChoiceGroup.getSelectedIndex());
				String BusName = busTF.getString();
				SoapObject result = vehicleservice.showBus(BusType, BusName);
				if(result!=null) {
					showbusForm.setTitle(BusType);
					showbusSI.setLabel(BusType + " " + BusName);
					showbusSI.setText("Bus No. : " + (String)result.getProperty(1) + "\nType : " + (String)result.getProperty(2) + "\nZone : " + (String)result.getProperty(3) + "\nTime : " + (String)result.getProperty(4) + "-" + (String)result.getProperty(5) + "\nFrom : " + (String)result.getProperty(6) + "\nTo : " + (String)result.getProperty(7) + "\nInbound :\n" + (String)result.getProperty(8) + "\nOutbound :\n" + (String)result.getProperty(9));
					display.setCurrent(showbusForm);
				}
				
			}
			else if(screen==guideForm) {
				int choose = guideChoiceGroup.getSelectedIndex() + 1;
				if(choose==1) {
					display.setCurrent(gpsForm);
				}
				else if(choose==2) {
					display.setCurrent(manualForm);
				}
			}
			else if(screen==gpsForm) {
				SoapObject result = guideservice.findUserPositionGPS(latTextField.getString(), lonTextField.getString());
				if(result!=null) {
					userPosition = (String)result.getProperty(0);
					userDescription = (String)result.getProperty(1);
					realLatitude = latTextField.getString();
					realLongitude = lonTextField.getString();
					userPosSI1.setText(userDescription + "\n");
					userPosSI2.setText((String)result.getProperty(2) + " meters\n");
					display.setCurrent(userPosForm);
				}
				else  {
					Alert alert = new Alert("Alert", "Can't detect your position", null, AlertType.ERROR);
					alert.addCommand(okCommand);
					display.setCurrent(alert);
				}
			}
			else if(screen==manualForm) {
				display.setCurrent(waitForm);
				manualListPlaceChoiceGroup.deleteAll();
				int choose = manualChoiceGroup.getSelectedIndex() + 1;
				manualListPlaceForm.setTitle(manualChoiceGroup.getString(choose-1));
				SoapObject result = placeservice.listPlace(choose);
				for(int i=0;i<result.getPropertyCount();i++)manualListPlaceChoiceGroup.append((String)result.getProperty(i), null);
				display.setCurrent(manualListPlaceForm);
			}
			else if(screen==manualListPlaceForm) {
				String choose = manualListPlaceChoiceGroup.getString(manualListPlaceChoiceGroup.getSelectedIndex());
				SoapObject result = guideservice.findUserPositionManual(choose);
				realLatitude = (String)result.getProperty(0);
				realLongitude = (String)result.getProperty(1);
				userPosition = (String)result.getProperty(2);
				userDescription = (String)result.getProperty(3);
				userPosSI1.setText(userDescription + "\n");
				userPosSI2.setText("0.0 meters\n");
				display.setCurrent(userPosForm);
			}
			else if(screen==userPosForm) {
				display.setCurrent(desPlaceForm);
			}
			else if(screen==desPlaceForm) {
				display.setCurrent(waitForm);
				desListPlaceChoiceGroup.deleteAll();
				int choose = desPlaceChoiceGroup.getSelectedIndex() + 1;
				desListPlaceForm.setTitle(desPlaceChoiceGroup.getString(choose-1));
				SoapObject result = placeservice.listPlace(choose);
				for(int i=0;i<result.getPropertyCount();i++)desListPlaceChoiceGroup.append((String)result.getProperty(i), null);
				display.setCurrent(desListPlaceForm);
			}
			else if(screen==desListPlaceForm) {
				display.setCurrent(waitForm);
				destinationPlace = desListPlaceChoiceGroup.getString(desListPlaceChoiceGroup.getSelectedIndex());
				preGuideSI.setText("Source : " + userDescription + "\nDestination : " + destinationPlace);
				display.setCurrent(preGuideForm);
			}
			else if(screen==preGuideForm) {
				SoapObject checkUserNearDestination = guideservice.checkUserNearDestination(userPosition, destinationPlace);
				String result1 = (String)checkUserNearDestination.getProperty(0);
				String result2 = (String)checkUserNearDestination.getProperty(1);
				
				if(result1.equals("true")) {
					userNearDesSI.setText("NOW, you are same area with your destination " + destinationPlace + " your destination estimate for " + result2 + " meters from you");
					display.setCurrent(userNearDesForm);
				}
				else if(result1.equals("false")) {
					SoapObject result = guideservice.decideGuide(userPosition, destinationPlace);
					resultGuideChoiceGroup.deleteAll();
					for(int i=0;i<result.getPropertyCount();i++) {
						if((btsEnable)&&(((String)result.getProperty(i)).equals("BTS-BTS"))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((ugEnable)&&(((String)result.getProperty(i)).equals("UG-UG"))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((btsugEnable)&&((((String)result.getProperty(i)).equals("BTS-UG"))||(((String)result.getProperty(i)).equals("UG-BTS")))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((bus1Enable)&&((((String)result.getProperty(i)).substring(0, 3)).equals("BUS"))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((bus2Enable)&&((((String)result.getProperty(i)).substring(0, 10)).equals("change BUS"))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
					}				
					display.setCurrent(resultGuideForm);
				}
			}
			else if(screen==userNearDesForm) {
				display.setCurrent(desPlaceForm);
			}
			
			else if(screen==filterForm) {
				btsEnable = filterChoiceGroup.isSelected(0);
				ugEnable = filterChoiceGroup.isSelected(1);
				btsugEnable = filterChoiceGroup.isSelected(2);
				bus1Enable = filterChoiceGroup.isSelected(3);
				bus2Enable = filterChoiceGroup.isSelected(4);
				
				SoapObject checkUserNearDestination = guideservice.checkUserNearDestination(userPosition, destinationPlace);
				String result1 = (String)checkUserNearDestination.getProperty(0);
				String result2 = (String)checkUserNearDestination.getProperty(1);
				
				if(result1.equals("true")) {
					userNearDesSI.setText("NOW, you are same area with your destination " + destinationPlace + " your destination estimate for " + result2 + " meters from you");
					display.setCurrent(userNearDesForm);
				}
				else if(result1.equals("false")) {
					SoapObject result = guideservice.decideGuide(userPosition, destinationPlace);
					resultGuideChoiceGroup.deleteAll();
					for(int i=0;i<result.getPropertyCount();i++) {
						if((btsEnable)&&(((String)result.getProperty(i)).equals("BTS-BTS"))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((ugEnable)&&(((String)result.getProperty(i)).equals("UG-UG"))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((btsugEnable)&&((((String)result.getProperty(i)).equals("BTS-UG"))||(((String)result.getProperty(i)).equals("UG-BTS")))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((bus1Enable)&&((((String)result.getProperty(i)).substring(0, 4)).equals("BUS "))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
						else if((bus2Enable)&&((((String)result.getProperty(i)).substring(0, 11)).equals("change BUS "))) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
					}				
					display.setCurrent(resultGuideForm);
				}
				display.setCurrent(resultGuideForm);
			}
			
			//ResultGuideForm choose Way to travel
			else if(screen==resultGuideForm) {
				String chooseGuide = resultGuideChoiceGroup.getString(resultGuideChoiceGroup.getSelectedIndex());
				//BTS->BTS
				if(chooseGuide.equals("BTS-BTS")) {
					System.out.println("Call BTS-BTS Service");
					SoapObject result = guideservice.BTSBTSService(userPosition, destinationPlace);
					if(result.getPropertyCount()==4) {
						BTSBTSResultSI.setText("You near BTS " + result.getProperty(0) + " station.\ndistance " + result.getProperty(3) + " meters.\n\nGetOn BTS at : " + result.getProperty(0) + "\nChange BTS line at : " + result.getProperty(1) + "\nGetOff BTS at : " + result.getProperty(2));
						display.setCurrent(BTSBTSResultForm);
					}
					else if(result.getPropertyCount()==3) {
						BTSBTSResultSI.setText("You near BTS " + result.getProperty(0) + " station.\ndistance " + result.getProperty(2) + " meters.\n\nGetOn BTS at : " + result.getProperty(0) + "\nGetOff BTS at : " + result.getProperty(1));
						display.setCurrent(BTSBTSResultForm);
					}
				}
				//BTS->UG
				else if(chooseGuide.equals("BTS-UG")) {
					System.out.println("Call BTS-UG Service");
					SoapObject result = guideservice.BTSUGService(userPosition, destinationPlace);
					BTSUGResultSI.setText("You near BTS " + result.getProperty(0) + " station.\ndistance " + result.getProperty(4) + " meters.\n\nGetOn BTS at : " + result.getProperty(0) + "\nGetOff BTS at : " + result.getProperty(1) + "\nGetOn MRT at : " + result.getProperty(2) + "\nGetOff MRT at : " + result.getProperty(3));
					display.setCurrent(BTSUGResultForm);
				}
				//UG->UG
				else if(chooseGuide.equals("UG-UG")) {
					System.out.println("Call UG-UG Service");
					SoapObject result = guideservice.UGUGService(userPosition, destinationPlace);
					UGUGResultSI.setText("You near MRT " + result.getProperty(0) + " station.\ndistance " + result.getProperty(2) + " meters.\n\nGetOn MRT at : " + result.getProperty(0) + "\nGetOff MRT at : " + result.getProperty(1));
					display.setCurrent(UGUGResultForm);
				}
				//UG->BTS
				else if(chooseGuide.equals("UG-BTS")) {
					System.out.println("Call UG-BTS Service");
					SoapObject result = guideservice.UGBTSService(userPosition, destinationPlace);
					UGBTSResultSI.setText("You near MRT " + result.getProperty(0) + " station.\ndistance " + result.getProperty(4) + " meters.\n\noGetOn MRT at : " + result.getProperty(0) + "\nGetOff MRT at : " + result.getProperty(1) + "\nGetOn BTS at : " + result.getProperty(2) + "\nGetOff BTS at : " + result.getProperty(3));
					display.setCurrent(UGBTSResultForm);
				}
				//BUS
				else if(chooseGuide.substring(0, 4).equals("BUS ")) {
					System.out.println("Call BUS Service" + chooseGuide.charAt(4));
					int i = Integer.parseInt(chooseGuide.substring(4)) - 1;
					SoapObject result = guideservice.BUSService(userPosition, destinationPlace, i);
					SoapObject busResult = (SoapObject)result.getProperty(0);
					String roadPath = guideservice.checkRoadPath(realLatitude, realLongitude, userPosition);
					String busPath = (String)busResult.getProperty(1);
					String busType = (String)busResult.getProperty(2);
					String busTypeResult = "";
					if(busType.equals("A")) busTypeResult = " (Ordinary Only) ";
					else if(busType.equals("B")) busTypeResult = " (Air Bus Only) ";
					else if(busType.equals("C")) busTypeResult = " (Both Ordinary and Air Bus) ";
					else if(busType.equals("D")) busTypeResult = " (Micro Bus) ";
					else if(busType.equals("E")) busTypeResult = " (Ordinary Express Way (Yellow Sign) Only) ";
					else if(busType.equals("F")) busTypeResult = " (Air Bus Express Way (Yellow Sign) Only) ";
					else if(busType.equals("G")) busTypeResult = " (Both Ordinary and Air Bus Express Way (Yellow Sign)) ";
					if(!roadPath.equals(busPath)) BUSResultSI.setText("You should cross the Road then\nGet BUS : " + (String)busResult.getProperty(0) + busTypeResult);
					else BUSResultSI.setText("Get BUS : " + (String)busResult.getProperty(0) + busTypeResult);
					display.setCurrent(BUSResultForm);
				}
				//BUS-BUS
				else if(chooseGuide.substring(0, 11).equals("change BUS ")) {
					System.out.println("Call BUS-BUS Service" + chooseGuide.charAt(11));
					int i = Integer.parseInt(chooseGuide.substring(11)) - 1;
					SoapObject result = guideservice.BUSBUSService(userPosition, destinationPlace, i);
					String bus1 = (String)result.getProperty(0);
					String path1 = (String)result.getProperty(1);
					String type1 = (String)result.getProperty(2);
					String bus2 = (String)result.getProperty(3);
					String path2 = (String)result.getProperty(4);
					String type2 = (String)result.getProperty(5);
					String connection = (String)result.getProperty(6);
					String roadPath = (String)guideservice.checkRoadPath(realLatitude, realLongitude, userPosition);
					
					String busTypeResult1 = "";
					if(type1.equals("A")) busTypeResult1 = " (Ordinary Only) ";
					else if(type1.equals("B")) busTypeResult1 = " (Air Bus Only) ";
					else if(type1.equals("C")) busTypeResult1 = " (Both Ordinary and Air Bus) ";
					else if(type1.equals("D")) busTypeResult1 = " (Micro Bus) ";
					else if(type1.equals("E")) busTypeResult1 = " (Ordinary Express Way (Yellow Sign) Only) ";
					else if(type1.equals("F")) busTypeResult1 = " (Air Bus Express Way (Yellow Sign) Only) ";
					else if(type1.equals("G")) busTypeResult1 = " (Both Ordinary and Air Bus Express Way (Yellow Sign)) ";
					String busTypeResult2 = "";
					if(type2.equals("A")) busTypeResult1 = " (Ordinary Only) ";
					else if(type2.equals("B")) busTypeResult2 = " (Air Bus Only) ";
					else if(type2.equals("C")) busTypeResult2 = " (Both Ordinary and Air Bus) ";
					else if(type2.equals("D")) busTypeResult2 = " (Micro Bus) ";
					else if(type2.equals("E")) busTypeResult2 = " (Ordinary Express Way (Yellow Sign) Only) ";
					else if(type2.equals("F")) busTypeResult2 = " (Air Bus Express Way (Yellow Sign) Only) ";
					else if(type2.equals("G")) busTypeResult2 = " (Both Ordinary and Air Bus Express Way (Yellow Sign)) ";
					if(!roadPath.equals(path1)) {
						if(!path1.equals(path2)) {
							BUSBUSResultSI.setText("You should cross the Road then\nGet BUS : " + bus1 + busTypeResult1 + "\nGet off BUS at : " + connection + "\nand cross the Road again\nGet BUS : " + bus2 + busTypeResult2);
						}
						else {
							BUSBUSResultSI.setText("You should cross the Road then\nGet BUS : " + bus1 + busTypeResult1 + "\nGet off BUS at : " + connection + "\nand Get BUS : " + bus2 + busTypeResult2);
						}
					}
					else {
						if(!path1.equals(path2)) {
							BUSBUSResultSI.setText("Get BUS : " + bus1 + busTypeResult1 + "\nGet off BUS at : " + connection + "\nand cross the Road\nGet BUS : " + bus2 + busTypeResult2);
						}
						else {
							BUSBUSResultSI.setText("Get BUS : " + bus1 + busTypeResult1 + "\nGet off BUS at : " + connection + "\nand Get BUS : " + bus2 + busTypeResult2);
						}
					}
					display.setCurrent(BUSBUSResultForm);
				}
				
				//VAN
				else if(chooseGuide.substring(0, 3).equals("VAN")) {
					System.out.println("Call VAN Service" + chooseGuide.charAt(3));
					int i = Integer.parseInt(chooseGuide.substring(3)) - 1;
					SoapObject result = guideservice.VANService(userPosition, destinationPlace, i);
					SoapObject vanResult = (SoapObject)result.getProperty(0);
					String roadPath = guideservice.checkRoadPath(realLatitude, realLongitude, userPosition);
					String vanPath = (String)vanResult.getProperty(1);
					if(!roadPath.equals(vanPath)) VANResultSI.setText("You should cross the Road then\nGet VAN : " + (String)vanResult.getProperty(0));
					else VANResultSI.setText("Get VAN : " + (String)vanResult.getProperty(0)); 
					display.setCurrent(VANResultForm);
				}
			}
			//Track BTS-BTS Form
			else if(screen==BTSBTSResultForm) {
				System.out.println("counterAlert = " + counterAlert);
				SoapObject result = guideservice.BTSBTSService(userPosition, destinationPlace);
				//Case InterChange at Siam BTS Station
				if(result.getPropertyCount()==3) {
					switch(counterAlert) {
						//Alert at InterChange Station
						case 0:
							setAlert = "Change BTS line at " + result.getProperty(1) + " station";
							timer.schedule(btsbtstimer1, 10000, 10000);
							//display.setCurrent(mainForm);
							counterAlert++;
						break;						
						//Alert at Destination Station
						case 1:
							setAlert = "Get Off BTS at " + result.getProperty(2) + " station Arrival " + destinationPlace;
							timer.schedule(btsbtstimer2, 10000, 10000);
							counterAlert++;
							//display.setCurrent(mainForm);
						break;
						//Finish Alert -> Return to MainForm
						case 2:
							counterAlert = 0;
							//timer.cancel();
							display.setCurrent(mainForm);
						break;
					}
				}
				//Case not InterChange
				else if(result.getPropertyCount()==2) {
					switch(counterAlert) {
						//Alert at Destination Station
						case 0:
							setAlert = "Get Off BTS at " + result.getProperty(1) + " station Arrival " + destinationPlace;
							timer.schedule(btsbtstimer1, 10000, 10000);
							counterAlert++;
						break;
						//Finish Alert -> Return to MainForm
						case 1:
							counterAlert = 0;
							display.setCurrent(mainForm);
						break;
					}
				}
			}
			//Track BTS->UG Form
			else if(screen==BTSUGResultForm) {
				System.out.println("counterAlert = " + counterAlert);
				SoapObject result = guideservice.BTSUGService(userPosition, destinationPlace);
				switch(counterAlert) {
					//Alert at InterChange Station from BTS to UG
					case 0:
						setAlert = "Get Off BTS at " + result.getProperty(1) + " station Get On MRT at " + result.getProperty(2) + " station";
						timer.schedule(btsugtimer1, 10000, 10000);
						counterAlert++;
					break;
					//Alert at Destination Station
					case 1:
						setAlert = "Get Off MRT at " + result.getProperty(3) + " station Arrival " + destinationPlace;
						timer.schedule(btsugtimer2, 10000, 10000);
						counterAlert++;
					break;
					//Finish Alert -> Return to MainForm
					case 2:
						counterAlert = 0;
						display.setCurrent(mainForm);
					break;
				}
			}
			//Track UG->UG Form
			else if(screen==UGUGResultForm) {
				System.out.println("counterAlert = " + counterAlert);
				SoapObject result = guideservice.UGUGService(userPosition, destinationPlace);
				switch(counterAlert) {
					//Alert at Destination Station
					case 0:
						setAlert = "Get Off MRT at " + result.getProperty(1) + " station Arrival " + destinationPlace;
						timer.schedule(ugugtimer1, 10000);
						counterAlert++;
					break;
					//Finish Alert -> Return to MainForm
					case 1:
						counterAlert = 0;
						display.setCurrent(mainForm);
					break;
				}
			}
			//Track UG->BTS Form
			else if(screen==UGBTSResultForm) {
				System.out.println("counterAlert = " + counterAlert);
				SoapObject result = guideservice.UGBTSService(userPosition, destinationPlace);
				switch(counterAlert) {
					//Alert at InterChange Station from MRT to BTS
					case 0:
						setAlert = "Get On MRT at " + result.getProperty(1) + " station Get On BTS at " + result.getProperty(2) + " station";
						timer.schedule(ugbtstimer1, 10000, 10000);
						counterAlert++;
					break;
					//Alert at Destination Station
					case 1:
						setAlert = "Get Off MRT at " + result.getProperty(3) + " station Arrival " + destinationPlace;
						timer.schedule(ugbtstimer2, 10000, 10000);
						counterAlert++;
					break;
					//Finish Alert -> Return to MainForm
					case 2:
						counterAlert = 0;
						display.setCurrent(mainForm);
					break;
				}
			}
			
			//Debug Form
			else if(screen==debugForm) {
				userLatitude = debugTF1.getString();
				userLongitude = debugTF2.getString();
				userPosition = debugTF3.getString();
				destinationPlace = debugTF4.getString();
				SoapObject result = guideservice.decideGuide(userPosition, destinationPlace);
				resultGuideChoiceGroup.deleteAll();
				for(int i=0;i<result.getPropertyCount();i++) resultGuideChoiceGroup.append((String)result.getProperty(i), null);
				display.setCurrent(resultGuideForm);
			}
			
			//Setting Form
			else if(screen==settingForm) {
				String remoteSite = settingTF1.getString();
				placeservice.setRemote(remoteSite);
				vehicleservice.setRemote(remoteSite);
				guideservice.setRemote(remoteSite);
				btsEnable = settingChoiceGroup.isSelected(0);
				ugEnable = settingChoiceGroup.isSelected(1);
				btsugEnable = settingChoiceGroup.isSelected(2);
				bus1Enable = settingChoiceGroup.isSelected(3);
				bus2Enable = settingChoiceGroup.isSelected(4);
				display.setCurrent(mainForm);
			}
		}
	}
	
//--------------------------------------------------- Timer Task Abstract Class ---------------------------------------------------//
	//BTSBTS Timer Task
	private class btsbtsTimer1 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.BTSBTSService(userPosition, destinationPlace);
			if(guideservice.checkTrackBTSStation((String)result.getProperty(1), "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(BTSBTSResultForm);
      			cancel();
			}
			
		}
	}
	private class btsbtsTimer2 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.BTSBTSService(userPosition, destinationPlace);
			if(guideservice.checkTrackBTSStation((String)result.getProperty(2), "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(BTSBTSResultForm);
      			cancel();
      		}
      	}
	}
	//BTSUG Timer Task
	private class btsugTimer1 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.BTSUGService(userPosition, destinationPlace);
			BTSUGResultForm.setTitle("Tracking");
			BTSUGResultSI.setText("Tracking to " + (String)result.getProperty(1));
      		display.setCurrent(BTSUGResultForm);
			if(guideservice.checkTrackBTSStation((String)result.getProperty(1), "13.8021", "100.5534")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			BTSUGResultForm.setTitle("Tracking");
      			BTSUGResultSI.setText("Tracking to " + (String)result.getProperty(3));
      			display.setCurrent(BTSUGResultForm);
      			cancel();
			}
     	}
	}
	private class btsugTimer2 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.BTSUGService(userPosition, destinationPlace);
			if(guideservice.checkTrackUGStation((String)result.getProperty(3), "13.7375", "100.5173")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			BTSUGResultForm.setTitle("Tracking");
      			BTSUGResultSI.setText("Finish Tracking.\nArrival " + destinationPlace);
      			display.setCurrent(BTSUGResultForm);
      			cancel();
      		}
      	}
	}
	//UG->UG Timer Task
	private class ugugTimer1 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.UGUGService(userPosition, destinationPlace);
			if(guideservice.checkTrackUGStation((String)result.getProperty(1), "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(UGUGResultForm);
      			cancel();
      		}
      	}
	}
	//UG->BTS Timer Task
	private class ugbtsTimer1 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.UGBTSService(userPosition, destinationPlace);
			if(guideservice.checkTrackUGStation((String)result.getProperty(1), "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(UGBTSResultForm);
      			cancel();
      		}
      	}
	}
	private class ugbtsTimer2 extends TimerTask {
		public final void run() {
			SoapObject result = guideservice.UGBTSService(userPosition, destinationPlace);
			if(guideservice.checkTrackBTSStation((String)result.getProperty(1), "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(UGBTSResultForm);
      			cancel();
      		}
      	}
	}
	//BTS Timer Task
	private class busTimer1 extends TimerTask {
		public final void run() {
			if(guideservice.checkTrackBUSandVAN(destinationPlace, "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(BUSResultForm);
      			cancel();
      		}
      	}
	}
	//VAN Timer Task
	private class vanTimer1 extends TimerTask {
		public final void run() {
			if(guideservice.checkTrackBUSandVAN(destinationPlace, "13.7450", "100.5334")) {
				Alert alert = new Alert(setAlert);
				alert.setString(setAlert);
      			alert.setTimeout(Alert.FOREVER);
      			alert.setType(AlertType.ALARM);
      			AlertType.ERROR.playSound(display);
      			display.setCurrent(alert);
      			display.setCurrent(VANResultForm);
      			cancel();
      		}
      	}
	}
}