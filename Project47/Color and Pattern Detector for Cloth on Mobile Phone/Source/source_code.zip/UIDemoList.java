
package com.borland.jbuilder.samples.micro.uidemo;
import javax.microedition.lcdui.*;

/**
 * Main demo list.
 */
public class UIDemoList extends List {

  // names of each demo
  private static final String[] demoNames = {//"

                                           "View image  Show Color and pattern detected  ",

                                };
  private static final Class[] demoClasses = {

    getClass("com.borland.jbuilder.samples.micro.uidemo.ImageItemDemo"),

  };

  // static instance handle for use in each demo
  static Displayable instance = null;

  // the current demo being displayed
  private Displayable currentDemo;

  /**
   * Construct the displayable
   */
  public UIDemoList() {
    super("List of Color and Pattern Detected", // displayable title
          List.IMPLICIT,      // list type (implicit, exclusive, multiple)
          demoNames,          // array of demo names...each will be a separate item in the list
          null);              // array of images - none for now.

    // set up an event listener
    setCommandListener(new CommandListener()  {
      public void commandAction(Command c, Displayable d) {
        this_commandPerformed(c, d);
      }
    });
    // initialize the UI
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    instance = this;
  }

  /**
   * Retrieves the class for the given class name.
   */
  private static Class getClass(String className) {
    Class requestedClass = null;
    try {
      requestedClass = Class.forName(className);
    }
    catch (ClassNotFoundException e) {
    }
    return requestedClass;
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception  {
    // add the Quit command
    addCommand(new Command("Exit", Command.EXIT, 1));
  }

  /**
   * Handle command events
   */
  public void this_commandPerformed(Command c, Displayable d) {
    if (c.getCommandType() == Command.EXIT) {
      currentDemo = null;
      // stop the midlet
      UIDemoMidlet.quitApp();
    }
    else {
      // instantiate and show the requested demo
      int selectedIndex = getSelectedIndex();
      try {
        currentDemo = (Displayable)demoClasses[selectedIndex].newInstance();
        Display.getDisplay(UIDemoMidlet.instance).setCurrent(currentDemo);
      }
      catch (Exception e) {
        // alert the user to a failure in loading the requested demo
        Alert a = new Alert("Error");
        a.setString("Failed to load demo: " + getString(selectedIndex));
        a.setTimeout(2000);
        Display.getDisplay(UIDemoMidlet.instance).setCurrent(a);
      }
    }
  }

}