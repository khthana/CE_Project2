
package com.borland.jbuilder.samples.micro.uidemo;
import java.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;

public class ImageItemDemo extends Form {

  /**
   image path
   */
  public static String IMAGE_SOURCE

      = "/com/borland/jbuilder/samples/micro/uidemo/a.jpg";



  ImageItem imageItem1 = new ImageItem("Original Image",
                                       null,
                                       ImageItem.LAYOUT_CENTER,
                                       "Unable to display image");
  ImageItem imageItem2 = new ImageItem("Resized Image",
                                       null,
                                       ImageItem.LAYOUT_CENTER,
                                       "Unable to display image");

  Ticker ticker1;
  public void this_commandPerformed(Command c, Displayable d) {
    if (c.getCommandType() == Command.BACK) {
      // stop the demo and return to the main  list
      Display.getDisplay(UIDemoMidlet.instance).setCurrent(UIDemoList.instance);
    }
  }



      //F fixed point constants
  private static int FP_SHIFT = 13;
 // private static final int FP_ONE = 1 << FP_SHIFT;
 // private static final int FP_HALF = 1 << (FP_SHIFT - 1);

  // resampling modes - valid values for the mode parameter of resizeImage()
  // any other value will default to MODE_BOX_FILTER because of the way the conditionals are set in resizeImage()
  public static final int MODE_POINT_SAMPLE = 0;
  public static final int MODE_BOX_FILTER = 1;
   /**
   * getPixels
   * Wrapper for pixel grabbing techniques.
    */

    int[] getPixels(Image src) {
    int w = src.getWidth();
    int h = src.getHeight();
    int[] pixels = new int[w * h];
    src.getRGB(pixels, 0, w, 0, 0, w, h);
    return pixels;
  }

  /**
   * drawPixels
   * Wrapper for pixel drawing function.
   * return The image created from the pixel array.
   */
  Image drawPixels(int[] pixels, int w, int h) {
    return Image.createRGBImage(pixels, w, h, true);
  }

  /**
   * resizeImage
   * Gets a source image along with new size for it and resizes it.
   * src is The source image.
   * destW The new width for the destination image.
   * destH The new heigth for the destination image.

   */
  Image resizeImage(Image src, int destW, int destH, int mode) {
    int srcW = src.getWidth();
    int srcH = src.getHeight();

    // create pixel arrays
    int[] destPixels = new int[destW * destH]; // array to hold destination pixels
    int[] srcPixels = getPixels(src); // array with source's pixels

    if (mode == MODE_POINT_SAMPLE) {
      // simple point sampled resizing
      // loop through the destination pixels, find the matching pixel on the source and use that
      for (int destY = 0; destY < destH; ++destY) {
        for (int destX = 0; destX < destW; ++destX) {
          int srcX = (destX * srcW) / destW;
          int srcY = (destY * srcH) / destH;
          destPixels[destX + destY * destW] = srcPixels[srcX + srcY * srcW];
        }
      }
    }
    else {
      // precalculate src/dest ratios
      int ratioW = (srcW << FP_SHIFT) / destW;
      int ratioH = (srcH << FP_SHIFT) / destH;

      int[] tmpPixels = new int[destW * srcH]; // temporary buffer for the horizontal resampling step

      // variables to perform additive blending
      int argb; // color extracted from source
      int a, r, g, b; // separate channels of the color
      int count; // number of pixels sampled for calculating the average

      // the resampling will be separated into 2 steps for simplicity
      // the first step will keep the same height and just stretch the picture horizontally
      // the second step will take the intermediate result and stretch it vertically

      // horizontal resampling
      for (int y = 0; y < srcH; ++y) {
        for (int destX = 0; destX < destW; ++destX) {
          count = 0;
          a = 0;
          r = 0;
          b = 0;
          g = 0; // initialize color blending vars
          int srcX = (destX * ratioW) >> FP_SHIFT; // calculate beginning of sample
          int srcX2 = ( (destX + 1) * ratioW) >> FP_SHIFT; // calculate end of sample

          // now loop from srcX to srcX2 and add up the values for each channel
          do {
            argb = srcPixels[srcX + y * srcW];
            a += ( (argb & 0xff000000) >> 24); // alpha channel
            r += ( (argb & 0x00ff0000) >> 16); // red channel
            g += ( (argb & 0x0000ff00) >> 8); // green channel
            b += (argb & 0x000000ff); // blue channel
            ++count; // count the pixel
            ++srcX; // move on to the next pixel
          }
          while (srcX <= srcX2 && srcX + y * srcW < srcPixels.length);

          // average out the channel values
          a /= count;
          r /= count;
          g /= count;
          b /= count;

          // recreate color from the averaged channels and place it into the temporary buffer
          tmpPixels[destX + y * destW] = ( (a << 24) | (r << 16) | (g << 8) | b);
        }
      }

      // vertical resampling of the temporary buffer (which has been horizontally resampled)
        for (int x = 0; x < destW; ++x) {
        for (int destY = 0; destY < destH; ++destY) {
          count = 0;
          a = 0;
          r = 0;
          b = 0;
          g = 0; // initialize color blending vars
          int srcY = (destY * ratioH) >> FP_SHIFT; // calculate beginning of sample
          int srcY2 = ( (destY + 1) * ratioH) >> FP_SHIFT; // calculate end of sample

          // now loop from srcY to srcY2 and add up the values for each channel
          do {
            argb = tmpPixels[x + srcY * destW];
            a += ( (argb & 0xff000000) >> 24); // alpha channel
            r += ( (argb & 0x00ff0000) >> 16); // red channel
            g += ( (argb & 0x0000ff00) >> 8); // green channel
            b += (argb & 0x000000ff); // blue channel
            ++count; // count the pixel
            ++srcY; // move on to the next pixel
          }
          while (srcY <= srcY2 && x + srcY * destW < tmpPixels.length);

          // average out the channel values
          a /= count;
          a = (a > 255) ? 255 : a;
          r /= count;
          r = (r > 255) ? 255 : r;
          g /= count;
          g = (g > 255) ? 255 : g;
          b /= count;
          b = (b > 255) ? 255 : b;

          // recreate color from the averaged channels and place it into the destination buffer
          destPixels[x +
              destY * destW] = ( (a << 24) | (r << 16) | (g << 8) | b);
        }
      }
    }
    //

    // return a new image created from the destination pixel buffer
    return drawPixels(destPixels, destW, destH);
  }
///////////////////////////////////////////////
int checkpattern(int []calcolor,int[] specolor){
    valuepoint = new int[500];
    check = new int[900];
    int found = 0;
int numcolor[];
numcolor = new int[13];

    int ano = 0;

    int j = 1;

///////////////  one tone /////////
       int onetone = 0;
    for (int k = 1; k <= 12; k++) {
      if (specolor[k] >= 800)
        onetone = 1;
    }

    if (onetone == 1) {
      String labelText = "\n  one tone";
      this.append(labelText);
      found = 1;
      for (int k = 1; k <= 12; k++) {
        if (specolor[k] < 700)
          specolor[k] = 0;
      }
return 1;
    }
////////////////// vertical stripe //////////////////
    if (found == 0) {
      int postung = 0;
      ano = 0;
      while (ano < 30) {
        for (int k = 0; k < 13; k++)
          numcolor[k] = 0;
        for (int k = ano; k < 900; k = k + 30) {
          numcolor[calcolor[k]]++;
        }
        for (int k = 0; k < 13; k++) {
          if (numcolor[k] > 20)
            postung++;
        }
        ano++;
      }
      if (postung > 20) {
        String labelText3 = "\n vertical stripe";
        this.append(labelText3);
        found = 2;
           return 2;
      }

    }

///////////////////////////--horizontal stripe--/////////////////////////////

    if (found == 0) {
      int posnon = 0;
      ano = 0;
      while (ano < 870) {
        for (int k = 0; k < 13; k++)
          numcolor[k] = 0;
        for (int k = ano; k < (ano + 30); k++) {
          numcolor[calcolor[k]]++;
        }
        for (int k = 0; k < 13; k++) {
          if (numcolor[k] > 20)
            posnon++;
        }
        ano = ano + 30;
      }
      if (posnon > 20) {
        String labelText3 = "\n horizontal stripe";
        this.append(labelText3);
        found = 3;
           return 3;
      }

    }
///////////////////////////////////////////////////////////////////////////
        int point = 0;
    if (found == 0) {
      re(0, calcolor);
      i = i + 2;

      for (j =1; j < 900; j++) {
        if (check[j] == 0) {
          re(j, calcolor);
          i = i + 2;
        }
      }
      valuepoint[i] = -1;
    j = 1;
      while(valuepoint[j] != -1) { if (valuepoint[j+1]  <= 3) {valuepoint[j+1] =0;  valuepoint[j]=0;} j = j+2;}   // reduce noise
     int max =0;
          int k=0;
      j = 1;
   while(valuepoint[j] != -1) { if(valuepoint[j+1] > max) {max = valuepoint[j+1];   k = valuepoint[j];}j =j+2;} // find max of  ground
j = 1;
   int tone=0;
      while(valuepoint [j] != -1){if(valuepoint[j] != 0){tone++;} j = j+2;}
      if (tone ==2){
        String labelText5 = "\n one spot";
        this.append(labelText5);
      return  4;  }
      if((tone> 2)&&(tone<=10)){
        String labelText5 = "\n many spot";
        this.append(labelText5);
        return 5;}
    }
    return 6;
  }


 private static int   valuepoint[] ;

  private static int check[];
  private  static int   i =  1;




 public void re(int point,int [] calcolor){

 valuepoint [i] = calcolor[point];
      check[point] = 1;
valuepoint [i+1]++;
      int y =   point/30;
      int x= point%30;
    if((x >0)&&(y>0)){ if((calcolor[point] == calcolor[point-31])&&(check[point-31] == 0))
    re(point-31,calcolor);}
     if(y>0){ if((calcolor[point] == calcolor[point-30])&&(check[point-30] == 0))
      re(point-30,calcolor);}
    if((x <29)&&(y>0)){ if((calcolor[point] == calcolor[point-29])&&(check[point-29] == 0))
        re(point-29,calcolor);}
    if(x >0){ if((calcolor[point] == calcolor[point-1])&&(check[point-1] == 0))
    re(point-1,calcolor);}
if(x<29){ if((calcolor[point] == calcolor[point+1])&&(check[point+1] == 0))
    re(point+1,calcolor);}
if((x >0)&&(y<29)){ if((calcolor[point] == calcolor[point+29])&&(check[point+29] == 0))
    re(point+29,calcolor);}
if(y<29){ if((calcolor[point] == calcolor[point+30])&&(check[point+30] == 0))
    re(point+30,calcolor);}
if((x <29)&&(y<29)){ if((calcolor[point] == calcolor[point+31])&&(check[point+31] == 0))
    re(point+31,calcolor);}


 }
/////////////////////////////////////////////////

  int[] color_detect(Image src) {
    int[] calcolor = getPixels(src);
    int w = src.getWidth();
    int h = src.getHeight();
    int r, g, b;
    int sum = w * h;
    int specolor[];
    specolor = new int[14];
    for (int i = 0; i < sum; i++) {
      calcolor[i] = calcolor[i] + 16777216;
      b = calcolor[i] % 256;
      calcolor[i] = calcolor[i] / 256;
      g = calcolor[i] % 256;
      r = calcolor[i] / 256;

      if (r >= 0 && r < 43) {
        if (g >= 0 && g < 43) {
          if (b >= 0 && b < 43) {
            specolor[1]++;
            calcolor[i] =1;
          }
          if (b >= 43 && b < 86) {
            specolor[1]++;
            calcolor[i] =1;
          }
          if (b >= 86 && b < 129) {
            specolor[2]++;
           calcolor[i] =2;
        }
          if (b >= 129&& b < 172) {
            specolor[2]++;
           calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2]++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2]++;
        calcolor[i] =2;
          }
        }

        if (g >= 43 && g < 86) {
          if (b >= 0 && b < 43) {
            specolor[1]  ++;
           calcolor[i] =2;
        }
          if (b >= 43 && b < 86) {
            specolor[1]  ++;
           calcolor[i] =2;
          }
          if (b >= 86 && b < 129) {
            specolor[2]  ++;
            calcolor[i] =2;
          }
          if (b >= 129 && b < 172) {
            specolor[2]  ++;
            calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
            calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2] ++;
            calcolor[i] =2;
          }
        }

        if (g >= 86 && g < 129) {
          if (b >= 0 && b < 51) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 129 && b < 172) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
             specolor[2] ++;
           calcolor[i] =2;
           }

        }
        if (g >= 129 && g < 172) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[2] ++;
         calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2] ++;
          calcolor[i] =2;
          }


        }
        if (g >= 172 && g <= 215) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 129 && b < 149) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 149 && b < 172) {
           specolor[2] ++;
         calcolor[i] =2;
         }

          if (b >= 172 && b <215) {
            specolor[2] ++;
         calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
             specolor[2] ++;
          calcolor[i] =2;
           }

        }
        if (g >= 215 && g <= 255) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 172 && b < 192) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 192 && b < 215) {
           specolor[2] ++;
         calcolor[i] =2;
         }

          if (b >= 215 && b <= 255) {
             specolor[2] ++;
           calcolor[i] =2;
           }
        }
     }
     ///////////////////////////////////////////1111
      if (r >= 43 && r < 86) {
        if (g >= 0 && g < 43) {
          if (b >= 0 && b < 43) {
            specolor[1]++;
          calcolor[i] =1;
          }
          if (b >= 43 && b < 86) {
            specolor[1]++;
         calcolor[i] =1;
          }
          if (b >= 86 && b < 129) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 129&& b < 172) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2]  ++;
         calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2]  ++;
        calcolor[i] =2;
          }
        }

        if (g >= 43 && g < 86) {
          if (b >= 0 && b < 43) {
            specolor[1]  ++;
         calcolor[i] =1;
          }
          if (b >= 43 && b < 86) {
            specolor[1]  ++;
         calcolor[i] =1;
          }
          if (b >= 86 && b < 129) {
            specolor[2]  ++;
          calcolor[i] =2;
          }
          if (b >= 129 && b < 172) {
            specolor[2]  ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2] ++;
        calcolor[i] =2;
          }
        }

        if (g >= 86 && g < 129) {
          if (b >= 0 && b < 51) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[2] ++;
         calcolor[i] =2;
          }
          if (b >= 129 && b < 172) {
            specolor[2] ++;
         calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
             specolor[2] ++;
           calcolor[i] =2;
           }

        }
        if (g >= 129 && g < 172) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[2] ++;
         calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2] ++;
          calcolor[i] =2;
          }
        }
        if (g >= 172 && g < 215) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
         calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
             specolor[2] ++;
          calcolor[i] =2;
           }
         }
         if (g >= 215 && g <= 255) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 172 && b < 192) {
            specolor[4] ++;
         calcolor[i] =4;
          }
          if (b >= 192 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }

          if (b >= 215 && b <= 255) {
             specolor[2] ++;
           calcolor[i] =2;
           }

        }

}
/////////////////////////////2
       if (r >= 86 && r < 129) {
        if (g >= 0 && g < 43) {
          if (b >= 0 && b < 43) {
            specolor[8]++;
         calcolor[i] =8;
          }
          if (b >= 43 && b < 86) {
            specolor[8]++;
          calcolor[i] =8;
          }
          if (b >= 86 && b < 129) {
            specolor[3] ++;
          calcolor[i] =3;
          }
          if (b >= 129&& b < 172) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2]  ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2]  ++;
        calcolor[i] =2;
          }
        }

        if (g >= 43 && g < 86) {
          if (b >= 0 && b < 43) {
            specolor[11]  ++;
          calcolor[i] =11;
          }
          if (b >= 43 && b < 86) {
            specolor[11]  ++;
          calcolor[i] =11;
          }
          if (b >= 86 && b < 129) {
            specolor[2]  ++;
          calcolor[i] =2;
          }
          if (b >= 129 && b < 172) {
            specolor[2]  ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2] ++;
        calcolor[i] =2;
          }
        }

        if (g >= 86 && g < 129) {
          if (b >= 0 && b < 51) {
            specolor[10] ++;
          calcolor[i] =10;
          }
          if (b >= 43 && b < 63) {
            specolor[10] ++;
          calcolor[i] =10;
          }
          if (b >=63&& b < 86) {
            specolor[1] ++;
          calcolor[i] =1;
          }

          if (b >= 86 && b < 129) {
            specolor[1] ++;
          calcolor[i] =1;
          }
          if (b >= 129 && b < 172) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
             specolor[2] ++;
           calcolor[i] =2;
           }

        }
        if (g >= 129 && g < 172) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
            specolor[2] ++;
          calcolor[i] =2;
          }
        }
        if (g >= 172 && g <215) {
          if (b >= 0 && b < 43) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 43 && b < 86) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 86 && b < 129) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 129 && b < 172) {
            specolor[4] ++;
          calcolor[i] =4;
          }
          if (b >= 172 && b < 215) {
            specolor[2] ++;
          calcolor[i] =2;
          }
          if (b >= 215 && b <= 255) {
             specolor[2] ++;
           calcolor[i] =2;
           }

        }
        if (g >= 215 && g <= 255) {
                  if (b >= 0 && b < 43) {
                    specolor[4] ++;
                  calcolor[i] =4;
                  }
                  if (b >= 43 && b < 86) {
                    specolor[4] ++;
                  calcolor[i] =4;
                  }
                  if (b >= 86 && b < 129) {
                    specolor[4] ++;
                  calcolor[i] =4;
                  }
                  if (b >= 129 && b < 172) {
                    specolor[4] ++;
                  calcolor[i] =4;
                  }
                  if (b >= 172 && b < 215) {
                    specolor[4] ++;
                  calcolor[i] =4;
                  }
                  if (b >= 215 && b <= 255) {
                     specolor[2] ++;
                   calcolor[i] =2;
                   }

                }

      }
///////////////////////////3
      if (r >= 129 && r < 172) {
             if (g >= 0 && g < 43) {
               if (b >= 0 && b < 43) {
                 specolor[8]++;
               calcolor[i] =8;
               }
               if (b >= 43 && b < 86) {
                 specolor[8]++;
               calcolor[i] =8;
               }
               if (b >= 86 && b < 129) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 129&& b < 172) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 172 && b <215) {
                 specolor[2]  ++;
               calcolor[i] =2;
               }
               if (b >= 215 && b <= 255) {
                 specolor[2]  ++;
             calcolor[i] =2;
               }
             }

             if (g >= 43 && g < 86) {
               if (b >= 0 && b < 43) {
                 specolor[11]  ++;
               calcolor[i] =11;
               }
               if (b >= 43 && b < 86) {
                 specolor[11]  ++;
               calcolor[i] =11;
               }
               if (b >= 86 && b < 129) {
                 specolor[8]  ++;
               calcolor[i] =8;
               }
               if (b >= 129 && b < 172) {
                 specolor[2]  ++;
               calcolor[i] =2;
               }
               if (b >= 172 && b < 215) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 215 && b <= 255) {
                 specolor[2] ++;
             calcolor[i] =2;
               }
             }

             if (g >= 86 && g < 129) {
               if (b >= 0 && b < 51) {
                 specolor[11] ++;
               calcolor[i] =11;
               }
               if (b >= 43 && b < 86) {
                 specolor[11] ++;
               calcolor[i] =11;
               }
               if (b >= 86 && b < 129) {
                 specolor[11] ++;
               calcolor[i] =11;
               }
              if (b >= 129 && b < 172) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 172 && b < 215) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 215 && b <= 255) {
                  specolor[2] ++;
                calcolor[i] =2;
                }

             }
             if (g >= 129 && g < 172) {
               if (b >= 0 && b < 43) {
                 specolor[10] ++;
               calcolor[i] =10;
               }
               if (b >= 43 && b < 86) {
                 specolor[10] ++;
               calcolor[i] =10;
               }
               if (b >= 86 && b < 106) {
                 specolor[10] ++;
               calcolor[i] =10;
               }
                 if (b >= 106 && b < 129) {
                   specolor[12] ++;
                 calcolor[i] =12;
                 }
                 if (b >= 129 && b < 172) {
                 specolor[12] ++;
               calcolor[i] =12;
               }
               if (b >= 172 && b < 192) {
                 specolor[12] ++;
               calcolor[i] =12;
               }
               if (b >= 192 && b < 215) {
                specolor[2] ++;
              calcolor[i] =2;
              }

               if (b >= 215 && b <= 255) {
                 specolor[2] ++;
               calcolor[i] =2;
               }


             }
             if (g >= 172 && g < 215) {
               if (b >= 0 && b < 43) {
                 specolor[10] ++;
               calcolor[i] =10;
               }
               if (b >= 43 && b < 86) {
                 specolor[4] ++;
               calcolor[i] =4;
               }
               if (b >= 86 && b < 129) {
                 specolor[4] ++;
               calcolor[i] =4;
               }
               if (b >= 129 && b < 172) {
                 specolor[12] ++;
               calcolor[i] =12;
               }
               if (b >= 172 && b < 215) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 215 && b <= 255) {
                  specolor[2] ++;
                calcolor[i] =2;
                }
              }
              if (g >= 215 && g <= 255) {
               if (b >= 0 && b < 43) {
                 specolor[4] ++;
               calcolor[i] =4;
               }
               if (b >= 43 && b < 86) {
                 specolor[4] ++;
               calcolor[i] =4;
               }
               if (b >= 86 && b < 129) {
                 specolor[4] ++;
               calcolor[i] =4;
               }
               if (b >= 129 && b < 172) {
                 specolor[4] ++;
               calcolor[i] =4;
               }
               if (b >= 172 && b < 215) {
                 specolor[2] ++;
               calcolor[i] =2;
               }
               if (b >= 215 && b <= 255) {
                  specolor[2] ++;
                calcolor[i] =2;
                }

             }

     }
/////////////////4
     if (r >= 172 && r < 215) {
            if (g >= 0 && g < 43) {
              if (b >= 0 && b < 43) {
                specolor[8]++;
              calcolor[i] =8;
              }
              if (b >= 43 && b < 86) {
                specolor[8]++;
              calcolor[i] =8;
              }
              if (b >= 86 && b < 129) {
                specolor[8] ++;
              calcolor[i] =8;
              }
              if (b >= 129&& b < 172) {
                specolor[8] ++;
              calcolor[i] =8;
              }
              if (b >= 172 && b < 215) {
                specolor[8]  ++;
              calcolor[i] =8;
              }
              if (b >= 215 && b <= 255) {
                specolor[2]  ++;
            calcolor[i] =2;
              }
            }

            if (g >= 43 && g < 86) {
              if (b >= 0 && b < 43) {
                specolor[11]  ++;
              calcolor[i] =11;
              }
              if (b >= 43 && b < 86) {
                specolor[11]  ++;
              calcolor[i] =11;
              }
              if (b >= 86 && b < 129) {
                specolor[8]  ++;
              calcolor[i] =8;
              }
              if (b >= 129 && b < 172) {
                specolor[8]  ++;
              calcolor[i] =8;
              }
              if (b >= 172 && b < 215) {
                specolor[2] ++;
              calcolor[i] =2;
              }
              if (b >= 215 && b <= 255) {
                specolor[2] ++;
            calcolor[i] =2;
              }
            }

            if (g >= 86 && g < 129) {
              if (b >= 0 && b < 51) {
                specolor[11] ++;
              calcolor[i] =11;
              }
              if (b >= 43 && b < 86) {
                specolor[11] ++;
              calcolor[i] =6;
              }
              if (b >= 86 && b < 129) {
                specolor[8] ++;
              calcolor[i] =8;
              }
              if (b >= 129 && b < 149) {
                specolor[8] ++;
              calcolor[i] =8;
              }
              if (b >= 149 && b < 172) {
              specolor[2] ++;
            calcolor[i] =2;
            }
            if (b >= 172 && b < 215) {
                specolor[2] ++;
              calcolor[i] =2;
              }
              if (b >= 215 && b <= 255) {
                 specolor[2] ++;
               calcolor[i] =2;
               }

            }
            if (g >= 129 && g < 172) {
              if (b >= 0 && b < 43) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 43 && b < 86) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 86 && b < 129) {
                specolor[11] ++;
              calcolor[i] =11;
              }
              if (b >= 129 && b < 172) {
                specolor[8] ++;
              calcolor[i] =8;
              }
              if (b >= 172 && b < 215) {
                specolor[2] ++;
              calcolor[i] =2;
              }
              if (b >= 215 && b <= 255) {
                specolor[2] ++;
              calcolor[i] =2;
              }


            }
            if (g >= 172 && g <215) {
              if (b >= 0 && b < 43) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 43 && b < 86) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 86 && b < 129) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 129 && b < 172) {
                specolor[12] ++;
              calcolor[i] =12;
              }
              if (b >= 172 && b < 215) {
                specolor[12] ++;
              calcolor[i] =12;
              }
              if (b >= 215 && b <= 255) {
                 specolor[12] ++;
               calcolor[i] =12;
               }
             }
             if (g >= 215 && g <= 255) {
              if (b >= 0 && b < 43) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 43 && b < 86) {
                specolor[10] ++;
              calcolor[i] =10;
              }
              if (b >= 86 && b < 129) {
                specolor[4] ++;
              calcolor[i] =4;
              }
              if (b >= 129 && b < 172) {
                specolor[4] ++;
              calcolor[i] =4;
              }
              if (b >= 172 && b < 215) {
                specolor[12] ++;
              calcolor[i] =12;
              }
              if (b >= 215 && b <= 255) {
                 specolor[12] ++;
               calcolor[i] =12;
               }

            }

    }
/////////////5
    if (r >= 215 && r <= 255) {
       if (g >= 0 && g < 43) {
         if (b >= 0 && b < 43) {
           specolor[8]++;
         calcolor[i] =8;
         }
         if (b >= 43 && b < 86) {
           specolor[8]++;
         calcolor[i] =8;
         }
         if (b >= 86 && b < 129) {
           specolor[8] ++;
         calcolor[i] =8;
         }
         if (b >= 129&& b < 172) {
           specolor[8] ++;
         calcolor[i] =8;
         }

         if (b >= 172 && b < 215) {
           specolor[8]  ++;
         calcolor[i] =8;
         }
         if (b >= 215 && b <= 255) {
           specolor[8]  ++;
       calcolor[i] =8;
         }
       }

       if (g >= 43 && g < 86) {
         if (b >= 0 && b < 43) {
           specolor[8]  ++;
         calcolor[i] =8;
         }
         if (b >= 43 && b < 86) {
           specolor[8]  ++;
         calcolor[i] =8;
         }
         if (b >= 86 && b < 129) {
           specolor[8]  ++;
         calcolor[i] =8;
         }
         if (b >= 129 && b < 172) {
           specolor[8]  ++;
         calcolor[i] =8;
         }
         if (b >= 172 && b < 215) {
           specolor[8] ++;
         calcolor[i] =8;
         }
         if (b >= 215 && b <= 255) {
           specolor[2] ++;
       calcolor[i] =2;
         }
       }

       if (g >= 86 && g < 129) {
         if (b >= 0 && b < 51) {
           specolor[11] ++;
         calcolor[i] =11;
         }
         if (b >= 43 && b < 86) {
           specolor[11] ++;
         calcolor[i] =11;
         }
         if (b >= 86 && b < 129) {
           specolor[11] ++;
         calcolor[i] =11;
         }
         if (b >= 129 && b < 172) {
           specolor[8] ++;
         calcolor[i] =8;
         }
         if (b >= 172 && b < 215) {
           specolor[8] ++;
         calcolor[i] =8;
         }
         if (b >= 215 && b <= 255) {
            specolor[2] ++;
          calcolor[i] =2;
          }

       }
       if (g >= 129 && g < 172) {
         if (b >= 0 && b < 43) {
           specolor[11] ++;
         calcolor[i] =11 ;
         }
         if (b >= 43 && b < 86) {
           specolor[11] ++;
         calcolor[i] =11;
         }
         if (b >= 86 && b < 129) {
           specolor[11] ++;
         calcolor[i] =11;
         }
         if (b >= 129 && b < 172) {
           specolor[8] ++;
         calcolor[i] =8;
         }
         if (b >= 172 && b < 215) {
           specolor[8] ++;
         calcolor[i] =8;
         }
         if (b >= 215 && b <= 255) {
           specolor[2] ++;
         calcolor[i] =2;
         }


       }
       if (g >= 172 && g < 215) {
         if (b >= 0 && b < 43) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 43 && b < 86) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 86 && b < 129) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 129 && b < 172) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 172 && b < 215) {
           specolor[12] ++;
         calcolor[i] =12;
         }
         if (b >= 215 && b <= 255) {
            specolor[12] ++;
          calcolor[i] =12;
          }
        }
        if (g >= 215 && g <= 255) {
         if (b >= 0 && b < 43) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 43 && b < 86) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 86 && b < 129) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 129 && b < 172) {
           specolor[10] ++;
         calcolor[i] =10;
         }
         if (b >= 172 && b < 215) {
           specolor[12] ++;
         calcolor[i] =12;
         }
         if (b >= 215 && b <= 255) {
            specolor[12] ++;
          calcolor[i] =12;
          }

       }

}
///////6
    }
int line = checkpattern(calcolor,specolor);
    specolor[13] = line;
    return specolor;

  }




  public ImageItemDemo() {
    super("View picture");

    setCommandListener(new CommandListener() {
      public void commandAction(Command c, Displayable d) {
        this_commandPerformed(c, d);
      }
    });

    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {


    ticker1 = new Ticker("");
    addCommand(new Command("Back", Command.BACK, 1));


    Image image = Image.createImage(IMAGE_SOURCE);
    imageItem1.setImage(image);
    Image image2 = resizeImage(image, 30, 30, 1);
    imageItem2.setImage(image2);
    this.append(imageItem1);
    this.append(imageItem2);
    int[] showcolor = color_detect(image2);




     {
       String labelText = "  \n";
      this.append (labelText);}

  ///////////line///////
    {
         InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/titleline.wav");
            Player p = Manager.createPlayer(in, "audio/x-wav");
            p.start();
            for(int i=0;i<2000000;i++){};
     }
     if (showcolor[13] ==1) {
              InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/onetone.wav");
                 Player p = Manager.createPlayer(in, "audio/x-wav");
                 p.start();
                 for(int i=0;i<2000000;i++){};
          }

          if (showcolor[13] ==2) {
                   InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/tung.wav");
                      Player p = Manager.createPlayer(in, "audio/x-wav");
                      p.start();
                      for(int i=0;i<2000000;i++){};
               }
               if (showcolor[13] ==3) {
                 InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/non.wav");
                   Player p = Manager.createPlayer(in, "audio/x-wav");
                   p.start();
                    for(int i=0;i<2000000;i++){};
                    }
            if (showcolor[13] ==4) {
               InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/onepoint.wav");
                  Player p = Manager.createPlayer(in, "audio/x-wav");
                 p.start();
                 for(int i=0;i<2000000;i++){};
                 }
             if (showcolor[13] ==5) {
                      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/manypoint.wav");
                    Player p = Manager.createPlayer(in, "audio/x-wav");
                 p.start();
                  for(int i=0;i<2000000;i++){};
    }
    if (showcolor[13] ==6) {
                      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/no.wav");
                    Player p = Manager.createPlayer(in, "audio/x-wav");
                 p.start();
                  for(int i=0;i<2000000;i++){};
    }


//////////////color//////////
   {
     String labelText = "  \n";
    this.append (labelText);
    InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/title.wav");
     Player p = Manager.createPlayer(in, "audio/x-wav");
     for(int i=0;i<2000000;i++){};
     p.start();

 //    p.start();
  }

    if (showcolor[1] >50) {
      String labelText = " Black Detected \n";
      this.append(labelText);
      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/black.wav");
         Player p = Manager.createPlayer(in, "audio/x-wav");
         for(int i=0;i<2000000;i++){};
         p.start();


    }
    if (showcolor[2] > 50) {
      String labelText = "Blue Detected\n";
      this.append(labelText);
      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/blue.wav");
         Player p = Manager.createPlayer(in, "audio/x-wav");
         for(int i=0;i<2000000;i++){};
         p.start();

    }

    if (showcolor[4] > 50) {
      String labelText = "Green Detected\n";
      this.append(labelText);
      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/green.wav");
                 Player p = Manager.createPlayer(in, "audio/x-wav");
                 for(int i=0;i<2000000;i++){};
         p.start();

}


    if (showcolor[8] >50) {
      String labelText = "Red Detected\n";
      this.append(labelText);
      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/red.wav");
      Player p = Manager.createPlayer(in, "audio/x-wav");
      for(int i=0;i<2000000;i++){};
         p.start();

    }

    if (showcolor[10] >50) {
      String labelText = "Yellow Detected\n";
      this.append(labelText);
      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/yellow.wav");
                 Player p = Manager.createPlayer(in, "audio/x-wav");
                 for(int i=0;i<2000000;i++){};
         p.start();

}
    if (showcolor[11] >50) {
     String labelText = "Orange Detected\n";
      this.append(labelText);
     InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/orange.wav");
                  Player p = Manager.createPlayer(in, "audio/x-wav");
                  for(int i=0;i<2000000;i++){};
         p.start();

 }
    if (showcolor[12] >50) {
      String labelText = "White Detected\n";
      this.append(labelText);
      InputStream in = getClass().getResourceAsStream("/com/borland/jbuilder/samples/micro/uidemo/white.wav");
                 Player p = Manager.createPlayer(in, "audio/x-wav");
                 for(int i=0;i<2000000;i++){};
         p.start();

}


   }

}






