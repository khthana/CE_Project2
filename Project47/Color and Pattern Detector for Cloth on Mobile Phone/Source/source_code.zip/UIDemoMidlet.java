
package com.borland.jbuilder.samples.micro.uidemo;

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;

/**
 * Main MIDlet class for handling the display of each demo.
 */
public class UIDemoMidlet extends MIDlet {

  static UIDemoMidlet instance;
  UIDemoList demoList = new UIDemoList();

  /**
   * Construct the MIDlet
   */
  public UIDemoMidlet() {
    this.instance = this;
  }

  /**
   * Main method
   */
  public void startApp() {
    // show the list of available demos
    Display.getDisplay(this).setCurrent(demoList);
  }

  /**
   * Handle pausing the MIDlet
   */
  public void pauseApp() {
  }

  /**
   * Handle destroying the MIDlet
   */
  public void destroyApp(boolean unconditional) {
    demoList = null;
  }

  /**
   * Quit the MIDlet
   */
  public static void quitApp() {
    instance.destroyApp(true);
    instance.notifyDestroyed();
    instance = null;
  }
}