/*
//============================================================================
//
//    FILE NAME : IRLS.c
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iRLS.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 29 January 2005
//    Creation Time: 12:25 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "irls.h"

/*
// ===========================================================================
// RLS_PARAMS
//
// This constant structure defines the default parameters for RLS objects
*/
IRLS_Params IRLS_PARAMS = {
    sizeof(IRLS_Params),
    NULL,//	float *tap_weight; 
	NULL, //float *state;
	NULL, //float *pi;
	NULL, //float *p0;
	NULL, //float *k;

	NULL,//float *tempP1;
	NULL, //float *tempP2;
	NULL, //float *tempMatrix;
	NULL, //float *temp1;
	0.999,//float lamda;
   	1.0101,//float invert;
	0,//float step;	
	0,//float x;
	0,//float d;
	0,//float y;
	0,//float e;   
	32,//XDAS_Int32 filter_length;
};
