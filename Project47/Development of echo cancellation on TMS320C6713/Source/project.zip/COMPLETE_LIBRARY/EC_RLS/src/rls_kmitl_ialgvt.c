/*
//============================================================================
//
//    FILE NAME : RLS_KMITL_ialgvt.c
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the RLS_KMITL module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 29 January 2005
//    Creation Time: 12:25 PM
//
//============================================================================
*/

#include <std.h>
#include "irls.h"

#include "rls_kmitl.h"

extern Int  RLS_KMITL_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  RLS_KMITL_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  RLS_KMITL_free(IALG_Handle, IALG_MemRec *);
extern Int  RLS_KMITL_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  RLS_KMITL_numAlloc(Void);
/*
// The RLS_KMITL_moved routine is only used if the RLS_KMITL_alloc routine
// returns more than one valid IALG_MemRec structure.
extern Void RLS_KMITL_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
*/
/*
// The RLS_KMITL_activate & RLS_KMITL_deactivate routines are
// only used if scratch memory is being used.
extern Void RLS_KMITL_activate(IALG_Handle);
extern Void RLS_KMITL_deactivate(IALG_Handle);
*/
extern XDAS_Void RLS_KMITL_apply(IRLS_Handle handle);
extern float RLS_KMITL_getError(IRLS_Handle handle);
extern float RLS_KMITL_getOutput(IRLS_Handle handle);
extern XDAS_Void RLS_KMITL_setInput(IRLS_Handle handle, float x);
extern XDAS_Void RLS_KMITL_setDesire(IRLS_Handle handle, float d);

#define IALGFXNS \
    &RLS_KMITL_IALG,       /* module ID                            */ \
    NULL,                  /* activate   (NULL => not suported)    */ \
    RLS_KMITL_alloc,       /* algAlloc                             */ \
    RLS_KMITL_control,     /* control    (NULL => not suported)    */ \
    NULL,                  /* deactivate (NULL => not suported)    */ \
    RLS_KMITL_free,        /* free                                 */ \
    RLS_KMITL_initObj,     /* init                                 */ \
    NULL,                  /* moved      (NULL => not suported)    */ \
    NULL                   /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// RLS_KMITL_IRLS
//
// This structure defines KMITL's implementation of the IRLS interface
// for the RLS_KMITL module.
*/
IRLS_Fxns RLS_KMITL_IRLS = {	/* module_vendor_interface */
    IALGFXNS,
    RLS_KMITL_apply,
    RLS_KMITL_getError,
    RLS_KMITL_getOutput,
    RLS_KMITL_setInput,
    RLS_KMITL_setDesire,
};

/*
//============================================================================
// RLS_KMITL_IALG
//
// This structure defines KMITL's implementation of the IALG interface
// for the RLS_KMITL module.
*/
#ifdef _TI_
asm("_RLS_KMITL_IALG .set _RLS_KMITL_IRLS");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns RLS_KMITL_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
