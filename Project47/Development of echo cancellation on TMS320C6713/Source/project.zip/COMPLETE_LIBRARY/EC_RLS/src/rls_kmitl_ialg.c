/*
//============================================================================
//
//    FILE NAME : RLS_KMITL_ialg.c
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the RLS_KMITL.h interface; KMITL's
//                implementation of the IRLS interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 29 January 2005
//    Creation Time: 12:25 PM
//
//============================================================================
*/

#pragma CODE_SECTION(RLS_KMITL_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(RLS_KMITL_free,       ".text:algFree")
#pragma CODE_SECTION(RLS_KMITL_initObj,    ".text:algInit")
#pragma CODE_SECTION(RLS_KMITL_control,    ".text:algControl")
#pragma CODE_SECTION(RLS_KMITL_init,       ".text:init")
#pragma CODE_SECTION(RLS_KMITL_exit,       ".text:exit")
/*
// The RLS_KMITL_moved routine is only used if the RLS_KMITL_alloc routine
// returns more than one valid IALG_MemRec structure.
#pragma CODE_SECTION(RLS_KMITL_moved,      ".text:algMoved")
*/
/*
// The RLS_KMITL_activate & RLS_KMITL_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(RLS_KMITL_activate,   ".text:algActivate")
#pragma CODE_SECTION(RLS_KMITL_deactivate, ".text:algDeactivate")
*/

#include <std.h>
#include <limits.h>
#include "iRLS.h"
#include "rls_kmitl.h"
//#include "rlscfg.h"

#define HLOCALBUFFER0 1
#define HLOCALBUFFER1 2
#define MTAB_NRECS 3
#define FILTER_LENGTH 32 
#define LAMDA 0.999
#define INVERT 1.0101

extern int tmprls;

Void RLS_adapt(IRLS_Handle handle);
Void UpdatePi(IRLS_Handle handle);

/*
//============================================================================
// RLS_KMITL_Obj
*/
typedef struct RLS_KMITL_Obj {
    IALG_Obj        alg;   /* MUST be first field of all RLS objs */

    /* TODO: add custom fields here */
    float *tap_weight; 
	float *state;
	float *pi;
	float *p0;
	float *k;
	//float *U;
	float *tempP1;
	float *tempP2;
	float *tempMatrix;
	float *temp1;
	float lamda;
   	float invert;
	float step;	
	float x;
	float d;
	float y;
	float e;   
	XDAS_Int32 filter_length;
	XDAS_Int32      *hLocalBuffer0;
    XDAS_Int32      *hLocalBuffer1;
    //RLS_Obj			*rls;
} RLS_KMITL_Obj;

/*
//============================================================================
// RLS_KMITL_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the RLS_KMITL processing methods.
*/
/*
// The RLS_KMITL_activate & RLS_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void RLS_KMITL_activate(IALG_Handle handle)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;
    
    // TODO: implement algActivate
}
*/

/*
//============================================================================
// RLS_KMITL_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a RLS_KMITL_Obj structure.
*/
Int RLS_KMITL_alloc(const IALG_Params *RLSParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IRLS_Params *params = (Void *)RLSParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IRLS_PARAMS;  /* set default parameters */
    }

    /* Request memory for RLS object */
    memTab[0].size = sizeof(RLS_KMITL_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;
    
    memTab[HLOCALBUFFER0].size = (params->filter_length) * sizeof(float);
    memTab[HLOCALBUFFER0].alignment = (0 * 8) / CHAR_BIT;
    memTab[HLOCALBUFFER0].space = IALG_EXTERNAL;
    memTab[HLOCALBUFFER0].attrs = IALG_PERSIST;

	memTab[HLOCALBUFFER1].size = (params->filter_length) * sizeof(float);
    memTab[HLOCALBUFFER1].alignment = (0 * 8) / CHAR_BIT;
    memTab[HLOCALBUFFER1].space = IALG_EXTERNAL;
    memTab[HLOCALBUFFER1].attrs = IALG_PERSIST;


    return (MTAB_NRECS);
}

/*
//============================================================================
// RLS_KMITL_control
//
// Control our object's parameters while the algorithm is running
*/
Int RLS_KMITL_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    IRLS_Status *sPtr = (IRLS_Status *)status;	
    RLS_KMITL_Obj *RLS = (Void *)handle;

    switch ((IRLS_Cmd)cmd) {

       case IRLS_GETSTATUS:
			sPtr->tap_weight = RLS->tap_weight;
			sPtr->state = RLS->state;
			sPtr->pi = RLS->pi;
			sPtr->p0 = RLS->p0;
			sPtr->k = RLS->k;
			//sPtr->U = RLS->U;
			sPtr->temp1 = RLS->temp1;
			sPtr->tempMatrix = RLS->tempMatrix;
			sPtr->tempP1 = RLS->tempP1;
			sPtr->tempP2 = RLS->tempP2;
			sPtr->step = RLS->step;
			sPtr->x = RLS->x;
			sPtr->d = RLS->d;
			sPtr->e = RLS->e;
			sPtr->y = RLS->y;
			sPtr->lamda = RLS->lamda;
			sPtr->invert = RLS->invert;
			sPtr->filter_length = RLS->filter_length;
			
            return(IALG_EOK);

       case IRLS_SETSTATUS:
			sPtr->tap_weight = RLS->tap_weight;
			sPtr->state = RLS->state;
			sPtr->pi = RLS->pi;
			sPtr->p0 = RLS->p0;
			sPtr->k = RLS->k;
			//sPtr->U = RLS->U;
			sPtr->temp1 = RLS->temp1;
			sPtr->tempMatrix = RLS->tempMatrix;
			sPtr->tempP1 = RLS->tempP1;
			sPtr->tempP2 = RLS->tempP2;
			sPtr->step = RLS->step;
			sPtr->x = RLS->x;
			sPtr->d = RLS->d;
			sPtr->e = RLS->e;
			sPtr->y = RLS->y;
			sPtr->lamda = RLS->lamda;
			sPtr->invert = RLS->invert;
			sPtr->filter_length = RLS->filter_length;
            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// RLS_KMITL_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the RLS_KMITL processing methods to persistent memory.
*/
/*
// The RLS_KMITL_activate & RLS_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void RLS_KMITL_deactivate(IALG_Handle handle)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;
    
    // TODO: implement algDeactivate
}
*/

/*
//============================================================================
// RLS_KMITL_exit
//
// Exit the RLS_KMITL module as a whole.
 */
Void RLS_KMITL_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// RLS_KMITL_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// RLS_KMITL_alloc operation above.
*/
Int RLS_KMITL_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    RLS_KMITL_Obj *RLS = (Void *)handle;

    n = RLS_KMITL_alloc(NULL, NULL, memTab);

    memTab[HLOCALBUFFER0].base = RLS->hLocalBuffer0; //handle;
	memTab[HLOCALBUFFER1].base = RLS->hLocalBuffer1;   //handle;
    return (n);
}

/*
//============================================================================
// RLS_KMITL_init
//
// Initialize the RLS_KMITL module as a whole.
*/
Void RLS_KMITL_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// RLS_KMITL_initObj
//
// Initialize the memory allocated for our instance.
*/
Int RLS_KMITL_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *RLSParams)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;
    const IRLS_Params *params = (Void *)RLSParams;
    
    int i,j;
	int index = 0;
	
	
	
	
	if(params == NULL){
        params = &IRLS_PARAMS; /* set default parameters */
    }
    
	RLS->tap_weight = params->tap_weight;
	RLS->p0 = params->p0;
	RLS->pi = params->pi;
	RLS->k  = params->k;
	RLS->temp1 = params->temp1;
	RLS->tempMatrix = params->tempMatrix;
	RLS->tempP1 = params->tempP1;
	RLS->tempP2 = params->tempP2;
	RLS->state = params->state;
	RLS->x = params->x;
	RLS->d = params->d;
	RLS->e = params->e;
	RLS->y = params->y;
	RLS->filter_length = params->filter_length;
	RLS->lamda = params->lamda;
	RLS->invert = params->invert;
	RLS->hLocalBuffer0 = memTab[HLOCALBUFFER0].base;
    RLS->hLocalBuffer1 = memTab[HLOCALBUFFER1].base;

	
    


    /* TODO: Implement any additional algInit desired */
   
   	for(i=0;i<FILTER_LENGTH;i++)
   	{
   		RLS->state[i] = 0;
   		RLS->tap_weight[i] = 0;
   	}
   	for(i=0;i<(FILTER_LENGTH*FILTER_LENGTH);i++)
   	{
   		RLS->p0[i] = 0;
   		RLS->tempMatrix[i] = 0;
   		RLS->tempP1[i] = 0;
   		RLS->tempP2[i] = 0;
   	}
   			
   	RLS->p0[0] = 1000;
	
	for(i=1;i<FILTER_LENGTH;i++)
	{
		for(j=0;j<FILTER_LENGTH;j++)
		{index++;}
				
		RLS->p0[i+index] = 1000;
	}
	
   
   	
    return (IALG_EOK);
}

/*
//============================================================================
// RLS_KMITL_moved
//
// Adjust any data pointers that has been moved by the client.
*/
/*
// The RLS_KMITL_moved routine is only used if the RLS_KMITL_alloc routine
// returns more than one valid IALG_MemRec structure.
Void RLS_KMITL_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *RLSParams)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;
    const IRLS_Params *params = (Void *)RLSParams;

}
*/

/*
//============================================================================
// RLS_KMITL_apply
// KMITL's implementation of the apply operation.
// Custom fields of the RLS_KMITL_Obj may be accessed as follows:
*/
XDAS_Void RLS_KMITL_apply(IRLS_Handle handle)
{
    //RLS_KMITL_Obj *RLS = (Void *)handle;

    /* TODO: implement apply */
	RLS_adapt(handle);
    /*
    int index;
    for(index=0; index<RLS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

XDAS_Void RLS_KMITL_setInputDesire(IRLS_Handle handle, float x, float d)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;

    /* TODO: implement setInputDesire */
	RLS->x = x;
	RLS->d = d;
   
}

float RLS_KMITL_getError(IRLS_Handle handle)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;

    /* TODO: implement getError */
    
    return((float)RLS->e);
}

float RLS_KMITL_getOutput(IRLS_Handle handle)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;

    /* TODO: implement getOutput */
    return((float)RLS->y);
}

XDAS_Void RLS_KMITL_setInput(IRLS_Handle handle, float x)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;

    /* TODO: implement setInput */
    RLS->x = x;
}

XDAS_Void RLS_KMITL_setDesire(IRLS_Handle handle, float d)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;

    /* TODO: implement setDesire */
    RLS->d = d;
}

Void RLS_adapt(IRLS_Handle handle)
{
//	RLS_KMITL_Obj *RLS = (Void *)handle;
	UpdatePi(handle);
	//UpdateP0(handle);
	
}

Void UpdatePi(IRLS_Handle handle)
{
	RLS_KMITL_Obj *RLS = (Void *)handle;
	//float *p0 = (Float *)MEM_alloc(rls,(FILTER_LENGTH*FILTER_LENGTH)*sizeof(float *),0);

	int i,j;
	int index;
	int l,index2,index3;
   	float mulVec;
   	float sum;
	float sumMatrix1;

	//const float lamda=0.999;
   //	const float invert = 1.0101;
    
    float *U = (float*)malloc(sizeof(float)*RLS->filter_length) ;
    
    sum = 0.0;
    index2 = 0;
    index3 = 0;
	index = 0;
	sumMatrix1 = 0;
	for(i=0;i<FILTER_LENGTH;i++)
		U[i] = 0;
   	
	//fill in input value to temp U
	for(i = 0; i<FILTER_LENGTH; i++)
	{
		if(i == 0)
			U[i] = RLS->x;
		else
			U[i] = RLS->state[i-1];	
	}
	//---------------------------------------
	// ----------------- Update PI value -----
	for(i=0;i<FILTER_LENGTH;i++)
	{
	  for(j=0;j<FILTER_LENGTH;j++)
	  {
	  	sumMatrix1 += RLS->p0[i+index]*U[j];
	     //sumMatrix1 += RLS->p0[i][j]*U[j];//p0[i][j]*tempX[j];
	  index++;
	  }
	  index--;
	  RLS->pi[i] = sumMatrix1;
	  //rlsS->pi[i] = sumMatrix1;   //pi[i] = sumMatrix1;
	  sumMatrix1 = 0.0;
	}
	
   	mulVec 	= 0.0;
   	sum 	= 0.0;
	
	 //for u hermitian * pi(n)
      for(i=0;i<FILTER_LENGTH;i++)
	  mulVec = mulVec + U[i] * RLS->pi[i];
	  //mulVec = mulVec + U[i]*rlsS->pi[i];   //pi[i];
	  sum =  RLS->lamda + mulVec;
	  //sum = lamda + mulVec;  //for lamda + uH*pi
	 //printf("%f\n",sum1);
      for(i=0;i<FILTER_LENGTH;i++) //for k(n) = pi(n)/(lamda + uH*pi(n)
		RLS->k[i] = (RLS->pi[i]) / sum;
		//rlsS->k[i] = rlsS->pi[i]/sum;	//k[i] = pi[i]/sum1;
		
		sum = 0;
		
 for(i=0;i<FILTER_LENGTH;i++)  //for find w(n-1)*u(n)
   {
   sum += (RLS->tap_weight[i]) * (U[i]);
      //y += rlsS->tap_weight[i]*U[i];   //w0[i]*U[i];
   }
   RLS->e = (RLS->d) - sum;
   RLS->y = sum;
   sum = 0;
   //e = d - y; // Prediction error
  
   //------ update weight vector ---------
   for(i=0;i<FILTER_LENGTH;i++)
     RLS->tap_weight[i] = RLS->tap_weight[i] + (RLS->k[i] * RLS->e);
     //rlsS->tap_weight[i] = rlsS->tap_weight[i] + (rlsS->k[i]*e); 
 
   
     // update p0 value-----------
	
	sum = 0.0;
    
	for(i=0;i<FILTER_LENGTH;i++) // for find invertlamda * P(n-1);
    {
      for(j=0;j<FILTER_LENGTH;j++)
      {     
	   //RLS->tempP1[i][j] = (RLS->p0[i][j]) * (RLS->invert);
	   RLS->tempP1[i+index2] = (RLS->p0[i+index2]) * (RLS->invert);
	  //RLS->p0[i+index]*invert;  //p0[i][j]*invert;
      index2++;
      }
      index2--;
    }
    
   // index2 = 0;
    for(i=0;i<FILTER_LENGTH;i++)
	{
	RLS->temp1[i]= RLS->invert*(RLS->k[i]);
		//temp1[i] = invert*(rlsS->k[i]);
	}
	
	 for(i=0;i<FILTER_LENGTH;i++)
	{
		for(j=0;j<FILTER_LENGTH;j++)
		{
		RLS->tempMatrix[i+index2] = (RLS->temp1[i]) * (U[j]);
			//RLS->tempMatrix[i][j] = RLS->temp1[i]*U[j];
       //sum = sum + temp1[i]*U[i];
		index2++;
		}
		index2--;
	}
	
	index2 = 0;
	
	for(i=0;i<FILTER_LENGTH;i++)
    {
		for(l=0;l<FILTER_LENGTH;l++)
		{
			for(j=0;j<FILTER_LENGTH;j++)
			{
	//			sum += (RLS->tempMatrix[i][j])* (RLS->p0[j][1]);
				sum += (RLS->tempMatrix[index2+j])* (RLS->p0[index3+1]);
				//rlsS->p0[index2+l];  //p0[j][l];
				index3 += FILTER_LENGTH;
			}
			index3 = 0;
			
			//RLS->tempP2[i][l] = sum;
			RLS->tempP2[index2+l] = sum;
				sum = 0;
		}
		index2 += FILTER_LENGTH;
	}
	
	index2 = 0;
	
	for(i=0;i<FILTER_LENGTH;i++)
     {
      for(j=0;j<FILTER_LENGTH;j++)
      {
		RLS->p0[i+index2] = RLS->tempP1[i+index2] - RLS->tempP2[i+index2];      
//RLS->rls->p0[i+index] = tempP1[i+index] - tempP2[i+index];
	  // RLS->p0[i][j] = RLS->tempP1[i][j] - RLS->tempP2[i][j]; //p0[i][j] = tempP1[i][j] - tempP2[i][j]; //update p0
	  index2++;
	  }
	  index2--;
	}
	
		//============== Shif filter state========
	for(i = 0; i<FILTER_LENGTH; i++)
	{
		RLS->state[i] = U[i];
		//rlsS->state[i] = U[i]; 
	}	  
}

Void RLS_KMITL_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *RLSParams)
{
    RLS_KMITL_Obj *RLS = (Void *)handle;
//    const INLMS_Params *params = (Void *)NLMSParams;

    RLS->hLocalBuffer0 = memTab[HLOCALBUFFER0].base;
    RLS->hLocalBuffer1 = memTab[HLOCALBUFFER1].base;
}
