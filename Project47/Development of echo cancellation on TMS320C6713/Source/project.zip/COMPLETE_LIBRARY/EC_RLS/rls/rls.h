/*
//============================================================================
//
//    FILE NAME : RLS.h
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                RLS module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 25 December 2004
//    Creation Time: 12:33 PM
//
//============================================================================
*/

#ifndef RLS_
#define RLS_

#include <alg.h>
#include <xdas.h>
#include "iRLS.h"

/*
// ===========================================================================
// RLS_Handle
//
// This pointer is used to reference all RLS instance objects
*/
typedef struct IRLS_Obj *RLS_Handle;

/*
// ===========================================================================
// RLS_Params
//
// This structure defines the creation parameters for all RLS objects
*/
typedef IRLS_Params RLS_Params;

/*
// ===========================================================================
// RLS_PARAMS
//
// This structure defines the default creation parameters for RLS objects
*/
#define RLS_PARAMS   IRLS_PARAMS

/*
// ===========================================================================
// RLS_Status
//
// This structure defines the real-time parameters for RLS objects
*/
typedef struct IRLS_Status   RLS_Status;

/*
// ===========================================================================
// RLS_Cmd
//
// This typedef defines the control commands RLS objects
*/
typedef IRLS_Cmd   RLS_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define RLS_GETSTATUS    IRLS_GETSTATUS
#define RLS_SETSTATUS    IRLS_SETSTATUS

/*
// ===========================================================================
// RLS_create
//
// Create an RLS instance object (using parameters specified by prms)
*/
extern RLS_Handle RLS_create(const IRLS_Fxns *fxns, const RLS_Params *prms);

/*
// ===========================================================================
// RLS_control
//
// Get, set, and change the parameters of the RLS function (using parameters specified by status).
*/
extern Int RLS_control(RLS_Handle handle, RLS_Cmd cmd, RLS_Status *status);

/*
// ===========================================================================
// RLS_delete
// Delete the RLS instance object specified by handle
*/
extern Void RLS_delete(RLS_Handle handle);

/*
// ===========================================================================
// RLS_apply
*/
extern XDAS_Void RLS_apply(RLS_Handle handle);

/*
// ===========================================================================
// RLS_getError
*/
extern float RLS_getError(RLS_Handle handle);

/*
// ===========================================================================
// RLS_getOutput
*/
extern float RLS_getOutput(RLS_Handle handle);

/*
// ===========================================================================
// RLS_setInput
*/
extern XDAS_Void RLS_setInput(RLS_Handle handle, float x);

/*
// ===========================================================================
// RLS_setDesire
*/
extern XDAS_Void RLS_setDesire(RLS_Handle handle, float d);

extern XDAS_Void NLMS_setInputDesire(RLS_Handle handle, float x, float d);
#endif	/* RLS_ */
