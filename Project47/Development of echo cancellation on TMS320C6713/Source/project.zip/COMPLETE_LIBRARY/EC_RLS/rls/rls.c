/*
//============================================================================
//
//    FILE NAME : RLS.c
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in RLS.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 29 January 2005
//    Creation Time: 12:25 PM
//
//============================================================================
*/

#pragma CODE_SECTION(RLS_create,  ".text:create")
#pragma CODE_SECTION(RLS_control, ".text:control")
#pragma CODE_SECTION(RLS_delete,  ".text:delete")
#pragma CODE_SECTION(RLS_init,    ".text:init")
#pragma CODE_SECTION(RLS_exit,    ".text:exit")

#include <std.h>
#include <alg.h>
#include <xdas.h>
#include "rls.h"

/*
// ===========================================================================
// RLS_create
//
//  Create an RLS instance object (using parameters specified by prms)
*/
RLS_Handle RLS_create(const IRLS_Fxns *fxns, const RLS_Params *prms)
{
    return ((RLS_Handle)ALG_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// RLS_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int RLS_control(RLS_Handle handle, RLS_Cmd cmd, RLS_Status *status)
{
    return (ALG_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// RLS_delete
//
// Delete the RLS instance object specified by handle
*/
Void RLS_delete(RLS_Handle handle)
{
    ALG_delete((IALG_Handle)handle);
}

/*
// ===========================================================================
// RLS_init
//
// RLS module initialization
*/
Void  RLS_init(Void)
{
}

/*
// ===========================================================================
// RLS_exit
//
// RLS module finalization
*/
Void  RLS_exit(Void)
{
}

/*
// ===========================================================================
// RLS_apply
*/
XDAS_Void RLS_apply(RLS_Handle handle)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->apply(handle);

    ALG_deactivate((IALG_Handle)handle);
}

float RLS_getError(RLS_Handle handle)
{
    float result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->getError(handle);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}

float RLS_getOutput(RLS_Handle handle)
{
    float result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->getOutput(handle);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}

XDAS_Void RLS_setInput(RLS_Handle handle, float x)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setInput(handle, x);

    ALG_deactivate((IALG_Handle)handle);
}

XDAS_Void RLS_setDesire(RLS_Handle handle, float d)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setDesire(handle, d);

    ALG_deactivate((IALG_Handle)handle);
}

XDAS_Void NLMS_setInputDesire(RLS_Handle handle, float x, float d)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setInputDesire(handle, x, d);

    ALG_deactivate((IALG_Handle)handle);
}
