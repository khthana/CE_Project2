
#include <std.h>
#include <stdio.h>
#include "rls.h"
#include "rls_kmitl.h"

#define FILTER_LENGTH 1000
#define LAMDA 0.999
#define INVERT 1.0101
#define CHANNAL 1

float tab[FILTER_LENGTH];
float sta[FILTER_LENGTH];
float PI[FILTER_LENGTH];
float K[FILTER_LENGTH];
float P0[FILTER_LENGTH*FILTER_LENGTH];
float T1[FILTER_LENGTH];
float TP1[FILTER_LENGTH*FILTER_LENGTH];
float TP2[FILTER_LENGTH*FILTER_LENGTH];
float TMATRIX[FILTER_LENGTH*FILTER_LENGTH];
float X[CHANNAL],D[CHANNAL],y[CHANNAL],e[CHANNAL];

float input,desire;
float input2,desire2;
float err,output;


void dataIO()
{}

void main(){
    int i;
    float tempD[CHANNAL];
    float tempE[CHANNAL];
    float tempY[CHANNAL];
    RLS_Handle  handle[CHANNAL];
    IRLS_Fxns   fxns;
    RLS_Params  params;

    fxns = RLS_KMITL_IRLS;
    params = RLS_PARAMS;
    	
    for(i=0;i<CHANNAL;i++)
    {
       tempD[i] = 0;
       tempE[i] = 0;
       tempY[i] = 0;
     }
     
	for(i=0;i<CHANNAL;i++)
	{
		fxns = RLS_KMITL_IRLS;
		params = RLS_PARAMS;
		params.filter_length = FILTER_LENGTH;
		params.lamda = LAMDA;
		params.invert = INVERT;
		params.state = sta;
		params.tap_weight = tab;
		params.p0 = P0;
		params.pi = PI;
		params.k = K;
		params.temp1 = T1;
		params.tempP1 = TP1;
		params.tempP2 = TP2;
		params.tempMatrix = TMATRIX;
		params.tap_weight = tab;
		params.state = sta;
	
	
		
	
    	RLS_init();
	    handle[i] = RLS_create(&fxns, &params);
    }
   
         while(1)
		{
			int flag = 1;
			dataIO();	// read input from file fill in x and d
		
			for(i=0;i<CHANNAL;i++)
			{
				if(CHANNAL > 1) {
					if(flag == 1)
					{
						X[i] = input;
						D[i] = desire;
						flag = 0;
					} else {
						X[i] = input2;
						D[i] = desire2;
						flag = 1;
					}
				}
				else {
					X[i] = input;
					D[i] = desire;
					//D[0] = 10;
					//D[1] = 11;
				}
			}
			for(i=0;i<CHANNAL;i++)
			{
				tempD[i] = D[i];
			}
			
			for(i=0;i<CHANNAL;i++)
			{
			
				RLS_setInput(handle[i],X[i]);
				RLS_setDesire(handle[i],tempD[i]);
				RLS_apply(handle[i]);
				y[i] = RLS_getOutput(handle[i]);
				tempY[i] = y[i];
				e[i] = RLS_getError(handle[i]);
				tempE[i] = e[i];
				//err = e[i];
				err = tempE[i];
			}
		}
		
        //RLS_apply(handle);
        //RLS_delete(handle);
    
    //RLS_exit();
}

