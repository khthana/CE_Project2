/*
//============================================================================
//
//    FILE NAME : _RLS.c
//
//    BLOCK NAME: RLS
//
//    GROUP NAME: Default Group
//
//    PURPOSE   : Provides the real-time block's DSP C source code.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 29 January 2005
//    Creation Time: 12:25 PM
//
//============================================================================
*/

#include "_rls.h"

#pragma DATA_SECTION(Params, ".hyper:ignore")
PARAMS Params;

/*----------------------------------------------------------------------------*/
/*               Optional real-time block interrupt routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called in response to a selected  */
/* DSP interrupt.  If this routine in not activated, the main block routine   */
/* will be called in response to a selected DSP interrupt.                    */
/*----------------------------------------------------------------------------*/
/*
void RLS_INT(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*               Optional real-time block initialization routine              */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called one time before the main   */
/* application begins.  This allows for any required software or hardware     */
/* initialization to be performed before the block executes.                  */
/*----------------------------------------------------------------------------*/

static IRLS_Fxns   fxns;
static RLS_Params  params;

void RLS_INIT(PARAMS *pPtr)
{
    fxns = RLS_KMITL_IRLS;
    params = RLS_PARAMS;
	
	params.step = pPtr->_step;
	params.x = pPtr->_x;
	params.d = pPtr->_d;
	params.e = pPtr->_e;
	params.y = pPtr->_y;
	params.lamda = pPtr->_lamda;
	params.invert = pPtr->_invert;
	params.filter_length = pPtr->_filter_length;
	
    pPtr->handle = RLS_create(&fxns, &params);
}


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block stop routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever the block diagram */
/* worksheet's execution is stopped.  Blocks that deal with hardware may need */
/* this routine to stop the hardware's execution.                             */
/*----------------------------------------------------------------------------*/
/*
void RLS_STOP(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block restart routine                */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever a block diagram   */
/* worksheet is executed after being stopped.  Blocks that deal with hardware */
/* may need this routine to restart the hardware's execution.                 */
/*----------------------------------------------------------------------------*/
/*
void RLS_RESTART(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                           Real-time block routine                          */
/*----------------------------------------------------------------------------*/
/* This is the main block routine.  It is called during each loop of the main */
/* application.  If an interrupt is selected, and the interrupt routine above */
/* is not activated, this routine will be called in response to the selected  */
/* interrupt instead of during the main application loop.                     */
/* Custom fields of the pPtr structure may be accessed as follows:            */
/*----------------------------------------------------------------------------*/
void RLS(PARAMS *pPtr)
{
    if(pPtr->handle){
        if(pPtr->Changed){
            RLS_Status	status;

            pPtr->Changed = FALSE;
           	status.step = pPtr->_step;
           	status.x = pPtr->_x;
           	status.d = pPtr->_d;
           	status.e = pPtr->_e;
           	status.y = pPtr->_y;
			status.filter_length = pPtr->_filter_length;
			status.lamda = pPtr->_lamda;
			status.invert = pPtr->_invert;
			
            RLS_control(pPtr->handle, RLS_SETSTATUS, &status);
        }

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        RLS_apply(pPtr->handle);
    }
}
