@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x rls.cmd
erase rls_kmitl.l67
erase rls.l67
ar6x -r rls_kmitl.l67 ..\Release\rls.o67
ar6x -r rls.l67 ..\Release\rls.obj
