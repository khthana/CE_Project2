-r
-m ..\Release\rls.map
-o ..\Release\rls.o67
-h
-g _RLS_KMITL_IRLS
-g _RLS_KMITL_IALG
-g _RLS_KMITL_alloc
-g _RLS_KMITL_free
-g _RLS_KMITL_initObj
-g _RLS_KMITL_control
-g _RLS_KMITL_init
-g _RLS_KMITL_exit
-g _RLS_KMITL_apply
-g _IRLS_PARAMS

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\RLS_KMITL_ialg.obj
..\Release\RLS_KMITL_ialgvt.obj
..\Release\iRLS.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
/*
// The RLS_KMITL_activate & RLS_KMITL_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
