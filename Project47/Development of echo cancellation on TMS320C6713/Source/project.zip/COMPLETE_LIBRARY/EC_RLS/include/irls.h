/*
//============================================================================
//
//    FILE NAME : IRLS.h
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : IRLS Interface Header
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 25 December 2004
//    Creation Time: 12:33 PM
//
//============================================================================
*/

#ifndef IRLS_
#define IRLS_

#include <xdas.h>
#include <ialg.h>

//#######################################
#define FILTER_LENGTH 32 
#define BUFF_INPUT 80
//#######################################

//#######################################
/*
// ===========================================================================
// IRLS_Handle
//
// This handle is used to reference all RLS instance objects
*/
typedef struct IRLS_Obj *IRLS_Handle;

/*
// ===========================================================================
// IRLS_Obj
//
// This structure must be the first field of all RLS instance objects
*/
typedef struct IRLS_Obj {
    struct IRLS_Fxns *fxns;
} IRLS_Obj;

/*
// ===========================================================================
// IRLS_Status
//
// Status structure defines the parameters that can be changed or read
// during real-time operation of the alogrithm.
*/
typedef struct IRLS_Status {
    Int  size;  /* must be first field of all status structures */
	float *tap_weight; 
	float *state;
	float *pi;
	float *p0;
	float *k;
	//float *U;
	float *tempP1;
	float *tempP2;
	float *tempMatrix;
	float *temp1;
	float lamda;
   	float invert;
	float step;	
	float x;
	float d;
	float y;
	float e;   
	XDAS_Int32 filter_length;
} IRLS_Status;

/*
// ===========================================================================
// IRLS_Cmd
//
// The Cmd enumeration defines the control commands for the RLS
// control method.
*/
typedef enum IRLS_Cmd {
  IRLS_GETSTATUS,
  IRLS_SETSTATUS
} IRLS_Cmd;

/*
// ===========================================================================
// IRLS_Params
//
// This structure defines the creation parameters for all RLS objects
*/
typedef struct IRLS_Params {
    Int size;	  /* must be first field of all params structures */
	float *tap_weight; 
	float *state;
	float *pi;
	float *p0;
	float *k;
	//float *U;
	float *tempP1;
	float *tempP2;
	float *tempMatrix;
	float *temp1;
	float lamda;
	float invert;
	float step;	
	float x;
	float d;
	float y;
	float e;   
	XDAS_Int32 filter_length;
} IRLS_Params;

/*
// ===========================================================================
// IRLS_PARAMS
//
// Default parameter values for RLS instance objects
*/
extern IRLS_Params IRLS_PARAMS;

/*
// ===========================================================================
// IRLS_Fxns
//
// This structure defines all of the operations on RLS objects
*/
typedef struct IRLS_Fxns {
    IALG_Fxns	ialg;    /* IRLS extends IALG */
    XDAS_Void (*apply)(IRLS_Handle handle);
    float (*getError)(IRLS_Handle handle);
    float (*getOutput)(IRLS_Handle handle);
    XDAS_Void (*setInput)(IRLS_Handle handle, float x);
    XDAS_Void (*setDesire)(IRLS_Handle handle, float d);
	XDAS_Void (*setInputDesire)(IRLS_Handle handle, float x, float d);
} IRLS_Fxns;

#endif	/* IRLS_ */
