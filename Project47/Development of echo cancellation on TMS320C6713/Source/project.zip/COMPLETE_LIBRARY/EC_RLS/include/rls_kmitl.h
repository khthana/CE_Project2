/*
//============================================================================
//
//    FILE NAME : RLS_KMITL.h
//
//    ALGORITHM : RLS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Interface for the RLS_KMITL module; KMITL's implementation
//                of the IRLS interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Sat - 25 December 2004
//    Creation Time: 12:33 PM
//
//============================================================================
*/

#ifndef RLS_KMITL_
#define RLS_KMITL_

#include "iRLS.h"
#include <ialg.h>

/*
//============================================================================
// RLS_KMITL_IALG
//
// KMITL's implementation of the IALG interface for RLS
*/
extern far IALG_Fxns RLS_KMITL_IALG;

/*
//============================================================================
// RLS_KMITL_IRLS
//
// KMITL's implementation of the IRLS interface
*/
extern far IRLS_Fxns RLS_KMITL_IRLS;

/*
//============================================================================
// RLS_KMITL_init
//
// Initialize the RLS_KMITL module as a whole
*/
extern Void RLS_KMITL_init(Void);

/*
//============================================================================
// RLS_KMITL_exit
//
// Exit the RLS_KMITL module as a whole
*/
extern Void RLS_KMITL_exit(Void);

#endif	/* RLS_KMITL_ */
