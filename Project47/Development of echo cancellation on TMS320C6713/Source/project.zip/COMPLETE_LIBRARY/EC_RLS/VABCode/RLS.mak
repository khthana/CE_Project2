# Microsoft Developer Studio Generated NMAKE File, Based on RLS.dsp
!IF "$(CFG)" == ""
CFG=RLS - Win32 Release
!MESSAGE No configuration specified. Defaulting to RLS - Win32 Release.
!ENDIF 

!IF "$(CFG)" != "RLS - Win32 Release" && "$(CFG)" != "RLS - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "RLS.mak" CFG="RLS - Win32 Release"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "RLS - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "RLS - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "RLS - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\RLS.dll"


CLEAN :
	-@erase "$(INTDIR)\IFRLS.obj"
	-@erase "$(INTDIR)\RLS.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\RLS.dll"
	-@erase "$(OUTDIR)\RLS.exp"
	-@erase "$(OUTDIR)\RLS.lib"
	-@erase "$(OUTDIR)\RLS.map"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MT /W3 /GX /O2 /I "c:\ti\plugins\xdais\CW\\" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\RLS.res" /i "c:\ti\plugins\xdais\CW\\" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\RLS.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /incremental:no /pdb:"$(OUTDIR)\RLS.pdb" /map:"$(INTDIR)\RLS.map" /machine:I386 /def:".\RLS.def" /out:"$(OUTDIR)\RLS.dll" /implib:"$(OUTDIR)\RLS.lib" 
DEF_FILE= \
	".\RLS.def"
LINK32_OBJS= \
	"$(INTDIR)\IFRLS.obj" \
	"$(INTDIR)\RLS.res" \
	"c:\ti\plugins\xdais\CW\\Bddk.lib" \
	"c:\ti\plugins\xdais\CW\\htmlhelp.lib"

"$(OUTDIR)\RLS.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "RLS - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\RLS.dll"


CLEAN :
	-@erase "$(INTDIR)\IFRLS.obj"
	-@erase "$(INTDIR)\RLS.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\RLS.dll"
	-@erase "$(OUTDIR)\RLS.exp"
	-@erase "$(OUTDIR)\RLS.ilk"
	-@erase "$(OUTDIR)\RLS.lib"
	-@erase "$(OUTDIR)\RLS.map"
	-@erase "$(OUTDIR)\RLS.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MTd /W3 /Gm /GX /ZI /Od /I "c:\ti\plugins\xdais\CW\\" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\RLS.res" /i "c:\ti\plugins\xdais\CW\\" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\RLS.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\RLS.pdb" /map:"$(INTDIR)\RLS.map" /debug /machine:I386 /def:".\RLS.def" /out:"$(OUTDIR)\RLS.dll" /implib:"$(OUTDIR)\RLS.lib" 
DEF_FILE= \
	".\RLS.def"
LINK32_OBJS= \
	"$(INTDIR)\IFRLS.obj" \
	"$(INTDIR)\RLS.res" \
	"c:\ti\plugins\xdais\CW\\Bddk.lib" \
	"c:\ti\plugins\xdais\CW\\htmlhelp.lib"

"$(OUTDIR)\RLS.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("RLS.dep")
!INCLUDE "RLS.dep"
!ELSE 
!MESSAGE Warning: cannot find "RLS.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "RLS - Win32 Release" || "$(CFG)" == "RLS - Win32 Debug"
SOURCE=.\IFRLS.c

"$(INTDIR)\IFRLS.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\RLS.rc

"$(INTDIR)\RLS.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)



!ENDIF 
