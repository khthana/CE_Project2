/*
//============================================================================
//
//    FILE NAME : LMS_KMITL_ialg.c
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the LMS_KMITL.h interface; KMITL's
//                implementation of the ILMS interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#pragma CODE_SECTION(LMS_KMITL_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(LMS_KMITL_free,       ".text:algFree")
#pragma CODE_SECTION(LMS_KMITL_initObj,    ".text:algInit")
#pragma CODE_SECTION(LMS_KMITL_control,    ".text:algControl")
#pragma CODE_SECTION(LMS_KMITL_init,       ".text:init")
#pragma CODE_SECTION(LMS_KMITL_exit,       ".text:exit")
#pragma CODE_SECTION(LMS_KMITL_moved,      ".text:algMoved")
/*
// The LMS_KMITL_activate & LMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(LMS_KMITL_activate,   ".text:algActivate")
#pragma CODE_SECTION(LMS_KMITL_deactivate, ".text:algDeactivate")
*/

#include <std.h>
#include <limits.h>
#include "ilms.h"
#include "lms_kmitl.h"

#define HISTORY 1 // *tap_weight
#define WORKBUFFER 2 // *state
#define MTAB_NRECS 3
#define HLOCALBUFFER0_SIZE 1000
#define HLOCALBUFFER1_SIZE 1000


void LMS_adapt(ILMS_Handle handle);
void LMS_getMaxNorm(ILMS_Handle handle);
void LMS_normAlg(ILMS_Handle handle);
float LMS_filter(Float input,ILMS_Handle handle);
/*
//============================================================================
// LMS_KMITL_Obj
*/
typedef struct LMS_KMITL_Obj {
    IALG_Obj        alg;   /* MUST be first field of all LMS objs */
    float *         tap_weight;
    float *         state;
    float           step;
    float           x;
    float           d;
    float           y;
    float           e;
    XDAS_UInt32     filter_length;
    XDAS_UInt32     number_norm;
    float           maxNorm;
    XDAS_UInt32     count_for_norm;
    XDAS_Int32      *hLocalBuffer0;
    XDAS_Int32      *hLocalBuffer1;

    /* TODO: add custom fields here */
} LMS_KMITL_Obj;

/*
//============================================================================
// LMS_KMITL_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the LMS_KMITL processing methods.
*/
/*
// The LMS_KMITL_activate & LMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void LMS_KMITL_activate(IALG_Handle handle)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;
    
    // TODO: implement algActivate
}
*/

/*
//============================================================================
// LMS_KMITL_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a LMS_KMITL_Obj structure.
*/
Int LMS_KMITL_alloc(const IALG_Params *LMSParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const ILMS_Params *params = (Void *)LMSParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &ILMS_PARAMS;  /* set default parameters */
    }

    /* Request memory for LMS object */
    memTab[0].size = sizeof(LMS_KMITL_Obj);
    memTab[0].alignment = 0;//(0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;

    // NOTE: Some algorithms may be better suited to use an equation to define memtab
    //       size(s). User may want to modify the size field as required by his algorithm.

    /* Request memory for hLocalBuffer0 array */
    memTab[HISTORY].size = (params->filter_length) * sizeof(float);
    memTab[HISTORY].alignment = 0;//(0 * 8) / CHAR_BIT;
    memTab[HISTORY].space = IALG_EXTERNAL;
    memTab[HISTORY].attrs = IALG_PERSIST;

    /* Request memory for hLocalBuffer1 array */
    memTab[WORKBUFFER].size = (params->filter_length) * sizeof(float);
    memTab[WORKBUFFER].alignment = 0;//(0 * 8) / CHAR_BIT;
    memTab[WORKBUFFER].space = IALG_EXTERNAL;
    memTab[WORKBUFFER].attrs = IALG_PERSIST;

    return (MTAB_NRECS);
}

/*
//============================================================================
// LMS_KMITL_control
//
// Control our object's parameters while the algorithm is running
*/
Int LMS_KMITL_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    ILMS_Status *sPtr = (ILMS_Status *)status;	
    LMS_KMITL_Obj *LMS = (Void *)handle;

    switch ((ILMS_Cmd)cmd) {

       case ILMS_GETSTATUS:
            sPtr->tap_weight = LMS->tap_weight;
            sPtr->state = LMS->state;
            sPtr->step = LMS->step;
            sPtr->x = LMS->x;
            sPtr->d = LMS->d;
            sPtr->y = LMS->y;
            sPtr->e = LMS->e;
            sPtr->filter_length = LMS->filter_length;
            sPtr->number_norm = LMS->number_norm;  
            sPtr->maxNorm = LMS->maxNorm;
            sPtr->count_for_norm = LMS->count_for_norm;

            return(IALG_EOK);

       case ILMS_SETSTATUS:
            LMS->tap_weight = sPtr->tap_weight;
            LMS->state = sPtr->state;
            LMS->step = sPtr->step;
            LMS->x = sPtr->x;
            LMS->d = sPtr->d;
            LMS->y = sPtr->y;
            LMS->e = sPtr->e;
            LMS->filter_length = sPtr->filter_length;
            LMS->number_norm = sPtr->number_norm;
            LMS->maxNorm = sPtr->maxNorm;
            LMS->count_for_norm = sPtr->count_for_norm;

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// LMS_KMITL_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the LMS_KMITL processing methods to persistent memory.
*/
/*
// The LMS_KMITL_activate & LMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void LMS_KMITL_deactivate(IALG_Handle handle)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;
    
    // TODO: implement algDeactivate
}
*/

/*
//============================================================================
// LMS_KMITL_exit
//
// Exit the LMS_KMITL module as a whole.
 */
Void LMS_KMITL_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// LMS_KMITL_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// LMS_KMITL_alloc operation above.
*/
Int LMS_KMITL_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    LMS_KMITL_Obj *LMS = (Void *)handle;

    n = LMS_KMITL_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[HISTORY].base = LMS->hLocalBuffer0;
    memTab[WORKBUFFER].base = LMS->hLocalBuffer1;

    return (n);
}

/*
//============================================================================
// LMS_KMITL_init
//
// Initialize the LMS_KMITL module as a whole.
*/
Void LMS_KMITL_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// LMS_KMITL_initObj
//
// Initialize the memory allocated for our instance.
*/
Int LMS_KMITL_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *LMSParams)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;
    const ILMS_Params *params = (Void *)LMSParams;
    int i;

    if(params == NULL){
        params = &ILMS_PARAMS; /* set default parameters */
    }

    LMS->tap_weight = params->tap_weight;
    LMS->state = params->state;
    LMS->step = params->step;
    LMS->x = params->x;
    LMS->d = params->d;
    LMS->y = params->y;
    LMS->e = params->e;
    LMS->filter_length = params->filter_length;
    LMS->number_norm = params->number_norm;
    LMS->maxNorm = params->maxNorm;
    LMS->count_for_norm = params->count_for_norm;
    LMS->hLocalBuffer0 = memTab[HISTORY].base;
    LMS->hLocalBuffer1 = memTab[WORKBUFFER].base;
  
    

    /* TODO: Implement any additional algInit desired */
    for(i = 0;i<params->filter_length;i++)
    {
    	LMS->state[i] = 0;
    	LMS->tap_weight[i] = 0;
    }
    LMS->step = 0.8; 
    LMS->x = 0;
    LMS->d = 0;
    LMS->y = 0;
    LMS->e = 0;
    LMS->maxNorm = 0;
    LMS->count_for_norm = 0;
    LMS->filter_length  = params->filter_length;
    LMS->hLocalBuffer0  = memTab[HISTORY].base;
    LMS->hLocalBuffer1  = memTab[WORKBUFFER].base;
        
    return (IALG_EOK);
}

/*
//============================================================================
// LMS_KMITL_moved
//
// Adjust any data pointers that has been moved by the client.
*/
Void LMS_KMITL_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *LMSParams)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;
  //  const ILMS_Params *params = (Void *)LMSParams;
    LMS->hLocalBuffer0 = memTab[HISTORY].base;
    LMS->hLocalBuffer1 = memTab[WORKBUFFER].base;
}

/*
//============================================================================
// LMS_KMITL_apply
// KMITL's implementation of the apply operation.
// Custom fields of the LMS_KMITL_Obj may be accessed as follows:
//     LMS->tap_weight = ...;
//     LMS->state = ...;
//     LMS->step = ...;
//     LMS->x = ...;
//     LMS->d = ...;
//     LMS->y = ...;
//     LMS->e = ...;
//     LMS->filter_length = ...;
//     LMS->maxNorm = ...;
//     LMS->count_for_norm = ...;
//     LMS->hLocalBuffer0 = ...;
//     LMS->hLocalBuffer1 = ...;
*/
XDAS_Void LMS_KMITL_apply(ILMS_Handle handle)
{
   // LMS_KMITL_Obj *LMS = (Void *)handle;

    /* TODO: implement apply */
	LMS_adapt(handle);
    /*
    int index;
    for(index=0; index<LMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// LMS_KMITL_setInput
// KMITL's implementation of the setInput operation.
// Custom fields of the LMS_KMITL_Obj may be accessed as follows:
//     LMS->tap_weight = ...;
//     LMS->state = ...;
//     LMS->step = ...;
//     LMS->x = ...;
//     LMS->d = ...;
//     LMS->y = ...;
//     LMS->e = ...;
//     LMS->filter_length = ...;
//     LMS->maxNorm = ...;
//     LMS->count_for_norm = ...;
//     LMS->hLocalBuffer0 = ...;
//     LMS->hLocalBuffer1 = ...;
*/
XDAS_Void LMS_KMITL_setInput(ILMS_Handle handle, float x)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;

    /* TODO: implement setInput */
	LMS->x = x;
    /*
    int index;
    for(index=0; index<LMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// LMS_KMITL_setDesire
// KMITL's implementation of the setDesire operation.
// Custom fields of the LMS_KMITL_Obj may be accessed as follows:
//     LMS->tap_weight = ...;
//     LMS->state = ...;
//     LMS->step = ...;
//     LMS->x = ...;
//     LMS->d = ...;
//     LMS->y = ...;
//     LMS->e = ...;
//     LMS->filter_length = ...;
//     LMS->maxNorm = ...;
//     LMS->count_for_norm = ...;
//     LMS->hLocalBuffer0 = ...;
//     LMS->hLocalBuffer1 = ...;
*/
XDAS_Void LMS_KMITL_setDesire(ILMS_Handle handle, float d)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;

    /* TODO: implement setDesire */
	LMS->d = d;
    /*
    int index;
    for(index=0; index<LMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// LMS_KMITL_getError
// KMITL's implementation of the getError operation.
// Custom fields of the LMS_KMITL_Obj may be accessed as follows:
//     LMS->tap_weight = ...;
//     LMS->state = ...;
//     LMS->step = ...;
//     LMS->x = ...;
//     LMS->d = ...;
//     LMS->y = ...;
//     LMS->e = ...;
//     LMS->filter_length = ...;
//     LMS->maxNorm = ...;
//     LMS->count_for_norm = ...;
//     LMS->hLocalBuffer0 = ...;
//     LMS->hLocalBuffer1 = ...;
*/
float LMS_KMITL_getError(ILMS_Handle handle)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;

    /* TODO: implement getError */

    /*
    int index;
    for(index=0; index<LMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */

    return((float)LMS->e);
}

/*
//============================================================================
// LMS_KMITL_getOutput
// KMITL's implementation of the getOutput operation.
// Custom fields of the LMS_KMITL_Obj may be accessed as follows:
//     LMS->tap_weight = ...;
//     LMS->state = ...;
//     LMS->step = ...;
//     LMS->x = ...;
//     LMS->d = ...;
//     LMS->y = ...;
//     LMS->e = ...;
//     LMS->filter_length = ...;
//     LMS->maxNorm = ...;
//     LMS->count_for_norm = ...;
//     LMS->hLocalBuffer0 = ...;
//     LMS->hLocalBuffer1 = ...;
*/
float LMS_KMITL_getOutput(ILMS_Handle handle)
{
    LMS_KMITL_Obj *LMS = (Void *)handle;

    /* TODO: implement getOutput */

    /*
    int index;
    for(index=0; index<LMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
    return((float)LMS->y);
}

//-------------------

Void LMS_adapt(ILMS_Handle handle)
{
	LMS_KMITL_Obj *LMS = (Void *)handle;
	
		Int i;
		// Norm Alg
		LMS_normAlg(handle);
		// filter & � Predict error
		LMS->y = LMS_filter(LMS->x,handle);
		LMS->e = LMS->d - LMS->y;
		// Update Weight vector 
		for(i = 0; i<LMS->filter_length; i++)
		{
			LMS->tap_weight[i] += LMS->step * LMS->state[i] * LMS->e;
		}
}
//--------------------------------------

Float LMS_filter(Float input,ILMS_Handle handle)
{
	LMS_KMITL_Obj *LMS = (Void *)handle;
	
	Float y;
	Int i;
	Float *U;//[32];
	U = (float *)malloc(sizeof(float)*LMS->filter_length);
	
	for(i = 0; i<LMS->filter_length; i++)
	{
		U[i] = 0;
	}
	
	y = 0;
	
	// Fill value in temp
	for(i = 0; i<LMS->filter_length; i++)
	{
		if(i == 0)
			U[i] = LMS->x;
		else
			U[i] = LMS->state[i-1]; 
	}
	
	// Convolutoin
	for(i = 0; i<LMS->filter_length; i++)
	{
		y += LMS->tap_weight[i] * U[i]; 
	}
	
	//============== Shif filter state========
	for(i = 0; i<LMS->filter_length; i++)
	{
		LMS->state[i] = U[i]; 
	}
		
	free(U);
	
	return y;
}

//-----------------------------------

Void LMS_normAlg(ILMS_Handle handle)
{
	LMS_KMITL_Obj *LMS = (Void *)handle;
	
	LMS_getMaxNorm(handle);
	if( LMS->count_for_norm == LMS->number_norm)
	{
		LMS->step = 1/LMS->maxNorm;
		LMS->count_for_norm = 0;
		LMS->maxNorm = 0;
	}
	LMS->count_for_norm++;
}
//--------------------------------------

Void LMS_getMaxNorm(ILMS_Handle handle)
{
	LMS_KMITL_Obj *LMS = (Void *)handle;
	
	Float norm = 0;
	Int i;
	for(i = 0; i<LMS->filter_length; i++)
	{
		norm = norm + (LMS->state[i] * LMS->state[i]);
	}
	if( norm > LMS->maxNorm)
		LMS->maxNorm = norm;
}
//--------------------------------------

