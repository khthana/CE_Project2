/*
//============================================================================
//
//    FILE NAME : LMS_KMITL_ialgvt.c
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the LMS_KMITL module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#include <std.h>
#include "ilms.h"

#include "lms_kmitl.h"

extern Int  LMS_KMITL_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  LMS_KMITL_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  LMS_KMITL_free(IALG_Handle, IALG_MemRec *);
extern Int  LMS_KMITL_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  LMS_KMITL_numAlloc(Void);
extern Void LMS_KMITL_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
/*
// The LMS_KMITL_activate & LMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
extern Void LMS_KMITL_activate(IALG_Handle);
extern Void LMS_KMITL_deactivate(IALG_Handle);
*/
extern XDAS_Void LMS_KMITL_apply(ILMS_Handle handle);
extern XDAS_Void LMS_KMITL_setInput(ILMS_Handle handle, float x);
extern XDAS_Void LMS_KMITL_setDesire(ILMS_Handle handle, float d);
extern float LMS_KMITL_getError(ILMS_Handle handle);
extern float LMS_KMITL_getOutput(ILMS_Handle handle);

#define IALGFXNS \
    &LMS_KMITL_IALG,       /* module ID                            */ \
    NULL,                  /* activate   (NULL => not suported)    */ \
    LMS_KMITL_alloc,       /* algAlloc                             */ \
    LMS_KMITL_control,     /* control    (NULL => not suported)    */ \
    NULL,                  /* deactivate (NULL => not suported)    */ \
    LMS_KMITL_free,        /* free                                 */ \
    LMS_KMITL_initObj,     /* init                                 */ \
    LMS_KMITL_moved,       /* moved      (NULL => not suported)    */ \
    NULL                   /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// LMS_KMITL_ILMS
//
// This structure defines KMITL's implementation of the ILMS interface
// for the LMS_KMITL module.
*/
ILMS_Fxns LMS_KMITL_ILMS = {	/* module_vendor_interface */
    IALGFXNS,
    LMS_KMITL_apply,
    LMS_KMITL_setInput,
    LMS_KMITL_setDesire,
    LMS_KMITL_getError,
    LMS_KMITL_getOutput,
};

/*
//============================================================================
// LMS_KMITL_IALG
//
// This structure defines KMITL's implementation of the IALG interface
// for the LMS_KMITL module.
*/
#ifdef _TI_
asm("_LMS_KMITL_IALG .set _LMS_KMITL_ILMS");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns LMS_KMITL_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
