/*
//============================================================================
//
//    FILE NAME : ILMS.c
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iLMS.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "ilms.h"

/*
// ===========================================================================
// LMS_PARAMS
//
// This constant structure defines the default parameters for LMS objects
*/
ILMS_Params ILMS_PARAMS = {
    sizeof(ILMS_Params),
    NULL, /* tap_weight */
    NULL, /* state */
    0.8, /* step */
    0, /* x */
    0, /* d */
    0, /* y */
    0, /* e */
    32, /* filter_length */
    100,
    0, /* maxNorm */
    0, /* count_for_norm */
};
