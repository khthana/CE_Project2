-r
-m ..\Release\lms.map
-o ..\Release\lms.o67
-h
-g _LMS_KMITL_ILMS
-g _LMS_KMITL_IALG
-g _LMS_KMITL_alloc
-g _LMS_KMITL_free
-g _LMS_KMITL_initObj
-g _LMS_KMITL_control
-g _LMS_KMITL_moved
-g _LMS_KMITL_init
-g _LMS_KMITL_exit
-g _LMS_KMITL_apply
-g _LMS_KMITL_setInput
-g _LMS_KMITL_setDesire
-g _LMS_KMITL_getError
-g _LMS_KMITL_getOutput
-g _ILMS_PARAMS

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\LMS_KMITL_ialg.obj
..\Release\LMS_KMITL_ialgvt.obj
..\Release\iLMS.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
    .text:algMoved {}
/*
// The LMS_KMITL_activate & LMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
