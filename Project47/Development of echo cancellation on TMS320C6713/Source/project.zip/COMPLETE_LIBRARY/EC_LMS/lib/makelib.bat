@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x lms.cmd
erase lms_kmitl.l67
erase lms.l67
ar6x -r lms_kmitl.l67 ..\Release\lms.o67
ar6x -r lms.l67 ..\Release\lms.obj
