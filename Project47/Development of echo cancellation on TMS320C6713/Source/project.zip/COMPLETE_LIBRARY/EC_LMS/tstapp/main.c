
#include <std.h>
#include "lms.h"
#include "lms_kmitl.h"

#define FILTER_LENGTH 2500 // Length of vector
#define NUM_FIND_NORM 100 // Finding a norm in alg every NUM_FIND_NORM time
#define CHANNAL 1	// Multichannal

float coff[CHANNAL][FILTER_LENGTH]; 
float sta[CHANNAL][FILTER_LENGTH];
float x[CHANNAL],d[CHANNAL],y[CHANNAL],e[CHANNAL];

float input,desire; // for fill in from fileIO
float input2,desire2; // for fill in from fileIO
float err,output;

void dataIO()
{
}

void main(){

    //---------- Define Parameter ----------//
    LMS_Handle  handle[CHANNAL];
    ILMS_Fxns   fxns;
    LMS_Params  params;

    int i,j;     
	//---------- Initial Values Object ----//
	for(i = 0;i<CHANNAL;i++)
	{	
		for(j = 0;j<FILTER_LENGTH;j++)
		{
			coff[i][j] = 0;
			sta[i][j] = 0;
		}
	}
	//-------- Init Value to Params -----//
	
	for(i = 0; i<CHANNAL; i++)
	{
	    fxns = LMS_KMITL_ILMS;
		params = LMS_PARAMS;
		params.filter_length = FILTER_LENGTH;
		params.number_norm = NUM_FIND_NORM;
		for(j=0;j<FILTER_LENGTH;j++)
		{
			params.tap_weight = coff[i];
	    	params.state = sta[i];
	    }	    		    
     	LMS_init();
	    handle[i] = LMS_create(&fxns, &params);
	 }

    //------------ Apply ----------------//
    while(1){  
    	int flag = 1;    
      	dataIO();//Initial value to input and desire variable;
      	for(i = 0; i<CHANNAL; i++)
      	{
      		if(CHANNAL>1){
      			if(flag==1)
      			{
      				x[i] = input;
      				d[i] = desire;
      				flag = 0;
      			}else{
	      			x[i] = input2;
    	  			d[i] = desire2;
      				flag = 1;
      			}
      		}
      		else{
      			x[i] = input;
      			d[i] = desire;
      		}
      	}
      	
      	for(i = 0; i<CHANNAL; i++)
        {
        	LMS_setInput(handle[i],x[i]);
			LMS_setDesire(handle[i],d[i]);
			LMS_apply(handle[i]);
			y[i] = LMS_getOutput(handle[i]);
			e[i] = LMS_getError(handle[i]);		
			err = e[i];
		}
	}
    
    //-------- Destroy handle object -----//
    //for(i = 0; i<CHANNAL; i++)
    //	 LMS_delete(handle[i]);
//    LMS_exit();
}

