/*
//============================================================================
//
//    FILE NAME : _LMS.c
//
//    BLOCK NAME: LMS
//
//    GROUP NAME: Default Group
//
//    PURPOSE   : Provides the real-time block's DSP C source code.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#include "_lms.h"

#pragma DATA_SECTION(Params, ".hyper:ignore")
PARAMS Params;

/*----------------------------------------------------------------------------*/
/*               Optional real-time block interrupt routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called in response to a selected  */
/* DSP interrupt.  If this routine in not activated, the main block routine   */
/* will be called in response to a selected DSP interrupt.                    */
/*----------------------------------------------------------------------------*/
/*
void LMS_INT(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*               Optional real-time block initialization routine              */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called one time before the main   */
/* application begins.  This allows for any required software or hardware     */
/* initialization to be performed before the block executes.                  */
/*----------------------------------------------------------------------------*/

static ILMS_Fxns   fxns;
static LMS_Params  params;

void LMS_INIT(PARAMS *pPtr)
{
    fxns = LMS_KMITL_ILMS;
    params = LMS_PARAMS;

    params.step = pPtr->_step;
    params.x = pPtr->_x;
    params.d = pPtr->_d;
    params.y = pPtr->_y;
    params.e = pPtr->_e;
    params.filter_length = pPtr->_filter_length;
    params.number_norm = pPtr->_number_norm;
    params.maxNorm = pPtr->_maxNorm;
    params.count_for_norm = pPtr->_count_for_norm;

    pPtr->handle = LMS_create(&fxns, &params);
}


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block stop routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever the block diagram */
/* worksheet's execution is stopped.  Blocks that deal with hardware may need */
/* this routine to stop the hardware's execution.                             */
/*----------------------------------------------------------------------------*/
/*
void LMS_STOP(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block restart routine                */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever a block diagram   */
/* worksheet is executed after being stopped.  Blocks that deal with hardware */
/* may need this routine to restart the hardware's execution.                 */
/*----------------------------------------------------------------------------*/
/*
void LMS_RESTART(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                           Real-time block routine                          */
/*----------------------------------------------------------------------------*/
/* This is the main block routine.  It is called during each loop of the main */
/* application.  If an interrupt is selected, and the interrupt routine above */
/* is not activated, this routine will be called in response to the selected  */
/* interrupt instead of during the main application loop.                     */
/* Custom fields of the pPtr structure may be accessed as follows:            */
/*     pPtr->_step = ...;                                                     */
/*     pPtr->_x = ...;                                                        */
/*     pPtr->_d = ...;                                                        */
/*     pPtr->_y = ...;                                                        */
/*     pPtr->_e = ...;                                                        */
/*     pPtr->_filter_length = ...;                                            */
/*     pPtr->_maxNorm = ...;                                                  */
/*     pPtr->_count_for_norm = ...;                                           */
/*----------------------------------------------------------------------------*/
void LMS(PARAMS *pPtr)
{
    if(pPtr->handle){
        if(pPtr->Changed){
            LMS_Status	status;

            pPtr->Changed = FALSE;
            status.step = pPtr->_step;
            status.x = pPtr->_x;
            status.d = pPtr->_d;
            status.y = pPtr->_y;
            status.e = pPtr->_e;
            status.filter_length = pPtr->_filter_length;
            status.number_norm = pPtr->_number_norm;
            status.maxNorm = pPtr->_maxNorm;
            status.count_for_norm = pPtr->_count_for_norm;
            LMS_control(pPtr->handle, LMS_SETSTATUS, &status);
        }

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        LMS_apply(pPtr->handle);
        //LMS_setInput(pPtr->handle);        
        //LMS_setDesire(pPtr->handle);
        //LMS_getError(pPtr->handle);
        //LMS_getOutput(pPtr->handle);
    }
}
