/*
//============================================================================
//
//    FILE NAME : LMS.h
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                LMS module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#ifndef LMS_
#define LMS_

#include <alg.h>
#include <xdas.h>
#include "ilms.h"

/*
// ===========================================================================
// LMS_Handle
//
// This pointer is used to reference all LMS instance objects
*/
typedef struct ILMS_Obj *LMS_Handle;

/*
// ===========================================================================
// LMS_Params
//
// This structure defines the creation parameters for all LMS objects
*/
typedef ILMS_Params LMS_Params;

/*
// ===========================================================================
// LMS_PARAMS
//
// This structure defines the default creation parameters for LMS objects
*/
#define LMS_PARAMS   ILMS_PARAMS

/*
// ===========================================================================
// LMS_Status
//
// This structure defines the real-time parameters for LMS objects
*/
typedef struct ILMS_Status   LMS_Status;

/*
// ===========================================================================
// LMS_Cmd
//
// This typedef defines the control commands LMS objects
*/
typedef ILMS_Cmd   LMS_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define LMS_GETSTATUS    ILMS_GETSTATUS
#define LMS_SETSTATUS    ILMS_SETSTATUS

/*
// ===========================================================================
// LMS_create
//
// Create an LMS instance object (using parameters specified by prms)
*/
extern LMS_Handle LMS_create(const ILMS_Fxns *fxns, const LMS_Params *prms);

/*
// ===========================================================================
// LMS_control
//
// Get, set, and change the parameters of the LMS function (using parameters specified by status).
*/
extern Int LMS_control(LMS_Handle handle, LMS_Cmd cmd, LMS_Status *status);

/*
// ===========================================================================
// LMS_delete
// Delete the LMS instance object specified by handle
*/
extern Void LMS_delete(LMS_Handle handle);

/*
// ===========================================================================
// LMS_apply
*/
extern XDAS_Void LMS_apply(LMS_Handle handle);

/*
// ===========================================================================
// LMS_setInput
*/
extern XDAS_Void LMS_setInput(LMS_Handle handle, float x);


/*
// ===========================================================================
// LMS_setDesire
*/
extern XDAS_Void LMS_setDesire(LMS_Handle handle, float d);


/*
// ===========================================================================
// LMS_getError
*/
extern float LMS_getError(LMS_Handle handle);

/*
// ===========================================================================
// LMS_getOutput
*/
extern float LMS_getOutput(LMS_Handle handle);

#endif	/* LMS_ */
