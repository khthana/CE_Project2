/*
//============================================================================
//
//    FILE NAME : LMS.c
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in LMS.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#pragma CODE_SECTION(LMS_create,  ".text:create")
#pragma CODE_SECTION(LMS_control, ".text:control")
#pragma CODE_SECTION(LMS_delete,  ".text:delete")
#pragma CODE_SECTION(LMS_init,    ".text:init")
#pragma CODE_SECTION(LMS_exit,    ".text:exit")

#include <std.h>
#include <alg.h>
#include <xdas.h>
#include "lms.h"

/*
// ===========================================================================
// LMS_create
//
//  Create an LMS instance object (using parameters specified by prms)
*/
LMS_Handle LMS_create(const ILMS_Fxns *fxns, const LMS_Params *prms)
{
    return ((LMS_Handle)ALG_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// LMS_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int LMS_control(LMS_Handle handle, LMS_Cmd cmd, LMS_Status *status)
{
    return (ALG_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// LMS_delete
//
// Delete the LMS instance object specified by handle
*/
Void LMS_delete(LMS_Handle handle)
{
    ALG_delete((IALG_Handle)handle);
}

/*
// ===========================================================================
// LMS_init
//
// LMS module initialization
*/
Void  LMS_init(Void)
{
}

/*
// ===========================================================================
// LMS_exit
//
// LMS module finalization
*/
Void  LMS_exit(Void)
{
}

/*
// ===========================================================================
// LMS_apply
*/
XDAS_Void LMS_apply(LMS_Handle handle)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->apply(handle);

    ALG_deactivate((IALG_Handle)handle);
}

/*
// ===========================================================================
// LMS_setInput
*/
XDAS_Void LMS_setInput(LMS_Handle handle, float x)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setInput(handle, x);

    ALG_deactivate((IALG_Handle)handle);

}

// ===========================================================================
// LMS_setDesire
XDAS_Void LMS_setDesire(LMS_Handle handle, float d)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setDesire(handle, d);

    ALG_deactivate((IALG_Handle)handle);
}



/*
// ===========================================================================
// LMS_getError
*/
float LMS_getError(LMS_Handle handle)
{
    float result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->getError(handle);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}

/*
// ===========================================================================
// LMS_getOutput
*/
float LMS_getOutput(LMS_Handle handle)
{
    float result;
    
    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->getOutput(handle);

    ALG_deactivate((IALG_Handle)handle);
    
    return(result);
}
