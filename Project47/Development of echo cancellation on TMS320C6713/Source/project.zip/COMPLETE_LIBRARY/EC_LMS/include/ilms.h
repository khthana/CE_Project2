/*
//============================================================================
//
//    FILE NAME : ILMS.h
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : ILMS Interface Header
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#ifndef ILMS_
#define ILMS_

#include <xdas.h>
#include <ialg.h>

/*
// ===========================================================================
// ILMS_Handle
//
// This handle is used to reference all LMS instance objects
*/
typedef struct ILMS_Obj *ILMS_Handle;

/*
// ===========================================================================
// ILMS_Obj
//
// This structure must be the first field of all LMS instance objects
*/
typedef struct ILMS_Obj {
    struct ILMS_Fxns *fxns;
} ILMS_Obj;

/*
// ===========================================================================
// ILMS_Status
//
// Status structure defines the parameters that can be changed or read
// during real-time operation of the alogrithm.
*/
typedef struct ILMS_Status {
    Int             size;  /* must be first field of all status structures */
    float *         tap_weight;
    float *         state;
    float           step;
    float           x;
    float           d;
    float           y;
    float           e;
    XDAS_UInt32     filter_length;
    XDAS_UInt32     number_norm;
    float           maxNorm;
    XDAS_UInt32     count_for_norm;
} ILMS_Status;

/*
// ===========================================================================
// ILMS_Cmd
//
// The Cmd enumeration defines the control commands for the LMS
// control method.
*/
typedef enum ILMS_Cmd {
  ILMS_GETSTATUS,
  ILMS_SETSTATUS
} ILMS_Cmd;

/*
// ===========================================================================
// ILMS_Params
//
// This structure defines the creation parameters for all LMS objects
*/
typedef struct ILMS_Params {
    Int size;	  /* must be first field of all params structures */
    float *         tap_weight;
    float *         state;
    float           step;
    float           x;
    float           d;
    float           y;
    float           e;
    XDAS_UInt32     filter_length;
    XDAS_UInt32     number_norm;    
    float           maxNorm;
    XDAS_UInt32     count_for_norm;
} ILMS_Params;

/*
// ===========================================================================
// ILMS_PARAMS
//
// Default parameter values for LMS instance objects
*/
extern ILMS_Params ILMS_PARAMS;

/*
// ===========================================================================
// ILMS_Fxns
//
// This structure defines all of the operations on LMS objects
*/
typedef struct ILMS_Fxns {
    IALG_Fxns	ialg;    /* ILMS extends IALG */
    XDAS_Void (*apply)(ILMS_Handle handle);
    XDAS_Void (*setInput)(ILMS_Handle handle, float x);  
    XDAS_Void (*setDesire)(ILMS_Handle handle, float d);
    float (*getError)(ILMS_Handle handle);
    float (*getOutput)(ILMS_Handle handle);
} ILMS_Fxns;

#endif	/* ILMS_ */
