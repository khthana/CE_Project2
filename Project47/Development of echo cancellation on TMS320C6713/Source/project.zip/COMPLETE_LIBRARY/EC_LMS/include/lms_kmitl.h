/*
//============================================================================
//
//    FILE NAME : LMS_KMITL.h
//
//    ALGORITHM : LMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Interface for the LMS_KMITL module; KMITL's implementation
//                of the ILMS interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//============================================================================
*/

#ifndef LMS_KMITL_
#define LMS_KMITL_

#include "ilms.h"
#include <ialg.h>

/*
//============================================================================
// LMS_KMITL_IALG
//
// KMITL's implementation of the IALG interface for LMS
*/
extern far IALG_Fxns LMS_KMITL_IALG;

/*
//============================================================================
// LMS_KMITL_ILMS
//
// KMITL's implementation of the ILMS interface
*/
extern far ILMS_Fxns LMS_KMITL_ILMS;

/*
//============================================================================
// LMS_KMITL_init
//
// Initialize the LMS_KMITL module as a whole
*/
extern Void LMS_KMITL_init(Void);

/*
//============================================================================
// LMS_KMITL_exit
//
// Exit the LMS_KMITL module as a whole
*/
extern Void LMS_KMITL_exit(Void);

#endif	/* LMS_KMITL_ */
