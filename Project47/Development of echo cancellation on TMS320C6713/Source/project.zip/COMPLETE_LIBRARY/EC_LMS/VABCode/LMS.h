//============================================================================
//
//    FILE NAME : LMS.h
//
//    BLOCK NAME: LMS
//
//    GROUP NAME: Default Group
//
//    PURPOSE:    Header file for the block: LMS.DLL
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Creation Date: Mon - 07 February 2005
//    Creation Time: 10:45 PM
//
//    Copyright (C) 1992, 2005 Hyperception, All rights reserved
//
//============================================================================
//    NOTE: Do not modify lines starting with "//;".  This information is
//          required by the C Code Generator for block importing.
//============================================================================

#ifdef RC_INVOKED
#define ID(id) id
#else
#define ID(id) MAKEINTRESOURCE(id)
#endif

//============================================================================
//   Include Files
//============================================================================
#include "hresourc.h"
#include "resource.h"
#include "bddrv.h"

//============================================================================
//   Definitions
//============================================================================
// menu and block names 
#define MNAME   "LMS"
#define GNAME   "Default Group"
#define LNAME   "eXpressDSP Library"
#define BFNAME  "LMS"
#define BINAME  "LIS"

// Whenever VERSION is changed, IDS_REV_NUMBER in the *.rc file should also be changed
#define VERSION "4.00"

//; Definitions
//; End of Definitions

// Number of user parameters
#define NUM_PARAMS   10

//---------------------------------------------------------------------------
// The following two definitions identify the size (in addresses) of the     
// block's DSP parameters and internal (persistent-storage) variables.       
//---------------------------------------------------------------------------
// NOTE: The parameter size (PARAMS_SIZE) definition below is the size of    
//       parameter space to reserve in DSP memory.  In most cases, the size  
//       will be the same as NUM_PARAMS.  However, since the TEXT and FILE   
//       types are not applicable to the DSP, PARAM_SIZE may be less than    
//       NUM_PARAMS.                                                         
//---------------------------------------------------------------------------
#define PARAMS_SIZE   8


// Miscellaneous definitions
#define TEXT_LENGTH   256


//============================================================================
//   Structure Definitions
//============================================================================

typedef struct
{
//; Block Parameter Structure

//------------------------------------------------------------------------------
//  General Block Information
//------------------------------------------------------------------------------
    int           Precision;
    int           LocalError;
    unsigned long Framesize;

//------------------------------------------------------------------------------
//  User Parameters                                                             
//------------------------------------------------------------------------------
    float         _step;
    float         _x;
    float         _d;
    float         _y;
    float         _e;
    long          _filter_length;
    float         _maxNorm;
    long          _count_for_norm;

//------------------------------------------------------------------------------
//  Real-Time Driver Support Information
//------------------------------------------------------------------------------
    char          DriverName[16];   // driver name (no path)
    BYTE          RunMode;          // run mode


//------------------------------------------------------------------------------
// Any user-added variables that are added to the BLOCK_PARAM structure should
// be added between the following tags so they can be included in future
// versions of this block.
//------------------------------------------------------------------------------
//; Added Variables
//; End of Added Variables

//; End of Block Parameter Structure
} BLOCK_PARAM;

//---------------------------------------------------------------------------
//  The parameter structure below is used to store temporary or scratch
//  information that is only required by the block during the life of the
//  current worksheet.  This information is not stored to disk for use with
//  other worksheets.  User-added variables that are only valid during the
//  life of a worksheet, such as handles, should be added at the end of this
//  structure.
//---------------------------------------------------------------------------
typedef struct
{
//; Scratch Parameter Structure

//------------------------------------------------------------------------------
//  Real-Time Parameter Structure and Driver Handles
//------------------------------------------------------------------------------
    HANDLE        hRTParam;            // handle to real-time block structure
    HINSTANCE     hDriver;             // handle to DSP board driver
    FARPROC       lpfnRideSendCommand; // pointer to RIDE driver command handler


//------------------------------------------------------------------------------
// Any user-added variables that are added to the SCRATCH_PARAM structure should
// be added between the following tags so they can be included in future
// versions of this block.
//------------------------------------------------------------------------------
//; Added Variables
    HBITMAP       hBitmap;
    BITMAP        Bitmap;
//; End of Added Variables
//; End of Scratch Parameter Structure

} SCRATCH_PARAM;


//============================================================================
//   Function Prototypes
//============================================================================

//------------------------------------------------------------------------------
//  Block DLL Interface Functions
//------------------------------------------------------------------------------
int  PASCAL UserSetupProc(HANDLE *, HANDLE *);
int  PASCAL UserDefaultSetupProc(HANDLE, HANDLE);
int  PASCAL UserPreInitializeProc(HANDLE,HANDLE, HANDLE);
int  PASCAL UserInitializeProc(HANDLE,HANDLE, HANDLE);
int  PASCAL UserRTCompileProc(HANDLE, HANDLE, HANDLE, int);
int  PASCAL UserExecProc(HANDLE,HANDLE, HANDLE);
int  PASCAL UserExitProc(HANDLE,HANDLE, HANDLE);
int  PASCAL UserResetProc(HANDLE,HANDLE, HANDLE);
BOOL PASCAL UserDialogProc(HWND,UINT,WPARAM,LPARAM);
int  PASCAL UserSaveProc(HANDLE, HANDLE, LPSTR, LPSTR);
int  PASCAL UserLoadProc(HANDLE, HANDLE, LPSTR, LPSTR);
void PASCAL UserGetParameterListProc(HWND);
int  PASCAL UserSetParameterProc(HANDLE,HANDLE,DWORD,void *);

//------------------------------------------------------------------------------
//  Static Functions
//------------------------------------------------------------------------------
static int PASCAL DownloadDSPParameters(BLOCK_PARAM *, SCRATCH_PARAM *);


//------------------------------------------------------------------------------
//  Block's Data Processing Routines
//------------------------------------------------------------------------------
int  PASCAL LMSFloat(HANDLE, HANDLE);

//============================================================================
//  NOTE: User-added routine (function) prototypes should be placed in the
//        following section.
//============================================================================


//; External Routine Prototypes

//; End of External Routine Prototypes
