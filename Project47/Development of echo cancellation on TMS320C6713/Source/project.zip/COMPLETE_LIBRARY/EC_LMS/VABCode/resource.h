#ifndef resource_h
#define resource_h
//==========================================================================
// RESOURCE.H
// Resource Header file for Hypersignal Auto-Generated Block DLL                     
// Component Wizard for eXpressDSP generated include file.
//===========================================================================



#endif
