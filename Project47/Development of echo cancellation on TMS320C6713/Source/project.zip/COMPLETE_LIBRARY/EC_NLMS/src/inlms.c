/*
//============================================================================
//
//    FILE NAME : INLMS.c
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iNLMS.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "inlms.h"

/*
// ===========================================================================
// NLMS_PARAMS
//
// This constant structure defines the default parameters for NLMS objects
*/
INLMS_Params INLMS_PARAMS = {
    sizeof(INLMS_Params),
    NULL, /* tap_weight */
    NULL, /* state */
    0.8, /* step */
    0.001, /* offset */
    0, /* x */
    0, /* d */
    0, /* e */
    0, /* y */
    0, /* Ee */
    0, /* Eu */
    0.999, /* gramma */
    3, /* delay */
    32, /* filter_length */
};
