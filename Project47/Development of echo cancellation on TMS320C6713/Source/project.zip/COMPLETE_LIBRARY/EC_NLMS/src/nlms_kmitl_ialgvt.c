/*
//============================================================================
//
//    FILE NAME : NLMS_KMITL_ialgvt.c
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the NLMS_KMITL module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#include <std.h>
#include "inlms.h"

#include "nlms_kmitl.h"

extern Int  NLMS_KMITL_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  NLMS_KMITL_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  NLMS_KMITL_free(IALG_Handle, IALG_MemRec *);
extern Int  NLMS_KMITL_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  NLMS_KMITL_numAlloc(Void);
extern Void NLMS_KMITL_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
/*
// The NLMS_KMITL_activate & NLMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
extern Void NLMS_KMITL_activate(IALG_Handle);
extern Void NLMS_KMITL_deactivate(IALG_Handle);
*/
extern XDAS_Void NLMS_KMITL_apply(INLMS_Handle handle);
extern XDAS_Void NLMS_KMITL_setInput(INLMS_Handle handle, float x);
extern XDAS_Void NLMS_KMITL_setDesire(INLMS_Handle handle, float d);
extern float NLMS_KMITL_getOutput(INLMS_Handle handle);
extern float NLMS_KMITL_getError(INLMS_Handle handle);
extern XDAS_Void NLMS_KMITL_setInputDesire(INLMS_Handle handle, float x, float d);

#define IALGFXNS \
    &NLMS_KMITL_IALG,       /* module ID                            */ \
    NULL,                   /* activate   (NULL => not suported)    */ \
    NLMS_KMITL_alloc,       /* algAlloc                             */ \
    NLMS_KMITL_control,     /* control    (NULL => not suported)    */ \
    NULL,                   /* deactivate (NULL => not suported)    */ \
    NLMS_KMITL_free,        /* free                                 */ \
    NLMS_KMITL_initObj,     /* init                                 */ \
    NLMS_KMITL_moved,       /* moved      (NULL => not suported)    */ \
    NULL                    /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// NLMS_KMITL_INLMS
//
// This structure defines KMITL's implementation of the INLMS interface
// for the NLMS_KMITL module.
*/
INLMS_Fxns NLMS_KMITL_INLMS = {	/* module_vendor_interface */
    IALGFXNS,
    NLMS_KMITL_apply,
    NLMS_KMITL_setInput,
    NLMS_KMITL_setDesire,
    NLMS_KMITL_getOutput,
    NLMS_KMITL_getError,
    NLMS_KMITL_setInputDesire,
};

/*
//============================================================================
// NLMS_KMITL_IALG
//
// This structure defines KMITL's implementation of the IALG interface
// for the NLMS_KMITL module.
*/
#ifdef _TI_
asm("_NLMS_KMITL_IALG .set _NLMS_KMITL_INLMS");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns NLMS_KMITL_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
