/*
//============================================================================
//
//    FILE NAME : NLMS_KMITL_ialg.c
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the NLMS_KMITL.h interface; KMITL's
//                implementation of the INLMS interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#pragma CODE_SECTION(NLMS_KMITL_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(NLMS_KMITL_free,       ".text:algFree")
#pragma CODE_SECTION(NLMS_KMITL_initObj,    ".text:algInit")
#pragma CODE_SECTION(NLMS_KMITL_control,    ".text:algControl")
#pragma CODE_SECTION(NLMS_KMITL_init,       ".text:init")
#pragma CODE_SECTION(NLMS_KMITL_exit,       ".text:exit")
#pragma CODE_SECTION(NLMS_KMITL_moved,      ".text:algMoved")
/*
// The NLMS_KMITL_activate & NLMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(NLMS_KMITL_activate,   ".text:algActivate")
#pragma CODE_SECTION(NLMS_KMITL_deactivate, ".text:algDeactivate")
*/

#include <std.h>
#include <limits.h>
#include "inlms.h"
#include "nlms_kmitl.h"

#define HLOCALBUFFER0 1
#define HLOCALBUFFER1 2
#define MTAB_NRECS 3
#define HLOCALBUFFER0_SIZE 1000
#define HLOCALBUFFER1_SIZE 1000


void adaptnlms(INLMS_Handle handle);
float filter(INLMS_Handle handle);
void updateMu(INLMS_Handle handle);
/*
//============================================================================
// NLMS_KMITL_Obj
*/
typedef struct NLMS_KMITL_Obj {
    IALG_Obj        alg;   /* MUST be first field of all NLMS objs */
    float *         tap_weight;
    float *         state;
    float           step;
    float           offset;
    float           x;
    float           d;
    float           e;
    float           y;
    float           Ee;
    float           Eu;
    float           gramma;
    float           delay;
    XDAS_Int32      filter_length;
    XDAS_Int32      *hLocalBuffer0;
    XDAS_Int32      *hLocalBuffer1;

    /* TODO: add custom fields here */
} NLMS_KMITL_Obj;

/*
//============================================================================
// NLMS_KMITL_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the NLMS_KMITL processing methods.
*/
/*
// The NLMS_KMITL_activate & NLMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void NLMS_KMITL_activate(IALG_Handle handle)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;
    
    // TODO: implement algActivate
}
*/

/*
//============================================================================
// NLMS_KMITL_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a NLMS_KMITL_Obj structure.
*/
Int NLMS_KMITL_alloc(const IALG_Params *NLMSParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const INLMS_Params *params = (Void *)NLMSParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &INLMS_PARAMS;  /* set default parameters */
    }

    /* Request memory for NLMS object */
    memTab[0].size = sizeof(NLMS_KMITL_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;

    // NOTE: Some algorithms may be better suited to use an equation to define memtab
    //       size(s). User may want to modify the size field as required by his algorithm.

    /* Request memory for hLocalBuffer0 array */
    memTab[HLOCALBUFFER0].size = (params->filter_length) * sizeof(float);
    memTab[HLOCALBUFFER0].alignment = (0 * 8) / CHAR_BIT;
    memTab[HLOCALBUFFER0].space = IALG_EXTERNAL;
    memTab[HLOCALBUFFER0].attrs = IALG_PERSIST;

    /* Request memory for hLocalBuffer1 array */
    memTab[HLOCALBUFFER1].size = (params->filter_length) * sizeof(float);
    memTab[HLOCALBUFFER1].alignment = (0 * 8) / CHAR_BIT;
    memTab[HLOCALBUFFER1].space = IALG_EXTERNAL;
    memTab[HLOCALBUFFER1].attrs = IALG_PERSIST;

    return (MTAB_NRECS);
}

/*
//============================================================================
// NLMS_KMITL_control
//
// Control our object's parameters while the algorithm is running
*/
Int NLMS_KMITL_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    INLMS_Status *sPtr = (INLMS_Status *)status;	
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    switch ((INLMS_Cmd)cmd) {

       case INLMS_GETSTATUS:
            sPtr->tap_weight = NLMS->tap_weight;
            sPtr->state = NLMS->state;
            sPtr->step = NLMS->step;
            sPtr->offset = NLMS->offset;
            sPtr->x = NLMS->x;
            sPtr->d = NLMS->d;
            sPtr->e = NLMS->e;
            sPtr->y = NLMS->y;
            sPtr->Ee = NLMS->Ee;
            sPtr->Eu = NLMS->Eu;
            sPtr->gramma = NLMS->gramma;
            sPtr->delay = NLMS->delay;
            sPtr->filter_length = NLMS->filter_length;

            return(IALG_EOK);

       case INLMS_SETSTATUS:
            NLMS->tap_weight = sPtr->tap_weight;
            NLMS->state = sPtr->state;
            NLMS->step = sPtr->step;
            NLMS->offset = sPtr->offset;
            NLMS->x = sPtr->x;
            NLMS->d = sPtr->d;
            NLMS->e = sPtr->e;
            NLMS->y = sPtr->y;
            NLMS->Ee = sPtr->Ee;
            NLMS->Eu = sPtr->Eu;
            NLMS->gramma = sPtr->gramma;
            NLMS->delay = sPtr->delay;
            NLMS->filter_length = sPtr->filter_length;

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// NLMS_KMITL_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the NLMS_KMITL processing methods to persistent memory.
*/
/*
// The NLMS_KMITL_activate & NLMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void NLMS_KMITL_deactivate(IALG_Handle handle)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;
    
    // TODO: implement algDeactivate
}
*/

/*
//============================================================================
// NLMS_KMITL_exit
//
// Exit the NLMS_KMITL module as a whole.
 */
Void NLMS_KMITL_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// NLMS_KMITL_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// NLMS_KMITL_alloc operation above.
*/
Int NLMS_KMITL_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    n = NLMS_KMITL_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[HLOCALBUFFER0].base = NLMS->hLocalBuffer0;
    memTab[HLOCALBUFFER1].base = NLMS->hLocalBuffer1;

    return (n);
}

/*
//============================================================================
// NLMS_KMITL_init
//
// Initialize the NLMS_KMITL module as a whole.
*/
Void NLMS_KMITL_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// NLMS_KMITL_initObj
//
// Initialize the memory allocated for our instance.
*/
Int NLMS_KMITL_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *NLMSParams)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;
    const INLMS_Params *params = (Void *)NLMSParams;
	int i;
    if(params == NULL){
        params = &INLMS_PARAMS; /* set default parameters */
    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
 NLMS->tap_weight = params->tap_weight;
    NLMS->state = params->state;
    NLMS->step = params->step;
    NLMS->offset = params->offset;
    NLMS->x = params->x;
    NLMS->d = params->d;
    NLMS->e = params->e;
    NLMS->y = params->y;
    NLMS->Ee = params->Ee;
    NLMS->Eu = params->Eu;
    NLMS->gramma = params->gramma;
    NLMS->delay = params->delay;
    NLMS->filter_length = params->filter_length;
    NLMS->hLocalBuffer0 = memTab[HLOCALBUFFER0].base;
    NLMS->hLocalBuffer1 = memTab[HLOCALBUFFER1].base;

    /* TODO: Implement any additional algInit desired */
	for(i = 0;i<params->filter_length;i++)
    {
    	if(i<NLMS->delay)
    		NLMS->tap_weight[i] = 0.001;
    	else
    		NLMS->tap_weight[i] = 0; 
    		
    	NLMS->state[i] = 0;
    	
    }    
  	
    
    return (IALG_EOK);
}

/*
//============================================================================
// NLMS_KMITL_moved
//
// Adjust any data pointers that has been moved by the client.
*/
Void NLMS_KMITL_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *NLMSParams)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;
//    const INLMS_Params *params = (Void *)NLMSParams;

    NLMS->hLocalBuffer0 = memTab[HLOCALBUFFER0].base;
    NLMS->hLocalBuffer1 = memTab[HLOCALBUFFER1].base;
}

/*
//============================================================================
// NLMS_KMITL_apply
// KMITL's implementation of the apply operation.
// Custom fields of the NLMS_KMITL_Obj may be accessed as follows:
//     NLMS->tap_weight = ...;
//     NLMS->state = ...;
//     NLMS->step = ...;
//     NLMS->offset = ...;
//     NLMS->x = ...;
//     NLMS->d = ...;
//     NLMS->e = ...;
//     NLMS->y = ...;
//     NLMS->Ee = ...;
//     NLMS->Eu = ...;
//     NLMS->gramma = ...;
//     NLMS->filter_length = ...;
//     NLMS->hLocalBuffer0 = ...;
//     NLMS->hLocalBuffer1 = ...;
*/
XDAS_Void NLMS_KMITL_apply(INLMS_Handle handle)
{
 //   NLMS_KMITL_Obj *NLMS = (Void *)handle;

    /* TODO: implement apply */
	
	adaptnlms(handle);				
	updateMu(handle);
    
    /*
    int index;
    for(index=0; index<NLMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// NLMS_KMITL_setInput
// KMITL's implementation of the setInput operation.
// Custom fields of the NLMS_KMITL_Obj may be accessed as follows:
//     NLMS->tap_weight = ...;
//     NLMS->state = ...;
//     NLMS->step = ...;
//     NLMS->offset = ...;
//     NLMS->x = ...;
//     NLMS->d = ...;
//     NLMS->e = ...;
//     NLMS->y = ...;
//     NLMS->Ee = ...;
//     NLMS->Eu = ...;
//     NLMS->gramma = ...;
//     NLMS->filter_length = ...;
//     NLMS->hLocalBuffer0 = ...;
//     NLMS->hLocalBuffer1 = ...;
*/
XDAS_Void NLMS_KMITL_setInput(INLMS_Handle handle, float x)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    /* TODO: implement setInput */
	NLMS->x = x;
    /*
    int index;
    for(index=0; index<NLMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// NLMS_KMITL_setDesire
// KMITL's implementation of the setDesire operation.
// Custom fields of the NLMS_KMITL_Obj may be accessed as follows:
//     NLMS->tap_weight = ...;
//     NLMS->state = ...;
//     NLMS->step = ...;
//     NLMS->offset = ...;
//     NLMS->x = ...;
//     NLMS->d = ...;
//     NLMS->e = ...;
//     NLMS->y = ...;
//     NLMS->Ee = ...;
//     NLMS->Eu = ...;
//     NLMS->gramma = ...;
//     NLMS->filter_length = ...;
//     NLMS->hLocalBuffer0 = ...;
//     NLMS->hLocalBuffer1 = ...;
*/
XDAS_Void NLMS_KMITL_setDesire(INLMS_Handle handle, float d)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    /* TODO: implement setDesire */
	NLMS->d = d;
    /*
    int index;
    for(index=0; index<NLMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// NLMS_KMITL_getOutput
// KMITL's implementation of the getOutput operation.
// Custom fields of the NLMS_KMITL_Obj may be accessed as follows:
//     NLMS->tap_weight = ...;
//     NLMS->state = ...;
//     NLMS->step = ...;
//     NLMS->offset = ...;
//     NLMS->x = ...;
//     NLMS->d = ...;
//     NLMS->e = ...;
//     NLMS->y = ...;
//     NLMS->Ee = ...;
//     NLMS->Eu = ...;
//     NLMS->gramma = ...;
//     NLMS->filter_length = ...;
//     NLMS->hLocalBuffer0 = ...;
//     NLMS->hLocalBuffer1 = ...;
*/
float NLMS_KMITL_getOutput(INLMS_Handle handle)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    /* TODO: implement getOutput */

    /*
    int index;
    for(index=0; index<NLMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */

    return((float)NLMS->y);
}

/*
//============================================================================
// NLMS_KMITL_getError
// KMITL's implementation of the getError operation.
// Custom fields of the NLMS_KMITL_Obj may be accessed as follows:
//     NLMS->tap_weight = ...;
//     NLMS->state = ...;
//     NLMS->step = ...;
//     NLMS->offset = ...;
//     NLMS->x = ...;
//     NLMS->d = ...;
//     NLMS->e = ...;
//     NLMS->y = ...;
//     NLMS->Ee = ...;
//     NLMS->Eu = ...;
//     NLMS->gramma = ...;
//     NLMS->filter_length = ...;
//     NLMS->hLocalBuffer0 = ...;
//     NLMS->hLocalBuffer1 = ...;
*/
float NLMS_KMITL_getError(INLMS_Handle handle)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    /* TODO: implement getError */

    /*
    int index;
    for(index=0; index<NLMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */

    return((float)NLMS->e);
}

/*
//============================================================================
// NLMS_KMITL_setInputDesire
// KMITL's implementation of the setInputDesire operation.
// Custom fields of the NLMS_KMITL_Obj may be accessed as follows:
//     NLMS->tap_weight = ...;
//     NLMS->state = ...;
//     NLMS->step = ...;
//     NLMS->offset = ...;
//     NLMS->x = ...;
//     NLMS->d = ...;
//     NLMS->e = ...;
//     NLMS->y = ...;
//     NLMS->Ee = ...;
//     NLMS->Eu = ...;
//     NLMS->gramma = ...;
//     NLMS->filter_length = ...;
//     NLMS->hLocalBuffer0 = ...;
//     NLMS->hLocalBuffer1 = ...;
*/
XDAS_Void NLMS_KMITL_setInputDesire(INLMS_Handle handle, float x, float d)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;

    /* TODO: implement setInputDesire */
	NLMS->x = x;
	NLMS->d = d;
    /*
    int index;
    for(index=0; index<NLMS->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

void adaptnlms(INLMS_Handle handle)
{
    NLMS_KMITL_Obj *NLMS = (Void *)handle;
	int i; 
	NLMS->y = filter(handle);
	NLMS->e = NLMS->d - NLMS->y;
	//======= Update Weight vector =========
	for(i = 0; i<NLMS->filter_length; i++)
	{
		NLMS->tap_weight[i] += NLMS->step * NLMS->state[i] * NLMS->e ;
	}
}

float filter(INLMS_Handle handle)
{
	NLMS_KMITL_Obj *NLMS = (Void *)handle;

	float y;
	int i;
	
	float *U = (float*)malloc(sizeof(float)*NLMS->filter_length) ;
	
	for(i = 0; i<NLMS->filter_length; i++)
	{
		U[i] = 0;
	}
	
	y = 0;
	
	// Fill value in temp
	for(i = 0; i<NLMS->filter_length; i++)
	{
		if(i == 0)
			U[i] = NLMS->x ;
		else
			U[i] = NLMS->state[i-1]; 
	}
	
	// Convolutoin
	for(i = 0; i<NLMS->filter_length; i++)
	{
		y +=  NLMS->tap_weight[i] * U[i]; 
	}
	
	//============== Shif filter state========
	for(i = 0; i<NLMS->filter_length; i++)
	{
		 NLMS->state[i] = U[i]; 
	}	
	
	free(U);
	return ((float)y);
}
//#####################
void updateMu(INLMS_Handle handle)
{
	
	NLMS_KMITL_Obj *NLMS = (Void *)handle;

	float norm = 0,W = 0,muH = 0,D=0;
	
	int i;
	for(i = 0; i<NLMS->filter_length; i++)
	{ 
		norm = norm + (NLMS->state[i] * NLMS->state[i]);
	}
	
	NLMS->Eu = (1 - NLMS->gramma) * (NLMS->x * NLMS->x) + (NLMS->gramma * NLMS->Eu); 
	NLMS->Ee = (1 - NLMS->gramma) * (NLMS->e * NLMS->e) + (NLMS->gramma * NLMS->Ee); 
	
	for(i = 0;i<NLMS->delay; i++)
	{
		W = W + (NLMS->tap_weight[i]*NLMS->tap_weight[i]);
	}
	
	D = (NLMS->filter_length/NLMS->delay)*W;
	muH = NLMS->Eu*D / NLMS->Ee;

	if(muH>1)
		muH=1;
		
	NLMS->step = muH/(norm+NLMS->offset);
	
	
}
