/*
//============================================================================
//
//    FILE NAME : INLMS.h
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : INLMS Interface Header
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#ifndef INLMS_
#define INLMS_

#include <xdas.h>
#include <ialg.h>

/*
// ===========================================================================
// INLMS_Handle
//
// This handle is used to reference all NLMS instance objects
*/
typedef struct INLMS_Obj *INLMS_Handle;

/*
// ===========================================================================
// INLMS_Obj
//
// This structure must be the first field of all NLMS instance objects
*/
typedef struct INLMS_Obj {
    struct INLMS_Fxns *fxns;
} INLMS_Obj;

/*
// ===========================================================================
// INLMS_Status
//
// Status structure defines the parameters that can be changed or read
// during real-time operation of the alogrithm.
*/
typedef struct INLMS_Status {
    Int             size;  /* must be first field of all status structures */
    float *         tap_weight;
    float *         state;
    float           step;
    float           offset;
    float           x;
    float           d;
    float           e;
    float           y;
    float           Ee;
    float           Eu;
    float           gramma;
    XDAS_Int32	    delay;
    XDAS_Int32      filter_length;
} INLMS_Status;

/*
// ===========================================================================
// INLMS_Cmd
//
// The Cmd enumeration defines the control commands for the NLMS
// control method.
*/
typedef enum INLMS_Cmd {
  INLMS_GETSTATUS,
  INLMS_SETSTATUS
} INLMS_Cmd;

/*
// ===========================================================================
// INLMS_Params
//
// This structure defines the creation parameters for all NLMS objects
*/
typedef struct INLMS_Params {
    Int size;	  /* must be first field of all params structures */
    float *         tap_weight;
    float *         state;
    float           step;
    float           offset;
    float           x;
    float           d;
    float           e;
    float           y;
    float           Ee;
    float           Eu;
    float           gramma;
    XDAS_Int32      delay;
    XDAS_Int32      filter_length;
} INLMS_Params;

/*
// ===========================================================================
// INLMS_PARAMS
//
// Default parameter values for NLMS instance objects
*/
extern INLMS_Params INLMS_PARAMS;

/*
// ===========================================================================
// INLMS_Fxns
//
// This structure defines all of the operations on NLMS objects
*/
typedef struct INLMS_Fxns {
    IALG_Fxns	ialg;    /* INLMS extends IALG */
    XDAS_Void (*apply)(INLMS_Handle handle);
    XDAS_Void (*setInput)(INLMS_Handle handle, float x);
    XDAS_Void (*setDesire)(INLMS_Handle handle, float d);
    float (*getOutput)(INLMS_Handle handle);
    float (*getError)(INLMS_Handle handle);
    XDAS_Void (*setInputDesire)(INLMS_Handle handle, float x, float d);
} INLMS_Fxns;

#endif	/* INLMS_ */
