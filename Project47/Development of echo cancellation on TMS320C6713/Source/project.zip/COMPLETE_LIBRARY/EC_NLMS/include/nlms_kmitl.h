/*
//============================================================================
//
//    FILE NAME : NLMS_KMITL.h
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Interface for the NLMS_KMITL module; KMITL's implementation
//                of the INLMS interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#ifndef NLMS_KMITL_
#define NLMS_KMITL_

#include "inlms.h"
#include <ialg.h>

/*
//============================================================================
// NLMS_KMITL_IALG
//
// KMITL's implementation of the IALG interface for NLMS
*/
extern far IALG_Fxns NLMS_KMITL_IALG;

/*
//============================================================================
// NLMS_KMITL_INLMS
//
// KMITL's implementation of the INLMS interface
*/
extern far INLMS_Fxns NLMS_KMITL_INLMS;

/*
//============================================================================
// NLMS_KMITL_init
//
// Initialize the NLMS_KMITL module as a whole
*/
extern Void NLMS_KMITL_init(Void);

/*
//============================================================================
// NLMS_KMITL_exit
//
// Exit the NLMS_KMITL module as a whole
*/
extern Void NLMS_KMITL_exit(Void);

#endif	/* NLMS_KMITL_ */
