#include <stdio.h>
#include <std.h>
#include "nlms.h"
#include "nlms_kmitl.h"

#define FILTER_LENGTH 1000 
#define DELAY 100/* = 10 % of weight*/
#define GRAMMA 0.999/*Between [0.9 - 0.999]*/
#define OFFSET 0.001
#define CHANNAL 1	// Multichannal

float coff[CHANNAL][FILTER_LENGTH]; 
float sta[CHANNAL][FILTER_LENGTH];
float x[CHANNAL],d[CHANNAL],y[CHANNAL],e[CHANNAL];


float input,desire; // for fill in from fileIO
float input2,desire2; // for fill in from fileIO
float err,output;


void dataIO()
{
}

void main(){

    //---------- Define Parameter ----------//
    NLMS_Handle  handle[CHANNAL];
    INLMS_Fxns   fxns;
    NLMS_Params  params;

	int i,j ;
	//---------- Initial Values Object ----//
	for(i = 0;i<CHANNAL;i++)
	{	
		for(j = 0;j<FILTER_LENGTH;j++)
		{
			coff[i][j] = 0;
			sta[i][j] = 0;
		}
	}
	//-------- Init Value to Params -----//
	
	for(i = 0; i<CHANNAL; i++)
	{
	    //fxns = LMS_KMITL_ILMS;
		//params = LMS_PARAMS;
		//params.filter_length = FILTER_LENGTH;
		//params.number_norm = NUM_FIND_NORM;				
		fxns = NLMS_KMITL_INLMS;
	    params = NLMS_PARAMS;
	    params.delay = DELAY;
	    params.filter_length = FILTER_LENGTH;
	    params.gramma = GRAMMA;
	    params.offset = OFFSET;
	    params.step = 0.8;
    
		for(j=0;j<FILTER_LENGTH;j++)
		{
			params.tap_weight = coff[i];
	    	params.state = sta[i];
	    }	    		    
     	NLMS_init();
	    handle[i] = NLMS_create(&fxns, &params);
	 }
	 
	//------------ Apply ----------------//
    while(1){  
    	int flag = 1;    
      	dataIO();//Initial value to input and desire variable;
      	for(i = 0; i<CHANNAL; i++)
      	{
      		if(CHANNAL>1){
      			if(flag==1)
      			{
      				x[i] = input;
      				d[i] = desire;
      				flag = 0;
      			}else{
	      			x[i] = input2;
    	  			d[i] = desire2;
      				flag = 1;
      			}
      		}
      		else{
      			x[i] = input;
      			d[i] = desire;
      		}
      	}
      	
      	for(i = 0; i<CHANNAL; i++)
        {
        	NLMS_setInput(handle[i],x[i]);
			NLMS_setDesire(handle[i],d[i]);
			NLMS_apply(handle[i]);
			y[i] = NLMS_getOutput(handle[i]);
			e[i] = NLMS_getError(handle[i]);		
			err = e[i];
		}
	}
    
    //-------- Destroy handle object -----//
    //for(i = 0; i<CHANNAL; i++)
    //	 LMS_delete(handle[i]);
//    LMS_exit();
}
/*
	
	for(i = 0;i<FILTER_LENGTH;i++)
	{
		coff[i] = 0;
		sta[i] = 0;
		coff2[i] = 0;
		sta2[i] = 0;
	}
	
	
    fxns = NLMS_KMITL_INLMS;
    params = NLMS_PARAMS;
    params.delay = DELAY;
    params.filter_length = FILTER_LENGTH;
    params.gramma = GRAMMA;
    params.offset = OFFSET;
    params.tap_weight = coff;
    params.state = sta;
    params.step = 0.8;

    NLMS_init();
    
    handle = NLMS_create(&fxns, &params);
    
    fxns = NLMS_KMITL_INLMS;
    params = NLMS_PARAMS;
    params.delay = DELAY;
    params.filter_length = FILTER_LENGTH;
    params.gramma = GRAMMA;
    params.offset = OFFSET;
    params.tap_weight = coff2;
    params.state = sta2;
    params.step = 0.8;

    NLMS_init();
    
    handle2 = NLMS_create(&fxns, &params);
    
    //if((handle = NLMS_create(&fxns, &params)) != NULL){
         while(1)
		{
			dataIO();	// read input from file fill in x and d
			NLMS_setInput(handle,x);
			NLMS_setDesire(handle,d);
			
			NLMS_apply(handle);
			
			y = NLMS_getOutput(handle);
			e = NLMS_getError(handle);
			
			//--------------
			dataIO();	// read input from file fill in x and d
			NLMS_setInput(handle2,x2);
			NLMS_setDesire(handle2,d2);
			
			NLMS_apply(handle2);
			
			y2 = NLMS_getOutput(handle2);
			e2 = NLMS_getError(handle2);
			
		}

        //NLMS_delete(handle);
    ///}
   // NLMS_exit();
}
*/

