/*
//============================================================================
//
//    FILE NAME : _NLMS.c
//
//    BLOCK NAME: NLMS
//
//    GROUP NAME: Default Group
//
//    PURPOSE   : Provides the real-time block's DSP C source code.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#include "_nlms.h"

#pragma DATA_SECTION(Params, ".hyper:ignore")
PARAMS Params;

/*----------------------------------------------------------------------------*/
/*               Optional real-time block interrupt routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called in response to a selected  */
/* DSP interrupt.  If this routine in not activated, the main block routine   */
/* will be called in response to a selected DSP interrupt.                    */
/*----------------------------------------------------------------------------*/
/*
void NLMS_INT(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*               Optional real-time block initialization routine              */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called one time before the main   */
/* application begins.  This allows for any required software or hardware     */
/* initialization to be performed before the block executes.                  */
/*----------------------------------------------------------------------------*/

static INLMS_Fxns   fxns;
static NLMS_Params  params;

void NLMS_INIT(PARAMS *pPtr)
{
    fxns = NLMS_KMITL_INLMS;
    params = NLMS_PARAMS;

    params.step = pPtr->_step;
    params.offset = pPtr->_offset;
    params.x = pPtr->_x;
    params.d = pPtr->_d;
    params.e = pPtr->_e;
    params.y = pPtr->_y;
    params.Ee = pPtr->_Ee;
    params.Eu = pPtr->_Eu;
    params.gramma = pPtr->_gramma;
    params.delay = pPtr->_delay;
    params.filter_length = pPtr->_filter_length;

    pPtr->handle = NLMS_create(&fxns, &params);
}


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block stop routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever the block diagram */
/* worksheet's execution is stopped.  Blocks that deal with hardware may need */
/* this routine to stop the hardware's execution.                             */
/*----------------------------------------------------------------------------*/
/*
void NLMS_STOP(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block restart routine                */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever a block diagram   */
/* worksheet is executed after being stopped.  Blocks that deal with hardware */
/* may need this routine to restart the hardware's execution.                 */
/*----------------------------------------------------------------------------*/
/*
void NLMS_RESTART(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                           Real-time block routine                          */
/*----------------------------------------------------------------------------*/
/* This is the main block routine.  It is called during each loop of the main */
/* application.  If an interrupt is selected, and the interrupt routine above */
/* is not activated, this routine will be called in response to the selected  */
/* interrupt instead of during the main application loop.                     */
/* Custom fields of the pPtr structure may be accessed as follows:            */
/*     pPtr->_step = ...;                                                     */
/*     pPtr->_offset = ...;                                                   */
/*     pPtr->_x = ...;                                                        */
/*     pPtr->_d = ...;                                                        */
/*     pPtr->_e = ...;                                                        */
/*     pPtr->_y = ...;                                                        */
/*     pPtr->_Ee = ...;                                                       */
/*     pPtr->_Eu = ...;                                                       */
/*     pPtr->_gramma = ...;                                                   */
/*     pPtr->_filter_length = ...;                                            */
/*----------------------------------------------------------------------------*/
void NLMS(PARAMS *pPtr)
{
    if(pPtr->handle){
        if(pPtr->Changed){
            NLMS_Status	status;

            pPtr->Changed = FALSE;
            status.step = pPtr->_step;
            status.offset = pPtr->_offset;
            status.x = pPtr->_x;
            status.d = pPtr->_d;
            status.e = pPtr->_e;
            status.y = pPtr->_y;
            status.Ee = pPtr->_Ee;
            status.Eu = pPtr->_Eu;
            status.gramma = pPtr->_gramma;
            status.delay = pPtr->_delay;
            status.filter_length = pPtr->_filter_length;
            NLMS_control(pPtr->handle, NLMS_SETSTATUS, &status);
        }

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        NLMS_apply(pPtr->handle);
        //NLMS_setInput(pPtr->handle);
        //NLMS_setDesire(pPtr->handle);
        //NLMS_getOutput(pPtr->handle);
        //NLMS_getError(pPtr->handle);
        //NLMS_setInputDesire(pPtr->handle);
    }
}
