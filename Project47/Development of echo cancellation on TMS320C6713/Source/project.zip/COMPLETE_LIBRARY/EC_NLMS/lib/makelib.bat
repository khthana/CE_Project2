@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x nlms.cmd
erase nlms_kmitl.l67
erase nlms.l67
ar6x -r nlms_kmitl.l67 ..\Release\nlms.o67
ar6x -r nlms.l67 ..\Release\nlms.obj
