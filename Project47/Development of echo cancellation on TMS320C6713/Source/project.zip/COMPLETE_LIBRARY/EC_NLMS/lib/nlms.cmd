-r
-m ..\Release\nlms.map
-o ..\Release\nlms.o67
-h
-g _NLMS_KMITL_INLMS
-g _NLMS_KMITL_IALG
-g _NLMS_KMITL_alloc
-g _NLMS_KMITL_free
-g _NLMS_KMITL_initObj
-g _NLMS_KMITL_control
-g _NLMS_KMITL_moved
-g _NLMS_KMITL_init
-g _NLMS_KMITL_exit
-g _NLMS_KMITL_apply
-g _NLMS_KMITL_setInput
-g _NLMS_KMITL_setDesire
-g _NLMS_KMITL_getOutput
-g _NLMS_KMITL_getError
-g _NLMS_KMITL_setInputDesire
-g _INLMS_PARAMS

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\NLMS_KMITL_ialg.obj
..\Release\NLMS_KMITL_ialgvt.obj
..\Release\iNLMS.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
    .text:algMoved {}
/*
// The NLMS_KMITL_activate & NLMS_KMITL_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
