/*
//============================================================================
//
//    FILE NAME : NLMS.h
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                NLMS module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#ifndef NLMS_
#define NLMS_

#include <alg.h>
#include <xdas.h>
#include "inlms.h"

/*
// ===========================================================================
// NLMS_Handle
//
// This pointer is used to reference all NLMS instance objects
*/
typedef struct INLMS_Obj *NLMS_Handle;

/*
// ===========================================================================
// NLMS_Params
//
// This structure defines the creation parameters for all NLMS objects
*/
typedef INLMS_Params NLMS_Params;

/*
// ===========================================================================
// NLMS_PARAMS
//
// This structure defines the default creation parameters for NLMS objects
*/
#define NLMS_PARAMS   INLMS_PARAMS

/*
// ===========================================================================
// NLMS_Status
//
// This structure defines the real-time parameters for NLMS objects
*/
typedef struct INLMS_Status   NLMS_Status;

/*
// ===========================================================================
// NLMS_Cmd
//
// This typedef defines the control commands NLMS objects
*/
typedef INLMS_Cmd   NLMS_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define NLMS_GETSTATUS    INLMS_GETSTATUS
#define NLMS_SETSTATUS    INLMS_SETSTATUS

/*
// ===========================================================================
// NLMS_create
//
// Create an NLMS instance object (using parameters specified by prms)
*/
extern NLMS_Handle NLMS_create(const INLMS_Fxns *fxns, const NLMS_Params *prms);

/*
// ===========================================================================
// NLMS_control
//
// Get, set, and change the parameters of the NLMS function (using parameters specified by status).
*/
extern Int NLMS_control(NLMS_Handle handle, NLMS_Cmd cmd, NLMS_Status *status);

/*
// ===========================================================================
// NLMS_delete
// Delete the NLMS instance object specified by handle
*/
extern Void NLMS_delete(NLMS_Handle handle);

/*
// ===========================================================================
// NLMS_apply
*/
extern XDAS_Void NLMS_apply(NLMS_Handle handle);

/*
// ===========================================================================
// NLMS_setInput
*/
extern XDAS_Void NLMS_setInput(NLMS_Handle handle, float x);

/*
// ===========================================================================
// NLMS_setDesire
*/
extern XDAS_Void NLMS_setDesire(NLMS_Handle handle, float d);

/*
// ===========================================================================
// NLMS_getOutput
*/
extern float NLMS_getOutput(NLMS_Handle handle);

/*
// ===========================================================================
// NLMS_getError
*/
extern float NLMS_getError(NLMS_Handle handle);

/*
// ===========================================================================
// NLMS_setInputDesire
*/
extern XDAS_Void NLMS_setInputDesire(NLMS_Handle handle, float x, float d);

#endif	/* NLMS_ */
