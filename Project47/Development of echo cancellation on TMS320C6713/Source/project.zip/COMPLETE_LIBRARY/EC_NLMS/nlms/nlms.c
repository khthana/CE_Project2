/*
//============================================================================
//
//    FILE NAME : NLMS.c
//
//    ALGORITHM : NLMS
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in NLMS.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 10 February 2005
//    Creation Time: 11:32 PM
//
//============================================================================
*/

#pragma CODE_SECTION(NLMS_create,  ".text:create")
#pragma CODE_SECTION(NLMS_control, ".text:control")
#pragma CODE_SECTION(NLMS_delete,  ".text:delete")
#pragma CODE_SECTION(NLMS_init,    ".text:init")
#pragma CODE_SECTION(NLMS_exit,    ".text:exit")

#include <std.h>
#include <alg.h>
#include <xdas.h>
#include "nlms.h"

/*
// ===========================================================================
// NLMS_create
//
//  Create an NLMS instance object (using parameters specified by prms)
*/
NLMS_Handle NLMS_create(const INLMS_Fxns *fxns, const NLMS_Params *prms)
{
    return ((NLMS_Handle)ALG_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// NLMS_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int NLMS_control(NLMS_Handle handle, NLMS_Cmd cmd, NLMS_Status *status)
{
    return (ALG_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// NLMS_delete
//
// Delete the NLMS instance object specified by handle
*/
Void NLMS_delete(NLMS_Handle handle)
{
    ALG_delete((IALG_Handle)handle);
}

/*
// ===========================================================================
// NLMS_init
//
// NLMS module initialization
*/
Void  NLMS_init(Void)
{
}

/*
// ===========================================================================
// NLMS_exit
//
// NLMS module finalization
*/
Void  NLMS_exit(Void)
{
}

/*
// ===========================================================================
// NLMS_apply
*/
XDAS_Void NLMS_apply(NLMS_Handle handle)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->apply(handle);

    ALG_deactivate((IALG_Handle)handle);
}

/*
// ===========================================================================
// NLMS_setInput
*/
XDAS_Void NLMS_setInput(NLMS_Handle handle, float x)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setInput(handle, x);

    ALG_deactivate((IALG_Handle)handle);
}

/*
// ===========================================================================
// NLMS_setDesire
*/
XDAS_Void NLMS_setDesire(NLMS_Handle handle, float d)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setDesire(handle, d);

    ALG_deactivate((IALG_Handle)handle);
}

/*
// ===========================================================================
// NLMS_getOutput
*/
float NLMS_getOutput(NLMS_Handle handle)
{
    float result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->getOutput(handle);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}

/*
// ===========================================================================
// NLMS_getError
*/
float NLMS_getError(NLMS_Handle handle)
{
    float result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->getError(handle);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}

/*
// ===========================================================================
// NLMS_setInputDesire
*/
XDAS_Void NLMS_setInputDesire(NLMS_Handle handle, float x, float d)
{
    ALG_activate((IALG_Handle)handle);

    handle->fxns->setInputDesire(handle, x, d);

    ALG_deactivate((IALG_Handle)handle);
}
