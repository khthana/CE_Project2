#ifndef hresourc_h
#define hresourc_h

//==========================================================================
// HRESOURC.H
// Resource Header file for Hypersignal Auto-Generated Block DLL                     
// Component Wizard for eXpressDSP generated include file.
//===========================================================================


//--------------------------------------------------------------------------
//                       USER PARAMETERS' STRING IDC's                      
//--------------------------------------------------------------------------
#define IDC_STRING_STEP                             51
#define IDC_STRING_OFFSET                           52
#define IDC_STRING_X                                53
#define IDC_STRING_D                                54
#define IDC_STRING_E                                55
#define IDC_STRING_Y                                56
#define IDC_STRING_EE                               57
#define IDC_STRING_EU                               58
#define IDC_STRING_GRAMMA                           59
#define IDC_STRING_FILTER_LENGTH                    60

//--------------------------------------------------------------------------
//                        USER PARAMETERS' EDIT IDC's                       
//--------------------------------------------------------------------------
#define IDC_EDIT_STEP                               201
#define IDC_EDIT_OFFSET                             202
#define IDC_EDIT_X                                  203
#define IDC_EDIT_D                                  204
#define IDC_EDIT_E                                  205
#define IDC_EDIT_Y                                  206
#define IDC_EDIT_EE                                 207
#define IDC_EDIT_EU                                 208
#define IDC_EDIT_GRAMMA                             209
#define IDC_EDIT_FILTER_LENGTH                      210

//--------------------------------------------------------------------------
//                  USER PARAMETERS' VARIABLE LIST IDC's                    
//--------------------------------------------------------------------------
#define IDC_VAR_STEP                                211
#define IDC_VAR_OFFSET                              212
#define IDC_VAR_X                                   213
#define IDC_VAR_D                                   214
#define IDC_VAR_E                                   215
#define IDC_VAR_Y                                   216
#define IDC_VAR_EE                                  217
#define IDC_VAR_EU                                  218
#define IDC_VAR_GRAMMA                              219
#define IDC_VAR_FILTER_LENGTH                       220

//--------------------------------------------------------------------------
//                    USER PARAMETERS' RADIO BUTTON IDC's                   
//--------------------------------------------------------------------------
 
//--------------------------------------------------------------------------
//                     USER PARAMETERS' COMBO BOX IDC's                     
//--------------------------------------------------------------------------
#define IDC_COMBO_SWI                               401 

 
//--------------------------------------------------------------------------
//                     USER PARAMETERS' CHECK BOX IDC's                     
//--------------------------------------------------------------------------

//--------------------------------------------------------------------------
//                     USER PARAMETERS' FILE BROWSE IDC's                   
//--------------------------------------------------------------------------

//--------------------------------------------------------------------------
//                      REAL-TIME DRIVER IDC's 700-799                      
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//                             BITMAP IDC's 800-899                         
//--------------------------------------------------------------------------
#define IDB_BITMAP                                  801
#define IDB_SWI                                     802
#define IDB_HWI                                     803
#define IDB_IDL                                     804
#define IDB_PRD                                     805
#define IDB_CLK                                     806

#define IDC_STATIC                                  -1


#endif
