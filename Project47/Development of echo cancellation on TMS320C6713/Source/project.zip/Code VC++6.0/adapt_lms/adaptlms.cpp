/*-------------------------------------------------------------------------*/
/*                                                                         */
/*    LMS( Least Mean Square Algorithm )                                   */                 
/*    adaptlms.cpp                                                         */
/*    Before run program you should put b and x signal from matlab to file */ 
/*                                                                         */ 
/*-------------------------------------------------------------------------*/

#include <stdio.h>
#include "adaptlms.h" /* for global variable */

/*-------------------------------------------------------------------------*/

void main(void)
{
	int flag = 0;					/* if 1 is have a file to be necessary */
	flag = checkHaveFile();
	if(flag){
		openInputFromFile("c:/adaptlms/input.txt",x,"x");	/* Read input from this file */
		openInputFromFile("c:/adaptlms/b.txt",b,"b");		/* Read b from this file     */
		initValues(y,e,d,w0,Zi,Zf); /* Initial each values (global variable) */
		getDesired(b,x,d);			/* Get desired signal(d) */
		initlms(w0,mu,Zi,&S);		/* Initial for stucture  */
		
/*-----------------------------------------------------------*/
/*    */adaptlms(x,d,&S,y,e);		/* Process LMS algorithm */
/*-----------------------------------------------------------*/

		writeDesiredToFile(d);		/* Write d to file       */
		writeErrorToFile(e);		/* Write error to file	 */
		writeOutputToFile(y);		/* Write y to file       */
	//	writeStructToFile(&S);		/* Write S to file       */
		printf("-------------------------------------\n");
		printf("Update Structure = %d time\n",S.iter);
		printf("You able to check all value in path c:\\adatlms\\xxx.txt\n");
		printf("-------------------------------------\n");
	}
	else{
		printf("----------------------------------------\n");
		printf("----- >> !! Error file not found\n");
		printf("----- >> C:\\adaptlms\\input.txt\n");
		printf("----- >> C:\\adaptlms\\b.txt\n\a");			/* \a is beeb sound */
		printf("----------------------------------------\n");
		printf("*Comment Before run program you should put b and x signal from matlab to file\n\n");
	}	
}

/*--------------------------------------------------------------------------------*/

void initValues(double *y,double *e,double *d,double *w0,double *Zi,double *Zf)
{

	int i;
	for(i = 0; i<MAX_INPUT; i++)
	{
		y[i] = 0.00;	/* Initial output from filter */
		e[i] = 0.00;	/* Initial error */
		d[i] = 0.00;	/* Initial desire signal */
	}
	for(i = 0; i<MAX_WEIGHT; i++)
	{
		w0[i] = 0.00;	/* Initial weight vecter */
		Zi[i] = 0.00;	/* Initial Z initial */
		Zf[i] = 0.00;	/* Initial Z final */
	}

}

/*--------------------------------------------------------------------------------*/

void initlms(double *w0,double mu,double *Zi,Struct *S)
{

	/* INITLMS Initialize structure for FIR LMS adaptive filter.*/
	S->coeffs = w0;
	S->states = Zi;
	S->step = mu;
	S->iter = 0; /* Iteration count. */

}

/*--------------------------------------------------------------------------------*/

void adaptlms(double *x,double *d,Struct *S,double *y,double *e)
{

	/* ADAPTLMS Least mean squared (LMS) FIR adaptive filter. */
	adaptfirfilt(x,d,S,y,e);

}

/*--------------------------------------------------------------------------------*/

void adaptfirfilt(double *x,double *d,Struct *S,double *y,double *e)
{
	
	int n;int u = 0;
	printf("%d",MAX_INPUT);
	for(n=0; n<MAX_INPUT; n++)
	{
		/* Update mu every 50 sample */
		if( (n % MAX_MU) == 0 )
		{
			updateMu(&mu,x,n);
			S->step = mu; 
		}
	
		/* Call preadapt to filter the input and update the filter state */
		preadaptfir(x[n],d[n],S,&y[n],&e[n]);/* n for update mu in function preadaptfir */
		/* Update FIR filter states, increment counter.*/
		S->states = Zf;/* Zf is grobal variable */
		S->iter = S->iter + 1;
	}

}

/*--------------------------------------------------------------------------------*/

void preadaptfir(double x,double d,Struct *S,double *y,double *e)
{
	
	/* PREADAPT Perform the filtering step for an adaptive filter.*/
	int i;
	/* Use filter to compute the output and return the final conditon */
	firfilter(S->coeffs,x,S->states,y);
	(*e) = d - (*y);/* Prediction error */
	
	/*-----------------------------------*/
	/*	Update weight vector (S.coeffs)  */
	/*-----------------------------------*/
	for(i = 0; i<MAX_WEIGHT; i++)
	{
		/*S.step is step size(mu)*/
		S->coeffs[i] = S->coeffs[i] + ( S->step * Zf[i] * (*e));
	}

}

/*--------------------------------------------------------------------------------*/

void firfilter(double *coeffs,double x,double *Zi,double *y)
{

	double U[MAX_WEIGHT];
	int i;
	for(i = 0; i<MAX_WEIGHT; i++)
	{
		U[i] = 0.00;
	}

	(*y) = 0.00;/* Reset y for change new value */
	for(i = 0; i<MAX_WEIGHT; i++)
	{
		if(i == 0)
			U[i] = x;
		else
			U[i] = Zi[i-1];
	}
	for(i = 0; i<MAX_WEIGHT; i++)
	{
		(*y) = (*y) + (coeffs[i]*U[i]);
	}
	/* Zf = u(1:end-1);  code in mathlab */
	for(i = 0; i<MAX_WEIGHT; i++)
	{
		Zf[i] = U[i];
	}

}

/*--------------------------------------------------------------------------------*/

void updateMu(double *mu,double *x,int n)
{

	double normMax = 0.00;
	double norm = 0.00;
	double tempX[MAX_WEIGHT];
	int i,j,k;
	for(i = 0; i<MAX_WEIGHT; i++)	/* Initial temp input */
	{
		tempX[i] = 0.00;
	}
	
	for(j = 0; j<MAX_MU; j++)
	{
 		/* Find temp input[32] */
		for(k = 0; k<MAX_WEIGHT ;k++)
		{
			if( (j-k+n)<0 )
				tempX[k] = 0.00;
			else
				tempX[k] = x[j-k+n];
		}
		/* Find MaxNorm */
		for(i = 0; i<MAX_WEIGHT; i++)
		{
			norm = norm + (tempX[i]*tempX[i]);
		}
		/* Find norm max */
		if(norm > normMax)
			normMax = norm;
		norm = 0.00;/* Clear for to find new value again */
	}
	(*mu) = 1/normMax;

}
/*--------------------------------------------------------------------------------*/

/*  d  = filter(b,1,x);    % Desired signal From math lab */
void getDesired(const double *b,double *x,double *d)
{
	
	double tempD[MAX_B];/* MAX_B = 32 */
	int i,j,k;
	for(i = 0; i<MAX_B; i++)
	{
		tempD[i] = 0.00;
	}
	
	for(j = 0; j<MAX_INPUT; j++)
	{
		/* Find temp d[32] */
		for(k = 0; k<MAX_B ;k++)
		{
			if( (j-k)<0 )
				tempD[k] = 0.00;
			else
				tempD[k] = x[j-k];
		}
		/* Convolution b and input */
		for(i = 0; i<MAX_B; i++)
		{
			d[j] = d[j] + (tempD[i]*b[i]);
		}
	}

}
/*--------------------------------------------------------------------------------*/

void writeErrorToFile(const double *e)
{
	
	/*------------------------/
	/	Write error to file   
	/------------------------*/
	FILE *pt;
	int  j;
	pt = fopen("c:/adaptlms/error.txt","w+");
	for (j=0;j<MAX_INPUT;j++)
	{
		fprintf(pt,"%f\n",e[j]);
	}
	fclose(pt);

}

/*--------------------------------------------------------------------------------*/

void writeDesiredToFile(const double *d)
{

	/*-------------------------/
	/	Write d to file       
	/-------------------------*/
	FILE *pt;
	int  j;
	pt = fopen("c:/adaptlms/d.txt","w+");
	for (j=0;j<MAX_INPUT;j++)
	{
		fprintf(pt,"%f\n",d[j]);
	}
	fclose(pt);

}

/*--------------------------------------------------------------------------------*/

void writeOutputToFile(const double *y)
{
	
	/*------------------------/
	/	Write y to file
	/------------------------*/
	FILE *pt;
	int j;
	pt = fopen("c:/adaptlms/output.txt","w+");
	for (j=0;j<MAX_INPUT;j++)
	{
		fprintf(pt,"%f\n",y[j]);
	}
	fclose(pt);

}

/*--------------------------------------------------------------------------------*/

void writeStructToFile(const Struct *S)
{
	
	/*------------------------/
	/	Write S to file
	/------------------------*/
	FILE *pt;
	int j;
	pt = fopen("c:/adaptlms/struct.txt","w+");
	/*-------------------------------------
		double *coeffs;  w0 
		double step;     mu - LMS step size 
		double *states;  window 
		int iter;
	---------------------------------------*/
	fprintf(pt,"---------------------------------------------\n");
	fprintf(pt,"     This is last values of stucture S       \n");
	fprintf(pt,"---------------------------------------------\n");
	fprintf(pt,"S.coeffs \nor w0 \n");
	for (j=0;j<MAX_WEIGHT;j++)
	{
		fprintf(pt," \t%f\n",S->coeffs[j]);
	}
	fprintf(pt,"S.step \nor mu or step size \n");
	fprintf(pt," \t%f\n",S->step);
	fprintf(pt,"S.states \nor Zf and Zi \n");
	for (j=0;j<MAX_WEIGHT;j++)
	{
		fprintf(pt," \t%f\n",S->states[j]);
	}
	fprintf(pt,"S.iter \nor iterative of loop structure update\n");
	fprintf(pt," \t%d\n",S->iter);
	
	fclose(pt);
	/*------------------------/
	/	Write Last W to file 
	/------------------------*/
	pt = fopen("c:/adaptlms/w.txt","w+");
	for (j=0;j<MAX_WEIGHT;j++)
	{
		fprintf(pt,"%f\n",S->coeffs[j]);
	}
	fclose(pt);

}
/*--------------------------------------------------------------------------------*/

void openInputFromFile(const char * path, double * target,const char *word)
{

	/*-----------------------------------*/
	/*  Get From File                    */
	/*-----------------------------------*/
	/*	Path : file name                 */
	/*	Target : pointer to target array */
	/*-----------------------------------*/
	FILE *pt;
	float inp;
	int j;
	int MAX_X;
	/* Compare word format */
	if (word == "x") 
		MAX_X = MAX_INPUT;
	else /* case word = b */
		MAX_X = MAX_B;
	/* Open file	 */
	pt = fopen(path,"r");
	if (NULL==pt) {return;}
	/* put values to array */
	for (j=0;j<MAX_X;j++)
	{
		fscanf(pt,"%e",&inp);
		target[j] = inp;
	}
	fclose(pt);

}

/*--------------------------------------------------------------------------------*/

int checkHaveFile()
{

	FILE *pt;
	float inp = NULL;
	/*Check file input.txt*/
	pt = fopen("c:/adaptlms/input.txt","r");
	if(pt == NULL)
	{
		return 0;
	}
	fclose(pt);
	
	/*Check file b.txt*/
	pt = fopen("c:/adaptlms/b.txt","r");
	if (NULL==pt)
	{
		return 0;
	}
	fclose(pt);
	return 1;

}

/*--------------------------------------------------------------------------------*/