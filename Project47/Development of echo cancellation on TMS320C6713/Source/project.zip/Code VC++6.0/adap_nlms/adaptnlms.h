//#define MAX_INPUT 500/* Max sample signal */ 
#define MAX_INPUT 300000
#define MAX_WEIGHT 1100/* Max window for create weight + DELAY */ 
#define DELAY 100/* = 10 % of weight*/
#define MAX_B 1100/* Max window of fir filter that will be convolution with input*/
#define GRAMMA 0.999/*Between [0.9 - 0.999]*/
/* Stucture for adaptive filter lms alg */
typedef struct Struct{
	double *coeffs; /* w0 */
    double step;/* mu - LMS step size */
	double *states;/* window */
	double offset;/*This is useful to avoid divide by zero (or very small
                   numbers)*/
	int iter;
}Struct;
/* Global variable */
Struct S;
double x[MAX_INPUT];/*array for input signal*/ 
double d[MAX_INPUT];/*array for desire signal*/ 
double y[MAX_INPUT];/*array for output from firter design*/ 
double e[MAX_INPUT];/*array for error*/ 
double w0[MAX_WEIGHT];/*array for weight vector*/ 
double Zi[MAX_WEIGHT];/*array for delay initial*/ 
double Zf[MAX_WEIGHT];/*array for delay final*/ 
double b[MAX_B];/*array for fir that become from function fir1 from mathlab */ 
double mu = 0.00;/*mu value for update weight vector*/ 
double Eu = 0.00;
double Ee = 0.00;

/* Protyype declearation */
void adaptnlms(double *,double *,Struct *,double *,double *);
void initnlms(double *,double,double *,Struct *);
void adaptfirfilt(double *,double *,Struct *,double *,double *);
void preadaptfir(double *,double,Struct *,double *,double *,int);
void firfilter(double *,double,double *,double *);
void initValues(double *,double *,double *,double *,double *,double *);
void updateMu(double *,double *,int,double,double,double,double);
void getDesired(const double *,double *,double *);
/*  This fuction about a file   */
void writeErrorToFile(const double *);
void writeDesiredToFile(const double *);
void writeOutputToFile(const double *);
void writeStructToFile(const Struct *);
void openInputFromFile(const char *,double *,const char *);
int checkHaveFile(void);