#ifndef _WINMAIN_H_
#define _WINMAIN_H_

///////////////////////////////////////////////////////////
// Player data
///////////////////////////////////////////////////////////
// Maximum # of players allowed to be connected at once
#define MAX_PLAYERS           8
#define MAX_MONSTER			  120


// Player states
#define STATE_IDLE            1 
#define STATE_MOVE            2
#define STATE_SWING           3
#define STATE_HURT            4
#define STATE_DIE			  5

// Animations
#define ANIM_IDLE             1
#define ANIM_WALK             2
#define ANIM_SWING            3
#define ANIM_HURT             4
#define ANIM_DIE		      5

typedef struct sPlayer {
  BOOL  Connected;        // TRUE if player active

  long  HP;				  // HP Value

  char  Name[32];		  // Name of player
  DPNID dpnidPlayer;      // DirectPlay Player ID #

  long  State;            // Last known state (STATE_*)
  long  Time;             // Time of last state update
  long  Latency;          // Half of round trip latency in ms

  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Angle facing
  float Speed;            // Movement speed

  int	NumMap;			  // Number maps 

  cObject Body;           // Character 3-D object
  cObject Weapon;         // Weapon 3-D object
  long  LastAnim;         // Last known animation

  // Constructor and destructor
  sPlayer()  
  { 
    Connected	= FALSE; 
    dpnidPlayer = 0; 
    LastAnim	= 0; 
    Time		= 0;
	HP			= 0;
  }

  ~sPlayer() { Body.Free(); Weapon.Free(); }
} sPlayer;

//Monster state
typedef struct sMonster {

  BOOL  Alive;				// TRUE if monster alive

  long  ID;					// #ID Monster
  long  AI;                 // STAND, WANDER, etc
  float Direction;          // Angle character is facing
  long  State;              // Last known state (STATE_*)
  float Speed;              // Movement speed
  long  Time;               // Time of last state update

  int	NumMap;			    // Number map
  long  Latency;          // Half of round trip latency in ms

  float XPos, YPos, ZPos;   // Current coordinates
  long  Number;				// Number are show
  long  DelayNum;

  cObject Body;             // Character object class
  long LastAnim;			// Last known animation

  // Constructor
  sMonster()
  {
	ID    = 0;
	Alive = FALSE;
	Time  = 0;
	LastAnim = 0;
    State = STATE_IDLE;     // Set default animation
	Number = 0;
	DelayNum = 0;

  }
  ~sMonster() { Body.Free(); }
}sMonster;

///////////////////////////////////////////////////////////
// Network message data
///////////////////////////////////////////////////////////
// Types of messages
#define MSG_CREATE_PLAYER		1
#define MSG_PLAYER_INFO			2
#define MSG_DESTROY_PLAYER		3
#define MSG_STATE_CHANGE		4
#define MSG_MAP_CHANGE			5
#define MSG_MONSTER_STATE		6
#define MSG_NUMBER				7
#define MSG_DEC_HP				8
#define MSG_FULL_HP				9
#define MSG_STATE_CHANGE_TIME	14
#define MSG_ASSIGNID			256

// The message header structure used in all messages
typedef struct {
  long  Type;             // Type of message (MSG_*)
  long  Size;             // Size of data to send
  DPNID PlayerID;         // Player performing action
} sMessageHeader;

// The message queue message structure
typedef struct {
  sMessageHeader Header;  // Message header

  char Data[1024];        // Message data
} sMessage;

// Request a player DPNID from server message
typedef struct {
  sMessageHeader Header;  // Message header
} sAssignPlayerIDMessage;

// Create a player message
typedef struct {
  sMessageHeader Header;  // Message header

  float XPos, YPos, ZPos; // Create player coordinates
  float Direction;        // Direction of player
  int	NumMap;			  // Map number
  char  Name[32];         // Name of player
  long	HP;				  // HP Players
} sCreatePlayerMessage;

// Request player information message
typedef struct {
  sMessageHeader Header;  // Message header

  DPNID PlayerID;         // Which player to request
} sRequestPlayerInfoMessage;

// Destroy a player message
typedef struct {
  sMessageHeader Header;  // Message header
} sDestroyPlayerMessage;

// Change in state message
typedef struct {
  sMessageHeader Header;  // Message header

  long  State;            // State message (STATE_*)
  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Player facing direction
  float Speed;            // Walking speed of player

  long  Latency;          // Latency value from server
} sStateChangeMessage;

// Change map message
typedef struct {
  sMessageHeader Header;  // Message header

  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Player facing direction
  int NumMap;			  // Map number

} sMapChangeMessage;

// Monster message
typedef struct {
  sMessageHeader Header;  // Message header

  long  ID;				  // ID monster
  long  State;            // State message (STATE_*)
  float XPos, YPos, ZPos; // Monster coordinates
  float Direction;        // Monster facing direction
  float Speed;            // Walking speed of monster
  int	NumMap;			  // Number of map
  BOOL  Alive;			  // Monster alive ?		
} sMonsterStateMessage;

// Number message
typedef struct {
  sMessageHeader Header;  // Message header

  long  ID;				  // ID monster
  long  Number;			  // Numbers are show
  int   NumMap;				  
} sNumberMessage;

// Decrease HP Player
typedef struct{
  sMessageHeader Header; // Message header

  long Dec_HP;			 // Dec HP Player
} sDecHPPlayerMessage;

typedef struct {
  sMessageHeader Header; // Message header

  long HP_FULL;			 // Full HP Player
} sFullHPPlayerMessage;

///////////////////////////////////////////////////////////
// Client class definition
///////////////////////////////////////////////////////////
class cClient : public cNetworkClient
{
  private:
    BOOL ConnectComplete(DPNMSG_CONNECT_COMPLETE *Msg);
    BOOL Receive(DPNMSG_RECEIVE *Msg);
};

///////////////////////////////////////////////////////////
// Application class definition
///////////////////////////////////////////////////////////
class cApp : public cApplication
{
  private:
    CRITICAL_SECTION m_UpdateCS;    // Critical sections

    cGraphics       m_Graphics;     // Graphics object
    cCamera         m_Camera;       // Camera object
    cFont           m_Font;         // Font object
	cFont			m_NumberFont;

    GUID           *m_guidAdapter;  // Adapter used to connect
    cNetworkAdapter m_Adapters;     // List of adapters
    cClient         m_Client;       // Derived client class

    char            m_HostIP[16];   // Host IP Address
    char            m_Name[32];     // Player name

    cInput          m_Input;        // Input object
    cInputDevice    m_Keyboard;     // Keyboard object
    cInputDevice    m_Mouse;        // Mouse object

    cMesh           m_TerrainMesh[4];	// Terrain object mesh
    cMesh			m_WarpGate;			// Warp to next map
	cObject			Warp;				// Character 3-D object
	cNodeTreeMesh   m_NodeTreeMesh;		// NodeTree object

    cMesh           m_CharacterMesh; // Mesh for character
    cMesh           m_WeaponMesh;    // Mesh for weapon
    cAnimation      m_CharacterAnim; // Animation for character

	cMesh			m_MonsterMesh;	 // Mesh for monster
	cAnimation	    m_MonsterAnim;	 // Animation for monster	

    long            m_NumPlayers;   // # players connected
    sPlayer        *m_Players;      // Player data
	sMonster	   *m_Monster;		// Monster data

    float           m_CamAngle;     // Viewing camera angle
	float			m_CamYAxis;		// Viewing camera height 
	float			Height;

	int			    ResponseTime;	// State change response time
	DWORD			GetTime;

	cLight          m_Light;		// Light
	BOOL			m_WindowScreen;	// Screen [ Full && Window ] 

    BOOL SelectAdapter();            // Select network adapter
    BOOL InitializeGame();           // Initialize game
    BOOL JoinGame();                 // Join network session

    // Get player's number in list
    long GetPlayerNum(DPNID dpnidPlayer);

    void UpdatePlayers();            // Update all players

	void UpdateMonster();			 // Update all monsters

    void RenderScene();              // Render the scene

    // Send a client network message to server
    BOOL SendNetworkMessage(void *Msg, long SendFlags);

    // Functions to process incoming messages
    void AssignID(sMessage *Msg);
    void CreatePlayer(sMessage *Msg);
    void DestroyPlayer(sMessage *Msg);
    void ChangeState(sMessage *Msg);
	void ChangeMap(sMessage *Msg);
	void ChangeStateMonster(sMessage *Msg);
	void ShowNumber(sMessage *Msg);
	void DecHPPlayer(sMessage *Msg);
	void FullHPPlayer(sMessage *Msg);
	void ResponseChangeState(sMessage *Msg);

	// Check if collides  between charactors
	BOOL cApp::CheckSphereIntersect(				\
		float XCenter1, float YCenter1, float ZCenter1, \
		float Radius1,									\
		float XCenter2, float YCenter2, float ZCenter2, \
		float Radius2);
	
  public:
    // Overloaded class functions
    cApp();

    BOOL Init();
    BOOL Shutdown();
    BOOL Frame();

    // Siphon a network receive message to application
    BOOL Receive(DPNMSG_RECEIVE *Msg);

    // Set adapter to use, IP to connect to, and name to use
    void SetInfo(GUID *Adapter, char *IP, char *Name, BOOL Screen);
};

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow);
BOOL CALLBACK ConnectDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam);

#endif
