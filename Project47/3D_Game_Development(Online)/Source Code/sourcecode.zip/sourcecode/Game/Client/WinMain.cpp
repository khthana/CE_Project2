/**************************************************
Client Game 3D Online

OLALA Group

Required libraries:
  D3D8.LIB, D3DX8.LIB, DINPUT8.LIB, D3DXOF.LIB,
  DXGUID.LIB, DPNET.LIB, DPLAY.LIB, and DPNADDR.LIB
**************************************************/

#include "Core_Global.h"
#include "Frustum.h"
#include "NodeTree.h"
#include "WinMain.h"
#include "resource.h"

cApp            *g_Application; // Global application pointer
cNetworkAdapter *g_Adapters;    // Global adapter list pointer

BOOL             g_Connected = FALSE;  // Connection status

///////////////////////////////////////////////////////////
// cApp functions
///////////////////////////////////////////////////////////
cApp::cApp()
{ 
  // Setup main window information
  m_Width  = 640; 
  m_Height = 480;
  m_Style  = WS_BORDER | WS_CAPTION |                         \
             WS_MINIMIZEBOX | WS_SYSMENU;
  strcpy(m_Class, "ClientClass");
  strcpy(m_Caption, "���� 3 �Ե��͹�Ź�"); // Caption Game 3D Online

  // Clear class data
  m_Players     = NULL;
  m_Monster     = NULL;
  g_Application = this;
  g_Adapters    = &m_Adapters;

  // Create a critical section for updating data
	InitializeCriticalSection(&m_UpdateCS);
}

BOOL cApp::Init()
{
  // Select a network adapter to use (or quit if selected)
  if(SelectAdapter() == FALSE)
    return FALSE;

  // Initialize the game, set video mode, load data, etc
  if(InitializeGame() == FALSE) {
    Error(FALSE, "Unable to initialize game.");
    return FALSE;
  }

  // Get time for calculate player connect
  GetTime = timeGetTime();

  // Join networked game
  if(JoinGame() == FALSE) {
    Error(FALSE, "Unable to connect to server.");
    return FALSE;
  }

  return TRUE;
}

BOOL cApp::Shutdown()
{
  // Shutdown network
  m_Adapters.Shutdown();
  m_Client.Disconnect();
  m_Client.Shutdown();

  // Free players
  delete [] m_Players;
  m_Players = NULL;

  //Free monsters
  delete [] m_Monster;
  m_Monster = NULL;

  // Free meshes
  m_NodeTreeMesh.Free();
  m_TerrainMesh[0].Free();
  m_TerrainMesh[1].Free();
  m_TerrainMesh[2].Free();
  m_TerrainMesh[3].Free();
	
  m_CharacterMesh.Free();
  m_WeaponMesh.Free();
  m_CharacterAnim.Free();
  m_WarpGate.Free();
  Warp.Free();

  // Shutdown input
  m_Keyboard.Free();
  m_Mouse.Free();
  m_Input.Shutdown();

  // Shutdown graphics
  m_Font.Free();
  m_Graphics.Shutdown();

  // Remove critical section
  DeleteCriticalSection(&m_UpdateCS);

  return TRUE;
}

BOOL cApp::Frame()
{
  static DWORD UpdateCounter  = timeGetTime();
  static long MoveAction = 0, LastMove = 0;
  static BOOL CamMoved = FALSE;
  BOOL AllowMovement;
  long Dir;
  float Angles[13] = { 0.0f, 0.0f, 1.57f, 0.785f, 3.14f,      \
                       0.0f, 2.355f, 0.0f, 4.71f, 5.495f,     \
                       0.0f, 0.0f, 3.925f };

  // Get local input every frame 
  m_Keyboard.Acquire(TRUE);  
  m_Mouse.Acquire(TRUE);     
  m_Keyboard.Read();
  m_Mouse.Read();

  // Pressing ESC quits program
  if(m_Keyboard.GetKeyState(KEY_ESC) == TRUE)
    return FALSE;

  // Handle connection and waiting for data screen
  if(g_Connected == FALSE || !m_Players[0].dpnidPlayer) {

    // Display message(s)
    m_Graphics.Clear();
    if(m_Graphics.BeginScene() == TRUE) {
      m_Font.Print("���ѧ�������͡Ѻ���������...", 0, 0);
      if(!m_Players[0].dpnidPlayer)
        m_Font.Print("��س����ѡ����...", 0, 20);
      m_Graphics.EndScene();
    }
    m_Graphics.Display();

	// Calculate player connect time
	ResponseTime = timeGetTime() - GetTime;

    // Request player ID from server every 2 seconds
    if(timeGetTime() > UpdateCounter + 2000) {
      UpdateCounter = timeGetTime();  // Update counter

      sAssignPlayerIDMessage apidm;
      apidm.Header.Type = MSG_ASSIGNID;
      apidm.Header.Size = sizeof(sAssignPlayerIDMessage);
      SendNetworkMessage(&apidm, DPNSEND_NOLOOPBACK |         \
                                 DPNSEND_GUARANTEED);
    }
    return TRUE;
  }

  // Store movements every frame
  if(m_Keyboard.GetKeyState(KEY_UP) == TRUE)
    MoveAction |= 1;
  if(m_Keyboard.GetKeyState(KEY_RIGHT) == TRUE)
    MoveAction |= 2;
  if(m_Keyboard.GetKeyState(KEY_DOWN) == TRUE)
    MoveAction |= 4;
  if(m_Keyboard.GetKeyState(KEY_LEFT) == TRUE)
    MoveAction |= 8;
  
  // Store attack action
  if(m_Keyboard.GetKeyState(KEY_SPACE) == TRUE)
    MoveAction |= 16;
  if(m_Mouse.GetButtonState(MOUSE_LBUTTON) == TRUE) 
    MoveAction |= 16;


  // Rotate camera
  if(m_Mouse.GetButtonState(MOUSE_RBUTTON) == TRUE){
	 m_CamAngle -= (float)m_Mouse.GetXDelta()/200;
	 m_CamYAxis += (float)m_Mouse.GetYDelta()/2;

	 if(m_CamYAxis < Height+10)	//Not Below Character stand on ground
		m_CamYAxis = Height+10;
	 if(m_CamYAxis > 500)		//Not Far Away
		m_CamYAxis = 500;

	 CamMoved = TRUE;	
  }	
  
  // Only update players every 33ms (30 times a second)
  if(timeGetTime() < UpdateCounter + 33)
    return TRUE;

  // Set flag to allow player movement
  AllowMovement = TRUE;

  // Don't allow movement if still swinging weapon
  if(m_Players[0].State == STATE_SWING)
    AllowMovement = FALSE;

  // Don't allow movement if still being hurt
  if(m_Players[0].State == STATE_HURT)
    AllowMovement = FALSE;

  if(m_Players[0].State == STATE_DIE)
	AllowMovement = FALSE;

  // Handle movements if allowed
  if(AllowMovement == TRUE) {

    // Process attack
    if(MoveAction & 16) {
      MoveAction = 0;  // Clear movement
      LastMove = 0;    // Clear last movement

	  // Get time attack for calculate reponse time
	  GetTime = timeGetTime();

      // Send attack message - let server signal swing
      sStateChangeMessage Msg;
      Msg.Header.Type     = MSG_STATE_CHANGE;
      Msg.Header.Size     = sizeof(sStateChangeMessage);
      Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
      Msg.State           = STATE_SWING;
      Msg.Direction       = m_Players[0].Direction;

      // Send message to server
      SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
    }

    // Process local player movements
    if((Dir = MoveAction) > 0 && Dir < 13) {
      // Set new player state (w/time and direction)
      EnterCriticalSection(&m_UpdateCS);
      m_Players[0].State     = STATE_MOVE;
      m_Players[0].Direction = Angles[Dir] - m_CamAngle + 4.71f;
      LeaveCriticalSection(&m_UpdateCS);

      // Reset last move if camera moved since last update
      if(CamMoved == TRUE) {
        CamMoved = FALSE;
        LastMove = 0;
      }

      // Send actions to server if changed from last move
      if(MoveAction != LastMove) {
	    LastMove = MoveAction;  // Store last action

        m_Players[0].Time = timeGetTime();

		// Get time attack for calculate reponse time
		GetTime = timeGetTime();

        // Construct message
        sStateChangeMessage Msg;
        Msg.Header.Type     = MSG_STATE_CHANGE;
        Msg.Header.Size     = sizeof(sStateChangeMessage);
        Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
        Msg.State           = STATE_MOVE;
        Msg.Direction       = m_Players[0].Direction;

        // Send message to server
        SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
      }
    } else {
      // Change to idle state
      EnterCriticalSection(&m_UpdateCS);
      m_Players[0].State = STATE_IDLE;
      LeaveCriticalSection(&m_UpdateCS);

      // Send update only if player moved last update
      if(LastMove) {
        LastMove = 0;

		// Get time attack for calculate response time
		GetTime = timeGetTime();

        sStateChangeMessage Msg;
        Msg.Header.Type     = MSG_STATE_CHANGE;
        Msg.Header.Size     = sizeof(sStateChangeMessage);
        Msg.Header.PlayerID = m_Players[0].dpnidPlayer;
        Msg.State           = STATE_IDLE;
        Msg.Direction       = m_Players[0].Direction;

        // Send message to server
        SendNetworkMessage(&Msg, DPNSEND_NOLOOPBACK);
      }
    }
  }

  // Update all players
  UpdatePlayers();

  // Update all monsters
  UpdateMonster();

  // Render the scene
  RenderScene();

  MoveAction = 0; // Clear action data for next frame

  UpdateCounter = timeGetTime(); // Reset update counter

  return TRUE;
}

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow)
{
  cApp App;
  return App.Run();
}

///////////////////////////////////////////////////////////
// Select adapter dialog and other functions
///////////////////////////////////////////////////////////
BOOL CALLBACK ConnectDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam)
{
  int Selection;
  long i;
  char Name[32], IP[16], Text[256];
  static HWND hAdapters;
  BOOL Screen;

  switch(uMsg) {
    case WM_INITDIALOG:
      // Get adapter list window handle
      hAdapters = GetDlgItem(hWnd, IDC_ADAPTERS);

      // Add adapter names to list
      for(i=0;i<g_Adapters->GetNumAdapters();i++) {
        g_Adapters->GetName(i, Text);
        SendMessage(hAdapters, CB_INSERTSTRING,i,(LPARAM)Text);
      }

      // Select first adapter in list
      SendMessage(hAdapters, CB_SETCURSEL, 0, 0);

      // Clear fields
      SetWindowText(GetDlgItem(hWnd, IDC_HOSTIP), "127.0.0.1");
      SetWindowText(GetDlgItem(hWnd, IDC_NAME), "");

	  // Set full screen mode
	  SendDlgItemMessage(hWnd, IDC_FULLSCREEN, BM_SETCHECK, 1, 0);

      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam)) {

        case IDC_OK:
          // Make sure an adapter was selected
          if((Selection = SendMessage(hAdapters,              \
                                      CB_GETCURSEL,           \
                                      0, 0)) == LB_ERR)
            break;

          // Make sure there's an IP entered
          GetWindowText(GetDlgItem(hWnd, IDC_HOSTIP), IP, 16);
          if(!strlen(IP))
            break;

          // Make sure there's a name entered
          GetWindowText(GetDlgItem(hWnd, IDC_NAME), Name, 32);

          if(!strlen(Name))
            break;

		  // Select screen mode
		  if(SendDlgItemMessage(hWnd, IDC_FULLSCREEN, BM_GETCHECK, 0, 0))
			  Screen = FALSE;
		  else
			  Screen = TRUE;

          // Assign Adapter, IP, and Name
          if(g_Application != NULL)
            g_Application->SetInfo(                           \
                    g_Adapters->GetGUID(Selection), IP, Name, Screen);

          // Quit dialog
          EndDialog(hWnd, TRUE);
          return TRUE;

        case IDC_CANCEL:
          EndDialog(hWnd, FALSE);
          return TRUE;
      }

  }
  return FALSE;
}

void cApp::SetInfo(GUID *Adapter, char *IP, char *Name, BOOL Screen)
{
  m_guidAdapter = Adapter;
  strcpy(m_HostIP, IP);
  strcpy(m_Name, Name);
  m_WindowScreen = Screen;
}

///////////////////////////////////////////////////////////
// Misc. application functions
///////////////////////////////////////////////////////////
long cApp::GetPlayerNum(DPNID dpnidPlayer)
{
  long i;

  // Error checking
  if(m_Players == NULL)
    return -1;

  // Scan list looking for match
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == dpnidPlayer &&             \
       m_Players[i].Connected == TRUE)
      return i;
  }

  return -1;  // Not found in list
}

///////////////////////////////////////////////////////////
// Network send and receive functions
///////////////////////////////////////////////////////////
BOOL cApp::SendNetworkMessage(void *Msg, long SendFlags)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;
  unsigned long Size;

  // Get size of message to send
  if((Size = mh->Size) == 0)
    return FALSE;

  // Send the mesage
  return m_Client.Send(Msg, Size, SendFlags);
}

BOOL cApp::Receive(DPNMSG_RECEIVE *Msg)
{
  sMessage *MsgPtr;

  // Get pointer to received data
  MsgPtr = (sMessage*)Msg->pReceiveData;

  // Handle packets by type
  switch(MsgPtr->Header.Type) {
    case MSG_ASSIGNID:       // Assign local player ID
      AssignID(MsgPtr);
      break;

    case MSG_PLAYER_INFO:    // Add a player to list
    case MSG_CREATE_PLAYER:
      CreatePlayer(MsgPtr);
      break;

    case MSG_DESTROY_PLAYER: // Remove a player from list
      DestroyPlayer(MsgPtr);
      break;

    case MSG_STATE_CHANGE:   // Change state of player
      ChangeState(MsgPtr);
      break;

	case MSG_MAP_CHANGE:	 // Change map of player
	  ChangeMap(MsgPtr);
	  break;

	case MSG_MONSTER_STATE:  // State of monster
	  ChangeStateMonster(MsgPtr);
	  break;

	case MSG_NUMBER:	     // Show number on monster
	  ShowNumber(MsgPtr);
	  break;

	case MSG_DEC_HP:		 // Decrease HP player	
	  DecHPPlayer(MsgPtr);
	  break;

	case MSG_FULL_HP:		 // Full HP for player die
	  FullHPPlayer(MsgPtr);
	  break;

	case MSG_STATE_CHANGE_TIME:		// Change state of player 
	  ResponseChangeState(MsgPtr);	// with calculate response time
	  break;

  }

  return TRUE;
}

///////////////////////////////////////////////////////////
// Message parsing functions
///////////////////////////////////////////////////////////
void cApp::AssignID(sMessage *Msg)
{
  sAssignPlayerIDMessage *apidm;

  // Error checking
  if(m_Players == NULL || m_Players[0].dpnidPlayer)
    return;

  // Get pointer to message data
  apidm = (sAssignPlayerIDMessage*)Msg;

  EnterCriticalSection(&m_UpdateCS);
  m_Players[0].dpnidPlayer = apidm->Header.PlayerID;
  LeaveCriticalSection(&m_UpdateCS);
}

void cApp::CreatePlayer(sMessage *Msg)
{
  sCreatePlayerMessage *cpm;
  long PlayerNum, i;

  // Error checking
  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return;

  // Get pointer to message data
  cpm = (sCreatePlayerMessage*)Msg;

  // Don't add local player to list
  if(cpm->Header.PlayerID == m_Players[0].dpnidPlayer) {

	// Enter critical section
	EnterCriticalSection(&m_UpdateCS);

	// Add player data
	m_Players[0].Connected   = TRUE;
	m_Players[0].XPos        = cpm->XPos;
	m_Players[0].YPos        = cpm->YPos;
	m_Players[0].ZPos        = cpm->ZPos;
	m_Players[0].Direction   = cpm->Direction;
	m_Players[0].Speed       = 0.0f;
	m_Players[0].State       = STATE_IDLE;
	m_Players[0].NumMap	     = cpm->NumMap;
	m_Players[0].HP		     = cpm->HP;	
	strcpy(m_Players[0].Name, cpm->Name);

    m_NumPlayers++;

	// Leave critical section
    LeaveCriticalSection(&m_UpdateCS);
	return;
  }


  // Make sure player not already in list while at
  // same time finding an empty slot.
  PlayerNum = -1;
  for(i=1;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == TRUE) {
      if(m_Players[i].dpnidPlayer == cpm->Header.PlayerID)
        return;
    } 
	else
      PlayerNum = i;
  }

  // Return error if no open slots
  if(PlayerNum == -1)
    return;

 	// Enter critical section
  EnterCriticalSection(&m_UpdateCS);

  // Add player data
  m_Players[PlayerNum].Connected   = TRUE;
  m_Players[PlayerNum].dpnidPlayer = cpm->Header.PlayerID;
  m_Players[PlayerNum].XPos        = cpm->XPos;
  m_Players[PlayerNum].YPos        = cpm->YPos;
  m_Players[PlayerNum].ZPos        = cpm->ZPos;
  m_Players[PlayerNum].Direction   = cpm->Direction;
  m_Players[PlayerNum].Speed       = 0.0f;
  m_Players[PlayerNum].State       = STATE_IDLE;
  m_Players[PlayerNum].NumMap	   = cpm->NumMap;
  m_Players[PlayerNum].HP		   = cpm->HP;	
  strcpy(m_Players[PlayerNum].Name, cpm->Name);

  m_NumPlayers++;

  // Leave critical section
  LeaveCriticalSection(&m_UpdateCS);
}

void cApp::DestroyPlayer(sMessage *Msg)
{
  sDestroyPlayerMessage *dpm;
  long PlayerNum;

  // Error checking
  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return;

  // Get pointer to message data
  dpm = (sDestroyPlayerMessage*)Msg;

  // Don't remove local player from list
  if(dpm->Header.PlayerID == m_Players[0].dpnidPlayer)
    return;

  // Get player number in list
  if((PlayerNum = GetPlayerNum(dpm->Header.PlayerID)) == -1)
    return;

  // Enter critical section
  EnterCriticalSection(&m_UpdateCS);

  // Set player as disconnected
  m_Players[PlayerNum].Connected = FALSE;
  m_NumPlayers--;

  // Leave critical section
	LeaveCriticalSection(&m_UpdateCS);
}

void cApp::ChangeState(sMessage *Msg)
{
  sStateChangeMessage *scm;
  sRequestPlayerInfoMessage rpim;
  long PlayerNum;

  // Error checking
  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return;

  // Get pointer to message data
  scm = (sStateChangeMessage*)Msg;

  // Get player number in list
  if((PlayerNum = GetPlayerNum(scm->Header.PlayerID)) == -1) {
    // Unknown player - request info 
    if(PlayerNum == -1) {
      // Construct message
      rpim.Header.Type = MSG_PLAYER_INFO;
      rpim.Header.Size = sizeof(sRequestPlayerInfoMessage);
      rpim.Header.PlayerID = m_Players[0].dpnidPlayer;
      rpim.PlayerID = scm->Header.PlayerID;

      // Send message to server
      SendNetworkMessage(&rpim, DPNSEND_NOLOOPBACK);

      return;
    }
  }

	// Enter critical section
  EnterCriticalSection(&m_UpdateCS);

  // Store new sytate info
  m_Players[PlayerNum].Time      = timeGetTime();
  m_Players[PlayerNum].State     = scm->State;
  m_Players[PlayerNum].XPos      = scm->XPos;
  m_Players[PlayerNum].YPos      = scm->YPos;
  m_Players[PlayerNum].ZPos      = scm->ZPos;
  m_Players[PlayerNum].Direction = scm->Direction;
  m_Players[PlayerNum].Speed     = scm->Speed;
  m_Players[PlayerNum].Latency   = scm->Latency;
 
  // Bounds latency to 1 second
  if(m_Players[PlayerNum].Latency > 1000)
    m_Players[PlayerNum].Latency = 1000;

  // Adjust time based on latency
  m_Players[PlayerNum].Time -= m_Players[PlayerNum].Latency;

  // Leave critical section
	LeaveCriticalSection(&m_UpdateCS);
}

void cApp::ChangeMap(sMessage *Msg)
{
  sMapChangeMessage *mcm;
  sRequestPlayerInfoMessage rpim;
  long PlayerNum;
  unsigned int Delay;

  // Get pointer to message data
  mcm = (sMapChangeMessage*)Msg;

  // Get player number in list
  if((PlayerNum = GetPlayerNum(mcm->Header.PlayerID)) == -1) {
    // Unknown player - request info 
    if(PlayerNum == -1) {
      // Construct message
      rpim.Header.Type = MSG_PLAYER_INFO;
      rpim.Header.Size = sizeof(sRequestPlayerInfoMessage);
      rpim.Header.PlayerID = m_Players[0].dpnidPlayer;
      rpim.PlayerID = mcm->Header.PlayerID;

      // Send message to server
      SendNetworkMessage(&rpim, DPNSEND_NOLOOPBACK);

      return;
    }
  }

  // Enter critical section
  EnterCriticalSection(&m_UpdateCS);

  // Store new state info
  m_Players[PlayerNum].XPos      = mcm->XPos;
  m_Players[PlayerNum].YPos      = mcm->YPos;
  m_Players[PlayerNum].ZPos      = mcm->ZPos;
  m_Players[PlayerNum].Direction = mcm->Direction;
  m_Players[PlayerNum].NumMap	 = mcm->NumMap;

  // Leave critical section
  LeaveCriticalSection(&m_UpdateCS);

  if(PlayerNum == 0)
  {
	// Display message waiting map
	m_Graphics.Clear();
	if(m_Graphics.BeginScene() == TRUE) {
		m_Font.Print("��ŴἹ���...", 0, 0);
		m_Graphics.EndScene();
	}
	m_Graphics.Display();

	Delay = timeGetTime();

	 // Change map in list
	if(m_Players[PlayerNum].NumMap == 1)
		m_NodeTreeMesh.Create(&m_Graphics, &m_TerrainMesh[0], QUADTREE);
	else if(m_Players[PlayerNum].NumMap == 2)
		m_NodeTreeMesh.Create(&m_Graphics, &m_TerrainMesh[1], QUADTREE);
	else if(m_Players[PlayerNum].NumMap == 3)
		m_NodeTreeMesh.Create(&m_Graphics, &m_TerrainMesh[2], QUADTREE);
	else if(m_Players[PlayerNum].NumMap == 4)
		m_NodeTreeMesh.Create(&m_Graphics, &m_TerrainMesh[3], QUADTREE);

	for(int i=0; i<MAX_MONSTER; i++)
		m_Monster[i].Alive = FALSE;

	while(timeGetTime() <= (Delay+2000));
  }
}

void cApp::ChangeStateMonster(sMessage *Msg)
{
	sMonsterStateMessage *msm;

	// Get pointer to message data
    msm = (sMonsterStateMessage*)Msg;

	 // Error checking
	if(m_Monster == NULL)
		return;
	if(msm->ID >= MAX_MONSTER)
		return;

	if(msm->NumMap == m_Players[0].NumMap) {

		// Enter critical section
		EnterCriticalSection(&m_UpdateCS);

		// Store new state info
		m_Monster[msm->ID].Time      = timeGetTime();
		m_Monster[msm->ID].XPos      = msm->XPos;
		m_Monster[msm->ID].YPos      = msm->YPos;
		m_Monster[msm->ID].ZPos      = msm->ZPos;
		m_Monster[msm->ID].Direction = msm->Direction;
		m_Monster[msm->ID].NumMap	 = msm->NumMap;
		m_Monster[msm->ID].Speed	 = msm->Speed;
		m_Monster[msm->ID].State	 = msm->State;
		m_Monster[msm->ID].Alive	 = msm->Alive;


		// Bounds latency to 1 second
		if(m_Players[0].Latency > 1000)
			m_Players[0].Latency = 1000;

		// Adjust time based on latency
		m_Monster[msm->ID].Time -= m_Players[0].Latency;

		// Leave critical section
		LeaveCriticalSection(&m_UpdateCS);
	}
}

void cApp::ResponseChangeState(sMessage *Msg)
{
  sStateChangeMessage *scm;
  sRequestPlayerInfoMessage rpim;
  long PlayerNum;

  // Error checking
  if(m_Players == NULL || !m_Players[0].dpnidPlayer)
    return;

  // Get pointer to message data
  scm = (sStateChangeMessage*)Msg;

  // Get player number in list
  if((PlayerNum = GetPlayerNum(scm->Header.PlayerID)) == -1) {
    // Unknown player - request info 
    if(PlayerNum == -1) {
      // Construct message
      rpim.Header.Type = MSG_PLAYER_INFO;
      rpim.Header.Size = sizeof(sRequestPlayerInfoMessage);
      rpim.Header.PlayerID = m_Players[0].dpnidPlayer;
      rpim.PlayerID = scm->Header.PlayerID;

      // Send message to server
      SendNetworkMessage(&rpim, DPNSEND_NOLOOPBACK);

      return;
    }
  }

  if(PlayerNum == 0)
	// Calculate response time
	ResponseTime = timeGetTime() - GetTime;

  // Enter critical section
  EnterCriticalSection(&m_UpdateCS);

  // Store new sytate info
  m_Players[PlayerNum].Time      = timeGetTime();
  m_Players[PlayerNum].State     = scm->State;
  m_Players[PlayerNum].XPos      = scm->XPos;
  m_Players[PlayerNum].YPos      = scm->YPos;
  m_Players[PlayerNum].ZPos      = scm->ZPos;
  m_Players[PlayerNum].Direction = scm->Direction;
  m_Players[PlayerNum].Speed     = scm->Speed;
  m_Players[PlayerNum].Latency   = scm->Latency;
 
  // Bounds latency to 1 second
  if(m_Players[PlayerNum].Latency > 1000)
    m_Players[PlayerNum].Latency = 1000;

  // Adjust time based on latency
  m_Players[PlayerNum].Time -= m_Players[PlayerNum].Latency;

  // Leave critical section
  LeaveCriticalSection(&m_UpdateCS);
}

///////////////////////////////////////////////////////////
// App initialization functions
///////////////////////////////////////////////////////////
BOOL cApp::SelectAdapter()
{
  int Result;

  // Hide main window
  ShowWindow(GethWnd(), SW_HIDE);

  // Build a list of network adapters
  m_Adapters.Init();

  // Open connection dialog
  Result=DialogBox(GethInst(), MAKEINTRESOURCE(IDD_CONNECT),  \
                   GethWnd(), ConnectDialogProc);

  // Don't continue if quit selected
  if(Result == FALSE)
    return FALSE;

  // Show main window
  ShowWindow(GethWnd(), SW_SHOW);

  // Continue if user selected OK
  return TRUE;
}

BOOL cApp::InitializeGame()
{
  long i;

  // Initialize the graphics device and set display mode
  m_Graphics.Init();
  m_Graphics.SetMode(GethWnd(), m_WindowScreen, TRUE);
  m_Graphics.SetPerspective(D3DX_PI/4, 1.3333f, 1.0f, 20000.0f);
  ShowMouse(FALSE);

  // Get a font
  m_Font.Create(&m_Graphics, "CordiaUPC", 22);
  m_NumberFont.Create(&m_Graphics, "Angsana", 38, TRUE);

  // Enable lighting and setup light
  m_Graphics.EnableLighting(TRUE);
  m_Graphics.SetAmbientLight(48,48,48);
  m_Graphics.EnableLight(0, TRUE);
  m_Light.SetAttenuation0(0.5f);
  m_Light.SetRange(1000.0f);


  // Initialize input and input devices
  m_Input.Init(GethWnd(), GethInst());
  m_Keyboard.Create(&m_Input, KEYBOARD);
  m_Mouse.Create(&m_Input, MOUSE, TRUE);

  // Load the mesh and create an NodeTree mesh from it
  m_TerrainMesh[0].Load(&m_Graphics, "..\\Data\\level1.x",        \
                                  "..\\Data\\");
  m_TerrainMesh[1].Load(&m_Graphics, "..\\Data\\level2.x",        \
                                  "..\\Data\\");
  m_TerrainMesh[2].Load(&m_Graphics, "..\\Data\\level3.x",        \
                                  "..\\Data\\");
  m_TerrainMesh[3].Load(&m_Graphics, "..\\Data\\level4.x",        \
                                  "..\\Data\\");
  //Load mesh (Warp Gate)
  m_WarpGate.Load(&m_Graphics, "..\\Data\\warp.x", "..\\Data\\");
  Warp.Create(&m_Graphics, &m_WarpGate);

  // Load the meshes and animations
  m_CharacterMesh.Load(&m_Graphics, "..\\Data\\Warrior2.x",    \
                                    "..\\Data\\");
  m_WeaponMesh.Load(&m_Graphics, "..\\Data\\Sword.x", "..\\Data\\");
  m_CharacterAnim.Load("..\\Data\\Warrior1.x", &m_CharacterMesh);
  m_CharacterAnim.SetLoop(TRUE, "Walk");
  m_CharacterAnim.SetLoop(TRUE, "Idle");
  m_CharacterAnim.SetLoop(FALSE, "Swing");
  m_CharacterAnim.SetLoop(FALSE, "Hurt");
  m_CharacterAnim.SetLoop(FALSE, "Die");

  // Load the meshes and animation for  monster
  m_MonsterMesh.Load(&m_Graphics, "..\\Data\\Yodan.x", "..\\Data\\");
  m_MonsterAnim.Load("..\\Data\\Yodan.x", &m_MonsterMesh);	
  m_MonsterAnim.SetLoop(TRUE, "Walk");
  m_MonsterAnim.SetLoop(TRUE, "Idle");
  m_MonsterAnim.SetLoop(FALSE, "Die");
  m_MonsterAnim.SetLoop(FALSE, "Swing");

  // Set the camera angle
  m_CamAngle = 0.0f;
  m_CamYAxis = 100.0f;
  Height = 10.0;

  // Set Reponse time
  ResponseTime  = 0;
  GetTime		= 0;

  // Create player structures
  m_Players = new sPlayer[MAX_PLAYERS]();

  // Create monster structures
  m_Monster = new sMonster[MAX_MONSTER]();

  // Setup player data
  for(i=0;i<MAX_PLAYERS;i++) {
    m_Players[i].Body.Create(&m_Graphics, &m_CharacterMesh);
    m_Players[i].Weapon.Create(&m_Graphics, &m_WeaponMesh);
    m_Players[i].Weapon.AttachToObject(&m_Players[i].Body, "WeaponHand");
    m_Players[i].Weapon.Rotate(1.57f, 0.0f, 0.0f);
  }
  
  // Setup monster data
  for(i=0;i<MAX_MONSTER;i++) {
    m_Monster[i].Body.Create(&m_Graphics, &m_MonsterMesh);
  }

  // Setup local player structure
  m_NumPlayers = 0;
  strcpy(m_Players[0].Name, "");
  //m_Players[0].Connected = TRUE;
  m_NodeTreeMesh.Create(&m_Graphics, &m_TerrainMesh[0], QUADTREE);


  sRequestPlayerInfoMessage rpim;

  rpim.Header.Type = MSG_PLAYER_INFO;
  rpim.Header.Size = sizeof(sRequestPlayerInfoMessage);
  rpim.Header.PlayerID = m_Players[0].dpnidPlayer;
  rpim.PlayerID = m_Players[0].dpnidPlayer;

  // Send message to server
  SendNetworkMessage(&rpim, DPNSEND_NOLOOPBACK);

  return TRUE;
}

BOOL cApp::JoinGame()
{
  // Initialize network and try to connect to host
  m_Client.Init();
  if(m_Client.Connect(m_guidAdapter, m_HostIP, 9123,          \
                      m_Name, "RPGGAME", NULL) == FALSE)
    return FALSE;

  return TRUE;  // Return success
}

///////////////////////////////////////////////////////////
// Game logic code
///////////////////////////////////////////////////////////
void cApp::UpdatePlayers()
{
  long  i;
  float XMove, ZMove, Dist, Speed;

  float Radius1,Radius2;
  float MinX, MaxX, MinZ, MaxZ;

  //float Height;
  long Elapsed;

  // Process all active player movements
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == TRUE && m_Players[0].NumMap == m_Players[i].NumMap) {

      // Get elapsed time from now and state time
      Elapsed = timeGetTime() - m_Players[i].Time;

      // Process player movement state
      if(m_Players[i].State == STATE_MOVE) {
        // Calculate amount of movement by time movement processed
        Speed = (float)Elapsed / 1000.0f * m_Players[i].Speed;
        XMove = (float)sin(m_Players[i].Direction) * Speed;
        ZMove = (float)cos(m_Players[i].Direction) * Speed;

		// Check for height changes (can step up to 64 units)
		Height = m_NodeTreeMesh.GetHeightBelow(m_Players[i].XPos, m_Players[i].YPos + 16.0f, m_Players[i].ZPos);
	
        // Check for movement collisions -
        // can't walk past anything blocking path
		if(m_NodeTreeMesh.CheckIntersect(
                            m_Players[i].XPos,
                            m_Players[i].YPos + 16.0f,
                            m_Players[i].ZPos,
                            m_Players[i].XPos + XMove,
                            m_Players[i].YPos + 16.0f,
                            m_Players[i].ZPos + ZMove,
                            &Dist) == TRUE)
		{
			XMove = ZMove = 0.0f;

			EnterCriticalSection(&m_UpdateCS);
			m_Players[i].State = STATE_IDLE;
			LeaveCriticalSection(&m_UpdateCS);
		}
	
		// Check Collision with another monsters
		for(int MonsterNum=0;MonsterNum<MAX_MONSTER;MonsterNum++){

			if(m_Monster[MonsterNum].Alive == TRUE && m_Players[0].NumMap == m_Monster[MonsterNum].NumMap)
			{
				// Bounds check 
				m_Players[i].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,      
											NULL,&MaxZ,NULL);
				Radius1 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

				m_Monster[MonsterNum].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,	
													 NULL,&MaxZ,NULL);
				Radius2 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

				// Check Intersect between two mesh
				if(CheckSphereIntersect(m_Players[i].XPos+XMove, m_Players[i].YPos,		
									 m_Players[i].ZPos+ZMove, Radius1,				
									 m_Monster[MonsterNum].XPos, m_Monster[MonsterNum].YPos,
									 m_Monster[MonsterNum].ZPos, Radius2) == TRUE )
				{
					XMove = ZMove = 0.0f;
					EnterCriticalSection(&m_UpdateCS);
					m_Players[i].State = STATE_IDLE;
					LeaveCriticalSection(&m_UpdateCS);
				}
			}
		}
      
        // Update coordinates
        EnterCriticalSection(&m_UpdateCS);
        m_Players[i].XPos += XMove;
        m_Players[i].YPos = Height;
        m_Players[i].ZPos += ZMove;
        m_Players[i].Time = timeGetTime(); // Reset time
        LeaveCriticalSection(&m_UpdateCS);
      } 

      // Set new animations as needed
      if(m_Players[i].State == STATE_IDLE) {
        if(m_Players[i].LastAnim != ANIM_IDLE) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_IDLE;
          m_Players[i].Body.SetAnimation(                     \
               &m_CharacterAnim, "Idle", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      } else
      if(m_Players[i].State == STATE_MOVE) {
        if(m_Players[i].LastAnim != ANIM_WALK) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_WALK;
          m_Players[i].Body.SetAnimation(                     \
               &m_CharacterAnim, "Walk", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      } else
      if(m_Players[i].State == STATE_SWING) {
        if(m_Players[i].LastAnim != ANIM_SWING) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_SWING;
          m_Players[i].Body.SetAnimation(                     \
               &m_CharacterAnim, "Swing", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      } else
      if(m_Players[i].State == STATE_HURT) {
        if(m_Players[i].LastAnim != ANIM_HURT) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_HURT;
          m_Players[i].Body.SetAnimation(                     \
               &m_CharacterAnim, "Hurt", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      }else
      if(m_Players[i].State == STATE_DIE) {
        if(m_Players[i].LastAnim != ANIM_DIE) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_DIE;
          m_Players[i].Body.SetAnimation(                     \
               &m_CharacterAnim, "Die", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      }
    }
  }
}

void cApp::UpdateMonster()
{
  long  i;
  float XMove, ZMove, Dist, Speed;
  float Height;
  long Elapsed;

  // Process all alive monsters movements and same map player
  for(i=0;i<MAX_MONSTER;i++) {
    if(m_Monster[i].Alive == TRUE && m_Players[0].NumMap == m_Monster[i].NumMap) {

      // Get elapsed time from now and state time
      Elapsed = timeGetTime() - m_Monster[i].Time;

      // Process player movement state
      if(m_Monster[i].State == STATE_MOVE) {
        // Calculate amount of movement by time movement processed
        Speed = (float)Elapsed / 1000.0f * m_Monster[i].Speed;
        XMove = (float)sin(m_Monster[i].Direction) * Speed;
        ZMove = (float)cos(m_Monster[i].Direction) * Speed;

		// Check for height changes (can step up to 64 units)
		Height = m_NodeTreeMesh.GetHeightBelow(m_Monster[i].XPos, m_Monster[i].YPos + 16.0f, m_Monster[i].ZPos);
	
        // Check for movement collisions -
        // can't walk past anything blocking path
		if(m_NodeTreeMesh.CheckIntersect(
                            m_Monster[i].XPos,
                            m_Monster[i].YPos + 16.0f,
                            m_Monster[i].ZPos,
                            m_Monster[i].XPos + XMove,
                            m_Monster[i].YPos + 16.0f,
                            m_Monster[i].ZPos + ZMove,
                            &Dist) == TRUE)
		{
			XMove = ZMove = 0.0f;
			EnterCriticalSection(&m_UpdateCS);
			m_Monster[i].State = STATE_IDLE;
			LeaveCriticalSection(&m_UpdateCS);
		}
      
        // Update coordinates
        EnterCriticalSection(&m_UpdateCS);
        m_Monster[i].XPos += XMove;
        m_Monster[i].YPos = Height;
        m_Monster[i].ZPos += ZMove;
        m_Monster[i].Time = timeGetTime(); // Reset time
        LeaveCriticalSection(&m_UpdateCS); 
      } 

      // Set new animations as needed
      if(m_Monster[i].State == STATE_IDLE) {
        if(m_Monster[i].LastAnim != ANIM_IDLE) {
          EnterCriticalSection(&m_UpdateCS);
          m_Monster[i].LastAnim = ANIM_IDLE;
          m_Monster[i].Body.SetAnimation(                     \
               &m_MonsterAnim, "Idle", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      } else
      if(m_Monster[i].State == STATE_MOVE) {
        if(m_Monster[i].LastAnim != ANIM_WALK) {
          EnterCriticalSection(&m_UpdateCS);
          m_Monster[i].LastAnim = ANIM_WALK;
          m_Monster[i].Body.SetAnimation(                     \
               &m_MonsterAnim, "Walk", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      }else
	  if(m_Monster[i].State == STATE_DIE) {
        if(m_Monster[i].LastAnim != ANIM_DIE) {
          EnterCriticalSection(&m_UpdateCS);
          m_Monster[i].LastAnim = ANIM_DIE;
          m_Monster[i].Body.SetAnimation(                     \
               &m_MonsterAnim, "Die", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
		}
	  }else
      if(m_Monster[i].State == STATE_SWING) {
        if(m_Monster[i].LastAnim != ANIM_SWING) {
          EnterCriticalSection(&m_UpdateCS);
          m_Monster[i].LastAnim = ANIM_SWING;
          m_Monster[i].Body.SetAnimation(                     \
               &m_MonsterAnim, "Swing", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      } /*else
      if(m_Players[i].State == STATE_HURT) {
        if(m_Players[i].LastAnim != ANIM_HURT) {
          EnterCriticalSection(&m_UpdateCS);
          m_Players[i].LastAnim = ANIM_HURT;
          m_Players[i].Body.SetAnimation(                     \
               &m_CharacterAnim, "Hurt", timeGetTime() / 32);
          LeaveCriticalSection(&m_UpdateCS);
        }
      }*/

    }
  }
}

void cApp::RenderScene()
{
  cFrustum Frustum;
  float Radius;
  long i;

  BOOL         GotMatrices = FALSE;
  D3DXMATRIX   matWorld, matView, matProj;
  D3DXVECTOR3  vecPos;
  D3DVIEWPORT8 vpScreen;
  float        MaxY;

  char		   buffer[5];
  char		   HP[] = "HP : ";
  char		   Delay[] ="˹�ǧ���� : ";

  // Center camera on player using CamAngle
  m_Camera.Point(m_Players[0].XPos +                          \
                     (float)cos(m_CamAngle) * 300.0f,         \
                 m_Players[0].YPos + m_CamYAxis,			  			                
                 m_Players[0].ZPos +                          \
                     (float)sin(m_CamAngle) * 300.0f,         \
                 m_Players[0].XPos,                           \
                 m_Players[0].YPos,                           \
                 m_Players[0].ZPos);

  // Position light
  m_Light.Move(m_Players[0].XPos, m_Players[0].YPos+60.0f, m_Players[0].ZPos);
  m_Graphics.SetLight(0, &m_Light);

  // Set camera and construct frustum
  m_Graphics.SetCamera(&m_Camera);
  Frustum.Construct(&m_Graphics);

  // Render scene
  m_Graphics.Clear();
  if(m_Graphics.BeginScene() == TRUE) {
    
    // Draw the terrain
    m_Graphics.EnableZBuffer(TRUE);
    m_NodeTreeMesh.Render(&Frustum);

    // Draw all characters active and in view and same map
    for(i=0;i<MAX_PLAYERS;i++) {
      if(m_Players[i].Connected == TRUE && m_Players[0].NumMap == m_Players[i].NumMap) {

        // Bounds check if player in view
        m_Players[i].Body.GetBounds(NULL,NULL,NULL,NULL,      \
                                    &MaxY,NULL,&Radius);

        if(Frustum.CheckSphere(m_Players[i].XPos,             \
                               m_Players[i].YPos,             \
                               m_Players[i].ZPos,             \
                               Radius) == TRUE) {

          // Position character and rotate
          m_Players[i].Body.Move(m_Players[i].XPos,           \
                                 m_Players[i].YPos,           \
                                 m_Players[i].ZPos);
          m_Players[i].Body.Rotate(0.0f,                      \
                                   m_Players[i].Direction,    \
                                   0.0f);
		  
          // Render body and weapon
          m_Players[i].Body.UpdateAnimation(timeGetTime()/32, \
                                            TRUE);
          m_Players[i].Body.Render();
          m_Players[i].Weapon.Render();

		  // Get the matrices and viewport if not done already
		  if(GotMatrices == FALSE) {
			 GotMatrices = TRUE;

			// Get the world, projection, and view transformations
			D3DXMatrixIdentity(&matWorld);
			m_Graphics.GetDeviceCOM()->GetTransform(           \
					                  D3DTS_VIEW, &matView);
			m_Graphics.GetDeviceCOM()->GetTransform(           \
					                  D3DTS_PROJECTION, &matProj);
			// Get viewport
			m_Graphics.GetDeviceCOM()->GetViewport(&vpScreen);
		  }

		  // Project coordinates to screen  
		  D3DXVec3Project(&vecPos,                              
					&D3DXVECTOR3(m_Players[i].XPos,                 
                    m_Players[i].YPos+(MaxY*1.2f),     
                    m_Players[i].ZPos),                
					&vpScreen, &matProj, &matView, &matWorld);

		  // Print all player name except owner
		  if(i != 0)
			m_Font.Print(m_Players[i].Name,                       
						(long)vecPos.x  - ((strlen(m_Players[i].Name)/2)*10), (long)vecPos.y,         
						0, 0, D3DCOLOR_RGBA(255,255,255,255));
		  
		  // Render warp map 
		  if(m_Players[0].NumMap == 1)
		  {
			  Warp.Move(67.0f, 40.0f, -1100.0f);
			  Warp.RotateRel(0, 40.0f+1, 0);
			  Warp.Render();
		  }
		  else if(m_Players[0].NumMap == 2)
		  {
			  Warp.Move(-800.0f, 40.0f, -720.0f);
			  Warp.RotateRel(0, 40.0f+1, 0);
			  Warp.Render();
			  Warp.Move(1070.0f, 40.0f, -995.0f);
			  Warp.RotateRel(0, 40.0f+1, 0);
			  Warp.Render();
		  }
		  else if(m_Players[0].NumMap == 3)
		  {
			  Warp.Move(2110.0f, 40.0f, 74.0f);
			  Warp.RotateRel(0, 40.0f+1, 0);
			  Warp.Render();
			  //Warp.Move(-1900.0f, 40.0f, 2120.0f);
			  //Warp.RotateRel(0, 40.0f+1, 0);
			  //Warp.Render();
		  }		
        }
      }
    }
	
	// Draw all monsters alive and in view and same map with player
	for(i=0;i<MAX_MONSTER;i++){
		if(m_Monster[i].Alive == TRUE && m_Players[0].NumMap == m_Monster[i].NumMap) {

			// Bounds check if monster in view
			m_Monster[i].Body.GetBounds(NULL,NULL,NULL,NULL,      \
										&MaxY,NULL,&Radius);

			if(Frustum.CheckSphere(m_Monster[i].XPos,             \
				                   m_Monster[i].YPos,             \
						           m_Monster[i].ZPos,             \
					               Radius) == TRUE) {

				// Position monster and rotate
				m_Monster[i].Body.Move(m_Monster[i].XPos,           \
									 m_Monster[i].YPos,           \
									 m_Monster[i].ZPos);

				m_Monster[i].Body.Rotate(0.0f,                      \
										m_Monster[i].Direction,    \
										0.0f);
		  
				// Render body monster
				m_Monster[i].Body.UpdateAnimation(timeGetTime()/32, \
													TRUE);
				m_Monster[i].Body.Render();
			
				// Project coordinates to screen  
				D3DXVec3Project(&vecPos,                              
			   				&D3DXVECTOR3(m_Monster[i].XPos,                 
							m_Monster[i].YPos+(MaxY*0.5f),     
							m_Monster[i].ZPos),                
							&vpScreen, &matProj, &matView, &matWorld);

				if(m_Monster[i].Number != 0) {
				
					if(m_Monster[i].Number == -1){
						m_NumberFont.Print("Miss", (long)vecPos.x, (long)vecPos.y,
							0, 0, D3DCOLOR_RGBA(255,255,255,200));
					}
					else{
						_itoa(m_Monster[i].Number, buffer, 10);

						m_NumberFont.Print(buffer, (long)vecPos.x , (long)vecPos.y,         
						0, 0, D3DCOLOR_RGBA(255,0,0,200));
					}

					if((timeGetTime() - m_Monster[i].DelayNum) > 1000)
						m_Monster[i].Number = 0;
				}
			}
		}
	}

	// Print own name and HP remain
	m_Font.Print(m_Players[0].Name, 0, 10);
	if(m_Players[0].HP < 0)
		m_Players[0].HP = 0;
	_itoa(m_Players[0].HP, buffer, 10);
	m_Font.Print(strcat(HP, buffer), 0, 40);

	// Print response time
	_itoa(ResponseTime, buffer, 10);
	m_Font.Print(strcat(Delay, buffer), m_Graphics.GetWidth()-150, 0);

    m_Graphics.EndScene();
  }

  m_Graphics.Display();  // Display the scene
}

BOOL cApp::CheckSphereIntersect(				\
float XCenter1, float YCenter1, float ZCenter1, \
float Radius1,									\
float XCenter2, float YCenter2, float ZCenter2, \
float Radius2)
{

	float XDiff, YDiff, ZDiff, Distance;

	// Calculate distance between center points
	XDiff = (float)fabs(XCenter2-XCenter1);
	YDiff = (float)fabs(YCenter2-YCenter1);
	ZDiff = (float)fabs(ZCenter2-ZCenter1);
	Distance = XDiff*XDiff + YDiff*YDiff + ZDiff*ZDiff;

	// Don't allow movement if intersecting
	if(Distance <= (Radius1*Radius1 + Radius2*Radius2))
		return TRUE;

	// No intersection
	return FALSE;

}

void cApp::ShowNumber(sMessage *Msg)
{
	sNumberMessage *nm;
	nm = (sNumberMessage*)Msg;

	if(nm->ID >= MAX_MONSTER)
		return;
	if(m_Monster == NULL)
		return;

	if(nm->NumMap == m_Players[0].NumMap){
		EnterCriticalSection(&m_UpdateCS);
		m_Monster[nm->ID].Number	= nm->Number;
		m_Monster[nm->ID].DelayNum	= timeGetTime();
		LeaveCriticalSection(&m_UpdateCS);
	}
}

void cApp::DecHPPlayer(sMessage *Msg)
{
	sDecHPPlayerMessage *sdpm;
	sdpm = (sDecHPPlayerMessage*)Msg;

	EnterCriticalSection(&m_UpdateCS);
	m_Players[0].HP	-= sdpm->Dec_HP;
	LeaveCriticalSection(&m_UpdateCS);
}

void cApp::FullHPPlayer(sMessage *Msg)
{
	sFullHPPlayerMessage *fhpm;
	fhpm = (sFullHPPlayerMessage*)Msg;

	EnterCriticalSection(&m_UpdateCS);
	m_Players[0].HP		= fhpm->HP_FULL;
	LeaveCriticalSection(&m_UpdateCS);
}

///////////////////////////////////////////////////////////
// Client class code
///////////////////////////////////////////////////////////
BOOL cClient::ConnectComplete(DPNMSG_CONNECT_COMPLETE *Msg) 
{ 
  // Save connection status
  if(Msg->hResultCode == S_OK)
    g_Connected = TRUE;
  else
    g_Connected = FALSE;

  return TRUE; 
}

BOOL cClient::Receive(DPNMSG_RECEIVE *Msg)
{
  // Send message to application class instance (if any)
  if(g_Application != NULL)
    g_Application->Receive(Msg);
  return TRUE;
}


