/**************************************************
Cluster Game 3D Online

OLALA Group

Required libraries:
  D3D8.LIB, D3DX8.LIB, DINPUT8.LIB, D3DXOF.LIB,
  DXGUID.LIB, DPNET.LIB, DPLAY.LIB, and DPNADDR.LIB
**************************************************/

#include "Core_Global.h"
#include "WinMain.h"
#include "resource.h"

cApp            *g_Application; // Global application pointer
cNetworkAdapter *g_Adapters;    // Global adapter list pointer

BOOL             g_Connected = FALSE;  // Connection status
BOOL			 g_Connecting = TRUE;  // Connecting status
BOOL			 ReceiveMapInfo = FALSE;// Cluster recive map number
int				 Map;

///////////////////////////////////////////////////////////
// cApp overidden virtual functions
///////////////////////////////////////////////////////////
cApp::cApp()
{ 
  // Setup main window information
  m_Width  = 320; 
  m_Height = 300;
  m_Style  = WS_BORDER | WS_CAPTION |                         \
             WS_MINIMIZEBOX | WS_SYSMENU;
  m_wcex.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
  strcpy(m_Class, "ClusterClass");
  strcpy(m_Caption, "����������ʵ�"); 

  // Clear class data
  m_Messages    = NULL;
  m_Players     = NULL;
  m_Monster		= NULL;
  m_guidAdapter = NULL;
  g_Application = this;
  g_Adapters    = &m_Adapters;

  // Create a critical section for updating data
  InitializeCriticalSection(&m_UpdateCS);
}

BOOL cApp::Init()
{
  // Select a network adapter to use (or quit if selected)
  if(SelectAdapter() == FALSE)
    return FALSE;

  // Setup the main interface window
  SetupApplicationWindow();

  // Initialize the game, set video mode, load data, etc
  if(InitializeGame() == FALSE) {
    Error(FALSE, "Unable to initialize game.");
    return FALSE;
  }

  // Join networked game
  if(JoinGame() == FALSE) {
    Error(FALSE, "Unable to connect to server.");
    return FALSE;
  }

  return TRUE;
}

BOOL cApp::Shutdown()
{
  // Shutdown network
  m_Adapters.Shutdown();
  m_Client.Disconnect();
  m_Client.Shutdown();

  // Delete message array
  delete [] m_Messages;
  m_Messages = NULL;

  // Free players
  delete [] m_Players;
  m_Players = NULL;

  //Free monsters
  delete [] m_Monster;
  m_Monster = NULL;

  // Free meshes
  m_TerrainMesh[0].Free();
  m_TerrainMesh[1].Free();
  m_TerrainMesh[2].Free();

  m_CharacterMesh.Free();
  m_MonsterMesh.Free();

  // Shutdown graphics
  m_Graphics.Shutdown();

  // Remove critical section
  DeleteCriticalSection(&m_UpdateCS);

  return TRUE;
}

BOOL cApp::Frame()
{
	if(ReceiveMapInfo == TRUE) {

		// Change message connectiing to list players
		if(g_Connected == TRUE && g_Connecting == TRUE){
			Map = NumMap - 1;
			CreateMonster();
			ListPlayers();
			g_Connecting = FALSE;
		}

		static DWORD PlayerCounter = timeGetTime();
		static DWORD NetworkCounter = timeGetTime();

		// Update players and monster every 33ms (30 times a second)
		if(timeGetTime() > PlayerCounter + 33) {
			UpdatePlayers();
			UpdateMonster();
			PlayerCounter = timeGetTime(); // Reset counter
		}

		// Send out network updates every 200ms (20 times a second)
		if(timeGetTime() > NetworkCounter + 200) {
			UpdateNetwork();
			NetworkCounter = timeGetTime(); // Reset counter
		}
	}
	return TRUE;
}

FAR PASCAL cApp::MsgProc(HWND hWnd, UINT uMsg,                \
                         WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) {
    case WM_DESTROY:
      PostQuitMessage(0);
      break;
    default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return 0;
}    

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow)
{
  cApp App;
  return App.Run();
}

///////////////////////////////////////////////////////////
// Select adapter dialog and other functions
///////////////////////////////////////////////////////////
BOOL CALLBACK ConnectDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam)
{
  int Selection;
  long i;
  char IP[16], Text[256];
  static HWND hAdapters;

  switch(uMsg) {
    case WM_INITDIALOG:
      // Get adapter list window handle
      hAdapters = GetDlgItem(hWnd, IDC_ADAPTERS);

      // Add adapter names to list
      for(i=0;i<g_Adapters->GetNumAdapters();i++) {
        g_Adapters->GetName(i, Text);
        SendMessage(hAdapters, CB_INSERTSTRING,i,(LPARAM)Text);
      }

      // Select first adapter in list
      SendMessage(hAdapters, CB_SETCURSEL, 0, 0);

      // Clear fields
      SetWindowText(GetDlgItem(hWnd, IDC_HOSTIP), "127.0.0.1");

      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam)) {

        case IDC_OK:
          // Make sure an adapter was selected
          if((Selection = SendMessage(hAdapters,              \
                                      CB_GETCURSEL,           \
                                      0, 0)) == LB_ERR)
            break;

          // Make sure there's an IP entered
          GetWindowText(GetDlgItem(hWnd, IDC_HOSTIP), IP, 16);
          if(!strlen(IP))
            break;

          // Assign Adapter, IP
          if(g_Application != NULL)
            g_Application->SetInfo(                           \
                    g_Adapters->GetGUID(Selection), IP);

          // Quit dialog
          EndDialog(hWnd, TRUE);
          return TRUE;

        case IDC_CANCEL:
          EndDialog(hWnd, FALSE);
          return TRUE;
      }

  }
  return FALSE;
}

void cApp::SetInfo(GUID *Adapter, char *IP)
{
  m_guidAdapter = Adapter;
  strcpy(m_HostIP, IP);
}

///////////////////////////////////////////////////////////
// Misc. application functions
///////////////////////////////////////////////////////////
void cApp::ListPlayers()
{
  long i;
  char Text[256];
  char Message[256] = "";
// char Number[2];

  // Error checking
  if(m_Players == NULL)
    return;

  // Clear player list
  SendMessage(m_Controls[2], LB_RESETCONTENT, 0, 0);

  // Count all players and add names to list
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == TRUE)
	{
	  strcat(Message, m_Players[i].Name);
	 // strcat(Message, " ����Ἱ��������Ţ ");
	 // itoa(m_Players[i].NumMap, Number, 10);
	 // strcat(Message, Number);

      SendMessage(m_Controls[2], LB_ADDSTRING, 0,             \
                 (LPARAM)Message);
	  strcpy(Message,"");
	}
  }

  // Display player count
  if(!m_NumPlayers){

	//Caption No Connected Players
	sprintf(Text, "����ռ������������� ��Ἱ��������Ţ %lu", NumMap);
    SetWindowText(m_Controls[1], Text); 
  }
  else {

	//Caption amount of Players Connected
    sprintf(Text, "�ռ������������� %lu �� ��Ἱ��������Ţ %lu", m_NumPlayers, NumMap);
    SetWindowText(m_Controls[1], Text);
  }
}

///////////////////////////////////////////////////////////
// Network send and receive functions
///////////////////////////////////////////////////////////
BOOL cApp::SendNetworkMessage(void *Msg, long SendFlags)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;
  unsigned long Size;

  // Get size of message to send
  if((Size = mh->Size) == 0)
    return FALSE;

  // Send the mesage
  return m_Client.Send(Msg, Size, SendFlags);
}

BOOL cApp::Receive(DPNMSG_RECEIVE *Msg)
{
  
  sMessageHeader *mh = (sMessageHeader*)Msg->pReceiveData;
  sMessage	*MsgPtr	 = (sMessage*)Msg->pReceiveData;

  // Make sure it's a valid message type and queue it
  switch(mh->Type) {

	case MSG_CREATE_PLAYER_MAP:  // Add a player
      AddPlayer(MsgPtr);
      break;

    case MSG_DESTROY_PLAYER_MAP: // Remove a player
      RemovePlayer(MsgPtr);
      break;

    case MSG_STATE_CHANGE_MAP:	 // State player change	
	  PlayerStateChange(MsgPtr);
	  break;

	case MSG_CLUSTER_MAP:		 // Assign map number to cluster
	  AssignMap(MsgPtr);
      break;
  }

  return TRUE;
}

///////////////////////////////////////////////////////////////////
// Process Game Function											
///////////////////////////////////////////////////////////////////
void cApp::AddPlayer(sMessage *Msg)
{
  sCreatePlayerMessage *cpm;
  long PlayerNum, i;

  // Get pointer to message data
  cpm = (sCreatePlayerMessage*)Msg;

  // Make sure player not already in list while at
  // same time finding an empty slot.
  PlayerNum = -1;
  for(i=1;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == TRUE) {
      if(m_Players[i].dpnidPlayer == cpm->Header.PlayerID)
        return;
    } 
	else
      PlayerNum = i;
  }

  // Return error if no open slots
  if(PlayerNum == -1)
    return;

  EnterCriticalSection(&m_UpdateCS);

  // Add player data
  m_Players[PlayerNum].Connected   = TRUE;
  m_Players[PlayerNum].dpnidPlayer = cpm->Header.PlayerID;
  m_Players[PlayerNum].XPos        = cpm->XPos;
  m_Players[PlayerNum].YPos        = cpm->YPos;
  m_Players[PlayerNum].ZPos        = cpm->ZPos;
  m_Players[PlayerNum].Direction   = cpm->Direction;
  m_Players[PlayerNum].Speed       = 256.0f;
  m_Players[PlayerNum].State       = STATE_IDLE;
  m_Players[PlayerNum].NumMap	   = cpm->NumMap;
  m_Players[PlayerNum].HP		   = cpm->HP;	
  strcpy(m_Players[PlayerNum].Name, cpm->Name);

  LeaveCriticalSection(&m_UpdateCS);

  m_NumPlayers++;		// Add Number Player

  ListPlayers();        // List all players

}

BOOL cApp::RemovePlayer(sMessage *Msg)
{
  long i;

  // Error checking
  if(m_Players == NULL)
    return FALSE;

  // Search for player in list
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
       m_Players[i].Connected == TRUE) {

	  EnterCriticalSection(&m_UpdateCS);
      m_Players[i].Connected = FALSE;  // Disconnect player
	  LeaveCriticalSection(&m_UpdateCS);

	  m_NumPlayers--;		//subtractive amount of player

      // List all players
      ListPlayers();

      return TRUE;
    }
  }

  return FALSE;  // Return failure
}

BOOL cApp::PlayerStateChange(sMessage *Msg)
{
	
  sStateChangeMessage *scm, uscm;
  sMonsterStateMessage msm;
  long i, PlayerNum;
  float XDiff, ZDiff, Dist, Angle;
  long DecHP_Monster;
  BOOL AllowChange;

  // Error checking
  if(m_Players == NULL)
    return FALSE;

  // Get pointer to state change message
  scm = (sStateChangeMessage*)Msg;

  // Get player number in list
  PlayerNum = -1;
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
       m_Players[i].Connected == TRUE) {
      PlayerNum = i;
      break;
    }
  }
  if(PlayerNum == -1)
    return FALSE;

  AllowChange = TRUE;  // Flag to allow changes in state

  // Refuse to update player if swinging sword
  if(m_Players[PlayerNum].State == STATE_SWING)
    AllowChange = FALSE;

  // Refuse to update player if hurt
  if(m_Players[PlayerNum].State == STATE_HURT)
    AllowChange = FALSE;

  //Refuse to update player if die
  if(m_Players[PlayerNum].State == STATE_DIE)
	AllowChange = FALSE;


  // Only change state if allowed
  if(AllowChange == TRUE) {

	EnterCriticalSection(&m_UpdateCS);

    // Update selected player
    m_Players[PlayerNum].Time      = timeGetTime();
    m_Players[PlayerNum].State     = scm->State;
    m_Players[PlayerNum].Direction = scm->Direction;

    // Adjust action time based on latency
    m_Players[PlayerNum].Time -= m_Players[PlayerNum].Latency;

	LeaveCriticalSection(&m_UpdateCS);

    // Send player data to all clients
    uscm.Header.Type     = MSG_STATE_CHANGE_TIME;
    uscm.Header.Size     = sizeof(sStateChangeMessage);
    uscm.Header.PlayerID = m_Players[PlayerNum].dpnidPlayer;
    uscm.State           = m_Players[PlayerNum].State;
    uscm.XPos            = m_Players[PlayerNum].XPos;
    uscm.YPos            = m_Players[PlayerNum].YPos;
    uscm.ZPos            = m_Players[PlayerNum].ZPos;
    uscm.Direction       = m_Players[PlayerNum].Direction;
    uscm.Speed           = m_Players[PlayerNum].Speed;
    SendNetworkMessage(&uscm, DPNSEND_NOLOOPBACK);

    // If swinging sword, determine who's hurt
    if(scm->State == STATE_SWING) {

      // Check all monsters
      for(i=0;i<MAX_MONSTER;i++) {
        
        // Only check against other players that are connected
        if(m_Monster[i].Alive == TRUE &&
		   m_Monster[i].State != STATE_DIE) {

          // Get distance to player
          XDiff = (float)fabs(m_Players[PlayerNum].XPos -     \
                              m_Monster[i].XPos);
          ZDiff = (float)fabs(m_Players[PlayerNum].ZPos -     \
                              m_Monster[i].ZPos);
          Dist = XDiff*XDiff + ZDiff*ZDiff;

          // Continue if distance between players acceptable
          if(Dist < 10000.0f) {
            
            // Get angle between players
            Angle = -(float)atan2(                            \
                           (m_Monster[i].ZPos -               \
                            m_Players[PlayerNum].ZPos),       \
                           (m_Monster[i].XPos -               \
                            m_Players[PlayerNum].XPos)) +     \
                            1.570796f;

             // Adjust for attacker's direction
            Angle -= m_Players[PlayerNum].Direction;

            Angle += 0.785f; // Adjust for FOV

            // Bounds angle value
            if(Angle < 0.0f)
              Angle += 6.28f;
            if(Angle >= 6.28f)
              Angle -= 6.28f;
                       
            // Player hit if in front of attacker (90 FOV)
            if(Angle >= 0.0f && Angle <= 1.570796f) {
				
				if((rand() % 100) < 80) 
				{
					//Attack complete
					while((DecHP_Monster = rand() % 15) < 7);

					// Decrease HP Monster
					EnterCriticalSection(&m_UpdateCS);
					m_Monster[i].HP -= DecHP_Monster;
					LeaveCriticalSection(&m_UpdateCS);

					sNumberMessage nm;
					nm.Header.Type  = MSG_NUMBER;
					nm.Header.Size  = sizeof(sMonsterStateMessage);
					nm.ID			= m_Monster[i].ID;
					nm.Number		= DecHP_Monster;
					nm.NumMap		= NumMap;
					SendNetworkMessage(&nm, DPNSEND_NOLOOPBACK);
              
					if(m_Monster[i].HP <= 0) {

						EnterCriticalSection(&m_UpdateCS);
						m_Monster[i].State = STATE_DIE;
						m_Monster[i].Time = timeGetTime();
						LeaveCriticalSection(&m_UpdateCS);

						// Send network message
						msm.Header.Type = MSG_MONSTER_STATE;
						msm.Header.Size = sizeof(sMonsterStateMessage);
						msm.ID			= m_Monster[i].ID;
						msm.State		= m_Monster[i].State;
						msm.XPos		= m_Monster[i].XPos;
						msm.YPos		= m_Monster[i].YPos;
						msm.ZPos		= m_Monster[i].ZPos;
						msm.Direction	= m_Monster[i].Direction;
						msm.Speed		= m_Monster[i].Speed;
						SendNetworkMessage(&msm, DPNSEND_NOLOOPBACK);
					}
				}
				else{
					// Attack missed  
					sNumberMessage nm;
					nm.Header.Type  = MSG_NUMBER;
					nm.Header.Size  = sizeof(sMonsterStateMessage);
					nm.ID			= m_Monster[i].ID;
					nm.Number		= -1; 
					SendNetworkMessage(&nm, DPNSEND_NOLOOPBACK);
				}
            }
          }
        }
      }
    }
  }

  return TRUE;
}


///////////////////////////////////////////////////////////
// App initialization functions
///////////////////////////////////////////////////////////
BOOL cApp::SelectAdapter()
{
  int Result;

  // Hide main window
  ShowWindow(GethWnd(), SW_HIDE);

  // Build a list of network adapters
  m_Adapters.Init();

  // Open connection dialog
  Result=DialogBox(GethInst(), MAKEINTRESOURCE(IDD_CONNECT),  \
                   GethWnd(), ConnectDialogProc);

  // Don't continue if quit selected
  if(Result == FALSE)
    return FALSE;

  // Continue if user selected OK
  return TRUE;
}

void cApp::SetupApplicationWindow()
{
  // Create the windows controls

  // Window to hold host IP address
  m_Controls[0] = CreateWindow("STATIC", "",                  \
          WS_CHILD | WS_VISIBLE,                              \
          4, 4, 312, 18,                                      \
          GethWnd(), NULL, GethInst(), NULL);

  // Window to hold # of connected players
  m_Controls[1] = CreateWindow("STATIC",                      \
          "����ռ�������������",                             \
          WS_CHILD | WS_VISIBLE,                              \
          4, 26, 312, 18,                                     \
          GethWnd(), NULL, GethInst(), NULL);

  // List box to display connect player's names and map number
  m_Controls[2] = CreateWindow("LISTBOX", "",                 \
          WS_CHILD | WS_BORDER | WS_VSCROLL | WS_VISIBLE,     \
          4, 48, 312, 250,                                    \
          GethWnd(), NULL, GethInst(), NULL);   

  // Show main window
  ShowWindow(GethWnd(), SW_SHOW);
}

BOOL cApp::InitializeGame()
{
  int i;

  // Initialize the graphics device and set display mode
  m_Graphics.Init();
  m_Graphics.SetMode(GethWnd());

  // Load the level mesh for collision checking
  m_TerrainMesh[0].Load(&m_Graphics, "..\\Data\\level1.x");
  m_TerrainMesh[1].Load(&m_Graphics, "..\\Data\\level2.x");
  m_TerrainMesh[2].Load(&m_Graphics, "..\\Data\\level3CM.x");

  // Load the meshes for collision checking
  m_CharacterMesh.Load(&m_Graphics, "..\\Data\\Warrior.x", "..\\Data\\");
  m_MonsterMesh.Load(&m_Graphics, "..\\Data\\Yodan.x", "..\\Data\\");
   
  // Allocate message queue and reset message pointers
  //m_Messages = new sMessage[NUM_MESSAGES]();
  //m_MsgHead = m_MsgTail = 0;

  // Create player structures
  m_Players = new sPlayer[MAX_PLAYERS]();

  // Create monster structures
  m_Monster = new sMonster[MAX_MONSTER]();

  // Setup player data
  for(i=0;i<MAX_PLAYERS;i++) {
    m_Players[i].Body.Create(&m_Graphics, &m_CharacterMesh);
  }
  
  // Setup monster data
  for(i=0;i<MAX_MONSTER;i++) {
    m_Monster[i].Body.Create(&m_Graphics, &m_MonsterMesh);
  }

  // Load trigger map
  m_Trigger[0].Load("..\\Data\\Level1.trg");
  m_Trigger[1].Load("..\\Data\\Level2.trg");
  m_Trigger[2].Load("..\\Data\\Level3.trg");

  // Display message(Connecting Server)
  SetWindowText(m_Controls[1], "���ѧ�������͡Ѻ���������");  

 // Reset # of players
  m_NumPlayers = 0;
  return TRUE;
}

BOOL cApp::JoinGame()
{
  char Text[33], IP[16];
  
  // Initialize network and try to connect to host
  m_Client.Init();
  if(m_Client.Connect(m_guidAdapter, m_HostIP, 9123,          \
                      "Server", "RPGGAME", NULL) == FALSE)
    return FALSE;

  // Get Server IP address and display in application window
  m_Client.GetIP(IP);

 // Caption Server IP Address 
  sprintf(Text, "�;դ�������: %s", IP);
  SetWindowText(m_Controls[0], Text);

  return TRUE;  // Return success
}

///////////////////////////////////////////////////////////////////
//  update functions							
///////////////////////////////////////////////////////////////////
void cApp::UpdatePlayers()
{
  long i;
  float XMove, ZMove, Speed;
  float Height;

  float Radius1,Radius2;
  float MinX, MaxX, MinZ, MaxZ;

  sStateChangeMessage scm;
  sMapChangeMessage mcm;
  sFullHPPlayerMessage fhpm;

  long Elapsed;
  long TriggerID;

  // Loop through all players
  for(i=0;i<MAX_PLAYERS;i++) {

    // Only update connected players
    if(m_Players[i].Connected == TRUE) {

      // Get elapsed time from now and state time
      Elapsed = timeGetTime() - m_Players[i].Time;

      // Process player movement state
      if(m_Players[i].State == STATE_MOVE) {

        // Calculate amount of movement by time passed
        Speed = (float)Elapsed / 1000.0f * m_Players[i].Speed;
        XMove = (float)sin(m_Players[i].Direction) * Speed;
        ZMove = (float)cos(m_Players[i].Direction) * Speed;

		// Check for height changes (can step up to 64 units)
		Height = GetHeightBelow(&m_TerrainMesh[Map] ,m_Players[i].XPos, m_Players[i].YPos + 16.0f, m_Players[i].ZPos);
		
        // Check for movement collisions -
        // can't walk past anything blocking path.
			if(CheckIntersect(&m_TerrainMesh[Map],                       \
                          m_Players[i].XPos,                  \
                          m_Players[i].YPos + 16.0f,          \
                          m_Players[i].ZPos,                  \
                          m_Players[i].XPos + XMove,          \
                          m_Players[i].YPos + 16.0f,          \
                          m_Players[i].ZPos + ZMove) == TRUE)
			{
				XMove = ZMove = 0.0f;

				EnterCriticalSection(&m_UpdateCS);
				m_Players[i].State = STATE_IDLE;
				LeaveCriticalSection(&m_UpdateCS);
			}
	
		
		// Check Collision with another monsters
		for(int MonsterNum=0;MonsterNum<MAX_MONSTER;MonsterNum++){

			if(m_Monster[MonsterNum].Alive == TRUE)
			{
				// Bounds check 
				m_Players[i].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,      
											NULL,&MaxZ,NULL);
				Radius1 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

				m_Monster[MonsterNum].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,	
													 NULL,&MaxZ,NULL);
				Radius2 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

				// Check Intersect between two mesh
				if(CheckSphereIntersect(m_Players[i].XPos+XMove, m_Players[i].YPos,		
									 m_Players[i].ZPos+ZMove, Radius1,				
									 m_Monster[MonsterNum].XPos, m_Monster[MonsterNum].YPos,
									 m_Monster[MonsterNum].ZPos, Radius2) == TRUE )
				{
					XMove = ZMove = 0.0f;
					
					EnterCriticalSection(&m_UpdateCS);
					m_Players[i].State = STATE_IDLE;
					LeaveCriticalSection(&m_UpdateCS);
				}
			}
		}

		EnterCriticalSection(&m_UpdateCS);
        // Update player coordinates
        m_Players[i].XPos += XMove;
        m_Players[i].YPos = Height;         // Stay on ground
        m_Players[i].ZPos += ZMove;
        m_Players[i].Time = timeGetTime();  // Reset time
		LeaveCriticalSection(&m_UpdateCS);
      }

	  // Trigger change map if any triggers hit
      if((TriggerID = m_Trigger[Map].GetTrigger(m_Players[i].XPos, m_Players[i].YPos, m_Players[i].ZPos))) {

		if(NumMap == 1)
		{
			EnterCriticalSection(&m_UpdateCS);
			m_Players[i].XPos = -867.0f;
			m_Players[i].YPos = 0.0f;
			m_Players[i].ZPos = -91.0f;
			m_Players[i].Direction = 0.0f;
			m_Players[i].NumMap++;
			LeaveCriticalSection(&m_UpdateCS);
		}
		else if(NumMap == 2)
		{
			if(TriggerID == 1)
			{
				EnterCriticalSection(&m_UpdateCS);
				m_Players[i].XPos = 0.0f;
				m_Players[i].YPos = 0.0f;
				m_Players[i].ZPos = 0.0f;
				m_Players[i].Direction = 0.0f;
				m_Players[i].NumMap--;
				LeaveCriticalSection(&m_UpdateCS);
			}
			else if(TriggerID == 2)
			{
				EnterCriticalSection(&m_UpdateCS);
				m_Players[i].XPos = 1190.0f;
				m_Players[i].YPos = 0.0f;
				m_Players[i].ZPos = 73.0f;
				m_Players[i].Direction = 0.0f;
				m_Players[i].NumMap++;
				LeaveCriticalSection(&m_UpdateCS);
			}
		}
		else if(NumMap == 3)
		{
			if(TriggerID == 1)
			{
				EnterCriticalSection(&m_UpdateCS);
				m_Players[i].XPos = 919.0f;
				m_Players[i].YPos = 0.0f;
				m_Players[i].ZPos = -631.0f;
				m_Players[i].Direction = 0.0f;;
				m_Players[i].NumMap--;
				LeaveCriticalSection(&m_UpdateCS);
			}
		}
		
		// Send network message to player
		mcm.Header.Type = MSG_MAP_CHANGE;
		mcm.Header.Size = sizeof(sMapChangeMessage);
		mcm.Header.PlayerID = m_Players[i].dpnidPlayer;
        mcm.XPos            = m_Players[i].XPos;
        mcm.YPos            = m_Players[i].YPos;
        mcm.ZPos            = m_Players[i].ZPos;
        mcm.Direction       = m_Players[i].Direction;
		mcm.NumMap			= m_Players[i].NumMap;
		
		// Send the message over network
        SendNetworkMessage(&mcm, DPNSEND_NOLOOPBACK);
		
		EnterCriticalSection(&m_UpdateCS);
		m_Players[i].Connected	= FALSE;
		LeaveCriticalSection(&m_UpdateCS);
		
		m_NumPlayers--;		// dec count player 
		ListPlayers();
      }

	  // Clear die status after 4 second
      if(m_Players[i].State == STATE_DIE) {
        if(Elapsed > 4000) {

		  EnterCriticalSection(&m_UpdateCS);
          m_Players[i].State = STATE_IDLE;
		  m_Players[i].HP    = 200;
		  LeaveCriticalSection(&m_UpdateCS);

		  fhpm.Header.Type		= MSG_FULL_HP;
		  fhpm.Header.Size		= sizeof(sFullHPPlayerMessage);
		  fhpm.Header.PlayerID  = m_Players[i].dpnidPlayer;
		  fhpm.HP_FULL			= 200;
		  SendNetworkMessage(&fhpm, DPNSEND_NOLOOPBACK);

          // Send network message to player to clear
          scm.Header.Type     = MSG_STATE_CHANGE_MAP;
          scm.Header.Size     = sizeof(sStateChangeMessage);
          scm.Header.PlayerID = m_Players[i].dpnidPlayer;
          scm.XPos            = m_Players[i].XPos;
          scm.YPos            = m_Players[i].YPos;
          scm.ZPos            = m_Players[i].ZPos;
          scm.Direction       = m_Players[i].Direction;
          scm.Speed           = m_Players[i].Speed;
          scm.State           = m_Players[i].State;

          // Send the message over network
          SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);
        }
      }

      // Clear swing status after 500 millisecond
      else if(m_Players[i].State == STATE_SWING) {
        if(Elapsed > 500) {

		  EnterCriticalSection(&m_UpdateCS);
          m_Players[i].State = STATE_IDLE;
		  LeaveCriticalSection(&m_UpdateCS);

          // Send network message to player to clear
          scm.Header.Type     = MSG_STATE_CHANGE_MAP;
          scm.Header.Size     = sizeof(sStateChangeMessage);
          scm.Header.PlayerID = m_Players[i].dpnidPlayer;
          scm.XPos            = m_Players[i].XPos;
          scm.YPos            = m_Players[i].YPos;
          scm.ZPos            = m_Players[i].ZPos;
          scm.Direction       = m_Players[i].Direction;
          scm.Speed           = m_Players[i].Speed;
          scm.State           = m_Players[i].State;

          // Send the message over network
          SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);
        }
      }

      // Clear hurt status after 0.25 second
      else if(m_Players[i].State == STATE_HURT) {
        if(Elapsed > 250) {

		  EnterCriticalSection(&m_UpdateCS);
          m_Players[i].State = STATE_IDLE;
		  LeaveCriticalSection(&m_UpdateCS);

          // Send network message to player to clear
          scm.Header.Type     = MSG_STATE_CHANGE_MAP;
          scm.Header.Size     = sizeof(sStateChangeMessage);
          scm.Header.PlayerID = m_Players[i].dpnidPlayer;
          scm.XPos            = m_Players[i].XPos;
          scm.YPos            = m_Players[i].YPos;
          scm.ZPos            = m_Players[i].ZPos;
          scm.Direction       = m_Players[i].Direction;
          scm.Speed           = m_Players[i].Speed;
          scm.State           = m_Players[i].State;

          // Send the message over network
          SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);
        }
      }
    }
  }
}

void cApp::UpdateMonster()
{

  float XMove, ZMove, Speed;
  float XDiff, YDiff, ZDiff, Dist, Radius;
  float Height;

  float Radius1,Radius2;
  float MinX, MaxX, MinZ, MaxZ;

  sMonsterStateMessage msm;

  long  i;
  long Elapsed;


  // Error checking
  if(m_Monster == NULL)
    return;

  // Loop through all players
  for(i=0;i<MAX_MONSTER;i++) {

    // Only update alive monsters
    if(m_Monster[i].Alive == TRUE) {
	
      // Get elapsed time from now and state time
	  Elapsed = timeGetTime() - m_Monster[i].Time;

	  // Monster not die or attack
	  if(m_Monster[i].State != STATE_DIE && 
		 m_Monster[i].State != STATE_SWING) {

		XMove = ZMove = 0.0f;

		// Calculate amount of movement by time passed
		Speed = (float)Elapsed / 1000.0f * m_Monster[i].Speed;
	  
		// Move character based on their type
		switch(m_Monster[i].AI) {
			case CHAR_STAND:
				break;
		
			case CHAR_WANDER:

				// Calculate new distance and direction if needed
				EnterCriticalSection(&m_UpdateCS);
				m_Monster[i].Distance -= (timeGetTime() - m_Monster[i].Time);
				LeaveCriticalSection(&m_UpdateCS);

				if(m_Monster[i].Distance <= 0.0f) {

					EnterCriticalSection(&m_UpdateCS);
					// Calculate a new distance to travel
					m_Monster[i].Distance = (float)(rand() % 2000) + 2000.0f;

					// Calculate a new direction
					m_Monster[i].Direction = (float)(rand()%360)*0.01744444f;
					LeaveCriticalSection(&m_UpdateCS);
				}

				// Process walk or stand still
				if(m_Monster[i].Distance > 1000.0f) {
					XMove = (float)sin(m_Monster[i].Direction) * Speed;
					ZMove = (float)cos(m_Monster[i].Direction) * Speed;

					EnterCriticalSection(&m_UpdateCS);
					m_Monster[i].State = STATE_MOVE;
					LeaveCriticalSection(&m_UpdateCS);
				} 
				else {

					EnterCriticalSection(&m_UpdateCS);
					// Stand still for one second
					m_Monster[i].State = STATE_IDLE;
					LeaveCriticalSection(&m_UpdateCS);
					
				}

				break;

			case CHAR_ROUTE:
				// Determine if character has reached point
				XDiff = (float)fabs(m_Monster[i].XPos -                   \
					      m_Monster[i].Route[m_Monster[i].CurrentPoint].XPos);
				YDiff = (float)fabs(m_Monster[i].YPos -                   \
					      m_Monster[i].Route[m_Monster[i].CurrentPoint].YPos);
				ZDiff = (float)fabs(m_Monster[i].ZPos -                   \
					      m_Monster[i].Route[m_Monster[i].CurrentPoint].ZPos);
				Dist = XDiff*XDiff + YDiff*YDiff + ZDiff*ZDiff;

				Radius = GetXZRadius(&m_Monster[i]) * 0.25f;
      
				// Go to next point if reached
				if(Dist < (Radius*Radius)) {

					EnterCriticalSection(&m_UpdateCS);
					m_Monster[i].CurrentPoint++;
					LeaveCriticalSection(&m_UpdateCS);

					if(m_Monster[i].CurrentPoint >= m_Monster[i].NumPoints)
					EnterCriticalSection(&m_UpdateCS);
					m_Monster[i].CurrentPoint = 0;
					LeaveCriticalSection(&m_UpdateCS);

					// Calculate new differences and distance
					XDiff = (float)fabs(m_Monster[i].XPos -                   \
							m_Monster[i].Route[m_Monster[i].CurrentPoint].XPos);
					YDiff = (float)fabs(m_Monster[i].YPos -                   \
							m_Monster[i].Route[m_Monster[i].CurrentPoint].YPos);
					ZDiff = (float)fabs(m_Monster[i].ZPos -                   \
							m_Monster[i].Route[m_Monster[i].CurrentPoint].ZPos);
					Dist = XDiff*XDiff + YDiff*YDiff + ZDiff*ZDiff;
				}

				// Setup movement towards target
				Dist = (float)sqrt(Dist);
				if(Speed > Dist)
					Speed = Dist;

				XMove=(m_Monster[i].Route[m_Monster[i].CurrentPoint].XPos - \
						m_Monster[i].XPos) / Dist * Speed;
				ZMove=(m_Monster[i].Route[m_Monster[i].CurrentPoint].ZPos - \
						m_Monster[i].ZPos) / Dist * Speed;

				// Set new direction
				EnterCriticalSection(&m_UpdateCS);
				m_Monster[i].Direction = (float)atan2(XMove, ZMove);

				// Set new action
				m_Monster[i].State = STATE_MOVE;
				LeaveCriticalSection(&m_UpdateCS);

				break;

			case CHAR_FOLLOW:
				if(m_Monster[i].TargetChar != NULL) {

					// Check distance between characters
					XDiff = (float)fabs(m_Monster[i].XPos -                 \
						                m_Monster[i].TargetChar->XPos);
					YDiff = (float)fabs(m_Monster[i].YPos -                 \
								         m_Monster[i].TargetChar->YPos);
					ZDiff = (float)fabs(m_Monster[i].ZPos -                 \
						                  m_Monster[i].TargetChar->ZPos);
				    Dist = XDiff*XDiff + YDiff*YDiff + ZDiff*ZDiff;
	
					// Update if further then distance
					if(Dist > (m_Monster[i].Distance*m_Monster[i].Distance)) {

						// Setup movement towards target
						Dist = (float)sqrt(Dist);
						if(Speed > Dist)
							Speed = Dist;

						XMove = (m_Monster[i].TargetChar->XPos -              \
								m_Monster[i].XPos) / Dist * Speed;
						ZMove = (m_Monster[i].TargetChar->ZPos -              \
								m_Monster[i].ZPos) / Dist * Speed;

						EnterCriticalSection(&m_UpdateCS);
						// Set new direction
						m_Monster[i].Direction = (float)atan2(XMove, ZMove);

						// Set new action
						m_Monster[i].State = STATE_MOVE;
						LeaveCriticalSection(&m_UpdateCS);
					}
				}

				break;

			case CHAR_EVADE:
				if(m_Monster[i].TargetChar != NULL) {

					// Check distance between characters
					XDiff = (float)fabs(m_Monster[i].XPos -                 \
									    m_Monster[i].TargetChar->XPos);
					YDiff = (float)fabs(m_Monster[i].YPos -                 \
									    m_Monster[i].TargetChar->YPos);
					ZDiff = (float)fabs(m_Monster[i].ZPos -                 \
									    m_Monster[i].TargetChar->ZPos);
					Dist = XDiff*XDiff + YDiff*YDiff + ZDiff*ZDiff;

					// Update if closer then distance
					if(Dist < (m_Monster[i].Distance*m_Monster[i].Distance)) {

						// Setup movement away from target
						Dist = (float)sqrt(Dist);
						if(Speed > Dist)
							Speed = Dist;
						XMove = -(m_Monster[i].TargetChar->XPos -             \
								  m_Monster[i].XPos) / Dist * Speed;
						ZMove = -(m_Monster[i].TargetChar->ZPos -             \
								  m_Monster[i].ZPos) / Dist * Speed;

						EnterCriticalSection(&m_UpdateCS);
						// Set new direction
						m_Monster[i].Direction = (float)atan2(XMove, ZMove);

						// Set new action
						m_Monster[i].State = STATE_MOVE;
						LeaveCriticalSection(&m_UpdateCS);
					}
				}
				break;
			}	

	// Check for height changes (can step up to 64 units)
	Height = GetHeightBelow(&m_TerrainMesh[Map] ,m_Monster[i].XPos, m_Monster[i].YPos + 16.0f, m_Monster[i].ZPos);

	
    // Check for movement collisions -
    // can't walk past anything blocking path.

		if(CheckIntersect(&m_TerrainMesh[Map],                       \
						  m_Monster[i].XPos,                  \
                          m_Monster[i].YPos + 16.0f,          \
                          m_Monster[i].ZPos,                  \
                          m_Monster[i].XPos + XMove,          \
                          m_Monster[i].YPos + 16.0f,          \
                          m_Monster[i].ZPos + ZMove) == TRUE)
		{
			XMove = ZMove = 0.0f;
			
			EnterCriticalSection(&m_UpdateCS);
			m_Monster[i].State = STATE_IDLE;
			LeaveCriticalSection(&m_UpdateCS);
		}

	// Check Collision with another monsters
	for(int MonsterNum=0;MonsterNum<MAX_MONSTER;MonsterNum++){

		if(m_Monster[MonsterNum].Alive == TRUE && 
		   m_Monster[i].ID != m_Monster[MonsterNum].ID)
		{
			// Bounds check 
			m_Monster[i].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,      
										NULL,&MaxZ,NULL);
			Radius1 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

			m_Monster[MonsterNum].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,	
												 NULL,&MaxZ,NULL);
			Radius2 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

			// Check Intersect between two mesh
			if(CheckSphereIntersect(m_Monster[i].XPos+XMove, m_Monster[i].YPos,		
									m_Monster[i].ZPos+ZMove, Radius1,				
									m_Monster[MonsterNum].XPos, m_Monster[MonsterNum].YPos,
									m_Monster[MonsterNum].ZPos, Radius2) == TRUE )
			{
				XMove = ZMove = 0.0f;

				EnterCriticalSection(&m_UpdateCS);
				m_Monster[i].State = STATE_IDLE;
				LeaveCriticalSection(&m_UpdateCS);
			}
		}
	}

	// Check Collision with players
	for(int PlayerNum=0;PlayerNum<MAX_PLAYERS;PlayerNum++){

		if(m_Players[PlayerNum].Connected == TRUE)
		{
			// Bounds check 
			m_Players[PlayerNum].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,      
										NULL,&MaxZ,NULL);
			Radius1 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

			m_Monster[i].Body.GetBounds(&MinX,NULL,&MinZ,&MaxX,	
												 NULL,&MaxZ,NULL);
			Radius2 = max(MaxX-MinX, MaxZ-MinZ) * 0.5f;

			// Check Intersect between two mesh
			if(CheckSphereIntersect(m_Players[PlayerNum].XPos, m_Players[PlayerNum].YPos,		
							    	m_Players[PlayerNum].ZPos, Radius1,				
								    m_Monster[i].XPos+XMove, m_Monster[i].YPos,
								    m_Monster[i].ZPos+ZMove, Radius2) == TRUE )
			{
				XMove = ZMove = 0.0f;

				EnterCriticalSection(&m_UpdateCS);
				m_Monster[i].State = STATE_IDLE;
				LeaveCriticalSection(&m_UpdateCS);
			}
		}
	}

	EnterCriticalSection(&m_UpdateCS);
	// Update player coordinates
    m_Monster[i].XPos += XMove;
    m_Monster[i].YPos = Height;         // Stay on ground
    m_Monster[i].ZPos += ZMove;
    m_Monster[i].Time = timeGetTime();  // Reset time
	LeaveCriticalSection(&m_UpdateCS);

	// Check monster attack Player
   	CheckMonsterAttack(i);

   } 

    // Clear die status after 2 second
    if(m_Monster[i].State == STATE_DIE) {
		if(Elapsed > 4000) {

		  EnterCriticalSection(&m_UpdateCS);
		  // not render monster die at client
		  m_Monster[i].Alive = FALSE;
		  LeaveCriticalSection(&m_UpdateCS);

          // Send network message to monster to clear
          msm.Header.Type     = MSG_MONSTER_STATE;
          msm.Header.Size     = sizeof(sMonsterStateMessage);
          msm.ID			  = m_Monster[i].ID;
          msm.XPos            = m_Monster[i].XPos;
          msm.YPos            = m_Monster[i].YPos;
          msm.ZPos            = m_Monster[i].ZPos;
          msm.Direction       = m_Monster[i].Direction;
          msm.Speed           = m_Monster[i].Speed;
          msm.State           = m_Monster[i].State;
		  msm.NumMap		  = m_Monster[i].NumMap;
		  msm.Alive			  = FALSE;	
          SendNetworkMessage(&msm, DPNSEND_NOLOOPBACK);
       }
	}

	// Clear swing status after 1 second
    if(m_Monster[i].State == STATE_SWING) {
       if(Elapsed > 1000) {

		  EnterCriticalSection(&m_UpdateCS);
          m_Monster[i].State = STATE_IDLE;
		  m_Monster[i].Time = timeGetTime();
		  LeaveCriticalSection(&m_UpdateCS);

          // Send network message to monster to clear
          msm.Header.Type     = MSG_MONSTER_STATE;
          msm.Header.Size     = sizeof(sMonsterStateMessage);
          msm.ID			  = m_Monster[i].ID;
          msm.XPos            = m_Monster[i].XPos;
          msm.YPos            = m_Monster[i].YPos;
          msm.ZPos            = m_Monster[i].ZPos;
          msm.Direction       = m_Monster[i].Direction;
          msm.Speed           = m_Monster[i].Speed;
          msm.State           = m_Monster[i].State;	
		  msm.NumMap		  = m_Monster[i].NumMap;
		  msm.Alive			  = m_Monster[i].Alive;

          // Send the message over network
          SendNetworkMessage(&msm, DPNSEND_NOLOOPBACK);
       }
	}
   }
  }   
}

void cApp::UpdateNetwork()
{
  long i;
  sStateChangeMessage scm;
  sMonsterStateMessage msm;

  // Send all player updates
  for(i=0;i<MAX_PLAYERS;i++) {

    // Only send data about connected players
    if(m_Players[i].Connected == TRUE) {
      scm.Header.Type     = MSG_STATE_CHANGE_MAP;
      scm.Header.Size     = sizeof(sStateChangeMessage);
      scm.Header.PlayerID = m_Players[i].dpnidPlayer;
      scm.XPos            = m_Players[i].XPos;
      scm.YPos            = m_Players[i].YPos;
      scm.ZPos            = m_Players[i].ZPos;
      scm.Direction       = m_Players[i].Direction;
      scm.Speed           = m_Players[i].Speed;
      scm.State           = m_Players[i].State;
      scm.Latency         = m_Players[i].Latency;
	  
      // Send the message over network
      SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);	
    }
  }

  // Send all monster updates
  for(i=0;i<MAX_MONSTER;i++){

	  // Only send data about alive monsters
	  if(m_Monster[i].Alive == TRUE){

  		// Send network message to player to clear
		 msm.Header.Type     = MSG_MONSTER_STATE;
		 msm.Header.Size     = sizeof(sMonsterStateMessage);
		 msm.ID				 = m_Monster[i].ID;
		 msm.XPos            = m_Monster[i].XPos;
	     msm.YPos            = m_Monster[i].YPos;
		 msm.ZPos            = m_Monster[i].ZPos;
	     msm.Direction       = m_Monster[i].Direction;
	     msm.Speed           = m_Monster[i].Speed;
		 msm.State           = m_Monster[i].State;
		 msm.NumMap		     = m_Monster[i].NumMap;
		 msm.Alive			 = m_Monster[i].Alive;

		 // Send the message over network
		 SendNetworkMessage(&msm, DPNSEND_NOLOOPBACK);
	  }
  }
}

///////////////////////////////////////////////////////////
// Game logic function
///////////////////////////////////////////////////////////
BOOL cApp::CheckIntersect(cMesh *Mesh,                        \
                 float XStart, float YStart, float ZStart,    \
                 float XEnd,   float YEnd,   float ZEnd)
{
  sMesh *MeshPtr;
  BOOL  Hit;
  float u, v, Dist;
  float XDiff, YDiff, ZDiff, Size;
  DWORD FaceIndex;
  D3DXVECTOR3 vecDir;

  // Error checking
  if(Mesh == NULL)
    return FALSE;

  // Start with parent mesh
  if((MeshPtr = Mesh->GetParentMesh()) == NULL)
    return FALSE;

  // Calculate ray
  XDiff = XEnd - XStart;
  YDiff = YEnd - YStart;
  ZDiff = ZEnd - ZStart;
  D3DXVec3Normalize(&vecDir, &D3DXVECTOR3(XDiff, YDiff, ZDiff));

  // Go through each mesh looking for intersection
  while(MeshPtr != NULL) {
    D3DXIntersect(MeshPtr->m_Mesh,                            \
                &D3DXVECTOR3(XStart,YStart,ZStart), &vecDir,  \
                &Hit, &FaceIndex, &u, &v, &Dist);

    if(Hit == TRUE) {
      Size = (float)sqrt(XDiff*XDiff+YDiff*YDiff+ZDiff*ZDiff);
      if(Dist <= Size)
        return TRUE;
    }

    MeshPtr = MeshPtr->m_Next;
  }

  return FALSE;
}

float cApp::GetHeightBelow(cMesh *Mesh, float XPos, float YPos, float ZPos)
{
  sMesh *MeshPtr;
  BOOL  Hit;
  float u, v, Dist;
  DWORD FaceIndex;

  // Error checking
  if(Mesh == NULL)
    return FALSE;

  // Start with parent mesh
  if((MeshPtr = Mesh->GetParentMesh()) == NULL)
    return FALSE;

  while(MeshPtr != NULL) {
	 D3DXIntersect(MeshPtr->m_Mesh,
				 &D3DXVECTOR3(XPos,YPos,ZPos),
				 &D3DXVECTOR3(0.0f, -1.0f, 0.0f),
				 &Hit, &FaceIndex, &u, &v, &Dist);
	if(Hit == TRUE)
		return YPos-Dist;
	 MeshPtr = MeshPtr->m_Next;
  }

  return YPos;
}

float cApp::GetXZRadius(sMonster *Monster)
{
  float MinX, MaxX, MinZ, MaxZ;
  float x, z;

  // Error checking
  if(Monster == NULL)
    return 0.0f;

  Monster->Body.GetBounds(&MinX, NULL, &MinZ,             \
                          &MaxX, NULL, &MaxZ, NULL);
  x = (float)max(fabs(MinX), fabs(MaxX));
  z = (float)max(fabs(MinZ), fabs(MaxZ));

  return max(x, z);
}

BOOL cApp::CheckSphereIntersect(				\
float XCenter1, float YCenter1, float ZCenter1, \
float Radius1,									\
float XCenter2, float YCenter2, float ZCenter2, \
float Radius2)
{

	float XDiff, YDiff, ZDiff, Distance;

	// Calculate distance between center points
	XDiff = (float)fabs(XCenter2-XCenter1);
	YDiff = (float)fabs(YCenter2-YCenter1);
	ZDiff = (float)fabs(ZCenter2-ZCenter1);
	Distance = XDiff*XDiff + YDiff*YDiff + ZDiff*ZDiff;

	// Don't allow movement if intersecting
	if(Distance <= (Radius1*Radius1 + Radius2*Radius2))
		return TRUE;

	// No intersection
	return FALSE;

}

void cApp::CheckMonsterAttack(int MonsterNum)
{
	float XDiff, YDiff, ZDiff, Dist, Radius;
	long i;
	sMonsterStateMessage msm;
	sStateChangeMessage scm;
	long DecHP;

      // Scan through list and pick a character
      for(i=0;i<MAX_PLAYERS;i++) {

        // Randomly pick enabled target (a PC),
        // and make sure the target is not hurt or dead.
        if((rand() % 100) < 10 &&                             \
           m_Players[i].Connected == TRUE &&                        \
           m_Players[i].State != STATE_HURT &&
		   m_Players[i].State != STATE_DIE) {

          // Get distance to target
          XDiff = (float)fabs(m_Monster[MonsterNum].XPos - m_Players[i].XPos);
          YDiff = (float)fabs(m_Monster[MonsterNum].YPos - m_Players[i].YPos);
          ZDiff = (float)fabs(m_Monster[MonsterNum].ZPos - m_Players[i].ZPos);
          Dist  = XDiff * XDiff + YDiff * YDiff + ZDiff * ZDiff;

          // Make sure in range to attack
          Radius = GetXZRadius(&m_Monster[MonsterNum]);

          // Attack if in range
          if((Radius*Radius) >= Dist) {

            // Point towards target character
            XDiff = m_Players[i].XPos - m_Monster[MonsterNum].XPos;
            ZDiff = m_Players[i].ZPos - m_Monster[MonsterNum].ZPos;

			EnterCriticalSection(&m_UpdateCS);
            m_Monster[MonsterNum].Direction = (float)atan2(XDiff, ZDiff);
			LeaveCriticalSection(&m_UpdateCS);

			if(m_Monster[MonsterNum].State != STATE_SWING){

				EnterCriticalSection(&m_UpdateCS);
				// Perform attack action
				m_Monster[MonsterNum].State = STATE_SWING;
				m_Monster[MonsterNum].Time  = timeGetTime();
				LeaveCriticalSection(&m_UpdateCS);

				// Send network message to monster to clear
				msm.Header.Type     = MSG_MONSTER_STATE;
				msm.Header.Size     = sizeof(sMonsterStateMessage);
				msm.ID			    = m_Monster[MonsterNum].ID;
				msm.XPos            = m_Monster[MonsterNum].XPos;
				msm.YPos            = m_Monster[MonsterNum].YPos;
				msm.ZPos            = m_Monster[MonsterNum].ZPos;
				msm.Direction       = m_Monster[MonsterNum].Direction;
				msm.Speed           = m_Monster[MonsterNum].Speed;
				msm.State           = m_Monster[MonsterNum].State;
				msm.Alive			= m_Monster[MonsterNum].Alive;
				msm.NumMap			= m_Monster[MonsterNum].NumMap;
				SendNetworkMessage(&msm, DPNSEND_NOLOOPBACK);

				if((rand() % 100) < 80) {
					while((DecHP = rand() % 5) < 2);

					EnterCriticalSection(&m_UpdateCS);
					m_Players[i].HP		-= DecHP;
					LeaveCriticalSection(&m_UpdateCS);

					sDecHPPlayerMessage sdpm;
					sdpm.Header.Type     = MSG_DEC_HP;
					sdpm.Header.Size     = sizeof(sDecHPPlayerMessage);
					sdpm.Header.PlayerID = m_Players[i].dpnidPlayer;
					sdpm.Dec_HP		     = DecHP;
					SendNetworkMessage(&sdpm, DPNSEND_NOLOOPBACK);

					if(m_Players[i].HP <= 0){

						EnterCriticalSection(&m_UpdateCS);
						// Change state player 
						m_Players[i].State	= STATE_DIE;
						m_Players[i].Time	= timeGetTime();
						LeaveCriticalSection(&m_UpdateCS);
	
						// Send network message
						scm.Header.Type		= MSG_STATE_CHANGE_MAP;
						scm.Header.Size		= sizeof(sStateChangeMessage);
						scm.Header.PlayerID	= m_Players[i].dpnidPlayer;
						scm.State			= m_Players[i].State;
						scm.XPos			= m_Players[i].XPos;
						scm.YPos			= m_Players[i].YPos;
						scm.ZPos			= m_Players[i].ZPos;
						scm.Direction		= m_Players[i].Direction;
						scm.Speed			= m_Players[i].Speed;
						SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);
					}
					else{

						EnterCriticalSection(&m_UpdateCS);
						// Change state player 
						m_Players[i].State	= STATE_HURT;
						m_Players[i].Time	= timeGetTime();
						LeaveCriticalSection(&m_UpdateCS);

						// Send network message
						scm.Header.Type		= MSG_STATE_CHANGE_MAP;
						scm.Header.Size		= sizeof(sStateChangeMessage);
						scm.Header.PlayerID	= m_Players[i].dpnidPlayer;
						scm.State			= m_Players[i].State;
						scm.XPos			= m_Players[i].XPos;
						scm.YPos			= m_Players[i].YPos;
						scm.ZPos			= m_Players[i].ZPos;
						scm.Direction		= m_Players[i].Direction;
						scm.Speed			= m_Players[i].Speed;
						SendNetworkMessage(&scm, DPNSEND_NOLOOPBACK);
					}
				}
			}
			break;
          }
        }
      }
    
}

void cApp::AssignMap(sMessage *Msg) 
{

	sClusterMapMessage *cmm;

	// Get pointer to message assign map to cluster
	cmm = (sClusterMapMessage*)Msg;
	
	NumMap = cmm->NumMap;
	ReceiveMapInfo = TRUE;

}
//////////////////////////////////////////////////////////////////
// Initialize Monster for each map
//////////////////////////////////////////////////////////////////

void cApp::CreateMonster()
{
	if(NumMap == 1)
	{
		m_Monster[0].ID			= 0;
		m_Monster[0].AI			= CHAR_WANDER;
		m_Monster[0].XPos		= 0.0f;
		m_Monster[0].YPos		= 0.0f;
		m_Monster[0].ZPos		= 0.0f;
		m_Monster[0].Direction	= 0.0f;
		m_Monster[0].Speed		= 200.0f;
		m_Monster[0].NumMap		= NumMap;
		m_Monster[0].Alive		= TRUE;

		m_Monster[1].ID			= 1;
		m_Monster[1].AI			= CHAR_WANDER;
		m_Monster[1].XPos		= 50.0f;
		m_Monster[1].YPos		= 0.0f;
		m_Monster[1].ZPos		= -200.0f;
		m_Monster[1].Direction	= 0.0f;
		m_Monster[1].Speed		= 200.0f;
		m_Monster[1].NumMap		= NumMap;
		m_Monster[1].Alive		= TRUE;

		m_Monster[2].ID			= 2;
		m_Monster[2].AI			= CHAR_WANDER;
		m_Monster[2].XPos		= 60.0f;
		m_Monster[2].YPos		= 0.0f;
		m_Monster[2].ZPos		= 1660.0f;
		m_Monster[2].Direction	= 0.0f;
		m_Monster[2].Speed		= 200.0f;
		m_Monster[2].NumMap		= NumMap;
		m_Monster[2].Alive		= TRUE;

		m_Monster[3].ID			= 3;
		m_Monster[3].AI			= CHAR_WANDER;
		m_Monster[3].XPos		= -1167.0f;
		m_Monster[3].YPos		= 0.0f;
		m_Monster[3].ZPos		= 1858.0f;
		m_Monster[3].Direction	= 0.0f;
		m_Monster[3].Speed		= 200.0f;
		m_Monster[3].NumMap		= NumMap;
		m_Monster[3].Alive		= TRUE;

		m_Monster[4].ID			= 4;
		m_Monster[4].AI			= CHAR_WANDER;
		m_Monster[4].XPos		= -1227.0f;
		m_Monster[4].YPos		= 0.0f;
		m_Monster[4].ZPos		= 926.0f;
		m_Monster[4].Direction	= 0.0f;
		m_Monster[4].Speed		= 200.0f;
		m_Monster[4].NumMap		= NumMap;
		m_Monster[4].Alive		= TRUE;

		m_Monster[5].ID			= 5;
		m_Monster[5].AI			= CHAR_WANDER;
		m_Monster[5].XPos		= -465.0f;
		m_Monster[5].YPos		= 0.0f;
		m_Monster[5].ZPos		= 502.0f;
		m_Monster[5].Direction	= 0.0f;
		m_Monster[5].Speed		= 200.0f;
		m_Monster[5].NumMap		= NumMap;
		m_Monster[5].Alive		= TRUE;

		m_Monster[6].ID			= 6;
		m_Monster[6].AI			= CHAR_WANDER;
		m_Monster[6].XPos		= 370.0f;
		m_Monster[6].YPos		= 0.0f;
		m_Monster[6].ZPos		= 1286.0f;
		m_Monster[6].Direction	= 0.0f;
		m_Monster[6].Speed		= 200.0f;
		m_Monster[6].NumMap		= NumMap;
		m_Monster[6].Alive		= TRUE;

		m_Monster[7].ID			= 7;
		m_Monster[7].AI			= CHAR_WANDER;
		m_Monster[7].XPos		= 1560.0f;
		m_Monster[7].YPos		= 0.0f;
		m_Monster[7].ZPos		= 2031.0f;
		m_Monster[7].Direction	= 0.0f;
		m_Monster[7].Speed		= 200.0f;
		m_Monster[7].NumMap		= NumMap;
		m_Monster[7].Alive		= TRUE;

		m_Monster[8].ID			= 8;
		m_Monster[8].AI			= CHAR_WANDER;
		m_Monster[8].XPos		= 1447.0f;
		m_Monster[8].YPos		= 0.0f;
		m_Monster[8].ZPos		= 1145.0f;
		m_Monster[8].Direction	= 0.0f;
		m_Monster[8].Speed		= 200.0f;
		m_Monster[8].NumMap		= NumMap;
		m_Monster[8].Alive		= TRUE;

		m_Monster[9].ID			= 9;
		m_Monster[9].AI			= CHAR_WANDER;
		m_Monster[9].XPos		= 1116.0f;
		m_Monster[9].YPos		= 0.0f;
		m_Monster[9].ZPos		= -1067.0f;
		m_Monster[9].Direction	= 0.0f;
		m_Monster[9].Speed		= 200.0f;
		m_Monster[9].NumMap		= NumMap;
		m_Monster[9].Alive		= TRUE;

		m_Monster[10].ID		= 10;
		m_Monster[10].AI		= CHAR_WANDER;
		m_Monster[10].XPos		= 1601.0f;
		m_Monster[10].YPos	  	= 0.0f;
		m_Monster[10].ZPos		= -12.0f;
		m_Monster[10].Direction	= 0.0f;
		m_Monster[10].Speed		= 200.0f;
		m_Monster[10].NumMap	= 1;
		m_Monster[10].Alive		= TRUE;

		m_Monster[11].ID		= 11;
		m_Monster[11].AI		= CHAR_WANDER;
		m_Monster[11].XPos		= 1598.0f;
		m_Monster[11].YPos	  	= 0.0f;
		m_Monster[11].ZPos		= 157.0f;
		m_Monster[11].Direction	= 0.0f;
		m_Monster[11].Speed		= 200.0f;
		m_Monster[11].NumMap	= 1;
		m_Monster[11].Alive		= TRUE;

		m_Monster[12].ID		= 12;
		m_Monster[12].AI		= CHAR_WANDER;
		m_Monster[12].XPos		= 1596.0f;
		m_Monster[12].YPos	  	= 0.0f;
		m_Monster[12].ZPos		= 322.0f;
		m_Monster[12].Direction	= 0.0f;
		m_Monster[12].Speed		= 200.0f;
		m_Monster[12].NumMap	= 1;
		m_Monster[12].Alive		= TRUE;

		m_Monster[13].ID		= 13;
		m_Monster[13].AI		= CHAR_WANDER;
		m_Monster[13].XPos		= 1594.0f;
		m_Monster[13].YPos	  	= 0.0f;
		m_Monster[13].ZPos		= 496.0f;
		m_Monster[13].Direction	= 0.0f;
		m_Monster[13].Speed		= 200.0f;
		m_Monster[13].NumMap	= 1;
		m_Monster[13].Alive		= TRUE;

		m_Monster[14].ID		= 14;
		m_Monster[14].AI		= CHAR_WANDER;
		m_Monster[14].XPos		= 1592.0f;
		m_Monster[14].YPos	  	= 0.0f;
		m_Monster[14].ZPos		= 623.0f;
		m_Monster[14].Direction	= 0.0f;
		m_Monster[14].Speed		= 200.0f;
		m_Monster[14].NumMap	= 1;
		m_Monster[14].Alive		= TRUE;

		m_Monster[15].ID		= 15;
		m_Monster[15].AI		= CHAR_WANDER;
		m_Monster[15].XPos		= 1590.0f;
		m_Monster[15].YPos	  	= 0.0f;
		m_Monster[15].ZPos		= 823.0f;
		m_Monster[15].Direction	= 0.0f;
		m_Monster[15].Speed		= 200.0f;
		m_Monster[15].NumMap	= 1;
		m_Monster[15].Alive		= TRUE;

		m_Monster[16].ID		= 16;
		m_Monster[16].AI		= CHAR_WANDER;
		m_Monster[16].XPos		= 1437.0f;
		m_Monster[16].YPos	  	= 0.0f;
		m_Monster[16].ZPos		= 1058.0f;
		m_Monster[16].Direction	= 0.0f;
		m_Monster[16].Speed		= 200.0f;
		m_Monster[16].NumMap	= 1;
		m_Monster[16].Alive		= TRUE;

		m_Monster[17].ID		= 17;
		m_Monster[17].AI		= CHAR_WANDER;
		m_Monster[17].XPos		= 1227.0f;
		m_Monster[17].YPos	  	= 0.0f;
		m_Monster[17].ZPos		= 1133.0f;
		m_Monster[17].Direction	= 0.0f;
		m_Monster[17].Speed		= 200.0f;
		m_Monster[17].NumMap	= 1;
		m_Monster[17].Alive		= TRUE;

		m_Monster[18].ID		= 18;
		m_Monster[18].AI		= CHAR_WANDER;
		m_Monster[18].XPos		= 893.0f;
		m_Monster[18].YPos	  	= 0.0f;
		m_Monster[18].ZPos		= 1251.0f;
		m_Monster[18].Direction	= 0.0f;
		m_Monster[18].Speed		= 200.0f;
		m_Monster[18].NumMap	= 1;
		m_Monster[18].Alive		= TRUE;

		m_Monster[19].ID		= 19;
		m_Monster[19].AI		= CHAR_WANDER;
		m_Monster[19].XPos		= 837.0f;
		m_Monster[19].YPos	  	= 0.0f;
		m_Monster[19].ZPos		= 1952.0f;
		m_Monster[19].Direction	= 0.0f;
		m_Monster[19].Speed		= 200.0f;
		m_Monster[19].NumMap	= 1;
		m_Monster[19].Alive		= TRUE;

		m_Monster[20].ID		= 20;
		m_Monster[20].AI		= CHAR_WANDER;
		m_Monster[20].XPos		= 607.0f;
		m_Monster[20].YPos	  	= 0.0f;
		m_Monster[20].ZPos		= 1997.0f;
		m_Monster[20].Direction	= 0.0f;
		m_Monster[20].Speed		= 200.0f;
		m_Monster[20].NumMap	= 1;
		m_Monster[20].Alive		= TRUE;

		m_Monster[21].ID		= 21;
		m_Monster[21].AI		= CHAR_WANDER;
		m_Monster[21].XPos		= 382.0f;
		m_Monster[21].YPos	  	= 0.0f;
		m_Monster[21].ZPos		= 2001.0f;
		m_Monster[21].Direction	= 0.0f;
		m_Monster[21].Speed		= 200.0f;
		m_Monster[21].NumMap	= 1;
		m_Monster[21].Alive		= TRUE;

		m_Monster[22].ID		= 22;
		m_Monster[22].AI		= CHAR_WANDER;
		m_Monster[22].XPos		= 132.0f;
		m_Monster[22].YPos	  	= 0.0f;
		m_Monster[22].ZPos		= 1997.0f;
		m_Monster[22].Direction	= 0.0f;
		m_Monster[22].Speed		= 200.0f;
		m_Monster[22].NumMap	= 1;
		m_Monster[22].Alive		= TRUE;

		m_Monster[23].ID		= 23;
		m_Monster[23].AI		= CHAR_WANDER;
		m_Monster[23].XPos		= -221.0f;
		m_Monster[23].YPos	  	= 0.0f;
		m_Monster[23].ZPos		= 1983.0f;
		m_Monster[23].Direction	= 0.0f;
		m_Monster[23].Speed		= 200.0f;
		m_Monster[23].NumMap	= 1;
		m_Monster[23].Alive		= TRUE;

		m_Monster[24].ID		= 24;
		m_Monster[24].AI		= CHAR_WANDER;
		m_Monster[24].XPos		= 534.0f;
		m_Monster[24].YPos	  	= 0.0f;
		m_Monster[24].ZPos		= 2033.0f;
		m_Monster[24].Direction	= 0.0f;
		m_Monster[24].Speed		= 200.0f;
		m_Monster[24].NumMap	= 1;
		m_Monster[24].Alive		= TRUE;

		m_Monster[25].ID		= 25;
		m_Monster[25].AI		= CHAR_WANDER;
		m_Monster[25].XPos		= -1341.0f;
		m_Monster[25].YPos	  	= 0.0f;
		m_Monster[25].ZPos		= 1735.0f;
		m_Monster[25].Direction	= 0.0f;
		m_Monster[25].Speed		= 200.0f;
		m_Monster[25].NumMap	= 1;
		m_Monster[25].Alive		= TRUE;

		m_Monster[26].ID		= 26;
		m_Monster[26].AI		= CHAR_WANDER;
		m_Monster[26].XPos		= 1487.0f;
		m_Monster[26].YPos	  	= 0.0f;
		m_Monster[26].ZPos		= 1357.0f;
		m_Monster[26].Direction	= 0.0f;
		m_Monster[26].Speed		= 200.0f;
		m_Monster[26].NumMap	= 1;
		m_Monster[26].Alive		= TRUE;

		m_Monster[27].ID		= 27;
		m_Monster[27].AI		= CHAR_WANDER;
		m_Monster[27].XPos		= -1552.0f;
		m_Monster[27].YPos	  	= 0.0f;
		m_Monster[27].ZPos		= 983.0f;
		m_Monster[27].Direction	= 0.0f;
		m_Monster[27].Speed		= 200.0f;
		m_Monster[27].NumMap	= 1;
		m_Monster[27].Alive		= TRUE;

		m_Monster[28].ID		= 28;
		m_Monster[28].AI		= CHAR_WANDER;
		m_Monster[28].XPos		= -1585.0f;
		m_Monster[28].YPos	  	= 0.0f;
		m_Monster[28].ZPos		= 587.0f;
		m_Monster[28].Direction	= 0.0f;
		m_Monster[28].Speed		= 200.0f;
		m_Monster[28].NumMap	= 1;
		m_Monster[28].Alive		= TRUE;

		m_Monster[29].ID		= 29;
		m_Monster[29].AI		= CHAR_WANDER;
		m_Monster[29].XPos		= -1018.0f;
		m_Monster[29].YPos	  	= 0.0f;
		m_Monster[29].ZPos		= 45.0f;
		m_Monster[29].Direction	= 0.0f;
		m_Monster[29].Speed		= 200.0f;
		m_Monster[29].NumMap	= 1;
		m_Monster[29].Alive		= TRUE;

		m_Monster[30].ID		= 30;
		m_Monster[30].AI		= CHAR_WANDER;
		m_Monster[30].XPos		= -581.0f;
		m_Monster[30].YPos	  	= 0.0f;
		m_Monster[30].ZPos		= 250.0f;
		m_Monster[30].Direction	= 0.0f;
		m_Monster[30].Speed		= 200.0f;
		m_Monster[30].NumMap	= 1;
		m_Monster[30].Alive		= TRUE;

		m_Monster[31].ID		= 31;
		m_Monster[31].AI		= CHAR_WANDER;
		m_Monster[31].XPos		= -464.0f;
		m_Monster[31].YPos	  	= 0.0f;
		m_Monster[31].ZPos		= -866.0f;
		m_Monster[31].Direction	= 0.0f;
		m_Monster[31].Speed		= 200.0f;
		m_Monster[31].NumMap	= 1;
		m_Monster[31].Alive		= TRUE;

		m_Monster[32].ID		= 32;
		m_Monster[32].AI		= CHAR_WANDER;
		m_Monster[32].XPos		= -811.0f;
		m_Monster[32].YPos	  	= 0.0f;
		m_Monster[32].ZPos		= -906.0f;
		m_Monster[32].Direction	= 0.0f;
		m_Monster[32].Speed		= 200.0f;
		m_Monster[32].NumMap	= 1;
		m_Monster[32].Alive		= TRUE;

		m_Monster[33].ID		= 33;
		m_Monster[33].AI		= CHAR_WANDER;
		m_Monster[33].XPos		= -1454.0f;
		m_Monster[33].YPos	  	= 0.0f;
		m_Monster[33].ZPos		= -894.0f;
		m_Monster[33].Direction	= 0.0f;
		m_Monster[33].Speed		= 200.0f;
		m_Monster[33].NumMap	= 1;
		m_Monster[33].Alive		= TRUE;

		m_Monster[34].ID		= 34;
		m_Monster[34].AI		= CHAR_WANDER;
		m_Monster[34].XPos		= -1630.0f;
		m_Monster[34].YPos	  	= 0.0f;
		m_Monster[34].ZPos		= -881.0f;
		m_Monster[34].Direction	= 0.0f;
		m_Monster[34].Speed		= 200.0f;
		m_Monster[34].NumMap	= 1;
		m_Monster[34].Alive		= TRUE;

		m_Monster[35].ID		= 35;
		m_Monster[35].AI		= CHAR_WANDER;
		m_Monster[35].XPos		= -1587.0f;
		m_Monster[35].YPos	  	= 0.0f;
		m_Monster[35].ZPos		= -1201.0f;
		m_Monster[35].Direction	= 0.0f;
		m_Monster[35].Speed		= 200.0f;
		m_Monster[35].NumMap	= 1;
		m_Monster[35].Alive		= TRUE;

		m_Monster[36].ID		= 36;
		m_Monster[36].AI		= CHAR_WANDER;
		m_Monster[36].XPos		= -1239.0f;
		m_Monster[36].YPos	  	= 0.0f;
		m_Monster[36].ZPos		= -1226.0f;
		m_Monster[36].Direction	= 0.0f;
		m_Monster[36].Speed		= 200.0f;
		m_Monster[36].NumMap	= 1;
		m_Monster[36].Alive		= TRUE;

		m_Monster[37].ID		= 37;
		m_Monster[37].AI		= CHAR_WANDER;
		m_Monster[37].XPos		= -978.0f;
		m_Monster[37].YPos	  	= 0.0f;
		m_Monster[37].ZPos		= -1215.0f;
		m_Monster[37].Direction	= 0.0f;
		m_Monster[37].Speed		= 200.0f;
		m_Monster[37].NumMap	= 1;
		m_Monster[37].Alive		= TRUE;

		m_Monster[38].ID		= 38;
		m_Monster[38].AI		= CHAR_WANDER;
		m_Monster[38].XPos		= -381.0f;
		m_Monster[38].YPos	  	= 0.0f;
		m_Monster[38].ZPos		= -1191.0f;
		m_Monster[38].Direction	= 0.0f;
		m_Monster[38].Speed		= 200.0f;
		m_Monster[38].NumMap	= 1;
		m_Monster[38].Alive		= TRUE;

		m_Monster[39].ID		= 10;
		m_Monster[39].AI		= CHAR_WANDER;
		m_Monster[39].XPos		= 448.0f;
		m_Monster[39].YPos	  	= 0.0f;
		m_Monster[39].ZPos		= -1147.0f;
		m_Monster[39].Direction	= 0.0f;
		m_Monster[39].Speed		= 200.0f;
		m_Monster[39].NumMap	= 1;
		m_Monster[39].Alive		= TRUE;

	}
	else if(NumMap == 2)
	{	
		m_Monster[0].ID			= 0;
		m_Monster[0].AI			= CHAR_WANDER;
		m_Monster[0].XPos		= -867.0f;
		m_Monster[0].YPos	  	= 0.0f;
		m_Monster[0].ZPos		= -91.0f;
		m_Monster[0].Direction	= 0.0f;
		m_Monster[0].Speed		= 200.0f;
		m_Monster[0].NumMap		= 2;
		m_Monster[0].Alive		= TRUE;

		m_Monster[1].ID			= 1;
		m_Monster[1].AI			= CHAR_WANDER;
		m_Monster[1].XPos		= 990.0f;
		m_Monster[1].YPos		= 0.0f;
		m_Monster[1].ZPos		= 1000.0f;
		m_Monster[1].Direction	= 0.0f;
		m_Monster[1].Speed		= 200.0f;
		m_Monster[1].NumMap		= 2;
		m_Monster[1].Alive		= TRUE;

		m_Monster[2].ID			= 2;
		m_Monster[2].AI			= CHAR_WANDER;
		m_Monster[2].XPos		= 890.0f;
		m_Monster[2].YPos		= 0.0f;
		m_Monster[2].ZPos		= -830.0f;
		m_Monster[2].Direction	= 0.0f;
		m_Monster[2].Speed		= 200.0f;
		m_Monster[2].NumMap		= 2;
		m_Monster[2].Alive		= TRUE;

		m_Monster[3].ID			= 3;
		m_Monster[3].AI			= CHAR_WANDER;
		m_Monster[3].XPos		= -38.0f;
		m_Monster[3].YPos	  	= 0.0f;
		m_Monster[3].ZPos		= -870.0f;
		m_Monster[3].Direction	= 0.0f;
		m_Monster[3].Speed		= 200.0f;
		m_Monster[3].NumMap		= 2;
		m_Monster[3].Alive		= TRUE;

		m_Monster[4].ID			= 4;
		m_Monster[4].AI			= CHAR_WANDER;
		m_Monster[4].XPos		= -1313.0f;
		m_Monster[4].YPos	  	= 0.0f;
		m_Monster[4].ZPos		= 600.0f;
		m_Monster[4].Direction	= 0.0f;
		m_Monster[4].Speed		= 200.0f;
		m_Monster[4].NumMap		= 2;
		m_Monster[4].Alive		= TRUE;

		m_Monster[5].ID			= 5;
		m_Monster[5].AI			= CHAR_WANDER;
		m_Monster[5].XPos		= 51.0f;
		m_Monster[5].YPos	  	= 0.0f;
		m_Monster[5].ZPos		= 1041.0f;
		m_Monster[5].Direction	= 0.0f;
		m_Monster[5].Speed		= 200.0f;
		m_Monster[5].NumMap		= 2;
		m_Monster[5].Alive		= TRUE;

		m_Monster[6].ID			= 6;
		m_Monster[6].AI			= CHAR_WANDER;
		m_Monster[6].XPos		= 1021.0f;
		m_Monster[6].YPos	  	= 0.0f;
		m_Monster[6].ZPos		= 1365.0f;
		m_Monster[6].Direction	= 0.0f;
		m_Monster[6].Speed		= 200.0f;
		m_Monster[6].NumMap		= 2;
		m_Monster[6].Alive		= TRUE;

		m_Monster[7].ID			= 7;
		m_Monster[7].AI			= CHAR_WANDER;
		m_Monster[7].XPos		= 969.0f;
		m_Monster[7].YPos	  	= 0.0f;
		m_Monster[7].ZPos		= 252.0f;
		m_Monster[7].Direction	= 0.0f;
		m_Monster[7].Speed		= 200.0f;
		m_Monster[7].NumMap		= 2;
		m_Monster[7].Alive		= TRUE;

		m_Monster[8].ID			= 8;
		m_Monster[8].AI			= CHAR_WANDER;
		m_Monster[8].XPos		= 1387.0f;
		m_Monster[8].YPos	  	= 0.0f;
		m_Monster[8].ZPos		= -598.0f;
		m_Monster[8].Direction	= 0.0f;
		m_Monster[8].Speed		= 200.0f;
		m_Monster[8].NumMap		= 2;
		m_Monster[8].Alive		= TRUE;

		m_Monster[9].ID			= 9;
		m_Monster[9].AI			= CHAR_WANDER;
		m_Monster[9].XPos		= 40.0f;
		m_Monster[9].YPos	  	= 0.0f;
		m_Monster[9].ZPos		= -693.0f;
		m_Monster[9].Direction	= 0.0f;
		m_Monster[9].Speed		= 200.0f;
		m_Monster[9].NumMap		= 2;
		m_Monster[9].Alive		= TRUE;

		m_Monster[10].ID		= 10;
		m_Monster[10].AI		= CHAR_WANDER;
		m_Monster[10].XPos		= -524.0f;
		m_Monster[10].YPos	  	= 0.0f;
		m_Monster[10].ZPos		= -590.0f;
		m_Monster[10].Direction	= 0.0f;
		m_Monster[10].Speed		= 200.0f;
		m_Monster[10].NumMap	= 2;
		m_Monster[10].Alive		= TRUE;

		m_Monster[11].ID		= 11;
		m_Monster[11].AI		= CHAR_WANDER;
		m_Monster[11].XPos		= -306.0f;
		m_Monster[11].YPos	  	= 0.0f;
		m_Monster[11].ZPos		= -923.0f;
		m_Monster[11].Direction	= 0.0f;
		m_Monster[11].Speed		= 200.0f;
		m_Monster[11].NumMap	= 2;
		m_Monster[11].Alive		= TRUE;

		m_Monster[12].ID		= 12;
		m_Monster[12].AI		= CHAR_WANDER;
		m_Monster[12].XPos		= 1073.0f;
		m_Monster[12].YPos	  	= 0.0f;
		m_Monster[12].ZPos		= -531.0f;
		m_Monster[12].Direction	= 0.0f;
		m_Monster[12].Speed		= 200.0f;
		m_Monster[12].NumMap	= 2;
		m_Monster[12].Alive		= TRUE;

		m_Monster[13].ID		= 13;
		m_Monster[13].AI		= CHAR_WANDER;
		m_Monster[13].XPos		= 1337.0f;
		m_Monster[13].YPos	  	= 0.0f;
		m_Monster[13].ZPos		= -1105.0f;
		m_Monster[13].Direction	= 0.0f;
		m_Monster[13].Speed		= 200.0f;
		m_Monster[13].NumMap	= 2;
		m_Monster[13].Alive		= TRUE;

		m_Monster[14].ID		= 14;
		m_Monster[14].AI		= CHAR_WANDER;
		m_Monster[14].XPos		= 1044.0f;
		m_Monster[14].YPos	  	= 0.0f;
		m_Monster[14].ZPos		= -1125.0f;
		m_Monster[14].Direction	= 0.0f;
		m_Monster[14].Speed		= 200.0f;
		m_Monster[14].NumMap	= 2;
		m_Monster[14].Alive		= TRUE;

		m_Monster[15].ID		= 15;
		m_Monster[15].AI		= CHAR_WANDER;
		m_Monster[15].XPos		= 680.0f;
		m_Monster[15].YPos	  	= 0.0f;
		m_Monster[15].ZPos		= -744.0f;
		m_Monster[15].Direction	= 0.0f;
		m_Monster[15].Speed		= 200.0f;
		m_Monster[15].NumMap	= 2;
		m_Monster[15].Alive		= TRUE;

		m_Monster[16].ID		= 16;
		m_Monster[16].AI		= CHAR_WANDER;
		m_Monster[16].XPos		= 1051.0f;
		m_Monster[16].YPos	  	= 0.0f;
		m_Monster[16].ZPos		= -736.0f;
		m_Monster[16].Direction	= 0.0f;
		m_Monster[16].Speed		= 200.0f;
		m_Monster[16].NumMap	= 2;
		m_Monster[16].Alive		= TRUE;

		m_Monster[17].ID		= 17;
		m_Monster[17].AI		= CHAR_WANDER;
		m_Monster[17].XPos		= 1424.0f;
		m_Monster[17].YPos	  	= 0.0f;
		m_Monster[17].ZPos		= 1149.0f;
		m_Monster[17].Direction	= 0.0f;
		m_Monster[17].Speed		= 200.0f;
		m_Monster[17].NumMap	= 2;
		m_Monster[17].Alive		= TRUE;

		m_Monster[18].ID		= 18;
		m_Monster[18].AI		= CHAR_WANDER;
		m_Monster[18].XPos		= 637.0f;
		m_Monster[18].YPos	  	= 0.0f;
		m_Monster[18].ZPos		= 1442.0f;
		m_Monster[18].Direction	= 0.0f;
		m_Monster[18].Speed		= 200.0f;
		m_Monster[18].NumMap	= 2;
		m_Monster[18].Alive		= TRUE;

		m_Monster[19].ID		= 19;
		m_Monster[19].AI		= CHAR_WANDER;
		m_Monster[19].XPos		= -1123.0f;
		m_Monster[19].YPos	  	= 0.0f;
		m_Monster[19].ZPos		= -377.0f;
		m_Monster[19].Direction	= 0.0f;
		m_Monster[19].Speed		= 200.0f;
		m_Monster[19].NumMap	= 2;
		m_Monster[19].Alive		= TRUE;

		m_Monster[20].ID		= 20;
		m_Monster[20].AI		= CHAR_WANDER;
		m_Monster[20].XPos		= -1260.0f;
		m_Monster[20].YPos	  	= 0.0f;
		m_Monster[20].ZPos		= -805.0f;
		m_Monster[20].Direction	= 0.0f;
		m_Monster[20].Speed		= 200.0f;
		m_Monster[20].NumMap	= 2;
		m_Monster[20].Alive		= TRUE;

		m_Monster[21].ID		= 21;
		m_Monster[21].AI		= CHAR_WANDER;
		m_Monster[21].XPos		= -1478.0f;
		m_Monster[21].YPos	  	= 0.0f;
		m_Monster[21].ZPos		= -690.0f;
		m_Monster[21].Direction	= 0.0f;
		m_Monster[21].Speed		= 200.0f;
		m_Monster[21].NumMap	= 2;
		m_Monster[21].Alive		= TRUE;

		m_Monster[22].ID		= 22;
		m_Monster[22].AI		= CHAR_WANDER;
		m_Monster[22].XPos		= -1505.0f;
		m_Monster[22].YPos	  	= 0.0f;
		m_Monster[22].ZPos		= -943.0f;
		m_Monster[22].Direction	= 0.0f;
		m_Monster[22].Speed		= 200.0f;
		m_Monster[22].NumMap	= 2;
		m_Monster[22].Alive		= TRUE;

		m_Monster[23].ID		= 23;
		m_Monster[23].AI		= CHAR_WANDER;
		m_Monster[23].XPos		= -1340.0f;
		m_Monster[23].YPos	  	= 0.0f;
		m_Monster[23].ZPos		= -1341.0f;
		m_Monster[23].Direction	= 0.0f;
		m_Monster[23].Speed		= 200.0f;
		m_Monster[23].NumMap	= 2;
		m_Monster[23].Alive		= TRUE;

		m_Monster[24].ID		= 24;
		m_Monster[24].AI		= CHAR_WANDER;
		m_Monster[24].XPos		= -930.0f;
		m_Monster[24].YPos	  	= 0.0f;
		m_Monster[24].ZPos		= -1464.0f;
		m_Monster[24].Direction	= 0.0f;
		m_Monster[24].Speed		= 200.0f;
		m_Monster[24].NumMap	= 2;
		m_Monster[24].Alive		= TRUE;

		m_Monster[25].ID		= 25;
		m_Monster[25].AI		= CHAR_WANDER;
		m_Monster[25].XPos		= -951.0f;
		m_Monster[25].YPos	  	= 0.0f;
		m_Monster[25].ZPos		= -1040.0f;
		m_Monster[25].Direction	= 0.0f;
		m_Monster[25].Speed		= 200.0f;
		m_Monster[25].NumMap	= 2;
		m_Monster[25].Alive		= TRUE;

		m_Monster[26].ID		= 26;
		m_Monster[26].AI		= CHAR_WANDER;
		m_Monster[26].XPos		= -484.0f;
		m_Monster[26].YPos	  	= 0.0f;
		m_Monster[26].ZPos		= -1011.0f;
		m_Monster[26].Direction	= 0.0f;
		m_Monster[26].Speed		= 200.0f;
		m_Monster[26].NumMap	= 2;
		m_Monster[26].Alive		= TRUE;

		m_Monster[27].ID		= 27;
		m_Monster[27].AI		= CHAR_WANDER;
		m_Monster[27].XPos		= 309.0f;
		m_Monster[27].YPos	  	= 0.0f;
		m_Monster[27].ZPos		= -645.0f;
		m_Monster[27].Direction	= 0.0f;
		m_Monster[27].Speed		= 200.0f;
		m_Monster[27].NumMap	= 2;
		m_Monster[27].Alive		= TRUE;

		m_Monster[28].ID		= 28;
		m_Monster[28].AI		= CHAR_WANDER;
		m_Monster[28].XPos		= -396.0f;
		m_Monster[28].YPos	  	= 0.0f;
		m_Monster[28].ZPos		= -1271.0f;
		m_Monster[28].Direction	= 0.0f;
		m_Monster[28].Speed		= 200.0f;
		m_Monster[28].NumMap	= 2;
		m_Monster[28].Alive		= TRUE;

		m_Monster[29].ID		= 29;
		m_Monster[29].AI		= CHAR_WANDER;
		m_Monster[29].XPos		= -146.0f;
		m_Monster[29].YPos	  	= 0.0f;
		m_Monster[29].ZPos		= -1135.0f;
		m_Monster[29].Direction	= 0.0f;
		m_Monster[29].Speed		= 200.0f;
		m_Monster[29].NumMap	= 2;
		m_Monster[29].Alive		= TRUE;

		m_Monster[30].ID		= 30;
		m_Monster[30].AI		= CHAR_WANDER;
		m_Monster[30].XPos		= -32.0f;
		m_Monster[30].YPos	  	= 0.0f;
		m_Monster[30].ZPos		= -700.0f;
		m_Monster[30].Direction	= 0.0f;
		m_Monster[30].Speed		= 200.0f;
		m_Monster[30].NumMap	= 2;
		m_Monster[30].Alive		= TRUE;

		m_Monster[31].ID		= 31;
		m_Monster[31].AI		= CHAR_WANDER;
		m_Monster[31].XPos		= 790.0f;
		m_Monster[31].YPos	  	= 0.0f;
		m_Monster[31].ZPos		= -637.0f;
		m_Monster[31].Direction	= 0.0f;
		m_Monster[31].Speed		= 200.0f;
		m_Monster[31].NumMap	= 2;
		m_Monster[31].Alive		= TRUE;

		m_Monster[32].ID		= 32;
		m_Monster[32].AI		= CHAR_WANDER;
		m_Monster[32].XPos		= 1123.0f;
		m_Monster[32].YPos	  	= 0.0f;
		m_Monster[32].ZPos		= -815.0f;
		m_Monster[32].Direction	= 0.0f;
		m_Monster[32].Speed		= 200.0f;
		m_Monster[32].NumMap	= 2;
		m_Monster[32].Alive		= TRUE;

		m_Monster[33].ID		= 33;
		m_Monster[33].AI		= CHAR_WANDER;
		m_Monster[33].XPos		= 1369.0f;
		m_Monster[33].YPos	  	= 0.0f;
		m_Monster[33].ZPos		= -1338.0f;
		m_Monster[33].Direction	= 0.0f;
		m_Monster[33].Speed		= 200.0f;
		m_Monster[33].NumMap	= 2;
		m_Monster[33].Alive		= TRUE;

		m_Monster[34].ID		= 34;
		m_Monster[34].AI		= CHAR_WANDER;
		m_Monster[34].XPos		= 1107.0f;
		m_Monster[34].YPos	  	= 0.0f;
		m_Monster[34].ZPos		= -1462.0f;
		m_Monster[34].Direction	= 0.0f;
		m_Monster[34].Speed		= 200.0f;
		m_Monster[34].NumMap	= 2;
		m_Monster[34].Alive		= TRUE;

		m_Monster[35].ID		= 35;
		m_Monster[35].AI		= CHAR_WANDER;
		m_Monster[35].XPos		= 938.0f;
		m_Monster[35].YPos	  	= 0.0f;
		m_Monster[35].ZPos		= -1109.0f;
		m_Monster[35].Direction	= 0.0f;
		m_Monster[35].Speed		= 200.0f;
		m_Monster[35].NumMap	= 2;
		m_Monster[35].Alive		= TRUE;

		m_Monster[36].ID		= 36;
		m_Monster[36].AI		= CHAR_WANDER;
		m_Monster[36].XPos		= 1199.0f;
		m_Monster[36].YPos	  	= 0.0f;
		m_Monster[36].ZPos		= -1011.0f;
		m_Monster[36].Direction	= 0.0f;
		m_Monster[36].Speed		= 200.0f;
		m_Monster[36].NumMap	= 2;
		m_Monster[36].Alive		= TRUE;

		m_Monster[37].ID		= 37;
		m_Monster[37].AI		= CHAR_WANDER;
		m_Monster[37].XPos		= 1366.0f;
		m_Monster[37].YPos	  	= 0.0f;
		m_Monster[37].ZPos		= -1233.0f;
		m_Monster[37].Direction	= 0.0f;
		m_Monster[37].Speed		= 200.0f;
		m_Monster[37].NumMap	= 2;
		m_Monster[37].Alive		= TRUE;

		m_Monster[38].ID		= 38;
		m_Monster[38].AI		= CHAR_WANDER;
		m_Monster[38].XPos		= 1076.0f;
		m_Monster[38].YPos	  	= 0.0f;
		m_Monster[38].ZPos		= -1247.0f;
		m_Monster[38].Direction	= 0.0f;
		m_Monster[38].Speed		= 200.0f;
		m_Monster[38].NumMap	= 2;
		m_Monster[38].Alive		= TRUE;

		m_Monster[39].ID		= 39;
		m_Monster[39].AI		= CHAR_WANDER;
		m_Monster[39].XPos		= 408.0f;
		m_Monster[39].YPos	  	= 0.0f;
		m_Monster[39].ZPos		= -1015.0f;
		m_Monster[39].Direction	= 0.0f;
		m_Monster[39].Speed		= 200.0f;
		m_Monster[39].NumMap	= 2;
		m_Monster[39].Alive		= TRUE;

	}
	else if(NumMap == 3)
	{
		m_Monster[0].ID			= 0;
		m_Monster[0].AI			= CHAR_WANDER;
		m_Monster[0].XPos		= 45.0f;
		m_Monster[0].YPos	  	= 0.0f;
		m_Monster[0].ZPos		= 360.0f;
		m_Monster[0].Direction	= 0.0f;
		m_Monster[0].Speed		= 200.0f;
		m_Monster[0].NumMap		= 3;
		m_Monster[0].Alive		= TRUE;

		m_Monster[1].ID			= 1;
		m_Monster[1].AI			= CHAR_WANDER;
		m_Monster[1].XPos		= -425.0f;
		m_Monster[1].YPos	  	= 0.0f;
		m_Monster[1].ZPos		= -775.0f;
		m_Monster[1].Direction	= 0.0f;
		m_Monster[1].Speed		= 200.0f;
		m_Monster[1].NumMap		= 3;
		m_Monster[1].Alive		= TRUE;

		m_Monster[2].ID			= 2;
		m_Monster[2].AI			= CHAR_WANDER;
		m_Monster[2].XPos		= -680.0f;
		m_Monster[2].YPos	  	= 0.0f;
		m_Monster[2].ZPos		= 1855.0f;
		m_Monster[2].Direction	= 0.0f;
		m_Monster[2].Speed		= 200.0f;
		m_Monster[2].NumMap		= 3;
		m_Monster[2].Alive		= TRUE;

		m_Monster[3].ID			= 3;
		m_Monster[3].AI			= CHAR_WANDER;
		m_Monster[3].XPos		= 1564.0f;
		m_Monster[3].YPos	  	= 0.0f;
		m_Monster[3].ZPos		= 2310.0f;
		m_Monster[3].Direction	= 0.0f;
		m_Monster[3].Speed		= 200.0f;
		m_Monster[3].NumMap		= 3;
		m_Monster[3].Alive		= TRUE;

		m_Monster[4].ID			= 4;
		m_Monster[4].AI			= CHAR_WANDER;
		m_Monster[4].XPos		= 2475.0f;
		m_Monster[4].YPos		= 0.0f;
		m_Monster[4].ZPos		= -1870.0f;
		m_Monster[4].Direction	= 0.0f;
		m_Monster[4].Speed		= 200.0f;
		m_Monster[4].NumMap		= 3;
		m_Monster[4].Alive		= TRUE;

		m_Monster[5].ID			= 5;
		m_Monster[5].AI			= CHAR_WANDER;
		m_Monster[5].XPos		= 1057.0f;
		m_Monster[5].YPos		= 0.0f;
		m_Monster[5].ZPos		= -2419.0f;
		m_Monster[5].Direction	= 0.0f;
		m_Monster[5].Speed		= 200.0f;
		m_Monster[5].NumMap		= 3;
		m_Monster[5].Alive		= TRUE;

		m_Monster[6].ID			= 6;
		m_Monster[6].AI			= CHAR_WANDER;
		m_Monster[6].XPos		= -217.0f;
		m_Monster[6].YPos		= 0.0f;
		m_Monster[6].ZPos		= -2400.0f;
		m_Monster[6].Direction	= 0.0f;
		m_Monster[6].Speed		= 200.0f;
		m_Monster[6].NumMap		= 3;
		m_Monster[6].Alive		= TRUE;

		m_Monster[7].ID			= 7;
		m_Monster[7].AI			= CHAR_WANDER;
		m_Monster[7].XPos		= -2314.0f;
		m_Monster[7].YPos		= 0.0f;
		m_Monster[7].ZPos		= 177.0f;
		m_Monster[7].Direction	= 0.0f;
		m_Monster[7].Speed		= 200.0f;
		m_Monster[7].NumMap		= 3;
		m_Monster[7].Alive		= TRUE;

		m_Monster[8].ID			= 8;
		m_Monster[8].AI			= CHAR_WANDER;
		m_Monster[8].XPos		= 2336.0f;
		m_Monster[8].YPos		= 0.0f;
		m_Monster[8].ZPos		= 457.0f;
		m_Monster[8].Direction	= 0.0f;
		m_Monster[8].Speed		= 200.0f;
		m_Monster[8].NumMap		= 3;
		m_Monster[8].Alive		= TRUE;

		m_Monster[9].ID			= 9;
		m_Monster[9].AI			= CHAR_WANDER;
		m_Monster[9].XPos		= 2794.0f;
		m_Monster[9].YPos		= 0.0f;
		m_Monster[9].ZPos		= -815.0f;
		m_Monster[9].Direction	= 0.0f;
		m_Monster[9].Speed		= 200.0f;
		m_Monster[9].NumMap		= 3;
		m_Monster[9].Alive		= TRUE;

		m_Monster[10].ID		= 10;
		m_Monster[10].AI		= CHAR_WANDER;
		m_Monster[10].XPos		= 2038.0f;
		m_Monster[10].YPos		= 0.0f;
		m_Monster[10].ZPos		= -2149.0f;
		m_Monster[10].Direction	= 0.0f;
		m_Monster[10].Speed		= 200.0f;
		m_Monster[10].NumMap	= 3;
		m_Monster[10].Alive		= TRUE;

		m_Monster[11].ID		= 11;
		m_Monster[11].AI		= CHAR_WANDER;
		m_Monster[11].XPos		= 1338.0f;
		m_Monster[11].YPos		= 0.0f;
		m_Monster[11].ZPos		= -2403.0f;
		m_Monster[11].Direction	= 0.0f;
		m_Monster[11].Speed		= 200.0f;
		m_Monster[11].NumMap	= 3;
		m_Monster[11].Alive		= TRUE;

		m_Monster[12].ID		= 12;
		m_Monster[12].AI		= CHAR_WANDER;
		m_Monster[12].XPos		= 474.0f;
		m_Monster[12].YPos		= 0.0f;
		m_Monster[12].ZPos		= -2111.0f;
		m_Monster[12].Direction	= 0.0f;
		m_Monster[12].Speed		= 200.0f;
		m_Monster[12].NumMap	= 3;
		m_Monster[12].Alive		= TRUE;

		m_Monster[13].ID		= 13;
		m_Monster[13].AI		= CHAR_WANDER;
		m_Monster[13].XPos		= -383.0f;
		m_Monster[13].YPos		= 0.0f;
		m_Monster[13].ZPos		= -1352.0f;
		m_Monster[13].Direction	= 0.0f;
		m_Monster[13].Speed		= 200.0f;
		m_Monster[13].NumMap	= 3;
		m_Monster[13].Alive		= TRUE;

		m_Monster[14].ID		= 14;
		m_Monster[14].AI		= CHAR_WANDER;
		m_Monster[14].XPos		= -652.0f;
		m_Monster[14].YPos		= 0.0f;
		m_Monster[14].ZPos		= -728.0f;
		m_Monster[14].Direction	= 0.0f;
		m_Monster[14].Speed		= 200.0f;
		m_Monster[14].NumMap	= 3;
		m_Monster[14].Alive		= TRUE;

		m_Monster[15].ID		= 15;
		m_Monster[15].AI		= CHAR_WANDER;
		m_Monster[15].XPos		= -520.0f;
		m_Monster[15].YPos		= 0.0f;
		m_Monster[15].ZPos		= 291.0f;
		m_Monster[15].Direction	= 0.0f;
		m_Monster[15].Speed		= 200.0f;
		m_Monster[15].NumMap	= 3;
		m_Monster[15].Alive		= TRUE;

		m_Monster[16].ID		= 16;
		m_Monster[16].AI		= CHAR_WANDER;
		m_Monster[16].XPos		= -181.0f;
		m_Monster[16].YPos		= 0.0f;
		m_Monster[16].ZPos		= 1212.0f;
		m_Monster[16].Direction	= 0.0f;
		m_Monster[16].Speed		= 200.0f;
		m_Monster[16].NumMap	= 3;
		m_Monster[16].Alive		= TRUE;

		m_Monster[17].ID		= 17;
		m_Monster[17].AI		= CHAR_WANDER;
		m_Monster[17].XPos		= -5.0f;
		m_Monster[17].YPos		= 0.0f;
		m_Monster[17].ZPos		= 1976.0f;
		m_Monster[17].Direction	= 0.0f;
		m_Monster[17].Speed		= 200.0f;
		m_Monster[17].NumMap	= 3;
		m_Monster[17].Alive		= TRUE;

		m_Monster[18].ID		= 18;
		m_Monster[18].AI		= CHAR_WANDER;
		m_Monster[18].XPos		= 1152.0f;
		m_Monster[18].YPos		= 0.0f;
		m_Monster[18].ZPos		= 2325.0f;
		m_Monster[18].Direction	= 0.0f;
		m_Monster[18].Speed		= 200.0f;
		m_Monster[18].NumMap	= 3;
		m_Monster[18].Alive		= TRUE;

		m_Monster[19].ID		= 19;
		m_Monster[19].AI		= CHAR_WANDER;
		m_Monster[19].XPos		= 1849.0f;
		m_Monster[19].YPos		= 0.0f;
		m_Monster[19].ZPos		= -381.0f;
		m_Monster[19].Direction	= 0.0f;
		m_Monster[19].Speed		= 200.0f;
		m_Monster[19].NumMap	= 3;
		m_Monster[19].Alive		= TRUE;

		m_Monster[20].ID		= 20;
		m_Monster[20].AI		= CHAR_WANDER;
		m_Monster[20].XPos		= 1991.0f;
		m_Monster[20].YPos		= 0.0f;
		m_Monster[20].ZPos		= -676.0f;
		m_Monster[20].Direction	= 0.0f;
		m_Monster[20].Speed		= 200.0f;
		m_Monster[20].NumMap	= 3;
		m_Monster[20].Alive		= TRUE;

		m_Monster[21].ID		= 21;
		m_Monster[21].AI		= CHAR_WANDER;
		m_Monster[21].XPos		= 2271.0f;
		m_Monster[21].YPos		= 0.0f;
		m_Monster[21].ZPos		= -733.0f;
		m_Monster[21].Direction	= 0.0f;
		m_Monster[21].Speed		= 200.0f;
		m_Monster[21].NumMap	= 3;
		m_Monster[21].Alive		= TRUE;

		m_Monster[22].ID		= 22;
		m_Monster[22].AI		= CHAR_WANDER;
		m_Monster[22].XPos		= 2576.0f;
		m_Monster[22].YPos		= 0.0f;
		m_Monster[22].ZPos		= -955.0f;
		m_Monster[22].Direction	= 0.0f;
		m_Monster[22].Speed		= 200.0f;
		m_Monster[22].NumMap	= 3;
		m_Monster[22].Alive		= TRUE;

		m_Monster[24].ID		= 24;
		m_Monster[24].AI		= CHAR_WANDER;
		m_Monster[24].XPos		= 2957.0f;
		m_Monster[24].YPos		= 0.0f;
		m_Monster[24].ZPos		= -903.0f;
		m_Monster[24].Direction	= 0.0f;
		m_Monster[24].Speed		= 200.0f;
		m_Monster[24].NumMap	= 3;
		m_Monster[24].Alive		= TRUE;

		m_Monster[25].ID		= 25;
		m_Monster[25].AI		= CHAR_WANDER;
		m_Monster[25].XPos		= 2955.0f;
		m_Monster[25].YPos		= 0.0f;
		m_Monster[25].ZPos		= -1424.0f;
		m_Monster[25].Direction	= 0.0f;
		m_Monster[25].Speed		= 200.0f;
		m_Monster[25].NumMap	= 3;
		m_Monster[25].Alive		= TRUE;

		m_Monster[26].ID		= 26;
		m_Monster[26].AI		= CHAR_WANDER;
		m_Monster[26].XPos		= 2651.0f;
		m_Monster[26].YPos		= 0.0f;
		m_Monster[26].ZPos		= -1803.0f;
		m_Monster[26].Direction	= 0.0f;
		m_Monster[26].Speed		= 200.0f;
		m_Monster[26].NumMap	= 3;
		m_Monster[26].Alive		= TRUE;

		m_Monster[27].ID		= 27;
		m_Monster[27].AI		= CHAR_WANDER;
		m_Monster[27].XPos		= 2717.0f;
		m_Monster[27].YPos		= 0.0f;
		m_Monster[27].ZPos		= -2299.0f;
		m_Monster[27].Direction	= 0.0f;
		m_Monster[27].Speed		= 200.0f;
		m_Monster[27].NumMap	= 3;
		m_Monster[27].Alive		= TRUE;

		m_Monster[28].ID		= 28;
		m_Monster[28].AI		= CHAR_WANDER;
		m_Monster[28].XPos		= 2381.0f;
		m_Monster[28].YPos		= 0.0f;
		m_Monster[28].ZPos		= -2730.0f;
		m_Monster[28].Direction	= 0.0f;
		m_Monster[28].Speed		= 200.0f;
		m_Monster[28].NumMap	= 3;
		m_Monster[28].Alive		= TRUE;

		m_Monster[29].ID		= 29;
		m_Monster[29].AI		= CHAR_WANDER;
		m_Monster[29].XPos		= 1885.0f;
		m_Monster[29].YPos		= 0.0f;
		m_Monster[29].ZPos		= -2904.0f;
		m_Monster[29].Direction	= 0.0f;
		m_Monster[29].Speed		= 200.0f;
		m_Monster[29].NumMap	= 3;
		m_Monster[29].Alive		= TRUE;

		m_Monster[30].ID		= 30;
		m_Monster[30].AI		= CHAR_WANDER;
		m_Monster[30].XPos		= 1487.0f;
		m_Monster[30].YPos		= 0.0f;
		m_Monster[30].ZPos		= -2320.0f;
		m_Monster[30].Direction	= 0.0f;
		m_Monster[30].Speed		= 200.0f;
		m_Monster[30].NumMap	= 3;
		m_Monster[30].Alive		= TRUE;

		m_Monster[31].ID		= 31;
		m_Monster[31].AI		= CHAR_WANDER;
		m_Monster[31].XPos		= 1106.0f;
		m_Monster[31].YPos		= 0.0f;
		m_Monster[31].ZPos		= -2038.0f;
		m_Monster[31].Direction	= 0.0f;
		m_Monster[31].Speed		= 200.0f;
		m_Monster[31].NumMap	= 3;
		m_Monster[31].Alive		= TRUE;

		m_Monster[32].ID		= 32;
		m_Monster[32].AI		= CHAR_WANDER;
		m_Monster[32].XPos		= -943.0f;
		m_Monster[32].YPos		= 0.0f;
		m_Monster[32].ZPos		= -1234.0f;
		m_Monster[32].Direction	= 0.0f;
		m_Monster[32].Speed		= 200.0f;
		m_Monster[32].NumMap	= 3;
		m_Monster[32].Alive		= TRUE;

		m_Monster[33].ID		= 33;
		m_Monster[33].AI		= CHAR_WANDER;
		m_Monster[33].XPos		= -1419.0f;
		m_Monster[33].YPos		= 0.0f;
		m_Monster[33].ZPos		= -998.0f;
		m_Monster[33].Direction	= 0.0f;
		m_Monster[33].Speed		= 200.0f;
		m_Monster[33].NumMap	= 3;
		m_Monster[33].Alive		= TRUE;

		m_Monster[34].ID		= 34;
		m_Monster[34].AI		= CHAR_WANDER;
		m_Monster[34].XPos		= -1546.0f;
		m_Monster[34].YPos		= 0.0f;
		m_Monster[34].ZPos		= -1380.0f;
		m_Monster[34].Direction	= 0.0f;
		m_Monster[34].Speed		= 200.0f;
		m_Monster[34].NumMap	= 3;
		m_Monster[34].Alive		= TRUE;

		m_Monster[35].ID		= 35;
		m_Monster[35].AI		= CHAR_WANDER;
		m_Monster[35].XPos		= -1182.0f;
		m_Monster[35].YPos		= 0.0f;
		m_Monster[35].ZPos		= -747.0f;
		m_Monster[35].Direction	= 0.0f;
		m_Monster[35].Speed		= 200.0f;
		m_Monster[35].NumMap	= 3;
		m_Monster[35].Alive		= TRUE;

		m_Monster[36].ID		= 36;
		m_Monster[36].AI		= CHAR_WANDER;
		m_Monster[36].XPos		= -1375.0f;
		m_Monster[36].YPos		= 0.0f;
		m_Monster[36].ZPos		= -441.0f;
		m_Monster[36].Direction	= 0.0f;
		m_Monster[36].Speed		= 200.0f;
		m_Monster[36].NumMap	= 3;
		m_Monster[36].Alive		= TRUE;

		m_Monster[37].ID		= 37;
		m_Monster[37].AI		= CHAR_WANDER;
		m_Monster[37].XPos		= -2001.0f;
		m_Monster[37].YPos		= 0.0f;
		m_Monster[37].ZPos		= -268.0f;
		m_Monster[37].Direction	= 0.0f;
		m_Monster[37].Speed		= 200.0f;
		m_Monster[37].NumMap	= 3;
		m_Monster[37].Alive		= TRUE;

		m_Monster[38].ID		= 38;
		m_Monster[38].AI		= CHAR_WANDER;
		m_Monster[38].XPos		= -1877.0f;
		m_Monster[38].YPos		= 0.0f;
		m_Monster[38].ZPos		= 1646.0f;
		m_Monster[38].Direction	= 0.0f;
		m_Monster[38].Speed		= 200.0f;
		m_Monster[38].NumMap	= 3;
		m_Monster[38].Alive		= TRUE;

		m_Monster[39].ID		= 39;
		m_Monster[39].AI		= CHAR_WANDER;
		m_Monster[39].XPos		= -1322.0f;
		m_Monster[39].YPos		= 0.0f;
		m_Monster[39].ZPos		= 2248.0f;
		m_Monster[39].Direction	= 0.0f;
		m_Monster[39].Speed		= 200.0f;
		m_Monster[39].NumMap	= 3;
		m_Monster[39].Alive		= TRUE;

	}
}

///////////////////////////////////////////////////////////
// Client class code
///////////////////////////////////////////////////////////
BOOL cClient::ConnectComplete(DPNMSG_CONNECT_COMPLETE *Msg) 
{ 
  // Save connection status
  if(Msg->hResultCode == S_OK)
    g_Connected = TRUE;
  else
    g_Connected = FALSE;

  return TRUE; 
}

BOOL cClient::Receive(DPNMSG_RECEIVE *Msg)
{
  // Send message to application class instance (if any)
  if(g_Application != NULL)
    g_Application->Receive(Msg);
  return TRUE;
}