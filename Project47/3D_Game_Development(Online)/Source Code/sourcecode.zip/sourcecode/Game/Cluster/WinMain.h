#ifndef _WINMAIN_H_
#define _WINMAIN_H_

//use trigger map
#include "Trigger.h" 

///////////////////////////////////////////////////////////////////
// Player data
///////////////////////////////////////////////////////////////////
// Maximum # of players allowed to be connected at once
#define MAX_PLAYERS           8
#define MAX_MONSTER			  40

// Player and Monster states
#define STATE_IDLE            1 
#define STATE_MOVE            2
#define STATE_SWING           3
#define STATE_HURT            4
#define STATE_DIE			  5

typedef struct sPlayer {

  BOOL  Connected;        // TRUE if player connected
  long  HP;				  // HP value

  char  Name[32];         // Name of player
  DPNID dpnidPlayer;      // DirectPlay Player ID #

  long  State;            // Last known state (STATE_*)
  long  Time;             // Time of last state update
  long  Latency;          // Half of round trip latency in ms

  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Angle facing
  float Speed;            // Movement speed

  cObject Body;           // Player Body
  int	NumMap;			  // Number map

  // Constructor
  sPlayer() { Connected = FALSE; Latency = 0;}
  ~sPlayer() { Body.Free(); }
} sPlayer;


///////////////////////////////////////////////////////////////////
// Monster Data and control
///////////////////////////////////////////////////////////////////

// AI types
#define CHAR_STAND       0
#define CHAR_WANDER      1
#define CHAR_ROUTE       2
#define CHAR_FOLLOW      3
#define CHAR_EVADE       4


// Path/Route structure
typedef struct {
  float XPos, YPos, ZPos;   // Target position
} sRoutePoint;

//Monster state
typedef struct sMonster {

  BOOL  Alive;				// TRUE if monster alive
  long  HP;					// HP value

  long  ID;					// #ID Monster
  long  AI;                 // STAND, WANDER, etc
  float Direction;          // Angle character is facing
  long  State;              // Last known state (STATE_*)
  float Speed;              // Movement speed
  long  Time;               // Time of last state update

  int	NumMap;			    // Number map

  float XPos, YPos, ZPos;   // Current coordinates

  sMonster *TargetChar;     // Character to follow
  float Distance;           // Follow/Evade distance
  float MinX, MinY, MinZ;   // Min bounding coordinates
  float MaxX, MaxY, MaxZ;   // Max bounding coordiantes 
  cObject Body;             // Monster Body

  long  NumPoints;          // # points in route
  long  CurrentPoint;       // Current route point
  sRoutePoint *Route;       // Route points

  // Constructor
  sMonster()
  {

	Alive = FALSE;				
    State = STATE_IDLE;     // Set default animation
    Distance = 0.0f;        // Set distance

    // Clear bounding box (for limiting movement)
    MinX = MinY = MinZ = MaxX = MaxY = MaxZ = 0.0f;

    NumPoints = 0;          // Set no route points
    Route = NULL;           // Set no route
	HP = 60;				// Set HP
  }

  ~sMonster()
  {
    delete [] Route;       // Release route
	Body.Free();		   // Release Object
  }
}sMonster;


///////////////////////////////////////////////////////////////////
// Network message data
///////////////////////////////////////////////////////////////////
// # of messages to process per frame
//#define MESSAGES_PER_FRAME   64

// # of message to allocate for message queue
//#define NUM_MESSAGES      1024

// Types of messages
#define MSG_CREATE_PLAYER_MAP		11
#define MSG_DESTROY_PLAYER_MAP		12
#define MSG_STATE_CHANGE_MAP		13

#define MSG_MAP_CHANGE				5
#define MSG_MONSTER_STATE			6
#define MSG_NUMBER				    7 
#define MSG_DEC_HP					8
#define MSG_FULL_HP					9	
#define MSG_CLUSTER_MAP			   10
#define MSG_STATE_CHANGE_TIME	   14
#define MSG_ASSIGNID	          256


// The message header structure used in all messages
typedef struct {
  long  Type;             // Type of message (MSG_*)
  long  Size;             // Size of data to send
  DPNID PlayerID;         // Player performing action
} sMessageHeader;

// The message queue message structure
typedef struct {
  sMessageHeader Header;  // Message header

  char Data[512];         // Message data
} sMessage;

// Create a player message
typedef struct {
  sMessageHeader Header;  // Message header

  float XPos, YPos, ZPos; // Create player coordinates
  float Direction;        // Direction of player
  int   NumMap;			  // Map Number	
  char  Name[32];         // Name of player
  long  HP;				  // HP Players

} sCreatePlayerMessage;

// Request player information message
typedef struct {
  sMessageHeader Header;  // Message header

  DPNID PlayerID;         // Which player to request
} sRequestPlayerInfoMessage;

// Destroy a player message
typedef struct {
  sMessageHeader Header;  // Message header
} sDestroyPlayerMessage;

// Change in state message
typedef struct {
  sMessageHeader Header;  // Message header

  long  State;            // State message (STATE_*)
  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Player facing direction
  float Speed;            // Walking speed of player

  long  Latency;          // Latency value of connection		
} sStateChangeMessage;

// Change map message
typedef struct {
  sMessageHeader Header;  // Message header

  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Player facing direction
  int NumMap;			  // Map number

} sMapChangeMessage;

// Monster message
typedef struct {
  sMessageHeader Header;  // Message header

  long  ID;				  // ID monster
  long  State;            // State message (STATE_*)
  float XPos, YPos, ZPos; // Monster coordinates
  float Direction;        // Monster facing direction
  float Speed;            // Walking speed of monster
  int	NumMap;			  // Number of map
  BOOL  Alive;			  // monster alive ?		
} sMonsterStateMessage;

// Number message
typedef struct {
  sMessageHeader Header;  // Message header

  long  ID;				  // ID monster
  long  Number;			  // Numbers are show
  int	NumMap;
} sNumberMessage;

typedef struct{
  sMessageHeader Header; // Message header

  long Dec_HP;			 // Dec HP Player
} sDecHPPlayerMessage;

typedef struct {
  sMessageHeader Header; // Message header

  long HP_FULL;			 // Full HP Player
} sFullHPPlayerMessage;

typedef struct {
  sMessageHeader Header; // Message header
  int	NumMap;		     // Map number
} sClusterMapMessage;


///////////////////////////////////////////////////////////
// Client class definition
///////////////////////////////////////////////////////////
class cClient : public cNetworkClient
{
  private:
    BOOL ConnectComplete(DPNMSG_CONNECT_COMPLETE *Msg);
    BOOL Receive(DPNMSG_RECEIVE *Msg);
};

///////////////////////////////////////////////////////////
// Application class definition
///////////////////////////////////////////////////////////
class cApp : public cApplication
{
  private:

	HWND             m_Controls[3];  // The app window handles

    CRITICAL_SECTION m_UpdateCS;    // Critical sections
	CRITICAL_SECTION m_MessageCS;

    cGraphics       m_Graphics;     // Graphics object
	DPNID			dpnidCluster;   // DirectPlay Cluster ID #

	cTrigger		m_Trigger[3];	// Trigger map

    GUID           *m_guidAdapter;  // Adapter used to connect
    cNetworkAdapter m_Adapters;     // List of adapters
    cClient         m_Client;       // Derived client class

    char            m_HostIP[16];   // Host IP Address
    char            m_Name[32];     // Player name

	int				NumMap;			// Map number

    cMesh           m_TerrainMesh[3];	 // Terrain object mesh
    cMesh           m_CharacterMesh; // Mesh for character
	cMesh			m_MonsterMesh;	 // Mesh for monster

    long            m_NumPlayers;   // # players connected
    sPlayer        *m_Players;      // Player data
	sMonster	   *m_Monster;		// Monster data

	sMessage        *m_Messages;     // Message queue
	long             m_MsgHead;      // Head of message list
    long             m_MsgTail;      // Tail of message list
    
    BOOL SelectAdapter();            // Select network adapter
	void SetupApplicationWindow();   // Set application window
    BOOL InitializeGame();           // Initialize game
	//BOOL HostGame();                 // Begin hosting game
    BOOL JoinGame();                 // Join network session

	void ListPlayers();              // List connected players
    //void ProcessQueuedMessages();    // Process waiting messages

	void UpdateNetwork();            // Send updates to players
	void UpdatePlayers();            // Update all players
	void UpdateMonster();			 // Update all monsters

    // Send a client network message to server
    BOOL SendNetworkMessage(void *Msg, long SendFlags);

    //  Functions to process queued network messages
    //BOOL QueueMessage(void *Msg);  
    void AssignMap(sMessage *Msg);
    void AddPlayer(sMessage *Msg);
    BOOL RemovePlayer(sMessage *Msg);
    BOOL PlayerStateChange(sMessage *Msg);

////////////////////////////////////////////////////////////////////
// Function to manage monster
///////////////////////////////////////////////////////////////////
/*
    // Set route points
    BOOL SetRoute(long IDNum,                                 \
                  long NumPoints, sRoutePoint *Route);

	 // Functions to move and get character coordinates
    BOOL Move(long IDNum, float XPos, float YPos, float ZPos);
    BOOL GetPosition(long IDNum,                              \
                     float *XPos, float *YPos, float *ZPos);
*/
	float GetXZRadius(sMonster *Monster);
	void CheckMonsterAttack(int MonsterNum);
/*
	// Functions to Set/Get character bounds
    BOOL SetBounds(long IDNum,                                \
                   float MinX, float MinY, float MinZ,        \
                   float MaxX, float MaxY, float MaxZ);
    BOOL GetBounds(long IDNum,                                \
                   float *MinX, float *MinY, float *MinZ,     \
                   float *MaxX, float *MaxY, float *MaxZ);

	 // Functions to Set/Get character AI
    BOOL SetAI(long IDNum, long Type);
    long GetAI(long IDNum);

	 // Set action (w/timer)
    BOOL SetAction(sMonster *Character,                     \
                   long Action, long AddTime = 0);
*/

    // Check if player collides with level mesh
    BOOL CheckIntersect(cMesh *Mesh,                          \
                 float XStart, float YStart, float ZStart,    \
                 float XEnd,   float YEnd,   float ZEnd);
	
	// Check if collides  between charactors
	BOOL CheckSphereIntersect(float XCenter1, float YCenter1, 
		float ZCenter1, float Radius1,						  \
		float XCenter2, float YCenter2, float ZCenter2,       \
		float Radius2);

	void CreateMonster();

	float GetHeightBelow(cMesh *Mesh, float XPos, float YPos, float ZPos);
	
	
  public:
    // Overloaded class functions
    cApp();

    BOOL Init();
    BOOL Shutdown();
    BOOL Frame();

	FAR PASCAL MsgProc(HWND hWnd, UINT uMsg,                  \
                       WPARAM wParam, LPARAM lParam);

	// Set adapter to use, IP to connect to, and name to use
    void SetInfo(GUID *Adapter, char *IP);

    // Siphon a network receive message to application
    BOOL Receive(DPNMSG_RECEIVE *Msg);

};

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow);
BOOL CALLBACK ConnectDialogProc(HWND hWnd, UINT uMsg,         \
                                WPARAM wParam, LPARAM lParam);

#endif
