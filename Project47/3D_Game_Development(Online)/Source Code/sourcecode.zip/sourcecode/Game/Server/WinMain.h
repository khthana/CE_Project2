#ifndef _WINMAIN_H_
#define _WINMAIN_H_

//use trigger map
#include "Trigger.h" 

///////////////////////////////////////////////////////////////////
// Player data
///////////////////////////////////////////////////////////////////
// Maximum # of players allowed to be connected at once
#define MAX_PLAYERS           8
#define MAX_CLUSTER			  3

// Player and Monster states
#define STATE_IDLE            1 
#define STATE_MOVE            2
#define STATE_SWING           3
#define STATE_HURT            4
#define STATE_DIE			  5

typedef struct sPlayer {

  BOOL  Connected;        // TRUE if player connected
  long  HP;				  // HP value

  char  Name[32];         // Name of player
  DPNID dpnidPlayer;      // DirectPlay Player ID #

  long  State;            // Last known state (STATE_*)
  long  Time;             // Time of last state update
  long  Latency;          // Half of round trip latency in ms

  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Angle facing
  float Speed;            // Movement speed

  //cTrigger m_Trigger;	  // Trigger map
  int	NumMap;			  // Number map

  // Constructor
  sPlayer() { Connected = FALSE; Latency = 0;}
  ~sPlayer() {}
} sPlayer;

typedef struct sCluster {

	DPNID dpnidCluster;		// DirectPlay Cluster ID #
	char  Name[32];			// Name of cluster
	BOOL  Connected;		// TRUE if cluster connect
	int	  NumMap;			// Number map

	// Constructor
	sCluster() { Connected = FALSE;}
	~sCluster() {}
} sCluster;

///////////////////////////////////////////////////////////////////
// Network message data
///////////////////////////////////////////////////////////////////
// # of messages to process per frame
#define MESSAGES_PER_FRAME  128

// # of message to allocate for message queue
#define NUM_MESSAGES		4096

// Types of messages
#define MSG_CREATE_PLAYER     1
#define MSG_PLAYER_INFO       2
#define MSG_DESTROY_PLAYER    3
#define MSG_STATE_CHANGE      4

// Types of message return from cluster 
#define MSG_MAP_CHANGE			5
#define MSG_MONSTER_STATE		6
#define MSG_NUMBER				7 
#define MSG_DEC_HP				8
#define MSG_FULL_HP				9	
#define MSG_CLUSTER_MAP			10
#define MSG_ASSIGNID			256
#define MSG_STATE_CHANGE_TIME	14

// Types of messages on cluster 
#define MSG_CREATE_PLAYER_MAP		11
#define MSG_DESTROY_PLAYER_MAP		12
#define MSG_STATE_CHANGE_MAP		13

// The message header structure used in all messages
typedef struct {
  long  Type;             // Type of message (MSG_*)
  long  Size;             // Size of data to send
  DPNID PlayerID;         // Player performing action
} sMessageHeader;

// The message queue message structure
typedef struct {
  sMessageHeader Header;  // Message header

  char Data[512];         // Message data
} sMessage;

// Request a player DPNID from server message
typedef struct {
  sMessageHeader Header;  // Message header
} sAssignPlayerIDMessage;

// Create a player message
typedef struct {
  sMessageHeader Header;  // Message header

  float XPos, YPos, ZPos; // Create player coordinates
  float Direction;        // Direction of player
  int   NumMap;			  // Map Number	
  char  Name[32];         // Name of player
  long  HP;				  // HP Players

} sCreatePlayerMessage;

// Request player information message
typedef struct {
  sMessageHeader Header;  // Message header

  DPNID PlayerID;         // Which player to request
} sRequestPlayerInfoMessage;

// Destroy a player message
typedef struct {
  sMessageHeader Header;  // Message header
} sDestroyPlayerMessage;

// Change in state message
typedef struct {
  sMessageHeader Header;  // Message header

  long  State;            // State message (STATE_*)
  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Player facing direction
  float Speed;            // Walking speed of player

  long  Latency;          // Latency value of connection		
} sStateChangeMessage;

// Change map message
typedef struct {
  sMessageHeader Header;  // Message header

  float XPos, YPos, ZPos; // Player coordinates
  float Direction;        // Player facing direction
  int NumMap;			  // Map number

} sMapChangeMessage;

// Monster message
typedef struct {
  sMessageHeader Header;  // Message header

  long  ID;				  // ID monster
  long  State;            // State message (STATE_*)
  float XPos, YPos, ZPos; // Monster coordinates
  float Direction;        // Monster facing direction
  float Speed;            // Walking speed of monster
  int	NumMap;			  // Number of map
  BOOL  Alive;			  // monster alive ?		
} sMonsterStateMessage;

// Number message
typedef struct {
  sMessageHeader Header;  // Message header

  long  ID;				  // ID monster
  long  Number;			  // Numbers are show
  int	NumMap;		
} sNumberMessage;

typedef struct{
  sMessageHeader Header; // Message header

  long Dec_HP;			 // Dec HP Player
} sDecHPPlayerMessage;

typedef struct {
  sMessageHeader Header; // Message header

  long HP_FULL;			 // Full HP Player
} sFullHPPlayerMessage;

typedef struct {
  sMessageHeader Header; // Message header
  int	NumMap;		     // Map number
} sClusterMapMessage;

///////////////////////////////////////////////////////////////////
// Server class definition
///////////////////////////////////////////////////////////////////
class cServer : public cNetworkServer
{
  private:
    BOOL CreatePlayer(DPNMSG_CREATE_PLAYER *Msg);
    BOOL DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg);
    BOOL Receive(DPNMSG_RECEIVE *Msg);
};

///////////////////////////////////////////////////////////////////
// Application class definition
///////////////////////////////////////////////////////////////////
class cApp : public cApplication
{
  private:
    HWND             m_Controls[4];  // The app window handles

    CRITICAL_SECTION m_UpdateCS;     // Critical sections
    CRITICAL_SECTION m_MessageCS;

    GUID            *m_guidAdapter;  // Adapter used to connect
    cNetworkAdapter  m_Adapters;     // List of adapters
    cServer          m_Server;       // Derived server class

    long             m_NumPlayers;   // # players connected
	long			 m_NumClusters;	 // # clusters connected	

    sPlayer         *m_Players;      // Player data
	sCluster		*m_Clusters;	 // Cluster data

    sMessage        *m_Messages;     // Message queue
    long             m_MsgHead;      // Head of message list
    long             m_MsgTail;      // Tail of message list

	long			receive;
	long			time;
    
    BOOL SelectAdapter();            // Select network adapter
    void SetupApplicationWindow();   // Set application window
    BOOL InitializeGame();           // Initialize game
    BOOL HostGame();                 // Begin hosting game

    void ListPlayers();              // List connected players

    void ProcessQueuedMessages();    // Process waiting messages
    void UpdateNetwork();            // Send updates to players
    void UpdateLatency();            // Update latency values

	// Get player's number in list
    long GetPlayerNum(DPNID dpnidPlayer);


    // Send a network message to client(s)
    BOOL SendNetworkMessage(void *Msg, long SendFlags = 0,    \
                            int To = -1);

    //  Functions to process queued network messages
    BOOL QueueMessage(void *Msg);  
    BOOL PlayerID(sMessage *Msg, DPNID To);
    BOOL PlayerInfo(sMessage *Msg, DPNID To);
    BOOL AddPlayer(sMessage *Msg);
    BOOL RemovePlayer(sMessage *Msg);
    BOOL PlayerStateChange(sMessage *Msg);

	void ChangeMap(sMessage *Msg);
	void ChangeStateMonster(sMessage *Msg);
	void ShowNumber(sMessage *Msg);
	void DecHPPlayer(sMessage *Msg);
	void FullHPPlayer(sMessage *Msg);
	void PlayerStateServer(sMessage *Msg);
	void ResponseChangeState(sMessage *Msg);

	int  FindCluster(int PlayerNum);
	
  public:
    // Overloaded class functions
    cApp();

    BOOL Init();
    BOOL Shutdown();
    BOOL Frame();
    FAR PASCAL MsgProc(HWND hWnd, UINT uMsg,                  \
                       WPARAM wParam, LPARAM lParam);

    void SetAdapter(GUID *Adapter); // Select adapter GUID

    // Functions to siphon network messages to application
    BOOL CreatePlayer(DPNMSG_CREATE_PLAYER *Msg);
    BOOL DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg);
    BOOL Receive(DPNMSG_RECEIVE *Msg);
};

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow);
BOOL CALLBACK ConfigDialogProc(HWND hWnd, UINT uMsg,          \
                               WPARAM wParam, LPARAM lParam);

#endif
