/**************************************************
Server Game 3D Online

OLALA Group

Required libraries:
  D3D8.LIB, D3DX8.LIB, DINPUT8.LIB, D3DXOF.LIB,
  DXGUID.LIB, DPNET.LIB, DPLAY.LIB, and DPNADDR.LIB
**************************************************/

#include "Core_Global.h"
#include "Server.h"
#include "WinMain.h"
#include "resource.h"

cApp            *g_Application; // Global application pointer
cNetworkAdapter *g_Adapters;    // Global adapter list pointer

///////////////////////////////////////////////////////////
// cApp overidden virtual functions
///////////////////////////////////////////////////////////
cApp::cApp()
{ 
  // Setup main window information
  m_Width  = 320;
  m_Height = 320;
  m_Style  = WS_BORDER | WS_CAPTION |                         \
             WS_MINIMIZEBOX | WS_SYSMENU;
  m_wcex.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
  strcpy(m_Class, "ServerClass");
  strcpy(m_Caption, "�������������"); //Caption Game Server

  // Clear class data
  m_Messages    = NULL;
  m_Players     = NULL;
  m_Clusters	= NULL;
  m_guidAdapter = NULL;
  g_Application = this;
  g_Adapters    = &m_Adapters;

  // Initialize a critical section for messaging
  InitializeCriticalSection(&m_MessageCS);
}

BOOL cApp::Init()
{
  // Select a network adapter to use (or quit if selected)
  if(SelectAdapter() == FALSE)
    return FALSE;

  // Setup the main interface window
  SetupApplicationWindow();

  // Initialize the game, set video mode, load data, etc
  if(InitializeGame() == FALSE) {
    Error(FALSE, "Unable to initialize game.");
    return FALSE;
  }

  // Begin hosting the game session
  if(HostGame() == FALSE) {
    Error(FALSE, "Unable to host network server.");
    return FALSE;
  }

  return TRUE;
}

BOOL cApp::Shutdown()
{
  // Disconnect network and free interfaces
  m_Adapters.Shutdown();
  m_Server.Disconnect();
  m_Server.Shutdown();

  // Delete message array
  delete [] m_Messages;
  m_Messages = NULL;

  // Delete players
  delete [] m_Players;
  m_Players = NULL;

  // Delete Clusters
  delete [] m_Clusters;
  m_Clusters = NULL;

  // Free the critical section
  DeleteCriticalSection(&m_MessageCS);

  return TRUE;
}

BOOL cApp::Frame()
{
  static DWORD LatencyCounter = timeGetTime();

  // Process some queued network messages
  ProcessQueuedMessages();

  // Update player latency values every 10 seconds
  if(timeGetTime() > LatencyCounter + 10000) {
    UpdateLatency();
    LatencyCounter = timeGetTime(); // Reset counter
  }

  return TRUE;
}

FAR PASCAL cApp::MsgProc(HWND hWnd, UINT uMsg,                \
                         WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) {
    case WM_DESTROY:
      PostQuitMessage(0);
      break;
    default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return 0;
}    

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev,          \
                   LPSTR szCmdLine, int nCmdShow)
{
  cApp App;
  return App.Run();  // Run the application instance
}

///////////////////////////////////////////////////////////
// Select adapter dialog and other functions
///////////////////////////////////////////////////////////
BOOL CALLBACK ConfigDialogProc(HWND hWnd, UINT uMsg,          \
                               WPARAM wParam, LPARAM lParam)
{
  long i;
  char Text[256];
  int Selection;
  static HWND hAdapters;

  switch(uMsg) {
    case WM_INITDIALOG:
      // Get adapter list window handle
      hAdapters = GetDlgItem(hWnd, IDC_ADAPTERS);

      // Add adapter names to list
      for(i=0;i<g_Adapters->GetNumAdapters();i++) {
        g_Adapters->GetName(i, Text);
        SendMessage(hAdapters, CB_INSERTSTRING,i,(LPARAM)Text);
      }

      // Select first adapter in list
      SendMessage(hAdapters, CB_SETCURSEL, 0, 0);

      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam)) {

        case IDC_OK:
          // Make sure an adapter was selected
          if((Selection = SendMessage(hAdapters,              \
                                      CB_GETCURSEL,           \
                                      0, 0)) == LB_ERR)
            break;

          // Assign adapter
          if(g_Application != NULL)
            g_Application->SetAdapter(                        \
                           g_Adapters->GetGUID(Selection));

          // Quit dialog
          EndDialog(hWnd, TRUE);
          return TRUE;

        case IDC_CANCEL:
          EndDialog(hWnd, FALSE);
          return TRUE;
      }

  }
  return FALSE;
}

void cApp::SetAdapter(GUID *Adapter)
{
  m_guidAdapter = Adapter;
}

///////////////////////////////////////////////////////////
// Misc. application functions
///////////////////////////////////////////////////////////
long cApp::GetPlayerNum(DPNID dpnidPlayer)
{
  long i;

  // Error checking
  if(m_Players == NULL)
    return -1;

  // Scan list looking for match
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == dpnidPlayer &&             \
       m_Players[i].Connected == TRUE)
      return i;
  }

  return -1;  // Not found in list
}

void cApp::ListPlayers()
{
  long i;
  char Text[256];
  char Message[256] = "";
  char Number[2];

  // Error checking
  if(m_Players == NULL)
    return;

  // Clear player list
  SendMessage(m_Controls[3], LB_RESETCONTENT, 0, 0);

  // Count all players and add names to list
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == TRUE)
	{
	  strcat(Message, m_Players[i].Name);
	  strcat(Message, " ����Ἱ��������Ţ ");
	  itoa(m_Players[i].NumMap, Number, 10);
	  strcat(Message, Number);

      SendMessage(m_Controls[3], LB_ADDSTRING, 0,             \
                 (LPARAM)Message);
	  strcpy(Message,"");
	}
  }

  // Display player count
  if(!m_NumPlayers)

	//Caption No Connected Players
    SetWindowText(m_Controls[1], "����ռ�������������"); 
  else {

	//Caption amount of Players Connected
    sprintf(Text, "�ռ������������� %lu �� ", m_NumPlayers);
    SetWindowText(m_Controls[1], Text);
  }

  // Display cluster count
  if(!m_NumClusters)

	  // Caption No connected clusters
	  SetWindowText(m_Controls[2], "����դ���������������");

  else{

	  // Caption amount of cluster connected
	  sprintf(Text, "�դ��������������� %lu ����ͧ", m_NumClusters);
	  SetWindowText(m_Controls[2], Text);

  }

}

///////////////////////////////////////////////////////////
// Network send and receive functions
///////////////////////////////////////////////////////////
BOOL cApp::SendNetworkMessage(void *Msg, long SendFlags, int To)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;
  unsigned long Size;

  // Get size of message to send
  if((Size = mh->Size) == 0)
    return FALSE;

  // Set destination to all players if To == -1
  if(To == -1)
    To = DPNID_ALL_PLAYERS_GROUP;

  // Send the message
  return m_Server.Send(To, Msg, Size, SendFlags);
}

BOOL cApp::CreatePlayer(DPNMSG_CREATE_PLAYER *Msg)
{
  sCreatePlayerMessage cpm;

  // Setup message data
  cpm.Header.Type     = MSG_CREATE_PLAYER;
  cpm.Header.Size     = sizeof(sCreatePlayerMessage);
  cpm.Header.PlayerID = Msg->dpnidPlayer;

  QueueMessage(&cpm); // Queue the message
  
  return TRUE;
}

BOOL cApp::DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg)
{
  sDestroyPlayerMessage dpm;

  // Setup message data
  dpm.Header.Type     = MSG_DESTROY_PLAYER;
  dpm.Header.Size     = sizeof(sDestroyPlayerMessage);
  dpm.Header.PlayerID = Msg->dpnidPlayer;
  
  QueueMessage(&dpm); // Queue the message

  return TRUE;
}

BOOL cApp::Receive(DPNMSG_RECEIVE *Msg)
{
  sMessageHeader *mh = (sMessageHeader*)Msg->pReceiveData;
  sMessage	    *MsgPtr = (sMessage*)Msg->pReceiveData;

  // Make sure it's a valid message type and queue it
  switch(mh->Type) {

	case MSG_STATE_CHANGE_MAP:
		PlayerStateServer(MsgPtr);
		break;

	case MSG_MAP_CHANGE:	 // Change map of player
		ChangeMap(MsgPtr);
		break;

	case MSG_MONSTER_STATE:  // State of monster
		ChangeStateMonster(MsgPtr);
		break;

	case MSG_NUMBER:	     // Show number on monster
		ShowNumber(MsgPtr);
		break;

	case MSG_DEC_HP:		 // Decrease HP player	
		DecHPPlayer(MsgPtr);
		break;

	case MSG_FULL_HP:		 // Full HP for player die
		FullHPPlayer(MsgPtr);
		break;

	case MSG_STATE_CHANGE_TIME: // Change state players's from cluster
		ResponseChangeState(MsgPtr); // for calculate response time
		break;

    case MSG_ASSIGNID: 
      // Store player ID before continuing
      mh->PlayerID = Msg->dpnidSender;
    case MSG_PLAYER_INFO:
    case MSG_STATE_CHANGE:

//		Calculate time in server
//		if(MsgPtr->Header.PlayerID == m_Players[0].dpnidPlayer)
//			receive = timeGetTime();
/*
	case MSG_MAP_CHANGE:	
	case MSG_MONSTER_STATE: 
	case MSG_NUMBER:	     
	case MSG_DEC_HP:
	case MSG_FULL_HP:	
	case MSG_STATE_CHANGE_MAP:
	case MSG_STATE_CHANGE_TIME:
*/

	// Add message to queue
	QueueMessage((void*)Msg->pReceiveData);
	break;
  }

  return TRUE;
}

///////////////////////////////////////////////////////////
// Message queue functions
///////////////////////////////////////////////////////////
BOOL cApp::QueueMessage(void *Msg)
{
  sMessageHeader *mh = (sMessageHeader*)Msg;

  // Error checking - make sure there's a message array
  if(m_Messages == NULL)
    return FALSE;

  // Return if no room left in queue
  if(((m_MsgHead+1) % NUM_MESSAGES) == m_MsgTail)
    return FALSE;

  // Stuff message into queue
  if(mh->Size <= sizeof(sMessage)) {
    // Start the critical section
    EnterCriticalSection(&m_MessageCS);

    memcpy(&m_Messages[m_MsgHead], Msg, mh->Size);

    // Go to next empty message (flip around if at end)
    m_MsgHead++;
    if(m_MsgHead >= NUM_MESSAGES)
      m_MsgHead = 0;

    // Leave the critical section
    LeaveCriticalSection(&m_MessageCS);
  }

  return TRUE;
}

BOOL cApp::PlayerID(sMessage *Msg, DPNID To)
{
  sAssignPlayerIDMessage apidm;

  apidm.Header.Type     = MSG_ASSIGNID;
  apidm.Header.Size     = sizeof(sAssignPlayerIDMessage);
  apidm.Header.PlayerID = To;
  SendNetworkMessage(&apidm, DPNSEND_NOLOOPBACK, To);

  return TRUE;
}

BOOL cApp::PlayerInfo(sMessage *Msg, DPNID To)
{
  sRequestPlayerInfoMessage *rpim;
  sCreatePlayerMessage cpm;
  long i;

  // Error checking
  if(m_Players == NULL)
    return FALSE;

  // Get pointer to request info
  rpim = (sRequestPlayerInfoMessage*)Msg;

  for(i=0;i<MAX_PLAYERS;i++) {
    // Only send if found in list
    if(m_Players[i].dpnidPlayer == rpim->PlayerID &&          \
       m_Players[i].Connected == TRUE) {
 
      // Send player info to requesting player
      cpm.Header.Type     = MSG_PLAYER_INFO;
      cpm.Header.Size     = sizeof(sCreatePlayerMessage);
      cpm.Header.PlayerID = rpim->PlayerID;
      cpm.XPos            = m_Players[i].XPos;
      cpm.YPos            = m_Players[i].YPos;
      cpm.ZPos            = m_Players[i].ZPos;
      cpm.Direction       = m_Players[i].Direction;
	  cpm.NumMap		  = m_Players[i].NumMap;
	  cpm.HP			  = m_Players[i].HP;
	  strcpy(cpm.Name, m_Players[i].Name);

      SendNetworkMessage(&cpm, DPNSEND_NOLOOPBACK, To);

      break;
    }
  }

  return TRUE;
}

BOOL cApp::AddPlayer(sMessage *Msg)
{
  long i,Cluster;
  DWORD Size = 0;
  DPN_PLAYER_INFO *dpi = NULL;
  HRESULT hr;
  DPNID PlayerID;

  // Error checking
  if(m_Players == NULL)
    return FALSE;

  // Get the player ID #
  PlayerID = Msg->Header.PlayerID;

  // Get the player information 
  hr = m_Server.GetServerCOM()->GetClientInfo(PlayerID, dpi,  \
                                              &Size, 0);

  // Return on error or if adding server
  if(FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL)
    return FALSE;

  // Allocate player data buffer and try again
  if((dpi = (DPN_PLAYER_INFO*)new BYTE[Size]) == NULL)
    return FALSE;
  ZeroMemory(dpi, Size);
  dpi->dwSize = sizeof(DPN_PLAYER_INFO);
  if(FAILED(m_Server.GetServerCOM()->GetClientInfo(           \
                                PlayerID, dpi, &Size, 0))) {
    delete [] dpi;
    return FALSE;
  }

  // Make sure not already in list
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == PlayerID &&                \
       m_Players[i].Connected == TRUE) {
      delete [] dpi;
      m_Server.DisconnectPlayer(PlayerID);
      return FALSE;
    }
  }

  // Search for an empty slot to put player
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].Connected == FALSE) {

      m_Players[i].Connected = TRUE; // Flag as connected

      // Save DirectPlay DPNID # and name of player
      m_Players[i].dpnidPlayer = PlayerID;
      wcstombs(m_Players[i].Name, dpi->pwszName, 32);
		
	  if(strcmp(m_Players[i].Name, "Server") == 0) {
		  for(Cluster=0;Cluster<MAX_CLUSTER;Cluster++){
			  if(m_Clusters[Cluster].Connected == FALSE) {
				  m_Clusters[Cluster].Connected = TRUE;
				  m_Clusters[Cluster].dpnidCluster = PlayerID;
				  strcpy(m_Clusters[Cluster].Name, m_Players[i].Name);
				  m_Clusters[Cluster].NumMap = Cluster + 1;

				  // Send map number to cluster  
				  sClusterMapMessage cmm;
				  cmm.Header.Type		= MSG_CLUSTER_MAP;
				  cmm.Header.Size		= sizeof(sClusterMapMessage);
				  cmm.Header.PlayerID	= m_Clusters[Cluster].dpnidCluster;
				  cmm.NumMap			= m_Clusters[Cluster].NumMap;
				  SendNetworkMessage(&cmm, DPNSEND_NOLOOPBACK, m_Clusters[Cluster].dpnidCluster);

				  // Not Player
				  m_Players[i].Connected = FALSE;

				  // inc cluster count
				  m_NumClusters++;
				  ListPlayers();

				  break;
			  }
		  }

		  return TRUE;
	  }

      // Setup player data
      m_Players[i].XPos      = 0.0f;
      m_Players[i].YPos      = 0.0f;
      m_Players[i].ZPos      = 0.0f;
      m_Players[i].Direction = 0.0f;
      m_Players[i].Speed     = 256.0f;
      m_Players[i].State     = STATE_IDLE;
      m_Players[i].Latency   = 0;
	  m_Players[i].NumMap	 = 1;
	  m_Players[i].HP		 = 200;
  		
	  // Send add player info to cluster
	  Cluster = FindCluster(i);
	  sCreatePlayerMessage cpm;
	  cpm.Header.Type     = MSG_CREATE_PLAYER_MAP;
	  cpm.Header.Size     = sizeof(sCreatePlayerMessage);
	  cpm.Header.PlayerID = PlayerID;
	  cpm.XPos            = m_Players[i].XPos;
	  cpm.YPos            = m_Players[i].YPos;
	  cpm.ZPos            = m_Players[i].ZPos;
	  cpm.Direction       = m_Players[i].Direction;
	  cpm.NumMap		  = m_Players[i].NumMap;
	  cpm.HP			  = m_Players[i].HP;
	  strcpy(cpm.Name ,m_Players[i].Name);
	  SendNetworkMessage(&cpm, DPNSEND_NOLOOPBACK, m_Clusters[Cluster].dpnidCluster);
	
      // Send add player info to all players in area
      cpm.Header.Type     = MSG_CREATE_PLAYER;
      SendNetworkMessage(&cpm, DPNSEND_NOLOOPBACK, -1);

	  m_NumPlayers++;		//Add Number Player

      ListPlayers();        // List all players

      delete [] dpi;        // Free player data

      return TRUE;          // Return success
    }
  }

  delete[] dpi;  // Free player data

  // Disconnect player - not allowed to connect
  m_Server.DisconnectPlayer(PlayerID);

  return FALSE;  // Return failure
}

BOOL cApp::RemovePlayer(sMessage *Msg)
{
  long i,Cluster;

  // Error checking
  if(m_Players == NULL)
    return FALSE;

  // Search for cluster in list
  for(i=0;i<MAX_CLUSTER;i++){
	 if(m_Clusters[i].dpnidCluster == Msg->Header.PlayerID &&    \
		m_Clusters[i].Connected == TRUE) {

		m_Clusters[i].Connected = FALSE;  // Disconnect player
		m_NumClusters--;		//subtractive amount of clusters

		// List all players
		ListPlayers();

		return TRUE;
	 }	
  }

  // Search for player in list
  for(i=0;i<MAX_PLAYERS;i++) {
    if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
       m_Players[i].Connected == TRUE) {

      m_Players[i].Connected = FALSE;  // Disconnect player

      // Send remove player message to all players in area
      sDestroyPlayerMessage dpm;
      dpm.Header.Type     = MSG_DESTROY_PLAYER;
      dpm.Header.Size     = sizeof(sDestroyPlayerMessage);
      dpm.Header.PlayerID = Msg->Header.PlayerID;
      SendNetworkMessage(&dpm, DPNSEND_NOLOOPBACK, -1);

	  // Send remove player message to cluster
	  Cluster = FindCluster(i);
	  dpm.Header.Type     = MSG_DESTROY_PLAYER_MAP;
	  SendNetworkMessage(&dpm, DPNSEND_NOLOOPBACK, m_Clusters[Cluster].dpnidCluster);

	  m_NumPlayers--;		//subtractive amount of player

	  if(m_NumPlayers <0)
		  m_NumPlayers = 0;

      // List all players
      ListPlayers();

      return TRUE;
	}	
  }
  return FALSE;  // Return failure
}

BOOL cApp::PlayerStateChange(sMessage *Msg)
{
	sStateChangeMessage *scm, uscm;
	long i, PlayerNum, Cluster;

    // Get player number in list
	PlayerNum = -1;
	for(i=0;i<MAX_PLAYERS;i++) {
		if(m_Players[i].dpnidPlayer == Msg->Header.PlayerID &&    \
		   m_Players[i].Connected == TRUE) {
				PlayerNum = i;
				break;
		}
	}

	if(PlayerNum == -1)
		return FALSE;

	// Get pointer to state change message
	scm = (sStateChangeMessage*)Msg;

	// Send player data to cluster
	Cluster = FindCluster(PlayerNum);
    uscm.Header.Type     = MSG_STATE_CHANGE_MAP;
    uscm.Header.Size     = sizeof(sStateChangeMessage);
    uscm.Header.PlayerID = m_Players[PlayerNum].dpnidPlayer;
    uscm.State           = scm->State;
    uscm.Direction       = scm->Direction;
    SendNetworkMessage(&uscm, DPNSEND_NOLOOPBACK, m_Clusters[Cluster].dpnidCluster);

  return TRUE;
}

void cApp::ChangeMap(sMessage *Msg)
{

	long PlayerNum, Cluster;
	sMapChangeMessage *mcm, smcm;
	sCreatePlayerMessage cpm;

	mcm = (sMapChangeMessage*)Msg;

	// Get player number in list
	if((PlayerNum = GetPlayerNum(mcm->Header.PlayerID)) == -1)
		return;

	// Change player data with new map and location
	m_Players[PlayerNum].XPos		= mcm->XPos;
	m_Players[PlayerNum].YPos		= mcm->YPos;
	m_Players[PlayerNum].ZPos		= mcm->ZPos;
	m_Players[PlayerNum].Direction	= mcm->Direction;
	m_Players[PlayerNum].NumMap		= mcm->NumMap;

	// Send message create player to cluster 
	Cluster = FindCluster(PlayerNum);
	cpm.Header.Type		= MSG_CREATE_PLAYER_MAP;
	cpm.Header.Size		= sizeof(sCreatePlayerMessage);
	cpm.Header.PlayerID = m_Players[PlayerNum].dpnidPlayer;
	cpm.HP				= m_Players[PlayerNum].HP;
	cpm.NumMap			= m_Players[PlayerNum].NumMap;
	cpm.XPos			= m_Players[PlayerNum].XPos;
	cpm.YPos			= m_Players[PlayerNum].YPos;
	cpm.ZPos			= m_Players[PlayerNum].ZPos;
	strcpy(cpm.Name	,m_Players[PlayerNum].Name);
	SendNetworkMessage(&cpm, DPNSEND_NOLOOPBACK, m_Clusters[Cluster].dpnidCluster); 

	// Send network message to all player
	smcm.Header.Type = MSG_MAP_CHANGE;
	smcm.Header.Size = sizeof(sMapChangeMessage);
	smcm.Header.PlayerID = m_Players[PlayerNum].dpnidPlayer;
    smcm.XPos            = m_Players[PlayerNum].XPos;
    smcm.YPos            = m_Players[PlayerNum].YPos;
    smcm.ZPos            = m_Players[PlayerNum].ZPos;
    smcm.Direction       = m_Players[PlayerNum].Direction;
	smcm.NumMap			 = m_Players[PlayerNum].NumMap;
    SendNetworkMessage(&smcm, DPNSEND_NOLOOPBACK);

	ListPlayers();
}

void cApp::ChangeStateMonster(sMessage *Msg)
{
	sMonsterStateMessage *msm;

	// Get pointer to message data
    msm = (sMonsterStateMessage*)Msg;

	// Send state monster to all players
	SendNetworkMessage(msm, DPNSEND_NOLOOPBACK);
}

void cApp::ShowNumber(sMessage *Msg)
{
	sNumberMessage *nm;

	// Get pointer to message data
	nm = (sNumberMessage*)Msg;

	// Send number dec HP monster to all player
	SendNetworkMessage(nm, DPNSEND_NOLOOPBACK);
}

void cApp::DecHPPlayer(sMessage *Msg)
{
	sDecHPPlayerMessage *dhpm;

	// Get pointer to message data
	dhpm = (sDecHPPlayerMessage*)Msg;

	// Send dec HP to player
	SendNetworkMessage(dhpm, DPNSEND_NOLOOPBACK, dhpm->Header.PlayerID);

}

void cApp::FullHPPlayer(sMessage *Msg)
{
	sFullHPPlayerMessage *fhpm;

	// Get pointer to message data
	fhpm = (sFullHPPlayerMessage*)Msg;

	// Send full HP to player
	SendNetworkMessage(fhpm, DPNSEND_NOLOOPBACK, fhpm->Header.PlayerID);

}

void cApp::PlayerStateServer(sMessage *Msg)
{
	sStateChangeMessage *scm;
	int PlayerNum;

	// Get pointer to message data
	scm = (sStateChangeMessage*)Msg;

	// Get player number in list
	if((PlayerNum = GetPlayerNum(scm->Header.PlayerID)) == -1)
		return;

	m_Players[PlayerNum].XPos		= scm->XPos;
	m_Players[PlayerNum].YPos		= scm->YPos;
	m_Players[PlayerNum].ZPos		= scm->ZPos;
	m_Players[PlayerNum].Direction	= scm->Direction;
	m_Players[PlayerNum].Speed		= scm->Speed;
	m_Players[PlayerNum].State		= scm->State;

	
	// Send player's state change to all client
	scm->Header.Type		= MSG_STATE_CHANGE;
	SendNetworkMessage(scm, DPNSEND_NOLOOPBACK, -1);
}

void cApp::ResponseChangeState(sMessage *Msg)
{
	sStateChangeMessage *scm;
	int PlayerNum;
//	char Text[256];

	// Get pointer to message data
	scm = (sStateChangeMessage*)Msg;

	// Get player number in list
	if((PlayerNum = GetPlayerNum(scm->Header.PlayerID)) == -1)
		return;


	m_Players[PlayerNum].XPos		= scm->XPos;
	m_Players[PlayerNum].YPos		= scm->YPos;
	m_Players[PlayerNum].ZPos		= scm->ZPos;
	m_Players[PlayerNum].Direction	= scm->Direction;
	m_Players[PlayerNum].Speed		= scm->Speed;
	m_Players[PlayerNum].State		= scm->State;
/*
	if(PlayerNum == 0) {
		time = timeGetTime() - receive;
		// Caption amount of cluster connected
		sprintf(Text, "������ %lu ������Թҷ�", time);
		SetWindowText(m_Controls[2], Text);
		ListPlayers();
	}
*/
	// Send player's state change to all client
	scm->Header.Type		= MSG_STATE_CHANGE_TIME;
	SendNetworkMessage(scm, DPNSEND_NOLOOPBACK, -1);
}


///////////////////////////////////////////////////////////
// App initialization functions
///////////////////////////////////////////////////////////
BOOL cApp::SelectAdapter()
{
  int Result;

  // Hide main window
  ShowWindow(GethWnd(), SW_HIDE);

  // Build a list of network adapters
  m_Adapters.Init();

  // Open configure dialog
  Result = DialogBox(GethInst(), MAKEINTRESOURCE(IDD_CONFIG), \
                     GethWnd(), ConfigDialogProc);

  // Don't continue if quit selected
  if(Result == FALSE)
    return FALSE;

  // Continue if user selected OK
  return TRUE;
}

void cApp::SetupApplicationWindow()
{
  // Create the windows controls

  // Window to hold host IP address
  m_Controls[0] = CreateWindow("STATIC", "",                  \
          WS_CHILD | WS_VISIBLE,                              \
          4, 4, 312, 18,                                      \
          GethWnd(), NULL, GethInst(), NULL);

  // Window to hold # of connected players
  m_Controls[1] = CreateWindow("STATIC",                      \
          "����ռ�������������",                             \
          WS_CHILD | WS_VISIBLE,                              \
          4, 26, 312, 18,                                     \
          GethWnd(), NULL, GethInst(), NULL);

	// Window to hold # of connected cluster
  m_Controls[2] = CreateWindow("STATIC",                      \
          "����դ���������������",                             \
          WS_CHILD | WS_VISIBLE,                              \
          4, 48, 312, 18,                                     \
          GethWnd(), NULL, GethInst(), NULL);


  // List box to display connect player's names and map number
  m_Controls[3] = CreateWindow("LISTBOX", "",                 \
          WS_CHILD | WS_BORDER | WS_VSCROLL | WS_VISIBLE,     \
          4, 70, 312, 250,                                    \
          GethWnd(), NULL, GethInst(), NULL);   

  // Show main window
  ShowWindow(GethWnd(), SW_SHOW);
}

BOOL cApp::InitializeGame()
{
  
  // Allocate message queue and reset message pointers
  m_Messages = new sMessage[NUM_MESSAGES]();
  m_MsgHead = m_MsgTail = 0;

  // Create player structures
  m_Players = new sPlayer[MAX_PLAYERS]();

  m_Clusters = new sCluster[MAX_CLUSTER]();

  // Reset # of players
  m_NumPlayers = 0;

  // Reset # of clusters
  m_NumClusters = 0;

  return TRUE;
}

BOOL cApp::HostGame()
{
  char Text[33], IP[16];

  // Configure server and begin hosting
  m_Server.Init();
  if(m_Server.Host(m_guidAdapter, 9123,                       \
                  "RPGGAME", NULL, MAX_PLAYERS) == FALSE)
    return FALSE;

  // Get Server IP address and display in application window
  m_Server.GetIP(IP);

  // Caption Server IP Address 
  sprintf(Text, "�;����������: %s", IP);
  SetWindowText(m_Controls[0], Text);

  return TRUE;  // Return success
}

///////////////////////////////////////////////////////////
// Game message queue processing and update functions
///////////////////////////////////////////////////////////
void cApp::ProcessQueuedMessages()
{
  sMessage *Msg;
  long Count = 0;

  // Pull out messages to process
  while(Count != MESSAGES_PER_FRAME && m_MsgHead != m_MsgTail) {

    // Get pointer to 'tail' message
    EnterCriticalSection(&m_MessageCS);
    Msg = &m_Messages[m_MsgTail];
    LeaveCriticalSection(&m_MessageCS);

    // Process a single message based on type
    switch(Msg->Header.Type) {
      case MSG_ASSIGNID: // Send users their player ID
        PlayerID(Msg, Msg->Header.PlayerID);
        break;

      case MSG_PLAYER_INFO:    // Request player info
        PlayerInfo(Msg, Msg->Header.PlayerID);
        break;

      case MSG_CREATE_PLAYER:  // Add a player
        AddPlayer(Msg);
        break;

      case MSG_DESTROY_PLAYER: // Remove a player
        RemovePlayer(Msg);
        break;

      case MSG_STATE_CHANGE:   // Change state of player
        PlayerStateChange(Msg);
        break;

	  case MSG_MAP_CHANGE:	 // Change map of player
		ChangeMap(Msg);
		break;

	  case MSG_MONSTER_STATE:  // State of monster
		ChangeStateMonster(Msg);
		break;

	  case MSG_NUMBER:	     // Show number on monster
		ShowNumber(Msg);
		break;

	  case MSG_DEC_HP:		 // Decrease HP player	
		DecHPPlayer(Msg);
		break;

	  case MSG_FULL_HP:		 // Full HP for player die
		FullHPPlayer(Msg);
		break;

	  case MSG_STATE_CHANGE_MAP: // Change State player's from cluster
		PlayerStateServer(Msg);
		break;

	  case MSG_STATE_CHANGE_TIME: // Change state players's from cluster
		ResponseChangeState(Msg); // for calculate response time
		break;
    }

    Count++; // Increase processed message count

    // Goto next message in list
    EnterCriticalSection(&m_MessageCS);
    m_MsgTail = (m_MsgTail + 1) % NUM_MESSAGES;
    LeaveCriticalSection(&m_MessageCS);
  }
}

void cApp::UpdateLatency()
{
  long i;
  DPN_CONNECTION_INFO dpci;
  HRESULT hr;

  // Go through all players
  for(i=0;i<MAX_PLAYERS;i++) {
    
    // Only process connected players
    if(m_Players[i].Connected == TRUE) {

      // Request player connection settings
      hr = m_Server.GetServerCOM()->GetConnectionInfo(        \
                   m_Players[i].dpnidPlayer, &dpci, 0);

      if(SUCCEEDED(hr)) {
        m_Players[i].Latency = dpci.dwRoundTripLatencyMS / 2;

        // Bounds latency to 1 second
        if(m_Players[i].Latency > 1000)
          m_Players[i].Latency = 1000;

      } else {
        m_Players[i].Latency = 0;
      }
    }
  }
}

int cApp::FindCluster(int PlayerNum){

	int Cluster;

	for(Cluster=0;Cluster<MAX_CLUSTER;Cluster++){
		if(m_Clusters[Cluster].NumMap == m_Players[PlayerNum].NumMap)
			break;
	}

	return Cluster;
}

///////////////////////////////////////////////////////////
// Server class code
///////////////////////////////////////////////////////////
BOOL cServer::CreatePlayer(DPNMSG_CREATE_PLAYER *Msg)
{
  // Send message to application class instance (if any)
  if(g_Application != NULL)
    g_Application->CreatePlayer(Msg);
 
  return TRUE;
}

BOOL cServer::DestroyPlayer(DPNMSG_DESTROY_PLAYER *Msg)
{
  // Send message to application class instance (if any)
  if(g_Application != NULL)
    g_Application->DestroyPlayer(Msg);
  return TRUE;
}

BOOL cServer::Receive(DPNMSG_RECEIVE *Msg)
{
  // Send message to application class instance (if any)
  if(g_Application != NULL)
    g_Application->Receive(Msg);
  return TRUE;
}