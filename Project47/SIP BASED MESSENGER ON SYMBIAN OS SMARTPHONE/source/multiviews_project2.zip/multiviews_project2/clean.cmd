@echo off
setlocal

set arg1=%1
set arg2=%2
set arg3=%3
goto :doit

:cleanall
setlocal

cd %1
 call abld clean -keepgoing %arg1%
 call abld reallyclean -keepgoing %arg1%

endlocal
goto :EOF

:doit

call :cleanall	group

if "%arg1%"=="wins" goto uninstall
if "%arg1%"=="thumb" goto uninstall
goto :EOF
:uninstall
..\epoc32\release\%arg1%\udeb\SIPCLIENTUNINSTALLER.EXE