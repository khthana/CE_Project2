#include "AudioPlayer.h"

#include <eikenv.h>
#include <aknutils.h>
#include "MultiViewsAppUi.h"

//#include <MultiViews.rsg>


_LIT(KToPlayFileWav1,	"\\system\\apps\\MULTIVIEWS\\Mermaid.wav");
_LIT(KToPlayFileWav2,	"\\system\\apps\\MULTIVIEWS\\freeLife.wav");
_LIT(KToPlayFileWav3,	"\\system\\apps\\MULTIVIEWS\\Ring.wav");

const TInt KToneVolumeDenominator = 2;

CAudioPlayer::CAudioPlayer(CMultiViewsAppUi& aAppUi)  : iState(EStopped),iAppUi(aAppUi) 	
	{        
		
	}

CAudioPlayer::~CAudioPlayer()	
	{	
	Stop();

	delete iPlayerFile;
	iPlayerFile = NULL;
 	}

CAudioPlayer* CAudioPlayer::NewL(CMultiViewsAppUi& aAppUi)
    {
    CAudioPlayer* self = NewLC(aAppUi);
    CleanupStack::Pop(self); 
    return self;
    }

CAudioPlayer* CAudioPlayer::NewLC(CMultiViewsAppUi& aAppUi)
    {
    CAudioPlayer* self = new (ELeave) CAudioPlayer(aAppUi);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }


void CAudioPlayer::ConstructL() { }

void CAudioPlayer::MapcInitComplete(TInt aError, const TTimeIntervalMicroSeconds& /*aDuration*/)
	{
	if (aError == KErrNone) {
		iPlayerFile->SetVolume(iPlayerFile->MaxVolume() );/// KToneVolumeDenominator);
		iPlayerFile->Play();
		}
	else{
		Stop();
		}
	}

void CAudioPlayer::MapcPlayComplete(TInt /*aError*/)
	{
	iState = EStopped;
	//delete iPlayerFile;
	//iPlayerFile = NULL;
	}

void CAudioPlayer::PlayWavL(TInt aInt)
	{
	TFileName wavFile;

	switch ( aInt )
        {
        case 1:
            {
            wavFile=KToPlayFileWav1;
            break;
            }
        case 2:
            {
            wavFile=KToPlayFileWav2;
			break;
            }
        case 3:
            {
            wavFile=KToPlayFileWav3;
			break;
            }
        default:
			{
            wavFile=KToPlayFileWav1;
            break;
            }     
        }
	
	//TFileName wavFile(KToPlayFileWav1);
	
	User::LeaveIfError(CompleteWithAppPath(wavFile));
	iState = EPlaying;
	iPlayerFile = CMdaAudioPlayerUtility::NewFilePlayerL(wavFile, *this);
	}

void CAudioPlayer::Stop()
	{
	iPlayerFile->Stop();

	//delete iPlayerFile;
	//iPlayerFile = NULL;

	iState = EStopped;
	}
