#include <eikmenup.h>
#include <mda\common\audio.h>
#include <mmf\common\MmfFourCC.h>

///////////////////////////////
#include <mmf\server\mmfcodec.h>
#include <mmf\server\mmfdatabuffer.h>
#include <mmf\plugin\mmfcodecimplementationuids.hrh>
///////////////////////////////

#include <aknquerydialog.h>
#include <aknnotewrappers.h>

//#include "sound.pan"
#include "RecordEngine.h"
#include "MultiViewsAppUi.h"

// RAW -> PCM
const TUid KMmfUidControllerAudio = {0x101F5022};
const TUid KUidFormatRAWRead  = {0x101F5C16};
const TUid KUidFormatRAWWrite =  {0x101F5C17};

// Identifying string for this audio utility
_LIT(KAudioRecorder, "Recorder");

// An existing sound sample file 
_LIT(KToPlayFileStream,	"C:\\System\\Apps\\Sound\\record.pcm");
_LIT(KToAMRFileStream,	"C:\\System\\Apps\\Sound\\record.amr");

const TInt KPCMBuffer = 320;
const TInt KAMRBuffer = 32;


CRecordEngine::CRecordEngine(CMultiViewsAppUi& aAppUi) : 
    iAppUi(aAppUi) 
    {
	// No implementation required
    }

CRecordEngine* CRecordEngine::NewL(CMultiViewsAppUi& aAppUi)
    {
    CRecordEngine* self = NewLC(aAppUi);
    CleanupStack::Pop(self); 
    return self;
    }

CRecordEngine* CRecordEngine::NewLC(CMultiViewsAppUi& aAppUi)
    {
    CRecordEngine* self = new (ELeave) CRecordEngine(aAppUi);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }


void CRecordEngine::ConstructL()
    {
    iMdaAudioRecorderUtility = CMdaAudioRecorderUtility::NewL(*this);
	

	}

CRecordEngine::~CRecordEngine()
    {
    delete iMdaAudioRecorderUtility;    
    iMdaAudioRecorderUtility = NULL;


    }

void CRecordEngine::RecordL()
    {
	
	iMdaAudioRecorderUtility->OpenFileL(KToPlayFileStream,
										KMmfUidControllerAudio,
										KMmfUidControllerAudio,
										KUidFormatRAWWrite,
										KMMFFourCCCodePCM16
										);
	

    // Record from the device microphone
    iMdaAudioRecorderUtility->SetAudioDeviceMode(CMdaAudioRecorderUtility::ELocal);

    // Set maximum gain for recording
    iMdaAudioRecorderUtility->SetGain(iMdaAudioRecorderUtility->MaxGain());
    
    // Delete current audio sample from beginning of file
    iMdaAudioRecorderUtility->SetPosition(TTimeIntervalMicroSeconds(0));
    iMdaAudioRecorderUtility->CropL();
   
    iMdaAudioRecorderUtility->RecordL();
    }

void CRecordEngine::StopL()
    {
    iMdaAudioRecorderUtility->Stop();
	}


const TDesC& CRecordEngine::Identify()
    {
    return KAudioRecorder;
    }



void CRecordEngine::MoscoStateChangeEvent(CBase* /*aObject*/, TInt /*aPreviousState*/, TInt /*aCurrentState*/, TInt /*aErrorCode*/)
    {
	// Mo implementation required
    }

void CRecordEngine::LoadPCMFileL()
	{
	
	RFs fs;	// file server instance
	CleanupClosePushL(fs);				// PUSH
	User::LeaveIfError(fs.Connect());
	
	RFile audiofile;
	CleanupClosePushL(audiofile);
	
	TFileName streamFile(KToPlayFileStream);
	User::LeaveIfError(CompleteWithAppPath(streamFile));
	User::LeaveIfError(audiofile.Open(fs, streamFile, EFileRead | EFileShareReadersOnly));

	// file opened ok, create buffer
	TInt size;
	audiofile.Size(size);
	size = size/320+1;
	iPCMBuffer.Reset();
	
	for (TInt idx=0; idx<size; idx++)
		{
		buffer = new(ELeave) TBuf8<KPCMBuffer>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iPCMBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}
	
	// create buffer ok, proceed reading
	TInt idx2=0;
	while (idx2<iPCMBuffer.Count())
		{
		TInt fstatus=audiofile.Read(*iPCMBuffer[idx2], 
			(iPCMBuffer[idx2])->MaxSize());

		if (fstatus!=KErrNone)
			break;
		idx2++;
		}
	
	//iStreamStart=0;
	//iStreamEnd=iSrcBuffer.Count()-1;
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy(2);	

	//User::InfoPrint(_L("Load PCM"));
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("Load PCM"));
	}

void CRecordEngine::SaveAMRFileL()
	{
	
	RFs fs;	// file server instance
	RFile audiofile;

	TInt writeidx=0;
	// open fileserver session and file
	User::LeaveIfError(fs.Connect());	
	// push into cleanup stack
	CleanupClosePushL(fs);

	// check for free space for saving the sample
	TVolumeInfo volinfo;
	TInt err=fs.Volume(volinfo,EDriveC);
	if ( volinfo.iFree<(iPCMBuffer.Count()*KAMRBuffer) )
		{
		// not enough free space on drive for saving, report and exit
		CleanupStack::PopAndDestroy();
		return;
		}

	
//	err = audiofile.Open(fs, KToAMRFileStream, EFileWrite|EFileStream);
	err = audiofile.Replace(fs, KToAMRFileStream, EFileWrite|EFileStream);


	if (err==KErrNone) 
		{
	
		// Uid of PCM16toAMR codec is 0x101FAF68
		CMMFCodec* codec = CMMFCodec::NewL(TUid::Uid(0x101FAF68));
		CleanupStack::PushL(codec);
		
		
		CMMFDescriptorBuffer* srcbuf = CMMFDescriptorBuffer::NewL(320);
		CleanupStack::PushL(srcbuf);
	
		// Copy your PCM frame data into srcbuf, for example: srcbuf->Data().Copy(pcmbuf);
		CMMFDescriptorBuffer* dstbuf = CMMFDescriptorBuffer::NewL(32);
		CleanupStack::PushL(dstbuf);

		// file opened ok, proceed writing
		// read audio data directly into iStreamBuffer
		for (TInt idx=0; idx<iPCMBuffer.Count(); idx++)	
			{
			
			srcbuf->Data().Copy(*iPCMBuffer[idx]);

			TCodecProcessResult result = codec->ProcessL(*srcbuf, *dstbuf);
			
			audiofile.Write(dstbuf->Data());
			
			writeidx++;
			// write buffers in correct order, rotate if necessary
			if (writeidx==iPCMBuffer.Count()) writeidx=0;
			}
			
		// now the dstbuf contains an AMR frame data
		CleanupStack::PopAndDestroy(dstbuf);
		CleanupStack::PopAndDestroy(srcbuf);
		CleanupStack::PopAndDestroy(codec);
		
		User::InfoPrint(KToAMRFileStream);
		
	
		}	
	else 
		{
		User::InfoPrint(_L("Error"));
		// failed to open file
		}
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy();

	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("Save AMR"));
	}