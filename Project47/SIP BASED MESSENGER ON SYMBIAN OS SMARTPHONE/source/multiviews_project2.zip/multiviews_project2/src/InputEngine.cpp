#include <mda\common\audio.h>
#include <MdaAudioInputStream.h>	// audio input stream
#include <MdaAudioOutputStream.h>	// audio output stream
#include <aknutils.h>
#include <eikgted.h>

#include <aknquerydialog.h>
#include <aknnotewrappers.h>


#include "InputEngine.h"
//#include "UINotifier.h"

// audio data buffer size
// 11200 bytes will contain 700ms of 16bit audio data 
const TInt KStreamBufferSize = 1024;
const TInt KTimer = 100000;

// number of audio data buffers
const TInt KStreamBufferCount = 80;

// file to store the sample
_LIT(KAudioFile2,"C:\\System\\Apps\\Sound\\record.wav");
_LIT(KAudioFile3,"C:\\System\\Apps\\Sound\\test.jpg");
_LIT(KAudioFile4,"C:\\System\\Apps\\Sound\\copy.jpg");

_LIT(KAudioFile1, "\\System\\apps\\Sockets\\Ring.wav");
//_LIT(KAudioFile2, "\\system\\apps\\Sockets\\Stream.pcm");
_LIT(KAudioFile, "\\system\\apps\\Sockets\\sample.aud");
//_LIT(KAudioFile, "\\system\\apps\\InputStream\\Stream2.pcm");
//_LIT(KAudioFile, "\\system\\apps\\InputStream\\Stream.pcm");
//_LIT(KToPlayFileStream,	"\\system\\apps\\InputStream\\Stream.pcm");

CInputEngine* CInputEngine::NewL() //MUINotifier& aConsole)
	{
	CInputEngine* self = CInputEngine::NewLC();//aConsole);
    CleanupStack::Pop(self);
	return self;
	}

CInputEngine* CInputEngine::NewLC() //MUINotifier& aConsole)
	{
	CInputEngine* self = new (ELeave) CInputEngine();//aConsole);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// Standard EPOC 2nd phase constructor
void CInputEngine::ConstructL()
	{
	// Construct input stream
	iInputStream = CMdaAudioInputStream::NewL(*this);
	// Construct output stream
	iOutputStream = CMdaAudioOutputStream::NewL(*this);

	// Stream buffer allocation
	//TDes8* buffer;
	for (TInt idx=0; idx<1; idx++)
		{
		buffer = new(ELeave) TBuf8<KStreamBufferSize>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iStreamBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}	
	iStreamStart=0;
	iStreamEnd=iStreamBuffer.Count()-1;
	
	
	}

// ----------------------------------------------------------------------------
// CInputEngine::CInputEngine(
//     CAudioStreamAppUi* aAppUi)
//
// constructor
// ----------------------------------------------------------------------------
CInputEngine::CInputEngine() //MUINotifier& aConsole)
	//: iConsole(aConsole)
	{
	//iAppUi=aAppUi;
	// initial audio stream properties, 8KHz mono
	iStreamSettings.iChannels=TMdaAudioDataSettings::EChannelsMono;
	iStreamSettings.iSampleRate=TMdaAudioDataSettings::ESampleRate8000Hz;
	}

// ----------------------------------------------------------------------------
// CInputEngine::~CInputEngine()
//
// destructor
// ----------------------------------------------------------------------------
CInputEngine::~CInputEngine()
	{ 
	// close and delete streams
	if (iInputStatus!=ENotReady)
		iInputStream->Stop();
	if (iOutputStatus!=ENotReady)
		iOutputStream->Stop();
    delete iInputStream;
    iInputStream=NULL;
    delete iOutputStream;
    iOutputStream=NULL;
	// empties and deletes stream buffer
	iStreamBuffer.ResetAndDestroy();
	}


// ----------------------------------------------------------------------------
// CInputEngine::Play()
//
// plays the audio data contained in the buffer
// ----------------------------------------------------------------------------
void CInputEngine::Play()
	{
	
	// if either stream is active, return
	if (iInputStatus!=ENotReady || iOutputStatus!=ENotReady) 
		return;
	// open output stream
	// upon completion will receive callback in 
	// MMdaAudioInputStreamCallback::MaoscOpenComplete()
	iOutputStream->Open(&iStreamSettings);

	//iConsole.PrintNotify(_L("Recording failed!"), CEikGlobalTextEditor::EBold);


	}


// ----------------------------------------------------------------------------
// CInputEngine::Record()
//
// records audio data into the buffer
// ----------------------------------------------------------------------------
void CInputEngine::Record()
	{
	//User::InfoPrint(_L("1111"));

	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("1111"));
	
	
	//iConsole.PrintNotify(_L("Recording0"), CEikGlobalTextEditor::EBold);

	// If either stream is active, return
	if (iInputStatus!=ENotReady || iOutputStatus!=ENotReady) 
		return;
	// open input stream
	// upon completion will receive callback in 
	// MMdaAudioInputStreamCallback::MaiscOpenComplete()
	iInputStream->Open(&iStreamSettings);


	}


// ----------------------------------------------------------------------------
// CInputEngine::Stop()
//
// stops playing/recording
// ----------------------------------------------------------------------------
void CInputEngine::Stop()
	{
	
	// if input or output streams are active, close them
	if (iInputStatus!=ENotReady) 
		{
		iInputStream->Stop();

		//iConsole.PrintNotify(_L("Recording Stopped."), CEikGlobalTextEditor::EBold);
		User::InfoPrint(_L("Stopped"));
		
		
		CAknInformationNote* note = new (ELeave) CAknInformationNote();
		note->ExecuteLD(_L("Stopped"));


		// get stream start (first block of audio) and end index
		iStreamEnd = iStreamIdx;
		iStreamStart = iStreamIdx+1;
		if (iStreamStart==iStreamBuffer.Count()) iStreamStart=0;
		}		
	if (iOutputStatus!=ENotReady) 
		{
		iOutputStream->Stop();

		//iConsole.PrintNotify(_L("Playback stopped."), CEikGlobalTextEditor::EBold);

		}
	}


// ----------------------------------------------------------------------------
// CInputEngine::LoadAudioFileL()
//
// loads the audio data from a file into the buffer
// ----------------------------------------------------------------------------

void CInputEngine::LoadAudioFileL()
	{
	
	RFs fs;	// file server instance
	CleanupClosePushL(fs);				// PUSH
	User::LeaveIfError(fs.Connect());
	
	RFile audiofile;
	CleanupClosePushL(audiofile);
	
	TFileName streamFile(iSendFileName);
	User::LeaveIfError(CompleteWithAppPath(streamFile));
	User::LeaveIfError(audiofile.Open(fs, streamFile, EFileRead | EFileShareReadersOnly));

	// file opened ok, create buffer
	TInt size;
	audiofile.Size(size);
	size = size/1024+1;
	iStreamBuffer.Reset();
	
	for (TInt idx=0; idx<size; idx++)
		{
		buffer = new(ELeave) TBuf8<KStreamBufferSize>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iStreamBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}
	
	// create buffer ok, proceed reading
	TInt idx2=0;
	while (idx2<iStreamBuffer.Count())
		{
		TInt fstatus=audiofile.Read(*iStreamBuffer[idx2], 
			(iStreamBuffer[idx2])->MaxSize());

		if (fstatus!=KErrNone)
			break;
		idx2++;
		}
	
	iStreamStart=0;
	iStreamEnd=iStreamBuffer.Count()-1;
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy(2);
	
	//iConsole.PrintNotify(_L("Loading Complete."), CEikGlobalTextEditor::EBold);

/*

	// open file
	TInt err = audiofile.Open(fs, KAudioFile1, EFileRead|EFileStream);
	if (err==KErrNone) 
		{
		// file opened ok, proceed reading
		TInt idx=0;
		while (idx<iStreamBuffer.Count())
			{
			TInt fstatus=audiofile.Read(*iStreamBuffer[idx], 
				(iStreamBuffer[idx])->MaxSize());
			if (fstatus!=KErrNone)
				break;
			idx++;
			}
		}	
	else 
		{
		// failed to open file
		}
	iStreamStart=0;
	iStreamEnd=iStreamBuffer.Count()-1;
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy();*/
	}


// ----------------------------------------------------------------------------
// CInputEngine::SaveAudioFileL()
//
// saves the audio data in the buffer into a file
// ----------------------------------------------------------------------------
void CInputEngine::SaveAudioFileL()
	{
	
	RFs fs;	// file server instance
	RFile audiofile;

	TInt writeidx=iStreamStart;
	// open fileserver session and file
	User::LeaveIfError(fs.Connect());	
	// push into cleanup stack
	CleanupClosePushL(fs);

	// check for free space for saving the sample
	TVolumeInfo volinfo;
	TInt err=fs.Volume(volinfo,EDriveC);
	if ( volinfo.iFree<(iStreamBuffer.Count()*KStreamBufferSize) )
		{
		// not enough free space on drive for saving, report and exit
		CleanupStack::PopAndDestroy();
		return;
		}

	err = audiofile.Create(fs, KAudioFile4, EFileWrite|EFileStream);
	if (err==KErrNone) 
		{
		// file opened ok, proceed writing
		// read audio data directly into iStreamBuffer
		for (TInt idx=0; idx<iStreamBuffer.Count(); idx++)	
			{
			audiofile.Write(*iStreamBuffer[writeidx]);
			writeidx++;
			// write buffers in correct order, rotate if necessary
			if (writeidx==iStreamBuffer.Count()) writeidx=0;
			}
		User::InfoPrint(KAudioFile4);
		}	
	else 
		{
		User::InfoPrint(_L("Error"));
		// failed to open file
		}
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy();

	//iConsole.PrintNotify(_L("Saving Complete."), CEikGlobalTextEditor::EBold);
	}

//
// MMdaAudioInputStream callbacks (MMdaAudioInputStreamCallback)
//

// ----------------------------------------------------------------------------
// CInputEngine::MaiscOpenComplete(
//     TInt aError)
//
// called upon completion of CMdaAudioInputStream::Open(),
// if the stream was opened succesfully (aError==KErrNone), it's ready for use.
// upon succesful open, the first audio data block will be read from the input
// stream.
// ----------------------------------------------------------------------------
void CInputEngine::MaiscOpenComplete(TInt aError)
	{
	//iConsole.PrintNotify(_L("2"), CEikGlobalTextEditor::EBold);
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
		note->ExecuteLD(_L("2222"));


	if (aError==KErrNone) 
		{	
		
		// input stream opened succesfully, set status
		iInputStatus = EOpen;
		// set stream properties, 16bit 8KHz mono
		iInputStream->SetAudioPropertiesL(iStreamSettings.iSampleRate, 
			iStreamSettings.iChannels);
		
		// set stream input gain to maximum
		iInputStream->SetGain(iInputStream->MaxGain());	
		// set stream priority to normal and time sensitive
		iInputStream->SetPriority(EPriorityNormal, EMdaPriorityPreferenceTime);				
		

		//User::InfoPrint(_L("Recording"));
		
		
		CAknInformationNote* note = new (ELeave) CAknInformationNote();
		note->ExecuteLD(_L("Recording"));

		
		//iConsole.PrintNotify(_L("Recording..."), CEikGlobalTextEditor::EBold);

		// issue ReadL() to read the first audio data block, 
		// subsequent calls to ReadL() will be issued 
		// in MMdaAudioInputStreamCallback::MaiscBufferCopied()
		iStreamIdx=0;
		iInputStream->ReadL(*iStreamBuffer[iStreamIdx]);
		

		} 
	else 
		{
		// input stream open failed
		iInputStatus = ENotReady;

		//iConsole.PrintNotify(_L("Recording failed!"), CEikGlobalTextEditor::EBold);

		}

	}

// ----------------------------------------------------------------------------
// CInputEngine::MaiscBufferCopied(
//     TInt aError, const TDesC8& aBuffer)
//
// called when a block of audio data has been read and is available at the 
// buffer reference *aBuffer.  calls to ReadL() will be issued until all blocks
// in the audio data buffer (iStreamBuffer) are filled.
// ----------------------------------------------------------------------------
void CInputEngine::MaiscBufferCopied(TInt aError, const TDesC8& aBuffer)
	{
	//iConsole.PrintNotify(_L("3"), CEikGlobalTextEditor::EBold);
	//User::InfoPrint(_L("3333"));
	
	//User::After(KTimer);

	//CAknInformationNote* note = new (ELeave) CAknInformationNote();
	//note->ExecuteLD(_L("3333"));

	if (aError==KErrNone) 
		{
		//User::InfoPrint(_L("5555"));
		//CAknInformationNote* note = new (ELeave) CAknInformationNote();
		//note->ExecuteLD(_L("5555"));


		// see if end of buffer, if so, rotate buffer
		if (&aBuffer==iStreamBuffer[iStreamBuffer.Count()-1])
			iStreamIdx=0;
			//CInputEngine::Stop();
			
		else
			iStreamIdx++;			// issue ReadL() for next audio data block
		iInputStream->ReadL(*iStreamBuffer[iStreamIdx]);
		}
	else if (aError==KErrAbort) 
		{
		// recording was aborted, due to call to CMdaAudioInputStream::Stop()
		// this KErrAbort will occur each time the Stop() above is executed.
		iInputStatus = ENotReady;
		}
	else 
		{
		// error reading data from input
		iInputStatus = ENotReady;
		}
	
	}

// ----------------------------------------------------------------------------
// CInputEngine::MaiscRecordComplete(
//     TInt aError)
//
// called when input stream is closed by CMdaAudioInputStream::Stop()
// ----------------------------------------------------------------------------
void CInputEngine::MaiscRecordComplete(TInt aError)
	{
	//iConsole.PrintNotify(_L("4..."), CEikGlobalTextEditor::EBold);
	//User::InfoPrint(_L("4444"));
	
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("4444"));

	iInputStatus = ENotReady;
	if (aError==KErrNone) 
		{
		// normal stream closure
		}
	else 
		{
		// completed with error(s)
		}
	}


// MMdaAudioOutputStream callbacks (MMdaAudioOutputStreamCallback)

// ----------------------------------------------------------------------------
// CInputEngine::MaoscOpenComplete(
//     TInt aError)
//
// called upon completion of CMdaAudioOutputStream::Open(),
// if the stream was opened succesfully (aError==KErrNone), it's ready for use.
// upon succesful open, the first audio data block will be written to the 
// output stream.
// ----------------------------------------------------------------------------
void CInputEngine::MaoscOpenComplete(TInt aError)
	{
	if (aError==KErrNone) 
		{
		// output stream opened succesfully, set status
		iOutputStatus = EOpen;
		// set stream properties, 16bit 8KHz mono
		iOutputStream->SetAudioPropertiesL(iStreamSettings.iSampleRate, 
			iStreamSettings.iChannels);
		// set volume to 1/4th of stream max volume
		iOutputStream->SetVolume(iOutputStream->MaxVolume()/4);
		// set stream priority to normal and time sensitive
		iOutputStream->SetPriority(EPriorityNormal, 
			EMdaPriorityPreferenceTime);				
		
		//iConsole.PrintNotify(_L("Playing..."), CEikGlobalTextEditor::EBold);

		// issue WriteL() to write the first audio data block, 
		// subsequent calls to WriteL() will be issued in 
		// MMdaAudioOutputStreamCallback::MaoscBufferCopied() 
		// until whole data buffer is written.
		//iStreamIdx=iStreamStart;
		iStreamIdx=0;

		iOutputStream->WriteL(*iStreamBuffer[iStreamIdx]);
		}
	else 
		{
		// output stream open failed
		iOutputStatus = ENotReady;

		//iConsole.PrintNotify(_L("Playback failed!"), CEikGlobalTextEditor::EBold);

		}		
	}

// ----------------------------------------------------------------------------
// CInputEngine::MaiscBufferCopied(
//     TInt aError, const TDesC8& aBuffer)
//
// called when a block of audio data has been written to MMF. calls to WriteL() 
// will be issued until all blocks in the audio data buffer (iStreamBuffer) are 
// written.
// ----------------------------------------------------------------------------
void CInputEngine::MaoscBufferCopied(TInt aError, const TDesC8& aBuffer)
	{	
	if (aError==KErrNone) 
		{
		if (&aBuffer==iStreamBuffer[iStreamEnd])
			{
			
			//iConsole.PrintNotify(_L("Playback complete."), CEikGlobalTextEditor::EBold);

			iOutputStatus = ENotReady;
			}
		else 
			{
			iStreamIdx++;
			// rotate stream if necessary
			if (iStreamIdx==iStreamBuffer.Count()) iStreamIdx=0;
			// issue WriteL() for next audio data block
			iOutputStream->WriteL(*iStreamBuffer[iStreamIdx]);	
			}
		}
	else if (aError==KErrAbort) 
		{
		// playing was aborted, due to call to CMdaAudioOutputStream::Stop()
		}
	else 
		{
		// error writing data to output
		iOutputStatus = ENotReady;
		}
	}


// ----------------------------------------------------------------------------
// CInputEngine::MaoscPlayComplete(
//     TInt aError)
//
// called when output stream is closed by CMdaAudioOutputStream::Stop() or if 
// end of audio data has been reached, in this case KErrUnderflow will be 
// returned.
// ----------------------------------------------------------------------------
void CInputEngine::MaoscPlayComplete(TInt aError)
	{
	iOutputStatus = ENotReady;
	if (aError==KErrNone) 
		{
		// normal stream closure
		}	
	else if (aError==KErrUnderflow) 
		{
		// end of audio data stream was reached because of stream underflow,
		}
	else 
		{
		// completed with error(s)
		}	
	}



////////////////////////////////////////////////

RPointerArray<TDes8> CInputEngine::GetBufferPointer()
{
	return iStreamBuffer;
}

void CInputEngine:: GetBufferPointer(RPointerArray<TDes8> aPtr)
{
	iStreamBuffer.Reset();
	iStreamBuffer=aPtr;
}

void CInputEngine::SetFilePath(const TDesC& aFileSend)
{
	iSendFileName.Copy(aFileSend);
}

// END OF FILE