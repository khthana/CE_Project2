#include "PlayerEngine.h"
#include "MultiViewsAppUi.h"

#include <eikgted.h>
#include <eikenv.h>
#include <barsread.h>
#include <aknutils.h>
#include <MdaAudioOutputStream.h>

///////////////////////////////
#include <mmf\server\mmfcodec.h>
#include <mmf\server\mmfdatabuffer.h>
#include <mmf\plugin\mmfcodecimplementationuids.hrh>
///////////////////////////////
#include <aknquerydialog.h>
#include <aknnotewrappers.h>


const TInt KPCMBuffer = 320;
const TInt KAMRBuffer = 32;


_LIT(KToPlayFileStream,	"C:\\System\\Apps\\Sound\\record.pcm");
_LIT(KToAMRFileStream,	"C:\\System\\Apps\\Sound\\record.amr");

////////////////////////////////
// 11200 bytes will contain 700ms of 16bit audio data 
const TInt KStreamBufferSize = 11200;
const TInt KTimer = 100000;

// number of audio data buffers
const TInt KStreamBufferCount = 80;

//const TInt KToneVolumeDenominator = 2;
////////////////////////////////


CPlayerEngine::CPlayerEngine()//CMultiViewsAppUi& aAppUi)
//:iState(EStopped)//,iAppUi(aAppUi) 
	{
	iStreamSettings.iChannels=TMdaAudioDataSettings::EChannelsMono;
	iStreamSettings.iSampleRate=TMdaAudioDataSettings::ESampleRate8000Hz;
	
	}

CPlayerEngine::~CPlayerEngine()
	{
	
	iPCMBuffer.ResetAndDestroy();
	iAMRBuffer.ResetAndDestroy();

	// close and delete streams
	if (iOutputStatus!=ENotReady)
		iOutputStream->Stop();
    delete iOutputStream;
    iOutputStream=NULL;
	// empties and deletes stream buffer
	iStreamBuffer.ResetAndDestroy();
	}

CPlayerEngine* CPlayerEngine::NewL()//CMultiViewsAppUi& aAppUi)
    {
    CPlayerEngine* self = NewLC();//aAppUi);
    CleanupStack::Pop(self); 
    return self;
    }

CPlayerEngine* CPlayerEngine::NewLC()//CMultiViewsAppUi& aAppUi)
    {
    CPlayerEngine* self = new (ELeave) CPlayerEngine();//aAppUi);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

void CPlayerEngine::ConstructL()
    {
    iOutputStream = CMdaAudioOutputStream::NewL(*this);
	
	for (TInt idx=0; idx<1; idx++)
		{
		buffer = new(ELeave) TBuf8<KPCMBuffer>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iPCMBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}	
	
	for (TInt idx2=0; idx2<1; idx2++)
		{
		buffer = new(ELeave) TBuf8<KAMRBuffer>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iAMRBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}	

	for (TInt idx3=0; idx3<1; idx3++)
		{
		buffer = new(ELeave) TBuf8<KStreamBufferSize>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iStreamBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}	
	iStreamStart=0;
	iStreamEnd=iStreamBuffer.Count()-1;
	}


/**
* MMdaAudioOutputStreamCallback derivation
* This has been called as a result of NewL() being called on the stream player
* in order to play the stream, we must 1st write the stream buffer to the client
* once this has been done, the stream will begin playing automatically
*
* @param aError Error code to indicate if open succeeded
*/

void CPlayerEngine::MaoscOpenComplete(TInt aError)
	{
	if (aError==KErrNone) 
		{
		// output stream opened succesfully, set status
		iOutputStatus = EOpen;
		// set stream properties, 16bit 8KHz mono
		iOutputStream->SetAudioPropertiesL(iStreamSettings.iSampleRate, 
			iStreamSettings.iChannels);
		// set volume to 1/4th of stream max volume
		iOutputStream->SetVolume(iOutputStream->MaxVolume()/4);
		// set stream priority to normal and time sensitive
		iOutputStream->SetPriority(EPriorityNormal, 
			EMdaPriorityPreferenceTime);				
		
		iStreamIdx=0;

		iOutputStream->WriteL(*iStreamBuffer[iStreamIdx]);
		}
	else 
		{
		// output stream open failed
		iOutputStatus = ENotReady;

	
		}		
	}
/**
* This has been called in response to WriteL() being called on the stream player
* or in response to Stop() being called on the stream player. in the latter case,
* aError is equal to KErrAbort.
* Otherwise, we add iStreamBuffer to the client queue, so that it will be repeated,
* when the last buffer has finished
*
* @param aError   Error code to indicate if copy was successful
* @param aBuffer  A reference to the descriptor that has been copied to the server
*/

void CPlayerEngine::MaoscBufferCopied(TInt aError, const TDesC8& aBuffer)
	{	
	if (aError==KErrNone) 
		{
		if (&aBuffer==iStreamBuffer[iStreamEnd])
			{
			
			//iConsole.PrintNotify(_L("Playback complete."), CEikGlobalTextEditor::EBold);

			iOutputStatus = ENotReady;
			}
		else 
			{
			iStreamIdx++;
			// rotate stream if necessary
			if (iStreamIdx==iStreamBuffer.Count()) iStreamIdx=0;
			// issue WriteL() for next audio data block
			iOutputStream->WriteL(*iStreamBuffer[iStreamIdx]);	
			}
		}
	else if (aError==KErrAbort) 
		{
		// playing was aborted, due to call to CMdaAudioOutputStream::Stop()
		}
	else 
		{
		// error writing data to output
		iOutputStatus = ENotReady;
		}
	}

/**
* Callback when playback finishes
*
* @param aError Error code indicates why playback was terminated
*/

void CPlayerEngine::MaoscPlayComplete(TInt aError)
	{
	iOutputStatus = ENotReady;
	if (aError==KErrNone) 
		{
		// normal stream closure
		}	
	else if (aError==KErrUnderflow) 
		{
		// end of audio data stream was reached because of stream underflow,
		}
	else 
		{
		// completed with error(s)
		}	
	}
//PLAYER FUNCTIONS

/**
* Constructs the stream player
* This will lead to a call to MaoscOpenComplete()
*/
void CPlayerEngine::Play()
    {
	// if either stream is active, return
	if (iOutputStatus!=ENotReady) 
		return;
	// open output stream
	// upon completion will receive callback in 
	// MMdaAudioInputStreamCallback::MaoscOpenComplete()
	iOutputStream->Open(&iStreamSettings);

	//iConsole.PrintNotify(_L("Recording failed!"), CEikGlobalTextEditor::EBold);

	}

/**
* Stops whatever is playing and deletes the player
*/
void CPlayerEngine::Stop()
	{
	if (iOutputStatus!=ENotReady) 
		{
		iOutputStream->Stop();

		//iConsole.PrintNotify(_L("Playback stopped."), CEikGlobalTextEditor::EBold);

		}
	}

	/*
void CPlayerEngine::LoadPCMFileL()
	{
	
	RFs fs;	// file server instance
	CleanupClosePushL(fs);				// PUSH
	User::LeaveIfError(fs.Connect());
	
	RFile audiofile;
	CleanupClosePushL(audiofile);
	
	TFileName streamFile(KToPlayFileStream);
	User::LeaveIfError(CompleteWithAppPath(streamFile));
	User::LeaveIfError(audiofile.Open(fs, streamFile, EFileRead | EFileShareReadersOnly));

	// file opened ok, create buffer
	TInt size;
	audiofile.Size(size);
	size = size/320+1;
	iPCMBuffer.Reset();
	
	for (TInt idx=0; idx<size; idx++)
		{
		buffer = new(ELeave) TBuf8<KPCMBuffer>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iPCMBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}
	
	// create buffer ok, proceed reading
	TInt idx2=0;
	while (idx2<iPCMBuffer.Count())
		{
		TInt fstatus=audiofile.Read(*iPCMBuffer[idx2], 
			(iPCMBuffer[idx2])->MaxSize());

		if (fstatus!=KErrNone)
			break;
		idx2++;
		}
	
	//iStreamStart=0;
	//iStreamEnd=iSrcBuffer.Count()-1;
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy(2);	

	//User::InfoPrint(_L("Load PCM"));
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("Load PCM"));
	}
*/

void CPlayerEngine::LoadAMRFileL()
	{
	
	RFs fs;	// file server instance
	CleanupClosePushL(fs);				// PUSH
	User::LeaveIfError(fs.Connect());
	
	RFile audiofile;
	CleanupClosePushL(audiofile);
	
	TFileName streamFile(KToAMRFileStream);
	User::LeaveIfError(CompleteWithAppPath(streamFile));
	User::LeaveIfError(audiofile.Open(fs, streamFile, EFileRead | EFileShareReadersOnly));

	// file opened ok, create buffer
	TInt size;
	audiofile.Size(size);
	size = size/32+1;
	iAMRBuffer.Reset();
	
	for (TInt idx=0; idx<size; idx++)
		{
		buffer = new(ELeave) TBuf8<KAMRBuffer>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iAMRBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}
	
	// create buffer ok, proceed reading
	TInt idx2=0;
	while (idx2<iAMRBuffer.Count())
		{
		TInt fstatus=audiofile.Read(*iAMRBuffer[idx2], 
			(iAMRBuffer[idx2])->MaxSize());

		if (fstatus!=KErrNone)
			break;
		idx2++;
		}
	
	//iStreamStart=0;
	//iStreamEnd=iSrcBuffer.Count()-1;
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy(2);	

	//User::InfoPrint(_L("Load AMR"));
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("Load AMR"));
	}

void CPlayerEngine::SavePCMFileL()
	{
	
	RFs fs;	// file server instance
	RFile audiofile;

	TInt writeidx=0;
	// open fileserver session and file
	User::LeaveIfError(fs.Connect());	
	// push into cleanup stack
	CleanupClosePushL(fs);

	// check for free space for saving the sample
	TVolumeInfo volinfo;
	TInt err=fs.Volume(volinfo,EDriveC);
	
	if ( volinfo.iFree<(iAMRBuffer.Count()*KPCMBuffer) )
		{
		// not enough free space on drive for saving, report and exit
		CleanupStack::PopAndDestroy();
		return;
		}

	err = audiofile.Replace(fs, KToPlayFileStream, EFileWrite|EFileStream);

	//err = audiofile.Open(fs, KToPlayFileStream, EFileWrite|EFileStream);

	if (err==KErrNone) 
		{
	
		// Uid of AMRtoPCM16 codec is 0x101FAF67
		CMMFCodec* codec = CMMFCodec::NewL(TUid::Uid(0x101FAF67));
		
		CleanupStack::PushL(codec);
		
		CMMFDescriptorBuffer* srcbuf = CMMFDescriptorBuffer::NewL(32);
		CleanupStack::PushL(srcbuf);
	
		// Copy your PCM frame data into srcbuf, for example: srcbuf->Data().Copy(pcmbuf);
		CMMFDescriptorBuffer* dstbuf = CMMFDescriptorBuffer::NewL(1280);
		CleanupStack::PushL(dstbuf);
		
		// file opened ok, proceed writing
		// read audio data directly into iStreamBuffer
		for (TInt idx=0; idx<iAMRBuffer.Count(); idx++)	
			{
			
			srcbuf->Data().Copy(*iAMRBuffer[idx]);

			TCodecProcessResult result = codec->ProcessL(*srcbuf, *dstbuf);
			
			audiofile.Write(dstbuf->Data());
			
			writeidx++;
			// write buffers in correct order, rotate if necessary
			if (writeidx==iAMRBuffer.Count()) writeidx=0;
			}
			
		// now the dstbuf contains an AMR frame data
		CleanupStack::PopAndDestroy(dstbuf);
		CleanupStack::PopAndDestroy(srcbuf);
		CleanupStack::PopAndDestroy(codec);
		
		User::InfoPrint(KToPlayFileStream);
		
	
		}	
	else 
		{
		User::InfoPrint(_L("Error"));
		// failed to open file
		}
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy();

	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("Save PCM"));
	}
/*

void CPlayerEngine::SaveAMRFileL()
	{
	
	RFs fs;	// file server instance
	RFile audiofile;

	TInt writeidx=0;
	// open fileserver session and file
	User::LeaveIfError(fs.Connect());	
	// push into cleanup stack
	CleanupClosePushL(fs);

	// check for free space for saving the sample
	TVolumeInfo volinfo;
	TInt err=fs.Volume(volinfo,EDriveC);
	if ( volinfo.iFree<(iPCMBuffer.Count()*KAMRBuffer) )
		{
		// not enough free space on drive for saving, report and exit
		CleanupStack::PopAndDestroy();
		return;
		}

	
	err = audiofile.Open(fs, KToAMRFileStream, EFileWrite|EFileStream);

	if (err==KErrNone) 
		{
	
		// Uid of PCM16toAMR codec is 0x101FAF68
		CMMFCodec* codec = CMMFCodec::NewL(TUid::Uid(0x101FAF68));
		CleanupStack::PushL(codec);
		
		
		CMMFDescriptorBuffer* srcbuf = CMMFDescriptorBuffer::NewL(320);
		CleanupStack::PushL(srcbuf);
	
		// Copy your PCM frame data into srcbuf, for example: srcbuf->Data().Copy(pcmbuf);
		CMMFDescriptorBuffer* dstbuf = CMMFDescriptorBuffer::NewL(32);
		CleanupStack::PushL(dstbuf);

		// file opened ok, proceed writing
		// read audio data directly into iStreamBuffer
		for (TInt idx=0; idx<iPCMBuffer.Count(); idx++)	
			{
			
			srcbuf->Data().Copy(*iPCMBuffer[idx]);

			TCodecProcessResult result = codec->ProcessL(*srcbuf, *dstbuf);
			
			audiofile.Write(dstbuf->Data());
			
			writeidx++;
			// write buffers in correct order, rotate if necessary
			if (writeidx==iPCMBuffer.Count()) writeidx=0;
			}
			
		// now the dstbuf contains an AMR frame data
		CleanupStack::PopAndDestroy(dstbuf);
		CleanupStack::PopAndDestroy(srcbuf);
		CleanupStack::PopAndDestroy(codec);
		
		User::InfoPrint(KToAMRFileStream);
		
	
		}	
	else 
		{
		User::InfoPrint(_L("Error"));
		// failed to open file
		}
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy();

	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(_L("Save AMR"));
	}
*/

void CPlayerEngine::LoadAudioFileL()
	{
	
	RFs fs;	// file server instance
	CleanupClosePushL(fs);				// PUSH
	User::LeaveIfError(fs.Connect());
	
	RFile audiofile;
	CleanupClosePushL(audiofile);
	
	TFileName streamFile(KToPlayFileStream);
	User::LeaveIfError(CompleteWithAppPath(streamFile));
	User::LeaveIfError(audiofile.Open(fs, streamFile, EFileRead | EFileShareReadersOnly));

	// file opened ok, create buffer
	TInt size;
	audiofile.Size(size);
	size = size/1024+1;
	iStreamBuffer.Reset();
	
	for (TInt idx=0; idx<size; idx++)
		{
		buffer = new(ELeave) TBuf8<KStreamBufferSize>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iStreamBuffer.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}
	
	// create buffer ok, proceed reading
	TInt idx2=0;
	while (idx2<iStreamBuffer.Count())
		{
		TInt fstatus=audiofile.Read(*iStreamBuffer[idx2], 
			(iStreamBuffer[idx2])->MaxSize());

		if (fstatus!=KErrNone)
			break;
		idx2++;
		}
	
	iStreamStart=0;
	iStreamEnd=iStreamBuffer.Count()-1;
	audiofile.Close();
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy(2);
	

	}


