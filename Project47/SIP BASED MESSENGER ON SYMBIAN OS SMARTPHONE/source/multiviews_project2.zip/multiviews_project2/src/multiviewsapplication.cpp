/* Copyright (c) 2003, Nokia. All rights reserved */

#include "MultiViewsDocument.h"
#include "MultiViewsApplication.h"

CApaDocument* CMultiViewsApplication::CreateDocumentL()
    {  
    // Create an MultiViews document, and return a pointer to it 
	return (static_cast<CApaDocument*>(CMultiViewsDocument::NewL(*this)));
    }

TUid CMultiViewsApplication::AppDllUid() const
    {
    // Return the UID for the MultiViews application
    return KUidMultiViewsApp;
    }

