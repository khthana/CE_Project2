/* Copyright (c) 2003, Nokia. All rights reserved */

#include "MultiViewsContainer2.h"

#include "MultiViewsView2.h"

#include "MultiViews.hrh"


//constant
const TInt KNumberOfLines = 0;
const TInt KTextInLimit = 128;
const TInt KTextOutLimit = NULL;

const TInt KUpperEditHeight = 102;
const TInt KLowerEditHeight = 36;



#define KUpperEditPosition	TPoint(2, 2)
#define KLowerEditPosition	TPoint(2, 106)

// ================= MEMBER FUNCTIONS =======================

// ----------------------------------------------------------------------------
// CMultiViewsContainer2::NewL()
//
// Creates instance of CMultiViewsContainer2.
// ----------------------------------------------------------------------------
CMultiViewsContainer2* CMultiViewsContainer2::NewL(const TRect& aRect,CRichText* aRichText, CMultiViewsView2* iView/*,TDes& aName*/)
	{
    CMultiViewsContainer2* self = CMultiViewsContainer2::NewLC(aRect,aRichText,iView/*,aName*/);
    CleanupStack::Pop(self);
    return self;
	}

// ----------------------------------------------------------------------------
// CMultiViewsContainer2::NewLC()
//
// Creates instance of CMultiViewsContainer2.
// ----------------------------------------------------------------------------
CMultiViewsContainer2* CMultiViewsContainer2::NewLC(const TRect& aRect,CRichText* aRichText, CMultiViewsView2* iView/*,TDes& aName*/)
	{
    CMultiViewsContainer2* self = new (ELeave) CMultiViewsContainer2;
    CleanupStack::PushL(self);
    self->ConstructL(aRect,aRichText,iView/*,aName*/);
    return self;
	}

// Constructor
CMultiViewsContainer2::CMultiViewsContainer2()
    {
    }

// Destructor
CMultiViewsContainer2::~CMultiViewsContainer2()
    {
		delete iOutputWindow;
		iOutputWindow = NULL;
		delete iInputWindow;
		iInputWindow = NULL;
    }

// ---------------------------------------------------------
// CMultiViewsContainer2::ConstructL(const TRect& aRect)
// EPOC two phased constructor
// ---------------------------------------------------------
//
void CMultiViewsContainer2::ConstructL(const TRect& aRect,CRichText* aRichText, CMultiViewsView2* iView/*,TDes& aName*/)
    {
    CreateWindowL();
	/*iName.Copy(aName);*/
	// Create output window
	iOutputWindow = new (ELeave) CEikRichTextEditor();
	iOutputWindow->SetContainerWindowL(*this);
	iOutputWindow->ConstructL(this, KNumberOfLines, KTextOutLimit, 
		EEikEdwinReadOnly, EGulFontControlAll, EGulNoSymbolFonts);
	iOutputWindow->SetExtent(KUpperEditPosition, 
		TSize(aRect.Width() - 4, KUpperEditHeight));

	// Create input window
	iInputWindow = new (ELeave) CEikRichTextEditor();
	iInputWindow->SetContainerWindowL(*this);
	iInputWindow->ConstructL(this, KNumberOfLines, KTextInLimit, 
		NULL, EGulFontControlAll, EGulNoSymbolFonts);
	iInputWindow->SetExtent(KLowerEditPosition, 
		TSize(aRect.Width() - 4, KLowerEditHeight));

    iInputWindow->SetFocus(ETrue);

    SetRect(aRect);

	//picture
	iBitmapOnline = new (ELeave) CFbsBitmap();
	//get mbm format
	TFileName bitmapFile (KMainPanePath);
	User::LeaveIfError (CompleteWithAppPath (bitmapFile));
	User::LeaveIfError(iBitmapOnline->Load(bitmapFile, EMbmMultiviewsOnline));

	//iRichText = aRichText;
	iOutputWindow->RichText()->AppendTakingSolePictureOwnershipL(*aRichText);

	iView2 = iView;
	IsDown = 0;

    ActivateL();
	


    }



// ---------------------------------------------------------
// CMultiViewsContainer2::SizeChanged()
// Called by framework when the view size is changed
// ---------------------------------------------------------
//
void CMultiViewsContainer2::SizeChanged()
    {
    }

// ---------------------------------------------------------
// CMultiViewsContainer2::CountComponentControls() const
// ---------------------------------------------------------
//
TInt CMultiViewsContainer2::CountComponentControls() const
    {
    return 2; // return nbr of controls inside this container
    }

// ---------------------------------------------------------
// CMultiViewsContainer2::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* CMultiViewsContainer2::ComponentControl(TInt aIndex) const
    {
    switch ( aIndex )
        {
        case 0:
            return iOutputWindow;
        case 1:
            return iInputWindow;
        default:
            return NULL;
        }
    }

// ---------------------------------------------------------
// CMultiViewsContainer2::Draw(const TRect& aRect) const
// ---------------------------------------------------------
//
void CMultiViewsContainer2::Draw(const TRect& aRect) const
    {
    CWindowGc& gc = SystemGc();
    // TODO: Add your drawing code here
    // example code...
    gc.SetPenStyle( CGraphicsContext::ENullPen );
    gc.SetBrushColor( TRgb(128,128,128) );
    gc.SetBrushStyle( CGraphicsContext::ESolidBrush );
    gc.DrawRect( aRect );
    }

// ---------------------------------------------------------
// CMultiViewsContainer2::HandleControlEventL(
//     CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void CMultiViewsContainer2::HandleControlEventL(
    CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
    {
    // TODO: Add your control event handler code here
    }

// ----------------------------------------------------------------------------
// CMultiViewsContainer2::OfferKeyEventL()
//
// Handles key events.
// ----------------------------------------------------------------------------
TKeyResponse CMultiViewsContainer2::OfferKeyEventL(const TKeyEvent& aKeyEvent, 
												TEventCode aType)
	{

	// Catch EStdKeyNkp5 and EStdKeyDevice3; they are used here to switch
	// the active CEikRichTextEditor.
	if (aKeyEvent.iScanCode == EStdKeyDevice3) 
	{
		if (aType == EEventKeyDown)
		{
			iView2->HandleCommandL(EMultiViewsStartVoice);
			IsDown = 1;
			return EKeyWasConsumed;
		}
		else if ((aType == EEventKeyUp) && (IsDown == 1))
		{
			iView2->HandleCommandL(EMultiViewsStopVoice);
			IsDown = 0;
			return EKeyWasConsumed;
		}
			/*if (iOutputWindow->IsFocused()) 
				{
					iOutputWindow->SetFocus(EFalse);
					iInputWindow->SetFocus(ETrue);
				} else {
					iInputWindow->SetFocus(EFalse);
					iOutputWindow->SetFocus(ETrue);
				}*/
	}
	else if(aType == EEventKey) 
	{
		switch(aKeyEvent.iCode)
		{
		case EKeyUpArrow:
			if (iOutputWindow->IsFocused())
				iOutputWindow->MoveCursorL(TCursorPosition::EFLineUp, EFalse);
			else 
			{
				TInt temp = iInputWindow->CursorPos();
				iInputWindow->MoveCursorL(TCursorPosition::EFLineUp, EFalse);
				if (temp == iInputWindow->CursorPos())
					iOutputWindow->MoveCursorL(TCursorPosition::EFPageUp, EFalse);
			}
			return EKeyWasConsumed;
		case EKeyDownArrow:
			if (iOutputWindow->IsFocused())
				iOutputWindow->MoveCursorL(TCursorPosition::EFLineDown, EFalse);
			else 
			{
				TInt temp = iInputWindow->CursorPos();
				iInputWindow->MoveCursorL(TCursorPosition::EFLineDown, EFalse);
				if (temp == iInputWindow->CursorPos())
					iOutputWindow->MoveCursorL(TCursorPosition::EFPageDown, EFalse);
			}
			return EKeyWasConsumed;
		}	
	}

	// Redirect keyevents to controls
    if (iOutputWindow) 
		{
	    if (iOutputWindow->IsFocused())
			return iOutputWindow->OfferKeyEventL(aKeyEvent, aType);
		}

    if (iInputWindow)
		{
	    if (iInputWindow->IsFocused())
			return iInputWindow->OfferKeyEventL(aKeyEvent, aType);
		}

    return EKeyWasNotConsumed;
	}

void CMultiViewsContainer2::GetText(TDes16& atext){
	//return text
	iInputWindow->GetText(atext);
	
	//t.Copy(atext);
	//iOutputWindow->SetTextL(&t);
	//iOutputWindow->HandleTextChangedL();
	//iOutputWindow->MoveCursorL(TCursorPosition::EFLineDown, EFalse);
	
}


void CMultiViewsContainer2::AppendText(TDes16& atext,TDes16& aName){

	CRichText* text = iOutputWindow->RichText();
	SetColor(KRgbBlue);
	TInt length = text->DocumentLength();
	//text->InsertL(text->DocumentLength(),_L("<ME>"));
	text->InsertL(text->DocumentLength(),'<');
	text->InsertL(text->DocumentLength(),aName);
	text->InsertL(text->DocumentLength(),'>');

	if(atext == _L16("@)")){
	ToInsertMyPictureL(EMbmMultiviewsOnline);
	}else{	
	
	text->InsertL(text->DocumentLength(), atext);
	text->InsertL(text->DocumentLength(), CEditableText::ELineBreak);
	//text->ApplyCharFormatL(iCharFormat, iCharFormatMask, length, atext.Length()+5);
	text->ApplyCharFormatL(iCharFormat, iCharFormatMask, length, aName.Length() + atext.Length()+3);
	iOutputWindow->HandleTextChangedL();
	iOutputWindow->SetCursorPosL(iOutputWindow->TextLength(), EFalse);
	//iOutputWindow->MoveCursorL(TCursorPosition::EFLineDown, EFalse);
	}
	//clear
	ClearInputWindow();
	//iInputWindow->SetTextL(NULL);
	
}

void CMultiViewsContainer2::AppendTextReceive(TDes16& atext,TDes16& aName){

	//iInputWindow->SetTextL(&_L16(""));
	//iInputWindow->SetTextL(&t);

	CRichText* text = iOutputWindow->RichText();
	SetColor(KRgbRed);
	TInt length = text->DocumentLength();
	//text->InsertL(text->DocumentLength(),_L("<YOU>"));
	text->InsertL(text->DocumentLength(),'<');
	text->InsertL(text->DocumentLength(),aName);
	text->InsertL(text->DocumentLength(),'>');

	if(atext == _L16("@)")){
	ToInsertMyPictureL(EMbmMultiviewsOnline);
	}else{	
	
	text->InsertL(text->DocumentLength(), atext);
	text->InsertL(text->DocumentLength(), CEditableText::ELineBreak);
	//text->ApplyCharFormatL(iCharFormat, iCharFormatMask, length, atext.Length()+6);
	text->ApplyCharFormatL(iCharFormat, iCharFormatMask, length, aName.Length() + atext.Length()+3);
	iOutputWindow->HandleTextChangedL();
	iOutputWindow->SetCursorPosL(iOutputWindow->TextLength(), EFalse);
	//iOutputWindow->MoveCursorL(TCursorPosition::EFLineDown, EFalse);
	}
	//clear
	ClearInputWindow();
	//iInputWindow->SetTextL(NULL);
	
}

void CMultiViewsContainer2::SetColor(const TRgb& rgb){
	iCharFormatMask.SetAttrib(EAttColor);
	iCharFormat.iFontPresentation.iTextColor = rgb;
}

void CMultiViewsContainer2::ClearInputWindow(){
	iInputWindow->Text()->Reset();
	iInputWindow->HandleTextChangedL();
	iInputWindow->SetCursorPosL(0,EFalse);
}


#define KLeftImagePositionInTheText		0//28


void CMultiViewsContainer2::ClearOutputWindow(){
//test Emotion	
	/*
	InsertMyPictureL(KLeftImagePositionInTheText,EMbmMultiviewsOnline);
	iOutputWindow->HandleTextChangedL();
	*/
//test Append History
	/*
	CRichText* text = iOutputWindow->RichText();
	iInputWindow->RichText()->AppendTakingSolePictureOwnershipL(*text);
	*/

	iOutputWindow->Text()->Reset();
	iOutputWindow->HandleTextChangedL();
	iOutputWindow->SetCursorPosL(0,EFalse);
}

void CMultiViewsContainer2::InsertMyPictureL(TInt aPos,TInt32 aId)
	{
	//PrepareBitmapL(aId);
	
	CMyPicture* picture;
	// Create a CPicture derived class which will draw our image, depending this Size
	//picture = new( ELeave )CMyPicture(TSize(KKImageWidth,KImageHeight),*(iBitmap->At(iBitmap->Count()-1)/*process the last item of iBitmap*/));
	
	//if (aId == EMultiViewsMbmSmile
	TSize iconSize(290, 290);
	//picture = new( ELeave )CMyPicture(TSize(KKImageWidth,KImageHeight),*iBitmapOnline);	
	picture = new( ELeave )CMyPicture(iconSize,*iBitmapOnline);	
	
	CleanupStack::PushL(picture);
	// Prepare the Picture header, which will be instered into the Richtext
	TPictureHeader header;
	header.iPicture =TSwizzle<CPicture>(picture);
	iOutputWindow->RichText()->InsertL( aPos,header);
	iOutputWindow->HandleTextChangedL();
	iOutputWindow->SetCursorPosL(iOutputWindow->TextLength(), EFalse);

	CleanupStack::Pop(); // picture - Richtext take the ownership 
	}

void CMultiViewsContainer2::ToInsertMyPictureL(TInt32 aId){
	
	//iOutputWindow->RichText()->InsertL(iOutputWindow->TextLength(),_L("<ME>"));
	InsertMyPictureL(iOutputWindow->TextLength(),aId);
	iOutputWindow->RichText()->InsertL(iOutputWindow->TextLength(), CEditableText::ELineBreak);
	iOutputWindow->HandleTextChangedL();
	iOutputWindow->SetCursorPosL(iOutputWindow->TextLength(), EFalse);

}