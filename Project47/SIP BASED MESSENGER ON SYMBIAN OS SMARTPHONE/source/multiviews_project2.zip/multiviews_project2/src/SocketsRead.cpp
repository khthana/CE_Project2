/*
* ==============================================================================
*  Name        : SocketsRead.cpp
*  Part of     : CommunicationChannel
*  Description : Implementation of SocketsRead class
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/
#include <aknquerydialog.h>
#include <aknnotewrappers.h>

#include "SocketsRead.h"
#include <GameLogger.h>
#include <SocketObserver.h>

const TInt KBufferSize = 4096;
const TInt KBufferCount = 80;
const TInt KFileSize = 28521;
_LIT(KBlank,"");
//_LIT(KAudioFile4,"C:\\System\\Apps\\Sound\\copy.jpg");
_LIT(KFilePath,"C:\\System\\apps\\sound\\");

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::NewL
***
***  DESCRIPTION	N/A
***
***  INPUT			RSocket& aSocket
***					MSocketObserver& aObserver
***
***  RETURN			CSocketsRead*
***
***************************************************************************************
**************************************************************************************/
CSocketsRead* CSocketsRead::NewL(RSocket& aSocket, MSocketObserver& aObserver, TInt aReadBufferSize)
{
	CSocketsRead* self = CSocketsRead::NewLC(aSocket,aObserver, aReadBufferSize);
	CleanupStack::Pop();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::NewLC
***
***  DESCRIPTION	N/A
***
***  INPUT			RSocket& aSocket
***					MSocketObserver& aObserver
***
***  RETURN			CSocketsRead*
***
***************************************************************************************
**************************************************************************************/
CSocketsRead* CSocketsRead::NewLC(RSocket& aSocket,MSocketObserver& aObserver, TInt aReadBufferSize)
{
	CSocketsRead* self = new (ELeave) CSocketsRead(aSocket,aObserver);
	CleanupStack::PushL(self);
	self->ConstructL(aReadBufferSize);
	return self;
}


/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::CSocketsRead
***
***  DESCRIPTION	N/A
***
***  INPUT			RSocket& aSocket
***					MSocketObserver& aObserver
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CSocketsRead::CSocketsRead(RSocket& aSocket,MSocketObserver& aObserver)
: CActive(EPriorityStandard),
  iSocket(aSocket),
  iObserver(aObserver),
  iPtr(TPtr8::TPtr8(0,0)),
  iIdBuf(0)

{
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::~CSocketsRead
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CSocketsRead::~CSocketsRead()
{
	//LOG_METHOD(_L("CSocketsRead::~CSocketsRead"));
	Cancel();
	
	if(iBuffer)
	{
//		WRITE_LOG_FORMAT(_L("iBuffer on %d"),iBuffer);
		delete iBuffer;
	}

  }

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::ConstructL
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsRead::ConstructL(TInt aReadBufferSize)
{
//	LOG_METHOD(_L("CSocketsRead::ConstructL()"));

	iBuffer = HBufC8::NewL(aReadBufferSize);
//	WRITE_LOG_FORMAT(_L("iBuffer on %d"),iBuffer);
	iPtr.Set(iBuffer->Des());
	CActiveScheduler::Add(this);

	// Stream buffer allocation
	/*TDes8* buffer;
	for (TInt idx=0; idx<KBufferCount; idx++)
		{
		buffer = new(ELeave) TBuf8<KBufferSize>;
		CleanupStack::PushL(buffer);		
		buffer->SetMax();
		User::LeaveIfError(iStreamBuf.Append(buffer));		
		CleanupStack::Pop(buffer);		
		}*/

	/*RFs fs;
	RFile outputfile;

	User::LeaveIfError(fs.Connect());	
	// push into cleanup stack
	CleanupClosePushL(fs);

	// check for free space for saving the sample
	TVolumeInfo volinfo;
	fs.Volume(volinfo,EDriveC);
	if ( volinfo.iFree<iRecieveFileSize )
		{
		// not enough free space on drive for saving, report and exit
		CleanupStack::PopAndDestroy();
		return;
		}

	//path.Copy(KAudioFile4);
	//path.Append(iRecieveFileName);

	if (iRecieveFileName != KBlank) {
		outputfile.Replace(fs, KAudioFile4, EFileWrite|EFileStream);
		outputfile.Close();
	}

	CleanupStack::PopAndDestroy();*/

	sender = -1;
	size = 0;
	iCountRecieved = 0;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::DoCancel
***
***  DESCRIPTION	This function is called as part of the active object�s Cancel()
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsRead::DoCancel()
{
//	iSocket.CancelRecv();
//	iSocket.Close();
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::RunL
***
***  DESCRIPTION	Handles an active object�s request completion event
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsRead::RunL()
{
//	WRITE_LOG(_L("CSocketsRead::RunL"));
	//WRITE_LOG_FORMAT(_L("iStatus on %d"),iStatus.Int());
	if (iStatus == KErrNone)
	{
		IssueRead();
		if ((size%4096 == 0) || (size == iRecieveFileSize))
		{
			iCountRecieved++;
			if (size == iRecieveFileSize)
				iCountRecieved = 0;
			iObserver.PackedReceived(*iBuffer);
		}
	}
	else
	{
		iObserver.SocketTimeout();
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::IssueRead
***
***  DESCRIPTION	Reads from socket
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsRead::IssueRead()
{
	//LOG_METHOD(_L("CSocketsRead::IssueRead"));

	ASSERT(!IsActive());

	if (sender == -1)
	{
		iSocket.RecvOneOrMore(outbuf, 0, iStatus, iDummyLength);
		sender = 0;
	}
	else if (sender == 0)
	{
		RFs fs;
		RFile outputfile;
		
		User::LeaveIfError(fs.Connect());	
		// push into cleanup stack
		CleanupClosePushL(fs);

		if (size == 0)
		{
			// check for free space for saving the sample
			TVolumeInfo volinfo;
			fs.Volume(volinfo,EDriveC);
			if ( volinfo.iFree<iRecieveFileSize )
			{
				// not enough free space on drive for saving, report and exit
				CleanupStack::PopAndDestroy();
				return;
			}

			path.Copy(KFilePath);
			path.Append(iRecieveFileName);

			/*TInt err;

			do
			{
				err = outputfile.Open(fs, path, EFileWrite|EFileStream);
				if (err == KErrNone)
				{
					path.Insert(path.Locate('.'), _L("(2)"));
					outputfile.Close();
				}
			}while(err == KErrNone);

			outputfile.Create(fs, path, EFileWrite|EFileStream);
			outputfile.Close();
*/
			outputfile.Replace(fs, path, EFileWrite|EFileStream);
			outputfile.Close();
		}

		outputfile.Open(fs, path, EFileWrite|EFileStream);

		TInt aPos;
		outputfile.Seek(ESeekEnd, aPos);
	
		iSocket.RecvOneOrMore(outbuf, 0, iStatus, iDummyLength);
		outputfile.Write(outbuf);

		//TInt complete=0;
		outputfile.Size(size);

		/*if (size == iRecieveFileSize)
		{
			_LIT(KMessage2, "Complete");
			CAknInformationNote* note2 = new (ELeave) CAknInformationNote();
			note2->ExecuteLD(KMessage2);
			complete=1;
		}*/
		outputfile.Close();

		CleanupStack::PopAndDestroy();
	}
	else
		iSocket.RecvOneOrMore(outbuf, 0, iStatus, iDummyLength);

////////// Note Test /////////////
	//HBufC* test;
	//test.Copy(iPtr);
	//TBuf16<20> buf;
	//buf.Copy(iPtr);
	//User::InfoPrint(buf);
	
	//CAknInformationNote* note = new (ELeave) CAknInformationNote();
	//note->ExecuteLD(buf);

////////// Note Test /////////////
	SetActive();
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsRead::Start
***
***  DESCRIPTION	Starts reader
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsRead::Start()
{
//	LOG_METHOD(_L("CSocketsRead::Start"));
	if (!IsActive())
	{
		IssueRead();
	}
}

RPointerArray<TDes8> CSocketsRead::GettingBufferPtr()
{
	return iStreamBuf;
}

void CSocketsRead::Clear()
{
  
	/*RFs fs;
	RFile outputfile;

	User::LeaveIfError(fs.Connect());	
	// push into cleanup stack
	CleanupClosePushL(fs);

	// check for free space for saving the sample
	TVolumeInfo volinfo;
	fs.Volume(volinfo,EDriveC);
	if ( volinfo.iFree<iRecieveFileSize )
		{
		// not enough free space on drive for saving, report and exit
		CleanupStack::PopAndDestroy();
		return;
		}

	outputfile.Replace(fs, KAudioFile4, EFileWrite|EFileStream);
	outputfile.Close();
	CleanupStack::PopAndDestroy();
	*/
}
