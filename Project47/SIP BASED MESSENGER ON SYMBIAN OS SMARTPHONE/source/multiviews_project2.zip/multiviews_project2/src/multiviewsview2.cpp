/* Copyright (c) 2003, Nokia. All rights reserved */

#include <aknviewappui.h>
#include <aknconsts.h>
#include <aknnotewrappers.h>
#include <MultiViews.rsg>

#include "MultiViewsView2.h"
#include "MultiViewsContainer2.h"
#include "MultiViews.hrh"

CMultiViewsView2* CMultiViewsView2::NewL()
    {
    CMultiViewsView2* self = CMultiViewsView2::NewLC();
    CleanupStack::Pop(self);
    return self;
    }

CMultiViewsView2* CMultiViewsView2::NewLC()
    {
    CMultiViewsView2* self = new (ELeave) CMultiViewsView2();
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

CMultiViewsView2::CMultiViewsView2()
    {
    // No implementation required
    }

CMultiViewsView2::~CMultiViewsView2()
    {
		if( iRichText ){
			delete iRichText;
		}
    }

void CMultiViewsView2::ConstructL()
    {
    BaseConstructL(R_MULTIVIEWS_VIEW2);


	//iContainer = CMultiViewsContainer2::NewL(ClientRect());
	//AppUi()->AddToStackL( iContainer );


    }


TUid CMultiViewsView2::Id() const
    {
    return TUid::Uid(EMultiViewsView2Id);
    }

void CMultiViewsView2::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
                                    TUid /*aCustomMessageId*/,
                                    const TDesC8& /*aContactName*/)
    {
    
	/*ASSERT(!(iContainer));
    iContainer = CMultiViewsContainer2::NewL(ClientRect());
	iContainer->SetMopParent(this);	 
    */
	//iContainer->ConstructL(ClientRect());
	if (!iContainer){

		//iContactName.Copy(aContactName);

		iContainer = CMultiViewsContainer2::NewL(ClientRect(),iRichText, this/*,iRealContactName*/);
        iContainer->SetMopParent(this);
		AppUi()->AddToStackL( /**this,*/ iContainer );
			
	}

	iDisplayBool = ETrue;

    }

void CMultiViewsView2::SetContactName(const TDes16& aContactName){
	
	iContactName.Copy(aContactName);

}

void CMultiViewsView2::SetRealContactName(const TDes16& aContactName){
	
	iRealContactName.Copy(aContactName);

}

void CMultiViewsView2::GetContactName(TDes16& aContactName){
	
	aContactName.Copy(iContactName);

}
void CMultiViewsView2::DoDeactivate()
    {

    if ( iContainer ){
	        AppUi()->RemoveFromViewStack( *this, iContainer );
    }
    
    delete iContainer;
    iContainer = NULL;
	iDisplayBool = EFalse;

    }

void CMultiViewsView2::HandleCommandL(TInt aCommand)
    {   
    /*if (aCommand == EMoIcon1)
		
		iContainer->ToInsertMyPictureL(EMbmMultiviewsOnline);		

	else if (aCommand == EMultiViewsClearInput)
		iContainer->ClearInputWindow();
	else if (aCommand == EMultiViewsClearOutput)
		iContainer->ClearOutputWindow();
    else 
        {*/
        AppUi()->HandleCommandL(aCommand);


        //}
    }

TBool CMultiViewsView2::IsDisplay()
    {
	    return iDisplayBool;

    }

void CMultiViewsView2::ToGetText(TDes16& aText){

	iContainer->GetText(aText);

}
	
void CMultiViewsView2::ToAppendText(TDes16& aText,TDes16& aName){

	iContainer->AppendText(aText,aName);

}

void CMultiViewsView2::ToAppendTextReceive(TDes16& aText){

	iContainer->AppendTextReceive(aText,iRealContactName);

}

void CMultiViewsView2::ToAppendRichText(CRichText* aRichText){
	//iContainer->AppendRichTextReceive(aRichText);
	iRichText = aRichText;

}

/*CMultiViewsContainer2* CMultiViewsView2::AppContain(){

	return iContainer;
}*/

void CMultiViewsView2::ToInsertMyPictureL(TInt32 aId){
	iContainer->ToInsertMyPictureL(aId);
}


void CMultiViewsView2::ClearInputWindow(){
	iContainer->ClearInputWindow();	
}

void CMultiViewsView2::ClearOutputWindow(){
	iContainer->ClearOutputWindow();
}

