#include <SIPProfileRegistryObserver.h>
#include <SIPObserver.h> 
#include <SIPConnectionObserver.h> 
#include <SIP.h> 
#include <SipProfileRegistry.h> 
#include <SipProfileRegistry.h>
#include <SIPProfile.h> 
#include <SIPConnection.h> 
#include <SIPInviteDialogAssoc.h> 
#include <SIPFromHeader.h> 
#include <SIPToHeader.h> 
#include <SIPContactHeader.h> 
#include <SIPAddress.h> 
#include <SIPClientTransaction.h> 
#include <sipservertransaction.h> 
#include <sipdialog.h> 
#include <SIPResponseElements.h> 
#include <SIPRequestElements.h> 
#include <sipmessageelements.h> 
#include <sipcseqheader.h> 
#include <sipcontenttypeheader.h>  
#include <sipuri.h> 
#include "CSIPEngine.h"

#include <eikgted.h>
#include <es_enum.h>

#include <aknnotewrappers.h> 



_LIT8(KStatus1, "Status = Online");
_LIT8(KStatus2, "Status = Busy");
_LIT8(KStatus3, "Status = Away");
_LIT8(KStatus4, "Status = Offline");

CSIPEngine* CSIPEngine::NewL(TUid aUid,CMultiViewsAppUi *aAppUi)  { 
	CSIPEngine* self = new( ELeave ) CSIPEngine( aUid , aAppUi ); 
	CleanupStack::PushL( self ); self->ConstructL(); 
	CleanupStack::Pop(); 
	return self; 
} 

CSIPEngine::~CSIPEngine() { 
	/*delete iSIP; 
	delete iProfileRegistry ;
	delete iProfile; 
	delete iConnection; 
	delete iSIPClientTransaction; 
	delete iSIPInviteDialogAssoc;
	delete iSIPSubscribeDialogAssoc;*/
	SdpCodecStringPool::Close();
	if (iSIPClientTransaction != NULL)
		delete iSIPClientTransaction;
	if (iSIPInviteDialogAssoc != NULL)
		delete iSIPInviteDialogAssoc ;
	if (iSIPSubscribeDialogAssoc != NULL)
		delete iSIPSubscribeDialogAssoc ;
	delete iConnection;
	delete iProfile;
	delete iProfileRegistry ;
	delete iGameSaverAO;
	delete iSIP; 
	delete iInputEngine;
	
	////
	delete iPlayerEngine;

}

CSIPEngine::CSIPEngine(TUid& aUid,CMultiViewsAppUi *aAppUi) { 
	iUid = aUid;
	iAppUi = aAppUi;

}

void CSIPEngine::ConstructL(){
	/*iMyStatus = EOffline;*/
	// Initialize SIP Stack 
	iSIP = CSIP::NewL(iUid, *this); 
	
	// Initialize ProfileRegistry 
	iProfileRegistry = CSIPProfileRegistry::NewL(*iSIP, *this); 
	
	// Get the default profile. 
	iProfile = iProfileRegistry->DefaultProfileL(); 
	

	iOwnIP = _L("d.d.d.d");
	SdpCodecStringPool::OpenL();

	iInputEngine = CInputEngine::NewL ();

	//////////////////
	iPlayerEngine = CPlayerEngine::NewL ();

	
	iGameSaverAO = CProgressNoteGameSaverAO::NewL();

	iIsRecieve = 0;
}

void CSIPEngine::ExecuteL() { 
	// The client asks the API to enable the retrieved profile for its use. 
	// For that, the client must inherit and implement MSIPConnectionObserver. 
	TInt status = iProfileRegistry->EnableL(*iProfile, *this); 
	
	// The returned status indicates if the profile can be immediately used 
	// for creating a session, or if the client must wait for the profile to 
	// be registered. 
	
	if (status == KErrNone) { 
		// get the SIP connection used by the profile 
		iConnection = iProfileRegistry->ConnectionL(*iProfile); 
	} else 
		// KErrPending 
	{ 
		// wait for the profile to be registered before using it further 


		//User::InfoPrint(_L("can't register"));

		//iAppUi->RegisFail();

	}
	
	// Next look at 
	// ProfileRegistrationStatusChanged(TUint32 aSIPProfileId) 
	// method. Response for REGISTER request is handled there. 
	
} 
// End ExecuteL

void CSIPEngine::Invite(const TDesC8& user) { 
	
		// create a SIP dialog for sending an INVITE; 
		if (iSIPInviteDialogAssoc != NULL)
			delete iSIPInviteDialogAssoc ;
		iSIPInviteDialogAssoc = CreateSIPInviteDialogAssoc(user); 
		
		// Continue session establishement using the SIP Client API 
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iSIPInviteDialogAssoc->SendInviteL();

} 
// End Invite

void CSIPEngine::UnInvite() { 
		iSIPInviteDialogAssoc->SendByeL();
} 

void CSIPEngine::Invite2(const TDesC8& user, TBool iIsSendAudio) { 
		// create a SIP dialog for sending an INVITE; 
		if (iSIPInviteDialogAssoc != NULL)
			delete iSIPInviteDialogAssoc ;
        iSIPInviteDialogAssoc = CreateSIPInviteDialogAssoc(user);
           		
		TInt64 stamp = NTPTime();

		ResolveLocalIP(iConnection->IapId());

		iSDPVersionId = stamp;
		iSDPSessionId = stamp;
				
		iSipDirection = CSIPEngine::ESIPBoth;

		_LIT8(text, "application");
		_LIT8(plain, "sdp");
		CSIPContentTypeHeader* contentType = CSIPContentTypeHeader::NewL(text,plain);
		CleanupStack::PushL(contentType);
		CSIPMessageElements* msgElements = CSIPMessageElements::NewL();
		CleanupStack::PushL(msgElements);
		
		if(iIsSendAudio){
			msgElements->SetContentL(CreateSDPL2(),contentType);
		}else{
			msgElements->SetContentL(CreateSDPL(),contentType);
		}
				
		TBuf8<100> subject;
		//subject.Copy(iSIPEngine.Settings()->SIPSubject());
		subject = _L8("Invite Opponent");
				
		_LIT8(K100Rel,"100rel");
		CSIPSupportedHeader* supportHeader = CSIPSupportedHeader::NewL(K100Rel);
		CleanupStack::PushL(supportHeader);

		CSIPExtensionHeader* subjectHeader = CSIPExtensionHeader::NewL(_L8("Subject"),subject);
		CleanupStack::PushL(subjectHeader);
		subjectHeader->SetNameL(_L8("s"));
				
		RPointerArray<CSIPHeaderBase>* userArray = new(ELeave) RPointerArray<CSIPHeaderBase>(1);
		CleanupStack::PushL(userArray);
		userArray->Append(subjectHeader);
		userArray->Append(supportHeader);
		msgElements->SetUserHeadersL(*userArray);
				
		//iSIPEngine.iCSIPClientTransactionArray->InsertL(0,iSIPEngine.iSipInviteAssoc->SendInviteL(msgElements));

		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iSIPInviteDialogAssoc->SendInviteL(msgElements);

		CleanupStack::PopAndDestroy(userArray);
		CleanupStack::Pop(subjectHeader);
		CleanupStack::Pop(supportHeader);
		CleanupStack::Pop(msgElements);
		CleanupStack::Pop(contentType);
						
} 
// End Invite2


void CSIPEngine::Subscribe(const TDesC8& user) { 
	/*
		// create a SIP dialog for sending an INVITE; 
		if (iSIPSubscribeDialogAssoc != NULL)
			delete iSIPSubscribeDialogAssoc ;
		iSIPSubscribeDialogAssoc = CreateSIPSubscribeDialogAssoc(user); 
		
		// Continue session establishement using the SIP Client API 
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iSIPSubscribeDialogAssoc->SendSubscribeL(); 	
	*/
		// create a SIP dialog for sending an INVITE; 
		if (iSIPInviteDialogAssoc != NULL)
			delete iSIPInviteDialogAssoc ;
		iSIPInviteDialogAssoc = CreateSIPInviteDialogAssoc(user); 
		
		// Continue session establishement using the SIP Client API 
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iSIPInviteDialogAssoc->SendInviteL();
} 
// End Subscribe

/*void CSIPEngine::UnSubscribe(const TDesC8& user) { 
	
		// create a SIP dialog for sending an INVITE; 
		iSIPSubscribeDialogAssoc = CreateSIPSubscribeDialogAssoc(user); 
		
		// Continue session establishement using the SIP Client API 
		//iSIPClientTransaction = iSIPSubscribeDialogAssoc->SendUnSubscribeL(); 	
} */
// End UnSubscribe
void CSIPEngine::Notify(const TDesC8& user) { 		
		/*
		// create a SIP Request for sending an NOTIFY; 
		CSIPRequestElements* iRequest = CreateSIPRequestMessage(user);			
		
		// Continue session establishement using the SIP Client API 
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iConnection->SendRequestL(iRequest);
		*/

		// create a SIP dialog for sending an INVITE; 
		if (iSIPInviteDialogAssoc != NULL)
			delete iSIPInviteDialogAssoc ;
        iSIPInviteDialogAssoc = CreateSIPInviteDialogAssoc(user);
           		
		_LIT8(text, "text");
		_LIT8(plain, "plain");
		CSIPContentTypeHeader* contentType = CSIPContentTypeHeader::NewL(text,plain);
		CleanupStack::PushL(contentType);
		CSIPMessageElements* msgElements = CSIPMessageElements::NewL();
		CleanupStack::PushL(msgElements);

		//HBufC8* iBuffer = HBufC8::NewL(16);
		//_LIT8(KStatus, "Status = Away");
		//*iBuffer = KStatus;

		// Get Status before send notify
		HBufC8* iBuffer = HBufC8::NewL(50); //status 16 name 30+4
		/*	enum TUserStatus
		{
			EOnline = 0,
			EBusy,
			EAway,
			EOffline,
			EAppOffline,
		};*/

		TInt status = iAppUi->GetStatus();
		switch(status)
			{
			case EOnline:
				*iBuffer = KStatus1;
			break;
			case EBusy:           
				*iBuffer = KStatus2;
			break;
			case EAway:
				*iBuffer = KStatus3;
			break;
			case EAppOffline:
				*iBuffer = KStatus4;
			break;
			default:
				*iBuffer = KStatus4;
			break;
			}

		//CleanupStack::PushL(iBuffer);
		//Append Name
		TPtr8 ptr(iBuffer->Des());
		ptr.Append('|');
		
		TBuf16<20> namebuf;
		iAppUi->GetMyName(namebuf);
		
		//XXXXXXXXXX
		
		TBuf8<40> namebuf2;
		iAppUi->EncodeL(namebuf);
		iAppUi->GetBuf8(namebuf2);
		//namebuf2.Copy(namebuf);
		ptr.Append(namebuf2);

		//Append location
		ptr.Append('|');

		TBuf16<40> namebuf3;
		iAppUi->GetMyLocation(namebuf3);
		
		TBuf8<80> namebuf4;
		namebuf4.Copy(namebuf3);
		ptr.Append(namebuf4);


		msgElements->SetContentL(iBuffer,contentType);
				
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iSIPInviteDialogAssoc->SendInviteL(msgElements);

		CleanupStack::Pop(msgElements);
		CleanupStack::Pop(contentType);

} 
// End Notify

/*
void CSIPEngine::Message(const TDesC8& user,const TDesC8& aMsg) { 		
		// create a SIP Request for sending an NOTIFY; 
		CSIPRequestElements* iRequest = CreateSIPRequestMessage(user,aMsg);			
		
		// Continue session establishement using the SIP Client API 
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iConnection->SendRequestL(iRequest);
} 
// End SEND MESSAGE
*/
void CSIPEngine::Message(const TDesC8& user,const TDesC8& aMsg) { 		
		// create a SIP dialog for sending an INVITE; 
		if (iSIPInviteDialogAssoc != NULL)
			delete iSIPInviteDialogAssoc ;
        iSIPInviteDialogAssoc = CreateSIPInviteDialogAssoc(user);
           		
		_LIT8(text, "text");
		_LIT8(plain, "plain");
		CSIPContentTypeHeader* contentType = CSIPContentTypeHeader::NewL(text,plain);
		CleanupStack::PushL(contentType);
		CSIPMessageElements* msgElements = CSIPMessageElements::NewL();
		CleanupStack::PushL(msgElements);

		//HBufC8* iBuffer = HBufC8::NewL(16);
		//_LIT8(KStatus, "Status = Away");
		//*iBuffer = KStatus;
		
		//Msg BODY
		TInt lengthMsg = aMsg.Length();
		HBufC8* iBuffer = HBufC8::NewL(lengthMsg);
		*iBuffer = aMsg;

		msgElements->SetContentL(iBuffer,contentType);
				
		if (iSIPClientTransaction != NULL)
			delete iSIPClientTransaction;
		iSIPClientTransaction = iSIPInviteDialogAssoc->SendInviteL(msgElements);

		CleanupStack::Pop(msgElements);
		CleanupStack::Pop(contentType);
		
} 
// End SEND MESSAGE
/***********************************************************************
* Constructs CSIPInviteDialogAssoc object for test purposes. 
* @return CSIPInviteDialogAssoc object 
************************************************************************/ 
CSIPInviteDialogAssoc* CSIPEngine::CreateSIPInviteDialogAssoc(const TDesC8& user) { 
	// Construct toHeader. Note that we use possibly non-existing
	// opponent SIP Address. 
	CSIPAddress* toAddress = CSIPAddress::DecodeL(user); 
	CleanupStack::PushL(toAddress); 

	CSIPToHeader* toHeader = CSIPToHeader::NewL(toAddress); 

	CleanupStack::Pop(toAddress); 
	CleanupStack::PushL(toHeader); 

	// and construct CSIPInviteDialogAssoc by using 
	// from- and toHeaders: 
	CSIPInviteDialogAssoc* inviteDialogAssoc = CSIPInviteDialogAssoc::NewL( *iConnection, toHeader, *iProfile ); 

	CleanupStack::Pop(toHeader); 
//	delete toAddress;
	//delete toHeader;

	return inviteDialogAssoc; 
} 

/*CSIPInviteDialogAssoc* CSIPEngine::CreateSIPInviteDialogAssoc(const TDesC8& user,const TDesC8& aMsg) { 
	// Construct toHeader. Note that we use possibly non-existing
	// opponent SIP Address. 
	CSIPAddress* toAddress = CSIPAddress::DecodeL(user); 
	CleanupStack::PushL(toAddress); 

	CSIPToHeader* toHeader = CSIPToHeader::NewL(toAddress); 

	CleanupStack::Pop(toAddress); 
	CleanupStack::PushL(toHeader); 

	// and construct CSIPInviteDialogAssoc by using 
	// from- and toHeaders: 
	CSIPInviteDialogAssoc* inviteDialogAssoc = CSIPInviteDialogAssoc::NewL( *iConnection, toHeader, *iProfile ); 

	CleanupStack::Pop(toHeader); 
//	delete toAddress;
	//delete toHeader;

	return inviteDialogAssoc; 
} */



CSIPSubscribeDialogAssoc* CSIPEngine::CreateSIPSubscribeDialogAssoc(const TDesC8& user) { 
	// Construct toHeader. Note that we use possibly non-existing
	// opponent SIP Address. 
	CSIPAddress* toAddress = CSIPAddress::DecodeL(user); 
	CleanupStack::PushL(toAddress); 

	CSIPToHeader* toHeader = CSIPToHeader::NewL(toAddress); 

	CleanupStack::Pop(toAddress); 
	CleanupStack::PushL(toHeader); 

	// and construct CSIPInviteDialogAssoc by using 
	// from- and toHeaders: 
	CSIPSubscribeDialogAssoc* subscribeDialogAssoc = CSIPSubscribeDialogAssoc::NewL( *iConnection, toHeader, *iProfile ); 

	CleanupStack::Pop(toHeader); 
//	delete toAddress;
	//delete toHeader;

	return subscribeDialogAssoc; 
} 

CSIPRequestElements* CSIPEngine::CreateSIPRequestMessage(const TDesC8& user) { 
	//Create To:Header is opponent SIP Address. 
	CSIPAddress* toAddress = CSIPAddress::DecodeL(user); 
	CleanupStack::PushL(toAddress); 

	CSIPToHeader* toHeader = CSIPToHeader::NewL(toAddress); 
	
	CleanupStack::Pop(toAddress); 
	CleanupStack::PushL(toHeader);
		
	//Get SIP User "sip:xxx@domain.com"
	TBuf8<60> user1;
	user1.Copy(_L8("sip:"));
	//get user name from stack0
	const TDesC8 &userName = iProfile->ServerParameter(CSIPProfile::ERegistrar,CSIPProfile::EDigestUsername);
	const TDesC8 &realm = iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestRealm);
	user1.Append(userName);
	user1.Append(_L8("@"));
	user1.Append(realm);
	user1.ZeroTerminate();

	//Create CSIPRequestElements
	//  will Create CSIPMessageElement
	CSIPRequestElements* iRequest = CSIPRequestElements::NewL(toHeader);
	CleanupStack::Pop(toHeader); 

	//Create To:Header is My Own SIP Address. 
	CSIPAddress* formAddress2 = CSIPAddress::DecodeL(user1); 
	CleanupStack::PushL(formAddress2); 
	CSIPFromHeader* fromHeader = CSIPFromHeader::NewL(formAddress2); 
	CleanupStack::Pop(formAddress2); 
	CleanupStack::PushL(fromHeader);
	
	//Set Header Form ::step 3
	iRequest->SetFromHeaderL(fromHeader);
	CleanupStack::Pop(fromHeader); 

	//Construct SIP URI. ::step 4 zang-ignore
	// SIP URI. -> sip:user:password@host:port;uri-parameters?headers 
	CSIPURI* toAddress3 = CSIPURI::DecodeL(user); 
	CleanupStack::PushL(toAddress3); 
	iRequest->SetRemoteURIL(toAddress3);
	CleanupStack::Pop(toAddress3);
	
	CSIPContentTypeHeader* contentType = CSIPContentTypeHeader::NewL(_L8("text"),_L8("plain"));



	// Get Status before send notify
	HBufC8* iBuffer = HBufC8::NewL(50); //status 16 name 30+4
	/*	enum TUserStatus
	{
		EOnline = 0,
		EBusy,
		EAway,
		EOffline,
		EAppOffline,
	};*/

	TInt status = iAppUi->GetStatus();
    switch(status)
        {
        case EOnline:
			*iBuffer = KStatus1;
		break;
        case EBusy:           
			*iBuffer = KStatus2;
        break;
		case EAway:
			*iBuffer = KStatus3;
		break;
		case EAppOffline:
			*iBuffer = KStatus4;
		break;
        default:
			*iBuffer = KStatus4;
        break;
        }

	//CleanupStack::PushL(iBuffer);
	TPtr8 ptr(iBuffer->Des());
	ptr.Append('|');
	
	TBuf16<20> namebuf;
	iAppUi->GetMyName(namebuf);
	
	TBuf8<40> namebuf2;
	namebuf2.Copy(namebuf);
	ptr.Append(namebuf2);

	iRequest->MessageElements().SetContentL(iBuffer, contentType);
	
	//CleanupStack::PopAndDestroy();
	//delete iBuffer;
	// Set Method
	iRequest->SetMethodL(_L8("MESSAGE"));  
	return iRequest;
} 


CSIPRequestElements* CSIPEngine::CreateSIPRequestMessage(const TDesC8& user,const TDesC8& aMsg) { 
	CSIPAddress* toAddress = CSIPAddress::DecodeL(user); 
	CleanupStack::PushL(toAddress); 
	CSIPToHeader* toHeader = CSIPToHeader::NewL(toAddress); 
	CleanupStack::Pop(toAddress); 
	CleanupStack::PushL(toHeader);
	TBuf8<60> user1;
	user1.Copy(_L8("sip:"));
	const TDesC8 &userName = iProfile->ServerParameter(CSIPProfile::ERegistrar,CSIPProfile::EDigestUsername);
	const TDesC8 &realm = iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestRealm);
	user1.Append(userName);
	user1.Append(_L8("@"));
	user1.Append(realm);
	user1.ZeroTerminate();
	//Create CSIPRequestElements
	//  will Create CSIPMessageElement
	CSIPRequestElements* iRequest = CSIPRequestElements::NewL(toHeader);
	CleanupStack::Pop(toHeader); 
	//Create To:Header is My Own SIP Address. 
	CSIPAddress* formAddress2 = CSIPAddress::DecodeL(user1); 
	CleanupStack::PushL(formAddress2); 
	CSIPFromHeader* fromHeader = CSIPFromHeader::NewL(formAddress2); 
	CleanupStack::Pop(formAddress2); 
	CleanupStack::PushL(fromHeader);
	iRequest->SetFromHeaderL(fromHeader);
	CleanupStack::Pop(fromHeader); 
	//Construct SIP URI. ::step 4 zang-ignore
	// SIP URI. -> sip:user:password@host:port;uri-parameters?headers 
	CSIPURI* toAddress3 = CSIPURI::DecodeL(user); 
	CleanupStack::PushL(toAddress3); 
	iRequest->SetRemoteURIL(toAddress3);
	CleanupStack::Pop(toAddress3);
	CSIPContentTypeHeader* contentType = CSIPContentTypeHeader::NewL(_L8("text"),_L8("plain"));

	//MSg BODY

	TInt lengthMsg = aMsg.Length();
	HBufC8* iBuffer = HBufC8::NewL(lengthMsg);
	*iBuffer = aMsg;
	//CleanupStack::PushL(iBuffer);
	iRequest->MessageElements().SetContentL(iBuffer, contentType);
	//CleanupStack::PopAndDestroy();
	// Set Method
	iRequest->SetMethodL(_L8("MESSAGE"));  
	return iRequest;
} 


//MSIPProfileRegistryObserver implementation: 
void CSIPEngine::ProfileRegistrationStatusChanged(TUint32 aSIPProfileId) { 
	// First inform User Interface that this method is being called 
	User::InfoPrint(_L("ProfileRegistrationStatusChanged")); 
	
	// Check that the changed profile is the same we use 
	if (aSIPProfileId == iProfile->Id()) { 
		// Check that registration to the server was successful 
		if ( iProfile->Status() == CSIPProfile::ERegistered) { 
			// Get a connection object from ProfileRegistry. 
			// Note: this can only be done after successful 
			// registration. 
			iConnection = iProfileRegistry->ConnectionL(*iProfile);
			
			// Continue this example application directly by 
			// sending INVITE request. 	
			
			//AUTO_Subscribe			
			iAppUi->ToSubScribe();
			iAppUi->ChangeContextStatus(0);
			iAppUi->SetTitleUsername();
			iAppUi->SetIsRegis(ETrue);
			//iAppUi->ChangeTitleUsername(GetOwnUsername());
			//iAppUi->SetTitleUsername();//Get From FileStore

		} 
	} 
} 


TBool CSIPEngine::IsRegistered() { 	
	// Check that registration to the server was successful 
	if ( iProfile->Status() == CSIPProfile::ERegistered) { 
		//User::InfoPrint(_L("Registered") );
			
		
	TInt status = iProfileRegistry->EnableL(*iProfile, *this); 
	
	// The returned status indicates if the profile can be immediately used 
	// for creating a session, or if the client must wait for the profile to 
	// be registered. 
	
	if (status == KErrNone) { 
		// get the SIP connection used by the profile 
		iConnection = iProfileRegistry->ConnectionL(*iProfile); 
	} else 
		// KErrPending 
	{ 
	}

		return ETrue;
	} else {
		//User::InfoPrint(_L("Not Registered") );
		return EFalse;
	}
} 

// MSIPConnectionObserver implementation 
void CSIPEngine::IncomingResponse ( CSIPClientTransaction& aTransaction, CSIPDialogAssocBase& /*aDialogAssoc*/) { 
	if (aTransaction.ResponseElements()->CSeqHeader()->Method() == _L8("SUBSCRIBE")) {
		if (aTransaction.ResponseElements()->StatusCode() == 200){
			
			
			//TBuf16<10> user;
			TBuf8<60> user;
			const TDesC8 &userName = aTransaction.ResponseElements()->ToHeader()->SIPAddress().URI().User();
			user.Copy(userName);
			//User::InfoPrint(user);

			iAppUi->UpdateStatus(user,EOnline);//set to online //"sip:player1@161.246.5.195")
			

		} else {
			//aTransaction.ResponseElements().iMessageElements()
		}
	} else if (aTransaction.ResponseElements()->CSeqHeader()->Method() == _L8("INVITE")) {

		User::InfoPrint(_L("IncomingResponse")); 
		// ACK is sent to any 2xx response 
		if (aTransaction.ResponseElements()->StatusCode() == 150)
		{
				//TBuf16<10> user;
			TBuf8<60> user;
			const TDesC8 &userName = aTransaction.ResponseElements()->ToHeader()->SIPAddress().URI().User();
			user.Copy(userName);
			//User::InfoPrint(user);

			iAppUi->UpdateStatus(user,EOnline);//set to online //"sip:player1@161.246.5.195")
			
		}
		else if (aTransaction.ResponseElements()->StatusCode() == 200) 
		{ 
			// Send ACK message: 
			const CSIPResponseElements *reqElem = aTransaction.ResponseElements();
		
			CSdpDocument* sdpDoc = CSdpDocument::DecodeLC(reqElem->MessageElements().Content());

			//XXXX
			TBool isAudio = EFalse;
			RStringF media = sdpDoc->MediaFields()[0]->Media();
				
			if(media == SdpCodecStringPool::StringPoolL().StringF(SdpCodecStringConstants::EMediaAudio,SdpCodecStringPool::StringTableL()) ){
					isAudio = ETrue;
			}else{
					isAudio = EFalse;
			}

			ProcessSDPL(sdpDoc);
			CleanupStack::PopAndDestroy(sdpDoc);

			iSIPInviteDialogAssoc->SendAckL(aTransaction);
			
			iSocketsEngine = CSocketsEngine::NewL(*this, EFalse, this);

			//TBuf8<512> temp;
			//temp.Copy(iSendfile);
			
			iSocketsEngine->SetFilePath(iSendfile);
			
			iSocketsEngine->SetServerName(iOpponentIp);
			TInt		 iPort;
			iPort = 49152;
			iSocketsEngine->SetPort(iPort);
			
			iSocketsEngine->ConnectL();

			// Start send file
			iSocketsEngine->SetSender(1);
			count = 0;
			
			if(isAudio){
				iSocketsEngine->SetSender(2);
			}else{
				SendFile();
			}
		}
		else if (aTransaction.ResponseElements()->StatusCode() == 406) {
			_LIT(KMessage, "Rejected by the reciever!");
			CAknWarningNote* note = new (ELeave) CAknWarningNote();
			note->ExecuteLD(KMessage);
		}
	} 
} 

// MSIPConnectionObserver implementation.
//Gets called when an INVITE comes
void CSIPEngine::IncomingRequest (CSIPServerTransaction* aTransaction)
{

	User::InfoPrint(_L("IncomingRequest")); 
	if (aTransaction->Type() == CSIPTransactionBase::EINVITE)
	{
		if (aTransaction->RequestElements()->MessageElements().Content().Length() == 0)//Subscribe
		{
			// Subscribe (Invite without content)
			CSIPResponseElements* response = CSIPResponseElements::NewL(150,_L8("Accepted"));
			CleanupStack::PushL(response);
			aTransaction->SendResponseL(response);
			CleanupStack::Pop(response);

			TBuf8<60> user;
			const TDesC8 &userName = aTransaction->RequestElements()->FromHeader()->SIPAddress().URI().User();
			user.Copy(userName);

			//SubScribe after Notify Only!!
			//If user in myAcc not online
			
			/*iAppUi->ToNotify(user);		
			iAppUi->ToSubScribe(user);*/

			//iAppUi->ToSubScribe(user);
			iAppUi->ToNotify(user);		
			
		} 
		else 
		{

			if (aTransaction->RequestElements()->MessageElements().ContentType()->MediaSubtype() == _L8("plain"))//Message
			{
				// Notify (Invite with text/plain)
				const CSIPRequestElements* request = aTransaction->RequestElements();
				const TDesC8 &context = request->MessageElements().Content(); 
		
				//if contex is status   ***  message(= text sended )
				TBuf16<128> headMsg;
				headMsg.Copy(context);

				//TBuf16<128> contentMsg;
		
				headMsg.SetLength(6);
				User::InfoPrint(headMsg);
				//_LIT16(KMsg,"Message");
				_LIT16(KStatus,"Status");

				TBuf8<60> user;
				const TDesC8 &userName = aTransaction->RequestElements()->FromHeader()->SIPAddress().URI().User();
				user.Copy(userName);


				if (headMsg == KStatus){
			
					//UpdateUserStatus()
					//Cut Status = Away
					//contentMsg.Copy(context)
					//headMsg.Delete(0,3);//cut 3 char
					TBuf8<256> contextCopy;
					TBuf8<256> contextLocation;

					contextCopy.Copy(context);
					TInt pos;
					pos = contextCopy.Locate('|');
					pos = pos +1;
					contextCopy.Delete(0,pos);

					contextLocation.Copy(contextCopy);

					pos = contextCopy.Locate('|');
					contextCopy.SetLength(pos);
					
					pos = pos +1;
					contextLocation.Delete(0,pos);


					//TBuf16<128> bbb;
					//bbb.Copy(contextCopy);
					//User::InfoPrint(bbb);
		
					TBuf8<256> context2;
					context2.Copy(context);
					pos = context2.Locate('|');
					context2.SetLength(pos);
				
					//context2 is status
					//contextcopy is name
					//contextlocation is location

					if(context2 == KStatus1){
						iAppUi->UpdateStatus(user,EOnline,contextCopy,contextLocation);
					}
					else if(context2 == KStatus2){
						iAppUi->UpdateStatus(user,EBusy,contextCopy,contextLocation);
					}
					else if(context2 == KStatus3){
						iAppUi->UpdateStatus(user,EAway,contextCopy,contextLocation);
					}
					else if(context2 == KStatus4){
						iAppUi->UpdateStatus(user,EOffline,contextCopy,contextLocation);
					}
	
				}else{
			
					//TBuf16<128> iMsg;
					//iMsg.Copy(context);
					//iAppUi->ReceiveMsg(user,iMsg);
					iAppUi->ReceiveMsg(user,context);
				}

			CSIPResponseElements* response = CSIPResponseElements::NewL(160,_L8("OK"));
			CleanupStack::PushL(response);
			aTransaction->SendResponseL(response);
			CleanupStack::Pop(response);

			} 
			else
			{
				// Invite with SDP 
				_LIT(KMessage, "Incoming Invite");
				CAknInformationNote* note = new (ELeave) CAknInformationNote();
				note->ExecuteLD(KMessage);
				//Answer immediately with 180 Ringing
				//THE NEXT LINE IS VERY IMPORTANT AND ALMOST NOWHERE DOCUMENTED!!
				iSIPInviteDialogAssoc=CSIPInviteDialogAssoc::NewL(*aTransaction);
				CSIPResponseElements* responseRinging;
				responseRinging= CSIPResponseElements::NewL(180, _L8("Ringing"));
				aTransaction->SendResponseL(responseRinging);

				//Now handle the request correctly
				//TBuf8<100> *senderAddr=new TBuf8<100>;
				const CSIPRequestElements *reqElem = aTransaction->RequestElements();
				//const CSIPMessageElements& cSIPMessageElements=reqElem->MessageElements();
		
				CSdpDocument* sdpDoc = CSdpDocument::DecodeLC(reqElem->MessageElements().Content());
				TBool isAudio = EFalse;
				RStringF media = sdpDoc->MediaFields()[0]->Media();
				
				_LIT(KQueryStr, "Recieve file?");
				_LIT(KQueryStr2, "Start Speech?");
				TBuf<15> msggAlert;
				TBuf<50> msggAlert2;

				TBuf8<60> user = reqElem->FromHeader()->SIPAddress().URI().User();

				if(media == SdpCodecStringPool::StringPoolL().StringF(SdpCodecStringConstants::EMediaAudio,SdpCodecStringPool::StringTableL()) ){
					isAudio = ETrue;
					msggAlert.Copy(KQueryStr2);
					msggAlert2.Copy( user );
					
				}else{
					isAudio = EFalse;
					msggAlert.Copy(KQueryStr);
					msggAlert2.Copy(iRecieveFileName);

				}

				HBufC8* asSting = ProcessSDPL(sdpDoc);				
				CleanupStack::PopAndDestroy(sdpDoc);
	
				//
				if( iEikonEnv->QueryWinL(msggAlert, msggAlert2) )
				{
					CleanupStack::PushL(asSting);
					CSIPResponseElements* response2 = CSIPResponseElements::NewL(200,_L8("OK"));
					CleanupStack::PushL(response2);
		
					_LIT8 (text, "application");
					_LIT8(plain, "sdp");
			
					CSIPContentTypeHeader* contentType = CSIPContentTypeHeader::NewL(text,plain);
					CleanupStack::PushL(contentType);

					response2->MessageElements().SetContentL(asSting,contentType);

					TRAPD(err,aTransaction->SendResponseL(response2));
					CleanupStack::Pop(contentType);
					CleanupStack::Pop(response2);
					CleanupStack::Pop(asSting);
				
					// Socket Listen port
					iSocketsEngine = CSocketsEngine::NewL(*this, EFalse, this);
					iServSocketsEngine = CServSocketsEngine::NewL(iSocketsEngine, *this);
					TInt		 iListenPort;
					iListenPort = 1025;
					iServSocketsEngine->StartSocketListenerL(iListenPort);

					if(isAudio){
						iSocketsEngine->SetSender(2);
					}

				}
				else
				{
					// Rejected Invite
					CSIPResponseElements* responseDeny;
					responseDeny= CSIPResponseElements::NewL(406, _L8("Not Acceptable"));
					aTransaction->SendResponseL(responseDeny);
				}
			}
		}
	}
	if (aTransaction->Type() == CSIPTransactionBase::ESUBSCRIBE) {
		CSIPResponseElements* response = CSIPResponseElements::NewL(200,_L8("OK"));
		CleanupStack::PushL(response);
		aTransaction->SendResponseL(response);
		CleanupStack::Pop(response);
	}
	if (aTransaction->Type() == CSIPTransactionBase::EMESSAGE) {
		const CSIPRequestElements* request = aTransaction->RequestElements();
		const TDesC8 &status = request->MessageElements().Content(); 
		TBuf16<20> show;
		show.Copy(status);
		User::InfoPrint(show);
		CSIPResponseElements* response = CSIPResponseElements::NewL(200,_L8("OK"));
		CleanupStack::PushL(response);
		aTransaction->SendResponseL(response);
		CleanupStack::Pop(response);
	}

	delete aTransaction;
}

// MSIPConnectionObserver implementation. 
void CSIPEngine::IncomingRequest ( CSIPServerTransaction* aTransaction , CSIPDialog& aDialog) { 
	// handle incoming request by using SIP API. 
	// CSIPRequestElements reqElem = aTransaction->RequestElements() 
	// 
	if (aTransaction->Type() == CSIPTransactionBase::EACK)
	{
		if (aDialog.IsAssociated(*iSIPInviteDialogAssoc))
		{
			//INVITE succesful
			User::InfoPrint(_L("IncomingACK"));
			// Start Session
			// ...
		}
	}
	if (aTransaction->Type() == CSIPTransactionBase::EBYE)
	{
		//Buddy left
		User::InfoPrint(_L("IncomingBYE"));
		iServSocketsEngine->Disconnect();
	}
	delete aTransaction;
}

/*NEW FUNC---------------------------*/
void CSIPEngine::ResolveLocalIP(TUint aIapId)
{
	
	//WRITE_LOG_FORMAT(_L("IAP: %d"),aIapId);
	

	RSocketServ socketServ;
	socketServ.Connect();
	
	TUint iapId = aIapId;
	RConnection connection;
	connection.Open(socketServ);
	TPckgBuf<TConnectionInfo> connectionInfo;

	TUint count;
	connection.EnumerateConnections(count);
	for (TUint machConnection = 1; machConnection <= count; machConnection++)
	{
		connection.GetConnectionInfo(machConnection, connectionInfo);
		TUint bufId = connectionInfo().iIapId;
	
		if (bufId == iapId)
			break;
	}

	User::LeaveIfError(connection.Attach(connectionInfo,RConnection::EAttachTypeNormal));

	TInetAddr addr;

	RSocket socket;
	User::LeaveIfError(socket.Open(socketServ, KAfInet, KSockDatagram, 
		KProtocolInetUdp, connection));

	if (socket.SetOpt(KSoInetEnumInterfaces, KSolInetIfCtrl) == KErrNone)
		{
		TPckgBuf<TSoInetInterfaceInfo> opt;
		while (socket.GetOpt(KSoInetNextInterface, KSolInetIfCtrl, opt) == KErrNone)
			{
			TPckgBuf<TSoInetIfQuery> optifquery;
			optifquery().iName = opt().iName;
			if(socket.GetOpt(KSoInetIfQueryByName, KSolInetIfQuery, optifquery) == KErrNone)
				{
				TInetAddr& address = (TInetAddr &)opt().iAddress;
				if(!address.IsUnspecified() && !address.IsLoopback())
					{
					if(address.IsV4Mapped())
						{
						address.ConvertToV4();
						}
					if(optifquery().iZone[1] == aIapId)
						{
						if(address.Family() == KAfInet6)
							{
							if(!address.IsLinkLocal())
								{
								addr = address;
								addr.SetScope(0);
								}
							}
						else
							{
							addr = address;
							addr.SetScope(0);
							}
						}
						break;
					}
				}
			}
		}
	socket.Close();

	addr.Output(iOwnIP);
	//WRITE_LOG(_L("Local IP: "));;
	//WRITE_LOG(iSIPEngine.iOwnIP);
	socketServ.Close();

}

TInt64 CSIPEngine::NTPTime()
{		
	TTime ntpTime;
	ntpTime.UniversalTime();
	TTimeIntervalYears toNTP(1900);
	ntpTime -= toNTP;
	TInt64 ntpTime64 = ntpTime.Int64();
	ntpTime64 /= 1000000;
	TBuf<20>  ntpTimeSTR;
	ntpTimeSTR.AppendNum(ntpTime64);
	return ntpTime64;
}

HBufC8* CSIPEngine::CreateSDPL()
{
	_LIT8(sesName,"SipSession");
	iSDPVersionId +=1;
	
	CSdpDocument* sdpDoc = CSdpDocument::NewLC();
	
	TInetAddr address;
	address.Input(iOwnIP);
	sdpDoc->SetSessionNameL(sesName);

	//Get File Size
	RFs fs;	// file server instance
	CleanupClosePushL(fs);					
	// PUSH
	User::LeaveIfError(fs.Connect());
	RFile mediafile;
	CleanupClosePushL(mediafile);
	TFileName streamFile;
	streamFile.Copy(iSendfile);
	User::LeaveIfError(CompleteWithAppPath(streamFile));
	User::LeaveIfError(mediafile.Open(fs, streamFile, EFileRead | EFileShareReadersOnly));
	// file opened ok, create buffer
	TInt size;
	mediafile.Size(size);
	mediafile.Close();
	iRecieveFileSize = size;
	// pop and destroy resources pushed into stack
	CleanupStack::PopAndDestroy(2);

	TBuf8<256> filename;
	filename.Copy(iSendfile);
	filename.Delete(0,(filename.LocateReverse('\\')+1));
	iRecieveFileName.Copy(filename);

	TBuf8<100> formats;	
	formats.Copy(filename);

	TBuf8<10> filesize;	
	filesize.AppendNum(size);
	
	CSdpOriginField* sdpOrigField ;
	//TDesC8 name = iSIPEngine.iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestUsername);
	//if (name.Length() > 0)
	//	sdpOrigField = CSdpOriginField::NewL(iSIPEngine.iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestUsername),iSIPEngine.iSDPSessionId,iSIPEngine.iSDPVersionId,address); 
	//else
	//_LIT8(KDefaultUsername,"ZangDefaultName");
	sdpOrigField = CSdpOriginField::NewL(filesize,iSDPSessionId,iSDPVersionId,address); 

	CleanupStack::PushL(sdpOrigField);
	sdpDoc->SetOriginField(sdpOrigField);
	CleanupStack::Pop(sdpOrigField);

	CSdpConnectionField* conData = CSdpConnectionField::NewL(address);
	CleanupStack::PushL(conData);
	sdpDoc->SetConnectionField(conData);
	CleanupStack::Pop(conData);

	TInt iListenPort;
	iListenPort = 1025;

	CSdpMediaField* media = CSdpMediaField::NewL(SdpCodecStringPool::StringPoolL().StringF(SdpCodecStringConstants::EMediaData ,SdpCodecStringPool::StringTableL()),iListenPort, SdpCodecStringPool::StringPoolL().StringF(SdpCodecStringConstants::EProtocolTcp,SdpCodecStringPool::StringTableL()),formats);
	CleanupStack::PushL(media);
	
	/*RStringF modifier = SdpCodecStringPool::StringPoolL().OpenFStringL(_L8("direction"));
	CSdpAttributeField* direction = NULL;
	
	switch(iSipDirection)
	{
	case CSIPEngine::ESIPBoth:
		direction = CSdpAttributeField::NewL(modifier, KSDPAttributeDirectionBoth);
		break;
	case CSIPEngine::ESIPActive:
		direction = CSdpAttributeField::NewL(modifier, KSDPAttributeDirectionActive);
		break;
	case CSIPEngine::ESIPPassive:
		direction = CSdpAttributeField::NewL(modifier, KSDPAttributeDirectionPassive);
		break;
	}
	if (direction)
	{
		media->AttributeFields().Append(direction);
	}
	modifier.Close();
	*/


	sdpDoc->MediaFields().Append(media);
	CleanupStack::Pop(media);
//	CSdpDocument::TSDPErrors errorCode;
//	if (sdpDoc->IsValid())
//		{
		CBufStore* store = CBufStore::NewLC(1);
		RStoreWriteStream writeStream;
		TStreamId writeStreamId = writeStream.CreateL(*store);
		CleanupClosePushL(writeStream);
		sdpDoc->EncodeL(writeStream);

		MStreamBuf* buffer = writeStream.Sink();
		TInt lenght = buffer->SizeL();
		writeStream.Close();
		CleanupStack::Pop();

		HBufC8* sdpBuffer =  HBufC8::NewLC(lenght);
		TPtr8 bufPtr(sdpBuffer->Des());

		RStoreReadStream readStream;
		readStream.OpenL(*store,writeStreamId);	
		CleanupClosePushL(readStream);
		readStream.ReadL(bufPtr,lenght);
		readStream.Close();
		CleanupStack::Pop();
		CleanupStack::Pop();
		CleanupStack::PopAndDestroy(store);
		CleanupStack::PopAndDestroy(sdpDoc);
		
		return sdpBuffer;
//	}
//	else
//	{
//		CleanupStack::PopAndDestroy(sdpDoc);
//		return NULL;
//	}	
}

HBufC8* CSIPEngine::CreateSDPL2()
{
	_LIT8(sesName,"SipSession");
	iSDPVersionId +=1;
	
	CSdpDocument* sdpDoc = CSdpDocument::NewLC();
	
	TInetAddr address;
	address.Input(iOwnIP);
	sdpDoc->SetSessionNameL(sesName);

	CSdpOriginField* sdpOrigField ;
	//TDesC8 name = iSIPEngine.iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestUsername);
	//if (name.Length() > 0)
	//	sdpOrigField = CSdpOriginField::NewL(iSIPEngine.iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestUsername),iSIPEngine.iSDPSessionId,iSIPEngine.iSDPVersionId,address); 
	//else
	_LIT8(KDefaultUsername,"12345");
	sdpOrigField = CSdpOriginField::NewL(KDefaultUsername,iSDPSessionId,iSDPVersionId,address); 

	CleanupStack::PushL(sdpOrigField);
	sdpDoc->SetOriginField(sdpOrigField);
	CleanupStack::Pop(sdpOrigField);

	CSdpConnectionField* conData = CSdpConnectionField::NewL(address);
	CleanupStack::PushL(conData);
	sdpDoc->SetConnectionField(conData);
	CleanupStack::Pop(conData);

	TInt iListenPort;
	iListenPort = 1025;

	CSdpMediaField* media = CSdpMediaField::NewL(SdpCodecStringPool::StringPoolL().StringF(SdpCodecStringConstants::EMediaAudio,SdpCodecStringPool::StringTableL()),iListenPort, SdpCodecStringPool::StringPoolL().StringF(SdpCodecStringConstants::EProtocolTcp,SdpCodecStringPool::StringTableL()),KDefaultUsername);
	CleanupStack::PushL(media);

	sdpDoc->MediaFields().Append(media);
	CleanupStack::Pop(media);
//	CSdpDocument::TSDPErrors errorCode;
//	if (sdpDoc->IsValid())
//		{
		CBufStore* store = CBufStore::NewLC(1);
		RStoreWriteStream writeStream;
		TStreamId writeStreamId = writeStream.CreateL(*store);
		CleanupClosePushL(writeStream);
		sdpDoc->EncodeL(writeStream);

		MStreamBuf* buffer = writeStream.Sink();
		TInt lenght = buffer->SizeL();
		writeStream.Close();
		CleanupStack::Pop();

		HBufC8* sdpBuffer =  HBufC8::NewLC(lenght);
		TPtr8 bufPtr(sdpBuffer->Des());

		RStoreReadStream readStream;
		readStream.OpenL(*store,writeStreamId);	
		CleanupClosePushL(readStream);
		readStream.ReadL(bufPtr,lenght);
		readStream.Close();
		CleanupStack::Pop();
		CleanupStack::Pop();
		CleanupStack::PopAndDestroy(store);
		CleanupStack::PopAndDestroy(sdpDoc);
		
		return sdpBuffer;
//	}
//	else
//	{
//		CleanupStack::PopAndDestroy(sdpDoc);
//		return NULL;
//	}	
}

HBufC8* CSIPEngine::ProcessSDPL(CSdpDocument* aSdpDoc)
{
	
	CSdpDocument* sdpDoc = aSdpDoc;
	iOpponentPort = (sdpDoc->MediaFields()[0]->Port());
	iOpponentIp.Copy(sdpDoc->OriginField()->Address());

	//get filename
	iRecieveFileName.Copy( (sdpDoc->MediaFields()[0]->FormatList()) );
	//get filesize
	TBuf8<10> buf;
	buf.Copy(sdpDoc->OriginField()->UserName());
	TInt j=0;
	TInt l=1;
	for (TInt k=buf.Length()-1; k>=0; k--)
	{
		j=j+(buf[k]-48)*l;
		l=l*10;
	}
	iRecieveFileSize = j;

	/////////////////////////////////
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(iOpponentIp);
	/////////////////////////////////

	// Get OWN IP
	ResolveLocalIP(iConnection->IapId());
	TInetAddr address;
	address.Input(iOwnIP);
	sdpDoc->ConnectionField()->SetInetAddressL(address);

	TInt64 stamp = NTPTime();
	iSDPVersionId = stamp;
	TBuf<10> sessionId;
	sessionId.AppendNum(iSDPVersionId);
	iSDPVersionId += 1;
	TBuf<10> versionId;
	versionId.AppendNum(iSDPVersionId);
	//WRITE_LOG(_L("resetting originator!"));

	//_LIT8(KDefaultUsername,"-");
	//TDesC8 name = iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestUsername);
	if (buf.Length() > 0)
		sdpDoc->OriginField()->SetUserNameL(buf);
	else
		sdpDoc->OriginField()->SetUserNameL(iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestUsername));

	sdpDoc->OriginField()->SetSessionId(iSDPSessionId);
	sdpDoc->OriginField()->SetVersion(iSDPVersionId);
	sdpDoc->OriginField()->SetInetAddress(address);
	

	/*_LIT8(KSDPAttributeDirection,"direction");
	_LIT8(KSDPAttributeDirectionBoth,"both");
	_LIT8(KSDPAttributeDirectionActive,"active");
	_LIT8(KSDPAttributeDirectionPassive,"passive");
	RPointerArray<CSdpAttributeField>& sdpAttributes = sdpDoc->MediaFields()[0]->AttributeFields();
	for (TInt attribute = 0; attribute < sdpAttributes.Count(); attribute++)
	{

		if (((CSdpAttributeField*)sdpAttributes[attribute])->Attribute().DesC().Compare(KSDPAttributeDirection) == 0)
		{
			RStringF modifier = SdpCodecStringPool::StringPoolL().OpenFStringL(_L8("direction"));
		
			if (((CSdpAttributeField*)sdpAttributes[attribute])->Value().Compare(KSDPAttributeDirectionBoth) == 0 ||
				((CSdpAttributeField*)sdpAttributes[attribute])->Value().Compare(KSDPAttributeDirectionPassive) == 0)
			{
				((CSdpAttributeField*)sdpAttributes[attribute])->SetL(modifier,KSDPAttributeDirectionActive);
				iSipDirection = CSIPEngine::ESIPActive;
			}
			else if (((CSdpAttributeField*)sdpAttributes[attribute])->Value().Compare(KSDPAttributeDirectionActive) == 0)
			{
				//Observer()->SIPStartSocketListenerL(iSIPEngine.iListenPort);
				TInetAddr address;
				address.Input(iOwnIP);
				sdpDoc->ConnectionField()->SetInetAddressL(address);
				sdpDoc->MediaFields()[0]->SetPortL(iListenPort);
		
				((CSdpAttributeField*)sdpAttributes[attribute])->SetL(modifier,KSDPAttributeDirectionPassive);
				iSipDirection = CSIPEngine::ESIPPassive;
			}
			modifier.Close();
		}
		
	}
*/
	CBufStore* store = CBufStore::NewLC(1);
	RStoreWriteStream writeStream;
	TStreamId writeStreamId = writeStream.CreateL(*store);
	CleanupClosePushL(writeStream);
	sdpDoc->EncodeL(writeStream);
	MStreamBuf* buffer = writeStream.Sink();
	TInt lenght = buffer->SizeL();
	writeStream.Close();
	CleanupStack::Pop();

	HBufC8* sdpBuffer =  HBufC8::NewLC(lenght);
	TPtr8 bufPtr(sdpBuffer->Des());
	RStoreReadStream readStream;
	readStream.OpenL(*store,writeStreamId);	
	CleanupClosePushL(readStream);
	readStream.ReadL(bufPtr,lenght);
	readStream.Close();
	CleanupStack::Pop();
	CleanupStack::Pop();
	CleanupStack::PopAndDestroy(store);

	return sdpBuffer;

}



TDesC16& CSIPEngine::GetOwnUsername(){
	TBuf8<60> user1;
	user1.Copy(_L8("sip:"));
	//get user name from stack0
	const TDesC8 &userName = iProfile->ServerParameter(CSIPProfile::ERegistrar,CSIPProfile::EDigestUsername);
	const TDesC8 &realm = iProfile->ServerParameter(CSIPProfile::EOutboundProxy,CSIPProfile::EDigestRealm);
	user1.Append(userName);
	user1.Append(_L8("@"));
	user1.Append(realm);
	user1.ZeroTerminate();
	
	TBuf16<40> user3;
	user3.Copy(user1);
	//User::InfoPrint(user3);
//	HBufC* user4 = NULL;
	iOwnUsername = user3;
	return iOwnUsername;


}


void CSIPEngine::ToStatusChange(){
	iConnection = iProfileRegistry->ConnectionL(*iProfile);
	iAppUi->ToSubScribe();
	iAppUi->ChangeContextStatus(0);
}


CSIPConnection* CSIPEngine::GetConnection()
{
	return iConnection;
}
CSocketsEngine* CSIPEngine::GetSocket()
{
	return iSocketsEngine;
}

void CSIPEngine::MessageReceived(TDesC8& /*aMessageContent*/){
	HBufC8* iBuffer = HBufC8::NewL(16);
	_LIT8(KStatus,"ACK");
	*iBuffer = KStatus;

	if (!iSocketsEngine->GetSender())
	{
		//_LIT(KMessage, "Recieve");
		//CAknInformationNote* note = new (ELeave) CAknInformationNote();
		//note->ExecuteLD(KMessage);
		iSocketsEngine->WriteL(iBuffer);
		if (iIsRecieve == 0)
		{
			//Start Progress
			iGameSaverAO->SaveGameL(iSocketsEngine->GetiRecieveFileSize());
			iIsRecieve = 1;
		}
		if (iSocketsEngine->GetiCountRecieved() == 0)
		{
			//Finish Progress
			iGameSaverAO->ToFinished();
		
			_LIT(KMessage2, "Received Complete");
			CAknInformationNote* note2 = new (ELeave) CAknInformationNote();
			note2->ExecuteLD(KMessage2);
			iIsRecieve = 0;

			TInt i = iRecieveFileName.Find(_L("amr"));
			if (i != KErrNotFound)
			{
				//Play Sound
				iPlayerEngine->LoadAMRFileL ();
				iPlayerEngine->SavePCMFileL ();
				iPlayerEngine->LoadAudioFileL();
				iPlayerEngine->Play();
			}


			
		}
		else if (iSocketsEngine->GetiCountRecieved() == 1)
		{
			//Update Progress
			iGameSaverAO->ToSetActive();
			iGameSaverAO->ToSetActive();
			iGameSaverAO->ToSetActive();
		}
		else
		{
			//Update Progress
			iGameSaverAO->ToSetActive();
			iGameSaverAO->ToSetActive();
			iGameSaverAO->ToSetActive();
			iGameSaverAO->ToSetActive();
		}
	}
	else
	{
		//_LIT(KMessage2, "ACK");
		//CAknInformationNote* note = new (ELeave) CAknInformationNote();
		//note->ExecuteLD(KMessage2);
		//iGameSaverAO->ToSetActive();
		SendFile();
	}
}

void CSIPEngine::SendFile()
{
	if (!count)
	{
		//iGameSaverAO->SaveGameL(iRecieveFileSize);
		iInputEngine->LoadAudioFileL();
		iStream=iInputEngine->GetBufferPointer();
	}
	//_LIT(KQueryStr, "Send?");
	//_LIT(filename, "Next Buffer");

	/*for (TInt idx=0; idx<iStream.Count(); idx++)
	{
		sipEngine->GetSocket()->WriteL (iStream[idx]->Alloc());	
		//iSocketsEngine->WriteL (iStream[idx]->Alloc());
		//if (!iEikonEnv->QueryWinL(KQueryStr,filename ))
		//	idx = iStream.Count();
	}
	_LIT(KMessage, "Sent Complete");
	CAknInformationNote* note = new (ELeave) CAknInformationNote();
	note->ExecuteLD(KMessage);*/

	if (count<iStream.Count())
	{
		for (TInt i = 0; i<4; i++) 
		{
			iSocketsEngine->WriteL (iStream[count]->Alloc());

			if (count == 0)
			{
				//Start Progress Note
				iGameSaverAO->SaveGameL(iRecieveFileSize);
			}
			else
			{
				//Update Progress Note
				iGameSaverAO->ToSetActive();
			}
			count++;
			if (count == iStream.Count())
				break;
		}
		//iSocketsEngine->WriteL (iStream[idx]->Alloc());
		//if (!iEikonEnv->QueryWinL(KQueryStr,filename ))
		//	idx = iStream.Count();
	}
	else
	{
		iGameSaverAO->ToFinished();
		
		_LIT(KMessage, "Transferred Complete");
		CAknInformationNote* note = new (ELeave) CAknInformationNote();
		note->ExecuteLD(KMessage);
		
		iSocketsEngine->SetSender(0);
		count = 0;
		UnInvite();
		//iSocketsEngine->Disconnect();
		if (iServSocketsEngine)
		{
			delete iServSocketsEngine;
			iServSocketsEngine = NULL;
		}
		if (iSocketsEngine)
		{
			delete iSocketsEngine;
			iSocketsEngine = NULL;
		}
		//_LIT(KMessage, "Sent Complete");
		//CAknInformationNote* note = new (ELeave) CAknInformationNote();
		//note->ExecuteLD(KMessage);
	}

}

void CSIPEngine::SetFilePath(const TDesC& aFileSend)
{
	iSendfile.Copy(aFileSend);
	
	iInputEngine->SetFilePath(iSendfile);
	//iSocketsEngine->SetFilePathNamePrepareToSend(aFileSend);	

}

