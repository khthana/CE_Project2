/*
* ============================================================================
*  Name     : My picture class
*  Part of  : RTx
*  Created  : 2003. 08. 15. by  (V) - Forum Nokia 
*  Implementation notes:
*
*     
*  Version  :
*  Copyright: Forum Nokia
* ============================================================================
*/



// INCLUDE FILES

#include "mypicture.h"
#include <fbs.h>


// ---------------------------------------------------------
// Constructor
// ---------------------------------------------------------
//

CMyPicture::CMyPicture( TSize aSize, CFbsBitmap& aBitmap )
	: iSizeInTwips(aSize), iBitmap(&aBitmap)
    {
    }


// ---------------------------------------------------------
// LineBreakPossible()
// ---------------------------------------------------------
//

TBool CMyPicture::LineBreakPossible( TUint /*aClass*/,
										   TBool /*aBeforePicture*/,
										   TBool /*aHaveSpaces*/ ) const
	{
	return EFalse;
	}

// ---------------------------------------------------------
// Draw()
// ---------------------------------------------------------
//

void CMyPicture::Draw( CGraphicsContext& aGc,
						     const TPoint& aTopLeft,
						     const TRect& aClipRect,
						     MGraphicsDeviceMap* aMap ) const
	{
	TRect bitmapRect=aMap->TwipsToPixels(TRect(TPoint(),iSizeInTwips));
	bitmapRect.Move(aTopLeft);
	aGc.Reset();
	aGc.SetClippingRect(aClipRect);
	aGc.DrawBitmap(bitmapRect, iBitmap);
	}

// ---------------------------------------------------------
// ExternalizeL()
// ---------------------------------------------------------
//

void CMyPicture::ExternalizeL( RWriteStream& /*aStream*/ ) const
	{
	}
		
// ---------------------------------------------------------
// SetOriginalSizeInTwips()
// ---------------------------------------------------------
//

void CMyPicture::SetOriginalSizeInTwips( TSize aSize )
	{
	iSizeInTwips = aSize;
	}

// ---------------------------------------------------------
// GetOriginalSizeInTwips()
// ---------------------------------------------------------
//

void CMyPicture::GetOriginalSizeInTwips( TSize& aSize ) const
	{
	aSize = iSizeInTwips;
	}

