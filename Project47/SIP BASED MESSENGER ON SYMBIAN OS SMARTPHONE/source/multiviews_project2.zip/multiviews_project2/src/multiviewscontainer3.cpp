/* Copyright (c) 2003, Nokia. All rights reserved */

#include "MultiViewsContainer3.h"

CMultiViewsContainer3* CMultiViewsContainer3::NewL(const TRect& aRect)
    {
    CMultiViewsContainer3* self = CMultiViewsContainer3::NewLC(aRect);
    CleanupStack::Pop(self);
    return self;
    }

CMultiViewsContainer3* CMultiViewsContainer3::NewLC(const TRect& aRect)
    {
    CMultiViewsContainer3* self = new (ELeave) CMultiViewsContainer3();
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    return self;
    }

CMultiViewsContainer3::~CMultiViewsContainer3()
	{	
	delete iBitmap;

	}

CMultiViewsContainer3::CMultiViewsContainer3()
	{
		
	}


void CMultiViewsContainer3::ConstructL(const TRect& aRect)
    {
	//Load Bitmap
	iBitmap = new (ELeave) CFbsBitmap();
	//get mbm format
	TFileName bitmapFile (KMainPanePath);
	User::LeaveIfError (CompleteWithAppPath (bitmapFile));

	User::LeaveIfError(iBitmap->Load(bitmapFile, EMbmMultiviewsMaintab2));

	iListBarPosition = 0;

    CreateWindowL();
    SetRect(aRect);
    ActivateL();
    }

TInt CMultiViewsContainer3::CountComponentControls() const
    {
    return 0;
    }

void CMultiViewsContainer3::Draw(const TRect& aRect) const
    {    
    CWindowGc& gc = SystemGc();
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    //gc.SetBrushColor(KRgbBlue);
    //gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);

	//draw background
	TPoint topLeft(KTopLeftX, KTopLeftY);
	TSize bitmapSize(KSizeWidth, KSizeHeight);
	gc.DrawBitmap(TRect(topLeft, bitmapSize), iBitmap);	
	

	//draw List's Bar
	gc.SetPenColor(KRgbBlue); 
	gc.SetPenStyle(CGraphicsContext::ESolidPen); // make pen solid
						/*x1*/						/*x2*//*y2*/
//	gc.DrawRect(  TRect(75,10+(iListBarPosition*25),170, 30+(iListBarPosition*25) ) );
/*	gc.DrawRect(  TRect(75,10,150,30) );
	gc.DrawRect(  TRect(75,35,150,55) );
	gc.DrawRect(  TRect(75,60,150,80) );
	gc.DrawRect(  TRect(75,85,150,105) );
	gc.DrawRect(  TRect(75,110,150,130) );
*/
	gc.SetPenColor(KRgbBlack); 
	//Account List
	TSize iconSize(24, 24);
	gc.UseFont(iCoeEnv->NormalFont());
	
	

    }

CCoeControl* CMultiViewsContainer3::ComponentControl(TInt /*aIndex*/) const
    {
    return NULL;
    }

void CMultiViewsContainer3::IncListBarPosition()
{
	if ( iListBarPosition < 4 ){
		iListBarPosition ++ ;
	}

}

void CMultiViewsContainer3::DecListBarPosition()
{
    if ( iListBarPosition > 0 ){
		iListBarPosition -- ;
	}

}


TInt CMultiViewsContainer3::GetBarPosition()
{
    return iListBarPosition;
	
}
