#include "AccountList.h"
#include <e32math.h>
#include <eikenv.h>

_LIT(KNameBase,"Anonymous");
_LIT(KIPBase,"127.0.0.1");

TAccountList::TAccountList(TInt aStatus,const TDesC& aUsername,const TDesC& aIP)
{
	iUsername = aUsername;
	iIP = aIP;
	iStatus   = aStatus;

	//iRichText = CRichText::NewL(CEikonEnv::Static()->SystemParaFormatLayerL(), CEikonEnv::Static()->SystemCharFormatLayerL()); 

}
TAccountList::TAccountList()
{
	iUsername = KNameBase;
	iIP = KIPBase;
	iStatus   = 0;
}

TAccountList::~TAccountList()
{
	//delete iRichText;
}
// ----------------------------------------------------
// ----------------------------------------------------
/*TPlayerName TAccountList::GetUsername()
{
	return( iUsername );
}

TPlayerNameAccount TAccountList::GetIP()
{
	return( iIP );
}

TInt TAccountList::GetStatus()
{
	return( iStatus );
}
*/
//
//Get friend and Status
//
TInt TAccountList::GetStatus(TPlayerName& aName)
{
        aName=iUsername;
        return(iStatus);
}

void TAccountList::GetIP(TPlayerName& aName,TPlayerNameAccount& aIP)
{
	aName=iUsername;
	aIP =iIP;
}

TInt TAccountList::GetStatus(TPlayerName& aName,TPlayerNameAccount& aIP)
{
	aName=iUsername;
	aIP =iIP;
	return iStatus;
}

void TAccountList::GetLocation(TPlayerNameAccount& aLocation)
{
	aLocation = iLocation;
}

//---------------
//	RichText
//---------------
CRichText* TAccountList::GetRichText()
{
	return iRichText;
}

void TAccountList::ResetRichText(){
	iRichText->Reset();
}

void TAccountList::AppendRichText(const TDesC& aText,const TRgb& rgb,TDes16& aName){

	//iRichText = CRichText::NewL(CEikonEnv::Static()->SystemParaFormatLayerL(), CEikonEnv::Static()->SystemCharFormatLayerL()); 
	//SetColor(KRgbRed);
	SetColor(rgb);
	TInt length = iRichText->DocumentLength();
	//iRichText->InsertL(iRichText->DocumentLength(),_L("<YOU>"));
	iRichText->InsertL(iRichText->DocumentLength(),'<');
	iRichText->InsertL(iRichText->DocumentLength(),aName);
	iRichText->InsertL(iRichText->DocumentLength(),'>');
	iRichText->InsertL(iRichText->DocumentLength(), aText);
	iRichText->InsertL(iRichText->DocumentLength(), CEditableText::ELineBreak);
	iRichText->ApplyCharFormatL(iCharFormat, iCharFormatMask, length, aName.Length() + aText.Length()+2);
}
void TAccountList::AppendRichText(const TDesC& aText,const TRgb& rgb){

	//iRichText = CRichText::NewL(CEikonEnv::Static()->SystemParaFormatLayerL(), CEikonEnv::Static()->SystemCharFormatLayerL()); 
	//SetColor(KRgbRed);
	SetColor(rgb);
	TInt length = iRichText->DocumentLength();
	//iRichText->InsertL(iRichText->DocumentLength(),_L("<YOU>"));
	iRichText->InsertL(iRichText->DocumentLength(),'<');
	iRichText->InsertL(iRichText->DocumentLength(),iUsername);
	iRichText->InsertL(iRichText->DocumentLength(),'>');
	iRichText->InsertL(iRichText->DocumentLength(), aText);
	iRichText->InsertL(iRichText->DocumentLength(), CEditableText::ELineBreak);
	iRichText->ApplyCharFormatL(iCharFormat, iCharFormatMask, length, iUsername.Length()+aText.Length()+2);
}

void TAccountList::SetColor(const TRgb& rgb){
	iCharFormatMask.SetAttrib(EAttColor);
	iCharFormat.iFontPresentation.iTextColor = rgb;
}

// ----------------------------------------------------
//
// TScore Load/Save functions
//
// ----------------------------------------------------
void TAccountList::ExternalizeL(RWriteStream& aStream) const
{
	//
	// Write the score as a 32bit integer
	//
        aStream.WriteInt32L(iStatus);
        //
        // Write the name
        //
        aStream << iUsername;

		aStream << iIP;
}

void TAccountList::InternalizeL(RReadStream& aStream)
{
	//
	// Read the score
	//
        iStatus  = aStream.ReadInt32L();
        //
        // Read the name
        //
        aStream >> iUsername;

		aStream >> iIP;

}

void TAccountList::SetStatus(TInt status)
{
	iStatus = status;
}


void TAccountList::SetRichTextAvailable(TBool aBool)
{
	if(aBool){
		iRichText = CRichText::NewL(CEikonEnv::Static()->SystemParaFormatLayerL(), CEikonEnv::Static()->SystemCharFormatLayerL()); 
	}else{
		delete iRichText;
	}
	isRichTextAvailable = aBool;
}


TBool TAccountList::GetRichTextStatus(){
	return isRichTextAvailable;
}

TBool TAccountList::IsMessageIn(){
	return isMessageIn;
}


void TAccountList::SetMessageInStatus(TBool aBool){
	isMessageIn = aBool;
}

void TAccountList::SetUsername(const TDesC& aUser){
	iUsername.Copy(aUser);
}

void TAccountList::SetLocation(const TDesC& aLocation){
	iLocation.Copy(aLocation);
}
