/* Copyright (c) 2003, Nokia. All rights reserved */

#include <e32std.h>
//#include <e32des16.h>

#include "MultiViews.pan"
#include "MultiViewsAppUi.h"
#include "MultiViewsView1.h"
#include "MultiViewsView2.h"
#include "MultiViewsView3.h"

#include <avkon.rsg>
#include <Multiviews.rsg>
#include "MultiViews.hrh"

#include "MultiViewsAddAccountDialog.h"
#include "SendMessageDialog.h"

#include <avkon.hrh>
#include <aknnotewrappers.h> 
#include <eikmenup.h>
#include <caknfileselectiondialog.h> 
#include <MGFetch.h>
#include <pathinfo.h>
#include <apgcli.h>
#include <apgtask.h>
#include <apmstd.h>

#include <msvstd.h>

//Etel
#include <avkon.hrh>
#include <aknnotewrappers.h> 
#include <etel.h>
#include <etelmm.h>
#include <f32file.h>
#include <commdb.h>

#include <utf.h>
#include <stdio.h>

// System includes
//#include <aknutils.h>           // CompleteWithAppPath()
//#include <SendAppUiExample.rsg> // Resource ids
//#include <SendNorm.rsg>         // R_SENDUI_MENU
//#include <aknapp.h>             // CAknApplication
#include <miutset.h>            // KUidMsgTypeSMTP
#include <mmsconst.h>           // KUidMsgTypeMultimedia
//#include <sendui.h>             // CSendAppUi
#include <smut.h>               // KUidMsgTypeSMS
#include <stringloader.h>       // StringLoader
//#include <txtrich.h>            // CRichText

#include <aknnotedialog.h> // CAknWaitNoteWrapper

#include "AudioPlayer.h"

#include "RecordEngine.h"
#include "PlayerEngine.h"

//const TUid KMessagingUid	= { 0x100058C5 };
//const TUid KMessagingMainViewUid			= { 1 };
const TInt KDefaultGranularity = 4;
const TInt KNumberOfStepsToSaveGame(5);

_LIT(KAttachmentFileName, "Image.gif");

CMultiViewsAppUi::CMultiViewsAppUi()
	: iNaviDecorator(NULL)
    {
    // No implementation required
    }

void CMultiViewsAppUi::SetBeforeExit(){
	int i,count=iAccountTable->Count();
	for(i=0;i<count;i++){
		(&(*iAccountTable)[i])->SetRichTextAvailable(EFalse);
		(&(*iAccountTable)[i])->SetStatus(3);//set to Offline
	}
	this->SaveScoreL(iFileStoreName);
}


CMultiViewsAppUi::~CMultiViewsAppUi()
    {
		delete iAudioPlayer;
		delete iRecordEngine;
		delete iPlayerEngine;
		delete iGameSaverAO;
		delete iAccountTable;
		iFs.Close();
		
		delete iNaviDecorator;
		//SIP
		delete iSipEngine;		
		//SMS Email
		delete iSendAppUi;
		delete iRichText;
		//delay
		iTimeWaster.Close();
    }

void CMultiViewsAppUi::ConstructL()
    {

    //BaseConstructL(EAknEnableSkin);
	BaseConstructL();


	iMyName = _L("your name");
	iMyStatus = EOffline;
	
	//ChangeTitleStatus();
	
	//create CArrayFix // new first
	iAccountTable=new(ELeave)CArrayFixSeg<TAccountList>(KTableScoreSize);

	//create sip Engine
	iSipEngine = CSIPEngine::NewL(KUidMultiViewsApp,this);

   	iTimeWaster.CreateLocal();
	//ToWaitDialog();

	
	//###
	TBuf<40> name = iSipEngine->GetOwnUsername();
	name.Delete(0,4);
	TInt pos;
	pos = name.Locate('@');
	name.SetLength(pos);
	//###
	//create user folder
	iFileStoreName.Copy(KFolderStore);
	iFileStoreName.Append(name);
	iFileStoreName.Append(_L("\\"));
	iFolderName.Copy(iFileStoreName);
	iFileStoreName.Append(_L("Account.dat"));

	//
    // Connect to the file server and create the directory if needed
    //
    User::LeaveIfError(iFs.Connect());
    iFs.MkDirAll(iFileStoreName);
	
	//
	// Create file :: add account and Save to file // and Load to CArray
	//
	//
	CDir* dir = NULL;
	User::LeaveIfError(iFs.GetDir(iFolderName,KEntryAttNormal,ESortByDate,dir));

	if(dir->Count()){
		//somefile were found, get the name of the zeroth entry
	}else{
		//Nofile found
		initScoreL();
		SaveScoreL(iFileStoreName);
	
	}
	delete dir;


	this->ResetScore();
    this->LoadScoreL(iFileStoreName);

	
	//Create History Array 5
	//iRichText = new(ELeave)CArrayFixSeg<CRichText *>(KTableScoreSize);
	int i,count=iAccountTable->Count();
	for(i=0;i<count;i++){
			(&(*iAccountTable)[i])->SetRichTextAvailable(ETrue);
			(&(*iAccountTable)[i])->SetMessageInStatus(EFalse);
	}


	
	//move down
	iAppView1 = CMultiViewsView1::NewL(/*sipEngine*/iAccountTable);
    iAppView2 = CMultiViewsView2::NewL();
	iAppView3 = CMultiViewsView3::NewL();
	AddViewL(iAppView1); // Transfer ownership to base class 
    AddViewL(iAppView2); // Transfer ownership to base class 
	AddViewL(iAppView3)
		; 
    SetDefaultViewL(*iAppView1);

	//CEikStatusPane* statusPane = StatusPane();
	//statusPane->SwitchLayoutL (R_AVKON_STATUS_PANE_LAYOUT_EMPTY);

	SetupListQueryItemArrayL();

	// Construct the CSendAppUi object //for SMS EMAIL
    iSendAppUi = CSendAppUi::NewL(ECmdSendAppUiBaseCmdId);
    iSendAppUiCapabilities.iFlags = TSendingCapabilities::ESupportsBodyText;

    // Construct the CRichText object
    // This is really for convenience, as it's used throughout
    // and awkward to construct
    iRichText = CRichText::NewL(iEikonEnv->SystemParaFormatLayerL(),
                                iEikonEnv->SystemCharFormatLayerL()); 
    
	iSMyRegis=EFalse;
		//Register
	if ( iSipEngine->IsRegistered() ){
		//ToSubScribe();
		//ChangeContextStatus(ETrue);
		iSipEngine->ToStatusChange();
		SetTitleUsername();
		iSMyRegis=ETrue;

	}else{
		iSipEngine->ExecuteL();
		iSMyRegis=EFalse;
	}
	ToWaitDialog();
	//SubScribePlayer();

	iGameSaverAO = CProgressNoteGameSaverAO::NewL();
	
	iAudioPlayer = CAudioPlayer::NewL(*this);
	
	iAudioPlayer->PlayWavL(1);

	iOutputBuffer = _L16("Location Not Set");

	iRecordEngine =CRecordEngine::NewL (*this);
	iPlayerEngine =CPlayerEngine::NewL ();//*this);
    }

void CMultiViewsAppUi::HandleCommandL(TInt aCommand)
    {
    switch(aCommand)
        {
		case EMultiViewsSwitchToView3:
			//iGameSaverAO->SaveGameL();
			ActivateLocalViewL(TUid::Uid(EMultiViewsView3Id));

		break;
        case EEikCmdExit:
        case EAknSoftkeyExit:
			iMyStatus = EOffline;			
			if(iSMyRegis){
				ChangeTitleStatus();
			}
			SetBeforeExit();
			iSMyRegis = ETrue;//because it ask again
			ToWaitDialog();

            Exit();
        break;
		case EMultiViewsSwitchToView2:
			{
			//get select status
			
			TInt contactStatus;
			TInt contactID = -1;
			contactID = iAppView1->GetBarPosition();

			TPlayerNameAccount ip;
			TPlayerName name;
			contactStatus = (&(*iAccountTable)[contactID])->GetStatus(name,ip);
			//ip name
			iContactName.Copy(ip);	
			iContactRealName.Copy(name);


			//full sip name
			User::InfoPrint(iContactRealName);
			
			if(contactStatus != EOffline){
			
			ActivateLocalViewL(TUid::Uid(EMultiViewsView2Id));
			iAppView2->SetContactName(iContactName);
			iAppView2->SetRealContactName(iContactRealName);

			//copy history
			CRichText * iRichText = (&(*iAccountTable)[contactID])->GetRichText();
			iAppView2->ToAppendRichText(iRichText);
			//reset history
			//(&(*iAccountTable)[contactID])->ResetRichText();
			}else{
			//goto SMS
				CAknQueryDialog* saveGameQuery = CAknQueryDialog::NewL();	
				if (saveGameQuery->ExecuteLD(R_LISTQUERY_CONFIRMATION_QUERY)){

					SendAwakeUser();
				}
	

			}
			}
		break;
		case EMultiViewsSwitchToView1:
			{
			ActivateLocalViewL(TUid::Uid(EMultiViewsView1Id));
			TBuf16<128> contact;
			iAppView2->GetContactName(contact);
			int i,count=iAccountTable->Count();

			TPlayerName name;
			TPlayerNameAccount ip;
			for(i=0;i<count;i++) {
				(&(*iAccountTable)[i])->GetIP(name,ip);
				if(ip == contact){
					(&(*iAccountTable)[i])->SetMessageInStatus(EFalse);	
				}
			}
			
			}
		break;
		/*case EMultiViewsRegister:
			//Register SIP Server		
			iSipEngine->ExecuteL();
		break;
		case EMultiViewsSubscribe:
			//Subscribe SIP Server		
			//sipEngine->Subscribe(_L8("sip:player1@161.246.5.195"));
			ToSubScribe();
			
		break;*/
		case EStartConversation:
		{
			TInt contactStatus;
			TInt contactID = -1;
			contactID = iAppView1->GetBarPosition();

			//TPlayerNameAccount ip;
			//TPlayerName name;
			contactStatus = (&(*iAccountTable)[contactID])->GetStatus(iContactRealName,iContactName);
			//ip name
			//iContactName.Copy(ip);	
			//iContactRealName.Copy(name);
			TBuf8<60> contact;
			contact.Copy(iContactName);

			iSipEngine->Invite2(contact,ETrue);
			
			
			//iPlayerEngine->PlayStreamL ();

		}
		break;
		case EGoToFiles:
		{
			OpenUsingAknSelectionDlg();

		}
		break;
		case EGetSelectLocationString:
		{
			
			TInt contactID = -1;
			contactID = iAppView1->GetBarPosition();

			TPlayerName name;
			TPlayerNameAccount location;
			(&(*iAccountTable)[contactID])->GetIP(name,location);
			
			(&(*iAccountTable)[contactID])->GetLocation(location);

			TBuf16<60> aOutput;
			aOutput.Copy(name);
			aOutput.Append(_L(" is in "));
			aOutput.Append(location);

			CAknInformationNote* note = new (ELeave) CAknInformationNote();
			note->SetTimeout(CAknNoteDialog::ENoTimeout);
			note->ExecuteLD(aOutput);

		}
		break;
		case EGetMyLocationString:
		{
			GetLocationString();
			ChangeTitleStatus();
			
		}
		break;
		case EMultiViewsSendAwake:
		{
			/*
			TInt contactStatus;
			TInt contactID = -1;
			contactID = iAppView1->GetBarPosition();

			contactStatus = (&(*iAccountTable)[contactID])->GetStatus(iContactRealName,iContactName);
			
			SendAwakeUser();
			*/
			iPlayerEngine->LoadAMRFileL ();
			iPlayerEngine->SavePCMFileL ();
			
			iPlayerEngine->LoadAudioFileL();
			iPlayerEngine->Play();
		}
		break;
		case EMultiViewsAddContact:
			{
			CDesCArray* textArray = new (ELeave) CDesCArrayFlat(5);
				CleanupStack::PushL(textArray);

			if (CMultiviewsAddAccountDialog::RunDlgLD (iPlayerName,textArray))
			{
				TPlayerNameAccount name;
				name.Copy(iPlayerName);
				name.Delete(0,4);
				TInt pos;
				pos = name.Locate('@');
				name.SetLength(pos);

				TAccountList aAccount(3,name,iPlayerName);   

				this->AddScoreL(aAccount);
				/*this->SaveScoreL(iFileStoreName);
				ResetScore();
				LoadScoreL(iFileStoreName);
				SortArray();*/

				//XXXXXXXXXXXXX

				//SetTitleUsername();???
				
			
				//User::InfoPrint(name);
				
				//subscribe this player
				/*TBuf8<60> ip;
				ip.Copy(iPlayerName);				
				iSipEngine->Subscribe(ip);*/

				//init
				/*TPlayerName name2;
				TPlayerNameAccount aip;
				int i,count=iAccountTable->Count();
				for(i=0;i<count;i++) {
					(&(*iAccountTable)[i])->GetIP(name2,aip);
					if(aip == iPlayerName){
						(&(*iAccountTable)[i])->SetMessageInStatus(EFalse);	
					}
				}*/

				//SaveScoreL(iFileStoreName);
				//ResetScore();
				//LoadScoreL(iFileStoreName);
				//this->SortArray();
				this->SaveScoreL(iFileStoreName);
				ResetScore();
				LoadScoreL(iFileStoreName);
				SortArray();

				int i,count=iAccountTable->Count();
				for(i=0;i<count;i++){
					(&(*iAccountTable)[i])->SetRichTextAvailable(ETrue);
					(&(*iAccountTable)[i])->SetMessageInStatus(EFalse);
				}

				//subscribe this player
				TBuf8<60> ip;
				ip.Copy(iPlayerName);				
				iSipEngine->Subscribe(ip);

				
				ChangeTitleStatus();
				SetTitleUsername();
			}

			
			CleanupStack::PopAndDestroy(textArray);

			}
		break;
		case EMultiViewsSendMsg:
//iSipEngine->Message(_L8("sip:sang@161.246.5.195"),_L8("HelloWorld"));
		/*if (CSendMessageDialog::RunDlgLD (iPlayerName))
			{			

			}*/
			{
			//TBuf16<128> buf;
			TBuf16<128> sendtext;
			TBuf16<128> contact;

			iAppView2->ToGetText(sendtext);
			//totext.Copy(buf);
			
			//SEnd Message
			iAppView2->GetContactName(contact);
			//sendtext.Copy(buf);
			
			EncodeL(sendtext);
			TBuf8<256> toSendtext;
			toSendtext.Copy(iOutput8Buffer);

			//EncodeL(contact);
			TBuf8<256> toContact;
			//toContact.Copy(iOutput8Buffer);
		
			//toSendtext.Copy(sendtext);
			toContact.Copy(contact);

			ToMessage(toContact , toSendtext);//sent to another - sip message



			iAppView2->ToAppendText(sendtext,iMyName);//insert to chat

			TBuf8<256> toContactHistory;
			toContactHistory.Copy(toContact);
			toContactHistory.Delete(0,4);
			TInt pos;
			pos = toContactHistory.Locate('@');
			toContactHistory.SetLength(pos);
			

			ToHistory(toContactHistory,sendtext,KRgbBlue);//sent to history

			
			}
		break;
		case EMultiViewsDeleteContactSelect:
			{				
				TInt posbar = iAppView1->GetBarPosition();
								
				int count=iAccountTable->Count();
				count = count - 1;

				if((posbar == count)&&(posbar ==0))	{
					//alert
					
										
					CAknInformationNote* note2 = new (ELeave) CAknInformationNote();					
					note2->ExecuteLD(_L("Add another before delete"));
					
					
				}else if(posbar == count){
					iAccountTable->Delete(posbar);
					iAppView1->DecBarPosition();

				}else{

					iAccountTable->Delete(posbar);
					this->SaveScoreL(iFileStoreName);

				}

			}
		break;
		case EMultiViewsSetMyName:
			//querry dialog
/*			if (CMultiviewsAddAccountDialog::RunDlgLD (iPlayerName))
			{
				iMyName = iPlayerName;
				User::InfoPrint(iMyName);
				//SetTitleUsername();
				SaveScoreL(iFileStoreName);
			}
*/
			{
				TBuf<60>note;
				CAknTextQueryDialog* querydlg = CAknTextQueryDialog::NewL(note);		
				querydlg->SetMaxLength(note.MaxLength());
				querydlg->SetPromptL(_L("Enter Name: "));
				
				TInt retVal = querydlg->RunDlgLD(R_AVKON_DIALOG_QUERY_VALUE_TEXT);
				if( retVal){
					iMyName = note;
					SaveScoreL(iFileStoreName);
					SetTitleUsername();
				}
			}

		break;
		case ESetStatusToOnline:
			//0 = online 1=busy 2=in car 3=offline
			if(iMyStatus == EBusy ){
				iMyName.SetLength(iMyName.LocateReverse('('));
				SetTitleUsername();
			}			
			iMyStatus = EOnline;
			ChangeContextStatus(EOnline);
			ChangeTitleStatus();
			

		break;
		case ESetStatusToAppearOffline:
			if(iMyStatus == EBusy ){
				iMyName.SetLength(iMyName.LocateReverse('('));
				SetTitleUsername();
			}
			iMyStatus = EAppOffline;
			ChangeContextStatus(EOffline);
			ChangeTitleStatus();

		break;
		case ESetStatusToBusy:
			{
			if(iMyStatus == EBusy ){
				iMyName.SetLength(iMyName.LocateReverse('('));
				SetTitleUsername();
			}
			TBuf<60>note;
			CAknTextQueryDialog* querydlg = CAknTextQueryDialog::NewL(note);		
			querydlg->SetMaxLength(note.MaxLength());
			querydlg->SetPromptL(_L("Busy What?: "));
			
			TInt retVal = querydlg->RunDlgLD(R_AVKON_DIALOG_QUERY_VALUE_TEXT);
			if( retVal){
			
				iMyStatus = EBusy;
				ChangeTitleStatus();
				
				//iTextBusyWhat = iMyName;
				
				iMyName.Append('(');
				iMyName.Append(note);
				iMyName.Append(')');
				ChangeContextStatus(EBusy);
				SetTitleUsername();
			}			
			
			}

		break;
		case ESetStatusToInCar:
			if(iMyStatus == EBusy ){
				iMyName.SetLength(iMyName.LocateReverse('('));
				SetTitleUsername();
			}
			iMyStatus = EInCar;
			ChangeContextStatus(EInCar);
			ChangeTitleStatus();

		break;
		case EMultiViewsSignOut:
			{
			/*ChangeContextStatus(EFalse);
			iMyStatus = EOffline;			
			ChangeTitleStatus();*/
			
			TInt contactID = -1;
			contactID = iAppView1->GetBarPosition();

			TPlayerNameAccount ip;
			TPlayerName name;
			(&(*iAccountTable)[contactID])->GetIP(name,ip);
			//ip name
				
			//iContactName.Copy(ip);		
			//User::InfoPrint(iContactName);
			//iAppView2->SetContactName(iContactName);
			TBuf8<100> test;
			test.Copy(ip);
			iSipEngine->Invite( test );

			//sipEngine->Invite(_L8("sip:player2@161.246.5.192"));


			//
			//	Sign Out SIP
			//
		
			//test
			
			}
			
		break;
		case EMultiViewsSendPicture:
			{
				BrowseUsingMGFetchL(EImageFile);
			}			
		break;
		case EMultiViewsSendSound:
			{
				/*//Stop Record
				iRecordEngine->StopL();

				//Convert PCM16 to AMR
				//iPlayerEngine->LoadPCMFileL ();
				//iPlayerEngine->SaveAMRFileL ();

				iRecordEngine->LoadPCMFileL ();
				iRecordEngine->SaveAMRFileL ();
				//Send Amr
				BrowseRecordAmr();*/
				BrowseUsingMGFetchL(EAudioFile);
				//BrowseUsingMGFetchL(ENoMediaFile);

			}
		break;
		case EMultiViewsSendFile:
			{
				
				BrowseUsingAknSelectionDlg(   );

			}
		break;
		case EMultiViewsStartVoice:
			{
				iRecordEngine->RecordL ();
			}
		break;
		case EMultiViewsStopVoice:
			{
				iRecordEngine->StopL();
				iRecordEngine->LoadPCMFileL ();
				iRecordEngine->SaveAMRFileL ();
				BrowseRecordAmr();
			}
		break;
		case EMoIcon1:
			{

				iAppView2->ToInsertMyPictureL(EMbmMultiviewsOnline);
			}			
		break;
		case EMoIcon2:
			{
				//send text @)
				TBuf8<60> temp;
				temp.Copy(_L8("@)"));
				
				TBuf16<15> sendtext;
				TBuf16<60> contact;
				sendtext.Copy(temp);
				iAppView2->GetContactName(contact);
				TBuf8<60> toSendtext;
				TBuf8<100> toContact;
				toSendtext.Copy(sendtext);
				toContact.Copy(contact);
				ToMessage(toContact , toSendtext);//sent to another - sip message
				iAppView2->ToAppendText(sendtext,iMyName);//insert to chat
			
				TBuf8<100> toContactHistory;
				toContactHistory.Copy(toContact);
				toContactHistory.Delete(0,4);
				TInt pos;
				pos = toContactHistory.Locate('@');
				toContactHistory.SetLength(pos);
				ToHistory(toContactHistory,sendtext,KRgbBlue);//sent to history
			
			}			
		break;

		case EMultiViewsClearInput:
			{
				iAppView2->ClearInputWindow();
			}			
		break;
		case EMultiViewsClearOutput:
			{
				iAppView2->ClearOutputWindow();
			}			
		break;
        default:
			if (iAppView1->IsDisplay()){
				User::InfoPrint(_L("true"));
			}else{
				User::InfoPrint(_L("false"));
			}
			//Exit();
			//Panic(EMultiViewsBasicUi);
            break;
        }
    }

void CMultiViewsAppUi::SetTitleUsername(){
	
	ChangeTitleUsername(iMyName);
	//Noti fy to set name
	ToNotify();
}


TKeyResponse CMultiViewsAppUi::HandleKeyEventL(const TKeyEvent &aKeyEvent,
    TEventCode aType)
{

//return EKeyWasNotConsumed;	
	
if (aType==EEventKey)
  {
	  if ((aKeyEvent.iScanCode ==EStdKeyDevice3)&&(iAppView1->IsDisplay())){
		  //get select status
				
			TInt contactStatus;
			TInt contactID = -1;
			contactID = iAppView1->GetBarPosition();

			TPlayerNameAccount ip;
			TPlayerName name;
			contactStatus = (&(*iAccountTable)[contactID])->GetStatus(name,ip);
			//ip name
			iContactName.Copy(ip);	
			iContactRealName.Copy(name);


			//full sip name
			User::InfoPrint(iContactRealName);
			
			if(contactStatus != EOffline){
			
			ActivateLocalViewL(TUid::Uid(EMultiViewsView2Id));
			iAppView2->SetContactName(iContactName);
			iAppView2->SetRealContactName(iContactRealName);

			//copy history
			CRichText * iRichText = (&(*iAccountTable)[contactID])->GetRichText();
			iAppView2->ToAppendRichText(iRichText);
			//reset history
			//(&(*iAccountTable)[contactID])->ResetRichText();
			}else{
			//goto SMS
				CAknQueryDialog* saveGameQuery = CAknQueryDialog::NewL();	
				if (saveGameQuery->ExecuteLD(R_LISTQUERY_CONFIRMATION_QUERY)){

					SendAwakeUser();
				}

			}
	  }else if (iAppView2->IsDisplay()){
			//do no thing	

	  }else	if (aKeyEvent.iCode==EKeyLeftArrow){
			User::InfoPrint(_L("UIleft"));
			ActivateLocalViewL(TUid::Uid(EMultiViewsView3Id));


	  }else if (aKeyEvent.iCode==EKeyRightArrow){
			User::InfoPrint(_L("UIright"));
			ActivateLocalViewL(TUid::Uid(EMultiViewsView1Id));
			
	  }else	
	  if (iAppView1->IsDisplay()){
			iAppView1->HandleKeyEventL(aKeyEvent , aType );
			User::InfoPrint(_L("5555"));
	  }
	  else {
			
	  }
	
  }
  return EKeyWasNotConsumed;



}


void CMultiViewsAppUi::ToSubScribe(){
	
	int i,count=iAccountTable->Count();
    TPlayerName name;
	TPlayerNameAccount ip;
   
	for(i=0;i<count;i++)
    {
		(&(*iAccountTable)[i])->GetIP(name,ip);
		
		TBuf8<60> buf8;
		buf8.Copy(ip);

		iSipEngine->Subscribe(buf8);
	}
}

void CMultiViewsAppUi::ToSubScribe(const TDesC8& user){
	
	int i,count=iAccountTable->Count();
    TPlayerName name;
	TPlayerNameAccount ip;
	TInt status;

	for(i=0;i<count;i++)
    {

		status = (&(*iAccountTable)[i])->GetStatus(name,ip);
	//ip name
		
		TBuf8<60> bufname;
		bufname.Copy(name);

		TBuf8<60> bufuser;
		bufuser.Copy(user);

		if(status == EOffline ){
			if (bufname == bufuser){
				TBuf8<60> buf2;
				buf2.Copy(ip);
				iSipEngine->Subscribe(buf2);
			}
		}
	}
}

void CMultiViewsAppUi::ToNotify(const TDesC8& user){
	
	int i,count=iAccountTable->Count();
    TPlayerName name;
	TPlayerNameAccount ip;
	TInt status;

	for(i=0;i<count;i++) {
		status = (&(*iAccountTable)[i])->GetStatus(name,ip);
		//ip name
		TBuf8<60> buf;
		buf.Copy(name);

		TBuf8<60> bufuser;
		bufuser.Copy(user);

		//if user == Online then Notify :: 1 time
		if(status == EOffline ){
			if (buf == user){
				TBuf8<60> buf2;
				buf2.Copy(ip);
				iSipEngine->Notify(buf2);
			}
		}
		
	}
}

void CMultiViewsAppUi::ToNotify(){
	
	int i,count=iAccountTable->Count();
    TPlayerName name;
	TPlayerNameAccount ip;
	TInt status;

	for(i=0;i<count;i++) {
		status = (&(*iAccountTable)[i])->GetStatus(name,ip);
		//ip name
		//if(status != EOffline ){
			TBuf8<60> buf2;
			buf2.Copy(ip);
			iSipEngine->Notify(buf2);
		//}
		
	}
}
void CMultiViewsAppUi::AddScoreL(const TAccountList& aAccountList)
{
    //
    // Insert the element in the Score table 
    // (using an Integer key on iValue)
    //
    TKeyArrayFix byScore(_FOFF(TAccountList,iStatus),ECmpTInt);
    
	iAccountTable->InsertIsqAllowDuplicatesL(aAccountList,byScore);

	
	//
    // Remove the last player from the table if necessary
    // and compress the table (to free unused space)
    //
    if(iAccountTable->Count()>KTableScoreSize)
        iAccountTable->Delete(KTableScoreSize);
    iAccountTable->Compress();
}

void CMultiViewsAppUi::SortArray(){
    TKeyArrayFix byScore(_FOFF(TAccountList,iStatus),ECmpTInt);
	iAccountTable->Sort(byScore);
}

void CMultiViewsAppUi::ResetScore()
{
    iAccountTable->Delete(0,iAccountTable->Count());
}


void CMultiViewsAppUi::LoadScoreL(const TDesC& aStoreName)
{
  //
  // Create the parsed name and open the store
  //
  TParse  parsedName;
  iFs.Parse(aStoreName,parsedName);

  
  CFileStore* store = CDirectFileStore::OpenLC(iFs,parsedName.FullName(),EFileRead);

  //
  // Open the data stream inside the store
  //
  RStoreReadStream stream;
  stream.OpenLC(*store,store->Root());
  
  //
  // Load the name
  //
  stream >> iMyName;

  //SetTitleUsername();

  // 
  // Read all the data
  //
  TAccountList sc;
  TInt i,count=stream.ReadInt32L();

  for(i=0;i<count;i++)
  {
      stream >> sc;  // This will call the TScore::InternalizeL method
      iAccountTable->AppendL(sc);
  }

  // 
  // Delete all the remaining stuff on the cleanup stack
  // (store and stream)
  //
  CleanupStack::PopAndDestroy(2);
}


void CMultiViewsAppUi::SaveScoreL(const TDesC& aStoreName)
{
  //
  // Create a direct file store that will contain the score table
  // (Erase previous one) 
  //
  TParse  parsedName;
  iFs.Parse(aStoreName,parsedName);//parse

  //create an empty file store (replacing the existibg one - if any) and open it in write mode
  //(ReplaceLC()
  CFileStore* store = CDirectFileStore::ReplaceLC(iFs,parsedName.FullName(),EFileWrite);
  
  //give it the type you want. Here, I choose Direct File Store because it is the simplest choice
  //when you want to manage all the data in RAM memory rather than on the file system:
  store->SetTypeL(KDirectFileStoreLayoutUid);

  //create the data stream inside the store:
  // Create the hi-score stream
  //
  RStoreWriteStream stream;
  TStreamId id = stream.CreateLC(*store);

  //write all the data into the stream:
	
  //
  // Write the name
  //
  stream << iMyName;
	
  //SetTitleUsername();

  //
  // Write the number of score table entries in the store
  //
  TInt count= iAccountTable->Count();
  stream.WriteInt32L(count);

  //
  // Then write each entry
  //
  TInt i;
  for(i=0;i<count;i++)
  {
      stream << iAccountTable->At(i); // This will call the TScore::ExternalizeL method
  }

  //
  // Commit the changes to the stream
  //
  stream.CommitL();
  CleanupStack::PopAndDestroy();

  //
  // Set the stream in the store and commit the store
  //
  store->SetRootL(id);
  store->CommitL();
  CleanupStack::PopAndDestroy();
}

void CMultiViewsAppUi::initScoreL()
{    // port username ipstring
	//0 = online 1=busy 2=away 3=offline

	TAccountList aAccount(3,_L("player1"),_L("sip:player1@161.246.5.195")),
    anotherTAccountList2(3,_L("player2"),_L("sip:player2@161.246.5.195")),
    anotherTAccountList3(3,_L("player3") ,_L("sip:player3@161.246.5.195")),
    anotherTAccountList4(3,_L("player4") ,_L("sip:player4@161.246.5.195")),
	anotherTAccountList5(3,_L("player5") ,_L("sip:player5@161.246.5.195"));

    this->AddScoreL(aAccount);
    this->AddScoreL(anotherTAccountList2);
    this->AddScoreL(anotherTAccountList3);
    this->AddScoreL(anotherTAccountList4);
	this->AddScoreL(anotherTAccountList5);

}

void CMultiViewsAppUi::UpdateStatus(const TDesC8& aUser,TInt aStatus,const TDesC8& aName,const TDesC8& aLocation){//user = ip  name = username
	//iUser = aUser;
	User::InfoPrint(_L("Update"));
	//User::InfoPrint(aUser);
	int i,count=iAccountTable->Count();
    TPlayerName name;
	TPlayerNameAccount ip;
    for(i=0;i<count;i++)
    {
        (&(*iAccountTable)[i])->GetIP(name,ip);
		TBuf8<100> buf;
		buf.Copy(ip);
		buf.Delete(0,4);
		TInt pos;
		pos = buf.Locate('@');
		buf.SetLength(pos);

		//check if ip equal
		if(buf == aUser){
			User::InfoPrint(_L("ToUpdate"));
			//User::InfoPrint(name);
			(&(*iAccountTable)[i])->SetStatus(aStatus);
			
			TPlayerName iHisname;
			DecodeL(aName);
			iHisname.Copy(iOutput16Buffer);

			//iHisname.Copy(aName);
			(&(*iAccountTable)[i])->SetUsername(iHisname);

			TPlayerNameAccount iLocal;
			iLocal.Copy(aLocation);
			(&(*iAccountTable)[i])->SetLocation(iLocal);
			
			this->SaveScoreL(iFileStoreName);
			this->UpdateBoard();
		}
	}
}
void CMultiViewsAppUi::UpdateStatus(const TDesC8& aUser,TInt aStatus){//user = ip  name = username
	//iUser = aUser;
	User::InfoPrint(_L("Update"));
	//User::InfoPrint(aUser);
	int i,count=iAccountTable->Count();
    TPlayerName name;
	TPlayerNameAccount ip;
    for(i=0;i<count;i++)
    {
        (&(*iAccountTable)[i])->GetIP(name,ip);
		TBuf8<100> buf;
		buf.Copy(ip);
		buf.Delete(0,4);
		TInt pos;
		pos = buf.Locate('@');
		buf.SetLength(pos);

		//check if ip equal
		if(buf == aUser){
			User::InfoPrint(_L("ToUpdate"));
			//User::InfoPrint(name);
			(&(*iAccountTable)[i])->SetStatus(aStatus);
			//(&(*iAccountTable)[i])->SetUsername(aName);
			this->UpdateBoard();
		}
	}
}

void CMultiViewsAppUi::UpdateBoard(){
	this->SortArray();
	if(iAppView1->IsDisplay()){
		iAppView1->UpdateBoard();
	}
	
}


void CMultiViewsAppUi::ChangeContextStatus(TInt aStatus){
	//Change Context Picture
	TUid contextPaneUid;
	contextPaneUid.iUid = EEikStatusPaneUidContext;
	CEikStatusPane* statusPane = StatusPane();
   	CEikStatusPaneBase::TPaneCapabilities subPane =	statusPane->PaneCapabilities(contextPaneUid);
	// if we can access the context pane
	if (subPane.IsPresent() && subPane.IsAppOwned()){
    	CEikStatusPane* statusPane = StatusPane();
    	CAknContextPane* contextPane = (CAknContextPane*) statusPane->ControlL(contextPaneUid);

		if(aStatus == EOnline){
			CFbsBitmap* bitmap = iEikonEnv->CreateBitmapL(KMainPanePath, EMbmMultiviewsContext);
			CFbsBitmap* mask   = iEikonEnv->CreateBitmapL(KMainPanePath, EMbmMultiviewsContextmask);
			// set the context pane's image
			contextPane->SetPicture(bitmap,mask);
			//Change MyStatus and isOnline
			iMyStatus = EOnline;
		}else if (aStatus == EBusy){
			CFbsBitmap* bitmap = iEikonEnv->CreateBitmapL(KMainPanePath, EMbmMultiviewsContext2);
			CFbsBitmap* mask   = iEikonEnv->CreateBitmapL(KMainPanePath, EMbmMultiviewsContextmask2);
			// set the context pane's image
			contextPane->SetPicture(bitmap,mask);
			//Change MyStatus and isOnline
			//iMyStatus = EBusy;
		}else if(aStatus == EInCar){
			CFbsBitmap* bitmap = iEikonEnv->CreateBitmapL(KMainPanePath, EMbmMultiviewsContext3);
			CFbsBitmap* mask   = iEikonEnv->CreateBitmapL(KMainPanePath, EMbmMultiviewsContextmask3);
			// set the context pane's image
			contextPane->SetPicture(bitmap,mask);
			//Change MyStatus and isOnline
			//iMyStatus = EInCar;
		}else{//offline
			contextPane->SetPictureToDefaultL();
			//Change MyStatus and isOnline
			iMyStatus = EOffline;
		}
	}
	//isOnline = aIsOnline;
	ChangeTitleStatus();
}

void CMultiViewsAppUi::ChangeTitleStatus(){
	TUid naviPaneUid;
	naviPaneUid.iUid = EEikStatusPaneUidNavi;
	CEikStatusPane* statusPane = StatusPane();
   	CEikStatusPaneBase::TPaneCapabilities subPane =	statusPane->PaneCapabilities(naviPaneUid);

    // if we can access the navigation pane
	if (subPane.IsPresent() && subPane.IsAppOwned()){
		CAknNavigationControlContainer* naviPane = (CAknNavigationControlContainer *) statusPane->ControlL(naviPaneUid);
        delete iNaviDecorator;
        iNaviDecorator = NULL;

	TBuf<40> t = NULL;
	t.Append(_L("Status : "));
	/*
	_LIT16(KOnline,"Online");
	_LIT16(KOffline,"Offline");
	_LIT16(KBusy,"Busy");
	_LIT16(KAway,"Away");
	_LIT16(KAppOffline,"Appear Offline");
	*/	
    switch(iMyStatus)
        {
			case EOnline:						
				//t.Append(KOnline);
				t.Append(_L16("Online"));
			break;
			case EOffline:
				//t.Append(KOffline);
				t.Append(_L16("Offline"));
			break;
			case EBusy:
				//t.Append(KBusy);
				t.Append(_L16("Busy"));
			break;
			case EInCar:
				//t.Append(KAway);
				t.Append(_L16("Driving Car"));
			break;
			case EAppOffline:
				//t.Append(KAppOffline);
				t.Append(_L16("Appear Offline"));
			break;

			default:
				//t.Append(KOffline);
				t.Append(_L16("Appear Offline"));
			break;
        }			



	//	Notify ALL to Update Status
	ToNotify();




		HBufC* labelText = HBufC::NewL(t.Length());
		*labelText = t;

        // set the navigation pane's label
		iNaviDecorator = naviPane->CreateNavigationLabelL(*labelText);
		//CleanupStack::PopAndDestroy(labelText);
		delete labelText;

        naviPane->PushL(*iNaviDecorator);
        }

}

void CMultiViewsAppUi::ChangeTitleUsername(TDesC16& auser){
	
	TBuf<60> user;
	user.Copy(auser);
	//user.Insert(0,_L16("DGaSIP:"));

	TUid titlePaneUid;
	titlePaneUid.iUid = EEikStatusPaneUidTitle;

	CEikStatusPane* statusPane = StatusPane();

	CEikStatusPaneBase::TPaneCapabilities subPane =	statusPane->PaneCapabilities(titlePaneUid);

	// if we can access the title pane
	if (subPane.IsPresent() && subPane.IsAppOwned()){

		CAknTitlePane* titlePane = (CAknTitlePane*) statusPane->ControlL(titlePaneUid);
		
		HBufC* titleText = HBufC::NewL(user.Length());
		*titleText = user;

		titlePane->SetTextL(*titleText);
		delete titleText;
		//CleanupStack::PopAndDestroy(titleText);
	}

}

TInt CMultiViewsAppUi::GetStatus(){
	return iMyStatus;
}


void CMultiViewsAppUi::ToMessage(const TDesC8& user,const TDesC8& aMsg){

	iSipEngine->Message(user,aMsg);

}

void CMultiViewsAppUi::ReceiveMsg(const TDesC8& user,const TDesC8& msg){

	TPlayerNameAccount name;
	if(iAppView2->IsDisplay()){ 
		//get now contact
		iAppView2->GetContactName(name);
		name.Delete(0,4);
		TInt pos;
		pos = name.Locate('@');
		name.SetLength(pos);
	}
	TBuf16<15> iuser;
	iuser.Copy(user);

	if( (iAppView2->IsDisplay()) && (name == iuser) ){
		TBuf16<128> buf;
		//buf.Copy(msg);
		DecodeL(msg);
		buf.Copy(iOutput16Buffer);

		iAppView2->ToAppendTextReceive(buf);
		
		//keep history too
		ToHistory(user,buf,KRgbRed);

	}else{
				
		TBuf16<128> buf;
		//buf.Copy(msg);
		DecodeL(msg);
		buf.Copy(iOutput16Buffer);
		//keep history //All of Message
		ToHistory(user,buf,KRgbRed);
		
		iAudioPlayer->PlayWavL(2);
	}
	
}


// ----------------------------------------------------------------------------
// CMultiViewsAppUi::BrowseUsingAknSelectionDlg
// 
// Opens a new CAknFileSelectionDialog with given aPath (relative to 
// phone memory root path).
// ----------------------------------------------------------------------------
void CMultiViewsAppUi::BrowseUsingAknSelectionDlg(/*const TFileName& aPath*/)
	{
	TFileName filename;

	// Create default filename. (contains only the folder, 
	// e.g. C:\Nokia\Images\) This is used as a starting folder for browsing.
	
	//filename.Append(PathInfo::PhoneMemoryRootPath());
	
	//filename.Append(aPath);
	filename.Append(_L("c:\\Nokia\\"));

	//User::InfoPrint(aPath);

	_LIT(KDialogTitle, "Browse files");
	TBool ret = CAknFileSelectionDialog::RunDlgLD(
		filename,		// on return, contains the selected file's name
		PathInfo::PhoneMemoryRootPath(), // default root path for browsing
		KDialogTitle,	// Dialog's title
		this			// Pointer to class implementing 
						// MAknFileSelectionObserver. OkToExitL is called
						// when user has selected an file.
		);

	// "ret" is true, if user has selected a file
	if( ret )
		{
		// Open the selected file into default application
		_LIT(KQueryStr, "Transfer file?");
		if( iEikonEnv->QueryWinL(KQueryStr,filename ) )
			{
			InitFileL(filename);
			}
		}
	}


// ----------------------------------------------------------------------------
// CMultiViewsAppUi::OkToExitL
//
// Inherited from MAknFileSelectionObserver.
// Called when user selects a file from CAknFileSelectionDialog.
// ----------------------------------------------------------------------------
TBool CMultiViewsAppUi::OkToExitL (const TDesC& /*aDriveAndPath*/,
									const TEntry& /*aEntry*/)
	{
	// Return ETrue if it is OK to close the CAknFileSelectionDialog.
	return ETrue;
	}


// ----------------------------------------------------------------------------
// CMultiViewsAppUi::BrowseUsingMGFetchL
//
// Opens MGFetch dialog with given media type.
// ----------------------------------------------------------------------------
void CMultiViewsAppUi::BrowseUsingMGFetchL(TMediaFileType aMediaType)
	{
	// Create array of descriptors for the selected files
	CDesCArrayFlat* fileArray = new (ELeave) CDesCArrayFlat(5);
	CleanupStack::PushL(fileArray);

	// Open the dialog.
	TBool ret = MGFetch::RunL(
		*fileArray, // When dialog is closed, fileArray contains selected files
		aMediaType, // Displays only media files of type aMediaType
		EFalse,		// Not used in S60 2.0 (single or multiple file selection)
		this		// Pointer to class implementing MMGFetchVerifier;
					// when user has selected file(s), 
					// MMGFetchVerifier::VerifySelectionL is called.
		);

	// "ret" is true, if user has selected file(s)
	if( ret )
		{
		// Open the first selected file into default application
		_LIT(KQueryStr, "Transfer file?");
		if(iEikonEnv->QueryWinL(KQueryStr, fileArray->MdcaPoint(0)))
			{
			InitFileL(fileArray->MdcaPoint(0));
			}
		}

	CleanupStack::PopAndDestroy(); // fileArray
	}


// ----------------------------------------------------------------------------
// CMultiViewsAppUi::VerifySelectionL
// 
// Inherited from MMGFetchVerifier.
// Called when user selects file(s) from MGFetch dialog.
// ----------------------------------------------------------------------------
TBool CMultiViewsAppUi::VerifySelectionL(const MDesCArray* /*aSelectedFiles*/)
	{
	// Verify the validity of aSelectedFiles if needed.
	// Return ETrue if we accept the selected file(s), otherwise return EFalse
	return ETrue;
	}


// ----------------------------------------------------------------------------
// CMultiViewsAppUi::InitFileL
//
// Opens aFilename -file into the application that is registered to handle
// the file type.
// ----------------------------------------------------------------------------
void CMultiViewsAppUi::InitFileL(const TDesC& aFileName)
	{
    
	//Send File
	//User::InfoPrint(aFileName);
	
	//TFileName filename;
	//filename.Copy(aFileName);
	/*filename.Delete(0,filename.LocateReverse('\'));
	User::InfoPrint(filename);
	*/
	//TBuf<128> buf;
	buf.Copy(aFileName);

	//iSendFile.Copy(buf);
	
	iSipEngine->SetFilePath(buf);

	//TOInvite2 + personname

	if(iAppView1->IsDisplay()){

		TInt contactID = -1;
		contactID = iAppView1->GetBarPosition();

		TPlayerNameAccount ip;
		TPlayerName name;
		(&(*iAccountTable)[contactID])->GetIP(name,ip);

		TBuf8<100> tempip;
		tempip.Copy(ip);
		User::InfoPrint(ip);	
		iSipEngine->Invite2( tempip ,EFalse);

	}else{
		TBuf16<60> temp;
		iAppView2->GetContactName(temp);
		TBuf8<100> ipx;
		ipx.Copy(temp);
		iSipEngine->Invite2( ipx , EFalse);

	}

	
	/*
	TDataType type;
    RApaLsSession appArcSession;

	// connect to AppArc server
    User::LeaveIfError(appArcSession.Connect());

	// Find the UID of the application that is registered to the MIME type of
	// the file (aFileName).
    TUid aUid;
    appArcSession.AppForDocument(aFileName, aUid, type);
    if (aUid != TUid::Uid(0) )
		{
		// Application found that could handle the file. Now we need to find
		// out from task list if the application is already running.
        TApaTaskList taskList( iEikonEnv->WsSession() );
        TApaTask task = taskList.FindApp( aUid );
        if ( task.Exists() )
			{
			// Application is already running. Requests the task to close its 
			// existing document and open a new one.
			task.BringToForeground();
			task.SwitchOpenFile( aFileName );
			}
			else
			{
			// Application is not running; start it with a new document
            TThreadId id;
            appArcSession.StartDocument( aFileName, type, id );
			}
		} else {
		// Cannot find application that could handle the file.
		_LIT(KCannotOpenFile,
			"Cannot open file. No application found to handle the file.");
		iEikonEnv->InfoWinL(KCannotOpenFile,aFileName);
		}

    appArcSession.Close();

  */
	}

// ----------------------------------------------------------------------------
// CMultiViewsAppUi::OpenUsingAknSelectionDlg
// 
// Opens a new CAknFileSelectionDialog with given aPath (relative to 
// phone memory root path).
// ----------------------------------------------------------------------------
void CMultiViewsAppUi::OpenUsingAknSelectionDlg(/*const TFileName& aPath*/)
	{
	TFileName filename;

	// Create default filename. (contains only the folder, 
	// e.g. C:\Nokia\Images\) This is used as a starting folder for browsing.
	
	//filename.Append(PathInfo::PhoneMemoryRootPath());
	
	//filename.Append(aPath);
	filename.Append(_L("c:\\Nokia\\"));

	//User::InfoPrint(aPath);

	_LIT(KDialogTitle, "Browse files");
	TBool ret = CAknFileSelectionDialog::RunDlgLD(
		filename,		// on return, contains the selected file's name
		PathInfo::PhoneMemoryRootPath(), // default root path for browsing
		KDialogTitle,	// Dialog's title
		this			// Pointer to class implementing 
						// MAknFileSelectionObserver. OkToExitL is called
						// when user has selected an file.
		);

	// "ret" is true, if user has selected a file
	if( ret )
		{
		// Open the selected file into default application
		_LIT(KQueryStr, "View file?");
		if( iEikonEnv->QueryWinL(KQueryStr,filename ) )
			{
			ViewFileL(filename);
			}
		}
	}

// ----------------------------------------------------------------------------
// CFileFetcherAppUi::ViewFileL
//
// Opens aFilename -file into the application that is registered to handle
// the file type.
// ----------------------------------------------------------------------------
void CMultiViewsAppUi::ViewFileL(const TDesC& aFileName) //const
	{
    TDataType type;
    RApaLsSession appArcSession;

	// connect to AppArc server
    User::LeaveIfError(appArcSession.Connect());

	// Find the UID of the application that is registered to the MIME type of
	// the file (aFileName).
    TUid aUid;
    appArcSession.AppForDocument(aFileName, aUid, type);
    if (aUid != TUid::Uid(0) )
		{
		// Application found that could handle the file. Now we need to find
		// out from task list if the application is already running.
        TApaTaskList taskList( iEikonEnv->WsSession() );
        TApaTask task = taskList.FindApp( aUid );
        if ( task.Exists() )
			{
			// Application is already running. Requests the task to close its 
			// existing document and open a new one.
			task.BringToForeground();
			task.SwitchOpenFile( aFileName );
			}
			else
			{
			// Application is not running; start it with a new document
            TThreadId id;
            appArcSession.StartDocument( aFileName, type, id );
			}
		} else {
		// Cannot find application that could handle the file.
		_LIT(KCannotOpenFile,
			"Cannot open file. No application found to handle the file.");
		iEikonEnv->InfoWinL(KCannotOpenFile,aFileName);
		}

    appArcSession.Close();
	}

void CMultiViewsAppUi::ToHistory(const TDesC8& user,const TDesC16& msg,const TRgb& rgb){
	//keep history //All of Message

	TPlayerName sipname;
	TPlayerNameAccount ip;
	int i,count=iAccountTable->Count();

	for(i=0;i<count;i++)
	{
		(&(*iAccountTable)[i])->GetIP(sipname,ip);
	
		TBuf8<100> buf;
		buf.Copy(ip);
		buf.Delete(0,4);
		TInt pos;
		pos = buf.Locate('@');
		buf.SetLength(pos);
		
		if(buf == user){
			User::InfoPrint(_L("History"));

			if(rgb == KRgbBlue){
				(&(*iAccountTable)[i])->AppendRichText(msg,rgb,iMyName);
			}else{
				(&(*iAccountTable)[i])->AppendRichText(msg,rgb);
			}


			//(&(*iAccountTable)[i])->SetStatus(EAway);//set to talk icon //away test
			(&(*iAccountTable)[i])->SetMessageInStatus(ETrue);
			this->UpdateBoard();
		}
	}

}


void CMultiViewsAppUi::SendAwakeUser()
{
	
		TInt index(0); // the index of the selected item
		CAknListQueryDialog* query = new (ELeave) CAknListQueryDialog(&index);
		query->PrepareLC(R_LISTQUERY_LIST_QUERY);
		query->SetItemTextArray(iListQueryItemArray);	
		query->SetOwnershipType (ELbmDoesNotOwnItemArray); // keep ownership of the item array. Only call this after setting the item array!
		if (query->RunLD()){
			//SaveGameToFileL((*iListQueryItemArray)[index]); // use the name of the currently selected item as the file name. 
			if(index == 0){
				//Email
				CreateEmailL();
			}else if(index==1){
				//SMS
				CreateSMSL();
			}else {
				
				CreateMMSL();
			}

		}
}
	

/**
* Called on construction. Instantiates the list query item array and populates
* it with appropriate list items. This method merely creates some list items dynamically, and adds them
* to the array.  In a real-world application, it is likely that the 
* items would be read from a file   
*/
void CMultiViewsAppUi::SetupListQueryItemArrayL()
	{
	iListQueryItemArray =  new (ELeave) CDesCArrayFlat(2);
	/*_LIT (KStringHeader, "Saved Game %d");
	TBuf <16> aString;
	for (TInt i = 1; i<= KMaxSavedGames; i++)
		{
		aString.Format(KStringHeader(), i);
		iListQueryItemArray->AppendL (aString);
		}
		*/
	iListQueryItemArray->AppendL (_L16("Send Email"));
	iListQueryItemArray->AppendL (_L16("Send SMS"));
	iListQueryItemArray->AppendL (_L16("Send MMS - Email"));

	}



/**
* Creates an SMS. The SMS editor is displayed with some body text and
* addresses already inserted. 
*/
void CMultiViewsAppUi::CreateSMSL()
    {
    /*__ASSERT_DEBUG(iRichText && iRichText->DocumentLength() == 0,
                   Panic(ERichTextNotReady));*/

    CDesCArrayFlat* addressArray = new (ELeave) CDesCArrayFlat(KDefaultGranularity);
    CleanupStack::PushL(addressArray);
    
	//HBufC* string = StringLoader::LoadLC(R_SMS_ADDRESS1);

	//HBufC* string = HBufC::NewL(iContactName.Length());
	iContactName.Delete(0,5);
	iContactName.SetLength(iContactName.Locate('@'));
	HBufC* string = HBufC::NewL(iContactName.Length());
	*string = iContactName;		

    addressArray->AppendL(*string);
    //CleanupStack::PopAndDestroy(string);
	delete string;
    string = NULL;
	
	// insert text into the message body
    /*HBufC**/ string = StringLoader::LoadLC(R_SMS_BODY_TEXT);
    iRichText->InsertL(0, *string);
    CleanupStack::PopAndDestroy(string);
    string = NULL;

	// display the SMS editor with some text and addresses already inserted
    iSendAppUi->CreateAndSendMessageL(KUidMsgTypeSMS, iRichText, NULL,
                                      KNullUid, addressArray, NULL, EFalse);
    iRichText->Reset();

	CleanupStack::PopAndDestroy(addressArray);
    }

/**
* Creates an email. The email editor is displayed with some body text, addresses
* and an attachment already inserted. 
*/
void CMultiViewsAppUi::CreateEmailL()
    {
    // create an array for addresses and add two to it
    CDesCArrayFlat* addressArray = new (ELeave) CDesCArrayFlat(KDefaultGranularity);
    CleanupStack::PushL(addressArray);

    //HBufC* string = StringLoader::LoadLC(R_EMAIL_ADDRESS1);
	iContactName.Delete(0,4);
	TInt pos = iContactName.Locate('@');
	iContactName.SetLength( pos+1 );
	iContactName.Append(_L16("mail.dtac.co.th"));

	HBufC* string = HBufC::NewL(iContactName.Length());
	*string = iContactName;
    addressArray->AppendL(*string);
    //CleanupStack::PopAndDestroy(string);
	delete string;
    string = NULL;

    /*string = StringLoader::LoadLC(R_EMAIL_ADDRESS2);
    addressArray->AppendL(*string);
    CleanupStack::PopAndDestroy(string);*/
	
	string = StringLoader::LoadLC(R_SMS_BODY_TEXT);
    iRichText->InsertL(0, *string);
	CleanupStack::PopAndDestroy(string);
	string = NULL;
	
    //CDesCArrayFlat* attachmentArray = new (ELeave) CDesCArrayFlat(KDefaultGranularity);
    //CleanupStack::PushL(attachmentArray);

    // Add the first attachment
    //TFileName attachmentName(KAttachmentFileName);
    //User::LeaveIfError(CompleteWithAppPath(attachmentName));
    //attachmentArray->AppendL(attachmentName);

    // Display the email editor with addresses already inserted
    iSendAppUi->CreateAndSendMessageL(KUidMsgTypeSMTP, iRichText, NULL,
        KNullUid, addressArray, NULL, ETrue);

	iRichText->Reset();

    CleanupStack::PopAndDestroy(addressArray);
    }

/**
* Creates an MMS. The MMS editor is displayed with some body text, addresses
* and an attachment already inserted. 
*/
void CMultiViewsAppUi::CreateMMSL()
    {
    // Declare string for reading resources into
    //HBufC* string = NULL;

	CDesCArrayFlat* addressArray = new (ELeave) CDesCArrayFlat(KDefaultGranularity);
    CleanupStack::PushL(addressArray);

    //HBufC* string = StringLoader::LoadLC(R_EMAIL_ADDRESS1);
	iContactName.Delete(0,4);
	TInt pos = iContactName.Locate('@');
	iContactName.SetLength( pos+1 );
	iContactName.Append(_L16("mail.dtac.co.th"));

	HBufC* string = HBufC::NewL(iContactName.Length());
	*string = iContactName;
    addressArray->AppendL(*string);
    //CleanupStack::PopAndDestroy(string);
	delete string;
    string = NULL;

	// Create an array for attachments and add one file to it
    CDesCArrayFlat* attachmentArray = new (ELeave) CDesCArrayFlat(KDefaultGranularity);
    CleanupStack::PushL(attachmentArray);

    // Add the first attachment
    TFileName attachmentName(KAttachmentFileName);
    User::LeaveIfError(CompleteWithAppPath(attachmentName));
    attachmentArray->AppendL(attachmentName);

    // create an array for aliases and add one to it. This will replace the
    // first MMS address in the MMS editor
    CDesCArrayFlat* aliasArray = new(ELeave) CDesCArrayFlat(KDefaultGranularity);
    CleanupStack::PushL(aliasArray);

    string = StringLoader::LoadLC(R_SMS_BODY_TEXT);
    aliasArray->AppendL(*string);
    CleanupStack::PopAndDestroy(string);
    string = NULL;

    // display the MMS editor with attachment and aliases already inserted
    iSendAppUi->CreateAndSendMessageL(KUidMsgTypeMultimedia, NULL, attachmentArray,
                                      KNullUid, addressArray, addressArray, ETrue);

    //CleanupStack::PopAndDestroy(2, attachmentArray); // aliasArray, attachmentArray
	CleanupStack::PopAndDestroy(3);
	
    }

/**
* Called by the AppUi when the Save Game command is invoked. 
* Constructs and executes the wait note wrapper. If the user cancels the note,
* it cancels the game save processing.
*/
void CMultiViewsAppUi::ToWaitDialog()
	{
	CAknWaitNoteWrapper* waitNoteWrapper = CAknWaitNoteWrapper::NewL();
	CleanupStack::PushL(reinterpret_cast<CBase*>(waitNoteWrapper)); // Required reinterpret_cast as CAknWaitNoteWrapper inherits privately from CActive
	if (! waitNoteWrapper->ExecuteL(R_WAITNOTE_SAVING_GAME_NOTE, *this)) // this is a blocking call, remember the wrapper isn't a dialog, so it doesn't need the EEikDialogFlagWait flag to make it blocking 
		CancelGameSave();
	CleanupStack::PopAndDestroy(waitNoteWrapper);
	}
/**
* Called by the wait note wrapper when the note is dismissed. 
* This is as a result of either the user cancelling the note,
* or the process finishing.
*/
void CMultiViewsAppUi::DialogDismissedL(TInt /*aButtonId*/)
	{	
	}

/**
* Called by the wait note wrapper following StepL. Unless the user has cancelled the note, 
* if this returns EFalse, it will call StepL again, otherwise, it will call ProcessFinished.
* @return ETrue if processing is complete, EFalse otherwise
*/
TBool CMultiViewsAppUi::IsProcessDone() const
	{
	return (iStepsCompleted == KNumberOfStepsToSaveGame);
	}

/**
* Called by the wait note wrapper if the process is complete or if the user cancelled the note.
* Completes the game save and resets the steps completed counter.
*/
void CMultiViewsAppUi::ProcessFinished()
	{
		CompleteGameSave();
		iStepsCompleted = 0;

		if(iSMyRegis){
			iSMyRegis=ETrue;
		}else{
			//iSMyRegis=ETrue;
			RegisFail();
			//ToWaitDialog();
		}
	}

/**
* Called by the wait note wrapper if the processing is not yet complete. 
* Completes a step in the processing, by saving part of the game to a file, and incrementing the
* number of steps completed. This is a synchronous method.
*/
void CMultiViewsAppUi::StepL()
	{
	SaveGamePartToFile();

	// Note that we have completed a step
	iStepsCompleted++;
	}

/**
* Dummy method which could be used to cancel a partially saved game, e.g.
* by resetting values and deleting the partially created file.
*/
void CMultiViewsAppUi::CancelGameSave()
	{
	}

/**
* Dummy method which could be used to save part of a game to a file
* In this example, it runs a timer for an arbitrary period of time
* to simulate saving part of the game. This is a synchronous method.
*/
void CMultiViewsAppUi::SaveGamePartToFile ()
	{
	// Use an arbitrary delay to simulate saving part of the game
	TRequestStatus status;
	TInt delay = 1000000; // 1 second
	iTimeWaster.After(status, delay);
	User::WaitForRequest(status); 
	}

/**
* Dummy method which could be used to complete the game saving process, e.g. by closing
* the saved game file.
* In this example it stops the timer used to simulate a game save.
*/
void CMultiViewsAppUi::CompleteGameSave()
	{
	iTimeWaster.Cancel();

	

	}


void CMultiViewsAppUi::GetMyName(TDes &aMyname){
	aMyname = iMyName;
}

void CMultiViewsAppUi::GetMyLocation(TDes &aMyLocate){
	aMyLocate = iOutputBuffer;
}

void CMultiViewsAppUi::RegisFail(){

	CAknQueryDialog* regisfailQuery = CAknQueryDialog::NewL();
	if (regisfailQuery->ExecuteLD(R_REGISTERFAIL_CONFIRMATION_QUERY)){
		
		iSipEngine->ExecuteL();
		ToWaitDialog();
	}else{


	}
}

void CMultiViewsAppUi::GetLocationString(){
	
	RTelServer iServer;
	RMobilePhone iPhone;
	RTelServer::TPhoneInfo iPhoneInfo;

	TRequestStatus iReqStatus;
	RMobileBroadcastMessaging iBroadcastMsg;

	//GSM CBM's length is 88 bytes
	TBuf8<88> iGsmMsgdata;
	_LIT(KGsmModuleName, "phonetsy.tsy");
	iServer.Connect();
	iServer.LoadPhoneModule( KGsmModuleName );
	TInt enumphone;
	User::LeaveIfError(iServer.EnumeratePhones(enumphone));
	
	if (enumphone < 1) {
		User::Leave(KErrNotFound);
	}

	//Initialise the phone object
	User::LeaveIfError(iServer.GetPhoneInfo(0, iPhoneInfo));
	User::LeaveIfError(iPhone.Open(iServer, iPhoneInfo.iName));
	iBroadcastMsg.Open(iPhone);
	RMobileBroadcastMessaging::TMobileBroadcastAttributesV1 iAttrInfo;
	TPckg<RMobileBroadcastMessaging::TMobileBroadcastAttributesV1> iDes(iAttrInfo);

	//Wait for the CBM
	iBroadcastMsg.ReceiveMessage(iReqStatus,iGsmMsgdata,iDes);
	User::WaitForRequest(iReqStatus);

	//TBuf16<88> tbuff;
	//tbuff.Copy(iGsmMsgdata);
	//User::InfoPrint(tbuff);

	//iShowMessage.Copy(tbuff);
	//iOutputBuffer.Copy(_L16("TEST"));

    //CAknConfirmationNote* confirmationNote = new (ELeave) CAknConfirmationNote;
	//confirmationNote->ExecuteLD(iShowMessage);


	if(iReqStatus.Int()==KErrNone){


		//DecodeL(iGsmMsgdata);
	
		//TBuf16<100> tbufff;
		//tbufff.Copy(iOutputBuffer);
		//User::InfoPrint(iOutputBuffer);

		//CAknConfirmationNote* confirmationNote = new (ELeave) CAknConfirmationNote;
		//confirmationNote->ExecuteLD(iOutputBuffer);

		//show the CBM retrieved
		//first write the 88 bytes of CBm into a file

		//I am doing this as I will be using C
		//code to decode the data
		RFs fs;
		fs.Connect();
		RFile file;
		TBuf<32> aFileName = _L("C:\\log.txt");
		fs.Delete(aFileName);
		file.Replace(fs,aFileName,EFileWrite);
		file.Write(iGsmMsgdata);
		file.Close();
		fs.Close();
		
		//here starts the decoding code
		//Credits : Vikram K.
		FILE* fp;
		fp = fopen("c:\\log.txt","rb");
		char locationString[94];
		char cbuf;
		int char_cnt=0;
		unsigned int bb = 0;
		
		//8-bit to 7-bit conversion
		unsigned char ur,curr,prev = 0;
		int cnt = 0;
		
		for(cnt = 0;cnt <6;cnt++)
			fread(&cbuf,1,1,fp);
		
		while(fread(&cbuf,1,1,fp)) {
			unsigned char aa = (1 << (7 - bb%7)) - 1;
			ur = cbuf & aa;
			ur = (ur << (bb)) | prev;
			curr = cbuf & (0xff ^ aa);
			curr = curr >> (7 - bb);
			prev = curr;

			if(ur == 0xd)
			{
				break;
			}

			locationString[char_cnt] = ur;
			bb = ++bb % 7;

			char_cnt++;
			if(bb==0)
			{
				locationString[char_cnt++] = prev;
				prev =0;
			}
		}
	
		locationString[char_cnt] = '\0';
		fclose(fp);

		//decoding ends here now just
		//convert the C string to TBuf (Symbian format)
		int len=0;
		while(locationString[len] != NULL)
			len++;
		
		// Create empty descriptor
		HBufC* nameHeap = HBufC::NewLC(len);
		TPtr namePtr(nameHeap->Des());
		
		// Copy contents
		for(int i=0; i<len; i++)
			namePtr.Append((TChar)locationString[i]);
		
		//now you have the location string
		//do whatever you want here..
		// Pop descriptor from cleanup stack
		
		iOutputBuffer = namePtr;
		CAknInformationNote* note2 = new (ELeave) CAknInformationNote();
		note2->SetTimeout(CAknNoteDialog::ENoTimeout);
		note2->ExecuteLD(namePtr);

		CleanupStack::PopAndDestroy(nameHeap);
//	}
	}
	else{//panic
	}
	
	iBroadcastMsg.Close();
	iPhone.Close();
	iServer.UnloadPhoneModule( KGsmModuleName );

	iServer.Close();
	
}

void CMultiViewsAppUi::DecodeL(const TDesC8& aUtf7)
    {

	iOutput16Buffer.Copy(_L(""));

    // Create a small output buffer
    TBuf16<20> outputBuffer;
    // Create a buffer for the unconverted text - initialised with the input text
    TPtrC8 remainderOfUtf7(aUtf7);

    // Create a "state" variable and initialise it with CnvUtfConverter::KStateDefault
    // After initialisation the state variable must not be tampered with.
    // Simply pass into each subsequent call of ConvertToUnicodeFromUtf7()
    TInt state=CnvUtfConverter::KStateDefault;

	for(;;) // conversion loop
        {
        // Start conversion. When the output buffer is full, return the 
        // number of characters that were not converted
        const TInt returnValue=CnvUtfConverter::ConvertToUnicodeFromUtf7(outputBuffer,remainderOfUtf7,state);

        // check to see that the descriptor isn't corrupt - leave if it is
        if (returnValue==CnvUtfConverter::EErrorIllFormedInput)
            User::Leave(KErrCorrupt);
        else if (returnValue<0) // future-proof against "TError" expanding
            User::Leave(KErrGeneral);

        // Do something here to store the contents of the output buffer.
		iOutput16Buffer.Append(outputBuffer);

        // Finish conversion if there are no unconverted characters in the remainder buffer
        if (returnValue==0)
            break; 

        // Remove the converted source text from the remainder buffer.
        // The remainder buffer is then fed back into loop
        remainderOfUtf7.Set(remainderOfUtf7.Right(returnValue));
        }
    }



void CMultiViewsAppUi::EncodeL(const TDesC16& aUnicodeText)
    {

	iOutput8Buffer.Copy(_L(""));

    // Create a small output buffer
    TBuf8<20> outputBuffer;
    // Create a buffer for the unconverted text - initialised with the input text
    TPtrC16 remainderOfUnicodeText(aUnicodeText);

	for(;;) // conversion loop
        {
        // Start conversion. When the output buffer is full, return the 
        // number of characters that were not converted
        const TInt returnValue=CnvUtfConverter::ConvertFromUnicodeToUtf7(outputBuffer, 
                                remainderOfUnicodeText, ETrue);

        // check to see that the descriptor isn�t corrupt - leave if it is
        if (returnValue==CnvUtfConverter::EErrorIllFormedInput)
            User::Leave(KErrCorrupt);
        else if (returnValue<0) // future-proof against "TError" expanding
            User::Leave(KErrGeneral);

        // Do something here to store the contents of the output buffer.
		iOutput8Buffer.Append(outputBuffer);


        // Finish conversion if there are no unconverted characters in the remainder buffer
        if (returnValue==0)
            break; 

        // Remove the converted source text from the remainder buffer.
        // The remainder buffer is then fed back into loop
        remainderOfUnicodeText.Set(remainderOfUnicodeText.Right(returnValue));
        }
    }

void CMultiViewsAppUi::GetBuf16(TDes16& aOutput16){
	aOutput16.Copy(iOutput16Buffer);
}

void CMultiViewsAppUi::GetBuf8(TDes8& aOutput8){
	aOutput8.Copy(iOutput8Buffer);
}

void CMultiViewsAppUi::SetIsRegis(TBool isRegis){
	iSMyRegis = isRegis;
}


void CMultiViewsAppUi::BrowseRecordAmr()
{
	TFileName filename;
	filename.Append(_L("c:\\System\\apps\\sound\\record.amr"));
	InitFileL(filename);
}
