/* Copyright (c) 2003, Nokia. All rights reserved */

#include "MultiViewsContainer1.h"

CMultiViewsContainer1* CMultiViewsContainer1::NewL(const TRect& aRect,
												   CArrayFixSeg<TAccountList> *aAccountTable)
    {
    CMultiViewsContainer1* self = CMultiViewsContainer1::NewLC(aRect,aAccountTable);
    CleanupStack::Pop(self);
    return self;
    }

CMultiViewsContainer1* CMultiViewsContainer1::NewLC(const TRect& aRect,
													CArrayFixSeg<TAccountList> *aAccountTable)
    {
    CMultiViewsContainer1* self = new (ELeave) CMultiViewsContainer1(aAccountTable);
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    return self;
    }

CMultiViewsContainer1::~CMultiViewsContainer1()
	{	
	delete iBitmap;
	delete iBitmapBusy;
	delete iBitmapOnline;
	delete iBitmapOffline;
	delete iBitmapAway;
	
	}

CMultiViewsContainer1::CMultiViewsContainer1(CArrayFixSeg<TAccountList> *aAccountTable)
	{
		iAccountTable = aAccountTable;
	}


void CMultiViewsContainer1::ConstructL(const TRect& aRect)
    {
	//Load Bitmap
	iBitmap = new (ELeave) CFbsBitmap();
	iBitmapBusy = new (ELeave) CFbsBitmap();
	iBitmapOnline = new (ELeave) CFbsBitmap();
	iBitmapOffline = new (ELeave) CFbsBitmap();
	iBitmapAway = new (ELeave) CFbsBitmap();
	iBitmapAlert= new (ELeave) CFbsBitmap();
	//get mbm format
	TFileName bitmapFile (KMainPanePath);
	User::LeaveIfError (CompleteWithAppPath (bitmapFile));

	User::LeaveIfError(iBitmap->Load(bitmapFile, EMbmMultiviewsMain));
	User::LeaveIfError(iBitmapBusy->Load(bitmapFile, EMbmMultiviewsBusy));
	User::LeaveIfError(iBitmapOnline->Load(bitmapFile, EMbmMultiviewsOnline));
	User::LeaveIfError(iBitmapOffline->Load(bitmapFile, EMbmMultiviewsOffline));
	User::LeaveIfError(iBitmapAway->Load(bitmapFile, EMbmMultiviewsAway));
	User::LeaveIfError(iBitmapAlert->Load(bitmapFile, EMbmMultiviewsWait));

	iListBarPosition = 0;

    CreateWindowL();
    SetRect(aRect);
    ActivateL();
    }

TInt CMultiViewsContainer1::CountComponentControls() const
    {
    return 0;
    }

void CMultiViewsContainer1::Draw(const TRect& aRect) const
    {    
    CWindowGc& gc = SystemGc();
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    //gc.SetBrushColor(KRgbBlue);
    //gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);

	//draw background
	TPoint topLeft(KTopLeftX, KTopLeftY);
	TSize bitmapSize(KSizeWidth, KSizeHeight);
	gc.DrawBitmap(TRect(topLeft, bitmapSize), iBitmap);	
	

	//draw List's Bar
	gc.SetPenColor(KRgbBlue); 
	gc.SetPenStyle(CGraphicsContext::ESolidPen); // make pen solid
						/*x1*/						/*x2*//*y2*/
	gc.DrawRect(  TRect(75,10+(iListBarPosition*25),170, 30+(iListBarPosition*25) ) );
/*	gc.DrawRect(  TRect(75,10,150,30) );
	gc.DrawRect(  TRect(75,35,150,55) );
	gc.DrawRect(  TRect(75,60,150,80) );
	gc.DrawRect(  TRect(75,85,150,105) );
	gc.DrawRect(  TRect(75,110,150,130) );
*/
	gc.SetPenColor(KRgbBlack); 
	//Account List
	TSize iconSize(24, 24);
	gc.UseFont(iCoeEnv->NormalFont());
	
	


	int status,i,count=iAccountTable->Count();
    TPlayerName name;
    for(i=0;i<count;i++)
    {
        status=(&(*iAccountTable)[i])->GetStatus(name);

		gc.DrawText(name, TPoint(80,(25*(i+1))));//+35+5   //20+10-5
		
		if( (&(*iAccountTable)[i])->IsMessageIn()  ){
			gc.DrawBitmap(TRect(TPoint(45, 5+(25*i)), iconSize), iBitmapAlert);
		}else if(status == 0){
			gc.DrawBitmap(TRect(TPoint(45, 5+(25*i)), iconSize), iBitmapOnline);	
		}else if(status == 3){
			gc.DrawBitmap(TRect(TPoint(45, 5+(25*i)), iconSize), iBitmapOffline);	

		}else if(status == 1){
			gc.DrawBitmap(TRect(TPoint(45, 5+(25*i)), iconSize), iBitmapBusy);	

		}else if(status == 2){
			gc.DrawBitmap(TRect(TPoint(45, 5+(25*i)), iconSize), iBitmapAway);	

		}
	}

    }

CCoeControl* CMultiViewsContainer1::ComponentControl(TInt /*aIndex*/) const
    {
    return NULL;
    }

void CMultiViewsContainer1::IncListBarPosition()
{
	int count=iAccountTable->Count();

	if ((iListBarPosition < 4) && (iListBarPosition < count-1)){
		iListBarPosition ++ ;
	}

}

void CMultiViewsContainer1::DecListBarPosition()
{
	if ( iListBarPosition > 0 ){
		iListBarPosition -- ;
	}

}


TInt CMultiViewsContainer1::GetBarPosition()
{
    return iListBarPosition;
	
}
