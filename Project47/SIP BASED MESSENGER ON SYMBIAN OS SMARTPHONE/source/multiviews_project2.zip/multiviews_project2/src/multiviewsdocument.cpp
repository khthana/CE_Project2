/* Copyright (c) 2003, Nokia. All rights reserved */

#include "MultiViewsAppUi.h"
#include "MultiViewsDocument.h"


CMultiViewsDocument* CMultiViewsDocument::NewL(CEikApplication& aApp)
    {
    CMultiViewsDocument* self = NewLC(aApp);
    CleanupStack::Pop(self);
    return self;
    }

CMultiViewsDocument* CMultiViewsDocument::NewLC(CEikApplication& aApp)
    {
    CMultiViewsDocument* self = new (ELeave) CMultiViewsDocument(aApp);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

void CMultiViewsDocument::ConstructL()
    {
    // No implementation required
    }    

CMultiViewsDocument::CMultiViewsDocument(CEikApplication& aApp) : CAknDocument(aApp) 
    {
    // No implementation required
    }   

CMultiViewsDocument::~CMultiViewsDocument()
    {
    // No implementation required
    }

CEikAppUi* CMultiViewsDocument::CreateAppUiL()
    {
    // Create the application user interface, and return a pointer to it
	return(static_cast<CEikAppUi*>(new (ELeave) CMultiViewsAppUi));
    }

