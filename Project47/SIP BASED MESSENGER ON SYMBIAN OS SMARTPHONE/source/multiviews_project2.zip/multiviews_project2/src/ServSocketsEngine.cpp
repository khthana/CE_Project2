/*
* ==============================================================================
*  Name        : ServSocketsEngine.cpp
*  Part of     : CommunicationChannel
*  Description : Implementation of CServSocketsEngine class
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/

#include <eikgted.h>
#include "ServSocketsEngine.h"
#include "SocketsEngine.h"
#include "SocketsRead.h"
#include "SocketsWrite.h"
//#include "Sockets.pan"
#include <GameLogger.h>

//class CMessageServiceAdvertiser;

_LIT(KDefaultServerName, "127.0.0.1");

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::NewL
***
***  DESCRIPTION	N/A
***
***  INPUT			CSocketsEngine* eng
***					MSocketsEngineObserver& aObserver
***
***  RETURN			CServSocketsEngine*
***
***************************************************************************************
**************************************************************************************/
CServSocketsEngine* CServSocketsEngine::NewL(CSocketsEngine* eng,MSocketsEngineObserver& aObserver)
{
//	LOG_METHOD(_L("CServSocketsEngine::NewL"));
	CServSocketsEngine* self = CServSocketsEngine::NewLC(eng,aObserver);
	CleanupStack::Pop();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::NewLC
***
***  DESCRIPTION	N/A
***
***  INPUT			CSocketsEngine* eng
***					MSocketsEngineObserver& aObserver
***
***  RETURN			CServSocketsEngine*
***
***************************************************************************************
**************************************************************************************/
CServSocketsEngine* CServSocketsEngine::NewLC(CSocketsEngine* eng,MSocketsEngineObserver& aObserver)
{
	CServSocketsEngine* self = new (ELeave) CServSocketsEngine(eng,aObserver);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::CServSocketsEngine
***
***  DESCRIPTION	N/A
***
***  INPUT			CSocketsEngine* eng
***					MSocketsEngineObserver& aObserver
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CServSocketsEngine::CServSocketsEngine(CSocketsEngine* eng,MSocketsEngineObserver& aObserver)
: CActive(EPriorityStandard),
  iServerName(KDefaultServerName),
  iSocketEngine(eng),
  iObserver(aObserver)
{
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::~CServSocketsEngine
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CServSocketsEngine::~CServSocketsEngine()
{
	//LOG_METHOD(_L("CServSocketsEngine::~CServSocketsEngine"));
	Cancel();

///
	//iSocketServ.Close();
///
	iListenSocket.Close();

	//WRITE_LOG_FORMAT(_L("iEngineStatus %d"), iEngineStatus);

	if (iEngineStatus == EConnecting)
		iAcceptedSocket.Close();
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::ConstructL
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::ConstructL()
{
	ChangeStatus(ENotConnected);

	CActiveScheduler::Add(this);

	// connect to RSocketServ
	User::LeaveIfError(iSocketServ.Connect());

	/*iPort = KDefaultPortNumber;*/
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::StartL
***
***  DESCRIPTION	Start listening for TCP connections.
***					Method leaves with KErrGeneral if if()-conditions not met.
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::StartL()
{
	//LOG_METHOD(_L("CServSocketsEngine::StartL"));

	// get TCP protocol description
	TProtocolDesc pInfo;
	User::LeaveIfError(iSocketServ.FindProtocol(_L("tcp"), pInfo));
	// open socket listening for TCP
	User::LeaveIfError(iListenSocket.Open(iSocketServ, pInfo.iAddrFamily, pInfo.iSockType, pInfo.iProtocol));

	// If port is KErrInUse try ports in order until success.
	// The Dynamic and/or Private Ports are those from 49152 to 65535
	// (http://www.iana.org/assignments/port-numbers)
	SetPort(49152);
	TInt ret = KErrInUse;
	while( ret == KErrInUse && iPort <= 65535 )
	{
		//WRITE_LOG_FORMAT(_L("SetPort %d"),iPort);
		iAddress.SetPort(iPort++);
		ret = iListenSocket.Bind(iAddress);
	}
	iPort--;
	
	if( ret != KErrNone )
	{
		// open failed
		iListenSocket.Close();
			//WRITE_LOG(_L("Error1!"));
		User::Leave(ret);
	}

	// start to listen
	ret = iListenSocket.Listen(1);
	if( ret != KErrNone )
	{
		// listen failed
		iListenSocket.Close();
			//WRITE_LOG(_L("Error2!"));
		User::Leave(ret);
	}

	// open socket
	ret = iAcceptedSocket.Open(iSocketServ);
	if( ret != KErrNone )
	{
		// socket open failed
		iListenSocket.Close();
			//WRITE_LOG(_L("Error3!"));
		User::Leave(ret);
	}
	iEngineStatus = EConnecting;

	iListenSocket.Accept(iAcceptedSocket, iStatus);

	iListenSocket.LocalName(iAddress);

	iAddress.Output(iServerName);

	SetActive();
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::Disconnect
***
***  DESCRIPTION	Disconnect
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::Disconnect()
{
	//LOG_METHOD(_L("CServSocketsEngine::Disconnect"));
	
	iAcceptedSocket.Close();
	iSocket.Close();
	iListenSocket.CancelAccept();
	iListenSocket.Close();

	iSocketServ.Close();
	ChangeStatus(ENotConnected);

	Cancel();
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::DoCancel
***
***  DESCRIPTION	This function is called as part of the active object�s Cancel()
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::DoCancel()
{
//	LOG_METHOD(_L("CServSocketsEngine::DoCancel"));
	iListenSocket.CancelAccept();
	ChangeStatus(ENotConnected);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::RunL
***
***  DESCRIPTION	Handles an active object�s request completion event
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::RunL()
{
	//LOG_METHOD(_L("CServSocketsEngine::RunL()"));
	User::InfoPrint(_L("CServSocketsEngine::RunL()")); 
	switch(iEngineStatus)
	{
	case EConnecting:
		//WRITE_LOG(_L("case EConnecting:"));
		User::InfoPrint(_L("case EConnecting:")); 
		if (iStatus == KErrNone)
		{
			ChangeStatus(EConnected);
			TProtocolDesc pd;
			iAcceptedSocket.Info(pd);
			iSocketEngine->SetSocket(&iAcceptedSocket, ETrue);

		}
		else
		{
			ChangeStatus(EConnectFailed);
			ChangeStatus(ENotConnected);
		}
		break;
	case EConnected:
		{
			//WRITE_LOG(_L("case EConnected:"));
			User::InfoPrint(_L("case EConnected:")); 
			break;
		}
	case EDisconnecting:
		//WRITE_LOG(_L("case EDisconnecting:"));
		User::InfoPrint(_L("case EDisconnecting:")); 
		if (iStatus == KErrNone)
		{
			ChangeStatus(ENotConnected);
		}
		else
		{
			ChangeStatus(EConnectFailed);
		}
		break;

	default:
		//WRITE_LOG(_L("case default:"));
		break;
    }
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::RunL
***
***  DESCRIPTION	Handles an active object�s request completion event
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::ChangeStatus(TServSocketsEngineState aNewStatus)
{
//	LOG_METHOD(_L("CServSocketsEngine::ChangeStatus"));
	iEngineStatus = aNewStatus;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::Connected
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TBool
***
***************************************************************************************
**************************************************************************************/
TBool CServSocketsEngine::Connected() const
{
	return (iEngineStatus != ENotConnected);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::ServerName
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TDesC&
***
***************************************************************************************
**************************************************************************************/
const TDesC& CServSocketsEngine::ServerName()
{
	RHostResolver hostResolver;
	TNameEntry entry;

	hostResolver.Open(iSocketServ, KAfInet, KProtocolInetTcp);
	hostResolver.GetByName(TPtrC(), entry);
	TInetAddr local = TInetAddr::Cast(entry().iAddr);
	local.Output(iServerName);
	return iServerName;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::SetPort
***
***  DESCRIPTION	N/A
***
***  INPUT			TInt aPort
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::SetPort(TInt aPort)
{
	iPort = aPort;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::Port
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TInt
***
***************************************************************************************
**************************************************************************************/
TInt CServSocketsEngine::Port() const
{
	return iPort;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::Address
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TInt
***
***************************************************************************************
**************************************************************************************/
TInt CServSocketsEngine::Address() const
{
	return iLocalAddress;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CServSocketsEngine::StartSocketListenerL
***
***  DESCRIPTION	N/A
***
***  INPUT			TInt& aPort - Port to which a TCP socket is set to listen
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CServSocketsEngine::StartSocketListenerL(TInt& aPort)
{
	//LOG_METHOD(_L("CServSocketsEngine::StartSocketListenerL"));
	// SetPort(aPort);
	StartL();
	aPort = iPort;
}
     