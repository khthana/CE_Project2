/**
* 
* @brief Definition of CSimpleDlgPlayerNameDialog
*
* Copyright (c) EMCC Software Ltd 2003
* @version 1.0
*/

// INCLUDE FILES

// Class include
#include "MultiviewsAddAccountDialog.h"

// System includes
#include <avkon.hrh> // EAknSoftkeyOk
#include <multiviews.rsg>
#include <eikedwin.h> // CEikEdwin
#include <eiklabel.h> // CEikLabel
#include <stringloader.h> // StringLoader

#include <eikspane.h>  // CEikStatusPane
#include <aknappui.h>  // iAvkonAppUi
#include <aknnavi.h>   // CAknNavigationControlContainer
#include <s32file.h>   // RFileReadStream,RFileWriteStream
#include <eiklbm.h>

#include <aknglobalconfirmationquery.h>
#include <aknnotewrappers.h>
//#include <GameLogger.h>
#include <barsread.h> 

#include <cpbkcontactengine.h> 


// User includes
#include "Multiviews.hrh" // dialog lines

//#include "Multiviewsappui.h"

// ================= MEMBER FUNCTIONS =======================

/**
* Called by the framework when a soft key is pressed.
* Saves the dialog data back to the model
* @param aButtonId The soft key which was pressed
*/
TBool CMultiviewsAddAccountDialog::OkToExitL(TInt aButtonId)
	{
		if(aButtonId != 3000)
		ClearNaviPane();
		return CAknDialog::OkToExitL(aButtonId);	
	}

CMultiviewsAddAccountDialog::~CMultiviewsAddAccountDialog(){

}

void CMultiviewsAddAccountDialog::ConstructL(CDesCArray* aArray)
{
	iTextArray = aArray;
	
	mode = 0;
	CAknDialog::ConstructL(R_MULTIVIEWS_CONTACT_DIALOG_MENUBAR);

}
/**
* Called by the framework before the dialog is sized and laid out. 
* Initialises the control values.
*/
void CMultiviewsAddAccountDialog::PreLayoutDynInitL()
	{
	CAknDialog::PreLayoutDynInitL();

	iListbox = (CEikTextListBox*)Control(ESelectionListControl);
	iListbox->Model()->SetOwnershipType(ELbmDoesNotOwnItemArray);
	
	ShowNaviPaneText(R_AKNEXSPANE_NAVI_CONTACTS);//create resource reader
	mode = 1;
	if(InitFromContactsDbL())
	{
		iContacts = ETrue;
		iListbox->Model()->SetItemTextArray( iPhonebookArray );
	}
	iListbox->HandleItemAdditionL();

	}
/**
* Static construction and execution of the dialog. 
* @param aPlayerName the name which this dialog will edit
* @return ETrue if the dialog is dismissed with a positive action, EFalse otherwise
*/
TBool CMultiviewsAddAccountDialog::RunDlgLD (TDes& aPlayerName, CDesCArray* aArray)
	{
		CMultiviewsAddAccountDialog* playerNameDialog = new (ELeave) CMultiviewsAddAccountDialog(aPlayerName);

		CleanupStack::PushL(playerNameDialog);

		playerNameDialog->ConstructL(aArray);

		CleanupStack::Pop(); // instance
		
		TInt res =  playerNameDialog->ExecuteLD(R_MULTIVIEWS_CONTACT_DIALOG);
		return res;
		
	}

/**************************************************************************************
***************************************************************************************
***
***  NAME			GenGameContactDialog::InitFromContactsDbL
***
***  DESCRIPTION	This method queries the Contacts Database to retrieve and cache
***					the names and telephone numbers of all the contacts.
***
***  INPUT			N/A
***
***  RETURN			TBool - contacts retrieved succesfully
***
***************************************************************************************
**************************************************************************************/

TBool CMultiviewsAddAccountDialog::InitFromContactsDbL()
{
	//Get the ContactIdArray from the Database - caller does
	//not take ownership, so don't push it onto the CleanupStack
//	LOG_METHOD(_L("InitFromContactsDbL"));
//	WRITE_LOG(_L("GenGameContactDialog::InitFromContactsDbL"));
	TBool retVal = EFalse;
	iDatabase = CContactDatabase::OpenL();
	const CContactIdArray* contacts = iDatabase->SortedItemsL();
	const TInt nc = contacts->Count();
	
	if(nc)
	{
		retVal = ETrue;
		iPhonebookArray = new (ELeave) CDesCArrayFlat(nc);

		for (TInt i=0;i<=nc-1;i++) //For each ContactId
			{
			CContactItem* contact=NULL;
			HBufC* firstNameBuf=NULL;
			HBufC* lastNameBuf=NULL;
			HBufC* numberBuf=NULL;
			
			//Open the contact and get its fieldset
			contact = iDatabase->OpenContactL((*contacts)[i]);
			CleanupStack::PushL(contact);
			
			CContactItemFieldSet& fieldSet = contact->CardFields();
			
			//The index of the field in the Contact fieldset
			TInt index;
			
			// Get Phone Number
			TInt lastind = -1;

			/**/
			index = fieldSet.Find(KUidContactFieldUrl);
			//index = fieldSet.Find(KUidContactFieldEMail);
			
			/**/	
			TInt k=0;
			
			const TInt fieldCount = fieldSet.Count();

			while(!(index < 0) || (index >= fieldCount))
				{
				k++;
				
				CContactItemField& phonenoField = fieldSet[index];
				CContactTextField* phoneno = phonenoField.TextStorage();
				
				numberBuf = phoneno->Text().AllocLC();
				
				_LIT(KSpaceDes," ");
				
				TInt bufLen = (numberBuf->Length()-1);
				TInt sq=0;
				while (sq<=bufLen)
					{
					if (numberBuf->Des().Mid(sq,1)==KSpaceDes)
						{
						numberBuf->Des().Delete(sq,1);
						bufLen--;
						}
					else
						sq++;
					}
				
				if (numberBuf->Length()>0)
					{
					// Get first name.
					TInt findpos = fieldSet.Find(KUidContactFieldGivenName);
					
					// Check that the first name field is actually there.
					if (!(findpos < 0) || (findpos >= fieldSet.Count()))
						{
						CContactItemField& firstNameField = fieldSet[findpos];
						CContactTextField* firstName = firstNameField.TextStorage();
						
						firstNameBuf = firstName->Text().AllocLC();
						}
					
					// Get last name.
					findpos = fieldSet.Find(KUidContactFieldFamilyName);
					
					// Check that the last name field is actually there.
					if (!(findpos < 0) || (findpos >= fieldSet.Count()))
						{
						CContactItemField& lastNameField = fieldSet[findpos];
						CContactTextField* lastName = lastNameField.TextStorage();
						
						lastNameBuf = lastName->Text().AllocLC();
						}
					
					TInt len = numberBuf->Length();
					if (firstNameBuf) len+=firstNameBuf->Length();
					if (lastNameBuf) len+=lastNameBuf->Length();
					
					HBufC* combinedDes = HBufC::NewLC(len+10);
					
					_LIT(KListItemFormatter," \t%S %S\t%S");
					_LIT(KListOItemFormatter," \t%S\t%S");
					
					if ((firstNameBuf)&&(lastNameBuf))
						combinedDes->Des().Format(KListItemFormatter,lastNameBuf,firstNameBuf,numberBuf);
					else
						{
						if (firstNameBuf)
							combinedDes->Des().Format(KListOItemFormatter,firstNameBuf,numberBuf);
						else if (lastNameBuf)
							combinedDes->Des().Format(KListOItemFormatter,lastNameBuf,numberBuf);
						
						}
					iPhonebookArray->InsertL(0,*combinedDes);
					
					CleanupStack::PopAndDestroy(combinedDes);
					
					if (lastNameBuf) CleanupStack::PopAndDestroy(lastNameBuf);
					
					if (firstNameBuf) CleanupStack::PopAndDestroy(firstNameBuf);
					}
				
				if (numberBuf) CleanupStack::PopAndDestroy(numberBuf);
				lastind = index;
				if (lastind<=fieldSet.Count()-1)
					{
					
					/**/
					
					
					index = fieldSet.FindNext(KUidContactFieldUrl,lastind+1);
					
					//index = fieldSet.FindNext(KUidContactFieldEMail,lastind+1);


					/**/
					if (index==lastind) break; //i.e. break while
					}
				else
					break;
				}		
			iDatabase->CloseContactL(contact->Id());	
			CleanupStack::PopAndDestroy(contact);
			}
		iPhonebookArray->Sort(ECmpFolded);
		}
		return retVal;
	}

/**************************************************************************************
***************************************************************************************
***
***  NAME			GenGameContactDialog::ShowNaviPaneText
***
***  DESCRIPTION	Show text in navipanel
***
***  INPUT			TInt aResourceId
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/

void CMultiviewsAddAccountDialog::ShowNaviPaneText(TInt aResourceId)
{
	CEikStatusPane *sp = iAvkonAppUi->StatusPane();
    CAknNavigationControlContainer* naviPane = (CAknNavigationControlContainer *)sp->ControlL(TUid::Uid(EEikStatusPaneUidNavi));

	TResourceReader reader;
	CCoeEnv::Static()->CreateResourceReaderLC(reader,aResourceId);
	
	iNaviDecorator = naviPane->CreateNavigationLabelL(reader);
	CleanupStack::Pop();//reader
	naviPane->PushL(*iNaviDecorator);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			GenGameContactDialog::ClearNaviPane
***
***  DESCRIPTION	Clear navipanel
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/

void CMultiviewsAddAccountDialog::ClearNaviPane()
{
	CEikStatusPane *sp = iAvkonAppUi->StatusPane();
    CAknNavigationControlContainer* naviPane = (CAknNavigationControlContainer *)sp->ControlL(TUid::Uid(EEikStatusPaneUidNavi));
	naviPane->PushDefaultL();
}


// End of File

void CMultiviewsAddAccountDialog::DynInitMenuPaneL( TInt aResourceId, CEikMenuPane* aMenuPane )
{
	if( aResourceId == R_MULTIVIEWS_CONTACT_DIALOG_MENU )
	{
		if( ((CEikTextListBox*)Control(ESelectionListControl))->CurrentItemIndex() == -1 )
		{
			aMenuPane->SetItemDimmed(EGenGameContactSelect,ETrue);
			aMenuPane->SetItemDimmed(EGenGameContactDelete,ETrue);
		}
		if(mode == 1) 
		{
			aMenuPane->SetItemDimmed(EGenGameContactNew,ETrue);
			aMenuPane->SetItemDimmed(EGenGameContactDelete,ETrue);
		}
		else if(mode == 0)
			aMenuPane->SetItemDimmed(EGenGameContactEnter, ETrue);
	}
}

TKeyResponse CMultiviewsAddAccountDialog::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
{
	if(!iContacts)
	{
		EnterContact();
		iContacts = ETrue;
	}
	if(  aType==EEventKey && aKeyEvent.iCode == 63557)
	{
		ProcessCommandL(EGenGameContactSelect);
		return EKeyWasConsumed;
	}
	return CAknDialog::OfferKeyEventL(aKeyEvent,aType);
}

void CMultiviewsAddAccountDialog::ProcessCommandL( TInt aCommandId )
{
	if( MenuShowing() )
	{
		HideMenu();
	}
	
	switch( aCommandId )
	{
		case EGenGameContactNew:
		{
			mode = 1;
			iListbox->SetCurrentItemIndex(0);
			ClearNaviPane();
			ShowNaviPaneText(R_AKNEXSPANE_NAVI_CONTACTS);
			{
				if(InitFromContactsDbL())
				{
					iListbox->Model()->SetItemTextArray( iPhonebookArray );
					iListbox->HandleItemAdditionL();
				}
				else
				{
					iTextArray->Reset();
					iListbox->HandleItemRemovalL();
					EnterContact();
				}
			}
			break;
		}
		case EGenGameContactSelect:
		{
			if (iListbox->Model()->NumberOfItems() == 0)
				return;

			TInt iIndex = iListbox->CurrentItemIndex();

			TPtrC item = iPhonebookArray->MdcaPoint(iIndex);

			//Get realName
			TLex lexer;
			lexer.Assign(item);
			lexer.SkipSpace();
			lexer.Mark();
			while(lexer.Peek()!='\t')
			{
				lexer.Inc();
				if( lexer.Eos() )
				{
					break;
				}
			}
			
			TPtrC realName = lexer.MarkedToken();
			//iEngine->SetOppRealName(realName);
			
			lexer.Inc();
			lexer.Mark();
			while(lexer.Peek()!='\t')
			{
				lexer.Inc();
				if( lexer.Eos() )
				{
					break;
				}
			}
			TPtrC temp = lexer.MarkedToken();
			/*			
			TBuf<60> bufname;
			bufname.Copy(temp);
			User::InfoPrint(bufname);

			bufname.Delete(0,1);
			bufname.Insert(0,_L16("sip:"));
			TInt pos;
			pos = bufname.Locate('@');
			bufname.SetLength(pos);
			bufname.Insert(bufname.Length(),_L16("@192.168.243.170"));
			*/

			iPlayerName = temp;
			
			TryExitL(aCommandId);
			break;
		}
		case EGenGameContactEnter:
		{
			if(EnterContact())
				TryExitL(aCommandId);
			break;
		}
	default:
		break;
	}
}

TInt CMultiviewsAddAccountDialog::EnterContact()
{
	TBuf<60>note;
	CAknTextQueryDialog* querydlg = CAknTextQueryDialog::NewL(note);		
	querydlg->SetMaxLength(note.MaxLength());
	querydlg->SetPromptL(_L("SIP Address: "));
	
	TInt retVal = querydlg->RunDlgLD(R_AVKON_DIALOG_QUERY_VALUE_TEXT);
	
	//iEngine->SetOppRealName(note);
	iPlayerName = note;
	
	return retVal;
}
