/**
* 
* @brief Definition of CSimpleDlgPlayerNameDialog
*
* Copyright (c) EMCC Software Ltd 2003
* @version 1.0
*/

// INCLUDE FILES

// Class include
#include "SendMessageDialog.h"

// System includes
#include <avkon.hrh> // EAknSoftkeyOk
#include <multiviews.rsg>
#include <eikedwin.h> // CEikEdwin
#include <eiklabel.h> // CEikLabel
#include <stringloader.h> // StringLoader

// User includes
#include "Multiviews.hrh" // dialog lines

//#include "Multiviewsappui.h"

// ================= MEMBER FUNCTIONS =======================

/**
* Called by the framework when a soft key is pressed.
* Saves the dialog data back to the model
* @param aButtonId The soft key which was pressed
*/
TBool CSendMessageDialog::OkToExitL(TInt aButtonId)
	{
	if (aButtonId == EAknSoftkeyOk)
		{
		CEikEdwin* editor = static_cast<CEikEdwin*>(ControlOrNull(ESendMessageDlg));
		if (editor)
			{
			editor->GetText(iPlayerName);
			
			//CMultiViewsAppUi::TestFunction(iPlayerName); 
			
			}
		}
	//User::InfoPrint(iPlayerName);
	return ETrue;
	}


/**
* Called by the framework before the dialog is sized and laid out. 
* Initialises the control values.
*/
void CSendMessageDialog::PreLayoutDynInitL()
	{
	CEikLabel* label = static_cast<CEikLabel*>(ControlOrNull(ESendMessageLabelDlg));
	if (label)
		{
		HBufC* labelText = StringLoader::LoadLC(R_SEND_TEXT);
		label->SetTextL(*labelText);
		CleanupStack::PopAndDestroy(labelText);
		}
	}


/**
* Static construction and execution of the dialog. 
* @param aPlayerName the name which this dialog will edit
* @return ETrue if the dialog is dismissed with a positive action, EFalse otherwise
*/
TBool CSendMessageDialog::RunDlgLD (TDes& aPlayerName)
	{
		CSendMessageDialog* playerNameDialog = new (ELeave) CSendMessageDialog(aPlayerName);
		return playerNameDialog->ExecuteLD(R_SENDMESSAGE_DIALOG);
		/*bool aa =  playerNameDialog->ExecuteLD(R_SIMPLEDLG_PLAYER_NAME_DIALOG);
		User::InfoPrint(aa);
		return aa;*/
	}

// End of File

