/* Copyright (c) 2003, Nokia. All rights reserved */

#include <aknviewappui.h>
#include <aknconsts.h>
#include <MultiViews.rsg>

#include "MultiViewsView3.h"
#include "MultiViewsContainer3.h"
#include "MultiViews.hrh"

CMultiViewsView3* CMultiViewsView3::NewL()
    {
    CMultiViewsView3* self = CMultiViewsView3::NewLC();
    CleanupStack::Pop(self);
    return self;
    }

CMultiViewsView3* CMultiViewsView3::NewLC()
    {
    CMultiViewsView3* self = new (ELeave) CMultiViewsView3();
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

CMultiViewsView3::CMultiViewsView3()
    {

    }

CMultiViewsView3::~CMultiViewsView3()
    {
    // No implementation required
    }

void CMultiViewsView3::ConstructL()
    {
    BaseConstructL(R_MULTIVIEWS_VIEW3);
    }


TUid CMultiViewsView3::Id() const
    {
    return TUid::Uid(EMultiViewsView3Id);
    }

void CMultiViewsView3::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
                                    TUid /*aCustomMessageId*/,
                                    const TDesC8& /*aCustomMessage*/)
    {
    ASSERT(!(iContainer));
    iContainer = CMultiViewsContainer3::NewL(ClientRect());
	
	iDisplayBool = ETrue;

    }

void CMultiViewsView3::DoDeactivate()
    {
    if (iContainer)
        {
        AppUi()->RemoveFromStack(iContainer);
        delete iContainer;
        iContainer = NULL;
		iDisplayBool = EFalse;
        }
    }

void CMultiViewsView3::HandleCommandL(TInt aCommand)
    {
/*	    switch(aCommand)
        {
        case EMultiViewsSwitchToView2:
			AppUi()->ActivateLocalViewL(TUid::Uid(EMultiViewsView2Id));	
							
			break;			
		default:
			AppUi()->HandleCommandL(aCommand);
            break;
        }
*/
		AppUi()->HandleCommandL(aCommand);
    }

TKeyResponse CMultiViewsView3::HandleKeyEventL(const TKeyEvent &aKeyEvent,
    TEventCode aType)
{
  if (aType==EEventKey)
  {
		//User::InfoPrint(_L("5555"));
		if (aKeyEvent.iCode==EKeyUpArrow){
			User::InfoPrint(_L("up"));
			
			iContainer->DecListBarPosition();
			iContainer->DrawDeferred();
 
		}else if (aKeyEvent.iCode==EKeyDownArrow){
			User::InfoPrint(_L("down555"));
			
			iContainer->IncListBarPosition();
			iContainer->DrawDeferred();

		}else if (aKeyEvent.iCode==EKeyLeftArrow){
			User::InfoPrint(_L("left"));

		}else if (aKeyEvent.iCode==EKeyRightArrow){
			User::InfoPrint(_L("right"));
		}else{

			
		}
/*
    if (aKeyEvent.iCode=='1')
      iEngine->KeyRotate(-1);

    if (aKeyEvent.iCode=='0' || aKeyEvent.iCode=='3')
      iEngine->KeyRotate(1);*/
  }
  return EKeyWasNotConsumed;
}


TBool CMultiViewsView3::IsDisplay()
    {
	    return iDisplayBool;

    }

void CMultiViewsView3::UpdateBoard(){
	    iContainer->DrawDeferred();
}

TInt CMultiViewsView3::GetBarPosition()
{
    return iContainer->GetBarPosition();
	
}
