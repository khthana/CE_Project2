/*
* ==============================================================================
*  Name        : SocketsEngine.cpp
*  Part of     : CommunicationChannel
*  Description : Implementation of SocketsEngine class
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/

#include <eikgted.h>
#include "SocketsEngine.h"
#include "SocketsRead.h"
#include "SocketsWrite.h"
//#include "Sockets.pan"
//#include <GameLogger.h>
#include <es_enum.h>
//#include <CommunicationChannelObserver.h>

_LIT(KDefaultServerName, "1.2.3.4");

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::NewL
***
***  DESCRIPTION	Second phase constructor
***
***  INPUT			MSocketsEngineObserver& aObserver
***
***  RETURN			CSocketsEngine*
***
***************************************************************************************
**************************************************************************************/
CSocketsEngine* CSocketsEngine::NewL(MSocketsEngineObserver& aObserver,TBool aServer , CSIPEngine* aSipEngine)
{
	CSocketsEngine* self = CSocketsEngine::NewLC(aObserver,aServer , aSipEngine);
	CleanupStack::Pop();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::NewLC
***
***  DESCRIPTION	Second phase constructor
***
***  INPUT			MSocketsEngineObserver& aObserver
***
***  RETURN			CSocketsEngine*
***
***************************************************************************************
**************************************************************************************/
CSocketsEngine* CSocketsEngine::NewLC(MSocketsEngineObserver& aObserver,TBool aServer, CSIPEngine* aSipEngine)
{
	CSocketsEngine* self = new (ELeave) CSocketsEngine(aObserver,aServer,aSipEngine);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::CSocketsEngine
***
***  DESCRIPTION	Constructor
***
***  INPUT			MSocketsEngineObserver& aObserver
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CSocketsEngine::CSocketsEngine(MSocketsEngineObserver& aObserver,TBool aServer,CSIPEngine* aSipEngine)
: CActive(EPriorityStandard),
  iObserver(aObserver),
  iServerName(KDefaultServerName),
  iServer(aServer),
  iSipEngine(aSipEngine)
{
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::~CSocketsEngine()
***
***  DESCRIPTION	Destructor
***
***  INPUT			N/A
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CSocketsEngine::~CSocketsEngine()
{
	//LOG_METHOD(_L("CSocketsEngine::~CSocketsEngine"));
	Cancel();
	if (iSocket && iConnected)
	{
		//WRITE_LOG(_L("Cancel & Close"));
		iSocket->CancelWrite();
		iSocket->CancelRecv();
		iSocket->Close();
	}

	if( iSocketsRead )
	{
		//WRITE_LOG(_L("delete iSocketsRead"));
		delete iSocketsRead;
		iSocketsRead = NULL;
	}
	if( iSocketsWrite )
	{
		//WRITE_LOG(_L("delete iSocketsWrite"));
		delete iSocketsWrite;
		iSocketsWrite = NULL;
	}
	
	iSocketServ.Close();
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::ConstructL()
***
***  DESCRIPTION	Constructor
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::ConstructL()
{
	//LOG_METHOD(_L("CSocketsEngine::ConstructL"));
	User::LeaveIfError(iSocketServ.Connect());
	iRequestId = 1;
	iConnected = EFalse;
	CActiveScheduler::Add(this);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::InitializeL
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::InitializeL()
{
//	//LOG_METHOD(_L("CSocketsEngine::InitializeL"));
	iEngineStatus = ENotConnected;
	//iSocketsRead = CSocketsRead::NewL(*iSocket,*this ,  300  /*,iSipEngine->Settings()->iReadBufferSize*/);
	iSocketsRead = CSocketsRead::NewL(*iSocket,*this ,  20000  /*,iSipEngine->Settings()->iReadBufferSize*/);
	iSocketsRead->iRecieveFileSize = iSipEngine->iRecieveFileSize;
	iSocketsRead->iRecieveFileName = iSipEngine->iRecieveFileName;
	iSocketsWrite = CSocketsWrite::NewL(*iSocket,*this);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::SetSocket
***
***  DESCRIPTION	Sets a connected socket for SocketsEngine
***
***  INPUT			RSocket *socket - connected socket
***					TInt aMode - connection type
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::SetSocket(RSocket *socket, TBool aServer)
{
	//LOG_METHOD(_L("CSocketsEngine::SetSocket"));
	iSocket = socket;
	iServer = aServer;
	iConnected = ETrue;
	InitializeL();
	Read();
	ChangeStatus(EConnected);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::ConnectL
***
***  DESCRIPTION	Connects TCP socket
***
***  INPUT			TUint32 aAddr - Address where to connect
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::ConnectL(TUint32 aAddr)
{
	//LOG_METHOD(_L("CSocketsEngine::ConnectL(TUint32 aAddr)"));
	if ((iEngineStatus == ENotConnected) || (iEngineStatus == ETimedOut))
	{
		if(iSocket)
		{
			iSocket->Close();
			delete iSocket;
		}
		iSocket = new (ELeave) RSocket();
	
		InitializeL();
		RConnection connection;
		connection.Open(iSocketServ);
		TPckgBuf<TConnectionInfo> connectionInfo;
		
		TUint count;
		connection.EnumerateConnections(count);
		for (TUint machConnection = 1; machConnection <= count; machConnection++)
		{
			connection.GetConnectionInfo(machConnection, connectionInfo);
			TUint bufId = connectionInfo().iIapId;

			/**/
			//CSIPConnection* iConnection = 
			TUint conId = iSipEngine->GetConnection()->IapId();
			if (bufId == conId)
				break;
		}

		User::LeaveIfError(connection.Attach(connectionInfo,RConnection::EAttachTypeNormal));
		
		User::LeaveIfError(iSocket->Open(iSocketServ, KAfInet, KSockStream, KProtocolInetTcp, connection));
		CleanupClosePushL(*iSocket);

		iAddress.SetPort(iPort);
		iAddress.SetAddress(aAddr);
			
		// DEBUG print
		TBuf<100>os;
		iAddress.Output(os);
		//WRITE_LOG(os);
		//WRITE_LOG_FORMAT(_L("port: %d"), iAddress.Port());

		iSocket->Connect(iAddress, iStatus);

		User::WaitForRequest(iStatus);
		
		//WRITE_LOG(_L("Socket connection status:"));
		//WRITE_LOG_FORMAT(_L("status = %d"),iStatus);	
		
		if (iStatus.Int() == KErrNone)
		{
			iConnected = ETrue;
		}

		User::LeaveIfError(iStatus.Int());

		SetActive();
		iEngineStatus =EConnected;
	
			
		iStatus = KRequestPending;
		TRequestStatus* pToRefStatus = &iStatus;
		User::RequestComplete(pToRefStatus,KErrNone);

		connection.Close();

		CleanupStack::Pop(iSocket);
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::ConnectL
***
***  DESCRIPTION	Connects TCP socket
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::ConnectL()
{
	//LOG_METHOD(_L("CSocketsEngine::ConnectL()"));
	if ((iEngineStatus == ENotConnected) || (iEngineStatus == ETimedOut))
	{
		TInetAddr addr;
		if (addr.Input(iServerName) == KErrNone)
		{
			ConnectL(addr.Address());
		}
		else
		{
			User::LeaveIfError(iResolver.Open(iSocketServ, KAfInet, KProtocolInetUdp));
			iResolver.GetByName(iServerName, iNameEntry, iStatus);
			ChangeStatus(ELookingUp);
			SetActive();
		}
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::Disconnect
***
***  DESCRIPTION	Disconnects SocketsEngine
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::Disconnect()
{
	//LOG_METHOD(_L("CSocketsEngine::Disconnect"));
	
	iConnected = EFalse;
	delete iSocketsRead;
	iSocketsRead = NULL;
	delete iSocketsWrite;
	iSocketsWrite = NULL;
	ChangeStatus(ENotConnected);
	iSocket->Close();
	delete iSocket;
	iSocket = NULL;

}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::DoCancel
***
***  DESCRIPTION	This function is called as part of the active object�s Cancel()
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::DoCancel()
{
	ChangeStatus(ENotConnected);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::WriteL
***
***  DESCRIPTION	Writes data to socket.
***
***  INPUT			const TDesC8& aData
***
***  RETURN			TInt
***
***************************************************************************************
**************************************************************************************/
TInt CSocketsEngine::WriteL(HBufC8* aData)
{
//	//LOG_METHOD(_L("CSocketsEngine::WriteL"));
//	//WRITE_LOG(*aData);

	if (iEngineStatus == EConnected)
	{
		iSocketsWrite->IssueWriteL(aData);

		iRequestId++;
	} else
	{
		iObserver.SendMessageError(ECBSIPErrorNotConnected);
	}
	return iRequestId;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::Read
***
***  DESCRIPTION	Starts SocketsReader
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::Read()
{
//	//LOG_METHOD(_L("CSocketsEngine::Read"));
	if (/*(iEngineStatus == EConnected) && */(!iSocketsRead->IsActive()))
	{
		iSocketsRead->Start();
		
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::RunL()
***
***  DESCRIPTION	Handles an active object�s request completion event
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::RunL()
{
	//LOG_METHOD(_L("CSocketsEngine::RunL"));
	//WRITE_LOG_FORMAT(_L("iStatus == %d"),iStatus);
	switch(iEngineStatus)
	{
		case EConnecting:
			if (iStatus == KErrNone)
			{
				//WRITE_LOG(_L("CSocketsEngine:connected"));
				User::InfoPrint(_L("Connected")); 
				ChangeStatus(EConnected);
				Read();
			
			}
			else
			{
				//WRITE_LOG(_L("CSocketsEngine: not connected"));
				User::InfoPrint(_L("ConnectFailed"));
				ChangeStatus(EConnectFailed);
				ChangeStatus(ENotConnected);
			}
			break;

		case ELookingUp:
			iResolver.Close();
			if (iStatus == KErrNone)
			{
				iNameRecord = iNameEntry();
				TBuf<15> ipAddr;
				TInetAddr::Cast(iNameRecord.iAddr).Output(ipAddr);
				ChangeStatus(ENotConnected);
				ConnectL(TInetAddr::Cast(iNameRecord.iAddr).Address());
			}
			else
			{
				ChangeStatus(ELookUpFailed);
				ChangeStatus(ENotConnected);
			}
			break;

		case EDisconnecting:
			if (iStatus == KErrNone)
			{
				ChangeStatus(ENotConnected);
			}
			else
			{
				ChangeStatus(EConnectFailed);
			}
			break;
		case EConnected:
			{
				//WRITE_LOG(_L("CSocketsEngine:connected"));
				User::InfoPrint(_L("Connected")); 
				Read();
			}
			break;
		default:
//			User::Panic(KPanicSocketsEngine, ESocketsBadStatus);
			break;
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::ChangeStatus
***
***  DESCRIPTION	Sets SocketsEngine state
***
***  INPUT			TSocketsEngineState aNewStatus
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::ChangeStatus(TSocketsEngineState aNewStatus)
{
//	//LOG_METHOD(_L("CSocketsEngine::ChangeStatus"));
	iEngineStatus = aNewStatus;

	// TODO: pass statuschange to Game Engine
	//TCBSIPNetworkStatusType status=ECBSIPNetworkInactive;
	TInt status = 0;//MCommunicationChannelObserver::EOffline;
	switch ( aNewStatus )
	{
	case EConnectFailed:
	case ELookUpFailed:
	case ELookingUp:
	case ETimedOut:
	case EConnecting:
	case ENotConnected:
		{
			status = EOnline; //MCommunicationChannelObserver::EOnline;
			break;
		}
	case EConnected:
		{
			status = ESessionConnected;//MCommunicationChannelObserver::ESessionConnected;
			break;
		}
	default:
		// do nothing
		break;
	}

	iObserver.NetworkStatusChange(status);
}


/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::SetServerName
***
***  DESCRIPTION	N/A
***
***  INPUT			const TDesC& aName
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::SetServerName(const TDesC& aName)
{
//	//LOG_METHOD(_L("CSocketsEngine::SetServerName"));
	iServerName.Copy(aName);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::ServerName
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TDesC&
***
***************************************************************************************
**************************************************************************************/
const TDesC& CSocketsEngine::ServerName() const
{
	return iServerName;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::SetPort
***
***  DESCRIPTION	N/A
***
***  INPUT			TInt aPort
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::SetPort(TInt aPort)
{
	iPort = aPort;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::Port
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TInt
***
***************************************************************************************
**************************************************************************************/
TInt CSocketsEngine::Port() const
{
	return iPort;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::Connected
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			TBool
***
***************************************************************************************
**************************************************************************************/
TBool CSocketsEngine::Connected() const
{
	return (iEngineStatus == EConnected);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::SendPacketCompleted
***
***  DESCRIPTION	Socket packed send completed
***                 Implementation of MSocketsEngineObserver
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::SendCompleted()
{
	//LOG_METHOD(_L("CSocketsEngine::SendCompleted"));
	// pass completion back to Game Engine
	iObserver.SendMessageCompleted(iRequestId);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::SocketTimeout
***
***  DESCRIPTION	Socket timeout
***                 Implementation of MSocketsEngineObserver
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::SocketTimeout()
{
	//LOG_METHOD(_L("CSocketsEngine::SocketTimeout"));
	// inform Game engine
	iObserver.SendMessageError(ECBSIPErrorMessageSendFailed);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsEngine::PackedReceived
***
***  DESCRIPTION	N/A
***
***  INPUT			TDesC8& aPacket
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsEngine::PackedReceived(TDesC8& aPacket)
{
	//LOG_METHOD(_L("CSocketsEngine::PackedReceived"));
	//WRITE_LOG_FORMAT(_L("aPacket.Length(): %d"),aPacket.Length());
	iObserver.MessageReceived(aPacket);
}

RPointerArray<TDes8> CSocketsEngine::GettingPtr()
{
	RPointerArray<TDes8> iPPP;
	iPPP=iSocketsRead->GettingBufferPtr() ;
	
	return iPPP;
}

void CSocketsEngine::Clear()
{
	iSocketsRead->Clear();
}

void CSocketsEngine::SetSender(TInt sender)
{
	iSocketsRead->sender = sender;
}

TInt CSocketsEngine::GetSender()
{
	return iSocketsRead->sender;
}

void CSocketsEngine::SetFilePath(const TDesC& aFileSend)
{

	iSendFileName.Copy(aFileSend);
}

TInt CSocketsEngine::GetiCountRecieved()
{
	return iSocketsRead->iCountRecieved;
}

TInt CSocketsEngine::GetiRecieveFileSize()
{
	return iSocketsRead->iRecieveFileSize;
}
