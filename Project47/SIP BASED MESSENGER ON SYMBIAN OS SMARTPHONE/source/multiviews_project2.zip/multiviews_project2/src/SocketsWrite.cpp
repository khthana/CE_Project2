/*
* ==============================================================================
*  Name        : SocketsWrite.cpp
*  Part of     : CommunicationChannel
*  Description : Implementation of SocketsWrite class
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/

#include "SocketsWrite.h"
//#include "TimeOutTimer.h"
//#include "Sockets.pan"
#include <GameLogger.h>

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::NewL
***
***  DESCRIPTION	N/A
***
***  INPUT			RSocket& aSocket
***					MSocketObserver& aObserver
***
***  RETURN			CSocketsRead*
***
***************************************************************************************
**************************************************************************************/
CSocketsWrite* CSocketsWrite::NewL(RSocket& aSocket, MSocketObserver& aObserver)
{
	CSocketsWrite* self = CSocketsWrite::NewLC(aSocket, aObserver);
	CleanupStack::Pop();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::NewLC
***
***  DESCRIPTION	N/A
***
***  INPUT			RSocket& aSocket
***					MSocketObserver& aObserver
***
***  RETURN			CSocketsWrite*
***
***************************************************************************************
**************************************************************************************/
CSocketsWrite* CSocketsWrite::NewLC(RSocket& aSocket, MSocketObserver& aObserver)
{
	CSocketsWrite* self = new (ELeave) CSocketsWrite(aSocket, aObserver);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::CSocketsWrite
***
***  DESCRIPTION	N/A
***
***  INPUT			RSocket& aSocket
***					MSocketObserver& aObserver
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CSocketsWrite::CSocketsWrite(RSocket& aSocket, MSocketObserver& aObserver)
: CActive(EPriorityStandard),
  iSocket(aSocket),
  iObserver(aObserver)
{
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::~CSocketsWrite
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			N/A
***
***************************************************************************************
**************************************************************************************/
CSocketsWrite::~CSocketsWrite()
{
	Cancel();

	iMessageArray->ResetAndDestroy();
	delete iMessageArray;
	iMessageArray = NULL;

}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::DoCancel
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsWrite::DoCancel()
{	
	//LOG_METHOD(_L("CSocketsWrite::DoCancel"));
//	iSocket.CancelWrite();

	if(iMessageArray->Count() > 0)
	{
		delete iMessageArray->At(0);
		iMessageArray->Delete(0);
		iMessageArray->Compress();	
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::ConstructL
***
***  DESCRIPTION	N/A
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsWrite::ConstructL()
{
//	LOG_METHOD(_L("CSocketsWrite::ConstructL()"));
	iMessageArray = new (ELeave) CArrayPtrFlat<HBufC8>(4);
	CActiveScheduler::Add(this);
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::RunL
***
***  DESCRIPTION	Handles an active object�s request completion event
***
***  INPUT			N/A
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsWrite::RunL()
{
//	WRITE_LOG(_L("CSocketsWrite::RunL"));
	
	//WRITE_LOG_FORMAT(_L("CSocketsWrite::RunL iStatus on %d"),iStatus.Int());

	if(iMessageArray->Count() > 0)
	{
		delete iMessageArray->At(0);
		iMessageArray->Delete(0);
		iMessageArray->Compress();	
	}

	if (iStatus != KErrNone)
		iObserver.SocketTimeout();
	else
		iObserver.SendCompleted();

	
	if(iMessageArray->Count() > 0)
	{
		//WRITE_LOG_FORMAT(_L("More stuff (%d) left in iMessageArray, let's send it!"),iMessageArray->Count());
		IssueWriteL(NULL);
	}
	else
	{
//		iObserver.SendCompleted();
	}
}

/**************************************************************************************
***************************************************************************************
***
***  NAME			CSocketsWrite::IssueWriteL
***
***  DESCRIPTION	Issues a write to socket. Takes ownership of HBufC8* aData
***
***  INPUT			const TDesC8& aData - Data to be written. Takes ownership of aData.
***
***  RETURN			void
***
***************************************************************************************
**************************************************************************************/
void CSocketsWrite::IssueWriteL(HBufC8* aData)
{
	//LOG_METHOD(_L("CSocketsWrite::IssueWriteL"));

	if(aData)
		iMessageArray->AppendL(aData);
	
	if (!IsActive() && (iMessageArray->Count() > 0) )
	{
		//WRITE_LOG(*iMessageArray->At(0));
		iSocket.Write(*iMessageArray->At(0), iStatus); 
		SetActive();
	}
	else
	{
		//WRITE_LOG(_L("CSocketsWrite::IssueWriteL ELSE branch, no immediate send"));
	}
}

