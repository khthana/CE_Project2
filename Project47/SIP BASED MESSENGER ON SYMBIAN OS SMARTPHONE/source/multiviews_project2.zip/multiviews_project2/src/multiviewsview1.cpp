/* Copyright (c) 2003, Nokia. All rights reserved */

#include <aknviewappui.h>
#include <aknconsts.h>
#include <MultiViews.rsg>

#include "MultiViewsView1.h"
#include "MultiViewsContainer1.h"
#include "MultiViews.hrh"

CMultiViewsView1* CMultiViewsView1::NewL(CArrayFixSeg<TAccountList> *aAccountTable/*CSIPEngine *aSipEngine*/)
    {
    CMultiViewsView1* self = CMultiViewsView1::NewLC(aAccountTable/*aSipEngine*/);
    CleanupStack::Pop(self);
    return self;
    }

CMultiViewsView1* CMultiViewsView1::NewLC(CArrayFixSeg<TAccountList> *aAccountTable/*CSIPEngine *aSipEngine*/)
    {
    CMultiViewsView1* self = new (ELeave) CMultiViewsView1(aAccountTable/*aSipEngine*/);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

CMultiViewsView1::CMultiViewsView1(CArrayFixSeg<TAccountList> *aAccountTable/*CSIPEngine *aSipEngine*/)
    {
	iAccountTable = aAccountTable;
    }

CMultiViewsView1::~CMultiViewsView1()
    {
    // No implementation required
    }

void CMultiViewsView1::ConstructL()
    {
    BaseConstructL(R_MULTIVIEWS_VIEW1);
    }


TUid CMultiViewsView1::Id() const
    {
    return TUid::Uid(EMultiViewsView1Id);
    }

void CMultiViewsView1::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
                                    TUid /*aCustomMessageId*/,
                                    const TDesC8& /*aCustomMessage*/)
    {
    ASSERT(!(iContainer));
    iContainer = CMultiViewsContainer1::NewL(ClientRect(),
									iAccountTable/*,iSipEngine*/);
	
	iDisplayBool = ETrue;

    }

void CMultiViewsView1::DoDeactivate()
    {
    if (iContainer)
        {
        AppUi()->RemoveFromStack(iContainer);
        delete iContainer;
        iContainer = NULL;
		iDisplayBool = EFalse;
        }
    }

void CMultiViewsView1::HandleCommandL(TInt aCommand)
    {
/*	    switch(aCommand)
        {
        case EMultiViewsSwitchToView2:
			AppUi()->ActivateLocalViewL(TUid::Uid(EMultiViewsView2Id));	
							
			break;			
		default:
			AppUi()->HandleCommandL(aCommand);
            break;
        }
*/
		AppUi()->HandleCommandL(aCommand);
    }

TKeyResponse CMultiViewsView1::HandleKeyEventL(const TKeyEvent &aKeyEvent,
    TEventCode aType)
{
  if (aType==EEventKey)
  {
		//User::InfoPrint(_L("5555"));
		if (aKeyEvent.iCode==EKeyUpArrow){
			User::InfoPrint(_L("up"));
			
			iContainer->DecListBarPosition();
			iContainer->DrawDeferred();
 
		}else if (aKeyEvent.iCode==EKeyDownArrow){
			User::InfoPrint(_L("down555"));
			
			iContainer->IncListBarPosition();
			iContainer->DrawDeferred();

		}else if (aKeyEvent.iCode==EKeyLeftArrow){
			User::InfoPrint(_L("left"));

		}else if (aKeyEvent.iCode==EKeyRightArrow){
			User::InfoPrint(_L("right"));
		}else{

			
		}
/*
    if (aKeyEvent.iCode=='1')
      iEngine->KeyRotate(-1);

    if (aKeyEvent.iCode=='0' || aKeyEvent.iCode=='3')
      iEngine->KeyRotate(1);*/
  }
  return EKeyWasNotConsumed;
}


TBool CMultiViewsView1::IsDisplay()
    {
	    return iDisplayBool;

    }

void CMultiViewsView1::UpdateBoard(){
	    iContainer->DrawDeferred();
}

TInt CMultiViewsView1::GetBarPosition()
{
    return iContainer->GetBarPosition();
	
}

void CMultiViewsView1::DecBarPosition()
{
	User::InfoPrint(_L("up"));
	iContainer->DecListBarPosition();
	iContainer->DrawDeferred();

}