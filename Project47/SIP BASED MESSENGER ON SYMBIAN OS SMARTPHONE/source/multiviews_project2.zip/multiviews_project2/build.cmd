@echo off
setlocal

set arg1=%1
set arg2=%2
set arg3=%3

pushd group
call bldmake bldfiles
call abld build %arg1% %arg2% %arg3%
popd

if "%arg1%"=="wins" goto install
if "%arg1%"=="thumb" goto install
goto end

:install
echo Install file SipAppCapabilities.xml to ..\epoc32\%arg1%\c\
copy /Y SipAppCapabilities.xml ..\epoc32\%arg1%\c\
..\epoc32\release\%arg1%\%arg2%\SIPCLIENTINSTALLER.EXE
endlocal

:end
echo on