/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_CONTAINER3_H__
#define __MULTIVIEWS_CONTAINER3_H__

#include <aknview.h>

//for draw background
#include <fbs.h> //CFbsBitmap
#include <aknutils.h>
#include <eikenv.h>		  // CEikonEnv iEikonEnv
#include <MultiViews.mbg> // Bitmap enumeration

class CFbsBitmap;

//path
_LIT(KMainPanePath, "\\system\\apps\\MultiViews\\MultiViews.mbm");
const TInt KTopLeftX = 0;
const TInt KTopLeftY = 0;
const TInt KSizeWidth = 174;
const TInt KSizeHeight = 144;
const TInt KTextMaxLength = 50;

class CMultiViewsContainer3 : public CCoeControl
    {
public: 

	CMultiViewsContainer3();
	~CMultiViewsContainer3();

    static CMultiViewsContainer3* NewL(const TRect& aRect);
    static CMultiViewsContainer3* NewLC(const TRect& aRect);

    void ConstructL(const TRect& aRect);

public: // from CoeControl

    TInt CountComponentControls() const;
    CCoeControl* ComponentControl(TInt aIndex) const;

	void IncListBarPosition();
	void DecListBarPosition();

    void Draw(const TRect& aRect) const;
	TInt GetBarPosition(); 

private:
	//for draw Bitmap
	CFbsBitmap* iBitmap;
	
	TInt iListBarPosition;

    };

#endif // __MULTIVIEWS_CONTAINER1_H__
