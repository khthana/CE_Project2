      /*
* ==============================================================================
*  Name        : SocketsEngine.h
*  Part of     : CommunicationChannel
*  Interface   : 
*  Description : SocketsEngine interface
*  Version     : 1.0
*
*  Copyright (c) 2002 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/

#ifndef __SOCKETSENGINE_H__
#define __SOCKETSENGINE_H__

// INCLUDES
#include <in_sock.h>
#include "SocketsEngineObserver.h"
#include "SocketObserver.h"
#include "CSIPEngine.h"

// FORWARD DECLARATIONS
class CSocketsRead;
class CSocketsWrite;
class CSIPEngine;
//class CGameEngine;
//class CMessageServiceSearcher;

// CLASS DECLARATION
/**
*  CSocketsEngine
*
*  @lib CommunicationChannel
*/
class CSocketsEngine : public CActive, MSocketObserver
{
public:
		enum TSIPNetworkStatusType
	{
		EOffline=0,
		EOnline,
		ESessionConnected,
		EGPRSSuspended
	};

	/**
    * Two-phased constructor.
	* @param aObserver
	* @param aServer
	* @param aSipEngine
    */
	static CSocketsEngine* NewL(MSocketsEngineObserver& aObserver,TBool aServer , CSIPEngine* aSipEngine);
	
	/**
    * Two-phased constructor.
	* @param aObserver
	* @param aServer
	* @param aSipEngine
    */
	static CSocketsEngine* NewLC(MSocketsEngineObserver& aObserver,TBool aServer , CSIPEngine* aSipEngine);

	/**
    * Destructor.
    */
	~CSocketsEngine();

public:

	/**
    * Sets a connected socket for SocketsEngine
    * @param socket Socket to be set
	* @param aServer
	*/
	void SetSocket(RSocket *socket, TBool aServer = EFalse);

	RPointerArray<TDes8> GettingPtr();
	/**
    * Connects TCP socket
    */
	void ConnectL();
	
	/**
    * Disconnects SocketsEngine
    */
	void Disconnect();
	
	/**
    * Writes data to socket.
    * @param aData Data to be written
    * @return iRequestId
    */
	TInt WriteL(HBufC8* aData);
	
	/**
    * Starts SocketsReader
    */
	void Read();
	
	/**
    * Sets server name
    * @param aName Server name
    */
	void SetServerName(const TDesC& aName);
	
	/**
    * Gets server name
    * @return Name of the server
    */
	const TDesC& ServerName() const;
	
	/**
    * Sets port
    * @param aPort Port to be set.
    */
	void SetPort(TInt aPort);
	
	/**
    * Gets port.
    * @return port
    */
	TInt Port() const;
	
	/**
    * Check if connected
    * @return ETrue if connected
    */
	TBool Connected() const;

	void Clear();

	void SetSender(TInt sender);

	TInt GetSender();

public:	// from MSocketObserver

	/**
    * From MSocketObserver Socket packed send completed
    */
	void SendCompleted();
	
	/**
    * From MSocketObserver Socket timeout
    */
	void SocketTimeout();
	
	/**
    * From MSocketObserver Packet received from socket
	* @param aPacket Received packet
    */
	void PackedReceived(TDesC8& aPacket);

	void SetFilePath(const TDesC& aFileSend);

public:  // from MTimeOutNotify
	TInt GetiRecieveFileSize();
	TInt GetiCountRecieved();

	// DATA
	enum TSocketsEngineState
	{
		ENotConnected,
		EConnecting,
		EConnected,
		ETimedOut,
		ELookingUp,
		ELookUpFailed,
		EConnectFailed,
		EDisconnecting
	};

protected:

	/**
    * From CActive This function is called as part of the active object�s Cancel()
    */
	void DoCancel();

	/**
    * From CActive Handles an active object�s request completion event
    */
	void RunL();

private:

	/**
    * C++ default constructor.
    */
	CSocketsEngine(MSocketsEngineObserver& aObserver,TBool aServer, CSIPEngine* aSipEngine);

	/**
    * By default Symbian 2nd phase constructor is private.
    */
	void ConstructL();
	
private:

	/**
    * Initializes SocketsEngine
    */
	void InitializeL();

	/**
    * Connects TCP socket
    * @param aAddr Address to be connected
    */
	void ConnectL(TUint32 aAddr);

	/**
    * Changes SocketsEngine state
    * @param aNewStatus
    */
	void ChangeStatus(TSocketsEngineState aNewStatus);

private:
	
	MSocketsEngineObserver&     iObserver;
	TSocketsEngineState         iEngineStatus;
	CSocketsRead*               iSocketsRead;
	CSocketsWrite*              iSocketsWrite;
	RSocket*                    iSocket;
	RSocketServ                 iSocketServ;
	RHostResolver               iResolver;
	TNameEntry                  iNameEntry;
	TNameRecord                 iNameRecord;
	TInetAddr                   iAddress;
	TInt                        iPort;
	TBuf<128>					iServerName;
	TBool						iServer;
	TInt						iRequestId;
	CSIPEngine*					iSipEngine;
	TBool						iConnected;

	TFileName					iSendFileName;
};

#endif // __SOCKETSENGINE_H__

// End of File

