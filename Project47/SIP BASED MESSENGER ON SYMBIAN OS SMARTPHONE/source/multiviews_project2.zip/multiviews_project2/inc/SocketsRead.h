/*
* ==============================================================================
*  Name        : SocketsRead.h
*  Part of     : CommunicationChannel
*  Interface   : 
*  Description : SocketsRead interface
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/ 

#ifndef __SOCKETSREAD_H__
#define __SOCKETSREAD_H__

// INCLUDES
#include <in_sock.h>
#include "SocketObserver.h"

// FORWARD DECLARATIONS
class CGameEngine;

// CLASS DECLARATION

/**
*  CSocketsRead
*
*  @lib CommunicationChannel
*/
class CSocketsRead : public CActive
{
public:
	
	/**
    * Two-phased constructor.
    * @param aSocket RSocket
    * @param aObserver MSocketObserver
    * @param aReadBufferSize Size of the read buffer
    */
	static CSocketsRead* NewL(RSocket& aSocket,MSocketObserver& aObserver,TInt aReadBufferSize);
	
	/**
    * Two-phased constructor.
    * @param aSocket RSocket
    * @param aObserver MSocketObserver
    * @param aReadBufferSize Size of the read buffer
    */
	static CSocketsRead* NewLC(RSocket& aSocket,MSocketObserver& aObserver, TInt aReadBufferSize);
	
	/**
    * Destructor.
    */
	~CSocketsRead();
	
	/**
    * Starts reader
    */
	void Start();

	RPointerArray<TDes8> GettingBufferPtr();

	void Clear();
	

protected: //From CActive
	
	/**
    * This function is called as part of the active object�s Cancel()
    */
	void DoCancel();
	
	/**
    * Handles an active object�s request completion event
    */
	void RunL();	

private:
	
	/**
    * C++ default constructor.
    */
	CSocketsRead(RSocket& aSocket,MSocketObserver& aObserver);
	
	/**
    * By default Symbian 2nd phase constructor is private.
    */
	void ConstructL(TInt aReadBufferSize);
	
	/**
    * Reads from socket
    */
	void IssueRead();

private: 

	RSocket&                iSocket; 
	
	MSocketObserver&		iObserver;

	HBufC8*					iBuffer; 
	
	TSockXfrLength          iDummyLength;
	
	TPtr8					iPtr;

	///////////////////////////////////
	RPointerArray<TDes8>    iStreamBuf;

	TInt					iIdBuf;

	TBuf8<4096>				outbuf;

	CCoeEnv*				iCoeEnv;

	TInt					size;
	
	TBuf<50>				path;

public:
	TInt iCountRecieved;
	TInt	sender;
	// Transfer File
	TInt iRecieveFileSize;
	TBuf<100> iRecieveFileName;
};

#endif // __SOCKETSREAD_H__

// End of File