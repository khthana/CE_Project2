/*
* ==============================================================================
*  Name        : ServSocketsEngine.h
*  Part of     : CommunicationChannel
*  Interface   : 
*  Description : ServSocketsEngine interface
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/ 

#ifndef __SERVSOCKETSENGINE_H__
#define __SERVSOCKETSENGINE_H__

//INCLUDES
#include <in_sock.h>
#include <bt_sock.h>
#include <SocketsEngineObserver.h>


// FORWARD DECLARATIONS
class CSocketsEngine;

// CLASS DECLARATION
/**
*  CServSocketsEngine
*
*  @lib CommunicationChannel
*/
class CServSocketsEngine : public CActive
{
public:
	
	/**
    * Two-phased constructor.
    */
	static CServSocketsEngine* NewL(CSocketsEngine* eng,MSocketsEngineObserver& aObserver);
	
	/**
    * Two-phased constructor.
    */
	static CServSocketsEngine* NewLC(CSocketsEngine* eng,MSocketsEngineObserver& aObserver);
	
	/**
    * Destructor.
    */
	~CServSocketsEngine();
	
public:
	
	/**
    * Start listening for TCP connections.
    */
	void StartL();
	
	/**
    * Starts listening the port
    * @param aPort Port to listen
    */
	void StartSocketListenerL(TInt& aPort);
	
	/**
    * ?member_description.
    */
	void Disconnect();
	
	/**
    * Gets server name
    * @return Name of the server
    */
	const TDesC& ServerName();
	
	/**
    * Sets port
    * @param aPort Port to be set
    */
	void SetPort(TInt aPort);
	
	/**
    * Gets port.
    * @return port
    */
	TInt Port() const;

	/**
    * ?member_description.
    * @since 
    * @return ?description
    */
	TInt Address() const;

	/**
    * Checks if connected
    * @return True if connected
    */
	TBool Connected() const;

protected:

	/**
    * From CActive Implements cancellation of an outstanding request.
    */
	void DoCancel();

	/**
    * From CActive Handles an active object�s request completion event.
    */
	void RunL();

private:

	/**
    * C++ default constructor.
    */
	CServSocketsEngine(CSocketsEngine* eng,MSocketsEngineObserver& aObserver);
	
	/**
    * By default Symbian 2nd phase constructor is private.
    */
	void ConstructL();

private:

	// DATA TYPES
	enum TServSocketsEngineState
	{	
		ENotConnected,
		EConnecting,
		EConnected,
		ETimedOut,
		ELookingUp,
		ELookUpFailed,
		EConnectFailed,
		EDisconnecting
	};

	/**
    * Sets ServSocketsEngine state
    * @param aNewStatus
    */
	void ChangeStatus(TServSocketsEngineState aNewStatus);

private:
	
	TServSocketsEngineState     iEngineStatus;
	RSocket                     iListenSocket;
	RSocket                     iSocket;
    RSocket 					iAcceptedSocket;
	RSocketServ                 iSocketServ;
	TInetAddr                   iAddress;
	TInt                        iPort;
	TInt	                    iLocalAddress;
	TBuf<128>					iServerName;
	CSocketsEngine*				iSocketEngine;
	MSocketsEngineObserver&	iObserver;

};

#endif // __SERVSOCKETSENGINE_H__

// End of File