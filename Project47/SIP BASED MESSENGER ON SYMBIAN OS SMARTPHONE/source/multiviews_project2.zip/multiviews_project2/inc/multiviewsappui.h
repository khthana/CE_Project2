/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_APPUI_H__
#define __MULTIVIEWS_APPUI_H__

#include <aknViewAppUi.h>

//for Register SIP
#include "CSIPEngine.h"

//for menu id
#include "MultiViews.hrh"
//for KUidMultiViewsApp
#include "Multiviewsapplication.h"

//for CArray
#include "AccountList.h"
typedef TBuf<30> TPlayerName;
typedef TBuf<30> TPlayerNameAccount;
#define KTableScoreSize 5

//for connect file
#include <akndoc.h>
#include <e32math.h>
#include <e32base.h>
#include <f32file.h>
#include <s32file.h>

//Menu Bar
#include <akntitle.h>
#include <akncontext.h>
#include <aknnavide.h>





#include <MultiViews.mbg> // Bitmap enumeration

//_LIT(KFileStore,"C:\\System\\Apps\\MultiViews\\Account.dat");
_LIT(KFolderStore,"C:\\System\\Apps\\MultiViews\\");
_LIT(KMainPanePath, "\\system\\apps\\MultiViews\\MultiViews.mbm");

//File Systems c:\Nokia
#include <maknfileselectionobserver.h> 
#include <mmgfetchverifier.h> 
#include <mediafiletypes.hrh>

#include <txtrich.h>   //Richtext

#include <sendui.h>   // TSendingCapabilities, CSendAppUi

#include <AknWaitNoteWrapper.h> // MAknBackgroundProcess

//progess
// System includes
#include <aknnotedialog.h> // CAknWaitNoteWrapper
#include <eikprogi.h> // CEikProgressInfo
//#include <progressnote.rsg>
// User Includes
#include "ProgressNoteGameSaverAO.h" // CProgressNoteGameSaverAO


// FORWARD DECLARATIONS
class CMultiViewsAddAccountDialog;

// FORWARD DECLARATIONS
class CSendMessageDialog;

class CMultiViewsView1;
class CMultiViewsView2;
class CMultiViewsView3;

//Forward for Compile SIPEngine cause CSIPEngine must compile before
class CSIPEngine;

class CAudioPlayer;

class CRecordEngine;

class CPlayerEngine;

class CMultiViewsAppUi : public CAknViewAppUi,
							// for CAknFileSelectionDialog
							public MAknFileSelectionObserver, 
							// for MGFetch
							public MMGFetchVerifier	,
							public MAknBackgroundProcess
    {
public:
	CMultiViewsAppUi();
	~CMultiViewsAppUi();
    void ConstructL();
	//void Test();

public: // from CAknAppUi
	// DATA TYPES
	//0 = online 1=busy 2=away 3=offline
	enum TUserStatus
	{
		EOnline = 0,
		EBusy,
		EInCar,
		EOffline,
		EAppOffline,
	};

    void HandleCommandL(TInt aCommand);
//Handle KeyEven
	TKeyResponse HandleKeyEventL(const TKeyEvent& /*aKeyEvent*/,
    TEventCode /*aType*/);

	void ToSubScribe();
	void ToSubScribe(const TDesC8& user);
	void ToNotify(const TDesC8& user);
	void ToNotify();
	void ToMessage(const TDesC8& user,const TDesC8& aMsg);
	void ReceiveMsg(const TDesC8& user,const TDesC8& msg);

	void AddScoreL(const TAccountList& aAccountList);
    void SaveScoreL(const TDesC& aStore);
    void LoadScoreL(const TDesC& aStore);
    void ResetScore();
	void initScoreL();//create file to keep contact
	//void UpdateStatus(TPlayerName aUser);
	void UpdateStatus(const TDesC8& aUser,TInt aStatus,const TDesC8& aName,const TDesC8& aLocation);
	void UpdateStatus(const TDesC8& aUser,TInt aStatus);

	void UpdateBoard();
	void SortArray();

	/**/
	void ChangeContextStatus(TInt aStatus);
	void ChangeTitleUsername(TDesC16&);
	void ChangeTitleStatus();
	void SetTitleUsername();
	void ToHistory(const TDesC8& user,const TDesC16& msg,const TRgb& rgb);
	
	void GetMyName(TDes &aMyname);
	void GetLocationString();
	void GetMyLocation(TDes &aMyLocate);


	/*NEW ATTRIBUTE*/
	TBuf<KMaxPlayerNameLength> iMyName;
	TInt iMyStatus;
	TBool isOnline;
	//TBuf16<128> iSendFile;

	TInt GetStatus();
	void SendAwakeUser();
	void SetupListQueryItemArrayL();

	void CreateSMSL();
    void CreateEmailL();
	void CreateMMSL();


	void ToWaitDialog();
	void SetBeforeExit();
	void RegisFail();

	void DecodeL(const TDesC8& aUtf7);
    void EncodeL(const TDesC16& aUnicodeText);

	void GetBuf16(TDes16& aOutput16);
	void GetBuf8(TDes8& aOutput8);
	
	void SetIsRegis(TBool isRegis);

private: // members Wait Dialog
	void CancelGameSave();
	void CompleteGameSave();
	void SaveGamePartToFile();

private: // from MAknBackgroundProcess
	void DialogDismissedL(TInt /*aButtonId*/); 
	TBool IsProcessDone() const;
	void ProcessFinished();  
	void StepL();  

private:
	TBuf<128> buf;
    CMultiViewsView1* iAppView1;
    CMultiViewsView2* iAppView2;
	CMultiViewsView3* iAppView3;
	//for Register SIP
	CSIPEngine* iSipEngine;

	//Array List//for connect file
	CArrayFixSeg<TAccountList> *iAccountTable;		
	RFs iFs;  // FileServer Session ID

	//CMultiViewsAddAccountDialog* iAppDialog;
	//Buffer Get From DiaLog
	TBuf<KMaxPlayerNameLength> iPlayerName;

	CAknNavigationDecorator* iNaviDecorator;

	TBuf<50> iFileStoreName;
	TBuf<50> iFolderName;

	//TBuf16<60> iContactName;
	TPlayerName iContactName;
	//TBuf16<60> iContactRealName;
	TPlayerNameAccount iContactRealName;
	//For History Handle
	//CArrayFixSeg<CRichText*>* iRichText;
	CDesCArrayFlat* iListQueryItemArray;
	
	//SMS Email
	CRichText*           iRichText;
	CSendAppUi*          iSendAppUi;
    TSendingCapabilities iSendAppUiCapabilities;

	RTimer iTimeWaster;
	TInt iStepsCompleted;
	TBuf16<30> iTextBusyWhat;

	CProgressNoteGameSaverAO* iGameSaverAO;
	TBuf<100> iOutputBuffer;
	TBuf16<100> iOutput16Buffer;
	TBuf8<200> iOutput8Buffer;

	//sound effect
	CAudioPlayer* iAudioPlayer;
	TBool iSMyRegis;

	//record
	CRecordEngine* iRecordEngine;

	//play stream
	CPlayerEngine* iPlayerEngine;

//File Handle
private:
	/*
	* InitFileL()
	*  
	* Opens given aFileName file into it's default handler application. i.e. 
	* into the application that has been registered to handle the MIME type 
	* of given file. (e.g. video file into RealPlayer)
	*
	* Params: 
	*		aFileName: file to open.
	* 
	* Returns:
	* 		-
	*
	*/
	void InitFileL(const TDesC& aFileName) ;
	void ViewFileL(const TDesC& aFileName) ;

	/*
	* BrowseUsingMGFetchL()
	*  
	* Opens a new MGFetch dialog for browsing media files. Selected file
	* is opened into its default (handler) application.
	*
	* Params: 
	*		aMediaType: Media type to browse for. See mediafiletypes.hrh file
	*					for the TMediaFileType enumeration.
	* 
	* Returns:
	* 		-
	*
	*/
	void BrowseUsingMGFetchL(TMediaFileType aMediaType);
	
	/*
	* BrowseUsingAknSelectionDlg()
	*  
	* Opens a new CAknFileSelectionDialog for browsing files. Selected file
	* is opened into its default (handler) application.
	*
	* Params: 
	*		aPath:  Path from where to browse files. Also the root path for 
	*				browsing, meaning that user cannot go any path higher
	*				than the given path.
	* Returns:
	* 		-
	*
	*/
	void BrowseUsingAknSelectionDlg(/*const TFileName& aPath*/);
	void OpenUsingAknSelectionDlg(/*const TFileName& aPath*/);

// From MMGFetchVerifier
private:
	/*
	* VerifySelectionL()
	*  
	* When user has selected file(s) from MGFetch dialog, this method is 
	* called to verify the selected files.
	*
	* Params: 
	*		aSelectedFiles: array of selected files.
	* 
	* Returns:
	* 		ETrue if aSelectedFiles are verified. EFalse if if not (dialog
	*		remains open).
	*
	*/
	TBool VerifySelectionL (const MDesCArray *aSelectedFiles); 

// From MAknFileSelectionObserver
private:
	/*
	* OkToExitL()
	*  
	* Called when user has selected a file from CAknFileSelectionDialog.
	* Verify the validity of selected file here, and by returning ETrue 
	* the dialog is closed (file accepted).
	*
	* Params: 
	*		aDriveAndPath:	full path and name of the selected file.
	*		aEntry:			TEntry containing infomation about the selection;
	*						like file size and is it read only. (see TEntry).
	* 
	* Returns:
	* 		ETrue to close the dialog. EFalse if the dialog should still
	*		be open.
	*
	*/
	TBool OkToExitL (const TDesC &aDriveAndPath, const TEntry &aEntry);
	
	

    protected:
	    void BrowseRecordAmr();
    };


#endif // __MULTIVIEWS_APPUI_H__

