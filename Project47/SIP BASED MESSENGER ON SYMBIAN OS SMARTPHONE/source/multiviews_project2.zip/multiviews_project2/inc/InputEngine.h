#ifndef INPUTENGINE_H
#define INPUTENGINE_H

// INCLUDES
#include <e32base.h>
#include <aknviewappui.h> 

#include <mda\common\audio.h>
#include <MdaAudioInputStream.h>	// audio input stream
#include <MdaAudioOutputStream.h>	// audio output stream

//#include "Inputstream.hrh"
//#include "socketsappui.h"	

// FORWARD DECLARATIONS
//class MUINotifier;
//class CsocketsView;

class CInputEngine : public CBase, MMdaAudioInputStreamCallback, 
	MMdaAudioOutputStreamCallback
{
public:
    static CInputEngine* NewL();//MUINotifier& aConsole);

/*!
 * NewLC()
 * 
 * discussion Create new CInputEngine object
 * return a pointer to the created instance of CInputEngine which 
 *    has also been pushed to cleanup stack
 */
    static CInputEngine* NewLC();//MUINotifier& aConsole);


/*!
 * ~CInputEngine()
 *
 * discussion Destroy the object and release all memory objects
 */
	~CInputEngine();
        

public: // New functions
	
/*!
 * Play()
 *
 * discussion Plays the audio data sample
 */
	void Play();
/*!
 * Record()
 *
 * discussion Records an audio data sample
 */
	void Record();
/*!
 * Stop()
 *
 * discussion Stops the playing/recording of the audio data
 */
	void Stop();
	
/*!
 * LoadAudioFileL()
 *
 * discussion Loads an audio data from a file
 */
	
	void LoadAudioFileL();
/*!
 * SaveAudioFileL()
 *
 * discussion Saves the audio data into a file
 */
	void SaveAudioFileL();

// Get Pointer Buffer

	RPointerArray<TDes8> GetBufferPointer();

	void GetBufferPointer(RPointerArray<TDes8> aPtr);

	void SetFilePath(const TDesC& aFileSend);

private: // in-class methods

/*!
 * MaiscOpenComplete()
 *
 * discussion A callback function that is called when 
 *    CMdaAudioInputStream::Open() has completed, indicating that the audio 
 *    input stream is ready for use.
 *
 * param aError KErrNone if the open succeeded, otherwise one of the system 
 *    error codes.
 */
	virtual void MaiscOpenComplete(TInt aError);
/*!
 * MaiscBufferCopied()
 *
 * discussion A callback function that is called when a chunk of audio data 
 *    has been copied to the descriptor specified in a 
 *    CMdaAudioInputStream::ReadL().
 *
 * param aError KErrNone if the copy succeeded, KErrAbort if the input stream
 *    was closed for some reason, otherwise one of the system error codes.
 */
	virtual void MaiscBufferCopied(TInt aError, const TDesC8& aBuffer);
/*!
 * MaiscRecordComplete()
 *
 * discussion A callback function that is called when the input stream is
 *    closed using CMdaAudioInputStream::Stop(). 
 *
 * param aError KErrNone if the stop succeeded, otherwise one of the system
 *    error codes.
 */	
	virtual void MaiscRecordComplete(TInt aError);

/*!
 * MaoscOpenComplete()
 *
 * discussion A callback function that is called when 
 *    CMdaAudioOutputStream::Open() has completed, indicating that the audio 
 *    output stream is ready for use.
 *
 * param aError KErrNone if the open succeeded, otherwise one of the system 
 *    error codes.
 */
	virtual void MaoscOpenComplete(TInt aError);
/*!
 * MaoscBufferCopied()
 *
 * discussion A callback function that is called when a descriptor has been 
 *    copied to the lower layers of MMF. It is also called when an error has 
 *    occurred or when the client has stopped the stream playing before the 
 *    descriptor has been fully copied (by calling 
 *    CMdaAudioOutputStream::Stop())
 *
 * param aError KErrNone if the copy succeeded, otherwise one of the system
 *    error codes. KErrAbort indicates that the client has stopped the stream
 *    playing before the descriptor has been copied.
 * param aBuffer reference to the buffer that has been copied.
 */
	virtual void MaoscBufferCopied(TInt aError, const TDesC8& aBuffer);
	
/*!
 * MaoscPlayComplete()
 *
 * discussion A callback function that is called when playback terminates as
 *    a result of a CMdaAudioOutputStream::Stop().
 *
 * param aError KErrNone if the close succeeded, otherwise one of the system
 *    error codes.
 */
	virtual void MaoscPlayComplete(TInt aError);

public: // Functions from base classes

private: // Basic two-phase EPOC constructors

/*!
 * ConstructL()
 *
 * discussion Perform the second phase construction of a CInputEngine 
 *    object
 */
    void ConstructL();
 
/*!
 * CInputEngine()
 *
 * discussion Perform the first phase of two phase construction 
 */
    CInputEngine();//MUINotifier& aConsole);

private:	

	// enumeration of input/output stream status
	enum TStatus
		{
		ENotReady,
		EOpen
		};

		
private: 	// data members

	// application UI object reference
	//CSocketsAppUi* iAppUi;
	
	// audio input stream object reference
	CMdaAudioInputStream* iInputStream;
	// audio output stream object reference
	CMdaAudioOutputStream* iOutputStream;
	// a buffer (pointer array) containing the audio data blocks
	RPointerArray<TDes8> iStreamBuffer;
	// audio data stream settings for input and output streams
	TMdaAudioDataSettings iStreamSettings;
	// status enumeration of input stream
	TStatus iInputStatus;
	// status enumeration of output stream	
	TStatus iOutputStatus;
	// index of audio data block currently being played/recorded on the buffer
	TInt iStreamIdx;
	// application status message displayed to user
	TBuf<64> iMsg;
	// stream start (first audio block in buffer) and end index
	TInt iStreamStart;
	TInt iStreamEnd;
	TDes8* buffer;

	TBuf<128> iSendFileName;

	/////////////////////////////////
	/*! @var console for displaying text etc */
	//MUINotifier&                iConsole;

};

#endif // AUDIOSTREAMENGINE_H


