#ifndef __AUDIOPLAYER_H__
#define __AUDIOPLAYER_H__

#include <MdaAudioSamplePlayer.h>
#include <mda\common\audio.h>

class CMultiViewsAppUi;

class CAudioPlayer :	public CBase,
						public MMdaAudioPlayerCallback
	{
	public:
		enum TState	{ EStopped, EPlaying };

	public:
		static CAudioPlayer* NewL(CMultiViewsAppUi& aAppUi);
		static CAudioPlayer* NewLC(CMultiViewsAppUi& aAppUi);
		~CAudioPlayer();

	public:				// MMdaAudioPlayerCallback
		virtual void MapcInitComplete(TInt aError, const TTimeIntervalMicroSeconds& aDuration);
		virtual void MapcPlayComplete(TInt aError);

	public:
		void PlayWavL(TInt aInt);
		void Stop();

	public:
		inline const TState& State() const;

	private:
		CAudioPlayer(CMultiViewsAppUi& aAppUi);
		void ConstructL();

	private:
		CMdaAudioPlayerUtility*		iPlayerFile;
		CMultiViewsAppUi&		iAppUi;
		
		TState			iState;
	};

// inline functions
const CAudioPlayer::TState& CAudioPlayer::State() const		{ return iState; }

#endif
