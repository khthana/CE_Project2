/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_VIEW3_H__
#define __MULTIVIEWS_VIEW3_H__


#include <aknview.h>

//for CArray
#include "AccountList.h"

class CMultiViewsContainer3;

class CMultiViewsView3: public CAknView
    {
public:

    static CMultiViewsView3* NewL();
    static CMultiViewsView3* NewLC();

    ~CMultiViewsView3();


public: // from CAknView

    TUid Id() const;
    void HandleCommandL(TInt aCommand);

	//Handle KeyEven
	TKeyResponse HandleKeyEventL(const TKeyEvent& /*aKeyEvent*/,
    TEventCode /*aType*/);

	
	void DoActivateL(const TVwsViewId& aPrevViewId,
                   TUid aCustomMessageId,
                   const TDesC8& aCustomMessage);
	void DoDeactivate();
	TBool IsDisplay();
	void UpdateBoard();
	TInt GetBarPosition(); 

	
private:


    CMultiViewsView3();
    void ConstructL();


private:

    /*! @var iContainer container for this view */
    CMultiViewsContainer3* iContainer;

    /*! @var iIdentifier identifier for this view */
    TUid iIdentifier;

	TBool iDisplayBool;

	//Array List
	CArrayFixSeg<TAccountList> *iAccountTable;	

    };


#endif // __MULTIVIEWS_VIEW1_H__
