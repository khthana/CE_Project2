#ifndef ACCOUNTLIST_H
#define ACCOUNTLIST_H

#include <e32std.h>

#include <e32math.h>
#include <e32base.h>
#include <f32file.h>
#include <s32file.h>

//rich text
#include <txtrich.h>

typedef TBuf<30> TPlayerName;
typedef TBuf<30> TPlayerNameAccount;

class TAccountList
	{
public :
	TAccountList(TInt aStatus,const TDesC& aUsername,const TDesC& aIP);
	TAccountList();
	~TAccountList();
    //TPlayerName GetUsername();
	//TPlayerNameAccount GetIP();
	//TInt GetStatus();
	
	TInt GetStatus(TPlayerName& aName);
	void GetLocation(TPlayerNameAccount& aLocation);
	void GetIP(TPlayerName& aName,TPlayerNameAccount& aIP);
	TInt GetStatus(TPlayerName& aName,TPlayerNameAccount& aIP);

	void SetStatus(TInt status);
	void SetUsername(const TDesC& aUser);
	void SetLocation(const TDesC& aLocation);

	void ExternalizeL(RWriteStream& aStream) const;
    void InternalizeL(RReadStream& aStream);
        
	void SetRichTextAvailable(TBool aBool);
	TBool GetRichTextStatus();
	TBool IsMessageIn();
	void SetMessageInStatus(TBool aBool);
	
public :
	TInt        iStatus; //3=offline 0=online 1=busy 2=away
	TBool		isRichTextAvailable;
	TBool		isMessageIn;

	//RichText
	void AppendRichText(const TDesC& aText,const TRgb& rgb,TDes16& aName);
	void AppendRichText(const TDesC& aText,const TRgb& rgb);
	void ResetRichText();
	CRichText* GetRichText();
	void SetColor(const TRgb& rgb);

private:
	
	TPlayerNameAccount iIP;
	TPlayerName iUsername;
	TPlayerNameAccount iLocation;
	CRichText* iRichText;

	TCharFormatMask iCharFormatMask;
	TCharFormat	iCharFormat;
	
	};

#endif
