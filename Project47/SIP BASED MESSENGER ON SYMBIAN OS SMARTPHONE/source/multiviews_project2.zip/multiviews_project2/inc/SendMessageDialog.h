#ifndef SENDMESSAGEDIALOG_H
#define SENDMESSAGEDIALOG_H

// INCLUDES

// System includes
#include <akndialog.h>	// CAknDialog

// CLASS DECLARATION

/**
*
* @class	CSimpleDlgPlayerNameDialog SimpleDlgDialog.h 
* @brief	This is the dialog class for a dialog example using a
* dialog based architecture.  
*
* Copyright (c) EMCC Software Ltd 2003
* @version 1.0
*/
class CSendMessageDialog : public CAknDialog
	{
public: // static construction and execution

	static TBool RunDlgLD (TDes& aPlayerName);

protected:	// from CAknDialog

	TBool OkToExitL(TInt aButtonId);

protected: // from CEikDialog

	void PreLayoutDynInitL();

private: // Constructor

	CSendMessageDialog(TDes& aPlayerName) : iPlayerName(aPlayerName){};

private: // data
	TDes& iPlayerName;
	};

#endif	// #ifndef SENDMESSAGEDIALOG_H

// End of File
