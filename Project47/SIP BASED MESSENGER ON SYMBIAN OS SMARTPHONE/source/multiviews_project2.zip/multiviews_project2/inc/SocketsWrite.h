/*
* ==============================================================================
*  Name        : SocketsWrite.h
*  Part of     : CommunicationChannel
*  Interface   : 
*  Description : CSocketsWrite interface
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/ 

#ifndef __SOCKETSWRITE_H__
#define __SOCKETSWRITE_H__

// INCLUDES
#include <in_sock.h>
#include "SocketObserver.h"

// CLASS DECLARATION

/**
*  CSocketsWrite
*
*  @lib CommunicationChannel
*/
class CSocketsWrite : public CActive
{
public:

	/**
    * Two-phased constructor.
    * @param aSocket RSocket
    * @param aObserver  MSocketObserver
    */
	static CSocketsWrite* NewL(RSocket& aSocket, MSocketObserver& aObserver);

	/**
    * Two-phased constructor.
    * @param aSocket RSocket
    * @param aObserver MSocketObserver
    */
	static CSocketsWrite* NewLC(RSocket& aSocket, MSocketObserver& aObserver);

	/**
    * Destructor.
    */
	~CSocketsWrite();
	
	/**
    * Issues a write to socket. Takes ownership of HBufC8* aData
	* @param aData Data to be written
    */
	void IssueWriteL(HBufC8* aData);

protected:
	
	/**
    * This function is called as part of the active object�s Cancel()
    */
	void DoCancel();
	
	/**
    * Handles an active object�s request completion event
    */
	void RunL();

private:
	
	/**
    * C++ default constructor.
    */
	CSocketsWrite(RSocket& aSocket, MSocketObserver& aObserver);
	
	/**
    * By default Symbian 2nd phase constructor is private.
    */
	void ConstructL();

private:

	RSocket&                iSocket;

	MSocketObserver&		iObserver;
	
	HBufC8*					iTransferBuffer;
	
	// Storage of data to be sent
	CArrayPtrFlat<HBufC8>*	iMessageArray;
};

#endif // __SOCKETSWRITE_H__

// End of File