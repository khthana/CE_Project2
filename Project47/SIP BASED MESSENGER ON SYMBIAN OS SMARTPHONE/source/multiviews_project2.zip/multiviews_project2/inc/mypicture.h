/*
* ============================================================================
*  Name     : My Picure.net
*  Part of  : RTx
*  Created  : 2003. 08. 15. by (V) - Forum Nokia 
*  Description:
*     This is the project specification file for RTx.
*     
*     
*  Version  :
*  Copyright: Forum Nokia
* ============================================================================
*/


#ifndef CMYPICTURE_H
#define CMYPICTURE_H

// Similar to CTestPicture declared in conpics.h 
//class CTestPicture : public CPicture


#include <gdi.h>


class TSize;
class CFbsBitmap;


/**
*  
*/
class CMyPicture :public CPicture
    {

    public:  // Constructors and NO destructor (bitmap not owned)
        
        /**
        * C++ default constructor.
		* @param aSize Size of the picture in twips.
		* @param aBitmap Bitmap
        */
        CMyPicture( TSize aSize, CFbsBitmap& aBitmap );

	public: // From CPicture

		/**
		* Prohibit linebreaks.
		*/
		TBool LineBreakPossible( TUint aClass,
								 TBool aBeforePicture,
								 TBool aHaveSpaces ) const;
		/**
        * Draw the picture
        */
		 void Draw( CGraphicsContext& aGc,
						   const TPoint& aTopLeft,
						   const TRect& aClipRect,
						   MGraphicsDeviceMap* aMap ) const;
		/**
        * There's no need for it in this , but must be implemented.
        */
		 void ExternalizeL( RWriteStream& aStream ) const;
		
        /**
        * Sets the picture's size in twips.
		* @param aSize Size.
        */
		 void SetOriginalSizeInTwips( TSize aSize );

        /**
        * Returns the picture's size in twips.
		* @param aSize Size.
        */
		 void GetOriginalSizeInTwips( TSize& aSize ) const;

	protected:	// Data

		TSize iSizeInTwips; // Size of the bitmap data
		CFbsBitmap* iBitmap; // reference to the Bitmap data
    };

#endif
            
