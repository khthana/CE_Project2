/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_VIEW1_H__
#define __MULTIVIEWS_VIEW1_H__


#include <aknview.h>

//for CArray
#include "AccountList.h"

class CMultiViewsContainer1;

class CMultiViewsView1: public CAknView
    {
public:

    static CMultiViewsView1* NewL(CArrayFixSeg<TAccountList> *aAccountTable);
    static CMultiViewsView1* NewLC(CArrayFixSeg<TAccountList> *aAccountTable);

    ~CMultiViewsView1();


public: // from CAknView

    TUid Id() const;
    void HandleCommandL(TInt aCommand);

	//Handle KeyEven
	TKeyResponse HandleKeyEventL(const TKeyEvent& /*aKeyEvent*/,
    TEventCode /*aType*/);

	
	void DoActivateL(const TVwsViewId& aPrevViewId,
                   TUid aCustomMessageId,
                   const TDesC8& aCustomMessage);
	void DoDeactivate();
	TBool IsDisplay();
	void UpdateBoard();
	TInt GetBarPosition(); 
	void DecBarPosition();

	
private:


    CMultiViewsView1(CArrayFixSeg<TAccountList> *aAccountTable);
    void ConstructL();


private:

    /*! @var iContainer container for this view */
    CMultiViewsContainer1* iContainer;

    /*! @var iIdentifier identifier for this view */
    TUid iIdentifier;

	TBool iDisplayBool;

	//Array List
	CArrayFixSeg<TAccountList> *iAccountTable;	

    };


#endif // __MULTIVIEWS_VIEW1_H__
