#ifndef __CRECORDENGINE__
#define __CRECORDENGINE__

#include <e32std.h>
#include <MdaAudioSampleEditor.h>
#include <mda\\client\\utility.h> // for MMdaObjectStateChangeObserver

class CMultiViewsAppUi;


class CRecordEngine : public CBase, public MMdaObjectStateChangeObserver
    {
public:
    static CRecordEngine* NewL(CMultiViewsAppUi& aAppUi);
    static CRecordEngine* NewLC(CMultiViewsAppUi& aAppUi);
    ~CRecordEngine();

public: // from MAudioAdapter
    void RecordL();
	void StopL();
    const TDesC& Identify();

	///
	void LoadPCMFileL();
	void SaveAMRFileL();

public: // from MMdaObjectStateChangeObserver
    void MoscoStateChangeEvent(CBase* aObject, TInt aPreviousState, TInt aCurrentState, TInt aErrorCode);
    
private:
    CRecordEngine(CMultiViewsAppUi& aAppUi);
    void ConstructL();

private:
    CMdaAudioRecorderUtility* iMdaAudioRecorderUtility;
    CMultiViewsAppUi&		iAppUi;


	///////////////////////////////////
	RPointerArray<TDes8> iPCMBuffer;
	RPointerArray<TDes8> iAMRBuffer;
	
	TDes8* buffer;
    };

#endif // __CRecordEngine__
