#ifndef CSIPENGINE_H
#define CSIPENGINE_H

#include <sipobserver.h>
#include <sipprofileregistry.h> 
#include <sipprofileregistryobserver.h> 
#include <sipsubscribedialogassoc.h> 
#include <sipconnectionobserver.h> 

#include <SdpDocument.h> 
#include <SdpCodecStringPool.h>


#include <SdpMediaField.h>
#include <SdpTimeField.h>
#include <SdpConnectionField.h>

#include <sipsupportedheader.h>
#include <sipextensionheader.h>
#include <sipsupportedheader.h>
#include <es_sock.h> 

#include <SdpConnectionField.h>
#include <SdpOriginField.h>
#include <SdpCodecStringConstants.h>
#include <in_sock.h>

#include <s32strm.h>

#include "MultiViewsAppUi.h"

#include "ServSocketsEngine.h"
#include "SocketsEngine.h"
#include "InputEngine.h"
#include "PlayerEngine.h"

class CProgressNoteGameSaverAO;
class CSIPProfileRegistryObserver; 
class CSIPObserver; 
class CSIPConnectionObserver; 
class CSIP; 
class CSipProfileRegistry; 
class CSIPProfile; 
class CSIPConnection; 
class CSIPInviteDialogAssoc; 
class CSIPFromHeader; 
class CSIPToHeader; 
class CSIPContactHeader; 
class CSIPAddress; 
class CSIPClientTransaction; 
class CSIPResponseElements; 
class CSIPRequestElements; 
class CSIPServerTransaction;
class CSIPInviteDialogAssoc;

class CSIPTransactionExecutor;
class CSIPDialog;

//For Appui*
class CMultiViewsAppUi;

class CSIPEngine : 
	public CBase, 
	public MSIPProfileRegistryObserver, 
	public MSIPObserver, 
	public MSIPConnectionObserver,
	public MSocketsEngineObserver
{ 
	public: 
	enum TUserStatus
	{
		EOnline = 0,
		EBusy,
		EAway,
		EOffline,
		EAppOffline,
	};

	enum TSIPDirection
	{
		ESIPBoth = 0,
		ESIPActive,
		ESIPPassive
	};
	
		static CSIPEngine* NewL(TUid aUid,CMultiViewsAppUi *aAppUi);
		~CSIPEngine();

		// MSIPProfileRegistryObserver implementation. 
		// Move to cpp-file if further implementation.
		void ProfileCreated(TUint32 /*aSIPProfileId*/){} 
		void ProfileUpdated(TUint32 /*aSIPProfileId*/){} 
		void ProfileDestroyed(TUint32 /*aSIPProfileId*/){}
		void ProfileRegistryErrorOccurred( TUint32 /*aSIPProfileId*/,TInt /*aError*/){}
		void ProfileRegistrationStatusChanged(TUint32) ; 
	
		// MSIPObserver implementation. 
		// Move to cpp-file if further implementation. 
		void IncomingRequest( TUint32 /*aIapId*/, CSIPServerTransaction* /*aTransaction*/){} 
		virtual void TimedOut( CSIPServerTransaction& /*aSIPServerTransaction*/){} 
	
		// MSIPConnectionObserver implementation. 
		// Move to cpp-file if further implementation.
		void IncomingRequest ( CSIPServerTransaction* /*aTransaction*/, CSIPDialog& /*aDialog*/);
		void IncomingResponse ( CSIPClientTransaction& /*aTransaction*/){} 
		void IncomingResponse ( CSIPClientTransaction& /*aTransaction*/, CSIPInviteDialogAssoc* /*aDialogAssoc*/){} 
		void IncomingResponse ( CSIPClientTransaction& /*aTransaction*/, CSIPRegistration& /*aRegistration*/){} 
		void ErrorOccured ( TInt /*aError*/, CSIPTransactionBase& /*aTransaction*/){} 
		void ErrorOccured ( TInt /*aError*/, CSIPClientTransaction& /*aTransaction*/, CSIPRegistration& /*aRegistration*/){} 
		void ErrorOccured ( TInt /*aError*/, CSIPTransactionBase& /*aTransaction*/, CSIPDialogAssocBase& /*aDialogAssoc*/){} 
		void ErrorOccured ( TInt /*aError*/, CSIPRefresh& /*aSIPRefresh*/){} 
		void ErrorOccured ( TInt /*aError*/, CSIPRegistration& /*aRegistration*/){} 
		void ErrorOccured ( TInt /*aError*/, CSIPDialogAssocBase& /*aDialogAssoc*/){} 
		void InviteCompleted ( CSIPClientTransaction& /*aTransaction*/){} 
		void ConnectionStateChanged ( CSIPConnection::TState /*aState*/){}

		//From MCommunicationObserver Indicates that sending message is completed succesfully
		void SendMessageCompleted(TUint /*aRequestId*/){}
		void SendMessageError(TInt /*aErrorCode*/){}
		void MessageReceived(TDesC8& aMessageContent);
		void NetworkStatusChange(TInt /*aNetworkStatus*/){}

		CSIPInviteDialogAssoc* CreateSIPInviteDialogAssoc(const TDesC8& user); 
		//CSIPInviteDialogAssoc* CreateSIPInviteDialogAssoc(const TDesC8& user,const TDesC8& aMsg);

		CSIPSubscribeDialogAssoc* CreateSIPSubscribeDialogAssoc(const TDesC8& user); 
		CSIPRequestElements* CreateSIPRequestMessage(const TDesC8& user);
		CSIPRequestElements* CreateSIPRequestMessage(const TDesC8& user,const TDesC8& aMsg);
		
		CSIPConnection* GetConnection();
		CSocketsEngine* GetSocket();

		HBufC8* ProcessSDPL(CSdpDocument* aSdpDoc);
		
		HBufC8* CreateSDPL();
		HBufC8* CreateSDPL2();

		void ResolveLocalIP(TUint aIapId);
		TInt64 NTPTime();

		void ExecuteL(); 
		void Invite(const TDesC8& user);
		void Invite2(const TDesC8& user,TBool iIsSendAudio);
		
		void UnInvite();
		void Subscribe(const TDesC8& user);
		//void UnSubscribe(const TDesC8& user);
		void Notify(const TDesC8& user);
		void Message(const TDesC8& user,const TDesC8& aMsg);
		TBool IsRegistered();
		void IncomingResponse ( CSIPClientTransaction& , CSIPDialogAssocBase& ) ;

		// Move to cpp-file if further implementation. 
		//void IncomingRequest ( CSIPServerTransaction* /*aTransaction*/, CSIPDialog& /*aDialog*/);
		void IncomingRequest ( CSIPServerTransaction* ) ;
		void SendFile();

		/*NEW FUNCTION*/
		TDesC16& GetOwnUsername();
		
		void ToStatusChange();
		void SetFilePath(const TDesC& aFileSend);

				
	private: 
		TInt iIsRecieve;
	
		//CSIPEngine(TUid& aUid,CMultiViewsAppUi *aAppUi);
	CSIPEngine(TUid& aUid ,CMultiViewsAppUi *aAppUi);
	void ConstructL();
	TUid iUid; 
	
	/*NEW ATTRIBUTE*/
	/*TBuf<40> iMyName;
	TInt iMyStatus;*/


	CSIP* iSIP; 
	CSIPProfileRegistry* iProfileRegistry; 
	CSIPProfile* iProfile; 
	CSIPConnection* iConnection; 
	CSIPClientTransaction* iSIPClientTransaction; 
	CSIPInviteDialogAssoc* iSIPInviteDialogAssoc;
	CSIPSubscribeDialogAssoc* iSIPSubscribeDialogAssoc;

	CMultiViewsAppUi *iAppUi;
	TBuf16<40> iOwnUsername;
	
	/*NEW ATTRIBUTE*/
	TInt64		 iSDPVersionId;
	TInt64		 iSDPSessionId;
	TSIPDirection iSipDirection;
	TBuf<100>	 iOwnIP;

	// SDP Info
	TBuf<20>	 iOpponentIp;
	TInt		 iOpponentPort;
	TInt		 iListenPort;

	// TCP server engine
	CServSocketsEngine*	iServSocketsEngine;
	// TCP transfer socket engine
	CSocketsEngine*		iSocketsEngine;

	// Input Stream
	CInputEngine*	iInputEngine;

	RPointerArray<TDes8> iStream;

	//to send file path
	TBuf<128> iSendfile;

	CCoeEnv* iCoeEnv;

	CProgressNoteGameSaverAO* iGameSaverAO;

	public:
	TInt count;
		
	// Transfer File
	TInt iRecieveFileSize;
	TBuf<100> iRecieveFileName;
	
	//	Player Engine
	CPlayerEngine* iPlayerEngine;

};

#endif	// #ifndef CSIPEngine_H