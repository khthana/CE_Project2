#ifndef __PlayerEngine_H__
#define __PlayerEngine_H__



#include <MdaAudioOutputStream.h> 
#include <mda\common\audio.h>

class CMultiViewsAppUi;

class CPlayerEngine :	public CBase,
							public MMdaAudioOutputStreamCallback
	{
	public:
		enum TState	{ EStopped, EPlaying };

	public:
		 static CPlayerEngine* NewL();//CMultiViewsAppUi& aAppUi);
		 static CPlayerEngine* NewLC();//CMultiViewsAppUi& aAppUi);
		
		
		~CPlayerEngine();

	public:				// MMdaAudioOutputStreamCallback
		
		virtual void MaoscOpenComplete(TInt aError);
		virtual void MaoscBufferCopied(TInt aError, const TDesC8& aBuffer);
		virtual void MaoscPlayComplete(TInt aError);

	public:
		void Play();
		void Stop();
		
		//void LoadPCMFileL();
		void LoadAMRFileL();
		void SavePCMFileL();
		//void SaveAMRFileL();
		void LoadAudioFileL();
	
	private:
		CPlayerEngine();//CMultiViewsAppUi& aAppUi);
		void ConstructL();

		enum TStatus
		{
		ENotReady,
		EOpen
		};

	private:
		//CMdaAudioOutputStream*		iPlayerStream;
		//TMdaAudioDataSettings		iStreamSettings;
		//TUint8*						iStreamData;
		//TPtr8*						iStreamBuffer;

		///////////////////////////////////
		RPointerArray<TDes8> iPCMBuffer;
		RPointerArray<TDes8> iAMRBuffer;

		//TDes8* buffer;
		///////////////////////////////////
		//TState			iState;
	
		// audio output stream object reference
		CMdaAudioOutputStream* iOutputStream;
		// a buffer (pointer array) containing the audio data blocks
		RPointerArray<TDes8> iStreamBuffer;
		// audio data stream settings for input and output streams
		TMdaAudioDataSettings iStreamSettings;
		
		// status enumeration of output stream	
		TStatus iOutputStatus;
		// index of audio data block currently being played/recorded on the buffer
		TInt iStreamIdx;
		// stream start (first audio block in buffer) and end index
		TInt iStreamStart;
		TInt iStreamEnd;
		TDes8* buffer;

		//TBuf<128> iSendFileName;

		//CMultiViewsAppUi&		iAppUi;
	};


#endif
