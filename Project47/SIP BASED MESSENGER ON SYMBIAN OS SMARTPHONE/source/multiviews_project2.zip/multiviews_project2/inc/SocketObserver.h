/*
* ==============================================================================
*  Name        : SocketObserver.h
*  Part of     : CommunicationChannel
*  Interface   : 
*  Description : SocketObserver interface
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/ 

#ifndef _SOCKETOBSERVER_H_
#define _SOCKETOBSERVER_H_

// INCLUDES
#include <e32std.h>

// CLASS DECLARATION
/**
*  MSocketObserver
*
*  @lib CommunicationChannel
*/
class MSocketObserver
{
public:

	/**
    * Socket packed send completed
    */
	virtual void SendCompleted()=0;

	/**
    * Socket timeout
    */
	virtual void SocketTimeout()=0;

	/**
    * Packed received
    * @param aPacket Received packet
    */
	virtual void PackedReceived(TDesC8& aPacket)=0;
};

#endif _SOCKETSENGINEOBSERVER_H_

// End of File