/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_CONTAINER2_H__
#define __MULTIVIEWS_CONTAINER2_H__

// INCLUDES
#include <coecntrl.h>
#include <eikrted.h>
   
// FORWARD DECLARATIONS
//class CEikLabel;        // for example labels

// CLASS DECLARATION

//for draw background
#include <fbs.h> //CFbsBitmap
#include <aknutils.h>
#include <eikenv.h>		  // CEikonEnv iEikonEnv
#include <MultiViews.mbg> // Bitmap enumeration
#include "mypicture.h"  

//#include <eiklabel.h>  // for example label control
#include <coemain.h>
#include <eikenv.h>
#include <gdi.h>
#include <txtrich.h>
#include <txtetext.h>
#include <txtfrmat.h>
#include "MultiViewsView2.h"

class CFbsBitmap;
//path
_LIT(KMainPanePath, "\\system\\apps\\MultiViews\\MultiViews.mbm");



class CMultiViewsContainer2 : public CCoeControl, MCoeControlObserver
    {
    public: // New functions
		/*
		* NewL()
		*/

		static CMultiViewsContainer2* NewL(const TRect& aRect,CRichText* aRichText, CMultiViewsView2* iView/*,TDes& aName*/);

		/*
		* NewLC()
		*/
		static CMultiViewsContainer2* NewLC(const TRect& aRect,CRichText* aRichText, CMultiViewsView2* iView/*,TDes& aName*/);

		/**
        * Destructor.
        */
        ~CMultiViewsContainer2();

		/**
        * From CCoeControl,Draw.
        */
        void Draw(const TRect& aRect) const;

		void GetText(TDes16& aText);
		
		void AppendText(TDes16& aText,TDes16& aName);

		void AppendTextReceive(TDes16& aText,TDes16& aName);

		void SetColor(const TRgb& rgb);

		void ClearInputWindow();

		void ClearOutputWindow();
		
		void ToInsertMyPictureL(TInt32 aId);


    public: // Functions from base classes
	    TInt IsDown;

    private: // Functions from base classes

       /**
        * From CoeControl,SizeChanged.
        */
        void SizeChanged();

       /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

       /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;
       	
		/**
		* From MCoeControlObserver
		* Acts upon changes in the hosted control's state. 
		*
		* @param	aControl	The control changing its state
		* @param	aEventType	The type of control event 
		*/
        void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);

	private: // Constructors and destructor
        
        /**
        * EPOC default constructor.
        * @param aRect Frame rectangle for container.
        */
        void ConstructL(const TRect& aRect,CRichText* aRichText, CMultiViewsView2* iView/*,TDes& aName*/);

		CMultiViewsContainer2();

		TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
        
		//void AddToOutputWindowL(const TDesC& aText);
		void InsertMyPictureL(TInt aPos,TInt32 aId);


    private: //data
        CFbsBitmap* iBitmapOnline;
        CEikRichTextEditor*	iOutputWindow;
		CEikRichTextEditor* iInputWindow;
		TCharFormatMask iCharFormatMask;
		TCharFormat	iCharFormat;
	
		CRichText* iRichText;
		CMultiViewsView2* iView2;
		//TBuf16<60> iName;

    };

#endif // __MULTIVIEWS_CONTAINER2_H__