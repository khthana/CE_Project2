#ifndef MULTIVIEWSADDACCOUNTDIALOG_H
#define MULTIVIEWSADDACCOUNTDIALOG_H

// INCLUDES

// System includes
#include <akndialog.h>	// CAknDialog

#include <aknsettingitemlist.h>
#include <AknTextSettingPage.h>
#include <AknSettingPage.h>
#include <AknDialog.h>

#include <cntdb.h>
#include <cntfield.h>
#include <cntitem.h>
#include <cntfldst.h>


// CLASS DECLARATION

/**
*
* @class	CSimpleDlgPlayerNameDialog SimpleDlgDialog.h 
* @brief	This is the dialog class for a dialog example using a
* dialog based architecture.  
*
* Copyright (c) EMCC Software Ltd 2003
* @version 1.0
*/
class CMultiviewsAddAccountDialog : public CAknDialog
	{
public: // static construction and execution

	static TBool RunDlgLD (TDes& aPlayerName, CDesCArray* aArray);
	

	~CMultiviewsAddAccountDialog();

protected:	// from CAknDialog

	TBool OkToExitL(TInt aButtonId);
	void ConstructL(CDesCArray* aArray);
	void ShowNaviPaneText(TInt aResourceId);
	void ClearNaviPane();
	TBool InitFromContactsDbL();
	TInt EnterContact();

protected: // from CEikDialog

	void PreLayoutDynInitL();
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
	void ProcessCommandL( TInt aCommandId );
	void DynInitMenuPaneL( TInt aResourceId, CEikMenuPane* aMenuPane );

private: // Constructor

	CMultiviewsAddAccountDialog(TDes& aPlayerName) : iPlayerName(aPlayerName){};

private: // data
	TDes& iPlayerName;
	
	CDesCArray* iTextArray;
	CEikTextListBox* iListbox;
	CAknNavigationDecorator* iNaviDecorator;
	TInt mode;
	CDesCArray* iPhonebookArray;
	//CPeriodic* iTimer;
	TBool iContacts;
	CContactDatabase* iDatabase;
	};

#endif	// #ifndef SIMPLEDLGPLAYERNAMEDIALOG_H

// End of File
