/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_VIEW2_H__
#define __MULTIVIEWS_VIEW2_H__


#include <aknview.h>
#include <txtrich.h>


class CMultiViewsContainer2;

class CMultiViewsView2: public CAknView
    {
public:
    static CMultiViewsView2* NewL();

    static CMultiViewsView2* NewLC();


    ~CMultiViewsView2();


public: // from CAknView
    TUid Id() const;
    void HandleCommandL(TInt aCommand);

  void DoActivateL(const TVwsViewId& aPrevViewId,
                   TUid aCustomMessageId,
                   const TDesC8& aCustomMessage);
  void DoDeactivate();


  TBool IsDisplay();


	void ToGetText(TDes16& aText);
	
	void ToAppendText(TDes16& aText,TDes16& aName);
	void ToAppendTextReceive(TDes16& aText);

	void SetContactName(const TDes16& aContactName);
	void SetRealContactName(const TDes16& aContactName);
	void GetContactName(TDes16& aContactName);

	void ToAppendRichText(CRichText* aRichText);

	//CMultiViewsContainer2* AppContain();

	void ToInsertMyPictureL(TInt32 aId);
	void ClearInputWindow();
	void ClearOutputWindow();
    
private:

    CMultiViewsView2();

    void ConstructL();


private:

    CMultiViewsContainer2* iContainer;

    TUid iIdentifier;

	TBool iDisplayBool;

	TBuf16<60> iContactName;
	TBuf16<60> iRealContactName;

	CRichText* iRichText;

    };


#endif // __MULTIVIEWS_VIEW2_H__

