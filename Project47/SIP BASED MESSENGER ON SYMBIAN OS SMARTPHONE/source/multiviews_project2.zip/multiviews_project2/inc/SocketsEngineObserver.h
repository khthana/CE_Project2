/*
* ==============================================================================
*  Name        : SocketsEngineObserver.h
*  Part of     : CommunicationChannel
*  Interface   : 
*  Description : SocketsEngineObserver interface
*  Version     : 1.0
*
*  Copyright (c) 2004 Nokia Corporation.
*  This material, including documentation and any related 
*  computer programs, is protected by copyright controlled by 
*  Nokia Corporation. All rights are reserved. Copying, 
*  including reproducing, storing, adapting or translating, any 
*  or all of this material requires the prior written consent of 
*  Nokia Corporation. This material also contains confidential 
*  information which may not be disclosed to others without the 
*  prior written consent of Nokia Corporation.
* ==============================================================================
*/

#ifndef _SOCKETSENGINEOBSERVER_H_
#define _SOCKETSENGINEOBSERVER_H_

// DATA
enum TCBSIPErrorType
{
	ECBSIOErrorNone=KErrNone,
	ECBSIPErrorGameEngineTimeout,
	ECBSIPErrorNetworkTimeout,
	ECBSIPErrorNotConnected,
	ECBSIPErrorMessageSendFailed,
	ECBSIPErrorLogoutFailed,
	ECBSIPErrorLoginFailed,
	ECBSIPErrorMessageTooLong
};

enum TCBSIPNetworkStatusType
{
	ECBSIPNetworkActive=0,
	ECBSIPNetworkInactive,
	ECBSIPNetworkSuspended,
	ECBSIPSIPRegistered,
	ECBSIPSIPConnected,
	ECBSIPSIPDisconnected,
	ECBSIPSIPUnregistered

};

// CLASS DECLARATION

class MSocketsEngineObserver
{
public:

	/**
    * Indicates that sending message is completed succesfully
    * @param aRequestId 
    */
	virtual void SendMessageCompleted(TUint aRequestId)=0;

	/**
    * Indicates that message sending is failed
    * @param aErrorCode Error code
    */
	virtual void SendMessageError(TInt aErrorCode)=0;
	
	/**
    * Message received from opponent
    * @param aMessageContent Content of the received message
    */
	virtual void MessageReceived(TDesC8& aMessageContent) = 0;
	
	/**
    * Indicates that the network status has changed
    * @param aNetworkStatus Status of the network
    */
	virtual void NetworkStatusChange(TInt aNetworkStatus) = 0;

};

#endif

// End of file