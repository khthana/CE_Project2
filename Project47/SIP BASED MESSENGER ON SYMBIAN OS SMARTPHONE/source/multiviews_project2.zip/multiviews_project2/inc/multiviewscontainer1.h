/* Copyright (c) 2003, Nokia. All rights reserved */

#ifndef __MULTIVIEWS_CONTAINER1_H__
#define __MULTIVIEWS_CONTAINER1_H__

#include <aknview.h>

//for CArray
#include "AccountList.h"
typedef TBuf<30> TPlayerName;
typedef TBuf<30> TPlayerNameAccount;
#define KTableScoreSize 5

//for draw background
#include <fbs.h> //CFbsBitmap
#include <aknutils.h>
#include <eikenv.h>		  // CEikonEnv iEikonEnv
#include <MultiViews.mbg> // Bitmap enumeration

class CFbsBitmap;

//path
_LIT(KMainPanePath, "\\system\\apps\\MultiViews\\MultiViews.mbm");
const TInt KTopLeftX = 0;
const TInt KTopLeftY = 0;
const TInt KSizeWidth = 174;
const TInt KSizeHeight = 144;
const TInt KTextMaxLength = 50;

class CMultiViewsContainer1 : public CCoeControl
    {
public: 

	CMultiViewsContainer1(CArrayFixSeg<TAccountList> *aAccountTable);
	~CMultiViewsContainer1();

    static CMultiViewsContainer1* NewL(const TRect& aRect,
							CArrayFixSeg<TAccountList> *aAccountTable);
    static CMultiViewsContainer1* NewLC(const TRect& aRect,
							CArrayFixSeg<TAccountList> *aAccountTable);

    void ConstructL(const TRect& aRect);

public: // from CoeControl

    TInt CountComponentControls() const;
    CCoeControl* ComponentControl(TInt aIndex) const;

	void IncListBarPosition();
	void DecListBarPosition();

    void Draw(const TRect& aRect) const;
	TInt GetBarPosition(); 

private:
	//for draw Bitmap
	CFbsBitmap* iBitmap,* iBitmapBusy,* iBitmapOnline,* iBitmapOffline,* iBitmapAway,* iBitmapAlert;
	
	//Array List
	CArrayFixSeg<TAccountList> *iAccountTable;	

	TInt iListBarPosition;

    };

#endif // __MULTIVIEWS_CONTAINER1_H__
