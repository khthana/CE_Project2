//Galaxy.java
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
public class Galaxy extends MIDlet implements CommandListener {
private Command myExitCommand,myGoCommand,myPauseCommand,myNewCommand;
private GalaxyCanvas myCanvas;
private GameThread myGameThread;
public Galaxy() {
		myExitCommand = new Command("Exit", Command.EXIT, 2);
		myGoCommand = new Command("Go", Command.SCREEN, 1);
		myPauseCommand = new Command("Pause", Command.SCREEN, 1);
		myNewCommand = new Command("Play Again", Command.SCREEN, 1);
    	myCanvas = new GalaxyCanvas(this);
    	myCanvas.addCommand(myExitCommand);
    	myCanvas.addCommand(myGoCommand);
    	myCanvas.setCommandListener(this);
}
public void setNewCommand() {
    	myCanvas.removeCommand(myPauseCommand);
    	myCanvas.removeCommand(myGoCommand);
    	myCanvas.addCommand(myNewCommand);
}
public void setGoCommand() {
    	myCanvas.removeCommand(myPauseCommand);
    	myCanvas.removeCommand(myNewCommand);
    	myCanvas.addCommand(myGoCommand);
}
public void setPauseCommand() {
   	myCanvas.removeCommand(myNewCommand);
    	myCanvas.removeCommand(myGoCommand);
    	myCanvas.addCommand(myPauseCommand);
}
public void startApp() throws MIDletStateChangeException {
    	myGameThread = new GameThread(myCanvas);
    	myCanvas.start();
}
public void destroyApp(boolean unconditional) throws MIDletStateChangeException {
    	myGameThread.requestStop();
    	myGameThread = null;
    	myCanvas = null;
    	System.gc();
}
public void pauseApp() {
    	setGoCommand();
    	myGameThread.pause();
}
public void commandAction(Command c, Displayable s) {
   	 if(c == myGoCommand) {
      		myCanvas.removeCommand(myGoCommand);
      		myCanvas.addCommand(myPauseCommand);
     		 myGameThread.go();
   	 } else if(c == myPauseCommand) {
      		myCanvas.removeCommand(myPauseCommand);
      		myCanvas.addCommand(myGoCommand);
     		 myGameThread.go();
   	 } else if(c == myNewCommand) {
      		myCanvas.removeCommand(myNewCommand);
      		myCanvas.addCommand(myGoCommand);
      		myGameThread.requestStop();
      		myGameThread = new GameThread(myCanvas);
      		System.gc();
      		myCanvas.reset();
    	} else if(c == myExitCommand) {
      		try {
			destroyApp(false);
			notifyDestroyed();
      		} catch (MIDletStateChangeException ex) {
     	 	}
    	}
}
}
