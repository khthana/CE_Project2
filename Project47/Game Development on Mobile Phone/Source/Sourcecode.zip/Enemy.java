//Enemy.java
import java.util.Random;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
public class Enemy extends Sprite {
public static int WIDTH = 16;
private Random myRandom = new Random();
private boolean myGalaxyOver;
private boolean myLeft;
private int myY;
public Enemy(boolean left) throws Exception {
    super(Image.createImage("/Enemy.png"), WIDTH, WIDTH);
    myY = GalaxyManager.DISP_HEIGHT - WIDTH - 80;
    myLeft = left;
    if(!myLeft) {
		setTransform(TRANS_MIRROR);
    }
    myGalaxyOver = false;
    setVisible(false);
}
public void reset() {
    setVisible(false);
    myGalaxyOver = false;
}
public int advance(Ship Ship, int tickCount, boolean left,int currentLeftBound, int currentRightBound) {
    int retVal = 0;
    if((getRefPixelX() + WIDTH <= currentLeftBound) || (getRefPixelX() - WIDTH >= currentRightBound)) {
		setVisible(false);
    }
    if(!isVisible()) {
      int rand = getRandomInt(100);
      int rand2 = getRandomInt(175);
		  if(rand == 3) {
				myGalaxyOver = false;
				setVisible(true);
				if(myLeft) {
					setRefPixelPosition(currentRightBound, rand2);
					move(-1, 0);
				} else {
					setRefPixelPosition(currentLeftBound, rand2);
					move(1, 0);
				}
		 }
    } else {
		 if(tickCount % 2 == 0) {
				nextFrame();
		  }
		 if(myLeft) {
                   int rand3 = getRandomInt(20);
				move(-1, rand3-10);//position enemy
				if((!myGalaxyOver) && (getRefPixelX() < Ship.getRefPixelX())) {
					makeSound();
					myGalaxyOver = true;
					retVal = Ship.getScoreThisGalaxy();

				}
		 } else {
				move(3, 0);
				if((!myGalaxyOver) && (getRefPixelX() > Ship.getRefPixelX()+Ship.WIDTH)) {
					makeSound();
					myGalaxyOver = true;
					retVal = Ship.getScoreThisGalaxy();
				}
		 }
    }
    return(retVal);
}
public int getRandomInt(int upper) {
    int retVal = myRandom.nextInt() % upper;
    if(retVal < 0) {
		retVal += upper;
    }
    return(retVal);
  }
public void makeSound(){
	try{
		InputStream in = getClass().getResourceAsStream("/pass.wav");
		Player mp= Manager.createPlayer(in,"audio/x-wav");
		mp.start();
	}
		catch(Exception ex){}
}
}
