//GalaxyCanvas.java
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import java.io.*;
public class GalaxyCanvas extends javax.microedition.lcdui.game.GameCanvas {
public static int GROUND_HEIGHT = 32;
public static int CORNER_X;
public static int CORNER_Y;
public static int DISP_WIDTH;
public static int DISP_HEIGHT;
public static int FONT_HEIGHT;
public static Font FONT;
public static int SCORE_WIDTH;
public static int TIME_WIDTH;
private Display myDisplay;
private Galaxy myGalaxy;
private GalaxyManager myManager;
public static boolean myGameOver;
private int myScore = 0;
private int myInitialGameTicks = 5000;// /16 =time
private int myOldGameTicks = myInitialGameTicks;
private int myGameTicks = myOldGameTicks;
private boolean myInitialized;
public static String myInitialString = "1:00";
private String myTimeString = myInitialString;
public static void setGameOver() {
    	myGameOver = true;
    	GameThread.requestStop();
}
public static boolean getGameOver() {
    	return(myGameOver);
}
public GalaxyCanvas(Galaxy midlet) {
    	super(false);
    	myDisplay = Display.getDisplay(midlet);
    	myGalaxy = midlet;
}
public void start() {
    	myGameOver = false;
    	myDisplay.setCurrent(this);
    	repaint();
}
public void reset() {
    	myManager.reset();
    	myScore = 0;
    	myGameOver = false;
    	myGameTicks = myInitialGameTicks;
    	myOldGameTicks = myInitialGameTicks;
    	repaint();
}
public void flushKeys() {
    	getKeyStates();
}
public void paint(Graphics g) {
    	if(!myInitialized) {
      		CORNER_X = g.getClipX();
      		CORNER_Y = g.getClipY();
      		DISP_WIDTH = g.getClipWidth();
      		DISP_HEIGHT = g.getClipHeight();
      		FONT = g.getFont();
      		FONT_HEIGHT = FONT.getHeight();
      		SCORE_WIDTH = FONT.stringWidth("Score: 000");
      		TIME_WIDTH = FONT.stringWidth("Time: " + myInitialString);
      		myInitialized = true;
    	}
    	g.setColor(0xffffff);
    	g.fillRect(CORNER_X, CORNER_Y, DISP_WIDTH, DISP_HEIGHT);
    	g.setColor(0x999999);
    	g.fillRect(CORNER_X, CORNER_Y + DISP_HEIGHT - GROUND_HEIGHT, DISP_WIDTH, DISP_HEIGHT);
    	try {
      		if(myManager == null) {
			myManager = new GalaxyManager(CORNER_X, CORNER_Y + FONT_HEIGHT*2, DISP_WIDTH, DISP_HEIGHT - FONT_HEIGHT*2 - GROUND_HEIGHT);
      		}
      		myManager.paint(g);
    	} catch(Exception e) {
      		errorMsg(g, e);
    	}
    	g.setColor(0);
    	g.setFont(FONT);
    	g.drawString("Score: " + myScore,(DISP_WIDTH - SCORE_WIDTH)/2, DISP_HEIGHT + 5 - GROUND_HEIGHT, g.TOP|g.LEFT);
//    	g.drawString("Time: " + formatTime(),(DISP_WIDTH - TIME_WIDTH)/2, CORNER_Y + FONT_HEIGHT, g.TOP|g.LEFT);
    	if(myGameOver) {
      		myGalaxy.setNewCommand();
      		g.setColor(0xffffff);
      		g.fillRect(CORNER_X, CORNER_Y, DISP_WIDTH, FONT_HEIGHT*2 + 1);
     		int goWidth = FONT.stringWidth("Game Over");
      		g.setColor(0);
      		g.setFont(FONT);
      		g.drawString("Game Over", (DISP_WIDTH - goWidth)/2,CORNER_Y + FONT_HEIGHT, g.TOP|g.LEFT);
    	}
}
public String formatTime() {
    	if((myGameTicks / 16) + 1 != myOldGameTicks) {
      		myTimeString = "";
      		myOldGameTicks = (myGameTicks / 16) + 1;
      		int smallPart = myOldGameTicks % 60;
      		int bigPart = myOldGameTicks / 60;
      		myTimeString += bigPart + ":";
      		if(smallPart / 10 < 1) {
			myTimeString += "0";
      		}
      		myTimeString += smallPart;
    	}
    	return(myTimeString);
}
public void advance() {
    	myGameTicks--;
	myScore += myManager.advance(myGameTicks);
        if(myManager.isGameOver()){
          setGameOver();
        }
    	if(myGameTicks == 0) {
//      		setGameOver();
    	}
    	try {
      		paint(getGraphics());
      		flushGraphics();
    	} catch(Exception e) {
      		errorMsg(e);
    	}
    	synchronized(this) {
      		try {
			wait(1);
      		} catch(Exception e) {}
    	}
}
public void checkKeys() {
    	if(! myGameOver) {
      		int keyState = getKeyStates();
 //                     System.out.println(keyState);
      		if((keyState & LEFT_PRESSED) != 0) {
//			myManager.setLeft(true);
                        myManager.left();
      		}
      		if((keyState & RIGHT_PRESSED) != 0) {
//			myManager.setLeft(false);
                        myManager.right();
      		}
      		if((keyState & UP_PRESSED) != 0) {
			myManager.up();
      		}
                if((keyState & DOWN_PRESSED) != 0) {
			myManager.down();
                }
                if(keyState == 256){
                  myManager.shoot();
                }
 	}
}
public void errorMsg(Exception e) {
    	errorMsg(getGraphics(), e);
    	flushGraphics();
}
public void errorMsg(Graphics g, Exception e) {
    	if(e.getMessage() == null) {
      		errorMsg(g, e.getClass().getName());
    	} else {
      		errorMsg(g, e.getClass().getName() + ":" + e.getMessage());
    	}
}
public void errorMsg(Graphics g, String msg) {
    	g.setColor(0xffffff);
    	g.fillRect(CORNER_X, CORNER_Y, DISP_WIDTH, DISP_HEIGHT);
   	 int msgWidth = FONT.stringWidth(msg);
    	g.setColor(0x00ff0000);
    	g.setFont(FONT);
    	g.drawString(msg, (DISP_WIDTH - msgWidth)/2,(DISP_HEIGHT - FONT_HEIGHT)/2, g.TOP|g.LEFT);
    	myGameOver = true;
}
}
