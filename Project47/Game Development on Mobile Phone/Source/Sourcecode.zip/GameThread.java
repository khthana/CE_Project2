//GameThread.java
public class GameThread extends Thread {
private boolean myShouldPause;
public static boolean myShouldStop;
private boolean myAlreadyStarted;
private GalaxyCanvas myGalaxyCanvas;
public GameThread(GalaxyCanvas canvas) {
    	myGalaxyCanvas = canvas;
}
public void go() {
   	 if(!myAlreadyStarted) {
      		myAlreadyStarted = true;
     		 start();
    	} else {
      		myShouldPause = !myShouldPause;
   	}
}
public void pause() {
    	myShouldPause = true;
}
public static void requestStop() {
    	myShouldStop = true;
}
public void run() {
    	myGalaxyCanvas.flushKeys();
    	myShouldStop = false;
    	myShouldPause = false;
    	while(true) {
      		if(myShouldStop) {
			break;
     		}
      		if(!myShouldPause) {
			myGalaxyCanvas.checkKeys();
			myGalaxyCanvas.advance();
      		}
	}
}
}
