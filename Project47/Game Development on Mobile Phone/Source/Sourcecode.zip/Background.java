//Background.java
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
public class Background extends TiledLayer {
public static int TILE_WIDTH = 50;
public static int TILE_HEIGHT = 300;
public static int[] FRAME_SEQUENCE = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
public static int COLUMNS;
public static int CYCLE = 5;
public static int TOP_Y;
private int mySequenceIndex = 0;
private int myAnimatedTileIndex;

public Background() throws Exception {
    super(setColumns(GalaxyCanvas.DISP_WIDTH), 1, Image.createImage("/back1.png"), TILE_WIDTH, TILE_HEIGHT);
    TOP_Y = GalaxyManager.DISP_HEIGHT - TILE_WIDTH;
    setPosition(0, 0);
    myAnimatedTileIndex = createAnimatedTile(2);
    for(int i = 0; i < COLUMNS; i++) {
		if((i % CYCLE == 0) || (i % CYCLE == 2)) {
			setCell(i, 0, myAnimatedTileIndex);
		} else {
			setCell(i, 0, 1);
		}
    }
}
public static int setColumns(int screenWidth) {
    COLUMNS = ((screenWidth / 20) + 1)*3;
    return(COLUMNS);
  }
public void reset() {
    setPosition(-(TILE_WIDTH*CYCLE), 0);
    mySequenceIndex = 0;
    setAnimatedTile(myAnimatedTileIndex, FRAME_SEQUENCE[mySequenceIndex]);
}
public void advance(int tickCount) {
    if(tickCount % 5 == 0) {
		mySequenceIndex++;
		mySequenceIndex %= 20;
		setAnimatedTile(myAnimatedTileIndex, FRAME_SEQUENCE[mySequenceIndex]);
    }
}
}
