//Bullet.java
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
public class Bullet extends Sprite {
public static int WIDTH = 10;
public static int HEIGHT = 4;
public static int[] FRAME_SEQUENCE = {1,1,1,1};
private int myInitialX;
private int myInitialY;
private int myNoGalaxyInt = -6;
private int myIsGalaxying = myNoGalaxyInt;
private int myScoreThisGalaxy = 0;
private int tempX = 0;
private int tempChkX = 0;
private int limit = 0;

  public Bullet(int initialX, int initialY) throws Exception {
      super(Image.createImage("/testsun.png"),WIDTH, HEIGHT);
      myInitialX = initialX;
      myInitialY = initialY;
      defineReferencePixel(WIDTH/2, 0);
      setRefPixelPosition(myInitialX, myInitialY);
      setFrameSequence(FRAME_SEQUENCE);
      tempX = 0;
      tempChkX = 0;
  }

  public int checkCollision(Enemy Enemy) {
      int retVal = 0;
          myScoreThisGalaxy=0;
      if(collidesWith(Enemy, true)) {
                  try{
          InputStream in = getClass().getResourceAsStream("/collide.wav");
                  Player mp= Manager.createPlayer(in,"audio/x-wav");
                  mp.start();
                  }
                  catch(Exception ex){}

                  retVal = 1;
                  Enemy.setVisible(false);
                  Enemy.reset();
      }
      return(retVal);
  }
  public int checkCollision(Boss boss) {
      int retVal = 0;
          myScoreThisGalaxy=0;
      if(collidesWith(boss, true)) {
                  try{
          InputStream in = getClass().getResourceAsStream("/collide.wav");
                  Player mp= Manager.createPlayer(in,"audio/x-wav");
                  mp.start();
                  }
                  catch(Exception ex){}


                  boss.life--;
                  if(boss.life==0){
                    boss.setVisible(false);
                    retVal = 1000;
                  }else{
                    myInitialX = 10000;
                    myInitialY = 10000;
                    limit=100;
                  }

      }
      return(retVal);
  }
public void reset() {
    myIsGalaxying = myNoGalaxyInt;
    setRefPixelPosition(myInitialX, myInitialY);
    setFrameSequence(FRAME_SEQUENCE);
    myScoreThisGalaxy = 0;
    setTransform(TRANS_NONE);
}
public void advance(int tickCoun) {
    setRefPixelPosition(myInitialX+tempX, myInitialY);
//    System.out.println(myInitialY);


}
  public void shoot(int x,int y) {
//    if(tempX<20)
    if(limit>50){
      myInitialX = x;
      myInitialY = y;
      tempX = 0;
      limit = 0;
    }
    tempX = tempX+3;
  }
  public void shoot(int x) {
    myInitialX = x;
    limit = limit+1;
    tempX = tempX+3;
  }
}
