//GalaxyManager.java
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import java.io.*;
public class GalaxyManager extends javax.microedition.lcdui.game.LayerManager {
public static int CANVAS_X;
public static int CANVAS_Y;
public static int DISP_WIDTH;
public static int DISP_HEIGHT;
private Ship myShip;
private Bullet myBullet;
private Enemy[] myLeftEnemys;
private Enemy[] myRightEnemys;
private Boss boss;
private Background myBackground;
boolean myLeft;
private int myCurrentLeftX;
boolean gameOver = false;
public void setLeft(boolean left) {
		myLeft = left;
}
public GalaxyManager(int x, int y, int width, int height) {
		CANVAS_X = x;
		CANVAS_Y = y;
		DISP_WIDTH = width;
		DISP_HEIGHT = height;
		myCurrentLeftX = Background.CYCLE*Background.TILE_WIDTH;
		setViewWindow(0, 0, DISP_WIDTH, DISP_HEIGHT);
}
void reset() {
		if(myBackground != null) {
			myBackground.reset();
		}
		if(myShip != null) {
			myShip.reset();
		}
		if(myLeftEnemys != null) {
			for(int i = 0; i < myLeftEnemys.length; i++) {
				myLeftEnemys[i].reset();
			}
		}
		if(myRightEnemys != null) {
			for(int i = 0; i < myRightEnemys.length; i++) {
				myRightEnemys[i].reset();
			}
		}
		myLeft = false;
		myCurrentLeftX = 0;//Background.CYCLE*Background.TILE_WIDTH;
                gameOver = false;
}
public void paint(Graphics g) throws Exception {
		if(myShip == null) {
			  myShip = new Ship(myCurrentLeftX ,DISP_HEIGHT/2 - Ship.HEIGHT +24);//set position Ship
			  append(myShip);
		}
		if(myLeftEnemys == null) {
			  myLeftEnemys = new Enemy[4];//number of enemy
			  for(int i = 0; i < myLeftEnemys.length; i++) {
					myLeftEnemys[i] = new Enemy(true);
					append(myLeftEnemys[i]);
			  }
		}
               System.out.println("waitingBos = "+myShip.waitingBos);
              if(myShip.waitingBos == 1){//time bos

                  boss = new Boss(true);
                  append(boss);
                  append(myBackground);
                }
/*
              if(myRightEnemys == null) {
			  myRightEnemys = new Enemy[2];
			  for(int i = 0; i < myRightEnemys.length; i++) {
					myRightEnemys[i] = new Enemy(false);
					append(myRightEnemys[i]);
			  }
		}*/
                if(myBullet == null){
                         myBullet = new Bullet(1000,1000);
                         append(myBullet);
                }
                if(myBackground == null) {
                          myBackground = new Background();
                          append(myBackground);
                }
		setViewWindow(myCurrentLeftX, 0, DISP_WIDTH, DISP_HEIGHT);
		paint(g, CANVAS_X, CANVAS_Y);
}
public void wrap() {
		if(myCurrentLeftX % (Background.TILE_WIDTH*Background.CYCLE) == 0) {
			  if(myLeft) {
					myShip.move(Background.TILE_WIDTH*Background.CYCLE, 0);
					myCurrentLeftX += (Background.TILE_WIDTH*Background.CYCLE);
					for(int i = 0; i < myLeftEnemys.length; i++) {
						myLeftEnemys[i].move(Background.TILE_WIDTH*Background.CYCLE, 0);
					}
/*					for(int i = 0; i < myRightEnemys.length; i++) {
						myRightEnemys[i].move(Background.TILE_WIDTH*Background.CYCLE, 0);
					}*/
			  } else {
					myShip.move(-(Background.TILE_WIDTH*Background.CYCLE), 0);
					myCurrentLeftX -= (Background.TILE_WIDTH*Background.CYCLE);
					for(int i = 0; i < myLeftEnemys.length; i++) {
						myLeftEnemys[i].move(-Background.TILE_WIDTH*Background.CYCLE, 0);
					}
/*					for(int i = 0; i < myRightEnemys.length; i++) {
						myRightEnemys[i].move(-Background.TILE_WIDTH*Background.CYCLE, 0);
					}*/
			  }
		}
}
public int advance(int gameTicks) {
		int retVal = 0;
		if(myLeft) {
			myCurrentLeftX--;
		} else {
			myCurrentLeftX++;
		}
                myBackground.advance(gameTicks);
                myShip.advance(gameTicks, myLeft);
                myBullet.shoot(myShip.myInitialX);
                myBullet.advance(gameTicks);
//		myShip.advance(gameTicks, myLeft);
                if(boss != null){
                  boss.advance(myShip, gameTicks, myLeft, myCurrentLeftX,
                               myCurrentLeftX + DISP_WIDTH);
                  //System.out.println("*******************************"+boss.life);
                  int chk2 = myBullet.checkCollision(boss);
                  if(chk2==1000){
                    gameOver = true;
                  }
                }
		for(int i = 0; i < myLeftEnemys.length; i++) {
			myLeftEnemys[i].advance(myShip, gameTicks, myLeft, myCurrentLeftX, myCurrentLeftX + DISP_WIDTH);
                        retVal += myBullet.checkCollision(myLeftEnemys[i]);
			int chk= myShip.checkCollision(myLeftEnemys[i]);
                        if(chk >0){
                         gameOver = true;// chk Ship collision
                        }
		}
/*		for(int i = 0; i < myRightEnemys.length; i++) {
			retVal -= myRightEnemys[i].advance(myShip, gameTicks, myLeft, myCurrentLeftX, myCurrentLeftX + DISP_WIDTH);
			retVal += myShip.checkCollision(myRightEnemys[i]);
		}*/
		wrap();
		return(retVal);
}
public void up() {
  myShip.up();
}
public void left() {
  myShip.left();
}
public void right() {
  myShip.right();
}
public void down() {
  myShip.down();
}
public void shoot(){
//  myBullet = null;
  myBullet.shoot(myShip.myInitialX, myShip.myInitialY);
}
public boolean isGameOver(){
  return gameOver;
}
}
