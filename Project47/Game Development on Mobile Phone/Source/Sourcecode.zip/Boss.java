//Boss.java
import java.util.Random;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
public class Boss extends Sprite {
public static int WIDTH = 16;
private Random myRandom = new Random();
private boolean myGalaxyOver;
private boolean myLeft;
  public int life = 2;
private int myY;
private int tempY = 0;
public Boss(boolean left) throws Exception {
    super(Image.createImage("/Boss.png"), WIDTH, WIDTH);// bos image
    myY = GalaxyManager.DISP_HEIGHT - WIDTH - 80;
    myLeft = left;
    if(!myLeft) {
                setTransform(TRANS_MIRROR);
    }
    myGalaxyOver = false;
    setVisible(false);
}
public void reset() {
    setVisible(false);
    myGalaxyOver = false;
}
public int advance(Ship Ship, int tickCount, boolean left,int currentLeftBound, int currentRightBound) {
    int retVal = 0;
      {if(tempY>myY){
        if(myY>0){//position bos
          tempY = myY;
          myY--;
        }else{
          tempY=myY;
          myY++;
        }}else{
        if(myY<170){//position bos
          tempY=myY;
          myY++;
        }else{
          tempY = myY;
          myY--;
        }}

                                myGalaxyOver = false;
                                setVisible(true);
                                        setRefPixelPosition(currentRightBound-50, myY);
                 if(tickCount % 2 == 0) {
                                nextFrame();
                  }
    }
    return(retVal);
}
}
