//Ship.java
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
public class Ship extends Sprite {
public static int WIDTH = 50;
public static int HEIGHT = 20;
public static int[] FRAME_SEQUENCE = { 1};
public int myInitialX;
public int myInitialY;
private int myNoGalaxyInt = -6;
private int myIsGalaxying = myNoGalaxyInt;
private int myScoreThisGalaxy = 0;
private int tempX = 0;
private int tempChkX = 0;
public int waitingBos = 0;

public Ship(int initialX, int initialY) throws Exception {
    super(Image.createImage("/testyan.png"),WIDTH, HEIGHT);
    myInitialX = initialX;
    myInitialY = initialY;
    defineReferencePixel(WIDTH/2, 0);
    setRefPixelPosition(myInitialX, myInitialY);
    setFrameSequence(FRAME_SEQUENCE);
    tempX = 0;
    tempChkX = 0;
}
public int checkCollision(Enemy Enemy) {
    int retVal = 0;
        myScoreThisGalaxy=0;
    if(collidesWith(Enemy, true)) {
                try{
        InputStream in = getClass().getResourceAsStream("/collide.wav");
                Player mp= Manager.createPlayer(in,"audio/x-wav");
                mp.start();
                }
                catch(Exception ex){}

                retVal = getScoreThisGalaxy();
                Enemy.setVisible(false);
                Enemy.reset();
    }
    return(retVal);
}
public void reset() {
    myIsGalaxying = myNoGalaxyInt;
    setRefPixelPosition(myInitialX, myInitialY);
    setFrameSequence(FRAME_SEQUENCE);
    myScoreThisGalaxy = 0;
    setTransform(TRANS_NONE);
}
public void advance(int tickCount, boolean left) {
    int tempX = this.tempX;
    this.tempX=0;
    if(tempX<0){
      if (tempChkX >= 2)
        tempChkX = tempChkX + tempX;
      else
      if ( (tempChkX < 4))
        tempX = 0;
    }else if(tempX>0){
      if (tempChkX <= 192)
        tempChkX = tempChkX + tempX;
      else
      if ( (tempChkX > 190))
        tempX = 0;
    }
    if(myInitialY < 1)
      myInitialY = myInitialY+2;
    else if(myInitialY > 171)//mobile 88  demo 171
      myInitialY = myInitialY-2;

//    setRefPixelPosition(getRefPixelX()+1+tempX, myInitialY);
//    System.out.println(tempChkX);

    this.myInitialX = getRefPixelX()+1+tempX;
    setRefPixelPosition(getRefPixelX()+1+tempX, myInitialY);
 System.out.println(myInitialY);
    waitingBos++;

}
  public void up() {
    myInitialY = myInitialY-2;
  }
  public void down() {
  myInitialY = myInitialY+2;
}
  public void right() {
//    if(tempX<20)
    tempX = tempX+2;
  }
  public void left() {
//    if(tempX>0)
    tempX = tempX-2;
  }
public int getScoreThisGalaxy(){
    if(myScoreThisGalaxy == 0) {
                myScoreThisGalaxy++;
    } else {
                myScoreThisGalaxy *= 2;
    }

    return(myScoreThisGalaxy);
}
}
