
/*  A Bison parser, made from naslparser.y with Bison version GNU Bison version 1.24
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	IF	258
#define	ELSE	259
#define	EQ	260
#define	NEQ	261
#define	SUPEQ	262
#define	INFEQ	263
#define	OR	264
#define	AND	265
#define	MATCH	266
#define	NOMATCH	267
#define	REP	268
#define	FOR	269
#define	REPEAT	270
#define	UNTIL	271
#define	FOREACH	272
#define	WHILE	273
#define	BREAK	274
#define	FUNCTION	275
#define	RETURN	276
#define	INCLUDE	277
#define	LOCAL	278
#define	GLOBAL	279
#define	PLUS_PLUS	280
#define	MINUS_MINUS	281
#define	L_SHIFT	282
#define	R_SHIFT	283
#define	R_USHIFT	284
#define	EXPO	285
#define	PLUS_EQ	286
#define	MINUS_EQ	287
#define	MULT_EQ	288
#define	DIV_EQ	289
#define	MODULO_EQ	290
#define	L_SHIFT_EQ	291
#define	R_SHIFT_EQ	292
#define	R_USHIFT_EQ	293
#define	RE_MATCH	294
#define	RE_NOMATCH	295
#define	IDENT	296
#define	STRING1	297
#define	STRING2	298
#define	INTEGER	299
#define	NOT	300
#define	UMINUS	301
#define	BIT_NOT	302

#line 1 "naslparser.y"

/* Parser for Nessus Attack Scripting Language version 2
 *
 * Copyright (C) 2004 - 2005 Apisak Srihamat and Nattawut Tintavon
 * Department of Computer Engineering Faculty of Engineering 
 * King Mongkut's Institute of Technology Ladkrabang Bangkok, Thailand
 * Reference from Nessus Attack Scripting Language version 2
 * by Michel Arboi and Renaud Deraison
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2,
 * as published by the Free Software Foundation
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 *
 */
#include <stdlib.h>         
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include <winsock2.h>

#include "nasl_global_ctxt.h"
#include "nasl_tree.h"
#include "nasl_lex_ctxt.h"
#include "nasl_var.h"
#include "nasl_func.h"
#include "nasl_regex.h"
#include "libnessus.h"


#define YYPARSE_PARAM parm
//#define YYLEX_PARAM parm

//#define YYERROR_VERBOSE

// for DEBUG
FILE *output; 
extern FILE *parse_tree;
extern int line_number;


#line 52 "naslparser.y"
typedef union {
  int		num;
  char		*str;
  struct asciiz {
    char	*val;
    int		len;
  } data;
  tree_cell	*node;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		209
#define	YYFLAG		-32768
#define	YYNTBASE	71

#define YYTRANSLATE(x) ((unsigned)(x) <= 302 ? yytranslate[x] : 107)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    68,     2,     2,     2,    55,    50,     2,    59,
    60,    53,    51,    61,    52,    70,    54,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    65,    64,    46,
    45,    47,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    66,     2,    67,    49,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    62,    48,    63,    69,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    56,
    57,    58
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     7,     9,    11,    18,    19,    21,    23,
    27,    31,    34,    36,    39,    42,    44,    46,    48,    50,
    52,    54,    56,    58,    60,    62,    64,    66,    67,    70,
    72,    78,    86,    88,    90,    92,    94,   104,   110,   116,
   123,   125,   127,   129,   130,   134,   136,   138,   143,   148,
   150,   151,   153,   157,   159,   163,   167,   171,   175,   179,
   183,   187,   191,   195,   199,   201,   203,   205,   207,   212,
   214,   217,   220,   223,   226,   230,   234,   237,   241,   245,
   249,   252,   255,   259,   263,   267,   271,   275,   279,   283,
   287,   291,   295,   297,   301,   305,   309,   313,   317,   321,
   325,   329,   333,   337,   339,   341,   343,   345,   347,   349,
   351,   353,   355,   363,   366
};

static const short yyrhs[] = {    72,
     0,    73,     0,    73,    72,     0,    79,     0,    74,     0,
    20,    98,    59,    75,    60,    77,     0,     0,    76,     0,
    98,     0,    98,    61,    76,     0,    62,    78,    63,     0,
    62,    63,     0,    79,     0,    79,    78,     0,    80,    64,
     0,    77,     0,    82,     0,    83,     0,    96,     0,   101,
     0,    89,     0,    92,     0,    81,     0,    91,     0,   105,
     0,   106,     0,    19,     0,     0,    21,   102,     0,    21,
     0,     3,    59,   102,    60,    79,     0,     3,    59,   102,
    60,    79,     4,    79,     0,    84,     0,    85,     0,    86,
     0,    87,     0,    14,    59,    88,    64,   102,    64,    88,
    60,    79,     0,    18,    59,   102,    60,    79,     0,    15,
    79,    16,   102,    64,     0,    17,    98,    59,   102,    60,
    79,     0,    96,     0,   101,     0,    92,     0,     0,    92,
    13,   102,     0,    42,     0,    43,     0,    22,    59,    90,
    60,     0,    98,    59,    93,    60,     0,    94,     0,     0,
    95,     0,    95,    61,    94,     0,   102,     0,    98,    65,
   102,     0,    97,    45,   102,     0,    97,    31,   102,     0,
    97,    32,   102,     0,    97,    33,   102,     0,    97,    34,
   102,     0,    97,    35,   102,     0,    97,    37,   102,     0,
    97,    38,   102,     0,    97,    36,   102,     0,    98,     0,
    99,     0,    41,     0,    13,     0,    98,    66,   100,    67,
     0,   102,     0,    25,    97,     0,    26,    97,     0,    97,
    25,     0,    97,    26,     0,    59,   102,    60,     0,   102,
    10,   102,     0,    68,   102,     0,   102,     9,   102,     0,
   102,    51,   102,     0,   102,    52,   102,     0,    52,   102,
     0,    69,   102,     0,   102,    53,   102,     0,   102,    30,
   102,     0,   102,    54,   102,     0,   102,    55,   102,     0,
   102,    50,   102,     0,   102,    49,   102,     0,   102,    48,
   102,     0,   102,    28,   102,     0,   102,    29,   102,     0,
   102,    27,   102,     0,   101,     0,   102,    11,   102,     0,
   102,    12,   102,     0,   102,    39,    90,     0,   102,    40,
    90,     0,   102,    46,   102,     0,   102,    47,   102,     0,
   102,     5,   102,     0,   102,     6,   102,     0,   102,     7,
   102,     0,   102,     8,   102,     0,    44,     0,    43,     0,
    42,     0,   103,     0,    96,     0,   104,     0,    98,     0,
    99,     0,    92,     0,    44,    70,    44,    70,    44,    70,
    44,     0,    23,    75,     0,    24,    75,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   142,   150,   160,   171,   171,   174,   186,   192,   199,   206,
   218,   224,   231,   232,   250,   256,   256,   256,   259,   259,
   259,   260,   260,   260,   260,   260,   261,   269,   278,   287,
   299,   309,   321,   321,   321,   321,   322,   336,   347,   359,
   372,   372,   372,   372,   380,   392,   392,   395,   424,   435,
   435,   441,   441,   451,   461,   473,   481,   491,   497,   503,
   509,   515,   521,   527,   535,   540,   542,   542,   549,   560,
   562,   569,   575,   581,   590,   596,   602,   608,   614,   620,
   626,   632,   638,   644,   650,   656,   662,   668,   674,   680,
   686,   692,   698,   699,   705,   711,   717,   723,   729,   735,
   741,   747,   753,   759,   766,   774,   782,   782,   782,   784,
   792,   792,   794,   811,   823
};

static const char * const yytname[] = {   "$","error","$undefined.","IF","ELSE",
"EQ","NEQ","SUPEQ","INFEQ","OR","AND","MATCH","NOMATCH","REP","FOR","REPEAT",
"UNTIL","FOREACH","WHILE","BREAK","FUNCTION","RETURN","INCLUDE","LOCAL","GLOBAL",
"PLUS_PLUS","MINUS_MINUS","L_SHIFT","R_SHIFT","R_USHIFT","EXPO","PLUS_EQ","MINUS_EQ",
"MULT_EQ","DIV_EQ","MODULO_EQ","L_SHIFT_EQ","R_SHIFT_EQ","R_USHIFT_EQ","RE_MATCH",
"RE_NOMATCH","IDENT","STRING1","STRING2","INTEGER","'='","'<'","'>'","'|'","'^'",
"'&'","'+'","'-'","'*'","'/'","'%'","NOT","UMINUS","BIT_NOT","'('","')'","','",
"'{'","'}'","';'","':'","'['","']'","'!'","'~'","'.'","tiptop","instr_decl_list",
"instr_decl","func_decl","arg_decl","arg_decl_1","block","instr_list","instr",
"simple_instr","ret","if_block","loop","for_loop","while_loop","repeat_loop",
"foreach_loop","aff_func","rep","string","inc","func_call","arg_list","arg_list_1",
"arg","aff","lvalue","identifier","array_elem","array_index","post_pre_incr",
"expr","var","ipaddr","loc","glob",""
};
#endif

static const short yyr1[] = {     0,
    71,    72,    72,    73,    73,    74,    75,    75,    76,    76,
    77,    77,    78,    78,    79,    79,    79,    79,    80,    80,
    80,    80,    80,    80,    80,    80,    80,    80,    81,    81,
    82,    82,    83,    83,    83,    83,    84,    85,    86,    87,
    88,    88,    88,    88,    89,    90,    90,    91,    92,    93,
    93,    94,    94,    95,    95,    96,    96,    96,    96,    96,
    96,    96,    96,    96,    97,    97,    98,    98,    99,   100,
   101,   101,   101,   101,   102,   102,   102,   102,   102,   102,
   102,   102,   102,   102,   102,   102,   102,   102,   102,   102,
   102,   102,   102,   102,   102,   102,   102,   102,   102,   102,
   102,   102,   102,   102,   102,   102,   102,   102,   102,   103,
   103,   103,   104,   105,   106
};

static const short yyr2[] = {     0,
     1,     1,     2,     1,     1,     6,     0,     1,     1,     3,
     3,     2,     1,     2,     2,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     0,     2,     1,
     5,     7,     1,     1,     1,     1,     9,     5,     5,     6,
     1,     1,     1,     0,     3,     1,     1,     4,     4,     1,
     0,     1,     3,     1,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     1,     1,     1,     1,     4,     1,
     2,     2,     2,     2,     3,     3,     2,     3,     3,     3,
     2,     2,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     1,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     7,     2,     2
};

static const short yydefact[] = {    28,
     0,    68,     0,    28,     0,     0,    27,     0,    30,     0,
     7,     7,     0,     0,    67,    28,     1,     2,     5,    16,
     4,     0,    23,    17,    18,    33,    34,    35,    36,    21,
    24,    22,    19,     0,    65,    66,    20,    25,    26,     0,
    44,     0,     0,     0,     0,   106,   105,   104,     0,     0,
     0,     0,   112,   108,   110,   111,    93,    29,   107,   109,
     0,   114,     8,     9,   115,    71,    65,    72,    12,     0,
    13,     3,    15,     0,    73,    74,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    51,     0,     0,     0,    43,
    41,    42,     0,     0,     0,     7,     0,    81,     0,    77,
    82,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    46,    47,     0,     0,    11,
    14,    45,    57,    58,    59,    60,    61,    64,    62,    63,
    56,     0,    50,    52,   110,    54,     0,    70,    28,     0,
     0,     0,    28,     0,     0,    75,   100,   101,   102,   103,
    78,    76,    94,    95,    92,    90,    91,    84,    96,    97,
    98,    99,    89,    88,    87,    79,    80,    83,    85,    86,
    48,    10,    49,     0,     0,    69,    31,     0,    39,    28,
    38,     0,     0,    53,    55,    28,    44,    40,     6,     0,
    32,     0,     0,    28,   113,    37,     0,     0,     0
};

static const short yydefgoto[] = {   207,
    17,    18,    19,    62,    63,    20,    70,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    89,    30,   128,    31,
    53,   142,   143,   144,    54,    34,    55,    56,   147,    57,
   146,    59,    60,    38,    39
};

static const short yypact[] = {   453,
   -52,-32768,   -40,   478,    -7,   -36,-32768,    -7,   485,   -31,
    -7,    -7,    -7,    -7,-32768,   312,-32768,    80,-32768,-32768,
-32768,   -27,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,    27,-32768,   584,   -37,-32768,-32768,-32768,-32768,   485,
    19,    26,    -5,   485,    -3,-32768,-32768,   -22,   485,   485,
   485,   485,-32768,-32768,   921,   640,-32768,   764,-32768,-32768,
   -33,-32768,-32768,    -9,-32768,-32768,    -4,-32768,-32768,     1,
   113,-32768,-32768,   485,-32768,-32768,   485,   485,   485,   485,
   485,   485,   485,   485,   485,   485,   485,   540,     2,-32768,
-32768,-32768,   485,   485,   596,    -7,    15,    33,   652,    33,
    33,   485,   485,   485,   485,   485,   485,   485,   485,   485,
   485,   485,   485,   -33,   -33,   485,   485,   485,   485,   485,
   485,   485,   485,   485,   485,-32768,-32768,     8,    -7,-32768,
-32768,   764,   764,   764,   764,   764,   764,   764,   764,   764,
   764,     9,-32768,    11,   906,   764,     6,   764,   478,   485,
   349,   708,   478,    14,     5,-32768,   845,   845,   845,   845,
   815,   875,   845,   845,   363,   363,   363,    33,-32768,-32768,
   845,   845,   290,   128,   406,   -28,   -28,    33,    33,    33,
-32768,-32768,-32768,   485,   485,-32768,    72,   400,-32768,   478,
-32768,    16,    35,-32768,   764,   478,    19,-32768,-32768,     7,
-32768,    21,    38,   478,-32768,-32768,    84,    87,-32768
};

static const short yypgoto[] = {-32768,
    71,-32768,-32768,   -11,   -21,  -100,    36,    -1,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   -88,-32768,   -68,-32768,
    20,-32768,   -73,-32768,    39,    37,     0,    17,-32768,    49,
   182,-32768,-32768,-32768,-32768
};


#define	YYLAST		987


static const short yytable[] = {    35,
    65,   113,    42,    35,    43,     2,    40,    45,   126,   127,
    64,    64,    67,    67,    71,    35,    36,    35,    41,    32,
    36,    86,    44,    32,   123,   124,   125,    61,    87,    36,
    36,     2,    36,    15,    36,    32,    73,    32,    33,    74,
    35,    93,    33,    13,    14,   169,   170,    97,    37,    66,
    68,   129,    37,    94,    33,    96,    33,    36,   155,    15,
    90,    87,   113,   130,    37,   150,    37,   181,   183,    71,
    35,   184,   186,   192,   193,   196,   203,    16,   200,    91,
   204,   205,     1,   208,   154,   145,   209,    36,    72,    92,
    32,   199,     2,     3,     4,    64,     5,     6,     7,     8,
     9,    10,    11,    12,    13,    14,   131,   182,   202,    33,
   194,     0,     0,     0,     0,     1,     0,     0,     0,    37,
    15,     0,     0,     0,     0,     2,     3,     4,    64,     5,
     6,     7,     0,     9,    10,    11,    12,    13,    14,     0,
     0,    16,     0,   -28,     0,     0,     0,   187,    35,     0,
     0,   191,    35,    15,   110,   111,   112,   113,     0,     0,
     0,     0,     0,     0,     0,    36,     0,     0,    32,    36,
     0,     0,    32,     0,    16,     0,   -28,   120,   121,   122,
   123,   124,   125,   145,     0,     0,     0,    33,   198,    35,
    58,    33,     0,     0,   201,    35,    35,    37,     0,     0,
     0,    37,   206,    35,     0,     0,    36,     0,     0,    32,
     0,     0,    36,    36,     0,    32,    90,     0,     0,     0,
    36,    88,     0,    32,     0,    95,     0,     0,    33,     0,
    98,    99,   100,   101,    33,    91,     0,     0,    37,     0,
     0,     0,    33,     0,    37,    92,     0,     0,     0,     0,
     0,     0,    37,     0,     0,   132,     0,     0,   133,   134,
   135,   136,   137,   138,   139,   140,   141,     0,   148,     0,
     0,     0,     0,     0,   151,   152,     0,     0,     0,     0,
     0,     0,     0,   157,   158,   159,   160,   161,   162,   163,
   164,   165,   166,   167,   168,     0,     0,   171,   172,   173,
   174,   175,   176,   177,   178,   179,   180,     0,     0,     0,
     0,     0,     0,     0,     1,     0,   110,   111,   112,   113,
     0,     0,     0,     0,     2,     3,     4,     0,     5,     6,
     7,   188,     9,    10,    11,    12,    13,    14,   119,   120,
   121,   122,   123,   124,   125,     0,     0,     0,     0,     0,
     0,     0,    15,   102,   103,   104,   105,   106,   107,   108,
   109,     0,     0,     0,     0,     0,   195,     0,     0,     0,
     0,     0,     0,    16,    69,   110,   111,   112,   113,     0,
     0,     0,     0,     0,     0,     0,     0,   114,   115,-32768,
-32768,-32768,   113,     0,   116,   117,   118,   119,   120,   121,
   122,   123,   124,   125,   102,   103,   104,   105,   106,   107,
   108,   109,   189,   121,   122,   123,   124,   125,     0,     0,
     0,     0,     0,     0,     0,     0,   110,   111,   112,   113,
     0,     0,   110,   111,   112,   113,     0,     0,   114,   115,
     0,     0,     0,     0,     0,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,     1,   121,   122,   123,   124,
   125,     0,     0,   197,     0,     2,     3,     4,     0,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,     0,
     1,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     2,     3,     4,    15,     5,     6,     7,     2,     9,    10,
    11,    12,    13,    14,     0,     0,     0,     0,     0,    13,
    14,     0,     0,     0,    16,     0,     0,     0,    15,     0,
     0,     0,     0,     0,     0,    15,    46,    47,    48,     0,
     0,     0,     0,     0,     0,     0,    49,     0,     0,    16,
     0,     0,     0,    50,   102,   103,   104,   105,   106,   107,
   108,   109,    51,    52,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   110,   111,   112,   113,
     0,     0,     0,     0,     0,     0,     0,     0,   114,   115,
     0,     0,     0,     0,     0,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,     0,     0,     0,     0,   149,
   102,   103,   104,   105,   106,   107,   108,   109,    75,    76,
     0,     0,     0,     0,    77,    78,    79,    80,    81,    82,
    83,    84,   110,   111,   112,   113,     0,     0,    85,     0,
     0,     0,     0,     0,   114,   115,     0,     0,     0,     0,
     0,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,     0,     0,     0,     0,   153,   102,   103,   104,   105,
   106,   107,   108,   109,   -66,   -66,     0,     0,     0,     0,
   -66,   -66,   -66,   -66,   -66,   -66,   -66,   -66,   110,   111,
   112,   113,     0,     0,   -66,     0,     0,     0,     0,     0,
   114,   115,     0,     0,     0,     0,     0,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,     0,     0,     0,
     0,   156,   102,   103,   104,   105,   106,   107,   108,   109,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   110,   111,   112,   113,     0,     0,
     0,     0,     0,     0,     0,     0,   114,   115,     0,     0,
     0,     0,     0,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,     0,     0,     0,     0,   190,   102,   103,
   104,   105,   106,   107,   108,   109,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   110,   111,   112,   113,     0,     0,     0,     0,     0,     0,
     0,     0,   114,   115,     0,     0,     0,     0,     0,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   102,
   103,   104,   105,     0,   107,   108,   109,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   110,   111,   112,   113,     0,     0,     0,     0,-32768,
-32768,-32768,-32768,   114,   115,-32768,-32768,     0,     0,     0,
   116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     0,   110,   111,   112,   113,     0,     0,     0,     0,   102,
   103,   104,   105,-32768,-32768,   108,   109,     0,     0,     0,
-32768,-32768,   118,   119,   120,   121,   122,   123,   124,   125,
     0,   110,   111,   112,   113,     0,     0,     0,     0,     0,
     0,     0,     0,   114,   115,     0,     0,     0,     0,     0,
   116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
   -65,   -65,     0,     0,     0,     0,   -65,   -65,   -65,   -65,
   -65,   -65,   -65,   -65,     0,   -65,   -65,     0,     0,     0,
   -65,   -65,   -65,   -65,   -65,   -65,   -65,   -65,   -65,     0,
     0,     0,     0,     0,    86,   -65,     0,     0,     0,     0,
   185,    87,     0,     0,     0,     0,     0,     0,     0,    86,
     0,     0,     0,     0,     0,     0,    87
};

static const short yycheck[] = {     0,
    12,    30,     4,     4,     5,    13,    59,     8,    42,    43,
    11,    12,    13,    14,    16,    16,     0,    18,    59,     0,
     4,    59,    59,     4,    53,    54,    55,    59,    66,    13,
    14,    13,    16,    41,    18,    16,    64,    18,     0,    13,
    41,    16,     4,    25,    26,   114,   115,    70,     0,    13,
    14,    61,     4,    59,    16,    59,    18,    41,    44,    41,
    41,    66,    30,    63,    16,    64,    18,    60,    60,    71,
    71,    61,    67,    60,    70,     4,    70,    62,    44,    41,
    60,    44,     3,     0,    96,    86,     0,    71,    18,    41,
    71,   192,    13,    14,    15,    96,    17,    18,    19,    20,
    21,    22,    23,    24,    25,    26,    71,   129,   197,    71,
   184,    -1,    -1,    -1,    -1,     3,    -1,    -1,    -1,    71,
    41,    -1,    -1,    -1,    -1,    13,    14,    15,   129,    17,
    18,    19,    -1,    21,    22,    23,    24,    25,    26,    -1,
    -1,    62,    -1,    64,    -1,    -1,    -1,   149,   149,    -1,
    -1,   153,   153,    41,    27,    28,    29,    30,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   149,    -1,    -1,   149,   153,
    -1,    -1,   153,    -1,    62,    -1,    64,    50,    51,    52,
    53,    54,    55,   184,    -1,    -1,    -1,   149,   190,   190,
     9,   153,    -1,    -1,   196,   196,   197,   149,    -1,    -1,
    -1,   153,   204,   204,    -1,    -1,   190,    -1,    -1,   190,
    -1,    -1,   196,   197,    -1,   196,   197,    -1,    -1,    -1,
   204,    40,    -1,   204,    -1,    44,    -1,    -1,   190,    -1,
    49,    50,    51,    52,   196,   197,    -1,    -1,   190,    -1,
    -1,    -1,   204,    -1,   196,   197,    -1,    -1,    -1,    -1,
    -1,    -1,   204,    -1,    -1,    74,    -1,    -1,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    -1,    87,    -1,
    -1,    -1,    -1,    -1,    93,    94,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,    -1,    -1,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,     3,    -1,    27,    28,    29,    30,
    -1,    -1,    -1,    -1,    13,    14,    15,    -1,    17,    18,
    19,   150,    21,    22,    23,    24,    25,    26,    49,    50,
    51,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    41,     5,     6,     7,     8,     9,    10,    11,
    12,    -1,    -1,    -1,    -1,    -1,   185,    -1,    -1,    -1,
    -1,    -1,    -1,    62,    63,    27,    28,    29,    30,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    27,
    28,    29,    30,    -1,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    55,     5,     6,     7,     8,     9,    10,
    11,    12,    64,    51,    52,    53,    54,    55,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
    -1,    -1,    27,    28,    29,    30,    -1,    -1,    39,    40,
    -1,    -1,    -1,    -1,    -1,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,     3,    51,    52,    53,    54,
    55,    -1,    -1,    64,    -1,    13,    14,    15,    -1,    17,
    18,    19,    20,    21,    22,    23,    24,    25,    26,    -1,
     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    13,    14,    15,    41,    17,    18,    19,    13,    21,    22,
    23,    24,    25,    26,    -1,    -1,    -1,    -1,    -1,    25,
    26,    -1,    -1,    -1,    62,    -1,    -1,    -1,    41,    -1,
    -1,    -1,    -1,    -1,    -1,    41,    42,    43,    44,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    52,    -1,    -1,    62,
    -1,    -1,    -1,    59,     5,     6,     7,     8,     9,    10,
    11,    12,    68,    69,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
    -1,    -1,    -1,    -1,    -1,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    60,
     5,     6,     7,     8,     9,    10,    11,    12,    25,    26,
    -1,    -1,    -1,    -1,    31,    32,    33,    34,    35,    36,
    37,    38,    27,    28,    29,    30,    -1,    -1,    45,    -1,
    -1,    -1,    -1,    -1,    39,    40,    -1,    -1,    -1,    -1,
    -1,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    -1,    -1,    -1,    -1,    60,     5,     6,     7,     8,
     9,    10,    11,    12,    25,    26,    -1,    -1,    -1,    -1,
    31,    32,    33,    34,    35,    36,    37,    38,    27,    28,
    29,    30,    -1,    -1,    45,    -1,    -1,    -1,    -1,    -1,
    39,    40,    -1,    -1,    -1,    -1,    -1,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    -1,    -1,    -1,
    -1,    60,     5,     6,     7,     8,     9,    10,    11,    12,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    27,    28,    29,    30,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    -1,    -1,
    -1,    -1,    -1,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    -1,    -1,    -1,    -1,    60,     5,     6,
     7,     8,     9,    10,    11,    12,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    27,    28,    29,    30,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    39,    40,    -1,    -1,    -1,    -1,    -1,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,     5,
     6,     7,     8,    -1,    10,    11,    12,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    27,    28,    29,    30,    -1,    -1,    -1,    -1,     5,
     6,     7,     8,    39,    40,    11,    12,    -1,    -1,    -1,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    -1,    27,    28,    29,    30,    -1,    -1,    -1,    -1,     5,
     6,     7,     8,    39,    40,    11,    12,    -1,    -1,    -1,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    -1,    27,    28,    29,    30,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    39,    40,    -1,    -1,    -1,    -1,    -1,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    25,    26,    -1,    -1,    -1,    -1,    31,    32,    33,    34,
    35,    36,    37,    38,    -1,    25,    26,    -1,    -1,    -1,
    45,    31,    32,    33,    34,    35,    36,    37,    38,    -1,
    -1,    -1,    -1,    -1,    59,    45,    -1,    -1,    -1,    -1,
    65,    66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,
    -1,    -1,    -1,    -1,    -1,    -1,    66
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
/*int yyparse (void);*/ //Apisak Comment 
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 192 "bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#else
#define YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#endif

int
yyparse(YYPARSE_PARAM)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 143 "naslparser.y"
{
	fprintf(output,"line %d :",line_number);
	fprintf(output,"tiptop: instr_decl_list\n");
	//----------------------------
	  ((naslctxt*)parm)->tree = yyvsp[0].node;
	//----------------------------  
	;
    break;}
case 2:
#line 151 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"instr_decl_list: instr_decl\n");
	  //-----------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_INSTR_L;
	  yyval.node->link[0] = yyvsp[0].node;
	  //-----------------------
	;
    break;}
case 3:
#line 161 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"instr_decl instr_decl_list\n");
	  //-----------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_INSTR_L;
	  yyval.node->link[0] = yyvsp[-1].node;
	  yyval.node->link[1] = yyvsp[0].node;
	  //-----------------------
	;
    break;}
case 6:
#line 175 "naslparser.y"
{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"func_decl: FUNCTION identifier '(' arg_decl ')' block\n");
	 //-----------------------
	  yyval.node = alloc_tree_cell(line_number, yyvsp[-4].str);
	  yyval.node->type = NODE_FUN_DEF;
	  yyval.node->link[0] = yyvsp[-2].node;
	  yyval.node->link[1] = yyvsp[0].node;
	 //-----------------------	 
	;
    break;}
case 7:
#line 186 "naslparser.y"
{ 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"arg_decl:\n"); 
	//-------------------
	 yyval.node = NULL;
	//-------------------
	;
    break;}
case 8:
#line 192 "naslparser.y"
{ 
				fprintf(output,"line %d :",line_number);
				fprintf(output,"arg_decl: arg_decl_1\n"); 
				//-------------------
				 yyval.node = yyvsp[0].node;
				//-------------------
				;
    break;}
case 9:
#line 199 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg_decl_1: identifier\n");
	  //------------------------
	   yyval.node = alloc_tree_cell(line_number, yyvsp[0].str); yyval.node->type = NODE_DECL;
	  //------------------------
	  ;
    break;}
case 10:
#line 207 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg_decl_1: identifier ',' arg_decl_1\n");
	  //-----------------------
	  yyval.node = alloc_tree_cell(line_number, yyvsp[-2].str);
	  yyval.node->type = NODE_DECL;
	  yyval.node->link[0] = yyvsp[0].node; 
	  //-----------------------
	;
    break;}
case 11:
#line 218 "naslparser.y"
{ 
     fprintf(output,"line %d :",line_number);
     fprintf(output,"block: '{' instr_list '}'\n"); 
     //-------------------
        yyval.node = yyvsp[-1].node;
     //-------------------
     ;
    break;}
case 12:
#line 224 "naslparser.y"
{ 
      fprintf(output,"line %d :",line_number);
      fprintf(output,"block: '{'  '}'\n");
      //------------------
	yyval.node = NULL;
      //------------------
      ;
    break;}
case 14:
#line 233 "naslparser.y"
{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"instr_list: instr| instr instr_list\n");
	 //--------------------------------
	  if (yyvsp[-1].node == NULL)
	    yyval.node = yyvsp[0].node;
	  else
	    {
	      yyval.node = alloc_tree_cell(line_number, NULL);
	      yyval.node->type = NODE_INSTR_L;
	      yyval.node->link[0] = yyvsp[-1].node;
	      yyval.node->link[1] = yyvsp[0].node; 
	    }
	 //--------------------------------
	;
    break;}
case 15:
#line 250 "naslparser.y"
{ 
     fprintf(output,"line %d :",line_number);
     fprintf(output,"instr: simple_instr ';\n");
     //----------------------
      yyval.node = yyvsp[-1].node;
     //----------------------
     ;
    break;}
case 27:
#line 261 "naslparser.y"
{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"simple_instr \n");
	 //--------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type =  NODE_BREAK;
	 //--------------------------
	;
    break;}
case 28:
#line 269 "naslparser.y"
{ 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"simple_instr //* nop //* \n"); 
	//---------------------------
	 yyval.node = NULL;
	//---------------------------
	;
    break;}
case 29:
#line 279 "naslparser.y"
{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"ret: RETURN expr\n");
	 //----------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type =  NODE_RETURN;
	  yyval.node->link[0] = yyvsp[0].node;
	 //----------------------------
	;
    break;}
case 30:
#line 289 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"ret: RETURN \n");
	  //---------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type =  NODE_RETURN;
	  //---------------------------
	;
    break;}
case 31:
#line 300 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"if_block: IF '(' expr ')' instr\n");
	  //---------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_IF_ELSE;
	  yyval.node->link[0] = yyvsp[-2].node; yyval.node->link[1] = yyvsp[0].node;
	  //---------------------------
	;
    break;}
case 32:
#line 310 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"if_block: IF '(' expr ')' instr ELSE instr\n");
	  //---------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_IF_ELSE;
	  yyval.node->link[0] = yyvsp[-4].node; yyval.node->link[1] = yyvsp[-2].node; yyval.node->link[2] = yyvsp[0].node;
	  //---------------------------
	;
    break;}
case 37:
#line 323 "naslparser.y"
{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"for_loop\n");
	 //---------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_FOR;
	  yyval.node->link[0] = yyvsp[-6].node;
	  yyval.node->link[1] = yyvsp[-4].node;
	  yyval.node->link[2] = yyvsp[-2].node;
	  yyval.node->link[3] = yyvsp[0].node;
	 //---------------------------------
	;
    break;}
case 38:
#line 337 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"while_loop\n");
	  //--------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_WHILE;
	  yyval.node->link[0] = yyvsp[-2].node;
	  yyval.node->link[1] = yyvsp[0].node;
	  //--------------------------------
	;
    break;}
case 39:
#line 348 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"repeat_loop\n");
	  //--------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_REPEAT_UNTIL;
	  yyval.node->link[0] = yyvsp[-3].node;
	  yyval.node->link[1] = yyvsp[-1].node;
	  //--------------------------------
	;
    break;}
case 40:
#line 360 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"foreach_loop\n");
	  //--------------------------------
	  yyval.node = alloc_tree_cell(line_number, yyvsp[-4].str);
	  yyval.node->type = NODE_FOREACH;
	  yyval.node->link[0] = yyvsp[-2].node;
	  yyval.node->link[1] = yyvsp[0].node;
	  //--------------------------------
	;
    break;}
case 44:
#line 372 "naslparser.y"
{ 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"aff_func: \n"); 
	//-----------------------------
	 yyval.node = NULL;
	//-----------------------------
	;
    break;}
case 45:
#line 381 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"rep: func_call REP expr\n");
	  //--------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_REPEATED;
	  yyval.node->link[0] = yyvsp[-2].node;
	  yyval.node->link[1] = yyvsp[0].node;
	  //--------------------------
	;
    break;}
case 46:
#line 392 "naslparser.y"
{ yyval.str = yyvsp[0].data.val; ;
    break;}
case 48:
#line 396 "naslparser.y"
{ 
	//-----------------------------------------------
	  naslctxt	subctx;
	  int		x;	          
	  x = init_nasl_ctx(&subctx, yyvsp[-1].str);
	  yyval.node = NULL;	  
	  if (x >= 0)
	    {
	      if (! yyparse(&subctx)) //naslparse(&subctx)
		{
		  yyval.node = subctx.tree;
		}
	      else
	      {
		//nasl_perror(NULL, "%s: Parse error at or near line %d\n",$3, subctx.line_nb);
		printf( "%s: Parse error at or near line %d\n",yyvsp[-1].str, subctx.line_nb);
		getch();
	      }
	      free(&subctx.buffer);
	      fclose(subctx.fp); subctx.fp = NULL;
	    }
	  free(& yyvsp[-1].str);	  
	 //-----------------------------------------------
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"include");
	;
    break;}
case 49:
#line 425 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"func_call: identifier '(' arg_list ')'\n");
	  //---------------------------
	  yyval.node = alloc_tree_cell(line_number, yyvsp[-3].str);
	  yyval.node->type = NODE_FUN_CALL;
	  yyval.node->link[0] = yyvsp[-1].node;
	  //---------------------------
	;
    break;}
case 51:
#line 435 "naslparser.y"
{ 
	 fprintf(output,"arg_list\n"); 
	 //----------------------------
	  yyval.node = NULL;
	 //----------------------------
	 ;
    break;}
case 53:
#line 442 "naslparser.y"
{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"arg_list1\n");
	 //-----------------------------
	  yyvsp[-2].node->link[1] = yyvsp[0].node;
	  yyval.node = yyvsp[-2].node;
	 //-----------------------------
	;
    break;}
case 54:
#line 452 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg : expr\n");
	  //----------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_ARG;
	  yyval.node->link[0] = yyvsp[0].node;
	  //----------------------------
	;
    break;}
case 55:
#line 462 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg : identifier ':' expr \n");
	  //----------------------------
	  yyval.node = alloc_tree_cell(line_number, yyvsp[-2].str);
	  yyval.node->type = NODE_ARG;
	  yyval.node->link[0] = yyvsp[0].node;
	  //----------------------------
	;
    break;}
case 56:
#line 474 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"=\n");
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_AFF, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	;
    break;}
case 57:
#line 481 "naslparser.y"
{
	  fprintf(
	  
	  
	  
	  output,"line %d :",line_number); fprintf(output,"==\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_PLUS_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 58:
#line 491 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"-=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_MINUS_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 59:
#line 497 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"*=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_MULT_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 60:
#line 503 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"\\=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_DIV_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 61:
#line 509 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number); fprintf(output,"%=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_MODULO_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 62:
#line 515 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,">=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_R_SHIFT_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 63:
#line 521 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number); fprintf(output,">>=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_R_USHIFT_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 64:
#line 527 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"<=\n"); 
	  //----------------------------
	   yyval.node = alloc_expr_cell(line_number, NODE_L_SHIFT_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------
	  ;
    break;}
case 65:
#line 535 "naslparser.y"
{ 
          fprintf(output,"line %d :",line_number); fprintf(output,"lvalue:	identifier = %s\n",yyvsp[0].str); 
	  //-----------------------------
	   yyval.node = alloc_tree_cell(line_number, yyvsp[0].str); yyval.node->type = NODE_VAR;
	  //-----------------------------
	  ;
    break;}
case 68:
#line 542 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); 
	  fprintf(output,"identifier:IDENT | REP\n");
	  //------------------------------	  
	  yyval.str = _strdup("x");
	  //------------------------------
	  ;
    break;}
case 69:
#line 550 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"array_elem: identifier '[' array_index ']'\n");
	  //-------------------------------
	  yyval.node = alloc_tree_cell(line_number, yyvsp[-3].str);
	  yyval.node->type = NODE_ARRAY_EL;
	  yyval.node->link[0] = yyvsp[-1].node;
	  //-------------------------------
	;
    break;}
case 71:
#line 563 "naslparser.y"
{  
   	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: PLUS_PLUS lvalue\n"); 
	//---------------------------------
	 yyval.node = alloc_expr_cell(line_number, EXPR_INCR, NULL, yyvsp[0].node);
	//---------------------------------
	;
    break;}
case 72:
#line 569 "naslparser.y"
{
 	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: MINUS_MINUS lvalue\n"); 
	//---------------------------------
	 yyval.node = alloc_expr_cell(line_number, EXPR_DECR, NULL, yyvsp[0].node);
	//---------------------------------
	;
    break;}
case 73:
#line 575 "naslparser.y"
{ 
 	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: lvalue PLUS_PLUS\n"); 
	//---------------------------------
	 yyval.node= alloc_expr_cell(line_number, EXPR_INCR, yyvsp[-1].node, NULL);
	//---------------------------------
	;
    break;}
case 74:
#line 581 "naslparser.y"
{ 
        fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: lvalue MINUS_MINUS\n"); 
        //---------------------------------
	 yyval.node= alloc_expr_cell(line_number, EXPR_DECR, yyvsp[-1].node, NULL);
        //---------------------------------
       ;
    break;}
case 75:
#line 590 "naslparser.y"
{ 
          fprintf(output,"line %d :",line_number); fprintf(output,"expr : '(' expr ')'\n"); 
	  //----------------------------------
	   yyval.node = yyvsp[-1].node;
	  //----------------------------------
	  ;
    break;}
case 76:
#line 596 "naslparser.y"
{  
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr AND expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_AND, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 77:
#line 602 "naslparser.y"
{  
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '!' expr %/prec NOT\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_NOT, yyvsp[0].node, NULL);
	  //----------------------------------
	  ;
    break;}
case 78:
#line 608 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr OR expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_OR, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 79:
#line 614 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '+' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_PLUS, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 80:
#line 620 "naslparser.y"
{ 
	 fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '-' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_MINUS, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	 ;
    break;}
case 81:
#line 626 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '-' expr %/prec UMINUS\n");
	  //----------------------------------
	    yyval.node = alloc_expr_cell(line_number, EXPR_U_MINUS, yyvsp[0].node, NULL);
	  //----------------------------------
	  ;
    break;}
case 82:
#line 632 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '~' expr %/prec BIT_NOT\n");
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_BIT_NOT, yyvsp[0].node, NULL);
	  //----------------------------------
	  ;
    break;}
case 83:
#line 638 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '*' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_MULT, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 84:
#line 644 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr EXPO expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_EXPO, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 85:
#line 650 "naslparser.y"
{ 
       	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '/' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_DIV, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 86:
#line 656 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '%/' expr\n"); 
	  //----------------------------------
	    yyval.node = alloc_expr_cell(line_number, EXPR_MODULO, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 87:
#line 662 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '&' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_BIT_AND, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 88:
#line 668 "naslparser.y"
{
	  fprintf(output,"line %d :",line_number);  fprintf(output,"expr : expr '^' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_BIT_XOR, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 89:
#line 674 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '|' expr\n"); 
	  //----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_BIT_OR, yyvsp[-2].node, yyvsp[0].node);
	  //----------------------------------
	  ;
    break;}
case 90:
#line 680 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr R_SHIFT expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_R_SHIFT, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 91:
#line 686 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr R_USHIFT expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_R_USHIFT, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 92:
#line 692 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr L_SHIFT expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, EXPR_L_SHIFT, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 94:
#line 699 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr MATCH expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_MATCH, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 95:
#line 705 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr NOMATCH expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_NOMATCH, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 96:
#line 711 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr RE_MATCH string\n"); 
	  //-----------------------------------
	   yyval.node = alloc_RE_cell(line_number, COMP_RE_MATCH, yyvsp[-2].node, yyvsp[0].str);
	  //-----------------------------------
	  ;
    break;}
case 97:
#line 717 "naslparser.y"
{ 	
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr RE_NOMATCH string\n"); 
	  //-----------------------------------
	   yyval.node = alloc_RE_cell(line_number, COMP_RE_NOMATCH, yyvsp[-2].node, yyvsp[0].str);
	  //-----------------------------------
	  ;
    break;}
case 98:
#line 723 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '<' expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_LT, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 99:
#line 729 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '>' expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_GT, yyvsp[-2].node, yyvsp[0].node); 
	  //-----------------------------------
	  ;
    break;}
case 100:
#line 735 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr EQ expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_EQ, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 101:
#line 741 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr NEQ expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_NE, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 102:
#line 747 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr SUPEQ expr\n"); 
	  //-----------------------------------
	   yyval.node = alloc_expr_cell(line_number, COMP_GE, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 103:
#line 753 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr INFEQ expr\n"); 
	  //-----------------------------------
	    yyval.node = alloc_expr_cell(line_number, COMP_LE, yyvsp[-2].node, yyvsp[0].node);
	  //-----------------------------------
	  ;
    break;}
case 104:
#line 759 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : INTEGER\n"); 
	  //-----------------------------------
	    yyval.node = alloc_tree_cell(line_number, NULL); 
	    yyval.node->x.i_val = yyvsp[0].num; yyval.node->type = CONST_INT;	
	  //-----------------------------------
	  ;
    break;}
case 105:
#line 766 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"expr : STRING2 : %s \n",yyvsp[0].str);
	  //------------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL); yyval.node->x.str_val = yyvsp[0].str;
	  yyval.node->type = CONST_STR; yyval.node->size = strlen(yyvsp[0].str);
	  //------------------------------------
	;
    break;}
case 106:
#line 774 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"expr : STRING1 :%s \n",yyvsp[0].data.val);
	  //------------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL); yyval.node->x.str_val = yyvsp[0].data.val;
	  yyval.node->type = CONST_DATA; yyval.node->size = yyvsp[0].data.len;
	  //------------------------------------
	;
    break;}
case 110:
#line 784 "naslparser.y"
{ 
   	fprintf(output,"line %d :",line_number);
   	fprintf(output,"var : identifier\n"); 
	//---------------------------------------	
	yyval.node = alloc_tree_cell(line_number, yyvsp[0].str); 
	yyval.node->type = NODE_VAR;
	//---------------------------------------
	;
    break;}
case 113:
#line 795 "naslparser.y"
{
	 // I don't know why comment this Dev-C++ not parse error -_-"
	 // fprintf(output,"line %d :",line_number);
	 // fprintf(output,"IPADDRESS : %d.%d.%d.%d", $1, $3, $5, $7);
	  //-------------------------------------
	  char *s = malloc(44);
	  _snprintf(s, 44, "%d.%d.%d.%d", yyvsp[-6].num, yyvsp[-4].num, yyvsp[-2].num, yyvsp[0].num);
	  yyval.node = alloc_tree_cell(line_number, s);
	  yyval.node->type = CONST_STR;
	  yyval.node->size = strlen(s);
	  //--------------------------------------
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"IPADDRESS : %d.%d.%d.%d", yyvsp[-6].num, yyvsp[-4].num, yyvsp[-2].num, yyvsp[0].num);
	;
    break;}
case 114:
#line 812 "naslparser.y"
{ 
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"loc: LOCAL arg_decl\n");
	 //---------------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_LOCAL;
	  yyval.node->link[0] = yyvsp[0].node;
	 //---------------------------------------
	;
    break;}
case 115:
#line 824 "naslparser.y"
{ 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"glob: GLOBAL arg_decl\n");
	 //---------------------------------------
	  yyval.node = alloc_tree_cell(line_number, NULL);
	  yyval.node->type = NODE_GLOBAL;
	  yyval.node->link[0] = yyvsp[0].node;
	 //---------------------------------------
	;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 487 "bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 834 "naslparser.y"


#include <stdio.h>
//#include <stdlib.h>

int 
yyerror(const char *s)
{
  fprintf(output,"%s",s);
  return 0;
}
int
init_nasl_ctx(naslctxt* pc, const char* name)
{
#ifdef MULTIPLE_INCLUDE_DIRS
  static const char* inc_dirs[] = { ".", "/tmp" }; /* TBD */
#endif
  pc->line_nb = 1;
  pc->tree = NULL;
  pc->buffer = (char *)malloc(80);
  pc->maxlen = 80;

#ifdef MULTIPLE_INCLUDE_DIRS
  if (name[0] == '/')		/* absolute path */
#endif
    {
      /* Shouldn't we reject the file? */
      if ((pc->fp = fopen(name, "r")) == NULL)
	{
	  perror(name);
	  return -1;
	}
      return 0;
    }
#ifdef MULTIPLE_INCLUDE_DIRS
  else
    {
      char	full_name[MAXPATHLEN];
      int	i;

      for (i = 0; i < sizeof(inc_dirs) / sizeof(*inc_dirs); i ++)
	{
	  snprintf(full_name, sizeof(full_name),  "%s/%s", inc_dirs[i], name);
	  if ((pc->fp = fopen(full_name, "r")) != NULL)
	    return 0;
	  perror(full_name);
	}
      return -1;
    }
#endif
}
//-------------------------------------------------------------------
//-----------------------------------------------------------------------
FILE*	nasl_trace_fp = NULL;

tree_cell*  nasl_exec(lex_ctxt* , tree_cell* );
//-----------------------------------------------------------------------
//----nasl_debug.c
//------------------------------------------
int nasl_trace_enabled()
{
 if( nasl_trace_fp == NULL )
   return 0;
 else 
  return 1;  
}
//------------------------------------------
void nasl_trace(lex_ctxt * lexic, char * msg, ...)
{
 va_list param;
 char debug_message[4096];
 char *script_name = "", *p;
  
 if(nasl_trace_fp == NULL)
	 return;
 va_start(param, msg);
 
 if( lexic != NULL )
 {
  script_name = arg_get_value(lexic->script_infos, "script_name");
  if(script_name == NULL)
   script_name = "";
 }
 
 _vsnprintf(debug_message, sizeof(debug_message), msg, param);
 for (p = debug_message; *p != '\0'; p ++)
   ;
 if (p == debug_message || p[-1] != '\n')
   fprintf(nasl_trace_fp, "[%d](%s) %s\n",getpid(), script_name, debug_message); 
 else
   fprintf(nasl_trace_fp, "[%d](%s) %s",getpid(), script_name, debug_message); 
 va_end(param);
}
//-----------------------------------------------------------------------
//----nasl_var.c
//------------------------------------------
static const char*
get_var_name(anon_nasl_var *v)
{
  static char	str[16];
#ifdef ALL_VARIABLES_NAMED
  if (v->av_name != NULL)
    return v->av_name;
#endif
  _snprintf(str, sizeof(str), "[%08x]", (int)v);
  return str;
}
//------------------------------------------
tree_cell*
nasl_read_var_ref(lex_ctxt* lexic, tree_cell* tc)
{
  tree_cell	*ret;
  anon_nasl_var	*v;

  if (tc == NULL || tc == FAKE_CELL)
    {
      fprintf(parse_tree, "nasl_read_var_ref: cannot read NULL or FAKE cell\n");      
      return NULL;
    }
  if (tc->type != REF_VAR)
    {
      fprintf(parse_tree, "nasl_read_var_ref: argument (type=%d) is not REF_VAR %s\n", tc->type, get_line_nb(tc));      
      return NULL;
    }

  v = tc->x.ref_val;
  if (v == NULL)
    {
      fprintf(parse_tree, "nasl_read_var_ref: NULL variable in REF_VAR\n");      
      return NULL;
    }

  ret = alloc_tree_cell(tc->line_nb, NULL);

  switch (v->var_type)
    {
    case VAR2_INT:
      ret->type = CONST_INT;
      ret->x.i_val = v->v.v_int;
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> %d\n", get_var_name(v), ret->x.i_val);
      return ret;

    case VAR2_STRING:
      ret->type = CONST_STR;
      /* Fix bad string length */
      if (v->v.v_str.s_siz <= 0 && v->v.v_str.s_val[0] != '\0')
	{
	  v->v.v_str.s_siz = strlen(v->v.v_str.s_val);
	  fprintf(parse_tree, "nasl_read_var_ref: Bad string length fixed\n");
	}
      /* Go on next case */
    case VAR2_DATA:
      ret->type = v->var_type == VAR2_STRING ? CONST_STR : CONST_DATA;
      if(v->v.v_str.s_val == NULL)
      {
       ret->x.str_val = NULL;
       ret->size = 0;
      }
      else
      {
       ret->x.str_val = malloc(v->v.v_str.s_siz);
       memcpy(ret->x.str_val, v->v.v_str.s_val, v->v.v_str.s_siz);
       ret->size = v->v.v_str.s_siz;
      }
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> \"%s\"\n", get_var_name(v), ret->x.str_val);
      return ret;

    case VAR2_ARRAY:
      ret->type = REF_ARRAY;
      ret->x.ref_val = &v->v.v_arr;
      return ret;

    case VAR2_UNDEF:
#if NASL_DEBUG > 0
      name = get_var_name(v);
      if (strcmp(name, "NULL") != 0) /* special case */
	fprintf(parse_tree, "nasl_read_var_ref: variable %s is undefined %s\n",
		    name, get_line_nb(tc));
#endif
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> undef\n", get_var_name(v), v->var_type);
      break;

    default:
      fprintf(parse_tree, "nasl_read_var_ref: unhandled variable type %d\n",
	      v->var_type);
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> ???? (Var type %d)\n", get_var_name(v), v->var_type);
      break;
    }
  deref_cell(ret);
  return NULL;
}
//------------------------------------------
tree_cell*
nasl_incr_variable(lex_ctxt* lexic, tree_cell* tc, int pre, int val)
{
  anon_nasl_var	*v;
  int		old_val = 0, new_val;
  tree_cell	*retc;

  if (tc->type != REF_VAR)
    {
      fprintf(parse_tree,
	      "nasl_incr_variable: argument (type=%d) is not REF_VAR %s\n",
	      tc->type, get_line_nb(tc));
      return NULL;
    }

  v = tc->x.ref_val;

  switch (v->var_type)
    {
    case VAR2_INT:
      old_val = v->v.v_int;
      break;
    case VAR2_STRING:
    case VAR2_DATA:
#if NASL_DEBUG > 0
      fprintf(parse_tree, "nasl_incr_variable: variable %s is a STRING %s - converting to integer\n", "", get_line_nb(tc));
#endif
      old_val = v->v.v_str.s_val == NULL ? 0 : atoi(v->v.v_str.s_val);
      break;
    case VAR2_UNDEF:
#if NASL_DEBUG > 0
      fprintf(parse_tree, "nasl_incr_variable: variable %s is undefined %s\n",
	      "", get_line_nb(tc));
#endif
      old_val = 0;
      break;

    default:
      fprintf(parse_tree, "nasl_incr_variable: variable %s has bad type %d %s\n",
	      /*get_var_name(v)*/ "", get_line_nb(tc));
      return NULL;
    }
  new_val = old_val + val;

  clear_anon_var(v);
  v->var_type = VAR2_INT;
  v->v.v_int = new_val;

  retc = alloc_tree_cell(0, NULL);
  retc->type = CONST_INT;
  retc->x.i_val = pre ? new_val : old_val;
  
  return retc;  
}
//------------------------------------------
tree_cell* 
decl_local_variables(lex_ctxt* lexic, tree_cell* vars)
{
  tree_cell	*t;

  for (t = vars; t != NULL; t = t->link[0])
    if (t->x.str_val == NULL)
      fprintf(parse_tree, "decl_local_variables: null name!\n");
    else
      add_named_var_to_ctxt(lexic, t->x.str_val, NULL);
  return FAKE_CELL;
}
//------------------------------------------
tree_cell*
decl_global_variables(lex_ctxt* lexic, tree_cell* vars)
{
  lex_ctxt	*c = lexic;

  while (c->up_ctxt != NULL)
    c = c->up_ctxt;
  return decl_local_variables(c, vars);
}
//-----------------------------------------------------------------------
/*
int
hash_str2(const char* s, int n)
{
  unsigned long		h = 0;
  const char		*p;

  if (s == NULL)
    return 0;

  for (p = s; *p != '\0'; p ++)
    h = (h << 3) + (unsigned char) *p;
  return h % n;
}

static int
hash_str(const char* s)
{
  return hash_str2(s, VAR_NAME_HASH);
}
*/
//------------------------------------------
static named_nasl_var*
get_var_by_name(nasl_array* a, const char* s)
{
  int			h = hash_str(s);
  named_nasl_var	*v;
  
  if (a->hash_elt == NULL)
    a->hash_elt = malloc(VAR_NAME_HASH * sizeof(named_nasl_var*));

  for (v = a->hash_elt[h]; v != NULL; v = v->next_var)
    if (v->var_name != NULL && strcmp(s, v->var_name) == 0)
      return v;

  v = malloc(sizeof(named_nasl_var));
  v->var_name = _strdup(s);
  v->u.var_type = VAR2_UNDEF;
  v->next_var = a->hash_elt[h];

  a->hash_elt[h] = v;
  return v;
}
//------------------------------------------
/* This function climbs up in the context list */
static named_nasl_var*
get_var_ref_by_name(lex_ctxt* ctxt, const char* name, int climb)
{
  named_nasl_var	*v, *prev;
  int		h = hash_str(name);
  lex_ctxt	*c;


  if(climb != 0)
    {
      for (c = ctxt; c != NULL; c = c->up_ctxt)
	if (c->ctx_vars.hash_elt != NULL)
	  for (prev = NULL, v = c->ctx_vars.hash_elt[h]; v != NULL; v = v->next_var)
	    if (v->var_name != NULL && strcmp(name, v->var_name) == 0)
	      {
#ifdef SILLY_OPT
		if (prev != NULL) /* Move it to start of list */
		  {
		    prev->next_var = v->next_var;
		    v->next_var = c->ctx_vars.hash_elt[h];
		    c->ctx_vars.hash_elt[h] = v;
		  }
#endif
	      return v;
    }
#ifdef SILLY_OPT
	    else
	      prev = v;
#endif
    }
  else
    {
      if (ctxt->ctx_vars.hash_elt != NULL)
	for (prev = NULL, v = ctxt->ctx_vars.hash_elt[h]; v != NULL; v = v->next_var)
	  if (v->var_name != NULL && strcmp(name, v->var_name) == 0)
	    {
#ifdef SILLY_OPT
	      if (prev != NULL) /* Move it to start of list */
		{
		  prev->next_var = v->next_var;
		  v->next_var = ctxt->ctx_vars.hash_elt[h];
		  ctxt->ctx_vars.hash_elt[h] = v;
		}
#endif
	    return v;
	    }
#ifdef SILLY_OPT
	  else
	    prev = v;
#endif
    }

  if (ctxt->ctx_vars.hash_elt == NULL)
    ctxt->ctx_vars.hash_elt = malloc(sizeof(named_nasl_var*) * VAR_NAME_HASH);

  v = malloc(sizeof(named_nasl_var));
  v->var_name = _strdup(name);
  v->u.var_type = VAR2_UNDEF;
  v->next_var = ctxt->ctx_vars.hash_elt[h];
  ctxt->ctx_vars.hash_elt[h] = v;

  return v;  
}
//------------------------------------------
tree_cell*
get_variable_by_name(lex_ctxt* ctxt, const char* name)
{
  named_nasl_var	* v;

  if (name == NULL)
    return NULL;
  v = get_var_ref_by_name(ctxt, name, 1);
  return var2cell(&v->u);
}
//------------------------------------------
tree_cell*
get_array_elem(lex_ctxt* ctxt, const char* name, tree_cell* idx)
{
  named_nasl_var	*v = get_var_ref_by_name(ctxt, name, 1);
  named_nasl_var	*nv;
  anon_nasl_var		*u, *av;
  tree_cell	*tc, idx0;


  u = &v->u;

  if (idx == NULL)
    {
#if NASL_DEBUG > 0
      fprintf(parse_tree, "get_array_elem: NULL index\n");
#endif
      /* Treat it as zero */
      idx = &idx0;
      idx->x.i_val = 0;
      idx->type = CONST_INT;
    }

  switch (u->var_type)
    {
    case VAR2_UNDEF:
      /* We define the array here */
      u->var_type = VAR2_ARRAY;
    case VAR2_ARRAY:
      switch(idx->type)
	{
	case CONST_INT:
	  av = nasl_get_var_by_num(&u->v.v_arr, idx->x.i_val, 1);
	  return var2cell(av);
	  
	case CONST_STR:
	case CONST_DATA:
	  nv = get_var_by_name(&u->v.v_arr, idx->x.str_val);
	  return var2cell(nv != NULL ? &nv->u : NULL);
	  
	default:
	  fprintf(parse_tree, "get_array_elem: unhandled index type 0x%x\n",
		  idx->type);
	  return NULL;
	}
      /*NOTREACHED*/
      break;

    case VAR2_INT:
      fprintf(parse_tree, "get_array_elem: variable %s is an integer\n", name);
      return NULL;

    case VAR2_STRING:
    case VAR2_DATA:
      if (idx->type == CONST_INT)
	{
	  int	l = u->v.v_str.s_siz;

	  if (idx->x.i_val >= l)
	    {
	      fprintf(parse_tree, "get_array_elem: requesting character after end of string %s (%d >= %d)\n", name, idx->x.i_val, l);
	      tc = alloc_expr_cell(idx->line_nb, CONST_DATA /*CONST_STR*/,
				   NULL, NULL);
	      tc->x.str_val = _strdup("");
	      tc->size = 0;
	      return tc;
	    }
	  else
	    {
	      if ( idx->x.i_val <  0)
	       {
	        fprintf(parse_tree, "Negative index !\n");
	      	return NULL;
	       }
	      tc = alloc_expr_cell(idx->line_nb, CONST_DATA /*CONST_STR*/,
				   NULL, NULL);
	      tc->x.str_val = malloc(2);
	      tc->x.str_val[0] = u->v.v_str.s_val[idx->x.i_val];
	      tc->x.str_val[1] = '\0';
	      tc->size = 1;
	      return tc;
	    }
	}
      else
	{
	  fprintf(parse_tree, "get_array_elem: Cannot use a non integer index  (type 0x%x) in string\n", idx->type);
	  return NULL;
	}
      /*NOTREACHED*/
      break;

    default:
      fprintf(parse_tree, "Severe bug: unknown variable type 0x%x %s\n",
	      u->var_type, get_line_nb(idx));
      return NULL;
    }
  /*NOTREACHED*/
  return NULL;
}
//-----------------------------------------
//-----------------------------------------------------------------------
//----nasl_func.c
//-----------------------------------------
/* This function climbs up in the context list */
static nasl_func*
get_func(lex_ctxt* ctxt, const char* name, int h)
{
  nasl_func	*v, *prev;
  lex_ctxt	*c;

  for (c = ctxt; c != NULL; c = c->up_ctxt)
    {
      for (prev = NULL, v = c->functions[h]; v != NULL; v = v->next_func)
	if (v->func_name != NULL && strcmp(name, v->func_name) == 0)
	  {
#ifdef SILLY_OPT
	    if (prev != NULL) /* Move it to start of list */
	      {
		prev->next_func = v->next_func;
		v->next_func = c->functions[h];
		c->functions[h]= v;
	      }
#endif
	  return v;
	  }
#ifdef SILLY_OPT
	else
	  prev = v;
#endif
    }

  return NULL;
}
//-----------------------------------------
int compare( const void *arg1, const void *arg2 )
{
   /* Compare all of both strings: */
   return _stricmp( * ( char** ) arg1, * ( char** ) arg2 );
}

//-----------------------------------------
nasl_func*
insert_nasl_func(lex_ctxt* lexic, const char* fname, tree_cell* decl_node)
{
  int		h = hash_str(fname);
  int		i;
  nasl_func	*pf;
  tree_cell	*pc;

  if (get_func(lexic, fname, h) != NULL)
    {
      fprintf(parse_tree, "insert_nasl_func: function '%s' is already defined\n",fname);
      return NULL;
    }
  pf = malloc(sizeof(nasl_func));
  pf->func_name = _strdup(fname);

  if (decl_node != NULL && decl_node != FAKE_CELL)
    {
      for (pc = decl_node->link[0]; pc != NULL; pc = pc->link[0])
	if (pc->x.str_val == NULL)
	  pf->nb_unnamed_args ++;
	else
	  pf->nb_named_args ++;

      pf->args_names = malloc(sizeof(char*) * pf->nb_named_args);
      for (i = 0, pc = decl_node->link[0]; pc != NULL; pc = pc->link[0])
	if (pc->x.str_val != NULL)
	  pf->args_names[i ++] = _strdup(pc->x.str_val);
      /* sort arg names */
//void qsort( void *base, size_t num, size_t width, int (__cdecl *compare )(const void *elem1, const void *elem2 ) );
  qsort(pf->args_names, pf->nb_named_args,sizeof(pf->args_names[0]), compare );

      pf->block = decl_node->link[1];
      ref_cell(pf->block);
    }
  pf->next_func = lexic->functions[h];
  lexic->functions[h] = pf;
  return pf;
}
//-----------------------------------------
tree_cell*
decl_nasl_func(lex_ctxt* lexic, tree_cell* decl_node)
{
  if (decl_node == NULL || decl_node == FAKE_CELL)
    {
      fprintf(parse_tree, "Cannot insert NULL or FAKE cell as function\n");
      return NULL;
    }
    
  if (insert_nasl_func(lexic, decl_node->x.str_val, decl_node) == NULL)
    return NULL;
  else
    return FAKE_CELL;
}
//---------------------------------------------
//-----------------------------------------------------------------------
/* cell2atom returns a 'referenced' cell */	
tree_cell* cell2atom(lex_ctxt* lexic, tree_cell* c1)
{
  tree_cell	*c2 = NULL, *ret = NULL;
  if (c1 == NULL || c1 == FAKE_CELL)
    return c1;

  switch(c1->type)
    {
    case CONST_INT:
    case CONST_STR:
    case CONST_DATA:
    case REF_ARRAY:
    case DYN_ARRAY:
      ref_cell(c1);
      return c1;
    default:
      c2 = nasl_exec(lexic, c1);
      ret = cell2atom(lexic, c2);
      deref_cell(c2);
      return ret;
    }
}
//-----------------------------------------------------------------------
static void
nasl_dump_expr(FILE* fp, const tree_cell* c)
{
  if (c == NULL)
    fprintf(fp, "NULL");
  else if  (c == FAKE_CELL)
    fprintf(fp, "FAKE");
  else
    switch(c->type)
      {
      case NODE_VAR:
	fprintf(fp, "%s", c->x.str_val);
	break;
      case EXPR_AND:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") && (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_OR:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") || (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_NOT:
	fprintf(fp, "! (");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ")");
	break;
      case EXPR_PLUS:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") + (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_MINUS:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") - (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case EXPR_INCR:
	if (c->link[0] == NULL)
	  {
	    fprintf(fp, " ++");
	    nasl_dump_expr(fp, c->link[1]);
	  }
	else
	  {
	    nasl_dump_expr(fp, c->link[0]);
	    fprintf(fp, "++ ");
	  }
	break;
      case EXPR_DECR:
	if (c->link[0] == NULL)
	  {
	    fprintf(fp, " --");
	    nasl_dump_expr(fp, c->link[1]);
	  }
	else
	  {
	    nasl_dump_expr(fp, c->link[0]);
	    fprintf(fp, "-- ");
	  }
	break;
	    
      case EXPR_EXPO:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") ** (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case EXPR_U_MINUS:
	fprintf(fp, " - (");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ")");
	break;

      case EXPR_MULT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") * (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_DIV:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") / (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_MODULO:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") %% (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_AND:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") & (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_OR:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") | (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_XOR:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") ^ (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_NOT:
	fprintf(fp, "~ (");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ")");
	break;
      case EXPR_L_SHIFT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") << (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_R_SHIFT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") >> (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_R_USHIFT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") >>> (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case COMP_MATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >< ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_NOMATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >!< ");
	nasl_dump_expr(fp, c->link[1]);
	break;

      case COMP_RE_MATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " =~ ");
	nasl_dump_expr(fp, c->link[1]);
	break;

      case COMP_RE_NOMATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " !~ ");
	nasl_dump_expr(fp, c->link[1]);
	break;

      case COMP_LT:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " < ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_LE:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " <= ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_GT:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " > ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_GE:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >= ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " == ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case CONST_INT:
	fprintf(fp, "%d", c->x.i_val);
	break;
      case CONST_STR:
      case CONST_DATA:
	fprintf(fp, "\"%s\"", c->x.str_val);
	break;

      case NODE_ARRAY_EL:
	fprintf(fp, "%s[", c->x.str_val);
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "]");
	break; 

      case NODE_FUN_CALL:
	fprintf(fp, "%s(...)", c->x.str_val);
	break;
	
      case NODE_AFF:
	nasl_dump_expr(fp, c->link[0]);
	putc('=', fp);
	nasl_dump_expr(fp, c->link[1]);
	break;

      case NODE_PLUS_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "+= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_MINUS_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "-= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_MULT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "*= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_DIV_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "/= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_MODULO_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "%%= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_L_SHIFT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " <<= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_R_SHIFT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >>= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_R_USHIFT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >>>= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      default:
	fprintf(fp, "*%d*", c->type);
	break;      
      }
}
//-----------------------------------------------------------------------
static void
nasl_short_dump(FILE* fp, const tree_cell* c)
{
  if (c == NULL || c == FAKE_CELL)
    return;

  switch (c->type)
    {
    case NODE_IF_ELSE:
      fprintf(fp, "NASL:%04d> if (", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ") { ... }");
      if (c->link[2] != NULL)  fprintf(fp, " else { ... }");
      putc('\n', fp);
      break;

    case NODE_FOR:
      fprintf(fp, "NASL:%04d> for (", c->line_nb); nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, "; "); nasl_dump_expr(fp, c->link[1]);
      fprintf(fp, "; "); nasl_dump_expr(fp, c->link[2]);
      fprintf(fp, ") { ... }\n");
      break;

    case NODE_WHILE:
      fprintf(fp, "NASL:%04d> while (", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ") { ... }\n");
      break;

    case NODE_FOREACH:
      fprintf(fp, "NASL:%04d> foreach %s (", c->line_nb, c->x.str_val);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ") { ... }\n");
      break;

    case NODE_REPEAT_UNTIL:
      fprintf(fp, "NASL:%04d> repeat { ... } until (", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ")\n");
      break;

    case NODE_REPEATED:
      fprintf(fp, "NASL:%04d> ... x ", c->line_nb); 
      nasl_dump_expr(fp, c->link[1]);
      putc('\n', fp);
      break;

    case NODE_RETURN:
      fprintf(fp, "NASL:%04d> return ", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ";\n");
      break;

    case NODE_BREAK:
      fprintf(fp, "NASL:%04d> break\n", c->line_nb);
      break;

    case NODE_AFF:
    case NODE_PLUS_EQ:
    case NODE_MINUS_EQ:
    case NODE_MULT_EQ:
    case NODE_DIV_EQ:
    case NODE_MODULO_EQ:
    case NODE_R_SHIFT_EQ:
    case NODE_R_USHIFT_EQ:
    case NODE_L_SHIFT_EQ:
      fprintf(fp, "NASL:%04d> ", c->line_nb);
      nasl_dump_expr(fp, c);
      fprintf(fp, ";\n");
      break;

    case NODE_FUN_CALL:
      fprintf(fp, "NASL:%04d> %s(...)\n", c->line_nb, c->x.str_val);
      break;

    case NODE_LOCAL:
      fprintf(fp, "NASL:%04d> local_var ...\n", c->line_nb);
      break;

    case NODE_GLOBAL:
      fprintf(fp, "NASL:%04d> global_var ...\n", c->line_nb);
      break;
    }
}
//--------------------------------------------------------------------
int
cell2int(lex_ctxt* lexic, tree_cell* c)
{
  tree_cell	*c2 = NULL;
  int		x;

  if (c == NULL || c == FAKE_CELL) /*  Do not SEGV on undefined variables */
    return 0;

  switch(c->type)
    {
    case CONST_INT:
      return c->x.i_val;
    case CONST_STR:
    case CONST_DATA:  
      return strtol(c->x.str_val, NULL, 0);
    default:
      c2 = nasl_exec(lexic, c);
      x = cell2int(lexic, c2);
      deref_cell(c2);
      return x;
    }
}
//--------------------------------------------------------------------
int
cell2bool(lex_ctxt* lexic, tree_cell* c)
{
  tree_cell	*c2;
  int		flag;


  if (c == NULL || c == FAKE_CELL)
    return 0;
  
  switch (c->type)
    {
    case CONST_INT:
      return c->x.i_val != 0;
    case CONST_STR:
    case CONST_DATA:
      if (c->size == 0)
	return 0;
      if(c->x.str_val[0] == '0' && c->size == 1)
	  return 0;
     return 1;

    case REF_ARRAY:
    case DYN_ARRAY:
      //printf( "cell2bool: converting array to boolean does not make sense!\n");
	printf( "cell2bool: converting array to boolean does not make sense!\n");
	getch();
      return 1;

    default:
      c2 = nasl_exec(lexic, c);
      flag = cell2bool(lexic, c2);
      deref_cell(c2);
      return flag;
    }
}
//--------------------------------------------------------------------
static int
cvt_bool(lex_ctxt* lexic, tree_cell* c)
{
  int	flag;

#if 0
  nasl_dump_tree(c);
#endif
  flag = cell2bool(lexic, c);
  /* free(c); free_tree(c); */
  return flag;
}
//--------------------------------------------------------------------
char*
cell2str(lex_ctxt* lexic, tree_cell* c)
{
  char	* p;
  tree_cell	*c2;
  nasl_array	*a;

  if (c == NULL || c == FAKE_CELL)
    {
#if NASL_DEBUG > 0
      printf( "Cannot convert NULL or FAKE cell to string\n");
      getch();
#endif
      return NULL;
    }
      
  switch(c->type)
    {
    case CONST_INT:
      p = malloc(16);
      _snprintf(p, 16, "%d", c->x.i_val);
      return p;
      
    case CONST_STR:
    case CONST_DATA:
      if ( c->x.str_val == NULL)
	p = _strdup("");
      else
        strncpy(p, c->x.str_val, c->size );
	//p = nasl_strndup(c->x.str_val, c->size);
	

      return p;
      
    case REF_ARRAY:
    case DYN_ARRAY:
      a = c->x.ref_val;
      p = (char*)array2str(a);
      return _strdup(p);

    default:
      c2 = nasl_exec(lexic, c);
      p = cell2str(lexic, c2);
      deref_cell(c2);
      if (p == NULL)
	p = _strdup("");
      return p;
    }
}
//--------------------------------------------------------------------
tree_cell*
int2cell(int x)
{
  tree_cell	*c = alloc_expr_cell(0, CONST_INT, NULL, NULL);
  c->x.i_val = x;
  return c;
}
//--------------------------------------------------------------------
tree_cell*
bool2cell(int x)
{
  return int2cell(x != 0);
}
//--------------------------------------------------------------------
int
cell_cmp(lex_ctxt* lexic, tree_cell* c1, tree_cell* c2)
{
  int		flag, x1, x2, typ, typ1, typ2;
  char		*s1, *s2;
  int		len_s1, len_s2, len_min;


#if NASL_DEBUG >= 0
  if (c1 == NULL || c1 == FAKE_CELL)
    printf( "cell_cmp: c1 == NULL !\n");
    getch();
  if (c2 == NULL || c2 == FAKE_CELL)
    printf( "cell_cmp: c2 == NULL !\n");
    getch();
#endif

  /* We first convert the cell to atomic types */
  c1 = cell2atom(lexic, c1);
  c2 = cell2atom(lexic, c2);

  /*
   * Comparing anything to something else which is entirely different 
   * may lead to unpredictable results.
   * Here are the rules:
   * 1. No problem with same types, although we do not compare arrays yet
   * 2. No problem with CONST_DATA / CONST_STR
   * 3. When an integer is compared to a string, the integer is converted
   * 4. When NULL is compared to an integer, it is converted to 0
   * 5. When NULL is compared to a string, it is converted to ""
   * 6. NULL is "smaller" than anything else (i.e. an array)
   * Anything else is an error
   */
  typ1 = cell_type(c1);
  typ2 = cell_type(c2);

  if (typ1 == 0 && typ2 == 0)	/* Two NULL */
    {
      deref_cell(c1); deref_cell(c2); 
      return 0;
    }

  if (typ1 == typ2)		/* Same type, no problem */
    typ = typ1;
  else if ((typ1 == CONST_DATA || typ1 == CONST_STR) &&
	   (typ2 == CONST_DATA || typ2 == CONST_STR))
    typ = CONST_DATA;		/* Same type in fact (string) */
  /* We convert an integer into a string before compare */
  else if ((typ1 == CONST_INT && (typ2 == CONST_DATA || typ2 == CONST_STR)) ||
	   (typ2 == CONST_INT && (typ1 == CONST_DATA || typ1 == CONST_STR)) )
    {
#if NASL_DEBUG > 0
      printf( "cell_cmp: converting integer to string\n");
      getch();
#endif
      typ = CONST_DATA;
    }
  else if (typ1 == 0)		/* 1st argument is null */
    if (typ2 == CONST_INT || typ2 == CONST_DATA || typ2 == CONST_STR)
      typ = typ2;		/* We convert it to 0 or "" */
    else
      {
	deref_cell(c1); deref_cell(c2); 
	return -1;		/* NULL is smaller than anything else */
      }
  else if (typ2 == 0)		/* 2nd argument is null */
    if (typ1 == CONST_INT || typ1 == CONST_DATA || typ1 == CONST_STR)
      typ = typ1;		/* We convert it to 0 or "" */
    else
      {
	deref_cell(c1); deref_cell(c2); 
	return 1;		/* Anything else is greater than NULL  */
      }
  else
    {
      printf( "cell_cmp: comparing %s and %s does not make sense\n", nasl_type_name(typ1), nasl_type_name(typ2));
      getch();
      deref_cell(c1); deref_cell(c2); 
      return 0;
    } 

  switch (typ)
    {
    case CONST_INT:
      x1 = cell2int(lexic, c1);
      x2 = cell2int(lexic, c2);
      deref_cell(c1); deref_cell(c2); 
      return x1 - x2;

    case CONST_STR:
    case CONST_DATA:
      s1 = cell2str(lexic, c1);
      if (typ1 == CONST_STR || typ1 == CONST_DATA)
	len_s1 = c1->size;
      else if (s1 == NULL)
	len_s1 = 0;
      else
	len_s1 = strlen(s1);

      s2 = cell2str(lexic, c2);
      if (typ2 == CONST_STR || typ2 == CONST_DATA)
	len_s2 = c2->size;
      else if (s2 == NULL)
	len_s2 = 0;
      else
	len_s2 = strlen(s2);
       		  
      len_min = len_s1 < len_s2 ? len_s1 : len_s2;
      flag = 0;

      if (len_min > 0)
	flag = memcmp(s1, s2, len_min);
      if (flag == 0)
	flag = len_s1 - len_s2;
       	
      free(&s1); free(&s2); 
      deref_cell(c1); deref_cell(c2); 
      return flag;

    case REF_ARRAY:
    case DYN_ARRAY:
      fprintf(stderr, "cell_cmp: cannot compare arrays yet\n");
      deref_cell(c1); deref_cell(c2); 
      return 0;

    default:
      fprintf(stderr, "cell_cmp: don't known how to compare %s and %s\n",
	      nasl_type_name(typ1), nasl_type_name(typ2));
      deref_cell(c1); deref_cell(c2); 
      return 0;
    }
}
//--------------------------------------------------------------------
static int
expo(int x, int y)
{
  int	z;

  if (y == 0)
    return 1;
  else if (y < 0)
    if (x == 1)
      return 1;
    else
      return 0;
  else if (y == 1)
    return x;

  z = expo(x, y /2);
  if (y % 2 == 0)
    return z * z;
  else
    return x * z * z;
}
//--------------------------------------------------------------------
tree_cell*
nasl_exec(lex_ctxt* lexic, tree_cell* st)
{
  tree_cell	*ret = NULL, *ret2 = NULL, *tc1 = NULL, *tc2 = NULL, *tc3 = NULL, *idx = NULL, *args;
  int		flag, x, y, z;
  char		*s1 = NULL, *s2 = NULL, *s3 = NULL, *p = NULL;
  char		*p1, *p2;
  int		len1, len2;
  nasl_func	*pf = NULL;
  int		i, n;
  unsigned long sz;


#if 0
  nasl_dump_tree(st);      /* See rt.value, rt.type, rt.length */
#endif

  /* return */
  if (lexic->ret_val != NULL)
    {
      ref_cell(lexic->ret_val);
      return lexic->ret_val;
    }

  /* break */
  if (lexic->break_flag)
    return FAKE_CELL;

  if (st == FAKE_CELL)
    return FAKE_CELL;

  if (st == NULL)
    {
#if NASL_DEBUG > 0
      fprintf(parse_tree, "nasl_exec: st == NULL\n");
#endif
      return NULL;
    }

  if (nasl_trace_fp != NULL)
    nasl_short_dump(nasl_trace_fp, st);

  switch(st->type)
    {
    case NODE_IF_ELSE:
      ret = nasl_exec(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (ret == NULL)
	return NULL;
#endif
      if (cvt_bool(lexic, ret))
	ret2 = nasl_exec(lexic, st->link[1]);
      else
	if (st->link[2] != NULL) /* else branch */
	  ret2 = nasl_exec(lexic, st->link[2]);
	else			/* No else */
	  ret2 = FAKE_CELL;
      deref_cell(ret);
      return ret2;

    case NODE_INSTR_L:	/* Block. [0] = first instr, [1] = tail */
      ret = nasl_exec(lexic, st->link[0]);
#if NASL_DEBUG > 1
      if (ret == NULL)
	fprintf(parse_tree, "Instruction failed. Going on in block\n");
#endif
      if (st->link[1] == NULL || lexic->break_flag)
	return ret;
      deref_cell(ret);
      ret = nasl_exec(lexic, st->link[1]);
      return ret;
	
    case NODE_FOR:
      /* [0] = start expr, [1] = cond, [2] = end_expr, [3] = block */
      ret2 = nasl_exec(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (ret2 == NULL)
	return NULL;
#endif
      deref_cell(ret2);
      for (;;)
	{
	  /* Break the loop if 'return' */
	  if (lexic->ret_val != NULL)
	    {
	      ref_cell(lexic->ret_val);
	      return lexic->ret_val;
	    }

	  /* condition */
	  if ((ret = nasl_exec(lexic, st->link[1])) == NULL)
	    return NULL;	/* We can return here, as NULL is false */
	  flag = cvt_bool(lexic, ret);
	  deref_cell(ret);
	  if (! flag)
	    break;
	  /* block */
	  ret = nasl_exec(lexic, st->link[3]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  deref_cell(ret);

	  /* break */
	  if (lexic->break_flag)
	    {
	      lexic->break_flag = 0;
	      return FAKE_CELL;
	    }

	  /* end expression */
	  ret = nasl_exec(lexic, st->link[2]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  deref_cell(ret); 
	}
      return FAKE_CELL;

    case NODE_WHILE:
      /* [0] = cond, [1] = block */
      for (;;)
	{
	  /* return? */
	  if (lexic->ret_val != NULL)
	    {
	      ref_cell(lexic->ret_val);
	      return lexic->ret_val;
	    }
	  /* Condition */
	  if ((ret = nasl_exec(lexic, st->link[0])) == NULL)
	    return NULL;	/* NULL is false */
	  flag = cvt_bool(lexic, ret);
	  deref_cell(ret);
	  if (! flag)
	    break;
	  /* Block */
	  ret = nasl_exec(lexic, st->link[1]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif	  
	  deref_cell(ret);

	  /* break */
	  if (lexic->break_flag)
	    {
	      lexic->break_flag = 0;
	      return FAKE_CELL;
	    }
	}
      return FAKE_CELL;

    case NODE_REPEAT_UNTIL:
      /* [0] = block, [1] = cond  */
      for (;;)
	{
	  /* return? */
	  if (lexic->ret_val != NULL)
	    {
	      ref_cell(lexic->ret_val);
	      return lexic->ret_val;
	    }
	  /* Block */
	  ret = nasl_exec(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  deref_cell(ret);

	  /* break */
	  if (lexic->break_flag)
	    {
	      lexic->break_flag = 0;
	      return FAKE_CELL;
	    }

	  /* Condition */
	  ret = nasl_exec(lexic, st->link[1]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  flag = cvt_bool(lexic, ret);
	  deref_cell(ret);
	  if (flag)
	    break;
	}
      return FAKE_CELL;

    case NODE_FOREACH:
      /* str_val = index name, [0] = array, [1] = block */
      {
	nasl_iterator	ai;
	tree_cell	*v, *a, *val;

	///v = get_variable_by_name(lexic, st->x.str_val);
	if (v == NULL)
	  return NULL;		/* We cannot go on if we have no variable to iterate */
	a = nasl_exec(lexic, st->link[0]); 
	ai = nasl_array_iterator(a);
	while ((val = nasl_iterate_array(&ai)) != NULL)
	  {
	    tc1 = nasl_affect(v, val);
	    ret = nasl_exec(lexic, st->link[1]);
	    deref_cell(val);
	    deref_cell(tc1);
#ifdef STOP_AT_FIRST_ERROR
	    if (ret == NULL) 
	      break;
#endif
	    deref_cell(ret);

	    /* return */
	    if (lexic->ret_val != NULL)
	      break;
	    /* break */
	    if (lexic->break_flag)
	      {
		lexic->break_flag = 0;
		break;
	      }

	  }
	deref_cell(a);
	deref_cell(v);
      }
      return FAKE_CELL;

    case NODE_FUN_DEF:
      /* x.str_val = function name, [0] = argdecl, [1] = block */
      ret = decl_nasl_func(lexic, st);
      return ret;

    case NODE_FUN_CALL:
      ///pf = get_func_ref_by_name(lexic, st->x.str_val);
      if (pf == NULL)
	{
	  fprintf(parse_tree, "Undefined function '%s'\n", st->x.str_val);
	  return NULL;
	}
      args = st->link[0];
#if 0
      fprintf(parse_tree,"****************\n");
      nasl_dump_tree(args);
      fprintf(parse_tree,"****************\n");
#endif
      ///ret = nasl_func_call(lexic, pf, args);
      return ret;

    case NODE_REPEATED:
      n = cell2int(lexic, st->link[1]);
      if (n <= 0)
	return NULL;
	
#ifdef STOP_AT_FIRST_ERROR	
      for (tc1 = NULL, i = 1; i <= n; i ++)
	{
	  deref_cell(tc1);
	  if ((tc1 = nasl_exec(lexic, st->link[0])) == NULL)
	    return NULL;
	}
      return tc1;
#else
      for (i = 1; i <= n; i ++)
	{
	  tc1 = nasl_exec(lexic, st->link[0]);
	  deref_cell(tc1);
	}
      return FAKE_CELL;
#endif

      /*
       * I wonder... 
       * Will nasl_exec be really called with NODE_EXEC or NODE_ARG?
       */
    case NODE_DECL:		/* Used in function declarations */
      /* [0] = next arg in list */
      /* TBD? */
      return st;		/* ? */

    case NODE_ARG:		/* Used function calls */
      /* val = name can be NULL, [0] = val, [1] = next arg */
      ret = nasl_exec(lexic, st->link[0]);	/* Is this wise? */
      return ret;

    case NODE_RETURN:
      /* [0] = ret val */
      ///ret = nasl_return(lexic, st->link[0]);
      return ret;

    case NODE_BREAK:
      lexic->break_flag = 1;
      return FAKE_CELL;

    case NODE_ARRAY_EL:		/* val = array name, [0] = index */
      idx = cell2atom(lexic, st->link[0]);
      ret = get_array_elem(lexic, st->x.str_val, idx);
      deref_cell(idx);
      return ret;

    case NODE_AFF:
      /* [0] = lvalue, [1] = rvalue */
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      ret = nasl_affect(tc1, tc2);
      deref_cell(tc1);		/* Must free VAR_REF */
      deref_cell(ret);
      return tc2;		/* So that "a = b = e;" works */

    case NODE_PLUS_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_PLUS, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;		/* So that "a = b += e;" works */
      
    case NODE_MINUS_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_MINUS, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;		/* So that "a = b -= e;" works */
      
    case NODE_MULT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_MULT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_DIV_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_DIV, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_MODULO_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_MODULO, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_L_SHIFT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_L_SHIFT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_R_SHIFT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_R_SHIFT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_R_USHIFT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_R_USHIFT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_VAR:
      /* val = variable name */
      ret = get_variable_by_name(lexic, st->x.str_val);
      return ret;

    case NODE_LOCAL:		/* [0] = argdecl */
      ret = decl_local_variables(lexic, st->link[0]);
      return ret;

    case NODE_GLOBAL:		/* [0] = argdecl */
      ret = decl_global_variables(lexic, st->link[0]);
      return ret;

    case EXPR_AND:
      x = cell2bool(lexic, st->link[0]);
      if(! x)
	return bool2cell(0);
      
      y = cell2bool(lexic, st->link[1]);
      return bool2cell(y);
     

    case EXPR_OR:
      x = cell2bool(lexic, st->link[0]);
      if(x)
       return bool2cell(x);
      y = cell2bool(lexic, st->link[1]);
      return bool2cell(y);

    case EXPR_NOT:
      x = cell2bool(lexic, st->link[0]);
      return bool2cell(! x);

    case EXPR_INCR:
    case EXPR_DECR:
      x =  (st->type == EXPR_INCR) ? 1 : -1;
      if (st->link[0] == NULL)
	{
	  y = 1;		/* pre */
	  tc1 = st->link[1];
	}
      else
	{
	  y = 0;		/* post */
	  tc1 = st->link[0];
	}
      tc2 = nasl_exec(lexic, tc1);
      if (tc2 == NULL)
	return NULL;
      ret = nasl_incr_variable(lexic, tc2, y, x);
      deref_cell(tc2);
      return ret;

      if (st->link[0] == NULL)
	ret = nasl_incr_variable(lexic, st->link[1], 1, 1);
      else
	ret = nasl_incr_variable(lexic, st->link[1], 0, 1);
      break;

    case EXPR_PLUS:
      s1 = s2 = NULL;
      tc1 = cell2atom(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (tc1 == NULL || tc1 == FAKE_CELL)
	return NULL;
#endif
      tc2 = cell2atom(lexic, st->link[1]);
      if (tc2 == NULL || tc2 == FAKE_CELL)
	{
#ifdef STOP_AT_FIRST_ERROR
	  deref_cell(tc1);
	  return NULL;
#else
	  return tc1;
#endif
	}

      if (tc1 == NULL || tc1 == FAKE_CELL)
	return tc2;

      /*
       * Anything added to a string is converted to a string
       * Otherwise anything added to an intger is converted into an integer
       */
      if (tc1->type == CONST_DATA || tc2->type == CONST_DATA)
	flag = CONST_DATA;
      else if (tc1->type == CONST_STR || tc2->type == CONST_STR)
	flag = CONST_STR;
      else if (tc1->type == CONST_INT || tc2->type == CONST_INT)
	flag = CONST_INT;
      else
	flag = NODE_EMPTY;
#if NASL_DEBUG > 0
      if ((flag == CONST_DATA || flag == CONST_STR) && 
	  (tc1->type == CONST_INT || tc2->type == CONST_INT))
	fprintf(parse_tree, "Horrible type conversion (int -> str) for operator + %s\n", get_line_nb(st));
#endif
      switch (flag)
	{
	case CONST_INT:
	  x = tc1->x.i_val;
	  y = cell2int(lexic, st->link[1]);
	  ret = int2cell(x + y);
	  break;

	case CONST_STR:
	case CONST_DATA:
	  s1 = s2 = NULL;
	  if (tc1->type == CONST_STR || tc1->type == CONST_DATA)
	    len1 = tc1->size;
	  else
	    {
	      s1 = cell2str(lexic, tc1);
	      len1 = (s1 == NULL ? 0 : strlen(s1));
	    }

	  if (tc2->type == CONST_STR || tc2->type == CONST_DATA)
	    len2 = tc2->size;
	  else
	    {
	      s2 = cell2str(lexic, tc2);
	      len2 = (s2 == NULL ? 0 : strlen(s2));
	    }

	  sz = len1 + len2;
	  s3 = malloc(sz);
	  if (len1 > 0)
	    memcpy(s3, s1 != NULL ? s1 : tc1->x.str_val, len1);
	  if (len2 > 0)
	    memcpy(s3 + len1, s2 != NULL ? s2 : tc2->x.str_val, len2);
	  free(&s1); free(&s2);
	  ret = alloc_tree_cell(0, s3);
	  ret->type = flag;
	  ret->size = sz;
	  break;

	default:
	  ret = NULL;
	  break;
	}
      deref_cell(tc1);
      deref_cell(tc2);
      return ret;

    case EXPR_MINUS:		/* Infamous duplicated code */
      s1 = s2 = NULL;
      tc1 = cell2atom(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (tc1 == NULL || tc1 == FAKE_CELL)
	return NULL;
#endif
      tc2 = cell2atom(lexic, st->link[1]);
      if (tc2 == NULL || tc1 == FAKE_CELL)
	{
#ifdef STOP_AT_FIRST_ERROR
	  deref_cell(tc1);
	  return NULL;
#else
	  return tc1;
#endif
	}

      if (tc1 == NULL || tc1 == FAKE_CELL)
	{
	  if (tc2->type == CONST_INT)
	    {
	      y = cell2int(lexic, tc2);
	      ret = int2cell(- y);
	    }
	  else
	    ret = NULL;
	  deref_cell(tc2);
	  return ret;
	}

      /*
       * Anything substracted from a string is converted to a string
       * Otherwise anything substracted from integer is converted into an
       * integer
       */
      if (tc1->type == CONST_DATA || tc2->type == CONST_DATA)
	flag = CONST_DATA;
      else if (tc1->type == CONST_STR || tc2->type == CONST_STR)
	flag = CONST_STR;
      else if (tc1->type == CONST_INT || tc2->type == CONST_INT)
	flag = CONST_INT;
      else
	flag = NODE_EMPTY;
#if NASL_DEBUG > 0
      if ((flag == CONST_DATA || flag == CONST_STR) && 
	  (tc1->type == CONST_INT || tc2->type == CONST_INT))
	fprintf(parse_tree, "Horrible type conversion (int -> str) for operator - %s\n", get_line_nb(st));
#endif
      switch (flag)
	{
	case CONST_INT:
	  x = cell2int(lexic, tc1);
	  y = cell2int(lexic, tc2);
	  ret = int2cell(x - y);
	  break;

	case CONST_STR:
	case CONST_DATA:
	  if (tc1->type == CONST_STR || tc1->type == CONST_DATA)
	    {
	      p1 = tc1->x.str_val;
	      len1 = tc1->size;
	    }
	  else
	    {
	      p1 = s1 = cell2str(lexic, tc1);
	      len1 = (s1 == NULL ? 0 : strlen(s1));
	    }
	      
	  if (tc2->type == CONST_STR || tc2->type == CONST_DATA)
	    {
	      p2 = tc2->x.str_val;
	      len2 = tc2->size;
	    }
	  else
	    {
	      p2 = s2 = cell2str(lexic, tc2);
	      len2 = (s2 == NULL ? 0 : strlen(s2));
	    }

	  if (len2 == 0 || len1 < len2 || 
	      (p = (char*)strstr(p1,  p2)) == NULL)//memmem -> strstr in win32 ^^
	    {
	      s3 = malloc(len1);
	      memcpy(s3, p1, len1);
	      ret = alloc_tree_cell(0, s3);
	      ret->type = flag;
	      ret->size = len1;
	    }
	  else
	    {
	      sz = len1 - len2;
	      if (sz <= 0)
		{
		  sz = 0;
		  s3 = _strdup("");
		}
	      else
		{
		  s3 = malloc(sz);
		  if (p - p1 > 0)
		    memcpy(s3, p1, p - p1);
		  if (sz > p - p1)
		    memcpy(s3 + (p - p1), p + len2, sz - (p - p1));
		}
	      ret = alloc_tree_cell(0, s3);
	      ret->size = sz;
	      ret->type = flag;
	    }

	  free(&s1); free(&s2);
	 break;

	default:
	  ret = NULL;
	  break;
	}
      deref_cell(tc1);
      deref_cell(tc2);
      return ret;
    
    case EXPR_MULT:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x * y);

    case EXPR_DIV:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      if( y != 0 )
       return int2cell(x / y);
      else
       return int2cell(0);
       
    case EXPR_EXPO:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(expo(x, y));

    case EXPR_MODULO:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      if( y != 0)
       return int2cell(x % y);
      else
       return int2cell(0);

    case EXPR_BIT_AND:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x & y);

    case EXPR_BIT_OR:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x | y);

    case EXPR_BIT_XOR:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x ^ y);

    case EXPR_BIT_NOT:
      x = cell2int(lexic, st->link[0]);
      return int2cell(~ x);

    case EXPR_U_MINUS:
      x = cell2int(lexic, st->link[0]);
      return int2cell(- x);

      /* TBD: Handle shift for strings and arrays */
    case EXPR_L_SHIFT:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x << y);

    case EXPR_R_SHIFT:		/* arithmetic right shift */
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
#if NASL_DEBUG > 0
      if (y < 0)
	fprintf(parse_tree, "Warning: Negative count in right shift!\n");
#endif
      z = x >> y;
#ifndef __GNUC__
      if (x < 0 && z >= 0)	/* Fix it */
	{
#if NASL_DEBUG > 1
	  fprintf(parse_tree, "Warning: arithmetic right shift is buggy! Fixing...\n");
#endif
	  z |= (~0) << (sizeof(x) * 8 - y);
	}
#endif
      return int2cell(z);

    case EXPR_R_USHIFT:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
#if NASL_DEBUG > 0
      if (y < 0)
	fprintf(parse_tree, "Warning: Negative count in right shift!\n");
#endif
      z = (unsigned)x >> (unsigned)y;
#ifndef __GNUC__
      if (x < 0 && z <= 0)	/* Fix it! */
	{
#if NASL_DEBUG > 1
	  fprintf(parse_tree, "Warning: Logical right shift is buggy! Fixing...\n");
#endif
	  z &= ~((~0) << (sizeof(x) * 8 - y));
	}
#endif
      return int2cell(z);

    case COMP_MATCH:
    case COMP_NOMATCH:
      tc1 = cell2atom(lexic, st->link[0]); 
      tc2 = cell2atom(lexic, st->link[1]); 
      s1 = s2 = NULL;

      if (tc1 == NULL || tc1 == FAKE_CELL)
	{
	  p1 = ""; 
	  len1 = 0;
	}
      else if (tc1->type == CONST_STR || tc1->type == CONST_DATA)
	{
	  p1 = tc1->x.str_val;
	  len1 = tc1->size;
	}
      else
	{
#if NASL_DEBUG > 0
	  fprintf(parse_tree, "Horrible type conversion (%s -> str) for operator >< or >!< %s\n", nasl_type_name(tc1->type), get_line_nb(st));
#endif
	  p1 = s1 = cell2str(lexic, tc1);
	  len1 = strlen(s1);
	}

      if (tc2 == NULL || tc2 == FAKE_CELL)
	{
	  p2 = "";
	  len2 = 0;
	}
      else if (tc2->type == CONST_STR || tc2->type == CONST_DATA)
	{
	  p2 = tc2->x.str_val;
	  len2 = tc2->size;
	}
      else
	{
#if NASL_DEBUG > 0
	  fprintf(parse_tree, "Horrible type conversion (%s -> str) for operator >< or >!< %s\n", nasl_type_name(tc2->type), get_line_nb(st));
#endif
	  p2 = s2 = cell2str(lexic, tc2);
	  len2 = strlen(s2);
	}

      if(len1 <= len2)		
      	flag = ((void*)strstr(p2, p1) != NULL); //memmem -> strstr in win32 ^^
      else
      	flag = 0;
	
      free(&s1); free(&s2);
      deref_cell(tc1);
      deref_cell(tc2);
      if (st->type == COMP_MATCH)
	return bool2cell(flag);
      else
	return bool2cell(! flag);

    case COMP_RE_MATCH:
    case COMP_RE_NOMATCH:
      if (st->x.ref_val == NULL)
	{
	  fprintf(parse_tree, "nasl_exec: bad regex at or near line %d\n",
		  st->line_nb);
	  return NULL;
	}
      s1 = cell2str(lexic, st->link[0]);
      if (s1 == NULL)
	return 0;
      flag = nasl_regexec(st->x.ref_val, s1, 0, NULL, 0);
      free(s1);
      if (st->type == COMP_RE_MATCH)
	return bool2cell(flag != REG_NOMATCH);
      else
	return bool2cell(flag == REG_NOMATCH);

    case COMP_LT:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) < 0);

    case COMP_LE:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) <= 0);

    case COMP_EQ:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) == 0);

    case COMP_NE:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) != 0);

    case COMP_GT:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) > 0);

    case COMP_GE:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) >= 0);

    case REF_ARRAY:
    case DYN_ARRAY:
    case CONST_INT:
    case CONST_STR:
    case CONST_DATA:
      ref_cell(st);	/* nasl_exec returns a cell that should be deref-ed */
      return st;

    case REF_VAR:
      ret = nasl_read_var_ref(lexic, st);
      return ret;

    default:
      fprintf(parse_tree, "nasl_exec: unhandled node type %d\n", st->type);
      abort();
      return NULL;
    }

  deref_cell(ret);
  deref_cell(ret2);
  return NULL;
}

//--------------------------------------------------------------------
int safe_checks_only = 0;
//------------------------------------------------
static struct arglist * 
init_hostinfos( hostname, ip)
     char * hostname;
    struct in_addr * ip;
{
  struct arglist * hostinfos;
  struct arglist * ports;
  
  hostinfos = malloc(sizeof(struct arglist));
  arg_add_value(hostinfos, "FQDN", ARG_STRING, strlen(hostname), hostname);
  arg_add_value(hostinfos, "NAME", ARG_STRING, strlen(hostname), hostname);
  arg_add_value(hostinfos, "IP", ARG_PTR, sizeof(struct in_addr), ip);
  ports = malloc(sizeof(struct arglist));
  arg_add_value(hostinfos, "PORTS", ARG_ARGLIST, sizeof(struct arglist), ports);  
  return(hostinfos);
}
//------------------------------------------------
struct arglist * 
init(hostname, ip)
 char * hostname;
 struct in_addr ip;
{
 struct arglist * script_infos = malloc(sizeof(struct arglist));
 struct arglist * prefs        = malloc(sizeof(struct arglist));
 struct in_addr *pip = 		malloc(sizeof(*pip));
 *pip = ip;
 
 arg_add_value(script_infos, "standalone", ARG_INT, sizeof(int), (void*)1);
 arg_add_value(prefs, "checks_read_timeout", ARG_STRING, 4, strdup("5"));
 arg_add_value(script_infos, "preferences", ARG_ARGLIST, -1, prefs);
 
 if(safe_checks_only != 0)
   arg_add_value(prefs, "safe_checks", ARG_STRING, 3, strdup("yes"));
   
 arg_add_value(script_infos, "HOSTNAME", ARG_ARGLIST, -1,
 		init_hostinfos(hostname, pip));
	
 return script_infos;
}

//--------------------------------------------------------------------
extern FILE *yyin;
extern FILE *lex_act;
struct in_addr ip;
struct arglist * script_infos;

main(int argc,char **argv)
{	
	naslctxt ctx;
	char hostname[1024];
  	int mode = 0;
  	ctx.line_nb = 1;
 	ctx.tree = NULL;

	//Character Sequences
	yyin = fopen("apache_auth_sql_insertion.nasl","r"); //for test 
	if(yyin == NULL)
	{
		printf("error - cannot assign file yyin\n");
		getch();
		exit(1);
	}

	output =  fopen("parser_act.txt","w"); //for DEBUG
	parse_tree = fopen("output.txt","w");  	
	lex_act = fopen("lexer_act.txt","w");
	if(output == NULL||parse_tree == NULL ||lex_act ==NULL)
	{
		printf("error - cannot open file\n");
		exit(1);
	}	

	fprintf(lex_act,"line %d: ",line_number);
	
  	ip.s_addr = INADDR_LOOPBACK;
  	strncpy( hostname, "localhost", sizeof("localhost") );
  	script_infos = init(hostname, ip);
  	
	if(init_nasl_ctx(&ctx, "apache_auth_sql_insertion.nasl")<0)
	{
		printf("error init_nasl_ctx");
		getch();
		exit(1);
	}
 	if (yyparse(&ctx))
   	{
    	 printf( "\nParse error at or near line %d\n", ctx.line_nb);
	 getch();
     	 //nasl_clean_ctx(&ctx);
   	}
	nasl_dump_tree(ctx.tree);
	//getch();		
		
	fclose(lex_act);
	fclose(parse_tree);
	fclose(output);//for test
	//
	//-------------------------------------------------------------
}
