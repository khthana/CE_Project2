#include<stdlib.h>
#include<malloc.h>
#include<stdio.h>
#include"nasl_tree.h"
#include "nasl_regex.h"
#include "nasl_var.h"
#include "regex.h"

extern FILE *parse_tree = NULL;

static char * node_names[] = { 
  "NODE_EMPTY",
  "NODE_IF_ELSE",
  "NODE_INSTR_L",
  "NODE_FOR",
  "NODE_WHILE",
  "NODE_FOREACH",
  "NODE_REPEAT_UNTIL",
  "NODE_REPEATED",
  "NODE_FUN_DEF",
  "NODE_FUN_CALL",
  "NODE_DECL",
  "NODE_ARG",
  "NODE_RETURN",
  "NODE_BREAK",
  "NODE_ARRAY_EL",
  "NODE_AFF",
  "NODE_VAR",
  "NODE_LOCAL",
  "NODE_GLOBAL",
  "NODE_PLUS_EQ",
  "NODE_MINUS_EQ",
  "NODE_MULT_EQ",
  "NODE_DIV_EQ",
  "NODE_MODULO_EQ",

  "NODE_L_SHIFT_EQ",
  "NODE_R_SHIFT_EQ",
  "NODE_R_USHIFT_EQ",
  "EXPR_AND",
  "EXPR_OR",
  "EXPR_NOT",

  "EXPR_PLUS",
  "EXPR_MINUS",
  "EXPR_U_MINUS",
  "EXPR_MULT",
  "EXPR_DIV",
  "EXPR_MODULO",
  "EXPR_EXPO",

  "EXPR_BIT_AND",
  "EXPR_BIT_OR",
  "EXPR_BIT_XOR",
  "EXPR_BIT_NOT",
  "EXPR_INCR",
  "EXPR_DECR",
  "EXPR_L_SHIFT",
  "EXPR_R_SHIFT",
  "EXPR_R_USHIFT",

  "COMP_MATCH",
  "COMP_NOMATCH",
  "COMP_RE_MATCH",
  "COMP_RE_NOMATCH",

  "COMP_LT",
  "COMP_LE",
  "COMP_EQ",
  "COMP_NE",
  "COMP_GT",
  "COMP_GE",
  "CONST_INT",
  "CONST_STR",
  "CONST_DATA",
  "CONST_REGEX",

  "REF_VAR",
  "REF_ARRAY",
  "DYN_ARRAY"
};
//--------------------------------------------------
const char*
nasl_type_name(int t)
{
  static char	txt4[4][32];	/*  This function may be called 4 times in the same expression */
  static int	i = 0;
  char	*txt;

  if (++ i > 4) i = 0;
  txt = txt4[i];

  if (t >= 0 || t < sizeof(node_names) / sizeof(node_names[0]))
    _snprintf(txt, 32, "%s (%d)", node_names[t], t);
  else
    _snprintf(txt, 32, "*UNKNOWN* (%d)", t);
  return txt;
}
//--------------------------------------------------
int
cell_type(const tree_cell* c)
{
  if (c == NULL || c== FAKE_CELL)
    return 0;
  else
    return c->type;
}
//--------------------------------------------------
static void
prefix(int n, int i)
{
  int	j;
  for (j = 0; j < n; j ++)
    //putchar(' ');
    fprintf(parse_tree," ");

  if (i <= 0)
    //fputs("   ", stdout);
     fprintf(parse_tree,"   " );
  else
    fprintf(parse_tree,"%d: ", i);
}
//--------------------------------------------------
static void
dump_tree(const tree_cell* c, int n, int idx)
{
  int	i;

  if (c == NULL)
    return;

  prefix(n, idx);

  if (c == FAKE_CELL)
    {
      puts("* FAKE *");
      return;
    }

  if (c->line_nb > 0)
    fprintf(parse_tree,"L%d: ", c->line_nb);

#if 0
  if ((int) c < 0x1000)
    {
      fprintf(parse_tree,"* INVALID PTR 0x%x *\n", (int) c);
      return;
    }
#endif
  if (c->type < 0 || c->type >= sizeof(node_names) / sizeof(node_names[0]))
    fprintf(parse_tree,"* UNKNOWN %d (0x%x)*\n", c->type, c->type);
  else
    fprintf(parse_tree,"%s (%d)\n", node_names[c->type],c->type);


  prefix(n, idx);
  fprintf(parse_tree,"Ref_count=%d ", c->ref_count);
  if (c->size > 0)
    {
      /*prefix(n, idx);*/
      fprintf(parse_tree,"\tSize=%d (0x%x)", c->size, c->size);
    }
  //putchar('\n');
  fprintf(parse_tree,"\n");

  switch(c->type)
    {
    case CONST_INT:
      prefix(n, 0);
      fprintf(parse_tree,"Val=%d\n", c->x.i_val);
      break;

    case CONST_STR:
    case CONST_DATA:
    case NODE_VAR:
    case NODE_FUN_DEF:
    case NODE_FUN_CALL:
    case NODE_DECL:
    case NODE_ARG:
    case NODE_ARRAY_EL:
      prefix(n, 0);
      if (c->x.str_val == NULL)
	fprintf(parse_tree,"Val=(null)\n");
      else
	fprintf(parse_tree,"Val=\"%s\"\n", c->x.str_val);
      break;
    case REF_VAR:
      prefix(n, 0);
      if (c->x.ref_val == NULL)
	fprintf(parse_tree,"Ref=(null)\n");
      else
	{
	  named_nasl_var	*v = c->x.ref_val;
	  fprintf(parse_tree,"Ref=(type=%d, name=%s, value=%s)\n",
		 v->u.var_type, v->var_name != NULL ? v->var_name : "(null)",
		 var2str(&v->u));
	}
      break;

    case REF_ARRAY:
    case DYN_ARRAY:
      break;
    }

  for (i = 0; i < 4; i ++)
    {
      dump_tree(c->link[i], n+3, i+1);
    }
}
//--------------------------------------------------
void
nasl_dump_tree(const tree_cell* c)
{
  fprintf(parse_tree,"^^^^ %08x ^^^^^\n", (int) c);
  if (c == NULL)
    puts("NULL CELL");
  else if (c == FAKE_CELL)
    puts ("FAKE CELL");
  else
    dump_tree(c, 0, 0);
  fprintf(parse_tree,"vvvvvvvvvvvvvvvvvv\n");
}
//--------------------------------------------------
void
ref_cell(tree_cell* c)
{
  if (c == NULL || c == FAKE_CELL)
    return;
  c->ref_count ++;
  if (c->ref_count < 0)
    {
      //nasl_perror(NULL, "ref_cell: ref count is negative!\n");
      fprintf(parse_tree, "ref_cell: ref count is negative!\n");
      nasl_dump_tree(c);
      abort();
    }
}
//--------------------------------------------------
static void
free_tree(tree_cell *c)
{
  int			i;
  nasl_array		*a;

  if (c == NULL || c == FAKE_CELL)
    return;
#if 0
  nasl_dump_tree(c);
#endif
  for (i = 0; i < 4; i ++)
    if (c->link[i] != NULL)
      deref_cell(c->link[i]);
  if (c->x.str_val != NULL)
    switch(c->type)
      {
      case CONST_STR:
      case CONST_DATA:
#ifdef SCRATCH_FREED_MEMORY
	if (c->size > 0)
	  memset(c->x.str_val, 0xFF, c->size);
#endif
	free(&c->x.str_val);
	break;

      case CONST_REGEX:
#if 0
      case COMP_RE_MATCH:
      case COMP_RE_NOMATCH:
#endif
	if (c->x.ref_val != NULL)
	  {
	   // regfree(c->x.ref_val);   not have in win32
	    free(&c->x.ref_val);
	  }
	break;

      case DYN_ARRAY:
	a = c->x.ref_val;
	if (a != NULL)
	  {
	    free_array(a);
	    free(&c->x.ref_val);
	  }
	break;

      case NODE_FUN_DEF:
      case NODE_FUN_CALL:
      case NODE_VAR:
      case NODE_DECL:
      case NODE_ARG:
      case NODE_ARRAY_EL:
	free(&c->x.str_val);
	break;
      }
#ifdef SCRATCH_FREED_MEMORY
  memset(c, 0xFF, sizeof(*c));
#endif
  free(&c);
}
//--------------------------------------------------
void
deref_cell(tree_cell* c)
{
  if (c == NULL || c == FAKE_CELL)
    return;
  if (-- c->ref_count <= 0)
    free_tree(c);
}
//--------------------------------------------------
char*
get_line_nb(const tree_cell* c)
{
  static char txt[32];
  if (c == NULL || c == FAKE_CELL || c->line_nb <= 0)
    return "";
  _snprintf(txt, sizeof(txt), " at or near line %d ", c->line_nb);
  return txt;
}
//--------------------------------------------------
tree_cell*
alloc_tree_cell(int lnb, char *s)
{
  tree_cell	*p = malloc(sizeof(tree_cell));
  int		i;

  if (p == NULL)
    {
      perror("malloc");
      abort();
    }
  p->type = 0;
  p->size = 0;
  p->line_nb = lnb;
  p->x.str_val = s;
  p->ref_count = 1;
  for (i = 0; i < 4;i ++)
    p->link[i] = NULL;
  return p;
}
//---------------------------------------------------
tree_cell*
alloc_RE_cell(int lnb, int t, tree_cell *l, char *re_str)
{
  regex_t	*re = (regex_t *)malloc(sizeof(regex_t));     //before use emalloc
  int	e;

  tree_cell *c = alloc_tree_cell(lnb, NULL);
  c->type = t;			/* We could check the type... */
  c->link[0] = l;
  c->link[1] = FAKE_CELL;
  e = nasl_regcomp(re, re_str, REG_EXTENDED|REG_NOSUB|REG_ICASE);
  if (! e)
    c->x.ref_val = re;
  else
    {
  /* nasl_perror(NULL, "Line %d: Cannot compile regex: %s (error = %d)\n",
		  lnb, re_str, e);  */
      free(&re);   //before use free
    }
  free(re_str);
  return c;
}
//---------------------------------------------------
tree_cell*
alloc_expr_cell(int lnb, int t, tree_cell *l, tree_cell *r)
{
  tree_cell *c = alloc_tree_cell(lnb, NULL);
  c->type = t;
  c->link[0] = l;
  c->link[1] = r;
  return c;
}
//---------------------------------------------------
