#ifndef NASL_LEX_CTXT_H_INCLUDED
#define NASL_LEX_CTXT_H_INCLUDED

#include "nasl_var.h"
#include "nasl_func.h"

typedef struct struct_lex_ctxt {
  struct struct_lex_ctxt	*up_ctxt;
  tree_cell	*ret_val;	/* return value or exit flag */
  unsigned	fct_ctxt :1;	/* This is a function context */
  unsigned	break_flag : 1;	/* Break from loop */
  struct arglist	*script_infos;
  int			recv_timeout;
  /* Named variables hash set + anonymous variables array */
  nasl_array	ctx_vars;
  /* Functions hash set */
  nasl_func	*functions[FUNC_NAME_HASH];
} lex_ctxt;

#define NASL_COMPAT_LEX_CTXT	"NASL compat lex context"

#endif
