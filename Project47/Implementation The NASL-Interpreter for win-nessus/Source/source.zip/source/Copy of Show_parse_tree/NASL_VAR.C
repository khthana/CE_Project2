#include "nasl_var.h"
#include "nasl_lex_ctxt.h"
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>

extern FILE*	nasl_trace_fp;

static void	free_var_chain(named_nasl_var*);
static void	free_anon_var(anon_nasl_var*);
//-----------------------------------------------------------------------
static void
clear_array(nasl_array *a)
{
  int		i;

  if (a->num_elt != NULL)
    {
      for (i = 0; i < a->max_idx; i ++)
	free_anon_var(a->num_elt[i]);
      free(&a->num_elt);
    }
  a->max_idx = 0;
  if (a->hash_elt != NULL)
    {
      for (i = 0; i < VAR_NAME_HASH; i ++)
	free_var_chain(a->hash_elt[i]);
      free(&a->hash_elt);
    }
}
//-----------------------------------------------------------------------
void
clear_anon_var(anon_nasl_var* v)
{

  if (v == NULL)
    return;

  switch (v->var_type)
    {
    case VAR2_INT:
      v->v.v_int = 0;
      break;
    case VAR2_STRING:
    case VAR2_DATA:
      free(&v->v.v_str.s_val);
      v->v.v_str.s_siz = 0;
      break;
    case VAR2_ARRAY:
      clear_array(&v->v.v_arr);
      break;
    }
  v->var_type = VAR2_UNDEF;
  return;
}
//-----------------------------------------------------------------------
int
hash_str2(const char* s, int n)
{
  unsigned long		h = 0;
  const char		*p;

  if (s == NULL)
    return 0;

  for (p = s; *p != '\0'; p ++)
    h = (h << 3) + (unsigned char) *p;
  return h % n;
}


//-----------------------------------------------------------------------
static void
copy_anon_var(anon_nasl_var* v1, const anon_nasl_var *v2)
{
  /* TBD: free variable if necessary? */
  v1->var_type = v2->var_type;
  switch(v2->var_type)
    {
    case VAR2_STRING:
    case VAR2_DATA:
      if(v2->v.v_str.s_val != NULL)
	{
	  v1->v.v_str.s_val = malloc(v2->v.v_str.s_siz);
	  memcpy(v1->v.v_str.s_val, v2->v.v_str.s_val, v2->v.v_str.s_siz);
	  v1->v.v_str.s_siz = v2->v.v_str.s_siz;
	}
      else
	{
	  v1->v.v_str.s_val = NULL;
	  v1->v.v_str.s_siz = 0;
	}
      break;

    case VAR2_UNDEF:
      break;

    case VAR2_INT:
      v1->v.v_int = v2->v.v_int;
      break;

    case VAR2_ARRAY:
      /* TBD: handle arrays here for multi-dimensional arrays */
    default:
      printf( "copy_anon_var: unhandled type 0x%x\n", v2->var_type);
      clear_anon_var(v1);
    }
}
//-----------------------------------------------------------------------
static anon_nasl_var*
dup_anon_var(const anon_nasl_var* v)
{
  anon_nasl_var	*v1;

  if (v == NULL)
    return NULL;

  v1 = malloc(sizeof(anon_nasl_var));
  copy_anon_var(v1, v);
  return v1;
}
//-----------------------------------------------------------------------
static named_nasl_var*
dup_named_var(const named_nasl_var* v)
{
  named_nasl_var	*v1;

  if (v == NULL)
    return NULL;

  v1 = malloc(sizeof(named_nasl_var));
  copy_anon_var(&v1->u, &v->u);
  v1->var_name = _strdup(v->var_name);
  return v1;
}
//-----------------------------------------------------------------------
static void
copy_array(nasl_array *a1, const nasl_array *a2)
{
  int		i;
  named_nasl_var	*v1, *v2, *v;


  if (a1 == a2)
    {
#if NASL_DEBUG > 1
      printf( "copy_array: a1 == a2!\n");
#endif
      return;
    }
 
  clear_array(a1);

  if ( a2->num_elt != NULL )
    {
      a1->max_idx = a2->max_idx;
      a1->num_elt = malloc(sizeof(anon_nasl_var*) * a2->max_idx);
      for (i = 0; i < a2->max_idx; i ++)
	a1->num_elt[i] = dup_anon_var(a2->num_elt[i]);
    }
  if (a2->hash_elt != NULL)
    {
      a1->hash_elt = malloc(VAR_NAME_HASH * sizeof(named_nasl_var*));
      for (i = 0; i < VAR_NAME_HASH; i ++)
	{
	  v1= NULL;
	  for (v2 = a2->hash_elt[i]; v2 != NULL; v2 = v2->next_var)
	    {
	      v = dup_named_var(v2);
	      v->next_var = v1;
	      a1->hash_elt[i] = v;
	      v1 = v;
	    }
	}
    }
}
//-----------------------------------------------------------------------
static const char*
get_var_name(anon_nasl_var *v)
{
  static char	str[16];
#ifdef ALL_VARIABLES_NAMED
  if (v->av_name != NULL)
    return v->av_name;
#endif
  _snprintf(str, sizeof(str), "[%08x]", (int)v);
  return str;
}
//-----------------------------------------------------------------------
static void
free_var_chain(named_nasl_var* v)
{

  if (v == NULL)
    return;
  free_var_chain(v->next_var);
  free(&v->var_name);
  switch(v->u.var_type)
    {
    case VAR2_STRING:
    case VAR2_DATA:
      free(&v->u.v.v_str.s_val);
      break;
    case VAR2_ARRAY:
      free_array(&v->u.v.v_arr);
      break;
    }
  free(&v);
}
//-----------------------------------------------------------------------
static void
free_anon_var(anon_nasl_var* v)
{
  if (v == NULL)
    return;
  switch(v->var_type)
    {
    case VAR2_STRING:
    case VAR2_DATA:
      free(&v->v.v_str.s_val);
      break;
    case VAR2_ARRAY:
      free_array(&v->v.v_arr);
      break;
    }
  free(&v);

}

//-----------------------------------------------------------------------
nasl_iterator
nasl_array_iterator(tree_cell* c)
{
  nasl_iterator		it;
  anon_nasl_var	*v;

  it.a = NULL;
  it.v = NULL;
  it.i1 = 0;
  it.iH = 0;
  
  if (c == NULL || c == FAKE_CELL)
    return it;

  if (c->type == REF_VAR)
    {
      v = c->x.ref_val;
      if (v == NULL || v->var_type != VAR2_ARRAY)
	return it;
      it.a = &v->v.v_arr;
    }
  else if (c->type == REF_ARRAY || c->type == DYN_ARRAY)
    {
      it.a = c->x.ref_val;
    }
  else
    {
      printf( "nasl_array_iterator: unhandled type %d (0x%x)\n",
	      c->type, c->type);
    }

  return it;
}
//-----------------------------------------------------------------------
tree_cell*
nasl_iterate_array(nasl_iterator* it)
{
  anon_nasl_var	 *av;


  if (it == NULL || it->a == NULL)
    return NULL;

  if (it->i1 >= 0)
    {
      while (it->i1 < it->a->max_idx)
	{
	  av = it->a->num_elt[it->i1 ++];
	  if (av != NULL && av->var_type != VAR2_UNDEF)
	    return var2cell(av);
	}
      it->i1 = -1;
    }

  if (it->a->hash_elt == NULL)
    return NULL;

  if (it->v != NULL)
    it->v = it->v->next_var;
  do
    {
      while (it->v == NULL)
	if (it->iH >= VAR_NAME_HASH)
	  return NULL;
	else
	  it->v = it->a->hash_elt[it->iH ++];

      while (it->v != NULL && it->v->u.var_type == VAR2_UNDEF)
	it->v = it->v->next_var;
    }
  while (it->v == NULL);


  return var2cell(&it->v->u);
}
//-----------------------------------------------------------------------
const char*
array2str(const nasl_array* a)
{
  static char	*s = NULL;
  static int	len = 0;

  int		i, n, n1 = 0, l;
  anon_nasl_var	 *u;
  named_nasl_var *v;


  if (a == NULL)
    return "";

  if (len == 0)
    {
      len = 80;
      s = malloc(80);
    }

  strcpy(s, "[ "); n = strlen(s);

  if (a->num_elt != NULL)
    for (i = 0; i < a->max_idx; i ++)
      if ((u = a->num_elt[i]) != NULL && u->var_type != VAR2_UNDEF)
	{
	  if (n + 80 >= len)
	    {
	      len += 80;
	      s = realloc(s, len);
	    }
	  if (n1 > 0)
	    n += sprintf(s+n, ", ");
	  n1 ++;
	  switch (u->var_type)
	    {
	    case VAR2_INT:
	      _snprintf(s+n, len - n, "%d: %d", i, u->v.v_int);
	      n += strlen(s + n);
	      break;
	    case VAR2_STRING:
	    case VAR2_DATA:
	      if (u->v.v_str.s_siz < 64)
		{
		  _snprintf(s+n, len - n, "%d: '%s'", i, u->v.v_str.s_val);
		  n += strlen(s + n);
		}
	      else
		{
		  _snprintf(s+n, 70, "%d: '%s", i, u->v.v_str.s_val);
		  n += strlen(s + n);
		  n += sprintf(s+n, "'...");
		}
	      break;
	    default:
	      _snprintf(s+n, len-n, "%d: ????", i);
	      n += strlen(s + n);
	      break;
	    }
	}

  if (a->hash_elt != NULL)
    for (i = 0; i < VAR_NAME_HASH; i ++)
      for (v = a->hash_elt[i]; v != NULL; v = v->next_var)
	if (v->u.var_type != VAR2_UNDEF)
	  {
	    l = strlen(v->var_name);
	    u = &v->u;
	    if (n + 80 >= len)
	      {
		len += 80 + l;
		s = realloc(s, len);
	      }
	    if (n1 > 0)
	      n += sprintf(s+n, ", ");
	    n1 ++;
	    switch (u->var_type)
	      {
	      case VAR2_INT:
		n += _snprintf(s+n, len - n, "%s: %d", v->var_name, u->v.v_int);
		break;
	      case VAR2_STRING:
	      case VAR2_DATA:
		if (u->v.v_str.s_siz < 64)
		  {
		    _snprintf(s+n, len - n, "%s: '%s'", v->var_name, u->v.v_str.s_val);
		    n += strlen(s + n);
		  }
		else
		  {
		    _snprintf(s+n, 70+l, "%s: '%s", v->var_name, u->v.v_str.s_val);
		    n += strlen(s + n);
		    n += sprintf(s+n, "'...");
		  }
		break;
	      default:
		_snprintf(s+n, len-n, "%s: ????", v->var_name);
		n += strlen(s + n);
		break;
	      }
	  }

  if (n + 2 >= len)
    {
      len += 80;
      s = realloc(s, len);
    }
  strcpy(s + n, " ]");
  return s;
}
//-----------------------------------------------------------------------
const char*	var2str(const anon_nasl_var* v)
{
  static char	s1[16];

  if (v == NULL)
    return NULL;

  switch (v->var_type)
    {
    case VAR2_INT:
      _snprintf(s1, sizeof(s1), "%d", v->v.v_int);
      return s1;		/* buggy if called twice in a row */

    case VAR2_STRING:
    case VAR2_DATA:
      return v->v.v_str.s_val == NULL ? "" : (const char*)v->v.v_str.s_val;

    case VAR2_UNDEF:
#if NASL_DEBUG > 1
      printf( "var2str: variable %s is undefined!\n", get_var_name(v));
#endif
      return NULL;

    case VAR2_ARRAY:
      return array2str(&v->v.v_arr);

    default:
#if NASL_DEBUG > 0
      printf( "var2str: variable %s has unhandled type %d\n",
		  get_var_name(v), v->var_type);
#endif
      return "";
    }
}
//-----------------------------------------------------------------------
anon_nasl_var*
nasl_get_var_by_num(nasl_array* a, int num, int create)
{
  anon_nasl_var	*v = NULL;

  if (num < 0)
    {
      /* TBD: implement a min_index field, just like $[ in Perl */
      printf( "Negative integer index are not supported yet!\n");
      return NULL;
    }

  if (num < a->max_idx)
    v = a->num_elt[num];
  if (v != NULL || ! create)
    return v;

  if (num >= a->max_idx)
    {
      a->num_elt = realloc(a->num_elt, sizeof(anon_nasl_var*) * (num+1));
      memset(a->num_elt + a->max_idx,0,
	    sizeof(anon_nasl_var*) * (num+1-a->max_idx));
      a->max_idx = num +1;
    }
  v = malloc(sizeof(anon_nasl_var));
  v->var_type = VAR2_UNDEF;

  a->num_elt[num] = v;
  return v;  
}
//-----------------------------------------------------------------------
tree_cell*
var2cell(anon_nasl_var* v)
{
  tree_cell	*tc = alloc_tree_cell(0, NULL);

  tc->type = REF_VAR;
  tc->x.ref_val = v;		/* No need to free this later! */
  return tc;
}

//-----------------------------------------------------------------------
static tree_cell*
affect_to_anon_var(anon_nasl_var* v1, tree_cell* rval)
{
  anon_nasl_var	*v2 = NULL, v0;
  nasl_array	*a = NULL;
  int		t1, t2;
  void		*p;


  t1 = v1->var_type;

  if (rval == NULL || rval == FAKE_CELL)
    {
#if NASL_DEBUG > 1
      printf( "nasl_affect: affecting NULL or FAKE cell undefines variable %s %s\n", get_var_name(v1), get_line_nb(rval));
#endif
      clear_anon_var(v1);
      if(nasl_trace_enabled())nasl_trace(NULL, "NASL> %s <- undef\n", get_var_name(v1));
      return NULL;
    }

  switch (rval->type)
    {
    case CONST_INT:
      t2 = VAR2_INT;
      break;
    case CONST_STR:
      t2 = VAR2_STRING;
      break;
    case CONST_DATA:
      t2 = VAR2_DATA;
      break;

    case REF_VAR:
      v2 = rval->x.ref_val;
      if (v2 == v1)
	{
#if NASL_DEBUG > 1
	  printf( "Copying variable %s to itself is useless and dangerous!\n", get_var_name(v1));
#endif
	  return FAKE_CELL;
	}
      t2 = v2->var_type;
      if (t2 == VAR2_ARRAY)
	a = &v2->v.v_arr;	/* ? */
      break;

    case REF_ARRAY:
    case DYN_ARRAY:
      a = rval->x.ref_val;
      t2 = VAR2_ARRAY;
      if (v1->var_type == VAR2_ARRAY && &v1->v.v_arr == a)
	{
#if NASL_DEBUG > 1
	  printf( "Copying array %s to itself is useless and dangerous!\n", get_var_name(v1));
#endif
	  return FAKE_CELL;
	}
      break;

    default:
      printf("Cannot affect rvalue 0x%x to variable\n", rval->type);
      return NULL;
    }

  /*
   * Bug #146: when executing 
   *    x = 'abc'; x = x;  or   x = make_list(...); x = x[0];
   * the rvalue will be freed before it is copied to the lvalue
   */
  v0 = *v1;

  if (t1 != VAR2_UNDEF && t2 == VAR2_UNDEF)
    {
#if NASL_DEBUG > 0
      printf( "Warning: Undefining defined variable %s %s\n",
		  get_var_name(v1), get_line_nb(rval));
#endif
    }
  else if (t1 == VAR2_ARRAY && t2 != VAR2_ARRAY)
    {
#if NASL_DEBUG > 1
      printf(
		  "Warning: affecting non array (0x%x) to array variable %s\n",
		  t2, get_line_nb(rval));
#endif
    }
  else if ((t1 == VAR2_INT || t1 == VAR2_STRING || t1 == VAR2_DATA) &&
	   t2 == VAR2_ARRAY)
    {
#if NASL_DEBUG > 1
      printf("Warning: affecting array to atomic variable (0x%x) %s\n",  t2, get_line_nb(rval));
#endif
    }

  /* Bug #146: this fake clear is necessary if we copy an array*/
  memset(v1, 0, sizeof(*v1));
  /* Bug #146: no risk with the type, we already copied it */
  v1->var_type = t2;

  if (rval->type != REF_VAR && rval->type != REF_ARRAY && rval->type != DYN_ARRAY)
    switch (t2)
      {
      case VAR2_INT:
	v1->v.v_int = rval->x.i_val;
	break;
      case VAR2_STRING:
      case VAR2_DATA:
        if( rval->x.str_val == NULL )
	  {
	    v1->v.v_str.s_val = NULL;
	    v1->v.v_str.s_siz = 0;
	  }
	else
	  {
	    p = malloc(rval->size+1);
	    memcpy(p, rval->x.str_val, rval->size+1);
	    v1->v.v_str.s_siz = rval->size;
	    v1->v.v_str.s_val = p;
	  }
	break;
      }
  else				/* REF_xxx */
    switch(t2)
      {
      case VAR2_INT:
	v1->v.v_int = v2->v.v_int;
	break;
      case VAR2_STRING:
      case VAR2_DATA:
        if(v2->v.v_str.s_val == NULL)
	  {
	    v1->v.v_str.s_val = NULL;
	    v1->v.v_str.s_siz = 0;
	  }
	else
	  {
	    p = malloc(v2->v.v_str.s_siz);
	    memcpy(p, v2->v.v_str.s_val, v2->v.v_str.s_siz);
	    v1->v.v_str.s_siz = v2->v.v_str.s_siz;
	    v1->v.v_str.s_val = p;
	  }
	break;
      case VAR2_ARRAY:
	copy_array(&v1->v.v_arr, a);
	if (v0.var_type == VAR2_ARRAY)
	 memset(&v0,0, sizeof(v0));	/* So that we don't clear the variable twice */
	break;
      }

  if (nasl_trace_fp != NULL)
    switch(t2)
      {
      case VAR2_INT:
	nasl_trace(NULL, "NASL> %s <- %d\n", get_var_name(v1), v1->v.v_int);
	break;
      case VAR2_STRING:
      case VAR2_DATA:
	nasl_trace(NULL, "NASL> %s <- \"%s\"\n", get_var_name(v1), v1->v.v_str.s_val);
	break;
      case VAR2_ARRAY:
	nasl_trace(NULL, "NASL> %s <- (VAR2_ARRAY)\n", get_var_name(v1));
	break;
      default:
	nasl_trace(NULL, "NASL> %s <- (Type 0x%x)\n", get_var_name(v1), t2);
	break;
      }

  clear_anon_var(&v0);
  return FAKE_CELL;
}
//-----------------------------------------------------------------------
tree_cell*
nasl_affect(tree_cell* lval, tree_cell* rval)
{
  anon_nasl_var	*v1 = NULL;
  
  if(lval == NULL)
  {
   printf( "nasl_effect: invalid lvalue\n");
   return NULL;
  }

  if (lval->type != REF_VAR)
    {
      printf("nasl_affect: cannot affect to non variable %s\n",
	      nasl_type_name(lval->type));
      return NULL;
    }

  v1 = lval->x.ref_val;
  return affect_to_anon_var(v1, rval);
}
//-----------------------------------------------------------------------
static named_nasl_var*
create_named_var(const char* name, tree_cell* val)
{
  named_nasl_var	*v = malloc(sizeof(named_nasl_var));
  tree_cell		*tc;

  if (name != NULL)
    v->var_name = _strdup(name);

  if (val == NULL || val == FAKE_CELL)
    {
#if NASL_DEBUG > 1
      printf("create_named_var: affecting NULL or FAKE cell to variable %s\n", get_var_name(v));
#endif
      v->u.var_type = VAR2_UNDEF;
      return v;
    }

  tc = affect_to_anon_var(&v->u, val);
  /* Here we might test the return value */
  deref_cell(tc);
  return v;
}
//-----------------------------------------------------------------------
named_nasl_var*
add_named_var_to_ctxt(lex_ctxt* lexic, const char* name, tree_cell* val)
{
  int			h = hash_str(name);
  named_nasl_var	*v;
  
  /* Duplicated code ? */
  for (v = lexic->ctx_vars.hash_elt[h]; v != NULL; v = v->next_var)
    if (v->var_name != NULL && strcmp(name, v->var_name) == 0)
      {
	printf( "Cannot add existing variable %s\n", name);
	return NULL;
      }
  v = create_named_var(name, val);
  if (v == NULL)
    return NULL;
  v->next_var = lexic->ctx_vars.hash_elt[h];
  lexic->ctx_vars.hash_elt[h] = v;
  return v;
}

//-----------------------------------------------------------------------
/*
 * Note: the function does not free the nasl_array structure.
 * Do it if necessary
 */
void
free_array(nasl_array* a)
{
  int	i;

  if (a == NULL)
    return;
  if (a->num_elt != NULL)
    {
      for (i = 0; i  < a->max_idx; i ++)
	free_anon_var(a->num_elt[i]);
      free(&a->num_elt);
    }
  if (a->hash_elt != NULL)
    {
      for (i = 0; i < VAR_NAME_HASH; i ++)
	free_var_chain(a->hash_elt[i]);
      free(&a->hash_elt);
    }
  return;
}
//-----------------------------------------------------------------
