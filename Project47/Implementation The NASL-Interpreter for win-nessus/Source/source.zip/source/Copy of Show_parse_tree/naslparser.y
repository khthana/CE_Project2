%{
/* Parser for Nessus Attack Scripting Language version 2
 *
 * Copyright (C) 2004 - 2005 Apisak Srihamat and Nattawut Tintavon
 * Department of Computer Engineering Faculty of Engineering 
 * King Mongkut's Institute of Technology Ladkrabang Bangkok, Thailand
 * Reference from Nessus Attack Scripting Language version 2
 * by Michel Arboi and Renaud Deraison
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2,
 * as published by the Free Software Foundation
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 *
 */
#include <stdlib.h>         
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include <winsock2.h>

#include "nasl_global_ctxt.h"
#include "nasl_tree.h"
#include "nasl_lex_ctxt.h"
#include "nasl_var.h"
#include "nasl_func.h"
#include "nasl_regex.h"
#include "libnessus.h"


#define YYPARSE_PARAM parm
//#define YYLEX_PARAM parm

//#define YYERROR_VERBOSE

// for DEBUG
FILE *output; 
extern FILE *parse_tree;
extern int line_number;

%}
%union {
  int		num;
  char		*str;
  struct asciiz {
    char	*val;
    int		len;
  } data;
  tree_cell	*node;
}

%expect 1

%token IF
%token ELSE
%token EQ
%token NEQ
%token SUPEQ
%token INFEQ
%token OR
%token AND
%token MATCH
%token NOMATCH
%token REP
%token FOR
%token REPEAT
%token UNTIL
%token FOREACH
%token WHILE
%token BREAK
%token FUNCTION
%token RETURN
%token INCLUDE
%token LOCAL
%token GLOBAL
%token PLUS_PLUS
%token MINUS_MINUS
%token L_SHIFT
%token R_SHIFT
%token R_USHIFT
%token EXPO

%token PLUS_EQ
%token MINUS_EQ
%token MULT_EQ
%token DIV_EQ
%token MODULO_EQ
%token L_SHIFT_EQ
%token R_SHIFT_EQ
%token R_USHIFT_EQ
%token RE_MATCH
%token RE_NOMATCH

%token <str> IDENT
%token <data> STRING1
%token <str> STRING2

%token <num> INTEGER

%type <node> arg_list_1 arg_list arg
%type <node> arg_decl_1 arg_decl
%type <node> func_call func_decl
%type <node> instr instr_list instr_decl instr_decl_list simple_instr
%type <node> if_block block loop for_loop while_loop foreach_loop repeat_loop
%type <node> aff rep ret expr aff_func array_index array_elem lvalue var
%type <node> ipaddr post_pre_incr
%type <node> inc loc glob

%type <str>  identifier 
%type <str> string

/* Priority of all operators */
%right '=' PLUS_EQ MINUS_EQ MULT_EQ DIV_EQ MODULO_EQ L_SHIFT_EQ R_SHIFT_EQ R_USHIFT_EQ
%left OR
%left AND
%nonassoc '<' '>' EQ NEQ SUPEQ INFEQ MATCH NOMATCH RE_MATCH RE_NOMATCH
%left '|'
%left '^'
%left '&'
%nonassoc R_SHIFT R_USHIFT L_SHIFT
%left '+' '-' 
%left '*' '/' '%'
%nonassoc NOT
%nonassoc UMINUS BIT_NOT
%right EXPO
%nonassoc PLUS_PLUS MINUS_MINUS

%start	tiptop

%%

tiptop: instr_decl_list
	{
	fprintf(output,"line %d :",line_number);
	fprintf(output,"tiptop: instr_decl_list\n");
	//----------------------------
	  ((naslctxt*)parm)->tree = $1;
	//----------------------------  
	} ;
instr_decl_list: instr_decl
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"instr_decl_list: instr_decl\n");
	  //-----------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_INSTR_L;
	  $$->link[0] = $1;
	  //-----------------------
	}
	| instr_decl instr_decl_list 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"instr_decl instr_decl_list\n");
	  //-----------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_INSTR_L;
	  $$->link[0] = $1;
	  $$->link[1] = $2;
	  //-----------------------
	};
instr_decl: instr | func_decl;

/* Function declaration */
func_decl: FUNCTION identifier '(' arg_decl ')' block
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"func_decl: FUNCTION identifier '(' arg_decl ')' block\n");
	 //-----------------------
	  $$ = alloc_tree_cell(line_number, $2);
	  $$->type = NODE_FUN_DEF;
	  $$->link[0] = $4;
	  $$->link[1] = $6;
	 //-----------------------	 
	};

arg_decl: { 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"arg_decl:\n"); 
	//-------------------
	 $$ = NULL;
	//-------------------
	} | arg_decl_1 { 
				fprintf(output,"line %d :",line_number);
				fprintf(output,"arg_decl: arg_decl_1\n"); 
				//-------------------
				 $$ = $1;
				//-------------------
				};
arg_decl_1: identifier { 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg_decl_1: identifier\n");
	  //------------------------
	   $$ = alloc_tree_cell(line_number, $1); $$->type = NODE_DECL;
	  //------------------------
	  }
	| identifier ',' arg_decl_1 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg_decl_1: identifier ',' arg_decl_1\n");
	  //-----------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_DECL;
	  $$->link[0] = $3; 
	  //-----------------------
	};

/* Block */
block: '{' instr_list '}' { 
     fprintf(output,"line %d :",line_number);
     fprintf(output,"block: '{' instr_list '}'\n"); 
     //-------------------
        $$ = $2;
     //-------------------
     } | '{' '}' { 
      fprintf(output,"line %d :",line_number);
      fprintf(output,"block: '{'  '}'\n");
      //------------------
	$$ = NULL;
      //------------------
      };
instr_list: instr 
	| instr instr_list
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"instr_list: instr| instr instr_list\n");
	 //--------------------------------
	  if ($1 == NULL)
	    $$ = $2;
	  else
	    {
	      $$ = alloc_tree_cell(line_number, NULL);
	      $$->type = NODE_INSTR_L;
	      $$->link[0] = $1;
	      $$->link[1] = $2; 
	    }
	 //--------------------------------
	} ;

/* Instructions */
instr: simple_instr ';' { 
     fprintf(output,"line %d :",line_number);
     fprintf(output,"instr: simple_instr ';\n");
     //----------------------
      $$ = $1;
     //----------------------
     } | block | if_block | loop ;

/* "simple" instruction */
simple_instr : aff | post_pre_incr | rep
	| func_call | ret | inc | loc | glob
	| BREAK {
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"simple_instr \n");
	 //--------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type =  NODE_BREAK;
	 //--------------------------
	}
	| /* nop */ { 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"simple_instr //* nop //* \n"); 
	//---------------------------
	 $$ = NULL;
	//---------------------------
	};

/* return */
ret: RETURN expr
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"ret: RETURN expr\n");
	 //----------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type =  NODE_RETURN;
	  $$->link[0] = $2;
	 //----------------------------
	} |
	RETURN
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"ret: RETURN \n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type =  NODE_RETURN;
	  //---------------------------
	} ;

/* If block */
if_block: IF '(' expr ')' instr 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"if_block: IF '(' expr ')' instr\n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_IF_ELSE;
	  $$->link[0] = $3; $$->link[1] = $5;
	  //---------------------------
	}
	| IF '(' expr ')' instr ELSE instr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"if_block: IF '(' expr ')' instr ELSE instr\n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_IF_ELSE;
	  $$->link[0] = $3; $$->link[1] = $5; $$->link[2] = $7;
	  //---------------------------
	};

/* Loops */
loop : for_loop | while_loop | repeat_loop | foreach_loop ;
for_loop : FOR '(' aff_func ';' expr ';' aff_func ')' instr 
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"for_loop\n");
	 //---------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_FOR;
	  $$->link[0] = $3;
	  $$->link[1] = $5;
	  $$->link[2] = $7;
	  $$->link[3] = $9;
	 //---------------------------------
	};

while_loop : WHILE '(' expr ')' instr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"while_loop\n");
	  //--------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_WHILE;
	  $$->link[0] = $3;
	  $$->link[1] = $5;
	  //--------------------------------
	} ;
repeat_loop : REPEAT instr UNTIL expr ';'
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"repeat_loop\n");
	  //--------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_REPEAT_UNTIL;
	  $$->link[0] = $2;
	  $$->link[1] = $4;
	  //--------------------------------
	} ;

foreach_loop : FOREACH identifier '(' expr ')'  instr 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"foreach_loop\n");
	  //--------------------------------
	  $$ = alloc_tree_cell(line_number, $2);
	  $$->type = NODE_FOREACH;
	  $$->link[0] = $4;
	  $$->link[1] = $6;
	  //--------------------------------
	} ;

/* affectation or function call */
aff_func: aff | post_pre_incr | func_call | /*nop */ { 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"aff_func: \n"); 
	//-----------------------------
	 $$ = NULL;
	//-----------------------------
	};
/* repetition */
rep: func_call REP expr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"rep: func_call REP expr\n");
	  //--------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_REPEATED;
	  $$->link[0] = $1;
	  $$->link[1] = $3;
	  //--------------------------
	} ;

string : STRING1 { $$ = $1.val; } | STRING2 ;

/* include */
inc: INCLUDE '(' string ')'
	{ 
	//-----------------------------------------------
	  naslctxt	subctx;
	  int		x;	          
	  x = init_nasl_ctx(&subctx, $3);
	  $$ = NULL;	  
	  if (x >= 0)
	    {
	      if (! yyparse(&subctx)) //naslparse(&subctx)
		{
		  $$ = subctx.tree;
		}
	      else
	      {
		//nasl_perror(NULL, "%s: Parse error at or near line %d\n",$3, subctx.line_nb);
		printf( "%s: Parse error at or near line %d\n",$3, subctx.line_nb);
		getch();
	      }
	      free(&subctx.buffer);
	      fclose(subctx.fp); subctx.fp = NULL;
	    }
	  free(& $3);	  
	 //-----------------------------------------------
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"include");
	} ;

/* Function call */
func_call: identifier '(' arg_list ')'
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"func_call: identifier '(' arg_list ')'\n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_FUN_CALL;
	  $$->link[0] = $3;
	  //---------------------------
	};

arg_list : arg_list_1 | { 
	 fprintf(output,"arg_list\n"); 
	 //----------------------------
	  $$ = NULL;
	 //----------------------------
	 };
arg_list_1: arg | arg ',' arg_list_1
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"arg_list1\n");
	 //-----------------------------
	  $1->link[1] = $3;
	  $$ = $1;
	 //-----------------------------
	} ;

arg : expr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg : expr\n");
	  //----------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_ARG;
	  $$->link[0] = $1;
	  //----------------------------
	}
	| identifier ':' expr 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg : identifier ':' expr \n");
	  //----------------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_ARG;
	  $$->link[0] = $3;
	  //----------------------------
	} ;

/* Affectation */
aff:	lvalue '=' expr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"=\n");
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_AFF, $1, $3);
	  //----------------------------
	}
	| lvalue PLUS_EQ expr {
	  fprintf(
	  
	  
	  
	  output,"line %d :",line_number); fprintf(output,"==\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_PLUS_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue MINUS_EQ expr  { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"-=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_MINUS_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue MULT_EQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"*=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_MULT_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue DIV_EQ expr  { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"\\=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_DIV_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue MODULO_EQ expr  {
	  fprintf(output,"line %d :",line_number); fprintf(output,"%=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_MODULO_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue R_SHIFT_EQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,">=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_R_SHIFT_EQ, $1, $3);
	  //----------------------------
	  } 
	| lvalue R_USHIFT_EQ expr {
	  fprintf(output,"line %d :",line_number); fprintf(output,">>=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_R_USHIFT_EQ, $1, $3);
	  //----------------------------
	  } 
	| lvalue L_SHIFT_EQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"<=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_L_SHIFT_EQ, $1, $3);
	  //----------------------------
	  } 
	;

lvalue:	identifier { 
          fprintf(output,"line %d :",line_number); fprintf(output,"lvalue:	identifier = %s\n",$1); 
	  //-----------------------------
	   $$ = alloc_tree_cell(line_number, $1); $$->type = NODE_VAR;
	  //-----------------------------
	  } | array_elem ;

identifier:	IDENT | REP { 
	  fprintf(output,"line %d :",line_number); 
	  fprintf(output,"identifier:IDENT | REP\n");
	  //------------------------------	  
	  $$ = _strdup("x");
	  //------------------------------
	  } ; /* => For "x" */
array_elem: identifier '[' array_index ']'
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"array_elem: identifier '[' array_index ']'\n");
	  //-------------------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_ARRAY_EL;
	  $$->link[0] = $3;
	  //-------------------------------
	} ;

array_index: expr ;

post_pre_incr:
   PLUS_PLUS lvalue {  
   	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: PLUS_PLUS lvalue\n"); 
	//---------------------------------
	 $$ = alloc_expr_cell(line_number, EXPR_INCR, NULL, $2);
	//---------------------------------
	}
 | MINUS_MINUS lvalue {
 	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: MINUS_MINUS lvalue\n"); 
	//---------------------------------
	 $$ = alloc_expr_cell(line_number, EXPR_DECR, NULL, $2);
	//---------------------------------
	}
 | lvalue PLUS_PLUS { 
 	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: lvalue PLUS_PLUS\n"); 
	//---------------------------------
	 $$= alloc_expr_cell(line_number, EXPR_INCR, $1, NULL);
	//---------------------------------
	}
 | lvalue MINUS_MINUS { 
        fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: lvalue MINUS_MINUS\n"); 
        //---------------------------------
	 $$= alloc_expr_cell(line_number, EXPR_DECR, $1, NULL);
        //---------------------------------
       }
;

/* expression. We accepte affectations inside parenthesis */
expr: '(' expr ')' { 
          fprintf(output,"line %d :",line_number); fprintf(output,"expr : '(' expr ')'\n"); 
	  //----------------------------------
	   $$ = $2;
	  //----------------------------------
	  }
	| expr AND expr {  
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr AND expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_AND, $1, $3);
	  //----------------------------------
	  } 
	| '!' expr %prec NOT {  
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '!' expr %/prec NOT\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_NOT, $2, NULL);
	  //----------------------------------
	  }
	| expr OR expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr OR expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_OR, $1, $3);
	  //----------------------------------
	  } 
	| expr '+' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '+' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_PLUS, $1, $3);
	  //----------------------------------
	  } 
	| expr '-' expr { 
	 fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '-' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_MINUS, $1, $3);
	  //----------------------------------
	 } 
	| '-' expr %prec UMINUS { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '-' expr %/prec UMINUS\n");
	  //----------------------------------
	    $$ = alloc_expr_cell(line_number, EXPR_U_MINUS, $2, NULL);
	  //----------------------------------
	  } 
	| '~' expr %prec BIT_NOT { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '~' expr %/prec BIT_NOT\n");
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_NOT, $2, NULL);
	  //----------------------------------
	  } 
	| expr '*' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '*' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_MULT, $1, $3);
	  //----------------------------------
	  } 
	| expr EXPO expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr EXPO expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_EXPO, $1, $3);
	  //----------------------------------
	  } 
	| expr '/' expr { 
       	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '/' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_DIV, $1, $3);
	  //----------------------------------
	  } 
	| expr '%' expr {
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '%/' expr\n"); 
	  //----------------------------------
	    $$ = alloc_expr_cell(line_number, EXPR_MODULO, $1, $3);
	  //----------------------------------
	  } 
	| expr '&' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '&' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_AND, $1, $3);
	  //----------------------------------
	  } 
	| expr '^' expr {
	  fprintf(output,"line %d :",line_number);  fprintf(output,"expr : expr '^' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_XOR, $1, $3);
	  //----------------------------------
	  } 
	| expr '|' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '|' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_OR, $1, $3);
	  //----------------------------------
	  } 
	| expr R_SHIFT expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr R_SHIFT expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_R_SHIFT, $1, $3);
	  //-----------------------------------
	  } 
	| expr R_USHIFT expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr R_USHIFT expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_R_USHIFT, $1, $3);
	  //-----------------------------------
	  } 
	| expr L_SHIFT expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr L_SHIFT expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_L_SHIFT, $1, $3);
	  //-----------------------------------
	  } 
	| post_pre_incr
	| expr MATCH expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr MATCH expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_MATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr NOMATCH expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr NOMATCH expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_NOMATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr RE_MATCH string { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr RE_MATCH string\n"); 
	  //-----------------------------------
	   $$ = alloc_RE_cell(line_number, COMP_RE_MATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr RE_NOMATCH string { 	
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr RE_NOMATCH string\n"); 
	  //-----------------------------------
	   $$ = alloc_RE_cell(line_number, COMP_RE_NOMATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr '<' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '<' expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_LT, $1, $3);
	  //-----------------------------------
	  }
	| expr '>' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '>' expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_GT, $1, $3); 
	  //-----------------------------------
	  }
	| expr EQ expr  { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr EQ expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_EQ, $1, $3);
	  //-----------------------------------
	  }
	| expr NEQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr NEQ expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_NE, $1, $3);
	  //-----------------------------------
	  }
	| expr SUPEQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr SUPEQ expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_GE, $1, $3);
	  //-----------------------------------
	  }
	| expr INFEQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr INFEQ expr\n"); 
	  //-----------------------------------
	    $$ = alloc_expr_cell(line_number, COMP_LE, $1, $3);
	  //-----------------------------------
	  }
	| INTEGER { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : INTEGER\n"); 
	  //-----------------------------------
	    $$ = alloc_tree_cell(line_number, NULL); 
	    $$->x.i_val = $1; $$->type = CONST_INT;	
	  //-----------------------------------
	  }
	| STRING2 { 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"expr : STRING2 : %s \n",$1);
	  //------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL); $$->x.str_val = $1;
	  $$->type = CONST_STR; $$->size = strlen($1);
	  //------------------------------------
	}
	| STRING1 { 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"expr : STRING1 :%s \n",$1.val);
	  //------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL); $$->x.str_val = $1.val;
	  $$->type = CONST_DATA; $$->size = $1.len;
	  //------------------------------------
	}
	| var | aff | ipaddr;

var:	identifier { 
   	fprintf(output,"line %d :",line_number);
   	fprintf(output,"var : identifier\n"); 
	//---------------------------------------	
	$$ = alloc_tree_cell(line_number, $1); 
	$$->type = NODE_VAR;
	//---------------------------------------
	}
	| array_elem | func_call;

ipaddr: INTEGER '.' INTEGER '.' INTEGER '.' INTEGER 
	{
	 // I don't know why comment this Dev-C++ not parse error -_-"
	 // fprintf(output,"line %d :",line_number);
	 // fprintf(output,"IPADDRESS : %d.%d.%d.%d", $1, $3, $5, $7);
	  //-------------------------------------
	  char *s = malloc(44);
	  _snprintf(s, 44, "%d.%d.%d.%d", $1, $3, $5, $7);
	  $$ = alloc_tree_cell(line_number, s);
	  $$->type = CONST_STR;
	  $$->size = strlen(s);
	  //--------------------------------------
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"IPADDRESS : %d.%d.%d.%d", $1, $3, $5, $7);
	};

/* Local variable declaration */
loc: LOCAL arg_decl 
	{ 
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"loc: LOCAL arg_decl\n");
	 //---------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_LOCAL;
	  $$->link[0] = $2;
	 //---------------------------------------
	};

/* Global variable declaration */
glob: GLOBAL arg_decl 
	{ 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"glob: GLOBAL arg_decl\n");
	 //---------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_GLOBAL;
	  $$->link[0] = $2;
	 //---------------------------------------
	};

%%

#include <stdio.h>
//#include <stdlib.h>

int 
yyerror(const char *s)
{
  fprintf(output,"%s",s);
  return 0;
}
int
init_nasl_ctx(naslctxt* pc, const char* name)
{
#ifdef MULTIPLE_INCLUDE_DIRS
  static const char* inc_dirs[] = { ".", "/tmp" }; /* TBD */
#endif
  pc->line_nb = 1;
  pc->tree = NULL;
  pc->buffer = (char *)malloc(80);
  pc->maxlen = 80;

#ifdef MULTIPLE_INCLUDE_DIRS
  if (name[0] == '/')		/* absolute path */
#endif
    {
      /* Shouldn't we reject the file? */
      if ((pc->fp = fopen(name, "r")) == NULL)
	{
	  perror(name);
	  return -1;
	}
      return 0;
    }
#ifdef MULTIPLE_INCLUDE_DIRS
  else
    {
      char	full_name[MAXPATHLEN];
      int	i;

      for (i = 0; i < sizeof(inc_dirs) / sizeof(*inc_dirs); i ++)
	{
	  snprintf(full_name, sizeof(full_name),  "%s/%s", inc_dirs[i], name);
	  if ((pc->fp = fopen(full_name, "r")) != NULL)
	    return 0;
	  perror(full_name);
	}
      return -1;
    }
#endif
}
//-------------------------------------------------------------------
//-----------------------------------------------------------------------
FILE*	nasl_trace_fp = NULL;

tree_cell*  nasl_exec(lex_ctxt* , tree_cell* );
//-----------------------------------------------------------------------
//----nasl_debug.c
//------------------------------------------
int nasl_trace_enabled()
{
 if( nasl_trace_fp == NULL )
   return 0;
 else 
  return 1;  
}
//------------------------------------------
void nasl_trace(lex_ctxt * lexic, char * msg, ...)
{
 va_list param;
 char debug_message[4096];
 char *script_name = "", *p;
  
 if(nasl_trace_fp == NULL)
	 return;
 va_start(param, msg);
 
 if( lexic != NULL )
 {
  script_name = arg_get_value(lexic->script_infos, "script_name");
  if(script_name == NULL)
   script_name = "";
 }
 
 _vsnprintf(debug_message, sizeof(debug_message), msg, param);
 for (p = debug_message; *p != '\0'; p ++)
   ;
 if (p == debug_message || p[-1] != '\n')
   fprintf(nasl_trace_fp, "[%d](%s) %s\n",getpid(), script_name, debug_message); 
 else
   fprintf(nasl_trace_fp, "[%d](%s) %s",getpid(), script_name, debug_message); 
 va_end(param);
}
//-----------------------------------------------------------------------
//----nasl_var.c
//------------------------------------------
static const char*
get_var_name(anon_nasl_var *v)
{
  static char	str[16];
#ifdef ALL_VARIABLES_NAMED
  if (v->av_name != NULL)
    return v->av_name;
#endif
  _snprintf(str, sizeof(str), "[%08x]", (int)v);
  return str;
}
//------------------------------------------
tree_cell*
nasl_read_var_ref(lex_ctxt* lexic, tree_cell* tc)
{
  tree_cell	*ret;
  anon_nasl_var	*v;

  if (tc == NULL || tc == FAKE_CELL)
    {
      fprintf(parse_tree, "nasl_read_var_ref: cannot read NULL or FAKE cell\n");      
      return NULL;
    }
  if (tc->type != REF_VAR)
    {
      fprintf(parse_tree, "nasl_read_var_ref: argument (type=%d) is not REF_VAR %s\n", tc->type, get_line_nb(tc));      
      return NULL;
    }

  v = tc->x.ref_val;
  if (v == NULL)
    {
      fprintf(parse_tree, "nasl_read_var_ref: NULL variable in REF_VAR\n");      
      return NULL;
    }

  ret = alloc_tree_cell(tc->line_nb, NULL);

  switch (v->var_type)
    {
    case VAR2_INT:
      ret->type = CONST_INT;
      ret->x.i_val = v->v.v_int;
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> %d\n", get_var_name(v), ret->x.i_val);
      return ret;

    case VAR2_STRING:
      ret->type = CONST_STR;
      /* Fix bad string length */
      if (v->v.v_str.s_siz <= 0 && v->v.v_str.s_val[0] != '\0')
	{
	  v->v.v_str.s_siz = strlen(v->v.v_str.s_val);
	  fprintf(parse_tree, "nasl_read_var_ref: Bad string length fixed\n");
	}
      /* Go on next case */
    case VAR2_DATA:
      ret->type = v->var_type == VAR2_STRING ? CONST_STR : CONST_DATA;
      if(v->v.v_str.s_val == NULL)
      {
       ret->x.str_val = NULL;
       ret->size = 0;
      }
      else
      {
       ret->x.str_val = malloc(v->v.v_str.s_siz);
       memcpy(ret->x.str_val, v->v.v_str.s_val, v->v.v_str.s_siz);
       ret->size = v->v.v_str.s_siz;
      }
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> \"%s\"\n", get_var_name(v), ret->x.str_val);
      return ret;

    case VAR2_ARRAY:
      ret->type = REF_ARRAY;
      ret->x.ref_val = &v->v.v_arr;
      return ret;

    case VAR2_UNDEF:
#if NASL_DEBUG > 0
      name = get_var_name(v);
      if (strcmp(name, "NULL") != 0) /* special case */
	fprintf(parse_tree, "nasl_read_var_ref: variable %s is undefined %s\n",
		    name, get_line_nb(tc));
#endif
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> undef\n", get_var_name(v), v->var_type);
      break;

    default:
      fprintf(parse_tree, "nasl_read_var_ref: unhandled variable type %d\n",
	      v->var_type);
      if(nasl_trace_enabled())nasl_trace(lexic, "NASL> %s -> ???? (Var type %d)\n", get_var_name(v), v->var_type);
      break;
    }
  deref_cell(ret);
  return NULL;
}
//------------------------------------------
tree_cell*
nasl_incr_variable(lex_ctxt* lexic, tree_cell* tc, int pre, int val)
{
  anon_nasl_var	*v;
  int		old_val = 0, new_val;
  tree_cell	*retc;

  if (tc->type != REF_VAR)
    {
      fprintf(parse_tree,
	      "nasl_incr_variable: argument (type=%d) is not REF_VAR %s\n",
	      tc->type, get_line_nb(tc));
      return NULL;
    }

  v = tc->x.ref_val;

  switch (v->var_type)
    {
    case VAR2_INT:
      old_val = v->v.v_int;
      break;
    case VAR2_STRING:
    case VAR2_DATA:
#if NASL_DEBUG > 0
      fprintf(parse_tree, "nasl_incr_variable: variable %s is a STRING %s - converting to integer\n", "", get_line_nb(tc));
#endif
      old_val = v->v.v_str.s_val == NULL ? 0 : atoi(v->v.v_str.s_val);
      break;
    case VAR2_UNDEF:
#if NASL_DEBUG > 0
      fprintf(parse_tree, "nasl_incr_variable: variable %s is undefined %s\n",
	      "", get_line_nb(tc));
#endif
      old_val = 0;
      break;

    default:
      fprintf(parse_tree, "nasl_incr_variable: variable %s has bad type %d %s\n",
	      /*get_var_name(v)*/ "", get_line_nb(tc));
      return NULL;
    }
  new_val = old_val + val;

  clear_anon_var(v);
  v->var_type = VAR2_INT;
  v->v.v_int = new_val;

  retc = alloc_tree_cell(0, NULL);
  retc->type = CONST_INT;
  retc->x.i_val = pre ? new_val : old_val;
  
  return retc;  
}
//------------------------------------------
tree_cell* 
decl_local_variables(lex_ctxt* lexic, tree_cell* vars)
{
  tree_cell	*t;

  for (t = vars; t != NULL; t = t->link[0])
    if (t->x.str_val == NULL)
      fprintf(parse_tree, "decl_local_variables: null name!\n");
    else
      add_named_var_to_ctxt(lexic, t->x.str_val, NULL);
  return FAKE_CELL;
}
//------------------------------------------
tree_cell*
decl_global_variables(lex_ctxt* lexic, tree_cell* vars)
{
  lex_ctxt	*c = lexic;

  while (c->up_ctxt != NULL)
    c = c->up_ctxt;
  return decl_local_variables(c, vars);
}
//-----------------------------------------------------------------------
/*
int
hash_str2(const char* s, int n)
{
  unsigned long		h = 0;
  const char		*p;

  if (s == NULL)
    return 0;

  for (p = s; *p != '\0'; p ++)
    h = (h << 3) + (unsigned char) *p;
  return h % n;
}

static int
hash_str(const char* s)
{
  return hash_str2(s, VAR_NAME_HASH);
}
*/
//------------------------------------------
static named_nasl_var*
get_var_by_name(nasl_array* a, const char* s)
{
  int			h = hash_str(s);
  named_nasl_var	*v;
  
  if (a->hash_elt == NULL)
    a->hash_elt = malloc(VAR_NAME_HASH * sizeof(named_nasl_var*));

  for (v = a->hash_elt[h]; v != NULL; v = v->next_var)
    if (v->var_name != NULL && strcmp(s, v->var_name) == 0)
      return v;

  v = malloc(sizeof(named_nasl_var));
  v->var_name = _strdup(s);
  v->u.var_type = VAR2_UNDEF;
  v->next_var = a->hash_elt[h];

  a->hash_elt[h] = v;
  return v;
}
//------------------------------------------
/* This function climbs up in the context list */
static named_nasl_var*
get_var_ref_by_name(lex_ctxt* ctxt, const char* name, int climb)
{
  named_nasl_var	*v, *prev;
  int		h = hash_str(name);
  lex_ctxt	*c;


  if(climb != 0)
    {
      for (c = ctxt; c != NULL; c = c->up_ctxt)
	if (c->ctx_vars.hash_elt != NULL)
	  for (prev = NULL, v = c->ctx_vars.hash_elt[h]; v != NULL; v = v->next_var)
	    if (v->var_name != NULL && strcmp(name, v->var_name) == 0)
	      {
#ifdef SILLY_OPT
		if (prev != NULL) /* Move it to start of list */
		  {
		    prev->next_var = v->next_var;
		    v->next_var = c->ctx_vars.hash_elt[h];
		    c->ctx_vars.hash_elt[h] = v;
		  }
#endif
	      return v;
    }
#ifdef SILLY_OPT
	    else
	      prev = v;
#endif
    }
  else
    {
      if (ctxt->ctx_vars.hash_elt != NULL)
	for (prev = NULL, v = ctxt->ctx_vars.hash_elt[h]; v != NULL; v = v->next_var)
	  if (v->var_name != NULL && strcmp(name, v->var_name) == 0)
	    {
#ifdef SILLY_OPT
	      if (prev != NULL) /* Move it to start of list */
		{
		  prev->next_var = v->next_var;
		  v->next_var = ctxt->ctx_vars.hash_elt[h];
		  ctxt->ctx_vars.hash_elt[h] = v;
		}
#endif
	    return v;
	    }
#ifdef SILLY_OPT
	  else
	    prev = v;
#endif
    }

  if (ctxt->ctx_vars.hash_elt == NULL)
    ctxt->ctx_vars.hash_elt = malloc(sizeof(named_nasl_var*) * VAR_NAME_HASH);

  v = malloc(sizeof(named_nasl_var));
  v->var_name = _strdup(name);
  v->u.var_type = VAR2_UNDEF;
  v->next_var = ctxt->ctx_vars.hash_elt[h];
  ctxt->ctx_vars.hash_elt[h] = v;

  return v;  
}
//------------------------------------------
tree_cell*
get_variable_by_name(lex_ctxt* ctxt, const char* name)
{
  named_nasl_var	* v;

  if (name == NULL)
    return NULL;
  v = get_var_ref_by_name(ctxt, name, 1);
  return var2cell(&v->u);
}
//------------------------------------------
tree_cell*
get_array_elem(lex_ctxt* ctxt, const char* name, tree_cell* idx)
{
  named_nasl_var	*v = get_var_ref_by_name(ctxt, name, 1);
  named_nasl_var	*nv;
  anon_nasl_var		*u, *av;
  tree_cell	*tc, idx0;


  u = &v->u;

  if (idx == NULL)
    {
#if NASL_DEBUG > 0
      fprintf(parse_tree, "get_array_elem: NULL index\n");
#endif
      /* Treat it as zero */
      idx = &idx0;
      idx->x.i_val = 0;
      idx->type = CONST_INT;
    }

  switch (u->var_type)
    {
    case VAR2_UNDEF:
      /* We define the array here */
      u->var_type = VAR2_ARRAY;
    case VAR2_ARRAY:
      switch(idx->type)
	{
	case CONST_INT:
	  av = nasl_get_var_by_num(&u->v.v_arr, idx->x.i_val, 1);
	  return var2cell(av);
	  
	case CONST_STR:
	case CONST_DATA:
	  nv = get_var_by_name(&u->v.v_arr, idx->x.str_val);
	  return var2cell(nv != NULL ? &nv->u : NULL);
	  
	default:
	  fprintf(parse_tree, "get_array_elem: unhandled index type 0x%x\n",
		  idx->type);
	  return NULL;
	}
      /*NOTREACHED*/
      break;

    case VAR2_INT:
      fprintf(parse_tree, "get_array_elem: variable %s is an integer\n", name);
      return NULL;

    case VAR2_STRING:
    case VAR2_DATA:
      if (idx->type == CONST_INT)
	{
	  int	l = u->v.v_str.s_siz;

	  if (idx->x.i_val >= l)
	    {
	      fprintf(parse_tree, "get_array_elem: requesting character after end of string %s (%d >= %d)\n", name, idx->x.i_val, l);
	      tc = alloc_expr_cell(idx->line_nb, CONST_DATA /*CONST_STR*/,
				   NULL, NULL);
	      tc->x.str_val = _strdup("");
	      tc->size = 0;
	      return tc;
	    }
	  else
	    {
	      if ( idx->x.i_val <  0)
	       {
	        fprintf(parse_tree, "Negative index !\n");
	      	return NULL;
	       }
	      tc = alloc_expr_cell(idx->line_nb, CONST_DATA /*CONST_STR*/,
				   NULL, NULL);
	      tc->x.str_val = malloc(2);
	      tc->x.str_val[0] = u->v.v_str.s_val[idx->x.i_val];
	      tc->x.str_val[1] = '\0';
	      tc->size = 1;
	      return tc;
	    }
	}
      else
	{
	  fprintf(parse_tree, "get_array_elem: Cannot use a non integer index  (type 0x%x) in string\n", idx->type);
	  return NULL;
	}
      /*NOTREACHED*/
      break;

    default:
      fprintf(parse_tree, "Severe bug: unknown variable type 0x%x %s\n",
	      u->var_type, get_line_nb(idx));
      return NULL;
    }
  /*NOTREACHED*/
  return NULL;
}
//-----------------------------------------
//-----------------------------------------------------------------------
//----nasl_func.c
//-----------------------------------------
/* This function climbs up in the context list */
static nasl_func*
get_func(lex_ctxt* ctxt, const char* name, int h)
{
  nasl_func	*v, *prev;
  lex_ctxt	*c;

  for (c = ctxt; c != NULL; c = c->up_ctxt)
    {
      for (prev = NULL, v = c->functions[h]; v != NULL; v = v->next_func)
	if (v->func_name != NULL && strcmp(name, v->func_name) == 0)
	  {
#ifdef SILLY_OPT
	    if (prev != NULL) /* Move it to start of list */
	      {
		prev->next_func = v->next_func;
		v->next_func = c->functions[h];
		c->functions[h]= v;
	      }
#endif
	  return v;
	  }
#ifdef SILLY_OPT
	else
	  prev = v;
#endif
    }

  return NULL;
}
//-----------------------------------------
int compare( const void *arg1, const void *arg2 )
{
   /* Compare all of both strings: */
   return _stricmp( * ( char** ) arg1, * ( char** ) arg2 );
}

//-----------------------------------------
nasl_func*
insert_nasl_func(lex_ctxt* lexic, const char* fname, tree_cell* decl_node)
{
  int		h = hash_str(fname);
  int		i;
  nasl_func	*pf;
  tree_cell	*pc;

  if (get_func(lexic, fname, h) != NULL)
    {
      fprintf(parse_tree, "insert_nasl_func: function '%s' is already defined\n",fname);
      return NULL;
    }
  pf = malloc(sizeof(nasl_func));
  pf->func_name = _strdup(fname);

  if (decl_node != NULL && decl_node != FAKE_CELL)
    {
      for (pc = decl_node->link[0]; pc != NULL; pc = pc->link[0])
	if (pc->x.str_val == NULL)
	  pf->nb_unnamed_args ++;
	else
	  pf->nb_named_args ++;

      pf->args_names = malloc(sizeof(char*) * pf->nb_named_args);
      for (i = 0, pc = decl_node->link[0]; pc != NULL; pc = pc->link[0])
	if (pc->x.str_val != NULL)
	  pf->args_names[i ++] = _strdup(pc->x.str_val);
      /* sort arg names */
//void qsort( void *base, size_t num, size_t width, int (__cdecl *compare )(const void *elem1, const void *elem2 ) );
  qsort(pf->args_names, pf->nb_named_args,sizeof(pf->args_names[0]), compare );

      pf->block = decl_node->link[1];
      ref_cell(pf->block);
    }
  pf->next_func = lexic->functions[h];
  lexic->functions[h] = pf;
  return pf;
}
//-----------------------------------------
tree_cell*
decl_nasl_func(lex_ctxt* lexic, tree_cell* decl_node)
{
  if (decl_node == NULL || decl_node == FAKE_CELL)
    {
      fprintf(parse_tree, "Cannot insert NULL or FAKE cell as function\n");
      return NULL;
    }
    
  if (insert_nasl_func(lexic, decl_node->x.str_val, decl_node) == NULL)
    return NULL;
  else
    return FAKE_CELL;
}
//---------------------------------------------
//-----------------------------------------------------------------------
/* cell2atom returns a 'referenced' cell */	
tree_cell* cell2atom(lex_ctxt* lexic, tree_cell* c1)
{
  tree_cell	*c2 = NULL, *ret = NULL;
  if (c1 == NULL || c1 == FAKE_CELL)
    return c1;

  switch(c1->type)
    {
    case CONST_INT:
    case CONST_STR:
    case CONST_DATA:
    case REF_ARRAY:
    case DYN_ARRAY:
      ref_cell(c1);
      return c1;
    default:
      c2 = nasl_exec(lexic, c1);
      ret = cell2atom(lexic, c2);
      deref_cell(c2);
      return ret;
    }
}
//-----------------------------------------------------------------------
static void
nasl_dump_expr(FILE* fp, const tree_cell* c)
{
  if (c == NULL)
    fprintf(fp, "NULL");
  else if  (c == FAKE_CELL)
    fprintf(fp, "FAKE");
  else
    switch(c->type)
      {
      case NODE_VAR:
	fprintf(fp, "%s", c->x.str_val);
	break;
      case EXPR_AND:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") && (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_OR:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") || (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_NOT:
	fprintf(fp, "! (");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ")");
	break;
      case EXPR_PLUS:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") + (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_MINUS:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") - (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case EXPR_INCR:
	if (c->link[0] == NULL)
	  {
	    fprintf(fp, " ++");
	    nasl_dump_expr(fp, c->link[1]);
	  }
	else
	  {
	    nasl_dump_expr(fp, c->link[0]);
	    fprintf(fp, "++ ");
	  }
	break;
      case EXPR_DECR:
	if (c->link[0] == NULL)
	  {
	    fprintf(fp, " --");
	    nasl_dump_expr(fp, c->link[1]);
	  }
	else
	  {
	    nasl_dump_expr(fp, c->link[0]);
	    fprintf(fp, "-- ");
	  }
	break;
	    
      case EXPR_EXPO:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") ** (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case EXPR_U_MINUS:
	fprintf(fp, " - (");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ")");
	break;

      case EXPR_MULT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") * (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_DIV:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") / (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_MODULO:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") %% (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_AND:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") & (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_OR:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") | (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_XOR:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") ^ (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_BIT_NOT:
	fprintf(fp, "~ (");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ")");
	break;
      case EXPR_L_SHIFT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") << (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_R_SHIFT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") >> (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case EXPR_R_USHIFT:
	fprintf(fp, "(");
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, ") >>> (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;
      case COMP_MATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >< ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_NOMATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >!< ");
	nasl_dump_expr(fp, c->link[1]);
	break;

      case COMP_RE_MATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " =~ ");
	nasl_dump_expr(fp, c->link[1]);
	break;

      case COMP_RE_NOMATCH:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " !~ ");
	nasl_dump_expr(fp, c->link[1]);
	break;

      case COMP_LT:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " < ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_LE:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " <= ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_GT:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " > ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_GE:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >= ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case COMP_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " == ");
	nasl_dump_expr(fp, c->link[1]);
	break;
      case CONST_INT:
	fprintf(fp, "%d", c->x.i_val);
	break;
      case CONST_STR:
      case CONST_DATA:
	fprintf(fp, "\"%s\"", c->x.str_val);
	break;

      case NODE_ARRAY_EL:
	fprintf(fp, "%s[", c->x.str_val);
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "]");
	break; 

      case NODE_FUN_CALL:
	fprintf(fp, "%s(...)", c->x.str_val);
	break;
	
      case NODE_AFF:
	nasl_dump_expr(fp, c->link[0]);
	putc('=', fp);
	nasl_dump_expr(fp, c->link[1]);
	break;

      case NODE_PLUS_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "+= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_MINUS_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "-= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_MULT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "*= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_DIV_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "/= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_MODULO_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, "%%= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_L_SHIFT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " <<= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_R_SHIFT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >>= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      case NODE_R_USHIFT_EQ:
	nasl_dump_expr(fp, c->link[0]);
	fprintf(fp, " >>>= (");
	nasl_dump_expr(fp, c->link[1]);
	fprintf(fp, ")");
	break;

      default:
	fprintf(fp, "*%d*", c->type);
	break;      
      }
}
//-----------------------------------------------------------------------
static void
nasl_short_dump(FILE* fp, const tree_cell* c)
{
  if (c == NULL || c == FAKE_CELL)
    return;

  switch (c->type)
    {
    case NODE_IF_ELSE:
      fprintf(fp, "NASL:%04d> if (", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ") { ... }");
      if (c->link[2] != NULL)  fprintf(fp, " else { ... }");
      putc('\n', fp);
      break;

    case NODE_FOR:
      fprintf(fp, "NASL:%04d> for (", c->line_nb); nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, "; "); nasl_dump_expr(fp, c->link[1]);
      fprintf(fp, "; "); nasl_dump_expr(fp, c->link[2]);
      fprintf(fp, ") { ... }\n");
      break;

    case NODE_WHILE:
      fprintf(fp, "NASL:%04d> while (", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ") { ... }\n");
      break;

    case NODE_FOREACH:
      fprintf(fp, "NASL:%04d> foreach %s (", c->line_nb, c->x.str_val);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ") { ... }\n");
      break;

    case NODE_REPEAT_UNTIL:
      fprintf(fp, "NASL:%04d> repeat { ... } until (", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ")\n");
      break;

    case NODE_REPEATED:
      fprintf(fp, "NASL:%04d> ... x ", c->line_nb); 
      nasl_dump_expr(fp, c->link[1]);
      putc('\n', fp);
      break;

    case NODE_RETURN:
      fprintf(fp, "NASL:%04d> return ", c->line_nb);
      nasl_dump_expr(fp, c->link[0]);
      fprintf(fp, ";\n");
      break;

    case NODE_BREAK:
      fprintf(fp, "NASL:%04d> break\n", c->line_nb);
      break;

    case NODE_AFF:
    case NODE_PLUS_EQ:
    case NODE_MINUS_EQ:
    case NODE_MULT_EQ:
    case NODE_DIV_EQ:
    case NODE_MODULO_EQ:
    case NODE_R_SHIFT_EQ:
    case NODE_R_USHIFT_EQ:
    case NODE_L_SHIFT_EQ:
      fprintf(fp, "NASL:%04d> ", c->line_nb);
      nasl_dump_expr(fp, c);
      fprintf(fp, ";\n");
      break;

    case NODE_FUN_CALL:
      fprintf(fp, "NASL:%04d> %s(...)\n", c->line_nb, c->x.str_val);
      break;

    case NODE_LOCAL:
      fprintf(fp, "NASL:%04d> local_var ...\n", c->line_nb);
      break;

    case NODE_GLOBAL:
      fprintf(fp, "NASL:%04d> global_var ...\n", c->line_nb);
      break;
    }
}
//--------------------------------------------------------------------
int
cell2int(lex_ctxt* lexic, tree_cell* c)
{
  tree_cell	*c2 = NULL;
  int		x;

  if (c == NULL || c == FAKE_CELL) /*  Do not SEGV on undefined variables */
    return 0;

  switch(c->type)
    {
    case CONST_INT:
      return c->x.i_val;
    case CONST_STR:
    case CONST_DATA:  
      return strtol(c->x.str_val, NULL, 0);
    default:
      c2 = nasl_exec(lexic, c);
      x = cell2int(lexic, c2);
      deref_cell(c2);
      return x;
    }
}
//--------------------------------------------------------------------
int
cell2bool(lex_ctxt* lexic, tree_cell* c)
{
  tree_cell	*c2;
  int		flag;


  if (c == NULL || c == FAKE_CELL)
    return 0;
  
  switch (c->type)
    {
    case CONST_INT:
      return c->x.i_val != 0;
    case CONST_STR:
    case CONST_DATA:
      if (c->size == 0)
	return 0;
      if(c->x.str_val[0] == '0' && c->size == 1)
	  return 0;
     return 1;

    case REF_ARRAY:
    case DYN_ARRAY:
      //printf( "cell2bool: converting array to boolean does not make sense!\n");
	printf( "cell2bool: converting array to boolean does not make sense!\n");
	getch();
      return 1;

    default:
      c2 = nasl_exec(lexic, c);
      flag = cell2bool(lexic, c2);
      deref_cell(c2);
      return flag;
    }
}
//--------------------------------------------------------------------
static int
cvt_bool(lex_ctxt* lexic, tree_cell* c)
{
  int	flag;

#if 0
  nasl_dump_tree(c);
#endif
  flag = cell2bool(lexic, c);
  /* free(c); free_tree(c); */
  return flag;
}
//--------------------------------------------------------------------
char*
cell2str(lex_ctxt* lexic, tree_cell* c)
{
  char	* p;
  tree_cell	*c2;
  nasl_array	*a;

  if (c == NULL || c == FAKE_CELL)
    {
#if NASL_DEBUG > 0
      printf( "Cannot convert NULL or FAKE cell to string\n");
      getch();
#endif
      return NULL;
    }
      
  switch(c->type)
    {
    case CONST_INT:
      p = malloc(16);
      _snprintf(p, 16, "%d", c->x.i_val);
      return p;
      
    case CONST_STR:
    case CONST_DATA:
      if ( c->x.str_val == NULL)
	p = _strdup("");
      else
        strncpy(p, c->x.str_val, c->size );
	//p = nasl_strndup(c->x.str_val, c->size);
	

      return p;
      
    case REF_ARRAY:
    case DYN_ARRAY:
      a = c->x.ref_val;
      p = (char*)array2str(a);
      return _strdup(p);

    default:
      c2 = nasl_exec(lexic, c);
      p = cell2str(lexic, c2);
      deref_cell(c2);
      if (p == NULL)
	p = _strdup("");
      return p;
    }
}
//--------------------------------------------------------------------
tree_cell*
int2cell(int x)
{
  tree_cell	*c = alloc_expr_cell(0, CONST_INT, NULL, NULL);
  c->x.i_val = x;
  return c;
}
//--------------------------------------------------------------------
tree_cell*
bool2cell(int x)
{
  return int2cell(x != 0);
}
//--------------------------------------------------------------------
int
cell_cmp(lex_ctxt* lexic, tree_cell* c1, tree_cell* c2)
{
  int		flag, x1, x2, typ, typ1, typ2;
  char		*s1, *s2;
  int		len_s1, len_s2, len_min;


#if NASL_DEBUG >= 0
  if (c1 == NULL || c1 == FAKE_CELL)
    printf( "cell_cmp: c1 == NULL !\n");
    getch();
  if (c2 == NULL || c2 == FAKE_CELL)
    printf( "cell_cmp: c2 == NULL !\n");
    getch();
#endif

  /* We first convert the cell to atomic types */
  c1 = cell2atom(lexic, c1);
  c2 = cell2atom(lexic, c2);

  /*
   * Comparing anything to something else which is entirely different 
   * may lead to unpredictable results.
   * Here are the rules:
   * 1. No problem with same types, although we do not compare arrays yet
   * 2. No problem with CONST_DATA / CONST_STR
   * 3. When an integer is compared to a string, the integer is converted
   * 4. When NULL is compared to an integer, it is converted to 0
   * 5. When NULL is compared to a string, it is converted to ""
   * 6. NULL is "smaller" than anything else (i.e. an array)
   * Anything else is an error
   */
  typ1 = cell_type(c1);
  typ2 = cell_type(c2);

  if (typ1 == 0 && typ2 == 0)	/* Two NULL */
    {
      deref_cell(c1); deref_cell(c2); 
      return 0;
    }

  if (typ1 == typ2)		/* Same type, no problem */
    typ = typ1;
  else if ((typ1 == CONST_DATA || typ1 == CONST_STR) &&
	   (typ2 == CONST_DATA || typ2 == CONST_STR))
    typ = CONST_DATA;		/* Same type in fact (string) */
  /* We convert an integer into a string before compare */
  else if ((typ1 == CONST_INT && (typ2 == CONST_DATA || typ2 == CONST_STR)) ||
	   (typ2 == CONST_INT && (typ1 == CONST_DATA || typ1 == CONST_STR)) )
    {
#if NASL_DEBUG > 0
      printf( "cell_cmp: converting integer to string\n");
      getch();
#endif
      typ = CONST_DATA;
    }
  else if (typ1 == 0)		/* 1st argument is null */
    if (typ2 == CONST_INT || typ2 == CONST_DATA || typ2 == CONST_STR)
      typ = typ2;		/* We convert it to 0 or "" */
    else
      {
	deref_cell(c1); deref_cell(c2); 
	return -1;		/* NULL is smaller than anything else */
      }
  else if (typ2 == 0)		/* 2nd argument is null */
    if (typ1 == CONST_INT || typ1 == CONST_DATA || typ1 == CONST_STR)
      typ = typ1;		/* We convert it to 0 or "" */
    else
      {
	deref_cell(c1); deref_cell(c2); 
	return 1;		/* Anything else is greater than NULL  */
      }
  else
    {
      printf( "cell_cmp: comparing %s and %s does not make sense\n", nasl_type_name(typ1), nasl_type_name(typ2));
      getch();
      deref_cell(c1); deref_cell(c2); 
      return 0;
    } 

  switch (typ)
    {
    case CONST_INT:
      x1 = cell2int(lexic, c1);
      x2 = cell2int(lexic, c2);
      deref_cell(c1); deref_cell(c2); 
      return x1 - x2;

    case CONST_STR:
    case CONST_DATA:
      s1 = cell2str(lexic, c1);
      if (typ1 == CONST_STR || typ1 == CONST_DATA)
	len_s1 = c1->size;
      else if (s1 == NULL)
	len_s1 = 0;
      else
	len_s1 = strlen(s1);

      s2 = cell2str(lexic, c2);
      if (typ2 == CONST_STR || typ2 == CONST_DATA)
	len_s2 = c2->size;
      else if (s2 == NULL)
	len_s2 = 0;
      else
	len_s2 = strlen(s2);
       		  
      len_min = len_s1 < len_s2 ? len_s1 : len_s2;
      flag = 0;

      if (len_min > 0)
	flag = memcmp(s1, s2, len_min);
      if (flag == 0)
	flag = len_s1 - len_s2;
       	
      free(&s1); free(&s2); 
      deref_cell(c1); deref_cell(c2); 
      return flag;

    case REF_ARRAY:
    case DYN_ARRAY:
      fprintf(stderr, "cell_cmp: cannot compare arrays yet\n");
      deref_cell(c1); deref_cell(c2); 
      return 0;

    default:
      fprintf(stderr, "cell_cmp: don't known how to compare %s and %s\n",
	      nasl_type_name(typ1), nasl_type_name(typ2));
      deref_cell(c1); deref_cell(c2); 
      return 0;
    }
}
//--------------------------------------------------------------------
static int
expo(int x, int y)
{
  int	z;

  if (y == 0)
    return 1;
  else if (y < 0)
    if (x == 1)
      return 1;
    else
      return 0;
  else if (y == 1)
    return x;

  z = expo(x, y /2);
  if (y % 2 == 0)
    return z * z;
  else
    return x * z * z;
}
//--------------------------------------------------------------------
tree_cell*
nasl_exec(lex_ctxt* lexic, tree_cell* st)
{
  tree_cell	*ret = NULL, *ret2 = NULL, *tc1 = NULL, *tc2 = NULL, *tc3 = NULL, *idx = NULL, *args;
  int		flag, x, y, z;
  char		*s1 = NULL, *s2 = NULL, *s3 = NULL, *p = NULL;
  char		*p1, *p2;
  int		len1, len2;
  nasl_func	*pf = NULL;
  int		i, n;
  unsigned long sz;


#if 0
  nasl_dump_tree(st);      /* See rt.value, rt.type, rt.length */
#endif

  /* return */
  if (lexic->ret_val != NULL)
    {
      ref_cell(lexic->ret_val);
      return lexic->ret_val;
    }

  /* break */
  if (lexic->break_flag)
    return FAKE_CELL;

  if (st == FAKE_CELL)
    return FAKE_CELL;

  if (st == NULL)
    {
#if NASL_DEBUG > 0
      fprintf(parse_tree, "nasl_exec: st == NULL\n");
#endif
      return NULL;
    }

  if (nasl_trace_fp != NULL)
    nasl_short_dump(nasl_trace_fp, st);

  switch(st->type)
    {
    case NODE_IF_ELSE:
      ret = nasl_exec(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (ret == NULL)
	return NULL;
#endif
      if (cvt_bool(lexic, ret))
	ret2 = nasl_exec(lexic, st->link[1]);
      else
	if (st->link[2] != NULL) /* else branch */
	  ret2 = nasl_exec(lexic, st->link[2]);
	else			/* No else */
	  ret2 = FAKE_CELL;
      deref_cell(ret);
      return ret2;

    case NODE_INSTR_L:	/* Block. [0] = first instr, [1] = tail */
      ret = nasl_exec(lexic, st->link[0]);
#if NASL_DEBUG > 1
      if (ret == NULL)
	fprintf(parse_tree, "Instruction failed. Going on in block\n");
#endif
      if (st->link[1] == NULL || lexic->break_flag)
	return ret;
      deref_cell(ret);
      ret = nasl_exec(lexic, st->link[1]);
      return ret;
	
    case NODE_FOR:
      /* [0] = start expr, [1] = cond, [2] = end_expr, [3] = block */
      ret2 = nasl_exec(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (ret2 == NULL)
	return NULL;
#endif
      deref_cell(ret2);
      for (;;)
	{
	  /* Break the loop if 'return' */
	  if (lexic->ret_val != NULL)
	    {
	      ref_cell(lexic->ret_val);
	      return lexic->ret_val;
	    }

	  /* condition */
	  if ((ret = nasl_exec(lexic, st->link[1])) == NULL)
	    return NULL;	/* We can return here, as NULL is false */
	  flag = cvt_bool(lexic, ret);
	  deref_cell(ret);
	  if (! flag)
	    break;
	  /* block */
	  ret = nasl_exec(lexic, st->link[3]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  deref_cell(ret);

	  /* break */
	  if (lexic->break_flag)
	    {
	      lexic->break_flag = 0;
	      return FAKE_CELL;
	    }

	  /* end expression */
	  ret = nasl_exec(lexic, st->link[2]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  deref_cell(ret); 
	}
      return FAKE_CELL;

    case NODE_WHILE:
      /* [0] = cond, [1] = block */
      for (;;)
	{
	  /* return? */
	  if (lexic->ret_val != NULL)
	    {
	      ref_cell(lexic->ret_val);
	      return lexic->ret_val;
	    }
	  /* Condition */
	  if ((ret = nasl_exec(lexic, st->link[0])) == NULL)
	    return NULL;	/* NULL is false */
	  flag = cvt_bool(lexic, ret);
	  deref_cell(ret);
	  if (! flag)
	    break;
	  /* Block */
	  ret = nasl_exec(lexic, st->link[1]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif	  
	  deref_cell(ret);

	  /* break */
	  if (lexic->break_flag)
	    {
	      lexic->break_flag = 0;
	      return FAKE_CELL;
	    }
	}
      return FAKE_CELL;

    case NODE_REPEAT_UNTIL:
      /* [0] = block, [1] = cond  */
      for (;;)
	{
	  /* return? */
	  if (lexic->ret_val != NULL)
	    {
	      ref_cell(lexic->ret_val);
	      return lexic->ret_val;
	    }
	  /* Block */
	  ret = nasl_exec(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  deref_cell(ret);

	  /* break */
	  if (lexic->break_flag)
	    {
	      lexic->break_flag = 0;
	      return FAKE_CELL;
	    }

	  /* Condition */
	  ret = nasl_exec(lexic, st->link[1]);
#ifdef STOP_AT_FIRST_ERROR
	  if (ret == NULL)
	    return NULL;
#endif
	  flag = cvt_bool(lexic, ret);
	  deref_cell(ret);
	  if (flag)
	    break;
	}
      return FAKE_CELL;

    case NODE_FOREACH:
      /* str_val = index name, [0] = array, [1] = block */
      {
	nasl_iterator	ai;
	tree_cell	*v, *a, *val;

	///v = get_variable_by_name(lexic, st->x.str_val);
	if (v == NULL)
	  return NULL;		/* We cannot go on if we have no variable to iterate */
	a = nasl_exec(lexic, st->link[0]); 
	ai = nasl_array_iterator(a);
	while ((val = nasl_iterate_array(&ai)) != NULL)
	  {
	    tc1 = nasl_affect(v, val);
	    ret = nasl_exec(lexic, st->link[1]);
	    deref_cell(val);
	    deref_cell(tc1);
#ifdef STOP_AT_FIRST_ERROR
	    if (ret == NULL) 
	      break;
#endif
	    deref_cell(ret);

	    /* return */
	    if (lexic->ret_val != NULL)
	      break;
	    /* break */
	    if (lexic->break_flag)
	      {
		lexic->break_flag = 0;
		break;
	      }

	  }
	deref_cell(a);
	deref_cell(v);
      }
      return FAKE_CELL;

    case NODE_FUN_DEF:
      /* x.str_val = function name, [0] = argdecl, [1] = block */
      ret = decl_nasl_func(lexic, st);
      return ret;

    case NODE_FUN_CALL:
      ///pf = get_func_ref_by_name(lexic, st->x.str_val);
      if (pf == NULL)
	{
	  fprintf(parse_tree, "Undefined function '%s'\n", st->x.str_val);
	  return NULL;
	}
      args = st->link[0];
#if 0
      fprintf(parse_tree,"****************\n");
      nasl_dump_tree(args);
      fprintf(parse_tree,"****************\n");
#endif
      ///ret = nasl_func_call(lexic, pf, args);
      return ret;

    case NODE_REPEATED:
      n = cell2int(lexic, st->link[1]);
      if (n <= 0)
	return NULL;
	
#ifdef STOP_AT_FIRST_ERROR	
      for (tc1 = NULL, i = 1; i <= n; i ++)
	{
	  deref_cell(tc1);
	  if ((tc1 = nasl_exec(lexic, st->link[0])) == NULL)
	    return NULL;
	}
      return tc1;
#else
      for (i = 1; i <= n; i ++)
	{
	  tc1 = nasl_exec(lexic, st->link[0]);
	  deref_cell(tc1);
	}
      return FAKE_CELL;
#endif

      /*
       * I wonder... 
       * Will nasl_exec be really called with NODE_EXEC or NODE_ARG?
       */
    case NODE_DECL:		/* Used in function declarations */
      /* [0] = next arg in list */
      /* TBD? */
      return st;		/* ? */

    case NODE_ARG:		/* Used function calls */
      /* val = name can be NULL, [0] = val, [1] = next arg */
      ret = nasl_exec(lexic, st->link[0]);	/* Is this wise? */
      return ret;

    case NODE_RETURN:
      /* [0] = ret val */
      ///ret = nasl_return(lexic, st->link[0]);
      return ret;

    case NODE_BREAK:
      lexic->break_flag = 1;
      return FAKE_CELL;

    case NODE_ARRAY_EL:		/* val = array name, [0] = index */
      idx = cell2atom(lexic, st->link[0]);
      ret = get_array_elem(lexic, st->x.str_val, idx);
      deref_cell(idx);
      return ret;

    case NODE_AFF:
      /* [0] = lvalue, [1] = rvalue */
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      ret = nasl_affect(tc1, tc2);
      deref_cell(tc1);		/* Must free VAR_REF */
      deref_cell(ret);
      return tc2;		/* So that "a = b = e;" works */

    case NODE_PLUS_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_PLUS, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;		/* So that "a = b += e;" works */
      
    case NODE_MINUS_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_MINUS, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;		/* So that "a = b -= e;" works */
      
    case NODE_MULT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_MULT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_DIV_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_DIV, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_MODULO_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_MODULO, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_L_SHIFT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_L_SHIFT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_R_SHIFT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_R_SHIFT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_R_USHIFT_EQ:
      tc1 = nasl_exec(lexic, st->link[0]);
      tc2 = nasl_exec(lexic, st->link[1]);
      tc3 = alloc_expr_cell(0, EXPR_R_USHIFT, tc1, tc2);
      ret2 = nasl_exec(lexic, tc3);
      ret = nasl_affect(tc1, ret2);
      deref_cell(tc3);		/* Frees tc1 and tc2 */
      deref_cell(ret);
      return ret2;
      
    case NODE_VAR:
      /* val = variable name */
      ret = get_variable_by_name(lexic, st->x.str_val);
      return ret;

    case NODE_LOCAL:		/* [0] = argdecl */
      ret = decl_local_variables(lexic, st->link[0]);
      return ret;

    case NODE_GLOBAL:		/* [0] = argdecl */
      ret = decl_global_variables(lexic, st->link[0]);
      return ret;

    case EXPR_AND:
      x = cell2bool(lexic, st->link[0]);
      if(! x)
	return bool2cell(0);
      
      y = cell2bool(lexic, st->link[1]);
      return bool2cell(y);
     

    case EXPR_OR:
      x = cell2bool(lexic, st->link[0]);
      if(x)
       return bool2cell(x);
      y = cell2bool(lexic, st->link[1]);
      return bool2cell(y);

    case EXPR_NOT:
      x = cell2bool(lexic, st->link[0]);
      return bool2cell(! x);

    case EXPR_INCR:
    case EXPR_DECR:
      x =  (st->type == EXPR_INCR) ? 1 : -1;
      if (st->link[0] == NULL)
	{
	  y = 1;		/* pre */
	  tc1 = st->link[1];
	}
      else
	{
	  y = 0;		/* post */
	  tc1 = st->link[0];
	}
      tc2 = nasl_exec(lexic, tc1);
      if (tc2 == NULL)
	return NULL;
      ret = nasl_incr_variable(lexic, tc2, y, x);
      deref_cell(tc2);
      return ret;

      if (st->link[0] == NULL)
	ret = nasl_incr_variable(lexic, st->link[1], 1, 1);
      else
	ret = nasl_incr_variable(lexic, st->link[1], 0, 1);
      break;

    case EXPR_PLUS:
      s1 = s2 = NULL;
      tc1 = cell2atom(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (tc1 == NULL || tc1 == FAKE_CELL)
	return NULL;
#endif
      tc2 = cell2atom(lexic, st->link[1]);
      if (tc2 == NULL || tc2 == FAKE_CELL)
	{
#ifdef STOP_AT_FIRST_ERROR
	  deref_cell(tc1);
	  return NULL;
#else
	  return tc1;
#endif
	}

      if (tc1 == NULL || tc1 == FAKE_CELL)
	return tc2;

      /*
       * Anything added to a string is converted to a string
       * Otherwise anything added to an intger is converted into an integer
       */
      if (tc1->type == CONST_DATA || tc2->type == CONST_DATA)
	flag = CONST_DATA;
      else if (tc1->type == CONST_STR || tc2->type == CONST_STR)
	flag = CONST_STR;
      else if (tc1->type == CONST_INT || tc2->type == CONST_INT)
	flag = CONST_INT;
      else
	flag = NODE_EMPTY;
#if NASL_DEBUG > 0
      if ((flag == CONST_DATA || flag == CONST_STR) && 
	  (tc1->type == CONST_INT || tc2->type == CONST_INT))
	fprintf(parse_tree, "Horrible type conversion (int -> str) for operator + %s\n", get_line_nb(st));
#endif
      switch (flag)
	{
	case CONST_INT:
	  x = tc1->x.i_val;
	  y = cell2int(lexic, st->link[1]);
	  ret = int2cell(x + y);
	  break;

	case CONST_STR:
	case CONST_DATA:
	  s1 = s2 = NULL;
	  if (tc1->type == CONST_STR || tc1->type == CONST_DATA)
	    len1 = tc1->size;
	  else
	    {
	      s1 = cell2str(lexic, tc1);
	      len1 = (s1 == NULL ? 0 : strlen(s1));
	    }

	  if (tc2->type == CONST_STR || tc2->type == CONST_DATA)
	    len2 = tc2->size;
	  else
	    {
	      s2 = cell2str(lexic, tc2);
	      len2 = (s2 == NULL ? 0 : strlen(s2));
	    }

	  sz = len1 + len2;
	  s3 = malloc(sz);
	  if (len1 > 0)
	    memcpy(s3, s1 != NULL ? s1 : tc1->x.str_val, len1);
	  if (len2 > 0)
	    memcpy(s3 + len1, s2 != NULL ? s2 : tc2->x.str_val, len2);
	  free(&s1); free(&s2);
	  ret = alloc_tree_cell(0, s3);
	  ret->type = flag;
	  ret->size = sz;
	  break;

	default:
	  ret = NULL;
	  break;
	}
      deref_cell(tc1);
      deref_cell(tc2);
      return ret;

    case EXPR_MINUS:		/* Infamous duplicated code */
      s1 = s2 = NULL;
      tc1 = cell2atom(lexic, st->link[0]);
#ifdef STOP_AT_FIRST_ERROR
      if (tc1 == NULL || tc1 == FAKE_CELL)
	return NULL;
#endif
      tc2 = cell2atom(lexic, st->link[1]);
      if (tc2 == NULL || tc1 == FAKE_CELL)
	{
#ifdef STOP_AT_FIRST_ERROR
	  deref_cell(tc1);
	  return NULL;
#else
	  return tc1;
#endif
	}

      if (tc1 == NULL || tc1 == FAKE_CELL)
	{
	  if (tc2->type == CONST_INT)
	    {
	      y = cell2int(lexic, tc2);
	      ret = int2cell(- y);
	    }
	  else
	    ret = NULL;
	  deref_cell(tc2);
	  return ret;
	}

      /*
       * Anything substracted from a string is converted to a string
       * Otherwise anything substracted from integer is converted into an
       * integer
       */
      if (tc1->type == CONST_DATA || tc2->type == CONST_DATA)
	flag = CONST_DATA;
      else if (tc1->type == CONST_STR || tc2->type == CONST_STR)
	flag = CONST_STR;
      else if (tc1->type == CONST_INT || tc2->type == CONST_INT)
	flag = CONST_INT;
      else
	flag = NODE_EMPTY;
#if NASL_DEBUG > 0
      if ((flag == CONST_DATA || flag == CONST_STR) && 
	  (tc1->type == CONST_INT || tc2->type == CONST_INT))
	fprintf(parse_tree, "Horrible type conversion (int -> str) for operator - %s\n", get_line_nb(st));
#endif
      switch (flag)
	{
	case CONST_INT:
	  x = cell2int(lexic, tc1);
	  y = cell2int(lexic, tc2);
	  ret = int2cell(x - y);
	  break;

	case CONST_STR:
	case CONST_DATA:
	  if (tc1->type == CONST_STR || tc1->type == CONST_DATA)
	    {
	      p1 = tc1->x.str_val;
	      len1 = tc1->size;
	    }
	  else
	    {
	      p1 = s1 = cell2str(lexic, tc1);
	      len1 = (s1 == NULL ? 0 : strlen(s1));
	    }
	      
	  if (tc2->type == CONST_STR || tc2->type == CONST_DATA)
	    {
	      p2 = tc2->x.str_val;
	      len2 = tc2->size;
	    }
	  else
	    {
	      p2 = s2 = cell2str(lexic, tc2);
	      len2 = (s2 == NULL ? 0 : strlen(s2));
	    }

	  if (len2 == 0 || len1 < len2 || 
	      (p = (char*)strstr(p1,  p2)) == NULL)//memmem -> strstr in win32 ^^
	    {
	      s3 = malloc(len1);
	      memcpy(s3, p1, len1);
	      ret = alloc_tree_cell(0, s3);
	      ret->type = flag;
	      ret->size = len1;
	    }
	  else
	    {
	      sz = len1 - len2;
	      if (sz <= 0)
		{
		  sz = 0;
		  s3 = _strdup("");
		}
	      else
		{
		  s3 = malloc(sz);
		  if (p - p1 > 0)
		    memcpy(s3, p1, p - p1);
		  if (sz > p - p1)
		    memcpy(s3 + (p - p1), p + len2, sz - (p - p1));
		}
	      ret = alloc_tree_cell(0, s3);
	      ret->size = sz;
	      ret->type = flag;
	    }

	  free(&s1); free(&s2);
	 break;

	default:
	  ret = NULL;
	  break;
	}
      deref_cell(tc1);
      deref_cell(tc2);
      return ret;
    
    case EXPR_MULT:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x * y);

    case EXPR_DIV:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      if( y != 0 )
       return int2cell(x / y);
      else
       return int2cell(0);
       
    case EXPR_EXPO:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(expo(x, y));

    case EXPR_MODULO:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      if( y != 0)
       return int2cell(x % y);
      else
       return int2cell(0);

    case EXPR_BIT_AND:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x & y);

    case EXPR_BIT_OR:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x | y);

    case EXPR_BIT_XOR:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x ^ y);

    case EXPR_BIT_NOT:
      x = cell2int(lexic, st->link[0]);
      return int2cell(~ x);

    case EXPR_U_MINUS:
      x = cell2int(lexic, st->link[0]);
      return int2cell(- x);

      /* TBD: Handle shift for strings and arrays */
    case EXPR_L_SHIFT:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
      return int2cell(x << y);

    case EXPR_R_SHIFT:		/* arithmetic right shift */
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
#if NASL_DEBUG > 0
      if (y < 0)
	fprintf(parse_tree, "Warning: Negative count in right shift!\n");
#endif
      z = x >> y;
#ifndef __GNUC__
      if (x < 0 && z >= 0)	/* Fix it */
	{
#if NASL_DEBUG > 1
	  fprintf(parse_tree, "Warning: arithmetic right shift is buggy! Fixing...\n");
#endif
	  z |= (~0) << (sizeof(x) * 8 - y);
	}
#endif
      return int2cell(z);

    case EXPR_R_USHIFT:
      x = cell2int(lexic, st->link[0]);
      y = cell2int(lexic, st->link[1]);
#if NASL_DEBUG > 0
      if (y < 0)
	fprintf(parse_tree, "Warning: Negative count in right shift!\n");
#endif
      z = (unsigned)x >> (unsigned)y;
#ifndef __GNUC__
      if (x < 0 && z <= 0)	/* Fix it! */
	{
#if NASL_DEBUG > 1
	  fprintf(parse_tree, "Warning: Logical right shift is buggy! Fixing...\n");
#endif
	  z &= ~((~0) << (sizeof(x) * 8 - y));
	}
#endif
      return int2cell(z);

    case COMP_MATCH:
    case COMP_NOMATCH:
      tc1 = cell2atom(lexic, st->link[0]); 
      tc2 = cell2atom(lexic, st->link[1]); 
      s1 = s2 = NULL;

      if (tc1 == NULL || tc1 == FAKE_CELL)
	{
	  p1 = ""; 
	  len1 = 0;
	}
      else if (tc1->type == CONST_STR || tc1->type == CONST_DATA)
	{
	  p1 = tc1->x.str_val;
	  len1 = tc1->size;
	}
      else
	{
#if NASL_DEBUG > 0
	  fprintf(parse_tree, "Horrible type conversion (%s -> str) for operator >< or >!< %s\n", nasl_type_name(tc1->type), get_line_nb(st));
#endif
	  p1 = s1 = cell2str(lexic, tc1);
	  len1 = strlen(s1);
	}

      if (tc2 == NULL || tc2 == FAKE_CELL)
	{
	  p2 = "";
	  len2 = 0;
	}
      else if (tc2->type == CONST_STR || tc2->type == CONST_DATA)
	{
	  p2 = tc2->x.str_val;
	  len2 = tc2->size;
	}
      else
	{
#if NASL_DEBUG > 0
	  fprintf(parse_tree, "Horrible type conversion (%s -> str) for operator >< or >!< %s\n", nasl_type_name(tc2->type), get_line_nb(st));
#endif
	  p2 = s2 = cell2str(lexic, tc2);
	  len2 = strlen(s2);
	}

      if(len1 <= len2)		
      	flag = ((void*)strstr(p2, p1) != NULL); //memmem -> strstr in win32 ^^
      else
      	flag = 0;
	
      free(&s1); free(&s2);
      deref_cell(tc1);
      deref_cell(tc2);
      if (st->type == COMP_MATCH)
	return bool2cell(flag);
      else
	return bool2cell(! flag);

    case COMP_RE_MATCH:
    case COMP_RE_NOMATCH:
      if (st->x.ref_val == NULL)
	{
	  fprintf(parse_tree, "nasl_exec: bad regex at or near line %d\n",
		  st->line_nb);
	  return NULL;
	}
      s1 = cell2str(lexic, st->link[0]);
      if (s1 == NULL)
	return 0;
      flag = nasl_regexec(st->x.ref_val, s1, 0, NULL, 0);
      free(s1);
      if (st->type == COMP_RE_MATCH)
	return bool2cell(flag != REG_NOMATCH);
      else
	return bool2cell(flag == REG_NOMATCH);

    case COMP_LT:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) < 0);

    case COMP_LE:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) <= 0);

    case COMP_EQ:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) == 0);

    case COMP_NE:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) != 0);

    case COMP_GT:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) > 0);

    case COMP_GE:
      return bool2cell(cell_cmp(lexic, st->link[0], st->link[1]) >= 0);

    case REF_ARRAY:
    case DYN_ARRAY:
    case CONST_INT:
    case CONST_STR:
    case CONST_DATA:
      ref_cell(st);	/* nasl_exec returns a cell that should be deref-ed */
      return st;

    case REF_VAR:
      ret = nasl_read_var_ref(lexic, st);
      return ret;

    default:
      fprintf(parse_tree, "nasl_exec: unhandled node type %d\n", st->type);
      abort();
      return NULL;
    }

  deref_cell(ret);
  deref_cell(ret2);
  return NULL;
}

//--------------------------------------------------------------------
int safe_checks_only = 0;
//------------------------------------------------
static struct arglist * 
init_hostinfos( hostname, ip)
     char * hostname;
    struct in_addr * ip;
{
  struct arglist * hostinfos;
  struct arglist * ports;
  
  hostinfos = malloc(sizeof(struct arglist));
  arg_add_value(hostinfos, "FQDN", ARG_STRING, strlen(hostname), hostname);
  arg_add_value(hostinfos, "NAME", ARG_STRING, strlen(hostname), hostname);
  arg_add_value(hostinfos, "IP", ARG_PTR, sizeof(struct in_addr), ip);
  ports = malloc(sizeof(struct arglist));
  arg_add_value(hostinfos, "PORTS", ARG_ARGLIST, sizeof(struct arglist), ports);  
  return(hostinfos);
}
//------------------------------------------------
struct arglist * 
init(hostname, ip)
 char * hostname;
 struct in_addr ip;
{
 struct arglist * script_infos = malloc(sizeof(struct arglist));
 struct arglist * prefs        = malloc(sizeof(struct arglist));
 struct in_addr *pip = 		malloc(sizeof(*pip));
 *pip = ip;
 
 arg_add_value(script_infos, "standalone", ARG_INT, sizeof(int), (void*)1);
 arg_add_value(prefs, "checks_read_timeout", ARG_STRING, 4, strdup("5"));
 arg_add_value(script_infos, "preferences", ARG_ARGLIST, -1, prefs);
 
 if(safe_checks_only != 0)
   arg_add_value(prefs, "safe_checks", ARG_STRING, 3, strdup("yes"));
   
 arg_add_value(script_infos, "HOSTNAME", ARG_ARGLIST, -1,
 		init_hostinfos(hostname, pip));
	
 return script_infos;
}

//--------------------------------------------------------------------
extern FILE *yyin;
extern FILE *lex_act;
struct in_addr ip;
struct arglist * script_infos;

main(int argc,char **argv)
{	
	naslctxt ctx;
	char hostname[1024];
  	int mode = 0;
  	ctx.line_nb = 1;
 	ctx.tree = NULL;

	//(1)Character Sequences
	//(2)CreateFile ->windows.h
	yyin = fopen("apache_auth_sql_insertion.nasl","r"); //for test 
	if(yyin == NULL)
	{
		printf("error - cannot assign file yyin\n");
		getch();
		exit(1);
	}

	output =  fopen("parser_act.txt","w"); //for DEBUG
	parse_tree = fopen("output.txt","w");  	
	lex_act = fopen("lexer_act.txt","w");
	if(output == NULL||parse_tree == NULL ||lex_act ==NULL)
	{
		printf("error - cannot open file\n");
		exit(1);
	}	

	fprintf(lex_act,"line %d: ",line_number);
	
  	ip.s_addr = INADDR_LOOPBACK;
  	strncpy( hostname, "localhost", sizeof("localhost") );
  	script_infos = init(hostname, ip);
  	
	if(init_nasl_ctx(&ctx, "apache_auth_sql_insertion.nasl")<0)
	{
		printf("error init_nasl_ctx");
		getch();
		exit(1);
	}
 	if (yyparse(&ctx))
   	{
    	 printf( "\nParse error at or near line %d\n", ctx.line_nb);
	 getch();
     	 //nasl_clean_ctx(&ctx);
   	}
	nasl_dump_tree(ctx.tree);
	//getch();		
		
	fclose(lex_act);
	fclose(parse_tree);
	fclose(output);//for test
	//
	//-------------------------------------------------------------
}
