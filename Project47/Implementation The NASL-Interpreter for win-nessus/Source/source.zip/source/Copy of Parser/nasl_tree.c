#include<stdlib.h>
#include<malloc.h>
#include<stdio.h>
#include"nasl_tree.h"
#include "nasl_regex.h"
//--------------------------------------------------
tree_cell*
alloc_tree_cell(int lnb, char *s)
{
  tree_cell	*p = malloc(sizeof(tree_cell));
  int		i;

  if (p == NULL)
    {
      perror("malloc");
      abort();
    }
  p->type = 0;
  p->size = 0;
  p->line_nb = lnb;
  p->x.str_val = s;
  p->ref_count = 1;
  for (i = 0; i < 4;i ++)
    p->link[i] = NULL;
  return p;
}
//---------------------------------------------------
tree_cell*
alloc_RE_cell(int lnb, int t, tree_cell *l, char *re_str)
{
  regex_t	*re = (regex_t *)malloc(sizeof(regex_t));     //before use emalloc
  int	e;

  tree_cell *c = alloc_tree_cell(lnb, NULL);
  c->type = t;			/* We could check the type... */
  c->link[0] = l;
  c->link[1] = FAKE_CELL;
  e = nasl_regcomp(re, re_str, REG_EXTENDED|REG_NOSUB|REG_ICASE);
  if (! e)
    c->x.ref_val = re;
  else
    {
  /* nasl_perror(NULL, "Line %d: Cannot compile regex: %s (error = %d)\n",
		  lnb, re_str, e);  */
      free(&re);   //before use efree
    }
  free(re_str);
  return c;
}
//---------------------------------------------------
tree_cell*
alloc_expr_cell(int lnb, int t, tree_cell *l, tree_cell *r)
{
  tree_cell *c = alloc_tree_cell(lnb, NULL);
  c->type = t;
  c->link[0] = l;
  c->link[1] = r;
  return c;
}
//---------------------------------------------------
