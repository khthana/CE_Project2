%{
/* Parser for Nessus Attack Scripting Language version 2
 *
 * Copyright (C) 2004 - 2005 Apisak Srihamat and Nattawut Tintavon
 * Department of Computer Engineering Faculty of Engineering 
 * King Mongkut's Institute of Technology Ladkrabang Bangkok, Thailand
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2,
 * as published by the Free Software Foundation
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 *
 */
#include <stdlib.h>         
#include <stdio.h>
#include <malloc.h>
#include <string.h>


#include "nasl_global_ctxt.h"
#include "nasl_tree.h"

#define YYPARSE_PARAM parm
//#define YYLEX_PARAM parm

//#define YYERROR_VERBOSE

// for DEBUG
FILE *output; 
extern int line_number;

%}
%union {
  int		num;
  char		*str;
  struct asciiz {
    char	*val;
    int		len;
  } data;
  tree_cell	*node;
}

%expect 1

%token IF
%token ELSE
%token EQ
%token NEQ
%token SUPEQ
%token INFEQ
%token OR
%token AND
%token MATCH
%token NOMATCH
%token REP
%token FOR
%token REPEAT
%token UNTIL
%token FOREACH
%token WHILE
%token BREAK
%token FUNCTION
%token RETURN
%token INCLUDE
%token LOCAL
%token GLOBAL
%token PLUS_PLUS
%token MINUS_MINUS
%token L_SHIFT
%token R_SHIFT
%token R_USHIFT
%token EXPO

%token PLUS_EQ
%token MINUS_EQ
%token MULT_EQ
%token DIV_EQ
%token MODULO_EQ
%token L_SHIFT_EQ
%token R_SHIFT_EQ
%token R_USHIFT_EQ
%token RE_MATCH
%token RE_NOMATCH

%token <str> IDENT
%token <data> STRING1
%token <str> STRING2

%token <num> INTEGER

%type <node> arg_list_1 arg_list arg
%type <node> arg_decl_1 arg_decl
%type <node> func_call func_decl
%type <node> instr instr_list instr_decl instr_decl_list simple_instr
%type <node> if_block block loop for_loop while_loop foreach_loop repeat_loop
%type <node> aff rep ret expr aff_func array_index array_elem lvalue var
%type <node> ipaddr post_pre_incr
%type <node> inc loc glob

%type <str>  identifier 
%type <str> string

/* Priority of all operators */
%right '=' PLUS_EQ MINUS_EQ MULT_EQ DIV_EQ MODULO_EQ L_SHIFT_EQ R_SHIFT_EQ R_USHIFT_EQ
%left OR
%left AND
%nonassoc '<' '>' EQ NEQ SUPEQ INFEQ MATCH NOMATCH RE_MATCH RE_NOMATCH
%left '|'
%left '^'
%left '&'
%nonassoc R_SHIFT R_USHIFT L_SHIFT
%left '+' '-' 
%left '*' '/' '%'
%nonassoc NOT
%nonassoc UMINUS BIT_NOT
%right EXPO
%nonassoc PLUS_PLUS MINUS_MINUS

%start	tiptop

%%

tiptop: instr_decl_list
	{
	fprintf(output,"line %d :",line_number);
	fprintf(output,"tiptop: instr_decl_list\n");
	//----------------------------
	  ((naslctxt*)parm)->tree = $1;
	//----------------------------  
	} ;
instr_decl_list: instr_decl
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"instr_decl_list: instr_decl\n");
	  //-----------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_INSTR_L;
	  $$->link[0] = $1;
	  //-----------------------
	}
	| instr_decl instr_decl_list 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"instr_decl instr_decl_list\n");
	  //-----------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_INSTR_L;
	  $$->link[0] = $1;
	  $$->link[1] = $2;
	  //-----------------------
	};
instr_decl: instr | func_decl;

/* Function declaration */
func_decl: FUNCTION identifier '(' arg_decl ')' block
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"func_decl: FUNCTION identifier '(' arg_decl ')' block\n");
	 //-----------------------
	  $$ = alloc_tree_cell(line_number, $2);
	  $$->type = NODE_FUN_DEF;
	  $$->link[0] = $4;
	  $$->link[1] = $6;
	 //-----------------------	 
	};

arg_decl: { 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"arg_decl:\n"); 
	//-------------------
	 $$ = NULL;
	//-------------------
	} | arg_decl_1 { 
				fprintf(output,"line %d :",line_number);
				fprintf(output,"arg_decl: arg_decl_1\n"); 
				//-------------------
				 $$ = $1;
				//-------------------
				};
arg_decl_1: identifier { 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg_decl_1: identifier\n");
	  //------------------------
	   $$ = alloc_tree_cell(line_number, $1); $$->type = NODE_DECL;
	  //------------------------
	  }
	| identifier ',' arg_decl_1 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg_decl_1: identifier ',' arg_decl_1\n");
	  //-----------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_DECL;
	  $$->link[0] = $3; 
	  //-----------------------
	};

/* Block */
block: '{' instr_list '}' { 
     fprintf(output,"line %d :",line_number);
     fprintf(output,"block: '{' instr_list '}'\n"); 
     //-------------------
        $$ = $2;
     //-------------------
     } | '{' '}' { 
      fprintf(output,"line %d :",line_number);
      fprintf(output,"block: '{'  '}'\n");
      //------------------
	$$ = NULL;
      //------------------
      };
instr_list: instr 
	| instr instr_list
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"instr_list: instr| instr instr_list\n");
	 //--------------------------------
	  if ($1 == NULL)
	    $$ = $2;
	  else
	    {
	      $$ = alloc_tree_cell(line_number, NULL);
	      $$->type = NODE_INSTR_L;
	      $$->link[0] = $1;
	      $$->link[1] = $2; 
	    }
	 //--------------------------------
	} ;

/* Instructions */
instr: simple_instr ';' { 
     fprintf(output,"line %d :",line_number);
     fprintf(output,"instr: simple_instr ';\n");
     //----------------------
      $$ = $1;
     //----------------------
     } | block | if_block | loop ;

/* "simple" instruction */
simple_instr : aff | post_pre_incr | rep
	| func_call | ret | inc | loc | glob
	| BREAK {
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"simple_instr \n");
	 //--------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type =  NODE_BREAK;
	 //--------------------------
	}
	| /* nop */ { 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"simple_instr //* nop //* \n"); 
	//---------------------------
	 $$ = NULL;
	//---------------------------
	};

/* return */
ret: RETURN expr
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"ret: RETURN expr\n");
	 //----------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type =  NODE_RETURN;
	  $$->link[0] = $2;
	 //----------------------------
	} |
	RETURN
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"ret: RETURN \n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type =  NODE_RETURN;
	  //---------------------------
	} ;

/* If block */
if_block: IF '(' expr ')' instr 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"if_block: IF '(' expr ')' instr\n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_IF_ELSE;
	  $$->link[0] = $3; $$->link[1] = $5;
	  //---------------------------
	}
	| IF '(' expr ')' instr ELSE instr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"if_block: IF '(' expr ')' instr ELSE instr\n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_IF_ELSE;
	  $$->link[0] = $3; $$->link[1] = $5; $$->link[2] = $7;
	  //---------------------------
	};

/* Loops */
loop : for_loop | while_loop | repeat_loop | foreach_loop ;
for_loop : FOR '(' aff_func ';' expr ';' aff_func ')' instr 
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"for_loop\n");
	 //---------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_FOR;
	  $$->link[0] = $3;
	  $$->link[1] = $5;
	  $$->link[2] = $7;
	  $$->link[3] = $9;
	 //---------------------------------
	};

while_loop : WHILE '(' expr ')' instr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"while_loop\n");
	  //--------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_WHILE;
	  $$->link[0] = $3;
	  $$->link[1] = $5;
	  //--------------------------------
	} ;
repeat_loop : REPEAT instr UNTIL expr ';'
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"repeat_loop\n");
	  //--------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_REPEAT_UNTIL;
	  $$->link[0] = $2;
	  $$->link[1] = $4;
	  //--------------------------------
	} ;

foreach_loop : FOREACH identifier '(' expr ')'  instr 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"foreach_loop\n");
	  //--------------------------------
	  $$ = alloc_tree_cell(line_number, $2);
	  $$->type = NODE_FOREACH;
	  $$->link[0] = $4;
	  $$->link[1] = $6;
	  //--------------------------------
	} ;

/* affectation or function call */
aff_func: aff | post_pre_incr | func_call | /*nop */ { 
	fprintf(output,"line %d :",line_number);
	fprintf(output,"aff_func: \n"); 
	//-----------------------------
	 $$ = NULL;
	//-----------------------------
	};
/* repetition */
rep: func_call REP expr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"rep: func_call REP expr\n");
	  //--------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_REPEATED;
	  $$->link[0] = $1;
	  $$->link[1] = $3;
	  //--------------------------
	} ;

string : STRING1 { $$ = $1.val; } | STRING2 ;

/* include */
inc: INCLUDE '(' string ')'
	{ 
	//-----------------------------------------------
	  naslctxt	subctx;
	  int		x;	          
	  x = init_nasl_ctx(&subctx, $3);
	  $$ = NULL;	  
	  if (x >= 0)
	    {
	      if (! yyparse(&subctx)) //naslparse(&subctx)
		{
		  $$ = subctx.tree;
		}
	      else
	      {
		//nasl_perror(NULL, "%s: Parse error at or near line %d\n",$3, subctx.line_nb);
		printf( "%s: Parse error at or near line %d\n",$3, subctx.line_nb);
		getch();
	      }
	      free(&subctx.buffer);
	      fclose(subctx.fp); subctx.fp = NULL;
	    }
	  free(& $3);	  
	 //-----------------------------------------------
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"include");
	} ;

/* Function call */
func_call: identifier '(' arg_list ')'
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"func_call: identifier '(' arg_list ')'\n");
	  //---------------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_FUN_CALL;
	  $$->link[0] = $3;
	  //---------------------------
	};

arg_list : arg_list_1 | { 
	 fprintf(output,"arg_list\n"); 
	 //----------------------------
	  $$ = NULL;
	 //----------------------------
	 };
arg_list_1: arg | arg ',' arg_list_1
	{
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"arg_list1\n");
	 //-----------------------------
	  $1->link[1] = $3;
	  $$ = $1;
	 //-----------------------------
	} ;

arg : expr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg : expr\n");
	  //----------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_ARG;
	  $$->link[0] = $1;
	  //----------------------------
	}
	| identifier ':' expr 
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"arg : identifier ':' expr \n");
	  //----------------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_ARG;
	  $$->link[0] = $3;
	  //----------------------------
	} ;

/* Affectation */
aff:	lvalue '=' expr
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"=\n");
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_AFF, $1, $3);
	  //----------------------------
	}
	| lvalue PLUS_EQ expr {
	  fprintf(output,"line %d :",line_number); fprintf(output,"==\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_PLUS_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue MINUS_EQ expr  { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"-=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_MINUS_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue MULT_EQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"*=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_MULT_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue DIV_EQ expr  { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"\\=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_DIV_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue MODULO_EQ expr  {
	  fprintf(output,"line %d :",line_number); fprintf(output,"%=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_MODULO_EQ, $1, $3);
	  //----------------------------
	  }
	| lvalue R_SHIFT_EQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,">=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_R_SHIFT_EQ, $1, $3);
	  //----------------------------
	  } 
	| lvalue R_USHIFT_EQ expr {
	  fprintf(output,"line %d :",line_number); fprintf(output,">>=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_R_USHIFT_EQ, $1, $3);
	  //----------------------------
	  } 
	| lvalue L_SHIFT_EQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"<=\n"); 
	  //----------------------------
	   $$ = alloc_expr_cell(line_number, NODE_L_SHIFT_EQ, $1, $3);
	  //----------------------------
	  } 
	;

lvalue:	identifier { 
          fprintf(output,"line %d :",line_number); fprintf(output,"lvalue:	identifier = %s\n",$1); 
	  //-----------------------------
	   $$ = alloc_tree_cell(line_number, $1); $$->type = NODE_VAR;
	  //-----------------------------
	  } | array_elem ;

identifier:	IDENT | REP { 
	  fprintf(output,"line %d :",line_number); 
	  fprintf(output,"identifier:IDENT | REP\n");
	  //------------------------------	  
	  $$ = _strdup("x");
	  //------------------------------
	  } ; /* => For "x" */
array_elem: identifier '[' array_index ']'
	{
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"array_elem: identifier '[' array_index ']'\n");
	  //-------------------------------
	  $$ = alloc_tree_cell(line_number, $1);
	  $$->type = NODE_ARRAY_EL;
	  $$->link[0] = $3;
	  //-------------------------------
	} ;

array_index: expr ;

post_pre_incr:
   PLUS_PLUS lvalue {  
   	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: PLUS_PLUS lvalue\n"); 
	//---------------------------------
	 $$ = alloc_expr_cell(line_number, EXPR_INCR, NULL, $2);
	//---------------------------------
	}
 | MINUS_MINUS lvalue {
 	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: MINUS_MINUS lvalue\n"); 
	//---------------------------------
	 $$ = alloc_expr_cell(line_number, EXPR_DECR, NULL, $2);
	//---------------------------------
	}
 | lvalue PLUS_PLUS { 
 	fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: lvalue PLUS_PLUS\n"); 
	//---------------------------------
	 $$= alloc_expr_cell(line_number, EXPR_INCR, $1, NULL);
	//---------------------------------
	}
 | lvalue MINUS_MINUS { 
        fprintf(output,"line %d :",line_number); fprintf(output,"post_pre_incr: lvalue MINUS_MINUS\n"); 
        //---------------------------------
	 $$= alloc_expr_cell(line_number, EXPR_DECR, $1, NULL);
        //---------------------------------
       }
;

/* expression. We accepte affectations inside parenthesis */
expr: '(' expr ')' { 
          fprintf(output,"line %d :",line_number); fprintf(output,"expr : '(' expr ')'\n"); 
	  //----------------------------------
	   $$ = $2;
	  //----------------------------------
	  }
	| expr AND expr {  
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr AND expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_AND, $1, $3);
	  //----------------------------------
	  } 
	| '!' expr %prec NOT {  
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '!' expr %/prec NOT\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_NOT, $2, NULL);
	  //----------------------------------
	  }
	| expr OR expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr OR expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_OR, $1, $3);
	  //----------------------------------
	  } 
	| expr '+' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '+' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_PLUS, $1, $3);
	  //----------------------------------
	  } 
	| expr '-' expr { 
	 fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '-' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_MINUS, $1, $3);
	  //----------------------------------
	 } 
	| '-' expr %prec UMINUS { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '-' expr %/prec UMINUS\n");
	  //----------------------------------
	    $$ = alloc_expr_cell(line_number, EXPR_U_MINUS, $2, NULL);
	  //----------------------------------
	  } 
	| '~' expr %prec BIT_NOT { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : '~' expr %/prec BIT_NOT\n");
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_NOT, $2, NULL);
	  //----------------------------------
	  } 
	| expr '*' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '*' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_MULT, $1, $3);
	  //----------------------------------
	  } 
	| expr EXPO expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr EXPO expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_EXPO, $1, $3);
	  //----------------------------------
	  } 
	| expr '/' expr { 
       	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '/' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_DIV, $1, $3);
	  //----------------------------------
	  } 
	| expr '%' expr {
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '%/' expr\n"); 
	  //----------------------------------
	    $$ = alloc_expr_cell(line_number, EXPR_MODULO, $1, $3);
	  //----------------------------------
	  } 
	| expr '&' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '&' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_AND, $1, $3);
	  //----------------------------------
	  } 
	| expr '^' expr {
	  fprintf(output,"line %d :",line_number);  fprintf(output,"expr : expr '^' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_XOR, $1, $3);
	  //----------------------------------
	  } 
	| expr '|' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '|' expr\n"); 
	  //----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_BIT_OR, $1, $3);
	  //----------------------------------
	  } 
	| expr R_SHIFT expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr R_SHIFT expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_R_SHIFT, $1, $3);
	  //-----------------------------------
	  } 
	| expr R_USHIFT expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr R_USHIFT expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_R_USHIFT, $1, $3);
	  //-----------------------------------
	  } 
	| expr L_SHIFT expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr L_SHIFT expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, EXPR_L_SHIFT, $1, $3);
	  //-----------------------------------
	  } 
	| post_pre_incr
	| expr MATCH expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr MATCH expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_MATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr NOMATCH expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr NOMATCH expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_NOMATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr RE_MATCH string { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr RE_MATCH string\n"); 
	  //-----------------------------------
	   $$ = alloc_RE_cell(line_number, COMP_RE_MATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr RE_NOMATCH string { 	
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr RE_NOMATCH string\n"); 
	  //-----------------------------------
	   $$ = alloc_RE_cell(line_number, COMP_RE_NOMATCH, $1, $3);
	  //-----------------------------------
	  }
	| expr '<' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '<' expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_LT, $1, $3);
	  //-----------------------------------
	  }
	| expr '>' expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr '>' expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_GT, $1, $3); 
	  //-----------------------------------
	  }
	| expr EQ expr  { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr EQ expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_EQ, $1, $3);
	  //-----------------------------------
	  }
	| expr NEQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr NEQ expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_NE, $1, $3);
	  //-----------------------------------
	  }
	| expr SUPEQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr SUPEQ expr\n"); 
	  //-----------------------------------
	   $$ = alloc_expr_cell(line_number, COMP_GE, $1, $3);
	  //-----------------------------------
	  }
	| expr INFEQ expr { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : expr INFEQ expr\n"); 
	  //-----------------------------------
	    $$ = alloc_expr_cell(line_number, COMP_LE, $1, $3);
	  //-----------------------------------
	  }
	| INTEGER { 
	  fprintf(output,"line %d :",line_number); fprintf(output,"expr : INTEGER\n"); 
	  //-----------------------------------
	    $$ = alloc_tree_cell(line_number, NULL); 
	    $$->x.i_val = $1; $$->type = CONST_INT;	
	  //-----------------------------------
	  }
	| STRING2 { 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"expr : STRING2 : %s \n",$1);
	  //------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL); $$->x.str_val = $1;
	  $$->type = CONST_STR; $$->size = strlen($1);
	  //------------------------------------
	}
	| STRING1 { 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"expr : STRING1 :%s \n",$1.val);
	  //------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL); $$->x.str_val = $1.val;
	  $$->type = CONST_DATA; $$->size = $1.len;
	  //------------------------------------
	}
	| var | aff | ipaddr;

var:	identifier { 
   	fprintf(output,"line %d :",line_number);
   	fprintf(output,"var : identifier\n"); 
	//---------------------------------------	
	$$ = alloc_tree_cell(line_number, $1); 
	$$->type = NODE_VAR;
	//---------------------------------------
	}
	| array_elem | func_call;

ipaddr: INTEGER '.' INTEGER '.' INTEGER '.' INTEGER 
	{
	 // I don't know why comment this Dev-C++ not parse error -_-"
	 // fprintf(output,"line %d :",line_number);
	 // fprintf(output,"IPADDRESS : %d.%d.%d.%d", $1, $3, $5, $7);
	  //-------------------------------------
	  char *s = malloc(44);
	  _snprintf(s, 44, "%d.%d.%d.%d", $1, $3, $5, $7);
	  $$ = alloc_tree_cell(line_number, s);
	  $$->type = CONST_STR;
	  $$->size = strlen(s);
	  //--------------------------------------
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"IPADDRESS : %d.%d.%d.%d", $1, $3, $5, $7);
	};

/* Local variable declaration */
loc: LOCAL arg_decl 
	{ 
	 fprintf(output,"line %d :",line_number);
	 fprintf(output,"loc: LOCAL arg_decl\n");
	 //---------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_LOCAL;
	  $$->link[0] = $2;
	 //---------------------------------------
	};

/* Global variable declaration */
glob: GLOBAL arg_decl 
	{ 
	  fprintf(output,"line %d :",line_number);
	  fprintf(output,"glob: GLOBAL arg_decl\n");
	 //---------------------------------------
	  $$ = alloc_tree_cell(line_number, NULL);
	  $$->type = NODE_GLOBAL;
	  $$->link[0] = $2;
	 //---------------------------------------
	};

%%

#include <stdio.h>
//#include <stdlib.h>

int 
yyerror(const char *s)
{
  fprintf(output,"%s",s);
  return 0;
}
int
init_nasl_ctx(naslctxt* pc, const char* name)
{
#ifdef MULTIPLE_INCLUDE_DIRS
  static const char* inc_dirs[] = { ".", "/tmp" }; /* TBD */
#endif
  pc->line_nb = 1;
  pc->tree = NULL;
  pc->buffer = (char *)malloc(80);
  pc->maxlen = 80;

#ifdef MULTIPLE_INCLUDE_DIRS
  if (name[0] == '/')		/* absolute path */
#endif
    {
      /* Shouldn't we reject the file? */
      if ((pc->fp = fopen(name, "r")) == NULL)
	{
	  perror(name);
	  return -1;
	}
      return 0;
    }
#ifdef MULTIPLE_INCLUDE_DIRS
  else
    {
      char	full_name[MAXPATHLEN];
      int	i;

      for (i = 0; i < sizeof(inc_dirs) / sizeof(*inc_dirs); i ++)
	{
	  snprintf(full_name, sizeof(full_name),  "%s/%s", inc_dirs[i], name);
	  if ((pc->fp = fopen(full_name, "r")) != NULL)
	    return 0;
	  perror(full_name);
	}
      return -1;
    }
#endif
}

extern FILE *yyin;

main(int argc,char **argv)
{	
	naslctxt ctx;
  	ctx.line_nb = 1;
 	ctx.tree = NULL;

	output =  fopen("output.txt","w"); //for test 
	if(output == NULL)
	{
		printf("error - cannot open file\n");
		exit(1);
	}	
	yyin = fopen("apache_auth_sql_insertion.nasl","r"); //for test 

	{	 
  	 yyparse((void*) &ctx);	 
	 //getch();
	}
	fclose(output);//for test
}
