#include "nasl_tree.h"

typedef struct {
  int		line_nb;
  FILE		*fp;
  tree_cell	*tree;
  char		*buffer;
  int		maxlen;
} naslctxt;
