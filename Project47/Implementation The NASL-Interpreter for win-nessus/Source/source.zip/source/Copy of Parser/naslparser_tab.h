#include "nasl_tree.h"

typedef union {
  int		num;
  char		*str;
  struct asciiz {
    char	*val;
    int		len;
  } data;
  tree_cell	*node;
} YYSTYPE;
#define	IF	258
#define	ELSE	259
#define	EQ	260
#define	NEQ	261
#define	SUPEQ	262
#define	INFEQ	263
#define	OR	264
#define	AND	265
#define	MATCH	266
#define	NOMATCH	267
#define	REP	268
#define	FOR	269
#define	REPEAT	270
#define	UNTIL	271
#define	FOREACH	272
#define	WHILE	273
#define	BREAK	274
#define	FUNCTION	275
#define	RETURN	276
#define	INCLUDE	277
#define	LOCAL	278
#define	GLOBAL	279
#define	PLUS_PLUS	280
#define	MINUS_MINUS	281
#define	L_SHIFT	282
#define	R_SHIFT	283
#define	R_USHIFT	284
#define	EXPO	285
#define	PLUS_EQ	286
#define	MINUS_EQ	287
#define	MULT_EQ	288
#define	DIV_EQ	289
#define	MODULO_EQ	290
#define	L_SHIFT_EQ	291
#define	R_SHIFT_EQ	292
#define	R_USHIFT_EQ	293
#define	RE_MATCH	294
#define	RE_NOMATCH	295
#define	IDENT	296
#define	STRING1	297
#define	STRING2	298
#define	INTEGER	299
#define	NOT	300
#define	UMINUS	301
#define	BIT_NOT	302


extern YYSTYPE yylval;
