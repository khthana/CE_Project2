function [maxdat,mindat,meandat] = stat()
% ��ʶԵԢ����Ť�ṹ
clear dataint;
conn = database('store','','');
curs = exec(conn,'select * from point');
curs = fetch(curs);
dataans = curs.data;
close(conn);
allrow = rows(curs);

for i = 1: allrow
    tmp = char(dataans(i,2));
    dataint(i) = str2num(tmp);
end
maxdat = max(dataint);
mindat = min(dataint);
meandat = mean(dataint);