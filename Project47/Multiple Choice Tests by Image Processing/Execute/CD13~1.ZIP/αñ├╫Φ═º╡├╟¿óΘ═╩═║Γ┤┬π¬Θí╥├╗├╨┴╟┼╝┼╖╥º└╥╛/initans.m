function initans(answers)
conn = database('store','','');
curs = exec(conn,'delete * from ans2');
curs = fetch(curs);
si = '''';
cm = ',';
fi = ')';
is = 'insert into ans2 values (';
for i = 1:100
    ans = int2str(answers(i));
    ans_id = int2str(i);
    sqlstate = strcat(is,si,ans_id,si,cm,si,ans,si,fi);
    conn = database('store','','');
    curs = exec(conn,sqlstate);
    curs = fetch(curs);
    dataans = curs.data;
    close(conn);
end     
