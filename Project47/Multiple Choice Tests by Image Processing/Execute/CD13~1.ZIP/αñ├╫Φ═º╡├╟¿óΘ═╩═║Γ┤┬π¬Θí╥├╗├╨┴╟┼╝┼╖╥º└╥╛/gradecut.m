function [grade] = gradecut(point)
% �Ѵ�ô...
if point > 80
    grade = 'A';
elseif point > 75
    grade = 'B+';
elseif point > 70
    grade = 'B';
elseif point > 65
    grade = 'C+';
elseif point > 60
    grade = 'C';
elseif point > 55
    grade = 'D+';
elseif point > 50
    grade = 'D';
else
    grade = 'F';
end