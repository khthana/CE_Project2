function varargout = update(varargin)
% UPDATE M-file for update.fig
%      UPDATE, by itself, creates a new UPDATE or raises the existing
%      singleton*.
%
%      H = UPDATE returns the handle to a new UPDATE or the handle to
%      the existing singleton*.
%
%      UPDATE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UPDATE.M with the given input arguments.
%
%      UPDATE('Property','Value',...) creates a new UPDATE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before update_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to update_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help update

% Last Modified by GUIDE v2.5 14-Mar-2005 01:00:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @update_OpeningFcn, ...
                   'gui_OutputFcn',  @update_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before update is made visible.
function update_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to update (see VARARGIN)

% Choose default command line output for update
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes update wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = update_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
conn = database('store','','');
curs = exec(conn,'select * from question');
curs = fetch(curs);
datatest = curs.data;
numrows = rows(curs);
set(handles.all_qt,'string',numrows);
close(conn);

% --- Executes on button press in AddButton.
function AddButton_Callback(hObject, eventdata, handles)
% hObject    handle to AddButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
update_id = get(handles.ed_id,'String');
update_qt = get(handles.ed_qt,'String');
update_ch1 = get(handles.ed_ch1,'String');
update_ch2 = get(handles.ed_ch2,'String');
update_ch3 = get(handles.ed_ch3,'String');
update_ch4 = get(handles.ed_ch4,'String');
update_ans = get(handles.ed_ans,'String');
bank = get(handles.bank_char,'String');
if strcmp(char(update_qt),bank) == 1 || strcmp(char(update_ch1),bank) == 1 || strcmp(char(update_ch2),bank) == 1 || strcmp(char(update_ch3),bank) == 1 || strcmp(char(update_ch4),bank) == 1 || strcmp(char(update_qt),'') == 1 || strcmp(char(update_ch1),'') == 1 || strcmp(char(update_ch2),'') == 1 || strcmp(char(update_ch3),'') == 1 || strcmp(char(update_ch4),'') == 1
    msgbox('��͡�����ŤӶ��-�ӵͺ���ú��سҵ�Ǩ�ͺ�ա��','��سҡ�͡','none');
elseif strcmp(char(update_ans),bank) == 1
    msgbox('��͡��������´��¡�سҵ�Ǩ�ͺ�ա��','��سҡ�͡','none');      
elseif strcmp(update_ans,'1') == 1 || strcmp(update_ans,'2') == 1 || strcmp(update_ans,'3') == 1 || strcmp(update_ans,'4') == 1
    % Cascade String SQL 
    si = '''';
    is = 'update question set quest = ';
    edch1 = ', choice1 = '
    edch2 = ', choice2 = '
    edch3 = ', choice3 = '
    edch4 = ', choice4 = '
    edans = ', answer = '
    condi = ' where id = '
    sqlstate = strcat(is,si,update_qt,si,edch1,si,update_ch1,si,edch2,si,update_ch2,si,edch3,si,update_ch3,si,edch4,si,update_ch4,si,edans,si,update_ans,si,condi,si,update_id,si);
    sqlstate = char(sqlstate);
    % Connect Database for Insert Data
    conn = database('store','','');
    curs = exec(conn,sqlstate);
    curs = fetch(curs);
    close(conn);
    close;
    msgbox('������������º����','ʶҹ�','none'); 
else           
    msgbox('��͹����Ţ 1-4 ��ҹ��','��سҡ�͡','none');    
end
% --- Executes on button press in CancelButton.
function CancelButton_Callback(hObject, eventdata, handles)
% hObject    handle to CancelButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closereq;


% --- Executes on button press in FindButton.
function FindButton_Callback(hObject, eventdata, handles)
% hObject    handle to FindButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
update_id = get(handles.ed_id,'string');
si = '''';
find = char(update_id);
is = 'select * from question where id = ';
sqlfind = strcat(is,si,find,si);
conn = database('store','','');
curs = exec(conn,sqlfind);
% curs = exec(conn,'select * from question where id =''2''');
curs = fetch(curs);
col = columnnames(curs);
qt = curs.Data(:,2);
ch1 = curs.Data(:,3);
ch2 = curs.Data(:,4);
ch3 = curs.Data(:,5);
ch4 = curs.Data(:,6);
ans = curs.Data(:,7);

% set(handles.ed_id,'string','');
set(handles.ed_qt,'string',qt);
set(handles.ed_ch1,'string',ch1);
set(handles.ed_ch2,'string',ch2);
set(handles.ed_ch3,'string',ch3);
set(handles.ed_ch4,'string',ch4);
set(handles.ed_ans,'string',ans);
close(conn);
