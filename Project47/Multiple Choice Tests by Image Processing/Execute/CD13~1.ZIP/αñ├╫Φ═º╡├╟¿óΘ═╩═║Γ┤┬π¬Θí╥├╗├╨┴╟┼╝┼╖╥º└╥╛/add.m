function varargout = add(varargin)
% ADD M-file for add.fig
%      ADD, by itself, creates a new ADD or raises the existing
%      singleton*.
%
%      H = ADD returns the handle to a new ADD or the handle to
%      the existing singleton*.
%
%      ADD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ADD.M with the given input arguments.
%
%      ADD('Property','Value',...) creates a new ADD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before add_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to add_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help add

% Last Modified by GUIDE v2.5 13-Mar-2005 23:26:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @add_OpeningFcn, ...
                   'gui_OutputFcn',  @add_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before add is made visible.
function add_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to add (see VARARGIN)

% Choose default command line output for add
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes add wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = add_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
conn = database('store','','');
curs = exec(conn,'select * from question');
curs = fetch(curs);
datatest = curs.data;
numrows = rows(curs);
% set(handles.ed_id,'string',numrows+1);
set(handles.tx_id,'string',numrows+1);
close(conn);

% --- Executes on button press in AddButton.
function AddButton_Callback(hObject, eventdata, handles)
% hObject    handle to AddButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA) 
add_id = get(handles.tx_id,'String');
add_qt = get(handles.ed_qt,'String');
add_ch1 = get(handles.ed_ch1,'String');
add_ch2 = get(handles.ed_ch2,'String');
add_ch3 = get(handles.ed_ch3,'String');
add_ch4 = get(handles.ed_ch4,'String');
add_ans = get(handles.ed_ans,'String');
bank = get(handles.bank_char,'String');
if strcmp(add_qt,bank) == 1 || strcmp(add_ch1,bank) == 1 || strcmp(add_ch2,bank) == 1 || strcmp(add_ch3,bank) == 1 || strcmp(add_ch4,bank) == 1 || strcmp(add_qt,bank) == 1 || strcmp(add_ch1,'') == 1 || strcmp(add_ch2,'') == 1 || strcmp(add_ch3,'') == 1 || strcmp(add_ch4,'') == 1    
    msgbox('��͡�����ŤӶ��-�ӵͺ���ú��سҵ�Ǩ�ͺ�ա��','��سҡ�͡','none');
elseif strcmp(add_ans,bank) == 1 || strcmp(add_ans,'') == 1
    msgbox('��͡��������´��¡�سҵ�Ǩ�ͺ�ա��','��سҡ�͡','none');    
elseif strcmp(add_ans,'1') == 1 || strcmp(add_ans,'2') == 1 || strcmp(add_ans,'3') == 1 || strcmp(add_ans,'4') == 1
    % Cascade String SQL 
    si = '''';
    cm = ',';
    fi = ')';
    is = 'insert into question values ('
    sqlstate = strcat(is,si,add_id,si,cm,si,add_qt,si,cm,si,add_ch1,si,cm,si,add_ch2,si,cm,si,add_ch3,si,cm,si,add_ch4,si,cm,si,add_ans,si,fi);
    % Connect Database for Insert Data
    sqlstate = char(sqlstate);
    conn = database('store','','');
    curs = exec(conn,sqlstate);
    curs = fetch(curs);
    close(conn);
    close;
    msgbox('�����ŨѴ�����º����','ʶҹ�','none'); 
else           
    msgbox('��͹����Ţ 1-4 ��ҹ��','��سҡ�͡','none');
end
% --- Executes on button press in CancelButton.
function CancelButton_Callback(hObject, eventdata, handles)
% hObject    handle to CancelButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closereq;


% --- Executes on button press in ClearButton.
function ClearButton_Callback(hObject, eventdata, handles)
% hObject    handle to ClearButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% set(handles.ed_id,'string','');
set(handles.ed_qt,'string','');
set(handles.ed_ch1,'string','');
set(handles.ed_ch2,'string','');
set(handles.ed_ch3,'string','');
set(handles.ed_ch4,'string','');
set(handles.ed_ans,'string','');