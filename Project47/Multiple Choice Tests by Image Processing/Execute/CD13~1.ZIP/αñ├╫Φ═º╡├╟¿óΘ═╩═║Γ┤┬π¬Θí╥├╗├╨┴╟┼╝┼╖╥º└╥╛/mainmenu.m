
%GUI spacing parameters
dfp = get(0,'DefaultFigurePosition');
mfp = [560 420];    %Reference width and height
bspc = mean([5/mfp(2)*dfp(4) 5/mfp(1)*dfp(3)]);
bhgt = 30/mfp(2) * dfp(4);
bwid = 100/mfp(1) * dfp(3);
bwid2 = 70/mfp(1) * dfp(3);

%Build main window
f = figure('Name','�к���Ǩ����ͺ�ù�� �Ҥ���ǡ������������� ʶҺѹ෤����վ�Ш�������Ҥس�����Ҵ��кѧ','Numbertitle','off','Resize','off',...
           'Menubar','none','Closerequestfcn','eventcallback(''Exit'')');
      
%Adjust size of dialog to fit uicontrols
p = get(gcf,'Position');
rgt = 6*(bspc+bwid);
top = p(4)+100;
set(gcf,'Position',[p(1)-100 p(2)-100 rgt top]);

%Build menu
qm = uimenu('Label','&Menu','Accelerator','M');
qmm = uimenu(qm,'Label','&ViewCamera');
    uimenu(qmm,'Label','&Show','Tag','ShowCam','Callback','eventcallback');
    uimenu(qmm,'Label','&Hide','Tag','HideCam','Callback','eventcallback');
cmm = uimenu(qm,'Label','&Check');
    uimenu(cmm,'Label','&Checking','Tag','Check','Callback','eventcallback');
    uimenu(cmm,'Label','&InitialAnswer','Tag','InitAns','Callback','eventcallback');
uimenu(qm,'Label','&AddTest','Tag','AddTest','Callback','eventcallback');
uimenu(qm,'Label','&EditTest','Tag','EditTest','Callback','eventcallback');
uimenu(qm,'Label','&DeleteTest','Tag','DeleteTest','Callback','eventcallback');
uimenu(qm,'Label','E&xit','Tag','Exit','Separator','on','Callback','eventcallback');


%Build Display Menu
dm = uimenu('Label','&Display','Accelerator','D');
uimenu(dm,'Label','Show&Point','Tag','ShowPoint','Callback','eventcallback');
dmm = uimenu(dm,'Label','Show&Test');
    uimenu(dmm,'Label','&Normal','Tag','Normal','Callback','eventcallback');
    uimenu(dmm,'Label','&Random','Tag','Randomdata','Callback','eventcallback');
uimenu(dm,'Label','Create&Random','Tag','CreateRandom','Callback','eventcallback');    
%Build About Menu
hm = uimenu('Label','&About','Accelerator','H','Tag','About Project','Callback','eventcallback');


%Pushbuttons for advanced query statements
uicontrol('String','ViewCam','Callback','eventcallback',...
  'Tooltip','�ʴ��Ҿ��ҹ���ͧ webcam','Tag','ShowCam',...
  'Position',[1 top-bhgt bwid2 bhgt]);
uicontrol('String','Check','Callback','eventcallback',...
  'Tooltip','���ͷӡ�õ�Ǩ�礤ӵͺ�ҼŤ�ṹ�����','Tag','Check',...
  'Position',[1+bwid2 top-bhgt bwid2 bhgt]);
uicontrol('String','InitialAnswer','Callback','eventcallback',...
  'Tooltip','��˹����','Tag','InitAns',...
  'Position',[1+2*bwid2  top-bhgt bwid2 bhgt]);
uicontrol('String','AddTest','Callback','eventcallback',...
  'Tooltip','��������ͺ','Tag','AddTest',...
  'Position',[1+3*bwid2 top-bhgt bwid2 bhgt]);
uicontrol('String','EditTest','Callback','eventcallback',...
  'Tooltip','��䢢���ͺ','Tag','EditTest',...
  'Position',[1+4*bwid2 top-bhgt bwid2 bhgt]);
uicontrol('String','DeleteTest','Callback','eventcallback',...
  'Tooltip','ź����ͺ','Tag','DeleteTest',...
  'Position',[1+5*bwid2 top-bhgt bwid2 bhgt]);
uicontrol('String','ShowPoint','Callback','eventcallback',...
  'Tooltip','�ʴ��Ţͧ��ṹ������','Tag','ShowPoint',...
  'Position',[1+6*bwid2 top-bhgt bwid2 bhgt]);
uicontrol('String','ShowTest','Callback','eventcallback',...
  'Tooltip','�ʴ��Ţͧ����ͺ','Tag','Normal',...
  'Position',[1+7*bwid2 top-bhgt bwid2 bhgt]);
uicontrol('String','Exit','Callback','eventcallback',...
  'Tooltip','�͡�ҡ�����','Tag','Exit',...
  'Position',[1+8*bwid2 top-bhgt bwid2 bhgt]);