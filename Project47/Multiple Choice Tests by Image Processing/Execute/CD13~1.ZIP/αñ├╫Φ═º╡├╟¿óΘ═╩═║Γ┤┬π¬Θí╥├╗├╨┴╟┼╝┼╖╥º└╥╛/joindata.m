function [datatest,m] = joindata()
conn = database('store','','');
curs = exec(conn,'select * from question');
curs = fetch(curs);
datatest = curs.data;
numrows = rows(curs);
numcols = cols(curs)
m = numrows;
n = numcols-1;
close(conn);