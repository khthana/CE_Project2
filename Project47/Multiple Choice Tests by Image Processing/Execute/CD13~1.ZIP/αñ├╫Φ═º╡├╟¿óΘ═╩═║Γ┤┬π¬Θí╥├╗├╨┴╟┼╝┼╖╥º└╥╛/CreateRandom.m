function CreateRandom()
conn = database('store','','');
curs = exec(conn,'delete * from ranquest');
curs = fetch(curs);
[datatest numrows] = joindata;
r = randperm(4); 
r_ans = randperm(numrows);
for i = 1 : numrows
    add_id = int2str(i);
    add_qt = char(datatest(r_ans(i),2));
    add_ch1 = char(datatest(r_ans(i),3));
    add_ch2 = char(datatest(r_ans(i),4));
    add_ch3 = char(datatest(r_ans(i),5));
    add_ch4 = char(datatest(r_ans(i),6));
    add_ans = int2str(i);    
    si = '''';
    cm = ',';
    fi = ')';
    is = 'insert into ranquest values ('
    sqlstate = strcat(is,si,add_id,si,cm,si,add_qt,si,cm,si,add_ch1,si,cm,si,add_ch2,si,cm,si,add_ch3,si,cm,si,add_ch4,si,cm,si,add_ans,si,fi);
%     Connect Database for Insert Data
    conn = database('store','','');
    curs = exec(conn,sqlstate);
    curs = fetch(curs);
    close(conn);
end
msgbox('�ӡ����������ͺ�������º����','ʶҹ�','none');