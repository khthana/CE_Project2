function varargout = finds(varargin)
% FINDS M-file for finds.fig
%      FINDS, by itself, creates a new FINDS or raises the existing
%      singleton*.
%
%      H = FINDS returns the handle to a new FINDS or the handle to
%      the existing singleton*.
%
%      FINDS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FINDS.M with the given input arguments.
%
%      FINDS('Property','Value',...) creates a new FINDS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before finds_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to finds_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help finds

% Last Modified by GUIDE v2.5 28-Jan-2005 17:03:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @finds_OpeningFcn, ...
                   'gui_OutputFcn',  @finds_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before finds is made visible.
function finds_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to finds (see VARARGIN)

% Choose default command line output for finds
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes finds wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = finds_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in FindButton.
function FindButton_Callback(hObject, eventdata, handles)
% hObject    handle to FindButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
finds_id = get(handles.ed_id,'String');
finds_qt = get(handles.ed_qt,'String');
finds_ch1 = get(handles.ed_ch1,'String');
finds_ch2 = get(handles.ed_ch2,'String');
finds_ch3 = get(handles.ed_ch3,'String');
finds_ch4 = get(handles.ed_ch4,'String');
finds_ch5 = get(handles.ed_ch5,'String');
finds_ans = get(handles.ed_ans,'String');
% Cascade String SQL 
si = '''';
cm = ',';
fi = ')';
is = 'insert into question values ('
sqlstate = strcat(is,si,finds_id,si,cm,si,finds_qt,si,cm,si,finds_ch1,si,cm,si,finds_ch2,si,cm,si,finds_ch3,si,cm,si,finds_ch4,si,cm,si,finds_ch5,si,cm,si,finds_ans,si,fi);
% Connect Database for Insert Data
sqlstate = char(sqlstate);
conn = database('store','','');
curs = exec(conn,sqlstate);
curs = fetch(curs);
close(conn);

% --- Executes on button press in CancelButton.
function CancelButton_Callback(hObject, eventdata, handles)
% hObject    handle to CancelButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
mainmenu;


% --- Executes on button press in TestButton.
function TestButton_Callback(hObject, eventdata, handles)
% hObject    handle to TestButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
conn = database('store','','');
curs = exec(conn,'select * from question');
curs = fetch(curs);
numcols = cols(curs)
datafield = curs.Data
set(handles.ed_ans,'string',numcols);
close(conn);