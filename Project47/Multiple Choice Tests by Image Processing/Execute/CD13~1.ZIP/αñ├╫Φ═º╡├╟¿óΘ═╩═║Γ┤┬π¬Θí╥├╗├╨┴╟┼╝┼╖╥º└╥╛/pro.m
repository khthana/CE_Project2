function pro();
clear answer;
clear student;
clear student_point;
% close all;
tic
% ====================== Input Picture =================
porg=vfm('grab');
% ============== Convert Color to Bina ==================
thres = graythresh(porg);
autothresh1=0.13;
rowrunup =433;
count = 0;
count_check = 0;
count_check2 = 0;
count_check3 = 0;
%=================== Check Barcode ===================== 
while(true)
    pbina = im2bw(porg,thres-autothresh1);
    %         imshow(pbina);
    % ====================== find markpoint==================
    while(true)
        for i=23:615
            if(pbina(rowrunup,i)==0 && pbina(rowrunup,i+1)>0)
                count=count+1;
                markpoint(count) = i;
            end
        end
        if count < 48
            %                 disp('Barcode ���֧ 48 �մ �Դ�����Դ��Ҵ');
            rowrunup = rowrunup-1;
            count = 0;
        else 
            break;
        end
    end
    if count ~= 48
        %             disp('Barcode �Թ 48 �մ �Դ�����Դ��Ҵ');
        autothersh1=autothresh1+0.01;
        count = 0;
    else
        break;
    end       
end

while(true)
    % ====================== Filter ==========================   
    t = 1;
    
    answers = 0;
    tmp_rowup = [];
    tmp_rowdown = [];
    pbina = im2bw(porg,thres-autothresh1);
    pbina_label = bwlabel(~pbina);
    Areachoice = regionprops(pbina_label,'Area','Centroid');
    idx = find([Areachoice.Area] > 15 & [Areachoice.Area]<110);
    pbina = ismember(pbina_label,idx);
    pbina = ~pbina;
    %     figure:imshow(pbina);
    % ========================= crop Coloum ====================   
    pcolumn1 = imcrop(pbina,[markpoint(22+(0*7)) 64 markpoint(27+(0*7))-markpoint(22+(0*7)) 352]);
    pcolumn2 = imcrop(pbina,[markpoint(22+(1*7)) 64 markpoint(27+(1*7))-markpoint(22+(1*7)) 352]);
    pcolumn3 = imcrop(pbina,[markpoint(22+(2*7)) 64 markpoint(27+(2*7))-markpoint(22+(2*7)) 352]);
    pcolumn4 = imcrop(pbina,[markpoint(22+(3*7)) 64 markpoint(27+(3*7))-markpoint(22+(3*7)) 352]);
    %         figure:imshow(pcolumn1);
    %         figure:imshow(pcolumn2);
    %         figure:imshow(pcolumn3);
    %     figure:imshow(pcolumn4);           
    % =========================== Position choice =================
    for j=0:3   
        rowup = 0;
        rowdown = 0;
        choice1(j+1)=markpoint(23+j*7)-markpoint(22+j*7)+5;                
        choice2(j+1)=markpoint(24+j*7)-markpoint(22+j*7)+5;
        choice3(j+1)=markpoint(25+j*7)-markpoint(22+j*7)+5;
        choice4(j+1)=markpoint(26+j*7)-markpoint(22+j*7)+5;        
        % =========================== Check �ӹǹ��� ====================
        if j==0 ptranspost = pcolumn1'; pcolumn = pcolumn1;
        elseif j==1 ptranspost = pcolumn2'; pcolumn = pcolumn2;
        elseif j==2 ptranspost = pcolumn3'; pcolumn = pcolumn3;
        elseif j==3 ptranspost = pcolumn4'; pcolumn = pcolumn4;
        end
        [check_circle_num,num3] = bwlabel(sum(~ptranspost));
        %         figure:imshow(~check_circle_num);
        if num3 ~= 28 && j <3 && count_check2 < 4 && count_check3==0
            %             disp(' check 28 ');
            autothresh1 = autothresh1+0.015;
            count_check2 =count_check2+1;
            break;        
        elseif num3~=16 && j==3 && count_check3<3
            %             disp(' check 16 ');
            autothresh1 = autothresh1+0.01;
            count_check3 =count_check3+1;
            break;       
        end
        size_pcolumn = size(ptranspost);
        
        sum_ptranspost = sum(~ptranspost);
        count2=0;
        for i=2:size_pcolumn(2)
            if sum_ptranspost(i-1)==0 & sum_ptranspost(i)>0
                count2=count2+1;
                rowup(count2)=i-1;%??????????????????????????????????????????
            end
            if sum_ptranspost(i-1)>0 & sum_ptranspost(i)==0       
                rowdown(count2)=i;
            end 
            
            if count2 > 1 & rowup(count2)-rowup(count2-1)>60
                tmp1 = rowup(count2);               
                for v=1:4
                    rowup(count2) = rowup(count2-1)+(rowup(count2-2)-rowup(count2-3));            
                    count2 = count2+1;
                    rowdown(count2-2) = rowdown(count2-3)+(rowdown(count2-3)-rowdown(count2-4));
                end
                rowup(count2)=tmp1;
                rowdown(count2-1) = rowup(count2)-3;        
            elseif count2 > 1 & rowup(count2)-rowup(count2-1)>48
                tmp1 = rowup(count2); 
                for v=1:3
                    rowup(count2) = rowup(count2-1)+(rowup(count2-2)-rowup(count2-3));
                    count2 = count2+1;
                    rowdown(count2-2) = rowdown(count2-3)+(rowdown(count2-3)-rowdown(count2-4));
                end
                rowup(count2)=tmp1;
                rowdown(count2-1) = rowup(count2)-3;
                
            elseif count2 > 1 & rowup(count2)-rowup(count2-1)>35
                tmp1 = rowup(count2);  
                if count2 < 4
                    break;
                else
                    for v=1:2
                        rowup(count2) = rowup(count2-1)+(rowup(count2-2)-rowup(count2-3));
                        count2 = count2+1;
                        rowdown(count2-2) = rowdown(count2-3)+(rowdown(count2-3)-rowdown(count2-4));
                    end
                    rowup(count2)=tmp1;
                    rowdown(count2-1) = rowup(count2)-3;        
                end    
            elseif count2 > 1 & rowup(count2)-rowup(count2-1)>20
                tmp1 = rowup(count2);
                rowup(count2) = rowdown(count2-1)+3;        
                count2=count2+1;
                rowup(count2)=tmp1;        
                rowdown(count2-1) = rowup(count2)-3;
            end
        end
       if length(rowup) == 16 || length(rowup) == 28 || count_check3==4 || count_check2==4
            if j==3 
                count2=16;
            elseif j==1
                rowup_tmp = rowup;
                count2=28;
            else  
                count2=28;
            end
            for i=2:count2+1
                prow=imcrop(pcolumn,[1 rowup(i-1) size_pcolumn(1) (rowdown(i-1)-rowup(i-1))]);
                %                                                 figure:imshow(prow);
                sum_row = sum(~prow);        
                [checkrow,num_circle]=bwlabel(sum_row );        
                cnt1=0;cnt2=0;cnt3=0;cnt4=0;
                if num_circle>0
                    for ii = 1:num_circle                     
                        zzz = find(checkrow==ii);    
                        if choice1(j+1)>zzz(1) answers(t)=1; cnt1 = 1; 
                        elseif choice2(j+1)>zzz(1) answers(t)=2; cnt2 = 1;
                        elseif choice3(j+1)>zzz(1) answers(t)=3; cnt3 = 1;
                        elseif choice4(j+1)>zzz(1) answers(t)=4; cnt4 = 1; 
                            %                         else answers(t)=0;
                        end
                    end
                else
                    answers(t)=0;
                end
                if (cnt1+cnt2+cnt3+cnt4)>1
                    answers(t)=0;
                    %                     disp('�բ�ͷ���ṹ 0 ����');                   
                end
                t=t+1;
            end          
        end         
    end 
    if count_check3 == 4
        break;
    end
    if count_check3 == 3 
        count_check3 = count_check3+1;
    end
    
    if t-1 ~= 100    
        %         disp('�ӹǹ����Թ 100 ��� �Դ��üԴ��Ҵ');
        autothresh1 = autothresh1+0.01;            
    else
        break;
    end
end

% ==========================check code ==============================
autothresh2 = .15;
rowup = rowup_tmp; 
while(true)
    %     code_start = find(arrangecode == 17);
    code_start = rowup(17)+64;
    code_zero = rowup(18)+64;
    code_one = rowup(19)+64;
    code_two = rowup(20)+64;
    code_three = rowup(21)+64;
    code_four = rowup(22)+64;
    code_five = rowup(23)+64;
    code_six = rowup(24)+64;
    code_seven = rowup(25)+64;
    code_eight = rowup(26)+64;
    code_nine = rowup(27)+64;
    code_end = rowup(28)+64;
    
    pbina = im2bw(porg,thres-autothresh2);
    %     figure:imshow(pbina);
    pbina = bwlabel(~pbina);
    pbina_filter = regionprops(pbina,'Area');
    idx = find([pbina_filter.Area] > 20 & [pbina_filter.Area] < 100);
    pbina2 = ismember(pbina,idx);
    pbina2 = ~pbina2;
%         figure:imshow(pbina2);     
    pcode = imcrop(pbina2,[markpoint(9) code_start(1) markpoint(20)-markpoint(9) code_end(1)-code_start(1)]);
    [pcode_label,num] = bwlabel(~pcode);
%             figure:imshow(~pcode_label);
    student_point = regionprops(pcode_label,'Centroid');
    code_zero=code_zero-code_start;
    code_one =code_one-code_start;
    code_two=code_two-code_start;
    code_three=code_three-code_start;
    code_four=code_four-code_start;
    code_five=code_five-code_start;
    code_six=code_six-code_start;
    code_seven=code_seven-code_start;
    code_eight=code_eight-code_start;
    code_nine=code_nine-code_start;
   
    if num == 8 
        for k = 1:num
            student_num = student_point(k).Centroid;
            round_num = round(student_num(2));
            round_num2 = round(student_num(1));
            for i = 1:8
                if round_num>code_nine student(k)=9; 
                elseif round_num>code_eight student(k)=8;
                elseif round_num>code_seven student(k)=7;
                elseif round_num>code_six student(k)=6;
                elseif round_num>code_five student(k)=5;
                elseif round_num>code_four student(k)=4;
                elseif round_num>code_three student(k)=3;
                elseif round_num>code_two student(k)=2;
                elseif round_num>code_one student(k)=1;
                elseif round_num>code_zero student(k)=0;                 
                end    
            end
        end
        disp('Finish');
        break;
    elseif num>8
        msgbox('�դ����Դ��Ҵ���ʹѡ�֡���Թ','error ���ʹѡ�֡��','none');
        break;
    else
        %         disp('�����ʹѡ�֡������� �Դ�����Դ��Ҵ');
        autothresh2 = autothresh2-.02;
    end
end
% ============================= check answer ==========================
clocks = toc;
% clocks = int2str(clocks);
msgbox(clocks,'���ҷ����');
% disp('�ʴ��ӹǹ��ͷ���������'); t=t-1
disp('�ʴ���ͷ���� 0 ');
z = find(answers == 0)
% disp('�ʴ��ӵͺ������'); answers


% checkans(answers);
%------------------------ ��Ǩ�ӵͺ --------------------------
student_point = checkans(answers);

% grade = gradecut(student_point);
%---------------------- �ʴ��Ţͧ��õ�Ǩ -----------------------
% student = [4 5 0 1 5 3 6 4];
% student_point = 45; 
students = '';
for i = 1 : 8
    students(i) = int2str(student(i));
end
p_std = students;
p_ans = student_point; 
p_txans = int2str(p_ans);
shmsg = strcat('���� :',p_std,' ��ṹ����� :',p_txans,' ��ṹ');
msgbox(shmsg,'�š�õ�Ǩ','none');

% ------------------------ ��Ǩ�ͺ����բ�������ѧ ----------------------
conn = database('store','','');
curs = exec(conn,'select * from point');
curs = fetch(curs);
datachk = curs.data;
rowschk = rows(curs);
close(conn);
have_id = '';
for i = 1:rowschk
    if p_std == char(datachk(i,1)); % ��Ǩ�ͺ����բ����ŷ��ҹ��������������
        have_id = 1;
        break;
    end
end
if have_id == 1
    msgbox('�µ�Ǩ�����...','��Ǩ�ͺ����ա�õ�Ǩ�ѧ','none');
else
    % --------------------- �����ʡѺ��ṹŧ�ҹ������ -------------------
    si = '''';
    cm = ',';
    fi = ')';
    is = 'insert into point values ('
    sqlstate = strcat(is,si,p_std,si,cm,si,p_txans,si,fi);
    conn = database('store','','');
    curs = exec(conn,sqlstate);
    curs = fetch(curs);
    close(conn);
    close;   
    msgbox('�ѹ�֡�����ŧ�ҹ���������º����','�Ѵ�红�����','none');
end