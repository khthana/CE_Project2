/**
 * MapServicesService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesmap;

public interface MapServicesService extends javax.xml.rpc.Service {
    public java.lang.String getMapServicesAddress();

    public servicesmap.MapServices getMapServices() throws javax.xml.rpc.ServiceException;

    public servicesmap.MapServices getMapServices(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
