/**
 * MapServicesSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesmap;
import java.awt.*;
import java.awt.Color;
import java.awt.image.*;
import com.sun.image.codec.jpeg.*;

import java.nio.*;
import java.nio.channels.*;
import java.nio.charset.*;

import java.io.*;
import java.sql.*;

public class MapServicesSoapBindingImpl implements servicesmap.MapServices{

	//----------------------GetMap--------------------------------------//
    public java.lang.String getMap(java.lang.String user, java.lang.String password, java.lang.String lat_tl, java.lang.String lon_tl, java.lang.String lat_rb, java.lang.String lon_rb, java.lang.String outtype) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();

		File Map = new File("C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.svg");
		String Mapsvg = "";
		Double di = new Double( lat_tl );
		double lat11 = di.doubleValue();
		di = new Double( lon_tl );
		double lon11 = di.doubleValue();
		di = new Double( lat_rb );
		double lat22 = di.doubleValue();
		di = new Double( lon_rb );
		double lon22 = di.doubleValue();
        if (outtype.equalsIgnoreCase("GML")) {
			m.exportToGML(user,password,lat11,lon11,lat22,lon22);
			return "http://161.246.5.68/axis/map.xml";
        } else if (outtype.equalsIgnoreCase("SVG")) {	
			m.exportToSVG(user,password,lat11,lon11,lat22,lon22);
		} else {
			m.exportToJPG(lat11,lon11,lat22,lon22,600,600);
			return "http://161.246.5.68/axis/map.jpg";
		}

		//m.closeConnect();
		try {
			BufferedReader bin = new BufferedReader(new FileReader(Map));
			String str;
			while ((str = bin.readLine()) != null) {
				Mapsvg = Mapsvg + str + "\n";
			}
			bin.close();
			return Mapsvg;
		} catch (IOException e) {
			return "";
		}
    }

	//----------------------GetPlaceMap--------------------------------------//
    public java.lang.String getPlaceMap(java.lang.String user, java.lang.String password, java.lang.String bid, java.lang.String bname) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		String bname_en = bname;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.placePersonMap(user_en,password_en,bid,bname_en);
		if (result.equalsIgnoreCase("authen_failed") || result.equalsIgnoreCase("no_place")) {
			return result;
		}
		File Map = new File("C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.svg");
		String Mapsvg = "";
		try {
			BufferedReader bin = new BufferedReader(new FileReader(Map));
			String str;
			while ((str = bin.readLine()) != null) {
				Mapsvg = Mapsvg + str + "\n";
			}
			bin.close();
			return Mapsvg;
		} catch (IOException e) {
			return "error";
		}
    }

	//------------------------GetPlaceDetail-----------------------------------//
    public java.lang.String[] getPlaceDetail(java.lang.String user, java.lang.String password, java.lang.String bid, java.lang.String bname, java.lang.String btype) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result[];
		String user_en = user;
		String password_en = password;
		String bname_en = bname;
		String btype_en = btype;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
			btype_en = new String(btype.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.PlaceDetail(user_en,password_en,bid,bname_en,btype_en);
		return result;
    }

	//----------------------SetPlaceDetail-----------------------------------//
    public java.lang.String setPlaceDetail(java.lang.String user, java.lang.String password, java.lang.String bname, java.lang.String btype, java.lang.String tel, java.lang.String website, java.lang.String opentime, java.lang.String lat, java.lang.String lon, java.lang.String detail) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		String bname_en = bname;
		String btype_en = btype;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
			btype_en = new String(btype.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.setPlaceDetail(user_en,password_en,bname_en,btype_en,tel,website,opentime,lat,lon,detail);
		return result;
    }

	//----------------------EditPlaceDetail-----------------------------------//
    public java.lang.String editPlaceDetail(java.lang.String user, java.lang.String password, java.lang.String bid, java.lang.String bname, java.lang.String btype, java.lang.String tel, java.lang.String website, java.lang.String opentime, java.lang.String lat, java.lang.String lon, java.lang.String detail) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		String bname_en = bname;
		String btype_en = btype;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
			btype_en = new String(btype.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.editPlaceDetail(user_en,password_en,bid,bname_en,btype_en,tel,website,opentime,lat,lon,detail);
		return result;
    }

	//----------------------SearchPlace-----------------------------------//
    public java.lang.String searchPlace(java.lang.String user, java.lang.String password, java.lang.String bname, java.lang.String btype) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		String bname_en = bname;
		String btype_en = btype;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
			btype_en = new String(btype.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.searchPlaceList(user_en,password_en,bname_en,btype_en);
		return result;
    }

	//----------------------GetPassword----------------------------------//
    public java.lang.String getPassword(java.lang.String user) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result;
		String user_en = user;
		try {
			user_en = new String(user.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.getPassword(user_en);
		return result;
    }

	//----------------------SetUser--------------------------------------//
	public java.lang.String setUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException {
		Service m = new Service();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.setUser(user_en,password_en);
		return result;
    }

	//----------------------EditUser-------------------------------------//
    public java.lang.String editUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException {
        return null;
    }

	//----------------------GetMapInfo----------------------------------//
    public java.lang.String getMapInfo() throws java.rmi.RemoteException {
		File MapInfofile = new File("C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/GetMapinfo.txt");
		String mapstr = "";
		try {
			BufferedReader bin = new BufferedReader(new FileReader(MapInfofile));
			String str;
			while ((str = bin.readLine()) != null) {
				mapstr = mapstr + str;
			}
			bin.close();
			return mapstr;
		} catch (IOException e) {
			return "";
		}
    }

	//----------------------GetPlaceDetialInfo----------------------------------//
    public java.lang.String getPlaceDetailInfo() throws java.rmi.RemoteException {
		File DetailInfofile = new File("C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/GetDetailinfo.txt");
		String Detailstr = "";
		try {
			BufferedReader bin = new BufferedReader(new FileReader(DetailInfofile));
			String str;
			while ((str = bin.readLine()) != null) {
				Detailstr = Detailstr + str;
			}
			bin.close();
			return Detailstr;
		} catch (IOException e) {
			return "";
		}
    }

}

class Service {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DATABASE_URL = "jdbc:mysql://localhost/spatial1";
	static final String USER = "root";
	static final String PASSWORD = "iamadmin";
	
	static final String GMLfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.xml";
	static final String SVGfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.svg";
	static final String JPGfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.jpg";
	static final String TOURfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/tour.txt";
	static final String PLACEfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/place.txt";

	private Connection conn;
	private Statement stmt;
	private	ResultSet rs;
	private int rsu;

	public void exportToGML(String user, String password, double lon_tl, double lat_tl, double lon_rb, double lat_rb) {
		try {
			FileOutputStream fos = new FileOutputStream(GMLfile);
			PrintStream ps = new PrintStream(fos);
			
			// print header
			ps.println("<?xml version='1.0' encoding='windows-874' standalone='no'?>");
			ps.println("<!--File:map.xml -->");
			ps.println("<CityModel xmlns:gml='http://www.opengis.net/gml'");
			ps.println("\t\txmlns:xlink='http://www.w3.org/1999/xlink'");
			ps.println("\t\txmlns:xsi='http://www.w3.org/2000/10/XMLschema-instance'");
			ps.println("\t\txsi:noNamespaceSchemaLocation='http://161.246.5.51/schema/bangkok.xsd'>");
			ps.println();
			
			String id, name, lat, lon;
			
			// bank
			rs = stmt.executeQuery(
				"SELECT Place_ID, Bank_Name, Lat, Lon FROM bank WHERE " +
				"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
				"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
			while(rs.next()) {
				id = "B" + rs.getObject(1).toString();
				name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
				lat = rs.getObject(3).toString();
				lon = rs.getObject(4).toString();
				
				ps.println("\t<cityMember>");
				ps.println("\t\t<Bank fid='" + id +"' Classified='1'>");
				ps.println("\t\t\t<gml:name>" + name +"</gml:name>");
				ps.println("\t\t\t<Location><gml:Point srsName='http://www.opengis.net/gml/srs/epsg.xml#4362'><gml:coordinates>" + lat + "," + lon + "</gml:coordinates></gml:Point></Location>");
				ps.println("\t\t</Bank>");
				ps.println("\t<cityMember>");
			}
			ps.println();
			
			// hospital
			rs = stmt.executeQuery(
				"SELECT Place_ID, Hospital_Name, Lat, Lon FROM hospital WHERE " +
				"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
				"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
			while(rs.next()) {
				id = "H" + rs.getObject(1).toString();
				name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
				lat = rs.getObject(3).toString();
				lon = rs.getObject(4).toString();
				
				ps.println("\t<cityMember>");
				ps.println("\t\t<Hospital fid='" + id +"' Classified='1'>");
				ps.println("\t\t\t<gml:name>" + name +"</gml:name>");
				ps.println("\t\t\t<Location><gml:Point srsName='http://www.opengis.net/gml/srs/epsg.xml#4362'><gml:coordinates>" + lat + "," + lon + "</gml:coordinates></gml:Point></Location>");
				ps.println("\t\t</Hospital>");
				ps.println("\t<cityMember>");
			}
			ps.println();
			
			// mall
			rs = stmt.executeQuery(
				"SELECT Place_ID, Mall_Name, Lat, Lon FROM mall WHERE " +
				"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
				"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
			while(rs.next()) {
				id = "M" + rs.getObject(1).toString();
				name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
				lat = rs.getObject(3).toString();
				lon = rs.getObject(4).toString();
				
				ps.println("\t<cityMember>");
				ps.println("\t\t<Mall fid='" + id +"'>");
				ps.println("\t\t\t<gml:name>" + name +"</gml:name>");
				ps.println("\t\t\t<Location><gml:Point srsName='http://www.opengis.net/gml/srs/epsg.xml#4362'><gml:coordinates>" + lat + "," + lon + "</gml:coordinates></gml:Point></Location>");
				ps.println("\t\t</Mall>");
				ps.println("\t<cityMember>");
			}
			ps.println();
			
			// policestation
			rs = stmt.executeQuery(
				"SELECT Place_ID, Police_Name, Lat, Lon FROM police WHERE " +
				"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
				"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
			while(rs.next()) {
				id = "P" + rs.getObject(1).toString();
				name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
				lat = rs.getObject(3).toString();
				lon = rs.getObject(4).toString();
				
				ps.println("\t<cityMember>");
				ps.println("\t\t<PoliceStation fid='" + id +"' Classified='1'>");
				ps.println("\t\t\t<gml:name>" + name +"</gml:name>");
				ps.println("\t\t\t<Location><gml:Point srsName='http://www.opengis.net/gml/srs/epsg.xml#4362'><gml:coordinates>" + lat + "," + lon + "</gml:coordinates></gml:Point></Location>");
				ps.println("\t\t</PoliceStation>");
				ps.println("\t<cityMember>");
			}
			ps.println();
			
			// restaurant
			rs = stmt.executeQuery(
				"SELECT Place_ID, Restaurant_Name, Lat, Lon FROM restaurant WHERE " +
				"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
				"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
			while(rs.next()) {
				id = "R" + rs.getObject(1).toString();
				name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
				lat = rs.getObject(3).toString();
				lon = rs.getObject(4).toString();
				
				ps.println("\t<cityMember>");
				ps.println("\t\t<Restaurant fid='" + id +"'>");
				ps.println("\t\t\t<gml:name>" + name +"</gml:name>");
				ps.println("\t\t\t<Location><gml:Point srsName='http://www.opengis.net/gml/srs/epsg.xml#4362'><gml:coordinates>" + lat + "," + lon + "</gml:coordinates></gml:Point></Location>");
				ps.println("\t\t</Restaurant>");
				ps.println("\t<cityMember>");
			}
			ps.println();
			
			// tourpoint
			rs = stmt.executeQuery(
				"SELECT Place_ID, Tour_Name, Lat, Lon FROM tourpoint WHERE " +
				"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
				"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
			while(rs.next()) {
				id = "T" + rs.getObject(1).toString();
				name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
				lat = rs.getObject(3).toString();
				lon = rs.getObject(4).toString();
				
				ps.println("\t<cityMember>");
				ps.println("\t\t<TourPoint fid='" + id +"'>");
				ps.println("\t\t\t<gml:name>" + name +"</gml:name>");
				ps.println("\t\t\t<Location><gml:Point srsName='http://www.opengis.net/gml/srs/epsg.xml#4362'><gml:coordinates>" + lat + "," + lon + "</gml:coordinates></gml:Point></Location>");
				ps.println("\t\t</TourPoint>");
				ps.println("\t<cityMember>");
			}
			ps.println();
			ps.println("</CityModel>");
			
			ps.close();
			fos.close();
		}
		catch(Exception e) {}
	}
	
	public void exportToSVG(String user, String password, double lon_tl, double lat_tl, double lon_rb, double lat_rb) {
		String BBox = 
			"Polygon((" +
			Double.toString(lon_tl) + " " + Double.toString(lat_tl) +
			", " + Double.toString(lon_rb) + " " + Double.toString(lat_tl) +
			", " + Double.toString(lon_rb) + " " + Double.toString(lat_rb) +
			", " + Double.toString(lon_tl) + " " + Double.toString(lat_rb) +
			", " + Double.toString(lon_tl) + " " + Double.toString(lat_tl) +
			"))";
		String width = Double.toString(lon_rb - lon_tl);
		String height = Double.toString(lat_rb - lat_tl);
		String layer[] = new String[20];
		
		try {
			FileOutputStream fos = new FileOutputStream(SVGfile);
			PrintStream ps = new PrintStream(fos, false, "UTF-8");
			
			// print header
			ps.println("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
			ps.println("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20000303 Stylable//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">");
			ps.println();
			ps.println(
				"<svg width=\"100%\" height=\"100%\" " +
				"viewBox=\"" + lon_tl + " " + lat_tl + " " + width + " " + height + "\">");
			ps.println();
			
			//**************** print graphical layer *****************
			try {
				int i=0;
				
				rs = stmt.executeQuery(
					"SELECT DISTINCT(layer) FROM geom ORDER BY 1");
				while(rs.next()) {
					layer[i] = rs.getObject(1).toString();
					i++;
				}
			}
			catch(SQLException e) {}
			
			// print layer 30,31,32,34
			for (int i=0;i<layer.length;i++) {
				if (layer[i] != null) {
					if (layer[i].equalsIgnoreCase("30") |
						layer[i].equalsIgnoreCase("31") |
						layer[i].equalsIgnoreCase("32") |
						layer[i].equalsIgnoreCase("34")) {
							
						if (layer[i].equalsIgnoreCase("30") | layer[i].equalsIgnoreCase("34"))
							ps.println("\t\t\t\t\t<g id=\"Layer1\" style=\"fill:none;stroke:red;stroke-width:0.0003\">");
						if (layer[i].equalsIgnoreCase("31"))
							ps.println("\t\t\t\t\t<g id=\"Layer2\" style=\"fill:none;stroke:green;stroke-width:0.0002\">");
						if (layer[i].equalsIgnoreCase("32"))
							ps.println("\t\t\t\t\t<g id=\"Layer3\" style=\"fill:none;stroke:blue;stroke-width:0.0001\">");
						
						try {
							rs = stmt.executeQuery(
								"SELECT ASTEXT(g) FROM geom WHERE layer=" + layer[i] + " " +
								"AND MBRContains(GeomFromText('" + BBox + "'), g)");
							while(rs.next()) {
								String s = rs.getObject(1).toString();
								ps.println("\t\t" + WKTtoSVG(s, layer[i]));
							}
						}
						catch(SQLException e) {}
						
						ps.println("\t\t\t\t\t</g>");
						ps.println();
					}
				}
			}
			//*********************************************************
			
			//****************** print all place's text ***************
			try {
				String id,name,lat,lon,temp;
				
				// Bank
				ps.println("\t\t\t\t\t<g id=\"Bank\">");
				ps.println("\t\t\t\t\t\t<g id=\"BankPoint\" style=\"fill:darkorchid\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Lat, Lon FROM bank WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
				while(rs.next()) {
					id = "B" + rs.getObject(1).toString();
					lat = rs.getObject(2).toString();
					lon = rs.getObject(3).toString();
					
					ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				
				ps.println("\t\t\t\t\t\t<g id=\"BankT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Bank_Name, Lat, Lon FROM bank WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
				while(rs.next()) {
					id = "B" + rs.getObject(1).toString();
					name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
					//name = new String(temp.getBytes("UTF-8"));
					lat = rs.getObject(3).toString();
					lon = rs.getObject(4).toString();
					
					ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				ps.println("\t\t\t\t\t</g>");
				
				// Hospital
				ps.println("\t\t\t\t\t<g id=\"Hospital\">");
				ps.println("\t\t\t\t\t\t<g id=\"HospitalPoint\" style=\"fill:darkorchid\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Lat, Lon FROM hospital WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
				while(rs.next()) {
					id = "H" + rs.getObject(1).toString();
					lat = rs.getObject(2).toString();
					lon = rs.getObject(3).toString();
					
					ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				
				ps.println("\t\t\t\t\t\t<g id=\"HospitalT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Hospital_Name, Lat, Lon FROM hospital WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
				while(rs.next()) {
					id = "H" + rs.getObject(1).toString();
					name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
					lat = rs.getObject(3).toString();
					lon = rs.getObject(4).toString();
					
					ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				ps.println("\t\t\t\t\t</g>");
				
				// Mall
				ps.println("\t\t\t\t\t<g id=\"Mall\">");
				ps.println("\t\t\t\t\t\t<g id=\"MallPoint\" style=\"fill:darkorchid\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Lat, Lon FROM mall WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
				while(rs.next()) {
					id = "M" + rs.getObject(1).toString();
					lat = rs.getObject(2).toString();
					lon = rs.getObject(3).toString();
					
					ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				
				ps.println("\t\t\t\t\t\t<g id=\"MallT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Mall_Name, Lat, Lon FROM mall WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
				while(rs.next()) {
					id = "M" + rs.getObject(1).toString();
					name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
					lat = rs.getObject(3).toString();
					lon = rs.getObject(4).toString();
					
					ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				ps.println("\t\t\t\t\t</g>");
				
				// Policestation
				ps.println("\t\t\t\t\t<g id=\"Police\">");
				ps.println("\t\t\t\t\t\t<g id=\"PolicePoint\" style=\"fill:darkorchid\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Lat, Lon FROM police WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
				while(rs.next()) {
					id = "P" + rs.getObject(1).toString();
					lat = rs.getObject(2).toString();
					lon = rs.getObject(3).toString();
					
					ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				
				ps.println("\t\t\t\t\t\t<g id=\"PoliceT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Police_Name, Lat, Lon FROM police WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
				while(rs.next()) {
					id = "P" + rs.getObject(1).toString();
					name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
					lat = rs.getObject(3).toString();
					lon = rs.getObject(4).toString();
					
					ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				ps.println("\t\t\t\t\t</g>");
				
				// Restaurant
				ps.println("\t\t\t\t\t<g id=\"Restaurant\">");
				ps.println("\t\t\t\t\t\t<g id=\"RestaurantPoint\" style=\"fill:darkorchid\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Lat, Lon FROM restaurant WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
				while(rs.next()) {
					id = "R" + rs.getObject(1).toString();
					lat = rs.getObject(2).toString();
					lon = rs.getObject(3).toString();
					
					ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				
				ps.println("\t\t\t\t\t\t<g id=\"RestaurantT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Restaurant_Name, Lat, Lon FROM restaurant WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
				while(rs.next()) {
					id = "R" + rs.getObject(1).toString();
					name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
					lat = rs.getObject(3).toString();
					lon = rs.getObject(4).toString();
					
					ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				ps.println("\t\t\t\t\t</g>");
				
				// Tourpoint
				ps.println("\t\t\t\t\t<g id=\"Tour\">");
				ps.println("\t\t\t\t\t\t<g id=\"TourPoint\" style=\"fill:darkorchid\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Lat, Lon FROM tourpoint WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
				while(rs.next()) {
					id = "T" + rs.getObject(1).toString();
					lat = rs.getObject(2).toString();
					lon = rs.getObject(3).toString();
					
					ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				
				ps.println("\t\t\t\t\t\t<g id=\"TourT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
				
				rs = stmt.executeQuery(
					"SELECT Place_ID, Tour_Name, Lat, Lon FROM tourpoint WHERE " +
					"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
					"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
				while(rs.next()) {
					id = "T" + rs.getObject(1).toString();
					name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
					lat = rs.getObject(3).toString();
					lon = rs.getObject(4).toString();
					
					ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
				}
				ps.println("\t\t\t\t\t\t</g>");
				ps.println("\t\t\t\t\t</g>");
				
				// private user's place :: must check for user and password
				rs = stmt.executeQuery(
					"SELECT COUNT(*) FROM user WHERE User_Name = '" + user + "' AND User_Password = '" + password + "'");
					
					if (rs.getObject(1).toString().equalsIgnoreCase("1")) {
						ps.println("\t\t\t\t\t<g id=\"User\">");
						ps.println("\t\t\t\t\t\t<g id=\"UserPoint\" style=\"fill:darkorchid\">");
						
						rs = stmt.executeQuery(
							"SELECT Place_ID, Lat, Lon FROM add_place WHERE " +
							"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
							"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
						while(rs.next()) {
							id = "U" + rs.getObject(1).toString();
							lat = rs.getObject(2).toString();
							lon = rs.getObject(3).toString();
							
							ps.println("\t\t\t\t\t\t\t<circle id=\"" + id + "\" cx=\"" + lon + "\" cy=\"" + lat + "\" r=\"0.0001\"/>");
						}
						ps.println("\t\t\t\t\t\t</g>");
						
						ps.println("\t\t\t\t\t\t<g id=\"UserT\" style=\"font-family:Microsoft Sans Serif;font-size:0.0003\">");
						
						rs = stmt.executeQuery(
							"SELECT Place_ID, Tour_Name, Lat, Lon FROM add_place WHERE " +
							"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
							"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);	
						while(rs.next()) {
							id = "U" + rs.getObject(1).toString();
							name = new String(rs.getObject(2).toString().getBytes("ISO-8859-1"), "TIS-620");
							lat = rs.getObject(3).toString();
							lon = rs.getObject(4).toString();
							
							ps.println("\t\t\t\t\t\t\t<text id=\"" + id + "\" x=\"" + lon + "\" y=\"" + lat + "\" dx=\"0.0002\" dy=\"0.0002\">" + name + "</text>");
						}
						ps.println("\t\t\t\t\t\t</g>");
						ps.println("\t\t\t\t\t</g>");
					}
			}
			catch(Exception e) {}
			//*********************************************************
			
			ps.println("</svg>");
			ps.close();
			fos.close();
		}
		catch(Exception e) {}
	}

	public void exportToJPG(double lon_tl, double lat_tl, double lon_rb, double lat_rb, int width, int height) {
		String BBox = 
			"Polygon((" +
			Double.toString(lon_tl) + " " + Double.toString(lat_tl) +
			", " + Double.toString(lon_rb) + " " + Double.toString(lat_tl) +
			", " + Double.toString(lon_rb) + " " + Double.toString(lat_rb) +
			", " + Double.toString(lon_tl) + " " + Double.toString(lat_rb) +
			", " + Double.toString(lon_tl) + " " + Double.toString(lat_tl) +
			"))";
		String layer[] = new String[20];
		boolean print_text = true;
		
		BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		
		try {
			FileOutputStream f = new FileOutputStream(JPGfile);
			Graphics g = bi.createGraphics();
			//set background's color = white
			g.setColor(Color.white);
			g.fillRect(0, 0, width, height);
			
			try {
				int i=0;
				
				rs = stmt.executeQuery(
					"SELECT DISTINCT(layer) FROM geom ORDER BY 1");
				while(rs.next()) {
					layer[i] = rs.getObject(1).toString();
					i++;
				}
			}
			catch(SQLException e) {}
			
			// draw layer 30,31,32,34
			for (int i=0;i<layer.length;i++) {
				if (layer[i] != null) {
					if (layer[i].equalsIgnoreCase("30") |
						layer[i].equalsIgnoreCase("31") |
						layer[i].equalsIgnoreCase("32") |
						layer[i].equalsIgnoreCase("34")) {
						
						if (layer[i].equalsIgnoreCase("30") | 
							layer[i].equalsIgnoreCase("34")) g.setColor(Color.red);
						if (layer[i].equalsIgnoreCase("31")) g.setColor(Color.green);
						if (layer[i].equalsIgnoreCase("32")) g.setColor(Color.blue);
						
						try {
							// print geographic information
							rs = stmt.executeQuery(
								"SELECT ASTEXT(g) FROM geom WHERE layer=" + layer[i] + " " +
								"AND MBRContains(GeomFromText('" + BBox + "'), g)");
							while(rs.next()) {
								String s = rs.getObject(1).toString();
								int x[] = getX(s,lon_tl,lon_rb,width);
								int y[] = getY(s,lat_tl,lat_rb,height);
								int n = getN(x);
								
								g.drawPolyline(x, y, n);
							}
							
							double llon = lon_rb - lon_tl;
							double llat = lat_rb - lat_tl;
							System.out.println(llon + " " + llat);
							
							// check width & height size
							if (llon >= llat & llat > 0.05) print_text = false;
							else if (llat > llon & llon > 0.05) print_text = false;
							
							if (print_text) {
							// -------------- print text ----------------------
								String name, lat, lon;
								int x[] = new int[1];
								int y[] = new int[1];
								double temp = 0.4/(lon_rb - lon_tl);
								int fsize = (int)temp;
								
								Font font = new Font("Micro Sans Serif", Font.PLAIN, fsize);
								g.setFont(font);
								g.setColor(Color.black);
								
								// print Bank
								rs = stmt.executeQuery(
									"SELECT Bank_Name, Lat, Lon FROM bank WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
								
								// print Hospital
								rs = stmt.executeQuery(
									"SELECT Hospital_Name, Lat, Lon FROM hospital WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
								
								// print Mall
								rs = stmt.executeQuery(
									"SELECT Mall_Name, Lat, Lon FROM mall WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
								
								// print Police station
								rs = stmt.executeQuery(
									"SELECT Police_Name, Lat, Lon FROM police WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
								
								// print Restaurant
								rs = stmt.executeQuery(
									"SELECT Restaurant_Name, Lat, Lon FROM restaurant WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
								
								// print Tourpoint
								rs = stmt.executeQuery(
									"SELECT Tour_Name, Lat, Lon FROM tour WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
								
								// print Add_place
								rs = stmt.executeQuery(
									"SELECT Place_Name, Lat, Lon FROM add_place WHERE " +
									"Lon > " + lon_tl + " AND " + "Lon < " + lon_rb + " AND " +
									"Lat > " + lat_tl + " AND " + "Lat < " + lat_rb);
								while (rs.next()) {
									name = "[] " + new String(rs.getObject(1).toString().getBytes("ISO-8859-1"), "TIS-620");
									lat = "LAT" + rs.getObject(2).toString();
									lon = "LON" + rs.getObject(3).toString();
									x = getX(lon,lon_tl,lon_rb,width);
									y = getY(lat,lat_tl,lat_rb,height);
									
									g.drawString(name, x[0], y[0]);
								}
	
							}							
						}
						catch(SQLException e) {}
					}
				}
			}
			
			g.dispose();
			JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(f);
			JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bi);
			param.setQuality((float)1.0, true);
			encoder.encode(bi, param);
			f.close();
		}
		catch(IOException e) {}
	}

	public String WKTtoSVG(String s, String layer) {
		int begin = 0;
		int end = 0;
		String output = "";
		
		if (s.startsWith("LINESTRING")) {
			begin = s.indexOf("(") + 1;
			end = s.indexOf(")") - 1;
			
			if (layer.equalsIgnoreCase("30") | layer.equalsIgnoreCase("34")) {
				output = "<polyline points=\"" + s.substring(begin, end) + "\" " +
					"style=\"fill:white;stroke:red;stroke-width:0.0003\"/>";
			}
			else if (layer.equalsIgnoreCase("31")) {
				output = "<polyline points=\"" + s.substring(begin, end) + "\" " +
					"style=\"fill:white;stroke:green;stroke-width:0.0002\"/>";
			}
			else if (layer.equalsIgnoreCase("32")) {
				output = "<polyline points=\"" + s.substring(begin, end) + "\" " +
					"style=\"fill:white;stroke:blue;stroke-width:0.0001\"/>";
			}
		}
		if (s.startsWith("MULTILINESTRING")) {
			int last = s.lastIndexOf(")") - 1;
			
			do {			
				if (s.charAt(s.indexOf("(") + 1) == '(') { begin = s.indexOf("(", end) + 2; }
				else { begin = s.indexOf("(", end) + 1; }
				end = s.indexOf(")", end+1);
				
				output += "<polyline points=\"" + s.substring(begin, end) + "\"/>\n";
			}while(end < last);
		}
		
		return output;
	}

	public int[] getX(String s, double lon_tl, double lon_rb, double width) {
		int begin = 0;
		int end = 0;
		int x[] = new int[150];
		
		if (s.startsWith("LINESTRING")) {
			int i = 0;
			
			for (int j=0;j<s.length();j++) {
				if (s.charAt(j) == '(' | s.charAt(j) == ',') { 
					begin = j+1;
				}
				if (s.charAt(j) == ' ') {
					end = j;
							
					double temp = (Double.valueOf(s.substring(begin,end)).doubleValue()-lon_tl)/(lon_rb-lon_tl)*width;
					x[i] = (int)temp;
					i++;
				}
			}
			
			return x;
		}
		else return null;
	}
	
	public int[] getY(String s, double lat_tl, double lat_rb, double width) {
		int begin = 0;
		int end = 0;
		int y[] = new int[150];
		
		if (s.startsWith("LINESTRING")) {
			int i = 0;
			
			for (int j=0;j<s.length();j++) {
				if (s.charAt(j) == ' ') { 
					begin = j+1;
				}
				if (s.charAt(j) == ',' | s.charAt(j) == ')') {
					end = j;
							
					double temp = (Double.valueOf(s.substring(begin,end)).doubleValue()-lat_tl)/(lat_rb-lat_tl)*width;
					y[i] = (int)temp;
					i++;
				}
			}
			
			return y;
		}
		else return null;
	}
	
	public int getN(int num[]) {
		int count = 0;
		for (int i=0;i<num.length;i++) if (num[i] != 0) count++;
		return count;
	}

	public void openConnect() {
		try {
			Class.forName(JDBC_DRIVER).newInstance();
			conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
			stmt = conn.createStatement();
		}
		catch(Exception e) {}
		finally {
			if (conn == null | stmt == null) {
				System.out.println("The problem has occured when trying to connect to database.");
			}
		}
	}
	
	public void closeConnect() {
		try {
			stmt.close();
			conn.close();
		}
		catch(Exception e) {}
		finally {
			if (conn != null | stmt != null) {
				System.out.println("The problem has occured when trying to close connection.");
			}
		}
	}

	public String searchPlaceList (String user,String password, String bname, String btype) {
		String result = "";
		try {
			FileOutputStream f = new FileOutputStream(TOURfile);
			PrintStream ps = new PrintStream(f);
			ResultSet rs;
			try {
				rs = stmt.executeQuery(
					"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
				if (rs.next()) {
					String dbpassword = rs.getObject(1).toString();
					
					if (dbpassword.equalsIgnoreCase(password)) {	

						String placetype[] = {"","","","","","","",""};
						if (btype.equalsIgnoreCase("Bank")) {
							placetype[0] = "Bank";
						} else if (btype.equalsIgnoreCase("Hospital")) {
							placetype[0] = "Hospital";
						} else if (btype.equalsIgnoreCase("Mall")) {
							placetype[0] = "Mall";
						} else if (btype.equalsIgnoreCase("Police")) {
							placetype[0] = "Police";
						} else if (btype.equalsIgnoreCase("Restuarant")) {
							placetype[0] = "Restuarant";
						} else if (btype.equalsIgnoreCase("Tourpoint")) {
							placetype[0] = "Tourpoint";
						} else {
							placetype[0] = "Bank";
							placetype[1] = "Hospital";
							placetype[2] = "Mall";
							placetype[3] = "Police";
							placetype[4] = "Restaurant";
							placetype[5] = "Tourpoint";
						}
						int a=0;
						String temp[] = {"","","","","","","","",""};
						while (placetype[a].length() > 0) {
							try {
								if (!placetype[a].equalsIgnoreCase("Tourpoint")) {
									rs = stmt.executeQuery(
										"SELECT * FROM "+placetype[a]+" WHERE "+placetype[a]+"_name LIKE '%"+bname+"%' ORDER BY 1");
								} else {
									rs = stmt.executeQuery(
										"SELECT * FROM tourpoint WHERE tour_name LIKE '%"+bname+"%' ORDER BY 1");
								}
								while(rs.next()) {
									temp[0] = rs.getObject(1).toString();
									temp[1] = rs.getObject(2).toString();
									if (btype.equalsIgnoreCase("Mall")) {
										temp[3] = rs.getObject(4)+"";
										temp[4] = rs.getObject(5)+"";
										temp[5] = rs.getObject(3)+"";
										temp[6] = rs.getObject(7)+"";
										temp[7] = rs.getObject(8)+"";
									} else if (btype.equalsIgnoreCase("Restaurant")) {
										temp[2] = rs.getObject(3)+"";
										temp[3] = rs.getObject(5)+"";
										temp[4] = rs.getObject(6)+"";
										temp[5] = rs.getObject(4)+"";
										temp[6] = rs.getObject(9)+"";
										temp[7] = rs.getObject(10)+"";
									} else if (btype.equalsIgnoreCase("Police")) {
										temp[2] = rs.getObject(3)+"";
										temp[3] = rs.getObject(4)+"";
										temp[6] = rs.getObject(5)+"";
										temp[7] = rs.getObject(6)+"";
									} else if (btype.equalsIgnoreCase("Tourpoint")) {
										temp[2] = rs.getObject(3)+"";
										temp[3] = rs.getObject(4)+"";
										temp[4] = rs.getObject(5)+"";
										temp[5] = rs.getObject(6)+"";
										temp[6] = rs.getObject(9)+"";
										temp[7] = rs.getObject(10)+"";
									} else {
										temp[2] = rs.getObject(3)+"";
										temp[3] = rs.getObject(4)+"";
										temp[4] = rs.getObject(5)+"";
										temp[5] = rs.getObject(6)+"";
										temp[6] = rs.getObject(7)+"";
										temp[7] = rs.getObject(8)+"";
									}
									result = result + temp[0] + " " + placetype[a] + " " + temp[1] + " " +
										" | <a href=\"showmap.jsp?lat="+temp[6]+"&lon="+temp[7]+"&outtype=GML\">GML</a> |" +
										" | <a href=\"showmap.jsp?lat="+temp[6]+"&lon="+temp[7]+"&outtype=SVG\">SVG</a> |" +								
										" | <a href=\"showmap.jsp?lat="+temp[6]+"&lon="+temp[7]+"&outtype=JPEG\">JPEG</a> | EDIT | <br>\n";
								}
								System.out.println("old pass");
									rs = stmt.executeQuery(
										"SELECT place_id,place_name,lat,lon FROM add_place WHERE place_name LIKE '%"+bname+"%' and place_type = '"+placetype[a]+"' and user_name = '"+user+"' ORDER BY 1");
								while(rs.next()) {
									result = result + rs.getObject(1).toString() + " " + placetype[a] + " " + rs.getObject(2).toString() + 
										" | <a href=\"showmap.jsp?lat="+rs.getObject(3)+"&lon="+rs.getObject(4)+"&outtype=GML\">GML</a> |" +
										" | <a href=\"showmap.jsp?lat="+rs.getObject(3)+"&lon="+rs.getObject(4)+"&outtype=GML\">SVG</a> |" +
										" | <a href=\"showmap.jsp?lat="+rs.getObject(3)+"&lon="+rs.getObject(4)+"&outtype=GML\">JPEG</a> |" +
										" | <a href=\"edit-place.jsp?pid="+rs.getObject(1).toString() +"&pname="+rs.getObject(2)+"&type="+placetype[a]+"\">EDIT</a> | <br>\n";
								}

								if (result.equalsIgnoreCase("")) {
									return "no_place";
								}
							}
							catch (SQLException e){System.out.println("SQL error");}
							a++;
						}
						ps.println(result);
					}else {return "authen_failed";}
				} else {return "authen_failed";}
			}
			catch (SQLException e){System.out.println("SQL error");}
		}
		catch (IOException e){System.out.println("IO error");}
		return result;
	}

	public String[] PlaceDetail (String user,String password, String bid,String bname, String btype) {
		String result[] = {"","","","","","","","",""};
		try {
			FileOutputStream f = new FileOutputStream(TOURfile);
			PrintStream ps = new PrintStream(f);
			ResultSet rs;
			try {
				rs = stmt.executeQuery(
					"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
				if (rs.next()) {
					String dbpassword = rs.getObject(1).toString();
					
					if (dbpassword.equalsIgnoreCase(password)) {	

						try {
							if (btype.equalsIgnoreCase("Bank")||btype.equalsIgnoreCase("Hospital")||btype.equalsIgnoreCase("Mall")||btype.equalsIgnoreCase("Police")||btype.equalsIgnoreCase("Restaurant")||btype.equalsIgnoreCase("Tourpoint")) {
								if (!btype.equalsIgnoreCase("Tourpoint")) {
									rs = stmt.executeQuery(
									"SELECT * FROM "+btype+" WHERE place_id = "+bid+" or "+btype+"_name = '"+bname+"' ORDER BY 1");
								} else {
									rs = stmt.executeQuery(
									"SELECT * FROM tourpoint WHERE place_id = "+bid+" or tour_name = '"+bname+"' ORDER BY 1");
								}
								while(rs.next()) {
									result[0] = rs.getObject(1).toString();
									result[1] = rs.getObject(2).toString();
									if (btype.equalsIgnoreCase("Mall")) {
										result[3] = rs.getObject(4)+"";
										result[4] = rs.getObject(5)+"";
										result[5] = rs.getObject(3)+"";
										result[6] = rs.getObject(7)+"";
										result[7] = rs.getObject(8)+"";
									} else if (btype.equalsIgnoreCase("Restaurant")) {
										result[2] = rs.getObject(3)+"";
										result[3] = rs.getObject(5)+"";
										result[4] = rs.getObject(6)+"";
										result[5] = rs.getObject(4)+"";
										result[6] = rs.getObject(9)+"";
										result[7] = rs.getObject(10)+"";
									} else if (btype.equalsIgnoreCase("Police")) {
										result[2] = rs.getObject(3)+"";
										result[3] = rs.getObject(4)+"";
										result[6] = rs.getObject(5)+"";
										result[7] = rs.getObject(6)+"";
									} else if (btype.equalsIgnoreCase("Tourpoint")) {
										result[2] = rs.getObject(3)+"";
										result[3] = rs.getObject(4)+"";
										result[4] = rs.getObject(5)+"";
										result[5] = rs.getObject(6)+"";
										result[6] = rs.getObject(9)+"";
										result[7] = rs.getObject(10)+"";
									} else {
										result[2] = rs.getObject(3)+"";
										result[3] = rs.getObject(4)+"";
										result[4] = rs.getObject(5)+"";
										result[5] = rs.getObject(6)+"";
										result[6] = rs.getObject(7)+"";
										result[7] = rs.getObject(8)+"";
									}
								}
							}
						}
						catch (SQLException e){System.out.println("SQL error");}
						ps.println(result[0]+" "+result[1]+" "+result[2]+" "+result[3]+" "+result[4]+" "+result[5]+" "+result[6]+" "+result[7]);
						if (result[0].equalsIgnoreCase("")) {
							try
							{
								rs = stmt.executeQuery(
									"SELECT * FROM add_place WHERE (place_id = "+bid+" or place_name = '"+bname+"' or place_type = '"+btype+"') and user_name = '"+user+"' ORDER BY 1");
								while(rs.next()) {
									result[0] = rs.getObject(1).toString();
									result[1] = rs.getObject(2).toString();
									result[2] = rs.getObject(3)+"";
									result[3] = rs.getObject(4)+"";
									result[4] = rs.getObject(5)+"";
									result[5] = rs.getObject(6)+"";
									result[6] = rs.getObject(7)+"";
									result[7] = rs.getObject(8)+"";
									result[8] = rs.getObject(9)+"";
								}
							}
							catch (SQLException e){System.out.println("SQL error");}
							ps.println(result[0]+" "+result[1]+" "+result[2]+" "+result[3]+" "+result[4]+" "+result[5]+" "+result[6]+" "+result[7]+" "+result[8]);
						}
						if (result[0].equalsIgnoreCase("")) {
							result[0] = "no_place"; 
							return result;
						}
					}else {result[0] = "authen_failed"; return result;}
				} else {result[0] = "authen_failed"; return result;}
			}
			catch (SQLException e){System.out.println("SQL error");}
		}
		catch(IOException e){System.out.println("IO error");}
		return result;
	}

	public String placePersonMap (String user,String password, String bid, String bname) {
		String result = "";
		String slatc = "";
		String slonc = "";
		try {
			FileOutputStream f = new FileOutputStream(TOURfile);
			PrintStream ps = new PrintStream(f);
			ResultSet rs;
			try {
				rs = stmt.executeQuery(
					"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
				if (rs.next()) {
					String dbpassword = rs.getObject(1).toString();
					
					if (dbpassword.equalsIgnoreCase(password)) {	
						
						String placetype[] = {"Bank","Hospital","Mall","Police","Restaurant","Tourpoint","",""};
						int a=0;
						while (placetype[a].length() > 0) {
							try {
								if (placetype[a].equalsIgnoreCase("Tourpoint")) {
									rs = stmt.executeQuery(
										"SELECT lat,lon FROM tourpoint WHERE place_id = "+bid+" and tour_name = '"+bname+"' ORDER BY 1");
								} else {
									rs = stmt.executeQuery(
										"SELECT lat,lon FROM "+placetype[a]+" WHERE place_id = "+bid+" and "+placetype[a]+"_name = '"+bname+"' ORDER BY 1");	
								}
								while(rs.next()) {
									slatc = rs.getObject(1).toString();
									slonc = rs.getObject(2).toString();
									result = result + rs.getObject(1).toString() + " " +
									rs.getObject(2).toString() + "<br>\n";
								}

								if (slatc.equals("") || slonc.equals("")) {
									rs = stmt.executeQuery(
											"SELECT lat,lon FROM add_place WHERE place_id = "+bid+" and place_name = '"+bname+"' and user_name = '"+user+"' ORDER BY 1");
									while(rs.next()) {
										slatc = rs.getObject(1).toString();
										slonc = rs.getObject(2).toString();
										result = result + rs.getObject(1).toString() + " " +
										rs.getObject(2).toString() + "<br>\n";
									}
								}

								if (slatc.equals("") || slonc.equals("")) {
									return "no_place";
								}
							}
							catch (SQLException e){System.out.println("SQL error");}
							a++;
						}
						Double dc = new Double (slatc);
						double latc = dc.doubleValue();
						dc = new Double (slonc);
						double lonc = dc.doubleValue();
						System.out.println(latc + " " +lonc);
						exportToSVG(user,password,latc-0.02,lonc-0.01,latc+0.02,lonc+0.01);
						ps.println(result);
						return "success";
					}else {return "authen_failed";}
				} else {return "authen_failed";}
			}
			catch (SQLException e){System.out.println("SQL error");}
		}
		catch (IOException e){System.out.println("IO error");}
		return result;
	}

	public String setPlaceDetail(String user, String password, String name, String type, String tel, String website, String opentime, String lat, String lon, String detail) {
		try {
			// check user & password
			rs = stmt.executeQuery(
				"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
			if (rs.next()) {
				String dbpassword = rs.getObject(1).toString();
				
				if (dbpassword.equalsIgnoreCase(password)) {
					String count = null;
					
					if (type.equalsIgnoreCase("bank")) {
						rs = stmt.executeQuery(
							"SELECT COUNT(*) FROM add_place WHERE Place_Name = '" + name + "'");
						if (rs.next()) {
							count = rs.getObject(1).toString();
							
							if (count.equalsIgnoreCase("0")) {
								rsu = stmt.executeUpdate(
									"INSERT INTO add_place(Place_Name, Place_Type, Tel, Website, OpenTime, Lat, Lon, Detail, User_Name) VALUES('" + name + "', '" + type + "', '" + tel + "', '" + website + "', '" + opentime + "', '" + lat + "', '" + lon + "', '" + detail + "', '" + user + "')");
								return "success";
							}
							else return "duplicate place";
						}
					}
					else if (type.equalsIgnoreCase("hospital")) {
						rs = stmt.executeQuery(
							"SELECT COUNT(*) FROM add_place WHERE Place_Name = '" + name + "'");
						if (rs.next()) {
							count = rs.getObject(1).toString();
							
							if (count.equalsIgnoreCase("0")) {
								rsu = stmt.executeUpdate(
									"INSERT INTO add_place(Place_Name, Place_Type, Tel, Website, OpenTime, Lat, Lon, Detail, User_Name) VALUES('" + name + "', '" + type + "', '" + tel + "', '" + website + "', '" + opentime + "', '" + lat + "', '" + lon + "', '" + detail + "', '" + user + "')");
								return "success";
							}
							else return "duplicate place";
						}
					}
					else if (type.equalsIgnoreCase("mall")) {
						rs = stmt.executeQuery(
							"SELECT COUNT(*) FROM add_place WHERE Place_Name = '" + name + "'");
						if (rs.next()) {
							count = rs.getObject(1).toString();
							
							if (count.equalsIgnoreCase("0")) {
								rsu = stmt.executeUpdate(
									"INSERT INTO add_place(Place_Name, Place_Type, Tel, Website, OpenTime, Lat, Lon, Detail, User_Name) VALUES('" + name + "', '" + type + "', '" + tel + "', '" + website + "', '" + opentime + "', '" + lat + "', '" + lon + "', '" + detail + "', '" + user + "')");
								return "success";
							}
							else return "duplicate place";
						}
					}
					else if (type.equalsIgnoreCase("police")) {
						rs = stmt.executeQuery(
							"SELECT COUNT(*) FROM add_place WHERE Place_Name = '" + name + "'");
						if (rs.next()) {
							count = rs.getObject(1).toString();
							
							if (count.equalsIgnoreCase("0")) {
								rsu = stmt.executeUpdate(
									"INSERT INTO add_place(Place_Name, Place_Type, Tel, Website, OpenTime, Lat, Lon, Detail, User_Name) VALUES('" + name + "', '" + type + "', '" + tel + "', '" + website + "', '" + opentime + "', '" + lat + "', '" + lon + "', '" + detail + "', '" + user + "')");
								return "success";
							}
							else return "duplicate place";
						}
					}
					else if (type.equalsIgnoreCase("restaurant")) {
						rs = stmt.executeQuery(
							"SELECT COUNT(*) FROM add_place WHERE Place_Name = '" + name + "'");
						if (rs.next()) {
							count = rs.getObject(1).toString();
							
							if (count.equalsIgnoreCase("0")) {
								rsu = stmt.executeUpdate(
									"INSERT INTO add_place(Place_Name, Place_Type, Tel, Website, OpenTime, Lat, Lon, Detail, User_Name) VALUES('" + name + "', '" + type + "', '" + tel + "', '" + website + "', '" + opentime + "', '" + lat + "', '" + lon + "', '" + detail + "', '" + user + "')");
								return "success";
							}
							else return "duplicate place";
						}
					}
					else if (type.equalsIgnoreCase("tourpoint")) {
						rs = stmt.executeQuery(
							"SELECT COUNT(*) FROM add_place WHERE Place_Name = '" + name + "'");
						if (rs.next()) {
							count = rs.getObject(1).toString();
							
							if (count.equalsIgnoreCase("0")) {
								rsu = stmt.executeUpdate(
									"INSERT INTO add_place(Place_Name, Place_Type, Tel, Website, OpenTime, Lat, Lon, Detail, User_Name) VALUES('" + name + "', '" + type + "', '" + tel + "', '" + website + "', '" + opentime + "', '" + lat + "', '" + lon + "', '" + detail + "', '" + user + "')");
								return "success";
							}
							else return "duplicate place";
						}
					}
				}
				else { return "authentication failed"; }
			}
			else { return "authentication failed"; }
			
		}
		catch(SQLException e) {}
		
		return "failed";
	}

	public String editPlaceDetail(String user, String password, String pid, String name, String type, String tel, String website, String opentime, String lat, String lon, String detail) {
		try {
			// check user & password
			rs = stmt.executeQuery(
				"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
			if (rs.next()) {
				String dbpassword = rs.getObject(1).toString();
				
				if (dbpassword.equalsIgnoreCase(password)) {
					String count = null;
								
					rs = stmt.executeQuery(
						"SELECT COUNT(*) FROM add_place WHERE Place_ID = '" + pid + "'");
					if (rs.next()) {
						count = rs.getObject(1).toString();
						
						if (count.equalsIgnoreCase("1")) {
							rsu = stmt.executeUpdate(
								"UPDATE add_place SET Place_Name = '" + name + "', Place_Type = '" + type + "', Tel = '" + tel + "', Website = '" + website + "', OpenTime = '" + opentime + "', Lat = '" + lat + "', Lon = '" + lon + "' WHERE Place_ID = " + pid);
							return "success";
						}
						else return "uneditable place";
					}
				}
				else { return "authentication failed"; }
			}
			else { return "authentication failed"; }
			
		}
		catch(SQLException e) {}
		
		return "failed";
	}

	public String setUser(String user, String password) {
		try {
			rs = stmt.executeQuery(
				"INSERT INTO user(User_Name, User_Password) VALUES('" + user + "', '" + password + "'");
		}
		catch(SQLException e) {
			return "failed";
		}
		
		return "success";
	}
	
	public String getPassword(String user) {
		String password = null;
		
		try {
			rs = stmt.executeQuery(
				"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
			if (rs.next()) {
				password = rs.getObject(1).toString();
			}
		}
		catch(SQLException e) {
			return null;
		}
		
		return password;
	}
}