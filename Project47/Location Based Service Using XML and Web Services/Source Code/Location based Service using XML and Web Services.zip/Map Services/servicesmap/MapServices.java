/**
 * MapServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesmap;

public interface MapServices extends java.rmi.Remote {
    public java.lang.String getMap(java.lang.String user, java.lang.String password, java.lang.String lat_tl, java.lang.String lon_tl, java.lang.String lat_rb, java.lang.String lon_rb, java.lang.String outtype) throws java.rmi.RemoteException;
    public java.lang.String getPlaceMap(java.lang.String user, java.lang.String password, java.lang.String bid, java.lang.String bname) throws java.rmi.RemoteException;
    public java.lang.String[] getPlaceDetail(java.lang.String user, java.lang.String password, java.lang.String bid, java.lang.String bname, java.lang.String btype) throws java.rmi.RemoteException;
    public java.lang.String setPlaceDetail(java.lang.String user, java.lang.String password, java.lang.String bname, java.lang.String btype, java.lang.String tel, java.lang.String website, java.lang.String opentime, java.lang.String lat, java.lang.String lon, java.lang.String detail) throws java.rmi.RemoteException;
    public java.lang.String editPlaceDetail(java.lang.String user, java.lang.String password, java.lang.String bid, java.lang.String bname, java.lang.String btype, java.lang.String tel, java.lang.String website, java.lang.String opentime, java.lang.String lat, java.lang.String lon, java.lang.String detail) throws java.rmi.RemoteException;
    public java.lang.String searchPlace(java.lang.String user, java.lang.String password, java.lang.String bname, java.lang.String btype) throws java.rmi.RemoteException;
    public java.lang.String getPassword(java.lang.String user) throws java.rmi.RemoteException;
    public java.lang.String setUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.String editUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.String getMapInfo() throws java.rmi.RemoteException;
    public java.lang.String getPlaceDetailInfo() throws java.rmi.RemoteException;
}
