/**
 * MapServicesServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesmap;

public class MapServicesServiceLocator extends org.apache.axis.client.Service implements servicesmap.MapServicesService {

    // Use to get a proxy class for MapServices
    private final java.lang.String MapServices_address = "http://localhost/axis/services/MapServices";

    public java.lang.String getMapServicesAddress() {
        return MapServices_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String MapServicesWSDDServiceName = "MapServices";

    public java.lang.String getMapServicesWSDDServiceName() {
        return MapServicesWSDDServiceName;
    }

    public void setMapServicesWSDDServiceName(java.lang.String name) {
        MapServicesWSDDServiceName = name;
    }

    public servicesmap.MapServices getMapServices() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(MapServices_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getMapServices(endpoint);
    }

    public servicesmap.MapServices getMapServices(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            servicesmap.MapServicesSoapBindingStub _stub = new servicesmap.MapServicesSoapBindingStub(portAddress, this);
            _stub.setPortName(getMapServicesWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (servicesmap.MapServices.class.isAssignableFrom(serviceEndpointInterface)) {
                servicesmap.MapServicesSoapBindingStub _stub = new servicesmap.MapServicesSoapBindingStub(new java.net.URL(MapServices_address), this);
                _stub.setPortName(getMapServicesWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("MapServices".equals(inputPortName)) {
            return getMapServices();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:servicesmap", "MapServicesService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("MapServices"));
        }
        return ports.iterator();
    }

}
