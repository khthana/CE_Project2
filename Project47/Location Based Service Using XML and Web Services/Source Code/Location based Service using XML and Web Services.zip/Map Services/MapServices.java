package servicesmap;

/**
 * Interface describing a web service to get Map Services.
 **/
public interface MapServices {
    public String getMap (String user, String password, String lat_tl, String lon1_tl, String lat2_rb, String lon2_rb, String outtype);
	public String getPlaceMap (String user, String password, String bid, String bname);

    public String[] getPlaceDetail (String user, String password, String bid, String bname, String btype);
	public String setPlaceDetail (String user, String password, String bname, String btype, String tel, String website, String opentime, String lat, String lon, String detail);
	public String editPlaceDetail (String user, String password, String bid, String bname, String btype, String tel, String website, String opentime, String lat, String lon, String detail);

	public String searchPlace (String user, String password, String bname, String ntype);

	public String getPassword (String user);
	public String setUser (String user, String password);
	public String editUser (String user, String password);
	
	public String getMapInfo ();
	public String getPlaceDetailInfo ();
}
