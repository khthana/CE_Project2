package servicesyellowpage;

/**
 * Interface describing a web service to get Yellow Page Services.
 **/
public interface YellowPageServices {
    public String[] getPersonDetail (String user, String password, String pid, String pname, String psurname);
	public String getPersonMap (String user, String password, String pid, String pname, String psurname);
	
	public String setPersonDetail (String user, String password, String person_name, String person_surname, String place_name, String address, String tel, String detail);
	public String editPersonDetail (String user, String password, String pid, String person_name, String person_surname, String place_id, String place_name, String address, String tel, String detail);
	
	public String searchPerson (String user, String password, String pname, String psurname);

	public String getPassword (String user);
	public String setUser (String user, String password);
	public String editUser (String user, String password);

	public String getPersonDetailInfo ();
}
