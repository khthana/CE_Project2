/**
 * YellowPageServicesService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesyellowpage;

public interface YellowPageServicesService extends javax.xml.rpc.Service {
    public java.lang.String getYellowPageServicesAddress();

    public servicesyellowpage.YellowPageServices getYellowPageServices() throws javax.xml.rpc.ServiceException;

    public servicesyellowpage.YellowPageServices getYellowPageServices(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
