/**
 * YellowPageServicesSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesyellowpage;
import java.io.*;
import java.sql.*;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import javax.xml.namespace.QName;

public class YellowPageServicesSoapBindingImpl implements servicesyellowpage.YellowPageServices{

	//----------------------GetPersonDetail-------------------------------------------//
    public java.lang.String[] getPersonDetail(java.lang.String user, java.lang.String password, java.lang.String pid, java.lang.String pname, java.lang.String psurname) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result[];
		String user_en = user;
		String password_en = password;
		String pname_en = pname;
		String psurname_en = psurname;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			pname_en = new String(pname.getBytes("TIS-620"));
			psurname_en = new String(psurname.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.personDetail(user_en,password_en,pid,pname_en,psurname_en);
		return result;
    }

	//----------------------GetPersonMap-------------------------------------------//
    public java.lang.String getPersonMap(java.lang.String user, java.lang.String password, java.lang.String pid, java.lang.String pname, java.lang.String psurname) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result = "";
		String user_en = user;
		String password_en = password;
		String pname_en = pname;
		String psurname_en = psurname;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			pname_en = new String(pname.getBytes("TIS-620"));
			psurname_en = new String(psurname.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.personPlace(user_en,password_en,pid,pname_en,psurname_en);
		if (result.equalsIgnoreCase("no_place") || result.equalsIgnoreCase("authen_failed")) {
			return result;
		}
		String bid = "";
		String bname = "";
		int i=0;
		boolean word = false;
		for (i=0;i<result.length();i++) {
			if (!word && result.charAt(i) == '-') {
				word = true;
				i++;
			}
			if (word) {
				bname = bname + result.charAt(i);
			} else {
				bid = bid + result.charAt(i);
			}
		}
		System.out.println(bid + "<=>" + bname);
		result = "";
		try {
			String endpoint = "http://localhost/axis/services/MapServices";
			Service service = new Service();
			Call call = (Call) service.createCall();
			call.setTimeout(new java.lang.Integer(1000000));

			call.setTargetEndpointAddress(new java.net.URL(endpoint));
			call.setOperationName(new QName("http://localhost/axis/services/MapServices", "getPlaceMap"));
			result = (String) call.invoke(new Object[] {bid,bname});
		} catch (Exception e) {}
		return result;
    }

	//----------------------SetPersonDetail-------------------------------------------//
    public java.lang.String setPersonDetail(java.lang.String user, java.lang.String password, java.lang.String pname, java.lang.String psurname, java.lang.String bname, java.lang.String address, java.lang.String tel, java.lang.String detail) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		String pname_en = pname;
		String psurname_en = psurname;
		String bname_en = bname;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			pname_en = new String(pname.getBytes("TIS-620"));
			psurname_en = new String(psurname.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.setPersonDetail(user_en,password_en,pname_en,psurname_en,bname_en,address,tel,detail);
		return result;
    }

	//----------------------EditPersonDetail-------------------------------------------//
    public java.lang.String editPersonDetail(java.lang.String user, java.lang.String password, java.lang.String pid, java.lang.String pname, java.lang.String psurname, java.lang.String bid, java.lang.String bname, java.lang.String address, java.lang.String tel, java.lang.String detail) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		String pname_en = pname;
		String psurname_en = psurname;
		String bname_en = bname;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			pname_en = new String(pname.getBytes("TIS-620"));
			psurname_en = new String(psurname.getBytes("TIS-620"));
			bname_en = new String(bname.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.editPersonDetail(user_en,password_en,pid,pname_en,psurname_en,bid,bname_en,address,tel,detail);
		return result;
    }

	//----------------------SearchPerson-------------------------------------------//
    public java.lang.String searchPerson(java.lang.String user, java.lang.String password, java.lang.String pname, java.lang.String psurname) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result = "";
		String user_en = user;
		String password_en = password;
		String pname_en = pname;
		String psurname_en = psurname;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
			pname_en = new String(pname.getBytes("TIS-620"));
			psurname_en = new String(psurname.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}

		result = m.searchPersonList(user_en,password_en,pname_en,psurname_en);
		return result;
    }

	//----------------------GetPassword----------------------------------//
    public java.lang.String getPassword(java.lang.String user) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result;
		String user_en = user;
		try {
			user_en = new String(user.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.getPassword(user_en);
		return result;
    }

	//----------------------SetUser--------------------------------------//
    public java.lang.String setUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException {
		ServiceYel m = new ServiceYel();			
		m.openConnect();
		String result;
		String user_en = user;
		String password_en = password;
		try {
			user_en = new String(user.getBytes("TIS-620"));
			password_en = new String(password.getBytes("TIS-620"));
		}
		catch (Exception e) {System.out.println("error encode");}
		result = m.setUser(user_en,password_en);
		return result;
    }

	//----------------------EditUser-------------------------------------//
    public java.lang.String editUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException {
        return null;
    }

	//----------------------GetPersonDetailInfo----------------------------------//
    public java.lang.String getPersonDetailInfo() throws java.rmi.RemoteException {
		File PDetailInfofile = new File("C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/GetPDetailinfo.txt");
		String PDetailstr = "";
		try {
			BufferedReader bin = new BufferedReader(new FileReader(PDetailInfofile));
			String str;
			while ((str = bin.readLine()) != null) {
				PDetailstr = PDetailstr + str;
			}
			bin.close();
			return PDetailstr;
		} catch (IOException e) {
			return "";
		}
    }

}

class ServiceYel {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DATABASE_URL = "jdbc:mysql://localhost/yellowpage";
	static final String USER = "root";
	static final String PASSWORD = "iamadmin";
	
	static final String GMLfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.gml";
	static final String SVGfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/map.svg";
	static final String TOURfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/tour.txt";
	static final String PLACEfile = "C:\\Program Files/Apache Group/Tomcat 4.1/webapps/axis/place.txt";

	private Connection conn;
	private Statement stmt;
	private	ResultSet rs;
	private int rsu;
	
	public void openConnect() {
		try {
			Class.forName(JDBC_DRIVER).newInstance();
			conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
			stmt = conn.createStatement();
		}
		catch(Exception e) {}
		finally {
			if (conn == null | stmt == null) {
				System.out.println("The problem has occured when trying to connect to database.");
			}
		}
	}
	
	public void closeConnect() {
		try {
			stmt.close();
			conn.close();
		}
		catch(Exception e) {}
		finally {
			if (conn != null | stmt != null) {
				System.out.println("The problem has occured when trying to close connection.");
			}
		}
	}

	public String searchPersonList (String user, String password, String pname, String psurname) {
		String result = "";
		try {
			FileOutputStream f = new FileOutputStream(TOURfile);
			PrintStream ps = new PrintStream(f);
			String qsur = "";
			String qname = "";

			try {
				rs = stmt.executeQuery(
					"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
				if (rs.next()) {
					String dbpassword = rs.getObject(1).toString();
					
					if (dbpassword.equalsIgnoreCase(password)) {	
						try {
							if (!pname.equalsIgnoreCase("")) {
								qname = "person_name LIKE '%"+pname+"%' ";
								if (!psurname.equalsIgnoreCase("")) {
									qname = qname + " or ";
								}
							}
							if (!psurname.equalsIgnoreCase("")) {
								qsur = "person_surname LIKE '%"+psurname+"%'";
							}
							if (pname.equalsIgnoreCase("") && psurname.equalsIgnoreCase("")) {
								qname = "person_name LIKE '%"+pname+"%' ";
								qname = qname + " or ";
								qsur = "person_surname LIKE '%"+psurname+"%'";
							}
								rs = stmt.executeQuery(
									"SELECT person_id,person_name,person_surname FROM person WHERE "+qname+" "+qsur+" ORDER BY 1");
							while(rs.next()) {
								result = result + rs.getObject(1).toString() + " " +
								rs.getObject(2).toString() +" "+ rs.getObject(3).toString() + " | <a href=\"PersonMapSVG.jsp?id="+rs.getObject(1).toString()+"&name="+rs.getObject(2).toString()+"&surname="+rs.getObject(3).toString()+"\">Place Map(SVG)</a> | EDIT |<br>\n";
							}

							if (!pname.equalsIgnoreCase("") && psurname.equalsIgnoreCase("")) {
								qname = "person_name LIKE '%"+pname+"%' and ";
							} else if (pname.equalsIgnoreCase("") && !psurname.equalsIgnoreCase("")) {
								qsur = "person_surname LIKE '%"+psurname+"%') and";
							} else {
								qname = "(person_name LIKE '%"+pname+"%' ";
								qname = qname + " or ";
								qsur = "person_surname LIKE '%"+psurname+"%') and";
							}
								rs = stmt.executeQuery(
									"SELECT person_id,person_name,person_surname FROM add_person WHERE "+qname+" "+qsur+" user_name = '"+user+"' ORDER BY 1");
							while(rs.next()) {
								result = result + rs.getObject(1).toString() + " " +
								rs.getObject(2).toString() +" "+ rs.getObject(3).toString() + " | <a href=\"PersonMapSVG.jsp?id="+rs.getObject(1).toString()+"&name="+rs.getObject(2).toString()+"&surname="+rs.getObject(3).toString()+"\">Place Map(SVG)</a> | <a href=\"edit-person2.jsp?id="+rs.getObject(1).toString()+"&name="+rs.getObject(2).toString()+"&surname="+rs.getObject(3).toString()+"\">EDIT</a> |<br>\n";
							}
						}
						catch (SQLException e){System.out.println("SQL error");}
						if (result.equalsIgnoreCase("")) {
							return "no_person";
						}
						ps.println(result);
					}else {return "authen_failed";}
				} else {return "authen_failed";}
			}
			catch (SQLException e){System.out.println("SQL error");}		
		}
		catch (IOException e){System.out.println("IO error");}
		return result;
	}

	public String[] personDetail (String user, String password, String pid,String pname, String psurname) {
		String result[] = {"","","","","","","",""};
		try {
			FileOutputStream f = new FileOutputStream(TOURfile);
			PrintStream ps = new PrintStream(f);

			try {
				rs = stmt.executeQuery(
					"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
				if (rs.next()) {
					String dbpassword = rs.getObject(1).toString();
					
					if (dbpassword.equalsIgnoreCase(password)) {	
							try
							{
								rs = stmt.executeQuery(
									"SELECT * FROM person WHERE person_id = "+pid+" and person_name = '"+pname+"' and person_surname = '"+psurname+"' ORDER BY 1");
								while(rs.next()) {
									result[0] = rs.getObject(1).toString();
									result[1] = rs.getObject(2).toString();
									result[2] = rs.getObject(3).toString();
									result[3] = rs.getObject(4)+"";
									result[4] = rs.getObject(5)+"";
									result[5] = rs.getObject(6)+"";
									result[6] = rs.getObject(7)+"";
									result[7] = rs.getObject(8)+"";
								}
							}
							catch (SQLException e){System.out.println("SQL error");}
							ps.println(result[0]+" "+result[1]+" "+result[2]+" "+result[3]+" "+result[4]+" "+result[5]+" "+result[6]+" "+result[7]);
							if (result[0].equalsIgnoreCase("")) {
								try
								{
									rs = stmt.executeQuery(
										"SELECT * FROM add_person WHERE person_id = "+pid+" and person_name = '"+pname+"' and person_surname = '"+psurname+"' and user_name = '"+user+"' ORDER BY 1");
									while(rs.next()) {
										result[0] = rs.getObject(1).toString();
										result[1] = rs.getObject(2).toString();
										result[2] = rs.getObject(3).toString();
										result[3] = rs.getObject(4)+"";
										result[4] = rs.getObject(5)+"";
										result[5] = rs.getObject(6)+"";
										result[6] = rs.getObject(7)+"";
										result[7] = rs.getObject(8)+"";
									}
								}
								catch (SQLException e){System.out.println("SQL error");}
								ps.println(result[0]+" "+result[1]+" "+result[2]+" "+result[3]+" "+result[4]+" "+result[5]+" "+result[6]+" "+result[7]);
							}

							if (result[0].equalsIgnoreCase("")) {
								result[0] = "no_person"; 
								return result;
							}
					}else {result[0] = "authen_failed"; return result;}
				} else {result[0] = "authen_failed"; return result;}
			}
			catch (SQLException e){System.out.println("SQL error");}		
		}
		catch(IOException e){System.out.println("IO error");}
		return result;
	}

	public String personPlace (String user,String password, String pid,String pname, String psurname) {
		String result = "";
		String bid = "";
		String bname = "";
		try {
			FileOutputStream f = new FileOutputStream(TOURfile);
			PrintStream ps = new PrintStream(f);

			try {
				rs = stmt.executeQuery(
					"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
				if (rs.next()) {
					String dbpassword = rs.getObject(1).toString();
					
					if (dbpassword.equalsIgnoreCase(password)) {	
						try {
							rs = stmt.executeQuery(
								"SELECT place_id,place_name FROM person WHERE person_id = "+pid+" and person_name = '"+pname+"' and person_surname = '"+psurname+"' ORDER BY 1");
							while(rs.next()) {
								bid = rs.getObject(1) + "";
								bname = rs.getObject(2) + "";
							}

							if (bid.equalsIgnoreCase("") || bname.equalsIgnoreCase("")) {
								rs = stmt.executeQuery(
									"SELECT place_id,place_name FROM add_person WHERE person_id = "+pid+" and person_name = '"+pname+"' and person_surname = '"+psurname+"' and user_name = '"+user+"' ORDER BY 1");
								while(rs.next()) {
									bid = rs.getObject(1) + "";
									bname = rs.getObject(2) + "";
								}
							}

							if (bid.equalsIgnoreCase("") || bname.equalsIgnoreCase("")) {
								return "no_place";
							}
							result = bid + "-" + bname;
						}
						catch (SQLException e){System.out.println("SQL error");}
						ps.println(result);
					}else {return "authen_failed";}
				} else {return "authen_failed";}
			}
			catch (SQLException e){System.out.println("SQL error");}		
		}
		catch(IOException e){System.out.println("IO error");}
		return result;
	}

	public String setPersonDetail(String user, String password, String person_name, String person_surname, String place_name, String address, String tel, String detail) {
		try {
			// check user & password
			rs = stmt.executeQuery(
				"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
			if (rs.next()) {
				String dbpassword = rs.getObject(1).toString();
				
				if (dbpassword.equalsIgnoreCase(password)) {
					String count = null;
										
					rs = stmt.executeQuery(
						"SELECT COUNT(*) FROM add_person WHERE Person_Name = '" + person_name + "'");
					if (rs.next()) {
						count = rs.getObject(1).toString();
						
						if (count.equalsIgnoreCase("0")) {
							rsu = stmt.executeUpdate(
								"INSERT INTO add_person(Person_Name, Person_Surname, Place_Name, Address, Tel, Detail, User_Name) VALUES('" + person_name + "', '" + person_surname + "', '" + place_name + "', '" + address + "', '" + tel + "', '" + detail + "', '" + user + "')");
							return "success";
						}
						else return "duplicate person";
					}
				}
				else { return "authentication failed"; }
			}
			else { return "authentication failed"; }
		}
		catch(SQLException e) {e.printStackTrace();}
		
		return "failed";
	}
	
	public String editPersonDetail(String user, String password, String pid, String person_name, String person_surname, String place_id, String place_name, String address, String tel, String detail) {
		try {
			// check user & password
			rs = stmt.executeQuery(
				"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
			if (rs.next()) {
				String dbpassword = rs.getObject(1).toString();
				
				if (dbpassword.equalsIgnoreCase(password)) {
					String count = null;
										
					rs = stmt.executeQuery(
						"SELECT COUNT(*) FROM add_person WHERE Person_ID = '" + pid + "'");
					if (rs.next()) {
						count = rs.getObject(1).toString();
						
						if (count.equalsIgnoreCase("1")) {
							rsu = stmt.executeUpdate(
								"UPDATE add_person SET Person_Name = '" + person_name + "', Person_Surname = '" + person_surname + "', place_ID = '" + place_id + "', Place_Name = '" + place_name + "', Address = '" + address + "', Tel = '" + tel + "', Detail = '" + detail + "' WHERE Person_ID = " + pid);
							return "success";
						}
						else return "uneditable person";
					}					
				}
				else { return "authenication failed"; }
			}
			else { return "authenication failed"; }
			
		}
		catch(SQLException e) {}
		
		return "failed";
	}

	public String setUser(String user, String password) {
		try {
			rs = stmt.executeQuery(
				"INSERT INTO user(User_Name, User_Password) VALUES('" + user + "', '" + password + "'");
		}
		catch(SQLException e) {
			return "failed";
		}
		
		return "success";
	}
	
	public String getPassword(String user) {
		String password = null;
		
		try {
			rs = stmt.executeQuery(
				"SELECT User_Password FROM user WHERE User_Name = '" + user + "'");
			if (rs.next()) {
				password = rs.getObject(1).toString();
			}
		}
		catch(SQLException e) {
			return null;
		}
		
		return password;
	}
}