/**
 * YellowPageServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesyellowpage;

public interface YellowPageServices extends java.rmi.Remote {
    public java.lang.String[] getPersonDetail(java.lang.String user, java.lang.String password, java.lang.String pid, java.lang.String pname, java.lang.String psurname) throws java.rmi.RemoteException;
    public java.lang.String getPersonMap(java.lang.String user, java.lang.String password, java.lang.String pid, java.lang.String pname, java.lang.String psurname) throws java.rmi.RemoteException;
    public java.lang.String setPersonDetail(java.lang.String user, java.lang.String password, java.lang.String pname, java.lang.String psurname, java.lang.String bname, java.lang.String address, java.lang.String tel, java.lang.String detail) throws java.rmi.RemoteException;
    public java.lang.String editPersonDetail(java.lang.String user, java.lang.String password, java.lang.String pid, java.lang.String pname, java.lang.String psurname, java.lang.String bid, java.lang.String bname, java.lang.String address, java.lang.String tel, java.lang.String detail) throws java.rmi.RemoteException;
    public java.lang.String searchPerson(java.lang.String user, java.lang.String password, java.lang.String pname, java.lang.String psurname) throws java.rmi.RemoteException;
    public java.lang.String getPassword(java.lang.String user) throws java.rmi.RemoteException;
    public java.lang.String setUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.String editUser(java.lang.String user, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.String getPersonDetailInfo() throws java.rmi.RemoteException;
}
