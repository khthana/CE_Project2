/**
 * YellowPageServicesServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package servicesyellowpage;

public class YellowPageServicesServiceLocator extends org.apache.axis.client.Service implements servicesyellowpage.YellowPageServicesService {

    // Use to get a proxy class for YellowPageServices
    private final java.lang.String YellowPageServices_address = "http://localhost/axis/services/YellowPageServices";

    public java.lang.String getYellowPageServicesAddress() {
        return YellowPageServices_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String YellowPageServicesWSDDServiceName = "YellowPageServices";

    public java.lang.String getYellowPageServicesWSDDServiceName() {
        return YellowPageServicesWSDDServiceName;
    }

    public void setYellowPageServicesWSDDServiceName(java.lang.String name) {
        YellowPageServicesWSDDServiceName = name;
    }

    public servicesyellowpage.YellowPageServices getYellowPageServices() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(YellowPageServices_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getYellowPageServices(endpoint);
    }

    public servicesyellowpage.YellowPageServices getYellowPageServices(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            servicesyellowpage.YellowPageServicesSoapBindingStub _stub = new servicesyellowpage.YellowPageServicesSoapBindingStub(portAddress, this);
            _stub.setPortName(getYellowPageServicesWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (servicesyellowpage.YellowPageServices.class.isAssignableFrom(serviceEndpointInterface)) {
                servicesyellowpage.YellowPageServicesSoapBindingStub _stub = new servicesyellowpage.YellowPageServicesSoapBindingStub(new java.net.URL(YellowPageServices_address), this);
                _stub.setPortName(getYellowPageServicesWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("YellowPageServices".equals(inputPortName)) {
            return getYellowPageServices();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:servicesyellowpage", "YellowPageServicesService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("YellowPageServices"));
        }
        return ports.iterator();
    }

}
