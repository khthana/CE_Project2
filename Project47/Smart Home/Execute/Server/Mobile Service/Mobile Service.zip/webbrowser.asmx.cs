using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using iHomeService.localhost;

namespace iHomeService
{
	/// <summary>
	/// Summary description for webbrowser.
	/// </summary>
	[WebService(Namespace="http://hardware17.ce.kmitl.ac.th/iHomeService")]
	public class webbrowser : System.Web.Services.WebService
	{
		public webbrowser()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5

		[WebMethod]
		public string HelloWorld()
		{
			return "Hello World";
		}
		#region Control
		[WebMethod]
		public string Exec_wListDevice(int mode)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_wListDevice(mode);
		}
		[WebMethod]
		public bool Exec_On(string dist_addr)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_On(dist_addr);
		}
		[WebMethod]
		public bool Exec_Off(string dist_addr)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_Off(dist_addr);
		}
		[WebMethod]
		public bool Exec_SetDim(string dist_addr,int percent)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_SetDim(dist_addr,percent);
		}		
		[WebMethod]
		public bool update_NameDevice(string addr,string new_name)
		{
			InternetworkService a = new InternetworkService();
			return a.update_NameDevice(addr,new_name);
		}
		#endregion

		#region Security
		/*[WebMethod]
		public bool Exec_ResetAlert()
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_ResetAlert();
		}*/
		[WebMethod]
		public bool Exec_ResetAlert(string dist_addr)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_ResetAlert(dist_addr);
		}
		[WebMethod]
		public bool Exec_SecurityEN(string dist_addr)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_SecurityEN(dist_addr);
		}
		[WebMethod]
		public bool Exec_SecurityDi(string dist_addr)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_SecurityDi(dist_addr);
		}
		[WebMethod]
		public bool Exec_TurnOffSound(string addr)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_TurnOffSound(addr);
		}
		
		#endregion

		#region Schedule
		[WebMethod]
		public string Exec_wListSchedulesByType(int mode)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_wListSchedulesByType(mode);
		}
		[WebMethod]
		public string Exec_ListSchedulesByDev(string address,int mode)
		{
			InternetworkService a = new InternetworkService();
			return a.Exec_ListSchedulesByDev(address,mode);
		}
		[WebMethod]
		public int AddSchedule(string name,int type,string datetime,string days,string address,int cmd,string param)
		{
			InternetworkService a = new InternetworkService();
			return a.AddSchedule(name,type,datetime,days,address,cmd,param);
		}
		[WebMethod]
		public int RemoveSchedule(string name)
		{
			InternetworkService a = new InternetworkService();
			return a.RemoveSchedule(name);
		}
		[WebMethod]
		public int UpdateSchedule(string name,string datetime,string days,string address,int cmd,string param)
		{
			InternetworkService a = new InternetworkService();
			return a.UpdateSchedule(name,datetime,days,address,cmd,param);
		}
		#endregion

		#region Camera
		[WebMethod]
		public bool AddCaptureFn(string name,string details,int port,int cap_time)
		{
			InternetworkService a = new InternetworkService();
			return a.AddCaptureFn(name,details,port,cap_time);
		}
		[WebMethod]
		public bool RemoveCamera(int port)
		{
			InternetworkService a = new InternetworkService();
			return a.RemoveCamera(port);
		}
		[WebMethod]
		public bool UpdateCaptureTime(int port,int cap_time)
		{
			InternetworkService a = new InternetworkService();
			return a.UpdateCaptureTime(port,cap_time);
		}
		[WebMethod]
		public string ManualCapture(int port,int size)
		{
			InternetworkService a = new InternetworkService();
			return a.ManualCapture(port,size);
		}
		[WebMethod]
		public string ViewCamera()
		{
			InternetworkService a = new InternetworkService();
			return a.ViewCamera();
		}		
		[WebMethod]
		public int getCaptureDriverCount()
		{
			InternetworkService a = new InternetworkService();
			return a.getCaptureDriverCount();
		}
		[WebMethod]
		public string getCaptureDriverName()
		{
			InternetworkService a = new InternetworkService();
			return a.getCaptureDriverName();
		}
		#endregion

		#region Macro
		[WebMethod]
		public bool AddEventMacro(string source_addr,int event_type,
			string dist_addr,int cmd,string param)
		{
			InternetworkService a = new InternetworkService();
			return a.AddEventMacro(source_addr,event_type,"",dist_addr,cmd,param);
		}
		[WebMethod]
		public bool RemoveEventMacro(int macro_id)
		{
			InternetworkService a = new InternetworkService();
			return a.RemoveEventMacro(macro_id);
		}
		[WebMethod]
		public string ViewMacro()
		{
			InternetworkService a = new InternetworkService();
			return a.ViewMacro();
		}
		#endregion

		#region LogView
		[WebMethod]
		public string getLog()
		{
			InternetworkService a = new InternetworkService();
			return a.getLog();
		}
		#endregion

		#region Setting		
		[WebMethod]
		public bool SetSmsNumber(string smsno)
		{
			InternetworkService a = new InternetworkService();
			return a.SetSmsNumber(smsno);
		}
		[WebMethod]
		public string getSmsNumber()
		{
			InternetworkService a = new InternetworkService();
			return a.getSmsNumber();
		}
		#endregion
	}
}
