using System;
using iHome.Connections;
using iHome.Gui;
using iHome.Log;

namespace iHome
{	
	using System.Runtime.Remoting;
	using System.Runtime.Remoting.Channels;
	using System.Runtime.Remoting.Channels.Http;
	using System.Reflection;
	using System.Collections;
	using System.Windows.Forms;

	public class RemotingConfigurationHelper
	{
		// UnregisterWellKnownServiceType
		//
		// Unregisters the specified type/uri from the list of currently registered
		// well-known types.
		//
		public static void UnregisterWellKnownServiceType( Type objectType, string objectUri )
		{
			LookupTypeInfo();

			try
			{
				// Fetch RemotingConfigHandler.Info field value (returns instance of RemotingConfigHandler$RemotingConfigInfo).
				//
				object o = s_RemotingConfigHandler_Info.GetValue(null);

				// In a moment we'll need to synchronize on the above object to make sure we
				// keep things thread-safe.  Since I'm going to reuse 'o' momentarily, save off
				// a copy of the reference now.
				//
				object syncObject = o;

				// Lookup RemotingConfigInfo._wellKnownExportInfo field.
				//
				FieldInfo fieldInfo = o.GetType().GetField("_wellKnownExportInfo", BINDING_FLAGS | BindingFlags.Instance);

				// Fetch value of RemotingConfigInfo._wellKnownExportInfo field (returns Hashtable).
				//
				o = fieldInfo.GetValue(o);
				Hashtable registeredTypes = (Hashtable)o;

				// Unhook the specified type from the list of registered types.  External synchronization
				// is required because, although 'registeredTypes' is a synchronized hashtable, two
				// operations need to be performed in a thread-safe fashion: remove the matching entry
				// from the IdentityHolder collection as well as the RemotingConfigHelper collection.
				// Refer to the source for RemotingConfigHandler.RegisterWellKnownServiceType to see the
				// steps we're mimicing.
				//
				lock( syncObject )
				{
					s_IdentityHolder_RemoveIdentity.Invoke(null, new object[]{objectUri});
					registeredTypes.Remove(objectUri.ToLower());
				}
			}
			catch
			{
			}
		}

		// UnregisterActivatedServiceType
		//
		// Unregisters the specified type/uri from the list of currently registered
		// client-activated types.
		//
		public static void UnregisterActivatedServiceType( Type objectType )
		{
			const BindingFlags BINDING_FLAGS = BindingFlags.Public | BindingFlags.NonPublic;

			LookupTypeInfo();

			try
			{
				// Fetch RemotingConfigHandler.Info field value (returns instance of RemotingConfigHandler$RemotingConfigInfo).
				//
				object o = s_RemotingConfigHandler_Info.GetValue(null);

				// Lookup RemotingConfigInfo._exportableClasses field.
				//
				FieldInfo fieldInfo = o.GetType().GetField("_exportableClasses", BINDING_FLAGS | BindingFlags.Instance);

				// Fetch value of RemotingConfigInfo._exportableClasses field (returns Hashtable).
				//
				o = fieldInfo.GetValue(o);
				Hashtable registeredTypes = (Hashtable)o;

				// Unhook the specified type from the list of registered types.  External
				// synchronization is not required because the hash-table referred to
				// by 'registeredTypes' is a synchronized hashtable that we're only making
				// one call to.
				//
				string key = string.Format("{0}, {1}", objectType.FullName, objectType.Assembly.GetName().Name);
				registeredTypes.Remove(key);
			}
			catch
			{
			}
		}

		// LookupTypeInfo
		//
		// This helper function looks up & caches the necessary type information
		// for the RemotingConfigHelper and IdentityHolder classes, and the
		// fields extracted from each.
		//
		// If the types or fields are not found as expected, an exception
		// will be raised.  If everything is discovered as expected, the discovered
		// type information is cached and subsequent calls to this method become a no-op.
		//
		static void LookupTypeInfo()
		{
			if( s_RemotingConfigHandlerType == null )
			{
				// Lookup System.Runtime.Remoting.RemotingConfigHandler type information.
				//
				s_RemotingConfigHandlerType = Type.GetType("System.Runtime.Remoting.RemotingConfigHandler, mscorlib");

				if( s_RemotingConfigHandlerType == null )
				{
					throw new ApplicationException("Failed to lookup System.Runtime.Remoting.RemotingConfigHandler type information");
				}
			}

			if( s_RemotingConfigHandler_Info == null )
			{
				// Lookup RemotingConfigHandler.Info field information.
				//
				s_RemotingConfigHandler_Info = s_RemotingConfigHandlerType.GetField("Info", BINDING_FLAGS | BindingFlags.Static);

				if( s_RemotingConfigHandler_Info == null )
				{
					throw new ApplicationException("Failed to lookup RemotingConfigHandler.Info field information");
				}
			}

			if( s_IdentityHolderType == null )
			{
				// Lookup System.Runtime.Remoting.IdentityHolder type information.
				//
				s_IdentityHolderType = Type.GetType("System.Runtime.Remoting.IdentityHolder, mscorlib");

				if( s_IdentityHolderType == null )
				{
					throw new ApplicationException("Failed to lookup System.Runtime.Remoting.IdentityHolder type information");
				}
			}

			if( s_IdentityHolder_RemoveIdentity == null )
			{
				// Lookup IdentityHolder.RemoveIdentity(string) method information.
				//
				Type[] argTypes = new Type[] { typeof(string) };
				s_IdentityHolder_RemoveIdentity = s_IdentityHolderType.GetMethod("RemoveIdentity", BINDING_FLAGS | BindingFlags.Static, null, argTypes, null);

				if( s_IdentityHolder_RemoveIdentity == null )
				{
					throw new ApplicationException("Failed to lookup RemotingConfigHandler.Info field information");
				}
			}
		}

		const BindingFlags BINDING_FLAGS = BindingFlags.Public | BindingFlags.NonPublic;

		static Type s_RemotingConfigHandlerType;            // System.Runtime.Remoting.RemotingConfigHelper class
		static FieldInfo s_RemotingConfigHandler_Info;      // static Info field

		static Type s_IdentityHolderType;                   // System.Runtime.Remoting.IdentityHolder class
		static MethodInfo s_IdentityHolder_RemoveIdentity;  // static RemoveIdentity(string objectUri) method
	}
	
	public class Server
	{		
		public static iHomeGui homeGui=null;
		public static HWCommand hw=null;
		public static Server server=null;
		public static cameraview cam=null;		

		[STAThread]
		static void Main() 
		{
			//			HttpChannel channel = new HttpChannel(8000);
			//			ChannelServices.RegisterChannel(channel);			
			
			//			Type iType =	Type.GetType("iHome.Connections.Internetwork");
			//
			//			RemotingConfiguration.RegisterWellKnownServiceType
			//				( iType,
			//				"iHomeRemote",
			//				WellKnownObjectMode.SingleCall );
			
			try
			{	
				// Create Logger
				iTxtLogger log=new iTxtLogger();
				iErrorLogger err=new iErrorLogger();
				Console.SetOut(log);
				Console.SetError(err);	

				// Create Channel
				ChannelServices.RegisterChannel(new HttpChannel(8000));
				RemotingConfiguration.ApplicationName = "iHomesrv";
				
				// Create Server
				server = new Server();
				homeGui = new iHomeGui();
				Application.Run(homeGui);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message+
					"\nAnother iHome Server maybe running.. or use the same resource.","Error",
					MessageBoxButtons.OK,MessageBoxIcon.Error);
			}			
		}

		// �Դ��÷ӧҹ Sever ������ҧ���������� �Դ port
		public void Start()
		{
			Console.WriteLine("Start iHome Server...");

			hw = new HWCommand();
			hw.Loading();

			cam = new cameraview();
			cam.Hide();
			hw.PrepareDBForCapture();
			
			try
			{
				//RemotingConfiguration.Configure("server-config.xml");
				RemotingConfiguration.RegisterWellKnownServiceType(typeof(Internetwork), "iHomeRemote", WellKnownObjectMode.SingleCall);
			}
			catch {throw;}	
		}
		public void Stop()
		{
			Console.WriteLine("iHome Server Stop...");
			// Free resource
			try
			{
				if (hw!=null) 
				{
					hw.Unloading();
					hw = null;
				}
				if (cam!=null) 
				{
					cam.Dispose();
					cam = null;
				}
				RemotingConfigurationHelper.UnregisterWellKnownServiceType(typeof(Internetwork), "iHomeRemote");
			}
			catch {throw;};
		}
		public void ViewCamGui()
		{
			cam = new cameraview();
			cam.ShowDialog();		
		}
		public void Exit()
		{
			homeGui.Dispose();
			Application.Exit();
		}
		~Server()
		{
			Stop();
		}		
	}
}

