using System;
using System.Data.OleDb;
using System.Data;
using System.Xml;
using iHome.EventScheduler;
namespace iHome
{
	class DBConn
	{
		#region ### Hardware Command ###
		public static string strCon = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source="+System.IO.Directory.GetCurrentDirectory()+@"\iHome.mdb;";
		private OleDbConnection conn;
		public DBConn()	{}
		
		#endregion

		#region Tools
		// ��� Mac ������
		public string getListMac()
		{
			string result = "";
			string sqlstr = @"Select mac from Hdev";

			conn = new OleDbConnection(strCon);
			conn.Open();			
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataReader reader;
			reader = com.ExecuteReader();
			while (reader.Read())
			{
				result += reader[0].ToString()+",";
			}
			conn.Close();
			return result;
		}

		// ��� address ������
		public string getListAddr()
		{
			string result = "";
			string sqlstr = @"Select address from HChannel";

			conn = new OleDbConnection(strCon);
			conn.Open();			
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataReader reader;
			reader = com.ExecuteReader();
			while (reader.Read())
			{
				result += reader[0].ToString()+",";
			}
			conn.Close();
			return result;
		}

		// �ӹǹ channels �ͧ���� Device
		public int getChannels(string mac)
		{
			string sqlstr = string.Format(@"Select channels from HDev Where mac='{0}'",mac);
			
			try
			{
				string result;
				conn = new OleDbConnection(strCon);
				conn.Open();			
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;			
				OleDbDataReader reader;
				reader = com.ExecuteReader();
				reader.Read();
				result = reader[0].ToString();
				conn.Close();
				return Int32.Parse(result);
			}
			catch
			{
				return 0;
			}
		}
		// ��� address �ͧ mac
		public string getAddress(string mac,int channel)
		{
			string sqlstr = string.Format(@"Select address from HChannel Where (mac='{0}') AND (channel={1})",mac,channel);
			
			try
			{
				string result;
				conn = new OleDbConnection(strCon);
				conn.Open();			
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;			
				OleDbDataReader reader;
				reader = com.ExecuteReader();
				reader.Read();
				result = reader[0].ToString();
				conn.Close();
				return result;
			}
			catch
			{
				return null;
			}
		}
		// �ŧ���� model �� Model_Name
		public string getModelName(string model_code)
		{
			string sqlstr = string.Format(@"Select name from DevModel Where model_code='{0}'",model_code);
			
			try
			{
				string result;
				conn = new OleDbConnection(strCon);
				conn.Open();			
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;			
				OleDbDataReader reader;
				reader = com.ExecuteReader();
				reader.Read();
				result = reader[0].ToString();
				conn.Close();
				return result;
			}
			catch
			{
				return "";
			}
		}
		// ��� Mac,Channel
		public string[] getMacChan(string addr)
		{
			try
			{
				string sqlstr = string.Format(
					@"Select mac,channel from HChannel WHERE  (address = '{0}')",addr);

				conn = new OleDbConnection(strCon);
				conn.Open();
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;

				OleDbDataReader reader;
				reader = com.ExecuteReader();

				string[] result = new string[2];	
				reader.Read();
				result[0] = reader[0].ToString();
				result[1] = reader[1].ToString();					
				return result;

			}
			catch
			{
				// error !
				//Console.WriteLine("Error : getMacChan({0})",addr);
				return null;
			}
		}

		// ��� Filed �ͧ�ػ�ó�  ����Ѻ�觤�� Reconfig ���� Register
		public string getFieldDevConfig(string mac,int field_mode)
		{
			string sqlstr = "";
			string result = "";

			switch (field_mode)
			{
				case 0: //power
					sqlstr = string.Format(
						@"SELECT power From iSwDev,HChannel Where mac='{0}' and addr = address order by channel",mac);
					break;
				case 1: //dimlevel
					sqlstr = string.Format(
						@"SELECT dim_level From iDimDev,HChannel Where mac='{0}' and addr = address order by channel",mac);
					break;
				case 2: // cam

					break;
				case 3: // alert channel
					sqlstr = string.Format(
						@"SELECT power From iSecurityDev,HChannel Where mac='{0}' and addr = address order by channel",mac);
					break;
				default://status
					break;
			}

			conn = new OleDbConnection(strCon);
			conn.Open();
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;

			OleDbDataReader reader;
			reader = com.ExecuteReader();
			while (reader.Read())
			{
				result += reader[0].ToString() + ",";
			}
			
			return result;
		}
		public object execSQLScalar(string sqlstr)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;	
				object result = com.ExecuteScalar();
				conn.Close();
				return result;			
			}
			catch
			{
				// error !
			}
			return null;
		}
		public bool execSQLnoQuery(string sqlstr)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;		
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}
		#endregion

		#region Retrieve Data
		// ������ Virtual device ���������
		public string ListDevice(int mode,bool refresh)
		{
			// force to refresh database 
			// if (refresh) then update database

			conn = new OleDbConnection(strCon);
			conn.Open();

			string sqlstr = "";
			switch (mode)
			{
				//all
				case 0:	sqlstr = @"select model,name,address,status from hdev,hchannel where hdev.mac=hchannel.mac and hdev.model <> '04' order by regis_no DESC";
						break;
				//model - SW
				case 1: sqlstr = @"select model,name,address,power,status from iSwDev,hchannel,hDev where hdev.mac=hchannel.mac and address = addr and model = '00' order by regis_no DESC";
						break;
				//model - SW-Dim
				case 2: sqlstr = @"select model,name,address,dim_level,status from hDev,iDimDev,hchannel where hdev.mac=hchannel.mac and address=addr and model = '01' order by regis_no DESC";
						break;
				//model - CameraCtl
				case 3: sqlstr = @"select model,hChannel.name,address,cap_time,status from hDev,iCameraDev,hchannel where hdev.mac=hchannel.mac and address=addr and model = '02' order by regis_no DESC";
						break;
				//model - Security
				case 4: sqlstr = @"select model,name,address,security_alert,power,status from hDev,iSecurityDev,hchannel where hdev.mac=hchannel.mac and address=addr and model = '03' order by regis_no DESC";
						break;
				// Camera device USB / CARD
				case 5: sqlstr = @"select name,details,port,cap_time,enable from iCamCard order by port";
					break;
				default: sqlstr = @"select model,name,address,status from hdev,hchannel where hdev.mac=hchannel.mac order by regis_no DESC";
						break;
			}

			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Device_List");			
			adap.SelectCommand = com;
			adap.Fill(result,"Device");
			conn.Close();

			return result.GetXml();
		}

		// **** ������ device ���������
		public string ListHDev(int mode,bool refresh)
		{
			// force to refresh database 
			// if (refresh) then update database
			string sqlstr = "";
			switch (mode)
			{
				// all
				case 0:	sqlstr = @"select mac,model,channels,pos,status from hdev";
					break;
				// new only
				//case 1: sqlstr = @"select mac,model,channels,pos from hdev";
				//break;
			}

			conn = new OleDbConnection(strCon);
			conn.Open();		
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("HDev");
			adap.SelectCommand = com;
			adap.Fill(result,"Device");
			conn.Close();

			return result.GetXml();
		}

		// **** ������ Virtual Device ���ҧ�����´ 
		public string ListDevProperty(string address)
		{
			string sqlstr = string.Format("Select model from hdev,hchannel where address='{0}' and hchannel.mac=hdev.mac",address);
			conn = new OleDbConnection(strCon);
			conn.Open();		
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;

			OleDbDataReader reader;
			reader = com.ExecuteReader();			
			reader.Read();
			switch (reader.GetString(0))
			{
				case "00":	// sw
						sqlstr = string.Format("Select model,hdev.mac,address,name,pos,power,status from iSwDev,hdev,hchannel where address='{0}' and address = addr and hchannel.mac=hdev.mac",address);
						break;
				case "01":	// dim
						sqlstr = string.Format("Select model,hdev.mac,address,name,pos,dim_level,status from iDimDev,hdev,hchannel where address='{0}' and address = addr and hchannel.mac=hdev.mac",address);
						break;
				case "02":	// camCtl
						sqlstr = string.Format("Select model,hdev.mac,address,name,pos,cap_program,cap_time,motion_mode,status from iCameraDev,hdev,hchannel where address='{0}' and address = addr and hchannel.mac=hdev.mac",address);
						break;
				case "03": // security
						sqlstr = string.Format("Select model,hdev.mac,address,name,pos,security_alert,status from iSecurityDev,hdev,hchannel where address='{0}' and address = addr and hchannel.mac=hdev.mac",address);
						break;
				default:sqlstr = "";
						break;
			}
			conn.Close();
			conn.Open();
			com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("DevProperty");
			adap.SelectCommand = com;
			adap.Fill(result);
			conn.Close();
			return result.GetXml();
		}

		#endregion

		#region Edit Database
		// ���� Device ����
		public bool ins_NewHdev(string mac,string model,string channels)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				string sqlstr = string.Format(
					"INSERT INTO HDev(mac, model,channels) VALUES ('{0}','{1}',{2})",mac,model,channels);
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;			
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();

					// �������Ѻ��㹡������
					string addrList = getListAddr();
					string strClass = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";					
					int iC,iG;

					for (int i=0;i<Int32.Parse(channels);i++)
					{
						// ������� Addr �������ӡѺ� DB
						string addr;
						do
						{
							Random ran = new Random();
							iC = ran.Next(strClass.Length);
							iG = ran.Next(strClass.Length);
							addr = strClass.Substring(iC,1)+strClass.Substring(iG,1);
						} while (addrList.IndexOf(addr) != -1);
						addrList += addr;  // ������� addr ���������������
						
						// �纤��ŧ� DB
						sqlstr = string.Format(
							"INSERT INTO HChannel(mac, channel,address,name) VALUES ('{0}',{1},'{2}','{3}')",
							mac,i+1,addr,getModelName(model)+" At:"+mac);
						conn.Open();						
						com = new OleDbCommand(sqlstr,conn);
						com.CommandType = CommandType.Text;
						// ���ҧ������� Device
						if (com.ExecuteNonQuery()>0) 
						{
							conn.Close();
							switch (model)
							{
								case "00":	// switch
									sqlstr = string.Format(
										"INSERT INTO iSwDev(addr,power) VALUES ('{0}',{1})",addr,0);
									break;
								case "01":	// dim
									sqlstr = string.Format(
										"INSERT INTO iDimDev(addr,dim_level) VALUES ('{0}',{1})",addr,0);
									break;
								case "02":	// cam
									sqlstr = string.Format(
										"INSERT INTO iCameraDev(addr,detail,enable)"+
										"VALUES ('{0}','{1}',{2})",addr,"",0);
									break;
								case "03":	// security
									sqlstr = string.Format(
										"INSERT INTO iSecurityDev(addr,security_alert,power)"+
										"VALUES ('{0}',{1},{2})",addr,0,0);
									break;

							}
							conn.Open();
							com = new OleDbCommand(sqlstr,conn);
							com.CommandType = CommandType.Text;
							if (com.ExecuteNonQuery()>0) conn.Close();
						}
					}
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}

		// ��䢪��� ���� Channel
		public bool update_NameDevice(string addr,string new_name)
		{
			string[] tmp = getMacChan(addr);
			if (tmp==null) return false;
			string sqlstr = string.Format(
				@"UPDATE HChannel SET name = '{0}' WHERE mac = '{1}' and channel = {2}",new_name,tmp[0],tmp[1]);
			return execSQLnoQuery(sqlstr);
		}
		// ��� Address
		public bool update_Address(string new_addr,string old_addr)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				string sqlstr = string.Format(
					@"UPDATE HChannel SET address = '{0}' WHERE  (address = '{1}')",new_addr,old_addr);
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;		
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}
		// **** ��ͧ���  ��� Status
		public bool update_Power(int new_status,string addr)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				string sqlstr = string.Format(
					@"UPDATE iSwDev SET power = {0} WHERE  addr = '{1}'",new_status,addr);
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;		
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}
		public bool update_Status2(string new_status,string mac,string channel)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				string sqlstr = string.Format(
					@"UPDATE HChannel SET status = {0} WHERE  (mac = '{1}') AND (channel={2})",new_status,mac,channel);
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;		
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}
		// ��� Dim level
		public bool update_DimLevel(int new_level,string addr)
		{
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				string sqlstr = string.Format(
					@"UPDATE iDimDev SET dim_level = {0} WHERE  addr = '{1}'",new_level,addr);
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;		
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}
		// ��� Security Alert
		/*public bool update_Alert(int Alert_status,string addr)
		{	// 0 = normal,1 = alert
			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();
				string sqlstr = string.Format(
					@"UPDATE iSecurityDev SET security_alert = {0} WHERE mac = '{1}')",Alert_status,addr);
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;		
				if (com.ExecuteNonQuery()>0)
				{
					conn.Close();
					return true;
				}				
			}
			catch
			{
				// error !
			}
			return false;
		}*/
		
		#endregion		
		
		#region WebService Schedule
		public string ListSchedulesByType(int mode)
		{
			string sqlstr = "";
			switch (mode)
			{
					//All
				case 5:	sqlstr = @"Select name.name,type,next_time,days,addr,cmd,param from iSchedule name,iScheduleType b where type=b.id";
					break;
					//Once
				case 0:	sqlstr = @"Select name.name,type,next_time,days,addr,cmd,param from iSchedule name,iScheduleType b where type=0 and type=b.id";
					break;
					//Daily
				case 1: sqlstr = @"Select name.name,type,next_time,addr,cmd,param from iSchedule name,iScheduleType b where type=1 and type=b.id";
					break;
					//Weekly
				case 2: sqlstr = @"Select name.name,type,next_time,addr,cmd,param from iSchedule name,iScheduleType b where type=2 and type=b.id";
					break;
					//Monthly
				case 3: sqlstr = @"Select name.name,type,next_time,addr,cmd,param from iSchedule name,iScheduleType b where type=3 and type=b.id";
					break;
					// Times
				case 4: sqlstr = @"Select name.name,type,next_time,addr,param from iSchedule name,iScheduleType b where type=4 and type=b.id";
					break;
				default: goto case 5;
					
			}
			conn = new OleDbConnection(strCon);
			conn.Open();		
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Schedule");
			adap.SelectCommand = com;
			int row = adap.Fill(result);
			conn.Close();
			if (row == 0) return "null";
			return result.GetXml();
		}
		
		public string ListSchedulesByDev(string address,int mode)
		{
			string sqlstr = "";
			conn = new OleDbConnection(strCon);
			
			switch (mode)
			{
				case 4:
					//all
					sqlstr = string.Format("Select name.name,type,next_time,days,cmd,param from iSchedule name,iScheduleType b where addr='{0}' and type=b.id",address);
					break;
				case 0:
					//once
					sqlstr = string.Format("Select name.name,type,next_time,cmd,param from iSchedule name,iScheduleType b where addr='{0}' and type=0 and type=b.id",address);
					break;
				case 1:
					//daily
					sqlstr = string.Format("Select name.name,type,next_time,days,cmd,param from iSchedule name,iScheduleType b where addr='{0}' and type=1 and type=b.id",address);
					break;
				case 2:
					//Weekly
					sqlstr = string.Format("Select name.name,type,next_time,cmd,param from iSchedule name,iScheduleType b where addr='{0}' and type=2 and type=b.id",address);
					break;
				case 3:
					//monthly
					sqlstr = string.Format("Select name.name,type,next_time,cmd,param from iSchedule name,iScheduleType b where addr='{0}' and type=3 and type=b.id",address);
					break;
				default: goto case 4;
			}
			conn = new OleDbConnection(strCon);
			conn.Open();
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Schedule");
			adap.SelectCommand = com;
			int row = adap.Fill(result);
			conn.Close();
			if (row == 0) return "null";
			return result.GetXml();
		}

		
		#endregion

		#region Camera		
		/*public string getRootSavePath()
		{
			string result = "";
			string sqlstr = @"Select image_root_path from iSetting";

			conn = new OleDbConnection(strCon);
			conn.Open();			
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			result = (String)com.ExecuteScalar();
			conn.Close();
			return result;
		}
		public string getRootHttpPath()
		{
			string result = "";
			string sqlstr = @"Select image_http_path from iSetting";

			conn = new OleDbConnection(strCon);
			conn.Open();			
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			result = (String)com.ExecuteScalar();
			conn.Close();
			return result;
		}*/
		public bool UpdatePortCamera(int old_port,int new_port)
		{
			string sqlstr = string.Format(
				@"UPDATE iCamCard SET port = {0} WHERE port = {1})",new_port,old_port);
			return execSQLnoQuery(sqlstr);		
		}
		public bool UpdateCapTimeCamera(int port,int cap_time)
		{
			string sqlstr = string.Format(
				@"UPDATE iCamCard SET cap_time = {0} WHERE port = {1}",cap_time,port);
			return execSQLnoQuery(sqlstr);
		}
		public bool InsertCapCamera(string name,string details,int port,int cap_time,int enable)
		{
			/*string sqlstr = string.Format(
				"INSERT INTO iCamera(addr,detail,port,cap_time,cap_program,enable"+
				"VALUES ('{0}','{1}',{2},{3},'{4}',{5})",
				addr,detail,port,cap_time,"",enable);*/
			string sqlstr = string.Format(
				"INSERT INTO iCamCard(name,details,port,cap_time,enable)"+
				"VALUES ('{0}','{1}',{2},{3},{4})",
				name,details,port,cap_time,enable);
			return execSQLnoQuery(sqlstr);		
		}
		public bool RemoveCapCamera(int port)
		{
			string sqlstr = string.Format(
				"DELETE FROM iCamCard WHERE port={0}",port);
			if (execSQLnoQuery(sqlstr))	return true;			
			return false;
		}
		public string ViewCamera()
		{
			conn = new OleDbConnection(strCon);
			conn.Open();

			string sqlstr = @"Select port,name,details,cap_time from iCamCard order by port";

			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Camera_List");			
			adap.SelectCommand = com;
			adap.Fill(result,"ListCamera");
			conn.Close();

			return result.GetXml();
		}

		#endregion

		#region security
		
		public bool SetSecurityLevel(string addr,int level)
		{
			try
			{
				string sqlstr = string.Format(
					@"UPDATE iSecurityDev SET security_alert = {0} WHERE  (addr = '{1}')",level,addr);
				return execSQLnoQuery(sqlstr);			
			}
			catch
			{
				return false;
			}
		}
		public bool ResetAllSecurityLevel()
		{
			try
			{
				string sqlstr = string.Format(
					@"UPDATE iSecurityDev SET security_alert = 0");
				return execSQLnoQuery(sqlstr);			
			}
			catch
			{
				return false;
			}
		}
		#endregion

		#region Setting
		public bool SetSmsNumber(string smsno)
		{
			string sqlstr = string.Format(
				@"UPDATE iSetting SET sms_number = '{0}'",smsno);
			return execSQLnoQuery(sqlstr);
		}
		public string getSmsNumber()
		{
			DBConn db = new DBConn();
			string sqlstr = @"Select sms_number From iSetting";
			return (string)db.execSQLScalar(sqlstr);
		}
		public bool SetPort(int port)
		{
			if (port<=0 || port >= 10) return false;			
			string sqlstr = string.Format(
				@"UPDATE iSetting SET serial_port = {0}",port);
			return execSQLnoQuery(sqlstr);
		}		
		// ��� local path save cam
		public bool setLocalCamSavePath(string path)
		{
			string sqlstr = string.Format(
				@"UPDATE iSetting SET image_root_path = '{0}'",path);
			return execSQLnoQuery(sqlstr);
		}
		// ��� Url path save cam
		public bool setURLCamSavePath(string path)
		{
			string sqlstr = string.Format(
				@"UPDATE iSetting SET image_http_path = '{0}'",path);
			return execSQLnoQuery(sqlstr);
		}
		// ��� serial port
		public int GetPort()
		{
			string sqlstr = "Select serial_port from iSetting";
			object result = execSQLScalar(sqlstr);
			if (result == null || result.Equals(System.DBNull.Value)) 
			{
				// set init value to program dir
				SetPort(1);
				return 1;
			}
			else return (int)result;
		}
		// ��� local path save cam
		public string getLocalCamSavePath()
		{
			string sqlstr = @"Select image_root_path From iSetting";
			object result = execSQLScalar(sqlstr);
			if (result == null || result.Equals(System.DBNull.Value)) 
			{
				// set init value to program dir
				string path = System.Environment.CurrentDirectory+"\\webcam\\";
				setLocalCamSavePath(path);
				return path;
			}
			else return (string)result;
		}
		// ��� Url path save cam
		public string getURLCamSavePath()
		{
			string sqlstr = @"Select image_http_path From iSetting";
			object result = execSQLScalar(sqlstr);
			if (result == null || result.Equals(System.DBNull.Value)) 
			{
				// set init value to program dir
				string path = "http://localhost/notset/";
				setLocalCamSavePath(path);
				return path;
			}
			else return (string)result;
		}

		#endregion
		
		#region EventBox
		public bool AddEventBox(int event_id,string name,string address,int cmd,string param)
		{
			string sqlstr = string.Format(
				"INSERT INTO iEvent(event_id,name,address,cmd,param) VALUES ({0},'{1}','{2}','{3}','{4}')",event_id,name,address,cmd,param);
			if (execSQLnoQuery(sqlstr))	return true;
			else return false;
		}
		public bool RemoveEventBox(int no)
		{
			string sqlstr = string.Format(
				"DELETE FROM iEvent WHERE event_no={0}",no);
			if (execSQLnoQuery(sqlstr))	return true;			
			return false;
		}
		public string[,] getEventBoxInvoke(int event_id)
		{
			try
			{
				string sqlstr = string.Format(
					@"Select name,address,cmd,param from iEvent WHERE  (event_id = {0})",event_id);

				conn = new OleDbConnection(strCon);
				conn.Open();

				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;			
				OleDbDataAdapter adap = new OleDbDataAdapter();
				DataSet result = new DataSet();			
				adap.SelectCommand = com;
				adap.Fill(result,"Table");
				conn.Close();

				//string results = "";
				int numrow = result.Tables["Table"].Rows.Count;	
				int numcol = result.Tables["Table"].Columns.Count;
				if (numrow>0)
				{
					string[,] data = new string[numrow,numcol];
					for (int i=0;i<numrow;i++)
					{
						data[i,0] = result.Tables[0].Rows[i][0].ToString();
						data[i,1] = result.Tables[0].Rows[i][1].ToString();
						data[i,2] = result.Tables[0].Rows[i][2].ToString();
					}
					return data;
				}
			}
			catch
			{
				// error !
				
			}
			return null;
		}

		
		public string ViewMacro()
		{
			conn = new OleDbConnection(strCon);
			conn.Open();

			string sqlstr = @"SELECT event_no,Source.address,event_type,Target.address,cmd,param from iEvent Target,iEventMonitor Source where Source.event_id = Target.event_id order by Source.Address,Target.event_id,cmd,param";
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Macro_List");			
			adap.SelectCommand = com;
			adap.Fill(result,"ListEventMacro");
			conn.Close();

			return result.GetXml();
		}
		/*public string ViewEventMonitor()
		{
			conn = new OleDbConnection(strCon);
			conn.Open();

			string sqlstr = @"SELECT address,cmd,param,event_id from iEvent order by address,cmd,param,event_id";

			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Device_List");			
			adap.SelectCommand = com;
			adap.Fill(result,"ListEventMonitor");
			conn.Close();

			return result.GetXml();
		}*/
		#endregion

		#region EventMonitor
		public int getEventID(string addr,int event_type)
		{
			string sqlstr = string.Format(@"Select event_id from iEventMonitor Where (address='{0}') AND (event_type={1})",addr,event_type);
			
			try
			{
				int result;
				conn = new OleDbConnection(strCon);
				conn.Open();			
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;			
				result = (int)com.ExecuteScalar();
				conn.Close();
				return result;
			}
			catch
			{
				return -1;
			}			
		}
		public bool RegisEvent(string address,int cmd)
		{
			string sqlstr = string.Format(
				"INSERT INTO iEventMonitor(address,event_type) VALUES ('{0}',{1})",address,cmd);
			if (execSQLnoQuery(sqlstr))	return true;
			else return false;
		}
		public bool UnRegisEvent(int event_id)
		{
			string sqlstr = string.Format(
				"DELETE FROM iEventMonitor WHERE event_id={0}",event_id);
			if (execSQLnoQuery(sqlstr))	return true;			
			return false;
		}
		#endregion

		#region Scheduler
		public bool AddSchedule(Schedule s)
		{
			string workdays = "";
			for (int i=0;i<7;i++)
			{
				if (s.WeekDayActive((DayOfWeek)i)) workdays += "1";
				else workdays += "0";
			}
			string sqlstr = string.Format(
				"INSERT INTO iSchedule(name,type,next_time,days,addr,cmd,param) VALUES ('{0}',{1},'{2}','{3}','{4}','{5}','{6}')",s.Name,(int)s.Type,s.StartTime,workdays,s.Addr,s.Cmd,s.Param);
			if (execSQLnoQuery(sqlstr))	return true;
			else return false;
		}
		public bool RemoveSchedule(Schedule s)
		{
			string sqlstr = string.Format(
				"DELETE FROM iSchedule WHERE name='{0}'",s.Name);
			if (execSQLnoQuery(sqlstr))	return true;			
			return false;
		}
		public bool UpdateSchedule(Schedule s)
		{
			string sqlstr = string.Format(
				"Update iSchedule SET next_time='{0}' WHERE name='{1}'",s.NextInvokeTime,s.Name);
			if (execSQLnoQuery(sqlstr))	return true;
			return false;
		}

		public void UpdateVarNextTime(string ScheduleName,DateTime NextTime)
		{
			string sqlstr = string.Format(
				"Update iSchedule SET next_time='{0}' WHERE name='{1}'",NextTime,ScheduleName);
			if (!execSQLnoQuery(sqlstr))
				throw new SchedulerException("UpdateVarNext_time Error!");

		}
		public void UpdateVarName(string ScheduleName,string NewName)
		{
			string sqlstr = string.Format(
				"Update iSchedule SET name='{0}' WHERE name='{1}'",NewName,ScheduleName);
			if (!execSQLnoQuery(sqlstr))
				throw new SchedulerException("UpdateVarName Error!");
		}
		public void UpdateVarIsActive(string NewName,bool Active)
		{
			string sqlstr = string.Format(
				"Update iSchedule SET is_active={0} WHERE name='{1}'",Active,NewName);
			if (!execSQLnoQuery(sqlstr))
				throw new SchedulerException("UpdateVarIsActive Error!");
		}
		public void UpdateVarWeekdays(string name,string weekdays)
		{
			string sqlstr = string.Format(
				"Update iSchedule SET days={0} WHERE name='{1}'",name,weekdays);
			if (!execSQLnoQuery(sqlstr))
				throw new SchedulerException("UpdateVarVarWeekdays Error!");
		}
		/*public void UpdateVarcmd(string name,string addr,int cmd,string param)
		{
			string sqlstr = string.Format(
				"Update iSchedule SET cmd={0} WHERE name='{1}'",name,cmd);
			if (!execSQLnoQuery(sqlstr))
				throw new SchedulerException("UpdateVarCmd Error!");
		}*/
		#endregion

		#region WebPage
		public string wListDevice(int mode)
		{
			// force to refresh database 
			// if (refresh) then update database

			conn = new OleDbConnection(strCon);
			conn.Open();

			string sqlstr = "";
			switch (mode)
			{
					//all
				case 0:	sqlstr = @"select model,name,address,hdev.mac,channel,pos,status from hdev,hchannel where hdev.mac=hchannel.mac order by status DESC,regis_no DESC";
					break;
					//model - SW
				case 1: sqlstr = @"select model,name,address,hdev.mac,channel,pos,power,status from iSwDev,hchannel,hDev where hdev.mac=hchannel.mac and address = addr and model = '00' order by status DESC,regis_no DESC";
					break;
					//model - SW-Dim
				case 2: sqlstr = @"select model,name,address,hdev.mac,channel,pos,dim_level,status from hDev,iDimDev,hchannel where hdev.mac=hchannel.mac and address=addr and model = '01' order by status DESC,regis_no DESC";
					break;
					//model - CameraCtl
				case 3: sqlstr = @"select model,hChannel.name,address,hdev.mac,channel,pos,port,cap_time,status from hDev,iCameraDev,hchannel where hdev.mac=hchannel.mac and address=addr and model = '02' order by status DESC,regis_no DESC";
					break;
					//model - Security
				case 4: sqlstr = @"select model,name,address,hdev.mac,channel,pos,security_alert,power,status from hDev,iSecurityDev,hchannel where hdev.mac=hchannel.mac and address=addr and model = '03' order by status DESC,regis_no DESC";
					break;
					// Camera device USB / CARD
				case 5: sqlstr = @"select name,details,port,cap_time,enable from iCamCard order by port";
					break;
				default: sqlstr = @"select model,name,address,mac,channel,pos,,status from hdev,hchannel where hdev.mac=hchannel.mac order by status DESC,regis_no DESC";
					break;
			}

			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;			
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Device_List");			
			adap.SelectCommand = com;
			adap.Fill(result,"Device");
			conn.Close();

			return result.GetXml();
		}
		public string wListSchedulesByType(int mode)
		{
			string sqlstr = "";
			switch (mode)
			{
					//All
				case 4:	sqlstr = @"Select name.name,type,next_time,days,addr,cmd,param from iSchedule name,HChannel where type=b.id";
					break;
					//Once
				case 0:	sqlstr = @"Select name.name,type,next_time,addr,cmd,param from iSchedule name,iScheduleType b where type=0 and type=b.id";
					break;
					//Daily
				case 1: sqlstr = @"Select name.name,type,next_time,addr,days,cmd,param from iSchedule name,iScheduleType b where type=1 and type=b.id";
					break;
					//Weekly
				case 2: sqlstr = @"Select name.name,type,next_time,addr,days,cmd,param from iSchedule name,iScheduleType b where type=2 and type=b.id";
					break;
					//Monthly
				case 3: sqlstr = @"Select name.name,type,next_time,addr,cmd,param from iSchedule name,iScheduleType b where type=3 and type=b.id";
					break;
				default: goto case 4;
					
			}
			conn = new OleDbConnection(strCon);
			conn.Open();		
			OleDbCommand com = new OleDbCommand(sqlstr,conn);
			com.CommandType = CommandType.Text;
			OleDbDataAdapter adap = new OleDbDataAdapter();
			DataSet result = new DataSet("Schedule");
			adap.SelectCommand = com;
			int row = adap.Fill(result);
			conn.Close();
			//if (row == 0) return "null";
			return result.GetXml();
		}
		#endregion

	}
}