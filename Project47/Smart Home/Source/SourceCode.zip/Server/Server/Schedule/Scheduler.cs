using System;
using System.Threading;
using System.Collections;

namespace iHome.EventScheduler
{
	// enumeration of Scheduler events used by the delegate
	public enum SchedulerEventType { CREATED, DELETED, INVOKED };

	// delegate for Scheduler events
	public delegate void SchedulerEventDelegate(SchedulerEventType type, string scheduleName);

	// This is the main class which will maintain the list of Schedules
	// and also manage them, like rescheduling, deleting schedules etc.
	public sealed class Scheduler
	{
		// Event raised when for any event inside the scheduler
		static public event SchedulerEventDelegate OnSchedulerEvent;

		// next event which needs to be kicked off,
		// this is set when a new Schedule is added or after invoking a Schedule
		static Schedule m_nextSchedule = null;
		static ArrayList  m_schedulesList = new ArrayList(); // list of schedles
		static Timer m_timer = new Timer(new TimerCallback(DispatchEvents), // main timer
			null,
			Timeout.Infinite,
			Timeout.Infinite);

		// Get schedule at a particular index in the array list
		public static Schedule GetScheduleAt(int index)
		{
			if (index < 0 || index >= m_schedulesList.Count)
				return null;
			return (Schedule)m_schedulesList[index];
		}

		// Number of schedules in the list
		public static int Count()
		{
			return m_schedulesList.Count;
		}

		// Indexer to access a Schedule object by name
		public static Schedule GetSchedule(string scheduleName)
		{
			for (int index=0; index < m_schedulesList.Count; index++)
				if (((Schedule)m_schedulesList[index]).Name == scheduleName)
					return (Schedule)m_schedulesList[index];
			return null;
		}

		// call back for the timer function
		static void DispatchEvents(object obj) // obj ignored
		{
			if (m_nextSchedule == null)
				return;
			m_nextSchedule.TriggerEvents(); // make this happen on a thread to let this thread continue
			if (m_nextSchedule.Type == ScheduleType.ONETIME)
			{
				RemoveSchedule(m_nextSchedule); // remove the schedule from the list
			}
			else
			{
				if (OnSchedulerEvent != null)
					OnSchedulerEvent(SchedulerEventType.INVOKED, m_nextSchedule.Name);
				m_schedulesList.Sort();
				SetNextEventTime();
			}
		}

		// method to set the time when the timer should wake up to invoke the next schedule
		static void SetNextEventTime()
		{
			if (m_schedulesList.Count == 0)
			{
				m_timer.Change(Timeout.Infinite, Timeout.Infinite); // this will put the timer to sleep
				return;
			}
			m_nextSchedule = (Schedule)m_schedulesList[0];
			TimeSpan ts = m_nextSchedule.NextInvokeTime.Subtract(DateTime.Now);
			if (ts < TimeSpan.Zero)
				ts = TimeSpan.Zero; // cannot be negative !
			m_timer.Change((long)ts.TotalMilliseconds, Timeout.Infinite); // invoke after the timespan
		}

		// Update a new schedule
		public static void AddScheduleArray(Schedule s)
		{
			s.OnNextTime += new NextTimeEvent(UpdateNextTime);
			DBConn db = new DBConn();
			if (!db.UpdateSchedule(s))
				throw new SchedulerException("Update Schedule DB Fail");

			if (GetSchedule(s.Name) != null)
				throw new SchedulerException("Schedule with the same name already exists");
			m_schedulesList.Add(s);
			m_schedulesList.Sort();
			// adjust the next event time if schedule is added at the top of the list
			if (m_schedulesList[0] == s)
				SetNextEventTime();
			if (OnSchedulerEvent != null)
				OnSchedulerEvent(SchedulerEventType.CREATED, s.Name);
		}
		// add a new schedule
		public static void AddSchedule(Schedule s)
		{
			DBConn db = new DBConn();
			if (!db.AddSchedule(s))
				throw new SchedulerException("Add schedule to DB Fail");
			AddScheduleArray(s);
		}
		// remove a schedule object from the list
		public static void RemoveSchedule(Schedule s)
		{
			if (s!=null)
			{
				DBConn db = new DBConn();
				if (!db.RemoveSchedule(s))
					throw new SchedulerException("Remove schedule from DB Fail");
				m_schedulesList.Remove(s);
				SetNextEventTime();
				if (OnSchedulerEvent != null)
					OnSchedulerEvent(SchedulerEventType.DELETED, s.Name);
			}
		}
		// remove schedule by name
		public static void RemoveSchedule(string name)
		{
			RemoveSchedule(GetSchedule(name));
		}
		public static void UnloadFromMem()
		{
			m_schedulesList.Clear();
		}
		// �Ӥ�� NextTime DB ����ա�õ�駤������������ŧ database
		private static void UpdateNextTime(string name)
		{
			DBConn db = new DBConn();
			db.UpdateVarNextTime(name,GetSchedule(name).NextInvokeTime);
		}

		// ��駤��  CMD DB
		/*public static void UpdateCmd(string name,string cmd)
		{
			DBConn db = new DBConn();
			db.UpdateVarcmd(name,cmd);	
		}	*/
		// ��駤�� Weekdays DB** ��Ѻ Daily ��ҹ�� ( weekdays �ռŵ�͡�äӹǳ���ҷӧҹ�ѧ���
		// �е�ͧ�ա�û�Ѻ������� ����ӴѺ������� )
		/*public static void UpdateWeekday(string name,string weekdays)
		{
			DBConn db = new DBConn();
			db.UpdateVarWeekdays(name,weekdays);
			Schedule s = GetSchedule(name);
			s.SetWeekDay(weekdays);
			m_schedulesList.Sort();
			// ��駤������繵�Ƿӧҹ�Ѵ件�������ӴѺ�á�ش ����ѹ�Ѻ�������ͧ��Ѻ��ا ������Ѻ�ó� add
			if (m_schedulesList[0] == s)
				SetNextEventTime();
		}*/
		// ��駤�� schedule name
		/*public static bool UpdateName(string OldName,string NewName)
		{
			Schedule s = GetSchedule(OldName);
			if (s != null) 
			{
				//throw new SchedulerException("Not Found old name : "+OldName);
				return false;
			}
			s.Name = NewName;
			return true;
		}
		// ��駤�� Active
		public static bool UpdateActive(string name,bool active)
		{
			Schedule s = GetSchedule(name);
			if (s != null) 
			{
				//throw new SchedulerException("Not Found schedule name : "+name);
				return false;
			}
			s.Active = active;
			return true;
		}*/

		/*
		public static bool ChangeSchedule(string name,int type,DateTime nexttime,string days,int command,string info)
		{
			return true;
		}*/
	
		/*private static void RefreshScheduler()
		{
			m_schedulesList.Sort();
			// adjust the next event time if schedule is added at the top of the list
			SetNextEventTime();
		}*/
	
	}
}
