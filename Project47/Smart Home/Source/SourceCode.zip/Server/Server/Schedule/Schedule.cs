using System;
using System.Threading;
namespace iHome.EventScheduler
{
	#region Event
	// Invoke schedule event
	public delegate void Invoke(string scheduleName,string addr,int cmd,string param);
	public delegate void NextTimeEvent(string scheduleName);
	#endregion
	#region Enum
	//schedule types
	public enum ScheduleType { ONETIME, DAILY, WEEKLY, MONTHLY, TIME };
	#endregion
	// base class for all schedules
	abstract public class Schedule : IComparable
	{
		// To be implemented by specific schedule objects when to invoke the schedule next
		internal abstract void CalculateNextInvokeTime();

		#region Member
		public event Invoke OnTrigger;
		public event NextTimeEvent OnNextTime;
		protected string m_name;								// name of the schedule
		protected ScheduleType m_type;							// type of schedule
		protected bool m_active;								// is schedule active ?

		protected DateTime m_startTime;							// time the schedule starts
		protected DateTime m_nextTime;							// time when this schedule is invoked next, 
																//used by scheduler

		private string m_addr;
		private int m_cmd;
		private string m_param;
		bool[] m_workingWeekDays = new bool[]{false, true, true, true, true, true, false};
		#endregion
		#region Accessor
		public ScheduleType Type
		{
			get { return m_type; }
		}

		public string Name 
		{
			get { return m_name; }
			set {m_name = value;}
		}

		public bool Active
		{
			get { return m_active; }
			set 
			{
				if (m_active!=value)
				{
					m_active = value;
				}
			}
		}
		public string Addr
		{
			get {return m_addr;}

		}
		public int Cmd
		{
			get {return m_cmd;}

		}
		public string Param
		{
			get {return m_param;}

		}
		#endregion

		// check if no week days are active
		protected bool NoFreeWeekDay()
		{
			bool check = false;
			for (int index=0; index<7; check = check|m_workingWeekDays[index], index++);
			return check;
		}

		// Setting the status of a week day
		public void SetWeekDay(DayOfWeek day, bool On)
		{
			m_workingWeekDays[(int)day] = On;
			Active = true; // assuming

			// Make schedule inactive if all weekdays are inactive
			// If a schedule is not using the weekdays the array should not be touched
			if (!NoFreeWeekDay())
				Active = false;
		}
		// Setting the status of a week day (using string) 0000000 len=7
		public virtual void SetWeekDay(string days)
		{
			char[] tmp = days.ToCharArray();
			if (days.Length==7)
			{
				for (int i=0;i<7;i++)
				{
					if (tmp[i]=='1') SetWeekDay((DayOfWeek)i,true);
					else SetWeekDay((DayOfWeek)i,false);
				}
			}
		}
		// Return if the week day is set active
		public bool WeekDayActive(DayOfWeek day)
		{
			return m_workingWeekDays[(int)day];
		}

		// Method which will return when the Schedule has to be invoked next
		// This method is used by Scheduler for sorting Schedule objects in the list
		public DateTime NextInvokeTime
		{
			get { return m_nextTime; }
			set {m_nextTime = value;}
		}

		// Accessor for m_startTime
		public DateTime StartTime
		{
			get { return m_startTime; }
			set
			{
				//if (m_type == ScheduleType.ONETIME)
				//{
					// start time can only be in future
					if (value.CompareTo(DateTime.Now) <= 0)
						throw new SchedulerException("Start Time should be in future");
					//m_startTime = value;
				//}else
				else
					m_startTime = value;
			}
		}

		// Constructor
		public Schedule(string name, DateTime startTime, ScheduleType type,string addr,int cmd,string param)
		{
			m_type = type;
			StartTime = startTime;
			m_nextTime = startTime;			
			m_name = name;
			m_addr = addr;
			m_cmd = cmd;
			m_param = param;
		}
		// Sets the next time this Schedule is kicked off and kicks off events on
		// a seperate thread, freeing the Scheduler to continue
		public void TriggerEvents()
		{
			CalculateNextInvokeTime(); // first set next invoke time to continue with rescheduling
			OnNextTime(m_name);
			ThreadStart ts = new ThreadStart(KickOffEvents);
			Thread t = new Thread(ts);
			t.Start();
		}
		// Implementation of ThreadStart delegate.
		// Used by Scheduler to kick off events on a seperate thread
		private void KickOffEvents()
		{
			if (OnTrigger != null)
				OnTrigger(Name,Addr,Cmd,Param);
		}

		// check to see if the Schedule can be invoked on the week day it is next scheduled 
		protected bool CanInvokeOnNextWeekDay()
		{
			return m_workingWeekDays[(int)m_nextTime.DayOfWeek];
		}

		// IComparable interface implementation is used to sort the array of Schedules
		// by the Scheduler
		public int CompareTo(object obj)
		{
			if (obj is Schedule)
			{
				return m_nextTime.CompareTo(((Schedule)obj).m_nextTime);
			}
			throw new Exception("Not a Schedule object");
		}		
	}
}
