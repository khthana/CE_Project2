using System;

namespace iHome.EventScheduler
{
	// OneTimeSchedule is used to schedule an event to run only once
	// Used by specific tasks to check self status
	public class OneTimeSchedule : Schedule
	{
		public OneTimeSchedule(string name, DateTime startTime,string addr,int cmd,string param) 
			: base(name, startTime, ScheduleType.ONETIME,addr,cmd,param)
		{
		}
		internal override void CalculateNextInvokeTime()
		{
			// it does not matter, since this is a one time schedule
			m_nextTime = DateTime.MaxValue;
		}
	}

	// Daily schedule is used set off to the event every day
	// Mainly useful in maintanance, recovery, logging and report generation
	// Restictions can be imposed on the week days on which to run the schedule
	public class DailySchedule : Schedule
	{
		public DailySchedule(string name, DateTime startTime,string days,string addr,int cmd,string param)
			: base(name, startTime, ScheduleType.DAILY,addr,cmd,param)
		{
			if (!days.Equals("0000000"))
				SetWeekDay(days);						
		}
		// Override ���е�ͧ�Ѿന���� nextInvoke
		public override void SetWeekDay(string days)
		{
			// ����¹���
			base.SetWeekDay(days);
			// Adjust nextInvoke time
			while (! CanInvokeOnNextWeekDay())
				m_nextTime = m_nextTime.AddDays(1);		
		}
		internal override void CalculateNextInvokeTime()
		{
			// add a day, and check for any weekday restrictions and keep adding a day
			m_nextTime = m_nextTime.AddDays(1);
			while (! CanInvokeOnNextWeekDay())
					m_nextTime = m_nextTime.AddDays(1);
		}
	}

	// Weekly schedules, useful generally in lazy maintanance jobs and
	// restarting services and others major jobs
	public class WeeklySchedule : Schedule
	{
		public WeeklySchedule(string name, DateTime startTime,string addr,int cmd,string param)
			: base(name, startTime, ScheduleType.WEEKLY,addr,cmd,param)
		{
		}
		// add a week (or 7 days) to the date
		internal override void CalculateNextInvokeTime()
		{
			m_nextTime = m_nextTime.AddDays(7);
		}
	}

	// Monthly schedule - used to kick off an event every month on the same day as scheduled
	// and also at the same hour and minute as given in start time
	public class MonthlySchedule : Schedule
	{
		public MonthlySchedule(string name, DateTime startTime,string addr,int cmd,string param)
			: base(name, startTime, ScheduleType.MONTHLY,addr,cmd,param)
		{
		}
		// add a month to the present time
		internal override void CalculateNextInvokeTime()
		{
			m_nextTime = m_nextTime.AddMonths(1);
		}
	}
	// TimeSchedule
	public class TimeSchedule : Schedule
	{
		public TimeSchedule(string name, DateTime startTime,string addr,int cmd,string param)
			: base(name, startTime, ScheduleType.TIME,addr,cmd,param)
		{
				SetWeekDay("1111111");	//all days					
		}
		internal override void CalculateNextInvokeTime()
		{
			// add a day, and check for any weekday restrictions and keep adding a day
			m_nextTime = m_nextTime.AddMinutes(Int32.Parse(Param));
		}
	}
}
