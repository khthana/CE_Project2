using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using iHome;
namespace iHome.Gui
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class iHomeGui : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtLog;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem mn_BD_CON;
		private System.Windows.Forms.MenuItem mn_BD_DIS;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem mn_What;
		private System.Windows.Forms.MenuItem mn_About;
		private System.Windows.Forms.MenuItem mn_ConfigCam;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem mn_Setting;
		private System.Windows.Forms.Label txtStatus;
		private NotifyIcon m_notifyicon;
		private ContextMenu m_menu; 
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public iHomeGui()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			m_menu = new ContextMenu(); 
			m_menu.MenuItems.Add(0, 
				new MenuItem("Show",new System.EventHandler(Show_Click))); 
			m_menu.MenuItems.Add(1, 
				new MenuItem("Hide",new System.EventHandler(Hide_Click))); 
			m_menu.MenuItems.Add(2, 
				new MenuItem("Exit",new System.EventHandler(Exit_Click)));
			m_menu.MenuItems[1].Enabled = false;	// hide disable

			m_notifyicon = new NotifyIcon();
			m_notifyicon.Text = "iHome Server"; 
			m_notifyicon.Visible = true; 
			//m_notifyicon.Icon = new Icon(GetType(),"iHome.ico");
			m_notifyicon.Icon = new Icon("iHome.ico");
			m_notifyicon.ContextMenu = m_menu;
			m_notifyicon.DoubleClick +=new EventHandler(m_notifyicon_DoubleClick);

			Connect();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				this.m_notifyicon.Dispose();
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtLog = new System.Windows.Forms.TextBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mn_BD_CON = new System.Windows.Forms.MenuItem();
			this.mn_BD_DIS = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.mn_Setting = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mn_ConfigCam = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.mn_What = new System.Windows.Forms.MenuItem();
			this.mn_About = new System.Windows.Forms.MenuItem();
			this.txtStatus = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtLog
			// 
			this.txtLog.Location = new System.Drawing.Point(8, 0);
			this.txtLog.Multiline = true;
			this.txtLog.Name = "txtLog";
			this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtLog.Size = new System.Drawing.Size(272, 56);
			this.txtLog.TabIndex = 0;
			this.txtLog.Text = "";
			this.txtLog.Visible = false;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem4});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem6});
			this.menuItem1.Text = "Program";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mn_BD_CON,
																					  this.mn_BD_DIS,
																					  this.menuItem5,
																					  this.mn_Setting});
			this.menuItem2.Text = "Server";
			// 
			// mn_BD_CON
			// 
			this.mn_BD_CON.Index = 0;
			this.mn_BD_CON.Text = "Start";
			this.mn_BD_CON.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// mn_BD_DIS
			// 
			this.mn_BD_DIS.Index = 1;
			this.mn_BD_DIS.Text = "Stop";
			this.mn_BD_DIS.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 2;
			this.menuItem5.Text = "-";
			// 
			// mn_Setting
			// 
			this.mn_Setting.Index = 3;
			this.mn_Setting.Text = "Setting";
			this.mn_Setting.Click += new System.EventHandler(this.menuItem7_Click_1);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mn_ConfigCam});
			this.menuItem3.Text = "Card/USB";
			// 
			// mn_ConfigCam
			// 
			this.mn_ConfigCam.Index = 0;
			this.mn_ConfigCam.Text = "Config Camera";
			this.mn_ConfigCam.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 2;
			this.menuItem6.Text = "Exit";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 1;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mn_What,
																					  this.mn_About});
			this.menuItem4.Text = "Help";
			// 
			// mn_What
			// 
			this.mn_What.Index = 0;
			this.mn_What.Text = "What \'s this?";
			// 
			// mn_About
			// 
			this.mn_About.Index = 1;
			this.mn_About.Text = "About";
			// 
			// txtStatus
			// 
			this.txtStatus.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtStatus.Location = new System.Drawing.Point(24, 16);
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Size = new System.Drawing.Size(240, 40);
			this.txtStatus.TabIndex = 4;
			this.txtStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// iHomeGui
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 71);
			this.Controls.Add(this.txtStatus);
			this.Controls.Add(this.txtLog);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Menu = this.mainMenu1;
			this.Name = "iHomeGui";
			this.Text = "iHome Server";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.iHomeGui_Closing);
			this.ResumeLayout(false);

		}
		#endregion
		
		public void AddLogBox(string msg)
		{
			txtLog.AppendText(msg+"\n");
		}
		public void Connect()
		{
			try
			{
				Server.server.Start();
				mn_BD_CON.Enabled = false;
				mn_BD_DIS.Enabled = true;
				mn_ConfigCam.Enabled = false;
				mn_Setting.Enabled = false;
				txtStatus.ForeColor = Color.Red;
				txtStatus.Text = "Start";
				m_notifyicon.Text = "iHome Server running...";
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message,"Error Message");
				mn_BD_CON.Enabled = true;
				mn_BD_DIS.Enabled = false;
				mn_ConfigCam.Enabled = true;
				mn_Setting.Enabled = true;
				txtStatus.ForeColor = Color.Blue;
				txtStatus.Text = "Stop";				
				Server.server.Stop();
				m_notifyicon.Text = "iHome Server Stopped"; 
			}
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			/*Server.server.ConnectToBoard();*/
			Connect();
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			/*Server.server.DisconnectToBoard();*/
			mn_BD_CON.Enabled = true;
			mn_BD_DIS.Enabled = false;
			mn_ConfigCam.Enabled = true;
			mn_Setting.Enabled = true;
			txtStatus.ForeColor = Color.Blue;
			txtStatus.Text = "Stop";
			Server.server.Stop();
			m_notifyicon.Text = "iHome Server Stopped"; 
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			//cam.Show();
			Server.server.ViewCamGui();
			this.Activate();
		}

		private void menuItem7_Click_1(object sender, System.EventArgs e)
		{
			BoardPort bp = new BoardPort();
			bp.ShowDialog(this);
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			Server.server.Exit();
		}
		protected void Exit_Click(Object sender, System.EventArgs e) 
		{
			Server.server.Exit();
		}
		protected void Hide_Click(Object sender, System.EventArgs e) 
		{
			HideForm();
		}
		protected void Show_Click(Object sender, System.EventArgs e) 
		{
			ShowForm();
		}
		private void iHomeGui_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			HideForm();
			// cancel event close
			e.Cancel = true;
		}

		private void m_notifyicon_DoubleClick(object sender, EventArgs e)
		{
			ShowForm();
		}
		private void ShowForm()
		{
			m_menu.MenuItems[0].Enabled = false;
			m_menu.MenuItems[1].Enabled = true;			
			Show();
			this.WindowState = FormWindowState.Normal;
		}
		private void HideForm()
		{
			m_menu.MenuItems[0].Enabled = true;
			m_menu.MenuItems[1].Enabled = false;
			Hide();
		}
	}
}
