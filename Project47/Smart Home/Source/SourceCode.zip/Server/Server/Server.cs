using System;
using iLibrary;
using iHome.EventCtler;

namespace iHome.Connections
{
	class Internetwork : MarshalByRefObject,IService
	{
		private DBConn db;
		public Internetwork()
		{
			db = new DBConn();
		}
		public string HelloWorld()
		{
			Console.WriteLine("Connect");
			return "HelloWorld";
		}
		public bool Exec_On(string dist_addr)
		{				
			return Server.hw.Exec_On(dist_addr);
		}
		public bool Exec_Off(string dist_addr)
		{			
			return Server.hw.Exec_Off(dist_addr);
		}
		public bool Exec_SetDim(string dist_addr,int percent)
		{			
			return Server.hw.Exec_SetDim(dist_addr,percent);
		}
		public bool update_NameDevice(string addr,string new_name)
		{
			return db.update_NameDevice(addr,new_name);
		}
		/*public bool Exec_SetMotionMode(string mac_addr,int mode)
		{			
			return Server.hw.Exec_SetMotionMode(mac_addr,mode);
		}
		public bool Exec_SetMotionProg(string mac_addr,string pattern)
		{			
			return Server.hw.Exec_SetMotionProg(mac_addr,pattern);
		}*/
		public string Exec_Listdevice(int mode,bool refresh)
		{
			return db.ListDevice(mode,refresh);
		}
		public string Exec_ListHDev(int mode,bool refresh)
		{
			return db.ListHDev(mode,refresh);
		}
		public string Exec_ListDevProperty(string address)
		{
			return db.ListDevProperty(address);
		}
		public string Exec_ListSchedulesByType(int mode)
		{
			return db.ListSchedulesByType(mode);
		}
		public string Exec_ListSchedulesByDev(string address,int mode)
		{
			return db.ListSchedulesByDev(address,mode);
		}
		public int AddSchedule(string name,int type,string datetime,string days,string address,int cmd,string param)
		{
			return Server.hw.AddSchedule(name,type,datetime,days,address,cmd,param);
		}
		public int RemoveSchedule(string name)
		{
			return Server.hw.RemoveSchedule(name);
		}
		public int UpdateSchedule(string name,string datetime,string days,string address,int cmd,string param)
		{
			return Server.hw.UpdateSchedule(name,datetime,days,address,cmd,param);
		}
		// sec
		public bool Exec_ResetAlert(string dist_addr)
		{
			return db.ResetAllSecurityLevel();
		}
		public bool Exec_ResetAlert()
		{
			return db.ResetAllSecurityLevel();
		}
		public bool Exec_SecurityEN(string dist_addr)
		{
			return Server.hw.Exec_SecurityEN(dist_addr);
		}
		public bool Exec_SecurityDi(string dist_addr)
		{
			return Server.hw.Exec_SecurityDi(dist_addr);
		}
		public bool Exec_TurnOffSound(string addr)
		{
			return Server.hw.Exec_TurnOffSound(addr);
		}
		// cam
		public bool AddCaptureFn(string deviceName,string details,int device_no,int cap_time)
		{
			return Server.hw.AddCaptureFn(deviceName,details,device_no,cap_time);
		}
		public bool RemoveCamera(int device_no)
		{
			return Server.hw.RemoveCamera(device_no);
		}
		/*public bool UpdatePortCapture(int old_port,int new_port)
		{
			return Camera.UpdatePortCapture(old_port,new_port);
		}*/
		public bool UpdateCaptureTime(int device_no,int cap_time)
		{
			return Server.hw.UpdateCaptureTime(device_no,cap_time);
		}
		public string ManualCapture(int port,int size)
		{
			string filename = Server.hw.ManualCapture(port,size);
			return filename;
		}
		public string ViewCamera()
		{
			return db.ViewCamera();
		}
		public int getCaptureDriverCount()
		{
			return Server.hw.getCaptureDriverCount();
		}
		public string getCaptureDriverName()
		{
			return Server.hw.getCaptureDriverName();
		}
		// log 
		public string getLog()
		{
			return Server.hw.getLog();
		}
		// Setting Programs
		public bool SetPort(int port)
		{
			return db.SetPort(port);
		}
		public int GetPort()
		{
			return db.GetPort();
		}
		public bool SetSmsNumber(string smsno)
		{
			return db.SetSmsNumber(smsno);
		}
		public string getSmsNumber()
		{
			return db.getSmsNumber();
		}
		// ------- Webpage --------------------------------------------------
		public string Exec_wListDevice(int mode)
		{
			return db.wListDevice(mode);
		}
		public string Exec_wListSchedulesByType(int mode)
		{
			return db.wListSchedulesByType(mode);
		}
		/*public int RegisterEvent(string address,int event_type)
		{
			return 0;//EventMonitor.RegisterEvent(address,(EventMonitorType)event_type);
		}
		public bool UnRegisterEvent(int event_id)
		{
			return EventMonitor.UnRegisEvent(event_id);
		}*/
		public bool AddEventMacro(string source_addr,int event_type,
			string name,string dist_addr,int cmd,string param)
		{
			return EventMonitor.AddMacro(source_addr,(EventMonitorType)event_type,name,dist_addr,cmd,param);
		}
		public bool RemoveEventMacro(int macro_id)
		{
			return EventMonitor.RemoveMacro(macro_id);
		}
		public string ViewMacro()
		{
			return db.ViewMacro();
		}

		// ------------------------------------------------------------------
	}
}