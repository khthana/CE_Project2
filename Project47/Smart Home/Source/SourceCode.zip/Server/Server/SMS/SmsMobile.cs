using System;

namespace iHome.Connections
{
	/**************************************************
	 * �ŧ����������Ѻ���������Ͷ�� ��� SIEMENS M55
	 * ************************************************/
	public sealed class SIEMENS_M55
	{
		public static string ToPDU(string msg)
		{
			int msgLen = msg.Length;
			if (msgLen<0) return "";	// no input
			char[] charTxt = msg.ToCharArray();			
			string[] binText = new string[msgLen];
			string binTemp;
			string pduText = "";		

			for (int i = 0 ; i < msgLen ; i++) 
			{
				binTemp = Convert.ToString((int)charTxt[i],2);
				switch (binTemp.Length) 
				{
					case 1 : binTemp = "000000" + binTemp ; break;
					case 2 : binTemp = "00000" + binTemp ; break;
					case 3 : binTemp = "0000" + binTemp ; break;
					case 4 : binTemp = "000" + binTemp ; break;
					case 5 : binTemp = "00" + binTemp ; break;
					case 6 : binTemp = "0" + binTemp ; break;
				}
				binText[i] = binTemp;
			}

			for (int i = 0 ; i < msgLen-1 ; i++) 
			{
				int tempModVal = (i+1)%8;
				if (tempModVal != 0) 
				{
					binText[i] = binText[i+1].Substring(7-tempModVal) + binText[i];
					binText[i+1] = binText[i+1].Substring(0, 7-tempModVal);
					if (binText[i] != "") 
					{
						
						String tempHex = Convert.ToString(Convert.ToUInt32(binText[i],2),16);
						if (tempHex.Length == 1) 
						{
							pduText = pduText + "0" + tempHex;
						} 
						else 
						{
							pduText = pduText + tempHex;
						}
					}
				}
			}

			if (binText[msgLen-1] != "") 
			{				
				String tempHex = Convert.ToString(Convert.ToUInt32(binText[msgLen-1],2),16);
				if (tempHex.Length == 1) 
				{
					pduText = pduText + "0" + tempHex;
				} 
				else 
				{
					pduText = pduText + tempHex;
				}
			}

			pduText = pduText.ToUpper();
			Console.WriteLine("Input Text is \"" + msg +"\"\n");
			Console.WriteLine("Input Length is " + msgLen + "\n");
			Console.WriteLine("Output PDU is " + pduText + "\n");
			
			return pduText;		
		}
	}
	/*class iHomeMains
	{		
		[STAThread]
		static void Main(string[] args)
		{
			string txt;
			do
			{
				txt = Console.ReadLine();
				SIEMENS_M55.ToPDU(txt);
			}
			while (txt != "q");
			Console.ReadLine();
		}
	}*/
}
