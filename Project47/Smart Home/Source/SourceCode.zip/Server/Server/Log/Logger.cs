/*
* ErrorLogWriter class: XML error log writer
*
* Authors:		R. LOPES
* Contributors:	R. LOPES
* Created:		23 October 2002
* Modified:		24 October 2002
*
* Version:		1.0
*/

using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace iHome.Log
{
	/// <summary>
	/// ErrorLogWriter class
	/// </summary>
	public class iTxtLogger:TextWriter
	{
		// Variables
		private bool Disposed;
		private TextWriter Writer;

		// Constructor
		public iTxtLogger(string FilePath)
		{
			Disposed=false;
			if (FilePath == "")
				FilePath = Directory.GetCurrentDirectory()+@"\Log.txt";
			try
			{
				Writer=new StreamWriter(FilePath,false,Encoding.Unicode);
			}
			catch
			{
				throw;
			}
		}
		public iTxtLogger()
		{
			Disposed=false;
			try
			{
				Writer=new StreamWriter(Directory.GetCurrentDirectory()+@"\Log.txt",false,Encoding.Unicode);
			}
			catch
			{
				throw;
			}
		}
		// Destructor (equivalent to Finalize() without the need to call base.Finalize())
		~iTxtLogger()
		{
			Dispose(false);
		}

		// Free resources immediately
		protected override void Dispose(bool Disposing)
		{
			if(!Disposed)
			{
				if(Disposing)
				{					
				}
				// Close file
				if (Writer!=null)
				{
					Writer.Close();
					Writer=null;
				}
				// Disposed
				Disposed=true;
				// Parent disposing
				base.Dispose(Disposing);
			}
		}

		// Close the file
		public override void Close()
		{
			// Free resources
			Dispose(true);
		}

		// Implement Encoding() method from TextWriter
		public override Encoding Encoding
		{
			get
			{
				return(Encoding.Unicode);
			}
		}

		// Implement WriteLine() method from TextWriter (remove MethodImpl attribute for single-threaded app)
		// Use stack trace and reflection to get the calling class and method
		[MethodImpl(MethodImplOptions.Synchronized)]
		public override void WriteLine(string Txt)
		{

			string msg = String.Format("{0} {1}",
				DateTime.Now.ToString("dd/MM/yy HH:mm:ss"),Txt);

			Writer.WriteLine(msg);
			Writer.Flush();
		}
	}
}
