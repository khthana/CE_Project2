// This Code is modify from ErrorLogWriter of R. LOPES
// http://www.codeproject.com/csharp/xml_error_log.asp

using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace iHome.Log
{
	/// <summary>
	/// ErrorLogWriter class
	/// </summary>
	public class iErrorLogger:TextWriter
	{
		// Variables
		private bool Disposed;
		private TextWriter Writer;

		// Constructor
		public iErrorLogger(string FilePath)
		{
			Disposed=false;
			if (FilePath == "")
				FilePath = Directory.GetCurrentDirectory()+@"\Log.txt";
			try
			{
				Writer=new StreamWriter(FilePath,true,Encoding.Unicode);
			}
			catch{throw;}
		}
		public iErrorLogger()
		{
			Disposed=false;
			try
			{
				Writer=new StreamWriter(Directory.GetCurrentDirectory()+@"\Error.txt",true,Encoding.Unicode);
			}
			catch{throw;}
		}
		// Destructor (equivalent to Finalize() without the need to call base.Finalize())
		~iErrorLogger()
		{
			Dispose(false);
		}

		// Free resources immediately
		protected override void Dispose(bool Disposing)
		{
			if(!Disposed)
			{
				if(Disposing)
				{					
				}
				
				// Close file
				if (Writer!=null)
				{
					Writer.Close();
					Writer=null;
				}
				// Disposed
				Disposed=true;
				// Parent disposing
				base.Dispose(Disposing);
			}
		}

		// Close the file
		public override void Close()
		{
			// Free resources
			Dispose(true);
		}

		// Implement Encoding() method from TextWriter
		public override Encoding Encoding
		{
			get
			{
				return(Encoding.Unicode);
			}
		}

		// Implement WriteLine() method from TextWriter (remove MethodImpl attribute for single-threaded app)
		// Use stack trace and reflection to get the calling class and method
		[MethodImpl(MethodImplOptions.Synchronized)]
		public override void WriteLine(string Txt)
		{
			Writer.WriteLine("Time	: " + DateTime.Now.ToString());
			Writer.WriteLine("Class	: " +new StackTrace().GetFrame(2).GetMethod().ReflectedType.FullName);
			Writer.WriteLine("Method	: " +new StackTrace().GetFrame(2).GetMethod().ToString());
			Writer.WriteLine("Comment	: " + Txt);
			Writer.WriteLine();
			Writer.Flush();
		}
	}
}