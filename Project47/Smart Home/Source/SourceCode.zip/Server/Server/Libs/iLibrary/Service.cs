using System;

namespace iLibrary
{
	public interface IService
	{
		//bool Exec_SetAddress(string addr,string mac);
		//bool Exec_SetMotionProg(string dist_addr,string pattern);
		//bool Exec_SetMotionMode(string dist_addr,int mode);
		string HelloWorld();
		bool Exec_On(string dist_addr);
		bool Exec_Off(string dist_addr);
		bool Exec_SetDim(string dist_addr,int percent);		
		string Exec_Listdevice(int mode,bool refresh);
		string Exec_ListHDev(int mode,bool refresh);
		string Exec_ListDevProperty(string address);
		
		bool update_NameDevice(string addr,string new_name);
		// security
		bool Exec_ResetAlert(string dist_addr);   // not used
		bool Exec_ResetAlert();
		bool Exec_SecurityEN(string dist_addr);
		bool Exec_SecurityDi(string dist_addr);
		bool Exec_TurnOffSound(string addr);
		// schedule
		string Exec_ListSchedulesByType(int mode);
		string Exec_ListSchedulesByDev(string address,int mode);
		int AddSchedule(string name,int type,string datetime,string days,string address,int cmd,string param);
		int RemoveSchedule(string name);
		int UpdateSchedule(string name,string datetime,string days,string address,int cmd,string param);
		// camera
		bool AddCaptureFn(string name,string details,int port,int cap_time);
		bool RemoveCamera(int port);
		//bool UpdatePortCapture(int old_port,int new_port);
		bool UpdateCaptureTime(int port,int cap_time);
		string ManualCapture(int port,int size);
		string ViewCamera();
		int getCaptureDriverCount();
		string getCaptureDriverName();		
		// log
		string getLog();
		// macro
		bool AddEventMacro(string source_addr,int event_type,
			string name,string dist_addr,int cmd,string param);
		bool RemoveEventMacro(int macro_id);
		string ViewMacro();
		// setting
		bool SetPort(int port);
		int GetPort();
		bool SetSmsNumber(string smsno);
		string getSmsNumber();
		// web
		string Exec_wListDevice(int mode);
		string Exec_wListSchedulesByType(int mode);

	}
}
