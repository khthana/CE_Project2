using System;
using CRs232;
using System.Collections;
using System.Timers;
using System.Text.RegularExpressions;
using System.Threading;
namespace iHome.Connections
{
	public struct frame_struct
	{  
		public string info;
		public int seq;
		public int ack;
		public int kind;
	}
	public class Protocol
	{
		#region Member
		/* Physical link */
		private Rs232 rsCOmm = new Rs232();
		private int serialPort = 0;
		/* Delegate Event */
		private System.Timers.Timer tmrWaitData = new System.Timers.Timer();
		private System.Timers.Timer tmrWaitIdle = new System.Timers.Timer();
		private System.Timers.Timer tmrWaitTimeOut = new System.Timers.Timer();
		private System.Timers.Timer tmrChkOutQueue = new System.Timers.Timer(); // ���

		public delegate void LinkEventHandler(object sender,EventMask Mask);
		public event LinkEventHandler OnLinkEvent;

		/* Regular expression */
		private string strPattern = "";
		
		/* Buffer */
		private string strRxBuf = "";
		private string strRxframe = "";
		private string strTxframe = "";
		private Queue rsQin = new Queue(10);
		private Queue rsQout = new Queue(10);
		private bool network_en = true;

		private frame_struct x;
		private frame_struct y;
		private static int NextFrameToSend = 0;
		private static int FrameExpected = 0;
		#endregion

		#region Const
		private const UInt32 START_BYTE = 0x02;//0x02;//0x02;//0x41; //A
		private const UInt32 STOP_BYTE = 0x03;//0x03;//0x03;//0x5A;	//Z
		private const int SIZEOF_SEQ = 1;
		private const int SIZEOF_ACK = 1;		
		private const int OFFSET_SEQ = 0;
		private const int OFFSET_ACK = OFFSET_SEQ+SIZEOF_SEQ;
		
		private const int RESENT_TIMEOUT = 2000; //ms
		private const int PIGGYBACK_TIMEOUT = 1;
		private const int TERMINATE_TIMEOUT = 10000;

		private const int OUTQUEUE_TIMER = 1000;
		#endregion

		#region Enum
		// delegate event
		[Flags]
			public enum EventMask
		{
			FrameArrive = 1,
			FrameTimeout = 2
		}
		// flow event
		public enum psk0_event
		{
			PacketReady = 0,
			FrameArrival = 1,
			TimeOut = 2,
			ChannelIdle = 3,
			Terminate = 4,
			CheckSumError = 5
		}
		#endregion

		#region Constructor
		public Protocol()
		{			

			// Regular expression
			strPattern = String.Format("{0}.*?{1}",(char)START_BYTE,(char)STOP_BYTE);

			strRxBuf = "";
			strRxframe = "";
			strTxframe = "";
			rsQin.Clear();
			rsQout.Clear();
			network_en = true;
			NextFrameToSend = 0;
			FrameExpected = 0;
			// ### Load config
			LoadConfig();

			// timer
			tmrWaitData.Interval = RESENT_TIMEOUT;		// wait data 2000 ms
			tmrWaitData.Elapsed += new ElapsedEventHandler(tmrWaitData_Elapsed);

			tmrWaitIdle.Interval = PIGGYBACK_TIMEOUT;		// wait data 3000 ms
			tmrWaitIdle.Elapsed += new ElapsedEventHandler(tmrWaitIdle_Elapsed);
			
			tmrWaitTimeOut.Interval = TERMINATE_TIMEOUT;		// wait for terminate 10000 ms
			tmrWaitTimeOut.Elapsed += new ElapsedEventHandler(tmrWaitTimeOut_Elapsed);

			tmrChkOutQueue.Interval = OUTQUEUE_TIMER;		// wait for terminate 10000 ms
			tmrChkOutQueue.Elapsed += new ElapsedEventHandler(tmrChkOutQueue_Elapsed);
			tmrChkOutQueue.Start();
		}
		private void LoadConfig()
		{
			DBConn db = new DBConn();
			serialPort = db.GetPort();
			if (serialPort != 0)
			{
				StartComm();
			}
			// else error
		}
		private void StartComm()
		{
			// comport
			try
			{
				rsCOmm.Port = serialPort;
				rsCOmm.BaudRate = 9600;
				rsCOmm.DataBit = 8;
				rsCOmm.StopBit = Rs232.DataStopBit.StopBit_1;
				rsCOmm.Parity = Rs232.DataParity.Parity_None;
				rsCOmm.Timeout = 500;
				rsCOmm.UseXonXoff = true;
				rsCOmm.BufferSize = 2048;
				//delegate with event handle
				rsCOmm.CommEvent += new CRs232.Rs232.CommEventHandler(rsCOmm_LinkEvent);
			}
			catch
			{

			}
		}
		public void RestartComm()
		{
			rsCOmm.Close();
			LoadConfig();
			StartComm();
		}
		#endregion

		#region EventHandle

		/*RS232*/
		private void rsCOmm_LinkEvent(Rs232 source,Rs232.EventMasks Mask)
		{
			switch (Mask)
			{
				case Rs232.EventMasks.RxChar:
					//Console.WriteLine("CMD Char = {0}",source.InputStreamString);
					//Server.homeGui.AddLogBox(source.InputStreamString);
					OnRxChar(source);
					break;
				case Rs232.EventMasks.Break:
					break;
				case Rs232.EventMasks.CarrierDetect:
					break;
				case Rs232.EventMasks.ClearToSend:
					break;
				case Rs232.EventMasks.DataSetReady:
					break;
				case Rs232.EventMasks.Ring:
					break;
				case Rs232.EventMasks.RXFlag:
					break;
				case Rs232.EventMasks.StatusError:
					break;
				case Rs232.EventMasks.TxBufferEmpty:
					break;
			}	
		}
		/******************************************************************
		 * �͡���觢����ū�� (Timeout) retransmis old frame
		 * ***************************************************************/
		private void tmrWaitData_Elapsed(object sender, ElapsedEventArgs e)
		{
			flow_control(psk0_event.TimeOut);
		}
		/******************************************************************
		 * �͡��ʹͧ ACK ������Ѻ��������� (piggyback)
		 * ***************************************************************/
		private void tmrWaitIdle_Elapsed(object sender, ElapsedEventArgs e)
		{
			flow_control(psk0_event.ChannelIdle);
		}
		/******************************************************************
		 * �͡��ʹͧ ACK ������Ѻ��������� (piggyback)
		 * ***************************************************************/
		private void tmrWaitTimeOut_Elapsed(object sender, ElapsedEventArgs e)
		{
			OnLinkEvent(this,EventMask.FrameTimeout);
			flow_control(psk0_event.Terminate);			
		}
		/******************************************************************
		* ��Ǩ�ͺ���������㹤�� �������ҧ Event
		* ***************************************************************/
		private void tmrChkOutQueue_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (rsQout.Count > 0 && network_en)
			{
				flow_control(psk0_event.PacketReady);
			}
		}
		#endregion

		#region Property
		public string getStream
		{
			get
			{
				return strRxframe.Substring(2);
			}
		}
		#endregion

		#region Method

		/******************************************************************
		* ON RXChar :
		* �¡����ҡ streaming data
		* result: �����觶١�Ѵ start-stop �͡
		******************************************************************/
		private void OnRxChar(Rs232 source)
		{
			strRxBuf += source.InputStreamString;
			// built regular expression---.*?===
			Regex r = new Regex(strPattern);
			//strRxBuf = "trash---Hello World===trash---How Are You?===trash";
			// matching
			for (Match m = r.Match(strRxBuf);m.Success;m=m.NextMatch())
			{
				strRxframe = m.Value.Substring(1,m.Length-2);				
				// rise frame arrive event
				flow_control(psk0_event.FrameArrival);
				// remove match value and non-useable
				//strRxBuf = strRxBuf.Replace(m.Value,"");
				int findex = strRxBuf.IndexOf(m.Value,0);
				strRxBuf = strRxBuf.Remove(0,findex+m.Length);
			}
		}
		/******************************************************************
		 * Implement not clear
		 * ***************************************************************/
		public void Tx(string d)
		{
			rsQout.Enqueue(d);
		}
		/******************************************************************
		 * Make data for suitable for process (seq/ack/info)
		 * ***************************************************************/
		private bool get_frame(ref frame_struct f)
		{
			if (strRxframe.Length != 0)
			{
				f.seq = Convert.ToInt32(strRxframe.Substring(OFFSET_SEQ,SIZEOF_SEQ));
				f.ack = Convert.ToInt32(strRxframe.Substring(OFFSET_ACK,SIZEOF_ACK));
				f.info = strRxframe.Substring(SIZEOF_SEQ+SIZEOF_ACK);
				return true;
			}
			return false;
		}
		//------------------------------------------------------------------
		// Send data
		private void send_frame(frame_struct f)
		{
			string buffer = String.Format("{0}{1}{2}",f.seq,f.ack,f.info);
			send_data(buffer);
		}
		private void send_data(string buf)
		{
			buf = String.Format("{0}{1}{2}",(char)START_BYTE,buf,(char)STOP_BYTE);
			rsCOmm.Write(buf);
		}
		//-----------------------------------------------------------------
		/******************************************************************
		* flow_control :
		* �������������������  --- ��Ҩж١���ǹ������� timeout ��˹��
		******************************************************************/
		private void flow_control(psk0_event event2)
		{
			switch(event2)
			{
				case psk0_event.PacketReady :		
					network_en = false;
					/* a packet has arrived from the network layer */
					string tmp = (string)rsQout.Dequeue();
					
					//if (!Processing)
					//{
						strTxframe = tmp;						
						tmrWaitIdle.Stop();
						x.info = strTxframe; 		/* place packet in frame */
						x.seq = NextFrameToSend;
						/* piggyback acknowledge of last frame received */
						x.ack = 1-FrameExpected;
						send_frame(x); /* send it to physical layer */
						tmrWaitData.Start();	 // wait to resent
						tmrWaitTimeOut.Start();  // wait to terminate	
					//}
					break;

				case psk0_event.FrameArrival :
					/* a frame has arrived from the physical layer */
					/* get the frame */

					if (get_frame(ref y)==false) break;					
					/* check that it is the one that is expected */
					//Console.WriteLine(String.Format("Rec:({0},{1})",y.seq,y.ack));
					if(y.ack==NextFrameToSend) /* acknowledgment has arrived */
					{
						tmrWaitTimeOut.Stop();	//stop terminate
						tmrWaitData.Stop();		//stop resent
						NextFrameToSend = 1-NextFrameToSend;
						/*tmrWaitIdle.Start();*/
						network_en = true;
						//sent_data_from_q();
					}
					if (y.seq==FrameExpected)
					{						
						FrameExpected = 1-FrameExpected;
						tmrWaitIdle.Start();	// wait to ack without data
						//rise event
						OnLinkEvent(this,EventMask.FrameArrive);	/* valid frame */					
					}

					break;

				case psk0_event.TimeOut :
					/* a frame has not been ACKed in time, */
					/* so re-send the outstanding frame */
					tmrWaitData.Stop();
					x.info = strTxframe;
					x.seq = NextFrameToSend;
					x.ack = 1-FrameExpected;
					send_frame(x);
					tmrWaitData.Start();
					break;

				case psk0_event.ChannelIdle:
					tmrWaitIdle.Stop();
					x.info = "";
					x.seq = NextFrameToSend;
					x.ack = 1-FrameExpected;
					send_frame(x);		// send it to physical layer 
					//Is a frame then increase seq
					NextFrameToSend = 1-NextFrameToSend;

					break;

				case psk0_event.Terminate:
					tmrWaitTimeOut.Stop();
					tmrWaitData.Stop();					
					OnLinkEvent(this,EventMask.FrameTimeout);
					// Disable this connection
					network_en = true;
					break;

				case psk0_event.CheckSumError :	/* ignored */
					break;
			}
		}
		// Someting maybe improve later
		// use to open and close com port to prevent demage from event
		// handle error (not register)
		public void Open()
		{
			try
			{
				rsCOmm.Open();
				rsCOmm.EnableEvents();
			}
			catch
			{
				throw;
			}
		}
		public void Close()
		{
			rsCOmm.Close();
		}
		#endregion
	}

}