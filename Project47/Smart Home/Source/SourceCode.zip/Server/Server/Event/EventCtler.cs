using System;
using System.Threading;
using System.Collections;

namespace iHome.EventCtler{
	
	public sealed class EventWorker
	{	
		public delegate void Invoke(int event_id,string name,string address,int cmd,string param);
		public static event Invoke OnEventTrigger;
		private int event_id;
		private string name;				// name of event	
		private string address;				// Target address
		private int cmd;					// Target command
		private string param;				// Target param

		public EventWorker(int event_id,string name,string address,int cmd,string param)
		{
			this.event_id = event_id;
			this.name = name;
			this.address = address;
			this.cmd = cmd;
			this.param = param;
		}
		public void KickOffEvents()
		{
			Console.WriteLine(string.Format("KickOffEvent address = {0}",address));
			if (OnEventTrigger != null)
				OnEventTrigger(event_id,name,address,cmd,param);
		}
	}
}
