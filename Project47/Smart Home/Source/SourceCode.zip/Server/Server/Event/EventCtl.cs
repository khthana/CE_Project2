using System;
using System.Threading;
using System.Data.OleDb;

namespace iHome.EventCtler
{
	public enum EventMonitorType {
		POWER_ON,POWER_OFF,TAKE_SHOT,ALERT,CHANGE}	
	public sealed class EventMonitor
	{
		public static int ReturnError = -1;
		
		// ��� Event_id �ͧ�����˵ء�ó���ŧ����¹���
		public static int getEventID(string address,EventMonitorType cmd)
		{
			DBConn db = new DBConn();			
			return db.getEventID(address,(int)cmd);
		}
		/*// ŧ����¹���͵�Ǩ�Ѻ Event
		private static int RegisterEvent(string addr,EventMonitorType e)
		{
			DBConn db = new DBConn();
			bool success = db.RegisEvent(addr,(int)e);
			if (success)
				return db.getEventID(addr,(int)e);
			else
				return -1;
		}
		// ¡��ԡ����¹���͵�Ǩ�Ѻ Event
		public static bool UnRegisEvent(int event_id)
		{
			DBConn db = new DBConn();
			return db.UnRegisEvent(event_id);
		}*/
		public static bool AddMacro(string source_addr,EventMonitorType e,
									string name,string dist_addr,int cmd,string param)
		{
			DBConn db = new DBConn();
			int event_id = db.getEventID(source_addr,(int)e);
			if (event_id == EventMonitor.ReturnError)
			{
				// Register New
				try
				{
					bool success = db.RegisEvent(source_addr,(int)e);
					if (success)
						event_id = db.getEventID(source_addr,(int)e);
					else
						return false; // false
				}
				catch
				{
					Console.Error.WriteLine("Database Error");
					return false;
				}
			}
			
			// Add new Macro
			try
			{
				return db.AddEventBox(event_id,name,dist_addr,cmd,param);
			}
			catch 
			{
				Console.Error.WriteLine("Database Error");
				return false;
			}
		}
		public static bool RemoveMacro(int macro_id)
		{
			try
			{
				DBConn db = new DBConn();			
				return db.RemoveEventBox(macro_id);
			}
			catch
			{
				Console.Error.WriteLine("Database Error");
				return false;
			}
		}
		// �ա������¹�ŧ --> ��Ǩ�ͺ����� Register ON_EVENT ���ͻ���
		// ��� Register ��� ���Ӥ�� event_id �����¡����觷���˹����ӧҹ�ҡ
		public static void InvokeEvent(string address,EventMonitorType event_type)
		{
			int event_id = getEventID(address,event_type);			
			if (event_id != EventMonitor.ReturnError)
			{
				DBConn db = new DBConn();
				string[,] list = db.getEventBoxInvoke(event_id);
				if (list != null)
				{
					string name;int cmd;string param;
					for (int i=0;i<list.GetLength(0);i++)
					{
						name = list[i,0];
						address = list[i,1];
						cmd = Int32.Parse(list[i,2]);
						param = list[i,3];
						EventWorker work = new EventWorker(event_id,name,address,cmd,param);
						ThreadStart ts = new ThreadStart(work.KickOffEvents);
						Thread t = new Thread(ts);
						Console.WriteLine(string.Format("InvokeEvent address = {0}",address));
						t.Start();
					}
				}
			}				
		}		
	}
}