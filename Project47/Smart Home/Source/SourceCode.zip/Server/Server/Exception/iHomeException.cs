using System;

namespace iHome
{
	/// <summary>
	/// Summary description for iHomeException.
	/// </summary>
	public class iHomeException : Exception
	{
		public iHomeException(string msg) : base(msg)
		{
			Console.Error.WriteLine(msg);
			//ErrorLog.ErrorRoutine(false,this);
		}
	}
}
