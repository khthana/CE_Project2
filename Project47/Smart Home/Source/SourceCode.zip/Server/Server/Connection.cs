using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Data.OleDb;
using System.Data;
using iHome.EventScheduler;
using iHome.EventCtler;
using iHome.Connections;
using CRs232;

namespace iHome
{
	public class HWCommand
	{	
		private static int ident = 0;
		private static string nextIdent()
		{
			ident++;
			if (ident > 99) ident = 0;			
			return ident.ToString("00");
		}
		public class frameL2
		{
			private bool isUseable = true;
			public string mac;
			public exec_cmd command;
			private string ident;
			public string info;
			public frameL2()
			{
				ident = nextIdent();
			}
			public frameL2(string stream)
			{	
				// ����ͧ gen ident ��������Ҩҡ�����
				this.Phase(stream);
			}
			public frameL2(string mac,exec_cmd command,string info)
			{	
				ident = nextIdent();
				this.mac = mac;
				this.command = command;
				this.info = info;
			}
						
			public string Ident
			{
				get
				{
					return ident;
				}
			}
			public bool IsUseable
			{
				get
				{
					return isUseable;
				}
			}
			public void Phase(string stream)
			{
				try
				{
					mac = stream.Substring(0,2);
					command = (exec_cmd)char.Parse(stream.Substring(2,1));				
					ident = stream.Substring(3,2);// 2 Byte
					info = stream.Substring(5);
				}
				catch
				{
					isUseable = false;
				}
			}
			public override string ToString()
			{
				return String.Format("{0}{1}{2}{3}",mac,(char)command,ident,info);
			}
			public static string MakeFrameString(string addr,exec_cmd command,string info)
			{
				string ident = nextIdent();
				return String.Format("{0}{1}{2}{3}",addr,(char)command,ident,info);
			}
		}				

		#region Const
		private const string LIMITER = "/";
		#endregion

		#region MEMBER
		private bool isFrameTimeOut = false;	// ���Ǩ�ͺ��� Frame �������Դ Timeout �����ѧ
		private Protocol ptc;
		private string identnum;				// �����Ţ identifier �������¡��� client ������¡
		#endregion

		#region Constructor
		public HWCommand()
		{
			// reset status all interface module
			DBConn db = new DBConn();
			string sqlstr = @"UPDATE HDev SET status = 0";								
			db.execSQLnoQuery(sqlstr);			
		}
		#endregion

		#region ENUM
		public enum exec_cmd
		{
			ON	= (char)100,
			OFF = (char)101,
			Dim = (char)102,
			MotionMode = (char)103,
			MotionProg = (char)104,
			Alert = (char)105,
			Read = (char)200,
			// return only
			Info = (char)201,			// ��������´�ػ�ó�
			DeviceReg = (char)202,	// ŧ����¹�ػ�ó�
			Result = (char)203,		// ���Ѿ���÷ӧҹ
			ErrorMsg = (char)204
		}
		#endregion

		#region Event
		/******************************************************************
		 * ��������Ѻ Frame �����Ũҡ���Protocol
		 * ***************************************************************/
		public void ptc_OnLinkEvent(object sender,Protocol.EventMask  Mask)
		{
			switch (Mask)
			{
				case Protocol.EventMask.FrameArrive:
					try
					{
						frameL2 f = new frameL2(((Protocol)sender).getStream);
						if (f.IsUseable)OnFramArrive(f);
					}
					catch {Console.Error.WriteLine("Frame Error");}

					break;

				case Protocol.EventMask.FrameTimeout:
					isFrameTimeOut = true;
					break;
			}
		}
		/******************************************************************
		 * ������Դ��� Event �ҡ����觵�ҧ � (EventMonitor)
		 * ***************************************************************/
		public void EventWorker_OnEventTrigger(int event_id,string name,string address,int cmd,string param)
		{
			ScheduleCallBack("ON_EVENT"+event_id.ToString(),address,cmd,param);
		}
		/******************************************************************
		 * �ѧ��ѹ�ӧҹ ��������Ѻ Frame �����Ũҡ���Protocol (ptc_OnLinkEvent)
		 * ***************************************************************/
		private void OnFramArrive(frameL2 f)
		{
			switch (f.command)
			{
				case exec_cmd.DeviceReg:
				{
					try
					{
						DBConn db = new DBConn();
						// ���� model �ҡ Dev �� 1 ��ѡ ��� DB �� 2 ��ѡ 0X
						string model = "0"+f.info.Substring(1,1);
						string channels = f.info.Substring(3,1);
						string MacInList = db.getListMac();
						/* ��Ǩ�ͺ��á�� Insert ����բͧ����������������ѧ */
						if (MacInList.IndexOf(f.mac)==-1)
						{
							if (!db.ins_NewHdev(f.mac,model,channels))
								Console.Error.WriteLine("Write Database Error");
							else
								Console.WriteLine(String.Format(
									"Found New Device # Mac={1},noCHs={2}",f.mac,channels));
						}
						else
						{
							// �ػ�ó��ա�á�˹������������ DB �觤�ҹ�����Ѻ�ػ�ó�
							// fn : ���ҧ��� config �����������ҡ DB ����ػ�ó�

							/* ���ҧ fn ��觴֧����Ҩҡ��ŵ�ҧ � �� ret ��� �ӴѺ��� ch
							* 1. �Ӥ�� model�����͡��Ҩ������㴺�ҧ
							* 2. ���¡ fn �ͧ��ŷ���ͧ���
							* 3. �Ӽ��Ѿ��������ѹ������ҧ�� config str
							* 4. �觤����
							* */

							string strConfig = "";
							char[] tmp = null;
							frameL2 l2 = null;
							switch (model)
							{
								case "00": // SW (status)
									//strConfig += String.Format("{0}{1},{2}{3}",LIMITER,(char)exec_cmd.OFF,db.getFieldDevConfig(f.mac,0),LIMITER);
									tmp = db.getFieldDevConfig(f.mac,0).ToCharArray();
									for (int i=0;i<tmp.Length;i+=2)
									{
										if (tmp[i] == '1')
											strConfig += String.Format("({0})",i/2+1);
									}
									l2 = new frameL2(f.mac,exec_cmd.ON,strConfig);
									break;
								case "01": // Dim (status,Dim)
									//strConfig += String.Format("{0}{1},{2}{3}",LIMITER,(char)exec_cmd.OFF,db.getFieldDevConfig(f.mac,0),LIMITER);
									//strConfig += String.Format("{0}{1},{2}{3}",LIMITER,(char)exec_cmd.Dim,db.getFieldDevConfig(f.mac,1),LIMITER);
									tmp = db.getFieldDevConfig(f.mac,1).ToCharArray();
									for (int i=0;i<tmp.Length;i+=2)
									{
										strConfig += String.Format("({0},{1})",i/2+1,tmp[i]);
									}
									l2 = new frameL2(f.mac,exec_cmd.Dim,strConfig);
									break;
								case "02": // Camera
									break;
								case "03": // Security
									tmp = db.getFieldDevConfig(f.mac,3).ToCharArray();
									for (int i=0;i<tmp.Length;i+=2)
									{
										if (tmp[i] == '1')
											strConfig += String.Format("({0})",i/2+1);
									}
									l2 = new frameL2(f.mac,exec_cmd.ON,strConfig);
									break;
							}
							
							// Update Status to ON
							string sqlstr = string.Format(
								@"UPDATE HDev SET status = 1 WHERE mac = '{0}'",f.mac);								
							db.execSQLnoQuery(sqlstr);
							
							// Send direct to physical layer
							if (strConfig != "") ptc.Tx(l2.ToString());

							Console.WriteLine(String.Format(
								"Found OLD Device # Mac={0},noCHs={1}",f.mac,channels));

						}
					}
					catch {Console.Error.WriteLine("Register Device Fail");}
				}					
					break;

				case exec_cmd.Result:
				{
					//Server.homeGui.AddLogBox("Recieve Result for id="+f.Ident.ToString());
					identnum = f.Ident;
				}
					break;

				case exec_cmd.Info: /* INfo �ҡ Control BD */
				{
					try
					{	
						DBConn db = new DBConn();
						// Phaser detail
						Regex r;
						Match m;
						//string inputString = @"/BB,A,1,0,1,0//EE,A,10,9,8,6/";
						string inputString = f.info;
						string strRegex = LIMITER + @".*?" + LIMITER;
						//r = new Regex(@"/.*?/",RegexOptions.Compiled/*|RegexOptions.IgnoreCase*/);
						r = new Regex(strRegex,RegexOptions.Compiled/*|RegexOptions.IgnoreCase*/);
						string a;
						
						for (m = r.Match(inputString); m.Success; m = m.NextMatch()) 
						{
							// �ش����� 1 �ѹ �� Mc,C,1,0,1,0
							a = m.Value.Substring(1,m.Length-2);

							// �¡�����
							switch ((exec_cmd)Char.Parse(a.Substring(3,1)))
							{
								case exec_cmd.OFF:	//channel status
								{
									string mac_addr = a.Substring(0,2);
									int noCH = db.getChannels(mac_addr);
									int noParam = 0;							
									string[] param = getParam(a.Substring(5),ref noParam);							
									if (noParam > noCH ) noParam = noCH;
									string address;
									char[] devfield;
									for (int i=0;i<noParam;i++)
									{	// ch �������� 1
										address = db.getAddress(mac_addr,i+1);										
										//-----------------------------------------------
										// ��Ǩ�������¹�ŧ�ͧ������
										devfield = db.getFieldDevConfig(mac_addr,0).ToCharArray(); //field sw
										if (param[i] != devfield[i*2].ToString())  // to convert devfield[0->2->4->] use i*2 (0,0,1,0) skipt ,
										{	
											// First invoke CHANGE Event then other
											EventMonitor.InvokeEvent(address,EventMonitorType.CHANGE);
											switch (param[i])
											{
												case "0": //OFF
													EventMonitor.InvokeEvent(address,EventMonitorType.POWER_OFF);
													break;
												case "1": //ON
													EventMonitor.InvokeEvent(address,EventMonitorType.POWER_ON);
													break;
											}	
											db.update_Power(Int32.Parse(param[i]),address);
										}
										//-----------------------------------------------																	
										
									}
								}
									break;
								case exec_cmd.Dim:	// dim status
								{
									string mac_addr = a.Substring(0,2);
									int noCH = db.getChannels(mac_addr);
									int noParam = 0;							
									string[] param = getParam(a.Substring(5),ref noParam);							
									if (noParam > noCH ) noParam = noCH;
									string address;
									char[] devfield;
									for (int i=0;i<noParam;i++)
									{	// ch �������� 1
										address = db.getAddress(mac_addr,i+1);										
										//-----------------------------------------------
										// ��Ǩ�������¹�ŧ�ͧ������
										devfield = db.getFieldDevConfig(mac_addr,1).ToCharArray(); //field sw
										if (param[i] != devfield[i].ToString())
										{
											// First invoke CHANGE Event then other
											EventMonitor.InvokeEvent(address,EventMonitorType.CHANGE);
											// Dimmer �������¹�� 0 �ʴ���һԴ �������� 0 ����Դ
											switch (param[i])
											{
												case "0": //OFF
													EventMonitor.InvokeEvent(address,EventMonitorType.POWER_OFF);
													break;
												default: // ON
													EventMonitor.InvokeEvent(address,EventMonitorType.POWER_ON);
													break;
											}			
											db.update_DimLevel(Int32.Parse(param[i]),address);
										}
										//-----------------------------------------------
										
									}
								}
									break;
								case exec_cmd.Alert:	//channel status
								{
									string mac_addr = a.Substring(0,2);
									int noCH = db.getChannels(mac_addr);
									int noParam = 0;							
									string[] param = getParam(a.Substring(5),ref noParam);							
									if (noParam > noCH ) noParam = noCH;
									string address;
									char[] devfield;
									for (int i=0;i<noParam;i++)
									{	// ch �������� 1
										address = db.getAddress(mac_addr,i+1);										
										//-----------------------------------------------
										// ��Ǩ�������¹�ŧ�ͧ������
										devfield = db.getFieldDevConfig(mac_addr,3).ToCharArray(); //field Security
										if (param[i] != devfield[i*2].ToString())
										{
											// First invoke CHANGE Event then other
											EventMonitor.InvokeEvent(address,EventMonitorType.CHANGE);
											switch (param[i])
											{
												case "1": //ON
													EventMonitor.InvokeEvent(address,EventMonitorType.ALERT);
													break;
											}
											db.SetSecurityLevel(db.getAddress(mac_addr,i+1),Int16.Parse(param[i]));
											//db.update_Alert(Int16.Parse(param[i]),db.getAddress(mac_addr,i+1));
										}
										//-----------------------------------------------
									}
								}
									break;
							}
						}
					}
					catch (iHomeException)
					{
						throw;
					}
				}
					break;
				case exec_cmd.ErrorMsg:
				{				
					try
					{
						DBConn db = new DBConn();
						string mac = f.info.Substring(1,2);
						int err = Int32.Parse(f.info.Substring(4,1)); //conv error_code -> num
						string sqlstr = "";
						switch (err)
						{
							case 0:
								break;
							case 1: // disconnected
								sqlstr = string.Format(
									@"UPDATE HDev SET status = 0 WHERE mac = '{0}'",mac);								
								db.execSQLnoQuery(sqlstr);
								break;
							default:
								break;
						}
					}
					catch {Console.Error.WriteLine("Write Database Error");}
				}
					break;
			}
		}
		#endregion
		
		#region Method

		public void Loading()
		{
			try
			{
				ptc = new Protocol();
				ptc.Open();
				LoadSchedule();		
				EventWorker.OnEventTrigger +=new EventWorker.Invoke(EventWorker_OnEventTrigger);
				ptc.OnLinkEvent += new Protocol.LinkEventHandler(ptc_OnLinkEvent);
			}
			catch {throw;}
		}
		public void Unloading()
		{
			try
			{
				ptc.Close();
			}
			catch {throw;}
		}
		private string[] getParam(string str,ref int sizeArray)
		{
			Regex r;
			Match m;
			str+=",";	// ������������Ǩ�ͺ��ҡ Regex
			r = new Regex(@".*?,",
				RegexOptions.Compiled/*|RegexOptions.IgnoreCase*/);
			string[] a = new string[10];
			int i = 0;
			for (m = r.Match(str); (m.Success); m = m.NextMatch()) 
			{
				a[i++] = m.Value.Substring(0,m.Length-1);
			}
			sizeArray = i;	// no of param
			return a;
		}
		/*****************************************
		 * ��Һ觺͡����� connection �ͧ client �
		 * **************************************/
		private bool waitForResult(string Num)
		{	
			while (!string.Equals(Num,identnum) && !isFrameTimeOut)
			{
				Thread.Sleep(500);
				//				if (++counter*sleep_time > timeout) return false;
			}
			if (isFrameTimeOut)
			{
				isFrameTimeOut = false;
				return false;
			}
			else
				return true;
		}


		#region About Mobile
		/*******************************************
		 * �Դ comport �觢����������Ͷ��
		 * ******************************************/
		private void sendSMS(string SMSstring)
		{
			try
			{
				DBConn db = new DBConn();
				char[] charTel = db.getSmsNumber().ToCharArray();
				if (charTel.Length != 10) return;
				//int x = SMSstring.Length;

				string PDUtxt = String.Format("0011000A81{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}0000AA0{10}{11}",
					charTel[1],charTel[0],
					charTel[3],charTel[2],
					charTel[5],charTel[4],
					charTel[7],charTel[6],
					charTel[9],charTel[8],
					Convert.ToString(SMSstring.Length,16),SIEMENS_M55.ToPDU(SMSstring));
				//Console.WriteLine("To mobile : "+PDUtxt);

				Rs232 rsCOmm = new Rs232();
				rsCOmm.Open(2,9600,8,Rs232.DataParity.Parity_None,Rs232.DataStopBit.StopBit_1,2048);
				
				System.Threading.ManualResetEvent reset = new System.Threading.ManualResetEvent(false);
								
				rsCOmm.Write("AT" + Char.ToString((char)13));
				reset.WaitOne(1000,false);
				rsCOmm.Write("AT+CMGF=0" + Char.ToString((char)13));
				reset.WaitOne(1000,false);
				rsCOmm.Write(String.Format("AT+CMGS={0}{1}",(PDUtxt.Length/2)-1,(char)13));
				reset.WaitOne(1000,false);
				rsCOmm.Write(PDUtxt + Char.ToString((char)26));
				reset.WaitOne(1000,false);
				rsCOmm.Close();
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine("Send SMS Fail"+ex.Message);
			}
		}
		
		#endregion

		#region About Hardward
		/****************************************************
		 * �ŧ���������������������
		 * �Ѵ�������ͼš�÷ӧҹ ��͹��ä׹���
		 * 
		 * */

		/******************************************************
		 * Update :
		 * - ��˹� id ������� connection
		 * 
		 * �ѭ�� :
		 * - �ѧ����ա�õ�Ǩ�ͺ�����١��ͧ�ͧ������ �� �����Ţ Address ,ch
		 * 
		 * *****************************************************/
		public bool Exec_On(string dist_addr)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			frameL2 f = new frameL2(mc[0],exec_cmd.ON,"("+mc[1]+")");
			ptc.Tx(f.ToString());
		
			if (waitForResult(f.Ident)) 
			{
				string sqlstr = string.Format(
					@"UPDATE iSwDev SET power = {0} WHERE  (addr = '{1}')",1,dist_addr);

				// �����Ҩ� HW �зӧҹ����ó�����Ң����ŵ�� DB
				return db.execSQLnoQuery(sqlstr);
			}
			else
			{
				Console.WriteLine("Operation Timeout # Power on Fail : Address = "+dist_addr);
				return false;
			}
		}
		public bool Exec_Off(string dist_addr)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			frameL2 f = new frameL2(mc[0],exec_cmd.OFF,"("+mc[1]+")");
			ptc.Tx(f.ToString());
			
			if (waitForResult(f.Ident)) 
			{
				string sqlstr = string.Format(
					@"UPDATE iSwDev SET power = {0} WHERE  (addr = '{1}')",0,dist_addr);

				// �����Ҩ� HW �зӧҹ����ó�����Ң����ŵ�� DB
				return db.execSQLnoQuery(sqlstr);
			}
			else
			{
				Console.WriteLine("Operation Timeout # Power off Fail : Address = "+dist_addr);
				return false;
			}
		}
		public bool Exec_SetDim(string dist_addr,int percent)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			string info = string.Format("({0},{1})",mc[1],percent);
			frameL2 f = new frameL2(mc[0],exec_cmd.Dim,info);			
			ptc.Tx(f.ToString());

			if (waitForResult(f.Ident)) 
			{
				string sqlstr = string.Format(
					@"UPDATE iDimDev SET dim_level = {0} WHERE  (addr = '{1}')",percent,dist_addr);

				// �����Ҩ� HW �зӧҹ����ó�����Ң����ŵ�� DB
				return db.execSQLnoQuery(sqlstr);
			}
			else
			{
				Console.WriteLine("Operation Timeout # Dimmer Fail : Address = "+dist_addr);
				return false;
			}
		}
		public bool Exec_SetMotionMode(string dist_addr,int mode)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			string info = string.Format("({0},{1})",mc[1],mode);
			frameL2 f = new frameL2(mc[0],exec_cmd.MotionMode,info);			
			ptc.Tx(f.ToString());

			if (waitForResult(f.Ident)) 
			{
				string sqlstr = string.Format(
					@"UPDATE iCameraDev SET motion_mode = {0} WHERE  (addr = '{1}')",mode,dist_addr);

				return db.execSQLnoQuery(sqlstr);
			}
			else
			{
				Console.WriteLine("Operation Timeout # SetMotionMode Fail : Address = "+dist_addr);
				return false;
			}
		}
		public bool Exec_SetMotionProg(string dist_addr,string pattern)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			string info = string.Format("({0},{1})",mc[1],pattern);
			frameL2 f = new frameL2(mc[0],exec_cmd.MotionProg,info);			
			ptc.Tx(f.ToString());

			if (waitForResult(f.Ident)) 
			{
				string sqlstr = string.Format(
					@"UPDATE iCameraDev SET cap_program = '{0}' WHERE  (address = '{1}')",pattern,dist_addr);

				// �����Ҩ� HW �зӧҹ����ó�����Ң����ŵ�� DB
				return db.execSQLnoQuery(sqlstr);
			}
			else
			{
				Console.WriteLine("Operation Timeout # MotionProgram Fail : Address = "+dist_addr);
				return false;
			}
		}
		// ��ҹ��� info �ͧ�ػ�ó� < ��������� >
		public bool Exec_Read(string dist_addr)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			frameL2 f = new frameL2(mc[0],exec_cmd.Read,"");			
			ptc.Tx(f.ToString());
			return waitForResult(f.Ident);
		}		

		#endregion

		#region Camera
		// ��Ŵ�����š��ͧ����ͧ��� Capture
		/*private void LoadRegisterCamera()
		{
			string strCon = DBConn.strCon;
			OleDbConnection conn;
			DBConn db = new DBConn();
			conn = new OleDbConnection(strCon);
			conn.Open();
			try
			{
				string sqlstr = @"Select addr,detail,port from iCameraDev where enable = 1";
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;
				OleDbDataReader reader = com.ExecuteReader();
				while (reader.Read())
				{
					Camera c = new Camera(reader["addr"].ToString(),reader["name"].ToString(),
						Int16.Parse(reader["port"].ToString()));
					CameraCtrl.AddCamera(c);
				}
				conn.Close();
			}
			catch
			{
				//error
			}
		}*/
		public int getCaptureDriverCount()
		{			
			return Server.cam.getDriverCount();
		}
		public string getCaptureDriverName()
		{
			try
			{
				System.IO.MemoryStream stream = new System.IO.MemoryStream();
				System.Xml.XmlTextWriter 
					writer = new System.Xml.XmlTextWriter(stream,System.Text.Encoding.ASCII);
				for (int i=0;i<Server.cam.getDriverCount();i++)
				{				
					writer.WriteStartElement("Driver");
					writer.WriteStartElement("No");
					writer.WriteString(i.ToString());
					writer.WriteEndElement();
					writer.WriteStartElement("Name");
					writer.WriteString(Server.cam.getDriverName(i));
					writer.WriteEndElement();
					writer.WriteEndElement();
				}
				writer.Flush();	
				stream.Position = 0;
				return System.Text.Encoding.ASCII.GetString(stream.ToArray());
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex.Message);
				return null;
			}
		}
		public void PrepareDBForCapture()
		{
			DBConn db = new DBConn();
			string sqlstr = @"INSERT INTO HDev(mac, model,channels) VALUES ('00','04',1)";
			if (db.execSQLnoQuery(sqlstr))
			{
				sqlstr = @"INSERT INTO HChannel(mac, channel,address,name) VALUES ('00',1,'00','CameraVirtualDevice')";
				db.execSQLnoQuery(sqlstr);
			}
		}
		// ŧ����¹
		public bool AddCaptureFn(string name,string details,int port,int cap_time)
		{
			if (port >= getCaptureDriverCount() || port < 0) return false;

			DBConn db = new DBConn();			
			return	db.InsertCapCamera(name,details,port,cap_time,1)
				&& UpdateCaptureTime(port,cap_time);
		}
		public bool UpdateCaptureTime(int port,int cap_time)
		{
			RemoveCaptimeSchedule(port);
			if (cap_time > 0)
			{
				string namesche = String.Format("CAMXX PORT={0}",port);
				Schedule s;
				DateTime ackTime = DateTime.Now.AddMinutes(cap_time);
				s = new TimeSchedule(namesche,ackTime,"00",3,cap_time.ToString()); // 3 = capture
				s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
				Scheduler.AddSchedule(s);
			}
			DBConn db = new DBConn();
			return db.UpdateCapTimeCamera(port,cap_time);
		}
		private bool RemoveCaptimeSchedule(int port)
		{
			string namesche = String.Format("CAMXX PORT={0}",port);
			Scheduler.RemoveSchedule(namesche);
			return true;
		}
		// ����͡
		public bool RemoveCamera(int port)
		{	
			DBConn db = new DBConn();
			if (RemoveCaptimeSchedule(port))
				return db.RemoveCapCamera(port);
			else return false;
		}
		public bool UpdatePortCapture(int old_port,int new_port)
		{
			DBConn db = new DBConn();
			if (db.UpdatePortCamera(old_port,new_port))
			{
				//CameraCtrl.getCamera(addr).port = port;
				return true;
			}
			return false;
		}
		public string ManualCapture(int port,int size)
		{
			try
			{
				lock(this)
				{
					if (Server.cam != null )
					{	
						//Server.cam.start();
						string filename = Server.cam.capture(port,size);
						if (filename.Equals("")) return "";
						//Server.cam.stop();
						DBConn db = new DBConn();
						string http_path = db.getURLCamSavePath();
						if (size==0)
							http_path =  http_path+"images/mobile/"+port+"/"+filename;
						else
							http_path =  http_path+"images/webpage/"+port+"/"+filename;
						return http_path;
					}
					return "";
				}
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex.Message);
				//if (Server.cam != null) Server.cam.Dispose();
				return "";
			}
			//return CameraCtrl.getCamera(addr).capture();
		}		
		
		#endregion

		#region About Security
		public bool Exec_SecurityEN(string dist_addr)
		{
			try
			{
				DBConn db = new DBConn();
				string[] mc = db.getMacChan(dist_addr);
				frameL2 f = new frameL2(mc[0],exec_cmd.ON,"("+mc[1]+")");
				ptc.Tx(f.ToString());
			
				if (waitForResult(f.Ident)) 
				{
					string sqlstr = string.Format(
						@"UPDATE iSecurityDev SET power = {0} WHERE  (addr = '{1}')",1,dist_addr);

					// �����Ҩ� HW �зӧҹ����ó�����Ң����ŵ�� DB
					return db.execSQLnoQuery(sqlstr);
				}
				else
				{
					return false;
				}
			}
			catch
			{
				return false;
			}
		}
		public bool Exec_SecurityDi(string dist_addr)
		{
			DBConn db = new DBConn();
			string[] mc = db.getMacChan(dist_addr);
			frameL2 f = new frameL2(mc[0],exec_cmd.OFF,"("+mc[1]+")");
			ptc.Tx(f.ToString());
			
			if (waitForResult(f.Ident)) 
			{
				string sqlstr = string.Format(
					@"UPDATE iSecurityDev SET power = {0} WHERE  (addr = '{1}')",0,dist_addr);

				// �����Ҩ� HW �зӧҹ����ó�����Ң����ŵ�� DB
				return db.execSQLnoQuery(sqlstr);
			}
			else
			{
				return false;
			}
		}
		public bool Exec_TurnOffSound(string addr)
		{
			try
			{
				if (Exec_Off(addr))
				{
					DBConn db = new DBConn();
					db.ResetAllSecurityLevel();
				}
				return true;
			}
			catch
			{
				return false;
			}
		}
		#endregion

		#region About Schedule
		public int AddSchedule(string name,int type,string datetime,string days,string address,int cmd,string param)
		{
			/* return msg:
			 * 0 = no error
			 * 1 = name exist
			 * 2 = time is older
			 * */
			try
			{
				DateTime time = DateTime.Parse(datetime);
				Schedule s = null;
				switch((ScheduleType)type)
				{
					case ScheduleType.ONETIME:
                        s = new OneTimeSchedule(name,time,address,cmd,param);
						s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
						break;
					case ScheduleType.DAILY:
						s = new DailySchedule(name,time,days,address,cmd,param);
						s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
						break;
					case ScheduleType.WEEKLY:
						s = new WeeklySchedule(name,time,address,cmd,param);
						s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
						break;
					case ScheduleType.MONTHLY:
						s = new MonthlySchedule(name,time,address,cmd,param);
						s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
						break;
				}
				if (s == null) return 1;//error
				Scheduler.AddSchedule(s);
				return 0;
			}
			catch
			{
				return 1; //error
			}
		}
		public int RemoveSchedule(string name)
		{
			try
			{
				Scheduler.RemoveSchedule(name);
				return 0;
			}
			catch
			{
				return 1;
			}			
		}
		public int UpdateSchedule(string name,string datetime,string days,string address,int cmd,string param)
		{
			try
			{
				int schType = (int)Scheduler.GetSchedule(name).Type;
				RemoveSchedule(name);
				AddSchedule(name,schType,datetime,days,address,cmd,param);
				return 0;
			}
			catch
			{
				return 1;
			}			
		}
		public void LoadSchedule()
		{	
			Schedule s;
			string strCon = DBConn.strCon;
			OleDbConnection conn;
			DBConn db = new DBConn();
			Scheduler.UnloadFromMem();

			try
			{
				conn = new OleDbConnection(strCon);
				conn.Open();

				string sqlstr = @"Select name,type,next_time,days,addr,cmd,param From iSchedule";
				OleDbCommand com = new OleDbCommand(sqlstr,conn);
				com.CommandType = CommandType.Text;
				OleDbDataReader reader = com.ExecuteReader();
				
				DateTime ackTime;
				char[] tmp;
				while (reader.Read())
				{					
					switch ((ScheduleType)reader["type"])
					{
						case ScheduleType.ONETIME:
							ackTime = (DateTime)reader["next_time"];
							if (ackTime > DateTime.Now)
							{
								s = new OneTimeSchedule(reader["name"].ToString(), ackTime,reader["addr"].ToString(),
									Int16.Parse(reader["cmd"].ToString()),reader["param"].ToString());
								s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
								Scheduler.AddScheduleArray(s);
							}
							else
							{
								sqlstr = String.Format(@"Delete From iSchedule Where name='{0}'",reader["name"]);
								if (!db.execSQLnoQuery(sqlstr)) throw new SchedulerException(this.ToString()+"LoadFromDB() : Delete error!");
							}
							break;
						case ScheduleType.DAILY:
							tmp = reader["days"].ToString().ToCharArray();
							ackTime = (DateTime)reader["next_time"];
							while ((tmp[(int)ackTime.DayOfWeek]!='1') && (ackTime < DateTime.Now))
							{
								ackTime = ackTime.AddDays(1);
							}
							s = new DailySchedule(reader["name"].ToString(),ackTime,reader["days"].ToString(),
								reader["addr"].ToString(),Int16.Parse(reader["cmd"].ToString()),reader["param"].ToString());
							s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
							Scheduler.AddScheduleArray(s);
							break;
						case ScheduleType.WEEKLY:
							tmp = reader["days"].ToString().ToCharArray();
							ackTime = (DateTime)reader["next_time"];
							while ((tmp[(int)ackTime.DayOfWeek]!='1') && (ackTime < DateTime.Now))
							{
								ackTime = ackTime.AddDays(7);
							}
							s = new WeeklySchedule(reader["name"].ToString(),ackTime,
								reader["addr"].ToString(),Int16.Parse(reader["cmd"].ToString()),reader["param"].ToString());
							s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
							Scheduler.AddScheduleArray(s);
							break;
						case ScheduleType.MONTHLY:
							tmp = reader["days"].ToString().ToCharArray();
							ackTime = (DateTime)reader["next_time"];
							while ((tmp[(int)ackTime.DayOfWeek]!='1') && (ackTime < DateTime.Now))
							{
								ackTime = ackTime.AddMonths(1);
							}
							s = new MonthlySchedule(reader["name"].ToString(),ackTime,
								reader["addr"].ToString(),Int16.Parse(reader["cmd"].ToString()),reader["param"].ToString());
							s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
							Scheduler.AddScheduleArray(s);
							break;
						case ScheduleType.TIME:
							//tmp = reader["days"].ToString().ToCharArray();
							ackTime = (DateTime)reader["next_time"];
							while (ackTime < DateTime.Now)
							{
								DateTime a = ackTime;
								if (a.AddDays(1) > DateTime.Now)
									ackTime = ackTime.AddMinutes(Int32.Parse(reader["param"].ToString()));
								else
									ackTime = ackTime.AddDays(1);
							}
							s = new TimeSchedule(reader["name"].ToString(),ackTime,
								reader["addr"].ToString(),Int16.Parse(reader["cmd"].ToString()),reader["param"].ToString());
							s.OnTrigger += new EventScheduler.Invoke(ScheduleCallBack);
							Scheduler.AddScheduleArray(s);
							break;
					}

				}
				conn.Close();
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex.Message);
			}
		}		
		// ����ա�õ�Ǩ�ͺ���Ѿ���÷ӧҹ
		public void ScheduleCallBack(string scheduleName,string addr,int cmd,string param)
		{
			/*Console.WriteLine("ScheduleCallBack called from " 
				+ scheduleName + " @ " + DateTime.Now.ToLongTimeString()+"\n "
				+ "Addr=" +addr+" Cmd="+cmd.ToString()+" Param="+param);*/

			//string msg = "Called from "
			switch (cmd)
			{
				case 0:	// ON
				{
					Console.WriteLine(String.Format("[{0}] Power ON",scheduleName));
					Server.hw.Exec_On(addr);
				}
					break;
				case 1: // OFF
				{
					Console.WriteLine(String.Format("[{0}] Power OFF",scheduleName));
					Server.hw.Exec_Off(addr);
				}
					break;
				case 2: // DIM
				{
					Console.WriteLine(String.Format("[{0}] Set Dim Lv={1}",scheduleName,param));
					Server.hw.Exec_SetDim(addr,Int32.Parse(param));
				}
					break;
				case 3: // take shot
				{
					//Console.WriteLine("[Execute TakeShot] Port="+scheduleName.Substring(11));
					Server.hw.ManualCapture(Int32.Parse(addr),1);					
				}
					break;
				case 4: // Security
				{
					/*Console.WriteLine("Called from "+scheduleName+"@"+DateTime.Now.ToLongTimeString()+"\n"
						+ "Addr=" +addr+"Command = Alert Alarm");*/
					/*DBConn db = new DBConn();
					db.SetSecurityLevel(addr,1);*/
					Console.WriteLine(String.Format("[{0}] SMS to {1}",scheduleName,param));
					Server.hw.sendSMS("xxx");
				}
					break;
			}

		}	
		#endregion

		#region LogReader
		public string getLog()
		{
			string fileName = System.IO.Directory.GetCurrentDirectory()+@"\Log.txt";
			System.Text.StringBuilder sbuilder = new System.Text.StringBuilder();
			try
			{
				using ( StreamReader reader = new StreamReader(new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
							))
				{
					//start at the end of the file
					
					/*long ReadOffset = reader.BaseStream.Length;
					ReadOffset -= 10;
					if (ReadOffset < 0) return "";
					else
						reader.BaseStream.Seek(10, SeekOrigin.Begin);
					while (reader.Read() != '\n') {};*/
						//read out of the file until the EOF
						string line = "";
						while ( (line = reader.ReadLine()) != null )
							sbuilder.Append(line+"\n");
							//Console.WriteLine(line);

						//update the last max offset
						//lastMaxOffset = reader.BaseStream.Position;
					//}
				}
			}
			catch ( Exception ex )
			{
				Console.Error.WriteLine(ex.ToString());
			}
			return sbuilder.ToString();
		}
		#endregion
		
		#endregion

	}


}
