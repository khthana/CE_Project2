using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace iHome.Gui
{
	/// <summary>
	/// Summary description for BoardPort.
	/// </summary>
	public class BoardPort : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ComboBox cbBoardPort;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button bLocalPath;
		private System.Windows.Forms.TextBox tbLocalPath;
		private System.Windows.Forms.TextBox tbURL;
		private System.Windows.Forms.Button bSavePort;
		private System.Windows.Forms.Button bCancel;
		private DBConn db = new DBConn();
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BoardPort()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			OnLoad();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cbBoardPort = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.bLocalPath = new System.Windows.Forms.Button();
			this.tbURL = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tbLocalPath = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			this.bSavePort = new System.Windows.Forms.Button();
			this.bCancel = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// cbBoardPort
			// 
			this.cbBoardPort.Items.AddRange(new object[] {
															 "COM1",
															 "COM2",
															 "COM3",
															 "COM4",
															 "COM5",
															 "COM6"});
			this.cbBoardPort.Location = new System.Drawing.Point(144, 24);
			this.cbBoardPort.Name = "cbBoardPort";
			this.cbBoardPort.Size = new System.Drawing.Size(80, 21);
			this.cbBoardPort.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(72, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 24);
			this.label1.TabIndex = 1;
			this.label1.Text = "Com Port";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.cbBoardPort);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(288, 64);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Borad Connection";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.bLocalPath);
			this.groupBox2.Controls.Add(this.tbURL);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.tbLocalPath);
			this.groupBox2.Controls.Add(this.label2);
			this.groupBox2.Location = new System.Drawing.Point(8, 80);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(288, 88);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Camera save target";
			// 
			// bLocalPath
			// 
			this.bLocalPath.Location = new System.Drawing.Point(248, 24);
			this.bLocalPath.Name = "bLocalPath";
			this.bLocalPath.Size = new System.Drawing.Size(32, 24);
			this.bLocalPath.TabIndex = 4;
			this.bLocalPath.Text = "...";
			this.bLocalPath.Click += new System.EventHandler(this.bLocalPath_Click);
			// 
			// tbURL
			// 
			this.tbURL.Location = new System.Drawing.Point(48, 56);
			this.tbURL.Name = "tbURL";
			this.tbURL.Size = new System.Drawing.Size(192, 20);
			this.tbURL.TabIndex = 3;
			this.tbURL.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(32, 16);
			this.label3.TabIndex = 2;
			this.label3.Text = "URL";
			// 
			// tbLocalPath
			// 
			this.tbLocalPath.Location = new System.Drawing.Point(64, 24);
			this.tbLocalPath.Name = "tbLocalPath";
			this.tbLocalPath.ReadOnly = true;
			this.tbLocalPath.Size = new System.Drawing.Size(176, 20);
			this.tbLocalPath.TabIndex = 1;
			this.tbLocalPath.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 24);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Local path";
			// 
			// bSavePort
			// 
			this.bSavePort.Location = new System.Drawing.Point(72, 176);
			this.bSavePort.Name = "bSavePort";
			this.bSavePort.Size = new System.Drawing.Size(72, 24);
			this.bSavePort.TabIndex = 6;
			this.bSavePort.Text = "Save";
			this.bSavePort.Click += new System.EventHandler(this.bSavePort_Click_1);
			// 
			// bCancel
			// 
			this.bCancel.Location = new System.Drawing.Point(152, 176);
			this.bCancel.Name = "bCancel";
			this.bCancel.Size = new System.Drawing.Size(72, 24);
			this.bCancel.TabIndex = 7;
			this.bCancel.Text = "Cancel";
			this.bCancel.Click += new System.EventHandler(this.bCancel_Click);
			// 
			// BoardPort
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 210);
			this.Controls.Add(this.bCancel);
			this.Controls.Add(this.bSavePort);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "BoardPort";
			this.Text = "Setting";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void OnLoad()
		{
			cbBoardPort.SelectedIndex = db.GetPort() - 1;
			tbLocalPath.Text = db.getLocalCamSavePath();
			tbURL.Text = db.getURLCamSavePath();
		}

		private void bLocalPath_Click(object sender, System.EventArgs e)
		{
			if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
				tbLocalPath.Text = folderBrowserDialog1.SelectedPath+"\\";
		}
		private void bSavePort_Click_1(object sender, System.EventArgs e)
		{
			int port = cbBoardPort.SelectedIndex + 1;
			if (!db.SetPort(port))
				MessageBox.Show("Can 't change port","Error");
			if (!db.setLocalCamSavePath(tbLocalPath.Text))
				MessageBox.Show("Can 't change Local path","Error");
			if (!db.setURLCamSavePath(tbURL.Text))
				MessageBox.Show("Can 't change URL","Error");
		}

		private void bCancel_Click(object sender, System.EventArgs e)
		{
			this.Dispose();
		}


	}
}
