using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
namespace iHome.Gui
{
	/// <summary>
	/// Summary description for cameraview.
	/// </summary>
	public class cameraview : System.Windows.Forms.Form
	{
		public AxVIDEOOCXLib.AxVideoOCX axVideoOCX1;
		public AxVIDEOOCXTOOLSLib.AxVideoOCXTools axVideoOCXTools1;
		public int hImage;
		public int hsmImage;
		private System.Windows.Forms.Button bDriver;
		private System.Windows.Forms.Button bPreview;
		private System.Windows.Forms.Button bStop;
		private System.Windows.Forms.Button bConfig;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public cameraview()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(cameraview));
			this.axVideoOCX1 = new AxVIDEOOCXLib.AxVideoOCX();
			this.axVideoOCXTools1 = new AxVIDEOOCXTOOLSLib.AxVideoOCXTools();
			this.bDriver = new System.Windows.Forms.Button();
			this.bPreview = new System.Windows.Forms.Button();
			this.bStop = new System.Windows.Forms.Button();
			this.bConfig = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.axVideoOCX1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.axVideoOCXTools1)).BeginInit();
			this.SuspendLayout();
			// 
			// axVideoOCX1
			// 
			this.axVideoOCX1.Enabled = true;
			this.axVideoOCX1.Location = new System.Drawing.Point(8, 8);
			this.axVideoOCX1.Name = "axVideoOCX1";
			this.axVideoOCX1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axVideoOCX1.OcxState")));
			this.axVideoOCX1.Size = new System.Drawing.Size(320, 240);
			this.axVideoOCX1.TabIndex = 0;
			// 
			// axVideoOCXTools1
			// 
			this.axVideoOCXTools1.Enabled = true;
			this.axVideoOCXTools1.Location = new System.Drawing.Point(344, 8);
			this.axVideoOCXTools1.Name = "axVideoOCXTools1";
			this.axVideoOCXTools1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axVideoOCXTools1.OcxState")));
			this.axVideoOCXTools1.Size = new System.Drawing.Size(32, 32);
			this.axVideoOCXTools1.TabIndex = 1;
			// 
			// bDriver
			// 
			this.bDriver.Location = new System.Drawing.Point(344, 56);
			this.bDriver.Name = "bDriver";
			this.bDriver.Size = new System.Drawing.Size(88, 24);
			this.bDriver.TabIndex = 2;
			this.bDriver.Text = "Driver";
			this.bDriver.Click += new System.EventHandler(this.bDriver_Click);
			// 
			// bPreview
			// 
			this.bPreview.Location = new System.Drawing.Point(344, 88);
			this.bPreview.Name = "bPreview";
			this.bPreview.Size = new System.Drawing.Size(88, 24);
			this.bPreview.TabIndex = 3;
			this.bPreview.Text = "Init";
			this.bPreview.Click += new System.EventHandler(this.bPreview_Click);
			// 
			// bStop
			// 
			this.bStop.Location = new System.Drawing.Point(344, 120);
			this.bStop.Name = "bStop";
			this.bStop.Size = new System.Drawing.Size(88, 24);
			this.bStop.TabIndex = 4;
			this.bStop.Text = "Stop";
			this.bStop.Click += new System.EventHandler(this.bStop_Click);
			// 
			// bConfig
			// 
			this.bConfig.Location = new System.Drawing.Point(344, 168);
			this.bConfig.Name = "bConfig";
			this.bConfig.Size = new System.Drawing.Size(88, 24);
			this.bConfig.TabIndex = 5;
			this.bConfig.Text = "Config";
			this.bConfig.Click += new System.EventHandler(this.bConfig_Click);
			// 
			// cameraview
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(440, 258);
			this.Controls.Add(this.bConfig);
			this.Controls.Add(this.bStop);
			this.Controls.Add(this.bPreview);
			this.Controls.Add(this.bDriver);
			this.Controls.Add(this.axVideoOCXTools1);
			this.Controls.Add(this.axVideoOCX1);
			this.Name = "cameraview";
			this.Text = "Camera Configuration";
			((System.ComponentModel.ISupportInitialize)(this.axVideoOCX1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.axVideoOCXTools1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/*public bool Loading()
		{
			//axVideoOCX1.Mode = 0;
			//return axVideoOCX1.Init();
			return true;
		}*/
		public int getDriverCount()
		{			
			return axVideoOCX1.GetDriverCount();
		}
		public string getDriverName(int no)
		{
			return axVideoOCX1.GetDriverName(no);
		}
		//public int get
		/*private void start()
		{	
			//axVideoOCX1.Close();
			axVideoOCX1.Mode = 0;
			axVideoOCX1.Init();
			//Console.WriteLine(axVideoOCX1.Driver);			
			//axVideoOCX1.SetPreview(true);
			//hImage = axVideoOCX1.GetColorImageHandle();
			hImage = axVideoOCX1.GetColorImageHandle();
			axVideoOCX1.Start();			
		}
		private void stop()
		{
			axVideoOCX1.Stop();	
			axVideoOCX1.ReleaseImageHandle(hImage);
			axVideoOCX1.ReleaseImageHandle(hsmImage);
			axVideoOCX1.Close();
		}*/
		public string capture(int port,int size)
		{
			//if (!axVideoOCX1.IsAccessible) return "";
			if (axVideoOCX1 == null) axVideoOCX1 = new AxVIDEOOCXLib.AxVideoOCX();
			if (axVideoOCXTools1 == null) axVideoOCXTools1 = new AxVIDEOOCXTOOLSLib.AxVideoOCXTools();
			axVideoOCX1.Driver = port;
			axVideoOCX1.Mode = 0;
			axVideoOCX1.Init();
			hImage = axVideoOCX1.GetColorImageHandle();
			axVideoOCX1.Start();			

			string filename,filenameMobile;
			string mac = port.ToString();
			DBConn db = new DBConn();
			string root = db.getLocalCamSavePath();
			string path = root+"images/Webpage/"+mac+"/";
			string pathMobile = root+"images/Mobile/"+mac+"/";
			DateTime time = DateTime.Now;
			if (!Directory.Exists(path))
			{
				Directory.CreateDirectory(path);
			}
			if (!Directory.Exists(pathMobile))
			{
				Directory.CreateDirectory(pathMobile);
			}

			filename = path+time.ToString("dd-MM-yy_HH-mm-ss")+".jpg";
			filenameMobile = pathMobile+time.ToString("dd-MM-yy_HH-mm-ss")+"_small.jpg";

			while (axVideoOCX1.CtlCapture(hImage)==0){};
			hsmImage = axVideoOCX1.CreateColorImageHandle(152,164);
			axVideoOCXTools1.CtlResize(hImage,hsmImage);

			axVideoOCXTools1.SetTextStyle(hImage,"arial",10,0,0,255);
			axVideoOCXTools1.SetTextBackground(hImage,1,255,255,255);
			axVideoOCXTools1.DrawText(hImage,time.ToString("dd/MM/yy HH:mm:ss"),230,210);
			axVideoOCXTools1.DrawText(hImage,"  iHome-Monitors  ",230,220);
			
			axVideoOCXTools1.SetTextStyle(hsmImage,"arial",10,0,0,255);
			axVideoOCXTools1.SetTextBackground(hsmImage,1,255,255,255);
			axVideoOCXTools1.DrawText(hsmImage,time.ToString("dd/MM/yy HH:mm:ss"),52,124);
			axVideoOCXTools1.DrawText(hsmImage,"  iHome-Monitors  ",52,134);
			
			axVideoOCX1.SaveJPEG(hImage,50,filename);
			axVideoOCX1.SaveJPEG(hsmImage,50,filenameMobile);

			axVideoOCX1.Stop();	
			axVideoOCX1.ReleaseImageHandle(hImage);
			axVideoOCX1.ReleaseImageHandle(hsmImage);
			axVideoOCX1.Close();

			if (size==0) // mobile
				return time.ToString("dd-MM-yy_HH-mm-ss")+"_small.jpg";
			else   // web
				return time.ToString("dd-MM-yy_HH-mm-ss")+".jpg";
		}
		~cameraview()
		{
			axVideoOCX1.Close();
			Dispose();
		}

		private void bDriver_Click(object sender, System.EventArgs e)
		{
			axVideoOCX1.ShowDriverDlg();
		}

		private void bConfig_Click(object sender, System.EventArgs e)
		{
			axVideoOCX1.ShowSourceDlg();
		}

		private void bPreview_Click(object sender, System.EventArgs e)
		{
			axVideoOCX1.Close();
			axVideoOCX1.Init();
			axVideoOCX1.Mode = 0;
			axVideoOCX1.SetPreview(true);
			//axVideoOCX1.Start();
		}

		private void bStop_Click(object sender, System.EventArgs e)
		{
			axVideoOCX1.Close();
		}
	}
}
