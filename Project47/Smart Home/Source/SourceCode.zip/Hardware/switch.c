#include <reg51.h>
//define port name
sbit sw1=P1^0;
sbit sw2=P1^1;
sbit sw3=P1^2;
sbit sw4=P1^3;
sbit tog1=P1^4;
sbit tog2=P1^5;
sbit tog3=P1^6;
sbit tog4=P1^7;
sbit sta4=P3^2;
sbit sta3=P3^3;
sbit sta2=P3^4;
sbit sta1=P3^5;

//database 
data unsigned char status;

//instruction 
#define cmdon 100
#define cmdoff 101
#define info 201
#define regist 202
#define result 203
#define error 204
#define askalive 205

//const variables
#define mymac1 '5'
#define mymac2 '1'
#define startb1 0xA0
#define startb2 0xAF
#define stopb1 0xB0
#define stopb2 0xBF
#define on 0
#define off 1
#define sw_dev '0'
#define ch1 '1'
#define ch2 '2'
#define ch3 '3'
#define ch4 '4'
#define ok '1'

//buffer
data unsigned char sbuf[40];
data unsigned char RFbuff;

//global variables
data unsigned char index=0;
data unsigned char rec_com=0;
data unsigned char slen;//length of frame data from RF
data unsigned char header_complete=0;
//data unsigned char recseq=0;
//data unsigned char transeq=0;
data unsigned char data_com=0;
data unsigned char chksum=0;
data unsigned char chksum_com=0;
data unsigned char regist_complete=0;
data unsigned char needsend=0;
data unsigned char lastchksum=0;
data unsigned char inc1=0;
data unsigned char inc2=0;
data unsigned char inc3=0;
data unsigned char inc4=0;
data unsigned char firsttime=1;
data unsigned char timeout=1;

//Status toggle
data unsigned char push1=0;
data unsigned char push2=0;
data unsigned char push3=0;
data unsigned char push4=0;

void initialize_serial();
void send_RF(unsigned char dat);
void receive_RF();
//unsigned char change_seq(unsigned char seq);
void chk_header();
void receive_framedata();
void chk_sum();
void chk_framedata();
void chk_process();
void cmdswitch(unsigned char cmd);
void send_ok();
void send_RF_preamble();
void send_cmdswitch();
void send_regist();
void registry();
void myheader();
void delay(unsigned char wait);
unsigned char change_status(unsigned char change);
void checktoggle();

void main()
{
	unsigned short count=0;
	unsigned char loop=0;
	initialize_serial();
	delay(0x51);
//	registry();
//	needsend=1;
//	send_ok();
	loop=3;
	while(1)
	{
		if (count==0xFFFF && loop==10)
		{
			status=0;
			timeout=1;
		}
		if (timeout==1 && loop>=3)
		{
			loop=0;
			count=0;
			registry();
			if (firsttime==0)
				needsend=1;//need send status
//			timeout=0;
		}
		if (count==0x00FF)
		{
			lastchksum=0;
		}
		if (tog1==0 || tog2==0 || tog3==0 || tog4==0)
			checktoggle();
/*		if (tog1==0 && push1==0)
			inc1++;
		else inc1=0;
		if (tog2==0 && push2==0)
			inc2++;
		else inc2=0;
		if (tog3==0 && push3==0)
			inc3++;
		else inc3=0;
		if (tog4==0 && push4==0)
			inc4++;
		else inc4=0;
		if (tog1==1 && push1==1)
			push1=0;
		if (tog2==1 && push2==1)
			push2=0;
		if (tog3==1 && push3==1)
			push3=0;
		if (tog4==1 && push4==1)
			push4=0;
		if (inc1==1)
		{
			sw1=change_status(sw1);//change relay status
			sta1=sw1;//change_status(sta1);//change led status
			push1=1;
			needsend=1;
			inc1++;
		}
		if (inc2==1)
		{
			sw2=change_status(sw2);
			sta2=sw2;//change_status(sta2);
			push2=1;
			needsend=1;
			inc2++;
		}
		if (inc3==1)
		{
			sw3=change_status(sw3);
			sta3=sw3;//change_status(sta3);
			push3=1;
			needsend=1;
			inc3++;
		}
		if (inc4==1)
		{
			sw4=change_status(sw4);
			sta4=sw4;//change_status(sta4);
			push4=1;
			needsend=1;
			inc4++;
		}*/
 	    	
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				receive_framedata();						
			}
		}
		if (rec_com==1)
		{
			chk_framedata();
			if (data_com==1)
			{
				chk_process();
				loop=0;
				count=0;
			}			
		}
		if (count==0xFFFF)
		{	
			loop++;
			count=0;
		}
		else count++;

	}
}
void initialize_serial()
{
// Initialize the serial port (9600, 8, N, 1) 
	PCON &= 0x7F;							// Clear bit 7 of the PCON register (SMOD1 = 0)  
	SCON = 0x50;							// 0101,0000 (Mode 1 and RxD enable)			
	TMOD |= 0x20;							// Timer #1 in autoreload 8 bit mode
	TCON = 0x40;							// Set Timer #1 to run mode
	TH1 = 0xFA;//FA = 4800 FD=9600			// Baud rate is determined by
											// Timer #1 overflow rate
											// Baud Rate = (Fcpu / 384) / (256 - TH1)
											// Fcpu = 11.0592 MHz
											// TH1 = 253
	TR1 = 1;								// Turn on Timer 1
}
void send_RF(unsigned char dat)
{
	SBUF=dat;
	while(!TI);
	TI=0;
}
void receive_RF()
{		
	while (!RI);
	RI=0;
	RFbuff = SBUF;
}
void chk_header()
{
	receive_RF();
	if (RFbuff=='j')
	{
		receive_RF();
		if (RFbuff=='U')
			header_complete=1;
	}
}
void receive_framedata()
{
	char i=0;
	while (!(sbuf[i-1]==stopb2 && sbuf[i-2]==stopb1))
	{
		receive_RF();
		sbuf[i]=RFbuff;
		i++;
	}
	if (i<40)
	{
		slen=i;
		rec_com=1;
		header_complete=0;//clear
	}
}
void chk_framedata()
{
	if (sbuf[2]==mymac1 && sbuf[3]==mymac2)
	{
		chk_sum();
		if (chksum_com==1)
		{
			data_com=1;
			chksum_com=0;
		}
	}
	rec_com=0;//clear
}
void chk_sum()
{
	char i=2;
	chksum=0;
	for (i;i<slen-3;i++)
		chksum=chksum+sbuf[i];
	if (chksum==sbuf[i] && chksum!=lastchksum)
	{
		lastchksum=chksum;
		chksum_com=1;
	}
}
void delay(unsigned char wait)
{
	unsigned char i;
	for (i=0;i<wait;i++);
}
void chk_process()
{
	timeout=0;
	if (sbuf[4]==cmdon)
	{
		send_ok();
		cmdswitch(on);
//		delay();	
	}
	else if (sbuf[4]==cmdoff)
	{
		send_ok();
		cmdswitch(off);
//		delay();
		
	}
	else if (sbuf[4]==askalive)
	{
		firsttime=0;
		if (needsend==1)//need send status
		{
			send_cmdswitch();
			needsend=0;
		}
		else 
		{	
			send_regist();
			status=1;
		}
	}
	data_com=0;
}
void cmdswitch(unsigned char cmd)
{
	char i;
	i=7;
	while(!(sbuf[i]==stopb1))
	{
		if (sbuf[i]=='(')
		{
			i++; //channel
			if (sbuf[i]==ch1)
				{ sw1=cmd; sta1=sw1;}
			else if (sbuf[i]==ch2)
				{ sw2=cmd; sta2=sw2;}
			else if (sbuf[i]==ch3)
				{ sw3=cmd; sta3=sw3;}
		    else if (sbuf[i]==ch4)
				{ sw4=cmd; sta4=sw4;}
			i++; // ')'
		}
		i++;
	}
}

void send_ok()
{
	unsigned char i,sum=0;
	sum=mymac1+mymac2+result+sbuf[5]+sbuf[6]+ok;
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(result);
		send_RF(sbuf[5]);
		send_RF(sbuf[6]);
		send_RF(ok);
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
}
void send_cmdswitch()
{
	unsigned char sum;
	unsigned char c1=0,c2=0,c3=0,c4=0;
	char i;
	sum=mymac1+mymac2+info+'0'+'0'+'/'+mymac1+mymac2+','+cmdoff+','+','+','+','+'/';
	if (sw1==0)
	{
		c1=1;
		sum=sum+1;
	}
	if (sw2==0)
	{
		c2=1;
		sum=sum+1;
	}
	if (sw3==0)
	{
		c3=1;
		sum=sum+1;
	}
	if (sw4==0)
	{
		c4=1;
		sum=sum+1;
	}
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(info);
		send_RF('0');
		send_RF('0');
		send_RF('/');
		send_RF(mymac1);
		send_RF(mymac2);
		send_RF(',');
		send_RF(cmdoff);
		send_RF(',');
		send_RF(c1);
		send_RF(',');
		send_RF(c2);
		send_RF(',');
		send_RF(c3);
		send_RF(',');
		send_RF(c4);
		send_RF('/');
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
//	transeq=change_seq(transeq);
}
void send_RF_preamble()
{
	send_RF(0x55);
	send_RF(0xAA);
	send_RF('j');
	send_RF('U');
}
void send_regist()
{
	unsigned char sum=0,i;
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(regist);
		send_RF('0');
		send_RF('0');
		send_RF('(');
		send_RF(sw_dev);
		send_RF(',');
		send_RF('4');
		send_RF(')');
		sum=mymac1+mymac2+regist+'0'+'0'+'('+'0'+','+'4'+')';
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
}
void registry()
{
	unsigned short countloop=0;
	send_regist();
	while (countloop!=0xFFFF)
	{
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				header_complete=0;
				break;
			}
		}
		countloop++;
	}
	if (countloop!=0xFFFF)
		status=1;
}
void myheader()
{
	send_RF_preamble();
	send_RF(startb1);
	send_RF(startb2);
	send_RF(mymac1);
	send_RF(mymac2);
}
unsigned char change_status(unsigned char change)
{
	if (change==0)
		change=1;
	else change=0;
	return change;
}
void checktoggle()
{
		if (tog1==0 && push1==0)
			inc1++;
		else inc1=0;
		if (tog2==0 && push2==0)
			inc2++;
		else inc2=0;
		if (tog3==0 && push3==0)
			inc3++;
		else inc3=0;
		if (tog4==0 && push4==0)
			inc4++;
		else inc4=0;
		if (tog1==1 && push1==1)
			push1=0;
		if (tog2==1 && push2==1)
			push2=0;
		if (tog3==1 && push3==1)
			push3=0;
		if (tog4==1 && push4==1)
			push4=0;
		if (inc1==1)
		{
			sw1=change_status(sw1);//change relay status
			sta1=sw1;//change_status(sta1);//change led status
			push1=1;
			needsend=1;
			inc1++;
		}
		if (inc2==1)
		{
			sw2=change_status(sw2);
			sta2=sw2;//change_status(sta2);
			push2=1;
			needsend=1;
			inc2++;
		}
		if (inc3==1)
		{
			sw3=change_status(sw3);
			sta3=sw3;//change_status(sta3);
			push3=1;
			needsend=1;
			inc3++;
		}
		if (inc4==1)
		{
			sw4=change_status(sw4);
			sta4=sw4;//change_status(sta4);
			push4=1;
			needsend=1;
			inc4++;
		}
}
