#include <reg51.h>

//define port name
sbit sm1=P1^0;
sbit sm2=P1^1;
sbit sm3=P1^2;
sbit sm4=P1^3;
sbit pir1=P1^4;
sbit pir2=P1^5;
sbit pir3=P1^6;
sbit pir4=P1^7;
sbit siren=P3^7;

//data unsigned int count;

//const variables
#define mymac1 '6'
#define mymac2 '4'
#define startb1 0xA0
#define startb2 0xAF
#define stopb1 0xB0
#define stopb2 0xBF
#define on 1
#define off 0
#define secure_dev '3'
#define ok '1'

//channel number
#define ch1 '1'
#define ch2 '2'
#define ch3 '3'
#define ch4 '4'
#define ch5 '5'
#define ch6 '6'
#define ch7 '7'
#define ch8 '8'
#define ch9 '9'

//instruction 
#define cmdon 100
#define cmdoff 101
#define info 201
#define regist 202
#define result 203
#define error 204
#define askalive 205

//buffer
data unsigned char sbuf[30];
data unsigned char RFbuff;
data unsigned char status_dev[9]={0,0,0,0,0,0,0,0,0};

//Activate (default not activate)
data unsigned char act_sm1=1;
data unsigned char act_sm2=0;
data unsigned char act_sm3=0;
data unsigned char act_sm4=0;
data unsigned char act_pir1=1;
data unsigned char act_pir2=0;
data unsigned char act_pir3=0;
data unsigned char act_pir4=0;
data unsigned char status=0;
data unsigned char dev=1;
data unsigned char EndTimer=0;
data unsigned char process=0;

//global variables
data unsigned char index=0;
data unsigned char rec_com=0;
data unsigned char slen;//length of frame data from RF
data unsigned char header_complete=0;
data unsigned char data_com=0;
data unsigned char chksum=0;
data unsigned char chksum_com=0;
data unsigned char regist_complete=0;
data unsigned char needsend=0;
data unsigned char lastchksum=0;
data unsigned short inc=0;
data unsigned char chkloop=0;
data unsigned char firsttime=1;
data unsigned char timeout=1;

void initialize_serial();
void send_RF(unsigned char dat);
void receive_RF();
void chk_header();
void receive_framedata();
void chk_sum();
void chk_framedata();
void chk_process();
void send_ok();
void send_RF_preamble();
void send_regist();
void registry();
void myheader();
void cmdsecure(unsigned char cmd);
void send_cmdsecure();
void checksecuritydev();
void delay(unsigned char wait);
void enabletimer();
void incdev();
//unsigned char change_status(unsigned char change);

void endcounter() interrupt 1
{
	EndTimer=1;
}

void main()
{
	unsigned short count=0;
	unsigned char loop=0;
	TMOD |= 0x01;	// Timer 0, Mode 1, 16-bit timer
	TR0 = 0;		// Disable timer 0
	initialize_serial();
	delay(0x64);
//	registry();
//	needsend=1;
	loop=3;
	while(1)
	{	
/*		if (count==0xFFFF && loop==10)
		{
			status=0;
			timeout=1;
			loop=0;
			count=0;
		}
		if (timeout==1)
		{
			registry();
			needsend=1;//need send status
			timeout=0;
		}*/
		if (count==0xFFFF && loop==7)
		{
			status=0;
			timeout=1;
		}
		if (timeout==1 && loop>=2)
		{
			loop=0;
			count=0;
			registry();
			if (firsttime==0)
				needsend=1;//need send status
//			timeout=0;
		}
		if (count==0x00FF)
		{
			lastchksum=0;
		}
		
		checksecuritydev();

		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				receive_framedata();						
			}
		}
		if (rec_com==1)
		{
			chk_framedata();
			if (data_com==1)
			{
				chk_process();
				loop=0;
				count=0;
			}			
		}
		if (count==0xFFFF)
		{	
			loop++;
			count=0;
		}
		else count++;
	}
}
void initialize_serial()
{
// Initialize the serial port (9600, 8, N, 1) 
	PCON &= 0x7F;							// Clear bit 7 of the PCON register (SMOD1 = 0)  
	SCON = 0x50;							// 0101,0000 (Mode 1 and RxD enable)			
	TMOD |= 0x20;							// Timer #1 in autoreload 8 bit mode
	TCON = 0x40;							// Set Timer #1 to run mode
	TH1 = 0xFA;//FA = 4800 FD=9600			// Baud rate is determined by
											// Timer #1 overflow rate
											// Baud Rate = (Fcpu / 384) / (256 - TH1)
											// Fcpu = 11.0592 MHz
											// TH1 = 253
	TR1 = 1;								// Turn on Timer 1
}

void checksecuritydev()
{
	char active=0;
/*	if (dev==1)
 	 {
		if (sm1==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (sm1==0 || EndTimer==1)
		{
			if (sm1==0)
				act_sm1=1;
			else act_sm1=0;
			incdev();
		}

	}
	else if (dev==2)
	{
		if (sm2==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (sm2==0 || EndTimer==1)
		{
			if (sm2==0)
				act_sm2=1;
			else act_sm2=0;
			incdev();
		}
	}
	else if (dev==3)
	{
		if (sm3==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (sm3==0 || EndTimer==1)
		{
			if (sm3==0)
				act_sm3=1;
			else act_sm3=0;
			incdev();
		}
	}
	else if (dev==4)
	{
		if (sm4==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (sm4==0 || EndTimer==1)
		{
			if (sm4==0)
				act_sm4=1;
			else act_sm4=0;
			incdev();
		}
	}
	else if (dev==5)
	{
		if (pir1==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (pir1==0 || EndTimer==1)
		{
			if (pir1==0)
				act_pir1=1;
			else act_pir1=0;
			incdev();
		}
	}
	else if (dev==6)
	{
		if (pir2==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (pir2==0 || EndTimer==1)
		{
			if (pir2==0)
				act_pir2=1;
			else act_pir2=0;
			incdev();
		}
	}
	else if (dev==7)
	{
		if (pir3==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (pir3==0 || EndTimer==1)
		{
			if (pir3==0)
				act_pir3=1;
			else act_pir3=0;
			incdev();
		}
	}
	else if (dev==8)
	{
		if (pir4==1 && EndTimer==0 && process==0)
		{
			enabletimer();	
		}
		else if (pir4==0 || EndTimer==1)
		{
			if (pir4==0)
				act_pir4=1;
			else act_pir4=0;
			incdev();
		}
	}*/
	if (needsend==0)
	{
		if (act_sm1==1 && sm1==1)
		{
/*			inc=0;
			while(sm1)
			{
				if (inc>1000)
					break;
				inc++;
			}*/
			while(sm1)
			{
				inc++;
			}
			if (inc>100)
	 		{
				status_dev[4]=1;
				active=1;
			}
		}
		else
			status_dev[4]=0;

		if (act_sm2==1 && sm2==1)
		{
			inc=0;
/*			while(sm2)
			{
				if (inc>1000)
					break;
				inc++;
			}*/
			while(sm2)
			{
				inc++;
			}
			if (inc>100)
			{
				status_dev[5]=1;
				active=1;
			}
		}
		else
			status_dev[5]=0;

		if (act_sm3==1 && sm3==1)
		{
			inc=0;
/*			while(sm3)
			{
				if (inc>1000)
					break;
				inc++;
			}*/
			while(sm3)
			{
				inc++;
			}
			if (inc>100)
			{
				status_dev[6]=1;
				active=1;
			}
		}
		else
			status_dev[6]=0;

		if (act_sm4==1 && sm4==1)
		{
			inc=0;
/*			while(sm4)
			{	if (inc>1000)
					break;
				inc++;
			}*/
			while(sm4)
			{
				inc++;
			}
			if (inc>100)
			{
				status_dev[7]=1;
				active=1;
			}
		}
		else 
			status_dev[7]=0;

		if (act_pir1==1 && pir1==1)
		{
			status_dev[0]=1;
			active=1;
		}
		else 
			status_dev[0]=0;
		if (act_pir2==1 && pir2==1)
		{
			status_dev[1]=1;
			active=1;
		}
		else 
			status_dev[1]=0;
		if (act_pir3==1 && pir3==1)
		{
			status_dev[2]=1;
			active=1;
		}
		else 
			status_dev[2]=0;
		if (act_pir4==1 && pir4==1)
		{
			status_dev[3]=1;
			active=1;
		}
		else 
			status_dev[3]=0;
	}

	if (active)
	{
		needsend=1;
		status_dev[8]=1;
		siren=0;
	}
}
void enabletimer()
{
	process=1;
	TH0=0xFC;
	TL0=0x17;
	TR0=1;
}
void incdev()
{
	TR0=0;
	process=0;
	EndTimer=0;
	dev++;
	if (dev==10)
		dev=1;
}
void send_RF(unsigned char dat)
{
	SBUF=dat;
	while(!TI);
	TI=0;
}
void receive_RF()
{		
	while (!RI);
	RI=0;
	RFbuff = SBUF;
}
void chk_header()
{
	receive_RF();
	if (RFbuff=='j')
	{
		receive_RF();
		if (RFbuff=='U')
			header_complete=1;
	}
}
void receive_framedata()
{
	char i=0;
	while (!(sbuf[i-1]==stopb2 && sbuf[i-2]==stopb1))
	{
		receive_RF();
		sbuf[i]=RFbuff;
		i++;
	}
	if (i<40)
	{
		slen=i;
		rec_com=1;
		header_complete=0;//clear
	}
}
void chk_framedata()
{
	if (sbuf[2]==mymac1 && sbuf[3]==mymac2)
	{
		chk_sum();
		if (chksum_com==1)
		{
			data_com=1;
			chksum_com=0;
		}
	}
	rec_com=0;//clear
}
void chk_sum()
{
	char i=2;
	chksum=0;
	for (i;i<slen-3;i++)
		chksum=chksum+sbuf[i];
	if (chksum==sbuf[i] && chksum!=lastchksum)
	{
		lastchksum=chksum;
		chksum_com=1;
	}
}
void chk_process()
{
	timeout=0;
	if (sbuf[4]==cmdon)
	{
		cmdsecure(on);
		send_ok();
	}
	else if (sbuf[4]==cmdoff)
	{
		cmdsecure(off);
		send_ok();
	}
	else if (sbuf[4]==askalive)
	{
		firsttime=0;
		if (needsend==1 || chkloop==5)//need send status
		{
			send_cmdsecure();
			needsend=0;
			chkloop=0;
		}
		else 
		{	
			send_regist();
			status=1;
			chkloop++;
		}
	}
	data_com=0;
}
void send_ok()
{
	unsigned char i,sum=0;
	sum=mymac1+mymac2+result+sbuf[5]+sbuf[6]+ok;
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(result);
		send_RF(sbuf[5]);
		send_RF(sbuf[6]);
		send_RF(ok);
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
}
void send_RF_preamble()
{
	send_RF(0x55);
	send_RF(0xAA);
	send_RF('j');
	send_RF('U');
}
void send_regist()
{
	unsigned char sum=0,i;
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(regist);
		send_RF('0');
		send_RF('0');
		send_RF('(');
		send_RF(secure_dev);
		send_RF(',');
		send_RF('9');//number of channel
		send_RF(')');
		sum=mymac1+mymac2+regist+'0'+'0'+'('+secure_dev+','+'9'+')';
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
}
void registry()
{
	unsigned short countloop=0;
	send_regist();
	while (countloop!=0xFFFF)
	{
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				header_complete=0;
				break;
			}
		}
		countloop++;
	}
	if (countloop!=0xFFFF)
		status=1;
}
void myheader()
{
	send_RF_preamble();
	send_RF(startb1);
	send_RF(startb2);
	send_RF(mymac1);
	send_RF(mymac2);
}
void cmdsecure(unsigned char cmd)
{
	char i;
	i=7;
	while(!(sbuf[i]==stopb1))
	{
		if (sbuf[i]=='(')
		{
			i++; //channel
			if (sbuf[i]==ch1)
				act_pir1=cmd;
			else if (sbuf[i]==ch2)
				act_pir2=cmd;
			else if (sbuf[i]==ch3)
				act_pir3=cmd;
		    else if (sbuf[i]==ch4)
				act_pir4=cmd;
		    else if (sbuf[i]==ch5)
				act_sm1=cmd;
		    else if (sbuf[i]==ch6)
				act_sm2=cmd;
		    else if (sbuf[i]==ch7)
				act_sm3=cmd;
		    else if (sbuf[i]==ch8)
				act_sm4=cmd;
		    else if (sbuf[i]==ch9)
			{
				if (cmd==cmdon)
				{ 	siren=0; status_dev[8]=1; }
				else { siren=1; status_dev[8]=0; }
				needsend=1;
			}
			i++; // ')'
		}
		i++;
	}
}
void send_cmdsecure()
{
	unsigned char sum;
	char i,j;
	sum=mymac1+mymac2+info+'0'+'0'+'/'+mymac1+mymac2+','+','+','+','+','+','+','+','+','+'/';
	for (i=0;i<9;i++)
		sum=sum+status_dev[i];

	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(info);
		send_RF('0');
		send_RF('0');
		send_RF('/');
		send_RF(mymac1);
		send_RF(mymac2);
		for (j=0;j<9;j++)
		{
			send_RF(',');
			send_RF(status_dev[j]);
		}
		send_RF('/');
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
}
void delay(unsigned char wait)
{
	unsigned char i;
	for (i=0;i<wait;i++);
}


