#include <reg52.h>
sbit sync=P3^3;
sbit read=P3^7; //active low
sbit write=P3^6; //active low
sbit OE=P3^2; //active low
sbit sta1=P1^7;
sbit tog1=P1^6;
sbit CH = P1^0;
sbit tx=P3^0;
//sbit select=P1^5;

// ---------- Settings ----------
#define MAX_LEVEL 7	// Number of level - 1
#define divide 32

//instruction 
#define cmddim 102
#define info 201
#define regist 202
#define result 203
#define error 204
#define askalive 205

//const variables
#define mymac1 '7'
#define mymac2 '3'
#define startb1 0xA0
#define startb2 0xAF
#define stopb1 0xB0
#define stopb2 0xBF
#define dim_dev '1'
#define ch1 '1'
#define ok '1'
#define send 0
#define receive 1

//buffer
idata unsigned char sbuf[40];
idata unsigned char RFbuff;

//database 
data unsigned char status;
data unsigned char autolevel=0;

//Status toggle
data unsigned char push1=0;

//global variables
data unsigned char index=0;
data unsigned char rec_com=0;
data unsigned char slen;//length of frame data from RF
data unsigned char header_complete=0;
data unsigned char data_com=0;
data unsigned char chksum=0;
data unsigned char chksum_com=0;
data unsigned char regist_complete=0;
data unsigned char needsend=0;
data unsigned char lastchksum=0;
data unsigned char inc1=0;

data unsigned short PhaseLen;	// 'ON' Phase length (in cycles unit)
data unsigned short StepLen;		// How long does a level runs (cycles)
data unsigned short MapTable[8];	// Each level cycles
data unsigned short Remain;
data unsigned char CHLevel = 0;	//  Level of channel
data unsigned char TmpLev = 0;
data unsigned char start=0;
data unsigned char output=0;
data unsigned char firsttime=1;
data unsigned char timeout=1;

// ---------- Function Prototypes ----------
void GetPhaseLen(void);		// Get a cycle length (return on timer 0 counter TL0,TH0)
unsigned short GetAvgPhaseLen(void);	// Get average cycle length
void readADC();
void delay(int time);
void initialize_serial();
void send_RF_preamble();
void myheader();
void send_regist();
void registry();
void chk_header();
void receive_RF();
void send_RF(unsigned char dat);
void chk_framedata();
void chk_sum();
void receive_framedata();
unsigned char change_status(unsigned char change);
void chk_process();
void cmddimmer();
void send_ok();
void send_cmddimmer();
void delays(unsigned char wait);
//void Dimmer();
void Dimmer() interrupt 1
{
	if (start==1 && TmpLev>0)
	{
		start=0;
		CH=0;//turn on light
		Remain=0xFFFF-(MapTable[TmpLev]-PhaseLen);
		TH0 = ((unsigned short)Remain >> 8);//load remain timer
		TL0 = Remain;
 	    TR0 = 1;//enable timer 0
	}
	else 
	{
		CH=1;//turn off light
		TmpLev=CHLevel;
	}
}
void synchronize() interrupt 2
{
	start=1;
	TH0 = ((unsigned short)MapTable[TmpLev] >> 8);//load timer
 	TL0 = MapTable[TmpLev];
	TR0 = 1;//Enable timer 0
}
/*void test()
{
	unsigned short i;
	send_regist();
	for (i=0;i<30000;i++);
	send_ok();
	for (i=0;i<30000;i++);
}*/
void main(void)
{
	unsigned short count=0;
	unsigned char loop=0,i;
//	test();
	write=0;
	// Find phase length
	PhaseLen = GetAvgPhaseLen();
	StepLen = PhaseLen / (MAX_LEVEL+1);
	PhaseLen = 0xFFFF-PhaseLen;
	for (i=0; i<MAX_LEVEL; i++) {	// Create map table
		MapTable[i] = 0xFFFF-((MAX_LEVEL-i) * StepLen);
	}
	MapTable[MAX_LEVEL]=MapTable[MAX_LEVEL-1]+(StepLen/2);

	initialize_serial();
	// Init Timer 0
	TMOD |= 0x01;	// Timer 0, Mode 1, 16-bit timer
	TR0 = 0;		// Disable timer 0
	IT1 = 0x01;	//External interrupt1 active falling edge
	IE	= 0x86; //enable global,External interupt1 and interrupt Timer0
	
	delays(0x73);
//	registry();
//	needsend=1;
//	select=receive;
	loop=2;
	while (1) 
	{
		if (count==0xFFFF && loop==2 && sta1==1)
		{
//			status=0;
			timeout=1;
//			loop=0;
//			count=0;
		}
		if (count>5000 && sta1==0)
		{
			timeout=1;
//			count=0;
//			loop=0;
		}
		if (timeout==1 && ((loop>0 && sta1==1) ||(count>2500 && sta1==0)))
		{
			registry();
			if (firsttime==0)
				needsend=1;//need send status
//			timeout=0;
		}
		if (count==0x00FF)
		{
			lastchksum=0;
		}
		if (tog1==0 && push1==0)
			inc1++;
		else inc1=0;
		if (tog1==1 && push1==1)
			push1=0;
		if (inc1==1)
		{	
			sta1=change_status(sta1);//change led status
			// Check level
			if (sta1==0)
			{
				readADC();
				CHLevel=output/divide;
				count=0;
			}
			else CHLevel=autolevel;
			push1=1;
			needsend=1;
			inc1++;
		}
		else if (sta1==0)
		{
			readADC();
			output=output/divide;
			if (CHLevel!=output)
			{
				CHLevel=output;
				needsend=1;
			}
		}
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				receive_framedata();						
			}
		}
		if (rec_com==1)
		{
			chk_framedata();
			if (data_com==1)
			{
				chk_process();
				loop=0;
				count=0;
			}			
		}
		if (count==0xFFFF)
		{	
			loop++;
			count=0;
		}
		else count++;
	}	// Loop forever
}
void initialize_serial()
{
// Initialize the serial port (9600, 8, N, 1) 
	PCON &= 0x7F;							// Clear bit 7 of the PCON register (SMOD1 = 0)  
	SCON = 0x50;							// 0101,0000 (Mode 1 and RxD enable)			
	TMOD |= 0x20;							// Timer #1 in autoreload 8 bit mode
	TCON = 0x40;							// Set Timer #1 to run mode
	TH1 = 0xFA;//FA = 4800 FD=9600			// Baud rate is determined by
											// Timer #1 overflow rate
											// Baud Rate = (Fcpu / 384) / (256 - TH1)
											// Fcpu = 11.0592 MHz
											// TH1 = 253
	TR1 = 1;								// Turn on Timer 1
}

void readADC()
{
	write=1;
	read=0;
	delay(5);
	output=P2;
	read=1;
	write=0;
}
void delay(int time)
{
	int i,j;
	for (i=0;i<time;i++)
    	for  (j=0;j<10;j++);
}
void GetPhaseLen(void)
{
	// Init Timer 0
	TMOD |= 0x01;	// Timer 0, Mode 1, 16-bit timer
	TR0 = 0;		// Disable timer 0
	TH0 = 0;		// Reload timer
	TL0 = 0;

	// Wait for falling edge
	while (!sync) {}
	while (sync) {}
	TR0 = 1;		// Enable timer 0

	// Wait for rising edge
	while (!sync) {}
	TR0 = 0;		// Disable timer 0
}

unsigned short GetAvgPhaseLen(void)
{
	unsigned short avg;
	unsigned char i;

	GetPhaseLen();
	avg = ((unsigned short)TH0 << 8) | (unsigned short)TL0;
	for (i=0;i<19;i++) // Use 20 samples
	{	
		GetPhaseLen();
		avg = (avg + (((unsigned short)TH0 << 8) | (unsigned short)TL0)) / 2;
	}
	return avg;
}
void registry()
{
	unsigned short countloop=0;
	send_regist();
	while (countloop!=0xFFFF)
	{
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				header_complete=0;
				break;
			}
		}
		countloop++;
	}
	if (countloop==0xFFFF)
		status=1;
}
void send_regist()
{
	unsigned char sum=0,i;
//	select=send;
	sum=mymac1+mymac2+regist+'0'+'0'+'('+dim_dev+','+'1'+')';
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(regist);
		send_RF('0');
		send_RF('0');
		send_RF('(');
		send_RF(dim_dev);
		send_RF(',');
		send_RF('1');
		send_RF(')');		
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
//	select=receive;
}
void myheader()
{
	send_RF_preamble();
	send_RF(startb1);
	send_RF(startb2);
	send_RF(mymac1);
	send_RF(mymac2);
}
void send_RF(unsigned char dat)
{
	SBUF=dat;
	while(!TI);
	TI=0;
}
void send_RF_preamble()
{
	send_RF(0x55);
	send_RF(0xAA);
	send_RF('j');
	send_RF('U');
}
void receive_RF()
{		
	while (!RI);
	RI=0;
	RFbuff = SBUF;
}
void chk_header()
{
	receive_RF();
	if (RFbuff=='j')
	{
		receive_RF();
		if (RFbuff=='U')
			header_complete=1;
	}
}
void receive_framedata()
{
	char i=0;
	while (!(sbuf[i-1]==stopb2 && sbuf[i-2]==stopb1))
	{
		receive_RF();
		sbuf[i]=RFbuff;
		i++;
	}
	if (i<40)
	{
		slen=i;
		rec_com=1;
		header_complete=0;//clear
	}
}
void chk_framedata()
{
	if (sbuf[2]==mymac1 && sbuf[3]==mymac2)
	{
		chk_sum();
		if (chksum_com==1)
		{
			data_com=1;
			chksum_com=0;
		}
	}
	rec_com=0;//clear
}
void chk_sum()
{
	char i=2;
	chksum=0;
	for (i;i<slen-3;i++)
		chksum=chksum+sbuf[i];
	if (chksum==sbuf[i] && chksum!=lastchksum)
	{
		lastchksum=chksum;
		chksum_com=1;
	}
}
unsigned char change_status(unsigned char change)
{
	if (change==0)
		change=1;
	else change=0;
	return change;
}
void chk_process()
{
	if (sbuf[4]==cmddim)
	{
		cmddimmer();
		send_ok();
	}
	else if (sbuf[4]==askalive)
	{
		firsttime=0;
		if (needsend==1)//need send status
		{
			send_cmddimmer();
			needsend=0;
		}
		else 
		{	
			send_regist();
			status=1;
		}
	}
	data_com=0;
}
void cmddimmer()
{
	char i;
	i=7;
	while(!(sbuf[i]==stopb1))
	{
		if (sbuf[i]=='(')
		{
			i++; //channel
			if (sbuf[i]==ch1)
			{
 		    	i=i+2;
				autolevel=sbuf[i]-0x30;
				CHLevel=autolevel;
				sta1=1;
			}
			i++; // ')'
		}
		i++;
	}
}
void send_ok()
{
	unsigned char i,sum=0;
//	select=send;
	sum=mymac1+mymac2+result+sbuf[5]+sbuf[6]+ok;
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(result);
		send_RF(sbuf[5]);
		send_RF(sbuf[6]);
		send_RF(ok);
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
//	select=receive;
}
void send_cmddimmer()
{
	unsigned char sum;
	unsigned char c1=0;
	unsigned char i;
//	select=send;
	sum=mymac1+mymac2+info+'0'+'0'+'/'+mymac1+mymac2+','+cmddim+','+(CHLevel+0x30)+'/';
	for (i=0;i<20;i++)
	{
		myheader();
		send_RF(info);
		send_RF('0');
		send_RF('0');
		send_RF('/');
		send_RF(mymac1);
		send_RF(mymac2);
		send_RF(',');
		send_RF(cmddim);
		send_RF(',');
		send_RF(CHLevel+0x30);
		send_RF('/');
		send_RF(sum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
//	select=receive;
}
void delays(unsigned char wait)
{
	unsigned char i;
	for (i=0;i<wait;i++);
}
