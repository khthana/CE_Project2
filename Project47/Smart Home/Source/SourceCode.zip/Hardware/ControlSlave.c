#include <reg52.h>
sbit int0=P3^7;

//database
idata unsigned char sw[4][5]={{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}};
idata unsigned char dim[4][5]={{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}};
//idata unsigned char motion[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0}};
idata unsigned char secure[2][5]={{0,0,0,0,0},{0,0,0,0,0}};

//buffer
idata unsigned char sbuf[40]; //serial buffer
idata unsigned char ibuf[40]; //interrupt buffer
data unsigned char RFbuff;

//const variables
#define startb 0x02//STX
#define stopb 0x03//ETX
#define startb1 0xA0
#define startb2 0xAF
#define stopb1 0xB0
#define stopb2 0xBF
#define sw_dev '0'
#define dim_dev '1'
#define motion_dev '2'
#define secure_dev '3'
#define delete 0xDD


//global register
//data unsigned char sindex=0;
data unsigned char rec_com=0;
data unsigned char int_com=0;
data unsigned char sw_no=0;
data unsigned char dim_no=0;
data unsigned char secure_no=0;
data unsigned char motion_no=0;
data unsigned char index=0;
data unsigned char ilen;//length of frame data from interrupt 
data unsigned char slen;//length of frame data from RF
data unsigned char header_complete=0;
data unsigned char lastmac1=0;
data unsigned char lastmac2=0;
data unsigned char lastchksum=0;
data unsigned char data_com=0;
data unsigned char chksum=0;
data unsigned char chksum_com=0;
data unsigned char regist_complete=0;
//data unsigned char i;

//instruction
#define regist 202
#define result 203
#define error 204
#define info 201
#define askalive 205
#define ok '1'
#define notavailiable '1'

void initialize_serial();
void send_master(unsigned char DATA);
void receive_RF();
void chk_header();
void receive_framedata();
void chk_framedata();
void chk_sum();
unsigned char change_seq(unsigned char seq);
void send_framedata();
void chk_process();
void registry();
void sw_regist();
void dim_regist();
//void motion_regist();
void secure_regist();
void chk_alive();
char ask_alive(unsigned char mac1,unsigned char mac2);
void regist_ok();
void ask_reset();
void dead(unsigned char mac1,unsigned char mac2);
void send_RF_preamble();
void whatprocess();
void forward();
void WaitClientReady();
void Delete(unsigned char mc1,unsigned char mc2);

void receive_slave() interrupt 0
{
	ibuf[index]=P2;
	if (ibuf[index]==stopb)
	{
		int_com=1;//complete
		ilen=index;
		index=0;
	}
	else
		index++;
}

void send_RF(unsigned char dat)
{
	SBUF=dat;
	while(!TI);
	TI=0;
}

void main()
{
	unsigned short count=0; 
	unsigned char loop=0;
	P2=0xFF;//Define P2 is INPUT
	IT0 = 0x1;	//interrupt0 active falling edge
	IE	= 0x81; //enable global and interrupt0	
	initialize_serial();

	while(1)
	{
		if ((sw_no!=0 || dim_no!=0 || motion_no!=0 || secure_no!=0)&& count==0xFFFF && loop==1)
		{
			lastmac1=0;
			lastmac2=0;
			lastchksum=0;
			chk_alive();
			loop=0;
			count=0;
		}
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				receive_framedata();
//				send_framedata();
			}
		}
		if (rec_com==1)
		{
			chk_framedata();
			if (data_com==1)
			{
//				send_framedata();
				chk_process();
				data_com=0;
				loop=0;
				count=0;
			}			
		}
		if (int_com==1)
		{
			whatprocess();
			int_com=0;
		}
		if (count==0xFFFF)
		{	
			loop++;
			count=0;
		}
		else count++;
	}
}
void initialize_serial()
{
// Initialize the serial port (9600, 8, N, 1) 
	PCON &= 0x7F;							// Clear bit 7 of the PCON register (SMOD1 = 0)  
	SCON = 0x50;							// 0101,0000 (Mode 1 and RxD enable)			
	TMOD |= 0x20;							// Timer #1 in autoreload 8 bit mode
	TCON = 0x40;							// Set Timer #1 to run mode
	TH1 = 0xFA;//FA = 4800 FD=9600			// Baud rate is determined by
											// Timer #1 overflow rate
											// Baud Rate = (Fcpu / 384) / (256 - TH1)
											// Fcpu = 11.0592 MHz
											// TH1 = 253
	TR1 = 1;								// Turn on Timer 1
}
void receive_RF()
{		
	while (!RI);
	RI=0;
	RFbuff = SBUF;
}
void send_master(unsigned char DATA)
{
	unsigned char i;
	P0=DATA;
	int0=0;
	for (i=0;i<2;i++);
	int0=1;
	for (i=0;i<100;i++);
}
void chk_header()
{
	receive_RF();
	if (RFbuff=='j')
	{
		receive_RF();
		if (RFbuff=='U')
			header_complete=1;
	}
}
void receive_framedata()
{
	char i=0;
	while (!(sbuf[i-1]==stopb2 && sbuf[i-2]==stopb1))
	{
		receive_RF();
		sbuf[i]=RFbuff;
		i++;
	}
	if (i<40)
	{
		slen=i;
		rec_com=1;
		header_complete=0;//clear
	}
}
void chk_framedata()
{
	chk_sum();
	if (!(sbuf[2]==lastmac1 && sbuf[3]==lastmac2 && chksum==lastchksum))
	{
//		send_RF(4);
		if (chksum_com==1)
		{
//			send_RF(5);
			lastmac1=sbuf[2];
			lastmac2=sbuf[3];
			lastchksum=chksum;
			data_com=1;
			chksum_com=0;
		}
	}
	rec_com=0;//clear
}
void chk_sum()
{
	char i=2;
	chksum=0;
	for (i=2;i<slen-3;i++)
		chksum=chksum+sbuf[i];
	if (chksum==sbuf[i])
		chksum_com=1;
}
void send_framedata()
{	
	char i=2;
	send_master(startb);//this function use i too so don't use i global
//	send_RF(startb);
	for (i;i<slen-3;i++)
	{
		send_master(sbuf[i]);
//		send_RF(sbuf[i]);
	}
	send_master(stopb);
//	send_RF(stopb);
}
void chk_process()
{
	
	if (sbuf[4]==regist)
	{
//		send_RF(7);
		registry();
	}
	else if (sbuf[4]==info || sbuf[4]==result )//forward command to master 
	{
		forward();
	}
}
void registry()
{
	unsigned char device;
	device=sbuf[8];
	if (device==sw_dev)
	{
		sw_regist();
	}
	else if (device==dim_dev)
		dim_regist();
/*	else if (device==motion_dev)
		motion_regist();*/
	else if (device==secure_dev)
		secure_regist();
	if (regist_complete==1)
	{
//		WaitClientReady();
		send_framedata();
		regist_ok();
		regist_complete=0;//clear
	}
}
void WaitClientReady()
{
	unsigned short i;
	int j;
	for (j=0;j<3;j++)
	{
		for (i=0;i<0xFFFF;i++);
	}
}
void sw_regist()
{
	char i,match=0;
//	char match=0;
	for (i=0;i<4;i++)
	{	
		if (sbuf[2]==sw[i][0] && sbuf[3]==sw[i][1])
		{
//			send_RF(10);
			if (sw[i][2]==0)
			{
				sw[i][2]=1;//update status
				match=1;//found sw device in db
				regist_complete=1;
			}
			else match=1;
			break;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			//send_RF(11);
			//send_RF(sw[i][0]);
			//send_RF(sw[i][1]);
			if (sw[i][0]==0 && sw[i][1]==0)
			{
				//send_RF(12);
				sw[i][0]=sbuf[2];
				sw[i][1]=sbuf[3];
				sw[i][2]=1;
				regist_complete=1;
				sw_no++;
				break;
			}
		}
	}
}
void dim_regist()
{
	char i,match=0;
//	char match=0;
	for (i=0;i<4;i++)
	{	
		if (sbuf[2]==dim[i][0] && sbuf[3]==dim[i][1])
		{
//			send_RF(10);
			if (dim[i][2]==0)
			{
				dim[i][2]=1;//update status
				match=1;//found sw device in db
				regist_complete=1;
			}
			else match=1;
			break;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			//send_RF(11);
			//send_RF(sw[i][0]);
			//send_RF(sw[i][1]);
			if (dim[i][0]==0 && dim[i][1]==0)
			{
				//send_RF(12);
				dim[i][0]=sbuf[2];
				dim[i][1]=sbuf[3];
				dim[i][2]=1;
				regist_complete=1;
				dim_no++;
				break;
			}
		}
	}
}
/*void motion_regist()
{
	char i,match=0;
	for (i=0;i<4;i++)
	{	
		if (sbuf[2]==motion[i][0] && sbuf[3]==motion[i][1])
		{
			if (motion[i][2]==0)
			{	
				motion[i][2]=1;//update status
				match=1;//found motion device in db
				regist_complete=1;
			}
			else match=1;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			if (motion[i][0]==0 && motion[i][1]==0)
			{
				motion[i][0]=sbuf[2];
				motion[i][1]=sbuf[3];
				motion[i][2]=1;
				regist_complete=1;
				motion_no++;
				break;
			}
		}
	}
}*/
void secure_regist()
{
	char i,match=0;
	for (i=0;i<2;i++)
	{	
		if (sbuf[2]==secure[i][0] && sbuf[3]==secure[i][1])
		{
			if (secure[i][2]==0)
			{
				secure[i][2]=1;//update status
				match=1;//found security device in db
				regist_complete=1;
			}
			else match=1;
			break;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			if (secure[i][0]==0 && secure[i][1]==0)
			{
				secure[i][0]=sbuf[2];
				secure[i][1]=sbuf[3];
				secure[i][2]=1;
				regist_complete=1;
				secure_no++;
				break;
			}
		}
	}
}
void chk_alive()
{
	char i,done=0,allone=1;
	for (i=0;i<4;i++)//sw_no
		if (sw[i][3]==0 && sw[i][2]==1)//not check ,status availiable
		{
			if (int_com==1)
				break;
			if (ask_alive(sw[i][0],sw[i][1]))
			{
				if (int_com==1)
					break;
				sw[i][3]=1;//status device avaliable
				sw[i][4]=0;//clear deadtime
			}
			else 
			{
				if (int_com==1)
					break;
				sw[i][2]=0;//status device not avaliable
				dead(sw[i][0],sw[i][1]);
				sw[i][4]++;
			}
			done=1;
			break;
		}
		else if (sw[i][4]>0 && int_com!=1)
		{
			sw[i][4]++;
		}
		else if (sw[i][4]==5 && int_com!=1)
		{
			char k;
			for (k=0;k<5;k++)
				sw[i][k]=0;
			Delete(sw[i][0],sw[i][1]);
			sw_no--;
		}

	if (done==0)
		for (i=0;i<4;i++)
			if (dim[i][3]==0 && dim[i][2]==1)
			{
				if (int_com==1)
					break;
				if (ask_alive(dim[i][0],dim[i][1]))
				{
					if (int_com==1)
						break;
					dim[i][3]=1;//status device avaliable
					dim[i][4]=0;//clear deadtime
				}
				else 
				{
					if (int_com==1)
						break;
					dim[i][2]=0;//status device not avaliable
					dead(dim[i][0],dim[i][1]);
					dim[i][4]++;
				}
				done=1;
				break;
			}
			else if (dim[i][4]>0 && int_com!=1)
			{
				dim[i][4]++;
			}
			else if (dim[i][4]==5 && int_com!=1)
			{
				char k;
				for (k=0;k<5;k++)
					dim[i][k]=0;
				Delete(dim[i][0],dim[i][1]);
				dim_no--;
			}

	if (done==0)
		for (i=0;i<2;i++)
			if (secure[i][3]==0 && secure[i][2]==1)
			{
				if (int_com==1)
					break;
				if (ask_alive(secure[i][0],secure[i][1]))
				{
					if (int_com==1)
						break;
					secure[i][3]=1;//status device avaliable
					secure[i][4]=0;//clear deadtime
				}
				else 
				{
					if (int_com==1)
						break;
					secure[i][2]=0;//status device not avaliable
					dead(secure[i][0],secure[i][1]);
					secure[i][4]++;
				}
				done=1;
				break;
			}
			else if (secure[i][4]>0 && int_com!=1)
			{
				secure[i][4]++;
			}
			else if (secure[i][4]==5 && int_com!=1)
			{
				char k;
				for (k=0;k<5;k++)
					secure[i][k]=0;
				Delete(secure[i][0],secure[i][1]);
				secure_no--;
			}

	for (i=0;i<4;i++)
		if (sw[i][3]==0 && sw[i][2]==1)
			allone=0;
	for (i=0;i<4;i++)
		if (dim[i][3]==0 && dim[i][2]==1)
			allone=0;
	for (i=0;i<2;i++)
		if (secure[i][3]==0 && secure[i][2]==1)
			allone=0;


	if (allone==1)
		ask_reset();
}
char ask_alive(unsigned char mac1,unsigned char mac2)
{
	unsigned short count=0;
	unsigned char done=0,i,retransmit=0;
	chksum=0;
	chksum=mac1+mac2+askalive+'0'+'0';
	while(!done && retransmit<4 )
	{	
		for (i=0;i<20;i++)
		{
			send_RF_preamble();
			send_RF(startb1);
			send_RF(startb2);
			send_RF(mac1);
			send_RF(mac2);
			send_RF(askalive);
			send_RF('0');//ID1
			send_RF('0');//ID2
			send_RF(chksum);
			send_RF(stopb1);
			send_RF(stopb2);
			if (int_com==1)
				break;
		}
		count=0;
		while (count<0x09FF)
		{
			if (RI)
			{
				chk_header();
				if (header_complete==1)
				{
					header_complete=0;
					done=1;
					break;
				}
			}
	   		count++;
			if (int_com==1)
				break;
		}
		retransmit++;
		if (int_com==1)
			break;
	}
/*	while (count!=0xFFFF)
	{
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				header_complete=0;
				break;
			}
		}
	   count++;
	}*/
/*	if (count!=0xFFFF) 
		return 1;
	else return 0;*/
	return done;
}
void regist_ok()
{
	unsigned char i; 
	chksum=0;
	chksum=sbuf[2]+sbuf[3]+result+'0'+'0'+ok;
	for (i=0;i<20;i++)
	{
		send_RF_preamble();
		send_RF(startb1);
		send_RF(startb2);
		send_RF(sbuf[2]);
		send_RF(sbuf[3]);
		send_RF(result);
		send_RF('0');//ID1
		send_RF('0');//ID2
		send_RF(ok);//ok
		send_RF(chksum);
		send_RF(stopb1);
		send_RF(stopb2);
	}
}
void ask_reset()
{
	char i;
	for (i=0;i<4;i++)
		sw[i][3]=0;
	for (i=0;i<4;i++)
		dim[i][3]=0;
   	for (i=0;i<4;i++)
		secure[i][3]=0;
}
void dead(unsigned char mac1,unsigned char mac2)
{
	send_master(startb);
	send_master('0');//mac CB1
	send_master('0');//mac CB2
	send_master(error);
	send_master('0');//id1
	send_master('0');//id2
	send_master('(');
	send_master(mac1);
	send_master(mac2);
	send_master(',');
	send_master(notavailiable);//not availiable
	send_master(')');
	send_master(stopb);
}
void send_RF_preamble()
{
	send_RF(0x55);
	send_RF(0xAA);
	send_RF('j');
	send_RF('U');
}
void whatprocess()
{
	unsigned char i,j;
	unsigned char done=0,retransmit=0,count;
//	unsigned char j;
	while(!done && retransmit<4)
	
	{	
		for (i=0;i<20;i++)
		{
			chksum=0;
			send_RF_preamble();
			send_RF(startb1);
			send_RF(startb2);
			for (j=1;j<ilen;j++)
			{
				send_RF(ibuf[j]);
				chksum=chksum+ibuf[j];
			}
			send_RF(chksum);
			send_RF(stopb1);
			send_RF(stopb2);
		}
		if (RI)
		{
			chk_header();
			if (header_complete==1)
			{
				receive_framedata();
//				send_framedata();
			}
		}
		count=0;
		while (count<0x09FF)
		{
			if (RI)
			{
				chk_header();
				if (header_complete==1)
				{
					header_complete=0;
					done=1;
					break;
				}
			}
	   		count++;
		}
		retransmit++;
	}
}
void forward()
{
	send_framedata();
}
void Delete(unsigned char mc1,unsigned char mc2)
{
	send_master(startb);
	send_master(mc1);
	send_master(mc2);
	send_master(delete);
	send_master(stopb);
}
