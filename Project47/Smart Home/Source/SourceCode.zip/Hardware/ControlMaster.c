#include <reg52.h>
sbit int0=P3^7;

//database
idata unsigned char sw[4][7]={0};//id1,id2,status,ch1,ch2,ch3,ch4 
idata unsigned char dim[4][4]={0};//id1,id2,status,ch
idata unsigned char secure[2][12]={0};//id1,id2,status,pir1,pir.2,pir3,pir4,sm1,sm2,sm3,sm4,alert
//idata unsigned char motion[4][4]={0};//id1,id2,status,ch*/

//buffer
idata unsigned char sbuf[40]; //serial buffer    /////////////////30
idata unsigned char ibuf[40]; //interrupt buffer   /////////////////30

//const variables
#define sw_dev '0'
#define dim_dev '1'
#define motion_dev '2'
#define secure_dev '3'
#define ch1 '1'
#define ch2 '2'
#define ch3 '3'
#define ch4 '4'
#define startb 0x02//STX
#define stopb 0x03//ETX
#define delete 0xDD

//global variables
idata unsigned char sindex=0; //index of serial buffer from server
idata unsigned char index=0; //index of serial buffer
idata unsigned char sw_no=0;
idata unsigned char dim_no=0;
data unsigned char secure_no=0;
data unsigned char motion_no=0;
data unsigned char rec_com=0;//receive frame data from server complete
data unsigned char int_com=0;//receive frame data from slave complete
data unsigned char ilen;//length of frame data from interrupt
data unsigned char slen;//length of frame data from server
//data unsigned char serversender=0;
data unsigned char regist_complete=0;
data unsigned char seq='0';
data unsigned char ack='0';
data unsigned char NextFrameToSend='0';
data unsigned char FrameExpected='0';
data unsigned char waitok=0;
data unsigned char match=0;
data unsigned char i=0;
data unsigned char j=0;
data unsigned short count=0;
data unsigned char loop; 

//instruction
#define cmdon 100
#define cmdoff 101
#define cmddim 102
#define detail 105
#define on 1
#define off 0
#define read 200
#define info 201
#define regis 202
#define result 203
#define err 204//error command
#define ok '1'
#define notavailiable '1'
#define request 'R'
#define establish 'E'
 
void initialize_serial();
void send_serial(unsigned char dat);
void whatprocess();
void registry();
void sw_regist();
void dim_regist();
//void motion_regist();
void secure_regist();
void send_framedata();
//void change_seq_ack();
void error();
void chkprocess();
void cmdswitch(unsigned char cmd);
struct macaddress finddbofmac(unsigned char mac1,unsigned char mac2);
void send_cmd();
void send_slave(unsigned char DATA);
void readdb();
void readsw(unsigned char mc1,unsigned char mc2,unsigned char id1,unsigned char id2);
void readdim(unsigned char mc1,unsigned char mc2,unsigned char id1,unsigned char id2);
void readallsw();
void readalldim();
void myheader();
void not_availiable(unsigned char id1,unsigned char id2);
void update_swdb();
void update_dimdb();
void cmddimmer();
void readsecure(unsigned char mc1,unsigned char mc2,unsigned char id1,unsigned char id2);
void readallsecure();
void cmdsecure(unsigned char cmd);
void update_securedb();
void clearcountloop();
void requestconnect();

void receive_slave() interrupt 0
{
	ibuf[index]=P2;
	if (ibuf[index]==stopb)
	{
		int_com=1;//complete
		ilen=index;
		index=0;
	}
	else
		index++;
}
void receive_serial() interrupt 4
{
	if (RI)
	{
		RI=0;
		sbuf[sindex]= SBUF;
		if (sbuf[sindex]==stopb)
		{
			rec_com=1;//receive frame data from server complete
			slen=sindex;//length of frame data
			sindex=0;//reset index serial buffer for next frame
		}
		else
			sindex++;
	}
}
struct macaddress
{
	unsigned char dev;
	unsigned char pos;
};
void main()
{
	P2=0xFF;//Define P2 is INPUT
	IT0 = 0x1;	//interrupt0 active falling edge
	IE	= 0x91; //enable global,serial interupt and interrupt0
//	IE	= 0x81;
	initialize_serial();
	loop=3;
	while(1)
	{
/*		if (waitok==1)
		{
			count++;
			if (count==0xFFFF)
			{
				count=0;
				loop++;
			}
		} 
		if (loop>=3)
		{
			clearcountloop();
			NextFrameToSend='0';
			FrameExpected='0';
			requestconnect();
			waitok=1;
		}*/
		if (rec_com==1)
		{
/*			char i;
			for (i=0;i<=slen;i++)
				send_serial(sbuf[i]);*/
			chkprocess();
			rec_com=0;
		}
		if (int_com==1 && waitok==0)
//		if (int_com==1)
		{
/*			char i;
			for (i=0;i<=ilen;i++)
				send_serial(ibuf[i]);*/
			whatprocess();
			int_com=0;
		}

	}
}
void initialize_serial()
{
// Initialize the serial port (9600, 8, N, 1) 
	PCON &= 0x7F;							// Clear bit 7 of the PCON register (SMOD1 = 0)  
	SCON = 0x50;							// 0101,0000 (Mode 1 and RxD enable)			
	TMOD |= 0x20;							// Timer #1 in autoreload 8 bit mode
	TCON = 0x40;							// Set Timer #1 to run mode
	TH1 = 0xFD;;//	0XFA;					// Baud rate is determined by
											// Timer #1 overflow rate
											// Baud Rate = (Fcpu / 384) / (256 - TH1)
											// Fcpu = 11.0592 MHz
											// TH1 = 253
	TR1 = 1;								// Turn on Timer 1
}
void send_serial(unsigned char dat)
{
	SBUF=dat;
	while(!TI);
	TI=0;
}
void clearcountloop()
{
	loop=0;
	count=0;
}
void whatprocess()
{
	struct macaddress db;
	db=finddbofmac(ibuf[1],ibuf[2]);
	if (ibuf[3]==regis)//add new device
	{
		registry();
	}
	else if (ibuf[3]==err)//error device not availiable
	{
		error();
		waitok=1;
	}
	else if (ibuf[3]==info)
	{
		if (db.dev==sw_dev)
		{
			seq=NextFrameToSend;
			ack=('1'-FrameExpected)+'0';
			update_swdb();
			readsw(ibuf[1],ibuf[2],ibuf[4],ibuf[5]);
			waitok=1;
			//change_seq_ack();
		}
		else if (db.dev==dim_dev)
		{
			seq=NextFrameToSend;
			ack=('1'-FrameExpected)+'0';
			update_dimdb();
			readdim(ibuf[1],ibuf[2],ibuf[4],ibuf[5]);
			waitok=1;
			//change_seq_ack();
		}
		else if (db.dev==secure_dev)
		{
			seq=NextFrameToSend;
			ack=('1'-FrameExpected)+'0';
			update_securedb();
			readsecure(ibuf[1],ibuf[2],ibuf[4],ibuf[5]);
			waitok=1;
			//change_seq_ack();
		}
	}
	else if (ibuf==delete)
	{
		char k;
		if (db.dev==sw_dev)
		{
			for (k=0;k<7;k++)
				sw[db.pos][k]=0;
			sw_no--;
		}
		else if (db.dev==dim_dev)
		{
			for (k=0;k<4;k++)
				dim[db.pos][k]=0;
			dim_no--;
		}
		else if (db.dev==secure_dev)
		{
			for (k=0;k<12;k++)
				secure[db.pos][k]=0;
			secure_no--;
		}
	}
	else 
	{ 
		send_framedata();
		waitok=1;
	}
}
void registry()
{
	unsigned char device;
	device=ibuf[7];
	if (device==sw_dev)
		sw_regist();
	else if (device==dim_dev)
		dim_regist();
/*	else if (device==motion_dev)
		motion_regist();*/
	else if (device==secure_dev)
		secure_regist();
	if (regist_complete==1)
	{
		send_framedata();
		regist_complete=0;//clear
		waitok=1;
	}
}
void sw_regist()
{
	char i,match=0;
//	match=0;
	for (i=0;i<4;i++)
	{	
		if (ibuf[1]==sw[i][0] && ibuf[2]==sw[i][1])
		{
			if (sw[i][2]==0)
			{
				sw[i][2]=1;//update status
				match=1;//found sw device in db
				regist_complete=1;
			}
			else match=1;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			if (sw[i][0]==0 && sw[i][1]==0)
			{
				sw[i][0]=ibuf[1];
				sw[i][1]=ibuf[2];
				sw[i][2]=1;
				regist_complete=1;
				sw_no++;
				break;
			}
		}
	}
}
void dim_regist()
{
	char i,match=0;
	for (i=0;i<4;i++)
	{	
		if (ibuf[1]==dim[i][0] && ibuf[2]==dim[i][1])
		{
			if (dim[i][2]==0)
			{
				dim[i][2]=1;//update status
				match=1;//found dimmer device in db
				regist_complete=1;
			}
			else match=1;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			if (dim[i][0]==0 && dim[i][1]==0)
			{
				dim[i][0]=ibuf[1];
				dim[i][1]=ibuf[2];
				dim[i][2]=1;
				regist_complete=1;
				dim_no++;
				break;
			}
		}
	}
}
/*void motion_regist()
{
	char i,match=0;
	for (i=0;i<4;i++)
	{	
		if (ibuf[1]==motion[i][0] && ibuf[2]==motion[i][1])
		{
			if (motion[i][2]==0)
			{	
				motion[i][2]=1;//update status
				match=1;//found motion device in db
				regist_complete=1;
			}
			else match=1;
		}
	}
	if (match==0)
	{
		for (i=0;i<4;i++)
		{
			if (motion[i][0]==0 && motion[i][1]==0)
			{
				motion[i][0]=ibuf[1];
				motion[i][1]=ibuf[2];
				motion[i][2]=1;
				regist_complete=1;
				motion_no++;
				break;
			}
		}
	}
}*/
void secure_regist()
{
	char i,match=0;
	for (i=0;i<2;i++)
	{	
		if (ibuf[1]==secure[i][0] && ibuf[2]==secure[i][1])
		{
			if (secure[i][2]==0)
			{
				secure[i][2]=1;//update status
				match=1;//found security device in db
				regist_complete=1;
			}
			else match=1;
		}
	}
	if (match==0)
	{
		for (i=0;i<2;i++)
		{
			if (secure[i][0]==0 && secure[i][1]==0)
			{
				secure[i][0]=ibuf[1];
				secure[i][1]=ibuf[2];
				secure[i][2]=1;
				regist_complete=1;
				secure_no++;
				break;
			}
		}
	}
}
void send_framedata()
{
	char i;
	seq=NextFrameToSend;
	ack=('1'-FrameExpected)+'0';
	send_serial(startb);
	send_serial(seq);
	send_serial(ack);
	for (i=1;i<ilen;i++)
		send_serial(ibuf[i]);
	send_serial(stopb);
	//change_seq_ack();
}
/*void change_seq_ack()
{
	if (seq=='1' && ack=='1' )
	{
		seq='0';
		ack='1';
	}
	else if (seq=='0' && ack=='0' )
	{
		seq='1';
		ack='0';
	}
	else if (seq=='0' && ack=='1' )
	{
		seq='0';
		ack='0';
	}
	else if (seq=='1' && ack=='0' )
	{
		seq='1';
		ack='1';
	}
}*/
void error()
{
	struct macaddress db;
	db=finddbofmac(ibuf[7],ibuf[8]);
	if (ibuf[10]==notavailiable)
	{
		if (db.dev==sw_dev)
			sw[db.pos][2]=0;	
		else if (db.dev==dim_dev) 
			dim[db.pos][2]=0;
		else if (db.dev==secure_dev) 
			secure[db.pos][2]=0;

		send_framedata();
	}
}
struct macaddress finddbofmac(unsigned char mac1,unsigned char mac2)
{
	struct macaddress db;
	char match=0,i;
//	match=0;
	if (sw_no>0)
	{
		for (i=0;i<4;i++)
		{
			if (mac1==sw[i][0] && mac2==sw[i][1])
			{
				match=1;
				db.dev=sw_dev;
				db.pos=i;
				break;
			}
		}
	}
	if (match==0 && dim_no>0)
	{
		for (i=0;i<4;i++)
		{
			if (mac1==dim[i][0] && mac2==dim[i][1])
			{
				match=1;
				db.dev=dim_dev;
				db.pos=i;
				break;
			}
		}
	}
	if (match==0 && secure_no>0)
	{
		for (i=0;i<2;i++)
		{
			if (mac1==secure[i][0] && mac2==secure[i][1])
			{
				match=1;
				db.dev=secure_dev;
				db.pos=i;
				break;
			}
		}
	}
	return db;
}
void requestconnect()
{
	send_serial(startb);
	send_serial(request);
	send_serial(stopb);
}
void chkprocess()
{
/*	if (sbuf[0]==startb && sbuf[1]==request && sbuf[2]==stopb)
	{
		send_serial(startb);
		send_serial(establish);
		send_serial(stopb);
		waitok=1;
	}
	else if (sbuf[0]==startb && sbuf[1]==establish && sbuf[2]==stopb)
	{
		seq=NextFrameToSend;
		ack=('1'-FrameExpected)+'0';
		send_serial(startb);
		send_serial(seq);
		send_serial(ack);
		send_serial(stopb);
	}
	else*/ if (sbuf[0]==startb && sbuf[1]==FrameExpected  && sbuf[3]==stopb)
	{
//		clearcountloop();
		//change_seq_ack();
		FrameExpected = ('1'-FrameExpected)+'0';
		if (sbuf[2]==NextFrameToSend)
			NextFrameToSend = ('1'-NextFrameToSend)+'0';
		waitok=0;

/*		send_serial(NextFrameToSend);
		send_serial(waitok);*/
	}

//	else if (sbuf[0]==startb && sbuf[1]==seq && sbuf[2]==ack && sbuf[slen]==stopb)
	else if (sbuf[0]==startb && sbuf[1]==FrameExpected && sbuf[slen]==stopb)
	{
		struct macaddress db;
		db=finddbofmac(sbuf[3],sbuf[4]);
//		clearcountloop();
		//change_seq_ack();
		FrameExpected = ('1'-FrameExpected)+'0';
		if (sbuf[2]==NextFrameToSend)
			NextFrameToSend = ('1'-NextFrameToSend)+'0';
		if (sbuf[5]==cmdon)
		{
			if (db.dev==sw_dev)
				cmdswitch(on);
			send_cmd();
		}
		else if (sbuf[5]==cmdoff)
		{
			if (db.dev==sw_dev)
				cmdswitch(off);
			send_cmd();
		}
		else if (sbuf[5]==cmddim)
		{
			cmddimmer();
			send_cmd();
		}
		else if (sbuf[5]==read)
		{
			seq=NextFrameToSend;
			ack=('1'-FrameExpected)+'0';
			readdb();
			//change_seq_ack();
		}		
	}
}
void cmdswitch(unsigned char cmd)//
{
//	char i,j,match=0;
//	send_serial(2);
//	char j;
	match=0;
	for (i=0;i<4;i++)
	{
		if (sbuf[3]==sw[i][0] && sbuf[4]==sw[i][1] && sw[i][2]==1)
		{
			match=1;
			j=8;
			while(sbuf[j]!=stopb)
			{
				if (sbuf[j]=='(')
				{
					j++;
					if (sbuf[j]==ch1)
						sw[i][3]=cmd;
					else if (sbuf[j]==ch2)
						sw[i][4]=cmd;
					else if (sbuf[j]==ch3)
						sw[i][5]=cmd;
 				    else if (sbuf[j]==ch4)
						sw[i][6]=cmd;
					j++;
				}
				j++;
			}
			break;
		}
	}
/*	if (match==0)
	{
		send_error();
	}*/
}
void cmddimmer()//
{
//	char i,j,match=0;
//	send_serial(2);
//	char j;
	match=0;
	for (i=0;i<4;i++)
	{
		if (sbuf[3]==dim[i][0] && sbuf[4]==dim[i][1] && dim[i][2]==1)
		{
			match=1;
			j=8;
			while(sbuf[j]!=stopb)
			{
				if (sbuf[j]=='(')
				{
					j++;
					if (sbuf[j]==ch1)
					{
						j=j+2;
						dim[i][3]=sbuf[11];
					}
/*					else if (sbuf[j]==ch2)
						sw[i][4]=cmd;
					else if (sbuf[j]==ch3)
						sw[i][5]=cmd;
 				    else if (sbuf[j]==ch4)
						sw[i][6]=cmd;*/
					j++;
				}
				j++;
			}
			break;
		}
	}

/*	if (match==0)
	{
		send_error();
	}*/
}
/*void cmdsecure(unsigned char cmd)//
{
//	char i,j,match=0;
//	send_serial(2);
//	char j;
	match=0;
	for (i=0;i<secure_no;i++)
	{
		if (sbuf[3]==secure[i][0] && sbuf[4]==secure[i][1] && secure[i][2]==1)
		{
			match=1;
			j=8;
			while(sbuf[j]!=stopb)
			{
				if (sbuf[j]=='(')
				{
					j++;
					if (sbuf[j]==ch1)
						secure[i][3]=cmd;
					else if (sbuf[j]==ch2)
						secure[i][4]=cmd;
					else if (sbuf[j]==ch3)
						secure[i][5]=cmd;
 				    else if (sbuf[j]==ch4)
						secure[i][6]=cmd;
					j++;
				}
				j++;
			}
			break;
		}
	}
/*	if (match==0)
	{
		send_error();
	}
}*/
void send_cmd()
{
	char i;
//	send_serial(3);
	send_slave(startb);
	for (i=3;i<=slen;i++)
		send_slave(sbuf[i]);
//	change_seq_ack();

/*	send_serial(startb);
	for (i=3;i<=slen;i++)
		send_serial(sbuf[i]);*/
}
void send_slave(unsigned char DATA)
{
	unsigned char i;
	P0=DATA;
	int0=0;
	for (i=0;i<2;i++);
	int0=1;
	for (i=0;i<100;i++);
}
void readdb()
{
	if (sbuf[8]==sw_dev)
	{
		readallsw();
	}
	else if (sbuf[8]==dim_dev)
	{
		readalldim();
	}
/*	else if (sbuf[8]==motion_dev)
	{
		
	}*/
	else if (sbuf[8]==secure_dev)
	{
		readallsecure();
	}
	waitok=1;
	
}
void readsw(unsigned char mc1,unsigned char mc2,unsigned char id1,unsigned char id2)
{
	char i,j,match=0;
//	send_serial(7);
	for (i=0;i<4;i++)
	{
		if (mc1==sw[i][0] && mc2==sw[i][1] && sw[i][2]==1)
			match=1;
	}
	if (match)
	{
		myheader();
		send_serial(info);
		send_serial(id1);
		send_serial(id2);
		for (i=0;i<4;i++)
		{
			if (mc1==sw[i][0] && mc2==sw[i][1] && sw[i][2]==1)
			{
				send_serial('/');
				send_serial(sw[i][0]);
				send_serial(sw[i][1]);
				send_serial(',');
				send_serial(cmdoff);
				for (j=3;j<7;j++)
				{
					send_serial(',');
					if (sw[i][j]==on)
						send_serial('1');//status of ch on
					else send_serial('0');//status of ch off
				}
				send_serial('/');
			}
		}
		send_serial(stopb);
	}
	else not_availiable(id1,id2);
}
void readallsw()
{
//	char i,j,match=0;
//	send_serial(7);
	match=0;
	if (sw_no!=0)
	{
		for (i=0;i<4;i++)
			if (sw[i][0]!=0 && sw[i][1]!=0 && sw[i][2]==1)
				match=1;
	}
	if (match)
	{
		myheader();
		send_serial(info);
		send_serial(sbuf[6]);
		send_serial(sbuf[7]);
		for (i=0;i<4;i++)
		{
			if (sw[i][2]==1)
			{
				send_serial('/');
				send_serial(sw[i][0]);
				send_serial(sw[i][1]);
				send_serial(',');
				send_serial(cmdoff);
				for (j=3;j<7;j++)
				{
					send_serial(',');
					if (sw[i][j]==on)
						send_serial('1');//status of ch on
					else send_serial('0');//status of ch off
				}
				send_serial('/');
			}
		}
		send_serial(stopb);
	}
	else not_availiable(sbuf[6],sbuf[7]);
}
void readdim(unsigned char mc1,unsigned char mc2,unsigned char id1,unsigned char id2)
{
	char i,match=0;
//	send_serial(7);
	for (i=0;i<4;i++)
	{
		if (mc1==dim[i][0] && mc2==dim[i][1] && dim[i][2]==1)
			match=1;
	}
	if (match)
	{
		myheader();
		send_serial(info);
		send_serial(id1);
		send_serial(id2);
		for (i=0;i<4;i++)
		{
			if (mc1==dim[i][0] && mc2==dim[i][1] && dim[i][2]==1)
			{
				send_serial('/');
				send_serial(dim[i][0]);
				send_serial(dim[i][1]);
				send_serial(',');
				send_serial(cmddim);
				send_serial(',');
				send_serial(dim[i][3]);
				send_serial('/');
			}
		}
		send_serial(stopb);
	}
	else not_availiable(id1,id2);
}
void readalldim()
{
//	char i,match=0;
//	send_serial(7);
	match=0;
	if (dim_no!=0)
	{
		for (i=0;i<4;i++)
			if (dim[i][0]!=0 && dim[i][1]!=0 && dim[i][2]==1)
				match=1;
	}
	if (match)
	{
		myheader();
		send_serial(info);
		send_serial(sbuf[6]);
		send_serial(sbuf[7]);
		for (i=0;i<4;i++)
		{
			if (dim[i][2]==1)
			{
				send_serial('/');
				send_serial(dim[i][0]);
				send_serial(dim[i][1]);
				send_serial(',');
				send_serial(cmddim);
				send_serial(',');
				send_serial(dim[i][3]);
				send_serial('/');
			}
		}
		send_serial(stopb);
	}
	else not_availiable(sbuf[6],sbuf[7]);
}
void readsecure(unsigned char mc1,unsigned char mc2,unsigned char id1,unsigned char id2)
{
	char i,j,match=0;
//	send_serial(7);
	for (i=0;i<2;i++)
	{
		if (mc1==secure[i][0] && mc2==secure[i][1] && secure[i][2]==1)
			match=1;
	}
	if (match)
	{
		myheader();
		send_serial(info);
		send_serial(id1);
		send_serial(id2);
		for (i=0;i<2;i++)
		{
			if (mc1==secure[i][0] && mc2==secure[i][1] && secure[i][2]==1)
			{
				send_serial('/');
				send_serial(secure[i][0]);
				send_serial(secure[i][1]);
				send_serial(',');
				send_serial(detail);
				for (j=3;j<12;j++)
				{
					send_serial(',');
					if (secure[i][j]==on)
						send_serial('1');//status of ch on
					else send_serial('0');//status of ch off
				}
				send_serial('/');
			}
		}
		send_serial(stopb);
	}
	else not_availiable(id1,id2);
}
void readallsecure()
{
//	char i,j,match=0;
//	send_serial(7);
	match=0;
	if (secure_no!=0)
	{
		for (i=0;i<4;i++)
			if (secure[i][0]!=0 && secure[i][1]!=0 && secure[i][2]==1)
				match=1;
	}
	if (match)
	{
		myheader();
		send_serial(info);
		send_serial(sbuf[6]);
		send_serial(sbuf[7]);
		for (i=0;i<2;i++)
		{
			if (secure[i][2]==1)
			{
				send_serial('/');
				send_serial(secure[i][0]);
				send_serial(secure[i][1]);
//				send_serial(',');
//				send_serial(cmdoff);
				for (j=3;j<12;j++)
				{
					send_serial(',');
					if (secure[i][j]==on)
						send_serial('1');//status of ch on
					else send_serial('0');//status of ch off
				}
				send_serial('/');
			}
		}
		send_serial(stopb);
	}
//	else not_availiable(sbuf[6],sbuf[7]);
}
void not_availiable(unsigned char id1,unsigned char id2)
{
	myheader();	
	send_serial(err);
	send_serial(id1);
	send_serial(id2);
	send_serial(notavailiable);
	send_serial(stopb);
}
void myheader()
{
	send_serial(startb);
	send_serial(seq);
	send_serial(ack);
	send_serial('0');//mymac1
	send_serial('0');//mymac2		
}
void update_swdb()
{
	char i,match=0;
//	send_serial(6);
	if (ibuf[10]==cmdoff)
	{
		for (i=0;i<4;i++)
		{
			if (ibuf[1]==sw[i][0] && ibuf[2]==sw[i][1] && sw[i][2]==1)
			{
				match=1;
				sw[i][3]=ibuf[12];
				sw[i][4]=ibuf[14];
				sw[i][5]=ibuf[16];
				sw[i][6]=ibuf[18];
				break;
			}
		}
	}
}
void update_dimdb()
{
	char i,match=0;
//	send_serial(6);
	if (ibuf[10]==cmddim)
	{
		for (i=0;i<4;i++)
		{
			if (ibuf[1]==dim[i][0] && ibuf[2]==dim[i][1] && dim[i][2]==1)
			{
				match=1;
				dim[i][3]=ibuf[12];
				break;
			}
		}
	}
}
void update_securedb()
{
	char i,match=0;
//	send_serial(6);
	for (i=0;i<2;i++)
	{
		if (ibuf[1]==secure[i][0] && ibuf[2]==secure[i][1] && secure[i][2]==1)
		{
			match=1;
			secure[i][3]=ibuf[10];
			secure[i][4]=ibuf[12];
			secure[i][5]=ibuf[14];
			secure[i][6]=ibuf[16];
			secure[i][7]=ibuf[18];
			secure[i][8]=ibuf[20];
			secure[i][9]=ibuf[22];
			secure[i][10]=ibuf[24];
			secure[i][11]=ibuf[26];
			break;
		}
	}
}
