<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{	
		if (!IsPostBack){
			webbrowser web = new webbrowser();		
			smstxtbox.Text =  web.getSmsNumber();
		}
	}
	
	void Control_Click(object sender, System.EventArgs e)
	{
		webbrowser web = new webbrowser();
		String smsnum = smstxtbox.Text;
		bool response = web.SetSmsNumber(smsnum);		
		if (response) Session["onoff"]=1;
			else Session["onoff"]=0;
		Response.Redirect("security.aspx");		
	}
		
</SCRIPT>


<HTML>
<HEAD>
<TITLE>Security</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_security -->

<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>SMS Setting</B></FONT><BR>
    <BR>
  </DIV>
  
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="35%">&nbsp;</TD>
      <TD width="30%">
          <TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF0000" bgcolor="#FFFFCC">
            <TR>
              <TD><DIV align="center"><B><FONT color="#FF0000" size="-1"><BR>Enter phone number<BR></FONT></B> 
              		<asp:TextBox id="smstxtbox" runat="server" MaxLength="9" Columns="8" ></asp:TextBox><BR>
		  			<asp:Button id="Button_ok" runat="server" Text="OK" OnClick="Control_Click"></asp:Button><BR><BR></DIV>        	
			  </TD>
            </TR>
          </TABLE>
      </TD>
      <TD width="35%">&nbsp;</TD>
    </TR>
  </TABLE>
    
</FORM>


<BR>
<BR>
</BODY>
</HTML>
