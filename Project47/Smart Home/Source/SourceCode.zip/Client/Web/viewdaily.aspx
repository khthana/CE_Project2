<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
		//if (!IsPostBack) LoadTable(sender,e);
		if (Session["response"]!=null)
		{
			int ses = (int) Session["response"];
			if (ses!=0) 
			{
				showAlert(ses);
				Session["response"]=0;
			}
		}		
	}
	
	DataSet XMLtoDataSet(int mode)
	{
			webbrowser myService = new webbrowser();
			string data = myService.Exec_wListSchedulesByType(mode);    
			MemoryStream stream = new MemoryStream();
			byte[] bt = Encoding.ASCII.GetBytes(data);
			stream.Write(bt,0,bt.Length);
			stream.Position = 0;
			DataSet ds = new System.Data.DataSet();
			ds.ReadXml(stream);
			return ds;
	}
		
	void LoadTable(object sender, System.EventArgs e)
	{
			int sel = 1;
			DataSet ds = XMLtoDataSet(sel);
			if (ds.Tables.Count!=0)
			{			
				DataTable myTable = ds.Tables["Table"];			
							
				for(int i=0;i<ds.Tables["Table"].Rows.Count;i++)
				{
					//type
					String s = ds.Tables["Table"].Rows[i]["type"].ToString();
					if (s=="1") ds.Tables["Table"].Rows[i]["type"]="Daily";
					
					//command
					s = ds.Tables["Table"].Rows[i]["cmd"].ToString();
					if (s=="0") ds.Tables["Table"].Rows[i]["cmd"]="Power ON";
					else if (s=="1") ds.Tables["Table"].Rows[i]["cmd"]="Power OFF";
					else if (s=="2") ds.Tables["Table"].Rows[i]["cmd"]="Dimmer";
					else if (s=="3") ds.Tables["Table"].Rows[i]["cmd"]="Capture";
					
					//next_time
					s = ds.Tables["Table"].Rows[i]["next_time"].ToString();
					String year = s.Substring(0,4);
					String month = s.Substring(5,2);
					String date = s.Substring(8,2);
					String hour = s.Substring(11,2);
					String minute = s.Substring(14,2);
					ds.Tables["Table"].Rows[i]["next_time"]=date+"/"+month+"/"+year+" at "+hour+":"+minute;
									
					//days					
					s = ds.Tables["Table"].Rows[i]["days"].ToString();
					String d ="";
					char[] sc = s.ToCharArray();
					
					for(int j=0;j<sc.Length;j++)
					{
						switch(j)
						{
							case 0	:	if (sc[j]=='1') d=d+"Sun ";
										break;
							case 1	:	if (sc[j]=='1') d=d+"Mon ";	
										break;
							case 2	:	if (sc[j]=='1') d=d+"Tue ";
										break;
							case 3	:	if (sc[j]=='1') d=d+"Wed ";
										break;
							case 4	:	if (sc[j]=='1') d=d+"Thu ";
										break;
							case 5	:	if (sc[j]=='1') d=d+"Fri ";
										break;
							case 6	:	if (sc[j]=='1') d=d+"Sat ";
										break;							
						}
						ds.Tables["Table"].Rows[i]["days"] = d;
					}
				}	
				DataGrid1.DataSource = ds;			
				DataGrid1.DataMember = "Table";			
				DataBind();
				DataGrid1.Visible = true;
			}
	}
			
		
	void Control_Click(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
			String name = e.Item.Cells[1].Text;
			webbrowser web = new webbrowser();
			switch(((Button) e.CommandSource).ID)
			{
				case "Button_Edit":					
					Session["name"] = name;
					Session["datetime"] = e.Item.Cells[5].Text;
					Session["weekday"] = e.Item.Cells[4].Text;
					Session["addr"] = e.Item.Cells[0].Text;
					String command = e.Item.Cells[3].Text;
					Session["cmd"] = command;
					if (command=="Dimmer") 
						Session["level"] = e.Item.Cells[7].Text;
					Response.Redirect("editdaily.aspx");															
					break;
				case "Button_Delete":
					int response = web.RemoveSchedule(name);
					if (response==0 && DataGrid1.Items.Count==1)
						DataGrid1.Visible = false;					
					showAlert(response+1);																				
					break;
			}
	}
	
	void showAlert(int response)
	{
		String txtalert="";
		if (response==1)
			txtalert = " C o m p l e t e";		
		else txtalert = "       F a i l ! !";
			
		String alertScript = "<script>";
		alertScript += "alert('"+txtalert+"')";
		alertScript += "</script"+">";
		Response.Write(alertScript);
	}
	
</SCRIPT>


<HTML>
<HEAD>
<TITLE>Daily</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_schedule -->

<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>Daily</B></FONT><BR>
    <BR>
  </DIV>
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">    
    <TR> 
      <TD width="36%">&nbsp;</TD>
      <TD width="28%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FF6633">
    <TR>
    <TD><DIV align="center"><B><FONT size="-1"><A href="adddaily.aspx">Add New Schedule</A></FONT></B></DIV></TD></TR>
</TABLE>
</TD>
      <TD width="36%">&nbsp;</TD>
    </TR>
  </TABLE>
  <BR>
 
 <DIV align="center"><asp:datagrid id="DataGrid1" runat="server" OnItemCommand="Control_Click" OnPreRender="LoadTable" CssClass="devtable" Width="100%" ForeColor="#999999" GridLines="Vertical"
	CellPadding="1" BackColor="White" BorderWidth="1px" BorderStyle="None" BorderColor="#999999" HorizontalAlign="Center"
	AutoGenerateColumns="False">
	<FooterStyle BackColor="#CCCC99"></FooterStyle>
	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
	<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
	<ItemStyle BackColor="#F7F7DE"></ItemStyle>
	<HeaderStyle Font-Bold="True" HorizontalAlign="Center" ForeColor="White" BackColor="#FFCC00"></HeaderStyle>
	<Columns>
		<asp:BoundColumn DataField="addr" HeaderText="Address">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="name" HeaderText="Schedule Name">
		</asp:BoundColumn>
		<asp:BoundColumn DataField="type" HeaderText="Type">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>		
		<asp:BoundColumn DataField="cmd" HeaderText="Command">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="days" HeaderText="Do Every">			
		</asp:BoundColumn>
		<asp:BoundColumn DataField="next_time" HeaderText="Next Time">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>		
		<asp:TemplateColumn HeaderText="Control">
			<ItemTemplate>
				<asp:Button id="Button_Edit" runat="server" Text="Edit"></asp:Button>
				<FONT> </FONT>
				<asp:Button id="Button_Delete" runat="server" Text="Delete"></asp:Button>				
				
			</ItemTemplate>
		</asp:TemplateColumn>
		<asp:BoundColumn DataField="param" HeaderText="Level" Visible="false">			
		</asp:BoundColumn>
	</Columns>
	<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
</asp:datagrid></DIV>
</FORM>

<BR>
<BR>
</BODY>
</HTML>
