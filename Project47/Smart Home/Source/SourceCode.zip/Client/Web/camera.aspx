<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
		if (Session["response"]!=null)
		{
			int ses = (int) Session["response"];
			if (ses!=0) 
			{
				showAlert(ses);
				Session["response"]=0;
			}
		}
	}
	
	DataSet XMLtoDataSet()
	{
			webbrowser myService = new webbrowser();
			string data = myService.ViewCamera();    
			MemoryStream stream = new MemoryStream();
			byte[] bt = Encoding.ASCII.GetBytes(data);
			stream.Write(bt,0,bt.Length);
			stream.Position = 0;
			DataSet ds = new System.Data.DataSet();
			ds.ReadXml(stream);
			return ds;
	}
		
	void LoadTable(object sender, System.EventArgs e)
	{
			DataSet ds = XMLtoDataSet();			
			if (ds.Tables.Count!=0)
			{				
				DataGrid1.DataSource = ds;			
				DataGrid1.DataMember = "ListCamera";			
				DataBind();
			}
	}
	
		
	void Control_Click(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
			String port = e.Item.Cells[0].Text;
			webbrowser web = new webbrowser();
			bool response = false;
			switch(((Button) e.CommandSource).ID)
			{
				case "Button_Capture":					
					String url = web.ManualCapture(int.Parse(port),1);
					if (url!=null){
						imagecap.ImageUrl = url;
						imagelabel.Text =  e.Item.Cells[1].Text;
						imagecap.Visible = true;
						imagelabel.Visible = true;
						showAlert(1);
					}else showAlert(2);					
					break;
				case "Button_Delete":					
					imagecap.Visible = false;
					imagelabel.Visible = false;
					response = web.RemoveCamera(int.Parse(port));
					if (response && DataGrid1.Items.Count==1)
						DataGrid1.Visible = false;
					if (response) showAlert(1); else showAlert(2);										
					break;
				case "Button_Set":					
					imagecap.Visible = false;
					imagelabel.Visible = false;
					DropDownList dimlev = (DropDownList) e.Item.Cells[4].Controls[5];
					String lev = dimlev.SelectedItem.Text;
					response = web.UpdateCaptureTime(int.Parse(port),int.Parse(lev));
					if (response) showAlert(1); else showAlert(2);					
					break;
				
			}
	}
	
	void showAlert(int response)
	{
		String txtalert="";
		if (response==1)
			txtalert = " C o m p l e t e";		
		else txtalert = "       F a i l ! !";
			
		String alertScript = "<script>";
		alertScript += "alert('"+txtalert+"')";
		alertScript += "</script"+">";
		Response.Write(alertScript);
	}
</SCRIPT>


<HTML>
<HEAD>
<TITLE>Camera</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>

<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_camera -->

<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>Camera</B></FONT><BR>
    <BR>
  </DIV>
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">    
    <TR> 
      <TD width="36%">&nbsp;</TD>
      <TD width="28%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FF6633">
    <TR>
    <TD><DIV align="center"><B><FONT size="-1"><A href="addcamera.aspx">Add New Camera</A></FONT></B></DIV></TD></TR>
</TABLE>
</TD>
      <TD width="36%">&nbsp;</TD>
    </TR>
  </TABLE>
  <BR>
  
  <DIV align="center">
  
<asp:datagrid id="DataGrid1" runat="server" OnItemCommand="Control_Click" OnPreRender="LoadTable" CssClass="devtable" Width="85%" ForeColor="#999999" GridLines="Vertical"
	CellPadding="4" BackColor="White" BorderWidth="1px" BorderStyle="None" BorderColor="#999999" HorizontalAlign="Center"
	AutoGenerateColumns="False">
	<FooterStyle BackColor="#CCCC99"></FooterStyle>
	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
	<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
	<ItemStyle BackColor="#F7F7DE"></ItemStyle>
	<HeaderStyle Font-Bold="True" HorizontalAlign="Center" ForeColor="White" BackColor="#FFCC00"></HeaderStyle>
	<Columns>
		<asp:BoundColumn DataField="port" HeaderText="Port">
			<ItemStyle HorizontalAlign="Center" Width="8%"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="name" HeaderText="Camera Name">
			<ItemStyle Width="20%"></ItemStyle>
		</asp:BoundColumn>		
		<asp:BoundColumn DataField="details" HeaderText="Detail">
			<ItemStyle Width="20%"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="cap_time" HeaderText="Cap. Time(min)">
			<ItemStyle HorizontalAlign="Center" Width="18%"></ItemStyle>
		</asp:BoundColumn>
		<asp:TemplateColumn HeaderText="Control">
			<ItemStyle HorizontalAlign="Center" Width="35%"></ItemStyle>
			<ItemTemplate>
				<asp:Button id="Button_Capture" runat="server" Text="Capture"></asp:Button>
				<asp:Button id="Button_Delete" runat="server" Text="Delete"></asp:Button>
				<BR><FONT face="Tahoma" > Set Capture Time </FONT>
				<asp:DropDownList id="timeList" runat="server">
									<asp:ListItem Value="0">0</asp:ListItem>
									<asp:ListItem Value="5">5</asp:ListItem>
									<asp:ListItem Value="10">10</asp:ListItem>
									<asp:ListItem Value="15">15</asp:ListItem>
									<asp:ListItem Value="30">30</asp:ListItem>
									<asp:ListItem Value="60">60</asp:ListItem>
				</asp:DropDownList>
				<FONT face="Tahoma"> </FONT>
				<asp:Button id="Button_Set" runat="server" Text="Set"></asp:Button>				
								
			</ItemTemplate>
		</asp:TemplateColumn>
	</Columns>
	<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
</asp:datagrid>
  <BR>
  <BR>
  
  <asp:Image id="imagecap" runat="server" Visible="false" ImageUrl=""></asp:Image>
  <BR>
    
    <asp:Label id="imagelabel" runat="server" Visible="false" CssClass="whitetext">Capture</asp:Label>
    </DIV>
</FORM>


<BR>
<BR>
</BODY>
</HTML>
