<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>
<%@ import Namespace="System.Web.UI.WebControls" %>

<SCRIPT runat="server" >
		
	void Page_Load(object sender, System.EventArgs e) 
	{
			if (!IsPostBack) LoadTable(sender,e);
			if (Session["setdim"]!=null)
			{
				int s = (int) Session["setdim"];
				if (s!=-1) showAlert(s);
				Session["setdim"]=-1;
			}
	}
	
	DataSet XMLtoDataSet(int mode)
	{
			webbrowser myService = new webbrowser();
			string data = myService.Exec_wListDevice(mode);    
			MemoryStream stream = new MemoryStream();
			byte[] bt = Encoding.ASCII.GetBytes(data);
			stream.Write(bt,0,bt.Length);
			stream.Position = 0;
			DataSet ds = new System.Data.DataSet();
			ds.ReadXml(stream);
			return ds;
	}
		
	void LoadTable(object sender, System.EventArgs e)
	{
			int sel = 2;
			DataSet ds = XMLtoDataSet(sel);
			if (ds.Tables.Count!=0)
			{
				DataTable myTable = ds.Tables["Device"];			
							
				for(int i=0;i<ds.Tables["Device"].Rows.Count;i++)
				{
					//connection
					String s = ds.Tables["Device"].Rows[i]["status"].ToString();
					if (s=="0") ds.Tables["Device"].Rows[i]["status"]="FAIL";
					else ds.Tables["Device"].Rows[i]["status"]="OK";
					
					//model
					s = ds.Tables["Device"].Rows[i]["model"].ToString();
					if (s=="01") ds.Tables["Device"].Rows[i]["model"]="DIM";				
					
					//level
					//if (sel==2){
					//	s = ds.Tables["Device"].Rows[i]["dim_level"].ToString();
					//	if (s=="1") ds.Tables["Device"].Rows[i]["dim_level"]="ON"; 
					//	else ds.Tables["Device"].Rows[i]["dim_level"]="OFF";
					//}
				}
				
				DataGrid1.DataSource = ds;			
				DataGrid1.DataMember = "Device";			
				DataBind();
			}				
	}
			
	void dg1_itemdatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
	{ 						
	}
	
		
	void Control_Click(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
			String address = e.Item.Cells[4].Text;
			webbrowser web = new webbrowser();
			switch(((Button) e.CommandSource).ID)
			{
				case "Button_set":					
					DropDownList dimlev = (DropDownList) e.Item.Cells[7].Controls[1];
					String lev = dimlev.SelectedItem.Text;
					bool setdim = web.Exec_SetDim(address,int.Parse(lev));
					if (setdim) Session["setdim"]=1;
						else Session["setdim"]=0;
					Response.Redirect("dimmer.aspx");
					break;
				case "Button_name":
					Session["dev_name"] =  e.Item.Cells[1].Text;
					Session["address"] =  address;
					Session["page"] =  "dimmer";
					Response.Redirect("editname_home.aspx");
					break;				
			}			
	}	
	
	void showAlert(int response)
	{
		String txtalert="";
		if (response==1)
			txtalert = " C o m p l e t e";		
		else txtalert = "       F a i l ! !";
			
		String alertScript = "<script>";
		alertScript += "alert('"+txtalert+"')";
		alertScript += "</script"+">";
		Response.Write(alertScript);
	}
	
</SCRIPT>


<HTML>
<HEAD>
<TITLE>Dimmer</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>

<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_homeapp -->


<FORM id="form1" name="form1" method="post" runat="server" >
  <DIV align="center"><B><FONT color="#0066FF" size="+2">Dimmer</FONT></B><BR>
    <BR>
  </DIV>
  <DIV align="center"><asp:datagrid id="DataGrid1" runat="server" OnItemCommand="Control_Click" OnItemDataBound="dg1_itemdatabound" CssClass="devtable" Width="100%" ForeColor="#999999" GridLines="Vertical"
	CellPadding="1" BackColor="White" BorderWidth="1px" BorderStyle="None" BorderColor="#999999" HorizontalAlign="Center"
	AutoGenerateColumns="False">
	<FooterStyle BackColor="#CCCC99"></FooterStyle>
	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
	<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
	<ItemStyle BackColor="#F7F7DE"></ItemStyle>
	<HeaderStyle Font-Bold="True" HorizontalAlign="Center" ForeColor="White" BackColor="#FFCC00"></HeaderStyle>
	<Columns>
		<asp:BoundColumn DataField="dim_level" HeaderText="Level">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="name" HeaderText="Name"></asp:BoundColumn>
		<asp:BoundColumn DataField="pos" HeaderText="Location">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="model" HeaderText="Type">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="address" HeaderText="Address">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="channel" HeaderText="Channel">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="status" HeaderText="Conn">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:TemplateColumn HeaderText="Control">
			<ItemTemplate>
				<FONT size="-1">Level  </FONT>				
				<asp:DropDownList id="dimList" runat="server">
									<asp:ListItem Value="0">0</asp:ListItem>
									<asp:ListItem Value="1">1</asp:ListItem>
									<asp:ListItem Value="2">2</asp:ListItem>
									<asp:ListItem Value="3">3</asp:ListItem>
									<asp:ListItem Value="4">4</asp:ListItem>
									<asp:ListItem Value="5">5</asp:ListItem>
									<asp:ListItem Value="6">6</asp:ListItem>
									<asp:ListItem Value="7">7</asp:ListItem>									
				</asp:DropDownList>
				<FONT face="Tahoma"> </FONT>
				<asp:Button id="Button_set" runat="server" Text="Set"></asp:Button>
				<FONT face="Tahoma">&nbsp;</FONT>
				<asp:Button id="Button_name" runat="server" Text="Edit Name"></asp:Button>
			</ItemTemplate>
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:TemplateColumn>
	</Columns>
	<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
</asp:datagrid></DIV>
</FORM>


<BR>
<BR>
</BODY>
</HTML>