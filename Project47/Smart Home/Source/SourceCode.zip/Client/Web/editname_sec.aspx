<%@ Page Language="C#" Debug="true" ContentType="text/html" ResponseEncoding="tis-620" %>
<%@ Register TagPrefix="bdp" Namespace="BasicFrame.WebControls" Assembly="BasicFrame.WebControls.BasicDatePicker" %>


<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
			if (!IsPostBack){
				address_txtbox.Text = (String) Session["address"];
				address_txtbox.ReadOnly = true;
				name_txtbox.Text = (String) Session["dev_name"];				
			}
			
	}	
		
	void Control_Click(object source, System.EventArgs e)
	{				
			webbrowser web = new webbrowser();			
			bool response = web.update_NameDevice(address_txtbox.Text,name_txtbox.Text);
			if (response) Session["onoff"]=1;
				else Session["onoff"]=0;
			String page = (String) Session["page"];
			if (page == "switch")
				Response.Redirect("switch.aspx");
			else if (page == "dimmer")
				Response.Redirect("dimmer.aspx");
			else Response.Redirect("security.aspx");
	}
	
</SCRIPT>


<HTML>
<HEAD>
<TITLE>Edit Device Name</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>

<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_security -->

<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>Edit Name</B></FONT><BR>
    <BR>
  </DIV>
	
	
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="25%"><DIV align="center"></DIV></TD>
      <TD width="50%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FFFFCC">
          <TR> 
            <TD>
			<TABLE width="100%" border="0" cellpadding="0" cellspacing="0" class="devtable">
                <TR bgcolor="#FFCC66"> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Label id="Label1" runat="server"><FONT color="#FFFFFF">Device Name</FONT></asp:Label>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
				<TR> 
                  <TD><DIV align="right">Address</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:textbox id="address_txtbox" runat="server" MaxLength="2" Columns="3" ></asp:textbox>
				  </TD>
                </TR>
                <TR> 
                  <TD width="39%"><DIV align="right">Device name</DIV></TD>
                  <TD width="4%">&nbsp;</TD>
                  <TD width="57%"> <asp:TextBox id="name_txtbox" runat="server" MaxLength="25"></asp:TextBox> 
                  </TD>
                </TR>
                
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Button id="Button_add" OnClick="Control_Click" runat="server" Text="Update"></asp:Button>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
              </TABLE>

			
			</TD>
          </TR>
        </TABLE></TD>
      <TD width="25%">&nbsp;</TD>
    </TR>
  </TABLE>

	

</FORM>


<BR>
<BR>
</BODY>
</HTML>
