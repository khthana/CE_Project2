<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	
</SCRIPT>


<HTML>
<HEAD>
<TITLE>iHome Central</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<BR>

<DIV align="center"> <A href="#"><IMG src="files/ihomelogo2.gif" width="193" height="112" border="0"></A> 
  <BR>
  <BR>
</DIV>
<DIV align="center">
  <TABLE width="70%" border="0" cellpadding="0" cellspacing="0">
    <TR>
      <TD bgcolor="#FF9933" class="header">Home Appliance</TD>
      <TD>&nbsp;</TD>
      <TD bgcolor="#FF9933" class="header">Security</TD>
    </TR>
    <TR> 
      <TD width="47%" class="whitetext"><DIV align="center"><A href="switch.aspx">Switch</A> 
          | <A href="dimmer.aspx">Dimmer</A></DIV></TD>
      <TD width="6%">&nbsp;</TD>
      <TD width="47%" class="whitetext"><DIV align="center"><A href="security.aspx">View</A> 
          | <A href="sms.aspx">SMS Setting</A></DIV></TD>
    </TR>
  </TABLE>
  <TBLE width="80%" border="0" cellspacing="0" cellpadding="0">
    <TR class="whitetext"> 
      <TD width="18%">&nbsp;</TD>
      <TD width="31%">&nbsp;</TD>
      <TD width="14%">&nbsp;</TD>
      <TD width="37%">&nbsp;</TD>
    </TR>
  </TABLE>
  <BR>
  <TABLE width="70%" border="0" cellpadding="0" cellspacing="0">
    <TR>
      <TD bgcolor="#FF9933" class="header">Camera</TD>
      <TD>&nbsp;</TD>
      <TD bgcolor="#FF9933" class="header">Schedule</TD>
    </TR>
    <TR class="whitetext"> 
      <TD width="47%"><DIV align="center"><A href="camera.aspx">View</A> | <A href="http://161.246.6.57/cam">History</A> 
          | <A href="addcamera.aspx">New Camera</A></DIV></TD>
      <TD width="6%">&nbsp;</TD>
      <TD width="47%"><DIV align="center"><A href="viewonce.aspx">Once</A> | <A href="viewdaily.aspx">Daily</A> 
          | <A href="viewweekly.aspx">Weekly</A> | <A href="viewmonthly.aspx">Monthly</A></DIV></TD>
    </TR>
  </TABLE>
  <BR>
  <TABLE width="70%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="47%" bgcolor="#FF9933" class="header">Macro</TD>
      <TD width="6%">&nbsp;</TD>
	  <TD width="47%" bgcolor="#FF9933" class="header">Log</TD>      
    </TR>
    <TR> 
      <TD width="47%" class="whitetext" ><DIV align="center"><A href="macro.aspx">View</A> 
          | <A href="addmacro.aspx">New Macro</A></DIV></TD>
      <TD width="6%">&nbsp;</TD>
	  <TD width="47%" class="whitetext" ><DIV align="center"><A href="log.aspx">View 
          Log</A></DIV></TD>
      
    </TR>
  </TABLE>
  
  <BR>
  <TABLE width="70%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="47%" bgcolor="#FF9933" class="header">Setting</TD>
      <TD width="6%">&nbsp;</TD>
	  <TD width="47%" bgcolor="#FF9933" class="header">About</TD>      
    </TR>
    <TR> 
      <TD width="47%" class="whitetext" ><DIV align="center"><A href="setting.aspx">Setting</A></DIV></TD>
      <TD width="6%">&nbsp;</TD>
	  <TD width="47%" class="whitetext" ><DIV align="center"><A href="about.aspx">About</A></DIV></TD>
      
    </TR>
  </TABLE>
</DIV>

</BODY>
</HTML>
