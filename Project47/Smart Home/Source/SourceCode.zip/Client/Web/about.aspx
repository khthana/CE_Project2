<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
			
</SCRIPT>


<HTML>
<HEAD>
<TITLE>About iHome Project</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_about -->
<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>About</B></FONT><BR>
    <BR><BR>
	iHome Project , CE KMITL 2004<BR><BR>
	
  </DIV>
   
</FORM>


<BR>
<BR>
</BODY>
</HTML>
