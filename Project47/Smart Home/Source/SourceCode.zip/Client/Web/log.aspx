<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
		webbrowser web = new webbrowser();
		String logtxt = web.getLog();
		log_txtbox.Text = logtxt;	
	}
	
	void Refresh_click(object source, System.EventArgs e)
	{
		Response.Redirect("log.aspx");
	}
</SCRIPT>


<HTML>
<HEAD>
<TITLE>View Log</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_log -->

<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>View Log</B></FONT><BR>
    <BR>
	<ASP:BUTTON ID="Button_Refresh" runat="server" Text="Refresh" OnClick="Refresh_click" />
	<BR><BR>
	<ASP:TEXTBOX ID="log_txtbox" runat="server" TextMode="MultiLine" ReadOnly="true" Rows="11" Width="70%" BorderWidth="1" BorderColor="#999999"/>
  </DIV>
   
</FORM>

<BR>
</BODY>
</HTML>
