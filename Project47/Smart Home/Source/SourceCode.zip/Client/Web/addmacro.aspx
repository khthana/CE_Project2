<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	
	void Page_Load(object sender, System.EventArgs e)
	{
			if (!IsPostBack){
				level.Visible = false;
				dimList.Visible = false;
				sms.Visible = false;
				sms_txtbox.Visible = false;					
			}
	}
			
	void showHidden(object source, System.EventArgs e)
	{
			String sel = cmd_droplist_target.SelectedValue;			
			
			if (sel=="Dimmer") {
				level.Visible = true;
				dimList.Visible = true;
			}else if (sel=="SMS") {
				sms.Visible = true;
				sms_txtbox.Visible = true;
			}else {
				level.Visible = false;
				dimList.Visible = false;
				sms.Visible = false;
				sms_txtbox.Visible = false;	
			}			
	}
	
	void Control_Click(object source, System.EventArgs e)
	{
		String src = addr_source.Text;
		String target = addr_target.Text;
		int cmd_src = cmd_droplist_src.SelectedIndex;
		int cmd_target = cmd_droplist_target.SelectedIndex;
		String pa = "0";
		if (cmd_target==2)
			pa = dimList.SelectedValue;
		else if (cmd_target==4)
			pa = sms_txtbox.Text;		
		
		webbrowser web = new webbrowser();
		bool response = web.AddEventMacro(src,cmd_src,target,cmd_target,pa);
		if (response) Session["response"]=1;
			else Session["response"]=2;
		Response.Redirect("macro.aspx");		
	}	
			
</SCRIPT>


<HTML>
<HEAD>
<TITLE>New Macro</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_macro -->
<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>New Macro</B></FONT><BR>
    <BR>
  </DIV>
  
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="25%"><DIV align="center"></DIV></TD>
      <TD width="50%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FFFFCC">
          <TR> 
            <TD>
			<TABLE width="100%" border="0" cellpadding="0" cellspacing="0" class="devtable">
                <TR bgcolor="#FFCC66"> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Label id="Label1" runat="server"><FONT color="#FFFFFF">Macro</FONT></asp:Label>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD width="47%"><DIV align="right">Source Address</DIV></TD>
                  <TD width="4%">&nbsp;</TD>
                  <TD width="49%"><asp:textbox id="addr_source" runat="server" MaxLength="2" Columns="3" ></asp:textbox> </TD>
                </TR>
                <TR> 
                  <TD><DIV align="right">Event</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:DropDownList id="cmd_droplist_src" runat="server"> 
                      <asp:ListItem Value="On">ON</asp:ListItem>
                      <asp:ListItem Value="Off">OFF</asp:ListItem>                      
                      <asp:ListItem Value="Capture">Capture</asp:ListItem>
					  <asp:ListItem Value="Alert">Alert</asp:ListItem>
					  <asp:ListItem Value="OnorOff">ON or OFF</asp:ListItem>
                    </asp:DropDownList> 
				  </TD>
                </TR>
				<TR> 
                  <TD>&nbsp;</TD>
                  <TD>&nbsp;</TD>
                  <TD>&nbsp;</TD>
                </TR>
                <TR> 
                  <TD><DIV align="right">Target Address</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:textbox id="addr_target" runat="server" MaxLength="2" Columns="3" ></asp:textbox> </TD>
                </TR>
				<TR> 
                  <TD><DIV align="right">Command</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:DropDownList id="cmd_droplist_target" OnSelectedIndexChanged="showHidden" AutoPostBack="true" runat="server"> 
                      <asp:ListItem Value="On">ON</asp:ListItem>
                      <asp:ListItem Value="Off">OFF</asp:ListItem>
                      <asp:ListItem Value="Dimmer">Dimmer</asp:ListItem>
                      <asp:ListItem Value="Capture">Capture</asp:ListItem>
					  <asp:ListItem Value="SMS">SMS</asp:ListItem>
                    </asp:DropDownList>
					<FONT>&nbsp;</FONT>
					<asp:Label id="level" runat="server">Level</asp:Label>
					<asp:DropDownList id="dimList" runat="server"> 
                      <asp:ListItem Value="0">0</asp:ListItem>
                      <asp:ListItem Value="1">1</asp:ListItem>
                      <asp:ListItem Value="2">2</asp:ListItem>
                      <asp:ListItem Value="3">3</asp:ListItem>
                      <asp:ListItem Value="4">4</asp:ListItem>
                      <asp:ListItem Value="5">5</asp:ListItem>
                      <asp:ListItem Value="6">6</asp:ListItem>
                      <asp:ListItem Value="7">7</asp:ListItem>                      
                    </asp:DropDownList> 
				  </TD>
                </TR>                                
                <TR> 
                  <TD><DIV align="right"><asp:Label id="sms" runat="server">SMS Message</asp:Label></DIV>
				  </TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:textbox id="sms_txtbox" runat="server" MaxLength="50"></asp:textbox>
				  </TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Button id="Button_add" OnClick="Control_Click" runat="server" Text="New Macro"></asp:Button>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
              </TABLE>
			  			
			</TD>
          </TR>
        </TABLE></TD>
      <TD width="25%">&nbsp;</TD>
    </TR>
  </TABLE>
  </FORM>


<BR>
<BR>
</BODY>
</HTML>
