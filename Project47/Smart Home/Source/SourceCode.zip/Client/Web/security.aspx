<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>
<%@ import Namespace="System.Drawing" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
		if (!IsPostBack) LoadTable(sender,e);
		if (Session["onoff"]!=null)
		{
				int s = (int) Session["onoff"];
				if (s!=-1) showAlert(s);
				Session["onoff"]=-1;
		}
	}
	
	DataSet XMLtoDataSet(int mode)
	{
			webbrowser myService = new webbrowser();
			string data = myService.Exec_wListDevice(mode);    
			MemoryStream stream = new MemoryStream();
			byte[] bt = Encoding.ASCII.GetBytes(data);
			stream.Write(bt,0,bt.Length);
			stream.Position = 0;
			DataSet ds = new System.Data.DataSet();
			ds.ReadXml(stream);
			return ds;
	}
		
	void LoadTable(object sender, System.EventArgs e)
	{
			int sel = 4;
			DataSet ds = XMLtoDataSet(sel);
			bool sec_alert = false;
			
			if (ds.Tables.Count!=0)
			{
				DataTable myTable = ds.Tables["Device"];				
							
				for(int i=0;i<ds.Tables["Device"].Rows.Count;i++)
				{
					//connection
					String s = ds.Tables["Device"].Rows[i]["status"].ToString();
					if (s=="0") ds.Tables["Device"].Rows[i]["status"]="FAIL";
					else ds.Tables["Device"].Rows[i]["status"]="OK";
					
					//model
					s = ds.Tables["Device"].Rows[i]["model"].ToString();
					if (s=="03") ds.Tables["Device"].Rows[i]["model"]="SEC"; 
					
					//status
					if (sel==4){
						s = ds.Tables["Device"].Rows[i]["power"].ToString();
						if (s=="0") ds.Tables["Device"].Rows[i]["power"]="OFF"; 
						else if (s=="1") ds.Tables["Device"].Rows[i]["power"]="ON";
						
						s = ds.Tables["Device"].Rows[i]["security_alert"].ToString();
						if (s=="1") {
							ds.Tables["Device"].Rows[i]["power"]="ALERT";
							sec_alert = true;
						}
						
					}			
					//s = ds.Tables["Device"].Rows[i]["security_alert"].ToString();
					//if (s=="1") 
				}
				
				DataGrid1.DataSource = ds;			
				DataGrid1.DataMember = "Device";			
				DataBind();
			}
			
			if (sec_alert){
				for (int i=0;i<DataGrid1.Items.Count;i++)
				{
					String status = DataGrid1.Items[i].Cells[0].Text;
					if (status=="ALERT"){
						DataGrid1.Items[i].BackColor = Color.FromArgb(255,198,251); 
						DataGrid1.Items[i].ForeColor = Color.Red;
					}
				}
			}
	}
	
	void dg1_itemdatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
	{
			//Response.Write("itemdatabound"); 
	}
	
	void Control_Click(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
			String address = e.Item.Cells[4].Text;
			webbrowser web = new webbrowser();
			bool onoff=false;
			switch(((Button) e.CommandSource).ID)
			{
				case "Button_on":					
					onoff = web.Exec_SecurityEN(address);
					if (onoff) Session["onoff"]=1;
						else Session["onoff"]=0;
					Response.Redirect("security.aspx");					
					break;
				case "Button_off":										
					String a = e.Item.Cells[0].Text;
					if (a != "ALERT")
						onoff = web.Exec_SecurityDi(address);
					else onoff = web.Exec_ResetAlert(address);					
					
					if (onoff) Session["onoff"]=1;
						else Session["onoff"]=0;
					Response.Redirect("security");					
					break;
				case "Button_name":
					Session["dev_name"] =  e.Item.Cells[1].Text;					
					Session["address"] =  address;
					Session["page"] =  "security.aspx";
					Response.Redirect("editname_sec.aspx");
					break;
			}
			
	}
	
	void showAlert(int response)
	{
		String txtalert="";
		if (response==1)
			txtalert = " C o m p l e t e";		
		else txtalert = "       F a i l ! !";
			
		String alertScript = "<script>";
		alertScript += "alert('"+txtalert+"')";
		alertScript += "</script"+">";
		Response.Write(alertScript);
	}
		
</SCRIPT>


<HTML>
<HEAD>
<TITLE>Security</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_security -->

<FORM name="form1" method="post" runat="server" >
	<DIV align="center"><FONT color="#0066FF" size="+2"><B>Security</B></FONT><BR>
    <BR>
  </DIV>
  
  <DIV align="center">
<asp:datagrid id="DataGrid1" runat="server" OnItemDataBound="dg1_itemdatabound" OnItemCommand="Control_Click" CssClass="devtable" Width="100%" ForeColor="#999999" GridLines="Vertical"
	CellPadding="4" BackColor="White" BorderWidth="1px" BorderStyle="None" BorderColor="#999999" HorizontalAlign="Center"
	AutoGenerateColumns="False">
	<FooterStyle BackColor="#CCCC99"></FooterStyle>
	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
	<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
	<ItemStyle BackColor="#F7F7DE"></ItemStyle>
	<HeaderStyle Font-Bold="True" HorizontalAlign="Center" ForeColor="White" BackColor="#FFCC00"></HeaderStyle>
	<Columns>
		<asp:BoundColumn DataField="power" HeaderText="Status">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="name" HeaderText="Name"></asp:BoundColumn>
		<asp:BoundColumn DataField="pos" HeaderText="Location">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="model" HeaderText="Type">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="address" HeaderText="Address">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="channel" HeaderText="Channel">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="status" HeaderText="Conn">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:TemplateColumn HeaderText="Control">
			<ItemTemplate>
				<asp:Button id="Button_on" runat="server" Text="ON"></asp:Button>
				<FONT face="Tahoma"> </FONT>
				<asp:Button id="Button_off" runat="server" Text="OFF"></asp:Button>
				<FONT face="Tahoma">&nbsp;</FONT>
				<asp:Button id="Button_name" runat="server" Text="Edit Name"></asp:Button>
			</ItemTemplate>
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:TemplateColumn>				
	</Columns>
	<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
</asp:datagrid></DIV>

</FORM>


<BR>
<BR>
</BODY>
</HTML>
