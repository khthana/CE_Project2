<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	
	void Page_Load(object sender, System.EventArgs e)
	{			
	}
		
	DataSet XMLtoDataSet()
	{
			webbrowser myService = new webbrowser();
			string data = myService.getCaptureDriverName();    
			MemoryStream stream = new MemoryStream();
			byte[] bt = Encoding.ASCII.GetBytes(data);
			stream.Write(bt,0,bt.Length);
			stream.Position = 0;
			DataSet ds = new System.Data.DataSet();
			ds.ReadXml(stream);
			return ds;
	}
			
	void LoadTable(object sender, System.EventArgs e)
	{
			DataSet ds = XMLtoDataSet();
			if (ds.Tables.Count!=0)
			{				
				DataGrid1.DataSource = ds;			
				DataGrid1.DataMember = "Driver";			
				DataBind();				
			}
	}
	
	void Control_Click(object source, System.EventArgs e)
	{		
		String name = name_txtbox.Text;
		String detail = detail_txtbox.Text;
		String port = port_txtbox.Text;
		String captime = captime_droplist.SelectedValue;
		
		webbrowser web = new webbrowser();
		bool response = web.AddCaptureFn(name,detail,int.Parse(port),int.Parse(captime));
		
		if (response) Session["response"]=1;
			else Session["response"]=2;
		Response.Redirect("camera.aspx");		
		
	}		
</SCRIPT>


<HTML>
<HEAD>
<TITLE>New Camera</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_camera -->
<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>New Camera</B></FONT><BR>
    <BR>	
  </DIV>
  <DIV align="center"><FONT size="-1"><B>Port List</B></FONT><BR>
	<asp:datagrid id="DataGrid1" runat="server" OnPreRender="LoadTable" CssClass="devtable" Width="70%" ForeColor="#999999" GridLines="Vertical"
	CellPadding="1" BackColor="White" BorderWidth="1px" BorderStyle="None" BorderColor="#999999" HorizontalAlign="Center"
	AutoGenerateColumns="False">
	<FooterStyle BackColor="#CCCC99"></FooterStyle>
	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
	<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
	<ItemStyle BackColor="#F7F7DE"></ItemStyle>
	<HeaderStyle Font-Bold="True" HorizontalAlign="Center" ForeColor="White" BackColor="#FFCC66"></HeaderStyle>
	<Columns>
		<asp:BoundColumn DataField="No" HeaderText="Port Number">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="Name" HeaderText="Driver Name">
		</asp:BoundColumn>
	</Columns>
	<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
	</asp:datagrid>	
  </DIV><BR>
  
  
  
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="25%"><DIV align="center"></DIV></TD>
      <TD width="50%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FFFFCC">
          <TR> 
            <TD>
			<TABLE width="100%" border="0" cellpadding="0" cellspacing="0" class="devtable">
                <TR bgcolor="#FFCC66"> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Label id="Label1" runat="server"><FONT color="#FFFFFF">Camera</FONT></asp:Label>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD width="47%"><DIV align="right">Camera Name</DIV></TD>
                  <TD width="4%">&nbsp;</TD>
                  <TD width="49%"><asp:textbox id="name_txtbox" runat="server" MaxLength="30"></asp:textbox> </TD>
                </TR>
                <TR> 
                  <TD><DIV align="right">Datail</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:textbox id="detail_txtbox" runat="server" MaxLength="30"></asp:textbox> </TD>
                </TR>				
                <TR> 
                  <TD><DIV align="right">Port Number</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:textbox id="port_txtbox" runat="server" MaxLength="1" Columns="1" ></asp:textbox> </TD>
                </TR>
				<TR> 
                  <TD><DIV align="right">Capture Time (min.)</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:DropDownList id="captime_droplist" runat="server"> 
                      <asp:ListItem Value="0">0</asp:ListItem>
                      <asp:ListItem Value="5">5</asp:ListItem>
                      <asp:ListItem Value="10">10</asp:ListItem>
                      <asp:ListItem Value="15">15</asp:ListItem>
					  <asp:ListItem Value="30">30</asp:ListItem>
					  <asp:ListItem Value="60">60</asp:ListItem>
                    </asp:DropDownList> 
				  </TD>
                </TR>                                
                
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Button id="Button_add" OnClick="Control_Click" runat="server" Text="New Camera"></asp:Button>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
              </TABLE>
			  			
			</TD>
          </TR>
        </TABLE></TD>
      <TD width="25%">&nbsp;</TD>
    </TR>
  </TABLE>
  </FORM>


<BR>
<BR>
</BODY>
</HTML>
