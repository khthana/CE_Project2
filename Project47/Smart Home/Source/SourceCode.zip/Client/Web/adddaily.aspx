<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>
<%@ Register TagPrefix="bdp" Namespace="BasicFrame.WebControls" Assembly="BasicFrame.WebControls.BasicDatePicker" %>


<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
			if (!IsPostBack){
				level.Visible = false;
				dimList.Visible = false;
			}
	}
	
	void showLevel(object source, System.EventArgs e)
	{
			String sel = cmd_droplist.SelectedValue;			
			if (sel=="Dimmer") {
				level.Visible = true;
				dimList.Visible = true;				
			}else {
				level.Visible = false;
				dimList.Visible = false;	
			}			
	}
	
	void Control_Click(object source, System.EventArgs e)
	{
			//String address = e.Item.Cells[4].Text;
			String weekday="";
			for (int i=0;i<weekday_boxlist.Items.Count;i++)
				if (weekday_boxlist.Items[i].Selected)
					weekday = weekday+"1";
				else weekday = weekday+"0";
			//String ddmmyy = BasicDatePicker1.SelectedDateFormatted;
			String time = hour_drop.SelectedValue+":"+min_drop.SelectedValue;			
			DateTime dd = BasicDatePicker1.SelectedDate;
			int y = dd.Year+543;
			String ddmmyy = dd.Day.ToString()+"/"+dd.Month.ToString()+"/"+y.ToString();
					
			webbrowser web = new webbrowser();
			String name = schedname.Text;
			int type = 1;
			String datetime = ddmmyy+" "+time;
			String addr = address.Text;
			int cmd = cmd_droplist.SelectedIndex;
			String pa = "0";
			if (cmd==2) pa=dimList.SelectedValue;
			
			//Response.Write(datetime+"<br>");
			//Response.Write(weekday+"<br>");
			//Response.Write(addr+"<br>");
			//Response.Write(ddmmyy+"<br>");
			int response = web.AddSchedule(name,type,datetime,weekday,addr,cmd,pa);
			//Response.Write(response);
			
			Session["response"]=response+1;
			Response.Redirect("viewdaily.aspx");			
			
	}
		
	
</SCRIPT>


<HTML>
<HEAD>
<TITLE>New Daily Schedule</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>
<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_schedule -->

<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>New Daily</B></FONT><BR>
    <BR>
  </DIV>
	
	
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
    <TR> 
      <TD width="25%"><DIV align="center"></DIV></TD>
      <TD width="50%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FFFFCC">
          <TR> 
            <TD>
			<TABLE width="100%" border="0" cellpadding="0" cellspacing="0" class="devtable">
                <TR bgcolor="#FFCC66"> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Label id="Label1" runat="server"><FONT color="#FFFFFF">Daily</FONT></asp:Label>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
				<TR> 
                  <TD><DIV align="right">Address</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:textbox id="address" runat="server" MaxLength="2" Columns="3" ></asp:textbox>
				  </TD>
                </TR>
                <TR> 
                  <TD width="39%"><DIV align="right">Schedule name</DIV></TD>
                  <TD width="4%">&nbsp;</TD>
                  <TD width="57%"> <asp:TextBox id="schedname" runat="server" MaxLength="25"></asp:TextBox> 
                  </TD>
                </TR>
                <TR> 
                  <TD><DIV align="right">Command</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:DropDownList id="cmd_droplist" OnSelectedIndexChanged="showLevel" AutoPostBack="true" runat="server"> 
                      <asp:ListItem Value="On">ON</asp:ListItem>
                      <asp:ListItem Value="Off">OFF</asp:ListItem>
                      <asp:ListItem Value="Dimmer">Dimmer</asp:ListItem>
                      <asp:ListItem Value="Capture">Capture</asp:ListItem>
                    </asp:DropDownList> <asp:Label id="level" runat="server">Level</asp:Label> 
                    <asp:DropDownList id="dimList" runat="server"> 
                      <asp:ListItem Value="0">0</asp:ListItem>
                      <asp:ListItem Value="1">1</asp:ListItem>
                      <asp:ListItem Value="2">2</asp:ListItem>
                      <asp:ListItem Value="3">3</asp:ListItem>
                      <asp:ListItem Value="4">4</asp:ListItem>
                      <asp:ListItem Value="5">5</asp:ListItem>
                      <asp:ListItem Value="6">6</asp:ListItem>
                      <asp:ListItem Value="7">7</asp:ListItem>                      
                    </asp:DropDownList> </TD>
                </TR>
                <TR> 
                  <TD><DIV align="right">Start date</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><BDP:BasicDatePicker id="BasicDatePicker1" runat="server" DateFormat="ShortDate" ShowNoneButton="False" TextBoxReadOnly="True"> 
                    <DayHeaderStyle BackColor="#FFC0C0"></DayHeaderStyle> </BDP:BasicDatePicker> 
                  </TD>
                </TR>
                <TR> 
                  <TD>&nbsp;</TD>
                  <TD>&nbsp;</TD>
                  <TD>&nbsp;</TD>
                </TR>
                <TR> 
                  <TD valign="top"><DIV align="right">Do every</DIV></TD>
                  <TD rowspan="2">&nbsp;</TD>
                  <TD rowspan="2"><asp:CheckBoxList id="weekday_boxlist" CssClass="devtable" CellPadding="0" CellSpacing="0" runat="server"> 
                      <asp:ListItem Value="Sunday">Sunday</asp:ListItem>
                      <asp:ListItem Value="Monday">Monday</asp:ListItem>
                      <asp:ListItem Value="Tuesday">Tuesday</asp:ListItem>
                      <asp:ListItem Value="Wednesday">Wednesday</asp:ListItem>
                      <asp:ListItem Value="Thursday">Thursday</asp:ListItem>
                      <asp:ListItem Value="Friday">Friday</asp:ListItem>
                      <asp:ListItem Value="Saturday">Saturday</asp:ListItem>
                    </asp:CheckBoxList></DIV>
                    </TD>
                </TR>
                <TR> 
                  <TD valign="top">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD>&nbsp;</TD>
                  <TD>&nbsp;</TD>
                  <TD>&nbsp;</TD>
                </TR>
                <TR> 
                  <TD><DIV align="right">Time</DIV></TD>
                  <TD>&nbsp;</TD>
                  <TD><asp:DropDownList id="hour_drop" runat="server"> 
                      <asp:ListItem Value="0">0</asp:ListItem>
                      <asp:ListItem Value="1">1</asp:ListItem>
                      <asp:ListItem Value="2">2</asp:ListItem>
                      <asp:ListItem Value="3">3</asp:ListItem>
                      <asp:ListItem Value="4">4</asp:ListItem>
                      <asp:ListItem Value="5">5</asp:ListItem>
                      <asp:ListItem Value="6">6</asp:ListItem>
                      <asp:ListItem Value="7">7</asp:ListItem>
                      <asp:ListItem Value="8">8</asp:ListItem>
                      <asp:ListItem Value="9">9</asp:ListItem>
                      <asp:ListItem Value="10">10</asp:ListItem>
                      <asp:ListItem Value="11">11</asp:ListItem>
                      <asp:ListItem Value="12">12</asp:ListItem>
                      <asp:ListItem Value="13">13</asp:ListItem>
                      <asp:ListItem Value="14">14</asp:ListItem>
                      <asp:ListItem Value="15">15</asp:ListItem>
                      <asp:ListItem Value="16">16</asp:ListItem>
                      <asp:ListItem Value="17">17</asp:ListItem>
                      <asp:ListItem Value="18">18</asp:ListItem>
                      <asp:ListItem Value="19">19</asp:ListItem>
                      <asp:ListItem Value="20">20</asp:ListItem>
                      <asp:ListItem Value="21">21</asp:ListItem>
                      <asp:ListItem Value="22">22</asp:ListItem>
                      <asp:ListItem Value="23">23</asp:ListItem>
                    </asp:DropDownList> <FONT> : </FONT> 
					<asp:DropDownList id="min_drop" runat="server"> 
                      <asp:ListItem Value="0">0</asp:ListItem>
                      <asp:ListItem Value="1">1</asp:ListItem>
                      <asp:ListItem Value="2">2</asp:ListItem>
                      <asp:ListItem Value="3">3</asp:ListItem>
                      <asp:ListItem Value="4">4</asp:ListItem>
                      <asp:ListItem Value="5">5</asp:ListItem>
                      <asp:ListItem Value="6">6</asp:ListItem>
                      <asp:ListItem Value="7">7</asp:ListItem>
                      <asp:ListItem Value="8">8</asp:ListItem>
                      <asp:ListItem Value="9">9</asp:ListItem>
                      <asp:ListItem Value="10">10</asp:ListItem>
                      <asp:ListItem Value="11">11</asp:ListItem>
                      <asp:ListItem Value="12">12</asp:ListItem>
                      <asp:ListItem Value="13">13</asp:ListItem>
                      <asp:ListItem Value="14">14</asp:ListItem>
                      <asp:ListItem Value="15">15</asp:ListItem>
                      <asp:ListItem Value="16">16</asp:ListItem>
                      <asp:ListItem Value="17">17</asp:ListItem>
                      <asp:ListItem Value="18">18</asp:ListItem>
                      <asp:ListItem Value="19">19</asp:ListItem>
                      <asp:ListItem Value="20">20</asp:ListItem>
                      <asp:ListItem Value="21">21</asp:ListItem>
                      <asp:ListItem Value="22">22</asp:ListItem>
                      <asp:ListItem Value="23">23</asp:ListItem>
                      <asp:ListItem Value="24">24</asp:ListItem>
                      <asp:ListItem Value="25">25</asp:ListItem>
                      <asp:ListItem Value="26">26</asp:ListItem>
                      <asp:ListItem Value="27">27</asp:ListItem>
                      <asp:ListItem Value="28">28</asp:ListItem>
                      <asp:ListItem Value="29">29</asp:ListItem>
                      <asp:ListItem Value="30">30</asp:ListItem>
                      <asp:ListItem Value="31">31</asp:ListItem>
                      <asp:ListItem Value="32">32</asp:ListItem>
                      <asp:ListItem Value="33">33</asp:ListItem>
                      <asp:ListItem Value="34">34</asp:ListItem>
                      <asp:ListItem Value="35">35</asp:ListItem>
                      <asp:ListItem Value="36">36</asp:ListItem>
                      <asp:ListItem Value="37">37</asp:ListItem>
                      <asp:ListItem Value="38">38</asp:ListItem>
                      <asp:ListItem Value="39">39</asp:ListItem>
                      <asp:ListItem Value="40">40</asp:ListItem>
                      <asp:ListItem Value="41">41</asp:ListItem>
                      <asp:ListItem Value="42">42</asp:ListItem>
                      <asp:ListItem Value="43">43</asp:ListItem>
                      <asp:ListItem Value="44">44</asp:ListItem>
                      <asp:ListItem Value="45">45</asp:ListItem>
                      <asp:ListItem Value="46">46</asp:ListItem>
                      <asp:ListItem Value="47">47</asp:ListItem>
                      <asp:ListItem Value="48">48</asp:ListItem>
                      <asp:ListItem Value="49">49</asp:ListItem>
                      <asp:ListItem Value="50">50</asp:ListItem>
                      <asp:ListItem Value="51">51</asp:ListItem>
                      <asp:ListItem Value="52">52</asp:ListItem>
                      <asp:ListItem Value="53">53</asp:ListItem>
                      <asp:ListItem Value="54">54</asp:ListItem>
                      <asp:ListItem Value="55">55</asp:ListItem>
                      <asp:ListItem Value="56">56</asp:ListItem>
                      <asp:ListItem Value="57">57</asp:ListItem>
                      <asp:ListItem Value="58">58</asp:ListItem>
                      <asp:ListItem Value="59">59</asp:ListItem>
                    </asp:DropDownList> </TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
                <TR> 
                  <TD colspan="3"><DIV align="center"> 
                      <asp:Button id="Button_add" OnClick="Control_Click" runat="server" Text="New Schedule"></asp:Button>
                    </DIV></TD>
                </TR>
                <TR> 
                  <TD colspan="3">&nbsp;</TD>
                </TR>
              </TABLE>

			
			</TD>
          </TR>
        </TABLE></TD>
      <TD width="25%">&nbsp;</TD>
    </TR>
  </TABLE>

	

</FORM>


<BR>
<BR>
</BODY>
</HTML>
