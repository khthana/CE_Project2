<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="tis-620" %>

<%@ import Namespace="iHome.iHomeWebRef" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Text" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Xml" %>

<SCRIPT runat="server" >
	void Page_Load(object sender, System.EventArgs e)
	{
		//if (!IsPostBack) LoadTable(sender,e);
		if (Session["response"]!=null)
		{
			int ses = (int) Session["response"];
			if (ses!=0) 
			{
				showAlert(ses);
				Session["response"]=0;
			}
		}		
	}
	
	DataSet XMLtoDataSet()
	{
			webbrowser myService = new webbrowser();
			string data = myService.ViewMacro();    
			MemoryStream stream = new MemoryStream();
			byte[] bt = Encoding.ASCII.GetBytes(data);
			stream.Write(bt,0,bt.Length);
			stream.Position = 0;
			DataSet ds = new System.Data.DataSet();
			ds.ReadXml(stream);
			return ds;
	}
		
	void LoadTable(object sender, System.EventArgs e)
	{
			//int sel = 1;
			DataSet ds = XMLtoDataSet();
			if (ds.Tables.Count!=0)
			{			
				//DataTable myTable = ds.Tables["ListEventMacro"];			
							
				for(int i=0;i<ds.Tables["ListEventMacro"].Rows.Count;i++)
				{
					//event_type - source
					String s = ds.Tables["ListEventMacro"].Rows[i]["event_type"].ToString();
					if (s=="0") ds.Tables["ListEventMacro"].Rows[i]["event_type"]="Power ON";
					else if (s=="1") ds.Tables["ListEventMacro"].Rows[i]["event_type"]="Power OFF";
					else if (s=="2") ds.Tables["ListEventMacro"].Rows[i]["event_type"]="Capture";
					else if (s=="3") ds.Tables["ListEventMacro"].Rows[i]["event_type"]="Security Alert";
					else if (s=="4") ds.Tables["ListEventMacro"].Rows[i]["event_type"]="Power ON or OFF";
					
					//cmd - target
					s = ds.Tables["ListEventMacro"].Rows[i]["cmd"].ToString();
					if (s=="0") ds.Tables["ListEventMacro"].Rows[i]["cmd"]="Power ON";
					else if (s=="1") ds.Tables["ListEventMacro"].Rows[i]["cmd"]="Power OFF";
					else if (s=="2") ds.Tables["ListEventMacro"].Rows[i]["cmd"]="Dimmer";
					else if (s=="3") ds.Tables["ListEventMacro"].Rows[i]["cmd"]="Capture";
					else if (s=="4") ds.Tables["ListEventMacro"].Rows[i]["cmd"]="Send SMS";					
					
				}	
				DataGrid1.DataSource = ds;			
				DataGrid1.DataMember = "ListEventMacro";			
				DataBind();
				DataGrid1.Visible = true;
			}
	}
			
		
	void Control_Click(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{			
			webbrowser web = new webbrowser();
			switch(((Button) e.CommandSource).ID)
			{
				case "Button_Delete":
					String id = e.Item.Cells[0].Text;					
					
					bool response = web.RemoveEventMacro(int.Parse(id));
					int res;
					if (response){ 
						Session["response"]=1;
						res = 1;
					}else {
						Session["response"]=2;
						res = 2;
					}
					if (response && DataGrid1.Items.Count==1)
						DataGrid1.Visible = false;					
					showAlert(res);																				
					
					break;					
			}
	}
	
	void showAlert(int response)
	{
		String txtalert="";
		if (response==1)
			txtalert = " C o m p l e t e";		
		else txtalert = "       F a i l ! !";
			
		String alertScript = "<script>";
		alertScript += "alert('"+txtalert+"')";
		alertScript += "</script"+">";
		Response.Write(alertScript);
	}	
</SCRIPT>


<HTML>
<HEAD>
<TITLE>View Macro</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="csstemplate.css" rel="stylesheet" type="text/css">

<!-- #include FILE=menuscript -->
</HEAD>


<BODY background="files/main_bg.gif" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<!-- #include FILE=head_macro -->
<FORM name="form1" method="post" runat="server" >
  <DIV align="center"><FONT color="#0066FF" size="+2"><B>Macro</B></FONT><BR>
    <BR>
  </DIV>
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">    
    <TR> 
      <TD width="36%">&nbsp;</TD>
      <TD width="28%"><TABLE width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#FF6633">
    <TR>
    <TD><DIV align="center"><B><FONT size="-1"><A href="addmacro.aspx">Add New Macro</A></FONT></B></DIV></TD></TR>
</TABLE>
</TD>
      <TD width="36%">&nbsp;</TD>
    </TR>
  </TABLE>
  <BR>
  
  <DIV align="center"><asp:datagrid id="DataGrid1" runat="server" OnItemCommand="Control_Click" OnPreRender="LoadTable" CssClass="devtable" Width="60%" ForeColor="#999999" GridLines="Vertical"
	CellPadding="1" BackColor="White" BorderWidth="1px" BorderStyle="None" BorderColor="#999999" HorizontalAlign="Center"
	AutoGenerateColumns="False">
	<FooterStyle BackColor="#CCCC99"></FooterStyle>
	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
	<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
	<ItemStyle BackColor="#F7F7DE"></ItemStyle>
	<HeaderStyle Font-Bold="True" HorizontalAlign="Center" ForeColor="White" BackColor="#FFCC00"></HeaderStyle>
	<Columns>		
		<asp:BoundColumn DataField="event_no" HeaderText="Event No." Visible="false">			
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="Source.address" HeaderText="Source Address">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="event_type" HeaderText="Event">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="Target.address" HeaderText="Target Address">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>
		<asp:BoundColumn DataField="cmd" HeaderText="Command">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
		</asp:BoundColumn>				
		<asp:TemplateColumn HeaderText="Control">
			<ItemStyle HorizontalAlign="Center"></ItemStyle>
			<ItemTemplate>				
				<asp:Button id="Button_Delete" runat="server" Text="Delete"></asp:Button>				
			</ItemTemplate>
		</asp:TemplateColumn>
	</Columns>
	<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
</asp:datagrid></DIV>
   
</FORM>


<BR>
<BR>
</BODY>
</HTML>
