package iHome;

import java.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.util.Vector;
import java.util.Hashtable;

import org.ksoap2.*;
import org.ksoap2.serialization.*;
import org.ksoap2.transport.*;

import org.kxml2.io.*;
import org.kxml2.kdom.*;
import org.xmlpull.v1.*;


public class Service {	
	private String namespace;
	private String soapURL;
	private String soapAction;
	private String picture;
	//private String method;
	
	private Vector attribute;
	private Vector result;
	private	Vector device;	
	private Image image;
	private boolean XML;
	//private Thread run;
	//private boolean callservice;
	
	public Service(){
		result = new Vector();
		attribute = new Vector();	
		XML = true;
	}	
//-------------------------------------------------------------------------
	public String getnamespace() {		
		return namespace;		
	}
//-------------------------------------------------------------------------
	public String getsoapURL() {
		return soapURL;
	}
//-------------------------------------------------------------------------
	public String getsoapAction() {
		return soapAction;
	}
//-------------------------------------------------------------------------
	public void setPicture(String pic) {
		picture = pic;
	}
//-------------------------------------------------------------------------
	public Image getImage() {
		return image;
	}
//-------------------------------------------------------------------------	
	public Boolean getXML() {
		Boolean bool = new Boolean(XML);
		return bool;
	}	
//-------------------------------------------------------------------------	
	public Vector getresult() {		
		if (result.size()==0) 
			return null;
		else
			return result;
	}
//-------------------------------------------------------------------------	
	public Vector getdevice() {		
		if (device.size()==0) 
			return null;
		else
			return device;
	}
//-------------------------------------------------------------------------	
	public void copyDevToResult(){
		XML = true;		
		result.removeAllElements();		
		for (int i=0;i<device.size();i++)
	        result.addElement(device.elementAt(i));	            
	}	
//-------------------------------------------------------------------------	
	public void setnamespace(String in) {		
		namespace = in;		
	}
//-------------------------------------------------------------------------
	public void setsoapURL(String in) {
		soapURL = in;
	}
//-------------------------------------------------------------------------
	public void setsoapAction(String in) {
		soapAction = in;
	}
//-------------------------------------------------------------------------
	public void setresult(Vector in) {
		result = in;
	}
//-------------------------------------------------------------------------	
	public void addAttribute(String prop_name,Object value){
		SoapObject Ob = new SoapObject("","");
		Ob.addProperty(prop_name,value);
		attribute.addElement(Ob);
		
	}
//-------------------------------------------------------------------------
	public Object getKey(String key,int obnum){
		if (result.size()==0 || result.size()<obnum || !XML) 
			return null;
		else{
			Hashtable hash = (Hashtable) result.elementAt(obnum);
			return hash.get(key);
		}
				
	}
//-------------------------------------------------------------------------
	public Object setKey(String key,int obnum,Object value){
		if (result.size()==0 || result.size()<obnum || !XML ) 
			return null;
		else{
			Hashtable hash = (Hashtable) result.elementAt(obnum);
			return hash.put(key,value);
		}
				
	}
//-------------------------------------------------------------------------
	public void callService(String method) {
		System.out.println("--- Callservice Start :: "+method+" ---");					
		result.removeAllElements();
		Object resultOb = new Object();		
				
		HttpTransport ht = new HttpTransport(soapURL);
		
		try{			
			SoapObject rpc = new SoapObject(namespace,method);			
			PropertyInfo pi = new PropertyInfo();
						
			for (int i=0;i<attribute.size();i++){
				SoapObject vec = (SoapObject) attribute.elementAt(i);
				vec.getPropertyInfo(0,null,pi);
				rpc.addProperty(pi.name,vec.getProperty(0));				
			}
			attribute.removeAllElements();
			
			SoapSerializationEnvelope envelope = 
				new SoapSerializationEnvelope(SoapEnvelope.VER11);	
			envelope.bodyOut = rpc;			
			//envelope.dotNet = true;
			
			//HttpTransport ht = new HttpTransport(soapURL);
			ht.debug = true;			
			ht.call(soapAction+method, envelope);			
			resultOb = envelope.getResult();
			
			//result.addElement("\nRequestDump \n"+ht.requestDump);			
			//result.addElement(resultOb);
			
			//System.out.println( "\n\nRequest: \n" + ht.requestDump );
			//System.out.println( "\n\nResponse: \n" + ht.responseDump );
			//System.out.println("\n\n----------------- envelope.getResult -----------------\n"+
			//				   resultOb.toString()+"\n");						
			//System.out.println("callservice : "+method);
			

			//if (!method.equals(TurnON) && !method.equals(TurnOFF) && !method.equals(HelloWorld) && 
			//!resultOb.toString().equals("soap:Server")){
			if (resultOb.toString().startsWith("<")){
				XML = true;
				InputStream is;
				is = new ByteArrayInputStream(resultOb.toString().getBytes());
				XmlPullParser parser = new KXmlParser();
	            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
	            parser.setInput (is, null);	                
	            
	        	parser.nextTag();
	            parser.require(XmlPullParser.START_TAG, null, null);       	
	        	while (parser.nextTag () != XmlPullParser.END_TAG){
	        		Hashtable hash = new Hashtable();
	        		parser.require(XmlPullParser.START_TAG, null, null);        		        		
		        	while (parser.nextTag() != XmlPullParser.END_TAG) {
		        		parser.require(XmlPullParser.START_TAG, null, null);
		        		String text = parser.nextText();
		        		String name = parser.getName();
		        		System.out.println (name+" = "+text);		        		
		        		hash.put(name,text);
		        		parser.require(XmlPullParser.END_TAG, null, name);
		        	}
		        	System.out.println ("\n");
		        	result.addElement(hash);		        	
		        	parser.require(XmlPullParser.END_TAG, null, null);
	        	}
	        	System.out.println("\ndevice = "+result+"\n");	        	
	        	
	        	if (method.equals("Exec_ListDevice")||method.equals("ViewCamera")){
	        	//copy to device
	        		device = new Vector();	        		        		
	        		for (int i=0;i<result.size();i++)
	        			device.addElement(result.elementAt(i));	        		
	        	}
	        	
	        					
			}else if (resultOb.toString().equals("soap:Server")){
				System.out.println ("CallserviceError : "+resultOb.toString());
				XML= false;				
				result.addElement("false");					
			}else {
				XML= false;
				System.out.println ("resultOb ok : "+resultOb.toString());				
				result.addElement(resultOb);					
        	}
            //resultVector = (Vector) envelope.bodyIn;
            //System.out.println(envelope.bodyIn);                        
   
    	}

    	catch (Exception e) {
			e.printStackTrace();
			XML = false;
			result.addElement("false");	
			result.addElement("ErRor !!!");
			result.addElement("\nRequestDump \n"+ht.requestDump);
			result.addElement("\nResponseDump \n"+ht.responseDump);			
			result.addElement("\n\nerror... \n"+e);
		}
		System.out.println("--- Callservice Finish :: "+method+" ---");

	}

//-------------------------------------------------------------------------	
	public void callImage(){
		
		Thread mythread = Thread.currentThread();		
        Vector images = new Vector(5);
        //picture = "http://161.246.6.57/iHomeService/test_small.jpg";
		/* Free images and resources used by current frame. */
        //frame.reset();
        try {	// Catch OutOfMemory Errors
			try {
				images.addElement(createImage(picture));
				System.out.println("\n--- createImage ---\n");
			}

			// An exception is an abnormal condition that disrupts the application.  
			// If you do not catch these exceptions the program will be aborted.  
			catch (IOException ex) {
				System.out.println("\n--- catch ---\n");			
				try {					
					int namelen = picture.length();
					StringBuffer buf = new StringBuffer(namelen + 8);
					buf.append(picture);
					Runtime rt = Runtime.getRuntime();
					// Try for a sequence of images.
					for (int i = 0; ; i++) {

						//progressGauge.setValue(i % 10);
	                    // If cancelled, discard images and return immediately
						
						//if (run != mythread) {
						//	break;
						//}

						// locate the next in the series of images.
						buf.setLength(namelen);
						buf.append(i);
						buf.append(".png");
						String name = buf.toString();
						images.addElement(createImage(name));						
					}
				} catch (IOException io_ex) {}
			}
            
			// If cancelled, discard images and return immediately
			//System.out.println ("\n---- Show Image ----\n");
			
			//if (run != mythread) {				
			//	return;
			//}

			// Setup the images and display them.
			if (images.size() > 0) {
				System.out.println("\n--- Show image OK ---\n");
				//Form pic = new Form("pic");
				
				image = (Image) images.elementAt(0);				
				//ImageItem imgitem = new ImageItem("iHome",img,ImageItem.LAYOUT_CENTER,"Too Big");
				//camform.append(imgitem);	**********+++							
		    } else {
				System.out.println("Images could not be loaded.");
				//Alert alert_pic = new Alert("Error");
				//alert_pic.setString("Images could not be loaded.");
				//iDis.setCurrent(alert_pic, CamList);
			}	    
		} catch (OutOfMemoryError err) {
			System.out.println ("\n---- out of mem ----\n");
			int size = images.size();
		    if (size > 0) {
				images.setSize(size-1);
		    }
		    // If cancelled, discard images and return immediately
			//if (run != mythread) {
			//	return;
			//}
			
		    //alert.setString("Not enough memory for the image.");
            // If no images are loaded, provide the user an alert 
		    // Othersize, Alert and display the ones that were loaded.
			if (images.size() <= 0) {
		 		//display.setCurrent(alert, imageList);
			} else {
                //frame.setImages(images);
                //display.setCurrent(alert, frame);
            }
		}
	}
//-------------------------------------------------------------------------
	private Image createImage(String name) throws IOException {
		System.out.println("\n--- createImage ---\n");
        if (name.startsWith("http:")) {
            // Load from a ContentConnection
            HttpConnection c = null;
			DataInputStream is = null;
            try {
				c = (HttpConnection)Connector.open(name);
				int status = c.getResponseCode();
				if (status != 200) {
					throw new IOException("HTTP Response Code = " + status);
				}

				int len = (int)c.getLength();
				String type = c.getType();
				if (!type.equals("image/jpeg")) {
					throw new IOException("Expecting a jpeg image, but received " + type);
				}	

				if (len > 0) {
					is = c.openDataInputStream();
					byte[] data = new byte[len];
					is.readFully(data);					
		            return Image.createImage(data, 0, len);
				} else {
					throw new IOException("Content length is missing");
				}				
		   }
		   finally {		   		
				if (is != null)
					is.close();
				if (c != null)
					c.close();
		   }
      } else {
           throw new IOException("Unsupported media");
      }
   }
//-------------------------------------------------------------------------
	
}
