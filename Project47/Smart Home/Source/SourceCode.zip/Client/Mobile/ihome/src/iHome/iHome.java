package iHome;

import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import javax.microedition.rms.*;
import java.util.*;

public class iHome extends MIDlet implements CommandListener,ItemStateListener,Runnable{
	static final String DeviceLIST = "Exec_ListDevice";
	static final String ViewCamera = "ViewCamera";
	static final String	SchedulesByDev = "Exec_ListSchedulesByDev";	
	static final String AddSCHEDULE = "AddSchedule";
	static final String RemoveSCHEDULE = "RemoveSchedule";
	static final String UpdateSCHEDULE = "UpdateSchedule";
	static final String ManualCapture ="ManualCapture";
	static final String UpdateCaptureTime ="UpdateCaptureTime";
	static final String	TurnON  = "Exec_On";
	static final String TurnOFF = "Exec_Off";
	static final String SetDIM  = "Exec_SetDim";
		
	private Service service; 
	private Display iDis;	
	private String method;
	private String addr;
	private String model;
	private Gauge dimGauge;	
	private Appliance app;
	private Alert statusAlert;
	
	private boolean newsched;
	private boolean editsched;
	private boolean delsched;
	private boolean chklogin;	
		
	private Command okCmd;
	private Command cancelCmd;
	private Command backCmd;
	private Command statusCmd;	
	private Command dimCmd;	
	private Command editschedCmd;
	private Command newschedCmd;
	private Command delschedCmd;
	private Command settingCmd;
	private Command captureCmd;
	private Command recordCmd;			
	private Command testaddCmd;												//**
		
	private Form camForm;
	private Form dimForm;
	private Form schedForm;
	private Form settingForm;
	private Form loginForm;
	private Form splashForm;
	private Form test;														//**
	
	private List mainMenu;
	private List homeMenu;	
	private List deviceList;
	private List schedList;
	
	private ChoiceGroup dirChoice;
	private ChoiceGroup statusChoice;
	private ChoiceGroup schtypeChoice;
	private ChoiceGroup weekdayChoice;
	private ChoiceGroup captimeChoice;
	private ChoiceGroup dimlevChoice;
	
	private TextField degreeField;
	private TextField nameField;
	
	private TextField testField;											//**
	private TextField testField2;											//**
	private TextField testField3;											//**
	
	private DateField dateField;
		
		
//-------------------------------------------------------------------------	
	public iHome(){
		iDis = Display.getDisplay(this);		
		method = new String();
				
		okCmd = new Command("Ok", Command.OK, 3);
        backCmd = new Command("Back", Command.BACK, 3);
        cancelCmd = new Command("Cancel", Command.CANCEL, 1);
        statusCmd = new Command("Change Status", Command.ITEM, 1);        
        dimCmd = new Command("Change DimLevel", Command.ITEM, 1);        
        newschedCmd = new Command("New Schedule", Command.ITEM, 1);
        editschedCmd = new Command("Edit Schedule", Command.ITEM, 1);
        delschedCmd = new Command("Delete Schedule", Command.ITEM, 1);
        settingCmd = new Command("Setting", Command.ITEM, 1);
        captureCmd = new Command("Capture", Command.ITEM, 1);
        recordCmd = new Command("Set Record", Command.ITEM, 1);
        
        service = new Service();
        service.setnamespace(readRMS("namespace"));        
        service.setsoapURL(readRMS("url"));
        service.setsoapAction(readRMS("action"));
                                
        nameField = new TextField("Schedule name","",50,TextField.ANY);
        degreeField = new TextField("Degree","",3,TextField.NUMERIC); 
        degreeField.setLayout(Item.LAYOUT_LEFT);                        
        dateField = new DateField("Start Date",DateField.DATE_TIME);            
                       
		dimGauge = new Gauge("Dimmer Level",true,7,0);
		dimGauge.setLayout(Gauge.LAYOUT_CENTER);		        
		
        dirChoice = new ChoiceGroup("Set Direction",Choice.POPUP);
        dirChoice.append("Turn Left",null);
        dirChoice.append("Turn Right",null);
        
        captimeChoice = new ChoiceGroup("Record Every (min)",Choice.POPUP);
        captimeChoice.append("0",null);
        captimeChoice.append("5",null);
        captimeChoice.append("10",null);
        captimeChoice.append("15",null);
        captimeChoice.append("30",null);
        captimeChoice.append("60",null);
        
        dimlevChoice = new ChoiceGroup("Dimer Level",Choice.POPUP);
        for (int i=0;i<=7;i++){
        	dimlevChoice.append(Integer.toString(i),null);
        }        
        
        schtypeChoice = new ChoiceGroup("Schedule Type",Choice.POPUP);
        schtypeChoice.append("Once",null);
        schtypeChoice.append("Daily",null);
        schtypeChoice.append("Weekly",null);
        schtypeChoice.append("Monthly",null);        
        
        statusChoice = new ChoiceGroup("Status",Choice.POPUP);
        statusChoice.append("ON",null);
        statusChoice.append("OFF",null);
        
        weekdayChoice = new ChoiceGroup("Weekday",Choice.MULTIPLE);
        weekdayChoice.append("Sunday",null);
        weekdayChoice.append("Monday",null);
        weekdayChoice.append("Tuesday",null);
        weekdayChoice.append("Wednesday",null);
        weekdayChoice.append("Thursday",null);
        weekdayChoice.append("Friday",null);
        weekdayChoice.append("Saturday",null);
        
        mainMenu = new List("iHome",List.IMPLICIT);
        mainMenu.setCommandListener(this);
        setLIST("MainMenu",mainMenu);        
                
        homeMenu = new List("Select Menu",List.IMPLICIT);
        homeMenu.addCommand(backCmd);
        homeMenu.setCommandListener(this);
        setLIST("HomeMenu",homeMenu);
        
        deviceList = new List("Device List",List.IMPLICIT);
        deviceList.addCommand(backCmd);
        deviceList.setCommandListener(this);
        //deviceList.append("TV test\n   Status :: On or Off",null);			//**
        
        schedList = new List("Schedule List",List.IMPLICIT);
        schedList.addCommand(backCmd);
		//schedList.addCommand(newschedCmd);
		//schedList.addCommand(editschedCmd);
		//schedList.addCommand(delschedCmd);		
		schedList.setCommandListener(this);
		//schedList.append("on 16.50 29/12/04",null);							//**
                    
        statusAlert = new Alert("","",null,AlertType.CONFIRMATION);
		statusAlert.addCommand(okCmd);
		statusAlert.addCommand(cancelCmd);
		statusAlert.setTimeout(Alert.FOREVER);
		statusAlert.setCommandListener(this);
		statusAlert.setTitle("");		
		
		camForm = new Form("camForm");		
		camForm.addCommand(backCmd);
		camForm.setCommandListener(this);
		
		dimForm = new Form("Set Dimmer Level");		
		dimForm.addCommand(okCmd);
		dimForm.addCommand(backCmd);
		dimForm.append(dimGauge);
		dimForm.setCommandListener(this);
		
		schedForm = new Form("Set Schedule");
		schedForm.addCommand(backCmd);
		schedForm.addCommand(okCmd);
		schedForm.setCommandListener(this);
		schedForm.setItemStateListener(this);
									
		settingForm = new Form("Setting");
		settingForm.addCommand(cancelCmd);
		settingForm.addCommand(okCmd);
		settingForm.setCommandListener(this);
		
		loginForm = new Form("Login");
		loginForm.addCommand(cancelCmd);
		loginForm.addCommand(okCmd);
		loginForm.addCommand(settingCmd);
		loginForm.setCommandListener(this);
		
		splashForm = new Form("splashForm");		
		splashForm.addCommand(okCmd);	
		splashForm.setCommandListener(this);
				
		test = new Form("Test Service");											//**
		testField  = new TextField("method","HelloWorld",100,TextField.ANY);
		testField2 = new TextField("key","",100,TextField.ANY);
		testField3 = new TextField("attribute","",100,TextField.ANY);
		testaddCmd = new Command("Add", Command.ITEM, 1);							
		test.addCommand(okCmd);
		test.addCommand(testaddCmd);
		test.addCommand(backCmd);
		test.setCommandListener(this);
				
	}
//-------------------------------------------------------------------------	
	public void startApp(){
		//setSplashFORM();
		//iDis.setCurrent(splashForm);
		chklogin = true;
		iDis.setCurrent(mainMenu);
		
	}
//-------------------------------------------------------------------------	
	public void pauseApp(){}
	
//-------------------------------------------------------------------------	
	public void destroyApp(boolean flag) {}
	
//-------------------------------------------------------------------------	
	public void run(){
		/*
		if (mainMenu.getSelectedIndex()==1000) {
			service.callImage();
			camForm.deleteAll();				
			ImageItem imgitem = new ImageItem("",service.getImage(),ImageItem.LAYOUT_CENTER,null);
			camForm.append(imgitem);
			iDis.setCurrent(camForm);
			method = "";			
		}else {						
			service.callService(method);							
		}
		*/
		
		service.callService(method);
		
		if (test.isShown()){												//**
			test.deleteAll();
			test.append(testField);
			test.append(testField2);
			test.append(testField3);
			test.append("result :\n"+service.getresult().toString());
			
		}else if (method == DeviceLIST){
			System.out.println ("DeviceLIST "+service.getresult().size());
			if (service.getXML().booleanValue()){
				setDeviceLIST();			
				iDis.setCurrent(deviceList);
			}else {
				Alert err = new Alert("error","error "+method,null,AlertType.ERROR);
				//err.setTimeout(Alert.FOREVER);
				iDis.setCurrent(err,mainMenu);				
			}
			
		}else if (method == ViewCamera){
			if (service.getXML().booleanValue()){
				setDeviceLIST();			
				iDis.setCurrent(deviceList);
			}else {
				Alert err = new Alert("error","error "+method,null,AlertType.ERROR);
				//err.setTimeout(Alert.FOREVER);
				iDis.setCurrent(err,mainMenu);				
			}
					
		}else if (method == ManualCapture){
			if (!service.getXML().booleanValue()){
				String r = service.getresult().elementAt(0).toString();				
				service.setPicture(r);
				
				service.callImage();
				camForm.deleteAll();
				camForm.removeCommand(okCmd);
				camForm.setTitle("Capture Image");
				ImageItem imgitem = new ImageItem("",service.getImage(),
									              ImageItem.LAYOUT_CENTER,null);
				camForm.append(imgitem);				
				iDis.setCurrent(camForm);
				
			}
				
		}else if (method == SchedulesByDev){
			schedList.deleteAll();
			schedList.removeCommand(newschedCmd);
			schedList.removeCommand(editschedCmd);
			schedList.removeCommand(delschedCmd);		
			if (service.getXML().booleanValue()){	
				for (int i=0;i<service.getresult().size();i++){			
					String list = service.getKey("name",i).toString();
					schedList.append(list,null);
				}
				schedList.addCommand(newschedCmd);
				schedList.addCommand(editschedCmd);
				schedList.addCommand(delschedCmd);
				iDis.setCurrent(schedList);								
			} else {
				String r = service.getresult().elementAt(0).toString();
				if (r.equals("null")){
					schedList.addCommand(newschedCmd);
					iDis.setCurrent(schedList);	
				}else{				
					Alert err = new Alert("error","error "+method,null,AlertType.ERROR);
					//err.setTimeout(Alert.FOREVER);
					iDis.setCurrent(err,mainMenu);
				}				
			}								
					
		}else if (method == TurnON || method == TurnOFF || method == SetDIM || 
			method == UpdateCaptureTime){
				
			if (!service.getXML().booleanValue()){
				System.out.println("service ok "+method);
				String r = service.getresult().elementAt(0).toString();
				System.out.println (r);
				if (r.equals("true")){
					service.copyDevToResult();
					int i = deviceList.getSelectedIndex();
					if (method == TurnON) {
						service.setKey("power",i,new Integer(1));
					}else if (method==TurnOFF){
						service.setKey("power",i,new Integer(0));
					}else if (method==SetDIM){
						service.setKey("dim_level",i,new Integer(dimGauge.getValue()));
					}else if (method==UpdateCaptureTime){
						int c = captimeChoice.getSelectedIndex();
						String cap = captimeChoice.getString(c);
						service.setKey("cap_time",i,new Integer(Integer.parseInt(cap)));
					}
					
					Alert okay = new Alert("","Complete",null,AlertType.INFO);
					//okay.setTimeout(Alert.FOREVER);					
					setDeviceLIST();
					iDis.setCurrent(okay,deviceList);
										
				}else if (r.equals("false")){
					Alert err = new Alert("","Fail !!",null,AlertType.ERROR);
					//err.setTimeout(Alert.FOREVER);
					service.copyDevToResult();
					setDeviceLIST();
					iDis.setCurrent(err,deviceList);
					
				}	
								
			}else {
				System.out.println ("Error Method "+method);
				iDis.setCurrent(deviceList);			
			
			}			
			
		}else if (method == RemoveSCHEDULE || method == AddSCHEDULE || 
		 method == UpdateSCHEDULE) {
			System.out.println (service.getresult().toString());						
			if (!service.getXML().booleanValue()){
				String r = service.getresult().elementAt(0).toString();
				service.copyDevToResult();
				setDeviceLIST();
				if (r.equals("0")){
					Alert okay = new Alert("","Complete",null,AlertType.INFO);
					//okay.setTimeout(Alert.FOREVER);					
					iDis.setCurrent(okay,deviceList);
				}else if (r.equals("1")||r.equals("false")){
					Alert error = new Alert("","Fail !!",null,AlertType.ERROR);
					//error.setTimeout(Alert.FOREVER);					
					iDis.setCurrent(error,deviceList);
				}
			}else {
				System.out.println ("Error Method "+method);
				service.copyDevToResult();
				setDeviceLIST();
				iDis.setCurrent(deviceList);			
			}			
/*
		}else if (method == AddSCHEDULE){
			System.out.println (service.getresult().toString());
			service.copyDevToResult();
			setDeviceLIST();
			iDis.setCurrent(deviceList);
			
		}else if (method == UpdateSCHEDULE){
			System.out.println (service.getresult().toString());
			service.copyDevToResult();
			setDeviceLIST();
			iDis.setCurrent(deviceList);
*/			
		}

		
	}	
//-------------------------------------------------------------------------	
	public void commandAction(Command c,Displayable s){			
		
		if (s==mainMenu && c==List.SELECT_COMMAND){
			switch(mainMenu.getSelectedIndex()) {
				//Home Appliance
				case 0 	: 	iDis.setCurrent(homeMenu);														
							break;
				
				//Security
				case 1 	: 	deviceList.removeCommand(dimCmd);
							deviceList.addCommand(statusCmd);
							method = DeviceLIST;
							service.addAttribute("mode",new Integer(4));
							new Thread(this).start();
							iDis.setCurrent(deviceList);
							break;							
											
				//Camera		 	
				case 2	:	//iDis.setCurrent(camMenu);
							method =ViewCamera;							
							new Thread(this).start();							
							break;
				
				//Schedule
				case 3	:	//iDis.setCurrent(schedList);
							method = DeviceLIST;
							service.addAttribute("mode",new Integer(0));							
							new Thread(this).start();							
							break;
				//Setting
				case 4	:	setSettingFORM();
							iDis.setCurrent(settingForm);
							break;
				
				//TestService
				case 5 	: 	test.deleteAll();								//**
							test.append(testField);
							test.append(testField2);
							test.append(testField3);
							iDis.setCurrent(test);
							break;
				
				//Exit				
				case 6 	:	destroyApp(true);
						 	notifyDestroyed();
					 		break;				
				default	:	
			}
			
		}else if (s==homeMenu && c==List.SELECT_COMMAND){
			switch(homeMenu.getSelectedIndex()){
				//switch
				case 0	:	method = DeviceLIST;
							service.addAttribute("mode",new Integer(1));							
							new Thread(this).start();
							break;
				//dimmer			
				case 1	:	method = DeviceLIST;
							service.addAttribute("mode",new Integer(2));							
							new Thread(this).start();
							break;
				default	:	break;
			}
					
		}else if (s==deviceList && c==statusCmd){
			int i = deviceList.getSelectedIndex();
			String status = service.getKey("power",i).toString();			
			if (status.equals("1")){
				method = TurnOFF;
				statusAlert.setString("Are you sure to Turn Off");								
			} else if (status.equals("0")){
				method = TurnON;
				statusAlert.setString("Are you sure to Turn On");				
			}			
			iDis.setCurrent(statusAlert,deviceList);
			
		}else if (s==deviceList && c==dimCmd){
			iDis.setCurrent(dimForm);
		
		}else if (s==deviceList && c==captureCmd){
			method = ManualCapture;
			int index = deviceList.getSelectedIndex();
			String a = service.getKey("port",index).toString();
			service.addAttribute("port",new Integer(Integer.parseInt(a)));
			service.addAttribute("size",new Integer(0));
			new Thread(this).start();
		
		//}else if (s==deviceList && (c==List.SELECT_COMMAND||c==okCmd) && 
		//mainMenu.getSelectedIndex()==2){
		////Camera				  	
		//	int sel = 0;//camMenu.getSelectedIndex();
		//	//view camera 
		//	if (sel==0){
		//		new Thread(this).start();
		//					
		//	//record setting
		//	}else if (sel==1){
		//		
		//	}
		}else if (s==deviceList && c==recordCmd){
			//camForm.removeCommand(recordCmd);
			camForm.deleteAll();
			camForm.setTitle("Record Setting");
			camForm.addCommand(okCmd);
			camForm.append(captimeChoice);
			iDis.setCurrent(camForm);
		
		/*}else if (s==deviceList && c==okCmd && mainMenu.getSelectedIndex()==2){
		//camera 
			int i = captimeChoice.getSelectedIndex();
			String captime = captimeChoice.getString(i);
			method = AddSCHEDULE;
			service.addAttribute("name","");
			service.addAttribute("address","");
			service.addAttribute("cmd",new Integer(3));
			service.addAttribute("param",captime);
			
			service.addAttribute("type","0");
			service.addAttribute("datetime","11/11/2548 15:00");
			service.addAttribute("days","0000000");			
			new Thread(this).start();
		*/								
		} else if (s==deviceList && c==List.SELECT_COMMAND && 
		mainMenu.getSelectedIndex()==3){
		//Schedule								
			int i = deviceList.getSelectedIndex();
			addr = service.getKey("address",i).toString();
			model = service.getKey("model",i).toString();
			method = SchedulesByDev;
			service.addAttribute("mode",new Integer(4));
			service.addAttribute("address",addr);
			new Thread(this).start();			
			
		}else if (s==deviceList && c==List.SELECT_COMMAND && 
		(mainMenu.getSelectedIndex()==0 || mainMenu.getSelectedIndex()==1 || 
		 mainMenu.getSelectedIndex()==2) ){
			showDeviceSTATUS(deviceList.getSelectedIndex());
			
		}else if (s==statusAlert && c==okCmd && (mainMenu.getSelectedIndex()==0 || 
			mainMenu.getSelectedIndex()==1)) {
		//Home App & Security
			int i = deviceList.getSelectedIndex();
			String address = service.getKey("address",i).toString();
			service.addAttribute("dist_addr",address);
			new Thread(this).start();
										
		}else if (s==statusAlert && c==cancelCmd && (mainMenu.getSelectedIndex()==0 || 
			mainMenu.getSelectedIndex()==1)){
		//Home App & Security	
			iDis.setCurrent(deviceList);
		
		//schedule	
		}else if (s==statusAlert && c==okCmd && mainMenu.getSelectedIndex()==3) {
			if (newsched || editsched){								
				service.addAttribute("name",nameField.getString());				
				service.addAttribute("datetime",getDateTime());
				service.addAttribute("days",getWeekDay());
				service.addAttribute("address",addr);
				service.addAttribute("cmd",new Integer(statusChoice.getSelectedIndex()));
				service.addAttribute("param","0");				
			}
			
			System.out.println (nameField.getString());
			System.out.println (getDateTime());
			System.out.println (getWeekDay());
			System.out.println (addr);
			System.out.println (statusChoice.getSelectedIndex());
			
				
			if (newsched){
				
				
				newsched = false;
				method = AddSCHEDULE;
				int t = schtypeChoice.getSelectedIndex();				
				service.addAttribute("type",new Integer(t));				
				new Thread(this).start();
					
			}else if (editsched){
				editsched = false;
				method = UpdateSCHEDULE;
				new Thread(this).start();
			
			}else if (delsched){
				delsched = false;
				int i = schedList.getSelectedIndex();
				String name = service.getKey("name",i).toString();
				method = RemoveSCHEDULE;
				service.addAttribute("name",name);
				new Thread(this).start();				
			} 
		
		//schedule
		}else if (s==statusAlert && c==cancelCmd && mainMenu.getSelectedIndex()==3){
			iDis.setCurrent(schedForm);
				
		//}else if (s==camForm && c==dirCmd){
		//	camForm.removeCommand(dirCmd);
		//	camForm.addCommand(okCmd);
		//	camForm.append(dirChoice);
		//	camForm.append(degreeField);
		//	iDis.setCurrent(camForm);
						
		}else if (s==camForm && c==okCmd){			
		//	camForm.removeCommand(okCmd);
		//	camForm.deleteAll();
		//	iDis.setCurrent(deviceList);
			int i = deviceList.getSelectedIndex();
			method = UpdateCaptureTime;
			String port = service.getKey("port",i).toString();
			int choice = captimeChoice.getSelectedIndex();
			String cap = captimeChoice.getString(choice);			
			service.addAttribute("port",new Integer(Integer.parseInt(port)));
			service.addAttribute("cap_time",new Integer(Integer.parseInt(cap)));				
			new Thread(this).start();			
						
		}else if (s==dimForm && c==okCmd){
			method = SetDIM;
			int i = deviceList.getSelectedIndex();
			String address = service.getKey("address",i).toString();
			service.addAttribute("dist_addr",address);
			service.addAttribute("percent",new Integer(dimGauge.getValue()));
			new Thread(this).start();			
									
		}else if (s==settingForm && c==okCmd){
			saveSetting();
			if (chklogin)
				iDis.setCurrent(mainMenu);
			else iDis.setCurrent(loginForm);
		
		}else if (s==settingForm && c==cancelCmd){
			if (chklogin)
				iDis.setCurrent(mainMenu);
			else iDis.setCurrent(loginForm);
		
		}else if (s==splashForm && c==okCmd){
			TextField userField = new TextField("Username","",50,TextField.ANY);
			TextField passField = new TextField("Password","",50,TextField.PASSWORD);
			loginForm.append(userField);
			loginForm.append(passField);
			iDis.setCurrent(loginForm);
		
		}else if (s==loginForm && c==okCmd){
			chklogin = true;
			iDis.setCurrent(mainMenu);
			
		}else if (s==loginForm && c==cancelCmd){
			destroyApp(true);
			notifyDestroyed();			
		
		}else if (s==loginForm && c==settingCmd){
			setSettingFORM();
			iDis.setCurrent(settingForm);
						
		}else if (s==schedList && c==newschedCmd){
			newsched = true;
			Date today = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(today);
			int gmt7 = setGMT7(cal.get(Calendar.HOUR_OF_DAY));
			cal.set(Calendar.HOUR_OF_DAY,gmt7);
			dateField.setDate(cal.getTime());
			System.out.println (dateField.getDate().getTime());
											
			schedForm.deleteAll();
			schedForm.append(nameField);
			schedForm.append(schtypeChoice);
			nameField.setString("");
			if (model.equals("00")||model.equals("03"))
				schedForm.append(statusChoice);
			
			//dim
			if (model.equals("01"))	
				schedForm.append(dimlevChoice);
					
			schedForm.append(dateField);			
			
			statusChoice.setSelectedIndex(0,true);
			schtypeChoice.setSelectedIndex(0,true);
			for(int i=0;i<weekdayChoice.size();i++)
				weekdayChoice.setSelectedIndex(i,false);
			iDis.setCurrent(schedForm);
			
		}else if (s==schedList && c==editschedCmd){
			editsched = true;
			int i = schedList.getSelectedIndex();
			schedForm.deleteAll();		
			schedForm.append(nameField);
			schedForm.append(statusChoice);			
			setScheduleFORM(i);
			iDis.setCurrent(schedForm);
			
		}else if (s==schedList && c==delschedCmd){
			delsched = true;
			statusAlert.setString("Are you sure ?");
			iDis.setCurrent(statusAlert,schedForm);			
			
		}else if (s==schedList && c==List.SELECT_COMMAND){
			int i = schedList.getSelectedIndex();
			showScheduleDETAIL(i);
			
		}else if (s==schedForm && c==okCmd){			
			//System.out.println ("ok");			
			//System.out.println (dateField.getDate().getTime());
			
			String chk = checkSchedFORM();			
			System.out.println (chk);
			if (!chk.equals("ok")){				
				Alert error = new Alert("","Fail !!",null,AlertType.ERROR);
				//error.setTimeout(Alert.FOREVER);
				iDis.setCurrent(error,schedForm);
				
			}else{
				statusAlert.setString("Are you sure ?");
				iDis.setCurrent(statusAlert,schedForm);
			}
			
		}else if (c==backCmd){
						
			if (mainMenu.getSelectedIndex()==1){
			//Security				
				iDis.setCurrent(mainMenu);
			
			}else if (s==deviceList && mainMenu.getSelectedIndex()==0){
			//HomeApp				
				deviceList.removeCommand(dimCmd);
				deviceList.removeCommand(statusCmd);
				iDis.setCurrent(homeMenu);			
								
			}else if (s==deviceList && mainMenu.getSelectedIndex()==2){
			//Camera				
				deviceList.removeCommand(recordCmd);
				deviceList.removeCommand(captureCmd);
				iDis.setCurrent(mainMenu);
				
			}else if (s==dimForm){
				iDis.setCurrent(deviceList);
				
			}else if (s==schedList){
				service.copyDevToResult();								
				setDeviceLIST();
				iDis.setCurrent(deviceList);
			
			}else if (s==camForm){
				service.copyDevToResult();				
				iDis.setCurrent(deviceList);
							
			}else if (s==schedForm){
				newsched = false;
				editsched = false;
				delsched = false;
				iDis.setCurrent(schedList);
				
			}else iDis.setCurrent(mainMenu);
				
		}else if (s.getTitle().equals("Test Service") && c==okCmd){					//**
			method = testField.getString();
			new Thread(this).start();
			
		}else if (s.getTitle().equals("Test Service") && c==testaddCmd){			//**
			String test2 = testField2.getString();
			String test3 = testField3.getString();
			
			if (test2.equals("mode") || test2.equals("percent")){
				service.addAttribute(test2,new Integer(Integer.parseInt(test3)));
				
			}else if (test2.equals("refresh")){
				if (test3.equals("true")){
					service.addAttribute(test2,new Boolean(true));
				}else service.addAttribute(test2,new Boolean(false));
								
			}else service.addAttribute(test2,test3);
			test.append(test2+" : "+test3+"\n");
			testField2.setString("");
			testField3.setString("");
									
		}
	}
//-------------------------------------------------------------------------
	public void itemStateChanged(Item item){
		System.out.println ("itemstateCheanged");		
		if (item.getLabel() == schtypeChoice.getLabel()){						
			schedForm.deleteAll();
			schedForm.append(nameField);
			schedForm.append(schtypeChoice);
			if (!model.equals("01")) schedForm.append(statusChoice);
			if (model.equals("01")) schedForm.append(dimlevChoice);			
			
			//daily
			if (schtypeChoice.getSelectedIndex()==1) 
				schedForm.append(weekdayChoice);			
			schedForm.append(dateField);			
		//}else if (item.getLabel() == dateField.getLabel()){
		//	System.out.println ("DateField");
		}
		
	}
//-------------------------------------------------------------------------	
	public void setLIST(String key,List list){		
		int i=1;		
		while (true){		
			String get = key + "-" + i;
			String menu = getAppProperty(get);
			if (menu == null || menu.length()==0) 
				break;				
			else {
				try{
					get = "icon" + key + "-" + i;
					String s = getAppProperty(get);
					//System.out.println (i);					
					if (s!=null){
						Image img = Image.createImage(s);
						list.append(menu,img);						
					}else list.append(menu,null);					
				}catch(Exception e){}
			}
			i++;
		}						
	}
//-------------------------------------------------------------------------		
	public void setDeviceLIST(){
		deviceList.deleteAll();
		if (mainMenu.getSelectedIndex()==0 && homeMenu.getSelectedIndex()==0) 
			deviceList.addCommand(statusCmd);
		if (mainMenu.getSelectedIndex()==0 && homeMenu.getSelectedIndex()==1)
			deviceList.addCommand(dimCmd);
		if (mainMenu.getSelectedIndex()==2){		
			deviceList.addCommand(recordCmd);
			deviceList.addCommand(captureCmd);
			deviceList.setCommandListener(this);
		}
		
		for (int i=0;i<service.getresult().size();i++){			
			String list = service.getKey("name",i).toString();
			
			if (method!=ViewCamera && method!=UpdateCaptureTime)
			{			
				String model = service.getKey("model",i).toString();
				String status="";
				if ((mainMenu.getSelectedIndex()==0 && homeMenu.getSelectedIndex()==0)||
					(mainMenu.getSelectedIndex()==1))
					status = service.getKey("power",i).toString();
					
				else if (mainMenu.getSelectedIndex()==0 && homeMenu.getSelectedIndex()==1) 
					status = service.getKey("dim_level",i).toString();
					
				else if (mainMenu.getSelectedIndex()==3){
					status = service.getKey("status",i).toString();	
				}				
				
				if (status!=null){
					try{
						Image s;
						if (Integer.parseInt(status)>=1){					
							s = Image.createImage("/icons/on.png");					
						}else
							s = Image.createImage("/icons/off.png");
						deviceList.append(list,s);
					}catch(Exception e){}
				}else deviceList.append(list,null);
			}else deviceList.append(list,null);
		}										
	}
//-------------------------------------------------------------------------
	public void setScheduleFORM(int index){				
		String name = service.getKey("name",index).toString();
		nameField.setString(name);
		System.out.println ("setScheduleFORM");
		String next_time = service.getKey("next_time",index).toString();
		Calendar cal = Calendar.getInstance();
		
		cal.set(Calendar.DAY_OF_MONTH,Integer.parseInt(parseDateTime(next_time,"day")));
		cal.set(Calendar.MONTH,Integer.parseInt(parseDateTime(next_time,"month"))-1);
		cal.set(Calendar.YEAR,Integer.parseInt(parseDateTime(next_time,"year")));
		cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(parseDateTime(next_time,"hour")));
		cal.set(Calendar.MINUTE,Integer.parseInt(parseDateTime(next_time,"min")));
		cal.set(Calendar.SECOND,Integer.parseInt(parseDateTime(next_time,"sec")));				
		dateField.setDate(cal.getTime());
				
		String days = service.getKey("days",index).toString();
		for(int i=0;i<weekdayChoice.size();i++){
			if (days.charAt(i)=='0'){
				weekdayChoice.setSelectedIndex(i,false);
			}else
				weekdayChoice.setSelectedIndex(i,true);				 
		}
		
		String cmd = service.getKey("cmd",index).toString();
		statusChoice.setSelectedIndex(Integer.parseInt(cmd),true);
		
		String type = service.getKey("type",index).toString();
		int t = Integer.parseInt(type);
		schtypeChoice.setSelectedIndex(t,true);						
		//daily
		if (t==1) schedForm.append(weekdayChoice);
		schedForm.append(dateField);
		System.out.println (dateField.getDate().getTime());
	}
//-------------------------------------------------------------------------
	public void showDeviceSTATUS(int index){
		String status="";
		if (mainMenu.getSelectedIndex()!=2)
		{		
			if ((mainMenu.getSelectedIndex()==0 && homeMenu.getSelectedIndex()==0) ||
				mainMenu.getSelectedIndex()==1)
				status = service.getKey("power",index).toString();
				
			//else if (mainMenu.getSelectedIndex()==2)
			//	status = service.getKey("status",index).toString();
				 
			else status = service.getKey("dim_level",index).toString();
		}
		
		Alert s = new Alert("","",null,AlertType.INFO);
		if (mainMenu.getSelectedIndex()!=2)
		{		
			if (Integer.parseInt(status)>=1)
				s.setString("Status - ON");				
			else if (status.equals("0"))
				s.setString("Status - OFF");				
		}
		
		if (mainMenu.getSelectedIndex()==0 && homeMenu.getSelectedIndex()==1){
			String level = service.getKey("dim_level",index).toString();
			String lv = s.getString();
			lv = lv+"\nLevel - "+level;
			s.setString(lv); 
		}else if (mainMenu.getSelectedIndex()==2){
			String c = s.getString();
			String detail = service.getKey("details",index).toString();
			c = c+detail;
			String port = service.getKey("port",index).toString();
			c = c+"\nPort "+port;			
			String cap = service.getKey("cap_time",index).toString(); 			
			c = c+"\nCapture time "+cap+" min";
			s.setString(c);
		}
		iDis.setCurrent(s,deviceList);
				
	}
//-------------------------------------------------------------------------
	public void showScheduleDETAIL(int index){		
		String text = new String("");
		Alert s = new Alert("","",null,AlertType.INFO);
		s.setTimeout(Alert.FOREVER);
		
		String status = service.getKey("cmd",index).toString();
		String next_time = service.getKey("next_time",index).toString();
		String type = service.getKey("type",index).toString();
		if (status.equals("0")){			
			text = "Action - ON\n";
		} else if (status.equals("1")){				
			text = "Action - OFF\n";	
		} else if (status.equals("2")){				
			text = "Action - Dim\n";			
		}
		
		text = text + "Time - "+parseDateTime(next_time,"time")+"\n";
			  
		if (type.equals("0")){
		//once			
			s.setTitle("Once");			
			
		}else if (type.equals("1")){
		//daily
			s.setTitle("Daily");
			String days = service.getKey("days",index).toString();
			text = text + "Every - " + parseDay(days)+"\n";
			
		}else if (type.equals("2")){
		//weekly			
			s.setTitle("Weekly");
			text = text + "Every - " + parseDateTime(next_time,"weekday")+"\n";
			
		}else if (type.equals("3")){
		//monthly
			s.setTitle("Monthly");
			text = text + "Every - "+parseDateTime(next_time,"day")
				   +parseDateTime(next_time,"daysub")+"\n";		
		}
		
		text = text  +"Start Date - " +parseDateTime(next_time,"date");
		s.setString(text);
		iDis.setCurrent(s,schedList);		
	}

//-------------------------------------------------------------------------
	public String parseDateTime(String date,String field){
		//1461-12-30T[10] [11]00:00:00.0000000+07:00
		if (field.equals("day")){
			return date.substring(8,10);
			
		}else if (field.equals("month")){			
			return date.substring(5,7);
			
		}else if (field.equals("year")){			
			return date.substring(0,4);
			
		}else if (field.equals("hour")){
			int hr = Integer.parseInt(date.substring(11,13));
			return String.valueOf(hr);
			
		}else if (field.equals("min")){
			return date.substring(14,16);
			
		}else if (field.equals("sec")){
			return date.substring(17,19);
			
		}else if (field.equals("all")){
			return parseDateTime(date,"hour")+":"+parseDateTime(date,"min")+
			" "+parseDateTime(date,"day")+"/"+parseDateTime(date,"month")+
			"/"+parseDateTime(date,"year");
			
		}else if (field.equals("date")){
			return parseDateTime(date,"day")+"/"+parseDateTime(date,"month")+
			"/"+parseDateTime(date,"year");
			
		}else if (field.equals("time")){
			return parseDateTime(date,"hour")+":"+parseDateTime(date,"min")+
			":"+parseDateTime(date,"sec");
			
		}else if (field.equals("weekday")){
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH,Integer.parseInt(parseDateTime(date,"day")));
			cal.set(Calendar.MONTH,Integer.parseInt(parseDateTime(date,"month")));
			cal.set(Calendar.YEAR,Integer.parseInt(parseDateTime(date,"year")));			
			int w = cal.get(Calendar.DAY_OF_WEEK);
			if (w==Calendar.MONDAY){
				return	"Monday";	
			}else if (w==Calendar.TUESDAY){
				return  "Tuesday";
			}else if (w==Calendar.WEDNESDAY){
				return  "Wednesday";
			}else if (w==Calendar.THURSDAY){
				return  "Thursday";
			}else if (w==Calendar.FRIDAY){
				return  "Friday";
			}else if (w==Calendar.SATURDAY){
				return  "Saturday";
			}else if (w==Calendar.SUNDAY){
				return  "Sunday";
			}else return null;
						
		}else if (field.equals("daysub")){
			int d = Integer.parseInt(parseDateTime(date,"day"));
			if (d == 1 || d==21 || d==31){
				return "st";
			}else if (d == 2 || d==22){
				return "nd";
			}else if (d == 3 || d==23){
				return "rd";
			}else
				return "th";
			
		}else return null;
	}
//-------------------------------------------------------------------------	
	public String parseDay(String day){
		//0000111
		StringBuffer d = new StringBuffer();
		for(int i=0;i<day.length();i++){
			if (day.charAt(i)=='1'){
				switch (i){
					case 0	: 	d.append("Sun "); break;
					case 1 	: 	d.append("Mon "); break;
					case 2 	: 	d.append("Tue "); break;
					case 3 	: 	d.append("Wed "); break;
					case 4 	: 	d.append("Thu "); break;
					case 5 	: 	d.append("Fri "); break;
					case 6 	: 	d.append("Sat"); break;					
				}				
			}//else d.append("--- ");
		}
		return d.toString();
	}
//-------------------------------------------------------------------------
	public String getWeekDay(){
		StringBuffer week = new StringBuffer();
		for(int i=0;i<weekdayChoice.size();i++){
			if (weekdayChoice.isSelected(i)){
				week.append('1');
			}else week.append('0'); 
		}
		return week.toString();		
	}
//-------------------------------------------------------------------------
	public String getDateTime(){
		StringBuffer dt = new StringBuffer();
		Calendar cal = Calendar.getInstance();			
		cal.setTime(dateField.getDate());
		
		long xxx = dateField.getDate().getTime();
		System.out.println (xxx);
		/*
		int month = cal.get(Calendar.MONTH)+1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int year = cal.get(Calendar.YEAR)+543;
		dt.append(day+"/"+month+"/"+year);		
				
		cal.setTime(dateField.getDate());
		int hr = cal.get(Calendar.HOUR_OF_DAY);
		int min = cal.get(Calendar.MINUTE);
		int sec = cal.get(Calendar.SECOND);
		dt.append(" "+ hr +":"+ min +":"+ sec);
			
		System.out.println (dt.toString());
		*/
		return dt.toString();		
	}
//-------------------------------------------------------------------------
	public String checkSchedFORM(){
		String ret = new String();		
		Calendar today = Calendar.getInstance();		
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateField.getDate());
		
		if (nameField.size()==0)
			ret = "Please set Schedule's name.\n";
				
		Date t = new Date();
		today.setTime(t);
		int gmt7 = setGMT7(today.get(Calendar.HOUR_OF_DAY));
		today.set(Calendar.HOUR_OF_DAY,gmt7);		
		
		//System.out.println (cal.get(Calendar.HOUR_OF_DAY));
		//System.out.println (cal.get(Calendar.MINUTE));
		//System.out.println (cal.get(Calendar.DATE));
		//System.out.println (cal.get(Calendar.MONTH));
		//System.out.println (cal.get(Calendar.YEAR));
		if (!cal.after(today))
			ret = ret+"Can't start Date&Time in past !!";
		
		if (ret.length()==0)
			ret = "ok";
		
		return ret;
	}
//-------------------------------------------------------------------------
	public int setGMT7(int hour){
		hour = hour + 7;
		if (hour > 24)
			return hour-24;
		else if (hour == 24)
			return 0;
		else return hour; 		
	}
//-------------------------------------------------------------------------
	public void setSettingFORM(){
		TextField namespaceField = new TextField("Soap Namespace",readRMS("namespace"),
								   100,TextField.ANY);
		TextField soapAcField = new TextField("Soap Action",readRMS("action"),
								100,TextField.ANY);
		TextField soapUrlField = new TextField("Soap URL",readRMS("url"),
								 100,TextField.ANY);		
		settingForm.deleteAll();
		settingForm.append(namespaceField);
		settingForm.append(soapAcField);
		settingForm.append(soapUrlField);
								
	}
//-------------------------------------------------------------------------	
	public void saveSetting(){
		boolean zero = false;
		for(int i=0;i<settingForm.size();i++){		
			TextField txtField = (TextField) settingForm.get(i);
			RecordStore rs;			
			try{			
				rs = RecordStore.openRecordStore("settingRecord",true);
				byte[] data = txtField.getString().getBytes();			
				if (rs.getNumRecords()==0 || zero){
					rs.addRecord(data,0,data.length);
					zero = true;
				}else if (!zero)
					rs.setRecord(i+1,data,0,data.length);													
				rs.closeRecordStore();
				
			}catch(RecordStoreException e){}			
		}		
	}	
//-------------------------------------------------------------------------	
    public String readRMS(String value){
    	RecordStore rs;
		byte[] data = new byte[100];
		StringBuffer strRecord = new StringBuffer();
				
		try{
			rs = RecordStore.openRecordStore("settingRecord",true);						
			if (rs.getNumRecords()!=0){
				int i;											
				
				if (value.equals("namespace")) i=1;
				else if (value.equals("action")) i=2;
				else if (value.equals("url")) i=3;					
				else i=0;
				
				if (i!=0){										
					int size = rs.getRecordSize(i);
					rs.getRecord(i,data,0);
					for(int j=0;j<size;j++)
						strRecord.append((char) data[j]);
				}
				
			}else {
				if (value.equals("namespace"))
					strRecord.append("http://hardware17.ce.kmitl.ac.th/iHomeService");
				else if (value.equals("action"))
					strRecord.append("http://hardware17.ce.kmitl.ac.th/iHomeService/");
				else if (value.equals("url"))
					strRecord.append("http://hardware17.ce.kmitl.ac.th/iHomeService/mobile.asmx");
			}
			rs.closeRecordStore();
			return strRecord.toString();
						
		}catch(RecordStoreException e){
			strRecord.append(e.toString());
			return strRecord.toString();
		}
    }
//-------------------------------------------------------------------------
	public void setSplashFORM(){
		String get = getAppProperty("splashlogo");
		try{
			Image img = Image.createImage(get);
			ImageItem logo = new ImageItem("",img,ImageItem.LAYOUT_CENTER,"");
			splashForm.append(logo);
		}catch (Exception e){}
				
	}
//-------------------------------------------------------------------------
		
				
	
}