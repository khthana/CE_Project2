<%@ Control Language="c#" AutoEventWireup="false" Codebehind="start.ascx.cs" Inherits="Classroom.control.start" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<P>
	<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<asp:Panel id="Panel1" runat="server" Width="425px" Height="235px" BackImageUrl="../images/bg102.gif">
			<P>Virsual Classroom</P>
			<P>this project provide knowlede of internet programing and architecture.this 
				project is great one project</P>
		</asp:Panel>
	<P></P>
	<P></P>
	<P>&nbsp;</P>
	<P>&nbsp;</P>
	<P>&nbsp;</P>
	<P>&nbsp;</P>
	<P>&nbsp;</P>
	<P>&nbsp;</P>
	<P>&nbsp;</P>
	<P>&nbsp;&nbsp;
	</P>
</FONT>
