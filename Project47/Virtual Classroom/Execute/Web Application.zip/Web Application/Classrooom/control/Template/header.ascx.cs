namespace Classroom.control.Template
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for header.
	/// </summary>
	public abstract class header : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Image Image3;
		protected System.Web.UI.WebControls.Image Image4;
		protected System.Web.UI.WebControls.Panel Panel1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//Response.Write(Session["login"].ToString());
		/*	try
			{
				char dl = '\\';
				string temp=Session["login"].ToString();
				string[] info=temp.Split(dl);
				Label1.Text=info[6]+" ���� "+info[2]+"  "+info[3];
				Session["login"].Equals("");
			}
			catch( Exception ee)
			{
				//Response.Write("you don't login");
				Label1.Text="�س�ѧ����� login";
			}*/
			
			// 0=std_id, 1=password, 2=name, 3=surname, 4=begin_study, 5=course
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
