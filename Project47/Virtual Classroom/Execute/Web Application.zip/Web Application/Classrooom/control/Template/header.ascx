<%@ Control Language="c#" AutoEventWireup="false" Codebehind="header.ascx.cs" Inherits="Classroom.control.Template.header" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<asp:Panel id="Panel1" Height="150px" Width="747px" runat="server" MS_POSITIONING="GridLayout"
		style="POSITION: relative">
		<asp:Image id="Image1" style="Z-INDEX: 101; LEFT: 4px; POSITION: absolute; TOP: 1px" runat="server"
			Width="736px" Height="93px" ImageUrl="../../images/head20.gif"></asp:Image>
		<asp:Image id="Image2" style="Z-INDEX: 102; LEFT: 4px; POSITION: absolute; TOP: 94px" runat="server"
			ImageUrl="../../images/users_feedback_s.gif"></asp:Image>
		<asp:Image id="Image3" style="Z-INDEX: 103; LEFT: 191px; POSITION: absolute; TOP: 94px" runat="server"
			ImageUrl="../../images/topmenu_img1.gif"></asp:Image>
		<asp:Image id="Image4" style="Z-INDEX: 104; LEFT: 219px; POSITION: absolute; TOP: 94px" runat="server"
			Width="524px" Height="46px" ImageUrl="../../images/products_b.gif"></asp:Image>
	</asp:Panel></FONT>
