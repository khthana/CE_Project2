<%@ Control Language="c#" AutoEventWireup="false" Codebehind="LeftNev.ascx.cs" Inherits="Classroom.control.Template.LeftNev" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">&nbsp;</P>
<P>
	<asp:ImageButton id="ImageButton4" runat="server" ImageUrl="../../images/nav342368090.gif"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton3" runat="server" ImageUrl="../../images/nav342368091.gif"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton2" runat="server" ImageUrl="../../images/nav342368092.gif"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton1" runat="server" ImageUrl="../../images/nav342368093.gif"></asp:ImageButton></P>
<P>&nbsp;</P>
<P>
	<asp:Label id="Label1" runat="server" Width="176px" Font-Bold="True" Font-Italic="True" Font-Names="Arial"
		Font-Underline="True" Font-Size="Large">    ��Ѥ���Ҫԡ</asp:Label></P>
<P>
	<asp:ImageButton id="ImageButton5" ImageUrl="../../images/nav358582610.gif" runat="server"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton6" ImageUrl="../../images/nav358582611.gif" runat="server"></asp:ImageButton></P>
</FONT>
