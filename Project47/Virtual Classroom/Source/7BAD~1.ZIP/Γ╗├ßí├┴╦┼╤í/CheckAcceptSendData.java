package Sock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class CheckAcceptSendData {
  public CheckAcceptSendData() {

  }

  public void CheckSendBroadcast()
  {

  }

  public void CheckAcceptBroadcast()
  {

  }

  public void CheckSendPrivate()
  {

  }

  public void CheckAcceptPrivate()
  {

  }

  // Recieve Update Member Data from server
  public void CheckInitUpdateData()
  {

  }

  public void CheckUpdateLoginNewMember()
  {

  }

  public void CheckUpdateCloseMember()
  {

  }

  // end Recieve Update Member Data from server

}