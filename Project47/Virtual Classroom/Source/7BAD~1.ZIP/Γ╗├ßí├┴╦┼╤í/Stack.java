package Sock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */


public class Stack {
  private String s[]=new String[50];
  private int top;

  public Stack() {
    top = 0;
  }

  public void push(String st) {
    s[++top] = st;
  }

  public String pop() {
    return s[top--];
  }

  public int gettop() {
    return top;
  }
}
