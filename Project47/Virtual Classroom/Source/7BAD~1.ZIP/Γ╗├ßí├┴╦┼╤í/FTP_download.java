package Sock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */


import  com.jscape.inet.ftp.*;
import java.io.*;
import java.util.Enumeration;
import java.awt.event.*;
import javax.swing.*;

public class FTP_download extends FtpAdapter {

  private ProgressMonitor pm ;
  private long size,sizeload,loadall;
  private String root;
  private Stack  stack;
  private Ftp ftp;
  private int orderdir=0;
  private String SendToDirectory = "C:/Sock/Image";

  public FTP_download () {
    pm = new ProgressMonitor(new JFrame(),
                             "File downloading.........",
                             "Initializing. . .", 0, 100);
    sizeload=0;
    ftp=new Ftp();
    stack=new Stack();
    loadall=0;
  }
    // perform directory download
    public void doDownload(String hostname, String username, String password, String directory) throws FtpException {
      ftp.addFtpListener(this);
      ftp.setLocalDir(new File(SendToDirectory));/////////////////////////////////////// Set local
      ftp.setHostname(hostname);
      ftp.setUsername(username);
      ftp.setPassword(password);

      ftp.connect();
      // get file size and file path
      size = getsizeOfFloder(directory);
      ftp.setBinary();
      ftp.downloadDir(directory);
      ftp.disconnect();
    }

    public void IsdonwloadCancel(){
      pm.close();
      System.exit(0);
    }

     void setroot(String root){
      this.root=root;
    }
     public String getroot(){
      return root;
    }

    public  String getFileName(String hostname, String username, String password, String directory) throws FtpException {

      ftp.addFtpListener(this);
      ftp.setLocalDir(new File(SendToDirectory));/////////////////////////////////////// Set local

      ftp.setHostname(hostname);
      ftp.setUsername(username);
      ftp.setPassword(password);
      ftp.connect();


      String filename="";
       Enumeration files = ftp.getDirListing();
      while (files.hasMoreElements()) {
       // j++;
       // orderdir++;
        FtpFile file = (FtpFile) files.nextElement();
        //compute  all size of file
        size = size + file.getFilesize();
        //display path
         filename = file.getFilename();
      }// end while
      ftp.disconnect();
    return  filename;
  } // end function

    public long getsizeOfFloder(String dir) throws FtpException {
      int j = 0;
      Enumeration files = ftp.getDirListing();
      while (files.hasMoreElements()) {
        j++;
        orderdir++;
        FtpFile file = (FtpFile) files.nextElement();
        //compute  all size of file
        size = size + file.getFilesize();
        //display path
        String setroot = ftp.getDir() + file.getFilename();
        //get access into floder
        if (file.isDirectory() && orderdir != 1 && orderdir != 2 && j != 1 && j != 2) {
          String f = file.getFilename();
          //chang to inner directory
          stack.push(ftp.getDir()); //push current dir
          ftp.setDir(f); //set go into sub current found
          //get inner directory
          getsizeOfFloder(f);
          // after upon line stack of recurtion is release

          //chang String back to old directory when stack of recurtion is  release
          ftp.setDir(stack.pop());
        }
      }
  //    ftp.setDirUp();
      return size;
    }

    // captures download event
    public void download(FtpDownloadEvent evt) {
     sizeload = sizeload + evt.getSize();
      //collect  old size file
      loadall = sizeload;
    }

    // captures connect event
    public void connected(FtpConnectedEvent evt) {
        System.out.println("Connected to server: " + evt.getHostname());
    }

    // captures disconnect event
    public void disconnected(FtpDisconnectedEvent evt) {
        System.out.println("Disconnected from server: " + evt.getHostname());
        System.out.println("Total is"+size);
        System.out.println("size load is"+sizeload);
        pm.close();
    }
    public void  progress(FtpProgressEvent evt){  //construck  ProgressBar
      if(pm.isCanceled()){
        IsdonwloadCancel();
      }
      int n=(int)((loadall+evt.getBytes())*100/size);
      pm.setProgress(n);
      pm.setNote("Operation is "+n+"%complete");
    }
}

