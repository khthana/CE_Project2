using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Classrooom.Personal.Admin
{
	/// <summary>
	/// Summary description for Download.
	/// </summary>
	public class Download :  Classroom.PageTemplate
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			base.LeftNav.Width = 200;
			base.RightNav.Width=0;
			
			base.Header.Controls.Add(LoadControl("../../control/Template/header.ascx"));
			//string contend = Request.FilePath;
			//base.Response.Write(contend);

			bool check=true;
			try
			{
				Session["login"].Equals("");
			}
			catch(Exception ee)
			{
				check=false;
			}
			if(check)
			{
				base.Body.Controls.Add(LoadControl("../../control/Person/Admin/Download.ascx"));
				base.LeftNav.Controls.Add(LoadControl("../../control/Template/Person/A_LeftNev.ascx"));
			}
			else
			{
				base.Body.Controls.Add(LoadControl("../../control/Person/ErrLogin.ascx"));
				base.LeftNav.Controls.Add(LoadControl("../../control/Template/_blank.ascx"));
			}

			base.Footer.Controls.Add(LoadControl("../../control/Template/Footer.ascx"));
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
