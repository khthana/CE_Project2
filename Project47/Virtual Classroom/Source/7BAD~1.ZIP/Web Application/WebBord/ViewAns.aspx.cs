using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Classrooom.control.Webbord;
using System.ComponentModel.Design;
//using System.Web.UI.C

namespace Classrooom
{
	/// <summary>
	/// Summary description for ViewAns.
	/// </summary>
	public class ViewAns : Classroom.PageTemplate
	{
		
		Control foot,postform,body;
		public View_ans Vbody;
		//String sref;
			
		private void Page_Load(object sender, System.EventArgs e)
		{
			//IReferenceService.g		
			// Put user code to initialize the page here
			base.LeftNav.Width = 200;
			base.RightNav.Width=0;
			// ���ҧ instant controls ����ҡ custom controls file ������� reference �Ѻ foot , footform
			postform = LoadControl("../control/Webbord/Post_reply.ascx");
			body     = LoadControl("../control/Webbord/View_ans.ascx");
			foot     = LoadControl("../control/Template/Footer.ascx");

			//��� controls ����˹�١ add ���� placholder ����� ��������ա
			base.LeftNav.Controls.Add(LoadControl("../control/Template/_blank.ascx"));
			base.Header.Controls.Add(LoadControl("../control/Template/header.ascx"));
			//base.RightNav.Controls.Add(LoadControl("../control/Template/RigthNave.ascx"));
			base.Body.Controls.Add(postform); 
			base.Body.Controls.Add(body);
			base.Footer.Controls.Add(foot);
		}

		
		//pre render event run after run page_load of all control
		private void show(object sender,System.EventArgs e)
		{
			//base.Body.Controls.Add(body);
			int i = base.Body.Controls.IndexOf(body);
			Vbody = (View_ans)base.Body.Controls[i];
			Vbody.retriveDatatoDataset();
			int j= base.Body.Controls.IndexOf(postform);
			if(Vbody.checkSubmitForme()==true)
			{
				base.Body.Controls[j].Visible=true;
			}
			else
				base.Body.Controls[j].Visible=false;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//this.ViewState["Isgetform"]="none";
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
			this.PreRender += new System.EventHandler(this.show);

		}
		#endregion
	}
}
