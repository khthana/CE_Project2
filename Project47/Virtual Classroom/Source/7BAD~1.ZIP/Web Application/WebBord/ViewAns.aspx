<%@ Page language="c#" Codebehind="ViewAns.aspx.cs" AutoEventWireup="false" Inherits="Classrooom.ViewAns" enableViewState="True" enableViewStateMac="False"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>ViewAns</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	</body>
</HTML>
