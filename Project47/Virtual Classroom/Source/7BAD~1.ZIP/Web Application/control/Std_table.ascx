<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Std_table.ascx.cs" Inherits="Classrooom.control.Std_table" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">
		<asp:DataGrid id=DataGrid1 runat="server" DataSource="<%# dsTable_Course1 %>" DataMember="Opencourse" AutoGenerateColumns="False">
			<Columns>
				<asp:BoundColumn DataField="Subject_ID" SortExpression="Subject_ID" HeaderText="�����Ԫ�"></asp:BoundColumn>
				<asp:BoundColumn DataField="NameSubject" SortExpression="NameSubject" HeaderText="�Ԫ�"></asp:BoundColumn>
				<asp:BoundColumn DataField="Credit" SortExpression="Credit" HeaderText="Credit"></asp:BoundColumn>
				<asp:BoundColumn DataField="Sec" SortExpression="Sec" HeaderText="Sec"></asp:BoundColumn>
				<asp:BoundColumn DataField="Room" SortExpression="Room" HeaderText="��ͧ���¹"></asp:BoundColumn>
				<asp:BoundColumn DataField="Study_date" SortExpression="Study_date" HeaderText="�ѹ���¹"></asp:BoundColumn>
				<asp:BoundColumn DataField="Study_time" SortExpression="Study_time" HeaderText="�������¹"></asp:BoundColumn>
				<asp:BoundColumn DataField="Exam_date" SortExpression="Exam_date" HeaderText="�ѹ�ͺ"></asp:BoundColumn>
				<asp:BoundColumn DataField="Exam_time" SortExpression="Exam_time" HeaderText="�����ͺ"></asp:BoundColumn>
				<asp:BoundColumn DataField="Group_subject" SortExpression="Group_subject" HeaderText="�������Ԫ�"></asp:BoundColumn>
			</Columns>
		</asp:DataGrid></FONT></P>
