namespace Classrooom.control
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.OleDb;

	/// <summary>
	///		Summary description for Login.
	/// </summary>
	public class Login : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.RadioButton RadioButton1;
		protected System.Web.UI.WebControls.RadioButton RadioButton2;
		protected System.Web.UI.WebControls.RadioButton RadioButton3;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		protected System.Web.UI.WebControls.Panel Panel2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.TextBox TextBox1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			Panel2.Visible=false;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			//bool havedata=false;
			
			//bool checklogin = false;

			if(RadioButton1.Checked)
				//�բ����Źѡ���¹����
				if(!checklogin("Student"))
				{
					Panel1.Visible=false;
					Panel2.Visible=true;
				}
				else
					Response.Redirect(ResolveUrl("../Personal/Student/Table_std.aspx"));
			
			if(RadioButton2.Checked)
				//�բ������Ҩ��������
				if(!checklogin("Teacher"))
				{
					Panel1.Visible=false;
					Panel2.Visible=true;
				}
				else
					Response.Redirect(ResolveUrl("../Personal/Teacher/Table_teach.aspx"));
			
			if(RadioButton3.Checked)
				//�բ����ż������к�����
				if(!checklogin("Admin"))
				{
					Panel1.Visible=false;
					Panel2.Visible=true;
				}
				else
					Response.Redirect(ResolveUrl("../Personal/Admin/Download.aspx"));
		}

		private bool checklogin(String table)
		{
			OleDbDataReader rdr;
			bool check=false;
			String sql="SELECT * FROM "+table+" WHERE Id='"+TextBox1.Text+
				"' AND Password='"+TextBox2.Text+"'";
			OleDbCommand command = new OleDbCommand(sql,oleDbConnection1);
			oleDbConnection1.Open();
			rdr=command.ExecuteReader();
			String data="";

			while(rdr.Read())
			{	
				for(int i=0;i<rdr.FieldCount;i++)
				{
					check = true;
					data=data+rdr.GetValue(i)+'\\';
				}
			}
			rdr.Close();
			oleDbConnection1.Close();
			Session["login"]=data;
			Response.Write(Session["login"]);
			return check;
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			Panel1.Visible=true;
			Panel2.Visible=false;
		}


	}
}
