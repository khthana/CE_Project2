<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Login.ascx.cs" Inherits="Classrooom.control.Login" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<P>&nbsp;</P>
	<P><asp:panel id="Panel1" Height="176px" Width="416px" runat="server">
			<P>
				<asp:Label id="Label1" runat="server">Username</asp:Label>&nbsp;&nbsp;
				<asp:TextBox id="TextBox1" runat="server"></asp:TextBox></P>
			<P></P>
			<P>
				<asp:Label id="Label2" runat="server">Password</asp:Label>&nbsp;&nbsp;&nbsp;
				<asp:TextBox id="TextBox2" runat="server" TextMode="Password"></asp:TextBox></P>
			<P>
				<asp:RadioButton id="RadioButton1" runat="server" GroupName="1" Checked="True" Text="�ѡ�֡��"></asp:RadioButton>
				<asp:RadioButton id="RadioButton2" runat="server" GroupName="1" Text="�Ҩ����"></asp:RadioButton>
				<asp:RadioButton id="RadioButton3" runat="server" GroupName="1" Text="�������к�"></asp:RadioButton></P>
			<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<asp:Button id="Button1" runat="server" Text="�������к�"></asp:Button></P>
		</asp:panel>
</FONT>
<asp:panel id="Panel2" Height="138px" Width="416px" runat="server">
	<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</FONT>
		<asp:Label id="Label3" runat="server" Width="168px" Height="24px" ForeColor="Red" Font-Size="Large">���ʼ�ҹ �Դ��Ҵ</asp:Label></P>
	<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></P>
	<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></P>
	<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </FONT>
		<asp:Button id="Button2" runat="server" Text="�ͧ�ա����"></asp:Button></P>
</asp:panel>
