namespace Classrooom.control.Person.Teacher
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Threading;
	using System.Globalization;
	using System.Data.OleDb;

	/// <summary>
	///		Summary description for Table_teach.
	/// </summary>
	public class Table_teach : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;

		private void Page_Load(object sender, System.EventArgs e)
		{


			char dl = '\\';
			string temp=Session["login"].ToString();
			string[] info=temp.Split(dl);
			// 0=std_id, 1=password, 2=name, 3=surname, 4=begin_study, 5=course



			String sqlP="SELECT * FROM Opencourse WHERE Teacher_ID='"+info[0].ToString()+"'";

			//open the connection
			oleDbConnection1.Open();

			//create the data adapter and execute the query
			OleDbDataAdapter oDA = new OleDbDataAdapter(sqlP,oleDbConnection1); 

			//create the DataSet
			DataSet oDs = new DataSet(); 

			//Fill the dataset with the data adapter
			oDA.Fill(oDs); 
			oleDbConnection1.Close();

			
			DataGrid1.DataSource=oDs;
			DataGrid1.DataBind();
			
			//Clean Up
			oDA.Dispose(); 



		







			

		/*	DateTime dt = DateTime.Now;
			// Sets the CurrentCulture property to U.S. English.
			Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
			// Displays dt, formatted using the ShortDatePattern
			// and the CurrentThread.CurrentCulture.
			string yr=dt.ToString("y");
			char delim = ' ';
			string[] date=yr.Split(delim);
			decimal y=Convert.ToDecimal(date[1])+542;

			//string sql="SELECT * FROM Opencourse t1, Subject t2,Register t3 WHERE t1.Subject_ID=t2.Subject_ID AND t2.NameSubject=t3.Subject "
			//	+"AND t1.Teacher_ID='"+info[0].ToString()+"' AND t1.Graduate_year='2/"+y+"'";
			
			string sql="SELECT * FROM Opencourse WHERE Teacher_ID='"+info[0].ToString()+"'";
			this.oleDbSelectCommand1.CommandText = sql;
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;

			//DataGrid1.DataSource=

		
			//Response.Write(sql);


			oleDbDataAdapter1.Fill(dstable_teach1);
			Response.Write("<BR><BR> "+dstable_teach1.Tables[0].Rows.Count);
			DataGrid1.DataSource=dstable_teach1;
			DataGrid1.DataBind();*/





			/*// Put user code to initialize the page here

			char dl = '\\';
			string temp=Session["login"].ToString();
			string[] info=temp.Split(dl);
			// 0=std_id, 1=password, 2=name, 3=surname, 4=begin_study, 5=course
			

			DateTime dt = DateTime.Now;
			// Sets the CurrentCulture property to U.S. English.
			Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
			// Displays dt, formatted using the ShortDatePattern
			// and the CurrentThread.CurrentCulture.
			String yr=dt.ToString("y");
			char delim = ' ';
			String[] date=yr.Split(delim);
			decimal y=Convert.ToDecimal(date[1])+542;
			
			string sql="SELECT * FROM Opencourse t1, Subject t2,Register t3 WHERE (t1.Subject_ID=t2.Subject_ID) AND (t2.NameSubject=t3.Subject "
				+") AND (t1.Teacher_ID='"+info[0].ToString()+"') AND (t3.yr='2/"+y+"')";
			oleDbSelectCommand1.CommandText = sql;
			oleDbSelectCommand1.Connection = oleDbConnection1;
			
			

			oleDbDataAdapter1.Fill(dstable_teach1);
			DataGrid1.DataBind();*/
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
