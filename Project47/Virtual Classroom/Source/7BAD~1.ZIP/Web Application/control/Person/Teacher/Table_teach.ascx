<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Table_teach.ascx.cs" Inherits="Classrooom.control.Person.Teacher.Table_teach" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P>
	<FONT face="Tahoma">
		<asp:DataGrid id="DataGrid1" runat="server"></asp:DataGrid></FONT></P>
