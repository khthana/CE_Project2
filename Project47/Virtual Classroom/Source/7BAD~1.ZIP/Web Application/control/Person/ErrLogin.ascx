<%@ Control Language="c#" AutoEventWireup="false" Codebehind="ErrLogin.ascx.cs" Inherits="Classrooom.control.Person.ErrLogin" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<asp:Label id="Label1" runat="server" Width="424px" Font-Bold="True" Font-Size="Large" ForeColor="Red"> ���ʼԴ��Ҵ �ҡ������</asp:Label>
