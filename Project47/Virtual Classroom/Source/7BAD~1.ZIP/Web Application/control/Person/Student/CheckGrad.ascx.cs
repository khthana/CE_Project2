namespace Classrooom.control.Person.Student
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Threading;
	using System.Globalization;

	/// <summary>
	///		Summary description for CheckGrad.
	/// </summary>
	public class CheckGrad : System.Web.UI.UserControl
	{
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
		protected System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
		protected Classrooom.control.Person.Student.Dschk_std dschk_std1;

		string[] info;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			char dl = '\\';
			string temp=Session["login"].ToString();
			info=temp.Split(dl);
			// 0=std_id, 1=password, 2=name, 3=surname, 4=begin_study, 5=course
			

			DateTime dt = DateTime.Now;
			// Sets the CurrentCulture property to U.S. English.
			Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
			// Displays dt, formatted using the ShortDatePattern
			// and the CurrentThread.CurrentCulture.
			String yr=dt.ToString("y");
			char delim = ' ';
			String[] date=yr.Split(delim);
			decimal y=Convert.ToDecimal(date[1])+542;

			this.oleDbSelectCommand1.CommandText = "SELECT * FROM Opencourse t1, Subject t2,Register t3 WHERE t1.Subject_ID=t2.Subject_ID AND t2.NameSubject=t3.Subject "
				+"AND t3.Student_ID='"+info[0].ToString()+"' AND t3.yr='2/"+y+"'";
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;


			oleDbDataAdapter1.Fill(dschk_std1);
			DataGrid1.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
			this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
			this.dschk_std1 = new Classrooom.control.Person.Student.Dschk_std();
			((System.ComponentModel.ISupportInitialize)(this.dschk_std1)).BeginInit();
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			// 
			// oleDbDataAdapter1
			// 
			this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
			this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Opencourse", new System.Data.Common.DataColumnMapping[] {
																																																					  new System.Data.Common.DataColumnMapping("Defination", "Defination"),
																																																					  new System.Data.Common.DataColumnMapping("Exam_date", "Exam_date"),
																																																					  new System.Data.Common.DataColumnMapping("Exam_time", "Exam_time"),
																																																					  new System.Data.Common.DataColumnMapping("For_class", "For_class"),
																																																					  new System.Data.Common.DataColumnMapping("For_course", "For_course"),
																																																					  new System.Data.Common.DataColumnMapping("Graduate_year", "Graduate_year"),
																																																					  new System.Data.Common.DataColumnMapping("Max_std", "Max_std"),
																																																					  new System.Data.Common.DataColumnMapping("Room", "Room"),
																																																					  new System.Data.Common.DataColumnMapping("Sec", "Sec"),
																																																					  new System.Data.Common.DataColumnMapping("Study_date", "Study_date"),
																																																					  new System.Data.Common.DataColumnMapping("Study_time", "Study_time"),
																																																					  new System.Data.Common.DataColumnMapping("Subject_ID", "Subject_ID"),
																																																					  new System.Data.Common.DataColumnMapping("Teacher_ID", "Teacher_ID"),
																																																					  new System.Data.Common.DataColumnMapping("Credit", "Credit"),
																																																					  new System.Data.Common.DataColumnMapping("Expr1", "Expr1"),
																																																					  new System.Data.Common.DataColumnMapping("Group_subject", "Group_subject"),
																																																					  new System.Data.Common.DataColumnMapping("NameSubject", "NameSubject"),
																																																					  new System.Data.Common.DataColumnMapping("Pre", "Pre"),
																																																					  new System.Data.Common.DataColumnMapping("Expr2", "Expr2"),
																																																					  new System.Data.Common.DataColumnMapping("Grad", "Grad"),
																																																					  new System.Data.Common.DataColumnMapping("Student_ID", "Student_ID"),
																																																					  new System.Data.Common.DataColumnMapping("Subject", "Subject"),
																																																					  new System.Data.Common.DataColumnMapping("yr", "yr")})});
			// 
			// oleDbSelectCommand1
			// 
			this.oleDbSelectCommand1.CommandText = @"SELECT Opencourse.Defination, Opencourse.Exam_date, Opencourse.Exam_time, Opencourse.For_class, Opencourse.For_course, Opencourse.Graduate_year, Opencourse.Max_std, Opencourse.Room, Opencourse.Sec, Opencourse.Study_date, Opencourse.Study_time, Opencourse.Subject_ID, Opencourse.Teacher_ID, Subject.Credit, Subject.Defination AS Expr1, Subject.Group_subject, Subject.NameSubject, Subject.Pre, Subject.Subject_ID AS Expr2, Register.Grad, Register.Student_ID, Register.Subject, Register.yr FROM (Opencourse INNER JOIN Subject ON Opencourse.Subject_ID = Subject.Subject_ID), Register";
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			// 
			// dschk_std1
			// 
			this.dschk_std1.DataSetName = "Dschk_std";
			this.dschk_std1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dschk_std1)).EndInit();

		}
		#endregion
	}
}
