<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Table_std.ascx.cs" Inherits="Classrooom.control.Person.Student.Table_std" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">
		<asp:Literal id="Literal1" runat="server"></asp:Literal></FONT><FONT face="Tahoma">
	</FONT>
</P>
