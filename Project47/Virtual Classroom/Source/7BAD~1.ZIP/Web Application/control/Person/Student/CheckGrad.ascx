<%@ Control Language="c#" AutoEventWireup="false" Codebehind="CheckGrad.ascx.cs" Inherits="Classrooom.control.Person.Student.CheckGrad" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<asp:DataGrid id=DataGrid1 runat="server" DataSource="<%# dschk_std1 %>" DataMember="Opencourse" AutoGenerateColumns="False">
	<Columns>
		<asp:BoundColumn DataField="NameSubject" SortExpression="NameSubject" HeaderText="�����Ԫ�"></asp:BoundColumn>
		<asp:BoundColumn DataField="Sec" SortExpression="Sec" HeaderText="�����"></asp:BoundColumn>
		<asp:BoundColumn DataField="Credit" SortExpression="Credit" HeaderText="˹��¡Ե"></asp:BoundColumn>
		<asp:BoundColumn DataField="Room" SortExpression="Room" HeaderText="��ͧ���¹"></asp:BoundColumn>
		<asp:BoundColumn DataField="Study_date" SortExpression="Study_date" HeaderText="�ѹ���¹"></asp:BoundColumn>
		<asp:BoundColumn DataField="Study_time" SortExpression="Study_time" HeaderText="�������¹"></asp:BoundColumn>
		<asp:BoundColumn DataField="Exam_date" SortExpression="Exam_date" HeaderText="�ѹ�ͺ"></asp:BoundColumn>
		<asp:BoundColumn DataField="Exam_time" SortExpression="Exam_time" HeaderText="�����ͺ"></asp:BoundColumn>
	</Columns>
</asp:DataGrid>
