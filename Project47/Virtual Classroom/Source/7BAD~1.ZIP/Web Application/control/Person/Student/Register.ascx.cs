namespace Classrooom.control.Person.Student
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Globalization;
	using System.Threading;
	using System.Data.OleDb;


	/// <summary>
	///		Summary description for Register.
	/// </summary>
	public class Register : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Panel Panel2;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		string[] date;
		protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
		protected System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
		protected Classrooom.control.Person.Student.Dsreg dsreg1;
		protected System.Web.UI.WebControls.TextBox S1;
		protected System.Web.UI.WebControls.TextBox s11;
		protected System.Web.UI.WebControls.Label c1;
		protected System.Web.UI.WebControls.Label sn1;
		protected System.Web.UI.WebControls.TextBox S2;
		protected System.Web.UI.WebControls.TextBox s22;
		protected System.Web.UI.WebControls.Label c2;
		protected System.Web.UI.WebControls.Label sn2;
		protected System.Web.UI.WebControls.TextBox S3;
		protected System.Web.UI.WebControls.TextBox s33;
		protected System.Web.UI.WebControls.Label c3;
		protected System.Web.UI.WebControls.Label sn3;
		protected System.Web.UI.WebControls.TextBox S4;
		protected System.Web.UI.WebControls.TextBox s44;
		protected System.Web.UI.WebControls.Label c4;
		protected System.Web.UI.WebControls.Label sn4;
		protected System.Web.UI.WebControls.TextBox S5;
		protected System.Web.UI.WebControls.TextBox s55;
		protected System.Web.UI.WebControls.Label c5;
		protected System.Web.UI.WebControls.Label sn5;
		protected System.Web.UI.WebControls.TextBox S6;
		protected System.Web.UI.WebControls.TextBox s66;
		protected System.Web.UI.WebControls.Label c6;
		protected System.Web.UI.WebControls.Label sn6;
		protected System.Web.UI.WebControls.TextBox S7;
		protected System.Web.UI.WebControls.TextBox s77;
		protected System.Web.UI.WebControls.Label c7;
		protected System.Web.UI.WebControls.Label sn7;
		protected System.Web.UI.WebControls.TextBox S8;
		protected System.Web.UI.WebControls.TextBox s88;
		protected System.Web.UI.WebControls.Label c8;
		protected System.Web.UI.WebControls.Label sn8;
		decimal y;
		string[] info;
		bool FlagcheckPass,chkNonPre;
		protected System.Web.UI.WebControls.Literal Literal1;
		string[] sn={"","","","","","","","",  //�����Ԫ� 0-7
						"","","","","","","","",   //�����Ԫ� 8-15
						"","","","","","","","",   //�ѹ�ͺ 16-23
						"","","","","","","","",   //�����ͺ 24-31
						"","","","","","","","",   //�ѹ���¹ 32-39
						"","","","","","","","",  //�������¹ 40-47
						"","","","","","","","",}; //max student 48-57

		private void Page_Load(object sender, System.EventArgs e)
		{
			chkNonPre=true;
			
			// Put user code to initialize the page here
			//Panel3.Visible=false;
			char dl = '\\';
			string temp=Session["login"].ToString();
			info=temp.Split(dl);
			// 0=std_id, 1=password, 2=name, 3=surname, 4=begin_study, 5=course
			//Response.Write(info[1]);
			

			DateTime dt = DateTime.Now;
			// Sets the CurrentCulture property to U.S. English.
			Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
			// Displays dt, formatted using the ShortDatePattern
			// and the CurrentThread.CurrentCulture.
			String yr=dt.ToString("y");
			char delim = ' ';
			date=yr.Split(delim);
			y=Convert.ToDecimal(date[1])+542;

			//find term
			date[1]="2/"+y.ToString();
			//Response.Write("<br><BR>"+date[1]);
			//checkPrerequit("44010567","01072130");
			

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
			this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
			this.dsreg1 = new Classrooom.control.Person.Student.Dsreg();
			((System.ComponentModel.ISupportInitialize)(this.dsreg1)).BeginInit();
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			// 
			// oleDbDataAdapter1
			// 
			this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
			this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Subject", new System.Data.Common.DataColumnMapping[] {
																																																				   new System.Data.Common.DataColumnMapping("Credit", "Credit"),
																																																				   new System.Data.Common.DataColumnMapping("Defination", "Defination"),
																																																				   new System.Data.Common.DataColumnMapping("Group_subject", "Group_subject"),
																																																				   new System.Data.Common.DataColumnMapping("NameSubject", "NameSubject"),
																																																				   new System.Data.Common.DataColumnMapping("Subject_ID", "Subject_ID"),
																																																				   new System.Data.Common.DataColumnMapping("Expr1", "Expr1"),
																																																				   new System.Data.Common.DataColumnMapping("Exam_date", "Exam_date"),
																																																				   new System.Data.Common.DataColumnMapping("Exam_time", "Exam_time"),
																																																				   new System.Data.Common.DataColumnMapping("For_class", "For_class"),
																																																				   new System.Data.Common.DataColumnMapping("For_course", "For_course"),
																																																				   new System.Data.Common.DataColumnMapping("Graduate_year", "Graduate_year"),
																																																				   new System.Data.Common.DataColumnMapping("Max_std", "Max_std"),
																																																				   new System.Data.Common.DataColumnMapping("Room", "Room"),
																																																				   new System.Data.Common.DataColumnMapping("Sec", "Sec"),
																																																				   new System.Data.Common.DataColumnMapping("Study_date", "Study_date"),
																																																				   new System.Data.Common.DataColumnMapping("Study_time", "Study_time"),
																																																				   new System.Data.Common.DataColumnMapping("Expr2", "Expr2"),
																																																				   new System.Data.Common.DataColumnMapping("Teacher_ID", "Teacher_ID")})});
			// 
			// oleDbSelectCommand1
			// 
			this.oleDbSelectCommand1.CommandText = @"SELECT Subject.Credit, Subject.Defination, Subject.Group_subject, Subject.NameSubject, Subject.Subject_ID, Opencourse.Defination AS Expr1, Opencourse.Exam_date, Opencourse.Exam_time, Opencourse.For_class, Opencourse.For_course, Opencourse.Graduate_year, Opencourse.Max_std, Opencourse.Room, Opencourse.Sec, Opencourse.Study_date, Opencourse.Study_time, Opencourse.Subject_ID AS Expr2, Opencourse.Teacher_ID FROM (Subject INNER JOIN Opencourse ON Subject.Subject_ID = Opencourse.Subject_ID)";
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			// 
			// dsreg1
			// 
			this.dsreg1.DataSetName = "Dsreg";
			this.dsreg1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dsreg1)).EndInit();

		}
		#endregion
		//	string[] s;
		
		private void Button1_Click(object sender, System.EventArgs e)
		{

			//Panel3.Visible=true;
			String[] s={S1.Text,S2.Text,S3.Text,S4.Text,S5.Text,S6.Text,S7.Text,S8.Text};
		
			bool cf=false;
			//���Ԫҫ�ӷ���͡
			int m=0;
			for(int i=0;i<=7;i++)
			{
				//Response.Write(s[i]+"<br>");
				for(int j=i+1;j<=7;j++)
					if(s[i]==s[j]&&s[i]!="")
					{
						//Response.Write("���Ԫҫ��"+ s[i]);
						m=i;
						i=8;
						j=8;
						//sn[i]="�ա�á�͡�Ԫҫ��";
						cf=true;
						FlagcheckPass=false;
					}
			}
			if(cf)
			{
				//Response.Write("���Ԫҫ�� "+s[m]);
			
				Literal1.Text="��͡�����ū��";
				FlagcheckPass=false;
			}
			else
			{
				checkopen(s);
				
			}

		}
		private void insertintotable(int i)
		{
			//OleDbConnection myConnection = new OleDbConnection(myConnectionString);
			
			String sql="INSERT INTO Register (Student_ID,Subject,yr) VALUES('"+info[0].ToString()+"','"+sn[i]+"','2/2547')";
			OleDbCommand command11 = new OleDbCommand(sql,oleDbConnection1);
			command11.Connection.Open();
			//myCommand.Connection.Open();
			command11.ExecuteNonQuery();
			//myConnection.Close();
			command11.Connection.Close();
			command11.Dispose();
			Literal1.Text = "/�س��ŧ����¹���º��������";
		}
		private void checkopen(string[] s)
		{
			String[] sec={s11.Text,s22.Text,s33.Text,s44.Text,s55.Text,s66.Text,s77.Text,s88.Text};
				
			String sql="SELECT t2.*,t3.* FROM Subject t2,Opencourse t3 WHERE (t2.Subject_ID= t3.Subject_ID AND t3.Graduate_year='"+date[1]+"')"
				+" AND("
				+"    (t2.Subject_ID='"+s[0]+"'AND t3.Sec='"+sec[0]+"')"
				+" OR (t2.Subject_ID='"+s[1]+"'AND t3.Sec='"+sec[1]+"')"
				+" OR (t2.Subject_ID='"+s[2]+"'AND t3.Sec='"+sec[2]+"')"
				+" OR (t2.Subject_ID='"+s[3]+"'AND t3.Sec='"+sec[3]+"')"
				+" OR (t2.Subject_ID='"+s[4]+"'AND t3.Sec='"+sec[4]+"')"
				+" OR (t2.Subject_ID='"+s[5]+"'AND t3.Sec='"+sec[5]+"')"
				+" OR (t2.Subject_ID='"+s[6]+"'AND t3.Sec='"+sec[6]+"')"
				+" OR (t2.Subject_ID='"+s[7]+"'AND t3.Sec='"+sec[7]+"')"
				+"     )";

			//Response.Write(sql);

			this.oleDbSelectCommand1.CommandText = sql;
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			oleDbDataAdapter1.Fill(dsreg1);
			int cr = dsreg1.Tables[0].Rows.Count;
				
			//����� �Ԫҹ���Դ����
				
			decimal[] credit={0,0,0,0,0,0,0,0};
			bool[] checkr={false,false,false,false,false,false,false,false};
			bool[] checkExdate ={false,false,false,false,false,false,false,false};
			bool[] checkStdate ={false,false,false,false,false,false,false,false};
			bool chkOp_Befo_chkre=false;

			for(int i=0;i< 8;i++)
			{
				if(s[i]=="")
					checkr[i]=true;

				for(int j=0;j<cr;j++)
				{
					Dsreg.SubjectRow r=(Dsreg.SubjectRow)dsreg1.Subject.Rows[j];
					//Dsreg.SubjectRow r=(Dsreg.SubjectRow)dsreg1.Subject.Rows[j];
					
					if( r["t2.Subject_ID"].ToString()==s[i]&& r["Sec"].ToString()==sec[i])
					{
						if(s[i]!="")
						{
							credit[i]=Convert.ToDecimal(r["Credit"].ToString());
							sn[i]=r["NameSubject"].ToString();

							//�������Ԫ�
							sn[i+8]=s[i];
							//���ѹ�ͺ �����ͺ
							sn[i+16]=r["Exam_date"].ToString();
							sn[i+24]=r["Exam_time"].ToString();
							sn[i+32]=r["Study_date"].ToString();
							sn[i+40]=r["Study_time"].ToString();
							sn[i+48]=r["Max_std"].ToString();
						}
						//check for display
						checkr[i]=true;
						j=cr;
					}
				}
				if(!(checkr[i]==true))
				{
					//Response.Write("<br> �ô��Ǩ�ͺ�Ԫ���С�����ͧ�Ԫ�  "+s[i]+" �ա����<br>");
					sn[i]="�ѧ����Դ�͹";
					chkOp_Befo_chkre=true;
					FlagcheckPass=false;
				}
			}
			
			///////////// check error
			decimal sumcredit=0;
			if(chkOp_Befo_chkre==false)
				for(int i=0;i<=7;i++)
				{
					for(int j=i+1;j<=7;j++)
						if(sn[i]!="" && sn[i+16]!="" && sn[i+32]!="")
						{
							if(sn[i+16]==sn[j+16] && sn[i+24]==sn[j+24])
								sn[i]="���ѹ��������ͺ��ӡѺ "+s[j];
						
							if(sn[i+32]==sn[j+32] && sn[i+40]==sn[j+40])
								sn[i]="���ѹ����������¹��ӡѺ "+s[j];
						}
					///////////////////////////////////////////////////////////
					if(sn[i]!="")
					{
						//Response.Write("�Ԫҷ���͡ "+s[i]);
						///////////////////////////////////check pre////////////////////////////
						checkPre(s[i],i);
						//chkNonPre=true;
					}
					sumcredit+=credit[i];
				}

			assingSN(sn,credit);

			//��Ǩ�ͺ���ŧ����¹�Ҵ�����Թ
			if(sumcredit>22)
			{
				Literal1.Text+="/�سŧ����¹�Թ 22 ˹���";
				//FlagcheckPass=false;
			}

			
			if(sumcredit<12)
			{
				Literal1.Text+="/�سŧ����¹���¡��� 12 ˹���";
				//FlagcheckPass=false;
			}

		}
		//bool sa=true;
		private string checkPre(string subject,int s_indexUpdate)
		{
			String sql="SELECT * FROM Subject t1,Requitsite t2 WHERE  t1.Subject_ID=t2.Subject_Id AND t2.Subject_Id='"
				+subject+"'";
			//Response.Write(sql);
			DataSet ds = new DataSet();
			//OleDbCommand command = new OleDbCommand(sql,oleDbConnection1);

			oleDbConnection1.Open();
			OleDbDataAdapter da = new OleDbDataAdapter(sql,oleDbConnection1);
			//da.SelectCommand = command;
			da.Fill(ds);

			da.Dispose();
			oleDbConnection1.Close();
			
			//DataGrid1.DataSource=
			int c = ds.Tables[0].Rows.Count;
			if(c==0)
			{
				ds.Dispose();
				//insertintotable(0);//////////////////////////////////////////////////////
				//Response.Write("������Ԫҡ�͹˹�� ");
				insertintotable(s_indexUpdate);
				//chkNonPre=false;
				return "";
			}

				
			for(int i=0;i<c;i++)
			{
				if(sn[i]!="")
				{
					//bool checkDerr=false;
					DataRow dr = ds.Tables[0].Rows[i];
					String s = dr["Pre_ID"].ToString();
					//checkPrerequit(s,info[0].ToString());
					//Response.Write("<BR>�ա�����Ԫҡ�͹ŧ");
					//Literal1.Text += "<BR> �Ԫҷ��سŧ���Ԫҷ���ͧ��á�͹˹��";
					
					//checkPrerequit(info[0].ToString(),s);
					// sa=true;
					if(checkPrerequit(info[0].ToString(),s))
					{
						
						insertintotable(i);////////////////////////////////////////////////
						//Response.Write("�س��ŧ����¹���º��������");
						
					}

				}
				
			}
			ds.Dispose();
			//FlagcheckPass=
			return "";

		}

		private bool checkPrerequit(String std_id,String sub_id)
		{

			String sqlP="SELECT t1.Subject FROM Register t1,Subject t2 WHERE t1.Subject=t2.NameSubject AND t2.Subject_ID='"+sub_id+"' AND t1.Student_ID='"+std_id+"'";
			//Response.Write(sqlP);

			//open the connection
			oleDbConnection1.Open();

			//create the data adapter and execute the query
			OleDbDataAdapter oDA = new OleDbDataAdapter(sqlP,oleDbConnection1); 

			//create the DataSet
			DataSet oDs = new DataSet(); 

			//Fill the dataset with the data adapter
			oDA.Fill(oDs); 
			oleDbConnection1.Close();


			//DataGrid2.DataSource=oDs;
			//DataGrid2.DataBind();
			
			//Clean Up
			oDA.Dispose(); 


			if(oDs.Tables[0].Rows.Count!=0)
			{
				//DataRow r=oDs.Tables[0].Rows[0];
				oleDbConnection1.Close();
				oDs.Dispose();
				//FlagcheckPass=true;
				//Literal1.Text += "<BR> �س��ŧ����¹���º��������/";
				return true;
				//insertintotable(int i);
			}
			else
			{
				oleDbConnection1.Close();
				//DataRow r=oDs.Tables[0].Rows[0];
				Literal1.Text += "<BR> �س��ͧŧ����¹�Ԫ� "+sub_id+"  ��͹/";
				oDs.Dispose();
				return false;
				//FlagcheckPass=false;
			}
			
		}
		private void assingSN(String[] sn,decimal[] c)
		{
			c1.Text=c[0].ToString();
			c2.Text=c[1].ToString();
			c3.Text=c[3].ToString();
			c4.Text=c[3].ToString();
			c5.Text=c[4].ToString();
			c6.Text=c[5].ToString();
			c7.Text=c[6].ToString();
			c8.Text=c[7].ToString();

			sn1.Text=sn[0];
			sn2.Text=sn[1];
			sn3.Text=sn[2];
			sn4.Text=sn[3];
			sn5.Text=sn[4];
			sn6.Text=sn[5];
			sn7.Text=sn[6];
			sn8.Text=sn[7];
		}
	}
}
