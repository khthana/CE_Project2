<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Register.ascx.cs" Inherits="Classrooom.control.Person.Student.Register" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">
		<asp:Literal id="Literal1" runat="server"></asp:Literal>
	</FONT>
</P>
<P>
	<TABLE id="Table2" cellSpacing="1" cellPadding="1" width="544" border="1" style="WIDTH: 544px; HEIGHT: 259px">
		<TR>
			<TD style="WIDTH: 97px; HEIGHT: 22px"><FONT>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����Ԫ�</FONT></TD>
			<TD style="WIDTH: 30px; HEIGHT: 22px"><FONT>�����</FONT></TD>
			<TD style="WIDTH: 72px; HEIGHT: 22px"><FONT>˹��¡Ե</FONT></TD>
			<TD style="HEIGHT: 22px"><FONT>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
					��������´</FONT></TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px; HEIGHT: 22px"><FONT face="Tahoma"><asp:textbox id="S1" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px; HEIGHT: 22px"><FONT face="Tahoma">
					<asp:textbox id="s11" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px; HEIGHT: 22px"><FONT face="Tahoma">
					<asp:Label id="c1" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp;</FONT></TD>
			<TD style="HEIGHT: 22px"><FONT face="Tahoma">
					<asp:Label id="sn1" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px; HEIGHT: 27px"><FONT face="Tahoma"><asp:textbox id="S2" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px; HEIGHT: 27px"><FONT face="Tahoma">
					<asp:textbox id="s22" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px; HEIGHT: 27px">
				<asp:Label id="c2" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
			<TD><FONT face="Tahoma">
					<asp:Label id="sn2" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px; HEIGHT: 15px"><FONT face="Tahoma"><asp:textbox id="S3" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px; HEIGHT: 15px"><FONT face="Tahoma">
					<asp:textbox id="s33" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px; HEIGHT: 15px"><FONT face="Tahoma">
					<asp:Label id="c3" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
			<TD style="HEIGHT: 15px"><FONT face="Tahoma">
					<asp:Label id="sn3" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px"><FONT face="Tahoma"><asp:textbox id="S4" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px"><FONT face="Tahoma">
					<asp:textbox id="s44" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px"><FONT face="Tahoma">
					<asp:Label id="c4" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
			<TD>
				<asp:Label id="sn4" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px; HEIGHT: 28px"><FONT face="Tahoma"><asp:textbox id="S5" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px; HEIGHT: 28px"><FONT face="Tahoma">
					<asp:textbox id="s55" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px; HEIGHT: 28px">
				<asp:Label id="c5" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
			<TD style="HEIGHT: 28px">
				<asp:Label id="sn5" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px"><FONT face="Tahoma"><asp:textbox id="S6" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px"><FONT face="Tahoma">
					<asp:textbox id="s66" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px"><FONT face="Tahoma">
					<asp:Label id="c6" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
			<TD>
				<asp:Label id="sn6" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px"><FONT face="Tahoma"><asp:textbox id="S7" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px"><FONT face="Tahoma">
					<asp:textbox id="s77" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px"><FONT face="Tahoma">
					<asp:Label id="c7" runat="server" Font-Size="XX-Small"></asp:Label>&nbsp; </FONT>
			</TD>
			<TD>
				<asp:Label id="sn7" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 97px"><FONT face="Tahoma"><asp:textbox id="S8" runat="server" Width="144px"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 30px"><FONT face="Tahoma">
					<asp:textbox id="s88" Width="36px" runat="server"></asp:textbox></FONT></TD>
			<TD style="WIDTH: 72px">
				<asp:Label id="c8" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
			<TD>
				<asp:Label id="sn8" runat="server" Font-Size="XX-Small"></asp:Label><FONT face="Tahoma">&nbsp;
				</FONT>
			</TD>
		</TR>
	</TABLE>
</P>
<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</FONT>
	<asp:button id="Button1" runat="server" Text="�ѹ�֡"></asp:button></P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P>&nbsp;</P>
