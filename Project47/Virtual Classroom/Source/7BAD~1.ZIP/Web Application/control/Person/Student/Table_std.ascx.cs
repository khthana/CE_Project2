namespace Classrooom.control.Person.Student
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.OleDb;
	using System.Text;

	/// <summary>
	///		Summary description for Table_std.
	/// </summary>
	public class Table_std : System.Web.UI.UserControl
	{
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
		protected System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
		protected Classrooom.control.Person.Student.DsGrad dsGrad1;
		protected System.Web.UI.WebControls.Literal Literal1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			char delim = '\\';
			string temp=Session["login"].ToString();
			string[] info=temp.Split(delim);
			// 0=std_id, 1=password, 2=name, 3=surname, 4=begin_study, 5=course


			// Put user code to initialize the page here
			String sql="SELECT * FROM Register t1,Subject t2 WHERE t1.Student_ID='"
				+info[0]+"'AND t1.Subject = t2.NameSubject"
				+" ORDER BY t1.yr";
			//Response.Write(sql);
		/*	DataSet ds = new DataSet();
			OleDbCommand command = new OleDbCommand(sql,oleDbConnection1);
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = command;*/

			this.oleDbSelectCommand1.CommandText = sql;
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;

			oleDbDataAdapter1.Fill(dsGrad1);
			//Response.Write(dsGrad1.Tables["Register"].Rows.Count.ToString());

			if(dsGrad1.Tables["Register"].Rows.Count!=0)
			{
				showgrad();
				
			}
			//DataGrid1.DataBind();
			//DropDownList1.DataBind();

		}

		private void showgrad()
		{
			//int i=0;
			StringBuilder str= new StringBuilder();
			DataTable yr = dsGrad1.Register.Columns["yr"].Table;
			//DsGrad.RegisterRow row = dsGrad1.Register.Rows[i];
			int count = yr.Rows.Count;

			DsGrad.RegisterRow r = (DsGrad.RegisterRow)dsGrad1.Register.Rows[0];
			str.Append("<TABLE BORDER='1' CELLPADDING='10'>");
			str.Append("<TR>  <TH> �ա���֡�� "+r["yr"].ToString()+"</TH> </TR>");
			float Gpoint_t=0;
			int point_t=0;
			float Gpoint=0;
			int point=0;
			bool end=false;

			for(int i=0;i<count;i++)
			{
				int j;
				if(i==count-1)
				{
					j=i;
					end=true;
				}
				else
					j=i+1;

				DsGrad.RegisterRow row = (DsGrad.RegisterRow)dsGrad1.Register.Rows[i];
				DsGrad.RegisterRow n_row = (DsGrad.RegisterRow)dsGrad1.Register.Rows[j];
				//Response.Write(row["yr"].ToString()+"<br>"+n_row["yr"].ToString()+"<br>");
				if(row["yr"].ToString()==n_row["yr"].ToString()&&end==false)
				{
					Gpoint_t += Grad(row["Grad"].ToString())*Convert.ToInt16(row["Credit"].ToString());
					point_t += Convert.ToInt16(row["Credit"].ToString());
					Gpoint += Grad(row["Grad"].ToString())*Convert.ToInt16(row["Credit"].ToString());
					point += Convert.ToInt16(row["Credit"].ToString());

					str.Append("<tr><td>");
					str.Append(row["Subject"].ToString()).Append("</td>");
					str.Append("<td>").Append(row["Grad"].ToString()+"<br>").Append("</td></tr>");
				}
				else
				{	
					Gpoint_t += Grad(row["Grad"].ToString())*Convert.ToInt16(row["Credit"].ToString());
					point_t += Convert.ToInt16(row["Credit"].ToString());
					Gpoint += Grad(row["Grad"].ToString())*Convert.ToInt16(row["Credit"].ToString());
					point += Convert.ToInt16(row["Credit"].ToString());

					str.Append("<tr><td>");
					str.Append(row["Subject"].ToString()).Append("</td>");
					str.Append("<td>").Append(row["Grad"].ToString()+"<br>").Append("</td></tr>");
					// �Դ�ô�����
					str.Append("<tr><td>");
					str.Append("GPS");
					str.Append("</td>");
					str.Append("<td>");
					//CalGrad();
					str.Append(Gpoint_t/point_t);
					str.Append("</td></tr>");
					Gpoint_t=0;
					point_t=0;

					if(end==true)
					{
						str.Append("<tr><td>");
						str.Append("GPA");
						str.Append("</td>");
						str.Append("<td>");
						//CalGrad();
						str.Append(Gpoint/point);
						str.Append("</td></tr>");
					}
					else
						//��鹻ա���֡������
						str.Append("<TR>  <TH> �ա���֡�� "+n_row["yr"].ToString()+"</TH> </TR>");
				}
				//Response.Write("point is "+point_t+"Gpoint is "+Gpoint+"<br>");
			}
			str.Append("</TABLE>");
			Literal1.Text=str.ToString();
		}
		private int Grad(String s)
		{
			if(s=="A")
				return 4;
			else
			if(s=="B")
				return 3;
			else
			if(s=="C")
				return 2;
			else
			if(s=="D")
				return 1;
			else
				return 0;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
			this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
			this.dsGrad1 = new Classrooom.control.Person.Student.DsGrad();
			((System.ComponentModel.ISupportInitialize)(this.dsGrad1)).BeginInit();
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Mode=Share Deny None;Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			// 
			// oleDbDataAdapter1
			// 
			this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
			this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Register", new System.Data.Common.DataColumnMapping[] {
																																																					new System.Data.Common.DataColumnMapping("Credit", "Credit"),
																																																					new System.Data.Common.DataColumnMapping("Defination", "Defination"),
																																																					new System.Data.Common.DataColumnMapping("Group_subject", "Group_subject"),
																																																					new System.Data.Common.DataColumnMapping("NameSubject", "NameSubject"),
																																																					new System.Data.Common.DataColumnMapping("Subject_ID", "Subject_ID"),
																																																					new System.Data.Common.DataColumnMapping("Grad", "Grad"),
																																																					new System.Data.Common.DataColumnMapping("Student_ID", "Student_ID"),
																																																					new System.Data.Common.DataColumnMapping("Subject", "Subject"),
																																																					new System.Data.Common.DataColumnMapping("yr", "yr")})});
			// 
			// oleDbSelectCommand1
			// 
			this.oleDbSelectCommand1.CommandText = "SELECT Subject.Credit, Subject.Defination, Subject.Group_subject, Subject.NameSub" +
				"ject, Subject.Subject_ID, Register.Grad, Register.Student_ID, Register.Subject, " +
				"Register.yr FROM (Register INNER JOIN Subject ON Register.Subject = Subject.Name" +
				"Subject)";
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			// 
			// dsGrad1
			// 
			this.dsGrad1.DataSetName = "DsGrad";
			this.dsGrad1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dsGrad1)).EndInit();

		}
		#endregion


	}
}
