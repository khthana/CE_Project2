<%@ Control Language="c#" AutoEventWireup="false" Codebehind="EditSubject.ascx.cs" Inherits="Classrooom.control.Person.Admin.EditSubject" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<asp:panel id="Panel1" Height="518px" runat="server">
		<P>��鹻շ��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
			<asp:DropDownList id="DropDownList1" runat="server">
				<asp:ListItem Selected="True" Value="1" Text="��鹻շ�� 1" />
				<asp:ListItem Value="2" Text="��鹻շ�� 2" />
				<asp:ListItem Value="3" Text="��鹻շ�� 3" />
				<asp:ListItem Value="4" Text="��鹻շ�� 4" />
			</asp:DropDownList></P>
		<P>�ա���֡��&nbsp;&nbsp;
			<asp:TextBox id="TextBox1" runat="server" MaxLength="6" Width="80px"></asp:TextBox>&nbsp;&nbsp;&nbsp;
		</P>
		<P>��ѡ�ٵ�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<asp:DropDownList id="DropDownList2" runat="server">
				<asp:ListItem Value="����" Text="4 ��" />
				<asp:ListItem Value="������ͧ" Text="3 ��" />
			</asp:DropDownList></P>
		<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<asp:Button id="BtList" runat="server" Text="�ʴ���������´"></asp:Button></P>
		<P>
			<asp:DataGrid id=DataGrid1 runat="server" Height="262px" Width="578px" DataKeyField="Graduate_year" AutoGenerateColumns="False" DataMember="Opencourse" DataSource="<%# dsOpencouse1 %>" BorderWidth="10px">
				<HeaderStyle ForeColor="Blue" BackColor="#66CC00"></HeaderStyle>
				<Columns>
					<asp:BoundColumn DataField="Graduate_year" SortExpression="Graduate_year" ReadOnly="True" HeaderText="�ա���֡��"></asp:BoundColumn>
					<asp:BoundColumn DataField="Subject_ID" SortExpression="Subject_ID" ReadOnly="True" HeaderText="�����Ԫ�"></asp:BoundColumn>
					<asp:BoundColumn DataField="Teacher_ID" SortExpression="Teacher_ID" ReadOnly="True" HeaderText="�����Ҩ����"></asp:BoundColumn>
					<asp:BoundColumn DataField="Sec" SortExpression="Sec" ReadOnly="True" HeaderText="��������"></asp:BoundColumn>
					<asp:BoundColumn DataField="For_course" SortExpression="For_course" ReadOnly="True" HeaderText="��ѡ�ٵ�"></asp:BoundColumn>
					<asp:BoundColumn DataField="For_class" SortExpression="For_class" HeaderText="��鹻�"></asp:BoundColumn>
					<asp:BoundColumn DataField="Max_std" SortExpression="Max_std" HeaderText="�ӹǹ"></asp:BoundColumn>
					<asp:BoundColumn DataField="Room" SortExpression="Room" HeaderText="��ͧ"></asp:BoundColumn>
					<asp:BoundColumn DataField="Study_date" SortExpression="Study_date" HeaderText="�ѹ���¹"></asp:BoundColumn>
					<asp:BoundColumn DataField="Study_time" SortExpression="Study_time" HeaderText="�������¹"></asp:BoundColumn>
					<asp:BoundColumn DataField="Exam_date" SortExpression="Exam_date" HeaderText="�ѹ�ͺ"></asp:BoundColumn>
					<asp:BoundColumn DataField="Exam_time" SortExpression="Exam_time" HeaderText="�����ͺ"></asp:BoundColumn>
					<asp:BoundColumn Visible="False" DataField="Defination" SortExpression="Defination" HeaderText="�����˵�"></asp:BoundColumn>
					<asp:EditCommandColumn ButtonType="LinkButton" UpdateText="��Ѻ��ا" CancelText="ź" EditText="���"></asp:EditCommandColumn>
					<asp:ButtonColumn Text="ź" CommandName="Delete"></asp:ButtonColumn>
				</Columns>
			</asp:DataGrid></P>
		<P>&nbsp;</P>
		<P>
			<asp:Label id="Label1" runat="server" Width="288px" Font-Bold="True" Font-Size="Large"></asp:Label></P>
	</asp:panel>
	<P>
</FONT><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma">&nbsp;</P>
<P>&nbsp;</P>
</FONT>
