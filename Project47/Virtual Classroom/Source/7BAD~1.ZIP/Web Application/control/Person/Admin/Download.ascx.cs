namespace Classrooom.control.Person.Admin
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.IO;
	using System.Text;

	/// <summary>
	///		Summary description for Download.
	/// </summary>
	public class Download : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label fileList;

		private void Page_Load(object sender, System.EventArgs e)
		{

			// Put user code to initialize the page here
			String root = "C:/Inetpub/wwwroot/Classrooom/FileForLoad/";
 
			String[] files = Directory.GetFiles(root);

			StringBuilder sb = new StringBuilder();

			sb.Append("<TABLE BORDER='7' CELLPADDING='10'>");
			sb.Append("<TR> <TD>����  File</TD> <TH> �ѹ���  Upload </TH> </TR>");
			
			foreach(String f in files)
			{
				String filename = Path.GetFileName(f);
				String p = root+f;
				DateTime filedate = Directory.GetCreationTime(f);
		

				sb.Append("<tr>");
				sb.Append("<td><a href=../../../Classrooom/Personal/Admin/FileDownload.aspx?file=");
				sb.Append(root).Append(Server.UrlEncode(filename));
				sb.Append(">").Append(filename+"</td>").Append("<td>"+filedate+"</td>").Append("</a>");
			}
			sb.Append("</table>");
			fileList.Text = sb.ToString();


		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
