<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Upload.ascx.cs" Inherits="Classrooom.control.Person.Admin.Upload" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<HTML>
	<HEAD>
		<title>Multiple File Upload</title>
	</HEAD>
	<BODY>
		<ASP:PANEL id="MultipleFileUploadForm" style="POSITION: relative" visible="true" runat="server"
			Height="440px" MS_POSITIONING="GridLayout" Width="501px" BorderStyle="Inset">
			<H1>File Upload Page</H1>
			<P>Select the Files to Upload to the Server:
				<BR>
				<INPUT id="File1" type="file" name="File1" runat="server"></P>
			<P><INPUT id="File2" type="file" name="File2" runat="server"></P>
			<P><INPUT id="File3" type="file" name="File2" runat="server"></P>
			<P><INPUT id="File4" type="file" name="File2" runat="server"></P>
			<P>&nbsp;
				<asp:CheckBox id="CBforApp" runat="server" Text="Upload For Application"></asp:CheckBox><INPUT id="Submit1" style="Z-INDEX: 101; LEFT: 16px; POSITION: absolute; TOP: 328px" type="submit"
					value="Upload Files" name="Submit1" runat="server">
				<asp:CheckBox id="CBforPost" style="Z-INDEX: 102; LEFT: 8px; POSITION: absolute; TOP: 288px" runat="server"
					Text="Upload For Post Document"></asp:CheckBox></P>
		</ASP:PANEL><ASP:LABEL id="ResultMsg" runat="server" ForeColor="#ff0033" Visible="False"></ASP:LABEL>
	</BODY>
</HTML>
