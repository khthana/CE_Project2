<%@ Control Language="c#" AutoEventWireup="false" Codebehind="InsertOpenCo.ascx.cs" Inherits="Classrooom.control.Person.Admin.InsertOpenCo" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma"></FONT>
<asp:Panel id="Panel1" runat="server" MS_POSITIONING="GridLayout" style="POSITION: relative"
	Height="838px" Width="534" BorderStyle="Ridge">
	<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 32px; POSITION: absolute; TOP: 24px" runat="server">�����Ԫ�</asp:Label>
	<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 32px; POSITION: absolute; TOP: 56px" runat="server">�Ҩ�������͹</asp:Label>
	<asp:Label id="Label3" style="Z-INDEX: 103; LEFT: 32px; POSITION: absolute; TOP: 96px" runat="server">�ա���֡��</asp:Label>
	<asp:Label id="Label4" style="Z-INDEX: 104; LEFT: 32px; POSITION: absolute; TOP: 136px" runat="server">��������</asp:Label>
	<asp:Label id="Label5" style="Z-INDEX: 105; LEFT: 32px; POSITION: absolute; TOP: 176px" runat="server">��ѡ�ٵ�</asp:Label>
	<asp:Label id="Label6" style="Z-INDEX: 106; LEFT: 32px; POSITION: absolute; TOP: 264px" runat="server">�ӹǹ�ѡ�֡��</asp:Label>
	<asp:Label id="Label7" style="Z-INDEX: 107; LEFT: 32px; POSITION: absolute; TOP: 304px" runat="server">����Ѻ��鹻շ��</asp:Label>
	<asp:Label id="Label8" style="Z-INDEX: 108; LEFT: 32px; POSITION: absolute; TOP: 352px" runat="server">��ͧ���¹</asp:Label>
	<asp:Label id="Label9" style="Z-INDEX: 109; LEFT: 32px; POSITION: absolute; TOP: 392px" runat="server">�ѹ���¹</asp:Label>
	<asp:Label id="Label10" style="Z-INDEX: 110; LEFT: 32px; POSITION: absolute; TOP: 440px" runat="server">�������¹</asp:Label>
	<asp:Label id="Label11" style="Z-INDEX: 111; LEFT: 32px; POSITION: absolute; TOP: 488px" runat="server">�ѹ�ͺ</asp:Label>
	<asp:Label id="Label12" style="Z-INDEX: 112; LEFT: 32px; POSITION: absolute; TOP: 536px" runat="server">�����ͺ</asp:Label>
	<asp:Label id="Label13" style="Z-INDEX: 113; LEFT: 32px; POSITION: absolute; TOP: 584px" runat="server">��������´�������</asp:Label>
	<asp:TextBox id="TextBox1" style="Z-INDEX: 114; LEFT: 200px; POSITION: absolute; TOP: 16px" runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox3" style="Z-INDEX: 115; LEFT: 200px; POSITION: absolute; TOP: 88px" runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox4" style="Z-INDEX: 116; LEFT: 200px; POSITION: absolute; TOP: 128px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox5" style="Z-INDEX: 117; LEFT: 200px; POSITION: absolute; TOP: 176px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox6" style="Z-INDEX: 118; LEFT: 200px; POSITION: absolute; TOP: 264px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox7" style="Z-INDEX: 119; LEFT: 200px; POSITION: absolute; TOP: 304px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox8" style="Z-INDEX: 120; LEFT: 200px; POSITION: absolute; TOP: 344px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox9" style="Z-INDEX: 121; LEFT: 200px; POSITION: absolute; TOP: 384px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox10" style="Z-INDEX: 122; LEFT: 200px; POSITION: absolute; TOP: 432px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox11" style="Z-INDEX: 123; LEFT: 200px; POSITION: absolute; TOP: 480px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox12" style="Z-INDEX: 124; LEFT: 200px; POSITION: absolute; TOP: 536px"
		runat="server"></asp:TextBox>
	<asp:TextBox id="TextBox13" style="Z-INDEX: 125; LEFT: 200px; POSITION: absolute; TOP: 584px"
		Width="232px" Height="102px" runat="server" TextMode="MultiLine"></asp:TextBox>
	<asp:Button id="Button1" style="Z-INDEX: 126; LEFT: 224px; POSITION: absolute; TOP: 728px" Width="104px"
		runat="server" Text="�ѹ�֡������"></asp:Button>
	<HR style="Z-INDEX: 127; LEFT: 8px; WIDTH: 91.21%; POSITION: absolute; TOP: 232px; HEIGHT: 1px"
		width="91.21%" SIZE="1">
	<asp:DropDownList id=DropDownList1 style="Z-INDEX: 128; LEFT: 200px; POSITION: absolute; TOP: 48px" Width="160px" runat="server" DataSource="<%# dsInsert1 %>" DataMember="Teacher" DataTextField="Name" DataValueField="ID">
	</asp:DropDownList>
	<asp:RequiredFieldValidator id="RequiredFieldValidator1" style="Z-INDEX: 129; LEFT: 392px; POSITION: absolute; TOP: 16px"
		runat="server" ErrorMessage="RequiredFieldValidator" ControlToValidate="TextBox1">��͡�����Ԫ�</asp:RequiredFieldValidator>
	<asp:RequiredFieldValidator id="RequiredFieldValidator2" style="Z-INDEX: 130; LEFT: 392px; POSITION: absolute; TOP: 88px"
		runat="server" ErrorMessage="RequiredFieldValidator" ControlToValidate="TextBox3">��͡�ա���֡��</asp:RequiredFieldValidator>
	<asp:RequiredFieldValidator id="RequiredFieldValidator3" style="Z-INDEX: 131; LEFT: 392px; POSITION: absolute; TOP: 128px"
		runat="server" ErrorMessage="RequiredFieldValidator" ControlToValidate="TextBox4">��͹ Section</asp:RequiredFieldValidator>
	<asp:RequiredFieldValidator id="RequiredFieldValidator4" style="Z-INDEX: 132; LEFT: 392px; POSITION: absolute; TOP: 176px"
		runat="server" ErrorMessage="RequiredFieldValidator" ControlToValidate="TextBox5">��͡��ѡ�ٵ�</asp:RequiredFieldValidator>
</asp:Panel>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
