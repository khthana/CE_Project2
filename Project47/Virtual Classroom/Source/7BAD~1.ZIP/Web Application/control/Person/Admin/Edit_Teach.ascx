<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Edit_Teach.ascx.cs" Inherits="Classrooom.control.Person.Admin.Edit_Teach" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
