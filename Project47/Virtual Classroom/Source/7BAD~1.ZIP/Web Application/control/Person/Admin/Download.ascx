<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Download.ascx.cs" Inherits="Classrooom.control.Person.Admin.Download" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<body>
	<P>
		<asp:Label id="fileList" runat="server"></asp:Label></P>
</body>
