namespace Classrooom.control.Person.Admin
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.IO;
	/// <summary>
	///		Summary description for Upload.
	/// </summary>
	public class Upload : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Panel MultipleFileUploadForm;
		protected System.Web.UI.WebControls.Label ResultMsg;
		protected System.Web.UI.HtmlControls.HtmlInputFile File1;
		protected System.Web.UI.HtmlControls.HtmlInputFile File2;
		protected System.Web.UI.HtmlControls.HtmlInputFile File3;
		protected System.Web.UI.HtmlControls.HtmlInputFile File4;
		protected System.Web.UI.WebControls.CheckBox CBforApp;
		protected System.Web.UI.WebControls.CheckBox CBforPost;
		protected System.Web.UI.HtmlControls.HtmlInputButton Submit1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Submit1.ServerClick += new System.EventHandler(this.Submit1_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Submit1_ServerClick(object sender, System.EventArgs e)
		{
			//Variable to hold the result
			String m_strResultMessage="";
			//Variable to hold the FileName
			String m_strFileName;
			//Variable FolderName where the files  will be saved
			String m_strFolderNameForApp = "C:/Inetpub/wwwroot/Classrooom/FileForApp/";
			String m_strFolderNameForLoad = "C:/Inetpub/wwwroot/Classrooom/FileForLoad/";
			//Variable to hold the File
			HttpPostedFile m_objFile;  
	
			//'Creates the folder if it does not exists
			if (!Directory.Exists(m_strFolderNameForApp))
				Directory.CreateDirectory(m_strFolderNameForApp);
			if (!Directory.Exists(m_strFolderNameForLoad))
				Directory.CreateDirectory(m_strFolderNameForLoad);

			//Remove old file before save a new file
			string[] files= Directory.GetFiles(m_strFolderNameForApp);
			foreach (string filename in files)
				File.Delete(filename);

			//'Variable used in the Loop
			int i; 
			try
			{
				//'Loop Through the Files
				for(i=0;i<=Request.Files.Count-1;i++)
				{
					//'Get the HttpPostedFile
					m_objFile = Request.Files[i];
					//Response.Write("file name is "+m_objFile.FileName+"<br>");
					//'Check that the File exists has a name and is not empty
					if (!(m_objFile == null || m_objFile.FileName == "" || m_objFile.ContentLength < 1))
					{
						//'Get the name of the file
						m_strFileName = m_objFile.FileName;
						m_strFileName = Path.GetFileName(m_strFileName);

						//   'Save each uploaded file
						if(CBforApp.Checked)
							m_objFile.SaveAs(m_strFolderNameForApp + m_strFileName);
						if(CBforPost.Checked)
							m_objFile.SaveAs(m_strFolderNameForLoad + m_strFileName);
						
						if(CBforApp.Checked||CBforPost.Checked)
						{
							//  'Assign the File Name and File Type to Result
							m_strResultMessage = m_strResultMessage + "Uploaded File: " +  m_objFile.FileName + " of type " + m_objFile.ContentType + " <br> ";

							//  'Hide the Multiple Form Upload Panel

							MultipleFileUploadForm.Visible = false;
							//Response.Write(m_strResultMessage);
						}
					}
				}

				//'If no files where selected provide a user friendly message
				//Response.Write(CBforPost.Checked+"  ");
				//Response.Write(CBforApp.Checked);
				if(m_strResultMessage == ""||!(CBforApp.Checked || CBforPost.Checked)) 
					m_strResultMessage = "Please select atleast one file or destination of file to upload.";
			}
			catch( Exception errorVariable )
			{
				//'Trap the exception
				m_strResultMessage = errorVariable.ToString();
			}

        //'Unhide the Result Label 
        ResultMsg.Visible = true;
        //'Assign the Result to ResultMsg Label Text
        ResultMsg.Text = m_strResultMessage;
		}
	}
}
