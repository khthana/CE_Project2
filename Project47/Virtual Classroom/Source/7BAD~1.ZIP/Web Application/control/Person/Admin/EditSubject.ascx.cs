namespace Classrooom.control.Person.Admin
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.OleDb;

	/// <summary>
	///		Summary description for EditSubject.
	/// </summary>
	public class EditSubject : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
		protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter2;
		protected System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
		protected System.Data.OleDb.OleDbCommand oleDbSelectCommand2;
		protected System.Data.OleDb.OleDbCommand oleDbInsertCommand1;
		protected System.Data.OleDb.OleDbCommand oleDbUpdateCommand1;
		protected System.Data.OleDb.OleDbCommand oleDbDeleteCommand1;
		protected Classrooom.control.Person.Admin.DsOpencouse dsOpencouse1;
		protected Classrooom.control.Person.Admin.DsOpencouse dsOpencouse2;
		protected System.Web.UI.WebControls.DropDownList DropDownList2;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button BtList;

		private void Page_Load(object sender, System.EventArgs e)
		{

			//Response.Write(TextBox1.Text);
			String sql="";
			//Response.Write(yr);
			if(!Page.IsPostBack)
				Page.Session["sql"]="";
			else
				sql=(String)Page.Session["sql"];

			//String sql ="SELECT * FROM Opencourse WHERE For_class = '"+Class+"' AND Graduate_year = '"+yr+"' AND For_course = '"+course+"'";
			this.oleDbSelectCommand1.CommandText = sql;
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
			this.oleDbDeleteCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbInsertCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbUpdateCommand1 = new System.Data.OleDb.OleDbCommand();
			this.dsOpencouse1 = new Classrooom.control.Person.Admin.DsOpencouse();
			((System.ComponentModel.ISupportInitialize)(this.dsOpencouse1)).BeginInit();
			this.BtList.Click += new System.EventHandler(this.BtList_Click);
			this.DataGrid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.edit);
			this.DataGrid1.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.update);
			this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.delete);
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			// 
			// oleDbDataAdapter1
			// 
			this.oleDbDataAdapter1.DeleteCommand = this.oleDbDeleteCommand1;
			this.oleDbDataAdapter1.InsertCommand = this.oleDbInsertCommand1;
			this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
			this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Opencourse", new System.Data.Common.DataColumnMapping[] {
																																																					  new System.Data.Common.DataColumnMapping("Defination", "Defination"),
																																																					  new System.Data.Common.DataColumnMapping("Exam_date", "Exam_date"),
																																																					  new System.Data.Common.DataColumnMapping("Exam_time", "Exam_time"),
																																																					  new System.Data.Common.DataColumnMapping("For_class", "For_class"),
																																																					  new System.Data.Common.DataColumnMapping("For_course", "For_course"),
																																																					  new System.Data.Common.DataColumnMapping("Graduate_year", "Graduate_year"),
																																																					  new System.Data.Common.DataColumnMapping("Max_std", "Max_std"),
																																																					  new System.Data.Common.DataColumnMapping("Room", "Room"),
																																																					  new System.Data.Common.DataColumnMapping("Sec", "Sec"),
																																																					  new System.Data.Common.DataColumnMapping("Study_date", "Study_date"),
																																																					  new System.Data.Common.DataColumnMapping("Study_time", "Study_time"),
																																																					  new System.Data.Common.DataColumnMapping("Subject_ID", "Subject_ID"),
																																																					  new System.Data.Common.DataColumnMapping("Teacher_ID", "Teacher_ID")})});
			this.oleDbDataAdapter1.UpdateCommand = this.oleDbUpdateCommand1;
			// 
			// oleDbDeleteCommand1
			// 
			this.oleDbDeleteCommand1.CommandText = @"DELETE FROM Opencourse WHERE (For_course = ?) AND (Graduate_year = ?) AND (Sec = ?) AND (Subject_ID = ?) AND (Teacher_ID = ?) AND (Exam_date = ? OR ? IS NULL AND Exam_date IS NULL) AND (Exam_time = ? OR ? IS NULL AND Exam_time IS NULL) AND (For_class = ? OR ? IS NULL AND For_class IS NULL) AND (Max_std = ? OR ? IS NULL AND Max_std IS NULL) AND (Room = ? OR ? IS NULL AND Room IS NULL) AND (Study_date = ? OR ? IS NULL AND Study_date IS NULL) AND (Study_time = ? OR ? IS NULL AND Study_time IS NULL)";
			this.oleDbDeleteCommand1.Connection = this.oleDbConnection1;
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_For_course", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "For_course", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Graduate_year", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Graduate_year", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Sec", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Sec", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Subject_ID", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Subject_ID", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Teacher_ID", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Teacher_ID", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_date", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_date", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_date1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_date", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_time", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_time", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_time1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_time", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_For_class", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "For_class", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_For_class1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "For_class", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Max_std", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Max_std", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Max_std1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Max_std", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Room", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Room", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Room1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Room", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_date", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_date", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_date1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_date", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_time", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_time", System.Data.DataRowVersion.Original, null));
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_time1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_time", System.Data.DataRowVersion.Original, null));
			// 
			// oleDbInsertCommand1
			// 
			this.oleDbInsertCommand1.CommandText = "INSERT INTO Opencourse(Defination, Exam_date, Exam_time, For_class, For_course, G" +
				"raduate_year, Max_std, Room, Sec, Study_date, Study_time, Subject_ID, Teacher_ID" +
				") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			this.oleDbInsertCommand1.Connection = this.oleDbConnection1;
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Defination", System.Data.OleDb.OleDbType.VarWChar, 0, "Defination"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Exam_date", System.Data.OleDb.OleDbType.VarWChar, 50, "Exam_date"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Exam_time", System.Data.OleDb.OleDbType.VarWChar, 50, "Exam_time"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("For_class", System.Data.OleDb.OleDbType.VarWChar, 50, "For_class"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("For_course", System.Data.OleDb.OleDbType.VarWChar, 50, "For_course"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Graduate_year", System.Data.OleDb.OleDbType.VarWChar, 50, "Graduate_year"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Max_std", System.Data.OleDb.OleDbType.VarWChar, 50, "Max_std"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Room", System.Data.OleDb.OleDbType.VarWChar, 50, "Room"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Sec", System.Data.OleDb.OleDbType.VarWChar, 50, "Sec"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Study_date", System.Data.OleDb.OleDbType.VarWChar, 50, "Study_date"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Study_time", System.Data.OleDb.OleDbType.VarWChar, 50, "Study_time"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Subject_ID", System.Data.OleDb.OleDbType.VarWChar, 50, "Subject_ID"));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Teacher_ID", System.Data.OleDb.OleDbType.VarWChar, 50, "Teacher_ID"));
			// 
			// oleDbUpdateCommand1
			// 
			this.oleDbUpdateCommand1.CommandText = @"UPDATE Opencourse SET Defination = ?, Exam_date = ?, Exam_time = ?, For_class = ?, For_course = ?, Graduate_year = ?, Max_std = ?, Room = ?, Sec = ?, Study_date = ?, Study_time = ?, Subject_ID = ?, Teacher_ID = ? WHERE (For_course = ?) AND (Graduate_year = ?) AND (Sec = ?) AND (Subject_ID = ?) AND (Teacher_ID = ?) AND (Exam_date = ? OR ? IS NULL AND Exam_date IS NULL) AND (Exam_time = ? OR ? IS NULL AND Exam_time IS NULL) AND (For_class = ? OR ? IS NULL AND For_class IS NULL) AND (Max_std = ? OR ? IS NULL AND Max_std IS NULL) AND (Room = ? OR ? IS NULL AND Room IS NULL) AND (Study_date = ? OR ? IS NULL AND Study_date IS NULL) AND (Study_time = ? OR ? IS NULL AND Study_time IS NULL)";
			this.oleDbUpdateCommand1.Connection = this.oleDbConnection1;
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Defination", System.Data.OleDb.OleDbType.VarWChar, 0, "Defination"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Exam_date", System.Data.OleDb.OleDbType.VarWChar, 50, "Exam_date"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Exam_time", System.Data.OleDb.OleDbType.VarWChar, 50, "Exam_time"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("For_class", System.Data.OleDb.OleDbType.VarWChar, 50, "For_class"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("For_course", System.Data.OleDb.OleDbType.VarWChar, 50, "For_course"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Graduate_year", System.Data.OleDb.OleDbType.VarWChar, 50, "Graduate_year"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Max_std", System.Data.OleDb.OleDbType.VarWChar, 50, "Max_std"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Room", System.Data.OleDb.OleDbType.VarWChar, 50, "Room"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Sec", System.Data.OleDb.OleDbType.VarWChar, 50, "Sec"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Study_date", System.Data.OleDb.OleDbType.VarWChar, 50, "Study_date"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Study_time", System.Data.OleDb.OleDbType.VarWChar, 50, "Study_time"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Subject_ID", System.Data.OleDb.OleDbType.VarWChar, 50, "Subject_ID"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Teacher_ID", System.Data.OleDb.OleDbType.VarWChar, 50, "Teacher_ID"));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_For_course", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "For_course", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Graduate_year", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Graduate_year", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Sec", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Sec", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Subject_ID", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Subject_ID", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Teacher_ID", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Teacher_ID", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_date", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_date", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_date1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_date", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_time", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_time", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Exam_time1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Exam_time", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_For_class", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "For_class", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_For_class1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "For_class", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Max_std", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Max_std", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Max_std1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Max_std", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Room", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Room", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Room1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Room", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_date", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_date", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_date1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_date", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_time", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_time", System.Data.DataRowVersion.Original, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Study_time1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Study_time", System.Data.DataRowVersion.Original, null));
			// 
			// dsOpencouse1
			// 
			this.dsOpencouse1.DataSetName = "DsOpencouse";
			this.dsOpencouse1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dsOpencouse1)).EndInit();

		}
		#endregion

		private void BtList_Click(object sender, System.EventArgs e)
		{
			//Response.Write("2 ");
			String Class = DropDownList1.SelectedValue;
			String yr = TextBox1.Text;
			String course= DropDownList2.SelectedValue;

			//Response.Write(Class+"   "+yr+"   "+course);

			//String course=DropDownList2.SelectedValue;
			String sql ="SELECT * FROM Opencourse WHERE For_class = '"+Class+"' AND Graduate_year = '"+yr+"' AND For_course = '"+course+"'";
			
			//use at later time
			Session["sql"]=sql;

			this.oleDbSelectCommand1.CommandText = sql;
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;

			oleDbDataAdapter1.Fill(dsOpencouse1,"Opencourse");

			if(dsOpencouse1.Opencourse.Rows.Count==0)
			{
				DataGrid1.Visible=false;
				Label1.Visible=true;
				Label1.Text="Data Not Found";
			}
			else
			{
				DataGrid1.Visible=true;
				Label1.Visible=false;
			}

			DataGrid1.DataBind();

		}

		private void delete(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			oleDbDataAdapter1.Fill(dsOpencouse1,"Opencourse");
			DataGrid1.DataBind();
				
			//DataGrid1.EditItemIndex=-1;
			//DataGrid1.SelectedIndex=e.Item.ItemIndex;
			//find primary key
			String Grad_yr=e.Item.Cells[0].Text;
			String Sub_ID = e.Item.Cells[1].Text;
			String Te_ID=e.Item.Cells[2].Text;
			String sec=e.Item.Cells[3].Text;
			String course=e.Item.Cells[4].Text;

			//use primary key to specific location of row in ds;
			DsOpencouse.OpencourseRow row = dsOpencouse1.Opencourse.FindByFor_courseGraduate_yearSecSubject_IDTeacher_ID(course,Grad_yr,sec,Sub_ID,Te_ID);	
			row.Delete();
			oleDbDataAdapter1.Update(dsOpencouse1);
		
			DataGrid1.SelectedIndex = -1;
			DataGrid1.EditItemIndex = -1;
			DataGrid1.DataSource = dsOpencouse1;
			DataGrid1.DataBind();
		}

		private void edit(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			DataGrid1.EditItemIndex=e.Item.ItemIndex;
			
			oleDbDataAdapter1.Fill(dsOpencouse1,"Opencourse");
			DataGrid1.DataBind();
		//	Response.Write(((TextBox)e.Item.Cells[8].Controls[0]).Text);
		
		}

		private void update(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			//DataGrid1.EditItemIndex=-1;
			DataGrid1.SelectedIndex=e.Item.ItemIndex;
			
			oleDbDataAdapter1.Fill(dsOpencouse1,"Opencourse");


			String Grad_yr=e.Item.Cells[0].Text;
			String Sub_ID = e.Item.Cells[1].Text;
			String Te_ID=e.Item.Cells[2].Text;
			String sec=e.Item.Cells[3].Text;
			String course=e.Item.Cells[4].Text;


			//use primary key to specific location of row in ds;
			DsOpencouse.OpencourseRow row = dsOpencouse1.Opencourse.FindByFor_courseGraduate_yearSecSubject_IDTeacher_ID(course,Grad_yr,sec,Sub_ID,Te_ID);	


			
			row["For_class"]=((TextBox)e.Item.Cells[5].Controls[0]).Text;
			row["Max_std"]=((TextBox)e.Item.Cells[6].Controls[0]).Text;
			row["Room"]=((TextBox)e.Item.Cells[7].Controls[0]).Text;
			row["Study_date"]=((TextBox)e.Item.Cells[8].Controls[0]).Text;
			row["Study_time"]=((TextBox)e.Item.Cells[9].Controls[0]).Text;
			row["Exam_date"]=((TextBox)e.Item.Cells[10].Controls[0]).Text;
			row["Exam_time"]=((TextBox)e.Item.Cells[11].Controls[0]).Text;
			row["Defination"]=((TextBox)e.Item.Cells[12].Controls[0]).Text;
			

		   oleDbDataAdapter1.Update(dsOpencouse1);

			DataGrid1.SelectedIndex = -1;
			DataGrid1.EditItemIndex = -1;
			DataGrid1.DataSource = dsOpencouse1;
			DataGrid1.DataBind();

		}

	}
}
