<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Edit_std.ascx.cs" Inherits="Classrooom.control.Person.Admin.Edit_std" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
