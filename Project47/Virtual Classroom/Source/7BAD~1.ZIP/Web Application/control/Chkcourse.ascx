<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Chkcourse.ascx.cs" Inherits="Classrooom.control.Chkcourse" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">
		<asp:Label id="Label2" runat="server" Width="240px">�շ�� 4 �Ҥ����֡�ҷ�� 1</asp:Label></FONT></P>
<P><FONT face="Tahoma">
		<TABLE id="Table1" style="WIDTH: 352px; HEIGHT: 75px" cellSpacing="1" cellPadding="1" width="352"
			align="left" border="1">
			<TR>
				<TD style="WIDTH: 13px; HEIGHT: 46px"><FONT face="Tahoma">�����Ԫ�</FONT></TD>
				<TD style="WIDTH: 219px; HEIGHT: 46px"><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
						�����Ԫ�</FONT></TD>
				<TD style="HEIGHT: 46px"><FONT face="Tahoma">˹��¡Ե</FONT></TD>
			</TR>
			<TR>
				<TD style="WIDTH: 13px; HEIGHT: 23px"><FONT face="Tahoma">01072131</FONT></TD>
				<TD style="WIDTH: 219px; HEIGHT: 23px"><FONT face="Tahoma">Project 1</FONT></TD>
				<TD style="HEIGHT: 23px"><FONT face="Tahoma">3</FONT></TD>
			</TR>
			<TR>
				<TD style="WIDTH: 13px"><FONT face="Tahoma">0107......</FONT></TD>
				<TD style="WIDTH: 219px"><FONT face="Tahoma">�Ԫ����͡�ҧ���ǡ�������������</FONT></TD>
				<TD><FONT face="Tahoma">3</FONT></TD>
			</TR>
			<TR>
				<TD style="WIDTH: 13px; HEIGHT: 23px"><FONT face="Tahoma">0107......</FONT></TD>
				<TD style="WIDTH: 219px; HEIGHT: 23px"><FONT face="Tahoma">�Ԫ����͡�ҧ���ǡ�������������</FONT></TD>
				<TD style="HEIGHT: 23px"><FONT face="Tahoma">3</FONT></TD>
			</TR>
			<TR>
				<TD style="WIDTH: 13px"><FONT face="Tahoma">0107......</FONT></TD>
				<TD style="WIDTH: 219px"><FONT face="Tahoma">�Ԫ����͡�����<FONT face="Tahoma">�Ԫ����͡�ҧ���ǡ�������������</FONT></FONT></TD>
				<TD><FONT face="Tahoma">3</FONT></TD>
			</TR>
			<TR>
				<TD style="WIDTH: 13px">01..........</TD>
				<TD style="WIDTH: 219px"><FONT face="Tahoma">�Ԫ����͡�����</FONT></TD>
				<TD>3</TD>
			</TR>
			<TR>
				<TD style="WIDTH: 13px"><FONT face="Tahoma"></FONT></TD>
				<TD style="WIDTH: 219px"><FONT face="Tahoma">���</FONT></TD>
				<TD><FONT face="Tahoma">15</FONT></TD>
			</TR>
		</TABLE>
	</FONT>
</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P>&nbsp;</P>
<FONT face="Tahoma">
	<P><FONT face="Tahoma">
			<asp:Label id="Label1" runat="server" Width="232px">�շ�� 4 �Ҥ����֡�ҷ�� 2</asp:Label></FONT>
</FONT></P>
<P><FONT face="Tahoma"> </FONT>
	<TABLE id="Table3" style="WIDTH: 352px; HEIGHT: 75px" cellSpacing="1" cellPadding="1" width="352"
		align="left" border="1">
		<TR>
			<TD style="WIDTH: 13px; HEIGHT: 46px"><FONT face="Tahoma">�����Ԫ�</FONT></TD>
			<TD style="WIDTH: 219px; HEIGHT: 46px"><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
					�����Ԫ�</FONT></TD>
			<TD style="HEIGHT: 46px"><FONT face="Tahoma">˹��¡Ե</FONT></TD>
		</TR>
		<TR>
			<TD style="WIDTH: 13px; HEIGHT: 23px"><FONT face="Tahoma">01072131</FONT></TD>
			<TD style="WIDTH: 219px; HEIGHT: 23px"><FONT face="Tahoma">Project 2</FONT></TD>
			<TD style="HEIGHT: 23px"><FONT face="Tahoma">3</FONT></TD>
		</TR>
		<TR>
			<TD style="WIDTH: 13px"><FONT face="Tahoma">0107......</FONT></TD>
			<TD style="WIDTH: 219px"><FONT face="Tahoma">�Ԫ����͡�ҧ���ǡ�������������</FONT></TD>
			<TD><FONT face="Tahoma">3</FONT></TD>
		</TR>
		<TR>
			<TD style="WIDTH: 13px; HEIGHT: 23px"><FONT face="Tahoma">0107......</FONT></TD>
			<TD style="WIDTH: 219px; HEIGHT: 23px"><FONT face="Tahoma">�Ԫ����͡�ҧ���ǡ�������������</FONT></TD>
			<TD style="HEIGHT: 23px"><FONT face="Tahoma">3</FONT></TD>
		</TR>
		<TR>
			<TD style="WIDTH: 13px"><FONT face="Tahoma">01..........</FONT></TD>
			<TD style="WIDTH: 219px"><FONT face="Tahoma">�Ԫ����͡�����</FONT></TD>
			<TD><FONT face="Tahoma">3</FONT></TD>
		</TR>
		<TR>
			<TD style="WIDTH: 13px">01..........</TD>
			<TD style="WIDTH: 219px"><FONT face="Tahoma">�Ԫ����͡�����</FONT></TD>
			<TD>3</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 13px"><FONT face="Tahoma"></FONT></TD>
			<TD style="WIDTH: 219px"><FONT face="Tahoma">���</FONT></TD>
			<TD><FONT face="Tahoma">15</FONT></TD>
		</TR>
	</TABLE>
</P>
<P><FONT face="Tahoma"> </FONT><FONT face="Tahoma"></FONT>
</P>
