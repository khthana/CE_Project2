<%@ Control Language="c#" AutoEventWireup="false" Codebehind="View_ans.ascx.cs" Inherits="Classrooom.control.Webbord.View_ans" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<P>&nbsp;</P>
	<P>&nbsp;<asp:panel id="Panel2" BorderStyle="Ridge" BorderColor="White" Font-Bold="True" BackColor="ControlLight"
			Height="74px" Width="536px" runat="server"></P>
	<P><asp:panel id="Panel1" BorderStyle="Inset" BackColor="MintCream" Height="28px" Width="584px"
			runat="server">
			<asp:Literal id="Literal1" runat="server"></asp:Literal>
		</asp:panel></P>
	<P><asp:literal id="Literal2" runat="server"></asp:literal></asp:panel></P>
	<P>
	&nbsp; </FONT>
<asp:repeater id="Repeater1" runat="server" EnableViewState="False">
	<ItemTemplate>
		<asp:Panel id="Panel3" runat="server" Width="536px" Height="39px" BackColor="#C0C0FF">
			<%# DataBinder.Eval(Container.DataItem, "ans")%>
		</asp:Panel>
		����&nbsp;<%# DataBinder.Eval(Container.DataItem, "name") %>&nbsp;&nbsp;&nbsp;email&nbsp;<%# DataBinder.Eval(Container.DataItem, "mail")%>&nbsp;&nbsp;&nbsp; 
		�ѹ���&nbsp;<%# DataBinder.Eval(Container.DataItem, "date") %>
		<br>
		<br>
	</ItemTemplate>
	<FooterTemplate>
		<br>
	</FooterTemplate>
</asp:repeater></P>
<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></P>
<P><FONT face="Tahoma"></FONT></P>
<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<asp:linkbutton id="LinkButton1" runat="server">�ͺ��з��</asp:linkbutton>&nbsp;
</P>
</FONT>
