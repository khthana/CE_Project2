<%@ Control Language="c#" AutoEventWireup="false" Codebehind="post1.ascx.cs" Inherits="Classrooom.control.Webbord.post1" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">�����˵� ��� Post � � ��سҡ�зӺ���鹰ҹ������Ҿ��</FONT></P>
<FONT face="Tahoma">
	<P>
		<asp:panel id="Panel1" style="POSITION: relative" Height="439" runat="server" Width="501px"
			BorderStyle="Outset">
			<asp:textbox id="posterTB" style="Z-INDEX: 101; LEFT: 104px; POSITION: absolute; TOP: 24px" runat="server"></asp:textbox>
			<asp:textbox id="emailTB" style="Z-INDEX: 102; LEFT: 104px; POSITION: absolute; TOP: 56px" runat="server"></asp:textbox>
			<asp:textbox id="topicTB" style="Z-INDEX: 103; LEFT: 104px; POSITION: absolute; TOP: 88px" runat="server"
				Width="152px"></asp:textbox>
			<asp:label id="Label2" style="Z-INDEX: 104; LEFT: 48px; POSITION: absolute; TOP: 24px" runat="server">����</asp:label>
			<asp:label id="Label3" style="Z-INDEX: 105; LEFT: 40px; POSITION: absolute; TOP: 56px" runat="server">email</asp:label>
			<asp:label id="Label4" style="Z-INDEX: 106; LEFT: 40px; POSITION: absolute; TOP: 88px" runat="server">��Ǣ��</asp:label></P>
	<P><asp:textbox id="desTB" style="Z-INDEX: 107; LEFT: 8px; POSITION: absolute; TOP: 144px" Width="464px"
			runat="server" Height="149px" TextMode="MultiLine"></asp:textbox></P>
	<P><asp:button id="Button1" style="Z-INDEX: 108; LEFT: 136px; POSITION: absolute; TOP: 336px" runat="server"
			Text="�����Ǣ������"></asp:button>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma">
			<asp:RequiredFieldValidator id="RequiredFieldValidator2" style="Z-INDEX: 110; LEFT: 272px; POSITION: absolute; TOP: 24px"
				runat="server" ErrorMessage="��س�������" ControlToValidate="posterTB"></asp:RequiredFieldValidator></FONT></P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma">
			<asp:RequiredFieldValidator id="RequiredFieldValidator1" style="Z-INDEX: 109; LEFT: 264px; POSITION: absolute; TOP: 88px"
				runat="server" ErrorMessage="��سҵ����Ǣ��" ControlToValidate="topicTB"></asp:RequiredFieldValidator></FONT></P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P><FONT face="Tahoma"></FONT>&nbsp;</P>
	<P>&nbsp;</P>
	</asp:panel>
	<P>&nbsp;</P>
</FONT>
