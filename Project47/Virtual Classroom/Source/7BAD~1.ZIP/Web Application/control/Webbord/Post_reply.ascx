<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Post_reply.ascx.cs" Inherits="Classrooom.control.Webbord.Post_reply" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<asp:panel id="Panel1" style="POSITION: relative" MS_POSITIONING="GridLayout" Width="400px"
		Height="345px" runat="server" BorderStyle="Outset">
		<asp:TextBox id="TextBox1" style="Z-INDEX: 101; LEFT: 32px; POSITION: absolute; TOP: 144px" runat="server"
			Height="105px" Width="267px" TextMode="MultiLine"></asp:TextBox>
		<asp:TextBox id="TextBox3" style="Z-INDEX: 102; LEFT: 88px; POSITION: absolute; TOP: 56px" runat="server"></asp:TextBox>
		<asp:TextBox id="TextBox4" style="Z-INDEX: 103; LEFT: 88px; POSITION: absolute; TOP: 16px" runat="server"></asp:TextBox>
		<asp:Label id="Label1" style="Z-INDEX: 104; LEFT: 40px; POSITION: absolute; TOP: 16px" runat="server">����</asp:Label>
		<asp:Label id="Label2" style="Z-INDEX: 105; LEFT: 32px; POSITION: absolute; TOP: 56px" runat="server">email</asp:Label>
		<asp:Button id="Button1" style="Z-INDEX: 106; LEFT: 112px; POSITION: absolute; TOP: 280px" runat="server"
			Text="�ͺ��з��"></asp:Button>
		<asp:RequiredFieldValidator id="RequiredFieldValidator1" style="Z-INDEX: 107; LEFT: 264px; POSITION: absolute; TOP: 16px"
			runat="server" ErrorMessage="��س�������" ControlToValidate="TextBox4"></asp:RequiredFieldValidator>
		<asp:RequiredFieldValidator id="RequiredFieldValidator2" style="Z-INDEX: 108; LEFT: 104px; POSITION: absolute; TOP: 104px"
			runat="server" ErrorMessage="��س�����ͤ���" ControlToValidate="TextBox1"></asp:RequiredFieldValidator>
	</asp:panel></FONT>
