<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Topic.ascx.cs" Inherits="Classrooom.control.Webbord.Topic" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<P><asp:datagrid id=DataGrid1 AutoGenerateColumns="False" DataSource="<%# dsTopic1 %>" DataKeyField="id" DataMember="topic" runat="server" BackColor="#99CCFF" ForeColor="#000033" AllowPaging="True" PageSize="20">
			<ItemStyle BackColor="White"></ItemStyle>
			<HeaderStyle ForeColor="#000033" BackColor="#00FF99"></HeaderStyle>
			<Columns>
				<asp:BoundColumn Visible="False" DataField="id" SortExpression="id" HeaderText="id"></asp:BoundColumn>
				<asp:ButtonColumn DataTextField="topic" SortExpression="topic" HeaderText="��Ǣ�͡�з��" CommandName="get_topic"></asp:ButtonColumn>
				<asp:BoundColumn DataField="poster" SortExpression="poster" HeaderText="����駡�з��"></asp:BoundColumn>
				<asp:BoundColumn DataField="date" SortExpression="date" HeaderText="�ѹ��� post"></asp:BoundColumn>
				<asp:BoundColumn DataField="reply" SortExpression="reply" HeaderText="���ͺ"></asp:BoundColumn>
				<asp:BoundColumn Visible="False" DataField="describ" SortExpression="describ" HeaderText="describ"></asp:BoundColumn>
				<asp:BoundColumn Visible="False" DataField="topic" SortExpression="topic" HeaderText="topic"></asp:BoundColumn>
			</Columns>
			<PagerStyle NextPageText=" &amp;gt;next" PrevPageText=" &amp;lt;prev" Mode="NumericPages"></PagerStyle>
		</asp:datagrid></P>
	<P>
		<asp:LinkButton id="LinkButton1" runat="server">��駡�з������</asp:LinkButton></P>
	<P>&nbsp;</P>
</FONT>
