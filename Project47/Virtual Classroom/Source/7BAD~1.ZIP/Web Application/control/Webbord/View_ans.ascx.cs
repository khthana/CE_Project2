namespace Classrooom.control.Webbord
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Data.OleDb;
//	using System.Web.UI.

	/// <summary>
	///		Summary description for View_ans.
	/// </summary>
	public abstract class View_ans : System.Web.UI.UserControl
	{
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Data.OleDb.OleDbConnection oleDbConnection2;
		protected System.Web.UI.WebControls.Repeater Repeater1;
		DataSet desDS = new DataSet();
		protected System.Web.UI.WebControls.Panel Panel2;
		protected System.Web.UI.WebControls.Literal Literal1;
		String id,topic,des;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.Literal Literal2;
		//Panel3 = new Panel();

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//avoid session time out
			if(Session.Count!=0)
			{
				this.ViewState["id"]=Session["id"].ToString();
				this.ViewState["topic"]=Session["topic"].ToString();
				this.ViewState["des"]=Session["des"].ToString();
			}

			id=this.ViewState["id"].ToString();
			topic=this.ViewState["topic"].ToString();
			des=this.ViewState["des"].ToString();
			retriveDatatoDataset();	
		}

		public void retriveDatatoDataset()
		{
			//retrive body of data
			OleDbCommand selectCMD = new OleDbCommand("SELECT * FROM des WHERE id ="+id, oleDbConnection1);
			OleDbDataAdapter desDA = new OleDbDataAdapter();
			desDA.SelectCommand = selectCMD;
			desDA.Fill(desDS, "des");
			Repeater1.DataSource=desDS;
			Repeater1.DataBind();
			desDS.Clear();
			Literal1.Text=topic;
			Literal2.Text=des;
		}
		bool  s=false;
		public bool checkSubmitForme()
		{
			return s;
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//Response.Write(topic);
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.LinkButton1.Click += new System.EventHandler(this.LinkButton1_Click);
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=C:\Inetpub\wwwroot\Classrooom\Web.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			s=true;
		}	


	}
}
