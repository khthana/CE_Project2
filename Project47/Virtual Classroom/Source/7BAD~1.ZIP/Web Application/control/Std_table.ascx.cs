namespace Classrooom.control
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Std_table.
	/// </summary>
	public class Std_table : System.Web.UI.UserControl
	{
		protected System.Data.OleDb.OleDbConnection oleDbConnection1;
		protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
		protected System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
		protected Classrooom.control.DsTable_Course dsTable_Course1;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			oleDbDataAdapter1.Fill(dsTable_Course1);
			DataGrid1.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
			this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
			this.dsTable_Course1 = new Classrooom.control.DsTable_Course();
			((System.ComponentModel.ISupportInitialize)(this.dsTable_Course1)).BeginInit();
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Data Source=""C:\Inetpub\wwwroot\Classrooom\registerDB.mdb"";Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1";
			// 
			// oleDbDataAdapter1
			// 
			this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
			this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Opencourse", new System.Data.Common.DataColumnMapping[] {
																																																					  new System.Data.Common.DataColumnMapping("Defination", "Defination"),
																																																					  new System.Data.Common.DataColumnMapping("Exam_date", "Exam_date"),
																																																					  new System.Data.Common.DataColumnMapping("Exam_time", "Exam_time"),
																																																					  new System.Data.Common.DataColumnMapping("For_class", "For_class"),
																																																					  new System.Data.Common.DataColumnMapping("For_course", "For_course"),
																																																					  new System.Data.Common.DataColumnMapping("Graduate_year", "Graduate_year"),
																																																					  new System.Data.Common.DataColumnMapping("Max_std", "Max_std"),
																																																					  new System.Data.Common.DataColumnMapping("Room", "Room"),
																																																					  new System.Data.Common.DataColumnMapping("Sec", "Sec"),
																																																					  new System.Data.Common.DataColumnMapping("Study_date", "Study_date"),
																																																					  new System.Data.Common.DataColumnMapping("Study_time", "Study_time"),
																																																					  new System.Data.Common.DataColumnMapping("Subject_ID", "Subject_ID"),
																																																					  new System.Data.Common.DataColumnMapping("Teacher_ID", "Teacher_ID"),
																																																					  new System.Data.Common.DataColumnMapping("Credit", "Credit"),
																																																					  new System.Data.Common.DataColumnMapping("Expr1", "Expr1"),
																																																					  new System.Data.Common.DataColumnMapping("Group_subject", "Group_subject"),
																																																					  new System.Data.Common.DataColumnMapping("NameSubject", "NameSubject"),
																																																					  new System.Data.Common.DataColumnMapping("Pre", "Pre"),
																																																					  new System.Data.Common.DataColumnMapping("Expr2", "Expr2")})});
			// 
			// oleDbSelectCommand1
			// 
			this.oleDbSelectCommand1.CommandText = @"SELECT Opencourse.Defination, Opencourse.Exam_date, Opencourse.Exam_time, Opencourse.For_class, Opencourse.For_course, Opencourse.Graduate_year, Opencourse.Max_std, Opencourse.Room, Opencourse.Sec, Opencourse.Study_date, Opencourse.Study_time, Opencourse.Subject_ID, Opencourse.Teacher_ID, Subject.Credit, Subject.Defination AS Expr1, Subject.Group_subject, Subject.NameSubject, Subject.Pre, Subject.Subject_ID AS Expr2 FROM (Opencourse INNER JOIN Subject ON Opencourse.Subject_ID = Subject.Subject_ID)";
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			// 
			// dsTable_Course1
			// 
			this.dsTable_Course1.DataSetName = "DsTable_Course";
			this.dsTable_Course1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dsTable_Course1)).EndInit();

		}
		#endregion
	}
}
