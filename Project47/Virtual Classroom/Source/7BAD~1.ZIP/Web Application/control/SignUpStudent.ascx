<%@ Control Language="c#" AutoEventWireup="false" Codebehind="SignUpStudent.ascx.cs" Inherits="Classrooom.control.SignUpStudent" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P>
	<asp:Panel id="Panel1" runat="server" Height="484px" MS_POSITIONING="GridLayout" style="POSITION: relative"
		Width="578" BorderStyle="Inset">
		<FONT face="Tahoma">
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 24px; POSITION: absolute; TOP: 24px" runat="server">���ʹѡ�֡��</asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 24px; POSITION: absolute; TOP: 128px" runat="server">���ʡ��</asp:Label>
			<asp:Label id="Label3" style="Z-INDEX: 103; LEFT: 24px; POSITION: absolute; TOP: 176px" runat="server">�շ������֡��</asp:Label>
			<asp:Label id="Label4" style="Z-INDEX: 104; LEFT: 24px; POSITION: absolute; TOP: 224px" runat="server">��ѡ�ٵ�</asp:Label>
			<asp:Label id="Label5" style="Z-INDEX: 105; LEFT: 24px; POSITION: absolute; TOP: 288px" runat="server">���Ѽ�ҹ</asp:Label>
			<asp:Label id="Label6" style="Z-INDEX: 106; LEFT: 24px; POSITION: absolute; TOP: 344px" runat="server">���ʼ�ҹ</asp:Label>
			<asp:Label id="Label7" style="Z-INDEX: 107; LEFT: 24px; POSITION: absolute; TOP: 72px" runat="server">����</asp:Label>
			<asp:TextBox id="TbId" style="Z-INDEX: 108; LEFT: 168px; POSITION: absolute; TOP: 24px" runat="server"></asp:TextBox></FONT>
		<asp:TextBox id="TbName" style="Z-INDEX: 109; LEFT: 168px; POSITION: absolute; TOP: 64px" runat="server"></asp:TextBox>
		<asp:TextBox id="TbSurname" style="Z-INDEX: 110; LEFT: 168px; POSITION: absolute; TOP: 120px"
			Width="152px" runat="server"></asp:TextBox>
		<asp:TextBox id="TbYear" style="Z-INDEX: 111; LEFT: 168px; POSITION: absolute; TOP: 176px" Width="152px"
			runat="server"></asp:TextBox>
		<asp:TextBox id="TbCourse" style="Z-INDEX: 112; LEFT: 168px; POSITION: absolute; TOP: 224px"
			Width="152px" runat="server"></asp:TextBox>
		<asp:TextBox id="TbPass" style="Z-INDEX: 113; LEFT: 168px; POSITION: absolute; TOP: 288px" Width="152px"
			runat="server" TextMode="Password"></asp:TextBox>
		<asp:TextBox id="RTbPass" style="Z-INDEX: 114; LEFT: 168px; POSITION: absolute; TOP: 344px" Width="152px"
			runat="server" TextMode="Password"></asp:TextBox>
		<asp:Button id="Button1" style="Z-INDEX: 115; LEFT: 200px; POSITION: absolute; TOP: 416px" Width="80px"
			runat="server" Text="��ŧ"></asp:Button>
		<asp:RequiredFieldValidator id="RequiredFieldValidator1" style="Z-INDEX: 116; LEFT: 344px; POSITION: absolute; TOP: 24px"
			runat="server" ControlToValidate="TbId" ErrorMessage="RequiredFieldValidator">��͹���ʹѡ�֡��</asp:RequiredFieldValidator>
		<asp:RequiredFieldValidator id="RequiredFieldValidator2" style="Z-INDEX: 117; LEFT: 336px; POSITION: absolute; TOP: 288px"
			runat="server" ControlToValidate="TbPass" ErrorMessage="RequiredFieldValidator">��͹���ʼ�ҹ</asp:RequiredFieldValidator>
		<asp:CompareValidator id="CompareValidator1" style="Z-INDEX: 118; LEFT: 336px; POSITION: absolute; TOP: 344px"
			runat="server" ControlToValidate="RTbPass" ErrorMessage="CompareValidator" ControlToCompare="TbPass">���ʼ�ҹ��ͧ��ҡѹ</asp:CompareValidator>
	</asp:Panel></P>
<P>
	<asp:Panel id="Panel2" Width="576px" Height="72px" runat="server">
		<P>
			<asp:Label id="response" Font-Bold="True" Width="552px" Font-Size="Large" runat="server">���Ѻ�����Ţͧ�س���º��������</asp:Label></P></P>
<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>
	<asp:Button id="Button2" runat="server" Text="��Ѻ˹����ѡ"></asp:Button></P>
<P></asp:Panel><FONT face="Tahoma" style="POSITION: relative"></FONT></P>
