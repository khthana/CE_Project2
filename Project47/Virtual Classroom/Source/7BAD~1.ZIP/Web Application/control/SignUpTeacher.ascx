<%@ Control Language="c#" AutoEventWireup="false" Codebehind="SignUpTeacher.ascx.cs" Inherits="Classrooom.control.SignUpTeacher" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P>
	<FONT face="Tahoma">
</P>
<P>
	<asp:Panel id="Panel1" runat="server" Height="363px" Width="501px" style="POSITION: relative"
		BorderStyle="Inset"></P>
<P>
	<asp:Button id="submit" runat="server" Text="�ѹ�֡������" style="Z-INDEX: 101; LEFT: 224px; POSITION: absolute; TOP: 312px"></asp:Button></P>
<P>
	<asp:Label id="Label1" runat="server" style="Z-INDEX: 102; LEFT: 32px; POSITION: absolute; TOP: 16px">���� </asp:Label>
	<asp:TextBox id="TbName" runat="server" style="Z-INDEX: 103; LEFT: 168px; POSITION: absolute; TOP: 16px"
		Width="152px"></asp:TextBox>
	<asp:Label id="Label3" runat="server" style="Z-INDEX: 104; LEFT: 24px; POSITION: absolute; TOP: 72px">���ʡ��</asp:Label>
	<asp:TextBox id="TbSurname" runat="server" style="Z-INDEX: 105; LEFT: 168px; POSITION: absolute; TOP: 72px"
		Width="152px"></asp:TextBox>
	<asp:Label id="Label4" runat="server" style="Z-INDEX: 106; LEFT: 32px; POSITION: absolute; TOP: 128px">ID</asp:Label>
	<asp:TextBox id="TbUsername" runat="server" style="Z-INDEX: 107; LEFT: 168px; POSITION: absolute; TOP: 128px"
		Width="152px"></asp:TextBox>
	<asp:Label id="Label5" runat="server" style="Z-INDEX: 110; LEFT: 32px; POSITION: absolute; TOP: 176px">Password</asp:Label>
	<asp:TextBox id="TbPassword" runat="server" style="Z-INDEX: 111; LEFT: 168px; POSITION: absolute; TOP: 176px"
		TextMode="Password" Width="152px"></asp:TextBox>
	<asp:Label id="Label6" runat="server" style="Z-INDEX: 112; LEFT: 32px; POSITION: absolute; TOP: 224px"> Password</asp:Label>
	<asp:TextBox id="TbRePassword" runat="server" style="Z-INDEX: 113; LEFT: 168px; POSITION: absolute; TOP: 224px"
		TextMode="Password" Width="152px"></asp:TextBox>
	<asp:RequiredFieldValidator id="RequiredFieldValidator1" style="Z-INDEX: 114; LEFT: 328px; POSITION: absolute; TOP: 16px"
		runat="server" ErrorMessage="��سҡ�͡����" ControlToValidate="TbName">��سҡ�͡����</asp:RequiredFieldValidator>
	<asp:RequiredFieldValidator id="RequiredFieldValidator2" style="Z-INDEX: 115; LEFT: 328px; POSITION: absolute; TOP: 72px"
		runat="server" ErrorMessage="��سҡ�͡���ʡ��" ControlToValidate="TbSurname">��سҡ�͡���ʡ��</asp:RequiredFieldValidator>
	<asp:RequiredFieldValidator id="RequiredFieldValidator3" style="Z-INDEX: 116; LEFT: 328px; POSITION: absolute; TOP: 128px"
		runat="server" ErrorMessage="��سҡ�͡ ID" ControlToValidate="TbUsername">��سҡ�͡ ID</asp:RequiredFieldValidator>
	<asp:CompareValidator id="CompareValidator2" style="Z-INDEX: 118; LEFT: 328px; POSITION: absolute; TOP: 224px"
		runat="server" ErrorMessage="��ͧ��ҡѺ��� password" ControlToValidate="TbPassword" Display="Dynamic"
		ControlToCompare="TbRePassword">��ͧ��ҡѺ��� password</asp:CompareValidator></asp:Panel>
	<FONT face="Tahoma">
</P>
<P>
	<asp:Panel id="Panel2" Width="496px" Height="57px" runat="server">
		<P>
			<asp:Label id="Label7" Width="440px" runat="server" Font-Bold="True" Font-Italic="True" Font-Size="Large">���Ѻ���������º�������Ǥ�Ѻ</asp:Label></P>
		<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<asp:LinkButton id="LinkButton1" Width="184px" runat="server">��Ѻ���˹�Ҩ���ѡ</asp:LinkButton></P>
	</asp:Panel>
<P></P>
</FONT></FONT>
