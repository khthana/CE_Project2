<%@ Control Language="c#" AutoEventWireup="false" Codebehind="Footer.ascx.cs" Inherits="Classroom.control.Template.Footer" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P>
	<FONT face="Tahoma"></FONT><FONT face="Tahoma">
		<asp:Panel id="Panel1" Height="92px" Width="742px" runat="server" MS_POSITIONING="GridLayout" style="POSITION: relative">
			<asp:Image id="Image1" style="Z-INDEX: 101; LEFT: 3px; POSITION: absolute; TOP: 9px" ImageUrl="../../images/bot1.gif" Height="46px" Width="271px" runat="server"></asp:Image>
			<asp:Image id="Image2" style="Z-INDEX: 102; LEFT: 274px; POSITION: absolute; TOP: 22px" ImageUrl="../../images/botmenu_bg.gif" Height="34px" Width="461px" runat="server"></asp:Image>
		</asp:Panel></FONT></P>
