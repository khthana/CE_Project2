<%@ Control Language="c#" AutoEventWireup="false" Codebehind="header.ascx.cs" Inherits="Classroom.control.Template.header" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<FONT face="Tahoma">
	<asp:Panel id="Panel1" Height="150px" Width="747px" runat="server" MS_POSITIONING="GridLayout" style="POSITION: relative">
		<asp:Image id="Image1" style="Z-INDEX: 101; LEFT: 4px; POSITION: absolute; TOP: 1px" ImageUrl="../../images/head20.gif" Height="93px" Width="736px" runat="server"></asp:Image>
		<asp:Image id="Image2" style="Z-INDEX: 102; LEFT: 4px; POSITION: absolute; TOP: 94px" ImageUrl="../../images/users_feedback_s.gif" runat="server"></asp:Image>
		<asp:Image id="Image3" style="Z-INDEX: 103; LEFT: 191px; POSITION: absolute; TOP: 94px" ImageUrl="../../images/topmenu_img1.gif" runat="server"></asp:Image>
		<asp:Image id="Image4" style="Z-INDEX: 104; LEFT: 219px; POSITION: absolute; TOP: 94px" ImageUrl="../../images/products_b.gif" Height="46px" Width="524px" runat="server"></asp:Image>
	</asp:Panel></FONT>
