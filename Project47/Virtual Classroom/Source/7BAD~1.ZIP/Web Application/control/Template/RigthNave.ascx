<%@ Control Language="c#" AutoEventWireup="false" Codebehind="RigthNave.ascx.cs" Inherits="Classroom.control.Template.RigthNave" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
