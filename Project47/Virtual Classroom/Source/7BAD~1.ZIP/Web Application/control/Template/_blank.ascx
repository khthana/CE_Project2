<%@ Control Language="c#" AutoEventWireup="false" Codebehind="_blank.ascx.cs" Inherits="Classrooom.control.Template.blank_foot" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
