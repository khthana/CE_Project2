<%@ Control Language="c#" AutoEventWireup="false" Codebehind="LeftNev.ascx.cs" Inherits="Classroom.control.Template.LeftNev" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P><FONT face="Tahoma">&nbsp;</P>
<P>
	<asp:ImageButton id="ImageButton4" runat="server" ImageUrl="../../images/nav342368090.gif"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton3" runat="server" ImageUrl="../../images/nav342368091.gif"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton2" runat="server" ImageUrl="../../images/nav342368092.gif"></asp:ImageButton></P>
<P>
	<asp:ImageButton id="ImageButton1" runat="server" ImageUrl="../../images/nav342368093.gif"></asp:ImageButton></P>
</FONT>
