<%@ Control Language="c#" AutoEventWireup="false" Codebehind="T_LeftNev.ascx.cs" Inherits="Classrooom.control.Template.Person.T_LeftNev" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P>
	<asp:LinkButton id="LinkButton1" runat="server">��Ǩ�ͺ�����͹</asp:LinkButton></P>
<P>
	<asp:LinkButton id="LinkButton2" runat="server">Download �͡���</asp:LinkButton></P>
<P>
	<asp:LinkButton id="LinkButton3" runat="server">Upload �͡���</asp:LinkButton></P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P><FONT face="Tahoma">
		<asp:LinkButton id="LinkButton4" runat="server">�͡�ҡ�к�</asp:LinkButton></FONT></P>
<P>&nbsp;</P>
