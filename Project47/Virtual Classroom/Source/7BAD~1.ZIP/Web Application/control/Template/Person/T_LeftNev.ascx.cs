namespace Classrooom.control.Template.Person
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for T_LeftNev.
	/// </summary>
	public class T_LeftNev : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.LinkButton LinkButton2;
		protected System.Web.UI.WebControls.LinkButton LinkButton3;
		protected System.Web.UI.WebControls.LinkButton LinkButton4;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LinkButton1.Click += new System.EventHandler(this.LinkButton1_Click);
			this.LinkButton2.Click += new System.EventHandler(this.LinkButton2_Click);
			this.LinkButton3.Click += new System.EventHandler(this.LinkButton3_Click);
			this.LinkButton4.Click += new System.EventHandler(this.LinkButton4_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion



		private void LinkButton2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Teacher/Download.aspx"));
		}

		private void LinkButton3_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Teacher/Upload.aspx"));
		}

		private void LinkButton4_Click(object sender, System.EventArgs e)
		{
			Session.Remove("login");

			Response.Redirect(ResolveUrl("../../../StartPage.aspx"));
		}

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Teacher/Table_teach.aspx"));
		}
	}
}
