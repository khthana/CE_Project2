namespace Classrooom.control.Template.Person
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for A_LeftNev.
	/// </summary>
	public class A_LeftNev : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.LinkButton LinkButton2;
		protected System.Web.UI.WebControls.LinkButton LinkButton3;
		protected System.Web.UI.WebControls.LinkButton LinkButton4;
		protected System.Web.UI.WebControls.LinkButton LinkButton6;
		protected System.Web.UI.WebControls.LinkButton LinkButton7;
		protected System.Web.UI.WebControls.LinkButton LinkButton5;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LinkButton1.Click += new System.EventHandler(this.LinkButton1_Click);
			this.LinkButton2.Click += new System.EventHandler(this.LinkButton2_Click);
			this.LinkButton3.Click += new System.EventHandler(this.LinkButton3_Click);
			this.LinkButton6.Click += new System.EventHandler(this.LinkButton6_Click);
			this.LinkButton7.Click += new System.EventHandler(this.LinkButton7_Click);
			this.LinkButton4.Click += new System.EventHandler(this.LinkButton4_Click);
			this.LinkButton5.Click += new System.EventHandler(this.LinkButton5_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Admin/Upload.aspx"));
		}

		private void LinkButton2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Admin/Download.aspx"));
		
		}

		private void LinkButton3_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Admin/EditSubject.aspx"));
		}

		private void LinkButton4_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Admin/InsertOpneCo.aspx"));
		}

		private void LinkButton5_Click(object sender, System.EventArgs e)
		{
			Session.Remove("login");
			Response.Redirect(ResolveUrl("../../../StartPage.aspx"));
		}

		private void LinkButton6_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Admin/Edit_std.aspx"));
		}

		private void LinkButton7_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(ResolveUrl("../../../Personal/Admin/Edit_teach.aspx"));
		}
	}
}
