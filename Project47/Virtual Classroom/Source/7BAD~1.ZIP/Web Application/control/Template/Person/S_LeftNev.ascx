<%@ Control Language="c#" AutoEventWireup="false" Codebehind="S_LeftNev.ascx.cs" Inherits="Classrooom.control.Template.Person.S_LeftNev" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<P>
	<asp:LinkButton id="LinkButton1" runat="server">Download  �͡���</asp:LinkButton></P>
<P>
	<asp:LinkButton id="LinkButton2" runat="server">��Ǩ�ͺ�������¹</asp:LinkButton></P>
<P>
	<asp:LinkButton id="LinkButton3" runat="server">��Ǩ�ͺ�ô</asp:LinkButton></P>
<P>
	<asp:LinkButton id="LinkButton4" runat="server">ŧ����¹</asp:LinkButton></P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P>
	<asp:LinkButton id="LinkButton5" runat="server">�͡�ҡ�к�</asp:LinkButton></P>
<P><FONT face="Tahoma"></FONT>&nbsp;</P>
<P>&nbsp;</P>
