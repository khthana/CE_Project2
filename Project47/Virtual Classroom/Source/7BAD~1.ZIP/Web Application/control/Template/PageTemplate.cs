using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Classroom
{
	public class PageTemplate : Page
	{
		//this object acts the same as the <form runat="server"> tag
		//when it is added to the Page's Controls collection
		private HtmlForm mainForm;

		//define the page region place holders
		private PlaceHolder _title;
		private PlaceHolder _header;
		private NavSection _leftNav;
		private PlaceHolder _body;
		private NavSection _rightNav;
		private PlaceHolder _footer;

		private int _width = 760;

		public PageTemplate()
		{
			//initialize the web form
			mainForm = new HtmlForm();

			//create new instance of each page region's PlaceHolder object
			_title = new PlaceHolder();
			_header = new PlaceHolder();
			_leftNav = new NavSection();
			_body = new PlaceHolder();
			_rightNav = new NavSection();
			_footer = new PlaceHolder();
		}

		public int Width
		{
			get{return _width;}
			set{_width = value;}
		}

		public string Title
		{
			get
			{
				//the get attribute is necessary to get our template to
				//play nice with Visual Studio .NET. It is not used
				//in the implementation
				return "";
			}
			set
			{
				//only allow one title to be added at a time
				_title.Controls.Clear();
				_title.Controls.Add(new LiteralControl(value));
			}
		}

		public PlaceHolder Header
		{
			get {return _header;}
			set {_header = value;}
		}

		public NavSection LeftNav
		{
			get {return _leftNav;}
			set {_leftNav = value;}
		}

		public PlaceHolder Body
		{
			get {return _body;}
			set {_body = value;}
		}

		public NavSection RightNav
		{
			get {return _rightNav;}
			set {_rightNav = value;}
		}

		public PlaceHolder Footer
		{
			get {return _footer;}
			set {_footer = value;}
		}

		override protected void OnInit(EventArgs e)
		{
			this.Load += new EventHandler(built_page);
			//object sender;
			//this.built_page(sender, e);

			//add the base header essentials
			AddStaticText(
				"<html>\n" +
				"<head>\n" +
				"<title>");
			Controls.Add(_title);
			AddStaticText(
				"</title>\n" +
				"</head>\n" +
				"<body>\n");

			//add the Web Form to the page
			Controls.Add(mainForm);

			//add the base footer essentials
			AddStaticText(
				"</body>\n" +
				"</html>");
		}

		private void AddStaticText(string output)
		{
			Controls.Add(new LiteralControl(output));
		}

		private void built_page(Object sender, EventArgs e)
		{
			int colSpan = 1;
			int bodyWidth = Width;

			//determine how many columns that the header and footer have to span, as well as
			//the width for the body section of the template
			if(LeftNav.Controls.Count > 0)
			{
				colSpan += 1;
				bodyWidth -= LeftNav.Width;
			}

			if(RightNav.Controls.Count > 0)
			{
				colSpan += 1;
				bodyWidth -= RightNav.Width;
			}

			//construct the Web Form and add the page region PlaceHolder and NavSection objects

			//begin main body framework
			mainForm.Controls.Add(new LiteralControl(
				"<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"" + Width.ToString() + "\">\n"));


			mainForm.Controls.Add(new LiteralControl(
				"\t<tr>\n" +
				"\t\t<td colspan=\"" + colSpan.ToString() + "\" valign=\"top\">\n"));

			//add a default header if one was not specified
			if(0==Header.Controls.Count)
			{
				mainForm.Controls.Add(LoadControl("uc_header.ascx"));
			}
			mainForm.Controls.Add(Header);
			
			mainForm.Controls.Add(new LiteralControl(
				"\n\t\t</td>\n" +
				"\t</tr>\n"));
			
			mainForm.Controls.Add(new LiteralControl("\t<tr>\n"));

			//add the left nav PlaceHolder if it was specified by the page
			if(LeftNav.Controls.Count > 0)
			{
				mainForm.Controls.Add(new LiteralControl(
					"\t\t<td valign=\"top\" width=\"" + LeftNav.Width.ToString() + "\">\n"));
				mainForm.Controls.Add(LeftNav);
				mainForm.Controls.Add(new LiteralControl("\n\t\t</td>\n"));
			}
			
			//add the body PlaceHolder if it was specified by the page, else throw an exception
			if(Body.Controls.Count > 0)
			{
				mainForm.Controls.Add(new LiteralControl("\t\t<td valign=\"top\">\n" + 
					"\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"4\" width=\"" + bodyWidth.ToString() + "\">\n" + 
					"\t\t\t\t<tr>\n" +
					"\t\t\t\t\t<td>\n"));
				mainForm.Controls.Add(Body);
				mainForm.Controls.Add(new LiteralControl(
					"\n\t\t\t\t\t</td>\n" +
					"\t\t\t\t</tr>\n" +
					"\t\t\t</table>\n" +
					"\t\t</td>\n"));
			}
			else
			{
				throw new Exception("You must specify content for the Body property of each page that implements the PageTemplate class.");
			}

			//add the right nav PlaceHolder if it was specified by the page
			if(RightNav.Controls.Count > 0)
			{
				mainForm.Controls.Add(new LiteralControl("\t\t<td valign=\"top\" width=\"" + RightNav.Width.ToString() + "\">\n"));
				mainForm.Controls.Add(RightNav);
				mainForm.Controls.Add(new LiteralControl("\n\t\t</td>\n"));
			}

			mainForm.Controls.Add(new LiteralControl("\t</tr>\n"));

			//add the footer PlaceHolder if it was specified by the page, else use the default
			mainForm.Controls.Add(new LiteralControl(
				"\t<tr>\n" +
				"\t\t<td colspan=\"" + colSpan.ToString() + "\" valign=\"top\">\n"));
			if(Footer.Controls.Count > 0)
			{
				mainForm.Controls.Add(Footer);
			}
			else
			{
				mainForm.Controls.Add(LoadControl("_blank.ascx"));
			}
			mainForm.Controls.Add(new LiteralControl(
				"\n\t\t</td>\n" +
				"\t</tr>\n" + 
				"</table>\n"));
		}

	}
/// <summary>
/// /////////////////////////////////////////////////////
/// </summary>
	public class NavSection : PlaceHolder
	{
		private int _width = 125;

		public int Width
		{
			get{return _width;}
			set{_width = value;}
		}
	}
}