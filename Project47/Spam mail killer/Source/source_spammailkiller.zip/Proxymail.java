 
import java.io.*;
import java.net.*;
 
class Proxymail extends Thread {
	
	private ServerSocket ss = null;
	private Socket socket_client = null;
	private Socket socket_server = null;
	
	private ClientToServer cts = null;
	private ServerToClient stc = null;
	
 	Proxymail(String proxy) {
		super(proxy);
	}
	
 	public void run() {
		try {
			while (true) {
			
    		ss = new ServerSocket(Integer.parseInt(Config.prop.getProperty("proxy port")));
			System.out.println("Proxy Created");
			MainFrame.updateProxyStatus("Status:   wait for connection");
			socket_client = ss.accept();
			System.out.println("Proxy Accepted");
			MainFrame.updateProxyStatus("Status:   running");
		
        	System.out.println("Connect to host");
        	socket_server = new Socket(Config.prop.getProperty("host"),
        						Integer.parseInt(Config.prop.getProperty("port")));
        	System.out.println("Connection completed");
		
 			cts = new ClientToServer("cts",
 									 socket_client.getInputStream(),
 									 socket_server.getOutputStream());
			stc = new ServerToClient("stc",
									 socket_server.getInputStream(),
									 socket_client.getOutputStream());
   			cts.start();
			stc.start();
			
 			cts.join();
			stc.join();
 			
 			socket_client.close();
			socket_server.close();
			System.out.println("Proxy End");
			MainFrame.updateProxyStatus("Status:   finish");
			}
   		}
 		catch (IOException ioex) {}
 		catch (InterruptedException irex) {}
  	}
	
}