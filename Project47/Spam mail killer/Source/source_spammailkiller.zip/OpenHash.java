
import java.util.*;
import java.io.*;

class OpenHash {

static public Hashtable Hashg = new Hashtable();
static public Hashtable Hashb = new Hashtable();
static public Hashtable Hashprob = new Hashtable();

static private File opengood = new File("good.txt");
static private File openbad = new File("bad.txt");
static private File openprob = new File("Hashprob.txt");

static public void Opengood() {
	try {
    	if (!opengood.exists()) {
    		opengood.createNewFile();
    		FileOutputStream fo = new FileOutputStream("good.txt");
    		ObjectOutputStream ob = new ObjectOutputStream(fo);
       		ob.writeObject(Hashg);
       		ob.close();
       		fo.close();
       	}
       	else { 
       		FileInputStream fi = new FileInputStream("good.txt");
       		ObjectInputStream ib = new ObjectInputStream(fi);
       		Object object = ib.readObject();
       		Hashg = (Hashtable) object;
       		ib.close();
       		fi.close();
       	}
	} catch (Exception e) {}
}

static public void Openbad() {
	try{
		if (!openbad.exists()) {
			openbad.createNewFile();
			FileOutputStream fo = new FileOutputStream("bad.txt");
       	    ObjectOutputStream ob = new ObjectOutputStream(fo);
       	    ob.writeObject(Hashb);
            ob.close();
            fo.close();
       }
       else{
       		FileInputStream fi = new FileInputStream("bad.txt");
       		ObjectInputStream ib = new ObjectInputStream(fi);
       		Object object = ib.readObject();
       		Hashb = (Hashtable)object;
       		ib.close();
       		fi.close();
       }
    }catch (Exception e) {}

 }
 
static public void Closegood(){
 	   try{
      
       FileOutputStream fo = new FileOutputStream("good.txt");
       ObjectOutputStream ob = new ObjectOutputStream(fo);
       ob.writeObject(Hashg);
       ob.close();
       fo.close();
       }catch (Exception e){}
}
 
static public void Closebad(){
 	try{ 
       FileOutputStream fo = new FileOutputStream("bad.txt");
       ObjectOutputStream ob = new ObjectOutputStream(fo);
       ob.writeObject(Hashb);
       ob.close();
       fo.close(); 
      }catch(Exception e){}
}
 
static public void OpenProb(){
 try{
        if (!openprob.exists()){
       	openprob.createNewFile();
       	FileOutputStream fo = new FileOutputStream("Hashprob.txt");
       	ObjectOutputStream ob = new ObjectOutputStream(fo);
       	ob.writeObject(Hashprob);
        ob.close();
        fo.close();
       }
       
       else{
       FileInputStream fi = new FileInputStream("Hashprob.txt");
       ObjectInputStream ib = new ObjectInputStream(fi);
       Object object = ib.readObject();
       Hashprob = (Hashtable)object;
       ib.close();
       fi.close();
       }
       }catch (Exception e){}	
}
 
static public void Closeprob(){
 	try{ 
       FileOutputStream fo = new FileOutputStream("Hashprob.txt");
       ObjectOutputStream ob = new ObjectOutputStream(fo);
       ob.writeObject(Hashprob);
       ob.close();
       fo.close(); 
      }catch(Exception e){}
}    	

}