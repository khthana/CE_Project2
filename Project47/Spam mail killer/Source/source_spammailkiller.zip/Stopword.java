
import java.io.*;
import java.util.*;

class Stopword {
	
	private static File stopwordFile = new File("stopword.txt");
	
	public static Vector stopword;
	
	public static void Load() {
		if (!stopwordFile.exists()) {
			stopword = new Vector();
			stopword.addElement("gone");
			stopword.addElement("smtp");
			stopword.addElement("status");
			stopword.addElement("plaintext");
			stopword.addElement("applet");
			stopword.addElement("edu");
			stopword.addElement("oct");
			stopword.addElement("it's");
			stopword.addElement("embed");
			stopword.addElement("helvetica");
			stopword.addElement("param");
			stopword.addElement("map");
			stopword.addElement("cdt");
			stopword.addElement("tue");
			stopword.addElement("height");
			stopword.addElement("you");
			stopword.addElement("strike");
			stopword.addElement("our");
			stopword.addElement("del");
			stopword.addElement("going");
			stopword.addElement("received");
			stopword.addElement("esmtp");
			stopword.addElement("ltd");
			stopword.addElement("width");
			stopword.addElement("not");
			stopword.addElement("person");
			stopword.addElement("nov");
			stopword.addElement("thead");
			stopword.addElement("head");
			stopword.addElement("marquee");
			stopword.addElement("she");
			stopword.addElement("message");
			stopword.addElement("pdt");
 			stopword.addElement("fri");
			stopword.addElement("are");
			stopword.addElement("return");
			stopword.addElement("yet");
			stopword.addElement("his");
			stopword.addElement("from");
			stopword.addElement("blink");
			stopword.addElement("samp");
			stopword.addElement("kbd");
			stopword.addElement("mail");
			stopword.addElement("note");
			stopword.addElement("sub");
			stopword.addElement("has");
			stopword.addElement("frame");
			stopword.addElement("spot");
			stopword.addElement("jul");
			stopword.addElement("may");
			stopword.addElement("alt");
			stopword.addElement("cite");
			stopword.addElement("center");
			stopword.addElement("nbsp");
			stopword.addElement("subject");
			stopword.addElement("dir");
			stopword.addElement("address");
			stopword.addElement("the");
			stopword.addElement("basefont");
			stopword.addElement("doing");
			stopword.addElement("caption");
			stopword.addElement("being");
			stopword.addElement("frameset");
			stopword.addElement("xmp");
			stopword.addElement("form");
			stopword.addElement("mailto");
			stopword.addElement("date");
			stopword.addElement("went");
 			stopword.addElement("big");
			stopword.addElement("sup");
			stopword.addElement("jun");
			stopword.addElement("path");
			stopword.addElement("listing");
			stopword.addElement("align");
 			stopword.addElement("will");
			stopword.addElement("link");
			stopword.addElement("serif");
			stopword.addElement("var");
			stopword.addElement("cellspacing");
			stopword.addElement("could");
			stopword.addElement("isindex");
			stopword.addElement("goes");
			stopword.addElement("input");
			stopword.addElement("and");
			stopword.addElement("inc");
			stopword.addElement("script");
			stopword.addElement("pre");
			stopword.addElement("that");
			stopword.addElement("meta");
			stopword.addElement("anotherbigword");
			stopword.addElement("title");
			stopword.addElement("nobr");
			stopword.addElement("sat");
			stopword.addElement("select");
			stopword.addElement("span");
			stopword.addElement("dfn");
			stopword.addElement("encoding");
			stopword.addElement("mon");
			stopword.addElement("blockquote");
			stopword.addElement("gmt");
			stopword.addElement("strong");
			stopword.addElement("est");
			stopword.addElement("jan");
			stopword.addElement("for");
			stopword.addElement("cgi");
			stopword.addElement("did");
			stopword.addElement("apr");
			stopword.addElement("been");
			stopword.addElement("have");
			stopword.addElement("base");
			stopword.addElement("math");
			stopword.addElement("had");
			stopword.addElement("bgcolor");
			stopword.addElement("fig");
			stopword.addElement("any");
			stopword.addElement("author");
			stopword.addElement("having");
			stopword.addElement("feb");
			stopword.addElement("dec");
 			stopword.addElement("sep");
			stopword.addElement("this");
			stopword.addElement("valign");
			stopword.addElement("off");
			stopword.addElement("with");
			stopword.addElement("thu");
			stopword.addElement("net");
			stopword.addElement("range");
			stopword.addElement("would");
			stopword.addElement("can");
			stopword.addElement("color");
			stopword.addElement("but");
			stopword.addElement("font");
			stopword.addElement("was");
			stopword.addElement("menu");
			stopword.addElement("abbrev");
			stopword.addElement("table");
			stopword.addElement("sun");
			stopword.addElement("tbody");
			stopword.addElement("ask");
			stopword.addElement("https");
			stopword.addElement("wed");
			stopword.addElement("tfoot");
			stopword.addElement("localhost");
			stopword.addElement("charset");
			stopword.addElement("lang");
			stopword.addElement("body");
			stopword.addElement("wbr");
			stopword.addElement("textarea");
			stopword.addElement("http");
			stopword.addElement("col");
			stopword.addElement("spacer");
			stopword.addElement("iframe");
			stopword.addElement("img");
			stopword.addElement("acronym");
			stopword.addElement("src");
			stopword.addElement("helo");
			stopword.addElement("him");
			stopword.addElement("colgroup");
			stopword.addElement("div");
			stopword.addElement("done");
			stopword.addElement("advanced");
			stopword.addElement("out");
			stopword.addElement("pst");
			stopword.addElement("aug");
			stopword.addElement("your");
			stopword.addElement("small");
			stopword.addElement("tab");
			stopword.addElement("yes");
			stopword.addElement("noframes");
			stopword.addElement("its");
			stopword.addElement("mar");
			stopword.addElement("ins");
			stopword.addElement("multicol");
			stopword.addElement("etc");
			stopword.addElement("also");
			stopword.addElement("code");
			stopword.addElement("does");
			stopword.addElement("area");
			stopword.addElement("banner");
			stopword.addElement("her");
			stopword.addElement("were");
			stopword.addElement("all");
			stopword.addElement("edt");
			stopword.addElement("cst");
			stopword.addElement("textflow");
			stopword.addElement("overlay");
			stopword.addElement("bgsound");
			stopword.addElement("sans");
			stopword.addElement("border");
			stopword.addElement("mbox");
 			stopword.addElement("from");
			stopword.addElement("to");
			stopword.addElement("subject");
			stopword.addElement("for");
			stopword.addElement("by");
			stopword.addElement("with");
			stopword.addElement("head");
			stopword.addElement("meta");
			stopword.addElement("body");
 			stopword.addElement("table");
			stopword.addElement("head");
			stopword.addElement("tr");
			stopword.addElement("td");
			stopword.addElement("font");
			stopword.addElement("br");
			stopword.addElement("center");
			stopword.addElement("p");
			stopword.addElement("u");
			stopword.addElement("i");
			stopword.addElement("b");
			stopword.addElement("a");
			stopword.addElement("-");
			stopword.addElement("|");
			stopword.addElement("x-mailer");
			stopword.addElement("x-priority");
			stopword.addElement("return-path");
			stopword.addElement("massage-id");
			stopword.addElement("multipart");
			stopword.addElement("mixed");
			stopword.addElement("x-msmail-priority");
			stopword.addElement("reply-to");
			stopword.addElement("content-type");
			stopword.addElement("delivered-to");
			stopword.addElement("content-transfer-encoding");
			stopword.addElement("mime-version");
			stopword.addElement("x-apparently-to");
			stopword.addElement("authentication-results");
			stopword.addElement("x-originating-ip");
			stopword.addElement("received");
			stopword.addElement("content-length");
			stopword.addElement("date");
			try {
				FileOutputStream fo = new FileOutputStream(stopwordFile);
				ObjectOutputStream obo = new ObjectOutputStream(fo);
				obo.writeObject(stopword);
				obo.close();
				fo.close();
			} 
			catch (IOException ioex) {}
 		}
 		else {
 			try {
 				FileInputStream fi = new FileInputStream(stopwordFile);
 				ObjectInputStream obi = new ObjectInputStream(fi);
 				stopword = (Vector) obi.readObject();
 				obi.close();
 				fi.close();
 			} 
 			catch (IOException ioex) {}
 			catch (ClassNotFoundException classex){}
 		}
	}

}







  