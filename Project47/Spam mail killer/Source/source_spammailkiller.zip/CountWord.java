import java.util.*;
import java.io.*;
class CountWord {
      
      //public Vector countword = new Vector();
   public Vector CountString(Vector store){
     int count;
     Vector countword = new Vector(); 
      try{
            
            for( int k=0;k<store.size();k++){  
               count = 1;
               for(int g=k+1;g<store.size();g++){
                  if(store.elementAt(k).equals(store.elementAt(g))){
                	 count++;
                     store.remove(g);
                     g=g-1;
                      }
                  }
                     countword.insertElementAt(new Integer(count),k);
              }
          } catch (Exception e){}
           
           return countword;  
      }
}

 
