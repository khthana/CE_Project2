import java.io.*;
import java.util.*;

class CountProbWord {
  
   //******number of massage**********
    private double prob,ngood,nbad,good,bad;
    private Vector word,probvalue = new Vector();
    private Object j;
   
     
   public void CountProb(){
        
        this.ngood = Double.parseDouble(Config.prop.getProperty("Good"));//Good more than1
        this.nbad = Double.parseDouble(Config.prop.getProperty("Bad"));
        Enumeration e1 = OpenHash.Hashg.keys();
        Enumeration e2 = OpenHash.Hashb.keys();
          CalProb(e1);
          CalProb(e2);
       
              

}

    public void CalProb(Enumeration e1){
  	double first,second,third,fouth ; 
        while(e1.hasMoreElements()!=false){
            j = e1.nextElement().toString();
       	    
     if( ((OpenHash.Hashg.containsKey(j)) == true) & ((OpenHash.Hashb.containsKey(j)) == true) ){  
       	      good = Double.parseDouble(OpenHash.Hashg.get(j).toString()) * 2.00;
       	      bad  = Double.parseDouble(OpenHash.Hashb.get(j).toString());
       	     
       	   }
       	   
    else if(((OpenHash.Hashg.containsKey(j)) == true) & ((OpenHash.Hashb.containsKey(j)) == false)){
       	   	  good = Double.parseDouble(OpenHash.Hashg.get(j).toString()) * 2.00;
       	   	  bad  = 0.00;
       	   }
       	   
    else if(((OpenHash.Hashg.containsKey(j)) == false) & ((OpenHash.Hashb.containsKey(j)) == true)){
       	       bad =  Double.parseDouble(OpenHash.Hashb.get(j).toString());
       	       good = 0.00;
       	   }
       	 
    else if(((OpenHash.Hashg.containsKey(j)) == false) & ((OpenHash.Hashb.containsKey(j)) == false)){
       	       bad =  0.00;
       	       good = 0.00;
       	   }
     	 
     //*******Concentrate good+bad>5*************//
      	 
       	   if((good+bad)>5.00){
     	   	 //********bad/nbad >1 *********** 
       	   	  if ((bad/nbad) >= 1.00 ){
       	   	         first = 1.00;
       	   	     if ((good/ngood) > 1.00)
       	   	         prob = 0.50;
       	   	     else{
       	   	         second = (good/ngood)+first;
       	   	         third = first/second;
       	   	        if(third > 0.99)
       	   	            prob = 0.99;
       	   	        else{
       	   	         if (third>0.01)
       	   	           prob = third;
       	   	         else 
       	   	           prob = 0.01;
       	   	      }
       	   	      }     
       	   	  }
       	   	  
       	   	  
       	   //********bad/nbad <1 ************	  
       	   	   else{
       	   	  
       	   	     first = (bad/nbad);
       	   	       if ((good/ngood) > 1.00){
       	   	          second = 1.00+first;
       	   	          third  = first/second;
       	   	          if (third>0.99)
       	   	             prob = 0.99;
       	   	          else{
       	   	             if(third > 0.01)
       	   	               prob = third;
       	   	             else
       	   	               prob = 0.01;	
       	   	            }
       	   	         }
       	   	       else{
       	   	       	  second = (good/ngood)+first;
       	   	       	  third = first/second;
       	   	       	  if (third>0.99)
       	   	       	     prob = 0.99;
       	   	       	  else{
       	   	       	  	 if(third >0.01)
       	   	       	  	  prob = third;
       	   	       	  	  else
       	   	       	  	   prob = 0.01;
       	   	       	  }
       	   	       }        
       	   	  }//else      
       	    }//if 
           
           else {prob = 0.00;}//good+bad<5
         
         OpenHash.Hashprob.put(j,new Double(prob));     
       }//while
       OpenHash.Closeprob();
  }
}