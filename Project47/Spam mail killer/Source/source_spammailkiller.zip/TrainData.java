
import java.util.*;
import java.io.*;

class TrainData extends Thread {
	
	private Vector mail,receivetoken,count;
	private Vector token = new Vector();
	private int rowselect;
	private int countamount;
    private String value;
    private String type = new String();
   
    TrainData(){};
    TrainData(int rowselect,String type) {
    try{	
    	MainFrame.updateStatus("                      Status:   Training");
	 
	 	FileInputStream fi = new FileInputStream(
						"./"+ManageMessage.dirMessage.getName()+"/"+ManageMessage.filename.get(rowselect));
		ObjectInputStream obis = new ObjectInputStream(fi);
		mail = (Vector) obis.readObject();
		obis.close();
		fi.close();
		this.type = type;
        this.rowselect = rowselect;
    }
    catch(IOException ioex){}
    catch(ClassNotFoundException cnfex){}
    }
    
    public void run() {
     
       
          for(int i=1;i<mail.size();i++){
     	   StringTokenizer st = new StringTokenizer(mail.get(i).toString());
            while (st.hasMoreTokens()){token.addElement(st.nextToken());} 
           }
        
        
        if (mail.get(0).equals("Spam")){
       	  try{
       	  new Reclassified(token,mail);
      	  //System.out.println("This method");
      	  this.CalculateData();
      	  }catch (NullPointerException Nullex){}
      	  }
        else if(mail.get(0).equals("Not Spam")){
          try{
          new Reclassified(token,mail);
          this.CalculateData();
          }catch(NullPointerException Nullex){}
          }
        else 
      	  this.CalculateData();
       Enumeration e1 = OpenHash.Hashprob.keys();
       while (e1.hasMoreElements()){
       	  Object next = e1.nextElement();
       	  if (Double.parseDouble(OpenHash.Hashprob.get(next).toString()) == 0.0){
       	  	OpenHash.Hashprob.remove(next);
       	  }
       }
          OpenHash.Closeprob();     
         // Printtext.printgood();
         // Printtext.printbad();
         // Printtext.printtotalprob();
     }
   public void CalculateData(){
  	 //String value;
  	 try{
      	 TextTokenizer text= new TextTokenizer();
      	 receivetoken = text.CutString(token);
      }catch(Exception e){}  
    // System.out.println("receiveold"+" == "+receivetoken.size());
     CountWord str = new CountWord();
     count = str.CountString(receivetoken);
    // System.out.println("receive"+"=="+receivetoken.size()+"count"+" = "+count.size());
     //Set Properties and Store In good Hashtable
     
     if(type.equals("Not Spam")){
     countamount = Integer.parseInt(Config.prop.getProperty("Good"));
     countamount++;
     value = value.valueOf(countamount);
     Config.prop.setProperty("Good",value);
     Config.Save();
     StoreHash.storegood(receivetoken,count);//Old method
      }
     
     else if(type.equals("Spam")){
     //System.out.println("2");
     countamount = Integer.parseInt(Config.prop.getProperty("Bad"));
     countamount++;
     value = value.valueOf(countamount);
     Config.prop.setProperty("Bad",value);
     Config.Save();
     StoreHash.storebad(receivetoken,count);
     }
     
     if ( (Integer.parseInt(Config.prop.getProperty("Good")) >0) && (Integer.parseInt(Config.prop.getProperty("Bad")))>0)
     {
      CountProbWord prob = new CountProbWord();
      prob.CountProb();
     }
     //FileOutputStream
      
     
     
    mail.removeElementAt(0);
     mail.add(0,type);
   try{	 
	 FileOutputStream fo = new FileOutputStream(
						"./"+ManageMessage.dirMessage.getName()+"/"+ManageMessage.filename.get(rowselect));
	 ObjectOutputStream obos = new ObjectOutputStream(fo);
	 obos.writeObject(mail);
	 obos.close();
	 fo.close();
    
	 Vector tmp = (Vector)ManageMessage.headerlist.get(rowselect);
	 ManageMessage.headerlist.removeElementAt(rowselect);
   	 MainFrame.updateTable();
   	 tmp.removeElementAt(3);
   	 tmp.add(3,type);
   	 ManageMessage.headerlist.add(rowselect,tmp);
   	 MainFrame.updateTable();
   	 MainFrame.updateSummary();
     MainFrame.updateStatus("");
     MainFrame.setDeleteButton(true);
     if (type.equals("Spam")) MainFrame.setSpamButton(false,true);
     else MainFrame.setSpamButton(true,false);
    }catch(IOException ioe){}
  }
 
 public void TrainBehindReceive(Vector mail,String type){
 	 for(int i=0;i<mail.size();i++){
       StringTokenizer st = new StringTokenizer(mail.get(i).toString());
        while (st.hasMoreTokens()){token.addElement(st.nextToken());} 
        }
 	 
 	try{
      	 TextTokenizer text= new TextTokenizer();
      	 receivetoken = text.CutString(token);
      }catch(Exception e){}  
      CountWord str = new CountWord();
      count = str.CountString(receivetoken);
      
      if(type.equals("Not Spam")){
       countamount = Integer.parseInt(Config.prop.getProperty("Good"));
       countamount++;
       value = value.valueOf(countamount);
       
       Config.prop.setProperty("Good",value);
       Config.Save();
       StoreHash.storegood(receivetoken,count);//Old method
       }
     
      else if(type.equals("Spam")){
     //System.out.println("2");
       countamount = Integer.parseInt(Config.prop.getProperty("Bad"));
       countamount++;
       value = value.valueOf(countamount);
       Config.prop.setProperty("Bad",value);
       Config.Save();
       StoreHash.storebad(receivetoken,count);
       }
     
     if ( (Integer.parseInt(Config.prop.getProperty("Good")) >0) && (Integer.parseInt(Config.prop.getProperty("Bad")))>0)
     {
      CountProbWord prob = new CountProbWord();
      prob.CountProb();
     }
   
 }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
   


