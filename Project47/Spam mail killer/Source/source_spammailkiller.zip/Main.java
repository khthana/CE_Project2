
class Main {
	
	private static Proxymail pm = null;
  	
  	public static void main(String[] args) {
 		 		
 		Config.Load();
 		
 		OpenHash.Opengood();
 		OpenHash.Openbad();
 		OpenHash.OpenProb();
 		Stopword.Load();
 		
 		ManageMessage.Prepare();
 		
 		new MainFrame("Spam Mail Killer");
 		
  		while (true) {
 			try {
 				pm = new Proxymail("Proxy Mail");
  				pm.start();
				pm.join();
  			}
 			catch (InterruptedException irex) {}
 		}
   	}
}