import java.io.*;
import java.util.*;

class Reclassified {
  
   Reclassified(Vector returnvalue,Vector mail){
   	int oldvalue,newvalue,value;
  	Vector countstring = new Vector();
  	Vector compare = new Vector(); 
   	 try{
   	
   	 TextTokenizer turntext = new TextTokenizer();
     countstring = turntext.CutString(returnvalue);
    
     }catch(Exception e){}
     CountWord countword = new CountWord();
     compare = countword.CountString(countstring);
     
  
     if(mail.get(0).equals("Not Spam")){
     	
     	for(int i=0;i<countstring.size();i++){
     	  oldvalue  =  Integer.parseInt(OpenHash.Hashg.get(countstring.get(i)).toString());
     	  newvalue  =  Integer.parseInt(compare.get(i).toString());
     	  value =  oldvalue-newvalue;
         // System.out.println(oldvalue+"-"+newvalue+"="+value);
      	  if (value == 0){OpenHash.Hashg.remove(countstring.elementAt(i));}
      	  else {OpenHash.Hashg.put(countstring.elementAt(i),new Integer(value));}
      	  }//End for
          
          OpenHash.Closegood();
          
          String addprop = new String();
          int propvalue =  Integer.parseInt(Config.prop.getProperty("Good"))-1;      
          addprop = addprop.valueOf(propvalue);
          Config.prop.setProperty("Good",addprop); 
          Config.Save();
          
         
      }//End if
     
     else if(mail.get(0).equals("Spam")){
     	
     	for(int i=0;i<countstring.size();i++){
     	   oldvalue  =  Integer.parseInt(OpenHash.Hashb.get(countstring.get(i)).toString());
     	   newvalue  =  Integer.parseInt(compare.get(i).toString());
     	   value = oldvalue-newvalue;
     	          
           if (value == 0){OpenHash.Hashb.remove(countstring.elementAt(i));}
      	   else {OpenHash.Hashb.put(countstring.elementAt(i),new Integer(value));}
        }//End for
          OpenHash.Closebad();
          
          String addprop = new String();
          int propvalue =  Integer.parseInt(Config.prop.getProperty("Bad"))-1;      
          addprop = addprop.valueOf(propvalue);
          Config.prop.setProperty("Bad",addprop);
          Config.Save();
      
       }//End Else
       
         // CountProbWord countprob = new CountProbWord();
         // countprob.CountProb();         
               
         
    }//End Constructor    
 }
