
import java.io.*;
	
class ClientToServer extends Thread {
	
	public static BufferedReader br_client = null;
	public static PrintStream ps_server = null;
  	
   	ClientToServer(String cts,InputStream is,OutputStream os) throws IOException {
		super(cts);
		InputStreamReader ir_client = new InputStreamReader(is);
		br_client = new BufferedReader(ir_client);
 		ps_server = new PrintStream(os);
  	}
	
 	public void run() {
		try {
			String command = null;
			while (true) {
				command = br_client.readLine();
				System.out.println("Client: "+command);
				ps_server.println(command);
 				if (command.startsWith("RETR")) ServerToClient.filter = true;
  				else
    			if (command.equals("QUIT")) break;
			}
			br_client.close();
			ps_server.close();
			ServerToClient.br_server.close();
			ServerToClient.ps_client.close();
   		}
		catch (IOException ioex) {}
 	}
 	
}
