
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.Vector;

class MailFrame extends JFrame implements Runnable {
	
	MailFrame(Vector mail,String title) {
		super(title);
		display = mail;
	}
	
	public void run() {
		display.removeElementAt(0);
		for (int i=0; i<display.size(); i++) if (display.get(i).equals("")) display.set(i," ");
 		jl.setListData(display);
 		jl.setFocusable(false);
 		getContentPane().add(new JScrollPane(jl));
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation( (screen.width-widthFrame)/2, (screen.height-heightFrame)/2 );
		setSize(widthFrame,heightFrame);
		setVisible(true);
		MainFrame.updateStatus("");
	}
	
	private Vector display;
	
	private int widthFrame = 600;
	private int heightFrame = 400;
	
	private JList jl = new JList();
 }