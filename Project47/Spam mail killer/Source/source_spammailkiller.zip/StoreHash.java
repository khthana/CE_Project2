import java.util.*;
import java.io.*;

class StoreHash {
 	StoreHash(){};
   
    static private int old,newvalue;
       
    static void storebad (Vector vecbad,Vector count){
        
        if (OpenHash.Hashb.size()!= 0){
         for(int y=0;y<vecbad.size();y++){
           if(OpenHash.Hashb.containsKey(vecbad.elementAt(y)) == true){    
	         old=Integer.parseInt(OpenHash.Hashb.get(vecbad.get(y)).toString());  
	         newvalue = old+Integer.parseInt(count.get(y).toString());    
	         OpenHash.Hashb.put(vecbad.get(y),new Integer(newvalue));        
	         }
           else 
             OpenHash.Hashb.put(vecbad.get(y),count.get(y)) ;
                 }//end for y
            }//end if
         
         else // Hash Size = 0;
            {
            for(int j=0;j<vecbad.size();j++)
            OpenHash.Hashb.put(vecbad.get(j),count.get(j)) ;
            }
            
            OpenHash.Closebad(); 
     
  } 
   
 
   static void storegood (Vector vecgood,Vector count){
        
        if (OpenHash.Hashg.size()!= 0){
         for(int y=0;y<vecgood.size();y++){
           if(OpenHash.Hashg.containsKey(vecgood.elementAt(y)) == true){    
	         old=Integer.parseInt(OpenHash.Hashg.get(vecgood.get(y)).toString());  
	         newvalue = old+Integer.parseInt(count.get(y).toString());    
	         OpenHash.Hashg.put(vecgood.get(y),new Integer(newvalue));        
	         }
           else 
             OpenHash.Hashg.put(vecgood.get(y),count.get(y)) ;
                 }//end for y
            }//end if
         
         else // Hash Size = 0;
            {
            for(int j=0;j<vecgood.size();j++)
            OpenHash.Hashg.put(vecgood.get(j),count.get(j)) ;
            }
            
            OpenHash.Closegood(); 
     }
  } 