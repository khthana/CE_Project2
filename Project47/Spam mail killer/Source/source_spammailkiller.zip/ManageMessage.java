
import java.io.*;
import java.util.Vector;

class ManageMessage {
	
	public static File dirMessage = new File("Message");
	
	public static Vector filename = new Vector();
	
 	public static Vector headerlist = new Vector();
	
	private static int msglastno;
	
   	public static void Prepare() {
		try {
			if (!dirMessage.exists()) {
				dirMessage.mkdir();
				MainFrame.setAllButton(false);
			}
			else {
    			String fn[];
    			FileInputStream fi;
 				ObjectInputStream obis;
 				Vector mail;
  				String tmp, from, subject, date, status;
 				int count;
 				
 				fn = dirMessage.list();
 				if (fn.length != 0) {
      			for (int i=0; i<fn.length; i++) {
					fi = new FileInputStream("./"+dirMessage.getName()+"/"+fn[i]);
					obis = new ObjectInputStream(fi);
					mail = (Vector) obis.readObject();
					obis.close();
					fi.close();
					status = (String)mail.get(0);
 					subject = null;
					from = null;
					date = null;
					count = 0;
					for (int j=1; j<mail.size(); j++) {
 						tmp = mail.get(j).toString();
 						if (tmp.startsWith("Subject: ")) {
 							subject = tmp.substring(9);
  							count++;
 						}
						else
						if (tmp.startsWith("From: ")) {
							from = tmp.substring(6);
  							count++;
						}
						else
						if (tmp.startsWith("Date: ")) {
 							date = tmp.substring(6);
  							count++;
						}
						if (count==3) break;
					}
 					mail.removeAllElements();
					mail.addElement(from);
					mail.addElement(subject);
					mail.addElement(date);
					mail.addElement(status);
 					headerlist.addElement(mail);
 				}
 				msglastno = Integer.parseInt(Config.prop.getProperty("msglastno"));
   				for (int i=0; i<fn.length; i++) filename.addElement(fn[i]);
   				}
   				else MainFrame.setAllButton(false);
   			}
		}
		catch (IOException ioex) {}
		catch (ClassNotFoundException cnfex) {}
	}
	
	public static void Load(int rowselect) {
		try {
			MainFrame.updateStatus("                      Status:   Openning");
			FileInputStream fi = new FileInputStream(
								"./"+dirMessage.getName()+"/"+filename.get(rowselect));
			ObjectInputStream obis = new ObjectInputStream(fi);
			Vector mail = (Vector) obis.readObject();
			obis.close();
			fi.close();
		//	for (int i=0; i<mail.size(); i++) System.out.println(mail.get(i));
			new Thread(new MailFrame(mail,(String)((Vector)headerlist.get(rowselect)).get(1))).start();
		}
		catch (IOException ioex) {}
		catch (ClassNotFoundException cnfex) {}
	}
	
	public static void Add(Vector addmail) {
		if (filename.size()==0) MainFrame.setAllButton(true);
		try {
			msglastno++;
			Config.prop.setProperty("msglastno",new Integer(msglastno).toString());
			Config.Save();
  			FileOutputStream fo = new FileOutputStream(
								"./"+dirMessage.getName()+"/"+msglastno+".msg");
    		ObjectOutputStream obos = new ObjectOutputStream(fo);
    		obos.writeObject(addmail);
    		obos.close();
    		fo.close();
     	}
    	catch (IOException ioex) {}
    	filename.addElement(msglastno+".msg");
    	String tmp=null, from=null, subject=null, date=null;
    	String status = (String)addmail.get(0);
 		int count=0;
		for (int i=1; i<addmail.size(); i++) {
 			tmp = addmail.get(i).toString();
 			if (tmp.startsWith("Subject: ")) {
 				subject = tmp.substring(9);
  				count++;
 			}
			else
			if (tmp.startsWith("From: ")) {
				from = tmp.substring(6);
  				count++;
			}
			else
			if (tmp.startsWith("Date: ")) {
 				date = tmp.substring(6);
  				count++;
			}
			if (count==3) break;
		}
		Vector mail = new Vector();
		mail.addElement(from);
		mail.addElement(subject);
		mail.addElement(date);
		mail.addElement(status);
 		headerlist.addElement(mail);
   		MainFrame.updateTable();
   		MainFrame.updateSummary();
	}
	
	public static void Delete(int rowselect) {
		MainFrame.updateStatus("                      Status:   Deleting");
		boolean deleteLast = false;
		if (rowselect==filename.size()-1) deleteLast = true;
 		File fileDelete = new File("./"+dirMessage.getName()+"/"+filename.get(rowselect));
		fileDelete.delete();
		filename.removeElementAt(rowselect);
		headerlist.removeElementAt(rowselect);
 		MainFrame.updateTable();
 		MainFrame.updateStatus("");
 		if (filename.size()==0) MainFrame.setAllButton(false);
 		if (deleteLast) MainFrame.rowselect--;
    }
    
    public static void DeleteAll() {
    	MainFrame.updateStatus("                      Status:   Deleting All");
    	File fileDelete;
    	for (int i=0; i<filename.size(); i++) {
    		fileDelete = new File("./"+dirMessage.getName()+"/"+filename.get(i));
    		fileDelete.delete();
    	}
    	filename.removeAllElements();
    	headerlist.removeAllElements();
     	MainFrame.updateTable();
    	MainFrame.updateStatus("");
    	MainFrame.setAllButton(false);
    }
    
 }