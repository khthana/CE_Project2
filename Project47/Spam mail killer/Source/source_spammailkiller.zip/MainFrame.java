
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.TableColumn;
import javax.swing.event.*;
import javax.swing.border.*;

import java.util.Vector;
 
class MainFrame extends JFrame {
	
	MainFrame(String title) {
		super(title);
		initFrame();
	}
	
	private void initFrame() {
		hostTextField.setText(Config.prop.getProperty("host"));
		portTextField.setText(Config.prop.getProperty("port"));
		proxyTextField.setText(Config.prop.getProperty("proxy port"));
		applyButton.addActionListener(new Action());
   		jp1.setLayout(null);
   		hostLabel.setLocation(15,10);
   		hostLabel.setSize(100,20);
   		jp1.add(hostLabel);
		hostTextField.setLocation(15,35);
		hostTextField.setSize(300,20);
		jp1.add(hostTextField);
		portLabel.setLocation(15,60);
		portLabel.setSize(100,20);
		jp1.add(portLabel);
		portTextField.setLocation(15,85);
		portTextField.setSize(300,20);
		jp1.add(portTextField);
		proxyLabel.setLocation(15,115);
		proxyLabel.setSize(100,20);
		jp1.add(proxyLabel);
		proxyTextField.setLocation(15,140);
		proxyTextField.setSize(300,20);
		jp1.add(proxyTextField);
		applyButton.setLocation(15,180);
		applyButton.setSize(70,30);
		jp1.add(applyButton);
 		statusProxyLabel.setForeground(Color.GRAY);
		statusProxyLabel.setLocation(15,240);
		statusProxyLabel.setSize(160,30);
 		jp1.add(statusProxyLabel);
 		tp.addTab("Proxy Setting",jp1);
 		
		jp2.setLayout(new BorderLayout());
 		viewButton.addActionListener(new Action());
 		deleteButton.addActionListener(new Action());
 		deleteAllButton.addActionListener(new Action());
 		spamButton.addActionListener(new Action());
 		nspamButton.addActionListener(new Action());
 		statusLabel.setForeground(Color.GRAY);
		toolbar.setFloatable(false);
		toolbar.add(viewButton);
		toolbar.addSeparator();
		toolbar.add(deleteButton);
		toolbar.add(deleteAllButton);
		toolbar.addSeparator();
		toolbar.add(spamButton);
		toolbar.add(nspamButton);
 		toolbar.add(statusLabel);
  		jp2.add(toolbar,BorderLayout.SOUTH);
 		
  		Vector columnHeader = new Vector();
 		columnHeader.addElement("From");
 		columnHeader.addElement("Subject");
 		columnHeader.addElement("Date");
 		columnHeader.addElement("Status");
 		table = new JTable(ManageMessage.headerlist,columnHeader);
  		table.getColumnModel().getColumn(0).setPreferredWidth(120);
 		table.getColumnModel().getColumn(1).setPreferredWidth(300);
 		table.getColumnModel().getColumn(2).setPreferredWidth(100);
 		table.getColumnModel().getColumn(3).setPreferredWidth(80);
   		table.setFocusable(false);
   		table.setShowGrid(false);
       	table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
 		ListSelectionModel sm = table.getSelectionModel();
  		sm.addListSelectionListener(new ListSelect());
   		jp2.add(new JScrollPane(table),BorderLayout.CENTER);
		tp.addTab("Train Message",jp2);
		
 		jp3.setLayout(null);
  		slider = new JSlider(JSlider.HORIZONTAL,0,100,(int)(Newmail.score*100));
 		slider.setMajorTickSpacing(10);
 		slider.setMinorTickSpacing(5);
 		slider.setPaintTicks(true);
 		slider.setPaintLabels(true);
		slider.setSnapToTicks(true);
		slider.setToolTipText("Drag And Drop");
    	slider.setLocation(80,50);
 		slider.setSize(300,50);
 		slider.addChangeListener(new ChangeSlider());
  		jp3.add(slider);
  		scoreLabel.setText("User define score range for probability of email");
  		scoreLabel.setLocation(80,150);
  		scoreLabel.setSize(350,20);
  		scoreLabel.setForeground(Color.BLUE);
   		jp3.add(scoreLabel);
    	jp3.setBorder(new TitledBorder("score"));
 		tp.addTab("Config Scroll",jp3);
		
 		jp4.setLayout(null);
 		numbergoodLabel.setLocation(50,50);
 		numbergoodLabel.setSize(200,20);
 		numbergoodLabel.setText("Not Spam : "+Config.prop.getProperty("Good")+" Message");
 		jp4.add(numbergoodLabel);
 		numberspamLabel.setLocation(50,100);
 		numberspamLabel.setSize(200,20);
 		numberspamLabel.setText("Spam : "+Config.prop.getProperty("Bad")+" Message");
 		jp4.add(numberspamLabel);
 		numbermsgLabel.setLocation(50,150);
 		numbermsgLabel.setSize(200,20);
 		numbermsgLabel.setText("Email Pass : "+Config.prop.getProperty("msglastno")+" Message");
 		jp4.add(numbermsgLabel);
		jp4.setBorder(new TitledBorder("summary"));
		tp.addTab("Summary",jp4);
		
 		getContentPane().add(tp);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation( (screen.width-widthFrame)/2 ,(screen.height-heightFrame)/2 );
		setSize(widthFrame,heightFrame);
 		setResizable(false);
 		setVisible(true);
 	}
 	
 	private int widthFrame = 550;
 	private int heightFrame = 330;
 	
 	private JTabbedPane tp = new JTabbedPane();
 	
 	private static JPanel jp1 = new JPanel();
  	private JLabel hostLabel = new JLabel("POP3 Server :");
 	private JLabel portLabel = new JLabel("POP3 Port :");
 	private JLabel proxyLabel = new JLabel("Proxy Port :");
 	private JTextField hostTextField = new JTextField(15);
 	private JTextField portTextField = new JTextField(15);
 	private JTextField proxyTextField = new JTextField(15);
 	private JButton applyButton = new JButton("Apply");
 	private static JLabel statusProxyLabel = new JLabel();
  	
 	private static JPanel jp2 = new JPanel();
 	private JToolBar toolbar = new JToolBar();
 	private static JButton viewButton = new JButton("View");
 	private static JButton deleteButton = new JButton("Delete");
 	private static JButton deleteAllButton = new JButton("Delete All");
 	private static JButton spamButton = new JButton("Spam");
 	private static JButton nspamButton = new JButton("Not Spam");
   	private static JLabel statusLabel = new JLabel();
  	private static JTable table = null;
  	
  	private JPanel jp3 = new JPanel();
  	private JSlider slider;
  	private JLabel scoreLabel = new JLabel();
  	
  	private static JPanel jp4 = new JPanel();
  	private static JLabel numbergoodLabel = new JLabel();
  	private static JLabel numberspamLabel = new JLabel();
  	private static JLabel numbermsgLabel = new JLabel();
  	
   	public static int rowselect;
   	
   	public static void updateSummary() {
   		numbergoodLabel.setText("Not Spam : "+Config.prop.getProperty("Good")+" Message");
    	numbergoodLabel.invalidate();
   		numberspamLabel.setText("Spam : "+Config.prop.getProperty("Bad")+" Message");
    	numberspamLabel.invalidate();
   		numbermsgLabel.setText("Email Pass : "+Config.prop.getProperty("msglastno")+" Message");
    	numbermsgLabel.invalidate();
    	jp4.validate();
    }
   	
   	public static void updateProxyStatus(String status) {
   		statusProxyLabel.setText(status);
   		statusProxyLabel.invalidate();
   		jp1.validate();
   	}
   	
   	public static void updateTable() {
   		table.invalidate();
  		jp2.validate();
   	}
   	
   	public static void updateStatus(String status) {
   		statusLabel.setText(status);
   		statusLabel.invalidate();
   		jp2.validate();
   	}
   	
   	public static void setSpamButton(boolean value1,boolean value2) {
   		spamButton.setEnabled(value1);
   		nspamButton.setEnabled(value2);
   	}
   	
   	public static void setDeleteButton(boolean value) {
   		deleteButton.setEnabled(value);
   		deleteAllButton.setEnabled(value);
   	}
   	
   	public static void setAllButton(boolean value) {
   		viewButton.setEnabled(value);
   		deleteButton.setEnabled(value);
   		deleteAllButton.setEnabled(value);
   		spamButton.setEnabled(value);
   		nspamButton.setEnabled(value);
   	}
   	
  	class Action implements ActionListener {
 		public void actionPerformed(ActionEvent e) {
 			if (e.getSource()==applyButton) {
  				Config.prop.setProperty("host",hostTextField.getText());
 				Config.prop.setProperty("port",portTextField.getText());
 				Config.prop.setProperty("proxy port",proxyTextField.getText());
 				Config.Save();
  			}
  			else
  			if ((e.getSource()==viewButton)) {
  				ManageMessage.Load(rowselect);
  			}
  			else
  			if ((e.getSource()==deleteButton)) {
  				ManageMessage.Delete(rowselect);
  			}
   			else
   			if (e.getSource()==deleteAllButton) {
   				int answer = JOptionPane.showConfirmDialog(null,
   										"Are you sure to delete all message ?",
   										"Confirm Delete",
   										JOptionPane.YES_NO_OPTION);
   				if (answer==JOptionPane.YES_OPTION) ManageMessage.DeleteAll();
   			}
   			else
   			if (e.getSource()==spamButton) {
   				setDeleteButton(false);
   				new TrainData(rowselect,"Spam").start();
     		}
   			else
   			if (e.getSource()==nspamButton) {
   				setDeleteButton(false);
   				new TrainData(rowselect,"Not Spam").start();
   			}
    	}
 	}
 	
 	class ListSelect implements ListSelectionListener {
 		public void valueChanged(ListSelectionEvent e) {
 			if (e.getValueIsAdjusting()) rowselect = table.getSelectedRow();
  			String type = (String)((Vector)ManageMessage.headerlist.get(rowselect)).get(3);
 			if (type.equals("Unclassified")) {
 				spamButton.setEnabled(true);
 				nspamButton.setEnabled(true);
 			}
 			else if (type.equals("Spam")) {
 				spamButton.setEnabled(false);
 				nspamButton.setEnabled(true);
 			}
 			else if (type.equals("Not Spam")) {
 				spamButton.setEnabled(true);
 				nspamButton.setEnabled(false);
 			}
     	}
 	}
 	
 	class ChangeSlider implements ChangeListener {
 		public void stateChanged(ChangeEvent e) {
 			JSlider sd = (JSlider) e.getSource();
  			if (!sd.getValueIsAdjusting()) {
 				int value = sd.getValue();
  				if (value==100) {
 					Newmail.score = 1;
 					Config.prop.setProperty("score","1");
 				}
 				else {
 					Newmail.score = Double.parseDouble("0."+value);
 					Config.prop.setProperty("score","0."+value);
 				}
  				Config.Save();
 			}
 		}
 	}
 }