
import java.io.*;
import java.util.Vector;
 
class ServerToClient extends Thread {
	
	public static BufferedReader br_server = null;
	public static PrintStream ps_client = null;
	
  	public static boolean filter = false;
	
	ServerToClient(String stc,InputStream is,OutputStream os) throws IOException {
		super(stc);
		InputStreamReader ir_server = new InputStreamReader(is);
		br_server = new BufferedReader(ir_server);
 		ps_client = new PrintStream(os);
 	}
	
  	public void run() {
 		try {
 			String response = null;
 			Vector mail = new Vector();
 			String type = null, tmp = null;
 			boolean found;
 			TrainData train;
         	while (true) {
 				if (filter) {
    				response = br_server.readLine();
   					if (!response.equals(".")) mail.addElement(response);
  					else {
   						train = new TrainData();
   						if ((Integer.parseInt(Config.prop.getProperty("Good")) >= 100) 
  								&& (Integer.parseInt(Config.prop.getProperty("Bad")) >= 100)){ 
  							type = Newmail.readmail(mail);
  						    train.TrainBehindReceive(mail,type);
  						}
  						else type = "Unclassified";
   						if (type.equals("Spam")) {
  							found = false;
  							for (int i=0; i<mail.size(); i++) {
     							if (!found) {
    								tmp = (String)mail.get(i);
    								if (tmp.startsWith("Subject: ")) {
    									tmp = "Subject: [spam] " + tmp.substring(9);
    									found = true;
    								}
    								System.out.println("Server: "+tmp);
    								ps_client.println(tmp);
    							} 
    							else {
    								System.out.println("Server: "+mail.get(i));
    								ps_client.println(mail.get(i));
    							}
    						}
  						}
  						else for (int i=0; i<mail.size(); i++) {
    						System.out.println("Server: "+mail.get(i));
    						ps_client.println(mail.get(i));
    					}
    					mail.add(0,type);
    					ManageMessage.Add(mail);
   						filter = false;
   						mail.removeAllElements();
      					System.out.println("Server: .");
    					ps_client.println(".");
   					}
 				}
 				else {
 					response = br_server.readLine();
    				System.out.println("Server: "+response);
					ps_client.println(response);
 				}
  				if (response.startsWith("-ERR")) break;
			}
			br_server.close();
			ps_client.close();
			ClientToServer.br_client.close();
			ClientToServer.ps_server.close();
    	}
		catch (IOException ioex) {}
	}
	
}
