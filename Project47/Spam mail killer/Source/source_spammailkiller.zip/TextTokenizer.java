import java.io.*;
import java.util.*;

class TextTokenizer {
   
     public Vector CutString(Vector x) throws Exception{  
	    
	     x = Cuturl(x);
         x = Cutnottoken(x);
         x = Checkip(x);
         x = Betweenword(x);
         
         for(int i=0;i<x.size();i++){
            if(Stopword.stopword.contains(x.get(i)))
              { x.remove(i);
               i=i-1;}
         }
         x = Checknumber(x);
         x = Checkdouble(x);
         x = Cutpicture(x);
        // System.out.println("x"+x.size());//check
      return x;
   }
     
    
    private Vector Cuturl(Vector cuturl){
      for (int i=0;i<cuturl.size();i++){
        if (cuturl.get(i).toString().startsWith("http")){
        if(cuturl.get(i).toString().indexOf("?") != -1)
         cuturl.setElementAt(cuturl.get(i).toString().substring(0,cuturl.get(i).toString().indexOf("?")),i);
         }
       }
       return cuturl;
     }
    
    private Vector Cutnottoken(Vector nottoken){
      String s,turn;
      Vector tmpnottoken = new Vector();
      try{
        for  (int i=0;i<nottoken.size();i++){
          Object j =  nottoken.elementAt(i);
          s = (String)j;
       StringTokenizer st = new StringTokenizer(s,"[]_*{}<>(),;:?!\\/%+><@\"\'= &");
          while (st.hasMoreTokens()){
           turn = st.nextToken();
           turn = turn.toLowerCase();
           tmpnottoken.addElement(turn);     
         }
       }
       }catch(Exception e){}
       return tmpnottoken;
      }
	
	private Vector Checknumber(Vector checknumber){
	  boolean test;	
	  Vector tmpchecknumber = new Vector(); 
	   for (int i=0;i<checknumber.size();i++){	
	   	 test = true;
	   try{                
         int n = Integer.parseInt(checknumber.get(i).toString());
         } catch(NumberFormatException e){test = false;} 
	    if (test==false)
	      tmpchecknumber.addElement(checknumber.get(i));
	    }
	    return tmpchecknumber;
	 }
   
    private Vector Checkdouble(Vector checkdouble){
	  boolean test;	
	  Vector tmpcheckdouble = new Vector(); 
	   for (int i=0;i<checkdouble.size();i++){	
	   	 test = true;
	   	try{                
         double y = Double.parseDouble(checkdouble.get(i).toString());
        } catch(NumberFormatException e){test = false;} 
	    if (test==false)
	      tmpcheckdouble.addElement(checkdouble.get(i));
	  }  
	   return tmpcheckdouble;
	 }
    
    private Vector Checkip(Vector checkip){
       
       Vector tmp = new Vector();
       Vector tmpcheckip = new Vector();
      
      for (int i=0;i<checkip.size();i++){
        if (checkip.get(i).toString().indexOf(".") != -1){  //Found Has Point
          boolean ip = true;//Check flag
          boolean ip2 = true;	  	  
       
       //*********Add Each Element of token has point to vector********//  
         
        while(checkip.get(i).toString().indexOf(".")!= -1){
          tmp.addElement(checkip.get(i).toString().substring(0,checkip.get(i).toString().indexOf(".")));
          checkip.setElementAt(checkip.get(i).toString().substring(checkip.get(i).toString().indexOf(".")+1),i);
          }///end while  
           tmp.addElement(checkip.get(i).toString());
                  
       //********check IS IP Address?****************    
         for(int k=0;k<tmp.size();k++){
          try{                
            int n = Integer.parseInt(tmp.get(k).toString());
           } catch(NumberFormatException e){ip2=false; break; }  
           }//end for
        //********IS IP******************************    
          if(ip2==true){
            StringBuffer st1 = new StringBuffer(tmp.get(0).toString());
            for(int l=1;l<tmp.size();l++)
              {st1.append("."+tmp.get(l));}
              tmpcheckip.addElement(st1);
           }//end if                   
           	         
          else{//*******Not IP It is String********
            for(int h=0;h<tmp.size()-1;h++){
             StringBuffer st2 =new StringBuffer(tmp.get(h).toString());	
             for(int m=h+1;m<tmp.size();m++){st2.append("."+tmp.get(m));}
                tmpcheckip.addElement(st2);
            }// end for h
             ip2 = true;
            }//end else not ip is string
           }//End if Check Has Point
          
          else{tmpcheckip.addElement(checkip.get(i));}
            tmp.removeAllElements(); 
         }//end for checkip
          return tmpcheckip;
      }
   
   private Vector Betweenword(Vector betweenword){
   	   String tmpcheck;
       boolean checkleft; 
       boolean checkright;
       for (int g=0;g<betweenword.size();g++){
         checkleft = true;
         checkright = true;
         tmpcheck = betweenword.get(g).toString();
         while(checkleft && !tmpcheck.equals(null)){
          if(tmpcheck.startsWith("-") || tmpcheck.startsWith("."))
              
              	tmpcheck = tmpcheck.substring(1);
          else checkleft = false;
          } 
          
          if (!tmpcheck.equals("")){
          	while(checkright){
          		if (tmpcheck.endsWith("-"))
          	     tmpcheck = tmpcheck.substring(0,tmpcheck.indexOf("-"));
          	    else if (tmpcheck.endsWith("."))
          	     tmpcheck = tmpcheck.substring(0,tmpcheck.indexOf("."));
          	    else checkright = false;
          	}
          }     	 	
          
          betweenword.setElementAt(tmpcheck,g);
        }
      return betweenword;
   }
  //*modified*****
   private Vector Cutpicture(Vector cutpic){
   	  for(int i=0;i<cutpic.size();i++){
   	  	if (cutpic.get(i).toString().length() > 30){
   	  	   if (cutpic.get(i).toString().indexOf("-")== -1 && cutpic.get(i).toString().indexOf(".")== -1)	
   	  		{
   	  		cutpic.remove(i);
   	  		i = i-1;
   	  	    }
   	  	}
   	  }
      return cutpic;
   }
}//end class
