
import java.io.*;
import java.util.*; 
 
class Newmail {
	
    private static Vector frommail = new Vector();
    private static Vector probhash = new Vector();
    private static Vector probchooseword = new Vector();
    private static double TotalProb;
    
    public static double score = Double.parseDouble(Config.prop.getProperty("score"));
   
   	public static String readmail(Vector mail) throws IOException {
      	
       for(int i=0;i<mail.size();i++){
     	  StringTokenizer st = new StringTokenizer(mail.get(i).toString());
          while (st.hasMoreTokens()) frommail.addElement(st.nextToken()); 
          }
       try{
       		  TextTokenizer text = new TextTokenizer();
    	      mail = text.CutString(mail);//wrong Use Vector
       
        }catch (Exception e){}
         
              probhash = CompareString(mail);
              probchooseword = Chooseword(probhash);
              Countprob(probchooseword);
              
        	  frommail.removeAllElements();
        	  probhash.removeAllElements();
        	  probchooseword.removeAllElements();
        	  
         System.out.println("TOTALPROB"+TotalProb);
         if (TotalProb >= score) 
           return "Spam"; 
         else 
           return "Not Spam";
    }
    
    private static Vector CompareString(Vector v){
        Vector compare = new Vector();
    	for(int i=0;i<v.size();i++){
    	     if(OpenHash.Hashprob.containsKey(v.get(i)))    
    		    compare.addElement(OpenHash.Hashprob.get(v.get(i)));
    		 else
    		    compare.addElement(new Double(0.4));
         }
      
       return compare;
    } 
    
    private static Vector Chooseword(Vector chooseword){
       	  double value;
       	  Vector probword = new Vector();
       	  for(int i=0;i<chooseword.size();i++){
       	  	value = Double.parseDouble(chooseword.get(i).toString());
       	  if((value > 0.0 && value <= 0.15) || (value>=0.85))
       	  	probword.addElement(new Double(value));
       	    }
       	  
       	  for(int j=0;j<probword.size();j++){System.out.println(probword.get(j));}
         
       return probword;
    }//Choose  words to compute;;;;
    
    private static void Countprob(Vector countprob){
    
      double up,down; 
      	up = 1.0; 
      	down = 1.0;
      	for(int i=0;i<countprob.size();i++){
          up = Double.parseDouble(countprob.get(i).toString())*up;
    	}
         System.out.println("a1*a2*a1...a15"+" === "+up);  
        for(int j=0;j<countprob.size();j++){
          down = (1.0-Double.parseDouble(countprob.get(j).toString()))*down;
        }
          System.out.println("1-a1*1-a2*...1-a15"+" === "+down);  
       
        TotalProb = up/(up+down);  
          // System.out.println(TotalProb); 
      } 
         
   }       






