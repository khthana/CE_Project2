
import java.io.*;
import java.util.Properties;

class Config {
	
	public static Properties prop = new Properties();
	
 	private static File fileConfig = new File("config.txt");
 	
  	public static void Load() {
 		try {
   			if (!fileConfig.exists()) {
   				fileConfig.createNewFile();
   				prop.setProperty("port","110");
   				prop.setProperty("proxy port","8888");
   				prop.setProperty("msglastno","0");
   				prop.setProperty("Good","0");
   				prop.setProperty("Bad","0");
   				prop.setProperty("score","0.85");
   				Save();
   			}
   			else {
 				FileInputStream fi = new FileInputStream(fileConfig);
 				prop.load(fi);
 				fi.close();
 			}
 		}
 		catch (IOException ioex) {}
 	}
 	
 	public static void Save() {
 		try {
 			FileOutputStream fo = new FileOutputStream(fileConfig);
 			prop.store(fo,"User Information");
 			fo.close();
 		}
 		catch (IOException ioex) {}
 	}
}