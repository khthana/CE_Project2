@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x cptgen.cmd
erase cptgen_kmitl.l67
erase cptgen.l67
ar6x -r cptgen_kmitl.l67 ..\Release\cptgen.o67
ar6x -r cptgen.l67 ..\Release\cptgen.obj
