-r
-m ..\Release\cptgen.map
-o ..\Release\cptgen.o67
-h
-g _CPTGEN_KMITL_ICPTGEN
-g _CPTGEN_KMITL_IALG
-g _CPTGEN_KMITL_alloc
-g _CPTGEN_KMITL_free
-g _CPTGEN_KMITL_initObj
-g _CPTGEN_KMITL_control
-g _CPTGEN_KMITL_init
-g _CPTGEN_KMITL_exit
-g _CPTGEN_KMITL_apply

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\CPTGEN_KMITL_ialg.obj
..\Release\CPTGEN_KMITL_ialgvt.obj
..\Release\iCPTGEN.obj
..\Release\CPTGEN_KMITL_priv.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
/*
// The CPTGEN_KMITL_activate & CPTGEN_KMITL_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
