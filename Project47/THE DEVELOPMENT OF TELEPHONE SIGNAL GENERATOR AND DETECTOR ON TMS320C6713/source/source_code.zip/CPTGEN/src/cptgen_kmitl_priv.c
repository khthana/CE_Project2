#include "cptgen_kmitl_priv.h"

//====================================================================
//=================INTERNAL FUNCTION IMPLEMENT==============================
//====================================================================
void CPT_GenTone(CPT_GenTone_Param* param)
{
	int step1, step2;
	int cs1, cs2, res;
	int num_of_samples;
	int amplitude = param->CPTparam->amplitude;
	int i;
	cs1 = param->CPTparam->step1;
	cs2 = param->CPTparam->step2;

	step1 = (param->freq[0]*512*1000)/param->CPTparam->SampRate;
	step2 = 0;
	if(param->freqNum == 2)
	{
		step2 = (param->freq[1]*512*1000)/param->CPTparam->SampRate;
	}

	num_of_samples = (param->length * param->CPTparam->SampRate) / 1000;
	param->SampNum = num_of_samples;

	for(i = (param->CPTparam->StartSample);i<num_of_samples; i++)
	{
		if(param->freqNum == 2)
		res = ((param->CPTparam->SinTable[(cs1/1000)%512] + param->CPTparam->SinTable[(cs2/1000)%512]) * 0.5);
			//res = res * 55 /100;	// reduce power
		else
		res = (param->CPTparam->SinTable[(cs1/1000)%512]);
		
		res = (res*amplitude)/100;

        cs1 += step1;
        cs2 += step2;
        param->CPTparam->data[param->CPTparam->count] = res;
        param->CPTparam->count++;
        if(param->CPTparam->count == param->CPTparam->frameSize && i != (num_of_samples-1))
        {
        	//param->CPTparam->state = 1;
        	param->CPTparam->StartSample = (i+1);
        	param->CPTparam->step1 = cs1;
        	param->CPTparam->step2 = cs2;
        	param->CPTparam->full = 1;
        	param->CPTparam->count = 0;
        	return;
        }
        else if(param->CPTparam->count == param->CPTparam->frameSize && i == (num_of_samples-1))
        {
        	//param->CPTparam->state = 0;
			param->CPTparam->StartSample = 0;
			//param->CPTparam->state = 0;
			param->CPTparam->step1 = 0;
			param->CPTparam->step2 = 0;
			param->CPTparam->full = 1;
			param->CPTparam->count = 0;
			return;
        }
		
	}
	//param->CPTparam->state = 0;
	param->CPTparam->StartSample = 0;
	//param->CPTparam->state = 0;
	param->CPTparam->step1 = 0;
	param->CPTparam->step2 = 0;
}

void CPT_GenPause(CPT_GenPause_Param* param)
{
	unsigned int i;
	unsigned int num_of_sample = (param->length * param->CPTparam->SampRate) / 1000;
	
	for(i = (param->CPTparam->StartSample);i<num_of_sample;i++)
	{
		param->CPTparam->data[param->CPTparam->count] = 0;
        param->CPTparam->count++;
        if(param->CPTparam->count == param->CPTparam->frameSize && i != (num_of_sample-1))
        {
        	//param->CPTparam->state = 0;
        	param->CPTparam->StartSample = (i+1);
        	param->CPTparam->step1 = 0;
        	param->CPTparam->step2 = 0;
        	param->CPTparam->full = 1;
        	param->CPTparam->count = 0;
        	return;
        }
        else if(param->CPTparam->count == param->CPTparam->frameSize && i == (num_of_sample-1))
        {
        	//param->CPTparam->state = 1;
			param->CPTparam->StartSample = 0;
			//param->CPTparam->state = 0;
			param->CPTparam->step1 = 0;
			param->CPTparam->step2 = 0;
			param->CPTparam->full = 1;
			param->CPTparam->count = 0;
			return;
        }
	}
	param->CPTparam->StartSample = 0;
	//param->CPTparam->state = 1;
	param->CPTparam->step1 = 0;
	param->CPTparam->step2 = 0;
}

void CPT_GenToneInit(CPT_GenTone_Param* Tparam,CPT_GenParam* param)
{
		Tparam->CPTparam = param;
}

void CPT_GenPauseInit(CPT_GenPause_Param* Pparam,CPT_GenParam* param)
{
	
	Pparam->CPTparam = param;
}

void Padding(CPT_GenParam *param)
{
	int i;
	if(param->count != 0)
	{
		for(i = param->count;i<param->frameSize;i++)
		{
			param->data[i] = 0;
		}
		param->full = 1;
	}
}

void SetState(int state,CPT_GenParam* param)
{
	param->state = state;
}
