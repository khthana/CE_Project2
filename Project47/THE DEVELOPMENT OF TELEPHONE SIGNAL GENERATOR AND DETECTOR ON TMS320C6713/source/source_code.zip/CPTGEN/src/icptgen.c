/*
//============================================================================
//
//    FILE NAME : ICPTGEN.c
//
//    ALGORITHM : CPTGEN
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iCPTGEN.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 1
//
//    Creation Date: Wed - 16 February 2005
//    Creation Time: 12:56 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "icptgen.h"

/*
// ===========================================================================
// CPTGEN_PARAMS
//
// This constant structure defines the default parameters for CPTGEN objects
*/
ICPTGEN_Params ICPTGEN_PARAMS = {
    sizeof(ICPTGEN_Params),
    1, /* unsigned int  framesizeOut0 */
    0, /* sinTable */
};
