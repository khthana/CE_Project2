/*
//============================================================================
//
//    FILE NAME : CPTGEN_KMITL_ialg.c
//
//    ALGORITHM : CPTGEN
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the CPTGEN_KMITL.h interface; KMITL's
//                implementation of the ICPTGEN interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 1
//
//    Creation Date: Wed - 16 February 2005
//    Creation Time: 12:56 PM
//
//============================================================================
*/

#pragma CODE_SECTION(CPTGEN_KMITL_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(CPTGEN_KMITL_free,       ".text:algFree")
#pragma CODE_SECTION(CPTGEN_KMITL_initObj,    ".text:algInit")
#pragma CODE_SECTION(CPTGEN_KMITL_control,    ".text:algControl")
#pragma CODE_SECTION(CPTGEN_KMITL_init,       ".text:init")
#pragma CODE_SECTION(CPTGEN_KMITL_exit,       ".text:exit")
/*
// The CPTGEN_KMITL_moved routine is only used if the CPTGEN_KMITL_alloc routine
// returns more than one valid IALG_MemRec structure.
#pragma CODE_SECTION(CPTGEN_KMITL_moved,      ".text:algMoved")
*/
/*
// The CPTGEN_KMITL_activate & CPTGEN_KMITL_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(CPTGEN_KMITL_activate,   ".text:algActivate")
#pragma CODE_SECTION(CPTGEN_KMITL_deactivate, ".text:algDeactivate")
*/

#include <std.h>
#include <limits.h>
#include "icptgen.h"
#include "cptgen_kmitl.h"
#include "CPTDefine.h"
#include "cptgen_kmitl_priv.h"

#define MTAB_NRECS 2

/*
//============================================================================
// CPTGEN_KMITL_Obj
*/
typedef struct CPTGEN_KMITL_Obj {
    IALG_Obj        alg;   /* MUST be first field of all CPTGEN objs */
    XDAS_UInt32     framesizeOut0;
    const XDAS_Int32 *sinTable;
    
    CPT_GenParam *param;

    /* TODO: add custom fields here */
} CPTGEN_KMITL_Obj;

/*
//============================================================================
// CPTGEN_KMITL_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the CPTGEN_KMITL processing methods.
*/
/*
// The CPTGEN_KMITL_activate & CPTGEN_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void CPTGEN_KMITL_activate(IALG_Handle handle)
{
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;
    
    // TODO: implement algActivate
}
*/

/*
//============================================================================
// CPTGEN_KMITL_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a CPTGEN_KMITL_Obj structure.
*/
Int CPTGEN_KMITL_alloc(const IALG_Params *CPTGENParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const ICPTGEN_Params *params = (Void *)CPTGENParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &ICPTGEN_PARAMS;  /* set default parameters */
    }

    /* Request memory for CPTGEN object */
    memTab[0].size = sizeof(CPTGEN_KMITL_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;
    
    memTab[1].size = sizeof(CPT_GenParam);
    memTab[1].alignment = 0;
    memTab[1].space = IALG_DARAM0;
    memTab[1].attrs = IALG_PERSIST;

    return (MTAB_NRECS);
}

/*
//============================================================================
// CPTGEN_KMITL_control
//
// Control our object's parameters while the algorithm is running
*/
Int CPTGEN_KMITL_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    ICPTGEN_Status *sPtr = (ICPTGEN_Status *)status;	
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;

    switch ((ICPTGEN_Cmd)cmd) {

       case ICPTGEN_GETSTATUS:

            return(IALG_EOK);

       case ICPTGEN_SETSTATUS:

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// CPTGEN_KMITL_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the CPTGEN_KMITL processing methods to persistent memory.
*/
/*
// The CPTGEN_KMITL_activate & CPTGEN_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void CPTGEN_KMITL_deactivate(IALG_Handle handle)
{
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;
    
    // TODO: implement algDeactivate
}
*/

/*
//============================================================================
// CPTGEN_KMITL_exit
//
// Exit the CPTGEN_KMITL module as a whole.
 */
Void CPTGEN_KMITL_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// CPTGEN_KMITL_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// CPTGEN_KMITL_alloc operation above.
*/
Int CPTGEN_KMITL_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;

    n = CPTGEN_KMITL_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[1].base = CPTGEN->param;

    return (n);
}

/*
//============================================================================
// CPTGEN_KMITL_init
//
// Initialize the CPTGEN_KMITL module as a whole.
*/
Void CPTGEN_KMITL_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// CPTGEN_KMITL_initObj
//
// Initialize the memory allocated for our instance.
*/
Int CPTGEN_KMITL_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *CPTGENParams)
{
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;
    const ICPTGEN_Params *params = (Void *)CPTGENParams;

    if(params == NULL){
        params = &ICPTGEN_PARAMS; /* set default parameters */
    }

    CPTGEN->framesizeOut0 = params->framesizeOut0;
    //CPTGEN->sinTable = params->sinTable;

    /* TODO: Implement any additional algInit desired */
    CPTGEN->param = memTab[1].base;
    
    CPTGEN->param->SinTable = params->sinTable;
	CPTGEN->param->SampRate = 8000;
	CPTGEN->param->count = 0;
	CPTGEN->param->completeCycle = 0;
	CPTGEN->param->StartSample = 0;
	CPTGEN->param->step1 = 0;
	CPTGEN->param->step2 = 0;
	CPTGEN->param->state = 1;
	CPTGEN->param->full = 0;
	CPTGEN->param->frameSize = CPTGEN->framesizeOut0;
    
    return (IALG_EOK);
}


//============================================================================
// CPTGEN_KMITL_moved
//
// Adjust any data pointers that has been moved by the client.


// The CPTGEN_KMITL_moved routine is only used if the CPTGEN_KMITL_alloc routine
// returns more than one valid IALG_MemRec structure.
Void CPTGEN_KMITL_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *CPTGENParams)
{
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;
    const ICPTGEN_Params *params = (Void *)CPTGENParams;
    
    CPTGEN->param = memTab[1].base;

}


/*
//============================================================================
// CPTGEN_KMITL_apply
// KMITL's implementation of the apply operation.
// Custom fields of the CPTGEN_KMITL_Obj may be accessed as follows:
//     CPTGEN->framesizeOut0 = ...;
//     CPTGEN->sinTable = ...;
*/
CPTGEN_Result CPTGEN_KMITL_apply(ICPTGEN_Handle handle, XDAS_Int32 code, XDAS_Int32 amplitude, XDAS_Int32 * out)
{
    CPTGEN_KMITL_Obj *CPTGEN = (Void *)handle;

    /* TODO: implement apply */
    CPTGEN_Result result;

    CPT_GenTone_Param Tparam;
	CPT_GenPause_Param Pparam;
	
	CPTGEN->param->full = 0;
	CPTGEN->param->code = code;
	CPTGEN->param->amplitude = amplitude;
	CPTGEN->param->data = out;
	
	result.code = code;
	result.amplitude = amplitude;
	result.Complete = FALSE;
	
	switch(CPTGEN->param->code)
	{
		case 0: //DIAL TONE
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			Tparam.freq[0] = GEN_DIAL_FREQ0;
			Tparam.freq[1] = GEN_DIAL_FREQ1;
			Tparam.freqNum = GEN_DIAL_NUM;
			Tparam.length = GEN_DIAL_TONE_DURATION;
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1 && CPTGEN->param->StartSample != 0)//want to continue
			{
				return result;
			}
			SetState(1,CPTGEN->param);
			CPTGEN->param->completeCycle = 1;
			//Padding(CPTGEN->param);

		break;
		
		case 1: //RING TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_RING_FREQ0;
			Tparam.freqNum = GEN_RING_NUM;
			Tparam.length = GEN_RING_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_RING_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)//want to continue
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 2: //BUSY TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_BUSY_FREQ0;
			Tparam.freqNum = GEN_BUSY_NUM;
			Tparam.length = GEN_BUSY_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_BUSY_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 3: //CONGESTION TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONGESTION_FREQ0;
			Tparam.freqNum = GEN_CONGESTION_NUM;
			Tparam.length = GEN_CONGESTION_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONGESTION_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 4: //SPECIAL INFORMATION TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_SPECIAL_FREQ0;
			Tparam.freqNum = GEN_SPECIAL_NUM;
			Tparam.length = GEN_SPECIAL_TONE_DURATION0;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_SPECIAL_PAUSE_DURATION0;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			
			SetState(3,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_SPECIAL_FREQ1;
			Tparam.freqNum = GEN_SPECIAL_NUM;
			Tparam.length = GEN_SPECIAL_TONE_DURATION1;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_SPECIAL_PAUSE_DURATION1;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(5,CPTGEN->param);}
				return result;
			}
			
			SetState(5,CPTGEN->param);
		}
		if(CPTGEN->param->state == 5)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_SPECIAL_FREQ2;
			Tparam.freqNum = GEN_SPECIAL_NUM;
			Tparam.length = GEN_SPECIAL_TONE_DURATION2;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(6,CPTGEN->param);}
				return result;
			}
			SetState(6,CPTGEN->param);
		}
		if(CPTGEN->param->state == 6)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_SPECIAL_PAUSE_DURATION2;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 5: //WARNING TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_WARNING_FREQ0;
			Tparam.freqNum = GEN_WARNING_NUM;
			Tparam.length = GEN_WARNING_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_WARNING_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 6: //PAY PHONE TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_PAYPHONE_FREQ0;
			Tparam.freqNum = GEN_PAYPHONE_NUM;
			Tparam.length = GEN_PAYPHONE_TONE_DURATION0;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_PAYPHONE_PAUSE_DURATION0;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			SetState(3,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_PAYPHONE_FREQ1;
			Tparam.freqNum = GEN_PAYPHONE_NUM;
			Tparam.length = GEN_PAYPHONE_TONE_DURATION1;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_PAYPHONE_PAUSE_DURATION1;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 7: //CALL WAITING TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CALL_WAIT_FREQ0;
			Tparam.freqNum = GEN_CALL_WAIT_NUM;
			Tparam.length = GEN_CALL_WAIT_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CALL_WAIT_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 8: //RECALL DIAL TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONFIRM_FREQ0;
			Tparam.freq[1] = GEN_CONFIRM_FREQ1;
			Tparam.freqNum = GEN_CONFIRM_NUM;
			Tparam.length = GEN_CONFIRM_TONE_DURATION0;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONFIRM_PAUSE_DURATION0;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			
			SetState(3,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONFIRM_FREQ0;
			Tparam.freq[1] = GEN_CONFIRM_FREQ1;
			Tparam.freqNum = GEN_CONFIRM_NUM;
			Tparam.length = GEN_CONFIRM_TONE_DURATION1;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONFIRM_PAUSE_DURATION1;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(5,CPTGEN->param);}
				return result;
			}
			
			SetState(5,CPTGEN->param);
		}
		if(CPTGEN->param->state == 5)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONFIRM_FREQ0;
			Tparam.freq[1] = GEN_CONFIRM_FREQ1;
			Tparam.freqNum = GEN_CONFIRM_NUM;
			Tparam.length = GEN_CONFIRM_TONE_DURATION2;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(6,CPTGEN->param);}
				return result;
			}
			SetState(6,CPTGEN->param);
		}
		if(CPTGEN->param->state == 6)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONFIRM_PAUSE_DURATION2;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(7,CPTGEN->param);}
				return result;
			}
			
			SetState(7,CPTGEN->param);
		}
		if(CPTGEN->param->state == 7)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_DIAL_FREQ0;
			Tparam.freq[1] = GEN_DIAL_FREQ1;
			Tparam.freqNum = GEN_DIAL_NUM;
			Tparam.length = GEN_DIAL_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 9: //INTERCEPT TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_INTERCEPT_FREQ0;
			Tparam.freqNum = GEN_INTERCEPT_NUM;
			Tparam.length = GEN_INTERCEPT_TONE_DURATION0;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_INTERCEPT_PAUSE_DURATION0;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				//if(CPTGEN->param->StartSample == 0)
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			SetState(3,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_INTERCEPT_FREQ1;
			Tparam.freqNum = GEN_INTERCEPT_NUM;
			Tparam.length = GEN_INTERCEPT_TONE_DURATION1;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_INTERCEPT_PAUSE_DURATION1;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 10: //CONFIRMATION TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONFIRM_FREQ0;
			Tparam.freq[1] = GEN_CONFIRM_FREQ1;
			Tparam.freqNum = GEN_CONFIRM_NUM;
			Tparam.length = GEN_CONFIRM_TONE_DURATION0;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONFIRM_PAUSE_DURATION0;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			
			SetState(3,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONFIRM_FREQ0;
			Tparam.freq[1] = GEN_CONFIRM_FREQ1;
			Tparam.freqNum = GEN_CONFIRM_NUM;
			Tparam.length = GEN_CONFIRM_TONE_DURATION1;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONFIRM_PAUSE_DURATION1;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(5,CPTGEN->param);}
				return result;
			}
			
			SetState(5,CPTGEN->param);
		}
		if(CPTGEN->param->state == 5)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CONFIRM_FREQ0;
			Tparam.freq[1] = GEN_CONFIRM_FREQ1;
			Tparam.freqNum = GEN_CONFIRM_NUM;
			Tparam.length = GEN_CONFIRM_TONE_DURATION2;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(6,CPTGEN->param);}
				return result;
			}
			SetState(6,CPTGEN->param);
		}
		if(CPTGEN->param->state == 6)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CONFIRM_PAUSE_DURATION2;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 11: //COMFORT TONE
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			Tparam.freq[0] = GEN_COMFORT_FREQ0;
			Tparam.freqNum = GEN_COMFORT_NUM;
			Tparam.length = GEN_COMFORT_TONE_DURATION;
			CPT_GenTone(&Tparam);
			CPTGEN->param->state = 1;
		break;
		
		case 12: //BUSY VERIFICATION TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_BUSY_VER_FREQ0;
			Tparam.freqNum = GEN_BUSY_VER_NUM;
			Tparam.length = GEN_BUSY_VER_TONE_DURATION0;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_BUSY_VER_PAUSE_DURATION0;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_BUSY_VER_FREQ0;
			Tparam.freqNum = GEN_BUSY_VER_NUM;
			Tparam.length = GEN_BUSY_VER_TONE_DURATION1;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_BUSY_VER_PAUSE_DURATION1;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
		
		case 13: //CALLER WAITING TONE
		if(CPTGEN->param->state == 1)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CALLER_FREQ0;
			Tparam.freqNum = GEN_CALLER_NUM;
			Tparam.length = GEN_CALLER_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(2,CPTGEN->param);}
				return result;
			}
			SetState(2,CPTGEN->param);
		}
		if(CPTGEN->param->state == 2)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CALLER_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(3,CPTGEN->param);}
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		if(CPTGEN->param->state == 3)
		{
			CPT_GenToneInit(&Tparam,CPTGEN->param);
			//==================
			Tparam.freq[0] = GEN_CALL_WAIT_FREQ0;
			Tparam.freqNum = GEN_CALL_WAIT_NUM;
			Tparam.length = GEN_CALL_WAIT_TONE_DURATION;
			//==================
			CPT_GenTone(&Tparam);
			if(CPTGEN->param->full == 1)
			{
				if(CPTGEN->param->StartSample == 0)
				{SetState(4,CPTGEN->param);}
				return result;
			}
			SetState(4,CPTGEN->param);
		}
		if(CPTGEN->param->state == 4)
		{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = GEN_CALL_WAIT_PAUSE_DURATION;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
					
		case 20:	//Pause
		//if(CPTGEN->param->state == 1)
		//{
			CPT_GenPauseInit(&Pparam,CPTGEN->param);
			//=================
			Pparam.length = 100;
			//=================
			CPT_GenPause(&Pparam);
			if(Pparam.CPTparam->full == 1 && Pparam.CPTparam->StartSample != 0)
			{
				return result;
			}
			SetState(1,CPTGEN->param);
		//}
		Pparam.CPTparam->completeCycle = 1;
		//Padding(CPTGEN->param);
		break;
	}
	
	if(CPTGEN->param->completeCycle == 1)
	{
		result.Complete = TRUE;
	}

    return result;
}
