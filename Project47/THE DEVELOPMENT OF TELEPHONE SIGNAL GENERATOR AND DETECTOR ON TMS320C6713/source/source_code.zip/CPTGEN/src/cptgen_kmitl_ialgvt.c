/*
//============================================================================
//
//    FILE NAME : CPTGEN_KMITL_ialgvt.c
//
//    ALGORITHM : CPTGEN
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the CPTGEN_KMITL module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 1
//
//    Creation Date: Wed - 16 February 2005
//    Creation Time: 12:56 PM
//
//============================================================================
*/

#include <std.h>
#include "icptgen.h"

#include "cptgen_kmitl.h"

extern Int  CPTGEN_KMITL_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  CPTGEN_KMITL_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  CPTGEN_KMITL_free(IALG_Handle, IALG_MemRec *);
extern Int  CPTGEN_KMITL_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  CPTGEN_KMITL_numAlloc(Void);
extern Void CPTGEN_KMITL_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
/*
// The CPTGEN_KMITL_activate & CPTGEN_KMITL_deactivate routines are
// only used if scratch memory is being used.
extern Void CPTGEN_KMITL_activate(IALG_Handle);
extern Void CPTGEN_KMITL_deactivate(IALG_Handle);
*/
extern CPTGEN_Result CPTGEN_KMITL_apply(ICPTGEN_Handle handle, XDAS_Int32 code, XDAS_Int32 amplitude, XDAS_Int32 * out);

#define IALGFXNS \
    &CPTGEN_KMITL_IALG,       /* module ID                            */ \
    NULL,							 /* activate   (NULL => not suported)    */ \
    CPTGEN_KMITL_alloc,       /* algAlloc                             */ \
    CPTGEN_KMITL_control,     /* control    (NULL => not suported)    */ \
    NULL,							/* deactivate (NULL => not suported)    */ \
    CPTGEN_KMITL_free,        /* free                                 */ \
    CPTGEN_KMITL_initObj,     /* init                                 */ \
    CPTGEN_KMITL_moved,     /* moved      (NULL => not suported)    */ \
    NULL                      /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// CPTGEN_KMITL_ICPTGEN
//
// This structure defines KMITL's implementation of the ICPTGEN interface
// for the CPTGEN_KMITL module.
*/
ICPTGEN_Fxns CPTGEN_KMITL_ICPTGEN = {	/* module_vendor_interface */
    IALGFXNS,
    CPTGEN_KMITL_apply,
};

/*
//============================================================================
// CPTGEN_KMITL_IALG
//
// This structure defines KMITL's implementation of the IALG interface
// for the CPTGEN_KMITL module.
*/
#ifdef _TI_
asm("_CPTGEN_KMITL_IALG .set _CPTGEN_KMITL_ICPTGEN");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns CPTGEN_KMITL_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
