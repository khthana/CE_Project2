/*
//============================================================================
//
//    FILE NAME : CPTGEN.c
//
//    ALGORITHM : CPTGEN
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in CPTGEN.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 1
//
//    Creation Date: Wed - 16 February 2005
//    Creation Time: 12:56 PM
//
//============================================================================
*/

#pragma CODE_SECTION(CPTGEN_create,  ".text:create")
#pragma CODE_SECTION(CPTGEN_control, ".text:control")
#pragma CODE_SECTION(CPTGEN_delete,  ".text:delete")
#pragma CODE_SECTION(CPTGEN_init,    ".text:init")
#pragma CODE_SECTION(CPTGEN_exit,    ".text:exit")

#include <std.h>
#include <alg.h>
#include <xdas.h>
#include "cptgen.h"

/*
// ===========================================================================
// CPTGEN_create
//
//  Create an CPTGEN instance object (using parameters specified by prms)
*/
CPTGEN_Handle CPTGEN_create(const ICPTGEN_Fxns *fxns, const CPTGEN_Params *prms)
{
    return ((CPTGEN_Handle)ALG_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// CPTGEN_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int CPTGEN_control(CPTGEN_Handle handle, CPTGEN_Cmd cmd, CPTGEN_Status *status)
{
    return (ALG_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// CPTGEN_delete
//
// Delete the CPTGEN instance object specified by handle
*/
Void CPTGEN_delete(CPTGEN_Handle handle)
{
    ALG_delete((IALG_Handle)handle);
}

/*
// ===========================================================================
// CPTGEN_init
//
// CPTGEN module initialization
*/
Void  CPTGEN_init(Void)
{
}

/*
// ===========================================================================
// CPTGEN_exit
//
// CPTGEN module finalization
*/
Void  CPTGEN_exit(Void)
{
}

/*
// ===========================================================================
// CPTGEN_apply
*/
CPTGEN_Result CPTGEN_apply(CPTGEN_Handle handle, XDAS_Int32 code, XDAS_Int32 amplitude, XDAS_Int32 * out)
{
    CPTGEN_Result result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->apply(handle, code, amplitude, out);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}
