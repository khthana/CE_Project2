/*
//============================================================================
//
//    FILE NAME : IDTMFG.c
//
//    ALGORITHM : DTMFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iDTMFG.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 13 December 2004
//    Creation Time: 09:37 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "idtmfg.h"

/*
// ===========================================================================
// DTMFG_PARAMS
//
// This constant structure defines the default parameters for DTMFG objects
*/
IDTMFG_Params IDTMFG_PARAMS = {
    sizeof(IDTMFG_Params),
    
    NULL,	//*ptr2konst
    NULL,	//*target_array
    0,		//array_elem
    
    NULL,	// genQ
    0,		// genQ_elem
    
    800,	//signal length (samples)
    800,    //pause length (samples)
};
