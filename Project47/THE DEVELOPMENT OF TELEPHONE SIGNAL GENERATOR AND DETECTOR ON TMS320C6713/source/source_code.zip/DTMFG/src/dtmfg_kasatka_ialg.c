/*
//============================================================================
//
//    FILE NAME : DTMFG_KASATKA_ialg.c
//
//    ALGORITHM : DTMFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the DTMFG_KASATKA.h interface; KASATKA's
//                implementation of the IDTMFG interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 13 December 2004
//    Creation Time: 09:37 PM
//
//============================================================================
*/

#pragma CODE_SECTION(DTMFG_KASATKA_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(DTMFG_KASATKA_free,       ".text:algFree")
#pragma CODE_SECTION(DTMFG_KASATKA_initObj,    ".text:algInit")
#pragma CODE_SECTION(DTMFG_KASATKA_control,    ".text:algControl")
#pragma CODE_SECTION(DTMFG_KASATKA_init,       ".text:init")
#pragma CODE_SECTION(DTMFG_KASATKA_exit,       ".text:exit")

// The DTMFG_KASATKA_moved routine is only used if the DTMFG_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
#pragma CODE_SECTION(DTMFG_KASATKA_moved,      ".text:algMoved")


// The DTMFG_KASATKA_activate & DTMFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(DTMFG_KASATKA_activate,   ".text:algActivate")
#pragma CODE_SECTION(DTMFG_KASATKA_deactivate, ".text:algDeactivate")


#include <std.h>
#include <limits.h>
#include "idtmfg.h"
#include "dtmfg_kasatka.h"

#define MTAB_NRECS 		3		//1	edited by Yury

#define HISTORY_TABN	1
#define FIELD_TABN 		2

/*
//============================================================================
// DTMFG_KASATKA_Obj
*/
typedef struct DTMFG_KASATKA_Obj {
    IALG_Obj        alg;   /* MUST be first field of all DTMFG objs */       

    /* TODO: add custom fields here */
    
    DTMFG_KONST	*konst;
    
    DTMFG_MBLK	*history;
    DTMFG_MBLK	*field;
    
} DTMFG_KASATKA_Obj;

// --- internal-used function

inline void gen_dtmf_incPtr(MdUns * ptr, MdUns maxE)
{
	*ptr = (*ptr+1) %  maxE;
}

// ---

// to enqueue data
MdInt gen_dtmf_enqueue(IDTMFG_Handle handle, Char data)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;

	if (DTMFG->field->gen_dtmf_sPtr == DTMFG->field->gen_dtmf_ePtr)
	{//full queue
		return (0);	// data's not be enqueued
	}else
	{//queue ready
		DTMFG->field->gen_dtmf_genDTMFQueue[DTMFG->field->gen_dtmf_ePtr] = data;
		gen_dtmf_incPtr(&(DTMFG->field->gen_dtmf_ePtr), DTMFG->field->gen_dtmf_genDTMFQueue_element);
		return (1);	// data's enqueued normally 				
	}
}

// ---
// to de-Q
MdInt gen_dtmf_dequeue(IDTMFG_Handle handle, Char * dest)	//#
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;
    
	if (((DTMFG->field->gen_dtmf_sPtr+1) %  DTMFG->field->gen_dtmf_genDTMFQueue_element) == DTMFG->field->gen_dtmf_ePtr)
	{// empty queue
		return (0);// empty queue
	}else
	{
		gen_dtmf_incPtr(&(DTMFG->field->gen_dtmf_sPtr), DTMFG->field->gen_dtmf_genDTMFQueue_element);
		*dest = DTMFG->field->gen_dtmf_genDTMFQueue[DTMFG->field->gen_dtmf_sPtr];	
		return (1);//	done
	}
}

// ---

XDAS_Void gen_dtmf_signal(IDTMFG_Handle handle, MdInt num_g)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;

    MdInt outs;									// tmp for each samples
    Int tmp;
    Uns cs1= DTMFG->field->gen_dtmf_acs1;
    Uns cs2= DTMFG->field->gen_dtmf_acs2;				// accumulative step count
    Uns step1 = DTMFG_LOW_STEP[DTMFG->field->gen_dtmf_currentDigit];	// step value
    Uns step2 = DTMFG_HI_STEP[DTMFG->field->gen_dtmf_currentDigit];	// step value
       	
    for (; num_g > 0; num_g--)
    {
        tmp = (DTMFG_SINE_TAB[(cs1>>10)%DTMFG_SINE_TAB_ELEM] + DTMFG_SINE_TAB[(cs2>>10)%DTMFG_SINE_TAB_ELEM]) >>1;
        tmp >>= 3;

	    	if ( (DTMFG->field->gen_dtmf_signalGend<=100) || (DTMFG->field->gen_dtmf_signalGend>=(DTMFG->field->gen_dtmf_signal_length-100)) )
	    	{
	   			if (DTMFG->field->gen_dtmf_signalGend<=100)
	   			{
	   				tmp = tmp * DTMFG->field->gen_dtmf_signalGend /100;
	   				outs = tmp;
	   			}else
	   			{	   				
	   				tmp = tmp * (DTMFG->field->gen_dtmf_signal_length - DTMFG->field->gen_dtmf_signalGend) /100;
	   				outs = tmp;
	   			}
	    	}else
	    	{
	    		outs = tmp;
	    	}	

		//if (outs >1000)	    
       	//LOG_printf(&log_gen, "out= %d", outs); 
	    		
		DTMFG->field->gen_dtmf_targetarray[DTMFG->field->gen_dtmf_arr_ptr++] = outs;
		
        cs1 += step1;
        cs2 += step2;
    }

	DTMFG->field->gen_dtmf_acs1 = ((cs1>>10)%DTMFG_SINE_TAB_ELEM)<<10;
	DTMFG->field->gen_dtmf_acs2 = ((cs2>>10)%DTMFG_SINE_TAB_ELEM)<<10;

	if (DTMFG->field->gen_dtmf_signalGend >= DTMFG->field->gen_dtmf_signal_length)
	{
		DTMFG->field->gen_dtmf_state = 2;
	}
			
}

// ---
XDAS_Void gen_dtmf_pause(IDTMFG_Handle handle, MdInt num_g)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;

    MdInt outs;									// tmp for each samples

    for (; num_g > 0; num_g--)
    {
        outs = 0;
		
		DTMFG->field->gen_dtmf_targetarray[DTMFG->field->gen_dtmf_arr_ptr++] = outs;
    }

	if (DTMFG->field->gen_dtmf_pauseGend >= DTMFG->field->gen_dtmf_pause_length)
	{
		DTMFG->field->gen_dtmf_state = 0;
	}    
		
}


// ---
/*
//============================================================================
// DTMFG_KASATKA_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the DTMFG_KASATKA processing methods.
*/

// The DTMFG_KASATKA_activate & DTMFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void DTMFG_KASATKA_activate(IALG_Handle handle)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;
    
    // TODO: implement algActivate
    // copy history to field
    memcpy((Void *) DTMFG->field, (Void *) DTMFG->history, sizeof(DTMFG_MBLK));        
}


/*
//============================================================================
// DTMFG_KASATKA_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a DTMFG_KASATKA_Obj structure.
*/
Int DTMFG_KASATKA_alloc(const IALG_Params *DTMFGParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IDTMFG_Params *params = (Void *)DTMFGParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IDTMFG_PARAMS;  /* set default parameters */
    }

    /* Request memory for DTMFG object */
    memTab[0].size = sizeof(DTMFG_KASATKA_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_EXTERNAL;
    memTab[0].attrs = IALG_PERSIST;
    
    // mem. tab for history var., edited by Yury
    memTab[HISTORY_TABN].size = sizeof(DTMFG_MBLK);
    memTab[HISTORY_TABN].alignment = 0;
    memTab[HISTORY_TABN].space = IALG_EXTERNAL;
    memTab[HISTORY_TABN].attrs = IALG_PERSIST;    
    
    // mem. tab for field var., edited by Yury
    memTab[FIELD_TABN].size = sizeof(DTMFG_MBLK);
    memTab[FIELD_TABN].alignment = 0;
    memTab[FIELD_TABN].space = IALG_DARAM0;
    memTab[FIELD_TABN].attrs = IALG_SCRATCH;

    return (MTAB_NRECS);
}

/*
//============================================================================
// DTMFG_KASATKA_control
//
// Control our object's parameters while the algorithm is running
*/
Int DTMFG_KASATKA_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    IDTMFG_Status *sPtr = (IDTMFG_Status *)status;	
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;

    switch ((IDTMFG_Cmd)cmd) {

       case IDTMFG_GETSTATUS:

            return(IALG_EOK);

       case IDTMFG_SETSTATUS:

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// DTMFG_KASATKA_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the DTMFG_KASATKA processing methods to persistent memory.
*/

// The DTMFG_KASATKA_activate & DTMFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void DTMFG_KASATKA_deactivate(IALG_Handle handle)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;
    
    // TODO: implement algDeactivate
    // copy field to history
    memcpy((Void *) DTMFG->history, (Void *) DTMFG->field, sizeof(DTMFG_MBLK));      
}


/*
//============================================================================
// DTMFG_KASATKA_exit
//
// Exit the DTMFG_KASATKA module as a whole.
 */
Void DTMFG_KASATKA_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// DTMFG_KASATKA_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// DTMFG_KASATKA_alloc operation above.
*/
Int DTMFG_KASATKA_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;

    n = DTMFG_KASATKA_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[0].size = sizeof(DTMFG_KASATKA_Obj);    
    
    memTab[HISTORY_TABN].base = DTMFG->history;
    memTab[HISTORY_TABN].size = sizeof(DTMFG_MBLK);
    
    memTab[FIELD_TABN].base = DTMFG->field;
    memTab[FIELD_TABN].size = sizeof(DTMFG_MBLK);   
       
    return (n);
}

/*
//============================================================================
// DTMFG_KASATKA_init
//
// Initialize the DTMFG_KASATKA module as a whole.
*/
Void DTMFG_KASATKA_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// DTMFG_KASATKA_initObj
//
// Initialize the memory allocated for our instance.
*/
Int DTMFG_KASATKA_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *DTMFGParams)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;
    const IDTMFG_Params *params = (Void *)DTMFGParams;

    if(params == NULL){
        //params = &IDTMFG_PARAMS; /* set default parameters */
        return (IALG_EFAIL);
    }


	if (params->target_array == NULL) {return (IALG_EFAIL);}
	if (params->ptr2konst == NULL) {return (IALG_EFAIL);}
	if (params->ptr2konst->dtmfg_sine_tab == NULL) {return (IALG_EFAIL);}
	
    /* TODO: Implement any additional algInit desired */     
    
   	DTMFG->history = memTab[HISTORY_TABN].base;
    DTMFG->field = memTab[FIELD_TABN].base;        
       
   	DTMFG->konst = params->ptr2konst;
       
    DTMFG->field->gen_dtmf_targetarray = params->target_array;
    DTMFG->field->gen_dtmf_array_element = params->array_elem;
    DTMFG->field->gen_dtmf_genDTMFQueue = params->genQ;
    DTMFG->field->gen_dtmf_genDTMFQueue_element = params->genQ_elem;
    DTMFG->field->gen_dtmf_signal_length = params->signal_len;
    DTMFG->field->gen_dtmf_pause_length = params->pause_len;
    
    DTMFG->field->gen_dtmf_acs1 = 0;
    DTMFG->field->gen_dtmf_acs2 = 0;
    
    DTMFG->field->gen_dtmf_state = 0;
    
    DTMFG->field->gen_dtmf_sPtr = 0;
    DTMFG->field->gen_dtmf_ePtr = 1;
    
    DTMFG->field->gen_dtmf_enable = 0;
    
    // copy field to history
    memcpy((Void *) DTMFG->history, (Void *) DTMFG->field, sizeof(DTMFG_MBLK));     
    
    return (IALG_EOK);
}

/*
//============================================================================
// DTMFG_KASATKA_moved
//
// Adjust any data pointers that has been moved by the client.
*/

// The DTMFG_KASATKA_moved routine is only used if the DTMFG_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
Void DTMFG_KASATKA_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *DTMFGParams)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;
    const IDTMFG_Params *params = (Void *)DTMFGParams;
    
    if (params != NULL)
    {
    	DTMFG->konst = params->ptr2konst;
    }
    
    DTMFG->field = memTab[FIELD_TABN].base;
    DTMFG->history = memTab[HISTORY_TABN].base;    

}


/*
//============================================================================
// DTMFG_KASATKA_apply
// KASATKA's implementation of the apply operation.
// Custom fields of the DTMFG_KASATKA_Obj may be accessed as follows:
*/
MdInt DTMFG_KASATKA_apply(IDTMFG_Handle handle)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;

    /* TODO: implement apply */
    
	MdInt tmp1;
	MdInt ret=0;
	
    if (DTMFG->field->gen_dtmf_enable == 0)
    {
    	return (-1);	// enable flag is not set!, target is not edited.
    }	

	DTMFG->field->gen_dtmf_arr_ptr=0;
	
	while (DTMFG->field->gen_dtmf_arr_ptr < DTMFG->field->gen_dtmf_array_element-1)
	{
		if ((DTMFG->field->gen_dtmf_state==0)&&(DTMFG->field->gen_dtmf_arr_ptr < DTMFG->field->gen_dtmf_array_element-1))
		{
			if (0==gen_dtmf_dequeue(handle, &(DTMFG->field->gen_dtmf_currentDigit)))
			{
				if (0 == DTMFG->field->gen_dtmf_arr_ptr) 
				{
					return (0);	// target's not edited
				}
				
				for (;DTMFG->field->gen_dtmf_arr_ptr < DTMFG->field->gen_dtmf_array_element; DTMFG->field->gen_dtmf_arr_ptr++)
				{				
					DTMFG->field->gen_dtmf_targetarray[DTMFG->field->gen_dtmf_arr_ptr]=0;
				}
			
			}else
			{
				DTMFG->field->gen_dtmf_acs1 = 0;
				DTMFG->field->gen_dtmf_acs2 = 0;
				DTMFG->field->gen_dtmf_signalGend = 0;

				DTMFG->field->gen_dtmf_pauseGend = 0;

				DTMFG->field->gen_dtmf_state = 1;				
			}
		}

		if ((DTMFG->field->gen_dtmf_state==1)&&(DTMFG->field->gen_dtmf_arr_ptr < DTMFG->field->gen_dtmf_array_element-1)) 
		{
			if ((DTMFG->field->gen_dtmf_array_element - DTMFG->field->gen_dtmf_arr_ptr) <= (DTMFG->field->gen_dtmf_signal_length - DTMFG->field->gen_dtmf_signalGend))	// remaining slot <= to be gen
			{
				tmp1 = DTMFG->field->gen_dtmf_array_element - DTMFG->field->gen_dtmf_arr_ptr;
				DTMFG->field->gen_dtmf_signalGend += tmp1;
				gen_dtmf_signal(handle,tmp1);
			}else
			{
				tmp1 = DTMFG->field->gen_dtmf_signal_length - DTMFG->field->gen_dtmf_signalGend;
				DTMFG->field->gen_dtmf_signalGend += tmp1;
				gen_dtmf_signal(handle,tmp1);
			}
			ret = 1;	// target array is edited
		}

		if ((DTMFG->field->gen_dtmf_state==2)&&(DTMFG->field->gen_dtmf_arr_ptr < DTMFG->field->gen_dtmf_array_element-1))
		{
			if ((DTMFG->field->gen_dtmf_array_element - DTMFG->field->gen_dtmf_arr_ptr) <= ( DTMFG->field->gen_dtmf_pause_length - DTMFG->field->gen_dtmf_pauseGend))	// remaining slot <= to be gen
			{
				tmp1 = DTMFG->field->gen_dtmf_array_element - DTMFG->field->gen_dtmf_arr_ptr;
				DTMFG->field->gen_dtmf_pauseGend += tmp1;
				gen_dtmf_pause(handle, tmp1);
			}else
			{
				tmp1 = DTMFG->field->gen_dtmf_pause_length - DTMFG->field->gen_dtmf_pauseGend;
				DTMFG->field->gen_dtmf_pauseGend += tmp1;
				gen_dtmf_pause(handle, tmp1);
			}
			ret = 1;	// target array is edited
		}

	}//while

	return (ret);	// not gen'd
}

// ---

MdInt DTMFG_KASATKA_enqueue(IDTMFG_Handle handle, Char data)
{    
	return (gen_dtmf_enqueue(handle, data));
}

// ---

Void DTMFG_KASATKA_setEnable(IDTMFG_Handle handle, Char enable, Char clearQ)
{
    DTMFG_KASATKA_Obj *DTMFG = (Void *)handle;
    
    DTMFG->field->gen_dtmf_enable = enable;
    
    if (clearQ != 0)
    {
 		// clear all data in Q
		DTMFG->field->gen_dtmf_sPtr = 0;
    	DTMFG->field->gen_dtmf_ePtr = 1;
    }
}

// ---

