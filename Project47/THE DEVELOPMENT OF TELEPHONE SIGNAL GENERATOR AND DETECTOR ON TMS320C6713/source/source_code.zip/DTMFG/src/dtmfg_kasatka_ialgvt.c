/*
//============================================================================
//
//    FILE NAME : DTMFG_KASATKA_ialgvt.c
//
//    ALGORITHM : DTMFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the DTMFG_KASATKA module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 13 December 2004
//    Creation Time: 09:37 PM
//
//============================================================================
*/

#include <std.h>
#include "idtmfg.h"

#include "dtmfg_kasatka.h"

extern Int  DTMFG_KASATKA_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  DTMFG_KASATKA_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  DTMFG_KASATKA_free(IALG_Handle, IALG_MemRec *);
extern Int  DTMFG_KASATKA_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  DTMFG_KASATKA_numAlloc(Void);

// The DTMFG_KASATKA_moved routine is only used if the DTMFG_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
extern Void DTMFG_KASATKA_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);


// The DTMFG_KASATKA_activate & DTMFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
extern Void DTMFG_KASATKA_activate(IALG_Handle);
extern Void DTMFG_KASATKA_deactivate(IALG_Handle);

extern MdInt DTMFG_KASATKA_apply(IDTMFG_Handle handle);
extern MdInt DTMFG_KASATKA_enqueue(IDTMFG_Handle handle, Char data);
extern Void DTMFG_KASATKA_setEnable(IDTMFG_Handle handle, Char enable, Char clearQ);

#define IALGFXNS \
    &DTMFG_KASATKA_IALG,       /* module ID                            */ \
    DTMFG_KASATKA_activate,    /* activate   (NULL => not suported)    */ \
    DTMFG_KASATKA_alloc,       /* algAlloc                             */ \
    DTMFG_KASATKA_control,     /* control    (NULL => not suported)    */ \
    DTMFG_KASATKA_deactivate,  /* deactivate (NULL => not suported)    */ \
    DTMFG_KASATKA_free,        /* free                                 */ \
    DTMFG_KASATKA_initObj,     /* init                                 */ \
    DTMFG_KASATKA_moved,       /* moved      (NULL => not suported)    */ \
    NULL                       /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// DTMFG_KASATKA_IDTMFG
//
// This structure defines KASATKA's implementation of the IDTMFG interface
// for the DTMFG_KASATKA module.
*/
IDTMFG_Fxns DTMFG_KASATKA_IDTMFG = {	/* module_vendor_interface */
    IALGFXNS,
    DTMFG_KASATKA_apply,
	DTMFG_KASATKA_enqueue,
	DTMFG_KASATKA_setEnable,
};

/*
//============================================================================
// DTMFG_KASATKA_IALG
//
// This structure defines KASATKA's implementation of the IALG interface
// for the DTMFG_KASATKA module.
*/
#ifdef _TI_
asm("_DTMFG_KASATKA_IALG .set _DTMFG_KASATKA_IDTMFG");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns DTMFG_KASATKA_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
