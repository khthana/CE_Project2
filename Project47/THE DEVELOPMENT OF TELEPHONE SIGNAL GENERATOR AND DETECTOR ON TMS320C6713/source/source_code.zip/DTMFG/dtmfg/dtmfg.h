/*
//============================================================================
//
//    FILE NAME : DTMFG.h
//
//    ALGORITHM : DTMFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                DTMFG module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 13 December 2004
//    Creation Time: 09:37 PM
//
//============================================================================
*/

#ifndef DTMFG_
#define DTMFG_

#include <algrf.h>
#include <xdas.h>
#include "idtmfg.h"

/*
// ===========================================================================
// DTMFG_Handle
//
// This pointer is used to reference all DTMFG instance objects
*/
typedef struct IDTMFG_Obj *DTMFG_Handle;

/*
// ===========================================================================
// DTMFG_Params
//
// This structure defines the creation parameters for all DTMFG objects
*/
typedef IDTMFG_Params DTMFG_Params;

/*
// ===========================================================================
// DTMFG_PARAMS
//
// This structure defines the default creation parameters for DTMFG objects
*/
#define DTMFG_PARAMS   IDTMFG_PARAMS

/*
// ===========================================================================
// DTMFG_Status
//
// This structure defines the real-time parameters for DTMFG objects
*/
typedef struct IDTMFG_Status   DTMFG_Status;

/*
// ===========================================================================
// DTMFG_Cmd
//
// This typedef defines the control commands DTMFG objects
*/
typedef IDTMFG_Cmd   DTMFG_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define DTMFG_GETSTATUS    IDTMFG_GETSTATUS
#define DTMFG_SETSTATUS    IDTMFG_SETSTATUS

/*
// ===========================================================================
// DTMFG_create
//
// Create an DTMFG instance object (using parameters specified by prms)
*/
extern DTMFG_Handle DTMFG_create(const IDTMFG_Fxns *fxns, const DTMFG_Params *prms);

/*
// ===========================================================================
// DTMFG_control
//
// Get, set, and change the parameters of the DTMFG function (using parameters specified by status).
*/
extern Int DTMFG_control(DTMFG_Handle handle, DTMFG_Cmd cmd, DTMFG_Status *status);

/*
// ===========================================================================
// DTMFG_delete
// Delete the DTMFG instance object specified by handle
*/
extern Void DTMFG_delete(DTMFG_Handle handle);

/*
// ===========================================================================
// DTMFG_apply
*/
extern MdInt DTMFG_apply(DTMFG_Handle handle);

#endif	/* DTMFG_ */
