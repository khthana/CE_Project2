/*
//============================================================================
//
//    FILE NAME : DTMFG.c
//
//    ALGORITHM : DTMFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in DTMFG.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 13 December 2004
//    Creation Time: 09:37 PM
//
//============================================================================
*/

#pragma CODE_SECTION(DTMFG_create,  ".text:create")
#pragma CODE_SECTION(DTMFG_control, ".text:control")
#pragma CODE_SECTION(DTMFG_delete,  ".text:delete")
#pragma CODE_SECTION(DTMFG_init,    ".text:init")
#pragma CODE_SECTION(DTMFG_exit,    ".text:exit")

#include <std.h>
#include <algrf.h>
#include <xdas.h>
#include "dtmfg.h"

/*
// ===========================================================================
// DTMFG_create
//
//  Create an DTMFG instance object (using parameters specified by prms)
*/
DTMFG_Handle DTMFG_create(const IDTMFG_Fxns *fxns, const DTMFG_Params *prms)
{
    return ((DTMFG_Handle)ALGRF_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// DTMFG_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int DTMFG_control(DTMFG_Handle handle, DTMFG_Cmd cmd, DTMFG_Status *status)
{
    return (ALGRF_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// DTMFG_delete
//
// Delete the DTMFG instance object specified by handle
*/
Void DTMFG_delete(DTMFG_Handle handle)
{
    ALGRF_delete((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// DTMFG_init
//
// DTMFG module initialization
*/
Void  DTMFG_init(Void)
{
}

/*
// ===========================================================================
// DTMFG_exit
//
// DTMFG module finalization
*/
Void  DTMFG_exit(Void)
{
}

/*
// ===========================================================================
// DTMFG_apply
*/
MdInt DTMFG_apply(DTMFG_Handle handle)
{
	MdInt tmp;
	
    ALGRF_activate((ALGRF_Handle)handle);

    tmp = handle->fxns->apply(handle);

    ALGRF_deactivate((ALGRF_Handle)handle);
    
    return (tmp);
}


// ---

MdInt DTMFG_enqueue(DTMFG_Handle handle, Char data)
{
	MdInt tmp;
	
    ALGRF_activate((ALGRF_Handle)handle);
		tmp = handle->fxns->enqueue(handle,data);
    ALGRF_deactivate((ALGRF_Handle)handle);	
    
    return (tmp);
}

// ---
Void DTMFG_setEnable(DTMFG_Handle handle, Char enable, Char clearQ)
{
    ALGRF_activate((ALGRF_Handle)handle);

    handle->fxns->setEnable(handle, enable, clearQ);

    ALGRF_deactivate((ALGRF_Handle)handle);
}

// ---
