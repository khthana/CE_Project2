-r
-m ..\Release\dtmfg.map
-o ..\Release\dtmfg.o67
-h
-g _DTMFG_KASATKA_IDTMFG
-g _DTMFG_KASATKA_IALG
-g _DTMFG_KASATKA_alloc
-g _DTMFG_KASATKA_free
-g _DTMFG_KASATKA_initObj
-g _DTMFG_KASATKA_control
-g _DTMFG_KASATKA_init
-g _DTMFG_KASATKA_exit
-g _DTMFG_KASATKA_apply

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\DTMFG_KASATKA_ialg.obj
..\Release\DTMFG_KASATKA_ialgvt.obj
..\Release\iDTMFG.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
/*
// The DTMFG_KASATKA_activate & DTMFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
