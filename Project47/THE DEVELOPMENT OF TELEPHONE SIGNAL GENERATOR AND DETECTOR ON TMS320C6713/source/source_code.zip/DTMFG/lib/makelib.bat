@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x dtmfg.cmd
erase dtmfg_kasatka.l67
erase dtmfg.l67
ar6x -r dtmfg_kasatka.l67 ..\Release\dtmfg.o67
ar6x -r dtmfg.l67 ..\Release\dtmfg.obj
