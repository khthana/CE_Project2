/*
//============================================================================
//
//    FILE NAME : DTMFD.c
//
//    ALGORITHM : DTMFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in DTMFD.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 06 January 2005
//    Creation Time: 02:35 PM
//
//============================================================================
*/

#pragma CODE_SECTION(DTMFD_create,  ".text:create")
#pragma CODE_SECTION(DTMFD_control, ".text:control")
#pragma CODE_SECTION(DTMFD_delete,  ".text:delete")
#pragma CODE_SECTION(DTMFD_init,    ".text:init")
#pragma CODE_SECTION(DTMFD_exit,    ".text:exit")

#include <std.h>
#include <algrf.h>
#include <xdas.h>
#include "dtmfd.h"

/*
// ===========================================================================
// DTMFD_create
//
//  Create an DTMFD instance object (using parameters specified by prms)
*/
DTMFD_Handle DTMFD_create(const IDTMFD_Fxns *fxns, const DTMFD_Params *prms)
{
    return ((DTMFD_Handle)ALGRF_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// DTMFD_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int DTMFD_control(DTMFD_Handle handle, DTMFD_Cmd cmd, DTMFD_Status *status)
{
    return (ALGRF_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// DTMFD_delete
//
// Delete the DTMFD instance object specified by handle
*/
Void DTMFD_delete(DTMFD_Handle handle)
{
    ALGRF_delete((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// DTMFD_init
//
// DTMFD module initialization
*/
Void  DTMFD_init(Void)
{
}

/*
// ===========================================================================
// DTMFD_exit
//
// DTMFD module finalization
*/
Void  DTMFD_exit(Void)
{
}

/*
// ===========================================================================
// DTMFD_apply
*/
XDAS_Void DTMFD_apply(DTMFD_Handle handle, MdInt * samp, MdInt * result)
{
    ALGRF_activate((ALGRF_Handle)handle);

    handle->fxns->apply(handle, samp, result);

    ALGRF_deactivate((ALGRF_Handle)handle);
}
