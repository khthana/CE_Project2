/*
//============================================================================
//
//    FILE NAME : DTMFD.h
//
//    ALGORITHM : DTMFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                DTMFD module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 06 January 2005
//    Creation Time: 02:35 PM
//
//============================================================================
*/

#ifndef DTMFD_
#define DTMFD_

#include <algrf.h>
#include <xdas.h>
#include "idtmfd.h"

/*
// ===========================================================================
// DTMFD_Handle
//
// This pointer is used to reference all DTMFD instance objects
*/
typedef struct IDTMFD_Obj *DTMFD_Handle;

/*
// ===========================================================================
// DTMFD_Params
//
// This structure defines the creation parameters for all DTMFD objects
*/
typedef IDTMFD_Params DTMFD_Params;

/*
// ===========================================================================
// DTMFD_PARAMS
//
// This structure defines the default creation parameters for DTMFD objects
*/
#define DTMFD_PARAMS   IDTMFD_PARAMS

/*
// ===========================================================================
// DTMFD_Status
//
// This structure defines the real-time parameters for DTMFD objects
*/
typedef struct IDTMFD_Status   DTMFD_Status;

/*
// ===========================================================================
// DTMFD_Cmd
//
// This typedef defines the control commands DTMFD objects
*/
typedef IDTMFD_Cmd   DTMFD_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define DTMFD_GETSTATUS    IDTMFD_GETSTATUS
#define DTMFD_SETSTATUS    IDTMFD_SETSTATUS

/*
// ===========================================================================
// DTMFD_create
//
// Create an DTMFD instance object (using parameters specified by prms)
*/
extern DTMFD_Handle DTMFD_create(const IDTMFD_Fxns *fxns, const DTMFD_Params *prms);

/*
// ===========================================================================
// DTMFD_control
//
// Get, set, and change the parameters of the DTMFD function (using parameters specified by status).
*/
extern Int DTMFD_control(DTMFD_Handle handle, DTMFD_Cmd cmd, DTMFD_Status *status);

/*
// ===========================================================================
// DTMFD_delete
// Delete the DTMFD instance object specified by handle
*/
extern Void DTMFD_delete(DTMFD_Handle handle);

/*
// ===========================================================================
// DTMFD_apply
*/
extern XDAS_Void DTMFD_apply(DTMFD_Handle handle, MdInt * samp, MdInt * result);

#endif	/* DTMFD_ */
