@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x dtmfd.cmd
erase dtmfd_kasatka.l67
erase dtmfd.l67
ar6x -r dtmfd_kasatka.l67 ..\Release\dtmfd.o67
ar6x -r dtmfd.l67 ..\Release\dtmfd.obj
