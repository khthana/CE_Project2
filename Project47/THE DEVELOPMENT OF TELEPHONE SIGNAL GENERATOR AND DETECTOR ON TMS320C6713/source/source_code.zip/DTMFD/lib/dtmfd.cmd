-r
-m ..\Release\dtmfd.map
-o ..\Release\dtmfd.o67
-h
-g _DTMFD_KASATKA_IDTMFD
-g _DTMFD_KASATKA_IALG
-g _DTMFD_KASATKA_alloc
-g _DTMFD_KASATKA_free
-g _DTMFD_KASATKA_initObj
-g _DTMFD_KASATKA_control
-g _DTMFD_KASATKA_init
-g _DTMFD_KASATKA_exit
-g _DTMFD_KASATKA_apply

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\DTMFD_KASATKA_ialg.obj
..\Release\DTMFD_KASATKA_ialgvt.obj
..\Release\iDTMFD.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
/*
// The DTMFD_KASATKA_activate & DTMFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
