/*
//============================================================================
//
//    FILE NAME : _DTMFD.c
//
//    BLOCK NAME: DTMFD
//
//    GROUP NAME: Default Group
//
//    PURPOSE   : Provides the real-time block's DSP C source code.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 06 January 2005
//    Creation Time: 02:35 PM
//
//============================================================================
*/

#include "_dtmfd.h"

#pragma DATA_SECTION(Params, ".hyper:ignore")
PARAMS Params;

/*----------------------------------------------------------------------------*/
/*               Optional real-time block interrupt routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called in response to a selected  */
/* DSP interrupt.  If this routine in not activated, the main block routine   */
/* will be called in response to a selected DSP interrupt.                    */
/*----------------------------------------------------------------------------*/
/*
void DTMFD_INT(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*               Optional real-time block initialization routine              */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called one time before the main   */
/* application begins.  This allows for any required software or hardware     */
/* initialization to be performed before the block executes.                  */
/*----------------------------------------------------------------------------*/

static IDTMFD_Fxns   fxns;
static DTMFD_Params  params;

void DTMFD_INIT(PARAMS *pPtr)
{
    fxns = DTMFD_KASATKA_IDTMFD;
    params = DTMFD_PARAMS;


    pPtr->handle = DTMFD_create(&fxns, &params);
}


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block stop routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever the block diagram */
/* worksheet's execution is stopped.  Blocks that deal with hardware may need */
/* this routine to stop the hardware's execution.                             */
/*----------------------------------------------------------------------------*/
/*
void DTMFD_STOP(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block restart routine                */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever a block diagram   */
/* worksheet is executed after being stopped.  Blocks that deal with hardware */
/* may need this routine to restart the hardware's execution.                 */
/*----------------------------------------------------------------------------*/
/*
void DTMFD_RESTART(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                           Real-time block routine                          */
/*----------------------------------------------------------------------------*/
/* This is the main block routine.  It is called during each loop of the main */
/* application.  If an interrupt is selected, and the interrupt routine above */
/* is not activated, this routine will be called in response to the selected  */
/* interrupt instead of during the main application loop.                     */
/* Custom fields of the pPtr structure may be accessed as follows:            */
/*----------------------------------------------------------------------------*/
void DTMFD(PARAMS *pPtr)
{
    if(pPtr->handle){
        if(pPtr->Changed){
            DTMFD_Status	status;

            pPtr->Changed = FALSE;
            DTMFD_control(pPtr->handle, DTMFD_SETSTATUS, &status);
        }

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        //DTMFD_apply(pPtr->handle);
    }
}
