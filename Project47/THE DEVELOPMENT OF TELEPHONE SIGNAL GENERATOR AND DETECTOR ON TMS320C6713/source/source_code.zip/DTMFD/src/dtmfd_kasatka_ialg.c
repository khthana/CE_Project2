/*
//============================================================================
//
//    FILE NAME : DTMFD_KASATKA_ialg.c
//
//    ALGORITHM : DTMFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the DTMFD_KASATKA.h interface; KASATKA's
//                implementation of the IDTMFD interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 06 January 2005
//    Creation Time: 02:35 PM
//
//============================================================================
*/

#pragma CODE_SECTION(DTMFD_KASATKA_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(DTMFD_KASATKA_free,       ".text:algFree")
#pragma CODE_SECTION(DTMFD_KASATKA_initObj,    ".text:algInit")
#pragma CODE_SECTION(DTMFD_KASATKA_control,    ".text:algControl")
#pragma CODE_SECTION(DTMFD_KASATKA_init,       ".text:init")
#pragma CODE_SECTION(DTMFD_KASATKA_exit,       ".text:exit")

// The DTMFD_KASATKA_moved routine is only used if the DTMFD_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
#pragma CODE_SECTION(DTMFD_KASATKA_moved,      ".text:algMoved")



// The DTMFD_KASATKA_activate & DTMFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(DTMFD_KASATKA_activate,   ".text:algActivate")
#pragma CODE_SECTION(DTMFD_KASATKA_deactivate, ".text:algDeactivate")


#include <std.h>
#include <limits.h>
#include "idtmfd.h"
#include "dtmfd_kasatka.h"

#include "dtmfdcfg.h"	// bios

#define MTAB_NRECS 3	// orig. 1\

#define HISTORY_TABN	1
#define FIELD_TABN 		2


/*
//============================================================================
// DTMFD_KASATKA_Obj
*/
typedef struct DTMFD_KASATKA_Obj {
    IALG_Obj        alg;   /* MUST be first field of all DTMFD objs */

    /* TODO: add custom fields here */
    DTMFD_KONST	*konst;
    
   	DTMFD_MBLK	*history;
   	DTMFD_MBLK	*field;   	
   	
} DTMFD_KASATKA_Obj;

// --- interior used function

// ---
// *** sample-Q's function.

void incPtr(MdInt * ptr)
{
	*ptr = (*ptr+1) %  MaxQueueItem;
}

// ---
void initDetectionBuffer(IDTMFD_Handle handle, MdInt v)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;

	Int i;
	
	for (i=0; i<MaxQueueItem; i++)
	{
		DTMFD->field->detectionBuffer[i] = v;
	}
	
	
	DTMFD->field->sPtr=0;
	DTMFD->field->ePtr=1;	
		//LOG_printf(&trace,"DetectionBuffer init'ed");	
}

// ---

// to enqueue data(sample)
MdInt enqueue(IDTMFD_Handle handle, MdInt * data, MdInt force)
{

    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
	if (DTMFD->field->sPtr == DTMFD->field->ePtr)
	{//full queue
		if (force)
		{//force mode, 
			DTMFD->field->detectionBuffer[DTMFD->field->ePtr] = *data;
			incPtr(&(DTMFD->field->ePtr));
			incPtr(&(DTMFD->field->sPtr));
			return (2);	// data's enqueued anormally
		}
		return (0);	// data's not be enqueued
	}else
	{//queue ready
		DTMFD->field->detectionBuffer[DTMFD->field->ePtr] = *data;
		incPtr(&(DTMFD->field->ePtr));
		return (1);	// data's enqueued normally 				
	}
}

//de-Q sample
MdInt dequeue(IDTMFD_Handle handle, MdInt * dest)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
	if (((DTMFD->field->sPtr+1) %  MaxQueueItem) == DTMFD->field->ePtr)
	{// empty queue
		return (0);// empty queue
	}else
	{
		incPtr(&(DTMFD->field->sPtr));
		*dest = DTMFD->field->detectionBuffer[DTMFD->field->sPtr];	
		return (1);//	done
	}	
}


// ---
// *** StateQ's function

MdInt enqStateQ(IDTMFD_Handle handle, MdInt data)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
	if (DTMFD->field->state_sPtr == DTMFD->field->state_ePtr)
	{//full queue
		DTMFD->field->stateQueue[DTMFD->field->state_ePtr] = data;
		DTMFD->field->state_ePtr = (DTMFD->field->state_ePtr+1) %  MaxStateQueueItem;
		DTMFD->field->state_sPtr = (DTMFD->field->state_sPtr+1) %  MaxStateQueueItem;
		return (2);	// data's enqueued anormally
	}else
	{//queue ready
		DTMFD->field->stateQueue[DTMFD->field->state_ePtr] = data;
		DTMFD->field->state_ePtr = (DTMFD->field->state_ePtr+1) %  MaxStateQueueItem;
		return (1);	// data's enqueued normally 				
	}
}

// ---

MdInt sumStateQ(IDTMFD_Handle handle)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;

	MdInt tmp=0;
	Int i;
	
	for(i=0; i< MaxStateQueueItem; i++)
	{tmp += DTMFD->field->stateQueue[i];}
	
	 return (tmp); 
}

// ---

// ----
// *** Power checking function

// common log. function, powered by Knuth's log alg.
Int dtmf_detect_kLog10(IDTMFD_Handle handle, Uns x)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
	Uns z;
	Int y,k;

	if (0 == x) return (-2147483648);	// assume for -infinity value

	for (k=0; k <32; k++)
	{
		if (x & 0x80000000) break;
		x <<= 1;
	}

	y = DTMF_DETECT_LOG_2N_TAB[k];

	//begin Knuth's log alg.
	z = x >> 1;
	for (k=1; k<27;)
	{
		if (0x80000000 == x) break;

		if ((x-z) < 0x80000000)
		{
			z >>= 1;
			k++;
		}else
		{
			x -= z;
			z = x >> k;
			y += DTMF_DETECT_LOG_2NM1_TAB[k];
		}
	} // for

	return (y);
} //int kLog10(...) 


// ---

// calculate power in dBm0
Int dtmf_detect_dBm0(IDTMFD_Handle handle, Uns avgsq, Int refm0)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
	return ((dtmf_detect_kLog10(handle, avgsq << 5)-refm0)/DTMF_DETECT_LSCALE);
} //int calc_dBm0(...)

// ---
// *** GZ Operation Function

MdInt detectF(IDTMFD_Handle handle, MdInt *data, MdInt num_data)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;

	Int u0;			// used in gz alg
	Int u1;			// used in gz alg
	Uns power;		// used in gz alg
	Int t;			// tmp var, used in gz alg
	Int in;			// each sample
	Int mx = 0;
	Int mulp = 1000;
	MdInt retv = 0;
	Int tmp;
	Uns powa[8];	// for 1209, 1336, 1477, 1633, 697, 770, 852, 941
	Uns tmpw;
	Uns avgsq=0;

	MdInt i,j,k;	
				//num_data -= 50;
			LOG_printf(&log_gz,"=====");
			
	mx = 0;
	k = DTMFD->field->sPtr;
	incPtr(&k);
	for (j=0;j<num_data-1;j++)	//find log pow
	{
		tmp = data[k];
		k++;
		
		if (tmp>mx) {mx = tmp;}			
		avgsq += tmp*tmp;
		
		if (k >= num_data) {k = 0;}
	}
		avgsq = avgsq/num_data;
		tmp = dtmf_detect_dBm0(handle, avgsq, DTMF_DETECT_M0_A_LAW);
		
		if ((tmp >= DTMF_DETECT_DBM0_OPRMIN) && (tmp <= DTMF_DETECT_DBM0_OPRMAX))
		{
			// go on
		}else	{
					return (0);	// reject due to not in range of accepted log pow
				}		
				
	mulp = 4095*1000/mx;	// may be change *1000 with <<10 operator.			
			
	for (i=0;i<8;i++)
	{
		k = DTMFD->field->sPtr;
		incPtr(&k);
		
		u0 = u1 = 0;
		for (j=0;j<num_data-1;j++)	// step thru each sample inputted by invoke fn.
		{
			tmp = data[k];
			k++;
						
			in = (tmp*mulp/1000) >> 5;	//to drop +-4095 -> +-127
			t = u0;
			u0 = in + ((DTMF_DETECT_COEFF_TAB[i]*u0)>>17) -u1;		// /10000
			u1 = t;
			
			if (k >= num_data) {k = 0;}			
		}
		power = u0*u0 + u1*u1 - ((DTMF_DETECT_COEFF_TAB[i]*u0*u1)>>17);	// /10000
		if (i<4)
		{// hi-group
			if ((power > THRESHOLDf)) {powa[i]=power;}else{powa[i]=0;}		
		}else
		{// low-group
			if ((power > THRESHOLDg)) {powa[i]=power;}else{powa[i]=0;}
		}
			LOG_printf(&log_gz,"gz pow= %0.3fM",power/1000000.0);
		
		/*
		if ((power > THRESHOLDg))	// gz pow must exceed THRESHOLD value
		{
			retv += 1 << (7-i);
			if (2<=++cnt) { LOG_printf(&log_gz,"mx= %d ret= %x",mx,retv); return (retv);}
		}
		*/			
	}//i
	
		tmpw = 0;j=-1;
		for (i=0;i<4;i++)
		{
			if ((powa[i]>tmpw)&&(powa[i]!=0)) {tmpw = powa[i];j=i;}
		}
		if ((j>=0)&&(mx > THRESHOLDv))
		{
			retv += 1 << (7-j);
		}
		//for (i=0;i<4;i++)
		//{if (powa[i]==tmpw) {retv += 1 << (7-i);}}
	
		tmpw = 0;j=-1;
		for (i=4;i<8;i++)
		{
			if ((powa[i]>tmpw)&&(powa[i]!=0)) {tmpw = powa[i];j=i;}
		}
		if ((j>=0)&&(mx > THRESHOLDv))
		{
			retv += 1 << (7-j);
		}		
		//for (i=4;i<8;i++)
		//{if (powa[i]==tmpw) {retv += 1 << (7-i);}}						
							
											LOG_printf(&log_gz,"=====");
			LOG_printf(&log_gz,"mx= %d ret= %x",mx,retv);
	return (retv);
}

// ---
// ***  interpret the result from GZ-OF
MdInt chk_dtmf(IDTMFD_Handle handle, MdInt *data, MdInt num_data)
{

	switch (detectF(handle, data,num_data))
	{
		case 0x41:
			return (0);
		case 0x88:
			return (1);
		case 0x48:
			return (2);
		case 0x28:
			return (3);
		case 0x84:
			return (4);
		case 0x44:
			return (5);
		case 0x24:
			return (6);
		case 0x82:
			return (7);
		case 0x42:
			return (8);
		case 0x22:
			return (9);
		case 0x81:
			return (10);	//*
		case 0x21:
			return (11);	//#
		case 0x18:
			return (12);	//A
		case 0x14:
			return (13);	//B
		case 0x12:
			return (14);	//C
		case 0x11:
			return (15);	//D
		default:
			return (100);	//unknown digit
	}						
								
}

// ---

//---
// *** to check that the singal is pause or not
MdInt isNotPause(IDTMFD_Handle handle, MdInt * samp)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
	Int tmp;
	Int tmp2;
	Uns avgsq=0;
	
	///*
	if (DTMFD->field->lastItem_sPtr == DTMFD->field->lastItem_ePtr)
	{//full queue
		DTMFD->field->lastItem[DTMFD->field->lastItem_ePtr] = *samp;
		DTMFD->field->lastItem_ePtr = (DTMFD->field->lastItem_ePtr+1) %  MaxLastItem;
		DTMFD->field->lastItem_sPtr = (DTMFD->field->lastItem_sPtr+1) %  MaxLastItem;
	}else
	{//queue ready
		DTMFD->field->lastItem[DTMFD->field->lastItem_ePtr] = *samp;
		DTMFD->field->lastItem_ePtr = (DTMFD->field->lastItem_ePtr+1) %  MaxLastItem;				
	}
	
	for (tmp=0; tmp<MaxLastItem; tmp++)
	{
		avgsq += DTMFD->field->lastItem[tmp] * DTMFD->field->lastItem[tmp];
	}
	avgsq = avgsq / MaxLastItem;
	
	tmp = dtmf_detect_dBm0(handle, avgsq,DTMF_DETECT_M0_A_LAW);
	
		tmp2 = DTMF_DETECT_DBM0_NONOPRMAX;
	
	if (tmp > tmp2)	// threshold for non-pause
	{
		return (1);	// non-pause sample
	}else
	{
		return (0);	// pause sample
	}	
	
}

// ---


/*
//============================================================================
// DTMFD_KASATKA_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the DTMFD_KASATKA processing methods.
*/
// The DTMFD_KASATKA_activate & DTMFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void DTMFD_KASATKA_activate(IALG_Handle handle)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
    // TODO: implement algActivate
    // copy history to field
    memcpy((Void *) DTMFD->field, (Void *) DTMFD->history, sizeof(DTMFD_MBLK));
}

/*
//============================================================================
// DTMFD_KASATKA_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a DTMFD_KASATKA_Obj structure.
*/
Int DTMFD_KASATKA_alloc(const IALG_Params *DTMFDParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IDTMFD_Params *params = (Void *)DTMFDParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IDTMFD_PARAMS;  /* set default parameters */
    }

    /* Request memory for DTMFD object */
    memTab[0].size = sizeof(DTMFD_KASATKA_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_EXTERNAL;
    memTab[0].attrs = IALG_PERSIST;
        
    ///*
   	// mem. tab for history var., edited by Yury
    memTab[HISTORY_TABN].size = sizeof(DTMFD_MBLK);
    memTab[HISTORY_TABN].alignment = 0;
    memTab[HISTORY_TABN].space = IALG_EXTERNAL;
    memTab[HISTORY_TABN].attrs = IALG_PERSIST;
    //*/      
    
    ///*
   	// mem. tab for field var., edited by Yury
    memTab[FIELD_TABN].size = sizeof(DTMFD_MBLK);
    memTab[FIELD_TABN].alignment = 0;
    memTab[FIELD_TABN].space = IALG_DARAM0;
    memTab[FIELD_TABN].attrs = IALG_SCRATCH;
    //*/
    
    return (MTAB_NRECS);
}

/*
//============================================================================
// DTMFD_KASATKA_control
//
// Control our object's parameters while the algorithm is running
*/

Int DTMFD_KASATKA_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    IDTMFD_Status *sPtr = (IDTMFD_Status *)status;	
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;

    switch ((IDTMFD_Cmd)cmd) {

       case IDTMFD_GETSTATUS:

            return(IALG_EOK);

       case IDTMFD_SETSTATUS:

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}


/*
//============================================================================
// DTMFD_KASATKA_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the DTMFD_KASATKA processing methods to persistent memory.
*/
// The DTMFD_KASATKA_activate & DTMFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void DTMFD_KASATKA_deactivate(IALG_Handle handle)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    
    // TODO: implement algDeactivate
    // copy field to history
    memcpy((Void *) DTMFD->history, (Void *) DTMFD->field, sizeof(DTMFD_MBLK));    
}

/*
//============================================================================
// DTMFD_KASATKA_exit
//
// Exit the DTMFD_KASATKA module as a whole.
 */
Void DTMFD_KASATKA_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// DTMFD_KASATKA_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// DTMFD_KASATKA_alloc operation above.
*/
Int DTMFD_KASATKA_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;

    n = DTMFD_KASATKA_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[0].size = sizeof(DTMFD_KASATKA_Obj);    
    
    memTab[HISTORY_TABN].base = DTMFD->history;
    memTab[HISTORY_TABN].size = sizeof(DTMFD_MBLK);
    
    memTab[FIELD_TABN].base = DTMFD->field;
    memTab[FIELD_TABN].size = sizeof(DTMFD_MBLK);    

    return (n);
}

/*
//============================================================================
// DTMFD_KASATKA_init
//
// Initialize the DTMFD_KASATKA module as a whole.
*/
Void DTMFD_KASATKA_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// DTMFD_KASATKA_initObj
//
// Initialize the memory allocated for our instance.
*/
Int DTMFD_KASATKA_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *DTMFDParams)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    const IDTMFD_Params *params = (Void *)DTMFDParams;

    if(params == NULL){
        params = &IDTMFD_PARAMS; /* set default parameters */
    }
    
    if (params->ptr2konst == NULL){return (IALG_EFAIL);}


    /* TODO: Implement any additional algInit desired */
    
    DTMFD->history = memTab[HISTORY_TABN].base;
    DTMFD->field = memTab[FIELD_TABN].base;
    
    DTMFD->konst = params->ptr2konst;
    
    DTMFD->field->sPtr = 0;
   	DTMFD->field->ePtr = 1;  
   	
   	DTMFD->field->state_sPtr = 0;
   	DTMFD->field->state_ePtr = 1;
   	
   	DTMFD->field->lastItem_sPtr = 0;
   	DTMFD->field->lastItem_ePtr = 1;
   	
   	DTMFD->field->cntS = 0;
   	DTMFD->field->cntZ = 0;
	DTMFD->field->cntLastS = 0;
	DTMFD->field->cntLastZ = 0;
	
	// copy field to history
    memcpy((Void *) DTMFD->history, (Void *) DTMFD->field, sizeof(DTMFD_MBLK));	
    
    return (IALG_EOK);
}

/*
//============================================================================
// DTMFD_KASATKA_moved
//
// Adjust any data pointers that has been moved by the client.
*/
// The DTMFD_KASATKA_moved routine is only used if the DTMFD_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
Void DTMFD_KASATKA_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *DTMFDParams)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;
    const IDTMFD_Params *params = (Void *)DTMFDParams;
    
    if (params != NULL)
    {
    	DTMFD->konst = params->ptr2konst;
    }
    
    DTMFD->field = memTab[FIELD_TABN].base;
    DTMFD->history = memTab[HISTORY_TABN].base;
        
}

/*
//============================================================================
// DTMFD_KASATKA_apply
// KASATKA's implementation of the apply operation.
// Custom fields of the DTMFD_KASATKA_Obj may be accessed as follows:
*/
XDAS_Void DTMFD_KASATKA_apply(IDTMFD_Handle handle, MdInt * samp, MdInt * result)
{
    DTMFD_KASATKA_Obj *DTMFD = (Void *)handle;

    /* TODO: implement apply */
    
	MdInt sumq;
		
	if (isNotPause(handle,samp))
	{		
		enqStateQ(handle,1);
		//LOG_printf(&trace,"is not pause");	
		enqueue(handle,samp,1);
		DTMFD->field->cntS++;	
		DTMFD->field->cntLastS++;
		
		sumq = sumStateQ(handle);
		if (sumq > 57) 
		{
		//LOG_printf(&trace,">40 ,%d",sumq);
			//if ((DTMFD->field->cntS>200) && (DTMFD->field->cntZ > 20)) {LOG_printf(&trace,">40 sumq=%d Z=%d",sumq, DTMFD->field->cntZ);}				
			if (DTMFD->field->cntZ > DTMF_IntMax+24)
			{
				//if (cntS>200) {LOG_printf(&trace,">40 sumq=%d Z=%d",sumq, cntZ);}			
				DTMFD->field->cntS = 57;
				
				//resetPtr();	// edit	
			}
			DTMFD->field->cntZ=0;			
		}
		
		DTMFD->field->cntLastZ = 0;
	}else
	{
		enqStateQ(handle,0);
				
		DTMFD->field->cntZ++;
		DTMFD->field->cntLastZ++;
										
		DTMFD->field->cntLastS = 0;
	}	
		

	if (DTMFD->field->cntZ >= DTMF_SigPauseMin)	//count zero > std then get previous signal (compensate +2)
	{
		//LOG_printf(&trace,"cntZ=%d cntS=%d",hmem->cntZ,hmem->cntS);	
		//LOG_printf(&trace,">sig non min");	
		if (DTMFD->field->cntS+16 >= DTMF_SigOprMin)	// compensate 2 sample-count
		{
			//LOG_printf(&trace,">sig min");		
			if (DTMFD->field->cntZ + DTMFD->field->cntS + 16 >= DTMF_Velocity)	// calculate velocity, conpensate +2 +12 +25 samp-cnt
			{// pass velocity constrain
						
				//sortDetectionBuffer(handle);
				*result = chk_dtmf(handle, DTMFD->field->detectionBuffer,MaxQueueItem);
					//if (*res<100) {
						//LOG_printf(&trace,"velo pass Z=%d S=%d",hmem->cntZ, hmem->cntS);	
						//LOG_printf(&trace,"lastZ=%d lastS=%d",hmem->cntLastZ, hmem->cntLastS);				
					//}					
				//initDetectionBuffer(handle,0);	
				DTMFD->field->cntS = DTMFD->field->cntLastS = 0;	//clear for new count			
				DTMFD->field->cntZ = DTMFD->field->cntLastZ = 0;	//clear for new count
				
				//resetPtr();	// edit																																			
			}else
			{// don't pass velocity constrain
			}

		}else
		{// duration of dtmf is lower than standardization		
				//LOG_printf(&trace,"sig miss");			
				//initDetectionBuffer(handle,0);			
				DTMFD->field->cntS = DTMFD->field->cntLastS = 0;
				DTMFD->field->cntZ = DTMFD->field->cntLastZ = 0;
				*result = 102;				
				//resetPtr();	// edit					
		}
	}else
	{// duration of pause is lower than standardization
	}//else

}
