/*
//============================================================================
//
//    FILE NAME : IDTMFD.c
//
//    ALGORITHM : DTMFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iDTMFD.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 06 January 2005
//    Creation Time: 02:35 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "idtmfd.h"

/*
// ===========================================================================
// DTMFD_PARAMS
//
// This constant structure defines the default parameters for DTMFD objects
*/
IDTMFD_Params IDTMFD_PARAMS = {
    sizeof(IDTMFD_Params),
    NULL,
};
