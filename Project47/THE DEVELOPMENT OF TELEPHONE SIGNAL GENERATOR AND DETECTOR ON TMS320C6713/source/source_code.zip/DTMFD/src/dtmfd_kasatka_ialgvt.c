/*
//============================================================================
//
//    FILE NAME : DTMFD_KASATKA_ialgvt.c
//
//    ALGORITHM : DTMFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the DTMFD_KASATKA module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Thu - 06 January 2005
//    Creation Time: 02:35 PM
//
//============================================================================
*/

#include <std.h>
#include "idtmfd.h"

#include "dtmfd_kasatka.h"

extern Int  DTMFD_KASATKA_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  DTMFD_KASATKA_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  DTMFD_KASATKA_free(IALG_Handle, IALG_MemRec *);
extern Int  DTMFD_KASATKA_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  DTMFD_KASATKA_numAlloc(Void);

// The DTMFD_KASATKA_moved routine is only used if the DTMFD_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
extern Void DTMFD_KASATKA_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);


// The DTMFD_KASATKA_activate & DTMFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
extern Void DTMFD_KASATKA_activate(IALG_Handle);
extern Void DTMFD_KASATKA_deactivate(IALG_Handle);

extern XDAS_Void DTMFD_KASATKA_apply(IDTMFD_Handle handle, MdInt * samp, MdInt * result);

#define IALGFXNS \
    &DTMFD_KASATKA_IALG,       /* module ID                            */ \
    DTMFD_KASATKA_activate,    /* activate   (NULL => not suported)    */ \
    DTMFD_KASATKA_alloc,       /* algAlloc                             */ \
    DTMFD_KASATKA_control,     /* control    (NULL => not suported)    */ \
    DTMFD_KASATKA_deactivate,  /* deactivate (NULL => not suported)    */ \
    DTMFD_KASATKA_free,        /* free                                 */ \
    DTMFD_KASATKA_initObj,     /* init                                 */ \
    DTMFD_KASATKA_moved,       /* moved      (NULL => not suported)    */ \
    NULL                       /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// DTMFD_KASATKA_IDTMFD
//
// This structure defines KASATKA's implementation of the IDTMFD interface
// for the DTMFD_KASATKA module.
*/
IDTMFD_Fxns DTMFD_KASATKA_IDTMFD = {	/* module_vendor_interface */
    IALGFXNS,
    DTMFD_KASATKA_apply,
};

/*
//============================================================================
// DTMFD_KASATKA_IALG
//
// This structure defines KASATKA's implementation of the IALG interface
// for the DTMFD_KASATKA module.
*/
#ifdef _TI_
asm("_DTMFD_KASATKA_IALG .set _DTMFD_KASATKA_IDTMFD");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns DTMFD_KASATKA_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
