@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x r2mfg.cmd
erase r2mfg_kasatka.l67
erase r2mfg.l67
ar6x -r r2mfg_kasatka.l67 ..\Release\r2mfg.o67
ar6x -r r2mfg.l67 ..\Release\r2mfg.obj
