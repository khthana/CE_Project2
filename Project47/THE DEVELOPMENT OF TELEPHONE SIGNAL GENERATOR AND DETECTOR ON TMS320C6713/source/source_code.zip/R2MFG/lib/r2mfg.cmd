-r
-m ..\Release\r2mfg.map
-o ..\Release\r2mfg.o67
-h
-g _R2MFG_KASATKA_IR2MFG
-g _R2MFG_KASATKA_IALG
-g _R2MFG_KASATKA_alloc
-g _R2MFG_KASATKA_free
-g _R2MFG_KASATKA_initObj
-g _R2MFG_KASATKA_control
-g _R2MFG_KASATKA_init
-g _R2MFG_KASATKA_exit
-g _R2MFG_KASATKA_apply

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\R2MFG_KASATKA_ialg.obj
..\Release\R2MFG_KASATKA_ialgvt.obj
..\Release\iR2MFG.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
/*
// The R2MFG_KASATKA_activate & R2MFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
