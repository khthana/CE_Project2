-l r2mfgcfg.cmd
-l algrf.l62

