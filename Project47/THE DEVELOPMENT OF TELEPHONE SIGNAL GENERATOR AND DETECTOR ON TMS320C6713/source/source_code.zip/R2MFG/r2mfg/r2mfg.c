/*
//============================================================================
//
//    FILE NAME : R2MFG.c
//
//    ALGORITHM : R2MFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in R2MFG.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 29 November 2004
//    Creation Time: 02:24 PM
//
//============================================================================
*/

#pragma CODE_SECTION(R2MFG_create,  ".text:create")
#pragma CODE_SECTION(R2MFG_control, ".text:control")
#pragma CODE_SECTION(R2MFG_delete,  ".text:delete")
#pragma CODE_SECTION(R2MFG_init,    ".text:init")
#pragma CODE_SECTION(R2MFG_exit,    ".text:exit")

#include <std.h>
#include <algrf.h>
#include <xdas.h>
#include "r2mfg.h"

/*
// ===========================================================================
// R2MFG_create
//
//  Create an R2MFG instance object (using parameters specified by prms)
*/
R2MFG_Handle R2MFG_create(const IR2MFG_Fxns *fxns, const R2MFG_Params *prms)
{
    return ((R2MFG_Handle)ALGRF_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// R2MFG_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int R2MFG_control(R2MFG_Handle handle, R2MFG_Cmd cmd, R2MFG_Status *status)
{
    return (ALGRF_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// R2MFG_delete
//
// Delete the R2MFG instance object specified by handle
*/
Void R2MFG_delete(R2MFG_Handle handle)
{
    ALGRF_delete((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// R2MFG_init
//
// R2MFG module initialization
*/
Void  R2MFG_init(Void)
{
}

/*
// ===========================================================================
// R2MFG_exit
//
// R2MFG module finalization
*/
Void  R2MFG_exit(Void)
{
}

/*
// ===========================================================================
// R2MFG_apply
*/
MdInt R2MFG_apply(R2MFG_Handle handle)
{
	MdInt tmp;
    ALGRF_activate((ALGRF_Handle)handle);

    tmp = handle->fxns->apply(handle);

    ALGRF_deactivate((ALGRF_Handle)handle);
    
    return (tmp);
}

// ---

XDAS_Void R2MFG_setDigit(R2MFG_Handle handle, MdInt digit)
{
    ALGRF_activate((ALGRF_Handle)handle);
	handle->fxns->setDigit(handle,digit);
    ALGRF_deactivate((ALGRF_Handle)handle);
}

// ---

XDAS_Void R2MFG_setState(R2MFG_Handle handle, MdInt state)
{
    ALGRF_activate((ALGRF_Handle)handle);
	handle->fxns->setState(handle,state);
    ALGRF_deactivate((ALGRF_Handle)handle);
}

// ---
