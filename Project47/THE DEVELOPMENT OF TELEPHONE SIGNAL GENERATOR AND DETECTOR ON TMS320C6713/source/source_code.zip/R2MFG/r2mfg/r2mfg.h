/*
//============================================================================
//
//    FILE NAME : R2MFG.h
//
//    ALGORITHM : R2MFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                R2MFG module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 29 November 2004
//    Creation Time: 02:24 PM
//
//============================================================================
*/

#ifndef R2MFG_
#define R2MFG_

#include <algrf.h>
#include <xdas.h>
#include "ir2mfg.h"

/*
// ===========================================================================
// R2MFG_Handle
//
// This pointer is used to reference all R2MFG instance objects
*/
typedef struct IR2MFG_Obj *R2MFG_Handle;

/*
// ===========================================================================
// R2MFG_Params
//
// This structure defines the creation parameters for all R2MFG objects
*/
typedef IR2MFG_Params R2MFG_Params;

/*
// ===========================================================================
// R2MFG_PARAMS
//
// This structure defines the default creation parameters for R2MFG objects
*/
#define R2MFG_PARAMS   IR2MFG_PARAMS

/*
// ===========================================================================
// R2MFG_Status
//
// This structure defines the real-time parameters for R2MFG objects
*/
typedef struct IR2MFG_Status   R2MFG_Status;

/*
// ===========================================================================
// R2MFG_Cmd
//
// This typedef defines the control commands R2MFG objects
*/
typedef IR2MFG_Cmd   R2MFG_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define R2MFG_GETSTATUS    IR2MFG_GETSTATUS
#define R2MFG_SETSTATUS    IR2MFG_SETSTATUS

/*
// ===========================================================================
// R2MFG_create
//
// Create an R2MFG instance object (using parameters specified by prms)
*/
extern R2MFG_Handle R2MFG_create(const IR2MFG_Fxns *fxns, const R2MFG_Params *prms);

/*
// ===========================================================================
// R2MFG_control
//
// Get, set, and change the parameters of the R2MFG function (using parameters specified by status).
*/
extern Int R2MFG_control(R2MFG_Handle handle, R2MFG_Cmd cmd, R2MFG_Status *status);

/*
// ===========================================================================
// R2MFG_delete
// Delete the R2MFG instance object specified by handle
*/
extern Void R2MFG_delete(R2MFG_Handle handle);

/*
// ===========================================================================
// R2MFG_apply
*/
extern MdInt R2MFG_apply(R2MFG_Handle handle);

#endif	/* R2MFG_ */
