/*
//============================================================================
//
//    FILE NAME : IR2MFG.c
//
//    ALGORITHM : R2MFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iR2MFG.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 29 November 2004
//    Creation Time: 02:24 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "ir2mfg.h"

/*
// ===========================================================================
// R2MFG_PARAMS
//
// This constant structure defines the default parameters for R2MFG objects
*/
IR2MFG_Params IR2MFG_PARAMS = {
    sizeof(IR2MFG_Params),
    
    NULL,	// *ptr2konst    
    NULL,	// *target_array
    0,		// array_elem
    55,		// percent_pow
};
