/*
//============================================================================
//
//    FILE NAME : R2MFG_KASATKA_ialgvt.c
//
//    ALGORITHM : R2MFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the R2MFG_KASATKA module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 29 November 2004
//    Creation Time: 02:24 PM
//
//============================================================================
*/

#include <std.h>
#include "ir2mfg.h"

#include "r2mfg_kasatka.h"

extern Int  R2MFG_KASATKA_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  R2MFG_KASATKA_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  R2MFG_KASATKA_free(IALG_Handle, IALG_MemRec *);
extern Int  R2MFG_KASATKA_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  R2MFG_KASATKA_numAlloc(Void);

// The R2MFG_KASATKA_moved routine is only used if the R2MFG_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
extern Void R2MFG_KASATKA_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);


// The R2MFG_KASATKA_activate & R2MFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
extern Void R2MFG_KASATKA_activate(IALG_Handle);
extern Void R2MFG_KASATKA_deactivate(IALG_Handle);

extern MdInt R2MFG_KASATKA_apply(IR2MFG_Handle handle);

extern XDAS_Void R2MFG_KASATKA_setDigit(IR2MFG_Handle handle, MdInt digit);
extern XDAS_Void R2MFG_KASATKA_setState(IR2MFG_Handle handle, MdInt state);

#define IALGFXNS \
    &R2MFG_KASATKA_IALG,       /* module ID                            */ \
    R2MFG_KASATKA_activate,    /* activate   (NULL => not suported)    */ \
    R2MFG_KASATKA_alloc,       /* algAlloc                             */ \
    R2MFG_KASATKA_control,     /* control    (NULL => not suported)    */ \
    R2MFG_KASATKA_deactivate,  /* deactivate (NULL => not suported)    */ \
    R2MFG_KASATKA_free,        /* free                                 */ \
    R2MFG_KASATKA_initObj,     /* init                                 */ \
    R2MFG_KASATKA_moved,       /* moved      (NULL => not suported)    */ \
    NULL                       /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// R2MFG_KASATKA_IR2MFG
//
// This structure defines KASATKA's implementation of the IR2MFG interface
// for the R2MFG_KASATKA module.
*/
IR2MFG_Fxns R2MFG_KASATKA_IR2MFG = {	/* module_vendor_interface */
    IALGFXNS,
    R2MFG_KASATKA_apply,
    R2MFG_KASATKA_setDigit,
    R2MFG_KASATKA_setState,
};

/*
//============================================================================
// R2MFG_KASATKA_IALG
//
// This structure defines KASATKA's implementation of the IALG interface
// for the R2MFG_KASATKA module.
*/
#ifdef _TI_
asm("_R2MFG_KASATKA_IALG .set _R2MFG_KASATKA_IR2MFG");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns R2MFG_KASATKA_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
