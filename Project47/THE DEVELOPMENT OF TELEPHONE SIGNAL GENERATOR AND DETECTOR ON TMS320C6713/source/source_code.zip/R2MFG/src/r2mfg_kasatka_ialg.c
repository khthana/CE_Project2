/*
//============================================================================
//
//    FILE NAME : R2MFG_KASATKA_ialg.c
//
//    ALGORITHM : R2MFG
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the R2MFG_KASATKA.h interface; KASATKA's
//                implementation of the IR2MFG interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Mon - 29 November 2004
//    Creation Time: 02:24 PM
//
//============================================================================
*/

#pragma CODE_SECTION(R2MFG_KASATKA_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(R2MFG_KASATKA_free,       ".text:algFree")
#pragma CODE_SECTION(R2MFG_KASATKA_initObj,    ".text:algInit")
#pragma CODE_SECTION(R2MFG_KASATKA_control,    ".text:algControl")
#pragma CODE_SECTION(R2MFG_KASATKA_init,       ".text:init")
#pragma CODE_SECTION(R2MFG_KASATKA_exit,       ".text:exit")

// The R2MFG_KASATKA_moved routine is only used if the R2MFG_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
#pragma CODE_SECTION(R2MFG_KASATKA_moved,      ".text:algMoved")


// The R2MFG_KASATKA_activate & R2MFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(R2MFG_KASATKA_activate,   ".text:algActivate")
#pragma CODE_SECTION(R2MFG_KASATKA_deactivate, ".text:algDeactivate")


#include <std.h>
#include <limits.h>
#include "ir2mfg.h"
#include "r2mfg_kasatka.h"

//#include "r2mfg_mblk.h"

#define MTAB_NRECS 		3	//orig. 1, changed by Yury
#define HISTORY_TABN	1
#define FIELD_TABN		2

/*
//============================================================================
// R2MFG_KASATKA_Obj
*/
typedef struct R2MFG_KASATKA_Obj {
    IALG_Obj        alg;   /* MUST be first field of all R2MFG objs */
    
    /* TODO: add custom fields here */
	R2MFG_KONST 	*konst;    
	
	R2MFG_MBLK		*field;	
	R2MFG_MBLK		*history;	

} R2MFG_KASATKA_Obj;


// --- internal-used function

XDAS_Void gen_r2mf_signal(IR2MFG_Handle handle, MdInt num_g)
{
	R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;	

    MdInt outs;									// tmp for each samples
    Int tmp;
    Uns cs1= R2MFG->field->gen_r2mf_acs1;
    Uns cs2= R2MFG->field->gen_r2mf_acs2;		// accumulative step count
           	
    for (; num_g > 0; num_g--)
    {
        tmp = (R2MFG_SINE_TAB[(cs1>>10)%R2MFG_SINE_TAB_ELEM] + R2MFG_SINE_TAB[(cs2>>10)%R2MFG_SINE_TAB_ELEM]) >>1;
        tmp >>=3;
        
        tmp = tmp* (R2MFG->field->gen_r2mf_percentpow) /100;

		outs = tmp;	
	   	    				
		R2MFG->field->gen_r2mf_targetarray[R2MFG->field->gen_r2mf_arr_ptr++] = outs;
		
       	cs1 += R2MFG->field->gen_r2mf_step1;
        cs2 += R2MFG->field->gen_r2mf_step2;
    }

	
	R2MFG->field->gen_r2mf_acs1 = ((cs1>>10)%R2MFG_SINE_TAB_ELEM)<<10;
	R2MFG->field->gen_r2mf_acs2 = ((cs2>>10)%R2MFG_SINE_TAB_ELEM)<<10;
				
}

// ---

/*
//============================================================================
// R2MFG_KASATKA_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the R2MFG_KASATKA processing methods.
*/

// The R2MFG_KASATKA_activate & R2MFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void R2MFG_KASATKA_activate(IALG_Handle handle)
{
    R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;
    
    // TODO: implement algActivate
    // copy history to field
    memcpy((Void *) R2MFG->field, (Void *) R2MFG->history, sizeof(R2MFG_MBLK));        
}


/*
//============================================================================
// R2MFG_KASATKA_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a R2MFG_KASATKA_Obj structure.
*/
Int R2MFG_KASATKA_alloc(const IALG_Params *R2MFGParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IR2MFG_Params *params = (Void *)R2MFGParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IR2MFG_PARAMS;  /* set default parameters */
    }

    /* Request memory for R2MFG object */
    memTab[0].size = sizeof(R2MFG_KASATKA_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_EXTERNAL;
    memTab[0].attrs = IALG_PERSIST;
    
    
    // below is custom mem. tab. 
    // mem tab for history var. (edited by Yury)
    ///*
    memTab[HISTORY_TABN].size = sizeof(R2MFG_MBLK);
    memTab[HISTORY_TABN].alignment = 0;
    memTab[HISTORY_TABN].space = IALG_EXTERNAL;
    memTab[HISTORY_TABN].attrs = IALG_PERSIST;
    //*/    
    
    // mem tab for field var. (edited by Yury)
    ///*
    memTab[FIELD_TABN].size = sizeof(R2MFG_MBLK);
    memTab[FIELD_TABN].alignment = 0;
    memTab[FIELD_TABN].space = IALG_DARAM0;
    memTab[FIELD_TABN].attrs = IALG_SCRATCH;
    //*/    
    

    return (MTAB_NRECS);
}

/*
//============================================================================
// R2MFG_KASATKA_control
//
// Control our object's parameters while the algorithm is running
*/
Int R2MFG_KASATKA_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    //IR2MFG_Status *sPtr = (IR2MFG_Status *)status;	
    //R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;

    switch ((IR2MFG_Cmd)cmd) {

       case IR2MFG_GETSTATUS:

            return(IALG_EOK);

       case IR2MFG_SETSTATUS:

            return(IALG_EOK);            

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// R2MFG_KASATKA_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the R2MFG_KASATKA processing methods to persistent memory.
*/

// The R2MFG_KASATKA_activate & R2MFG_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void R2MFG_KASATKA_deactivate(IALG_Handle handle)
{
    R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;
    
    // TODO: implement algDeactivate
    // copy field to history
    memcpy((Void *) R2MFG->history, (Void *) R2MFG->field, sizeof(R2MFG_MBLK));          
}


/*
//============================================================================
// R2MFG_KASATKA_exit
//
// Exit the R2MFG_KASATKA module as a whole.
 */
Void R2MFG_KASATKA_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// R2MFG_KASATKA_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// R2MFG_KASATKA_alloc operation above.
*/
Int R2MFG_KASATKA_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;

    n = R2MFG_KASATKA_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[0].size = sizeof(R2MFG_KASATKA_Obj);    
    
    memTab[HISTORY_TABN].base = R2MFG->history;
    memTab[HISTORY_TABN].size = sizeof(R2MFG_MBLK);
    
    memTab[FIELD_TABN].base = R2MFG->field;
    memTab[FIELD_TABN].size = sizeof(R2MFG_MBLK);        

    return (n);
}

/*
//============================================================================
// R2MFG_KASATKA_init
//
// Initialize the R2MFG_KASATKA module as a whole.
*/
Void R2MFG_KASATKA_init(Void)
{
    /* TODO: implement module init */
    
    
}

/*
//============================================================================
// R2MFG_KASATKA_initObj
//
// Initialize the memory allocated for our instance.
*/
Int R2MFG_KASATKA_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *R2MFGParams)
{
    R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;
    const IR2MFG_Params *params = (Void *)R2MFGParams;

    if(params == NULL){
    	return (IALG_EFAIL);
        //params = &IR2MFG_PARAMS; /* set default parameters */
    }
    
    if(params->target_array == NULL) {return (IALG_EFAIL);}
	if(params->ptr2konst == NULL) {return (IALG_EFAIL);}
	if(params->ptr2konst->r2mfg_sine_tab == NULL) {return (IALG_EFAIL);}	
		
	
    /* TODO: Implement any additional algInit desired */
    
    R2MFG->history = memTab[HISTORY_TABN].base;
    R2MFG->field = memTab[FIELD_TABN].base;    
    
    R2MFG->konst = params->ptr2konst;
    
    R2MFG->field->gen_r2mf_targetarray = params->target_array;
    R2MFG->field->gen_r2mf_array_element = params->array_elem;
    R2MFG->field->gen_r2mf_percentpow = params->percent_pow;
    
    R2MFG->field->gen_r2mf_acs1 = 0;
	R2MFG->field->gen_r2mf_acs2 = 0;    
	
	R2MFG->field->gen_r2mf_state = 0;        
	
    // copy field to history
    memcpy((Void *) R2MFG->history, (Void *) R2MFG->field, sizeof(R2MFG_MBLK));      	
    
    return (IALG_EOK);
}

/*
//============================================================================
// R2MFG_KASATKA_moved
//
// Adjust any data pointers that has been moved by the client.
*/

// The R2MFG_KASATKA_moved routine is only used if the R2MFG_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
Void R2MFG_KASATKA_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *R2MFGParams)
{
    R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;
    const IR2MFG_Params *params = (Void *)R2MFGParams;
    
    if (params != NULL)
    {
    	R2MFG->konst = params->ptr2konst;
    }
    
    R2MFG->field = memTab[FIELD_TABN].base;
    R2MFG->history = memTab[HISTORY_TABN].base;    

}


/*
//============================================================================
// R2MFG_KASATKA_apply
// KASATKA's implementation of the apply operation.
// Custom fields of the R2MFG_KASATKA_Obj may be accessed as follows:
*/
MdInt R2MFG_KASATKA_apply(IR2MFG_Handle handle)
{
    R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;

    /* TODO: implement apply */       
    
    R2MFG->field->gen_r2mf_arr_ptr = 0;
	
	switch (R2MFG->field->gen_r2mf_state)
	{
		case 0:	// idle
			return (0);	// target array's not edited
		case 1:
			gen_r2mf_signal(handle, R2MFG->field->gen_r2mf_array_element);
			return (1);	// target array's edited
		default:
			R2MFG->field->gen_r2mf_state = 0;
			break;		
	}
		
	return (0);    //R2MFG->field->gen_r2mf_state
}

// ---

XDAS_Void R2MFG_KASATKA_setDigit(IR2MFG_Handle handle, MdInt digit)
{
	R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;

	MdInt tmp1,tmp2;
	tmp1 = digit & 0x000F;	// digit 1..15
	tmp2 = (digit & 0x00F0)>>4; 	// 0-fwd, 1-bwd
	
	R2MFG->field->gen_r2mf_currentDigit = digit;
	R2MFG->field->gen_r2mf_acs1 = 0;
	R2MFG->field->gen_r2mf_acs2 = 0;	
	
	switch (tmp2)
	{
		case 0:	// fwd
			R2MFG->field->gen_r2mf_step1 = R2MFG_FWD_A[tmp1];
			R2MFG->field->gen_r2mf_step2 = R2MFG_FWD_B[tmp1];			
			break;
		case 1:	// bwd
			R2MFG->field->gen_r2mf_step1 = R2MFG_BWD_A[tmp1];
			R2MFG->field->gen_r2mf_step2 = R2MFG_BWD_B[tmp1];		
			break;
		default:	// unknown
			R2MFG->field->gen_r2mf_state = 0;
			break;			
	}
	
}

// ---

XDAS_Void R2MFG_KASATKA_setState(IR2MFG_Handle handle, MdInt state)
{
	R2MFG_KASATKA_Obj *R2MFG = (Void *)handle;
	
	R2MFG->field->gen_r2mf_state = state;
}

// ---


    
    
