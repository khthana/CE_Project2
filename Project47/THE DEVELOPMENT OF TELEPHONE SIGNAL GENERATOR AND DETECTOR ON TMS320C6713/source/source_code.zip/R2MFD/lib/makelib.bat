@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x r2mfd.cmd
erase r2mfd_kasatka.l67
erase r2mfd.l67
ar6x -r r2mfd_kasatka.l67 ..\Release\r2mfd.o67
ar6x -r r2mfd.l67 ..\Release\r2mfd.obj
