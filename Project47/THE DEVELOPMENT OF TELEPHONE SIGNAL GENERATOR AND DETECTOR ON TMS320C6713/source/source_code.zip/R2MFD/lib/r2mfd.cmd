-r
-m ..\Release\r2mfd.map
-o ..\Release\r2mfd.o67
-h
-g _R2MFD_KASATKA_IR2MFD
-g _R2MFD_KASATKA_IALG
-g _R2MFD_KASATKA_alloc
-g _R2MFD_KASATKA_free
-g _R2MFD_KASATKA_initObj
-g _R2MFD_KASATKA_control
-g _R2MFD_KASATKA_init
-g _R2MFD_KASATKA_exit
-g _R2MFD_KASATKA_apply

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\R2MFD_KASATKA_ialg.obj
..\Release\R2MFD_KASATKA_ialgvt.obj
..\Release\iR2MFD.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
/*
// The R2MFD_KASATKA_activate & R2MFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
