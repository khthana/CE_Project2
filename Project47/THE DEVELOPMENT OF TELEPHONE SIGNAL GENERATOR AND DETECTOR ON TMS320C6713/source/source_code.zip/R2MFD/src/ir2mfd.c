/*
//============================================================================
//
//    FILE NAME : IR2MFD.c
//
//    ALGORITHM : R2MFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iR2MFD.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Tue - 04 January 2005
//    Creation Time: 09:23 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "ir2mfd.h"

/*
// ===========================================================================
// R2MFD_PARAMS
//
// This constant structure defines the default parameters for R2MFD objects
*/
IR2MFD_Params IR2MFD_PARAMS = {
    sizeof(IR2MFD_Params),
    
    NULL,
};
