/*
//============================================================================
//
//    FILE NAME : R2MFD_KASATKA_ialgvt.c
//
//    ALGORITHM : R2MFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the R2MFD_KASATKA module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Tue - 04 January 2005
//    Creation Time: 09:23 PM
//
//============================================================================
*/

#include <std.h>
#include "ir2mfd.h"

#include "r2mfd_kasatka.h"

extern Int  R2MFD_KASATKA_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  R2MFD_KASATKA_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  R2MFD_KASATKA_free(IALG_Handle, IALG_MemRec *);
extern Int  R2MFD_KASATKA_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  R2MFD_KASATKA_numAlloc(Void);

// The R2MFD_KASATKA_moved routine is only used if the R2MFD_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
extern Void R2MFD_KASATKA_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);


// The R2MFD_KASATKA_activate & R2MFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
extern Void R2MFD_KASATKA_activate(IALG_Handle);
extern Void R2MFD_KASATKA_deactivate(IALG_Handle);

extern XDAS_Void R2MFD_KASATKA_apply(IR2MFD_Handle handle, MdInt * samp, MdInt * result);

#define IALGFXNS \
    &R2MFD_KASATKA_IALG,       /* module ID                            */ \
    R2MFD_KASATKA_activate,    /* activate   (NULL => not suported)    */ \
    R2MFD_KASATKA_alloc,       /* algAlloc                             */ \
    R2MFD_KASATKA_control,     /* control    (NULL => not suported)    */ \
    R2MFD_KASATKA_deactivate,  /* deactivate (NULL => not suported)    */ \
    R2MFD_KASATKA_free,        /* free                                 */ \
    R2MFD_KASATKA_initObj,     /* init                                 */ \
    R2MFD_KASATKA_moved,   	   /* moved      (NULL => not suported)    */ \
    NULL                       /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// R2MFD_KASATKA_IR2MFD
//
// This structure defines KASATKA's implementation of the IR2MFD interface
// for the R2MFD_KASATKA module.
*/
IR2MFD_Fxns R2MFD_KASATKA_IR2MFD = {	/* module_vendor_interface */
    IALGFXNS,
    R2MFD_KASATKA_apply,
};

/*
//============================================================================
// R2MFD_KASATKA_IALG
//
// This structure defines KASATKA's implementation of the IALG interface
// for the R2MFD_KASATKA module.
*/
#ifdef _TI_
asm("_R2MFD_KASATKA_IALG .set _R2MFD_KASATKA_IR2MFD");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns R2MFD_KASATKA_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
