/*
//============================================================================
//
//    FILE NAME : R2MFD_KASATKA_ialg.c
//
//    ALGORITHM : R2MFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the R2MFD_KASATKA.h interface; KASATKA's
//                implementation of the IR2MFD interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Tue - 04 January 2005
//    Creation Time: 09:23 PM
//
//============================================================================
*/

#pragma CODE_SECTION(R2MFD_KASATKA_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(R2MFD_KASATKA_free,       ".text:algFree")
#pragma CODE_SECTION(R2MFD_KASATKA_initObj,    ".text:algInit")
#pragma CODE_SECTION(R2MFD_KASATKA_control,    ".text:algControl")
#pragma CODE_SECTION(R2MFD_KASATKA_init,       ".text:init")
#pragma CODE_SECTION(R2MFD_KASATKA_exit,       ".text:exit")

// The R2MFD_KASATKA_moved routine is only used if the R2MFD_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
#pragma CODE_SECTION(R2MFD_KASATKA_moved,      ".text:algMoved")


// The R2MFD_KASATKA_activate & R2MFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(R2MFD_KASATKA_activate,   ".text:algActivate")
#pragma CODE_SECTION(R2MFD_KASATKA_deactivate, ".text:algDeactivate")


#include <std.h>
#include <limits.h>
#include "ir2mfd.h"
#include "r2mfd_kasatka.h"

#define MTAB_NRECS 3	// orig 1

#define HISTORY_TABN	1
#define FIELD_TABN 		2

/*
//============================================================================
// R2MFD_KASATKA_Obj
*/
typedef struct R2MFD_KASATKA_Obj {
    IALG_Obj        alg;   /* MUST be first field of all R2MFD objs */

    /* TODO: add custom fields here */
	R2MFD_KONST 	*konst;    	// by Yury
    
    R2MFD_MBLK		*history;	// by Yury
    R2MFD_MBLK		*field;		// by Yury
    
} R2MFD_KASATKA_Obj;

// --- internal-used function
// ----

// common log. function, powered by Knuth's log alg.
Int r2mf_detect_kLog10(IR2MFD_Handle handle, Uns x)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;

	Uns z;
	Int y,k;

	if (0 == x) return (-2147483648);	// assume for -infinity value

	for (k=0; k <32; k++)
	{
		if (x & 0x80000000) break;
		x <<= 1;
	}

	y = R2MF_DETECT_LOG_2N_TAB[k];

	//begin Knuth's log alg.
	z = x >> 1;
	for (k=1; k<27;)
	{
		if (0x80000000 == x) break;

		if ((x-z) < 0x80000000)
		{
			z >>= 1;
			k++;
		}else
		{
			x -= z;
			z = x >> k;
			y += R2MF_DETECT_LOG_2NM1_TAB[k];
		}
	} // for

	return (y);
} //int kLog10(...) 

// calculate power in dBm0
Int r2mf_detect_dBm0(IR2MFD_Handle handle, Uns avgsq, Int refm0)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;
	return ((r2mf_detect_kLog10(handle, avgsq << 5)-refm0)/R2MF_DETECT_LSCALE);
} //int calc_dBm0(...)


// ----


MdInt r2mf_detect_detectFfwd(IR2MFD_Handle handle, MdInt *data, MdInt num_data)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;

	Int u0;			// used in gz alg
	Int u1;			// used in gz alg
	Uns power;		// used in gz alg
	Int t;			// tmp var, used in gz alg
	Int in;			// each sample
	Int mx = 0;
	Int mulp = 1000;
	MdInt retv = 0;
	Int tmp;
	Uns avgsq=0;
	//unsigned int powa[6];	// for 1380, 1500, 1620, 1740, 1860, 1980
//	unsigned int tmpw;

	MdInt i,j;

			//LOG_printf(&log_gz,"fwd=====");
			
	mx = 0;
	for (j=0;j<num_data;j++)	//find log pow
	{
		//tmp = data[j] >> 3;	//to drop +-32767 --> +-4095
		tmp = data[j];
		if (tmp>mx) {mx = tmp;}	
		
		avgsq += tmp*tmp;
	}
	
		avgsq = avgsq/num_data;
		tmp = r2mf_detect_dBm0(handle, avgsq, R2MF_DETECT_M0_A_LAW);
			//LOG_printf(&log_gz,"avgsq= %d, log pow= %0.3f",avgsq,tmp/100.0);	
						
		if ((tmp >= R2MF_DETECT_DBM0_OPRMIN) && (tmp <= R2MF_DETECT_DBM0_OPRMAX))
		{
			// go on
		}else	{
					return (0);	// reject due to not in range of accepted log pow
				}	
	
	mulp = 4095*1000/mx;	// may be change *1000 with <<10 operator.			
			
	for (i=0;i<6;i++)
	{		
		u0 = u1 = 0;
		for (j=0;j<num_data;j++)	// step thru each sample inputted by invoke fn.
		{
			//tmp = data[j] >> 3;	//to drop +-32767 --> +-4095
			tmp = data[j];
				//in = tmp;
				//LOG_printf(&log_gz,"org_v= %d cvt_v= %d",data[j],in);				
			in = (tmp*mulp/1000) >> 5;	//to drop +-4095 -> +-127
			t = u0;
			u0 = in + ((R2MF_DETECT_COEFF_FWD_TAB[i]*u0)>>17) -u1;		// /10000
			u1 = t;
			
			//j++;	// unkomment this line to skip #2 (not used now, needs always kommented)
		}
		power = u0*u0 + u1*u1 - ((R2MF_DETECT_COEFF_FWD_TAB[i]*u0*u1)>>17);	// /10000
		if ((power > R2MF_DETECT_THRESHOLDf)) 
		{
			retv += 1 << (5-i);
		}else{}
			//LOG_printf(&log_gz,"gz pow= %0.3fM",power/1000000.0);
				
	}//i
		
		if ((retv>=0)&&(mx > R2MF_DETECT_THRESHOLDv))
		{
			//retv += 1 << 6;	// fwd bit 7
		}else
		{
			retv = 0;
		}									
											//LOG_printf(&log_gz,"=====");
			//LOG_printf(&log_gz,"mx= %d ret= %x",mx,retv);
	return (retv);
}

// ---

short r2mf_detect_detectFbwd(IR2MFD_Handle handle, MdInt *data,MdInt num_data)
{

    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;

	Int u0;			// used in gz alg
	Int u1;			// used in gz alg
	Uns power;		// used in gz alg
	Int t;			// tmp var, used in gz alg
	Int in;			// each sample
	Int mx = 0;
	Int mulp = 1000;
	MdInt retv = 0;
	Int tmp;
	Uns avgsq=0;
	//unsigned int powa[6];	// for 1380, 1500, 1620, 1740, 1860, 1980
//	unsigned int tmpw;

	MdInt i,j;

			//LOG_printf(&log_gz,"bwd=====");
			
	mx = 0;
	for (j=0;j<num_data;j++)	//find log pow
	{
			//tmp = data[j] >> 3;	//to drop +-32767 --> +-4095
			tmp = data[j];
		if (tmp>mx) {mx = tmp;}	
		
		avgsq += tmp*tmp;
		
	}
		avgsq = avgsq/num_data;
		tmp = r2mf_detect_dBm0(handle, avgsq, R2MF_DETECT_M0_A_LAW);
			//LOG_printf(&log_gz,"avgsq= %d, log pow= %0.3f",avgsq,tmp/100.0);			
		
		if ((tmp >= R2MF_DETECT_DBM0_OPRMIN) && (tmp <= R2MF_DETECT_DBM0_OPRMAX))
		{
			// go on
		}else	{
					return (0);	// reject due to not in range of accepted log pow
				}	
	
	mulp = 4095*1000/mx;	// may be change *1000 with <<10 operator.			
			
	for (i=0;i<6;i++)
	{		
		u0 = u1 = 0;
		for (j=0;j<num_data;j++)	// step thru each sample inputted by invoke fn.
		{
			//tmp = data[j] >> 3;	//to drop +-32767 --> +-4095
			tmp = data[j];			
				//in = tmp;
				//LOG_printf(&log_gz,"org_v= %d cvt_v= %d",data[j],in);				
			in = (tmp*mulp/1000) >> 5;	//to drop +-4095 -> +-127
			t = u0;
			u0 = in + ((R2MF_DETECT_COEFF_BWD_TAB[i]*u0)>>17) -u1;		// /10000
			u1 = t;
			
			//j++;	// unkomment this line to skip #2 (not used now, needs always kommented)
		}
		power = u0*u0 + u1*u1 - ((R2MF_DETECT_COEFF_BWD_TAB[i]*u0*u1)>>17);	// /10000
		if ((power > R2MF_DETECT_THRESHOLDg)) 
		{
			retv += 1 << (5-i);
		}else{}
			//LOG_printf(&log_gz,"gz pow= %0.3fM",power/1000000.0);
				
	}//i
		
		if ((retv>=0)&&(mx > R2MF_DETECT_THRESHOLDv))
		{
			//retv += 1 << 7;	// bwd bit 8
		}else
		{
			retv = 0;
		}									
											//LOG_printf(&log_gz,"=====");
			//LOG_printf(&log_gz,"mx= %d ret= %x",mx,retv);
	return (retv);
}

// ---

// ---

MdInt r2mf_detect_chk_r2mf(IR2MFD_Handle handle, MdInt *data,MdInt num_data)
{
	MdInt fwdr=0;
	MdInt bwdr=0;
	
	MdInt retv=0;
	
	MdInt tmp;
	
	switch (r2mf_detect_detectFfwd(handle, data,num_data))
	{
		case 0x30:
			fwdr = 1;
			break;
		case 0x28:
			fwdr = 2;
			break;			
		case 0x18:
			fwdr = 3;
			break;			
		case 0x24:
			fwdr = 4;
			break;			
		case 0x14:
			fwdr = 5;
			break;			
		case 0x0C:
			fwdr = 6;
			break;			
		case 0x22:
			fwdr = 7;
			break;			
		case 0x12:
			fwdr = 8;
			break;			
		case 0x0A:
			fwdr = 9;
			break;			
		case 0x06:
			fwdr = 10;	//
			break;			
		case 0x21:
			fwdr = 11;	//A
			break;			
		case 0x11:
			fwdr = 12;	//B
			break;			
		case 0x09:
			fwdr = 13;	//C
			break;			
		case 0x05:
			fwdr = 14;	//D
			break;			
		case 0x03:
			fwdr = 15;	//E
			break;			
		default:
			fwdr = 0;	//unknown digit
			break;			
	}		
	
	switch (tmp=r2mf_detect_detectFbwd(handle, data,num_data))
	{
		case 0x30:
			bwdr = 1;
			break;
		case 0x28:
			bwdr = 2;
			break;			
		case 0x18:
			bwdr = 3;
			break;			
		case 0x24:
			bwdr = 4;
			break;			
		case 0x14:
			bwdr = 5;
			break;			
		case 0x0C:
			bwdr = 6;
			break;			
		case 0x22:
			bwdr = 7;
			break;			
		case 0x12:
			bwdr = 8;
			break;			
		case 0x0A:
			bwdr = 9;
			break;			
		case 0x06:
			bwdr = 10;	//
			break;			
		case 0x21:
			bwdr = 11;	//A
			break;			
		case 0x11:
			bwdr = 12;	//B
			break;			
		case 0x09:
			bwdr = 13;	//C
			break;			
		case 0x05:
			bwdr = 14;	//D
			break;			
		case 0x03:
			bwdr = 15;	//E
			break;			
		default:
			bwdr = 0;	//unknown digit
			break;			
	}	
		
		
	retv = ((bwdr&0x000F)<<4) | (fwdr&0x000F) ;
	
	//LOG_printf(&trace,"--> %02X",retv);	
	return (retv);							
}

// ---


/*
//============================================================================
// R2MFD_KASATKA_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the R2MFD_KASATKA processing methods.
*/

// The R2MFD_KASATKA_activate & R2MFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void R2MFD_KASATKA_activate(IALG_Handle handle)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;
    
    // TODO: implement algActivate
    // copy history to field
    memcpy((Void *) R2MFD->field, (Void *) R2MFD->history, sizeof(R2MFD_MBLK));    
    
}


/*
//============================================================================
// R2MFD_KASATKA_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a R2MFD_KASATKA_Obj structure.
*/
Int R2MFD_KASATKA_alloc(const IALG_Params *R2MFDParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IR2MFD_Params *params = (Void *)R2MFDParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IR2MFD_PARAMS;  /* set default parameters */
    }

    /* Request memory for R2MFD object */
    memTab[0].size = sizeof(R2MFD_KASATKA_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_EXTERNAL;
    memTab[0].attrs = IALG_PERSIST;
    
    // below is custom mem. tab. 
    
    // mem tab for history var. (edited by Yury)
    ///*
    memTab[HISTORY_TABN].size = sizeof(R2MFD_MBLK);
    memTab[HISTORY_TABN].alignment = 0;
    memTab[HISTORY_TABN].space = IALG_EXTERNAL;
    memTab[HISTORY_TABN].attrs = IALG_PERSIST;
    //*/     
    
    // mem tab for field var. (edited by Yury)
    ///*
    memTab[FIELD_TABN].size = sizeof(R2MFD_MBLK);
    memTab[FIELD_TABN].alignment = 0;
    memTab[FIELD_TABN].space = IALG_DARAM0;
    memTab[FIELD_TABN].attrs = IALG_SCRATCH;
    //*/    

    return (MTAB_NRECS);
}

/*
//============================================================================
// R2MFD_KASATKA_control
//
// Control our object's parameters while the algorithm is running
*/
Int R2MFD_KASATKA_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    IR2MFD_Status *sPtr = (IR2MFD_Status *)status;	
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;

    switch ((IR2MFD_Cmd)cmd) {

       case IR2MFD_GETSTATUS:

            return(IALG_EOK);

       case IR2MFD_SETSTATUS:

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// R2MFD_KASATKA_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the R2MFD_KASATKA processing methods to persistent memory.
*/

// The R2MFD_KASATKA_activate & R2MFD_KASATKA_deactivate routines are
// only used if scratch memory is being used.
Void R2MFD_KASATKA_deactivate(IALG_Handle handle)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;
    
    // TODO: implement algDeactivate
    // copy field to history
    memcpy((Void *) R2MFD->history, (Void *) R2MFD->field, sizeof(R2MFD_MBLK));        
}


/*
//============================================================================
// R2MFD_KASATKA_exit
//
// Exit the R2MFD_KASATKA module as a whole.
 */
Void R2MFD_KASATKA_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// R2MFD_KASATKA_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// R2MFD_KASATKA_alloc operation above.
*/
Int R2MFD_KASATKA_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;

    n = R2MFD_KASATKA_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[0].size = sizeof(R2MFD_KASATKA_Obj);    
    
    memTab[HISTORY_TABN].base = R2MFD->history;
    memTab[HISTORY_TABN].size = sizeof(R2MFD_MBLK);
    
    memTab[FIELD_TABN].base = R2MFD->field;
    memTab[FIELD_TABN].size = sizeof(R2MFD_MBLK);        

    return (n);
}

/*
//============================================================================
// R2MFD_KASATKA_init
//
// Initialize the R2MFD_KASATKA module as a whole.
*/
Void R2MFD_KASATKA_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// R2MFD_KASATKA_initObj
//
// Initialize the memory allocated for our instance.
*/
Int R2MFD_KASATKA_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *R2MFDParams)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;
    const IR2MFD_Params *params = (Void *)R2MFDParams;

    if(params == NULL){
        params = &IR2MFD_PARAMS; /* set default parameters */
    }
    
    //check params
    
    if(params->ptr2konst == NULL) {return (IALG_EFAIL);}


    /* TODO: Implement any additional algInit desired */
    
    R2MFD->history = memTab[HISTORY_TABN].base;
    R2MFD->field = memTab[FIELD_TABN].base;
    
    R2MFD->konst = params->ptr2konst;
    
    R2MFD->field->r2mf_detect_sPtr = 0;
    
	// copy field to history
    memcpy((Void *) R2MFD->history, (Void *) R2MFD->field, sizeof(R2MFD_MBLK));    
    
    return (IALG_EOK);
}

/*
//============================================================================
// R2MFD_KASATKA_moved
//
// Adjust any data pointers that has been moved by the client.
*/

// The R2MFD_KASATKA_moved routine is only used if the R2MFD_KASATKA_alloc routine
// returns more than one valid IALG_MemRec structure.
Void R2MFD_KASATKA_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *R2MFDParams)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;
    const IR2MFD_Params *params = (Void *)R2MFDParams;
    
    if (params != NULL)
    {
    	R2MFD->konst = params->ptr2konst;
    }
    
    R2MFD->field = memTab[FIELD_TABN].base;
    R2MFD->history = memTab[HISTORY_TABN].base;
}


/*
//============================================================================
// R2MFD_KASATKA_apply
// KASATKA's implementation of the apply operation.
// Custom fields of the R2MFD_KASATKA_Obj may be accessed as follows:
*/
XDAS_Void R2MFD_KASATKA_apply(IR2MFD_Handle handle, MdInt * samp, MdInt * result)
{
    R2MFD_KASATKA_Obj *R2MFD = (Void *)handle;

    /* TODO: implement apply */

	MdInt tmp;	

	if (R2MFD->field->r2mf_detect_sPtr < R2MF_DETECT_MaxQueueItem)
	{
		R2MFD->field->r2mf_detect_detectionBuffer[R2MFD->field->r2mf_detect_sPtr++] = *samp;
		//*rx = 0;
		//tmp = 0;
	}else
	{
		tmp = r2mf_detect_chk_r2mf(handle, R2MFD->field->r2mf_detect_detectionBuffer,R2MF_DETECT_MaxQueueItem);
		*result = tmp;
		
		//r2mf_detect_resetPtr();
		R2MFD->field->r2mf_detect_sPtr=0;
		
		//LOG_printf(&log_gz,"xxx1 --> %02X %X",tmp,rx);		
	}
}

// ---

