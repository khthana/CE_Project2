/*
//============================================================================
//
//    FILE NAME : R2MFD.c
//
//    ALGORITHM : R2MFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in R2MFD.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Tue - 04 January 2005
//    Creation Time: 09:23 PM
//
//============================================================================
*/

#pragma CODE_SECTION(R2MFD_create,  ".text:create")
#pragma CODE_SECTION(R2MFD_control, ".text:control")
#pragma CODE_SECTION(R2MFD_delete,  ".text:delete")
#pragma CODE_SECTION(R2MFD_init,    ".text:init")
#pragma CODE_SECTION(R2MFD_exit,    ".text:exit")

#include <std.h>
#include <algrf.h>
#include <xdas.h>
#include "r2mfd.h"

/*
// ===========================================================================
// R2MFD_create
//
//  Create an R2MFD instance object (using parameters specified by prms)
*/
R2MFD_Handle R2MFD_create(const IR2MFD_Fxns *fxns, const R2MFD_Params *prms)
{
    return ((R2MFD_Handle)ALGRF_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// R2MFD_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int R2MFD_control(R2MFD_Handle handle, R2MFD_Cmd cmd, R2MFD_Status *status)
{
    return (ALGRF_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// R2MFD_delete
//
// Delete the R2MFD instance object specified by handle
*/
Void R2MFD_delete(R2MFD_Handle handle)
{
    ALGRF_delete((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// R2MFD_init
//
// R2MFD module initialization
*/
Void  R2MFD_init(Void)
{
}

/*
// ===========================================================================
// R2MFD_exit
//
// R2MFD module finalization
*/
Void  R2MFD_exit(Void)
{
}

/*
// ===========================================================================
// R2MFD_apply
*/
XDAS_Void R2MFD_apply(R2MFD_Handle handle, MdInt * samp, MdInt * result)
{
    ALGRF_activate((ALGRF_Handle)handle);

    handle->fxns->apply(handle, samp, result);

    ALGRF_deactivate((ALGRF_Handle)handle);
}
