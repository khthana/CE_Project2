/*
//============================================================================
//
//    FILE NAME : R2MFD.h
//
//    ALGORITHM : R2MFD
//
//    VENDOR    : KASATKA
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This header defines the interface used by clients of the
//                R2MFD module
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 0
//    Number of Outputs: 0
//
//    Creation Date: Tue - 04 January 2005
//    Creation Time: 09:23 PM
//
//============================================================================
*/

#ifndef R2MFD_
#define R2MFD_

#include <algrf.h>
#include <xdas.h>
#include "ir2mfd.h"

/*
// ===========================================================================
// R2MFD_Handle
//
// This pointer is used to reference all R2MFD instance objects
*/
typedef struct IR2MFD_Obj *R2MFD_Handle;

/*
// ===========================================================================
// R2MFD_Params
//
// This structure defines the creation parameters for all R2MFD objects
*/
typedef IR2MFD_Params R2MFD_Params;

/*
// ===========================================================================
// R2MFD_PARAMS
//
// This structure defines the default creation parameters for R2MFD objects
*/
#define R2MFD_PARAMS   IR2MFD_PARAMS

/*
// ===========================================================================
// R2MFD_Status
//
// This structure defines the real-time parameters for R2MFD objects
*/
typedef struct IR2MFD_Status   R2MFD_Status;

/*
// ===========================================================================
// R2MFD_Cmd
//
// This typedef defines the control commands R2MFD objects
*/
typedef IR2MFD_Cmd   R2MFD_Cmd;

/*
// ===========================================================================
// control method commands
*/
#define R2MFD_GETSTATUS    IR2MFD_GETSTATUS
#define R2MFD_SETSTATUS    IR2MFD_SETSTATUS

/*
// ===========================================================================
// R2MFD_create
//
// Create an R2MFD instance object (using parameters specified by prms)
*/
extern R2MFD_Handle R2MFD_create(const IR2MFD_Fxns *fxns, const R2MFD_Params *prms);

/*
// ===========================================================================
// R2MFD_control
//
// Get, set, and change the parameters of the R2MFD function (using parameters specified by status).
*/
extern Int R2MFD_control(R2MFD_Handle handle, R2MFD_Cmd cmd, R2MFD_Status *status);

/*
// ===========================================================================
// R2MFD_delete
// Delete the R2MFD instance object specified by handle
*/
extern Void R2MFD_delete(R2MFD_Handle handle);

/*
// ===========================================================================
// R2MFD_apply
*/
extern XDAS_Void R2MFD_apply(R2MFD_Handle handle, MdInt * samp, MdInt * result);

#endif	/* R2MFD_ */
