//============================================================================
//
//    FILE:       IFCPTDETECT.c
//
//    PURPOSE:    I/F routines for Hypersignal RIDE
//                interface source for - CPTDETECT.DLL
//
//    BLOCK NAME: CPTDETECT
//
//    GROUP NAME: Default Group
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 1
//    Number of Outputs: 0
//
//    Creation Date: Thu - 17 February 2005
//    Creation Time: 01:32 PM
//
//    Copyright (C) 1992, 2005 Hyperception, All rights reserved
//
/*============================================================================
    Function:   UserSetupProc()
    Purpose:    This function is called at the time of new block addition   
                to set up Block I/O information and user parameter struct   
                memory allocation
    Parameters: (HANDLE *)hParam        - Parameter information struct
                (HANDLE *)hScratchParam - Scratch Parameter struct
    Returns:    USR_NO_ERR if no error
                Error Code if error
    -------------------------------------------------------------------------
    Function:   UserDefaultSetupProc()
    Purpose:    To setup default parameters
    Parameters: hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    USR_NO_ERR if no error
                error code otherwise
    -------------------------------------------------------------------------
    Function:   UserPreInitializeProc()
    Purpose:    Pre-initialization procedure.
                This procedure is called before the UserInitializeProc.  It
                can be used for various functions such as loading a real-time
                driver associated with the block.
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    TRUE if initialization complete
                FALSE otherwise
    -------------------------------------------------------------------------
    Function:   UserInitializeProc()
    Purpose:    Initialization procedure
                This function will handle all memory allocations and
                other initializations required before processing
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    TRUE if initialization complete
                FALSE otherwise
    -------------------------------------------------------------------------
    Function:   UserRTCompileProc()
    Purpose:    Compiles and links block on target DSP
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
                ModeState     - Compile mode
    Returns:    TRUE if initialization complete
                FALSE otherwise
    -------------------------------------------------------------------------
    Function:   UserExecProc()
    Purpose:    Main procedure for algorithm computation.
                This function will handle all computation as well as i/o
                function if required
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    TRUE if initialization complete
                FALSE otherwise
    -------------------------------------------------------------------------
    Function:   UserExitProc()
    Purpose:    Exit function used for releasing resources (such as memory)
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    TRUE if no error
                FALSE otherwise
    -------------------------------------------------------------------------
    Function:   UserStopProc()
    Purpose:    Handles 'Stop' request from Block Diagram
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    TRUE if initialization complete
                FALSE otherwise
    -------------------------------------------------------------------------
    Function:   UserResetProc()
    Purpose:    Reset parameters such as frames pointers, flag to rerun the
                the algorithm
    Parameters: hBioInfo      - Block I/O information struct
                hParam        - Parameter information struct
                hScratchParam - Scratch Parameter struct
    Returns:    USR_NO_ERR if no error
                Error Code if error
    -------------------------------------------------------------------------
    Function:   UserDialogProc()
    Purpose:    Dialog function for this application. This is the user
                interface function
    Parameters: Algorithm dependent
    Returns:    TRUE if processed, FALSE if not
    Note:       This is a window callback function
    -------------------------------------------------------------------------
    Function:   UserSaveProc()
    Purpose:    This function is called to save the block parameters to a file.
    Parameters: HANDLE hParam              - Parameter information struct
                HANDLE hScratchParam       - Scratch Parameter struct
                (LPSTR)Section             - Section name of the file
                (LPSTR)FileName            - File name to save
    Returns:    USR_NO_ERR if no error
                Error Code if error
    -------------------------------------------------------------------------
    Function:   UserLoadProc()
    Purpose:    This function is called to load the block parameters from a file.
    Parameters: HANDLE hParam              - Parameter information struct
                HANDLE hScratchParam       - Scratch Parameter struct
                (LPSTR)Section             - Section name of the file
                (LPSTR)FileName            - File name to save
    Returns:    USR_NO_ERR if no error
                Error Code if error
    -------------------------------------------------------------------------
    Function:   UserGetParameterListProc()
    Purpose:    This function fills the list box with the names and IDs of
                all the modifiable parameters for this block.
    Parameters: HWND  hListBox       - Handle of the list box to fill with names
    Returns:    void
    -------------------------------------------------------------------------
    Function:   UserSetParameterProc()
    Purpose:    This function sets the specified parameter to the value 
                pointed to by val.
    Parameters: HANDLE hParam        - Handle of the BLOCK_PARAM structure
                HANDLE hScratchParam - Handle of the SCRATCH_PARAM structure
                DWORD  ID            - Identifier of the variable to change
                void  *val           - Pointer to new value
    Returns:    USR_NO_ERR if no error
                Error Code if error
=============================================================================*/

#include <windows.h>
#include <limits.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <htmlhelp.h>

#include "bddk.h"
#include "hresourc.h"
#include "resource.h"
#include "bddrv.h"
#include "CPTDETECT.h"


// Static Variables
static WORD     wBlockInstance = 0;  // counts number of instances of block
static BOOL     bRTChange = FALSE;   // signals the PC to download parameters


//===========================================================================
// Function   :  UserSetupProc()                                             
// Purpose    :  This function is called at the time of new block addition   
//               to set up Block I/O information and user parameter struct   
//               memory allocation                                           
// Parameters :  (HANDLE *)hParam    Parameter information struct        
//               (HANDLE *)hScratchParam Scratch Parameter struct        
// Returns    :  USR_NO_ERR if no error                                      
//               Error Code if error                                         
//===========================================================================
int PASCAL UserSetupProc(HANDLE *hParam, HANDLE *hScratchParam)
{
    BLOCK_PARAM       *pPtr;
    SCRATCH_PARAM     *sPtr;

     // allocate memory for block parameter structure */ 
     *hParam = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,(DWORD)sizeof(BLOCK_PARAM));
     if (*hParam == NULL) return(USR_ERR_MEM);

     // get pointer to block parameters
     if ((pPtr = (BLOCK_PARAM *)GlobalLock(*hParam))==NULL)
        return(USR_ERR_NPT);

     // allocate memory for scratch parameter structure
     *hScratchParam = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,(DWORD)sizeof(SCRATCH_PARAM));
     if (*hScratchParam == NULL){
        GlobalUnlock(*hParam);
        return(USR_ERR_MEM);
     }

     // get pointer to scratch parameters
     if ((sPtr = (SCRATCH_PARAM *)GlobalLock(*hScratchParam))==NULL){
         GlobalUnlock(*hParam);
         return(USR_ERR_NPT);
     }

     // allocate real-time block parameter structure
     sPtr->hRTParam = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,(DWORD)sizeof(RTBLOCK_PARAM));
     if (sPtr->hRTParam == NULL){
         GlobalUnlock(*hScratchParam);
         GlobalUnlock(*hParam);
         return(USR_ERR_MEM);
     }

     // unlock memory
     GlobalUnlock(*hScratchParam);
     GlobalUnlock(*hParam);

     return(USR_NO_ERR);
}     


//===========================================================================
// Function   :  UserDefaultSetupProc()
// Purpose    :  To setup default parameters
// Parameters :  hParam           Parameter information struct
//               hScratchParam    Scratch Parameter struct
// Returns    :  USR_NO_ERR if no error
//               error code otherwise
//===========================================================================
int PASCAL UserDefaultSetupProc(HANDLE hParam, HANDLE hScratchParam)
{
    BLOCK_PARAM       *pPtr;
    SCRATCH_PARAM     *sPtr;
    RTBLOCK_PARAM     *bPtr;


    // get pointer to block parameter structure
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
       return(USR_ERR_NPT);

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL) {
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    // reset local error condition
    pPtr->LocalError = USR_NO_ERR;

    UserLoadProc(hParam, hScratchParam, MNAME, RTBPARAM);

    // get pointer to real-time block parameter structure
    if ((bPtr = (RTBLOCK_PARAM *)GlobalLock(sPtr->hRTParam))==NULL)  {
       GlobalUnlock(hScratchParam);
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    // set board DSP handle to NULL to denote not initialized yet
    bPtr->hDSPParam = NULL;
    sPtr->hBitmap = LoadBitmap(GetBlockInstanceHandle(), MAKEINTRESOURCE(IDB_BITMAP));
    GetObject(sPtr->hBitmap, sizeof(BITMAP), &sPtr->Bitmap);

    // unlock memory
    GlobalUnlock (sPtr->hRTParam);
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);

    return(USR_NO_ERR);
}

//=============================================================================
// Function   :  UserPreInitializeProc()
// Purpose    :  Pre-initialization procedure.
//               This procedure is called before the UserInitializeProc.  It
//               can be used for various functions such as loading a real-time
//               driver associated with the block.
// Parameters :  hBioInfo  Block I/O information struct
//               hParam    Parameter information struct
//               hScratchParam Scratch Parameter struct
// Returns    :  TRUE if initialization complete
//               FALSE otherwise
//=============================================================================
int PASCAL UserPreInitializeProc(HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{
    BLOCK_PARAM       *pPtr;
    SCRATCH_PARAM     *sPtr;
    RTBLOCK_PARAM     *bPtr;


    // get pointer to block parameter structure
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
       return(USR_ERR_NPT);

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL) {
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    // initialize real-time block parameter structure
    // get pointer to real-time block parameter structure
    if ((bPtr = (RTBLOCK_PARAM *)GlobalLock(sPtr->hRTParam))==NULL)  {
       GlobalUnlock(hScratchParam);
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    // get block information and store in real-time block structure
    bPtr->bNumInputs     = GetNumInputs(hBioInfo);
    bPtr->bNumOutputs    = GetNumOutputs(hBioInfo);
    bPtr->bComplex       = 0;
    bPtr->bDimension     = 0;
    bPtr->wPrecision     = pPtr->Precision;
    bPtr->bBlockCompiled = FALSE;
    bPtr->wNumParams     = NUM_PARAMS;
    bPtr->dwParamsSize   = PARAMS_SIZE;
    bPtr->wErrorCode     = 0;
    bPtr->hErrorInfo     = NULL;

    wBlockInstance++;                         // increment block instance
    bPtr->wBlockInstance = wBlockInstance;    // store in block structure

//---------------------------------------------------------------------------
//                         Get Driver Name
//---------------------------------------------------------------------------
    if (!pPtr->DriverName[0]) {    // driver not found
      char Section[100];
      GlobalUnlock(sPtr->hRTParam);
      GlobalUnlock(hScratchParam);
      GlobalUnlock(hParam);
      GetAppSection(Section);
      MessageBox(GetBlockWindowHandle(),
        "'DSP Board' entry not found!  You need to install the DSP board driver.",
           Section,MB_OK|MB_ICONEXCLAMATION);
      return(USR_ERR_ICNFG);            // missing DSP Board entry
    }

//---------------------------------------------------------------------------
//                            Open Board Driver
//---------------------------------------------------------------------------
    if (sPtr->hDriver = RideOpenDriver ((LPSTR)pPtr->DriverName, &sPtr->lpfnRideSendCommand)){
        if (!RideSendCommand (sPtr->hDriver, DRV_OPENBLOCK, NULL, (LONG)sPtr->hRTParam)) {
            RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
            GlobalUnlock(sPtr->hRTParam);
            GlobalUnlock(hScratchParam);
            GlobalUnlock(hParam);
            return (USR_ERR_TO);
        }
    }
    else {
        // DSP board driver could not be opened
        char ErrorStr[256];

        GlobalUnlock(sPtr->hRTParam);
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);

        // display error message
        wsprintf(ErrorStr,"DSP board driver (%s) could not be opened.  "
                 "You must install the driver.",pPtr->DriverName);
        MessageBox(NULL,ErrorStr,"Hypersignal RIDE",MB_OK|MB_ICONEXCLAMATION);
        return (USR_ERR_OPENDRV);
    }

    // get DSP's default precision
    if (pPtr->Precision==HDT_INT && !RideSendCommand (sPtr->hDriver, DRV_INTSUPPORT,0,0)) {
        pPtr->Precision = HDT_AUTO;
    }
    else if (pPtr->Precision==HDT_FLOAT && !RideSendCommand (sPtr->hDriver, DRV_FLTSUPPORT,0,0)) {
        pPtr->Precision = HDT_AUTO;
    }

    // unlock memory
    GlobalUnlock(sPtr->hRTParam);
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);

    return(USR_NO_ERR);
}

//=============================================================================
// Function   :  UserInitializeProc()
// Purpose    :  Initialization procedure
//               This function will handle all memory allocations and
//               other initializations required before processing
// Parameters :  hBioInfo  Block I/O information struct
//               hParam    Parameter information struct
//               hScratchParam Scratch Parameter struct
// Returns    :  TRUE if initialization complete
//               FALSE otherwise
//=============================================================================
int PASCAL UserInitializeProc(HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{
    BLOCK_PARAM        *pPtr;
    SCRATCH_PARAM      *sPtr;
    RTBLOCK_PARAM      *bPtr;

    // get pointer to block parameters
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
       return(USR_ERR_NPT);

    // reset local error condition
    pPtr->LocalError = USR_NO_ERR;

    // get pointer to scratch parameters
    if ((sPtr=(SCRATCH_PARAM *) GlobalLock(hScratchParam)) == NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

    if ((bPtr = (RTBLOCK_PARAM *)GlobalLock(sPtr->hRTParam))==NULL)  {
       GlobalUnlock(hScratchParam);
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    // unlock memory
    GlobalUnlock(sPtr->hRTParam);
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);

    return(USR_NO_ERR);
}

//=============================================================================
// Function   :  UserRTCompileProc()
// Purpose    :  Compiles and links block on target DSP
// Parameters :  hBioInfo      - Block I/O information struct
//               hParam        - Parameter information struct
//               hScratchParam - Scratch Parameter struct
//               ModeState     - Compile mode
// Returns    :  TRUE if initialization complete
//               FALSE otherwise
//=============================================================================
int PASCAL UserRTCompileProc(HANDLE hBioInfo, HANDLE hParam,
                                 HANDLE hScratchParam, int ModeState)
{
    SCRATCH_PARAM     *sPtr;
    BLOCK_PARAM       *pPtr;

    // get pointer to block parameter structure
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
       return(USR_ERR_NPT);

    // reset local error condition
    pPtr->LocalError = USR_NO_ERR;

    // get pointer to scratch parameter structure
    if ((sPtr=(SCRATCH_PARAM *) GlobalLock(hScratchParam)) == NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

    if(sPtr->lpfnRideSendCommand == NULL){
      GlobalUnlock(hScratchParam);
      GlobalUnlock(hParam);
      return(USR_ERR_OPENDRV);
    }

    // determine compile mode and act accordingly
    switch (ModeState)  {

//---------------------------------------------------------------------------
//                   Initialize Compile/Link Block on Target DSP
//---------------------------------------------------------------------------
      case RT_COMPILE_INIT:

         // initialize real-time compiler/linker 
         if (!RideSendCommand (sPtr->hDriver, DRV_COMPILEINIT, NULL, (LONG)sPtr->hRTParam)) {
             RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
             GlobalUnlock(hScratchParam);
             GlobalUnlock(hParam);
             return (USR_ERR_COMPINIT);
         }
         break;

//---------------------------------------------------------------------------
//                   Compile/Link Block on Target DSP
//---------------------------------------------------------------------------
      case RT_COMPILE_BLOCK:

         // compile and download real-time block
         if (!RideSendCommand (sPtr->hDriver, DRV_LOADBLOCK, NULL, (LONG)sPtr->hRTParam)) {
             RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
             GlobalUnlock(hScratchParam);
             GlobalUnlock(hParam);
             return (USR_ERR_COMPBLOCK);
         }
         break;

//---------------------------------------------------------------------------
//              Compile/Link Real-Time Block Diagram on Target DSP
//---------------------------------------------------------------------------
      case RT_COMPILE_LINK:

         // link real-time block diagram
         if (!RideSendCommand (sPtr->hDriver, DRV_COMPILELINK, NULL, (LONG)sPtr->hRTParam)) {
             RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
             GlobalUnlock(hScratchParam);
             GlobalUnlock(hParam);
             return (USR_ERR_COMPLINK);
         }

         break;

//---------------------------------------------------------------------------
//             Establish (Link) Block Diagram Data Flow
//---------------------------------------------------------------------------
      case RT_COMPILE_DATA:

         // set run mode to link DSP data flow
         pPtr->RunMode = RT_RUN_LINK;

         // establish DSP data flow
         pPtr->LocalError = UserExecProc(hBioInfo,hParam,hScratchParam);

         // download parameters to DSP
         DownloadDSPParameters(pPtr, sPtr);

         break;

      default: break;
    }

    // unlock memory pointers
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);

    return(pPtr->LocalError);
}

//=============================================================================
// Function   : UserExecProc()
// Purpose    : Main procedure for algorithm computation.
//              This function will handle all computation as well as i/o
//              function if required
// Parameters:  hBioInfo      - Block I/O information struct
//              hParam        - Parameter information struct
//              hScratchParam - Scratch Parameter struct
// Returns    : TRUE if initialization complete
//              FALSE otherwise
//=============================================================================
int PASCAL UserExecProc(HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{
     int                nDSize;
     int                nPrecision;
     int                LocalError = USR_NO_ERR;
     BLOCK_PARAM       *pPtr;
     SCRATCH_PARAM     *sPtr;

//-----------------------------------------------------------------------------
//         Define input variables for Channel 0
//-----------------------------------------------------------------------------
     HANDLE             hBuf0;
     long               lFlag0;
     long               QFlag0;

     // get pointer to block parameter structure 
     if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
        return(USR_ERR_NPT);

     // get pointer to scratch parameter structure
     if ((sPtr=(SCRATCH_PARAM *) GlobalLock(hScratchParam)) == NULL){
         GlobalUnlock(hParam);
         return(USR_ERR_NPT);
     }

//-----------------------------------------------------------------------------
//         Get input channel and framesize info from Block  - Channel 0
//-----------------------------------------------------------------------------

     if (!GetInputChannelFlag(hBioInfo,0,(long *)&lFlag0))  {
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return(USR_ERR_FLAG);
     }

     if (!GetInputQFlag(hBioInfo,0,(long *)&QFlag0))  {
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return(USR_ERR_QFLAG);
     }

     if (!GetInputFrameSize(hBioInfo,0,(unsigned long *)&pPtr->FramesizeIn0))  {
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return(USR_ERR_FS);
     }
    
     hBuf0 = GetInputDataHandle(hBioInfo,0);
     if (hBuf0 == NULL) {
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
     }
  
     // get input channel context 

     pPtr->RCFlagIn0 = GETRCFLAG(lFlag0);
     pPtr->DTFlagIn0 = GETDTYPE(lFlag0);

     if (!GetInputSampFreq(hBioInfo,0,(double *)&pPtr->SampFreqIn0))  {
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return(USR_ERR_SMPF);
     }

     // Check input dimension

     if (GETDIMENSION(lFlag0) != 1){
          GlobalUnlock(hParam);
          return(USR_ERR_DIM);
     }

     // check data type and complex type attribute

     if (pPtr->DTFlagIn0 > HDT_MAXTYPE){         // check data type attribute
          GlobalUnlock(hScratchParam);
          GlobalUnlock(hParam);
          return(USR_ERR_FDT);
     }

     if (pPtr->RCFlagIn0 > RC_REAL){       // check complex attribute
          GlobalUnlock(hScratchParam);
          GlobalUnlock(hParam);
          return(USR_ERR_FDT);
     }


     if(pPtr->Precision != HDT_AUTO){
       if(pPtr->DTFlagIn0 != pPtr->Precision){
            GlobalUnlock(hScratchParam);
            GlobalUnlock(hParam);
            return(USR_ERR_FPREC);
       }
     }
//-----------------------------------------------------------------------------
//                   Set precision and framesize info                         
//-----------------------------------------------------------------------------

     pPtr->Framesize = ULONG_MAX;
     pPtr->Framesize = min(pPtr->Framesize, (unsigned long)pPtr->FramesizeIn0);

     nPrecision = pPtr->Precision;

     if (pPtr->Precision == HDT_AUTO){
         nPrecision = pPtr->DTFlagIn0;
     }

     if (nPrecision == HDT_FLOAT){
        nDSize = sizeof(float);
     }
     else if (nPrecision == HDT_INT){
        nDSize = sizeof(int);
     }
     else if (nPrecision == HDT_DOUBLE){
        nDSize = sizeof(double);
     }
     else if (nPrecision == HDT_LONG){
        nDSize = sizeof(long);
     }
     else if (nPrecision == HDT_SHORT){
        nDSize = sizeof(short);
     }
     else if (nPrecision == HDT_BYTE){
        nDSize = sizeof(BYTE);
     }
     else if (nPrecision == HDT_CHAR){
        nDSize = sizeof(char);
     }
     else {
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return(USR_ERR_PRC);
     }


//-----------------------------------------------------------------------------
//   Determine run mode (link, DSP run, or PC run)
//-------------------------------------------------------------------------
     if (pPtr->RunMode == RT_RUN_LINK) {
        RTBLOCK_PARAM far *bPtr;

        // lock real-time block structures
        if ((bPtr = (RTBLOCK_PARAM far *)GlobalLock(sPtr->hRTParam))==NULL)  {
           GlobalUnlock(hScratchParam);
           GlobalUnlock(hParam);
           return(USR_ERR_NPT);
        }

//-----------------------------------------------------------------------------
//   Call routine to establish data flow (link)
//-----------------------------------------------------------------------------

        if (nPrecision == HDT_FLOAT) lstrcpy(bPtr->BlockName,BFNAME);
        else                         lstrcpy(bPtr->BlockName,BINAME);
        bPtr->wPrecision = nPrecision;

        if (nPrecision == HDT_FLOAT) {
          RTDataFlowLink(hBioInfo, sPtr->hDriver, sPtr->hRTParam, (DriverCall *)sPtr->lpfnRideSendCommand);
        }
        else {
           // invalid data precision
           GlobalUnlock(hScratchParam);
           GlobalUnlock(hParam);
           return(USR_ERR_FPREC);   // return with error, invalid precision
        }

        // set run mode to run DSP next time
        pPtr->RunMode = RT_RUN_DSP;
        GlobalUnlock(sPtr->hRTParam);
     }
     else if (pPtr->RunMode == RT_RUN_DSP){
//-----------------------------------------------------------------------------
//   DSP Run
//-------------------------------------------------------------------------

        if (!(RideSendCommand(sPtr->hDriver, DRV_RUNDSP, NULL, (LONG)sPtr->hRTParam))){
             GlobalUnlock(hScratchParam);
             GlobalUnlock(hParam);
             return(USR_ERR_NPT);   // return error condition
        }

        // set run mode for PC next time
        pPtr->RunMode = RT_RUN_PC;
     }
     else if (pPtr->RunMode == RT_RUN_PC){
//-----------------------------------------------------------------------------
//   PC Run
//-------------------------------------------------------------------------
        // put optional PC-side run-time code here

     }

     GlobalUnlock(hScratchParam);
     GlobalUnlock(hParam);
     return(LocalError);
}


//===========================================================================
// Function   : UserExitProc()
// Purpose    : Exit function used for releasing resources (such as memory)
// Parameters:  hBioInfo      - Block I/O information struct
//              hParam        - Parameter information struct
//              hScratchParam - Scratch Parameter struct
// Returns    : TRUE if no error
//              FALSE otherwise
//===========================================================================
int PASCAL UserExitProc(HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{

//-----------------------------------------------------------------------------
//                  Free output channel memory
//-----------------------------------------------------------------------------
    BLOCK_PARAM       *pPtr;
    SCRATCH_PARAM     *sPtr;

    // get pointer to block parameter structure
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
       return(USR_ERR_NPT);

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

    // close block and driver
    RideSendCommand (sPtr->hDriver, DRV_CLOSEBLOCK, NULL, (LONG)sPtr->hRTParam);
    RideCloseDriver(sPtr->hDriver);

    // free memory
    FreeGlobalMemory(sPtr->hRTParam);

    // free block scratch parameter structure memory 
    GlobalUnlock(hScratchParam);
    FreeGlobalMemory(hScratchParam);

    // free block parameter structure memory 
    GlobalUnlock(hParam);
    FreeGlobalMemory(hParam);

    return(USR_NO_ERR);
}


//===========================================================================
// Function   : UserStopProc()
// Purpose    : Handles 'Stop' request from Block Diagram
// Parameters:  hBioInfo      - Block I/O information struct
//              hParam        - Parameter information struct
//              hScratchParam - Scratch Parameter struct
// Returns    : USR_NO_ERR if no error
//              Error Code if error
//===========================================================================
int PASCAL UserStopProc(HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{
    BLOCK_PARAM       *pPtr = NULL;
    SCRATCH_PARAM     *sPtr = NULL;

    // get pointer to block parameter structure
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam)) == NULL)
       return(USR_ERR_NPT);

    // reset local error condition
    pPtr->LocalError = USR_NO_ERR;
    pPtr->RunMode = RT_RUN_DSP;   // next run will start DSP

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

//---------------------------------------------------------------------------
//                              Stop DSP Board
//---------------------------------------------------------------------------
    if (!RideSendCommand (sPtr->hDriver, DRV_HOLDDSP, NULL, (LONG)sPtr->hRTParam)) {
       RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
    }

    // unlock memory
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);

    return(USR_NO_ERR);
}


//===========================================================================
// Function   : UserResetProc()
// Purpose    : Reset parameters such as frames pointers, flag to rerun the
//              the algorithm
// Parameters:  hBioInfo      - Block I/O information struct
//              hParam        - Parameter information struct
//              hScratchParam - Scratch Parameter struct
// Returns    : USR_NO_ERR if no error
//              Error Code if error
//===========================================================================
int PASCAL UserResetProc(HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{
    BLOCK_PARAM        *pPtr = NULL;
    SCRATCH_PARAM      *sPtr = NULL;

    // get pointer to block parameter structure 
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam)) == NULL)
       return(USR_ERR_NPT);

    // reset local error condition
    pPtr->LocalError = USR_NO_ERR;
    pPtr->RunMode = RT_RUN_DSP;       // next run will start DSP

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }


//---------------------------------------------------------------------------
//                              Reset DSP Board
//---------------------------------------------------------------------------
    // reset DSP
    if (!RideSendCommand (sPtr->hDriver, DRV_RESETDSP,NULL, (LONG)sPtr->hRTParam)) {
        RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);

        // unlock memory and return error
        GlobalUnlock(hScratchParam);
        GlobalUnlock(hParam);
        return (USR_ERR_NPT);
    }

    // unlock memory and return
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);
    return(USR_NO_ERR);
}


//===========================================================================
// Function   : UserDialogProc()
// Purpose    : Dialog function for this application. This is the user
//              interface function
// Parameters :
// Returns    : TRUE if processed, FALSE if not
// Note       : This is a window callback function
//===========================================================================
 
BOOL PASCAL UserDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    HANDLE             hItem;
    HANDLE             hItem2;
    BLOCK_PARAM       *pPtr;
    HANDLE             hParam;
    HANDLE             hScratchParam;
    SCRATCH_PARAM     *sPtr;
    RTBLOCK_PARAM     *bPtr;
    unsigned int       index;


    switch (message)
    {
      case WM_COMMAND:
           switch(LOWORD(wParam))
           {
             case IDOK:   {
                  char          OldDriverName[16];
                  WORD          wBoardNum;
                  WORD          wDSPNum;
                  WORD          wIntNum;
                  WORD          wSyncInNum;
                  WORD          wSyncOutNum;
                  BOOL          bProfile;

                  // get pointer to block parameters
                  hParam = GetHParam(hDlg);
                  if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL)
                  {
                     MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
                     EndDialog(hDlg,IDCANCEL);
                     return(TRUE);
                  }

                  // get pointer to scratch parameters
                  hScratchParam = GetScratchParam(hDlg);  // get handle of scratch parameters
                  if ((sPtr = (SCRATCH_PARAM *) GlobalLock(hScratchParam)) == NULL){
                      GlobalUnlock(hParam);
                      MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
                      EndDialog(hDlg, IDCANCEL);
                      return(TRUE);
                  }

                  // get pointer to real-time block parameters
                  if ((bPtr = (RTBLOCK_PARAM *) GlobalLock(sPtr->hRTParam)) == NULL){
                      GlobalUnlock(hScratchParam);
                      GlobalUnlock(hParam);
                      MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
                      EndDialog(hDlg, IDCANCEL);
                      return(TRUE);
                  }

                  // check if board or DSP number changed
                  wBoardNum = bPtr->wBoardNum;
                  wDSPNum = bPtr->wDSPNum;
                  bPtr->wBoardNum = GetDlgItemI(hDlg,IDC_EDIT_BRDNUM);
                  bPtr->wDSPNum   = GetDlgItemI(hDlg,IDC_EDIT_DSPNUM);

                  if ((bPtr->wBoardNum != wBoardNum) || (bPtr->wDSPNum != wDSPNum)){
                     // board or DSP changed so we need to change hDSPParam
                     if (!RideSendCommand (sPtr->hDriver, DRV_CHANGEDSP, NULL, (LONG)sPtr->hRTParam)) {
                        // restore original board/DSP numbers
                        bPtr->wBoardNum = wBoardNum;
                        bPtr->wDSPNum   = wDSPNum;

                        // unlock memory and return with ending dialog box
                        GlobalUnlock(sPtr->hRTParam);
                        GlobalUnlock(hScratchParam);
                        GlobalUnlock(hParam);
                        return (TRUE);
                     }
                     SetCompiledFlag(FALSE);
                  }

                  // get driver name
                  hItem = GetDlgItem(hDlg,IDC_COMBO_DRIVER);
                  index = (int)SendMessage(hItem,CB_GETCURSEL,0,0);
                  // copy current driver name to OldDriverName
                  lstrcpy(OldDriverName,pPtr->DriverName);
                  SendMessage(hItem,CB_GETLBTEXT,index,(LPARAM)(LPCSTR)pPtr->DriverName);

                  // check for driver change 
                  if (lstrcmpi(OldDriverName,pPtr->DriverName)){
                     // change DSP board drivers
                     if (ChangeDriver(pPtr->DriverName, sPtr->hRTParam, &sPtr->hDriver, &sPtr->lpfnRideSendCommand) != USR_NO_ERR){
                       // restore driver name to parameter structure
                       lstrcpy(pPtr->DriverName,OldDriverName);

                       GlobalUnlock(sPtr->hRTParam);
                       GlobalUnlock(hScratchParam);
                       GlobalUnlock(hParam);
                       return(TRUE);
                     }
                     SetCompiledFlag(FALSE);
                  }

                  // get interrupt number
                  wIntNum = bPtr->wIntNum;
                  hItem = GetDlgItem(hDlg,IDC_COMBO_DSPINT);
                  bPtr->wIntNum = (int)SendMessage(hItem,CB_GETCURSEL,0,0);
                  if (bPtr->wIntNum != wIntNum)
                    SetCompiledFlag(FALSE);

                  // get sync in number
                  wSyncInNum = bPtr->wSyncInNum;
                  hItem = GetDlgItem(hDlg,IDC_COMBO_SYNCIN);
                  bPtr->wSyncInNum = (int)SendMessage(hItem,CB_GETCURSEL,0,0);
                  if (bPtr->wSyncInNum != wSyncInNum)
                    SetCompiledFlag(FALSE);

                  // get sync out number
                  wSyncOutNum = bPtr->wSyncOutNum;
                  hItem = GetDlgItem(hDlg,IDC_COMBO_SYNCOUT);
                  bPtr->wSyncOutNum = (int)SendMessage(hItem,CB_GETCURSEL,0,0);
                  if (bPtr->wSyncOutNum != wSyncOutNum)
                    SetCompiledFlag(FALSE);

                  // get profile flag
                  bProfile = bPtr->bProfileBlock;
                  bPtr->bProfileBlock = IsDlgButtonChecked(hDlg,IDC_RADIO_PROFYES);
                  if (bPtr->bProfileBlock != bProfile)
                    SetCompiledFlag(FALSE);

                  // get precision
                  hItem = GetDlgItem(hDlg,IDC_PRECISION);
                  pPtr->Precision = GetPrecision(hItem);
                  if(pPtr->Precision != bPtr->wPrecision)
                    SetCompiledFlag(FALSE);

                  UserSaveProc(hParam, hScratchParam, MNAME, RTBPARAM);

                  InvalidateRect(GetBlockWindowHandle(), NULL, FALSE);

                  // download parameters to DSP
                  DownloadDSPParameters(pPtr, sPtr);

                  // unlock memory
                  GlobalUnlock(sPtr->hRTParam);
                  GlobalUnlock(hScratchParam);
                  GlobalUnlock(hParam);

                  EndDialog(hDlg,IDOK);
                  return(TRUE);
             }

             case IDCANCEL:
                  EndDialog(hDlg, IDCANCEL);
                  return (TRUE);

             case IDC_INFO:
                  // get pointer to block parameter structure
                  hParam = GetHParam(hDlg);
                  if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam))==NULL){
                     MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
                     break;
                  }

                  // get pointer to scratch parameter structure
                  hScratchParam = GetScratchParam(hDlg);
                  if ((sPtr = (SCRATCH_PARAM *) GlobalLock(hScratchParam)) == NULL){
                      EndDialog(hDlg, IDCANCEL);
                      return(TRUE);
                  }

                  // get block information
                  if (!RideSendCommand (sPtr->hDriver, DRV_BLOCKINFO, hDlg, (LONG)sPtr->hRTParam)) {
                      RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
                  }

                  // unlock memory and return
                  GlobalUnlock(hScratchParam);
                  GlobalUnlock(hParam);
                  return (TRUE);

             case IDHELP:   {
                  char Section[TEXT_LENGTH];
                  char HelpDir[TEXT_LENGTH];
                  char HelpFileName[TEXT_LENGTH];
                  char chmTopic[TEXT_LENGTH];
                  int x,y;
 
                  GetAppSection(Section);
                  GetPrivateProfileString(Section, "working dir", "c:\\hsblock", (LPSTR)HelpDir, TEXT_LENGTH, "hswindow.ini");
                  lstrcat(HelpDir,"\\help");
                  lstrcpy(HelpFileName,HelpDir);
                  lstrcat(HelpFileName,"\\");
                  lstrcat(HelpFileName,MNAME);
                  lstrcat(HelpFileName,".htm");
                  if(!FileExists(HelpFileName)){
                    lstrcpy(HelpFileName,HelpDir);
                    lstrcat(HelpFileName,"\\Component Reference Guide.chm");
                  }
 
                  lstrcpy(chmTopic, "Component Reference Guide\\");
                  y = strlen(chmTopic);
                  lstrcat(chmTopic, MNAME);
                  lstrcat(chmTopic, ".htm");
 
                  for (x=0; x < lstrlen(MNAME); x++, y++){
                    if (!isalnum(chmTopic[y]))
                      chmTopic[y] = '_';
                  }
 
                  HtmlHelp(hDlg, (LPCSTR)HelpFileName, HH_DISPLAY_TOPIC, (DWORD)chmTopic);
                  break;
             }

             default:
                  return(FALSE);
           }
           break;

      case WM_VSCROLL:
           return(ProcessRTScroll(hDlg, wParam, lParam));

      case WM_INITDIALOG: {
           WORD wIndex;
           WORD wMaxDriverNum;
           WORD wNumInts;
           WORD wNumSyncs;
           char Entry[32];
           char EntryStr[80];
           char Section[80];
           char DriverBasename[16];
           char IniFilename[256];

           // get pointer to block parameters
           hParam = GetHParam(hDlg);
           if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam)) == NULL)
           {
              MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
              EndDialog(hDlg,IDCANCEL);
              return(TRUE);
           }

           // get pointer to scratch parameters
           hScratchParam = GetScratchParam(hDlg);  // get handle of scratch parameters
           if ((sPtr = (SCRATCH_PARAM *) GlobalLock(hScratchParam)) == NULL){
               GlobalUnlock(hParam);
               MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
               EndDialog(hDlg, IDCANCEL);
               return(TRUE);
           }

           // get pointer to real-time block parameters
           if ((bPtr = (RTBLOCK_PARAM *) GlobalLock(sPtr->hRTParam)) == NULL){
               GlobalUnlock(hScratchParam);
               GlobalUnlock(hParam);
               MessageBox(hDlg,"Memory Allocation Error!","Hypersignal",MB_OK);
               EndDialog(hDlg, IDCANCEL);
               return(TRUE);
           }


           // initialize data precision
           hItem = GetDlgItem(hDlg,IDC_PRECISION);
           AddPrecision(hItem, HDT_AUTO);
           if (RideSendCommand (sPtr->hDriver, DRV_FLTSUPPORT,0,0))
             AddPrecision(hItem, HDT_FLOAT);
           SetPrecision(hItem, pPtr->Precision);

           // initialize driver parameters
           SetDlgItemI(hDlg,IDC_EDIT_BRDNUM,bPtr->wBoardNum);
           SetDlgItemI(hDlg,IDC_EDIT_DSPNUM,bPtr->wDSPNum);

           // initialize profile enable
           if (bPtr->bProfileBlock)
                CheckRadioButton(hDlg,IDC_RADIO_PROFYES,IDC_RADIO_PROFNO,IDC_RADIO_PROFYES);
           else CheckRadioButton(hDlg,IDC_RADIO_PROFYES,IDC_RADIO_PROFNO,IDC_RADIO_PROFNO);

           // get installed Hyperception drivers to load combo box
           hItem = GetDlgItem(hDlg,IDC_COMBO_DRIVER);

           // get max driver number stored in hswindow.ini
           wMaxDriverNum = GetPrivateProfileInt("Drivers","DriverNum",0,"hswindow.ini");

           // load driver combo box
           for(wIndex=0; wIndex < wMaxDriverNum; wIndex++){
             wsprintf(Entry,"DSP Driver #%d",wIndex+1);  // create driver section entry
             EntryStr[0] = '\0';   // clear driver string
             // attempt to read driver entry in hswindow.ini
             GetPrivateProfileString("Drivers",Entry,"",EntryStr,sizeof(EntryStr),"hswindow.ini");
             if (EntryStr[0])
               SendMessage(hItem,CB_ADDSTRING,0,(DWORD)(LPSTR)EntryStr);
           }
           SendMessage(hItem,CB_SELECTSTRING,(UINT)-1,(DWORD)(LPSTR)pPtr->DriverName);

           // load interrupt combo box
           hItem = GetDlgItem(hDlg,IDC_COMBO_DSPINT);  // get handle of int control

           // get current driver's base name
           lstrcpy(DriverBasename,pPtr->DriverName);
           wIndex = 0;
           while ((DriverBasename[wIndex]) && (DriverBasename[wIndex] != '.')) wIndex++;
           if (DriverBasename[wIndex] == '.') DriverBasename[wIndex] = '\0';

           // get name of current driver's initialization file
           GetAppSection(Section);
           GetPrivateProfileString(Section,"working dir","",(LPSTR)IniFilename,sizeof(IniFilename),"hswindow.ini");
           wsprintf(IniFilename,"%s\\%s\\%s.ini",IniFilename,DriverBasename,DriverBasename);

           // read interrupt strings to initialize Int Number combo box

           // get number of interrupt strings
           wNumInts = GetPrivateProfileInt("interrupts","NumInts",0,IniFilename);

           // create no interrupt string first
           SendMessage(hItem,CB_ADDSTRING,0,(DWORD)(LPSTR)"None");

           // read initialization file to get interrupt strings
           for (wIndex=1; wIndex <= wNumInts; wIndex++){
               wsprintf(Entry,"Int%d",wIndex);  // interrupt section entry
               EntryStr[0] = '\0';                // clear entry string
               GetPrivateProfileString("interrupts",(LPCSTR)Entry,(LPCSTR)"",(LPSTR)EntryStr,sizeof(EntryStr),IniFilename);
               if (EntryStr[0]) SendMessage(hItem,CB_ADDSTRING,0,(DWORD)(LPSTR)EntryStr);
           }
           SendMessage(hItem,CB_SETCURSEL,(UINT)bPtr->wIntNum,(DWORD)0);

           // Load sync in/out combo boxes
           hItem  = GetDlgItem(hDlg,IDC_COMBO_SYNCIN);   // get handle of sync in control
           hItem2 = GetDlgItem(hDlg,IDC_COMBO_SYNCOUT);  // get handle of sync out control

           // read sync strings to initialize sync in/out combo boxes

           // get number of sync strings
           wNumSyncs = GetPrivateProfileInt("syncs","NumSyncs",0,IniFilename);

           // create no sync string first
           SendMessage(hItem,CB_ADDSTRING,0,(DWORD)(LPSTR)"None");
           SendMessage(hItem2,CB_ADDSTRING,0,(DWORD)(LPSTR)"None");

           // read initialization file to get sync strings
           for (wIndex=1; wIndex <= wNumSyncs; wIndex++){
               wsprintf(Entry,"Sync%d",wIndex);  // sync section entry
               EntryStr[0] = '\0';                // clear entry string
               GetPrivateProfileString("syncs",(LPCSTR)Entry,(LPCSTR)"",(LPSTR)EntryStr,sizeof(EntryStr),IniFilename);
               if (EntryStr[0]) { 
                  SendMessage(hItem,CB_ADDSTRING,0,(DWORD)(LPSTR)EntryStr);
                  SendMessage(hItem2,CB_ADDSTRING,0,(DWORD)(LPSTR)EntryStr);
               } 
           }

           // select current syncs
           SendMessage(hItem, CB_SETCURSEL,(UINT)bPtr->wSyncInNum,(DWORD)0);
           SendMessage(hItem2,CB_SETCURSEL,(UINT)bPtr->wSyncOutNum,(DWORD)0);

           // if DSP is running, disable driver parameters
           if (RideSendCommand (sPtr->hDriver, DRV_DSPSTATUS, NULL, (LONG)sPtr->hRTParam)) {
              if (bPtr->dwBlockStatus == DSPSTAT_RUN)  {

                 // disable driver parameters
                 EnableWindow(GetDlgItem(hDlg,IDC_EDIT_BRDNUM),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_SCROLL_BRDSCRL),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_EDIT_DSPNUM),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_SCROLL_DSPSCRL),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_COMBO_DRIVER),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_RADIO_PROFYES),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_RADIO_PROFNO),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_COMBO_DSPINT),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SYNCIN),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SYNCOUT),FALSE);
                 EnableWindow(GetDlgItem(hDlg,IDC_PRECISION),FALSE);

                 // disable any user-defined parameters here that should not
                 // be changed while the DSP is running (such as framesize)


              }
           }

           // unlock memory
           GlobalUnlock(sPtr->hRTParam);
           GlobalUnlock(hScratchParam);
           GlobalUnlock(hParam);
            
           return (FALSE);
      }
    }

    return (FALSE);
}


//===========================================================================
//  Function:   UserGetParameterListProc()
//  Purpose:    This function fills the list box with the names and IDs of
//              all the modifiable parameters for this block.
//  Parameters: HWND  hListBox    - Handle of the list box to fill with names
//  Returns:    void
//===========================================================================
 
void PASCAL UserGetParameterListProc(HWND hListBox)
{
}


//===========================================================================
//  Function:   UserSetParameterProc()
//  Purpose:    This function sets the specified parameter to the value 
//              pointed to by val.
//  Parameters: HANDLE hParam        - Handle of the BLOCK_PARAM structure
//              HANDLE hScratchParam - Handle of the SCRATCH_PARAM structure
//              DWORD  ID            - Identifier of the variable to change
//              void  *val           - Pointer to new value
//  Returns:    USR_NO_ERR if no error
//              Error Code if error
//===========================================================================
 
int PASCAL UserSetParameterProc(HANDLE hParam, HANDLE hScratchParam, DWORD ID, void *val)
{
    int                RC = USR_NO_ERR;
    int                wIndex;
    char               Section[80];
    char               OldDriverName[16];
    char               DriverBasename[16];
    char               IniFilename[256];
    BLOCK_PARAM       *pPtr;
    SCRATCH_PARAM     *sPtr;
    RTBLOCK_PARAM     *bPtr;

    // get pointer to block parameter structure 
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam)) == NULL)
        return(USR_ERR_NPT);

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

    // get pointer to real-time block parameter structure
    if ((bPtr = (RTBLOCK_PARAM *)GlobalLock(sPtr->hRTParam))==NULL)  {
       GlobalUnlock(hScratchParam);
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    if (ID == IDC_COMBO_DSPINT || ID == IDC_COMBO_SYNCIN || ID == IDC_COMBO_SYNCOUT){
      // get current driver's base name
      lstrcpy(DriverBasename,pPtr->DriverName);
      wIndex = 0;
      while ((DriverBasename[wIndex]) && (DriverBasename[wIndex] != '.')) wIndex++;
      if (DriverBasename[wIndex] == '.') DriverBasename[wIndex] = '\0';

      // get name of current driver's initialization file
      GetAppSection(Section);
      GetPrivateProfileString(Section,"working dir","",(LPSTR)IniFilename,sizeof(IniFilename),"hswindow.ini");
      wsprintf(IniFilename,"%s\\%s\\%s.ini",IniFilename,DriverBasename,DriverBasename);
    }

    switch(ID){
        case IDC_PRECISION:
            if(*((int *)val) == HDT_CHAR)   break;
            if(*((int *)val) == HDT_BYTE)   break;
            if(*((int *)val) == HDT_SHORT)  break;
            if(*((int *)val) == HDT_INT)    break;
            if(*((int *)val) == HDT_LONG)   break;
            if(*((int *)val) == HDT_DOUBLE) break;
            if(pPtr->Precision != *((int *)val))
              SetCompiledFlag(FALSE);
            pPtr->Precision = *((int *)val);
            break;

        case IDC_COMBO_DRIVER:
          lstrcpy(OldDriverName, pPtr->DriverName);
          lstrcpy(pPtr->DriverName, (char *)val);
          if (lstrcmpi(OldDriverName,pPtr->DriverName)){
            // change DSP board drivers
            if (ChangeDriver(pPtr->DriverName, sPtr->hRTParam, &sPtr->hDriver, &sPtr->lpfnRideSendCommand) != USR_NO_ERR){
              // restore driver name to parameter structure
              lstrcpy(pPtr->DriverName,OldDriverName);
              RC = USR_ERR_DSPC;  // return driver error
              break;
            }
          }
          SetCompiledFlag(FALSE);
          break;

        case IDC_EDIT_BRDNUM:
          bPtr->wBoardNum = *((WORD *)val);
          if (!RideSendCommand(sPtr->hDriver, DRV_CHANGEDSP, NULL, (LONG)sPtr->hRTParam))
            RC = USR_ERR_DSPC; // return driver error
          SetCompiledFlag(FALSE);
          break;

        case IDC_EDIT_DSPNUM:
          bPtr->wDSPNum = *((WORD *)val);
          if (!RideSendCommand(sPtr->hDriver, DRV_CHANGEDSP, NULL, (LONG)sPtr->hRTParam))
            RC = USR_ERR_DSPC; // return driver error
          SetCompiledFlag(FALSE);
          break;

        case IDC_COMBO_DSPINT:
          // get number of interrupt strings
          wIndex = GetPrivateProfileInt("interrupts","NumInts",0,IniFilename);

          if (0 <= *((WORD *)val) && *((WORD *)val) <= wIndex){
              bPtr->wIntNum = *((WORD *)val);
              SetCompiledFlag(FALSE);
              break;
          }
          RC = USR_ERR_OVF; // return overflow warning
          SetCompiledFlag(FALSE);
          break;

        case IDC_COMBO_SYNCIN:
          // get number of sync strings
          wIndex = GetPrivateProfileInt("syncs","NumSyncs",0,IniFilename);

          if (0 <= *((WORD *)val) && *((WORD *)val) <= wIndex){
              bPtr->wSyncInNum = *((WORD *)val);
              SetCompiledFlag(FALSE);
              break;
          }
          RC = USR_ERR_OVF; // return overflow warning
          SetCompiledFlag(FALSE);
          break;

        case IDC_COMBO_SYNCOUT:
          // get number of sync strings
          wIndex = GetPrivateProfileInt("syncs","NumSyncs",0,IniFilename);

          if (0 <= *((WORD *)val) && *((WORD *)val) <= wIndex){
              bPtr->wSyncOutNum = *((WORD *)val);
              SetCompiledFlag(FALSE);
              break;
          }
          RC = USR_ERR_OVF; // return overflow warning
          SetCompiledFlag(FALSE);
          break;

        case IDC_RADIO_PROFILE:
          if (*((WORD *)val) == 0 || *((WORD *)val) == 1){
              bPtr->bProfileBlock = IDC_RADIO_PROFNO - *((WORD *)val);
              SetCompiledFlag(FALSE);
              break;
          }
          RC = USR_ERR_OVF; // return overflow warning
          SetCompiledFlag(FALSE);
          break;

        // The following routine should be called after any of the block parameters
        // have been changed.  Block Diagram will call this routine after processing
        // all the global and external variables for this block.
        case IDC_RT_DOWNLOAD:
          if (bRTChange) {
             RC = DownloadDSPParameters(pPtr,sPtr);
             bRTChange = FALSE;
          }
          break;
    }

    // unlock memory
    GlobalUnlock(sPtr->hRTParam);
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);
    return(RC);
}


//===========================================================================
//  Function:   UserSaveProc()
//  Purpose:    This function is called to save the block parameters to a file.
//  Parameters: HANDLE hParam              - Parameter information struct
//              HANDLE hScratchParam       - Scratch Parameter struct
//              (LPSTR)Section             - Section name of the file
//              (LPSTR)FileName            - File name to save
//  Returns:    USR_NO_ERR if no error
//              Error Code if error
//===========================================================================
 
int PASCAL UserSaveProc(HANDLE hParam, HANDLE hScratchParam, LPSTR Section, LPSTR FileName)
{
    BLOCK_PARAM       *pPtr;
    SCRATCH_PARAM     *sPtr;
    RTBLOCK_PARAM     *bPtr;

    // get pointer to block parameter structure 
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam)) == NULL)
        return(USR_ERR_NPT);

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

    // get pointer to real-time block parameter structure
    if ((bPtr = (RTBLOCK_PARAM *)GlobalLock(sPtr->hRTParam))==NULL)  {
       GlobalUnlock(hScratchParam);
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    // Save block's user parameters to file
    SaveParamStr(Section, "Version", -1, VERSION, FileName);
    SaveParamI(Section, "Precision", IDC_PRECISION, pPtr->Precision, FileName);
    SaveParamL(Section, "Framesize", IDC_FRAMESIZE, pPtr->Framesize, FileName);
    SaveParamL(Section, "FramesizeIn0", -1, pPtr->FramesizeIn0, FileName);
    SaveParamI(Section, "RCFlagIn0", -1, pPtr->RCFlagIn0, FileName);
    SaveParamI(Section, "DTFlagIn0", -1, pPtr->DTFlagIn0, FileName);
    SaveParamD(Section, "SampFreqIn0", -1, pPtr->SampFreqIn0, FileName);

    // Save block's driver parameters to file
    SaveParamStr(Section, "DriverName", -1, pPtr->DriverName, FileName);
    SaveParamI(Section, "wBoardNum", -1, bPtr->wBoardNum, FileName);
    SaveParamI(Section, "wDSPNum", -1, bPtr->wDSPNum, FileName);
    SaveParamI(Section, "wIntNum", -1, bPtr->wIntNum, FileName);
    SaveParamI(Section, "wSyncInNum", -1, bPtr->wSyncInNum, FileName);
    SaveParamI(Section, "wSyncOutNum", -1, bPtr->wSyncOutNum, FileName);
    SaveParamI(Section, "bProfile", -1, bPtr->bProfileBlock, FileName);

    // unlock memory
    GlobalUnlock(sPtr->hRTParam);
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);
    return(USR_NO_ERR);
}


//===========================================================================
//  Function:   UserLoadProc()
//  Purpose:    This function is called to load the block parameters from a file.
//  Parameters: HANDLE hParam              - Parameter information struct
//              HANDLE hScratchParam       - Scratch Parameter struct
//              (LPSTR)Section             - Section name of the file
//              (LPSTR)FileName            - File name to save
//  Returns:    USR_NO_ERR if no error
//              Error Code if error
//===========================================================================
 
int PASCAL UserLoadProc(HANDLE hParam, HANDLE hScratchParam, LPSTR Section, LPSTR FileName)
{
    char            HSWSection[80];
    char            WorksheetName[256];
    char            WorksheetSection[256];
    BLOCK_PARAM        *pPtr;
    SCRATCH_PARAM      *sPtr;
    RTBLOCK_PARAM      *bPtr;

    // get pointer to block parameter structure 
    if ((pPtr = (BLOCK_PARAM *)GlobalLock(hParam)) == NULL)
        return(USR_ERR_NPT);

    // get pointer to scratch parameter structure
    if ((sPtr = (SCRATCH_PARAM *)GlobalLock(hScratchParam))==NULL){
        GlobalUnlock(hParam);
        return(USR_ERR_NPT);
    }

    // get pointer to real-time block parameter structure
    if ((bPtr = (RTBLOCK_PARAM *)GlobalLock(sPtr->hRTParam))==NULL)  {
       GlobalUnlock(hScratchParam);
       GlobalUnlock(hParam);
       return(USR_ERR_NPT);
    }

    pPtr->Precision = LoadParamI(Section, "Precision", IDC_PRECISION, HDT_AUTO, FileName);
    // Load block's user parameters

    // Load block's driver parameters
    GetDriverFileName(WorksheetSection, WorksheetName);
    if (!WorksheetName[0]){
      GetAppSection(HSWSection);
      GetPrivateProfileString(HSWSection, "DSP Board", "", pPtr->DriverName, sizeof(pPtr->DriverName), "HSWINDOW.INI");
      lstrcat(pPtr->DriverName,".drv");    // append driver ext.
    }
    else{
      LoadParamStr(WorksheetSection, "DriverName", -1, "", pPtr->DriverName, WorksheetName);
    }
    bPtr->wBoardNum = LoadParamI(Section, "wBoardNum", -1, 1, FileName);
    bPtr->wDSPNum = LoadParamI(Section, "wDSPNum", -1, 1, FileName);
    bPtr->wIntNum = LoadParamI(Section, "wIntNum", -1, 0, FileName);
    bPtr->wSyncInNum = LoadParamI(Section, "wSyncInNum", -1, 0, FileName);
    bPtr->wSyncOutNum = LoadParamI(Section, "wSyncOutNum", -1, 0, FileName);
    bPtr->bProfileBlock = LoadParamI(Section, "bProfile", -1, 0, FileName);

    // unlock memory
    GlobalUnlock(sPtr->hRTParam);
    GlobalUnlock(hScratchParam);
    GlobalUnlock(hParam);
    return(USR_NO_ERR);
}

int PASCAL UserPaintProc(HDC hDC, HANDLE hBioInfo, HANDLE hParam, HANDLE hScratchParam)
{
  BOOL            NeedToRelease;
  RECT            Rect;
  HWND            hWnd;
  HDC             hImageDC;
  HDC             hMemDC;
  HBITMAP         hMemBitmap;
  HBITMAP         hOldImage;
  HBITMAP         hOldMemBitmap;
  BLOCK_PARAM    *pPtr;
  SCRATCH_PARAM  *sPtr;

  // get pointer to block parameter structure
  if ((pPtr = (BLOCK_PARAM far *)GlobalLock(hParam)) == NULL)
      return(USR_ERR_NPT);

  // get pointer to scratch parameter structure
  if ((sPtr = (SCRATCH_PARAM far *)GlobalLock(hScratchParam))==NULL){
      GlobalUnlock(hParam);
      return(USR_ERR_NPT);
  }

  hWnd = GetBlockWindowHandle();
  GetClientRect(hWnd, &Rect);

  NeedToRelease = FALSE;
  if(hDC == NULL){
    NeedToRelease = TRUE;
    hDC = GetDC(hWnd);
  }

  hImageDC = CreateCompatibleDC(hDC);
  hMemDC = CreateCompatibleDC(hDC);
  hMemBitmap = CreateCompatibleBitmap(hDC, sPtr->Bitmap.bmWidth, sPtr->Bitmap.bmHeight);
  hOldMemBitmap = (HBITMAP)SelectObject(hMemDC, hMemBitmap);
  hOldImage = (HBITMAP)SelectObject(hImageDC, sPtr->hBitmap);

  // blit the image onto the memory dc
  BitBlt(hMemDC,0,0,sPtr->Bitmap.bmWidth,sPtr->Bitmap.bmHeight,hImageDC,0,0,SRCCOPY);

  // Blit the memory image to the screen
  StretchBlt(hDC,0,0,Rect.right,Rect.bottom,hMemDC,0,0,sPtr->Bitmap.bmWidth,sPtr->Bitmap.bmHeight,SRCCOPY);

  SelectObject(hImageDC, hOldImage);
  SelectObject(hMemDC, hOldMemBitmap);
  DeleteObject(hMemBitmap);
  DeleteDC(hImageDC);
  DeleteDC(hMemDC);

  if(NeedToRelease)
    ReleaseDC(hWnd, hDC);

  GlobalUnlock(hScratchParam);
  GlobalUnlock(hParam);
  return(USR_NO_ERR);
}



//===========================================================================
// Function   : DownloadDSPParameters()
// Purpose    : Downloads DSP user paramenters
// Parameters : pPtr  - Pointer to block parameter information structure
//              sPtr  - Pointer to real-time block parameter information structure
// Returns    : USR_NO_ERR if no error
//              Error Code if error
//===========================================================================
static int PASCAL DownloadDSPParameters(BLOCK_PARAM *pPtr, SCRATCH_PARAM *sPtr)
{
    RTBLOCK_PARAM     *bPtr = NULL;

    if ((bPtr=(RTBLOCK_PARAM *) GlobalLock (sPtr->hRTParam)) == NULL)
        return(USR_ERR_NPT);

    // copy values from PC block to real-time block structure

    // don't download parameters if block is not compiled or there are no parameters
    if((!bPtr->bBlockCompiled) || (bPtr->wNumParams==0)){
        GlobalUnlock (sPtr->hRTParam);
        return(USR_NO_ERR);
    }


    // download 'Changed' flag to xDAIS algorithm so that the control function will be called
    bPtr->dwData     = 1;
    bPtr->bDataType  = RTDT_LNG;
    bPtr->bMemType   = DATA_MEM;

    if (!RideSendCommand (sPtr->hDriver, DRV_WRMEMVAL, NULL, (LONG)sPtr->hRTParam)) {
        RideSendCommand(sPtr->hDriver,DRV_ERRMSG,NULL,(LONG)sPtr->hRTParam);
        GlobalUnlock(sPtr->hRTParam);
        return (USR_ERR_NPT);
    }

    // unlock memory
    GlobalUnlock (sPtr->hRTParam);

    return(USR_NO_ERR);
}
