/*
//============================================================================
//
//    FILE NAME : CPTDETECT.c
//
//    ALGORITHM : CPTDETECT
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in CPTDETECT.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 0
//
//    Creation Date: Thu - 17 February 2005
//    Creation Time: 01:32 PM
//
//============================================================================
*/

#pragma CODE_SECTION(CPTDETECT_create,  ".text:create")
#pragma CODE_SECTION(CPTDETECT_control, ".text:control")
#pragma CODE_SECTION(CPTDETECT_delete,  ".text:delete")
#pragma CODE_SECTION(CPTDETECT_init,    ".text:init")
#pragma CODE_SECTION(CPTDETECT_exit,    ".text:exit")

#include <std.h>
#include <alg.h>
#include <xdas.h>
#include "cptdetect.h"

/*
// ===========================================================================
// CPTDETECT_create
//
//  Create an CPTDETECT instance object (using parameters specified by prms)
*/
CPTDETECT_Handle CPTDETECT_create(const ICPTDETECT_Fxns *fxns, const CPTDETECT_Params *prms)
{
    return ((CPTDETECT_Handle)ALG_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// CPTDETECT_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int CPTDETECT_control(CPTDETECT_Handle handle, CPTDETECT_Cmd cmd, CPTDETECT_Status *status)
{
    return (ALG_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// CPTDETECT_delete
//
// Delete the CPTDETECT instance object specified by handle
*/
Void CPTDETECT_delete(CPTDETECT_Handle handle)
{
    ALG_delete((IALG_Handle)handle);
}

/*
// ===========================================================================
// CPTDETECT_init
//
// CPTDETECT module initialization
*/
Void  CPTDETECT_init(Void)
{
}

/*
// ===========================================================================
// CPTDETECT_exit
//
// CPTDETECT module finalization
*/
Void  CPTDETECT_exit(Void)
{
}

/*
// ===========================================================================
// CPTDETECT_apply
*/
CPTDETECT_Result CPTDETECT_apply(CPTDETECT_Handle handle, XDAS_Int32 * in)
{
    CPTDETECT_Result result;

    ALG_activate((IALG_Handle)handle);

    result = handle->fxns->apply(handle, in);

    ALG_deactivate((IALG_Handle)handle);

    return(result);
}
