-r
-m ..\Release\cptdetect.map
-o ..\Release\cptdetect.o67
-h
-g _CPTDETECT_KMITL_ICPTDETECT
-g _CPTDETECT_KMITL_IALG
-g _CPTDETECT_KMITL_alloc
-g _CPTDETECT_KMITL_free
-g _CPTDETECT_KMITL_initObj
-g _CPTDETECT_KMITL_control
-g _CPTDETECT_KMITL_moved
-g _CPTDETECT_KMITL_init
-g _CPTDETECT_KMITL_exit
-g _CPTDETECT_KMITL_apply

/* TODO: List all OBJ files which make up the algorithm here */
..\Release\CPTDETECT_KMITL_ialg.obj
..\Release\CPTDETECT_KMITL_ialgvt.obj
..\Release\iCPTDETECT.obj
..\Release\cptdetect_kmitl_priv.obj

SECTIONS
{
    .text:algAlloc {}
    .text:algInit {}
    .text:algFree {}
    .text:algMoved {}
/*
// The CPTDETECT_KMITL_activate & CPTDETECT_KMITL_deactivate routines are
// only used if scratch memory is being used.
    .text:algActivate {}
    .text:algDeactivate {}
*/
    .text:algControl {}
    .text:init {}
    .text:exit {}
}
