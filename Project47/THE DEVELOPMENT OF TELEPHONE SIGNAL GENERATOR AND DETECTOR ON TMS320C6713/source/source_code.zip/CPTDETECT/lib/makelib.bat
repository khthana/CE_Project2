@echo NOTE: Please execute the c:\ti\DosRun.bat file located in
@echo       your CCS installation directory before running this batch file.
lnk6x cptdetect.cmd
erase cptdetect_kmitl.l67
erase cptdetect.l67
ar6x -r cptdetect_kmitl.l67 ..\Release\cptdetect.o67
ar6x -r cptdetect.l67 ..\Release\cptdetect.obj
