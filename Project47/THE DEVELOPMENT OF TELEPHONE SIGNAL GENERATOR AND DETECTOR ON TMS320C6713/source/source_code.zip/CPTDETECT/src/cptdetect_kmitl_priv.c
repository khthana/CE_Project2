#define CALLOG
#define DETECT_CONST
#include "cptdetect_kmitl_priv.h"
#include "icptdetect.h"
#include "CPTdefine.h"

//===========================================================================
//=====================INTERNAL FUNCTION=====================================
//===========================================================================
void ResetParam(CPT_DetectParam* dparam)
{
	dparam->isDetected = 0;
	dparam->isRejected = 0;
	dparam->power = 0;
	dparam->result = 99;
	dparam->isConfirmation = 0;
	dparam->isSecondDetect = 0;
	dparam->isSecondReject = 0;
	dparam->SecondPower = 0;
	dparam->SecondResult =  99;
}

int kLog10(unsigned int x)
{
	unsigned int z;
	int y,k;

	if (0 == x) return (-2147483648);	// assume for -infinity value

	for (k=0; k <32; k++)
	{
		if (x & 0x80000000) break;
		x <<= 1;
	}

	y = LOG10_2N[k];

	//begin Knuth's log alg.
	z = x >> 1;
	for (k=1; k<LMAX_TERM;)
	{
		if (0x80000000 == x) break;

		if ((x-z) < 0x80000000)
		{
			z >>= 1;
			k++;
		}else
		{
			x -= z;
			z = x >> k;
			y += LOG10_2NM1[k];
		}
	} // for

	return (y);
} //int kLog10(...) 

// calculate power in dBm0
int calc_dBm0(unsigned int avgsq)
{
	int refm0 = M0_A_LAW;
	return ((kLog10(avgsq << 5)-refm0)/LSCALE);
} //int calc_dBm0(...)



int calcCoeff(int freq)	//up scale by *1000
{
	int res;
	switch(freq)
	{
		case 360:res = 1920;break;
		case 400:res = 1902;break;
		case 440:res = 1881;break;
		case 480:res = 1859;break;
		case 620:res = 1767;break;
		case 950:res = 1468;break;
		case 1100:res = 1298;break;
		case 1400:res = 907;break;
		case 1800:res = 312;break;
	}
	return res;
}

int DetectFV2(short* data, int SampCount, const int* DetectedFreq,const int* Threshold,const int FreqCount, int* Power,const int* Db)
{
	int max = 0;
	int divx = 64;//for down scale less than 4000,000,000
	int FullScaleFact;
	int u0,u1,t,in;
	int power = 0;
	int sum2 = 0;
	int a,x,i,co,p;
	*Power = power;

	for(a=0;a<SampCount;a++)
	{
		sum2 += data[a]*data[a];

		if(data[a] > max)
		{
			max = data[a];
		}
	}
	//tt = calc_dBm0(sum2/SampCount);
	p = calc_dBm0(sum2/SampCount)/100;

	if(p > Db[0] || p < Db[1])
	{
		return 0;
	}
	FullScaleFact = 4095*1000/max;
	
	for(i=0;i<FreqCount;i++)
	{
		u0 = u1 = 0;
		co = calcCoeff(DetectedFreq[i]);
		in = t = 0;

		for(x=0;x<SampCount;x++)	
		{
			in = ((data[x]*FullScaleFact)/1000)/divx;
			t = u0;
			u0 = in + ((co*u0)/1000)-u1;
			u1 = t;
		}
		power = (u0*u0 + u1*u1 - ((co*u0*u1)/1000));
		
		if(power > Threshold[i])
		{
			//LOG_printf(&trace,"f = %d power = %d",DetectedFreq[i],power);
			*Power = power;
			return DetectedFreq[i];
		}
	}
	return 0;
}

void ChangeState(CPT_DetectParam *param)
{
	param->isDetected = 0;
	param->isRejected = 0;
	param->CountPrev = 0;
}

void FoundCPT(CPT_DetectParam *param)
{
	param->isDetected = 1;
	param->isRejected = 0;
	param->CountPrev = 0;
	param->state = START;
}


unsigned char DetectSignal(CPT_DetectParam *param)
{
	int power;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"Start");
#endif
	switch(param->state)
	{
	case START:
		////DIAL TONE
		if(param->CntS >= DIAL_TONE_MIN_DURATION*8000/1000)
			if(DetectFV2(param->PrevData,100,DIAL_FREQ1,DIAL_THRESHOLD1,DIAL_NUM1,&param->power,DIAL_DB)
			&& DetectFV2(param->PrevData,100,DIAL_FREQ2,DIAL_THRESHOLD2,DIAL_NUM2,&param->power,DIAL_DB))
			{
				//ListResult->AddString(_T("DIAL TONE"));
				param->result = 0;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
			else if(DetectFV2(param->PrevData,40,DIAL_FREQ3,DIAL_THRESHOLD3,DIAL_NUM3,&param->power,DIAL_DB))
			{
				//ListResult->AddString(_T("DIAL TONE"));
				param->result = 0;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}

		////RING TONE
		if((param->CntS >= RING_TONE_MIN_DURATION*8000/1000 && param->CntS <= RING_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= RING_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= RING_PAUSE_MAX_DURATION*8000/1000))
			if(DetectFV2(param->PrevData,100,RING_FREQ,RING_THRESHOLD,RING_NUM,&param->power,RING_DB))
			{
				//ListResult->AddString(_T("RING TONE"));
				param->result = 1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
		////BUSY_TONE
		if((param->CntS >= BUSY_TONE_MIN_DURATION*8000/1000 && param->CntS <= BUSY_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= BUSY_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= BUSY_PAUSE_MAX_DURATION*8000/1000))
			if(DetectFV2(param->PrevData,100,BUSY_FREQ,BUSY_THRESHOLD,BUSY_NUM,&param->power,BUSY_DB))
			{
				//ListResult->AddString(_T("BUSY TONE"));
				param->result = 2;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
		////CONGESTION TONE
		if(
			(param->CntS >= CONGESTION_TONE_MIN_DURATION*8000/1000 && param->CntS <= CONGESTION_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= CONGESTION_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= CONGESTION_PAUSE_MAX_DURATION*8000/1000)
			&& ((param->CntS+param->CntZ) >= CONGESTION_TOTAL_MIN_DURATION*8000/1000 
				&& (param->CntS+param->CntZ) <= CONGESTION_TOTAL_MAX_DURATION*8000/1000)
			)
			if(DetectFV2(param->PrevData,100,CONGESTION_FREQ,CONGESTION_THRESHOLD,CONGESTION_NUM,&param->power,CONGESTION_DB))
			{
				//ListResult->AddString(_T("CONGESTION TONE"));
				param->result = 3;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
		////SPECIAL INFORMATION
		if((param->CntS >= SPECIAL_TONE_MIN_DURATION0*8000/1000 && param->CntS <= SPECIAL_TONE_MAX_DURATION0*8000/1000) 
			&& (param->CntZ >= SPECIAL_PAUSE_MIN_DURATION0*8000/1000 && param->CntZ <= SPECIAL_PAUSE_MAX_DURATION0*8000/1000))
			if(DetectFV2(param->PrevData,100,&SPECIAL_FREQ[0],&SPECIAL_THRESHOLD[0],SPECIAL_NUM,&param->power,SPECIAL_DB))
			{
				param->state = SPECIAL1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result SPECIAL1");
#endif
				ChangeState(param);
				return 0;
			}
		////WARNING TONE
		if((param->CntS >= WARNING_TONE_MIN_DURATION*8000/1000 && param->CntS <= WARNING_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= WARNING_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= WARNING_PAUSE_MAX_DURATION*8000/1000))
			if(DetectFV2(param->PrevData,100,WARNING_FREQ,WARNING_THRESHOLD,WARNING_NUM,&param->power,WARNING_DB))
			{
				//ListResult->AddString(_T("WARNING TONE"));
				param->result = 5;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
		////PAYPHONE TONE
		if((param->CntS >= PAYPHONE_TONE_MIN_DURATION0*8000/1000 && param->CntS <= PAYPHONE_TONE_MAX_DURATION0*8000/1000) 
			&& (param->CntZ >= PAYPHONE_PAUSE_MIN_DURATION0*8000/1000 && param->CntZ <= PAYPHONE_PAUSE_MAX_DURATION0*8000/1000))
			if(DetectFV2(param->PrevData,20,&PAYPHONE_FREQ[0],&PAYPHONE_THRESHOLD[0],PAYPHONE_NUM,&param->power,PAYPHONE_DB))
			{
				param->state = PAYPHONE1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result PAYPHONE1");
#endif
				ChangeState(param);
				return 0;
			}
		////CALL WAITING TONE
		if((param->CntS >= CALL_WAIT_TONE_MIN_DURATION*8000/1000 && param->CntS <= CALL_WAIT_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= CALL_WAIT_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= CALL_WAIT_PAUSE_MAX_DURATION*8000/1000))
			if(DetectFV2(param->PrevData,100,CALL_WAIT_FREQ,CALL_WAIT_THRESHOLD,CALL_WAIT_NUM,&param->power,CALL_WAIT_DB))
			{
				//ListResult->AddString(_T("CALL WAITING TONE"));
				param->result = 7;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
		////INTERCEPT TONE
		if(
			(param->CntS >= INTERCEPT_TONE_MIN_DURATION0*8000/1000 && param->CntS <= INTERCEPT_TONE_MAX_DURATION0*8000/1000) 
			&& ((param->CntS+param->CntZ) >= INTERCEPT_TOTAL_MIN_DURATION0*8000/1000 
				&& (param->CntS+param->CntZ) <= INTERCEPT_TOTAL_MAX_DURATION0*8000/1000)
			)
			if(DetectFV2(param->PrevData,100,&INTERCEPT_FREQ[0],&INTERCEPT_THRESHOLD[0],INTERCEPT_NUM,&param->power,INTERCEPT_DB))
			{
				param->state = INTERCEPT1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result INTERCEPT1");
#endif
				ChangeState(param);
				return 0;
			}
		////CONFIRMATION
		if((param->CntS >= CONFIRM_TONE_MIN_DURATION0*8000/1000 && param->CntS <= CONFIRM_TONE_MAX_DURATION0*8000/1000) 
			&& (param->CntZ >= CONFIRM_PAUSE_MIN_DURATION0*8000/1000 && param->CntZ <= CONFIRM_PAUSE_MAX_DURATION0*8000/1000))
			if((DetectFV2(param->PrevData,100,&CONFIRM_FREQ[0],&CONFIRM_THRESHOLD[0],CONFIRM_NUM,&param->power,CONFIRM_DB))
				&&(DetectFV2(param->PrevData,100,&CONFIRM_FREQ[1],&CONFIRM_THRESHOLD[1],CONFIRM_NUM,&param->power,CONFIRM_DB)))
			{
				param->state = RECALL_CONFIRM1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result RECALL_CONFIRM1");
#endif
				ChangeState(param);
				return 0;
			}
		////COMFORT TONE
		if(param->CntS >= COMFORT_TONE_MIN_DURATION*8000/1000)
			if(DetectFV2(param->PrevData,100,COMFORT_FREQ,COMFORT_THRESHOLD,COMFORT_NUM,&param->power,COMFORT_DB) &&
			!DetectFV2(param->PrevData,100,DIAL_FREQ1,DIAL_THRESHOLD1,DIAL_NUM1,&param->power,DIAL_DB))
			{
				//ListResult->AddString(_T("COMFORT TONE"));
				param->result = 11;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 0;
			}
		////BUSY VERIFICATION
		if((param->CntS >= BUSY_VER_TONE_MIN_DURATION0*8000/1000 && param->CntS <= BUSY_VER_TONE_MAX_DURATION0*8000/1000) 
			&& (param->CntZ >= BUSY_VER_PAUSE_MIN_DURATION0*8000/1000 && param->CntZ <= BUSY_VER_PAUSE_MAX_DURATION0*8000/1000))
			if(DetectFV2(param->PrevData,100,BUSY_VER_FREQ,BUSY_VER_THRESHOLD,BUSY_VER_NUM,&param->power,BUSY_VER_DB))
			{
				param->state = BUSY_VERIFICATION1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result BUSY_VERIFICATION1");
#endif
				ChangeState(param);
				return 0;
			}
		////CALLER WAITING
		if((param->CntS >= CALLER_TONE_MIN_DURATION*8000/1000 && param->CntS <= CALLER_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= CALLER_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= CALLER_PAUSE_MAX_DURATION*8000/1000))
			if(DetectFV2(param->PrevData,100,CALLER_FREQ,CALLER_THRESHOLD,CALLER_NUM,&param->power,CALLER_DB))
			{
				param->state = CALLER_WAITING1;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result CALLER_WAITING1");
#endif
				ChangeState(param);
				return 0;
			}
		
			
	case SPECIAL1:
		if((param->CntS >= SPECIAL_TONE_MIN_DURATION1*8000/1000 && param->CntS <= SPECIAL_TONE_MAX_DURATION1*8000/1000) 
			&& (param->CntZ >= SPECIAL_PAUSE_MIN_DURATION1*8000/1000 && param->CntZ <= SPECIAL_PAUSE_MAX_DURATION1*8000/1000))
			if(DetectFV2(param->PrevData,100,&SPECIAL_FREQ[1],&SPECIAL_THRESHOLD[1],SPECIAL_NUM,&param->power,SPECIAL_DB))
			{
				param->state = SPECIAL2;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result SPECIAL2");
#endif
				ChangeState(param);
				return 0;
			}
		break;
	case SPECIAL2:
		if((param->CntS >= SPECIAL_TONE_MIN_DURATION2*8000/1000 && param->CntS <= SPECIAL_TONE_MAX_DURATION2*8000/1000) 
			&& (param->CntZ >= SPECIAL_PAUSE_MIN_DURATION2*8000/1000 && param->CntZ <= SPECIAL_PAUSE_MAX_DURATION2*8000/1000))
			if(DetectFV2(param->PrevData,100,&SPECIAL_FREQ[2],&SPECIAL_THRESHOLD[2],SPECIAL_NUM,&param->power,SPECIAL_DB))
			{
				//ListResult->AddString(_T("SPECIAL INFORMATION"));
				param->result = 4;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 0;
			}
		break;
	case PAYPHONE1:
		if((param->CntS >= PAYPHONE_TONE_MIN_DURATION1*8000/1000 && param->CntS <= PAYPHONE_TONE_MAX_DURATION1*8000/1000) 
			&& (param->CntZ >= PAYPHONE_PAUSE_MIN_DURATION1*8000/1000 && param->CntZ <= PAYPHONE_PAUSE_MAX_DURATION1*8000/1000))
			if(DetectFV2(param->PrevData,16,&PAYPHONE_FREQ[1],&PAYPHONE_THRESHOLD[1],PAYPHONE_NUM,&param->power,PAYPHONE_DB))
			{
				//ListResult->AddString(_T("PAYPHONE TONE"));
				param->result = 6;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				//m_iState = START;
				return 0;
			}
		break;
	case RECALL_CONFIRM1:
		if((param->CntS >= CONFIRM_TONE_MIN_DURATION1*8000/1000 && param->CntS <= CONFIRM_TONE_MAX_DURATION1*8000/1000) 
			&& (param->CntZ >= CONFIRM_PAUSE_MIN_DURATION1*8000/1000 && param->CntZ <= CONFIRM_PAUSE_MAX_DURATION1*8000/1000))
			if((DetectFV2(param->PrevData,100,&CONFIRM_FREQ[0],&CONFIRM_THRESHOLD[0],CONFIRM_NUM,&param->power,CONFIRM_DB))
				&&(DetectFV2(param->PrevData,100,&CONFIRM_FREQ[1],&CONFIRM_THRESHOLD[1],CONFIRM_NUM,&param->power,CONFIRM_DB)))
			{
				param->state = RECALL_CONFIRM2;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result RECALL_CONFIRM2");
#endif
				ChangeState(param);
				return 0;
			}
		break;
	case RECALL_CONFIRM2:
		if((param->CntS >= CONFIRM_TONE_MIN_DURATION2*8000/1000 && param->CntS <= CONFIRM_TONE_MAX_DURATION2*8000/1000) 
			&& (param->CntZ >= CONFIRM_PAUSE_MIN_DURATION2*8000/1000 && param->CntZ <= CONFIRM_PAUSE_MAX_DURATION2*8000/1000))
			if((DetectFV2(param->PrevData,100,&CONFIRM_FREQ[0],&CONFIRM_THRESHOLD[0],CONFIRM_NUM,&param->power,CONFIRM_DB))
				&&(DetectFV2(param->PrevData,100,&CONFIRM_FREQ[1],&CONFIRM_THRESHOLD[1],CONFIRM_NUM,&param->power,CONFIRM_DB)))
			{
				param->state = RECALL_CONFIRM3;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result RECALL_CONFIRM3");
#endif
				ChangeState(param);
				return 0;
			}
		break;
	case RECALL_CONFIRM3:
		////DIAL TONE
		if(param->CntS >= DIAL_TONE_MIN_DURATION*8000/1000)
		{
			if(DetectFV2(param->PrevData,100,DIAL_FREQ1,DIAL_THRESHOLD1,DIAL_NUM1,&param->power,CONFIRM_DB)
			&& DetectFV2(param->PrevData,100,DIAL_FREQ2,DIAL_THRESHOLD2,DIAL_NUM2,&param->power,CONFIRM_DB))
			{
				//ListResult->AddString(_T("RECALL DIAL TONE"));
				param->result = 8;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
			else if(DetectFV2(param->PrevData,40,DIAL_FREQ3,DIAL_THRESHOLD3,DIAL_NUM3,&param->power,CONFIRM_DB))
			{
				//ListResult->AddString(_T("RECALL DIAL TONE"));
				param->result = 8;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				FoundCPT(param);
				return 1;
			}
		}
			//ListResult->AddString(_T("CONFIRMATION"));
			param->result = 10;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
			//////for detect second after detect confirmation
			param->state = START;
			power = param->power;
			DetectSignal(param);	//if not recall dial tone retrive 2 tone first is confirmation second is need to detect
			param->isConfirmation = 1;
			param->isSecondDetect = param->isDetected;
			param->isSecondReject = param->isRejected;
			param->isDetected = 1;
			param->isRejected = 0;
			param->SecondPower = param->power;
			param->power = power;
			param->SecondResult = param->result;
			param->result = 10;
			//////end detect second tone/////
			return 1;
			//break;
	case INTERCEPT1:
		if(
			(param->CntS >= INTERCEPT_TONE_MIN_DURATION1*8000/1000 && param->CntS <= INTERCEPT_TONE_MAX_DURATION1*8000/1000) 
			&& ((param->CntS+param->CntZ) >= INTERCEPT_TOTAL_MIN_DURATION1*8000/1000 
				&& (param->CntS+param->CntZ) <= INTERCEPT_TOTAL_MAX_DURATION1*8000/1000)
			)
			if(DetectFV2(param->PrevData,100,&INTERCEPT_FREQ[1],&INTERCEPT_THRESHOLD[1],INTERCEPT_NUM,&param->power,INTERCEPT_DB))
			{
				//ListResult->AddString(_T("INTERCEPT TONE"));
				param->result = 9;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				param->isDetected = 1;
				param->isRejected = 0;
				param->state = START;
				return 1;
			}
		break;
	case BUSY_VERIFICATION1:
		if((param->CntS >= BUSY_VER_TONE_MIN_DURATION1*8000/1000 && param->CntS <= BUSY_VER_TONE_MAX_DURATION1*8000/1000) 
			&& (param->CntZ >= BUSY_VER_PAUSE_MIN_DURATION1*8000/1000 && param->CntZ <= BUSY_VER_PAUSE_MAX_DURATION1*8000/1000))
			if(DetectFV2(param->PrevData,100,BUSY_VER_FREQ,BUSY_VER_THRESHOLD,BUSY_VER_NUM,&param->power,BUSY_VER_DB))
			{
				//ListResult->AddString(_T("BUSY VERIFICATION"));
				param->result = 12;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				param->isDetected = 1;
				param->isRejected = 0;
				param->state = START;
				return 1;
			}
		break;
	case CALLER_WAITING1:
		if((param->CntS >= CALL_WAIT_TONE_MIN_DURATION*8000/1000 && param->CntS <= CALL_WAIT_TONE_MAX_DURATION*8000/1000) 
			&& (param->CntZ >= CALL_WAIT_PAUSE_MIN_DURATION*8000/1000 && param->CntZ <= CALL_WAIT_PAUSE_MAX_DURATION*8000/1000))
			if(DetectFV2(param->PrevData,100,CALL_WAIT_FREQ,CALL_WAIT_THRESHOLD,CALL_WAIT_NUM,&param->power,CALLER_DB))
			{
				//ListResult->AddString(_T("CALLER WAITING"));
				param->result = 13;
#ifdef DEBUG_MODE
				LOG_printf(&trace,"result %d",param->result);
#endif
				param->isDetected = 1;
				param->isRejected = 0;
				param->state = START;
				return 1;
			}
		break;
	}
	
	param->result = 99;	//REJECT
	param->isDetected = 0;
	param->isRejected = 1;
	param->power = 0;
#ifdef DEBUG_MODE
	LOG_printf(&trace,"result REJECT!?!??!");
#endif

	if(param->state != START)
	{
		param->state = START;
		DetectSignal(param);
		param->isConfirmation = 0;
		param->isSecondDetect = param->isDetected;
		param->isSecondReject = param->isRejected;
		param->isDetected = 0;
		param->isRejected = 1;
		param->SecondPower = param->power;
		param->power = 0;
		param->SecondResult = param->result;
		param->result = 99;
	}
	param->state = START;
	
	
	//ListResult->AddString(_T("REJECT!?!?!"));
	return 0;
}

unsigned char isSilence(int data,int minvalue)
{
	int logpow = calc_dBm0(data*data);

	if (logpow <= minvalue)
	{
		return 1;
	}else
	{
		return 0;
	}
}	// isSilence(...)
