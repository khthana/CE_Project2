/*
//============================================================================
//
//    FILE NAME : CPTDETECT_KMITL_ialgvt.c
//
//    ALGORITHM : CPTDETECT
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the CPTDETECT_KMITL module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 0
//
//    Creation Date: Thu - 17 February 2005
//    Creation Time: 01:32 PM
//
//============================================================================
*/

#include <std.h>
#include "icptdetect.h"

#include "cptdetect_kmitl.h"

extern Int  CPTDETECT_KMITL_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  CPTDETECT_KMITL_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  CPTDETECT_KMITL_free(IALG_Handle, IALG_MemRec *);
extern Int  CPTDETECT_KMITL_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  CPTDETECT_KMITL_numAlloc(Void);
extern Void CPTDETECT_KMITL_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
/*
// The CPTDETECT_KMITL_activate & CPTDETECT_KMITL_deactivate routines are
// only used if scratch memory is being used.
extern Void CPTDETECT_KMITL_activate(IALG_Handle);
extern Void CPTDETECT_KMITL_deactivate(IALG_Handle);
*/
extern CPTDETECT_Result CPTDETECT_KMITL_apply(ICPTDETECT_Handle handle, XDAS_Int32 * in);

#define IALGFXNS \
    &CPTDETECT_KMITL_IALG,       /* module ID                            */ \
    NULL,                        /* activate   (NULL => not suported)    */ \
    CPTDETECT_KMITL_alloc,       /* algAlloc                             */ \
    CPTDETECT_KMITL_control,     /* control    (NULL => not suported)    */ \
    NULL,                        /* deactivate (NULL => not suported)    */ \
    CPTDETECT_KMITL_free,        /* free                                 */ \
    CPTDETECT_KMITL_initObj,     /* init                                 */ \
    CPTDETECT_KMITL_moved,       /* moved      (NULL => not suported)    */ \
    NULL                         /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// CPTDETECT_KMITL_ICPTDETECT
//
// This structure defines KMITL's implementation of the ICPTDETECT interface
// for the CPTDETECT_KMITL module.
*/
ICPTDETECT_Fxns CPTDETECT_KMITL_ICPTDETECT = {	/* module_vendor_interface */
    IALGFXNS,
    CPTDETECT_KMITL_apply,
};

/*
//============================================================================
// CPTDETECT_KMITL_IALG
//
// This structure defines KMITL's implementation of the IALG interface
// for the CPTDETECT_KMITL module.
*/
#ifdef _TI_
asm("_CPTDETECT_KMITL_IALG .set _CPTDETECT_KMITL_ICPTDETECT");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns CPTDETECT_KMITL_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
