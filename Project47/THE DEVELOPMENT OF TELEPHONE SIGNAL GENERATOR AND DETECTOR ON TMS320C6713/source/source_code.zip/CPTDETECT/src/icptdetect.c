/*
//============================================================================
//
//    FILE NAME : ICPTDETECT.c
//
//    ALGORITHM : CPTDETECT
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iCPTDETECT.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 0
//
//    Creation Date: Thu - 17 February 2005
//    Creation Time: 01:32 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "icptdetect.h"

/*
// ===========================================================================
// CPTDETECT_PARAMS
//
// This constant structure defines the default parameters for CPTDETECT objects
*/
ICPTDETECT_Params ICPTDETECT_PARAMS = {
    sizeof(ICPTDETECT_Params),
    1, /* unsigned int  framesizeIn0 */
};
