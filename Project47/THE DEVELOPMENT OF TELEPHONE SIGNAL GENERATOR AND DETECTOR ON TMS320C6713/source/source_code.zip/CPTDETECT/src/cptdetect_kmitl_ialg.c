/*
//============================================================================
//
//    FILE NAME : CPTDETECT_KMITL_ialg.c
//
//    ALGORITHM : CPTDETECT
//
//    VENDOR    : KMITL
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the CPTDETECT_KMITL.h interface; KMITL's
//                implementation of the ICPTDETECT interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 0
//
//    Creation Date: Thu - 17 February 2005
//    Creation Time: 01:32 PM
//
//============================================================================
*/

#pragma CODE_SECTION(CPTDETECT_KMITL_alloc,      ".text:algAlloc")
#pragma CODE_SECTION(CPTDETECT_KMITL_free,       ".text:algFree")
#pragma CODE_SECTION(CPTDETECT_KMITL_initObj,    ".text:algInit")
#pragma CODE_SECTION(CPTDETECT_KMITL_control,    ".text:algControl")
#pragma CODE_SECTION(CPTDETECT_KMITL_init,       ".text:init")
#pragma CODE_SECTION(CPTDETECT_KMITL_exit,       ".text:exit")
#pragma CODE_SECTION(CPTDETECT_KMITL_moved,      ".text:algMoved")
/*
// The CPTDETECT_KMITL_activate & CPTDETECT_KMITL_deactivate routines are
// only used if scratch memory is being used.
#pragma CODE_SECTION(CPTDETECT_KMITL_activate,   ".text:algActivate")
#pragma CODE_SECTION(CPTDETECT_KMITL_deactivate, ".text:algDeactivate")
*/
#include <std.h>
#include <limits.h>
#include "icptdetect.h"
#include "cptdetect_kmitl.h"
#include "CPTdefine.h"

#define PARAM 1
#define MTAB_NRECS 2
#define PARAM_SIZE 1

/*
//============================================================================
// CPTDETECT_KMITL_Obj
*/
typedef struct CPTDETECT_KMITL_Obj {
    IALG_Obj        alg;   /* MUST be first field of all CPTDETECT objs */
    XDAS_UInt32     framesizeIn0;
    CPT_DetectParam *param;

    /* TODO: add custom fields here */
} CPTDETECT_KMITL_Obj;

/*
//============================================================================
// CPTDETECT_KMITL_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the CPTDETECT_KMITL processing methods.
*/
/*
// The CPTDETECT_KMITL_activate & CPTDETECT_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void CPTDETECT_KMITL_activate(IALG_Handle handle)
{
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;
    
    // TODO: implement algActivate
}
*/

/*
//============================================================================
// CPTDETECT_KMITL_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a CPTDETECT_KMITL_Obj structure.
*/
Int CPTDETECT_KMITL_alloc(const IALG_Params *CPTDETECTParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const ICPTDETECT_Params *params = (Void *)CPTDETECTParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &ICPTDETECT_PARAMS;  /* set default parameters */
    }

    /* Request memory for CPTDETECT object */
    memTab[0].size = sizeof(CPTDETECT_KMITL_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;

    // NOTE: Some algorithms may be better suited to use an equation to define memtab
    //       size(s). User may want to modify the size field as required by his algorithm.

    /* Request memory for param array */
    memTab[PARAM].size = sizeof(CPT_DetectParam);
    memTab[PARAM].alignment = 0;
    memTab[PARAM].space = IALG_DARAM0;
    memTab[PARAM].attrs = IALG_PERSIST;

    return (MTAB_NRECS);
}

/*
//============================================================================
// CPTDETECT_KMITL_control
//
// Control our object's parameters while the algorithm is running
*/
Int CPTDETECT_KMITL_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    ICPTDETECT_Status *sPtr = (ICPTDETECT_Status *)status;	
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;

    switch ((ICPTDETECT_Cmd)cmd) {

       case ICPTDETECT_GETSTATUS:

            return(IALG_EOK);

       case ICPTDETECT_SETSTATUS:

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// CPTDETECT_KMITL_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the CPTDETECT_KMITL processing methods to persistent memory.
*/
/*
// The CPTDETECT_KMITL_activate & CPTDETECT_KMITL_deactivate routines are
// only used if scratch memory is being used.
Void CPTDETECT_KMITL_deactivate(IALG_Handle handle)
{
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;
    
    // TODO: implement algDeactivate
}
*/

/*
//============================================================================
// CPTDETECT_KMITL_exit
//
// Exit the CPTDETECT_KMITL module as a whole.
 */
Void CPTDETECT_KMITL_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// CPTDETECT_KMITL_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// CPTDETECT_KMITL_alloc operation above.
*/
Int CPTDETECT_KMITL_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;

    n = CPTDETECT_KMITL_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[PARAM].base = CPTDETECT->param;

    return (n);
}

/*
//============================================================================
// CPTDETECT_KMITL_init
//
// Initialize the CPTDETECT_KMITL module as a whole.
*/
Void CPTDETECT_KMITL_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// CPTDETECT_KMITL_initObj
//
// Initialize the memory allocated for our instance.
*/
Int CPTDETECT_KMITL_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *CPTDETECTParams)
{
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;
    const ICPTDETECT_Params *params = (Void *)CPTDETECTParams;

    if(params == NULL){
        params = &ICPTDETECT_PARAMS; /* set default parameters */
    }

    CPTDETECT->framesizeIn0 = params->framesizeIn0;
    CPTDETECT->param = memTab[PARAM].base;

    CPTDETECT->param->CntS = 0;
	CPTDETECT->param->CntZ = 0;
	CPTDETECT->param->InterruptCntS = 0;
	CPTDETECT->param->isDetected = 0;
	CPTDETECT->param->isRejected = 0;
	CPTDETECT->param->power = 0;
	CPTDETECT->param->result = 99;
	CPTDETECT->param->CountPrev = 0;
	CPTDETECT->param->state = START;
	CPTDETECT->param->isConfirmation = 0;
	CPTDETECT->param->isSecondDetect = 0;
	CPTDETECT->param->isSecondReject = 0;
	CPTDETECT->param->SecondPower = 0;
	CPTDETECT->param->SecondResult =  99;
	CPTDETECT->param->StartKeep = 1;
	CPTDETECT->param->FirstStart = 1;
    
    return (IALG_EOK);
}

/*
//============================================================================
// CPTDETECT_KMITL_moved
//
// Adjust any data pointers that has been moved by the client.
*/
Void CPTDETECT_KMITL_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *CPTDETECTParams)
{
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;
    const ICPTDETECT_Params *params = (Void *)CPTDETECTParams;

    CPTDETECT->param = memTab[PARAM].base;
}

/*
//============================================================================
// CPTDETECT_KMITL_apply
// KMITL's implementation of the apply operation.
// Custom fields of the CPTDETECT_KMITL_Obj may be accessed as follows:
//     CPTDETECT->framesizeIn0 = ...;
//     CPTDETECT->param = ...;
*/
CPTDETECT_Result CPTDETECT_KMITL_apply(ICPTDETECT_Handle handle, XDAS_Int32 * in)
{
    CPTDETECT_KMITL_Obj *CPTDETECT = (Void *)handle;
    
    CPTDETECT_Result result;

    int i;
	
	ResetParam(CPTDETECT->param);
	
	CPTDETECT->param->data = in;

	for(i=0;i<CPTDETECT->framesizeIn0;i++)
	{
		int temp = CPTDETECT->param->data[i];
		if(isSilence(temp,CPTsilence) == 0)	//false = not silence
		{
			
			if(CPTDETECT->param->CntZ <= CPT_INTR)	//Interrupt between Tone Duration
			{
				CPTDETECT->param->CntS += CPTDETECT->param->CntZ;
				CPTDETECT->param->CntZ = 0;
				if(CPTDETECT->param->CntZ > 1)
				{
					CPTDETECT->param->CountPrev = 0;
				}
				CPTDETECT->param->CntS++;
			}
			else if(CPTDETECT->param->InterruptCntS <= CPT_PAUSE_INTR && CPTDETECT->param->CntZ > CPT_INTR) //Interrupt between Pause Duration
			{
				CPTDETECT->param->InterruptCntS++;
			}
			else if(CPTDETECT->param->InterruptCntS > CPT_PAUSE_INTR && CPTDETECT->param->CntZ > CPT_INTR) //Not Interrupt between Pause Duration AND Complete 1 cycle signal
			{
				
				CPTDETECT->param->StartKeep = 1;
				CPTDETECT->param->CntZ--;
				//CPT_Process
				DetectSignal(CPTDETECT->param);
				//END CPT_Process
				CPTDETECT->param->CntS = CPTDETECT->param->CntZ = 0;
				CPTDETECT->param->CntS = CPTDETECT->param->InterruptCntS;
				CPTDETECT->param->InterruptCntS = 0;
				CPTDETECT->param->CountPrev = 0;	//reset keep data
				CPTDETECT->param->CntS++;	//for first sample is zero
				CPTDETECT->param->CntS++;	//for recent sample is Tone
			}
			
			if(CPTDETECT->param->CntS > DIAL_TONE_MIN_DURATION*SAMP_RATE/1000)	//for detect dial tone duration
			{
				DetectSignal(CPTDETECT->param);
				CPTDETECT->param->CntS = CPTDETECT->param->CntZ = 0;
				CPTDETECT->param->CountPrev = 0;	//reset keep data
				CPTDETECT->param->CntS++;
			}
		}
		else	//silence
		{
			if(CPTDETECT->param->InterruptCntS == 0)
			{
				CPTDETECT->param->CntZ++;
			}
			else	//if CntS is Interrupt between Pause Duration
			{
				CPTDETECT->param->CntZ += CPTDETECT->param->InterruptCntS;
				CPTDETECT->param->CntZ++;
				CPTDETECT->param->InterruptCntS = 0;
			}
		}
		
		if(CPTDETECT->param->StartKeep == 1)
		{
			if(CPTDETECT->param->CountPrev < 200)	//count data for cal goertzel power
			{
				if(CPTDETECT->param->CountPrev == 0)
				{
					if(!CPTDETECT->param->FirstStart)
					{
						CPTDETECT->param->PrevData[CPTDETECT->param->CountPrev] = 0;
						CPTDETECT->param->CountPrev++;
					}
					else
					{
						CPTDETECT->param->FirstStart = 0;
					}
				}
				
				CPTDETECT->param->PrevData[CPTDETECT->param->CountPrev] = temp;
				CPTDETECT->param->CountPrev++;
				if(CPTDETECT->param->CountPrev == 200)
				{
					CPTDETECT->param->StartKeep = 0;
				}
			}
		}
	}
	
	result.isConfirmation = CPTDETECT->param->isConfirmation;
	result.isDetected = CPTDETECT->param->isDetected;
	result.isRejected = CPTDETECT->param->isRejected;
	result.isSecondDetect = CPTDETECT->param->isSecondDetect;
	result.isSecondReject = CPTDETECT->param->isSecondReject;
	result.result = CPTDETECT->param->result;
	result.SecondResult = CPTDETECT->param->SecondResult;

    return result;
}
