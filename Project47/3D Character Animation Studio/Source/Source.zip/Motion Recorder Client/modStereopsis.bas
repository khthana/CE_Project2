Attribute VB_Name = "modStereopsis"
Option Explicit

' Types
Public Type STR_WORLDCOOR
    x As Double
    y As Double
    z As Double
End Type

Public Type STR_IMAGECOOR
    x As Long
    y As Long
End Type

Public Type STR_IMAGESIZE
    width As Long
    height As Long
End Type

Public Type STR_CAMERA
    x As Double         ' Camera position (metres)
    y As Double
    z As Double
    focus As Double     ' Focal length (metres)
    iwidth As Double    ' Image plane size (metres)
    iheight As Double
End Type

' Declarations
Public Declare Function GetImageCoordinate Lib "MotionRec.dll" (coorPt As STR_WORLDCOOR, cam As STR_CAMERA, szImg As STR_IMAGESIZE) As STR_IMAGECOOR

