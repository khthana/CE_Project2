VERSION 5.00
Object = "{A91E1E76-6AE7-11D4-AD08-A8AB2E818B70}#1.0#0"; "VideoOCX.ocx"
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Motion Recorder Client"
   ClientHeight    =   7815
   ClientLeft      =   150
   ClientTop       =   540
   ClientWidth     =   9600
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   521
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   640
   StartUpPosition =   3  'Windows Default
   Begin MSWinsockLib.Winsock sockMain 
      Left            =   480
      Top             =   600
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      Protocol        =   1
   End
   Begin VB.Timer tmrCapture 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   0
      Top             =   600
   End
   Begin VB.PictureBox picToolbar 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      ForeColor       =   &H80000008&
      Height          =   615
      Left            =   0
      ScaleHeight     =   39
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   638
      TabIndex        =   1
      Top             =   0
      Width           =   9600
      Begin VB.PictureBox Picture1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FF8080&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   285
         Left            =   5160
         ScaleHeight     =   19
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   169
         TabIndex        =   20
         Top             =   285
         Width           =   2535
         Begin VB.CommandButton cmdSetCamera 
            Caption         =   "Set ..."
            Height          =   255
            Left            =   1920
            TabIndex        =   24
            Top             =   15
            Width           =   615
         End
         Begin VB.OptionButton optCamRight 
            Caption         =   "Right"
            Height          =   255
            Left            =   1200
            Style           =   1  'Graphical
            TabIndex        =   22
            Top             =   15
            Width           =   615
         End
         Begin VB.OptionButton optCamLeft 
            Caption         =   "Left"
            Height          =   255
            Left            =   600
            Style           =   1  'Graphical
            TabIndex        =   21
            Top             =   15
            Value           =   -1  'True
            Width           =   615
         End
         Begin VB.Label Label5 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Camera"
            Height          =   195
            Left            =   0
            TabIndex        =   23
            Top             =   15
            Width           =   540
         End
      End
      Begin VB.PictureBox picFramerate 
         Appearance      =   0  'Flat
         BackColor       =   &H00FF8080&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   6600
         ScaleHeight     =   17
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   73
         TabIndex        =   15
         Top             =   0
         Width           =   1095
         Begin VB.TextBox txtFramerate 
            Appearance      =   0  'Flat
            Height          =   285
            Left            =   720
            MaxLength       =   2
            TabIndex        =   19
            Text            =   "25"
            Top             =   0
            Width           =   375
         End
         Begin VB.CommandButton Command1 
            Caption         =   "..."
            Height          =   285
            Left            =   4680
            TabIndex        =   17
            Top             =   0
            Width           =   375
         End
         Begin VB.Label Label4 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Framerate"
            Height          =   195
            Left            =   0
            TabIndex        =   16
            Top             =   0
            Width           =   705
         End
      End
      Begin VB.CommandButton cmdRecord 
         BackColor       =   &H00C0C0FF&
         Caption         =   "Start!"
         Height          =   495
         Left            =   8760
         Style           =   1  'Graphical
         TabIndex        =   14
         Top             =   45
         Width           =   735
      End
      Begin VB.PictureBox picVideo 
         Appearance      =   0  'Flat
         BackColor       =   &H00FF8080&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   2280
         ScaleHeight     =   17
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   281
         TabIndex        =   9
         Top             =   0
         Width           =   4215
         Begin VB.CommandButton cmdEncoder 
            Caption         =   "Codec ..."
            Height          =   255
            Left            =   2160
            TabIndex        =   25
            Top             =   0
            Width           =   855
         End
         Begin VB.CommandButton cmdFormat 
            Caption         =   "Format ..."
            Height          =   255
            Left            =   1320
            TabIndex        =   12
            Top             =   0
            Width           =   855
         End
         Begin VB.CommandButton cmdSource 
            Caption         =   "Source ..."
            Height          =   255
            Left            =   480
            TabIndex        =   11
            Top             =   0
            Width           =   855
         End
         Begin VB.Label lblDimension 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "9999x9999"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   195
            Left            =   3120
            TabIndex        =   13
            Top             =   0
            Width           =   930
         End
         Begin VB.Label Label3 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Video"
            Height          =   195
            Left            =   0
            TabIndex        =   10
            Top             =   0
            Width           =   435
         End
      End
      Begin VB.PictureBox picTarget 
         Appearance      =   0  'Flat
         BackColor       =   &H00FF8080&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   285
         Left            =   15
         ScaleHeight     =   19
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   336
         TabIndex        =   6
         Top             =   285
         Width           =   5040
         Begin VB.CommandButton cmdBrowseTrg 
            Caption         =   "..."
            Height          =   285
            Left            =   4680
            TabIndex        =   8
            Top             =   0
            Width           =   375
         End
         Begin VB.TextBox txtTarget 
            Appearance      =   0  'Flat
            Height          =   285
            Left            =   585
            TabIndex        =   18
            Text            =   "Sample.avi"
            Top             =   0
            Width           =   4095
         End
         Begin VB.Label Label2 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Target"
            Height          =   195
            Left            =   0
            TabIndex        =   7
            Top             =   0
            Width           =   465
         End
      End
      Begin VB.PictureBox picMode 
         Appearance      =   0  'Flat
         BackColor       =   &H00FF8080&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   15
         ScaleHeight     =   17
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   145
         TabIndex        =   2
         Top             =   15
         Width           =   2175
         Begin VB.OptionButton optModeRecord 
            Caption         =   "Record"
            Height          =   255
            Left            =   480
            Style           =   1  'Graphical
            TabIndex        =   4
            Top             =   0
            Value           =   -1  'True
            Width           =   855
         End
         Begin VB.OptionButton optModeCal 
            Caption         =   "Calibration"
            Height          =   255
            Left            =   1320
            Style           =   1  'Graphical
            TabIndex        =   3
            Top             =   0
            Width           =   855
         End
         Begin VB.Label Label1 
            AutoSize        =   -1  'True
            BackStyle       =   0  'Transparent
            Caption         =   "Mode"
            Height          =   195
            Left            =   0
            TabIndex        =   5
            Top             =   0
            Width           =   405
         End
      End
      Begin VB.Label lblAbout 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "About"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   240
         Left            =   7920
         TabIndex        =   26
         Top             =   120
         Width           =   615
      End
   End
   Begin VIDEOOCXLib.VideoOCX vdoMain 
      Height          =   7200
      Left            =   0
      TabIndex        =   0
      Top             =   615
      Width           =   9600
      _Version        =   65536
      _ExtentX        =   16933
      _ExtentY        =   12700
      _StockProps     =   0
      ScaledDisplay   =   0   'False
      SaveAudio       =   0   'False
      Driver          =   0
      ControlWidth    =   384
      ControlHeight   =   288
      Mode            =   0
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private vimgFrame As Long   ' Captured image
Private vimgBuffer As Long
Private cdlTarget As New clsCommonDialog

Private Sub cmdBrowseTrg_Click()
    cdlTarget.ShowOpen
    
    If Trim$(cdlTarget.FileName) = "" Then Exit Sub
    txtTarget.Text = cdlTarget.FileName
    txtTarget.SelStart = Len(txtTarget.Text)
End Sub

Private Sub cmdEncoder_Click()
    vdoMain.AVISaveMovieShowCompressionDlg
End Sub

Private Sub cmdFormat_Click()   ' Set video format
    If (optModeCal.Value) Then tmrCapture.Enabled = False: vdoMain.Stop
    CloseImages
    
    vdoMain.ShowFormatDlg
    
    InitImages
    If (optModeCal.Value) Then vdoMain.Start: tmrCapture.Enabled = True
    
    UpdateData
End Sub

Private Sub cmdRecord_Click()
    If (cmdRecord.Caption = TXT_STARTREC) Then
        ' Start button
        StartRecord
    Else
        ' Stop button
        StopRecord
    End If
End Sub

Private Sub cmdSetCamera_Click()
    frmFocusCal.Show vbModal
End Sub

Private Sub cmdSource_Click()   ' Set video source
    Dim CalMode As Boolean
    CalMode = optModeCal.Value
    
    If (CalMode) Then optModeRecord.Value = True: UpdateMode    ' Swap to record mode
    vdoMain.ShowSourceDlg
    If (CalMode) Then optModeCal.Value = True: UpdateMode   ' Swap back
End Sub

Private Sub Form_Load()
    LoadCamParams

    ' Control Init
    InitVideo
    With cdlTarget
        .flags = &H2 + &H4 + &H800
        .MaxFileSize = 254
        .DialogTitle = "Select target"
        .DefaultExt = "avi"
        .Filter = "AVI Video (*.avi)|*.avi|All files|*.*"
    End With
    sockMain.Bind CON_LOCALPORT
    cmdRecord.Caption = TXT_STARTREC
    
    ' Update control
    UpdateMode
    UpdateData
End Sub

Private Sub Form_Unload(Cancel As Integer)
    CloseVideo
    
    SaveCamParams
End Sub

Private Sub lblAbout_Click()
    frmAbout.Show vbModal
End Sub

Private Sub optModeCal_Click()
    UpdateMode
End Sub

Private Sub optModeRecord_Click()
    UpdateMode
End Sub

Private Sub sockMain_DataArrival(ByVal bytesTotal As Long)
        
    Dim tmpstr As String
    Dim DatArr() As String
    sockMain.GetData tmpstr
    DatArr = Split(tmpstr, ":")
    
    Select Case DatArr(0)
        Case "HELLO":
            If (DatArr(1) = sockMain.LocalIP) Then sockMain.RemoteHost = "127.0.0.1" Else sockMain.RemoteHost = DatArr(1)
            sockMain.SendData "HELLO:" + sockMain.LocalIP
        Case "START":
            If (optModeRecord.Value) And (cmdRecord.Caption = TXT_STARTREC) Then StartRecord
        Case "STOP":
            If (optModeRecord.Value) And (cmdRecord.Caption = TXT_STOPREC) Then StopRecord
        Case "FRAMERATE":
            txtFramerate.Text = DatArr(1)
        Case "FILENAME":
            txtTarget.Text = DatArr(1) + "." + Split(sockMain.LocalIP, ".")(3) + ".avi"   ' Filename + Last Octet + .AVI
    End Select
End Sub

Private Sub tmrCapture_Timer()
    vdoMain.Capture vimgFrame   ' Capture
    
    FAL_SetImageDimension vdoMain.GetWidth, vdoMain.GetHeight
    FAL_CopyImage vdoMain.GetDataPointer(vimgFrame), vdoMain.GetDataPointer(vimgBuffer)
    
    ' Draw marker
    Dim WorldPt As STR_WORLDCOOR
    Dim cam As STR_CAMERA
    Dim ImgSize As STR_IMAGESIZE
    Dim ImagePt As STR_IMAGECOOR
    Dim Color As F_PIXEL
    
    cam.focus = 0.005
    cam.iwidth = 0.0032
    cam.iheight = 0.0024
    If (optCamLeft.Value) Then  ' Select camera side
        cam.X = -1.5
    Else
        cam.X = 1.5
    End If
    cam.Y = -5.4
    cam.z = 0
    
    ImgSize.width = vdoMain.GetWidth
    ImgSize.height = vdoMain.GetHeight
    
    Color.red = CAL_MARKER_COLORR
    Color.green = CAL_MARKER_COLORG
    Color.blue = CAL_MARKER_COLORB
    
    WorldPt.X = 0
    WorldPt.Y = 0
    WorldPt.z = -1.23
    
    ImagePt = GetImageCoordinate(WorldPt, cam, ImgSize)
    FAL_DrawCrosshair vdoMain.GetDataPointer(vimgBuffer), ImagePt.X, vdoMain.GetHeight - ImagePt.Y - 1, CAL_MARKER_SIZE, Color
    
    WorldPt.X = -1.2
    WorldPt.Y = 0
    WorldPt.z = -1.23
    
    ImagePt = GetImageCoordinate(WorldPt, cam, ImgSize)
    FAL_DrawCrosshair vdoMain.GetDataPointer(vimgBuffer), ImagePt.X, vdoMain.GetHeight - ImagePt.Y - 1, CAL_MARKER_SIZE, Color
    
    WorldPt.X = 1.2
    WorldPt.Y = 0
    WorldPt.z = -1.23
    
    ImagePt = GetImageCoordinate(WorldPt, cam, ImgSize)
    FAL_DrawCrosshair vdoMain.GetDataPointer(vimgBuffer), ImagePt.X, vdoMain.GetHeight - ImagePt.Y - 1, CAL_MARKER_SIZE, Color

    WorldPt.X = 0
    WorldPt.Y = 0.9
    WorldPt.z = -1.23
    
    ImagePt = GetImageCoordinate(WorldPt, cam, ImgSize)
    FAL_DrawCrosshair vdoMain.GetDataPointer(vimgBuffer), ImagePt.X, vdoMain.GetHeight - ImagePt.Y - 1, CAL_MARKER_SIZE, Color

    WorldPt.X = -1.2
    WorldPt.Y = 0.9
    WorldPt.z = -1.23
    
    ImagePt = GetImageCoordinate(WorldPt, cam, ImgSize)
    FAL_DrawCrosshair vdoMain.GetDataPointer(vimgBuffer), ImagePt.X, vdoMain.GetHeight - ImagePt.Y - 1, CAL_MARKER_SIZE, Color

    WorldPt.X = 1.2
    WorldPt.Y = 0.9
    WorldPt.z = -1.23
    
    ImagePt = GetImageCoordinate(WorldPt, cam, ImgSize)
    FAL_DrawCrosshair vdoMain.GetDataPointer(vimgBuffer), ImagePt.X, vdoMain.GetHeight - ImagePt.Y - 1, CAL_MARKER_SIZE, Color
    
    vdoMain.Show vimgBuffer  ' Display
End Sub

Private Sub txtTarget_DblClick()
    cmdBrowseTrg_Click
End Sub

Private Sub InitVideo()  ' Init VideoOCX
    vdoMain.ScaledDisplay = True
    vdoMain.Init
    
    InitImages
End Sub

Private Sub CloseVideo()    ' Close VideoOCX
    vdoMain.Stop

    CloseImages

    vdoMain.AVISaveMovieClose
    vdoMain.Close
End Sub

Private Sub UpdateMode() ' Select Video Mode (Record or Calibration)
    If (optModeRecord.Value) Then
        ' Record mode
        tmrCapture.Enabled = False
        vdoMain.Stop
        vdoMain.SetPreview True
        
        ' Init save movie
        vdoMain.AVISaveMovieInit txtTarget.Text
        
        cmdEncoder.Enabled = True
        cmdRecord.Enabled = True
    Else
        ' Calibration mode
        vdoMain.AVISaveMovieClose   ' Close save movie
        vdoMain.SetPreview False
        vdoMain.Start
        tmrCapture.Enabled = True
        
        cmdEncoder.Enabled = False
        cmdRecord.Enabled = False
    End If
End Sub

Public Sub UpdateData(Optional SaveAndValidation As Boolean = False)
    If (SaveAndValidation) Then
        ' Form -> Data
    Else
        ' Data -> Form
        lblDimension.Caption = Format$(vdoMain.GetWidth, "0") + "x" + Format$(vdoMain.GetHeight, "0")
    End If
End Sub

Public Sub StartRecord()    ' Start record
    ' Validation
    Dim Framerate As Single
    
    If Dir(txtTarget.Text) <> "" Then Kill txtTarget.Text   ' Delete existing file
    Framerate = Val(txtFramerate.Text)
    If (Framerate <= 0) Then
        MsgBox "Invalid framerate.", vbExclamation + vbOKOnly
        txtFramerate.SetFocus
        txtFramerate.SelStart = 0
        txtFramerate.SelLength = Len(txtFramerate.Text)
        Exit Sub
    End If
    
    ' Init Record
    vdoMain.AVISaveMovieInit txtTarget.Text
    vdoMain.AVISaveMovieSetFrameRate Framerate
    vdoMain.Audio = False
    
    If (vdoMain.AVISaveMovieStart) Then
        ' Start record
        cmdRecord.Caption = TXT_STOPREC
        cmdRecord.BackColor = &HC0FFC0
        
        picMode.Enabled = False
        picVideo.Enabled = False
        picTarget.Enabled = False
        picFramerate.Enabled = False
    Else
        MsgBox "Cannot start recording.", vbExclamation + vbOKOnly
    End If
End Sub

Public Sub StopRecord() ' Stop record
    vdoMain.AVISaveMovieStop
    'vdoMain.AVISaveMovieClose
    
    cmdRecord.Caption = TXT_STARTREC
    cmdRecord.BackColor = &HC0C0FF
    
    picMode.Enabled = True
    picVideo.Enabled = True
    picTarget.Enabled = True
    picFramerate.Enabled = True
End Sub

Private Sub InitImages()    ' Allocate image frames
    vimgFrame = vdoMain.GetColorImageHandle
    vimgBuffer = vdoMain.GetColorImageHandle
End Sub

Private Sub CloseImages()   ' Deallocate image frames
    vdoMain.ReleaseImageHandle vimgBuffer
    vdoMain.ReleaseImageHandle vimgFrame
End Sub
