VERSION 5.00
Begin VB.Form frmFocusCal 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Camera Parameters Settings"
   ClientHeight    =   9120
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   7095
   Icon            =   "frmFocusCal.frx":0000
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   608
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   473
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   5760
      TabIndex        =   46
      Top             =   720
      Width           =   1215
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   5760
      TabIndex        =   45
      Top             =   240
      Width           =   1215
   End
   Begin VB.Frame Frame2 
      Caption         =   "Calculation"
      Height          =   2775
      Left            =   120
      TabIndex        =   25
      Top             =   3120
      Width           =   5535
      Begin VB.CommandButton cmdCopyRight 
         Caption         =   "Copy to Right"
         Height          =   615
         Left            =   4560
         TabIndex        =   58
         Top             =   1920
         Width           =   735
      End
      Begin VB.CommandButton cmdCopyLeft 
         Caption         =   "Copy to Left"
         Height          =   615
         Left            =   3840
         TabIndex        =   44
         Top             =   1920
         Width           =   735
      End
      Begin VB.TextBox txtCCDHeight 
         BackColor       =   &H8000000F&
         Height          =   315
         Left            =   2400
         Locked          =   -1  'True
         TabIndex        =   42
         Top             =   2280
         Width           =   1095
      End
      Begin VB.TextBox txtCCDWidth 
         BackColor       =   &H8000000F&
         Height          =   315
         Left            =   2400
         Locked          =   -1  'True
         TabIndex        =   39
         Top             =   1920
         Width           =   1095
      End
      Begin VB.TextBox txtFocus 
         Height          =   315
         Left            =   2400
         TabIndex        =   36
         Top             =   1320
         Width           =   1095
      End
      Begin VB.TextBox txtHeight 
         Height          =   315
         Left            =   2400
         TabIndex        =   33
         Top             =   960
         Width           =   1095
      End
      Begin VB.TextBox txtWidth 
         Height          =   315
         Left            =   2400
         TabIndex        =   30
         Top             =   600
         Width           =   1095
      End
      Begin VB.TextBox txtDist 
         Height          =   315
         Left            =   2400
         TabIndex        =   27
         Top             =   240
         Width           =   1095
      End
      Begin VB.Label Label36 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   3600
         TabIndex        =   43
         Top             =   2400
         Width           =   120
      End
      Begin VB.Label Label35 
         AutoSize        =   -1  'True
         Caption         =   "CCD Height:"
         Height          =   195
         Left            =   240
         TabIndex        =   41
         Top             =   2400
         Width           =   885
      End
      Begin VB.Label Label34 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   3600
         TabIndex        =   40
         Top             =   2040
         Width           =   120
      End
      Begin VB.Label Label33 
         AutoSize        =   -1  'True
         Caption         =   "CCD Width:"
         Height          =   195
         Left            =   240
         TabIndex        =   38
         Top             =   2040
         Width           =   840
      End
      Begin VB.Line Line1 
         X1              =   240
         X2              =   5160
         Y1              =   1800
         Y2              =   1800
      End
      Begin VB.Label Label32 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   3600
         TabIndex        =   37
         Top             =   1440
         Width           =   120
      End
      Begin VB.Label Label31 
         AutoSize        =   -1  'True
         Caption         =   "Prefered Focal Length:"
         Height          =   195
         Left            =   240
         TabIndex        =   35
         Top             =   1440
         Width           =   1620
      End
      Begin VB.Label Label30 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   3600
         TabIndex        =   34
         Top             =   1080
         Width           =   120
      End
      Begin VB.Label Label29 
         AutoSize        =   -1  'True
         Caption         =   "Height of object to be imaged:"
         Height          =   195
         Left            =   240
         TabIndex        =   32
         Top             =   1080
         Width           =   2130
      End
      Begin VB.Label Label28 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   3600
         TabIndex        =   31
         Top             =   720
         Width           =   120
      End
      Begin VB.Label Label27 
         AutoSize        =   -1  'True
         Caption         =   "Width of object to be imaged:"
         Height          =   195
         Left            =   240
         TabIndex        =   29
         Top             =   720
         Width           =   2085
      End
      Begin VB.Label Label26 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   3600
         TabIndex        =   28
         Top             =   360
         Width           =   120
      End
      Begin VB.Label Label25 
         AutoSize        =   -1  'True
         Caption         =   "Distance from lens to object:"
         Height          =   195
         Left            =   240
         TabIndex        =   26
         Top             =   360
         Width           =   2010
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Current Values"
      Height          =   2895
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   5535
      Begin VB.TextBox txtRightFocus 
         Height          =   315
         Left            =   3960
         TabIndex        =   49
         Top             =   600
         Width           =   1095
      End
      Begin VB.TextBox txtRightWidth 
         Height          =   315
         Left            =   3960
         TabIndex        =   48
         Top             =   960
         Width           =   1095
      End
      Begin VB.TextBox txtRightHeight 
         Height          =   315
         Left            =   3960
         TabIndex        =   47
         Top             =   1320
         Width           =   1095
      End
      Begin VB.TextBox txtRightY 
         Height          =   315
         Left            =   3960
         TabIndex        =   21
         Top             =   2040
         Width           =   1095
      End
      Begin VB.TextBox txtRightX 
         Height          =   315
         Left            =   3960
         TabIndex        =   18
         Top             =   1680
         Width           =   1095
      End
      Begin VB.TextBox txtLeftY 
         Height          =   315
         Left            =   1320
         TabIndex        =   15
         Top             =   2040
         Width           =   1095
      End
      Begin VB.TextBox txtLeftX 
         Height          =   315
         Left            =   1320
         TabIndex        =   12
         Top             =   1680
         Width           =   1095
      End
      Begin VB.TextBox txtLeftHeight 
         Height          =   315
         Left            =   1320
         TabIndex        =   9
         Top             =   1320
         Width           =   1095
      End
      Begin VB.TextBox txtLeftWidth 
         Height          =   315
         Left            =   1320
         TabIndex        =   6
         Top             =   960
         Width           =   1095
      End
      Begin VB.TextBox txtLeftFocus 
         Height          =   315
         Left            =   1320
         TabIndex        =   3
         Top             =   600
         Width           =   1095
      End
      Begin VB.Label Label9 
         AutoSize        =   -1  'True
         Caption         =   "Z Position:  0"
         Height          =   195
         Left            =   3120
         TabIndex        =   57
         Top             =   2520
         Width           =   930
      End
      Begin VB.Label Label8 
         AutoSize        =   -1  'True
         Caption         =   "Z Position:  0"
         Height          =   195
         Left            =   480
         TabIndex        =   56
         Top             =   2520
         Width           =   930
      End
      Begin VB.Line Line2 
         X1              =   2760
         X2              =   2760
         Y1              =   360
         Y2              =   2640
      End
      Begin VB.Label Label7 
         AutoSize        =   -1  'True
         Caption         =   "Focal Length:"
         Height          =   195
         Left            =   2880
         TabIndex        =   55
         Top             =   720
         Width           =   975
      End
      Begin VB.Label Label6 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   5160
         TabIndex        =   54
         Top             =   720
         Width           =   120
      End
      Begin VB.Label Label4 
         AutoSize        =   -1  'True
         Caption         =   "CCD Width:"
         Height          =   195
         Left            =   2880
         TabIndex        =   53
         Top             =   1080
         Width           =   840
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   5160
         TabIndex        =   52
         Top             =   1080
         Width           =   120
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         Caption         =   "CCD Height:"
         Height          =   195
         Left            =   2880
         TabIndex        =   51
         Top             =   1440
         Width           =   885
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   5160
         TabIndex        =   50
         Top             =   1440
         Width           =   120
      End
      Begin VB.Label Label24 
         AutoSize        =   -1  'True
         Caption         =   "Right Camera"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   3720
         TabIndex        =   24
         Top             =   240
         Width           =   1425
      End
      Begin VB.Label Label23 
         AutoSize        =   -1  'True
         Caption         =   "Left Camera"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1200
         TabIndex        =   23
         Top             =   240
         Width           =   1260
      End
      Begin VB.Label Label22 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   5160
         TabIndex        =   22
         Top             =   2160
         Width           =   120
      End
      Begin VB.Label Label21 
         AutoSize        =   -1  'True
         Caption         =   "Y Position:"
         Height          =   195
         Left            =   3120
         TabIndex        =   20
         Top             =   2160
         Width           =   750
      End
      Begin VB.Label Label20 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   5160
         TabIndex        =   19
         Top             =   1800
         Width           =   120
      End
      Begin VB.Label Label19 
         AutoSize        =   -1  'True
         Caption         =   "X Position:"
         Height          =   195
         Left            =   3120
         TabIndex        =   17
         Top             =   1800
         Width           =   750
      End
      Begin VB.Label Label18 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   2520
         TabIndex        =   16
         Top             =   2160
         Width           =   120
      End
      Begin VB.Label Label17 
         AutoSize        =   -1  'True
         Caption         =   "Y Position:"
         Height          =   195
         Left            =   480
         TabIndex        =   14
         Top             =   2160
         Width           =   750
      End
      Begin VB.Label Label16 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   2520
         TabIndex        =   13
         Top             =   1800
         Width           =   120
      End
      Begin VB.Label Label15 
         AutoSize        =   -1  'True
         Caption         =   "X Position:"
         Height          =   195
         Left            =   480
         TabIndex        =   11
         Top             =   1800
         Width           =   750
      End
      Begin VB.Label Label14 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   2520
         TabIndex        =   10
         Top             =   1440
         Width           =   120
      End
      Begin VB.Label Label13 
         AutoSize        =   -1  'True
         Caption         =   "CCD Height:"
         Height          =   195
         Left            =   240
         TabIndex        =   8
         Top             =   1440
         Width           =   885
      End
      Begin VB.Label Label12 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   2520
         TabIndex        =   7
         Top             =   1080
         Width           =   120
      End
      Begin VB.Label Label11 
         AutoSize        =   -1  'True
         Caption         =   "CCD Width:"
         Height          =   195
         Left            =   240
         TabIndex        =   5
         Top             =   1080
         Width           =   840
      End
      Begin VB.Label Label10 
         AutoSize        =   -1  'True
         Caption         =   "m"
         Height          =   195
         Left            =   2520
         TabIndex        =   4
         Top             =   720
         Width           =   120
      End
      Begin VB.Label Label5 
         AutoSize        =   -1  'True
         Caption         =   "Focal Length:"
         Height          =   195
         Left            =   240
         TabIndex        =   2
         Top             =   720
         Width           =   975
      End
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3030
      Left            =   600
      Picture         =   "frmFocusCal.frx":09BA
      ScaleHeight     =   3000
      ScaleWidth      =   4500
      TabIndex        =   0
      Top             =   6000
      Width           =   4530
   End
End
Attribute VB_Name = "frmFocusCal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdCancel_Click()
    Unload Me
End Sub

Private Sub cmdCopyLeft_Click()
    ' Validation
    If (Trim$(txtCCDWidth.Text) = "") Or (txtCCDWidth.Text = "N/A") Then GoTo Invalid:
    If (Trim$(txtCCDHeight.Text) = "") Or (txtCCDHeight.Text = "N/A") Then GoTo Invalid:
    If (Trim$(txtFocus.Text) = "") Or (Val(txtFocus.Text) <= 0) Then GoTo Invalid:

    txtLeftFocus.Text = txtFocus.Text
    txtLeftWidth.Text = txtCCDWidth.Text
    txtLeftHeight.Text = txtCCDHeight.Text
    
    Exit Sub
Invalid:
    MsgBox "Cannot copy invalid value.", vbExclamation + vbOKOnly
End Sub

Private Sub cmdCopyRight_Click()
    ' Validation
    If (Trim$(txtCCDWidth.Text) = "") Or (txtCCDWidth.Text = "N/A") Then GoTo Invalid:
    If (Trim$(txtCCDHeight.Text) = "") Or (txtCCDHeight.Text = "N/A") Then GoTo Invalid:
    If (Trim$(txtFocus.Text) = "") Or (Val(txtFocus.Text) <= 0) Then GoTo Invalid:
    
    txtRightFocus.Text = txtFocus.Text
    txtRightWidth.Text = txtCCDWidth.Text
    txtRightHeight.Text = txtCCDHeight.Text
    
    Exit Sub
Invalid:
    MsgBox "Cannot copy invalid value.", vbExclamation + vbOKOnly
End Sub

Private Sub cmdOK_Click()
    ' Update data
    With camLeft
        .focus = Val(txtLeftFocus.Text)
        .iwidth = Val(txtLeftWidth.Text)
        .iheight = Val(txtLeftHeight.Text)
        .X = Val(txtLeftX.Text)
        .Y = Val(txtLeftY.Text)
        .z = 0
    End With
    With camRight
        .focus = Val(txtRightFocus.Text)
        .iwidth = Val(txtRightWidth.Text)
        .iheight = Val(txtRightHeight.Text)
        .X = Val(txtRightX.Text)
        .Y = Val(txtRightY.Text)
        .z = 0
    End With

    Unload Me
End Sub

'Private Sub FocusCalButton_Click()
'    FocusSub = Str((Val(ImageSize) * Val(LenToObj)) / Val(ObjImage))
'    frmMain.FocusMain = FocusSub
'End Sub

Private Sub Form_Load()
    ' Display data
    With camLeft
        txtLeftFocus.Text = Format$(.focus, "0.00000")
        txtLeftWidth.Text = Format$(.iwidth, "0.00000")
        txtLeftHeight.Text = Format$(.iheight, "0.00000")
        txtLeftX.Text = Format$(.X, "0.00000")
        txtLeftY.Text = Format$(.Y, "0.00000")
    End With
    With camRight
        txtRightFocus.Text = Format$(.focus, "0.00000")
        txtRightWidth.Text = Format$(.iwidth, "0.00000")
        txtRightHeight.Text = Format$(.iheight, "0.00000")
        txtRightX.Text = Format$(.X, "0.00000")
        txtRightY.Text = Format$(.Y, "0.00000")
    End With
End Sub

Private Sub Calculate() ' Calculate
   ' Validation
   If (Trim$(txtDist.Text) = "") Then GoTo Invalid:
   If (Trim$(txtWidth.Text) = "") Then GoTo Invalid:
   If (Trim$(txtHeight.Text) = "") Then GoTo Invalid:
   If (Trim$(txtFocus.Text) = "") Then GoTo Invalid:
   
   If (Val(txtDist.Text) = 0) Then GoTo Invalid:
   
   'Calc
   txtCCDWidth.Text = Format$((Val(txtWidth.Text) * Val(txtFocus.Text)) / Val(txtDist.Text), "0.00000")
   txtCCDHeight.Text = Format$((Val(txtHeight.Text) * Val(txtFocus.Text)) / Val(txtDist.Text), "0.00000")
   
   Exit Sub
Invalid:
    txtCCDWidth.Text = "N/A"
    txtCCDHeight.Text = "N/A"
End Sub

Private Sub txtDist_Change()
    Calculate
End Sub

Private Sub txtFocus_Change()
    Calculate
End Sub

Private Sub txtHeight_Change()
    Calculate
End Sub

Private Sub txtWidth_Change()
    Calculate
End Sub
