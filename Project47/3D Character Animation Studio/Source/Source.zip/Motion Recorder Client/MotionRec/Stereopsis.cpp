// Stereopsis.cpp: implementation of the CStereopsis class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Stereopsis.h"
#include "Math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStereopsis::CStereopsis()
{
	
}

CStereopsis::~CStereopsis()
{

}

STR_CAMERA CStereopsis::GetLeftCamera(void)
{
	return m_leftcam;
}

void CStereopsis::SetLeftCamera(const STR_CAMERA &camLeft)
{
	m_leftcam = camLeft;
}

STR_CAMERA CStereopsis::GetRightCamera(void)
{
	return m_rightcam;
}

void CStereopsis::SetRightCamera(const STR_CAMERA &camRight)
{
	m_rightcam = camRight;
}

double CStereopsis::GetLeftZetaAngle(void)
{

	double zeta = atan(m_leftcam.y/m_leftcam.x);
	return zeta;
}

double CStereopsis::GetRightZetaAngle(void)
{

	double zeta = atan(m_rightcam.y/m_rightcam.x);
	return zeta;
}

STR_WORLDCOOR CStereopsis::GetWorldCoordinate(const STR_IMAGECOOR &coorLeft, const STR_IMAGESIZE &szLeft, 
											  const STR_IMAGECOOR &coorRight, const STR_IMAGESIZE &szRight)
{
	STR_WORLDCOOR ret;
	
	ret.x = 0;
	ret.y = 0;
	ret.z = 0;

	// Find x , y Coordinate
	double zetaL = atan(m_leftcam.y/m_leftcam.x);
	double zetaR = atan(m_rightcam.y/m_rightcam.x);
	double xpiccoorLeft = (double)coorLeft.x - ((double)szLeft.width/2);
	double xpiccoorRight = (double)coorRight.x - ((double)szRight.width/2);
	double dxLeft = m_leftcam.iwidth*(xpiccoorLeft/(double)szLeft.width);
	double dxRight = m_rightcam.iwidth*(xpiccoorRight/(double)szRight.width);
	double alphaL = atan(fabs(dxLeft)/m_leftcam.focus);
	double alphaR = atan(fabs(dxRight)/m_rightcam.focus);
	double mL=0, mR=0;
	if (dxLeft >= 0)
		mL = tan(zetaL - alphaL);
	else
		mL= tan(zetaL + alphaL);
	if (dxRight >= 0)
		mR = tan(zetaR - alphaR);
	else
		mR = tan(zetaR + alphaR);

	double cL = (-mL*m_leftcam.x) + m_leftcam.y;
	double cR = (-mR*m_rightcam.x) + m_rightcam.y;
	double xPos = (cR-cL)/(mL-mR);
	double yPos = (mL*xPos) + cL;

	// Find z coordinate
	double L = sqrt(((xPos - m_leftcam.x)*(xPos - m_leftcam.x)) + ((yPos - m_leftcam.y)*(yPos - m_leftcam.y)));
	double ypiccoorLeft = (double)szLeft.height - coorLeft.y;  // - 1???
	double y2piccoorLeft = ypiccoorLeft - ((double)szLeft.height/2);
	double dz = m_leftcam.iheight*(y2piccoorLeft/(double)szLeft.height);
	double zPos = (dz*L)/m_leftcam.focus;

	ret.x = xPos;
	ret.y = yPos;
	ret.z = zPos;

	return ret;
}

STR_IMAGECOOR CStereopsis::GetLeftImageCoordinate(const STR_WORLDCOOR &coorWorld, const STR_IMAGESIZE &szLeft)
{
	STR_IMAGECOOR ret;

	ret.x = 0;
	ret.y = 0;

	// Find X image position
	double zeta  = atan(m_leftcam.y/m_leftcam.x);
	double m  =(coorWorld.y - m_leftcam.y)/(coorWorld.x - m_leftcam.x);
	double beta  = atan(m );
	double alpha  = 0;
	if (beta  >= zeta )
		alpha = beta  - zeta ;
	else
		alpha = zeta  - beta ;
	double dx = m_leftcam.focus*tan(alpha );
	double xpixel = (dx *szLeft.width)/m_leftcam.iwidth;
	double xImagePos = 0;
	if (beta  >= zeta )
		xImagePos = (szLeft.width/2) - xpixel;
	else
		xImagePos = (szLeft.width/2) + xpixel;

	// Find Y image position
	double L = sqrt(((coorWorld.x - m_leftcam.x)*(coorWorld.x - m_leftcam.x)) + ((coorWorld.y - m_leftcam.y)*(coorWorld.y - m_leftcam.y)));
	double dz = (coorWorld.z*m_leftcam.focus)/L;
	double y2pixel = (dz*szLeft.height)/m_leftcam.iheight;
	double ypixel = y2pixel + (szLeft.height/2);
	double yImagePos = szLeft.height - ypixel; // -1 ????

	ret.x = (int)xImagePos;
	ret.y = (int)yImagePos;

	return ret;
}

STR_IMAGECOOR CStereopsis::GetRightImageCoordinate(const STR_WORLDCOOR &coorWorld, const STR_IMAGESIZE &szRight)
{
	STR_IMAGECOOR ret;

	ret.x = 0;
	ret.y = 0;

	// Find X image position
	double zeta = atan(m_rightcam.y/m_rightcam.x);
	double m =(coorWorld.y - m_rightcam.y)/(coorWorld.x - m_rightcam.x);
	double beta = atan(m );
	double alpha = 0;
	if (beta  >= zeta )
		alpha = beta  - zeta ;
	else
		alpha = zeta  - beta ;
	double dx = m_rightcam.focus*tan(alpha );
	double xpixel = (dx *szRight.width)/m_rightcam.iwidth;
	double xImagePos = 0;
	if (beta  >= zeta )
		xImagePos = (szRight.width/2) - xpixel;
	else
		xImagePos = (szRight.width/2) + xpixel;

	// Find Y image position
	double L = sqrt(((coorWorld.x - m_rightcam.x)*(coorWorld.x - m_rightcam.x)) + ((coorWorld.y - m_rightcam.y)*(coorWorld.y - m_rightcam.y)));
	double dz = (coorWorld.z*m_rightcam.focus)/L;
	double y2pixel = (dz*szRight.height)/m_rightcam.iheight;
	double ypixel = y2pixel + (szRight.height/2);
	double yImagePos = szRight.height - ypixel; // -1 ????

	ret.x = (int)xImagePos;
	ret.y = (int)yImagePos;
	return ret;
}
