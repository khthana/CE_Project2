// MotionRec.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Stereopsis.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

STR_IMAGECOOR WINAPI GetImageCoordinate(const STR_WORLDCOOR &coorPt, const STR_CAMERA &cam, 
										const STR_IMAGESIZE &szImg)
{
	CStereopsis str;
	str.SetLeftCamera(cam);
	return str.GetLeftImageCoordinate(coorPt, szImg);
}
