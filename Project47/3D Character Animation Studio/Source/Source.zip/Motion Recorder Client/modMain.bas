Attribute VB_Name = "modMain"
Option Explicit

Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

' Settings
Public Const CAL_MARKER_SIZE As Long = 5
Public Const CAL_MARKER_COLORR As Byte = 255
Public Const CAL_MARKER_COLORG As Byte = 0
Public Const CAL_MARKER_COLORB As Byte = 0

Public Const CON_LOCALPORT As Integer = 8195

Public Const TXT_STARTREC As String = "Start!"
Public Const TXT_STOPREC As String = "Stop"

Public Const CAMERA_FILE As String = "Cameras.dat"

' Global Variables
Public camLeft As STR_CAMERA
Public camRight As STR_CAMERA

Public Sub Main()
    If (App.PrevInstance) Then End
    ChDir App.Path
    
    ' Init default value
    camLeft.focus = 0.005
    camLeft.iwidth = 0.0032
    camLeft.iheight = 0.0024
    camLeft.X = -1.5
    camLeft.Y = -5.4
    camLeft.z = 0

    camRight.focus = 0.005
    camRight.iwidth = 0.0032
    camRight.iheight = 0.0024
    camRight.X = 1.5
    camRight.Y = -5.4
    camRight.z = 0

    frmMain.Show
End Sub

Public Sub LoadCamParams() ' Load camera parameters
    If (Dir(App.Path + "\" + CAMERA_FILE) = "") Then Exit Sub
    
    Open App.Path + "\" + CAMERA_FILE For Random As #1
        Get #1, , camLeft
        Get #1, , camRight
    Close #1
End Sub

Public Sub SaveCamParams() ' Save camera parameters
    If (Dir(App.Path + "\" + CAMERA_FILE) <> "") Then Kill App.Path + "\" + CAMERA_FILE
    
    Open App.Path + "\" + CAMERA_FILE For Random As #1
        Put #1, , camLeft
        Put #1, , camRight
    Close #1
End Sub
