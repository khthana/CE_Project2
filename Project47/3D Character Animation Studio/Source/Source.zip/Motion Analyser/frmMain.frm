VERSION 5.00
Begin VB.MDIForm frmMain 
   BackColor       =   &H8000000C&
   Caption         =   "Motion Analyser : 3D Character Animation Studio"
   ClientHeight    =   8220
   ClientLeft      =   165
   ClientTop       =   855
   ClientWidth     =   12015
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "frmMain"
   StartUpPosition =   3  'Windows Default
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuOpenLeft 
         Caption         =   "Open Left Video ..."
      End
      Begin VB.Menu mnuOpenRight 
         Caption         =   "Open Right Video ..."
      End
      Begin VB.Menu mnuSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExportCSM 
         Caption         =   "Export as CSM ..."
      End
      Begin VB.Menu mnuExportCSV 
         Caption         =   "Export as CSV ..."
      End
      Begin VB.Menu mnuSep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuShowColor 
         Caption         =   "Color Settings"
      End
      Begin VB.Menu mnuStereopsis 
         Caption         =   "Stereopsis Settings"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuAbout 
         Caption         =   "&About Motion Analyser ..."
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' ====================================================================== MEMBER VARIABLES
' Flags

' Common dialog
Private cdlOpen As New clsCommonDialog

' Video Windows
Private vdoLeft As New frmVideo
Private vdoRight As New frmVideo

' ====================================================================== PRIVATE FUNCTIONS

' ====================================================================== PUBLIC FUNCTIONS

' ====================================================================== EVENT HANDLES

Private Sub MDIForm_Load()
    ' Init variables
    
    ' Load data
    LoadColors
    LoadStereopsis
End Sub

Private Sub MDIForm_Unload(Cancel As Integer)
    SaveColors
    SaveStereopsis
    End ' End program
End Sub

Private Sub mnuAbout_Click()
    frmAbout.Show vbModal
End Sub

Private Sub mnuExit_Click()
    Unload Me
End Sub

Private Sub mnuExportCSM_Click()    ' Generate CSM File
    ' Validation
    If (Not vdoLeft.flgOpenned) Then MsgBox "Please open left video file first.", vbExclamation + vbOKOnly: Exit Sub
    If (Not vdoRight.flgOpenned) Then MsgBox "Please open right video file first.", vbExclamation + vbOKOnly: Exit Sub
    
    Load frmExportCSM
    frmExportCSM.SetVideoForm vdoLeft, vdoRight
    frmExportCSM.Show vbModal

End Sub

Private Sub mnuExportCSV_Click()    ' Generate CSV File
    ' Validation
    If (Not vdoLeft.flgOpenned) Then MsgBox "Please open left video file first.", vbExclamation + vbOKOnly: Exit Sub
    If (Not vdoRight.flgOpenned) Then MsgBox "Please open right video file first.", vbExclamation + vbOKOnly: Exit Sub
    
    Load frmExportCSV
    frmExportCSV.SetVideoForm vdoLeft, vdoRight
    frmExportCSV.Show vbModal

End Sub

Private Sub mnuOpenLeft_Click() ' Open left vieo
    ' Validation
    If (vdoLeft.flgOpenned) Then
        If (MsgBox("Left video is already openned. Opening new file will cause all data lose. Continue?", vbExclamation + vbYesNo) = vbNo) Then Exit Sub
    End If

    With cdlOpen
        .DialogTitle = "Open Left Video"
        .Filter = "AVI Video|*.avi|All files|*.*"
        .flags = &H4 + &H800 + &H1000
        .MaxFileSize = 254
        .Filename = ""
    End With
    cdlOpen.ShowOpen
    
    ' Open left video window
    If Trim$(cdlOpen.Filename <> "") Then
        If (vdoLeft.InitVideo(cdlOpen.Filename)) Then
            vdoLeft.Show
        Else
            MsgBox "Cannot open the video file.", vbExclamation + vbOKOnly
            Unload vdoLeft
        End If
    End If
    ChDir App.Path
End Sub

Private Sub mnuOpenRight_Click()
    If (vdoRight.flgOpenned) Then
        If (MsgBox("Right video is already openned. Open new file will cause all data lose. Continue?", vbExclamation + vbYesNo) = vbNo) Then Exit Sub
    End If

    With cdlOpen
        .DialogTitle = "Open Right Video"
        .Filter = "AVI Video|*.avi|All files|*.*"
        .flags = &H4 + &H800 + &H1000
        .MaxFileSize = 254
        .Filename = ""
    End With
    cdlOpen.ShowOpen
    
    ' Open right video window
    If Trim$(cdlOpen.Filename <> "") Then
        If (vdoRight.InitVideo(cdlOpen.Filename)) Then
            vdoRight.Show
        Else
            MsgBox "Cannot open the video file.", vbExclamation + vbOKOnly
            Unload vdoRight
        End If
    End If
    ChDir App.Path
End Sub

Private Sub mnuShowColor_Click()    ' Show color settings dialog
    If (mnuShowColor.Checked) Then
        frmColor.Hide
    Else
        frmColor.Show
    End If
    mnuShowColor.Checked = Not mnuShowColor.Checked
End Sub

Private Sub mnuStereopsis_Click()   ' Show stereopsis settings
    If (mnuStereopsis.Checked) Then
        frmStereopsis.Hide
    Else
        frmStereopsis.Show
    End If
    mnuStereopsis.Checked = Not mnuStereopsis.Checked
End Sub
