VERSION 5.00
Begin VB.Form frmStereopsis 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Stereopsis Settings"
   ClientHeight    =   3855
   ClientLeft      =   2760
   ClientTop       =   3630
   ClientWidth     =   5415
   Icon            =   "frmStereopsis.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   257
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   361
   ShowInTaskbar   =   0   'False
   Begin VB.TextBox txtZOffset 
      Height          =   315
      Left            =   960
      TabIndex        =   27
      Top             =   2880
      Width           =   1215
   End
   Begin VB.CommandButton cmdApply 
      Caption         =   "Apply"
      Height          =   375
      Left            =   4080
      TabIndex        =   26
      Top             =   3360
      Width           =   1215
   End
   Begin VB.Frame Frame2 
      Caption         =   "Right Camera"
      Height          =   2655
      Left            =   2760
      TabIndex        =   14
      Top             =   120
      Width           =   2535
      Begin VB.TextBox txtRX 
         Height          =   315
         Left            =   1080
         TabIndex        =   19
         Top             =   240
         Width           =   1215
      End
      Begin VB.TextBox txtRY 
         Height          =   315
         Left            =   1080
         TabIndex        =   18
         Top             =   600
         Width           =   1215
      End
      Begin VB.TextBox txtRFocus 
         Height          =   315
         Left            =   1080
         TabIndex        =   17
         Top             =   1440
         Width           =   1215
      End
      Begin VB.TextBox txtRCCDW 
         Height          =   315
         Left            =   1080
         TabIndex        =   16
         Top             =   1800
         Width           =   1215
      End
      Begin VB.TextBox txtRCCDH 
         Height          =   315
         Left            =   1080
         TabIndex        =   15
         Top             =   2160
         Width           =   1215
      End
      Begin VB.Label Label12 
         AutoSize        =   -1  'True
         Caption         =   "Position X:"
         Height          =   195
         Left            =   240
         TabIndex        =   25
         Top             =   360
         Width           =   750
      End
      Begin VB.Label Label11 
         AutoSize        =   -1  'True
         Caption         =   "Position Y:"
         Height          =   195
         Left            =   240
         TabIndex        =   24
         Top             =   720
         Width           =   750
      End
      Begin VB.Label Label10 
         AutoSize        =   -1  'True
         Caption         =   "Position Z:  0"
         Height          =   195
         Left            =   240
         TabIndex        =   23
         Top             =   1080
         Width           =   930
      End
      Begin VB.Label Label9 
         AutoSize        =   -1  'True
         Caption         =   "Focus:"
         Height          =   195
         Left            =   240
         TabIndex        =   22
         Top             =   1560
         Width           =   480
      End
      Begin VB.Label Label8 
         AutoSize        =   -1  'True
         Caption         =   "CCD W:"
         Height          =   195
         Left            =   240
         TabIndex        =   21
         Top             =   1920
         Width           =   585
      End
      Begin VB.Label Label7 
         AutoSize        =   -1  'True
         Caption         =   "CCD H:"
         Height          =   195
         Left            =   240
         TabIndex        =   20
         Top             =   2280
         Width           =   540
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Left Camera"
      Height          =   2655
      Left            =   120
      TabIndex        =   2
      Top             =   120
      Width           =   2535
      Begin VB.TextBox txtLCCDH 
         Height          =   315
         Left            =   1080
         TabIndex        =   13
         Top             =   2160
         Width           =   1215
      End
      Begin VB.TextBox txtLCCDW 
         Height          =   315
         Left            =   1080
         TabIndex        =   11
         Top             =   1800
         Width           =   1215
      End
      Begin VB.TextBox txtLFocus 
         Height          =   315
         Left            =   1080
         TabIndex        =   9
         Top             =   1440
         Width           =   1215
      End
      Begin VB.TextBox txtLY 
         Height          =   315
         Left            =   1080
         TabIndex        =   6
         Top             =   600
         Width           =   1215
      End
      Begin VB.TextBox txtLX 
         Height          =   315
         Left            =   1080
         TabIndex        =   4
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label Label6 
         AutoSize        =   -1  'True
         Caption         =   "CCD H:"
         Height          =   195
         Left            =   240
         TabIndex        =   12
         Top             =   2280
         Width           =   540
      End
      Begin VB.Label Label5 
         AutoSize        =   -1  'True
         Caption         =   "CCD W:"
         Height          =   195
         Left            =   240
         TabIndex        =   10
         Top             =   1920
         Width           =   585
      End
      Begin VB.Label Label4 
         AutoSize        =   -1  'True
         Caption         =   "Focus:"
         Height          =   195
         Left            =   240
         TabIndex        =   8
         Top             =   1560
         Width           =   480
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         Caption         =   "Position Z:  0"
         Height          =   195
         Left            =   240
         TabIndex        =   7
         Top             =   1080
         Width           =   930
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         Caption         =   "Position Y:"
         Height          =   195
         Left            =   240
         TabIndex        =   5
         Top             =   720
         Width           =   750
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Position X:"
         Height          =   195
         Left            =   240
         TabIndex        =   3
         Top             =   360
         Width           =   750
      End
   End
   Begin VB.CommandButton CancelButton 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2760
      TabIndex        =   1
      Top             =   3360
      Width           =   1215
   End
   Begin VB.CommandButton OKButton 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   1440
      TabIndex        =   0
      Top             =   3360
      Width           =   1215
   End
   Begin VB.Label Label13 
      AutoSize        =   -1  'True
      Caption         =   "Z Offset:"
      Height          =   195
      Left            =   120
      TabIndex        =   28
      Top             =   3000
      Width           =   615
   End
End
Attribute VB_Name = "frmStereopsis"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

Private Sub CancelButton_Click()
    Unload Me
End Sub

Private Sub cmdApply_Click()    ' Update data
    Dim camLeft As STR_CAMERA, camRight As STR_CAMERA
    camLeft.X = Val(txtLX.Text)
    camLeft.Y = Val(txtLY.Text)
    camLeft.Z = 0
    camLeft.focus = Val(txtLFocus.Text)
    camLeft.iwidth = Val(txtLCCDW.Text)
    camLeft.iheight = Val(txtLCCDH.Text)
    camRight.X = Val(txtRX.Text)
    camRight.Y = Val(txtRY.Text)
    camRight.Z = 0
    camRight.focus = Val(txtRFocus.Text)
    camRight.iwidth = Val(txtRCCDW.Text)
    camRight.iheight = Val(txtRCCDH.Text)
    
    STR_SetLeftCamera camLeft
    STR_SetRightCamera camRight
    STR_SetZOffset Val(txtZOffset.Text)
End Sub

Private Sub Form_Load()
    ' Load & display current data
    Dim camLeft As STR_CAMERA, camRight As STR_CAMERA
    
    camLeft = STR_GetLeftCamera
    camRight = STR_GetRightCamera
    
    txtLX.Text = Format$(camLeft.X, "0.00000")
    txtLY.Text = Format$(camLeft.Y, "0.00000")
    txtLFocus.Text = Format$(camLeft.focus, "0.00000")
    txtLCCDW.Text = Format$(camLeft.iwidth, "0.00000")
    txtLCCDH.Text = Format$(camLeft.iheight, "0.00000")
    
    txtRX.Text = Format$(camRight.X, "0.00000")
    txtRY.Text = Format$(camRight.Y, "0.00000")
    txtRFocus.Text = Format$(camRight.focus, "0.00000")
    txtRCCDW.Text = Format$(camRight.iwidth, "0.00000")
    txtRCCDH.Text = Format$(camRight.iheight, "0.00000")
    
    txtZOffset.Text = Format$(STR_GetZOffset, "0.00000")
End Sub

Private Sub Form_Unload(Cancel As Integer)
    frmMain.mnuStereopsis.Checked = False
End Sub

Private Sub OKButton_Click()
    cmdApply_Click
    Unload Me
End Sub
