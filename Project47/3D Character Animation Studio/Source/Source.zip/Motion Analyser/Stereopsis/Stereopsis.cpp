// Stereopsis.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Stereopsis1.h"

CStereopsis stereo;
double zoffset = 0; 

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{

    return TRUE;
}

STR_CAMERA WINAPI STR_GetLeftCamera(void)
{
	return stereo.GetLeftCamera();
}

void WINAPI STR_SetLeftCamera(const STR_CAMERA &camLeft)
{
	stereo.SetLeftCamera(camLeft);
}

STR_CAMERA WINAPI STR_GetRightCamera(void)
{
	return stereo.GetRightCamera();
}

void WINAPI STR_SetRightCamera(const STR_CAMERA &camRight)
{
	stereo.SetRightCamera(camRight);
}

STR_WORLDCOOR WINAPI STR_GetWorldCoordinate(const STR_IMAGECOOR &coorLeft, const STR_IMAGESIZE &szLeft, 
											const STR_IMAGECOOR &coorRight, const STR_IMAGESIZE &szRight)
{
	STR_WORLDCOOR ret = stereo.GetWorldCoordinate(coorLeft, szLeft, coorRight, szRight);
	ret.z += zoffset;
	return ret;
}

STR_IMAGECOOR WINAPI STR_GetLeftImageCoordinate(const STR_WORLDCOOR &coorWorld, const STR_IMAGESIZE &szLeft)
{
	return stereo.GetLeftImageCoordinate(coorWorld, szLeft);
}

STR_IMAGECOOR WINAPI STR_GetRightImageCoordinate(const STR_WORLDCOOR &coorWorld, const STR_IMAGESIZE &szRight)
{
	return stereo.GetRightImageCoordinate(coorWorld, szRight);
}

void WINAPI STR_SetZOffset(double Offset)
{
	zoffset = Offset;
}

double WINAPI STR_GetZOffset()
{
	return zoffset;
}

