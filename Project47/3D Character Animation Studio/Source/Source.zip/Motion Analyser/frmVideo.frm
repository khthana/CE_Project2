VERSION 5.00
Object = "{A91E1E76-6AE7-11D4-AD08-A8AB2E818B70}#1.0#0"; "VideoOCX.ocx"
Begin VB.Form frmVideo 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Video"
   ClientHeight    =   4425
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   4830
   Icon            =   "frmVideo.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   295
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   322
   Begin VB.Timer tmrPlay 
      Enabled         =   0   'False
      Left            =   0
      Top             =   480
   End
   Begin VB.PictureBox picToolbar 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   660
      Left            =   0
      ScaleHeight     =   44
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   321
      TabIndex        =   2
      Top             =   3720
      Width           =   4815
      Begin VB.CommandButton cmdPlay 
         Height          =   330
         Left            =   0
         Picture         =   "frmVideo.frx":0F7A
         Style           =   1  'Graphical
         TabIndex        =   14
         ToolTipText     =   "Play/Stop Movie"
         Top             =   0
         Width           =   330
      End
      Begin VB.CommandButton cmdLoad 
         Height          =   330
         Left            =   2715
         Picture         =   "frmVideo.frx":1301
         Style           =   1  'Graphical
         TabIndex        =   13
         ToolTipText     =   "Load Marker Data"
         Top             =   330
         Width           =   330
      End
      Begin VB.CommandButton cmdSave 
         Height          =   330
         Left            =   2385
         Picture         =   "frmVideo.frx":1683
         Style           =   1  'Graphical
         TabIndex        =   12
         ToolTipText     =   "Save Marker Data"
         Top             =   330
         Width           =   330
      End
      Begin VB.CommandButton cmdGen 
         Height          =   330
         Left            =   3765
         Picture         =   "frmVideo.frx":1A09
         Style           =   1  'Graphical
         TabIndex        =   11
         ToolTipText     =   "Generate Lost Marker Data"
         Top             =   330
         Width           =   330
      End
      Begin VB.CommandButton cmdStop 
         Height          =   330
         Left            =   3435
         Picture         =   "frmVideo.frx":1D90
         Style           =   1  'Graphical
         TabIndex        =   10
         ToolTipText     =   "Stop Process"
         Top             =   330
         Width           =   330
      End
      Begin VB.CommandButton cmdStart 
         Height          =   330
         Left            =   3105
         Picture         =   "frmVideo.frx":20F1
         Style           =   1  'Graphical
         TabIndex        =   9
         ToolTipText     =   "Start/Resume Process"
         Top             =   330
         Width           =   330
      End
      Begin VB.ComboBox cmbMarker 
         Height          =   315
         Left            =   975
         Style           =   2  'Dropdown List
         TabIndex        =   8
         Top             =   330
         Width           =   975
      End
      Begin VB.CommandButton cmdDetectDef 
         Height          =   330
         Left            =   4485
         Picture         =   "frmVideo.frx":2453
         Style           =   1  'Graphical
         TabIndex        =   7
         ToolTipText     =   "Detect Markers in Default Gesture"
         Top             =   330
         Width           =   330
      End
      Begin VB.CommandButton cmdProcessDetect 
         Height          =   330
         Left            =   4155
         Picture         =   "frmVideo.frx":27BD
         Style           =   1  'Graphical
         TabIndex        =   6
         ToolTipText     =   "Detect Markers"
         Top             =   330
         Width           =   330
      End
      Begin VB.CheckBox chkCrosshair 
         Height          =   330
         Left            =   1995
         Picture         =   "frmVideo.frx":2B41
         Style           =   1  'Graphical
         TabIndex        =   5
         ToolTipText     =   "Toggle Crosshair Visibility"
         Top             =   330
         Width           =   330
      End
      Begin VB.ComboBox cmbView 
         Height          =   315
         Left            =   0
         Style           =   2  'Dropdown List
         TabIndex        =   4
         Top             =   330
         Width           =   975
      End
      Begin VB.HScrollBar hsbFrame 
         Height          =   330
         LargeChange     =   10
         Left            =   330
         Max             =   100
         TabIndex        =   3
         Top             =   0
         Width           =   4485
      End
   End
   Begin VIDEOOCXLib.VideoOCX vdoocxVideo 
      Height          =   480
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Visible         =   0   'False
      Width           =   480
      _Version        =   65536
      _ExtentX        =   847
      _ExtentY        =   847
      _StockProps     =   0
      ScaledDisplay   =   0   'False
      SaveAudio       =   0   'False
      Driver          =   0
      ControlWidth    =   384
      ControlHeight   =   288
      Mode            =   0
   End
   Begin VB.PictureBox picImage 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H0000FF00&
      Height          =   3600
      Left            =   0
      ScaleHeight     =   240
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   320
      TabIndex        =   1
      Top             =   0
      Width           =   4800
   End
End
Attribute VB_Name = "frmVideo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' ====================================================================== MEMBER VARIABLES
' Auxilary flags
Public flgOpenned As Boolean   ' Determine if the video is openned
Private flgToolbar As Boolean   ' Show toolbar?
Private flgCrosshair As Boolean ' Show crosshair?
Private flgProcess As Boolean   ' Processing?

' Image frames
Private vimgFrame As Long   ' Captured image handle
Private vimgBuffer() As Long    ' Image frame buffers
Private ViewCurrent As Long    ' Current view (-1 = Original)

' Marker data
Private Markers() As MARKER_GLOBAL    ' Detected Joints
Private MarkerActive As Integer     ' Current active marker
Private MarkerAvr() As clsIMAGECOOR ' Averaged marker data

' Video Parameters
Private VideoPath As String     ' Current video path & filename
Private FrameCurrent As Long    ' Current frame
Private FrameMax As Long        ' Max frame number

Private cdlOpenSave As New clsCommonDialog

' ====================================================================== PRIVATE FUNCTIONS
Private Function GetFilename(Path As String) As String     ' Return filename
    Dim tmpstr() As String
    Dim index As Integer
    tmpstr = Split(Path, "\")
    index = 0
    
    On Error GoTo Err1:
    While True
        GetFilename = tmpstr(index)
        index = index + 1
    Wend
    Exit Function
Err1: Resume Quit:
Quit:
End Function

Private Sub DrawMarker(PicBox As PictureBox, X As Long, Y As Long, size As Long, Color As Long)    ' Draw a marker on picImage
    PicBox.Line (X - size, Y)-(X + size + 1, Y), Color
    PicBox.Line (X, Y - size)-(X, Y + size + 1), Color
End Sub

Private Sub UpdateMarker()    ' Draw all markers on picImage
    picImage.Cls
    If (Not flgCrosshair) Then Exit Sub
       
    ' Draw marker crosshair
    Dim i  As Integer
    For i = 0 To MARKER_MAX
        If (Markers(i).Data(FrameCurrent).valid) Then
            If (i = MarkerActive) Then
                DrawMarker picImage, Markers(i).Data(FrameCurrent).X, Markers(i).Data(FrameCurrent).Y, MARKER_SIZE, MARKER_ACTIVE
                picImage.CurrentX = Markers(i).Data(FrameCurrent).X - MARKER_SIZE
                picImage.CurrentY = Markers(i).Data(FrameCurrent).Y - 12 - MARKER_SIZE
                picImage.ForeColor = MARKER_ACTIVE
                picImage.Print MARKER_NAME(i)
            Else
                DrawMarker picImage, Markers(i).Data(FrameCurrent).X, Markers(i).Data(FrameCurrent).Y, MARKER_SIZE, MARKER_NORMAL
            End If
        End If
    Next i
End Sub

Private Sub UpdateView()    ' Update current view
    If (ViewCurrent < 0) Then
        picImage.Picture = vdoocxVideo.ToPicture(vimgFrame)
    Else
        picImage.Picture = vdoocxVideo.ToPicture(vimgBuffer(ViewCurrent))
    End If
    UpdateMarker
End Sub

Private Sub UpdateForm()    ' Update controls and form
    ' Resize controls & window to fit new video
    Me.width = Me.width - (Me.ScaleWidth * Screen.TwipsPerPixelX) + vdoocxVideo.GetWidth * Screen.TwipsPerPixelX
    Me.height = Me.height - (Me.ScaleHeight * Screen.TwipsPerPixelY) + vdoocxVideo.GetHeight * Screen.TwipsPerPixelY
    If (flgToolbar) Then
        Me.height = Me.height + (picToolbar.height * Screen.TwipsPerPixelY)
        picToolbar.Visible = True
    Else
        picToolbar.Visible = False
    End If
    picImage.width = vdoocxVideo.GetWidth
    picImage.height = vdoocxVideo.GetHeight
    picToolbar.Top = picImage.height
    picToolbar.Left = 0
    picToolbar.width = Me.ScaleWidth
    
    ' Init control properties
    hsbFrame.Max = FrameMax
    hsbFrame.Value = FrameCurrent
End Sub

Private Sub UpdateControl()     ' Update control to reflect changes
    hsbFrame.Max = FrameMax
    hsbFrame.Value = FrameCurrent
    cmbView.ListIndex = ViewCurrent + 1
    cmbMarker.ListIndex = MarkerActive + 1
    If (flgCrosshair) Then
        chkCrosshair.Value = vbChecked
    Else
        chkCrosshair.Value = vbUnchecked
    End If
End Sub

Private Sub GenerateLost(MarkerNo As Integer, FrameNo As Long) ' Generate lost marker data in a period
    ' Validation
    If (FrameNo < 0) Or (FrameNo > FrameMax) Then Exit Sub
    If (Markers(MarkerNo).Data(FrameNo).valid) Then Exit Sub
    
    Dim LeftFrame As Long, RightFrame As Long   ' Left & Right frame of valid marker data
    LeftFrame = FrameNo
    RightFrame = FrameNo
    
    ' Find left valid frame no.
    Do While (LeftFrame >= 0)
        If (Markers(MarkerNo).Data(LeftFrame).valid) Then Exit Do
        LeftFrame = LeftFrame - 1
    Loop
    If (LeftFrame < 0) Then Exit Sub ' No left valid frame, exit
    
    ' Find right valid frame no.
    Do While (RightFrame <= FrameMax)
        If (Markers(MarkerNo).Data(RightFrame).valid) Then Exit Do
        RightFrame = RightFrame + 1
    Loop
    If (RightFrame > FrameMax) Then Exit Sub ' No right valid frame, exit
    
    ' Generate lost range
    Dim AddX As Double, AddY As Double
    Dim i As Long
    AddX = (Markers(MarkerNo).Data(RightFrame).X - Markers(MarkerNo).Data(LeftFrame).X) / (RightFrame - LeftFrame)
    AddY = (Markers(MarkerNo).Data(RightFrame).Y - Markers(MarkerNo).Data(LeftFrame).Y) / (RightFrame - LeftFrame)
    For i = (LeftFrame + 1) To (RightFrame - 1)
        Markers(MarkerNo).Data(i).X = Markers(MarkerNo).Data(LeftFrame).X + (AddX * (i - LeftFrame))
        Markers(MarkerNo).Data(i).Y = Markers(MarkerNo).Data(LeftFrame).Y + (AddY * (i - LeftFrame))
        Markers(MarkerNo).Data(i).valid = True
    Next i
End Sub

Private Sub SetControlEnable(Enable As Boolean) ' Set control to enable/disable
    If (Enable) Then
        cmdProcessDetect.Enabled = True
        cmdDetectDef.Enabled = True
        cmdGen.Enabled = True
        cmdLoad.Enabled = True
        cmdSave.Enabled = True
        hsbFrame.Enabled = True
    Else
        cmdProcessDetect.Enabled = False
        cmdDetectDef.Enabled = False
        cmdGen.Enabled = False
        cmdLoad.Enabled = False
        cmdSave.Enabled = False
        hsbFrame.Enabled = False
    End If
End Sub

' ====================================================================== PUBLIC FUNCTIONS

Public Function GetLastframe() As Long
    ' Validation
    If (Not flgOpenned) Then Exit Function

    GetLastframe = FrameMax
End Function

Public Function GetFramerate() As Long
    ' Validation
    If (Not flgOpenned) Then Exit Function

    GetFramerate = vdoocxVideo.GetFPS
End Function

Public Function GetMarker(FrameNo As Long, MarkerNo As Integer, X As Long, Y As Long) ' Get marker data
    MarkerAvr(MarkerNo).SetXY Markers(MarkerNo).Data(FrameNo).X, Markers(MarkerNo).Data(FrameNo).Y
    X = MarkerAvr(MarkerNo).X
    Y = MarkerAvr(MarkerNo).Y
    GetMarker = Markers(MarkerNo).Data(FrameNo).valid
End Function

Public Sub NewAverageMarker(ArrSize As Integer, Threshold As Double)    ' Create new average for GetMarker
    Dim i As Integer
    For i = 0 To MARKER_MAX
        MarkerAvr(i).NewAverage ArrSize
        MarkerAvr(i).MoveThreshold = Threshold
    Next i
End Sub

Public Sub GenerateLostMark(Optional FrameStart As Long = -1, Optional FrameStop As Long = -1)  ' Generate lost marker data
    ' Validation
    If (FrameStart < 0) Then FrameStart = 0
    If (FrameStop < 0) Or (FrameStop > FrameMax) Then FrameStop = FrameMax
    
    Dim i As Integer
    Dim f As Long
    Dim A As Long, b As Long
For i = 0 To MARKER_MAX
    A = 0: b = 0
    While A < FrameMax
        If (Markers(i).Data(A).valid) Then
        Else
        End If
        
    Wend
Next i
End Sub

Public Function IsMarkerLost(MarkerNo As Integer, Optional MaxLost As Long = 0) As Boolean ' Determine if marker lost more than MaxLost
    ' Validation
    If (MaxLost <= 0) Then MaxLost = LOSTMARK_MAX

    Dim i As Long
    Dim Count As Long
    i = FrameCurrent
    Count = 0
    While (Not Markers(MarkerNo).Data(i).valid)
        i = i - 1
        Count = Count + 1
        If (Count > MaxLost) Then IsMarkerLost = True: Exit Function
        If (i < 0) Then IsMarkerLost = False: Exit Function
    Wend
    IsMarkerLost = False
End Function

Public Function InitVideo(Filename As String) As Boolean   ' Init video file (AVI)
    If (Not vdoocxVideo.InitFromFile(Filename)) Then InitVideo = False: Exit Function
    flgOpenned = True
    VideoPath = Filename
    FrameMax = vdoocxVideo.GetLen - 1
    FrameCurrent = vdoocxVideo.GetFrameNumber

    ' Allocate data
    Dim i As Integer
    For i = 0 To MARKER_MAX
        ReDim Markers(i).Data(0 To FrameMax) As MARKER_DATA
    Next i
    vimgFrame = vdoocxVideo.GetColorImageHandle
    ReDim vimgBuffer(0 To FRAME_MAX) As Long
    For i = 0 To FRAME_MAX
        vimgBuffer(i) = vdoocxVideo.GetColorImageHandle
    Next i

    UpdateForm
    UpdateControl
    
    vdoocxVideo.Start
    SeekFrame 0
    
    InitVideo = True
End Function

Public Sub CloseVideo() ' Close video
    ' Validation
    If (Not flgOpenned) Then Exit Sub
    
    vdoocxVideo.Stop
    
    ' Deallocate data
    Dim i As Integer
    For i = 0 To FRAME_MAX
        vdoocxVideo.ReleaseImageHandle vimgBuffer(i)
    Next i
    vdoocxVideo.ReleaseImageHandle vimgFrame
    
    vdoocxVideo.Close
    flgOpenned = False
End Sub

Public Sub SeekFrame(Optional FrameNo As Long = -1, Optional Fast As Boolean = False)  ' Move to a video frame (Default is next frame)
    ' Validation
    If (Not flgOpenned) Then Exit Sub
    If (FrameNo > FrameMax) Then Exit Sub
    If (FrameNo < 0) Then FrameNo = FrameCurrent + 1
    
    ' Seek frame
    FrameCurrent = FrameNo
    vdoocxVideo.Seek FrameCurrent
    
    ' Capture & update image
    vdoocxVideo.Capture (vimgFrame)
    'UpdateControl
    UpdateMarker
    If (Not Fast) Then ProcessImage
    UpdateView
    
    ' Update caption
    Me.Caption = GetFilename(VideoPath) + " [" + Format$(FrameCurrent, "0") + "/" + Format$(FrameMax, "0") + "]"
End Sub

Public Sub SetActiveMarker(MarkerNo As Integer)     ' Set current active marker
    ' Validation
    If (Not flgOpenned) Then Exit Sub
    If (MarkerNo < -1) Or (MarkerNo > MARKER_MAX) Then Exit Sub
    
    MarkerActive = MarkerNo
    UpdateMarker
    UpdateControl
End Sub

Public Sub SetCurrentView(FrameNo As Integer)   ' Set current view of image
    ' Validation
    If (Not flgOpenned) Then Exit Sub
    If (FrameNo < -1) Or (FrameNo > FRAME_MAX) Then Exit Sub
    ViewCurrent = FrameNo
    UpdateView
    UpdateControl
End Sub

Public Sub ProcessImage()    ' Process image frames
    ' Validation
    If (Not flgOpenned) Then Exit Sub

    Dim i As Integer
    
    FAL_SetImageDimension vdoocxVideo.GetWidth, vdoocxVideo.GetHeight
    For i = 0 To FRAME_MAX
        FAL_HSVThreshold vdoocxVideo.GetDataPointer(vimgFrame), vdoocxVideo.GetDataPointer(vimgBuffer(i)), ProcessInfo(i).Range, ProcessInfo(i).HueOffset
        FAL_PutFloodfillBorder vdoocxVideo.GetDataPointer(vimgBuffer(i))
        ProcessInfo(i).Blob_count = FAL_AnalyseBlob2(vdoocxVideo.GetDataPointer(vimgBuffer(i)), ProcessInfo(i).Blobs(0), BLOBDETECT_MAX)
    Next i
End Sub

Public Sub DetectDefault()  ' Detect marker in default gesture by generate last-frame position
    ' Validation
    If (Not flgOpenned) Then Exit Sub

    Dim LastFrame As Long
    If (FrameCurrent = 0) Then LastFrame = FrameCurrent Else LastFrame = FrameCurrent - 1
    
    ' Default Data
    Markers(MARKER.LHead).Data(LastFrame).X = 170
    Markers(MARKER.LHead).Data(LastFrame).Y = 70
    Markers(MARKER.RHead).Data(LastFrame).X = 160
    Markers(MARKER.RHead).Data(LastFrame).Y = 70
    Markers(MARKER.Neck).Data(LastFrame).X = 165
    Markers(MARKER.Neck).Data(LastFrame).Y = 95
    Markers(MARKER.LSHLD).Data(LastFrame).X = 180
    Markers(MARKER.LSHLD).Data(LastFrame).Y = 100
    Markers(MARKER.RSHLD).Data(LastFrame).X = 145
    Markers(MARKER.RSHLD).Data(LastFrame).Y = 100
    Markers(MARKER.LElbow).Data(LastFrame).X = 183
    Markers(MARKER.LElbow).Data(LastFrame).Y = 130
    Markers(MARKER.RElbow).Data(LastFrame).X = 140
    Markers(MARKER.RElbow).Data(LastFrame).Y = 130
    Markers(MARKER.LWrist).Data(LastFrame).X = 183
    Markers(MARKER.LWrist).Data(LastFrame).Y = 150
    Markers(MARKER.RWrist).Data(LastFrame).X = 140
    Markers(MARKER.RWrist).Data(LastFrame).Y = 150
    Markers(MARKER.Chest).Data(LastFrame).X = 165
    Markers(MARKER.Chest).Data(LastFrame).Y = 112
    Markers(MARKER.LWaist).Data(LastFrame).X = 172
    Markers(MARKER.LWaist).Data(LastFrame).Y = 145
    Markers(MARKER.RWaist).Data(LastFrame).X = 152
    Markers(MARKER.RWaist).Data(LastFrame).Y = 145
    Markers(MARKER.LKnee).Data(LastFrame).X = 172
    Markers(MARKER.LKnee).Data(LastFrame).Y = 185
    Markers(MARKER.RKnee).Data(LastFrame).X = 150
    Markers(MARKER.RKnee).Data(LastFrame).Y = 185
    Markers(MARKER.LAnkle).Data(LastFrame).X = 170
    Markers(MARKER.LAnkle).Data(LastFrame).Y = 220
    Markers(MARKER.RAnkle).Data(LastFrame).X = 150
    Markers(MARKER.RAnkle).Data(LastFrame).Y = 220
    
    DetectMarker True
End Sub

Public Sub DetectMarker(Optional DetectDefault As Boolean = False)   ' Detect all markers (Last frame data must be all valid)
    Dim ind As Long
    Dim i As Integer
    Dim LastFrame As Long
    Dim blob As F_BLOB
    Dim tmppt As STR_IMAGECOOR
    Dim dx As Double, dy As Double, dist As Double
    
    ' Detect all marker

For i = 0 To MARKER_MAX

    ' Get last valid frame
    If (FrameCurrent = 0) Then
        LastFrame = FrameCurrent
    Else
        Dim Count As Long
        LastFrame = FrameCurrent - 1
        Do While (Not Markers(i).Data(LastFrame).valid)
            LastFrame = LastFrame - 1
            Count = Count + 1
            If (Count > LOSTMARK_MAX) Then LastFrame = FrameCurrent - 1: Exit Do ' Force use invalid data
        Loop
    End If

If (DetectDefault) Or (Markers(i).Data(LastFrame).valid) Then   ' Process only if detectdefault or valid

    FAL_SetBlobData ProcessInfo(Markers(i).detectframe).Blobs(0), ProcessInfo(Markers(i).detectframe).Blob_count
    FAL_BlobMoveFirst
    
    ' Detect marker's position on current frame related to previous frame position
    ind = FAL_BlobGetDataSNR(blob, ProcessInfo(Markers(i).detectframe).blob_min, ProcessInfo(Markers(i).detectframe).blob_max, Markers(i).Data(LastFrame).X, vdoocxVideo.GetHeight - Markers(i).Data(LastFrame).Y - 1, MOVEMENT_RADIUS)
    If (ind >= 0) Then
        tmppt.X = (blob.xmin + blob.xmax) / 2
        tmppt.Y = vdoocxVideo.GetHeight - ((blob.ymin + blob.ymax) / 2) - 1
        dx = (tmppt.X - Markers(i).Data(LastFrame).X)
        dy = (tmppt.Y - Markers(i).Data(LastFrame).Y)
        dist = Sqr((dx * dx) + (dy * dy))
        
        If (blob.ffalse <> 0) Then
            ' If this blob has been detected as other, compare and choose the nearest one
            If (dist < ProcessInfo(Markers(i).detectframe).BlobsExt(ind).dist) Then
                ' This one is nearer than the old one
                Markers(ProcessInfo(Markers(i).detectframe).BlobsExt(ind).detectas).Data(FrameCurrent).valid = False ' Set the old invalid

                ProcessInfo(Markers(i).detectframe).BlobsExt(ind).detectas = i
                ProcessInfo(Markers(i).detectframe).BlobsExt(ind).dist = dist
                Markers(i).Data(FrameCurrent).X = tmppt.X
                Markers(i).Data(FrameCurrent).Y = tmppt.Y
                Markers(i).Data(FrameCurrent).valid = True
            Else
                ' This one is not nearer than the old one
                Markers(i).Data(FrameCurrent).valid = False
            End If
        Else
            ' This blob is free
            FAL_BlobMarkFalse ind

            ProcessInfo(Markers(i).detectframe).BlobsExt(ind).detectas = i
            ProcessInfo(Markers(i).detectframe).BlobsExt(ind).dist = dist
            Markers(i).Data(FrameCurrent).X = tmppt.X
            Markers(i).Data(FrameCurrent).Y = tmppt.Y
            Markers(i).Data(FrameCurrent).valid = True
        End If
    Else
        ' Cannot detected
        Markers(i).Data(FrameCurrent).valid = False
    End If
    FAL_UnsetBlobData

End If

Next i

    UpdateMarker
End Sub

Public Function DetectLostMarker() As Integer  ' Return lost marker on current frame
    Dim i As Integer
    Dim Count As Long
    For i = 0 To MARKER_MAX
        If (Not Markers(i).Data(FrameCurrent).valid) Then
            DetectLostMarker = i
            Exit Function
        End If
    Next i
    DetectLostMarker = -1
End Function

Public Sub GenerateLostData()   ' Generate lost marker if possible
    ' Validation
    If (Not flgOpenned) Then Exit Sub

    Dim m As Integer, i As Long
    For m = 0 To MARKER_MAX
        For i = 0 To FrameMax
            If (Not Markers(m).Data(i).valid) Then GenerateLost m, i
        Next i
    Next m
End Sub

' ====================================================================== EVENT HANDLES
Private Sub chkCrosshair_Click()
    If (chkCrosshair.Value = vbChecked) Then
        flgCrosshair = True
    Else
        flgCrosshair = False
    End If
    UpdateMarker
End Sub

Private Sub cmbMarker_Click()
    SetActiveMarker cmbMarker.ListIndex - 1
End Sub

Private Sub cmbView_Click() ' Change view
    SetCurrentView cmbView.ListIndex - 1
End Sub

Private Sub cmdDetectDef_Click()
    ProcessImage
    DetectDefault
End Sub

Private Sub cmdGen_Click()
    GenerateLostData
End Sub

Private Sub cmdLoad_Click() ' Load marker data from file
    With cdlOpenSave
        .DialogTitle = "Load Marker Data"
        .Filter = "Marker Data File (*.mkd)|*.mkd|All files|*.*"
        .flags = &H4 + &H800 + &H1000
        .MaxFileSize = 254
        .Filename = ""
    End With
    cdlOpenSave.ShowOpen
    
    ' Load marker
    If (Trim$(cdlOpenSave.Filename) <> "") Then
        Dim m As Integer, f As Long
        Open cdlOpenSave.Filename For Random As #1
            For m = 0 To MARKER_MAX
                For f = 0 To FrameMax
                    Get #1, , Markers(m).Data(f)
                Next f
            Next m
        Close #1
        UpdateMarker
    End If
End Sub

' Play video
Private Sub cmdPlay_Click()
    tmrPlay.Interval = 1000 \ vdoocxVideo.GetFPS
    If (tmrPlay.Enabled) Then
        SetControlEnable True
        cmdStart.Enabled = True
        cmdStop.Enabled = True
        tmrPlay.Enabled = False
    Else
        SetControlEnable False
        cmdStart.Enabled = False
        cmdStop.Enabled = False
        tmrPlay.Enabled = True
    End If
    UpdateControl
End Sub

Private Sub cmdProcessDetect_Click()    ' Process & detect
    ProcessImage
    DetectMarker
End Sub

Private Sub cmdSave_Click() ' Save marker data to file
    With cdlOpenSave
        .DialogTitle = "Save Marker Data"
        .DefaultExt = ".mkd"
        .Filter = "Marker Data File (*.mkd)|*.mkd|All files|*.*"
        .flags = &H2000 + &H2 + &H800
        .MaxFileSize = 254
        .Filename = ""
    End With
    cdlOpenSave.ShowSave
    
    ' Save marker
    If (Trim$(cdlOpenSave.Filename) <> "") Then
        Dim m As Integer, f As Long
        Open cdlOpenSave.Filename For Random As #1
            For m = 0 To MARKER_MAX
                For f = 0 To FrameMax
                    Put #1, , Markers(m).Data(f)
                Next f
            Next m
        Close #1
    End If
End Sub

Private Sub cmdStart_Click()    ' Start process to detect all frames
    Dim i As Integer
    If (flgProcess) Then    ' Resume next frame (if all marker didn't lose)
        For i = 0 To MARKER_MAX
            If (IsMarkerLost(i)) Then SetActiveMarker i: Exit Sub
        Next i
    Else    ' Start over check current frame for starting process next frame
        Dim lost As Integer
        lost = DetectLostMarker
        If (lost >= 0) Then SetActiveMarker lost: Exit Sub
    End If
    SeekFrame

    cmdStart.Caption = "Resume"
    SetControlEnable False
    cmdPlay.Enabled = False
    flgProcess = True
    
    ' Start process until last frame
    Do
        ProcessImage
        DetectMarker
        For i = 0 To MARKER_MAX
            If (IsMarkerLost(i)) Then SetActiveMarker i: Exit Sub
        Next i
        
        If (FrameCurrent = FrameMax) Then Exit Do   ' Check exit
        SeekFrame   ' Goto next frame
        DoEvents
    Loop
    
    cmdStop_Click ' Stop process
End Sub

Private Sub cmdStop_Click()
    cmdStart.Caption = "Start"
    SetControlEnable True
    cmdPlay.Enabled = True
    flgProcess = False
    
    UpdateControl
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    If (KeyAscii = 27) Then ' ESC => Reset markers
        If (MsgBox("Are you sure to reset all marker data?", vbExclamation + vbYesNo) = vbNo) Then Exit Sub
    
        Dim i As Long, m As Integer
        For m = 0 To MARKER_MAX
            For i = 0 To FrameMax
                Markers(m).Data(i).valid = False
            Next i
        Next m
        UpdateMarker
    End If
End Sub

Private Sub Form_Load()
    Dim i As Integer

    ' Init controls
    vdoocxVideo.Mode = 1    ' AVI Mode
    
    ' Init variables
    flgOpenned = False
    flgToolbar = True
    flgCrosshair = True
    flgProcess = False
    MarkerActive = -1
    ViewCurrent = -1
    ReDim Markers(0 To MARKER_MAX) As MARKER_GLOBAL
    ReDim MarkerAvr(0 To MARKER_MAX) As clsIMAGECOOR
    For i = 0 To MARKER_MAX
        Set MarkerAvr(i) = New clsIMAGECOOR
    Next i
    
    ' Init controls
    cmbView.AddItem "Original"
    For i = 0 To FRAME_MAX
        cmbView.AddItem ProcessInfo(i).Name
    Next i
    cmbView.ListIndex = 0
    cmbMarker.AddItem "None"
    For i = 0 To MARKER_MAX
        cmbMarker.AddItem MARKER_NAME(i)
    Next i
    cmbMarker.ListIndex = 0
    
    ' Assign which frame to be detected to find each marker
    Markers(MARKER.LHead).detectframe = cPink
    Markers(MARKER.RHead).detectframe = cBlue
    Markers(MARKER.Neck).detectframe = cPink
    Markers(MARKER.LSHLD).detectframe = cYellow
    Markers(MARKER.RSHLD).detectframe = cGreen
    Markers(MARKER.LElbow).detectframe = cYellow
    Markers(MARKER.RElbow).detectframe = cGreen
    Markers(MARKER.LWrist).detectframe = cYellow
    Markers(MARKER.RWrist).detectframe = cGreen
    Markers(MARKER.Chest).detectframe = cBlue
    Markers(MARKER.LWaist).detectframe = cPink
    Markers(MARKER.RWaist).detectframe = cBlue
    Markers(MARKER.LKnee).detectframe = cPink
    Markers(MARKER.RKnee).detectframe = cBlue
    Markers(MARKER.LAnkle).detectframe = cPink
    Markers(MARKER.RAnkle).detectframe = cBlue
End Sub

Private Sub Form_Unload(Cancel As Integer)
    CloseVideo
End Sub

Private Sub hsbFrame_Change()   ' Goto frame
    SeekFrame hsbFrame.Value
End Sub

Private Sub hsbFrame_Scroll()
    SeekFrame hsbFrame.Value, True
End Sub

Private Sub picImage_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)   ' Update marker position
    If (Button = vbLeftButton) Then
        ' Validation
        If (Not flgOpenned) Then Exit Sub
        ' If press at a marker then set it to active
        Dim i As Integer
        Dim selmark As Integer
        selmark = -1
        For i = 0 To MARKER_MAX
            If (Markers(i).Data(FrameCurrent).valid) Then
                If (X >= (Markers(i).Data(FrameCurrent).X - MARKER_SIZE)) And (X <= (Markers(i).Data(FrameCurrent).X + MARKER_SIZE)) Then
                    If (Y >= (Markers(i).Data(FrameCurrent).Y - MARKER_SIZE)) And (Y <= (Markers(i).Data(FrameCurrent).Y + MARKER_SIZE)) Then
                        selmark = i
                        Exit For
                    End If
                End If
            End If
        Next i
        ' If don't click on a marker
        If (selmark < 0) Then
            ' Use current active marker
            If (MarkerActive < 0) Then Exit Sub
        Else
            ' Click on a marker
            MarkerActive = selmark
        End If
        flgCrosshair = True
    
        Markers(MarkerActive).Data(FrameCurrent).valid = True
        Markers(MarkerActive).Data(FrameCurrent).X = X - MARKER_SIZE
        Markers(MarkerActive).Data(FrameCurrent).Y = Y - MARKER_SIZE
    
        UpdateMarker
    ElseIf (Button = vbRightButton) Then
        ' Deselect marker
        SetActiveMarker -1
        
        ' If between process, this mean press 'Resume button'
        If (flgProcess) Then cmdStart_Click
    End If
End Sub

Private Sub picImage_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)   ' Update marker position
    If (Button = vbLeftButton) Then
        ' Validation
        If (Not flgOpenned) Then Exit Sub
        If (MarkerActive < 0) Or (MarkerActive > MARKER_MAX) Then Exit Sub
        
        Markers(MarkerActive).Data(FrameCurrent).X = X - MARKER_SIZE
        Markers(MarkerActive).Data(FrameCurrent).Y = Y - MARKER_SIZE
    
        UpdateMarker
    End If
End Sub

Private Sub picImage_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If (Button = vbLeftButton) Then
        UpdateControl
    End If
End Sub

Private Sub picToolbar_Resize() ' Resize controls on toolbar
    hsbFrame.width = picToolbar.width - 22
End Sub

Private Sub tmrPlay_Timer() ' Play video (loop infinity)
    If (FrameCurrent >= FrameMax) Then
        SeekFrame 0
    Else
        SeekFrame
    End If
End Sub

