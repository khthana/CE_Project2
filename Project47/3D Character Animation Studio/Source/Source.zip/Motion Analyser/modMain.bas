Attribute VB_Name = "modMain"
Option Explicit

' ====================================================================== CONSTANTS
Public Const EPALETTE_FILE As String = "EPalette.exe"  ' EPallete filename
Public Const COLOR_FILE As String = "Color.dat" ' Color config data file
Public Const STEREOPSIS_FILE As String = "Stereosis.dat"    ' Stereopsis data

' ====================================================================== EXTERNAL FUNCTIONS
Public Declare Function WinExec Lib "KERNEL32" (ByVal lpCmdLine As String, ByVal nCmdShow As Long) As Long

' ====================================================================== ENTRY POINT

Public Sub Main()   ' Program entry point
    If (App.PrevInstance) Then End  'Allow only 1 program instance
    ChDir App.Path
    
    ' Init main
    INIT_VIDEO
    INIT_MOTION
    
    ' Init stereopsis (Default)
    Dim camLeft As STR_CAMERA, camRight As STR_CAMERA
    camLeft.X = -1.5
    camLeft.Y = -5.4
    camLeft.Z = 0
    camLeft.focus = 0.005
    camLeft.iwidth = 0.0032
    camLeft.iheight = 0.0024
    camRight.X = 1.5
    camRight.Y = -5.4
    camRight.Z = 0
    camRight.focus = 0.005
    camRight.iwidth = 0.0032
    camRight.iheight = 0.0024
    STR_SetLeftCamera camLeft
    STR_SetRightCamera camRight
    STR_SetZOffset 1.23
    
    frmMain.Show
End Sub

' ====================================================================== PUBLIC FUNCTIONS

Public Sub SaveColors() ' Save image process data to file
    Dim i As Long
    If (Dir(App.Path + "\" + COLOR_FILE) <> "") Then Kill App.Path + "\" + COLOR_FILE   ' Delete old
    Open App.Path + "\" + COLOR_FILE For Random As #1
        For i = 0 To FRAME_MAX
            Put #1, , ProcessInfo(i).HueOffset
            Put #1, , ProcessInfo(i).Range
            Put #1, , ProcessInfo(i).blob_min
            Put #1, , ProcessInfo(i).blob_max
        Next i
    Close #1
End Sub

Public Sub LoadColors()   ' Load image process data from file
    If (Dir(App.Path + "\" + COLOR_FILE) = "") Then Exit Sub
    
    Dim i As Long
    Open App.Path + "\" + COLOR_FILE For Random As #1
        For i = 0 To FRAME_MAX
            Get #1, , ProcessInfo(i).HueOffset
            Get #1, , ProcessInfo(i).Range
            Get #1, , ProcessInfo(i).blob_min
            Get #1, , ProcessInfo(i).blob_max
        Next i
    Close #1
End Sub

Public Sub SaveStereopsis() ' Save stereopsis data to file
    Dim camLeft As STR_CAMERA, camRight As STR_CAMERA
    camLeft = STR_GetLeftCamera
    camRight = STR_GetRightCamera
    If (Dir(App.Path + "\" + STEREOPSIS_FILE) <> "") Then Kill App.Path + "\" + STEREOPSIS_FILE   ' Delete old
    Open App.Path + "\" + STEREOPSIS_FILE For Random As #1
        Put #1, , camLeft
        Put #1, , camRight
        Put #1, , STR_GetZOffset
    Close #1
End Sub

Public Sub LoadStereopsis() ' Load stereopsis data from file
    If (Dir(App.Path + "\" + STEREOPSIS_FILE) = "") Then Exit Sub
    
    Dim camLeft As STR_CAMERA, camRight As STR_CAMERA
    Dim Zoffset As Double
    Open App.Path + "\" + STEREOPSIS_FILE For Random As #1
        Get #1, , camLeft
        Get #1, , camRight
        Get #1, , Zoffset
    Close #1
    STR_SetLeftCamera camLeft
    STR_SetRightCamera camRight
    STR_SetZOffset Zoffset
End Sub

Public Sub GetMotionData(FrameNo As Long, LeftVDO As frmVideo, RightVDO As frmVideo, MotionData() As STR_WORLDCOOR, AvrXYZ() As clsWORLDCOOR)
    'On Error Resume Next    ' !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    ' Update motion data from markers
    Dim LeftImgSize As STR_IMAGESIZE, RightImgSize As STR_IMAGESIZE
    Dim i As Long
    Dim LeftPt As STR_IMAGECOOR, RightPt As STR_IMAGECOOR
    Dim WaistWidth As Double, HeadWidth As Double, ClavWidth As Double, StrnWidth As Double, KneeWidth As Double, FootWidth As Double, FootHeight As Double, MTWidth As Double
    'Dim zeta As Double, L As Double
    Dim posXLB As Double
    Dim posYLB As Double
    Dim posXRB As Double
    Dim posYRB As Double
    
    ' Get image size
    LeftImgSize.width = LeftVDO.vdoocxVideo.GetWidth
    LeftImgSize.height = LeftVDO.vdoocxVideo.GetHeight
    RightImgSize.width = RightVDO.vdoocxVideo.GetWidth
    RightImgSize.height = RightVDO.vdoocxVideo.GetHeight
    HeadWidth = 0.15
    WaistWidth = 0.1
    ClavWidth = 0.05
    StrnWidth = 0.1
    KneeWidth = 0.05
    FootWidth = 0.25
    FootHeight = 0.04
    MTWidth = 0.05
    
    ' Update values
    Dim tmpcoor As STR_WORLDCOOR
    If (LeftVDO.GetMarker(FrameNo, MARKER.LHead, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LHead, RightPt.X, RightPt.Y)) Then
         tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
         MotionData(JOINT.LFHD).X = tmpcoor.X
         MotionData(JOINT.LFHD).Y = tmpcoor.Y
         MotionData(JOINT.LFHD).Z = tmpcoor.Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RHead, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RHead, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RFHD).X = tmpcoor.X
        MotionData(JOINT.RFHD).Y = tmpcoor.Y
        MotionData(JOINT.RFHD).Z = tmpcoor.Z
                
        'Head on backside ++++
        PGenerate MotionData(JOINT.LFHD).X, MotionData(JOINT.LFHD).Y, MotionData(JOINT.RFHD).X, MotionData(JOINT.RFHD).Y, posXLB, posYLB, posXRB, posYRB
        MotionData(JOINT.RBHD).X = posXRB
        MotionData(JOINT.RBHD).Y = posYRB
        MotionData(JOINT.RBHD).Z = MotionData(JOINT.RFHD).Z
        
        MotionData(JOINT.LBHD).X = posXLB
        MotionData(JOINT.LBHD).Y = posYLB
        MotionData(JOINT.LBHD).Z = MotionData(JOINT.LFHD).Z
        
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.Neck, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.Neck, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.CLAV).X = tmpcoor.X
        MotionData(JOINT.CLAV).Y = tmpcoor.Y - (ClavWidth / 2)  ' ++++
        MotionData(JOINT.CLAV).Z = tmpcoor.Z
        '++++
        MotionData(JOINT.C7).X = MotionData(JOINT.CLAV).X
        MotionData(JOINT.C7).Y = MotionData(JOINT.CLAV).Y + (ClavWidth * 2)
        MotionData(JOINT.C7).Z = MotionData(JOINT.CLAV).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.Chest, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.Chest, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.STRN).X = tmpcoor.X
        MotionData(JOINT.STRN).Y = tmpcoor.Y - (StrnWidth / 2)
        MotionData(JOINT.STRN).Z = tmpcoor.Z
        '++++
        MotionData(JOINT.T10).X = MotionData(JOINT.STRN).X
        MotionData(JOINT.T10).Y = MotionData(JOINT.STRN).Y + (StrnWidth / 2)
        MotionData(JOINT.T10).Z = MotionData(JOINT.STRN).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.LSHLD, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LSHLD, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.LSHO).X = tmpcoor.X
        MotionData(JOINT.LSHO).Y = tmpcoor.Y
        MotionData(JOINT.LSHO).Z = tmpcoor.Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.LElbow, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LElbow, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.LELB).X = tmpcoor.X
        MotionData(JOINT.LELB).Y = tmpcoor.Y
        MotionData(JOINT.LELB).Z = tmpcoor.Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RSHLD, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RSHLD, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RSHO).X = tmpcoor.X
        MotionData(JOINT.RSHO).Y = tmpcoor.Y
        MotionData(JOINT.RSHO).Z = tmpcoor.Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RElbow, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RElbow, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RELB).X = tmpcoor.X
        MotionData(JOINT.RELB).Y = tmpcoor.Y
        MotionData(JOINT.RELB).Z = tmpcoor.Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.LWrist, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LWrist, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.LWRE).X = tmpcoor.X
        MotionData(JOINT.LWRE).Y = tmpcoor.Y
        MotionData(JOINT.LWRE).Z = tmpcoor.Z
        
        MotionData(JOINT.LWRI).X = MotionData(JOINT.LWRE).X
        MotionData(JOINT.LWRI).Y = MotionData(JOINT.LWRE).Y
        MotionData(JOINT.LWRI).Z = MotionData(JOINT.LWRE).Z
        '++++
        If (MotionData(JOINT.LWRE).X >= MotionData(JOINT.LELB).X) Then
            MotionData(JOINT.LFIN).X = MotionData(JOINT.LWRE).X + 0.01
        Else
            MotionData(JOINT.LFIN).X = MotionData(JOINT.LWRE).X - 0.01
        End If
        
        MotionData(JOINT.LFIN).Y = MotionData(JOINT.LWRE).Y '((MotionData(JOINT.LELB).Y - MotionData(JOINT.LWRE).Y) / (MotionData(JOINT.LELB).X - MotionData(JOINT.LWRE).X)) * (MotionData(JOINT.LWRE).X - MotionData(JOINT.LFIN).X) + MotionData(JOINT.LWRE).Y
        MotionData(JOINT.LFIN).Z = MotionData(JOINT.LWRE).Z '((MotionData(JOINT.LELB).Z - MotionData(JOINT.LWRE).Z) / (MotionData(JOINT.LELB).X - MotionData(JOINT.LWRE).X)) * (MotionData(JOINT.LWRE).X - MotionData(JOINT.LFIN).X) + MotionData(JOINT.LWRE).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RWrist, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RWrist, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RWRE).X = tmpcoor.X
        MotionData(JOINT.RWRE).Y = tmpcoor.Y
        MotionData(JOINT.RWRE).Z = tmpcoor.Z
        
        MotionData(JOINT.RWRI).X = MotionData(JOINT.RWRE).X
        MotionData(JOINT.RWRI).Y = MotionData(JOINT.RWRE).Y
        MotionData(JOINT.RWRI).Z = MotionData(JOINT.RWRE).Z
        '++++
        If (MotionData(JOINT.RWRE).X <= MotionData(JOINT.RELB).X) Then
            MotionData(JOINT.RFIN).X = MotionData(JOINT.RWRE).X - 0.01
        Else
            MotionData(JOINT.RFIN).X = MotionData(JOINT.RWRE).X + 0.01
        End If
        MotionData(JOINT.RFIN).Y = MotionData(JOINT.RWRE).Y '((MotionData(JOINT.RELB).Y - MotionData(JOINT.RWRE).Y) / (MotionData(JOINT.RELB).X - MotionData(JOINT.RWRE).X)) * (MotionData(JOINT.RWRE).X - MotionData(JOINT.RFIN).X) + MotionData(JOINT.RWRE).Y
        MotionData(JOINT.RFIN).Z = MotionData(JOINT.RWRE).Z '((MotionData(JOINT.RELB).Z - MotionData(JOINT.RWRE).Z) / (MotionData(JOINT.RELB).X - MotionData(JOINT.RWRE).X)) * (MotionData(JOINT.RWRE).X - MotionData(JOINT.RFIN).X) + MotionData(JOINT.RWRE).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.LWaist, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LWaist, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.LFWT).X = tmpcoor.X
        MotionData(JOINT.LFWT).Y = tmpcoor.Y
        MotionData(JOINT.LFWT).Z = tmpcoor.Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RWaist, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RWaist, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RFWT).X = tmpcoor.X
        MotionData(JOINT.RFWT).Y = tmpcoor.Y
        MotionData(JOINT.RFWT).Z = tmpcoor.Z
        
        'Waist on backside ++++
        PGenerate MotionData(JOINT.LFWT).X, MotionData(JOINT.LFWT).Y, MotionData(JOINT.RFWT).X, MotionData(JOINT.RFWT).Y, posXLB, posYLB, posXRB, posYRB
        MotionData(JOINT.RBWT).X = posXRB
        MotionData(JOINT.RBWT).Y = posYRB
        MotionData(JOINT.RBWT).Z = MotionData(JOINT.RFWT).Z
        
        MotionData(JOINT.LBWT).X = posXLB
        MotionData(JOINT.LBWT).Y = posYLB
        MotionData(JOINT.LBWT).Z = MotionData(JOINT.LFWT).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.LKnee, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LKnee, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.LKNE).X = tmpcoor.X
        MotionData(JOINT.LKNE).Y = tmpcoor.Y
        MotionData(JOINT.LKNE).Z = tmpcoor.Z
        '++++
        MotionData(JOINT.LKNI).X = MotionData(JOINT.LKNE).X
        MotionData(JOINT.LKNI).Y = MotionData(JOINT.LKNE).Y + KneeWidth
        MotionData(JOINT.LKNI).Z = MotionData(JOINT.LKNE).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.LAnkle, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.LAnkle, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.LANK).X = tmpcoor.X
        MotionData(JOINT.LANK).Y = tmpcoor.Y
        MotionData(JOINT.LANK).Z = tmpcoor.Z
        '++++
        MotionData(JOINT.LHEL).X = MotionData(JOINT.LANK).X
        MotionData(JOINT.LHEL).Y = MotionData(JOINT.LANK).Y
        MotionData(JOINT.LHEL).Z = MotionData(JOINT.LANK).Z - FootHeight
        
        MotionData(JOINT.LMT5).X = MotionData(JOINT.LHEL).X + (MTWidth / 2)
        MotionData(JOINT.LMT5).Y = MotionData(JOINT.LHEL).Y - (FootWidth * 0.5)
        MotionData(JOINT.LMT5).Z = MotionData(JOINT.LHEL).Z
        
        MotionData(JOINT.LMTI).X = MotionData(JOINT.LHEL).X - (MTWidth / 2)
        MotionData(JOINT.LMTI).Y = MotionData(JOINT.LHEL).Y - (FootWidth * 0.5)
        MotionData(JOINT.LMTI).Z = MotionData(JOINT.LHEL).Z
        
        MotionData(JOINT.LTOE).X = MotionData(JOINT.LHEL).X
        MotionData(JOINT.LTOE).Y = MotionData(JOINT.LHEL).Y - FootWidth
        MotionData(JOINT.LTOE).Z = MotionData(JOINT.LHEL).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RKnee, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RKnee, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RKNE).X = tmpcoor.X
        MotionData(JOINT.RKNE).Y = tmpcoor.Y
        MotionData(JOINT.RKNE).Z = tmpcoor.Z
        '++++
        MotionData(JOINT.RKNI).X = MotionData(JOINT.RKNE).X
        MotionData(JOINT.RKNI).Y = MotionData(JOINT.RKNE).Y + KneeWidth
        MotionData(JOINT.RKNI).Z = MotionData(JOINT.RKNE).Z
    End If
    If (LeftVDO.GetMarker(FrameNo, MARKER.RAnkle, LeftPt.X, LeftPt.Y)) And (RightVDO.GetMarker(FrameNo, MARKER.RAnkle, RightPt.X, RightPt.Y)) Then
        tmpcoor = STR_GetWorldCoordinate(LeftPt, LeftImgSize, RightPt, RightImgSize)
        MotionData(JOINT.RANK).X = tmpcoor.X
        MotionData(JOINT.RANK).Y = tmpcoor.Y
        MotionData(JOINT.RANK).Z = tmpcoor.Z
        '++++
        MotionData(JOINT.RHEL).X = MotionData(JOINT.RANK).X
        MotionData(JOINT.RHEL).Y = MotionData(JOINT.RANK).Y
        MotionData(JOINT.RHEL).Z = MotionData(JOINT.RANK).Z - FootHeight
        
        MotionData(JOINT.RMT5).X = MotionData(JOINT.RHEL).X - (MTWidth / 2)
        MotionData(JOINT.RMT5).Y = MotionData(JOINT.RHEL).Y - (FootWidth * 0.5)
        MotionData(JOINT.RMT5).Z = MotionData(JOINT.RHEL).Z
        
        MotionData(JOINT.RMTI).X = MotionData(JOINT.RHEL).X + (MTWidth / 2)
        MotionData(JOINT.RMTI).Y = MotionData(JOINT.RHEL).Y - (FootWidth * 0.5)
        MotionData(JOINT.RMTI).Z = MotionData(JOINT.RHEL).Z
        
        MotionData(JOINT.RTOE).X = MotionData(JOINT.RHEL).X
        MotionData(JOINT.RTOE).Y = MotionData(JOINT.RHEL).Y - FootWidth
        MotionData(JOINT.RTOE).Z = MotionData(JOINT.RHEL).Z
    End If

    ' Calculate for averaging
    For i = 0 To JOINT_MAX
        AvrXYZ(i).SetXYZ MotionData(i).X, MotionData(i).Y, MotionData(i).Z
        
        MotionData(i).X = AvrXYZ(i).X
        MotionData(i).Y = AvrXYZ(i).Y
        MotionData(i).Z = AvrXYZ(i).Z
    Next i
End Sub

Private Sub PGenerate(PXLF As Double, PYLF As Double, PXRF As Double, PYRF As Double, PXLB As Double, PYLB As Double, PXRB As Double, PYRB As Double)
    Dim A As Double
    Dim b As Double
    Dim c1 As Double
    Dim c2 As Double
    Dim cl3 As Double
    Dim cr3 As Double
    Dim d As Double
    Dim m As Double
    
    m = (PYLF - PYRF) / (PXLF - PXRF)
    If (m = 0) Then m = 0.000000001
    c1 = PYLF - (m * PXLF)
    A = m
    b = -1
    d = 0.1
    c2 = (d * Sqr((A ^ 2) + (b ^ 2))) + c1
    cl3 = PYLF - ((-1 / m) * PXLF)
    cr3 = PYRF - ((-1 / m) * PXRF)
    PXLB = (m / (1 + (m ^ 2))) * (cl3 - c2)
    PYLB = (m * PXLB) + c2
    PXRB = (m / (1 + (m ^ 2))) * (cr3 - c2)
    PYRB = (m * PXRB) + c2
          
End Sub
