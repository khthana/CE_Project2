Attribute VB_Name = "ModVideo"
Option Explicit

' ====================================================================== CONSTANTS
Public Const MARKER_MAX As Integer = 15   ' Max index of marker
Public MARKER_ACTIVE As Long ' Active marker color
Public MARKER_NORMAL As Long ' Normal marker color
Public Const MARKER_SIZE As Long = 5    ' Marker size in pixels
Public Const FRAME_MAX As Integer = 3   ' Max frame index
Public Const BLOBDETECT_MAX As Integer = 99      ' Max blob index
Public Const MOVEMENT_RADIUS As Long = 40   ' Max movement radius in pixels
Public Const LOSTMARK_MAX As Long = 2   ' Max lost marker in frames

Public MARKER_NAME() As String  ' Marker's name in order

' ====================================================================== TYPES

Public Enum MARKER
    LHead = 0
    RHead
    Neck
    LSHLD
    RSHLD
    LElbow
    RElbow
    LWrist
    RWrist
    Chest
    LWaist
    RWaist
    LKnee
    RKnee
    LAnkle
    RAnkle
End Enum

Public Enum MARKERCOLOR
    cBlue = 0
    cPink
    cGreen
    cYellow
End Enum

Public Type MARKER_DATA    ' A marker on image
    valid As Boolean
    X As Long
    Y As Long
End Type

Public Type MARKER_GLOBAL       ' A marker data
    detectframe As MARKERCOLOR  ' Which view do it be detected for this marker
    Data() As MARKER_DATA
End Type

Public Type F_BLOB_EXT
    detectas As Integer
    dist As Double
End Type

' Color Samples
Public Type IMAGEPROCESS_DATA
    Name As String
    Range As F_HSVRANGE
    HueOffset As Long
    Blobs() As F_BLOB   ' Blob array after threshold
    BlobsExt() As F_BLOB_EXT    ' Extension for F_BLOB
    Blob_count As Long  ' Blob count
    blob_min As Long    ' Size of deteced blob
    blob_max As Long
End Type

' ====================================================================== GLOBAL VARIABLES
Public ProcessInfo() As IMAGEPROCESS_DATA

' ====================================================================== FUNCTIONS

Public Sub INIT_VIDEO() ' Init this module
    MARKER_ACTIVE = RGB(0, 0, 255)
    MARKER_NORMAL = RGB(255, 0, 0)
    
    ReDim MARKER_NAME(0 To MARKER_MAX) As String
    ReDim ProcessInfo(0 To FRAME_MAX) As IMAGEPROCESS_DATA
    
    Dim i As Integer
    For i = 0 To FRAME_MAX
        ReDim ProcessInfo(i).Blobs(0 To BLOBDETECT_MAX) As F_BLOB
        ReDim ProcessInfo(i).BlobsExt(0 To BLOBDETECT_MAX) As F_BLOB_EXT
    Next i

    ProcessInfo(0).Name = "Blue"
    ProcessInfo(1).Name = "Pink"
    ProcessInfo(2).Name = "Green"
    ProcessInfo(3).Name = "Yellow"

    MARKER_NAME(0) = "LHead"
    MARKER_NAME(1) = "RHead"
    MARKER_NAME(2) = "Neck"
    MARKER_NAME(3) = "LSHLD"
    MARKER_NAME(4) = "RSHLD"
    MARKER_NAME(5) = "LElbow"
    MARKER_NAME(6) = "RElbow"
    MARKER_NAME(7) = "LWrist"
    MARKER_NAME(8) = "RWrist"
    MARKER_NAME(9) = "Chest"
    MARKER_NAME(10) = "LWaist"
    MARKER_NAME(11) = "RWaist"
    MARKER_NAME(12) = "LKnee"
    MARKER_NAME(13) = "RKnee"
    MARKER_NAME(14) = "LAnkle"
    MARKER_NAME(15) = "RAnkle"
End Sub

