Attribute VB_Name = "modStereopsis"
Option Explicit

' ====================================================================== TYPES

Public Type STR_WORLDCOOR
    x As Double
    y As Double
    Z As Double
End Type

Public Type STR_IMAGECOOR
    x As Long
    y As Long
End Type

Public Type STR_IMAGESIZE
    width As Long
    height As Long
End Type

Public Type STR_CAMERA
    x As Double         ' Camera position (metres)
    y As Double
    Z As Double
    focus As Double     ' Focal length (metres)
    iwidth As Double    ' Image plane size (metres)
    iheight As Double
End Type

' ====================================================================== EXTERNAL FUNCTIONS

Public Declare Function STR_GetLeftCamera Lib "Stereopsis.dll" () As STR_CAMERA
Public Declare Function STR_GetRightCamera Lib "Stereopsis.dll" () As STR_CAMERA
Public Declare Sub STR_SetLeftCamera Lib "Stereopsis.dll" (camLeft As STR_CAMERA)
Public Declare Sub STR_SetRightCamera Lib "Stereopsis.dll" (camRight As STR_CAMERA)
Public Declare Function STR_GetWorldCoordinate Lib "Stereopsis.dll" (coorLeft As STR_IMAGECOOR, szLeft As STR_IMAGESIZE, coorRight As STR_IMAGECOOR, szRight As STR_IMAGESIZE) As STR_WORLDCOOR
Public Declare Function STR_GetLeftImageCoordinate Lib "Stereopsis.dll" (coorWorld As STR_WORLDCOOR, szLeft As STR_IMAGESIZE) As STR_IMAGECOOR
Public Declare Function STR_GetRightImageCoordinate Lib "Stereopsis.dll" (coorWorld As STR_WORLDCOOR, szRight As STR_IMAGESIZE) As STR_IMAGECOOR
Public Declare Sub STR_SetZOffset Lib "Stereopsis.dll" (ByVal Offset As Double)
Public Declare Function STR_GetZOffset Lib "Stereopsis.dll" () As Double
