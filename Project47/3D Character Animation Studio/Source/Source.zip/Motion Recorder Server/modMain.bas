Attribute VB_Name = "modMain"
Option Explicit

Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

' Settings
Public Const CON_BROADCASTIP As String = "255.255.255.255"
Public Const CON_REMOTEPORT As Integer = 8195

Public Sub Main()
    ChDir App.Path

    frmMain.Show
End Sub

