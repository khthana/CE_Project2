VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Motion Recorder Server"
   ClientHeight    =   2295
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   3975
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   153
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   265
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      Caption         =   "Client Settings"
      Height          =   1455
      Left            =   120
      TabIndex        =   2
      Top             =   120
      Width           =   3735
      Begin VB.CommandButton cmdUpdate 
         Caption         =   "Update"
         Height          =   375
         Left            =   240
         TabIndex        =   8
         Top             =   960
         Width           =   975
      End
      Begin VB.TextBox txtFilename 
         Height          =   315
         Left            =   1080
         TabIndex        =   5
         Text            =   "Sample"
         Top             =   600
         Width           =   2055
      End
      Begin VB.TextBox txtFramerate 
         Height          =   315
         Left            =   1080
         MaxLength       =   2
         TabIndex        =   3
         Text            =   "25"
         Top             =   240
         Width           =   375
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         Caption         =   ".AVI"
         Height          =   195
         Left            =   3240
         TabIndex        =   7
         Top             =   645
         Width           =   330
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         Caption         =   "Filename"
         Height          =   195
         Left            =   240
         TabIndex        =   6
         Top             =   645
         Width           =   630
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Framerate"
         Height          =   195
         Left            =   240
         TabIndex        =   4
         Top             =   290
         Width           =   705
      End
   End
   Begin VB.CommandButton cmdStop 
      Caption         =   "Stop"
      Height          =   495
      Left            =   2640
      TabIndex        =   1
      Top             =   1680
      Width           =   1215
   End
   Begin VB.CommandButton cmdStart 
      Caption         =   "Start"
      Height          =   495
      Left            =   1320
      TabIndex        =   0
      Top             =   1680
      Width           =   1215
   End
   Begin MSWinsockLib.Winsock sockMain 
      Left            =   0
      Top             =   0
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      Protocol        =   1
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdStart_Click()    ' Start record
    sockMain.RemoteHost = CON_BROADCASTIP
    sockMain.SendData "START"
End Sub

Private Sub cmdStop_Click()     ' Stop record
    sockMain.RemoteHost = CON_BROADCASTIP
    sockMain.SendData "STOP"
End Sub

Private Sub cmdUpdate_Click()   ' Set client's framerate & filename
    sockMain.RemoteHost = CON_BROADCASTIP
    sockMain.SendData "FRAMERATE:" + Format$(Val(txtFramerate.Text), "0")
    sockMain.RemoteHost = CON_BROADCASTIP
    sockMain.SendData "FILENAME:" + txtFilename.Text
End Sub

Private Sub Form_Load()
    sockMain.RemoteHost = CON_BROADCASTIP
    sockMain.RemotePort = CON_REMOTEPORT
End Sub

Private Sub Form_Unload(Cancel As Integer)
    sockMain.Close
End Sub

