package sqoproj;

import java.awt.*;
import javax.swing.JFrame;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class user extends JFrame {

  public user() {
  }
}