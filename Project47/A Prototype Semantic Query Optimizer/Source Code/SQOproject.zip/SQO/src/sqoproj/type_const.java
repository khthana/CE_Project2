package sqoproj;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class type_const extends JFrame {
  private ButtonGroup radioGroup;
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JRadioButton jRadioButton3 = new JRadioButton();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  //Frame1 menu = new Frame1();
  att_con att = new att_con();
  inter_con inter = new inter_con();
  fd_con fd = new fd_con();
  public type_const() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    jLabel1.setText("Select type of constraints");
    this.getContentPane().setLayout(xYLayout1);
    jRadioButton1.setText("Attribute constraint");
    jRadioButton2.setText("Inter-Attribute constraint");
    jRadioButton3.setText("Funtional Dependency constraint");
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    this.getContentPane().add(jLabel1, new XYConstraints(40, 31, 137, 35));
    this.getContentPane().add(jRadioButton1,    new XYConstraints(41, 79, 133, 40));
    this.getContentPane().add(jRadioButton2,       new XYConstraints(41, 130, 155, 40));
    this.getContentPane().add(jRadioButton3,     new XYConstraints(41, 184, 213, 39));
    this.getContentPane().add(jButton1, new XYConstraints(87, 239, 58, 29));
    this.getContentPane().add(jButton2,    new XYConstraints(168, 239, 74, 29));
    this.setSize(new Dimension(380, 350));
    this.setTitle("TYPE CONSTRAINTS");
    this.setLocation(200,150);
    radioGroup = new ButtonGroup();
    radioGroup.add(jRadioButton1);
    radioGroup.add(jRadioButton2);
    radioGroup.add(jRadioButton3);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    if(jRadioButton1.isSelected())  att.show();
    if(jRadioButton2.isSelected())  inter.show();
    if(jRadioButton3.isSelected())  fd.show();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    // System.exit(0);
     this.setVisible(false);
     //menu.setVisible(true);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
}