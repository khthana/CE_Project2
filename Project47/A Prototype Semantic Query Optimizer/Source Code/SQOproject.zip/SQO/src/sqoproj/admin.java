package sqoproj;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.sql.*;

public class admin extends JFrame {
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JPasswordField jPassword = new JPasswordField();
  private JButton jButton1 = new JButton();
  type_const typeframe = new type_const();
  private JLabel jLabel2 = new JLabel();
  dblink dbuser= new dblink();
  private JTextField jUser = new JTextField();
  public admin() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    jLabel1.setText("Password");
    this.getContentPane().setLayout(xYLayout1);
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    xYLayout1.setWidth(398);
    xYLayout1.setHeight(200);
    jLabel2.setText("Username");
    jPassword.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jPassword_actionPerformed(e);
      }
    });
    this.getContentPane().add(jLabel1, new XYConstraints(34, 51, 65, 27));
    this.getContentPane().add(jPassword, new XYConstraints(103, 51, 108, 24));
    this.getContentPane().add(jLabel2, new XYConstraints(32, 13, -1, 20));
    this.getContentPane().add(jUser,  new XYConstraints(102, 11, 109, 27));
    this.getContentPane().add(jButton1,  new XYConstraints(229, 52, 54, 25));
    this.setLocation(250,180);
    this.setSize(new Dimension(325, 140));
    this.setTitle("LOGIN ");
  }

void jButton1_actionPerformed(ActionEvent e) {
    String pa,us;
    pa = jPassword.getText();
    us = jUser.getText();

    try{
    ResultSet setus;
    setus=dbuser.GetResultset("SELECT * from login where admin='"+ us +"'");
    setus.last();
    if(setus.getRow()!= 0){
    setus.first();
    String ps =setus.getString(2).trim();
    if(pa.equals(ps)){
         this.setVisible(false);
         typeframe.show();
         jUser.setText("");
         jPassword.setText("");
    }
    else {JOptionPane.showMessageDialog(null," Invalid Password","Authentication",JOptionPane.WARNING_MESSAGE );
      jPassword.setText("");}
    }
    else {
      JOptionPane.showMessageDialog(null," Invalid Username","Authentication",JOptionPane.WARNING_MESSAGE );
      jUser.setText("");
      jPassword.setText("");}
    }
catch(SQLException sqlException){
JOptionPane.showMessageDialog(null,sqlException.getMessage() ,"Database Error",JOptionPane.ERROR_MESSAGE);}
  }

  void jPassword_actionPerformed(ActionEvent e) {
    String pa,us;
   pa = jPassword.getText();
   us = jUser.getText();

   try{
   ResultSet setus;
   setus=dbuser.GetResultset("SELECT * from login where admin='"+ us +"'");
   setus.last();
   if(setus.getRow()!= 0){
   setus.first();
   String ps =setus.getString(2).trim();
   if(pa.equals(ps)){
        this.setVisible(false);
        typeframe.show();
        jUser.setText("");
        jPassword.setText("");
   }
   else {JOptionPane.showMessageDialog(null," Invalid Password","Authentication",JOptionPane.WARNING_MESSAGE );
     jPassword.setText("");}
   }
   else {
     JOptionPane.showMessageDialog(null," Invalid Username","Authentication",JOptionPane.WARNING_MESSAGE );
     jUser.setText("");
     jPassword.setText("");}
   }
catch(SQLException sqlException){
JOptionPane.showMessageDialog(null,sqlException.getMessage() ,"Database Error",JOptionPane.ERROR_MESSAGE);}
  }
}