package sqoproj;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.util.*;

public class att_con extends JFrame {
   dblinktb  dbatt = new dblinktb();
   dblink  dbattcon = new dblink();
   ResultSet tmpset,tmp2;
   String tabname="customer_tbl";
   int sel=0;   // select type constraint
   // for send to database/////
      int sign=0;            //
      String att,valueatt;   //

//----------------------- com gen ------------------
   private JLabel jLabel1 = new JLabel();
   private JLabel jLabel2 = new JLabel();
   private JPanel jPanel1 = new JPanel();
   private JRadioButton jRadiotype1 = new JRadioButton();
   private XYLayout xYLayout2 = new XYLayout();
   private JLabel jLabel3 = new JLabel();
   private JComboBox jComboatt1 = new JComboBox();
   private JLabel jLabel4 = new JLabel();
   private JComboBox jCombosign1 = new JComboBox();
   private JLabel jLabel5 = new JLabel();
   private JTextField jTextval1 = new JTextField();
   private JPanel jPanel2 = new JPanel();
   private TitledBorder titledBorder1;
   private JRadioButton jRadiotype2 = new JRadioButton();
   private XYLayout xYLayout3 = new XYLayout();
   private JLabel jLabel6 = new JLabel();
   private JLabel jLabel7 = new JLabel();
   private JLabel jLabel8 = new JLabel();
   private JLabel jLabel9 = new JLabel();
   private JLabel jLabel10 = new JLabel();
   private JTextField jTextval21 = new JTextField();
   private JComboBox jCombosign21 = new JComboBox();
   private JComboBox jCombosign22 = new JComboBox();
   private JTextField jTextval22 = new JTextField();
   private JComboBox jComboatt2 = new JComboBox();
   private JButton jButtonok1 = new JButton();
   private JButton jButtonok2 = new JButton();
   private JComboBox jComboatt3 = new JComboBox();
   private JTextField jTextval3 = new JTextField();
   private XYLayout xYLayout4 = new XYLayout();
   private JLabel jLabel12 = new JLabel();
   private JLabel jLabel13 = new JLabel();
   private JRadioButton jRadiotype3 = new JRadioButton();
   private JButton jButtonok3 = new JButton();
   private JPanel jPanel3 = new JPanel();
   private JLabel jLabel11 = new JLabel();
   private JButton jButtonok = new JButton();
   private JButton jButtoncancel = new JButton();
   private JComboBox jCombotable = new JComboBox();
   private TitledBorder titledBorder2;
   private ButtonGroup attgroup;
  private TitledBorder titledBorder3;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea jTextshow = new JTextArea();

  public att_con() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    titledBorder3 = new TitledBorder("");
    this.setSize(new Dimension(652, 420));
    this.setLocation(50,50);
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    this.getContentPane().setLayout(null);
    jLabel1.setText("Attribute Constraint");
    jLabel1.setBounds(new Rectangle(265, 10, 155, 39));
    jLabel2.setText("Table");
    jLabel2.setBounds(new Rectangle(19, 62, 58, 20));
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBounds(new Rectangle(15, 89, 619, 58));
    jPanel1.setLayout(xYLayout2);
    jRadiotype1.setText("< , > , <= , >= , =");
    jRadiotype1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jRadiotype1_actionPerformed(e);
      }
    });
    jLabel3.setText("Attribute");
    jLabel4.setText("sign");
    jLabel5.setText("value");
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBounds(new Rectangle(14, 157, 621, 61));
    jPanel2.setLayout(xYLayout3);
    jRadiotype2.setText("value1 < x < value2");
    jRadiotype2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jRadiotype2_actionPerformed(e);
      }
    });
    jLabel6.setText("value");
    jLabel7.setText("sign1");
    jLabel8.setText("Attribute");
    jLabel9.setText("sign2");
    jLabel10.setText("value");
    jButtonok1.setEnabled(false);
    jButtonok1.setMargin(new Insets(1, 1, 1, 1));
    jButtonok1.setText("OK");
    jButtonok1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonok1_actionPerformed(e);
      }
    });
    jButtonok2.setEnabled(false);
    jButtonok2.setMargin(new Insets(1, 1, 1, 1));
    jButtonok2.setText("OK");
    jButtonok2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonok2_actionPerformed(e);
      }
    });
    jButtonok3.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent e) {
    jButtonok3_actionPerformed(e);
      }
    });
    jLabel12.setText("in");
    jLabel13.setText("Attribute");
    jRadiotype3.setText("in");
    jRadiotype3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jRadiotype3_actionPerformed(e);
      }
    });
    jButtonok3.setText("OK");
    jButtonok3.setEnabled(false);
    jButtonok3.setMargin(new Insets(1, 1, 1, 1));
    jPanel3.setLayout(xYLayout4);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setBounds(new Rectangle(14, 227, 620, 61));
    jLabel11.setText("Display Constraint");
    jLabel11.setBounds(new Rectangle(24, 293, 112, 35));
    jButtonok.setBounds(new Rectangle(451, 315, 46, 27));
    jButtonok.setEnabled(false);
    jButtonok.setMaximumSize(new Dimension(45, 23));
    jButtonok.setMinimumSize(new Dimension(45, 23));
    jButtonok.setPreferredSize(new Dimension(45, 23));
    jButtonok.setMargin(new Insets(1, 1, 1, 1));
    jButtonok.setMnemonic('0');
    jButtonok.setText("OK");
    jButtonok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonok_actionPerformed(e);
      }
    });
    jButtoncancel.setBounds(new Rectangle(506, 314, 46, 28));
    jButtoncancel.setMargin(new Insets(0, 0, 0, 0));
    jButtoncancel.setText("Cancel");
    jButtoncancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtoncancel_actionPerformed(e);
      }
    });
    jCombotable.setBorder(BorderFactory.createLoweredBevelBorder());
    jCombotable.setBounds(new Rectangle(56, 60, 149, 23));
    jCombotable.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        jCombotable_actionPerformed(e);
      }
    });
    this.setTitle("Attribute Constraint");
    jCombosign1.setEnabled(false);
    jCombosign1.setToolTipText("");
    jCombosign21.setEnabled(false);
    jCombosign22.setEnabled(false);
    jScrollPane1.setBounds(new Rectangle(159, 301, 271, 62));
    jTextshow.setEditable(false);
    jComboatt1.setEnabled(false);
    jComboatt2.setEnabled(false);
    jComboatt3.setEnabled(false);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jLabel2, null);
    jPanel1.add(jButtonok1,        new XYConstraints(564, 16, 34, -1));
    jPanel1.add(jLabel4, new XYConstraints(278, 5, 58, 22));
    jPanel1.add(jComboatt1, new XYConstraints(142, 29, 126, 20));
    jPanel1.add(jLabel3, new XYConstraints(142, 10, 59, -1));
    jPanel1.add(jLabel5, new XYConstraints(368, 11, 42, 14));
    jPanel1.add(jCombosign1, new XYConstraints(280, 29, 74, 19));
    jPanel1.add(jRadiotype1, new XYConstraints(0, 18, -1, -1));
    jPanel1.add(jTextval1, new XYConstraints(364, 28, 93, 20));
    this.getContentPane().add(jLabel11, null);
    this.getContentPane().add(jButtoncancel, null);
    this.getContentPane().add(jButtonok, null);
    this.getContentPane().add(jCombotable, null);
    this.getContentPane().add(jPanel2, null);
    jPanel2.add(jRadiotype2,   new XYConstraints(2, 13, -1, -1));
    jPanel2.add(jButtonok2,  new XYConstraints(565, 16, 32, 26));
    jPanel2.add(jCombosign21, new XYConstraints(214, 26, 56, 19));
    jPanel2.add(jComboatt2, new XYConstraints(271, 26, 106, 20));
    jPanel2.add(jTextval22, new XYConstraints(444, 26, 70, 18));
    jPanel2.add(jLabel10, new XYConstraints(446, 7, 46, 23));
    jPanel2.add(jCombosign22, new XYConstraints(384, 27, 55, 18));
    jPanel2.add(jLabel9, new XYConstraints(386, 6, 38, 24));
    jPanel2.add(jLabel8, new XYConstraints(272, 5, 58, 23));
    jPanel2.add(jLabel7, new XYConstraints(215, 10, 40, 15));
    jPanel2.add(jTextval21, new XYConstraints(142, 26, 69, -1));
    jPanel2.add(jLabel6, new XYConstraints(146, 10, 45, 14));
    this.getContentPane().add(jPanel3, null);
    jPanel3.add(jComboatt3,  new XYConstraints(144, 20, 104, 20));
    jPanel3.add(jLabel12, new XYConstraints(255, 18, 38, 24));
    jPanel3.add(jTextval3,  new XYConstraints(268, 19, 235, 22));
    jPanel3.add(jButtonok3, new XYConstraints(565, 16, 32, 26));
    jPanel3.add(jLabel13, new XYConstraints(92, 19, 58, 23));
    jPanel3.add(jRadiotype3, new XYConstraints(2, 14, -1, -1));
    this.getContentPane().add(jPanel1, null);
    attgroup = new ButtonGroup();
    attgroup.add(jRadiotype1);
    attgroup.add(jRadiotype2);
    attgroup.add(jRadiotype3);
    jScrollPane1.getViewport().add(jTextshow, null);

    jCombosign1.addItem("=");
    jCombosign1.addItem("!=");
    jCombosign1.addItem(">") ;
    jCombosign1.addItem("<") ;
    jCombosign1.addItem(">=");
    jCombosign1.addItem("<=");
    jCombosign21.addItem("<");
    jCombosign21.addItem("<=");
    jCombosign22.addItem("<");
    jCombosign22.addItem("<=");
    myinit();
  }
//////////--------------------- my function ---------------------------

public void myinit(){
  try {
   String SQL ="SELECT DISTINCT table_name FROM information_schema.columns WHERE table_name in (select table_name FROM Information_Schema.Tables WHERE Table_Type='Base Table' and table_name <> 'dtproperties') ORDER BY table_name";
   tmpset = dbatt.GetResultset(SQL);
   String t="";
   tmpset.first();
   String k=tmpset.getString(1);
   jCombotable.addItem(k);
   while (tmpset.next()) {
   k=tmpset.getString(1);
   jCombotable.addItem(k);  }
   tmpset.close();
   this.getContentPane().add(jScrollPane1, null);
      this.getContentPane().add(jLabel1, null);
   }
    catch (SQLException sqlException ){
    JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
    System.exit(1);
    }
}


void  getattribute(JComboBox combo){
  try {
   combo.removeAllItems();
   String tabname= ""+ jCombotable.getSelectedItem();
   String SQL2 ="SELECT * FROM "+ tabname +" ";
   tmpset = dbatt.GetResultset(SQL2);
   tmpset.first();
   ResultSetMetaData metaD=tmpset.getMetaData();
   int numbc = metaD.getColumnCount();
   for(int loop=1 ; loop <= numbc ; loop++)
   combo.addItem(""+ metaD.getColumnName(loop));
   }
    catch (SQLException sqlException ){
    JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
    System.exit(1);
    }
}


// ----------------------- action --------------------------------
  void jRadiotype1_actionPerformed(ActionEvent e) {
   jCombosign1.setEnabled(true);
   jButtonok1.setEnabled(true);
   jComboatt1.setEnabled(true);
   jCombosign21.setEnabled(false);
   jCombosign22.setEnabled(false);
   jComboatt2.setEnabled(false);
   jComboatt2.removeAllItems();
   jComboatt3.setEnabled(false);
   jComboatt3.removeAllItems();
   jButtonok2.setEnabled(false);
   jButtonok3.setEnabled(false);
   jTextshow.setText("");
   jTextval21.setText("");
   jTextval22.setText("");
   jTextval3.setText("");
   getattribute(jComboatt1);
   sel=1;
  }

  void jRadiotype2_actionPerformed(ActionEvent e) {
    jCombosign21.setEnabled(true);
    jCombosign22.setEnabled(true);
    jComboatt2.setEnabled(true);
    jButtonok2.setEnabled(true);
    jComboatt1.setEnabled(false);
    jComboatt1.removeAllItems();
    jComboatt3.setEnabled(false);
    jComboatt3.removeAllItems();
    jCombosign1.setEnabled(false);
    jButtonok1.setEnabled(false);
    jButtonok3.setEnabled(false);
    jTextval1.setText("");
    jTextval3.setText("");
    jTextshow.setText("");
    getattribute(jComboatt2);
    sel =2;
  }

  void jRadiotype3_actionPerformed(ActionEvent e) {
     jButtonok3.setEnabled(true);
     jComboatt2.setEnabled(false);
     jComboatt2.removeAllItems();
     jComboatt1.setEnabled(false);
     jComboatt1.removeAllItems();
     jComboatt3.setEnabled(true);
     jCombosign1.setEnabled(false);
     jButtonok1.setEnabled(false);
     jCombosign21.setEnabled(false);
     jCombosign22.setEnabled(false);
     jButtonok2.setEnabled(false);
     jTextval1.setText("");
     jTextval21.setText("");
     jTextval22.setText("");
     jTextshow.setText("");
     getattribute(jComboatt3);
     sel=3;
  }

  void jButtoncancel_actionPerformed(ActionEvent e) {
    jButtonok.setEnabled(false);
    jCombotable.removeAllItems();
    jComboatt1.removeAllItems();
    jComboatt2.removeAllItems();
    jComboatt3.removeAllItems();

    jButtonok3.setEnabled(false);
    jCombosign1.setEnabled(false);
    jButtonok1.setEnabled(false);
    jCombosign21.setEnabled(false);
    jCombosign22.setEnabled(false);
    jButtonok2.setEnabled(false);
    jTextshow.setText("");
    jTextval1.setText("");
    jTextval21.setText("");
    jTextval22.setText("");
    jTextval3.setText("");
    jTextshow.setText("");
    myinit();
  }

  void jCombotable_actionPerformed(ItemEvent e) {
    if (e.getStateChange() == ItemEvent.SELECTED){
    switch (sel){
        case 1: getattribute(jComboatt1); break;
        case 2: getattribute(jComboatt2); break;
        case 3: getattribute(jComboatt3); break;
        default:
    }
    }
  }

  void jButtonok1_actionPerformed(ActionEvent e) {
   int attempty=jComboatt1.getSelectedIndex();
   if((attempty != -1) && (!jTextval1.getText().equals("") ) )
    {
      jButtonok.setEnabled(true);
      att= ""+jComboatt1.getSelectedItem();
      valueatt= jTextval1.getText();
      tabname=""+jCombotable.getSelectedItem();
       switch (jCombosign1.getSelectedIndex()){
         case 0: sign = 0;  break;  // 0 = '='
         case 1: sign = 1;  break;  // 1 = '!='
         case 2: sign = 2;  break;  // 2 = '>'
         case 3: sign = 3;  break;  // 3 = '<'
         case 4: sign = 4;  break;  // 4 = '>='
         case 5: sign = 5;  break;  // 5 = '<='
         default:
       }
    jTextshow.setText(jComboatt1.getSelectedItem()+"  " + jCombosign1.getSelectedItem()+"  "+jTextval1.getText());
   }
    else
      jTextshow.setText("Please fill all field");
  }

  void jButtonok2_actionPerformed(ActionEvent e) {
    int attempty=jComboatt2.getSelectedIndex();

    if((attempty != -1) && !jTextval21.getText().equals("") && !jTextval22.getText().equals("") )
       { int vall,valr;
         vall= Integer.parseInt(jTextval21.getText());
         valr= Integer.parseInt(jTextval22.getText());
          if(vall < valr){
          jButtonok.setEnabled(true);
          att= ""+jComboatt2.getSelectedItem();
          valueatt= jTextval21.getText()+"/"+ jTextval22.getText();
          tabname=""+jCombotable.getSelectedItem();
          if(jCombosign21.getSelectedIndex()==0){
              if(jCombosign22.getSelectedIndex()==0) sign=6;
              else sign=7;}
          else{
              if(jCombosign22.getSelectedIndex()==0) sign=9;
              else sign=8;
            }
            jTextshow.setText(jTextval21.getText()+"  "+ jCombosign21.getSelectedItem()
         +"  "+jComboatt2.getSelectedItem()+"  "+ jCombosign22.getSelectedItem()+"  "+jTextval22.getText());

          }
          else { jTextshow.setText("value not match");}
        }
       else
         jTextshow.setText("Please fill all field");
  }
  void jButtonok3_actionPerformed(ActionEvent e) {
    int attempty=jComboatt3.getSelectedIndex();
    if((attempty != -1) && (!jTextval3.getText().equals("") ) )
       {
      jTextshow.setText(jComboatt3.getSelectedItem()+"  in  "+jTextval3.getText() );
      jButtonok.setEnabled(true);
      att= ""+jComboatt3.getSelectedItem();
      valueatt= jTextval3.getText();
      tabname=""+jCombotable.getSelectedItem();
      sign= 10;
    }
       else
         jTextshow.setText("Please fill all field");
  }

  void jButtonok_actionPerformed(ActionEvent e) {
    int st=0;
    StringBuffer test =new StringBuffer();
    test.append(valueatt);
    boolean count=true;
    while((valueatt.indexOf("'",st) != -1)&&(count)){
      test.insert(valueatt.indexOf("'",st),"'");
      valueatt = test.toString();
      if(valueatt.length() > valueatt.indexOf("'",st) + 2)
      st=valueatt.indexOf("'",st) + 2;
      else count=false;
    }

   dbattcon.InsertData("INSERT INTO att_const values('"+ att +"','"+tabname+"',"+ sign +",'"+ valueatt +"')");
   jButtonok.setEnabled(false);
   jTextshow.setText("");
  }
}