package sqoproj;

import java.util.*;
import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.swing.table.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class us_query extends JFrame {
  String tbname;
  boolean reject = false;
  int q_flag=0,count;
  String query,output;
  int posi,index=0,pos1,pos2,pos3,str;
  boolean bw;
  String ntbname[]= new String[5];     // name of table query
  String tmptbname[]=new String[5];    // name label of name table
  boolean flagtmpname=false;           // if have label name set true
  int ntb=0;                           // number of table for query
  int checkupdate[]=new int[20];    // if -1  = cutt off
                                    // if 0  = default nochange
                                    // if 1 = index introduction
                                    // if 2  = update value
                                    // if 3 = reduce scan

  String[] indextb= new String[5];   // one table have one cluster index
  String indexcol[]= new String[5];
  int tmpcolind[]= new int[5];
  int numind;
  long firstTime,lastTime,elapseTime;  // for catch time
  String clause[] =new String [20];
  int conj[] =new int [20];
  String att[] = new String [20];
  int sign[] = new int [20];
  String val[] =new String [20];
  String tb[] = new String [20];
  boolean clus[] = new boolean[20];
  int and_or[] = new int [20];
  dblink dbconst = new dblink();
  dblinktb db = new dblinktb();
  checkatt chkatt = new checkatt();

  private ResultSetTable tableset1,tableset2;
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JTextField jTimeOld = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JTextField jTimeNew = new JTextField();
  private JButton jTranf = new JButton();
  private JButton jClrOld = new JButton();
  private JLabel jLabel6 = new JLabel();
  private JScrollPane jScrollOld = new JScrollPane();
  private JTextArea jTextOld = new JTextArea();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JTextArea jTextNew = new JTextArea();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JScrollPane jScrollPane3 = new JScrollPane();
  private JTable jTable1;
  private JTable jTable2;
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private JTextField jrownew = new JTextField();
  private JTextField jrowold = new JTextField();
  private JLabel jLabel10 = new JLabel();
  private JLabel jLabel11 = new JLabel();
  private JLabel jLabel12 = new JLabel();
  private JLabel jLabel13 = new JLabel();
  private JLabel jLabel14 = new JLabel();
  private JLabel jLabel15 = new JLabel();

  public us_query() {
    try {
      tableset1 = new ResultSetTable("sun.jdbc.odbc.JdbcOdbcDriver","jdbc:odbc:SQODB","select null") ;
      tableset2 = new ResultSetTable("sun.jdbc.odbc.JdbcOdbcDriver","jdbc:odbc:SQODB","select null") ;
      jTable1 = new JTable(tableset1);
      jTable2 = new JTable(tableset2);
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    jLabel1.setFont(new java.awt.Font("Serif", 1, 18));
    jLabel1.setText("User Query");
    this.getContentPane().setLayout(xYLayout1);
    xYLayout1.setWidth(787);
    xYLayout1.setHeight(547);
    this.setTitle("USER QUERY");
    this.setLocation(100,0);
    jLabel3.setText("New Query");
    jLabel4.setText("Time");
    jLabel5.setText("Time");
    jTranf.setActionCommand("Transform ");
    jTranf.setText("Transform Query");
    jTranf.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jTranf_actionPerformed(e);
      }
    });
    jClrOld.setText("Clear");
    jClrOld.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jClrOld_actionPerformed(e);
      }
    });
    jLabel6.setText("Original");
    this.init();
    jLabel7.setText("New");
    jLabel8.setText("ms");
    jLabel9.setText("ms");
    jLabel10.setText("rows");
    jLabel11.setText("rows");
    jLabel12.setText("Result");
    jLabel13.setText("Result");
    jLabel14.setText("Original");
    jLabel15.setText("Query");
    this.setLocation(3,3);
    this.setSize(new Dimension(800, 570));
    jTimeOld.setHorizontalAlignment(SwingConstants.RIGHT);
    jrownew.setHorizontalAlignment(SwingConstants.RIGHT);
    jrowold.setHorizontalAlignment(SwingConstants.RIGHT);
    this.getContentPane().add(jScrollOld,              new XYConstraints(80, 27, 566, 126));
    jScrollOld.getViewport().add(jTextOld, null);
    this.getContentPane().add(jScrollPane2,               new XYConstraints(79, 156, 568, 127));
    jScrollPane2.getViewport().add(jTextNew, null);
    this.getContentPane().add(jTranf,      new XYConstraints(650, 118, 129, 48));
    this.getContentPane().add(jTimeOld,  new XYConstraints(660, 50, 78, 28));
    this.getContentPane().add(jrownew, new XYConstraints(659, 256, 78, 28));
    this.getContentPane().add(jLabel11, new XYConstraints(740, 265, 37, 20));
    this.getContentPane().add(jLabel4,  new XYConstraints(660, 25, 55, 24));
    this.getContentPane().add(jTimeNew, new XYConstraints(659, 226, 78, 27));
    this.getContentPane().add(jLabel9, new XYConstraints(743, 229, 24, 26));
    this.getContentPane().add(jrowold,  new XYConstraints(661, 79, 78, 28));
    this.getContentPane().add(jLabel10,  new XYConstraints(742, 88, 32, 20));
    this.getContentPane().add(jLabel8,   new XYConstraints(742, 56, 24, 26));
    this.getContentPane().add(jLabel5,  new XYConstraints(660, 202, 52, 24));
    this.getContentPane().add(jScrollPane1,   new XYConstraints(79, 287, 662, 123));
    this.getContentPane().add(jScrollPane3,  new XYConstraints(79, 414, 661, 119));
    this.getContentPane().add(jLabel13, new XYConstraints(20, 432, 50, 18));
    this.getContentPane().add(jLabel7, new XYConstraints(18, 416, 45, 18));
    this.getContentPane().add(jLabel12, new XYConstraints(15, 301, 46, 37));
    this.getContentPane().add(jLabel6, new XYConstraints(13, 284, 59, 37));
    this.getContentPane().add(jLabel14,  new XYConstraints(21, 13, 60, 44));
    this.getContentPane().add(jLabel15,  new XYConstraints(22, 34, 60, 44));
    this.getContentPane().add(jLabel3, new XYConstraints(7, 149, 73, 32));
    this.getContentPane().add(jLabel1,   new XYConstraints(325, 0, 111, 36));
    this.getContentPane().add(jClrOld,   new XYConstraints(651, 169, 127, -1));
    jScrollPane3.getViewport().add(jTable2, null);
    jScrollPane1.getViewport().add(jTable1, null);
    getcolindex();
  }

  void nametb(){
  int pswhere;
  System.out.println(jTextOld.getText().trim());
  String query = jTextOld.getText().replace('\n',' ');
  query.trim();
  if (query.indexOf(" where ")==-1)
    pswhere=query.length();
  else
    pswhere=query.indexOf(" where ");  // position before where 1 char
  String txfrom=query.substring(query.indexOf(" from ")+6,pswhere).trim();
  if (txfrom.indexOf(",")== -1)
     {  ntbname[0]=txfrom.substring(0,txfrom.length());
        ntb++;
     }
  else{
    int poEnd=txfrom.lastIndexOf(","),str=0,end=txfrom.indexOf(",",str);
    while(end <= poEnd){
       if(txfrom.indexOf(",",str+1) == -1) end=txfrom.length();
       else   end=txfrom.indexOf(",",str+1);
//      System.out.println("\nstr= "+str +"\nend= "+end +"pend= "+poEnd);
      if(txfrom.indexOf(" ",str+1)==-1) // check have customer c or not
       ntbname[ntb]=txfrom.substring(str,end).trim();
       else
       {  flagtmpname=true;
          ntbname[ntb]=txfrom.substring(str,txfrom.indexOf(" ",str+1)).trim();
          tmptbname[ntb]=txfrom.substring(txfrom.indexOf(" ",str+1),end).trim();
       }
       str=end+1;
       ntb++;
    }  // while loop
  } // end else
//for(int i=0;i < ntb;i++)
//System.out.println( "table : "+ntbname[i]+"-"+tmptbname[i]+"-");
//System.out.println( "number : "+ntb);
  } // end function

  void init(){
    jTextNew.setEnabled(false);
    jTimeNew.setHorizontalAlignment(SwingConstants.RIGHT);
    for(int i=0;i<5;i++){
    ntbname[i]= "";      // name of table query
    tmptbname[i]= ""; }  // name label of name table
    flagtmpname=false;   // if have label name set true
    ntb=0;
  }
 void checktb(String att){
    //nametb();
    String query1,output1,tbn,tbn1,tbn2;
    int posi1,posi2,posi3,posi4,posi5;
    query1 = jTextOld.getText();
    posi1=query1.indexOf("from");
    if(query1.indexOf("where") == -1)
      output1 = query1.substring(posi1+4,query1.trim().length()).trim() ;
    else
      output1 = query1.substring(posi1+4,query1.indexOf("where")).trim() ;
    if(att.indexOf(".")==-1){   //one table
      tbname = output1;
    }
    else {
      posi2 = output1.indexOf(" ");
      posi3 =output1.indexOf(",");
      posi4 = output1.lastIndexOf(" ");
      tbn1=output1.substring(posi2,posi3).trim() ;
      tbn2=output1.substring(posi4).trim();
      posi5 = att.indexOf(".");
      tbn = att.substring(0,posi5);
      if(tbn.equalsIgnoreCase(tbn1)) tbname = output1.substring(0,posi2).trim();
      if(tbn.equalsIgnoreCase(tbn2)) tbname = output1.substring(posi3+1,posi4).trim();
    }

  }

  public boolean check_cond(boolean clause[],int conj[],int index){
    int i=0;
    boolean result=false,flag=true,flag_or=false;
    if(conj[i]==0&&clause[i]) result =true;
    while(conj[i]!=0){
      if(!clause[i]) flag = false;
      if(conj[i] ==2){  //OR
        flag_or =true;
             if(!flag)
               flag = true;
             else
               result =true;
        }
        i++;
        if(conj[i]==0){
          if(!clause[i]) flag = false;
          if((flag&&result&&flag_or)||(!flag_or&&flag)){
            q_flag =0; // true or true
            result =true;
          }
          if(!flag&&result&&flag_or) q_flag =1; // true or false
          if(flag&&!result&&flag_or){
            q_flag = 2;   // false or true
            result = true;
          }
        }
      }//end while
      if(result) return true;
      else return false;
  }
  void init_var(){
    count=0;
    reject= false;
    query="";
    output="";
    q_flag=posi=index=pos1=pos2=pos3=str=count=0;
    bw=false;
    for(int i=0;i<20;i++){
      conj[i] = 0;
      sign[i] = 0;
      and_or[i] = 0;
      att[i]="";
      sign[i]=0;
      clause[i]="";
      checkupdate[i]=0;
      val[i]="";
      tb[i]="";
    }
    for(int i=0;i<5;i++){
    ntbname[i]= "";      // name of table query
    tmptbname[i]= ""; }  // name label of name table
    flagtmpname=false;   // if have label name set true
    ntb=0;
    firstTime=0;
    lastTime=0;
    elapseTime=0;
  }
  void findatt(String output){
    str = 0;
    index = 0;
    count = 0;
    pos1=output.indexOf(" and ")+1;
    pos2=output.indexOf(" or ")+1;
    pos3=output.indexOf(" between ")+1;
    if((pos1== 0 && pos2 == 0)||((pos2==0) && (pos1>pos3)&& (pos3 != 0) && (pos1==output.lastIndexOf(" and ")+1)) ){   // only clause
      clause[0] = output;
      and_or[0] = 0; //not have conjuction(AND,OR)
    }
    else {
    while(pos1!= 0 || pos2 != 0){
      pos1=output.indexOf(" and ",str)+1;
      pos2=output.indexOf(" or ",str)+1;
      pos3=output.indexOf(" between ",str)+1;
      if(pos1==0 && pos2 == 0) break;
      bw = false;
      if(((pos1<pos2)&& (pos1 != 0))|| pos2 == 0){   //and before or
        if(pos1>pos3 && (pos3 != 0)){
          str = pos1+3;
          bw = true;
        }
        if(!bw){
        conj[index] = pos1;
        and_or[index]=1; //AND = 1
        str = pos1+3;
        index++;
        }
      }
      else if(((pos1>pos2)&& pos2 != 0)||pos1 == 0)   //or before and
      {
        if(pos1>pos3 && (pos3 != 0)){
          conj[index] = pos2;
          and_or[index] = 2;  //OR = 2
          str = pos1+3;
          bw = true;
          index++;
        }
        if(!bw){
          conj[index] = pos2;
          and_or[index] = 2;  //OR = 2
          str = pos2+2;
          index++;
        }

      }
    }//end while
    }//end else
    for(int i=0;i<index;i++){
      if(i==0) clause[i] = output.substring(0,conj[i]).trim();
      else {
        clause[i] = output.substring(conj[i-1]+3,conj[i]).trim();
      }
        if(conj[i+1] == 0){
          clause[i+1] = output.substring(conj[i]+3).trim();
        }
    }

    int count_clause = index+1;
    count = count_clause;
    int tempos1,tempos2;
    String atttemp;
    for(int j=0;j<count_clause;j++){
      if(clause[j].indexOf("!=") != -1 ){
        tempos1 = clause[j].indexOf("!=");
        tempos2 = tempos1+2;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 1;
        val[j] = clause[j].substring(tempos2).trim();
      }
      else if(clause[j].indexOf(">=") != -1 ){
        tempos1 = clause[j].indexOf(">=");
        tempos2 = tempos1+2;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 4;
        val[j] = clause[j].substring(tempos2).trim();
      }
      else if(clause[j].indexOf("<=") != -1 ){
        tempos1 = clause[j].indexOf("<=");
        tempos2 = tempos1+2;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 5;
        val[j] = clause[j].substring(tempos2).trim();
      }
      else if(clause[j].indexOf("=") != -1 ){
        tempos1 = clause[j].indexOf("=");
        tempos2 = tempos1+1;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 0;
        val[j] = clause[j].substring(tempos2).trim();
      }
      else if(clause[j].indexOf(">") != -1 ){
        tempos1 = clause[j].indexOf(">");
        tempos2 = tempos1+1;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 2;
        val[j] = clause[j].substring(tempos2).trim();
      }
      else if(clause[j].indexOf("<") != -1 ){
        tempos1 = clause[j].indexOf("<");
        tempos2 = tempos1+1;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 3;
        val[j] = clause[j].substring(tempos2).trim();
      }
      else if(clause[j].indexOf("in") != -1 ){
        String temp1,temp2;
        int a,b;
        tempos1 = clause[j].indexOf("in");
        tempos2 = tempos1+2;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 10;
        temp1 = clause[j].substring(tempos2).trim();
        a = temp1.indexOf("(");
        b = temp1.indexOf(")");
        val[j] = temp1.substring(a+1,b);
      }
      else if(clause[j].indexOf("between") != -1 ){
        String val1,val2,val3;
        int x,y,z;
        tempos1 = clause[j].indexOf("between");
        tempos2 = tempos1+7;
        atttemp = clause[j].substring(0,tempos1).trim();
        this.checktb(atttemp);
        if(atttemp.indexOf(".")==-1)
          att[j] = clause[j].substring(0,tempos1).trim();
        else
          att[j] = clause[j].substring(atttemp.indexOf(".")+1,tempos1).trim();
        tb[j] = tbname;
        sign[j] = 8;
        val3 = clause[j].substring(tempos2).trim();
        z = val3.indexOf(" and ")+1;
        val1 = val3.substring(0,z).trim();
        val2 = val3.substring(z+3).trim();
        val[j] = val1+"/"+val2;
      }
  }//end for

  }

  void jTranf_actionPerformed(ActionEvent e) {
    nametb();
    String output1="" , op_query="";
    jTimeNew.setText("");
    jTextNew.setText("");
    jrowold.setText("");
    jrownew.setText("");
    jTextNew.setEnabled(true);
    jTimeNew.setEnabled(true);
    query = jTextOld.getText().replace('\n',' ');
    posi=query.indexOf("where");
    if(posi!= -1){
    output1 = ""+query.substring(0,posi+6) ;
    output = query.substring(posi+5).trim() ;
    this.findatt(output);
    System.out.println("\nAfter pass function findatt- below -loop ="+ count);
    for(int i=0;i<count;i++){
      System.out.println(att[i]+"   "+sign[i]+"  "+val[i]+"   "+tb[i]);
      // System.out.println(and_or[j]);
    }
    System.out.println("----- check attribute -----");
    char t;
    for(int j=0;j<count;j++){
      t= val[j].charAt(0);
    if(Character.isDigit(t)||(!Character.isLetterOrDigit(t)))
      clus[j] = chkatt.compare(att[j],tb[j],sign[j],val[j]);
    else clus[j] = true;
 //     System.out.println("clus="+clus[j]);
    }
    System.out.println("---------------------------");
    boolean us_cond;
    String nw_query="";
    us_cond = this.check_cond(clus,and_or,count);
    if(!us_cond){
       reject=true;
    }
    else{
      if(q_flag==0) nw_query = output;
      else if(q_flag==1) {
        nw_query=output.substring(0,output.indexOf(" or ")).trim();
      }
      else if(q_flag == 2){
        nw_query=output.substring(output.indexOf(" or ")+4).trim();
      }

      if(posi==-1) op_query = query;
      else op_query = output1+nw_query;
      jTextNew.setText(op_query);

    }//end else
   for(int i=0; i< sign.length; i++){
     att[i]="";
     sign[i]=0;
     val[i]="";
     tb[i]=""; }
    findatt(nw_query);
    System.out.println("******** new query *********");
    for(int i=0; i< count; i++){
System.out.println("att = "+ att[i] + "| sign "+ sign[i] + "| value "+ val[i] +"| tbl "+tb[i]);
    }
    int point=0;
    char che;
    ResultSet constset;
    System.out.println("---------------Inter-att-----------------");
    // while not reject
    try{
    while((!reject)&&(point < count)){
      if((checkupdate[point] != -1)&&(!val[point].equalsIgnoreCase(""))){
   che= val[point].charAt(0);

   if(Character.isDigit(che)||(!Character.isLetterOrDigit(che)))
    {
    String sql= "Select * from inter_const";  //where attl='"+ att[point]+"' and tattl='"+tb[point]+"' or attr'"+ att[point]+"' and tattr='"+tb[point]+"'";
    constset=dbconst.GetResultset(sql);
    constset.last();
    if(constset.getRow()!= 0){
      constset.first();
      while((constset.getRow()!= 0 ) &&(!reject)){
      String interatta=constset.getString(1).trim();
      String interattb=constset.getString(2).trim();
      String tablea=constset.getString(3).trim();
      String tableb=constset.getString(4).trim();
      int signinter=constset.getInt(5);
      System.out.println(interatta+":"+interattb+":"+tablea+":"+tableb+":"+signinter);
      if(att[point].equalsIgnoreCase(interatta)){
        // call fn interattribute
      reject=interatt(att[point],tb[point],sign[point],val[point],point,interatta,tablea,signinter,interattb,tableb);
      System.out.print("reject ? = "+reject);
      }
      else if(att[point].equalsIgnoreCase(interattb)){
        // call fn interattribute  b swap a
      if(signinter == 2 || signinter == 4){
        signinter = signinter + 1;
      }
      else if(signinter == 3 || signinter == 5){
        signinter = signinter - 1;
      }
      reject=interatt(att[point],tb[point],sign[point],val[point],point,interattb,tableb,signinter,interatta,tablea);
      System.out.print("reject ? = "+reject);
      }
      constset.next();
      } // end while when have value in db
    } // end if not empty in recordset

    } // end if not attribute
    } // end if not equal null
     point++;
    } // end while
    } // end catch
    catch(SQLException sqlException){
   JOptionPane.showMessageDialog(null,sqlException.getMessage() ,"Database Error",JOptionPane.ERROR_MESSAGE);
   this.init_var();
    }
    // looop
    // reject=interatt(attq,tbq,signq,val,pos,atta,tba,signa,attb,tbb);
   //  reject=checkpred2(attdb2.trim(),tbdb2.trim(),signdb2,valuedb2.trim(),point,predicate1);

    System.out.println("--------------end inter att------------------");
    // fn interatt(
   ///////////////////////////////////////////////////////
    try{
    System.out.println(" loop = count = "+ count);
    char c;
    point=0;
    while ((!reject)&&(point < count)){
//    System.out.print("point point point point point point : "+point);
    if((checkupdate[point] != -1)&&(!val[point].equalsIgnoreCase(""))){
    c= val[point].charAt(0);
    if(Character.isDigit(c)||(!Character.isLetterOrDigit(c)))
    {

    constset=dbconst.GetResultset("Select * from fd_const where att1='"+ att[point]+"' and tb1='"+tb[point]+"' ");
    constset.last();
      if(constset.getRow()!= 0){
      constset.first();
      while((constset.getRow()!= 0 ) &&(!reject)){
      String attdb1=constset.getString(1).trim();
      String tbdb1=constset.getString(2).trim();
      int signdb1=constset.getInt(3);
      String valuedb1=constset.getString(4).trim();
      String attdb2=constset.getString(5).trim();
      String tbdb2=constset.getString(6).trim();
      int signdb2=constset.getInt(7);
      String valuedb2=constset.getString(8).trim();

      int predicate1=0;
      System.out.println("when check predicate match");
      System.out.println("\n--  query -- Attribute + "+att[point]+"+ sign = "+sign[point]+" value = " +val[point]+" table = "+tb[point]);
      System.out.println("--database-- Attribute + "+attdb1+"+ sign = "+signdb1+" value = " +valuedb1+" table = "+tbdb1);
      predicate1 = this.checkpred1(signdb1,valuedb1,point);
      System.out.println("\nvalue predicate = "+ predicate1 +"\n-0 match \n-1 cover range\n-2 not use");

      //call fn predicate1 = int checkpred1(attdb1,tbdb1,signdb1,valuedb1,position)
      if((predicate1==1)||(predicate1==0)){
          // and if table B is in query if not don't check
          // if predicate1=1 mean not match but in range
          // if predicate1=0 mean match
        System.out.println("\n---------start check B when A match A->B -----------\n"+ reject +":");
        reject=checkpred2(attdb2.trim(),tbdb2.trim(),signdb2,valuedb2.trim(),point,predicate1);
        System.out.println("\n---------- end check B  A->B ------------\nreject = "+ reject +" -");
        constset.next();
       // reject=false;
        }
      else {    // predicate = 2  not comparevalue
        constset.next();   }
      }  //end while
    }  // end if when not have attribute match in constraint
    }  //if  att = att
    } // if check update != -1;
      point++;

    } //end end while condition

  if (reject) {
  JOptionPane.showMessageDialog(null,"User Condition Contrast With Integrity Rules");
  jTextNew.setText(jTextOld.getText());
  jTimeNew.setText("0");
  jrownew.setText("0");
  tableset1.setQuery(jTextOld.getText().trim());
  elapseTime = tableset1.gettime();
  jTimeOld.setText(elapseTime+"");
  jrowold.setText(tableset1.getRowCount()+"");
  }
  else{
  String tmp="";
  System.out.println("count = "+ count);
  for(int i=0; i< count; i++)
    if(checkupdate[i] != -1)
      tmp= tmp + " and "+att[i]+" | "+sign[i]+" | "+val[i]+" | "+tb[i];
//  for(int i=0; i< count; i++)
//  System.out.println("att = "+ att[i] + ":: sign "+ sign[i] + " value "+ val[i] +" tbl "+tb[i]+"checkupdate "+checkupdate[i]);
      tmp="";
      tmp=getnewq(count);
      tmp=output1+tmp;
      jTextNew.setText(tmp);

      try{
      tableset1.setQuery(jTextOld.getText().trim());
      elapseTime = tableset1.gettime();
      jTimeOld.setText(elapseTime+"");
      jrowold.setText(tableset1.getRowCount()+"");

       tableset2.setQuery(tmp);
       elapseTime = tableset2.gettime();
       jTimeNew.setText(elapseTime+"");
       jrownew.setText(tableset1.getRowCount()+"");
  }
  catch(SQLException sqlException){
    JOptionPane.showMessageDialog(null,sqlException.getMessage() ,"Database Error",JOptionPane.ERROR_MESSAGE);
    this.init_var();
  }
  }

  this.init_var();
    }// end try

    catch(SQLException sqlException ){
     System.out.print("error");
     JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
     JOptionPane.showMessageDialog(null,"Please insert new Query");
     this.init_var();
    }  //end catch
    }// end if have where
  else { // if no have where
    try{
     jTextNew.setText(query);
     tableset1.setQuery(query);
     elapseTime = tableset1.gettime();
     jTimeOld.setText(elapseTime+"");
     jrowold.setText(tableset1.getRowCount()+"");

      tableset2.setQuery(query);
      elapseTime = tableset2.gettime();
      jTimeNew.setText(elapseTime+"");
      jrownew.setText(tableset1.getRowCount()+"");
 }
 catch(SQLException sqlException){
   JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
   JOptionPane.showMessageDialog(null,"Please insert new Query");
   this.init_var();
 }
  }//  end if no have where
  } // end action tranform

  public String getnewq(int counter){
     String tmp="";
     String tsign="";
     String tval="";
     String label="";
     int n=0;
     for(int i=0; i<counter; i++){
       if(checkupdate[i] !=-1){

         if(ntb>1)
            while(n<ntb){
            if(tb[i].equalsIgnoreCase(ntbname[n])){ label=tmptbname[n]+"."; n=ntb+1;}
            else {label = ""; n++;}
         }
         att[i].trim();
         val[i].trim();

         switch (sign[i]){
          case 0: tmp=tmp + " and "+label+att[i]+" = "+ val[i];   break;
          case 1: tmp=tmp + " and "+label+att[i]+" != "+ val[i];   break;
          case 2: tmp=tmp + " and "+label+att[i]+" > "+ val[i];   break;
          case 3: tmp=tmp + " and "+label+att[i]+" < "+ val[i];   break;
          case 4: tmp=tmp + " and "+label+att[i]+" >= "+ val[i];   break;
          case 5: tmp=tmp + " and "+label+att[i]+" <= "+ val[i];   break;
          case 6: tmp=tmp + " and "+label+att[i]+" > "+ val[i].substring(0,val[i].indexOf("/"))+" and "
              +label+att[i]+" < "+val[i].substring(val[i].indexOf("/")+1,val[i].trim().length());   break;
          case 7:tmp=tmp + " and "+label+att[i]+" > "+ val[i].substring(0,val[i].indexOf("/"))+" and "
              +label+att[i]+" <= "+val[i].substring(val[i].indexOf("/")+1,val[i].trim().length());   break;
          case 8:tmp=tmp + " and "+label+att[i]+" between "+ val[i].substring(0,val[i].indexOf("/"))+" and "
              +val[i].substring(val[i].indexOf("/")+1,val[i].trim().length());   break;
          case 9:tmp=tmp + " and "+label+att[i]+" >= "+ val[i].substring(0,val[i].indexOf("/"))+" and "
              +label+att[i]+" < "+val[i].substring(val[i].indexOf("/")+1,val[i].trim().length());   break;
          case 10: tmp=tmp + " and "+label+att[i]+" in ("+ val[i] + ")";
         }  // end switch
         } // end if incase array of attribute doesn't cutoff
         n=0;
       } // end for
      tmp=tmp.substring(5);       //cut and
    return tmp;
  }
  public boolean checkpred2(String fdatt2,String fdtb2,int fdsign2,String fdvalue2,int position,int pred1){
     int i=0;
     int qsign;
     boolean intro = true;
     String qattr,qtb,qval;
     while(i<count){
       qsign = sign[i];
       qattr = att[i];
       qtb = tb[i];
       qval = val[i];
       char chev;
       if(!val[i].equals(""))
       chev= val[i].charAt(0);
        else chev='c';
      if(Character.isDigit(chev)||(!Character.isLetterOrDigit(chev)))
    {

       System.out.println("\n In fn predicate2  check value of rule and value of query");
       System.out.println("\nin query     : sign  "+sign[i]+" | att= "+att[i]+" | table = "+tb[i]+" | value = "+val[i]);
       System.out.println("\nin rule of fd: sign  "+fdsign2+" | att= "+fdatt2+" | table = "+fdtb2+" | value = "+fdvalue2);
       if(qattr.equalsIgnoreCase(fdatt2)&&(checkupdate[i]!=3)){//&&pred1 == 0 ){  // A match
         intro =false;
         switch(qsign){
           case 0 :System.out.println("case0");
             System.out.print(qattr+"  "+qtb+"  "+fdvalue2.trim()+"  "+qval+"  "+fdsign2+"  "+i);
           if(compeql(qattr,qtb,fdvalue2.trim(),qval,fdsign2,i))
             return true;
           break;   //'='
           case 1: System.out.println("case1");
             if(compnoteql(qattr,qtb,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break; //'!='
           case 2: System.out.println("case2");//
             if(compmore(fdatt2,fdtb2,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break;  //'>'
           case 3: System.out.println("case3");//
             if(compless(fdatt2,fdtb2,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break; //'<'
           case 4: System.out.println("case4");//
             if(compmoreeql(fdatt2,fdtb2,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break; //'>='
           case 5: System.out.println("case5");//
             if(complesseql(fdatt2,fdtb2,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break; //'<='
           case 8: System.out.println("case8");//
             if(compbetween(fdatt2,fdtb2,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break; //'between'
           case 10: System.out.println("case10 : in");
             if(compin(fdatt2,fdtb2,fdvalue2.trim(),qval,fdsign2,i))
               return true;
             break; //'in'

           default :
           }//end switch
           }
         }//end A match
         i++;  //not match --> move next
     }//end while
     if(intro && chk_indx(fdatt2,fdtb2)){
       count++;
       att[count-1] = fdatt2;
       sign[count-1] = fdsign2;
       tb[count-1] = fdtb2;
       val[count-1] = fdvalue2;
       checkupdate[i] = 1;  // index
     }//end intro
    return false;
   }//end function

   public void getcolindex(){
     try{
  ResultSet setindex,tmpset;
//sp_helpindex customer_tbl
  setindex=db.GetResultset("SELECT o.name,i.colid FROM sysobjects o ,sysindexkeys i WHERE o.xtype = 'u' and o.id=i.id and i.indid = 1 and o.name !='dtproperties'");
  setindex.last();
  numind=setindex.getRow();
   if(setindex.getRow()!= 0){
     setindex.first();
     int count=0;
      while(count < numind){
        indextb[count]= setindex.getString(1).trim();
        tmpcolind[count]=setindex.getInt(2);
        count++;
        setindex.next();
      }
   }
   for(int i=0;i < numind ;i++){
   String SQL2 ="SELECT * FROM "+ indextb[i] +" ";
   tmpset = db.GetResultset(SQL2);
   tmpset.first();
   ResultSetMetaData metaD=tmpset.getMetaData();
   indexcol[i] = metaD.getColumnName(tmpcolind[i]);
   }
}
catch(SQLException sqlException){
JOptionPane.showMessageDialog(null,sqlException.getMessage() ,"Database Error",JOptionPane.ERROR_MESSAGE);}

   }
   public boolean chk_indx(String att,String tb){
     int i=0;
//     boolean con=true;
     while(i < numind){
       if(tb.equalsIgnoreCase(indextb[i])&& att.equalsIgnoreCase(indexcol[i]))
         {
        return true;
       }
       i++;
     }
     return false;
   }
   public boolean compeql(String attr,String tbatt,String valdb,String valadd,int signn,int pos){
     switch (signn)
     {
       case 0:  {  System.out.print("Start case = compeql");            //'='
                   if(valdb.equals(valadd)) {
                     if(chk_indx(attr,tbatt))
                       checkupdate[pos]=0;
                     else {
                       att[pos] = "";
                       tb[pos] = "";
                       sign[pos] = 0;
                       val[pos] = "";
                       checkupdate[pos]=-1;
                 }
                     return false;  // not reject
                   }
                break;       // reject
                }
       case 1:  if(valdb.equalsIgnoreCase(valadd)) return true;
                else{  checkupdate[pos]=0;
                return false;   }  //'!='

       case 2:  if(Integer.parseInt(valadd) > Integer.parseInt(valdb))
                   {
                      checkupdate[pos]=0;
                      System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                      return false;
                   }
                break;   //'>'  // reject
       case 3:  if(Integer.parseInt(valadd) < Integer.parseInt(valdb))
                   {
                      checkupdate[pos]=0;
                      System.out.print( Integer.parseInt(valadd)+" < "+ Integer.parseInt(valdb));
                      return false;
                   }
               break;  //'<'
       case 4:  if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
                    {
                      checkupdate[pos]=0;
                      System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                      return false;
                    }
                break;  //'>='
       case 5:
                if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
                    {
                      checkupdate[pos]=0;
                      System.out.print( Integer.parseInt(valadd)+" < "+ Integer.parseInt(valdb));
                      return false;
                    }
                break; //'<='
       case 6:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
                   {
                         checkupdate[pos]=0;
                         return false;
                   }
                break;//'<' -- '<'
       case 7:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
                   {
                          checkupdate[pos]=0;
                          return false;
                   }
                //'<' -- '<='
       case 8:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
                   {
                          checkupdate[pos]=0;
                          return false;
                   }
                break; //'<=' -- '<='
       case 9:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
                   {
                              checkupdate[pos]=0;
                              return false;
                   }
                break; //'<=' -- '<'
       case 10: {
             int ind=0;
             int end=0;
             if(valdb.indexOf(",") == -1){
               if( valdb.equalsIgnoreCase(valadd))
                 checkupdate[pos]=0;    // else reject
                 return false; } // if equal not reject
                 else{
                   boolean con=true;
                   ind=0;
                   end=(valdb.indexOf(",",1)) ;
                   while(con){
                     String word= valdb.substring(ind,end);
                     System.out.print(word+" ");
                     if( word.equalsIgnoreCase(valadd))
                         { System.out.print(" ::true:: " + word);
                     checkupdate[pos]=0;
                     return false; }
                     if(end==valdb.length()){
                       System.out.print(" ::false:: " +word);
                       con= false;
                       att[pos] = "";
                       tb[pos] = "";
                       sign[pos] = 0;
                       val[pos] = "";
                       checkupdate[pos]=-1;
                     return true; }
                     ind=end+1;
                     if (valdb.indexOf(",",ind+1) != -1)
                       end=(valdb.indexOf(",",ind+1));
                     else
                       end=valdb.length();
                   }
                 }  // end else over one value
                 break; // in}
               }
       default: return false;  // not reject
     }
     return true;  // end switch and reject
   }


 public boolean compnoteql(String attr,String tbatt,String valdb,String valadd,int signn,int pos){
 switch (signn)
 {
   case 0: { System.out.print("start");            //'='
               if(!valdb.equals(valadd)){   //query : a>3 and b!=5 , const : a>3 -> b=3
                 if(chk_indx(attr,tbatt)){
                   sign[pos] = signn;
                   val[pos] = valdb;
                   checkupdate[pos]=2;      //query : a>3 and b=3
                 }
                 else {
                   att[pos] = "";
                   tb[pos] = "";
                   sign[pos] = 0;
                   val[pos] = "";
                   checkupdate[pos]=-1;     //query : a>3
                 }
                 return false;   //not reject
               }
           return true;  //reject
   }//end case '='
   case 1: {
             if(valdb.equals(valadd)){  //query : a>3 and b!=5 , const : a>3 -> b!=5
               if(chk_indx(attr,tbatt))
                 checkupdate[pos]=0;   //query : a>3 and b!=5
               else {
                 att[pos] = "";
                 tb[pos] = "";
                 sign[pos] = 0;
                 val[pos] = "";
                 checkupdate[pos]=-1;  //query : a>3
               }
             }
             checkupdate[pos]=0;   //query : a>3 and b!=5
             return false;  //not reject
           }//end case '!='
   case 2:{
         if(Integer.parseInt(valadd) > Integer.parseInt(valdb))   //query : a>3 and b!=5 , const : a>3 -> b>3
           {
              checkupdate[pos]=0;    //query : a>3 and b!=5
              System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
              return false;          //not reject
         }
           else{                    //query : a>3 and b!=5 , const : a>3 -> b>6
             if(chk_indx(attr,tbatt)) {
               sign[pos] = signn;
               val[pos] = valdb;
               checkupdate[pos]=2;  //query : a>3 and b>6
             }
             else {
                 att[pos] = "";
                 tb[pos] = "";
                 sign[pos] = 0;
                 val[pos] = "";
                 checkupdate[pos]=-1;  //query : a>3
               }
               return false;          //not reject
             }
        }//'>'
    case 3:{
            if(Integer.parseInt(valadd) < Integer.parseInt(valdb))
                //query : a>3 and b!=5 , const : a>3 -> b<9
                 {
                    checkupdate[pos]=0;    //query : a>3 and b!=5
                    System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                    return false;          //not reject
               }
            else{    //query : a>3 and b!=10 , const : a>3 -> b<6
                   if(chk_indx(attr,tbatt)){
                     sign[pos] = signn;
                     val[pos] = valdb;
                     checkupdate[pos]=2;  //query : a>3 and b<6
                   }
                     else {
                       att[pos] = "";
                       tb[pos] = "";
                       sign[pos] = 0;
                       val[pos] = "";
                       checkupdate[pos]=-1;  //query : a>3
                     }
                     return false;          //not reject
                   }
       } //'<'
      case 4: {
               if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
                 //query : a>3 and b!=5 , const : a>3 -> b>=3
                 {
                    checkupdate[pos]=0;    //query : a>3 and b!=5
                    System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                    return false;          //not reject
               }
                 else{
                   //query : a>3 and b!=5 , const : a>3 -> b>=6
                   if(chk_indx(attr,tbatt)){
                     sign[pos] = signn;
                     val[pos] = valdb;
                     checkupdate[pos]=2;    //query : a>3 and b>=6
                   }
                     else {
                       att[pos] = "";
                       tb[pos] = "";
                       sign[pos] = 0;
                       val[pos] = "";
                       checkupdate[pos]=-1;  //query : a>3
                     }
                    return false;          //not reject
                   }
      }//'>='

     case 5:{
               if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
              //query : a>3 and b!=5 , const : a>3 -> b<=9
               {
                 checkupdate[pos]=0;    //query : a>3 and b!=5
                 System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                 return false;          //not reject
               }
               else{
                 //query : a>3 and b!=10 , const : a>3 -> b<=6
                 if(chk_indx(attr,tbatt)){
                   sign[pos] = signn;
                   val[pos] = valdb;
                   checkupdate[pos]=2;  //query : a>3 and b<=6
                 }
                 else {
                   att[pos] = "";
                   tb[pos] = "";
                   sign[pos] = 0;
                   val[pos] = "";
                   checkupdate[pos]=-1;  //query : a>3
                 }
                 return false;          //not reject
               }
     }  //'<'
   case 6:{
              if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
                {   //query : a>3 and b!=5 , const : a>3 -> 3<b<10
                      checkupdate[pos]=0;//query : a>3 and b!=5
                      return false;          //not reject
              }else{        //query : a>3 and b!=5 , const : a>3 -> 1<b<4
                            //query : a>3 and b!=5 , const : a>3 -> 7<b<10
                  if(chk_indx(attr,tbatt)){
                    sign[pos] = 2;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;  //query : a>3 and b>1

                    att[count] = attr;
                    sign[count] = 3;
                    tb[count] = tbatt;
                    val[count] = valdb.substring(valdb.indexOf("/")+1);
                    checkupdate[count] = 3;  // reduct scan
                    count++;             //query : a>3 and b>1 and b<4
                  }
                  else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                  }
                  return false;          //not reject
              }
   } //'<' -- '<'
   case 7:{
              if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
                 {
                   //query : a>3 and b!=5 , const : a>3 -> 3<b<=10
                       checkupdate[pos]=0;//query : a>3 and b!=5
                       return false;          //not reject
                 }
               else{
                 //query : a>3 and b!=5 , const : a>3 -> 1<b<=4
                  if(chk_indx(attr,tbatt)){
                    sign[pos] = 2;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;  //query : a>3 and b>1

                    att[count] = attr;
                    sign[count] = 5;
                    tb[count] = tbatt;
                    val[count] = valdb.substring(valdb.indexOf("/")+1);
                    checkupdate[count] = 3;  // reduct scan
                    count++;             //query : a>3 and b>1 and b<=4
                  }
                  else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                  }
                  return false;          //not reject
               }
   } //'<' -- '<='
   case 8:{
              if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
                (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
                {   //query : a>3 and b!=5 , const : a>3 -> 3<=b<=10
                      checkupdate[pos]=0;//query : a>3 and b!=5
                      return false;          //not reject
              }else{        //query : a>3 and b!=5 , const : a>3 -> 1<=b<=4
                            //query : a>3 and b!=5 , const : a>3 -> 7<=b<=10
                  if(chk_indx(attr,tbatt)){
                    sign[pos] = 4;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;  //query : a>3 and b>=1

                    att[count] = attr;
                    sign[count] = 5;
                    tb[count] = tbatt;
                    val[count] = valdb.substring(valdb.indexOf("/")+1);
                    checkupdate[count] = 3;  // reduct scan
                    count++;             //query : a>3 and b>=1 and b<=4
                  }
                  else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                  }
                  return false;          //not reject
              }
    }//'<=' -- '<='
   case 9:{
              if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
                (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
                 {
                   //query : a>3 and b!=5 , const : a>3 -> 3<=b<10
                       checkupdate[pos]=0;//query : a>3 and b!=5
                       return false;          //not reject
                 }
               else{
                 //query : a>3 and b!=5 , const : a>3 -> 1<=b<3
                 //query : a>3 and b!=5 , const : a>3 -> 6<=b<10
                  if(chk_indx(attr,tbatt)){
                    sign[pos] = 4;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;  //query : a>3 and b>=1

                    att[count] = attr;
                    sign[count] = 3;
                    tb[count] = tbatt;
                    val[count] = valdb.substring(valdb.indexOf("/")+1);
                    checkupdate[count] = 3;  // reduct scan
                    count++;             //query : a>3 and b>=1 and b<3
                  }
                  else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                  }
                  return false;          //not reject
               }
   }    //'<=' -- '<'
 case 10: {
   int ind=0;
   int end=0;
   if(valdb.indexOf(",") == -1){
     if( valdb.equalsIgnoreCase(valadd))   // case != in  case in
       return true; } // if equal reject
       else{
         boolean con=true;
         ind=0;
         end=(valdb.indexOf(",",1)) ;
         while(con){
           String word= valdb.substring(ind,end);
           System.out.print(word+" ");
           if( word.equalsIgnoreCase(valadd))
               { System.out.print(" ::true:: " + word);
           return true; }  // reject
           if(end==valdb.length()){
             System.out.print(" ::false:: " +word);
             con= false;
             if(chk_indx(attr,tbatt)){
               sign[pos] = signn;
               val[pos] = valdb;
               checkupdate[pos]=2;
             }
             else{
               att[pos] = "";
               tb[pos] = "";
               sign[pos] = 0;
               val[pos] = "";
             checkupdate[pos]=-1;}
           return false; }
           ind=end+1;
           if (valdb.indexOf(",",ind+1) != -1)
             end=(valdb.indexOf(",",ind+1));
           else
             end=valdb.length();
         }
       }  // end else over one value
       break;  //reject
  }   //'in'
   default:  return false;          //not reject
  }//end switch
  return true;   //reject
}//end fn noteq

 public boolean compmore(String attdb,String tbdb,String valdb,String valadd,int signn,int pos){
   int i,j;
    switch (signn){
      case 0:  System.out.print("start");            //'='
                  if( Integer.parseInt(valdb) > Integer.parseInt(valadd)){
                    //query : a>3 and b>5 , const : a>3 -> b=7
                    if(chk_indx(attdb,tbdb)){
                      sign[pos] = signn;
                      val[pos] = valdb;
                      checkupdate[pos]=2;      //query : a>3 and b=7
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;     //query : a>3
                    }
                    return false;          //not reject
                  }
                  System.out.print( valdb+" + "+ valadd);
                  //query : a>3 and b>5 , const : a>3 -> b=3
                  break;  //reject
      case 1: {
                //query : a>3 and b>5 , const : a>3 -> b!=3
                  checkupdate[pos]=0;
                  return false;          //not reject

              }
      case 2:{
            if(Integer.parseInt(valadd) > Integer.parseInt(valdb))
              //query : a>3 and b>5 , const : a>3 -> b>3
              {
                 checkupdate[pos]=0;    //query : a>3 and b>5
                 System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                 return false;          //not reject
            }
              else{                    //query : a>3 and b>5 , const : a>3 -> b>6
                if(chk_indx(attdb,tbdb)) {
                  if(Integer.parseInt(valadd) < Integer.parseInt(valdb)){
                  sign[pos] = signn;
                  val[pos] = valdb;
                  checkupdate[pos]=2;  //query : a>3 and b>6
                  }
                  else //query : a>3 and b>5 , const : a>3 -> b>5
                    checkupdate[pos]=0;  //no change
                }
                else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                  }
                  return false;          //not reject
                }
      }  //'>'

      case 3:{
        if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
          //query : a>3 and b>5 , const : a>3 -> b<3
          return true;   //reject

        else{           //query : a>3 and b>5 , const : a>3 -> b<9
          att[count] = attdb;
          sign[count] = signn;
          tb[count] = tbdb;
          val[count] = valdb;
          checkupdate[count] = 3;  // reduct scan
          count++;             //query : a>3 and b>5 and b<9
          return false;          //not reject
        }
      }   //'<'

     case 4: {
           if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
             //query : a>3 and b>5 , const : a>3 -> b>=3
           {
             checkupdate[pos]=0;    //query : a>3 and b>5
             System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
             return false;          //not reject
           }
           else{                    //query : a>3 and b>5 , const : a>3 -> b>=6
             if(chk_indx(attdb,tbdb)){
               sign[pos] = signn;
               val[pos] = valdb;
               checkupdate[pos]=2;    //query : a>3 and b>=6
             }
             else {
               att[pos] = "";
               tb[pos] = "";
               sign[pos] = 0;
               val[pos] = "";
               checkupdate[pos]=-1;  //query : a>3
             }
             return false;          //not reject
           }
     }   //'>='
      case 5:{
        if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
        //query : a>3 and b>5 , const : a>3 -> b<=3
          return true;
        else{          //query : a>3 and b>5 , const : a>3 -> b<=9
          att[count] = attdb;
          sign[count] = signn;
          tb[count] = tbdb;
          val[count] = valdb;
          checkupdate[count] = 3;  // reduct scan
          count++;             //query : a>3 and b>5 and b<=9
          return false;          //not reject
        }
      }   //'<='

      case 6:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
            {   //query : a>3 and b>5 , const : a>3 -> 3<b<10 , a>3 -> 5<b<10
          att[count] = attdb;
          sign[count] = 3;
          tb[count] = tbdb;
          val[count] = valdb.substring(valdb.indexOf("/")+1);
          checkupdate[count] = 3;  // reduct scan
          count++;             //query : a>3 and b>5 and b<10
          return false;          //not reject
          }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
            //query : a>3 and b>5 , const : a>3 -> 7<b<10
            if(chk_indx(attdb,tbdb)){
              val[pos] = valdb.substring(0,valdb.indexOf("/"));
              checkupdate[pos]=2;  //query : a>3 and b>7

              att[count] = attdb;
              sign[count] = 3;
              tb[count] = tbdb;
              val[count] = valdb.substring(valdb.indexOf("/")+1);
              checkupdate[count] = 3;  // reduct scan
              count++;             //query : a>3 and b>7 and b<10
            }
            else {
              att[pos] = "";
              tb[pos] = "";
              sign[pos] = 0;
              val[pos] = "";
              checkupdate[pos]=-1;  //query : a>3
            }
            return false;          //not reject
          }
          else return true;    //query : a>3 and b>5 , const : a>3 -> 1<b<4
      }//'<' -- '<'

      case 7:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
         (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
         {   //query : a>3 and b>5 , const : a>3 -> 3<b<=10 , a>3 -> 5<b<=10,
            att[count] = attdb;
            sign[count] = 5;
            tb[count] = tbdb;
            val[count] = valdb.substring(valdb.indexOf("/")+1);
            checkupdate[count] = 3;  // reduct scan
            count++;             //query : a>3 and b>5 and b<=10
            return false;          //not reject
            }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd)) &&
                     (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
                     //query : a>3 and b>5 , const : a>3 -> 7<b<=10
                     if(chk_indx(attdb,tbdb)){
                       val[pos] = valdb.substring(0,valdb.indexOf("/"));
                       checkupdate[pos]=2;  //query : a>3 and b>7

                       att[count] = attdb;
                       sign[count] = 5;
                       tb[count] = tbdb;
                       val[count] = valdb.substring(valdb.indexOf("/")+1);
                       checkupdate[count] = 3;  // reduct scan
                       count++;             //query : a>3 and b>7 and b<=10
                      }
                      else {
                          att[pos] = "";
                          tb[pos] = "";
                          sign[pos] = 0;
                          val[pos] = "";
                          checkupdate[pos]=-1;  //query : a>3
                        }
                      return false;          //not reject
            }
            else return true;    //query : a>3 and b>5 , const : a>3 -> 1<b<4
      }//'<' -- '<='

      case 8:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
          {   //query : a>3 and b>5 , const : a>3 -> 3<=b<=10 , a>3 -> 5<=b<=10,
          att[count] = attdb;
          sign[count] = 5;
          tb[count] = tbdb;
          val[count] = valdb.substring(valdb.indexOf("/")+1);
          checkupdate[count] = 3;  // reduct scan
          count++;             //query : a>3 and b>5 and b<=10
          return false;          //not reject
          }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
            //query : a>3 and b>5 , const : a>3 -> 7<=b<=10
                if(chk_indx(attdb,tbdb)){
                  sign[pos] = 4;
                  val[pos] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[pos]=2;  //query : a>3 and b>=7

                  att[count] = attdb;
                  sign[count] = 5;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(valdb.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b>=7 and b<=10
                }
                  else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                        }
            return false;          //not reject
          }
          else return true;    //query : a>3 and b>5 , const : a>3 -> 1<b<4
      }//'<=' -- '<='

    case 9:{
      if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
         (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
        {   //query : a>3 and b>5 , const : a>3 -> 3<=b<10 , a>3 -> 5<=b<10,
        att[count] = attdb;
        sign[count] = 3;
        tb[count] = tbdb;
        val[count] = valdb.substring(valdb.indexOf("/")+1);
        checkupdate[count] = 3;  // reduct scan
        count++;             //query : a>3 and b>5 and b<10
        return false;          //not reject
        }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd)) &&
                 (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
                //query : a>3 and b>5 , const : a>3 -> 7<=b<10
                if(chk_indx(attdb,tbdb)){
                  sign[pos] = 4;
                  val[pos] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[pos]=2;  //query : a>3 and b>=7

                  att[count] = attdb;
                  sign[count] = 3;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(valdb.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b>=7 and b<10
                }
                else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                        }
          return false;          //not reject
        }
        else return true;    //query : a>3 and b>5 , const : a>3 -> 1<b<4
    }   //'<=' -- '<'

  case 10: {
     int ind=0;
     int end=0;
     if(!valdb.substring(valdb.indexOf("",0),1).equalsIgnoreCase("'")){
     if(valdb.indexOf(",") == -1){
       if( Integer.parseInt(valdb) > Integer.parseInt(valadd))
         checkupdate[pos]=0;    // else reject
         return false; } // if equal not reject
    else{
        boolean con=true,covernotall =true,coverall=true;
        ind=0;
        end=(valdb.indexOf(",",1)) ;
        while(con){
             String word= valdb.substring(ind,end);
             System.out.print(word+" ");
             if( Integer.parseInt(valdb) > Integer.parseInt(valadd) )
                 { System.out.print("valuein in db > query =" + word);
                   covernotall= false;  }
             else{
                   System.out.print("valuein in db <= query =" + word);
                   coverall= false;     }
             if(end==valdb.length()){
               System.out.print("end");
               con= false;  }
             ind=end+1;
             if (valdb.indexOf(",",ind+1) != -1)
               end=(valdb.indexOf(",",ind+1));
             else
               end=valdb.length();
           } // end while
           if(covernotall) return true; // for all value in db not > attval then reject
           if(coverall){
              if(!chk_indx(attdb,tbdb)){
                att[pos] = "";
                tb[pos] = "";
                sign[pos] = 0;
                val[pos] = "";
                checkupdate[pos]=-1;
               }
              return false;
           }else return false;    // for have some value in case in > attval
         }  // end else
         }  // end check data in db is int
       }  // end case 10
      default:  return false;          //not reject
     }//end switch
    return true;  //break; (reject)
 }//end fn more

 public boolean compless(String attdb,String tbdb,String valdb,String valadd,int signn,int pos){
   int i,j;
    switch (signn){
      case 0:  System.out.print("start");            //'='
                  if( Integer.parseInt(valdb) < Integer.parseInt(valadd)){
                    //query : a>3 and b<5 , const : a>3 -> b=3
                    if(chk_indx(attdb,tbdb)){
                      sign[pos] = signn;
                      val[pos] = valdb;
                      checkupdate[pos]=2;      //query : a>3 and b=3
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;     //query : a>3
                    }
                    return false;          //not reject
                  }
                  System.out.print( valdb+" + "+ valadd);
                  break;  //return true
      case 1: {
                //query : a>3 and b<5 , const : a>3 -> b!=3
                  checkupdate[pos]=0;
                  return false;          //not reject

              }
      case 2:{
            if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
              //query : a>3 and b<5 , const : a>3 -> b>5 , a>3 -> b>7
              return true;
              else{
              //query : a>3 and b<5 , const : a>3 -> b>3
                att[count] = attdb;
                sign[count] = signn;
                tb[count] = tbdb;
                val[count] = valdb;
                checkupdate[count] = 3;  // reduct scan
                count++;             //query : a>3 and b<5 and b>3
               return false;          //not reject
                }
      }  //'>'

      case 3:{
        if(Integer.parseInt(valadd) < Integer.parseInt(valdb))
          //query : a>3 and b<5 , const : a>3 -> b<7
        {
          checkupdate[pos]=0;    //query : a>3 and b<5
          System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
          return false;          //not reject
        }
        else{       //query : a>3 and b<5 , const : a>3 -> b<3 , a>3 -> b<5
          if(chk_indx(attdb,tbdb)){
            if(Integer.parseInt(valadd) > Integer.parseInt(valdb)){
            sign[pos] = signn;
            val[pos] = valdb;
            checkupdate[pos]=2;    //query : a>3 and b<3
            }
            else    //query : a>3 and b<5 , const : a>3 -> b<5
            checkupdate[pos]=0;  //no change
          }
          else {
            att[pos] = "";
            tb[pos] = "";
            sign[pos] = 0;
            val[pos] = "";
            checkupdate[pos]=-1;  //query : a>3
          }
          return false;          //not reject
        }
      }   //'<'

      case 4: {
        if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
         //query : a>3 and b<5 , const : a>3 -> b>=5 , a>3 -> b>=7
          return true;
        else{
          //query : a>3 and b<5 , const : a>3 -> b>=3
          att[count] = attdb;
          sign[count] = signn;
          tb[count] = tbdb;
          val[count] = valdb;
          checkupdate[count] = 3;  // reduct scan
          count++;             //query : a>3 and b<5 and b>=3
          return false;          //not reject
        }
      }   //'>='

      case 5:{
        if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
          //query : a>3 and b<5 , const : a>3 -> b<=7 , a>3 -> b<=5
        {
          checkupdate[pos]=0;    //query : a>3 and b<5
          System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
          return false;          //not reject
        }
        else{     //query : a>3 and b<5 , const : a>3 -> b<=3
          if(chk_indx(attdb,tbdb)){
            sign[pos] = signn;
            val[pos] = valdb;
            checkupdate[pos]=2;    //query : a>3 and b<=3
          }
          else {
            att[pos] = "";
            tb[pos] = "";
            sign[pos] = 0;
            val[pos] = "";
            checkupdate[pos]=-1;  //query : a>3
          }
          return false;          //not reject
        }
      }   //'<='

      case 6:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
          (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
          {   //query : a>3 and b<5 , const : a>3 -> 3<b<10
             att[count] = attdb;
             sign[count] = 2;
             tb[count] = tbdb;
             val[count] = valdb.substring(0,valdb.indexOf("/"));
             checkupdate[count] = 3;  // reduct scan
             count++;             //query : a>3 and b<5 and b>3
             return false;          //not reject
             }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                      (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))){
                      //query : a>3 and b<5 , const : a>3 -> 1<b<4
               if(chk_indx(attdb,tbdb)){

                 sign[pos] = 2;
                 val[pos] = valdb.substring(0,valdb.indexOf("/"));
                 checkupdate[pos]=2;  //query : a>3 and b>1

                 att[count] = attdb;
                 sign[count] = 3;
                 tb[count] = tbdb;
                 val[count] = valdb.substring(valdb.indexOf("/")+1);
                 checkupdate[count] = 3;  // reduct scan
                 count++;             //query : a>3 and b>1 and b<4
               }
               else {
                 att[pos] = "";
                 tb[pos] = "";
                 sign[pos] = 0;
                 val[pos] = "";
                 checkupdate[pos]=-1;  //query : a>3
               }
              return false;          //not reject
             }
             else return true;    //query : a>3 and b<5 , const : a>3 -> 5<b<10
      } //'<' -- '<'

         case 7:{
             if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
               (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
               {   //query : a>3 and b<5 , const : a>3 -> 3<b<=10
                  att[count] = attdb;
                  sign[count] = 2;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b<5 and b>3
                  return false;          //not reject
                  }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))){
                           //query : a>3 and b<5 , const : a>3 -> 1<b<=4
                    if(chk_indx(attdb,tbdb)){

                      sign[pos] = 2;
                      val[pos] = valdb.substring(0,valdb.indexOf("/"));
                      checkupdate[pos]=2;  //query : a>3 and b>1

                      att[count] = attdb;
                      sign[count] = 5;
                      tb[count] = tbdb;
                      val[count] = valdb.substring(valdb.indexOf("/")+1);
                      checkupdate[count] = 3;  // reduct scan
                      count++;        //query : a>3 and b>1 and b<=4
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;  //query : a>3
                    }
                    return false;          //not reject
                  }
                  else return true;    //query : a>3 and b<5 , const : a>3 -> 5<b<=10
         } //'<' -- '<='

      case 8: if(checkupdate[pos]!=3)
      {
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
               (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd))
               &&(checkupdate[pos]!=3))
               {   //query : a>3 and b<5 , const : a>3 -> 3<=b<=10
                  att[count] = attdb;
                  sign[count] = 4;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b<5 and b>=3
                  return false;          //not reject
                  }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))){
                           //query : a>3 and b<5 , const : a>3 -> 1<=b<=4
                    if(chk_indx(attdb,tbdb)){
                      sign[pos] = 4;
                      val[pos] = valdb.substring(0,valdb.indexOf("/"));
                      checkupdate[pos]=2;  //query : a>3 and b>=1

                      att[count] = attdb;
                      sign[count] = 5;
                      tb[count] = tbdb;
                      val[count] = valdb.substring(valdb.indexOf("/")+1);
                      checkupdate[count] = 3;  // reduct scan
                      count++;        //query : a>3 and b>=1 and b<=4
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;  //query : a>3
                    }
                    return false;          //not reject
                  }
                  else return true;    //query : a>3 and b<5 , const : a>3 -> 5<=b<=10
      }//'<=' -- '<='
      else return false;
      case 9:{
               if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                 (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
                 {   //query : a>3 and b<5 , const : a>3 -> 3<=b<10
                    att[count] = attdb;
                    sign[count] = 4;
                    tb[count] = tbdb;
                    val[count] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[count] = 3;  // reduct scan
                    count++;             //query : a>3 and b<5 and b>=3
                    return false;          //not reject
                    }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                             (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))){
                             //query : a>3 and b<5 , const : a>3 -> 1<=b<4
                      if(chk_indx(attdb,tbdb)){

                        sign[pos] = 4;
                        val[pos] = valdb.substring(0,valdb.indexOf("/"));
                        checkupdate[pos]=2;  //query : a>3 and b>=1

                        att[count] = attdb;
                        sign[count] = 3;
                        tb[count] = tbdb;
                        val[count] = valdb.substring(valdb.indexOf("/")+1);
                        checkupdate[count] = 3;  // reduct scan
                        count++;             //query : a>3 and b>=1 and b<4

                      }
                        else {
                          att[pos] = "";
                          tb[pos] = "";
                          sign[pos] = 0;
                          val[pos] = "";
                          checkupdate[pos]=-1;  //query : a>3
                        }

                        return false;          //not reject
                    }
                    else return true;    //query : a>3 and b<5 , const : a>3 -> 5<=b<10
      } //'<=' -- '<'

    case 10: {
            int ind=0;
            int end=0;
            if(!valdb.substring(valdb.indexOf("",0),1).equalsIgnoreCase("'")){
            if(valdb.indexOf(",") == -1){
              if( Integer.parseInt(valdb)< Integer.parseInt(valadd))
                checkupdate[pos]=0;    // else reject
                return false; } // if equal not reject
           else{
               boolean con=true,covernotall =true,coverall=true;
               ind=0;
               end=(valdb.indexOf(",",1)) ;
               while(con){
                    String word= valdb.substring(ind,end);
                    System.out.print(word+" ");
                    if( Integer.parseInt(valdb) < Integer.parseInt(valadd) )
                        { System.out.print("valuein in db < query =" + word);
                          covernotall= false;  }
                    else{
                          System.out.print("valuein in db >= query =" + word);
                          coverall= false;     }
                    if(end==valdb.length()){
                      System.out.print("end");
                      con= false;  }
                    ind=end+1;
                    if (valdb.indexOf(",",ind+1) != -1)
                      end=(valdb.indexOf(",",ind+1));
                    else
                      end=valdb.length();
                  } // end while
                  if(covernotall) return true; // for all value in db not >= attval then reject
                  if(coverall){
                     if(!chk_indx(attdb,tbdb)){
                       att[pos] = "";
                       tb[pos] = "";
                       sign[pos] = 0;
                       val[pos] = "";
                       checkupdate[pos]=-1;
                      }
                     return false;
                  }else return false;    // for have some value in case in >= attval
                }  // end else
                }  // end check data in db is int
       }  // end case 10
      default:  return false;          //not reject
     }
    return true;
 }
 public boolean compmoreeql(String attdb,String tbdb,String valdb,String valadd,int signn,int pos){
   int i,j;
    switch (signn){
      case 0:  System.out.print("start");            //'='
                  if( Integer.parseInt(valdb) >= Integer.parseInt(valadd)){
                    //query : a>3 and b>=5 , const : a>3 -> b=7
                    if(chk_indx(attdb,tbdb)){
                      sign[pos] = signn;
                      val[pos] = valdb;
                      checkupdate[pos]=2;      //query : a>3 and b=7
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;     //query : a>3
                    }
                    return false;          //not reject
                  }
                  System.out.print( valdb+" + "+ valadd);
                  break;
      case 1: {
                //query : a>3 and b>=5 , const : a>3 -> b!=3
                  checkupdate[pos]=0;
                  return false;          //not reject

              }
      case 2:{
            if(Integer.parseInt(valadd) > Integer.parseInt(valdb))
              //query : a>3 and b>=5 , const : a>3 -> b>3
              {
                 checkupdate[pos]=0;    //query : a>3 and b>=5
                 System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                 return false;          //not reject
            }
              else{                    //query : a>3 and b>=5 , const : a>3 -> b>6
                if(chk_indx(attdb,tbdb)) {
                  sign[pos] = signn;
                  val[pos] = valdb;
                  checkupdate[pos]=2;  //query : a>3 and b>6
                }
                else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                  }
                  return false;          //not reject
                }
      }   //'>'

      case 3:{
                if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
                     //query : a>3 and b>=5 , const : a>3 -> b<3
                  return true;
                   else{
                     //query : a>3 and b>=5 , const : a>3 -> b<9
                      att[count] = attdb;
                      sign[count] = signn;
                      tb[count] = tbdb;
                      val[count] = valdb;
                      checkupdate[count] = 3;  // reduct scan
                      count++;             //query : a>3 and b>=5 and b<9
                      return false;          //not reject
                      }
      }   //'<'

            case 4: {
                  if(Integer.parseInt(valadd) > Integer.parseInt(valdb))
                    //query : a>3 and b>=5 , const : a>3 -> b>=3
                    {
                       checkupdate[pos]=0;    //query : a>3 and b>=5
                       System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                       return false;          //not reject
                  }
                    else{
                      //query : a>3 and b>=5 , const : a>3 -> b>=6
                      if(chk_indx(attdb,tbdb)){
                        if(Integer.parseInt(valadd) < Integer.parseInt(valdb)){
                        sign[pos] = signn;
                        val[pos] = valdb;
                        checkupdate[pos]=2;    //query : a>3 and b>=6
                        }
                        else
                          //query : a>3 and b>=5 , const : a>3 -> b>=5
                          checkupdate[pos]=0;  //no change
                      }
                        else {
                          att[pos] = "";
                          tb[pos] = "";
                          sign[pos] = 0;
                          val[pos] = "";
                          checkupdate[pos]=-1;  //query : a>3
                        }
                        return false;          //not reject
                      }
            }   //'>='

     case 5:{
                   if(Integer.parseInt(valadd) > Integer.parseInt(valdb))
                      //query : a>3 and b>=5 , const : a>3 -> b<=3
                     return true;
                    else{
                      //query : a>3 and b>=5 , const : a>3 -> b<=9
                      if(Integer.parseInt(valadd) != Integer.parseInt(valdb)){
                      att[count] = attdb;
                      sign[count] = signn;
                      tb[count] = tbdb;
                      val[count] = valdb;
                      checkupdate[count] = 3;  // reduct scan
                      count++;             //query : a>3 and b>5 and b<=9
                      }
                      else {
                        //query : a>3 and b>=5 , const : a>3 -> b<=5
                        sign[pos] = 0;  // '='
                        val[pos] = valdb;
                        checkupdate[pos]=2;    //query : a>3 and b=5
                      }
                      return false;          //not reject
                    }
     }  //'<='

    case 6:{
                if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
                   {   //query : a>3 and b>=5 , const : a>3 -> 3<b<10 , a>3 -> 5<b<10,
                      att[count] = attdb;
                      sign[count] = 3;
                      tb[count] = tbdb;
                      val[count] = valdb.substring(valdb.indexOf("/")+1);
                      checkupdate[count] = 3;  // reduct scan
                      count++;             //query : a>3 and b>=5 and b<10
                      return false;          //not reject
                      }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd)) &&
                               (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
                               //query : a>3 and b>=5 , const : a>3 -> 7<b<10
                               if(chk_indx(attdb,tbdb)){
                                 sign[pos] = 2;
                                 val[pos] = valdb.substring(0,valdb.indexOf("/"));
                                 checkupdate[pos]=2;  //query : a>3 and b>7

                                 att[count] = attdb;
                                 sign[count] = 3;
                                 tb[count] = tbdb;
                                 val[count] = valdb.substring(valdb.indexOf("/")+1);
                                 checkupdate[count] = 3;  // reduct scan
                                 count++;             //query : a>3 and b>7 and b<10
                               }
                               else {
                                 att[pos] = "";
                                 tb[pos] = "";
                                 sign[pos] = 0;
                                 val[pos] = "";
                                 checkupdate[pos]=-1;  //query : a>3
                               }
                                return false;          //not reject
                      }
                      else return true;    //query : a>3 and b>5 , const : a>3 -> 1<b<4
    }//'<' -- '<'

    case 7:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
         (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
         {   //query : a>3 and b>=5 , const : a>3 -> 3<b<=10
            att[count] = attdb;
            sign[count] = 5;
            tb[count] = tbdb;
            val[count] = valdb.substring(valdb.indexOf("/")+1);
            checkupdate[count] = 3;  // reduct scan
            count++;             //query : a>3 and b>=5 and b<=10
            return false;          //not reject
            }
            else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd)) &&
                     (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
                     //query : a>3 and b>=5 , const : a>3 -> 7<b<=10
                     if(chk_indx(attdb,tbdb)){
                       sign[pos] = 2;
                       val[pos] = valdb.substring(0,valdb.indexOf("/"));
                       checkupdate[pos]=2;  //query : a>3 and b>7

                       att[count] = attdb;
                       sign[count] = 5;
                       tb[count] = tbdb;
                       val[count] = valdb.substring(valdb.indexOf("/")+1);
                       checkupdate[count] = 3;  // reduct scan
                       count++;             //query : a>3 and b>7 and b<=10
                      }
                      else {
                          att[pos] = "";
                          tb[pos] = "";
                          sign[pos] = 0;
                          val[pos] = "";
                          checkupdate[pos]=-1;  //query : a>3
                        }
                      return false;          //not reject
            }
            else if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))
                 //query : a>3 and b>=11 , const : a>3 -> 7<b<=10
                 return true;
                 else {
                   //query : a>3 and b>=10 , const : a>3 -> 7<b<=10
                   sign[pos] = 0;
                   val[pos] = valdb.substring(valdb.indexOf("/")+1);
                   checkupdate[pos]=2;    //query : a>3 and b=10
                   return false;          //not reject
                 }

    }//'<' -- '<='

   case 8:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
            {   //query : a>3 and b>=5 , const : a>3 -> 3<=b<=10 , a>3 -> 5<=b<=10,
             System.out.println("count in casse 8 = "+count);
             att[count] = attdb;
              sign[count] = 5;
              tb[count] = tbdb;
              val[count] = valdb.substring(valdb.indexOf("/")+1);
              checkupdate[count] = 3;  // reduct scan
              count++;             //query : a>3 and b>5 and b<=10
              return false;          //not reject
          }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd)) &&
                   (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
                //query : a>3 and b>=5 , const : a>3 -> 7<=b<=10
                if(chk_indx(attdb,tbdb)){
                  sign[pos] = 4;
                  val[pos] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[pos]=2;  //query : a>3 and b>=7

                  att[count] = attdb;
                  sign[count] = 5;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(valdb.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b>=7 and b<=10
                }
                  else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                    }
                return false;          //not reject
          }
          else if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))
                 //query : a>3 and b>=11 , const : a>3 -> 7<=b<=10
                 return true;
                 else {
                   //query : a>3 and b>=10 , const : a>3 -> 7<=b<=10
                   sign[pos] = 0;
                   val[pos] = valdb.substring(valdb.indexOf("/")+1);
                   checkupdate[pos]=2;    //query : a>3 and b=10
                   return false;          //not reject
                 }
   }  //'<=' -- '<='

  case 9:{
      if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
         (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
        {   //query : a>3 and b>=5 , const : a>3 -> 3<=b<10 , a>3 -> 5<=b<10,
        att[count] = attdb;
        sign[count] = 3;
        tb[count] = tbdb;
        val[count] = valdb.substring(valdb.indexOf("/")+1);
        checkupdate[count] = 3;  // reduct scan
        count++;             //query : a>3 and b>5 and b<10
        return false;          //not reject
        }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd)) &&
                 (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))){
                //query : a>3 and b>=5 , const : a>3 -> 7<=b<10
                if(chk_indx(attdb,tbdb)){
                  sign[pos] = 4;
                  val[pos] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[pos]=2;  //query : a>3 and b>=7

                  att[count] = attdb;
                  sign[count] = 3;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(valdb.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b>=7 and b<10
                }
                else {
                    att[pos] = "";
                    tb[pos] = "";
                    sign[pos] = 0;
                    val[pos] = "";
                    checkupdate[pos]=-1;  //query : a>3
                        }
          return false;          //not reject
        }
        else return true;    //query : a>3 and b>5 , const : a>3 -> 1<b<4
  }  //'<=' -- '<'

  case 10: {
    int ind=0;
    int end=0;
    if(!valdb.substring(valdb.indexOf("",0),1).equalsIgnoreCase("'")){
      if(valdb.indexOf(",") == -1){
        if( Integer.parseInt(valdb) >= Integer.parseInt(valadd))
          checkupdate[pos]=0;    // else reject
        return false; } // if equal not reject
        else{
          boolean con=true,covernotall =true,coverall=true;
          ind=0;
          end=(valdb.indexOf(",",1)) ;
          while(con){
            String word= valdb.substring(ind,end);
            System.out.print(word+" ");
            if( Integer.parseInt(valdb) >= Integer.parseInt(valadd) )
                { System.out.print("valuein in db >= query =" + word);
            covernotall= false;  }
            else{
              System.out.print("valuein in db < query =" + word);
            coverall= false;     }
            if(end==valdb.length()){
              System.out.print("end");
            con= false;  }
            ind=end+1;
            if (valdb.indexOf(",",ind+1) != -1)
              end=(valdb.indexOf(",",ind+1));
            else
              end=valdb.length();
          } // end while
          if(covernotall) return true; // for all value in db not >= attval then reject
          if(coverall){
            if(!chk_indx(attdb,tbdb)){
              att[pos] = "";
              tb[pos] = "";
              sign[pos] = 0;
              val[pos] = "";
              checkupdate[pos]=-1;
            }
            return false;
          }else return false;    // for have some value in case in >= attval
        }  // end else
  }  // end check data in db is int
    }  // end case 10
      default:  return false;          //not reject
     }
    return true;
 }
 public boolean complesseql(String attdb,String tbdb,String valdb,String valadd,int signn,int pos){
   int i,j;
    switch (signn){
      case 0:  System.out.print("start");            //'='
                  if( Integer.parseInt(valdb) <= Integer.parseInt(valadd)){
                    //query : a>3 and b<=5 , const : a>3 -> b=3
                    if(chk_indx(attdb,tbdb)){
                      sign[pos] = signn;
                      val[pos] = valdb;
                      checkupdate[pos]=2;      //query : a>3 and b=3
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;     //query : a>3
                    }
                    return false;          //not reject
                  }
                  System.out.print( valdb+" + "+ valadd);
                  break;
      case 1: {
                //query : a>3 and b<=5 , const : a>3 -> b!=3
                  checkupdate[pos]=0;
                  return false;          //not reject

              }
      case 2:{
            if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
              //query : a>3 and b<=5 , const : a>3 -> b>5 , a>3 -> b>7
              return true;
              else{
              //query : a>3 and b<=5 , const : a>3 -> b>3
                att[count] = attdb;
                sign[count] = signn;
                tb[count] = tbdb;
                val[count] = valdb;
                checkupdate[count] = 3;  // reduct scan
                count++;             //query : a>3 and b<=5 and b>3
                return false;          //not reject
                }
      }  //'>'

      case 3:{
        if(Integer.parseInt(valadd) < Integer.parseInt(valdb))
          //query : a>3 and b<=5 , const : a>3 -> b<7
        {
          checkupdate[pos]=0;    //query : a>3 and b<=5
          System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
          return false;          //not reject
        }
        else{        //query : a>3 and b<=5 , const : a>3 -> b<3 , a>3 -> b<5
          if(chk_indx(attdb,tbdb)){
            sign[pos] = signn;
            val[pos] = valdb;
            checkupdate[pos]=2;    //query : a>3 and b<3
          }
          else {
            att[pos] = "";
            tb[pos] = "";
            sign[pos] = 0;
            val[pos] = "";
            checkupdate[pos]=-1;  //query : a>3
          }
          return false;          //not reject
        }
      }   //'<'

      case 4: {
        if(Integer.parseInt(valadd) < Integer.parseInt(valdb))
              //query : a>3 and b<=5 , const : a>3 -> b>=5 , a>3 -> b>=7
          return true;
        else{
          //query : a>3 and b<=5 , const : a>3 -> b>=3
          if(Integer.parseInt(valadd) > Integer.parseInt(valdb)){
          att[count] = attdb;
          sign[count] = signn;
          tb[count] = tbdb;
          val[count] = valdb;
          checkupdate[count] = 3;  // reduct scan
          count++;             //query : a>3 and b<5 and b>=3
          }
          else{
            //query : a>3 and b<=5 , const : a>3 -> b>=5
            sign[pos] = 0;  // '='
            val[pos] = valdb;
            checkupdate[pos]=2;  //query : a>3 and b=5
          }
          return false;          //not reject
        }
      }   //'>='
      case 5:{
        if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
          //query : a>3 and b<=5 , const : a>3 -> b<=7
        {
          checkupdate[pos]=0;    //query : a>3 and b<=5
          System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
          return false;          //not reject
        }
        else{
          //query : a>3 and b<=5 , const : a>3 -> b<=3
          if(chk_indx(attdb,tbdb)){
            sign[pos] = signn;
            val[pos] = valdb;
            checkupdate[pos]=2;    //query : a>3 and b<=3
          }
          else {
            att[pos] = "";
            tb[pos] = "";
            sign[pos] = 0;
            val[pos] = "";
            checkupdate[pos]=-1;  //query : a>3
          }
          return false;          //not reject
        }
      }   //'<='

      case 6:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
          (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
          {   //query : a>3 and b<=5 , const : a>3 -> 3<b<10
             att[count] = attdb;
             sign[count] = 2;
             tb[count] = tbdb;
             val[count] = valdb.substring(0,valdb.indexOf("/"));
             checkupdate[count] = 3;  // reduct scan
             count++;             //query : a>3 and b<=5 and b>3
             return false;          //not reject
             }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                      (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) <= Integer.parseInt(valadd))){
                      //query : a>3 and b<=5 , const : a>3 -> 1<b<4
               if(chk_indx(attdb,tbdb)){
                 sign[pos] = 2;
                 val[pos] = valdb.substring(0,valdb.indexOf("/"));
                 checkupdate[pos]=2;  //query : a>3 and b>1

                 att[count] = attdb;
                 sign[count] = 3;
                 tb[count] = tbdb;
                 val[count] = valdb.substring(valdb.indexOf("/")+1);
                 checkupdate[count] = 3;  // reduct scan
                 count++;             //query : a>3 and b>1 and b<4
               }
               else {
                 att[pos] = "";
                 tb[pos] = "";
                 sign[pos] = 0;
                 val[pos] = "";
                 checkupdate[pos]=-1;  //query : a>3
               }
               return false;          //not reject
             }
             else return true;    //query : a>3 and b<=5 , const : a>3 -> 5<b<10
      }  //'<' -- '<'

       case 7:{
             if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
               (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
               {   //query : a>3 and b<=5 , const : a>3 -> 3<b<=10
                  att[count] = attdb;
                  sign[count] = 2;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b<=5 and b>3
                  return false;          //not reject
                  }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))){
                           //query : a>3 and b<=5 , const : a>3 -> 1<b<=4
                    if(chk_indx(attdb,tbdb)){

                      sign[pos] = 2;
                      val[pos] = valdb.substring(0,valdb.indexOf("/"));
                      checkupdate[pos]=2;  //query : a>3 and b>1

                      att[count] = attdb;
                      sign[count] = 5;
                      tb[count] = tbdb;
                      val[count] = valdb.substring(valdb.indexOf("/")+1);
                      checkupdate[count] = 3;  // reduct scan
                      count++;        //query : a>3 and b>1 and b<=4
                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;  //query : a>3
                    }
                    return false;          //not reject
                  }
                  else return true;    //query : a>3 and b<=5 , const : a>3 -> 5<b<=10
       }  //'<' -- '<='

      case 8:{
        if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
               (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
               {   //query : a>3 and b<=5 , const : a>3 -> 3<=b<=10
                  att[count] = attdb;
                  sign[count] = 4;
                  tb[count] = tbdb;
                  val[count] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[count] = 3;  // reduct scan
                  count++;             //query : a>3 and b<=5 and b>=3
                  return false;          //not reject
                  }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                           (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) < Integer.parseInt(valadd))){
                           //query : a>3 and b<=5 , const : a>3 -> 1<=b<=4
                    if(chk_indx(attdb,tbdb)){

                      sign[pos] = 4;
                      val[pos] = valdb.substring(0,valdb.indexOf("/"));
                      checkupdate[pos]=2;  //query : a>3 and b>=1

                      att[count] = attdb;
                      sign[count] = 5;
                      tb[count] = tbdb;
                      val[count] = valdb.substring(valdb.indexOf("/")+1);
                      checkupdate[count] = 3;  // reduct scan
                      count++;        //query : a>3 and b>=1 and b<=4

                    }
                    else {
                      att[pos] = "";
                      tb[pos] = "";
                      sign[pos] = 0;
                      val[pos] = "";
                      checkupdate[pos]=-1;  //query : a>3
                    }
                    return false;          //not reject
                  }
                  else if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd))
                    //query : a>3 and b<=5 , const : a>3 -> 6<=b<=10
                        return true;
                  else {
                    //query : a>3 and b<=5 , const : a>3 -> 5<=b<=10
                    sign[pos] = 0;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;    //query : a>3 and b=10
                    return false;          //not reject
                  }
      }  //'<=' -- '<='

      case 9:{
               if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                 (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
                 {   //query : a>3 and b<=5 , const : a>3 -> 3<=b<10
                    att[count] = attdb;
                    sign[count] = 4;
                    tb[count] = tbdb;
                    val[count] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[count] = 3;  // reduct scan
                    count++;             //query : a>3 and b<=5 and b>=3
                    return false;          //not reject
                    }else if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
                             (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) <= Integer.parseInt(valadd))){
                             //query : a>3 and b<=5 , const : a>3 -> 1<=b<4
                      if(chk_indx(attdb,tbdb)){

                        sign[pos] = 4;
                        val[pos] = valdb.substring(0,valdb.indexOf("/"));
                        checkupdate[pos]=2;  //query : a>3 and b>=1

                        att[count] = attdb;
                        sign[count] = 3;
                        tb[count] = tbdb;
                        val[count] = valdb.substring(valdb.indexOf("/")+1);
                        checkupdate[count] = 3;  // reduct scan
                        count++;             //query : a>3 and b>=1 and b<4

                      }
                        else {
                          att[pos] = "";
                          tb[pos] = "";
                          sign[pos] = 0;
                          val[pos] = "";
                          checkupdate[pos]=-1;  //query : a>3
                        }

                     return false;          //not reject
                    }
                    else if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) > Integer.parseInt(valadd))
                    //query : a>3 and b<=5 , const : a>3 -> 6<=b<=10
                        return true;
                  else {
                    //query : a>3 and b<=5 , const : a>3 -> 5<=b<=10
                    sign[pos] = 0;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;    //query : a>3 and b=10
                    return false;          //not reject
                  }
             }//'<=' -- '<'
           case 10: {
                         int ind=0;
                         int end=0;
                         if(!valdb.substring(valdb.indexOf("",0),1).equalsIgnoreCase("'")){
                         if(valdb.indexOf(",") == -1){
                           if( Integer.parseInt(valdb)<= Integer.parseInt(valadd))
                             checkupdate[pos]=0;    // else reject
                             return false; } // if equal not reject
                        else{
                            boolean con=true,covernotall =true,coverall=true;
                            ind=0;
                            end=(valdb.indexOf(",",1)) ;
                            while(con){
                                 String word= valdb.substring(ind,end);
                                 System.out.print(word+" ");
                                 if( Integer.parseInt(valdb) <= Integer.parseInt(valadd) )
                                     { System.out.print("valuein in db <= query =" + word);
                                       covernotall= false;  }
                                 else{
                                       System.out.print("valuein in db > query =" + word);
                                       coverall= false;     }
                                 if(end==valdb.length()){
                                   System.out.print("end");
                                   con= false;  }
                                 ind=end+1;
                                 if (valdb.indexOf(",",ind+1) != -1)
                                   end=(valdb.indexOf(",",ind+1));
                                 else
                                   end=valdb.length();
                               } // end while
                               if(covernotall) return true; // for all value in db not >= attval then reject
                               if(coverall){
                                  if(!chk_indx(attdb,tbdb)){
                                    att[pos] = "";
                                    tb[pos] = "";
                                    sign[pos] = 0;
                                    val[pos] = "";
                                    checkupdate[pos]=-1;
                                   }
                                  return false;
                               }else return false;    // for have some value in case in >= attval
                             }  // end else
                             }  // end check data in db is int
       }  // end case 10
      default:  return false;          //not reject
     }
    return true;
 }
public boolean compbetween(String attr,String tbatt,String valdb,String valadd,int signn,int pos){
  int i,j;
   switch (signn){
     case 0:  System.out.print("start");            //'='
       if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)
            && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
            {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b=5,6..10
                   if(chk_indx(attr,tbatt)){
                     sign[pos] = signn;
                     val[pos] = valdb;
                     checkupdate[pos]=2;      //query : a>3 and b=3
                   }
                   else {
                     att[pos] = "";
                     tb[pos] = "";
                     sign[pos] = 0;
                     val[pos] = "";
                     checkupdate[pos]=-1;     //query : a>3
                   }
                   return false;          //not reject
                 }
                 System.out.print( valdb+" + "+ valadd);
                 break; //retrun false
   case 1: {
             //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> b!=3
               checkupdate[pos]=0;  //no change
              return false;          //not reject
           }
   case 2:{
         if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) <= Integer.parseInt(valdb))
           //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> b>10
           return true;
         else if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)
          && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
            {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b>7
                  sign[pos] = signn;
                  val[pos] = valdb;
                  checkupdate[pos]=2;    //query : a>3 and b>7

                  att[count] = attr;
                  sign[count] = 5;
                  tb[count] = tbatt;
                  val[count] = valadd.substring(valadd.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;            //query : a>3 and b>7 and b<=10
                  return false;          //not reject
            } else {
              //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b>2
              checkupdate[pos]=0;  //no change
               return false;          //not reject
            }
        }//'>'
   case 3:{
     if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb))
       //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> b<2
       return true;
     else if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb)
             && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
         {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b<7
            sign[pos] = 4;
            val[pos] = valadd.substring(0,valadd.indexOf("/"));
            checkupdate[pos]=2;    //query : a>3 and b>=5

            att[count] = attr;
            sign[count] = signn;
            tb[count] = tbatt;
            val[count] = valdb;
            checkupdate[count] = 3;  // reduct scan
            count++;            //query : a>3 and b>=5 and b<7
            return false;          //not reject
          }
      else {
            //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b<12
            checkupdate[pos]=0;  //no change
            return false;          //not reject
     }
   }//'<'
 case 4:{
         if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb))
           //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> b>=12
           return true;
         else if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)
          && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
            {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b>=7
                if(Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb)){
                  sign[pos] = signn;
                  val[pos] = valdb;
                  checkupdate[pos]=2;    //query : a>3 and b>=7

                  att[count] = attr;
                  sign[count] = 5;
                  tb[count] = tbatt;
                  val[count] = valadd.substring(valadd.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;            //query : a>3 and b>=7 and b<=10
                }
                else {  //const : a>3 -> b>=10
                  sign[pos] = 0;
                  val[pos] = valdb;
                  checkupdate[pos]=2;    //query : a>3 and b=10
                }
                return false;          //not reject
            } else {
              //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b>=2
              checkupdate[pos]=0;  //no change
               return false;          //not reject
            }
        }//'>='
  case 5:{
          if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb))
            //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> b<=2
            return true;
          else if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)
                  && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
              {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b<=7
                 if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb)){
                    sign[pos] = 4;
                    val[pos] = valadd.substring(0,valadd.indexOf("/"));
                    checkupdate[pos]=2;    //query : a>3 and b>=5

                    att[count] = attr;
                    sign[count] = signn;
                    tb[count] = tbatt;
                    val[count] = valdb;
                    checkupdate[count] = 3;  // reduct scan
                    count++;            //query : a>3 and b>=5 and b<=7
                 }
                 else {  //const : a>3 -> b<=5
                      sign[pos] = 0;
                      val[pos] = valdb;
                      checkupdate[pos]=2;    //query : a>3 and b=5
                 }
                return false;          //not reject
               }
           else {
                 //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b<=12
                checkupdate[pos]=0;  //no change
                return false;          //not reject
           }
       }//'<='
     case 6:{
        if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
            || Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) )
          //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> 1<b<5 , 10<b<20 (out of range)
          return true;
        else if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
               && Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
               && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))<= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) )
            {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 6<b<9
               sign[pos] = 2;
               val[pos] = valdb.substring(0,valdb.indexOf("/"));
               checkupdate[pos]=2;    //query : a>3 and b>6

               att[count] = attr;
               sign[count] = 3;
               tb[count] = tbatt;
               val[count] = valdb.substring(valdb.indexOf("/")+1);
               checkupdate[count] = 3;  // reduct scan
               count++;            //query : a>3 and b>6 and b<9
               return false;          //not reject
             }
             else if( Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                   && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                   && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))> Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                 {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 1<b<7
                    sign[pos] = 4;
                    val[pos] = valadd.substring(0,valadd.indexOf("/"));
                    checkupdate[pos]=2;    //query : a>3 and b>=5

                    att[count] = attr;
                    sign[count] = 3;
                    tb[count] = tbatt;
                    val[count] = valdb.substring(valdb.indexOf("/")+1);
                    checkupdate[count] = 3;  // reduct scan
                    count++;            //query : a>3 and b>=5 and b<7
                    return false;          //not reject
                 }
              else if( Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                   && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                   && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))> Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                 {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 7<b<12
                    sign[pos] = 2;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;    //query : a>3 and b>7

                    att[count] = attr;
                    sign[count] = 5;
                    tb[count] = tbatt;
                    val[count] = valadd.substring(valadd.indexOf("/")+1);
                    checkupdate[count] = 3;  // reduct scan
                    count++;            //query : a>3 and b>7 and b<=10
                    return false;          //not reject
                 }
         else {
               //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> b<12
               checkupdate[pos]=0;  //no change
               return false;          //not reject
        }
     }//'< _ <'
   case 7:{
           if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
               || Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) )
             //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> 1<b<=4 , 10<b<=20 (out of range)
             return true;
           else if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                  && Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                  && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))<= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) )
               {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 6<b<=9
                  sign[pos] = 2;
                  val[pos] = valdb.substring(0,valdb.indexOf("/"));
                  checkupdate[pos]=2;    //query : a>3 and b>6

                  att[count] = attr;
                  sign[count] = 5;
                  tb[count] = tbatt;
                  val[count] = valdb.substring(valdb.indexOf("/")+1);
                  checkupdate[count] = 3;  // reduct scan
                  count++;            //query : a>3 and b>6 and b<=9
                  return false;          //not reject
                }
                else if( Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                      && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                      && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))>= Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                    {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 1<b<=7
                       if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))!= Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                       {
                       sign[pos] = 4;
                       val[pos] = valadd.substring(0,valadd.indexOf("/"));
                       checkupdate[pos]=2;    //query : a>3 and b>=5

                       att[count] = attr;
                       sign[count] = 5;
                       tb[count] = tbatt;
                       val[count] = valdb.substring(valdb.indexOf("/")+1);
                       checkupdate[count] = 3;  // reduct scan
                       count++;            //query : a>3 and b>=5 and b<=7
                       }
                       else{//query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 1<b<=5
                          sign[pos] = 0;
                          val[pos] = valdb.substring(valdb.indexOf("/")+1);
                          checkupdate[pos]=2;    //query : a>3 and b=5
                       }
                       return false;          //not reject
                    }
                 else if( Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                      && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                      && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))>= Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                    {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 7<b<=12
                       sign[pos] = 2;
                       val[pos] = valdb.substring(0,valdb.indexOf("/"));
                       checkupdate[pos]=2;    //query : a>3 and b>7

                       att[count] = attr;
                       sign[count] = 5;
                       tb[count] = tbatt;
                       val[count] = valadd.substring(valadd.indexOf("/")+1);
                       checkupdate[count] = 3;  // reduct scan
                       count++;            //query : a>3 and b>7 and b<=10
                       return false;          //not reject
                    }
            else {
                  //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 10<b<=12
                  checkupdate[pos]=0;  //no change
                  return false;          //not reject
           }
     }//'< _ <='
   case 8: if(checkupdate[pos]!=3)
   {
          if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                  || Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) ){
                //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> 1<=b<=4 , 10<=b<=20 (out of range)
               if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) == Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))){
                  //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> 10<=b<=20
                 sign[pos] = 0;
                 val[pos] = valdb.substring(0,valdb.indexOf("/"));
                 checkupdate[pos]=2;    //query : a>3 and b=10
               }
               else return true;
              }
          else if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                     && Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                     && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))<= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) )
                  {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 6<=b<=9
                     sign[pos] = 4;
                     val[pos] = valdb.substring(0,valdb.indexOf("/"));
                     checkupdate[pos]=2;    //query : a>3 and b>=6

                     att[count] = attr;
                     sign[count] = 5;
                     tb[count] = tbatt;
                     val[count] = valdb.substring(valdb.indexOf("/")+1);
                     checkupdate[count] = 3;  // reduct scan
                     count++;            //query : a>3 and b>=6 and b<=9
                     return false;          //not reject
                   }
            else if( Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                         && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                         && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))>= Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                       {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 1<=b<=7
                          if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))> Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                          {
                          sign[pos] = 4;
                          val[pos] = valadd.substring(0,valadd.indexOf("/"));
                          checkupdate[pos]=2;    //query : a>3 and b>=5

                          att[count] = attr;
                          sign[count] = 5;
                          tb[count] = tbatt;
                          val[count] = valdb.substring(valdb.indexOf("/")+1);
                          checkupdate[count] = 3;  // reduct scan
                          count++;            //query : a>3 and b>=5 and b<=7
                          }
                          else{//query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 1<=b<=5
                             sign[pos] = 0;
                             val[pos] = valdb.substring(valdb.indexOf("/")+1);
                             checkupdate[pos]=2;    //query : a>3 and b=5
                          }
                          return false;          //not reject
                       }
              else if( Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                         && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                         && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))> Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                       {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 7<=b<=12
                          sign[pos] = 4;
                          val[pos] = valdb.substring(0,valdb.indexOf("/"));
                          checkupdate[pos]=2;    //query : a>3 and b>=7

                          att[count] = attr;
                          sign[count] = 5;
                          tb[count] = tbatt;
                          val[count] = valadd.substring(valadd.indexOf("/")+1);
                          checkupdate[count] = 3;  // reduct scan
                          count++;            //query : a>3 and b>=7 and b<=10
                          return false;          //not reject
                       }
               else {
                     //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 10<b<=12
                     checkupdate[pos]=0;  //no change
                     return false;          //not reject
              }
     } else return false;
     //'<= _ <='
   case 9:{
             if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                || Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) ){
                   //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> 1<=b<5 , 10<=b<20 (out of range)
                  if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) == Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))){
                     //query : a>3 and b between 5 and 10(5<=b<=10) , const : a>3 -> 10<=b<20
                    sign[pos] = 0;
                    val[pos] = valdb.substring(0,valdb.indexOf("/"));
                    checkupdate[pos]=2;    //query : a>3 and b=10
                  }
                  else return true;
                 }
             else if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) >= Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                        && Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                        && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))<= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) )
                     {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 6<=b<9
                        sign[pos] = 4;
                        val[pos] = valdb.substring(0,valdb.indexOf("/"));
                        checkupdate[pos]=2;    //query : a>3 and b>=6

                        att[count] = attr;
                        sign[count] = 3;
                        tb[count] = tbatt;
                        val[count] = valdb.substring(valdb.indexOf("/")+1);
                        checkupdate[count] = 3;  // reduct scan
                        count++;            //query : a>3 and b>=6 and b<9
                        return false;          //not reject
                      }
               else if( Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd.substring(0,valadd.indexOf("/")))
                            && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                            && Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))> Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                          {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 1<=b<7

                             sign[pos] = 4;
                             val[pos] = valadd.substring(0,valadd.indexOf("/"));
                             checkupdate[pos]=2;    //query : a>3 and b>=5

                             att[count] = attr;
                             sign[count] = 3;
                             tb[count] = tbatt;
                             val[count] = valdb.substring(valdb.indexOf("/")+1);
                             checkupdate[count] = 3;  // reduct scan
                             count++;            //query : a>3 and b>=5 and b<7

                             return false;          //not reject
                          }
                 else if( Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                            && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))< Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))
                            && Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))> Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))))
                          {   //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 7<=b<12
                             sign[pos] = 4;
                             val[pos] = valdb.substring(0,valdb.indexOf("/"));
                             checkupdate[pos]=2;    //query : a>3 and b>=7

                             att[count] = attr;
                             sign[count] = 5;
                             tb[count] = tbatt;
                             val[count] = valadd.substring(valadd.indexOf("/")+1);
                             checkupdate[count] = 3;  // reduct scan
                             count++;            //query : a>3 and b>=7 and b<=10
                             return false;          //not reject
                          }
                  else {
                        //query : a>3 and b between 5 and 10(5<=b<=10), const : a>3 -> 10<b<=12
                        checkupdate[pos]=0;  //no change
                        return false;          //not reject
                 }
     }//'<= _ <'
   case 10: {
              int ind=0;
              int end=0;
              // ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(val[pos])) &&
               //  (Integer.parseInt(val[pos]) <= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))))

              if(!valdb.substring(valdb.indexOf("",0),1).equalsIgnoreCase("'")){
              if(valdb.indexOf(",") == -1){
              if((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)) &&
                 (Integer.parseInt(valdb) <= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))))
                  checkupdate[pos]=0;    // else reject
                  return false; } // if equal not reject
             else{
                 boolean con=true,covernotall =true,coverall=true;
                 ind=0;
                 end=(valdb.indexOf(",",1)) ;
                 while(con){
                      String word= valdb.substring(ind,end);
                      System.out.print(word+" ");
                      if((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(word)) &&
                         (Integer.parseInt(word) <= Integer.parseInt(valadd.substring(valadd.indexOf("/")+1))))
                          { System.out.print("valuein in db in range between query =" + word);
                            covernotall= false;  }
                      else{
                            System.out.print("valuein in db not in range between query =" + word);
                            coverall= false;     }
                      if(end==valdb.length()){
                        System.out.print("end");
                        con= false;  }
                      ind=end+1;
                      if (valdb.indexOf(",",ind+1) != -1)
                        end=(valdb.indexOf(",",ind+1));
                      else
                        end=valdb.length();
                    } // end while
                    if(covernotall) return true; // for all value in db not >= attval then reject
                    if(coverall){
                       if(!chk_indx(attr,tbatt)){
                         att[pos] = "";
                         tb[pos] = "";
                         sign[pos] = 0;
                         val[pos] = "";
                         checkupdate[pos]=-1;
                        }
                       return false;
                    }else return false;    // for have some value in case in >= attval
                  }  // end else
                  }  // end check data in db is int
       }  // end case 10

   default:  return false;          //not reject
   }//end switch
  return true;
 }// fn between


public boolean compin(String attr,String tbatt,String valdb,String valadd,int signn,int pos){
   // in query a in ('a','ab','c','d') or a in (1,3,4)

switch(signn){
    case 0: {if(valadd.indexOf(",") == -1)    // in have single value
            {
              if(valadd.equalsIgnoreCase(valdb))    // and it equal in rule
                {
                if(chk_indx(attr,tbatt))    // and it is index
                 { sign[pos] = signn;          // change value from rule
                   val[pos] = valdb;
                   checkupdate[pos]=2;
                   return false;}
                 else { att[pos] = "";
                  tb[pos] = "";
                  sign[pos] = 0;
                  val[pos] = "";
                  checkupdate[pos]=-1;
                  return false;}
              }else return true;
             } else          // in have many value
             {
             int ind=0,end=0;
             boolean con=true;
             if (valadd.indexOf(",",ind+1) != -1)
             end = (valadd.indexOf(",",1));
             else end = valadd.length();
             while(con){
             String word= valadd.substring(ind,end);
             System.out.println(word+"---"+valdb+" ");
             if(word.equalsIgnoreCase(valdb))
               {con=false;
                sign[pos] = signn;          // change value from rule
                val[pos] = valdb;
                checkupdate[pos]=2;
                return false;
                }
              else{ if(end==valadd.length())  // until if last word not match in =
                {   con=false;                // reject
                    return true;
                }
              else{
              ind=end+1;
              if (valadd.indexOf(",",ind) != -1)
              end=(valadd.indexOf(",",ind));
              else end=val[pos].length();
                  }  // end else if not match and not last
                  } // end else if not match
             }  // end while
             } // end else many value in in
             } // end case 0 "="
    case 1:  { if(valadd.indexOf(",") == -1)    // in have single value
             { if(valadd.equalsIgnoreCase(valdb))    // and it equal in rule
                return true;                       // nean that restrict
             } else          // in have many value
             {
             int ind=0,end=0;
             boolean con=true;
             if (valadd.indexOf(",",ind+1) != -1)
             end = (valadd.indexOf(",",1));
             else end = valadd.length();
             while(con){
             String word= valadd.substring(ind,end);
             System.out.println(word+"---"+valdb+" ");
             if(word.equalsIgnoreCase(valdb))
               {con=false;
                 if(ind==0){
                   val[pos]=valadd.substring(end+1,valadd.trim().length());
                 }
                 else
                 { if(end==valadd.trim().length())val[pos]=valadd.substring(0,ind-1);
                  else
                   val[pos]= valadd.substring(0,ind)+valadd.substring(end+1,valadd.length());
                 }

                // change value from rule
                checkupdate[pos]=2;
                return false;
                }
              else{ if(end==valadd.length())  // until if last word not match in =
                {   con=false;                // reject
                    return false;
                }
              else{
              ind=end+1;
              if (valadd.indexOf(",",ind) != -1)
              end=(valadd.indexOf(",",ind));
              else end=val[pos].length();
                  }  // end else if not match and not last
                  } // end else if not match
             }  // end while
             } // end else many value in in
             } // end case 1 !=
    case 2:{ }
    case 3:{ }
    case 4:{ }
    case 5:{ }
    case 6:{ }
    case 7:{ }
    case 8:{ }
    case 9:{ }
    case 10:{
          String tmpvalq[]=new String[15];
          String tmpvaldb[]=new String[15];
          int ind=0,lenghtq=0,lenghtdb=0,point=0;
          int end;
          if (valadd.indexOf(",",ind+1) != -1)
          end=valadd.indexOf(",",1);
          else
          end = valadd.length();
          boolean con=true;
          // find value in array  -----------------
          // array temp of query
          while(con){
           tmpvalq[point] = valadd.substring(ind,end);
           System.out.println("\ntmpvalq"+point+" = "+tmpvalq[point]);
           point++;
           if(end==valadd.length())
            con=false;
            ind=end+1;
            if (valadd.indexOf(",",ind+1) != -1)
            end=(valadd.indexOf(",",ind+1));
            else
            end=valadd.length();
            }  lenghtq=point;
          // array temp of database
          ind=0; point=0;
          if (valdb.indexOf(",",ind+1) != -1)
          end=(valdb.indexOf(",",1));
          else end = valdb.length();
          con=true;

          while(con){
          tmpvaldb[point] = valdb.substring(ind,end);
          System.out.print("  tmpvaldb"+point+" = "+tmpvaldb[point]);
          point++;
          if(end==valdb.length())
           con=false;
           ind=end+1;
           if (valdb.indexOf(",",ind+1) != -1)
           end=valdb.indexOf(",",ind+1);
           else
           end=valdb.length();
            }  lenghtdb=point;
          ///---------------------------------------------------------
          point=0; con= true; ind=0;
          boolean checknullall=true,found=false;
          int countall=0;
          while(point < lenghtq){
            ind=0;
            con=true;
            found=false;
            while((con)&& ind<lenghtdb){
              if(tmpvaldb[ind].equalsIgnoreCase(tmpvalq[point]))
              { found=true; con=false; checknullall=false;}
              ind++;
            }
            if(!found){tmpvalq[point]="";}else countall++;
            point++;
         } // end while check value each query
         if(checknullall) return true;     // reject because no have value in rule
         else
         { if(countall==lenghtq){        //  if have all value
             if(chk_indx(attr,tbatt))   // don't change value in query condition
               return false;
             else { att[pos] = "";
                  tb[pos] = "";
                  sign[pos] = 0;
                  val[pos] = "";
                  checkupdate[pos]=-1;
                  return false; }
            } else{
              String tmpqueryS = "";
              for(int i=0;i<lenghtq;i++){
              if(!tmpvalq[i].equalsIgnoreCase("")) {
                tmpqueryS = tmpqueryS + ","+tmpvalq[i];
              }
              System.out.println(" value new in query in -> "+tmpqueryS);
              }// end for
              val[pos]=tmpqueryS.substring(1,tmpqueryS.length()).trim();
              return false;
             }  // end if have some value
        } // end if have some value in rule then change value in query condition
     } // end case =10
    default : return false;
   } // end swicth

  } // end function in

//-----------------------------------*******************************

int checkpred1(int signdb1,String valuedb1,int pos){
     // return 0 = match
     // return 1 = notmatch but in range
     // return 2 = no have all constraint
  switch(sign[pos]){
 case 0: System.out.println("case '=' ");
    switch(signdb1)
     { case 0: if(val[pos].equalsIgnoreCase(valuedb1.trim())) return 0;
               else return 2;  // =
       case 1: return 2;   //<>
       case 2: if(val[pos].substring(0,1).equals("'"))
             { if(val[pos].compareToIgnoreCase(valuedb1) > 0) return 1;
               else return 2;
             }
             else
             { if(Integer.parseInt(val[pos].trim()) > Integer.parseInt(valuedb1.trim())) return 1;
               else return 2;  }  // >
       case 3: if(val[pos].substring(0,1).equals("'"))
             { if(val[pos].compareToIgnoreCase(valuedb1) < 0) return 1;
               else return 2;
             }
             else
             { if(Integer.parseInt(val[pos].trim()) < Integer.parseInt(valuedb1.trim())) return 1;
               else return 2;  }   // <
        case 4: if(val[pos].substring(0,1).equals("'"))
             { if(val[pos].compareToIgnoreCase(valuedb1.trim()) >= 0) return 1;
               else return 2;
             }
             else
             { if(Integer.parseInt(val[pos]) >= Integer.parseInt(valuedb1)) return 1;
               else return 2;  }   // >=
        case 5: if(val[pos].substring(0,1).equals("'"))
            { if(val[pos].compareToIgnoreCase(valuedb1) <= 0) return 1;
              else return 2;
            }
            else
            { if(Integer.parseInt(val[pos]) <= Integer.parseInt(valuedb1)) return 1;
               else return 2;  }   // <
        case 6: if((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) < Integer.parseInt(val[pos])) &&
                   (Integer.parseInt(val[pos]) < Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                return 1;  else return 2;   //'<' -- '<'
        case 7: if((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) < Integer.parseInt(val[pos])) &&
                   (Integer.parseInt(val[pos]) <= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                return 1;  else return 2;  //'<' -- '<='
        case 8: if((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) <= Integer.parseInt(val[pos])) &&
                  (Integer.parseInt(val[pos]) <= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                return 1;  else return 2;  //'<=' -- '<='
        case 9: if((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) <= Integer.parseInt(val[pos])) &&
                  (Integer.parseInt(val[pos]) < Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                return 1;  else return 2;  //'<=' -- '<'
        case 10:
                int ind=0;
                int end=0;
                if(valuedb1.indexOf(",") == -1){
                  if( valuedb1.equalsIgnoreCase(val[pos]))
                    return 0; }
                    else{
                      boolean con=true;
                      ind=0;
                      end=(valuedb1.indexOf(",",1)) ;
                      while(con){
                        String word= valuedb1.substring(ind,end);
                        System.out.print(word+" ");
                        if( word.equalsIgnoreCase(val[pos]))
                            { System.out.print(" ::true:: " + word);
                        return 1; }
                        if(end==valuedb1.length()){
                          System.out.print(" ::false:: " +word);
                          con= false;
                        return 2; }
                        ind=end+1;
                        if (valuedb1.indexOf(",",ind+1) != -1)
                          end=(valuedb1.indexOf(",",ind+1));
                        else
                          end=valuedb1.length();
                      }
                    }  // end else over one value
                    break; // in}
            default: return 2;
             }// end switch case "="
 case 1: System.out.println(" <> ");//
         switch (signdb1){
         case 1:          //'='
           if(valuedb1.equalsIgnoreCase(val[pos])) return 0; break;
         case 0:case 2:case 3:case 4:case 5:case 6:case 7:case 8:case 9:case 10:default:return 2;
         }// end case <>
         break;
 case 2: System.out.println(" > ");      // value in const must less than in query a > 3  con a > 2
         switch (signdb1){
         case 2:  if(val[pos].equalsIgnoreCase(valuedb1))return 0;
                  if(Integer.parseInt(valuedb1) < Integer.parseInt(val[pos]))
                  return 1;  break;
         case 4:  if(Integer.parseInt(valuedb1) <= Integer.parseInt(val[pos]))
                  return 1;  break;
         default: return 2;
         }
         break;
 case 3: System.out.println(" < ");      // value in const must more than in query a < 7  con a < 9
          switch (signdb1){
            case 3:  if(val[pos].equalsIgnoreCase(valuedb1))return 0;
                     if(Integer.parseInt(valuedb1) > Integer.parseInt(val[pos]))
                     return 1;  break;
            case 5:  if(Integer.parseInt(valuedb1) >= Integer.parseInt(val[pos]))
                     return 1;  break;
            default: return 2;
         }
         break;
 case 4: System.out.println(" >= ");      // value in const must less than in query a >= 3  con a >= 2
           switch (signdb1){
           case 2:  if(Integer.parseInt(valuedb1) < Integer.parseInt(val[pos]))
                    return 1;  break;
           case 4:  if(val[pos].equalsIgnoreCase(valuedb1))return 0;
                    if(Integer.parseInt(valuedb1) < Integer.parseInt(val[pos]))
                    return 1;  break;
           default: return 2;
         }
         break;
 case 5: System.out.println(" <= ");      // value in const must more than in query a <=7  con a <= 5
           switch (signdb1){
           case 3:  if(Integer.parseInt(valuedb1) > Integer.parseInt(val[pos]))
                    return 1;  break;
           case 5:  if(val[pos].equalsIgnoreCase(valuedb1))return 0;
                    if(Integer.parseInt(valuedb1) > Integer.parseInt(val[pos]))
                    return 1;  break;
           default: return 2;
         }
         break;
/*
 case 6: System.out.println(" < -- < "); // value in const must overall in query
           switch (signdb1){
           case 2:case 4: // in query  7 < a < 18  and const  a > 5,7 or const  a >= 5,7
             if (Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1))
               return 1;  break;
           case 3:case 5: // in query  7 < a < 18  and const  a < 18,22 or const  a <= 18,22
             if (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1))
               return 1;  break;
           case 6: // in query 7 < a < 18  and const  5,7 < a < 18,20
             if (valuedb1.equalsIgnoreCase(val[pos])) return 0;
             if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
               && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
               return 1;  break;
           case 7:case 8:case 9: // in query 7 < a < 18  and const  5,7 < a <= 18,20
             if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
                && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
               return 1;  break;
           default : return 2;
           }
           break;
 case 7: System.out.println(" < -- <= "); // value in const must overall in query
              switch (signdb1){
              case 2:case 4: // in query  7 < a =< 18  and const  a > 5,7 or const  a >= 5,7
                if (Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1))
                  return 1;  break;
              case 3:// in query  7 < a =< 18  and const  a < 19,22
                if (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))< Integer.parseInt(valuedb1))
                  return 1;  break;
              case 5: // in query  7 < a =< 18  and const  const  a <= 18,22
                  if (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1))
                  return 1;  break;
              case 6:case 9: // in query 7 < a <= 18  and const  5,7 < a < 19,20   const 5,7 <= a < 19,20
                if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
                  && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))< Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                  return 1; break;
              case 7: // in query 7 < a <= 18  and const  5,7 < a <= 18,20
                if (valuedb1.equalsIgnoreCase(val[pos])) return 0;
                if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
                   && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                  return 1; break;
              case 8: // in query 7 < a <= 18  and const  5,7 <= a <= 18,20
                if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
                  && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
                  return 1; break;
              default : return 2;  // in query 7 < a <= 18  case =,<>,in not overall query
           } // end case 7 condition
           break;  */
case 8: System.out.println(" <= -- <= "); // value in const must overall in query
  switch (signdb1){
     case 2: // in query  7 <= a <= 18  and const  a > 5,6
         if (Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) > Integer.parseInt(valuedb1))
        return 1;  break;
     case 4: // in query  7 <= a <= 18  and const  a >= 5,7
        if (Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1))
        return 1;  break;
     case 3:// in query  7 <= a <= 18  and const  a < 19,22
        if (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))< Integer.parseInt(valuedb1))
        return 1;  break;
     case 5: // in query  7 <= a <= 18  and const  const  a <= 18,22
        if (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1))
        return 1;  break;
     case 6: // in query 7 <= a <= 18  and const  5,6 < a < 19,20
        if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) > Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
          && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))< Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     case 7: // in query 7 <= a <= 18  and const  5,6 < a <= 18,20
        if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) > Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
           && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     case 8: // in query 7 <= a <= 18  and const  5,7 <= a <= 18,20
        if (valuedb1.equalsIgnoreCase(val[pos])) return 0;
        if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
          && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     case 9: // in query 7 <= a <= 18  and const  5,7 <= a < 19,20
        if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
          && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))< Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     default : return 2;  // in query 7 <= a <= 18 case =,<>,in not overall query
           }  // end case 8 condition
        break;
        /*
case 9: System.out.println(" <= -- < "); // value in const must overall in query
  switch (signdb1){
     case 2: // in query  7 <= a < 18  and const  a > 5,6
         if (Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) > Integer.parseInt(valuedb1))
        return 1;  break;
     case 4: // in query  7 <= a < 18   and const  a >= 5,7
        if (Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1))
        return 1;  break;
     case 3: // in query  7 <= a < 18   and const  a < 18,19,22  or const  a <= 18,22
        if (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1))
        return 1;  break;
     case 6: // in query  7 <= a < 18   and const  5,6 < a < 18,20 or const  5,6 < a <= 18,20
        if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) > Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
          && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     case 8: // in query 7 <= a < 18  and const  5,7 <= a <= 18,20
        if (valuedb1.equalsIgnoreCase(val[pos])) return 0;
        if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
          && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     case 9: // in query 7 <= a < 18   and const  5,7 <= a < 18,20
       if (valuedb1.equalsIgnoreCase(val[pos])) return 0;
       if((Integer.parseInt(val[pos].substring(0,val[pos].indexOf("/"))) >= Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))))
          && (Integer.parseInt(val[pos].substring(val[pos].indexOf("/")+1))<= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))
        return 1; break;
     default : return 2;  // in query 7 <= a < 18   case =,<>,in not overall query
           }  // end case 9 condition
      break;  */
 case 10: // in query a in ('a','ab','c','d') or a in (1,3,4)
   System.out.println(" case in ");
   if(signdb1==0||signdb1==1){
      System.out.print(valuedb1+"+"+ val[pos]);
      if(val[pos].indexOf(",") == -1)
        {if(valuedb1.equalsIgnoreCase(val[pos]))return 0;}
        else return 2;
    }
  else {
    if(signdb1 == 10){
      String tmpvalq[]=new String[15];
      String tmpvaldb[]=new String[15];
      int ind=0,lenghtq=0,lenghtdb=0,point=0;
      int end;
      if (val[pos].indexOf(",",ind+1) != -1)
      end=val[pos].indexOf(",",1);
      else
      end = val[pos].length();
      boolean con=true;
      // find value in array  -----------------
      // array temp of query
      while(con){
       tmpvalq[point] = val[pos].substring(ind,end);
       System.out.println("\ntmpvalq"+point+" = "+tmpvalq[point]);
       point++;
       if(end==val[pos].length())
        con=false;
        ind=end+1;
        if (val[pos].indexOf(",",ind+1) != -1)
        end=(val[pos].indexOf(",",ind+1));
        else
        end=val[pos].length();
        }  lenghtq=point;
      // array temp of database
      ind=0; point=0;
      if (valuedb1.indexOf(",",ind+1) != -1)
      end=(valuedb1.indexOf(",",1));
      else end = valuedb1.length();
      con=true;

      while(con){
      tmpvaldb[point] = valuedb1.substring(ind,end);
      System.out.print("  tmpvaldb"+point+" = "+tmpvaldb[point]);
      point++;
      if(end==valuedb1.length())
       con=false;
       ind=end+1;
       if (valuedb1.indexOf(",",ind+1) != -1)
       end=valuedb1.indexOf(",",ind+1);
       else
       end=valuedb1.length();
        }  lenghtdb=point;
      ///---------------------------------------------------------
      point=0; con= true; ind=0;
      boolean check=true,found=false;
      while(point < lenghtq){
        ind=0;
        con=true;
        found=false;
        while((con)&& ind<lenghtdb){
          if(tmpvaldb[ind].equalsIgnoreCase(tmpvalq[point]))
          { found=true; con=false; }
          ind++;
        }
        if(!found){point=lenghtq; check=false;}
        point++;
     } // end while check value each query
     if(check) return 1;
     else  return 2;
    } // end case =10
    else // case else for case 2-9
     { int ind=0,end=0;
       boolean con=true,attin=false;
       if (valuedb1.indexOf(",",ind+1) != -1)
       end = (val[pos].indexOf(",",1));
       else end = val[pos].length();
       while(con){
       String word= val[pos].substring(ind,end);
       System.out.println(word+"---"+valuedb1+" ");

       if(!val[pos].substring(0,1).equalsIgnoreCase("'")){
       if (signdb1==2 ||signdb1==3||signdb1==4||signdb1==5) {
       if(((Integer.parseInt(word) > Integer.parseInt(valuedb1))&& signdb1==2 )
            || ((Integer.parseInt(word) < Integer.parseInt(valuedb1))&& signdb1==3 )
            || ((Integer.parseInt(word) >= Integer.parseInt(valuedb1))&& signdb1==4 )
            || ((Integer.parseInt(word) <= Integer.parseInt(valuedb1))&& signdb1==5 )
           ) attin=true; else attin =false;}
       else{
       if((((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) < Integer.parseInt(word)) &&
               (Integer.parseInt(word) < Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))&& signdb1 ==6)
           || (((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) < Integer.parseInt(word)) &&
               (Integer.parseInt(word) <= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))))&& signdb1 ==7)
           || (((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) <= Integer.parseInt(word)) &&
              (Integer.parseInt(word) <= Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1)))) && signdb1 == 8)
           || (((Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/"))) <= Integer.parseInt(word)) &&
              (Integer.parseInt(word) < Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1)))) && signdb1 == 9)
           )attin=true; else attin=false;
       }
       } // end if not string
       else { // if string
         if (signdb1==2 ||signdb1==3||signdb1==4||signdb1==5) {
       if(((word.compareToIgnoreCase(valuedb1)>0)&& signdb1==2 )
            || ((word.compareToIgnoreCase(valuedb1)<0)&& signdb1==3 )
            || ((word.compareToIgnoreCase(valuedb1)>=0)&& signdb1==4 )
            || (((word.compareToIgnoreCase(valuedb1)<=0))&& signdb1==5 )
           ) attin=true; else attin =false;}
       else{
       if(    ((valuedb1.substring(0,valuedb1.indexOf("/")).compareToIgnoreCase(word)<0) &&
               (word.compareToIgnoreCase(valuedb1.substring(valuedb1.indexOf("/")+1))<0)&& signdb1 ==6)
           || ((valuedb1.substring(0,valuedb1.indexOf("/")).compareToIgnoreCase(word)<0) &&
               (word.compareToIgnoreCase(valuedb1.substring(valuedb1.indexOf("/")+1))<=0)&& signdb1 ==7)
           || ((valuedb1.substring(0,valuedb1.indexOf("/")).compareToIgnoreCase(word)<=0) &&
               (word.compareToIgnoreCase(valuedb1.substring(valuedb1.indexOf("/")+1))<=0) && signdb1 == 8)
           || ((valuedb1.substring(0,valuedb1.indexOf("/")).compareToIgnoreCase(word)<=0) &&
               (word.compareToIgnoreCase(valuedb1.substring(valuedb1.indexOf("/")+1))<0) && signdb1 == 9)
           )attin=true; else attin=false;
       }
       } // end if else that is string

       if(attin)
       {
           if(end==val[pos].length()){
           System.out.print("all value in range");
           con=false;
           return 1; }
           ind=end+1;
           if (val[pos].indexOf(",",ind) != -1)
           end=(val[pos].indexOf(",",ind));
           else
           end=val[pos].length();
           }
         else {
         con =false;
         System.out.print("have one value restrict");
         return 2;}
       } // end continue
    }  // case else for case 2-9
  }// end else for case = 2-10
default:  System.out.println("default of switch of function");
   break;
  }  // end switch for fn
  return 2;
} // end function
///////////// fn inter /////////////////////
boolean interatt(String attq,String tbq,int signq,String valq,int pos,String atta,String tba,int signinter,String attb,String tbb){
  int i=0,signqb;
    String attqb,tbqb,valqb;
    boolean inswitch = false,reject =false;
    while(i<count && !reject){
     signqb = sign[i];
     attqb = att[i];
     tbqb = tb[i];
     valqb = val[i];
     char ch;
     if(!val[i].equals(""))
     ch= val[i].charAt(0) ;
     else ch='c';
     if(Character.isDigit(ch)||(!Character.isLetterOrDigit(ch)))
     {
      if(attqb.equalsIgnoreCase(attb)){
        inswitch =true;
        switch (signq){
         case 0: //fn equal of attq   // case A = 9
            if(eqlattq(valq,signinter,signqb,valqb)) reject=true;
               else reject = false;
               break;
         case 2: //fn more of attq   // case A > 9
            if(moreattq(valq,signinter,signqb,valqb)) reject=true;
               else reject = false;
               break;
         case 3: //fn less of attq   // case A < 9
            if(lessattq(valq,signinter,signqb,valqb)) reject=true;
               else reject = false;
               break;
         case 4:  //fn more equal of attq   // case A >= 9
           if(moreeqlattq(valq,signinter,signqb,valqb)) reject=true;
               else reject = false;
               break;
         case 5:  //fn less equal of attq   // case A <= 9
           if(lesseqlattq(valq,signinter,signqb,valqb)) reject=true;
               else reject = false;
               break;
         case 6:  //fn between of attq   // case A between 10 and 20
           if(bwattq(valq,signinter,signqb,valqb)) reject=true;
               else reject = false;
               break;
         default: return false;
        } // end switch signquery
      }//end if
     }//end if
     i++;
   } //end while
   if(reject) return true;
   else {
     if((!inswitch) && (chk_indx(attb,tbb))){
       switch (signq){
         case 0:
           switch(signinter){
             case 0 : {addindex(attb,tbb,0,valq); break;}
             case 1 : {addindex(attb,tbb,1,valq); break;}
             case 2 : {addindex(attb,tbb,3,valq); break;}
             case 3 : {addindex(attb,tbb,2,valq); break;}
             case 4 : {addindex(attb,tbb,5,valq); break;}
             case 5 : {addindex(attb,tbb,4,valq); break;}
           }
           break;
         case 2 :
           switch(signinter){
            case 0 : case 3 : case 5 : {addindex(attb,tbb,2,valq); break;}
            case 1 : case 2 : case 4 : break;
           }
           break;
         case 3 :
           switch(signinter){
            case 0 : case 2 : case 4 : {addindex(attb,tbb,3,valq); break;}
            case 1 : case 3 : case 5 : break;
           }
           break;
         case 4 :
           switch(signinter){
            case 0 : case 5 : {addindex(attb,tbb,4,valq); break;}
            case 3 : {addindex(attb,tbb,2,valq); break;}
            case 1 : case 2 : case 4 : break;
           }
           break;
         case 5 :
           switch(signinter){
            case 0 : case 4 : {addindex(attb,tbb,5,valq); break;}
            case 2 : {addindex(attb,tbb,3,valq); break;}
            case 1 : case 3 : case 5 : break;
           }
           break;
         case 6 :
           switch(signinter){
             case 0 : {addindex(attb,tbb,8,valq); break;}
             case 1 : case 2 : case 3 : case 4 : case 5 : break;
           }
           break;
       }//end switch signq
     }//end if
     return false;
   }//end else
} // end function
void addindex(String attb,String tbb,int signb,String valb){
 att[count] = attb;
 sign[count] = signb;
 tb[count] = tbb;
 val[count] = valb;
 count++;
} // end function

boolean eqlattq(String valqa,int signdb,int signqb,String valqb){
  switch(signdb){
    case 0:{  //  A = B
        switch(signqb){
          case 0: if(!valqa.equalsIgnoreCase(valqb)) return true;  break;
          case 1: if(valqa.equalsIgnoreCase(valqb)) return true;  break;
          case 2: if(Integer.parseInt(valqb)>= Integer.parseInt(valqa)) return true; break;
          case 3: if(Integer.parseInt(valqb)<= Integer.parseInt(valqa)) return true; break;
          case 4: if(Integer.parseInt(valqb) > Integer.parseInt(valqa)) return true; break;
          case 5: if(Integer.parseInt(valqb) < Integer.parseInt(valqa)) return true; break;
          case 8: if ((Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) > Integer.parseInt(valqa))
                  || (Integer.parseInt(valqa) > Integer.parseInt(valqb.substring(valqb.indexOf("/")+1))))return true;
                  break;
                     //(Integer.parseInt(valuedb1.substring(0,valuedb1.indexOf("/")))
                     //Integer.parseInt(valuedb1.substring(valuedb1.indexOf("/")+1))
          default: return false;  }
          break;
        } // end switch  case0  A=B
    case 1:{ // A!=B
              if(signqb==0)
                if(valqa.equalsIgnoreCase(valqb)) return true;
              else return false;  break;} // end switch case1 A != B
    case 2: { // A > B
                if(signqb==0||signqb==2||signqb==4)   // A=3  and b=2 ,b > 2, b >= 1
                  if(Integer.parseInt(valqb) >= Integer.parseInt(valqa)) return true;
                else if(signqb==8)
                   if(Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) >= Integer.parseInt(valqa)) return true;
                break;
            } // end case  A > B
    case 3: { // A < B
         if(signqb==0||signqb==2||signqb==4)   // A=3  and b=2 ,b < 2, b <= 1
           if(Integer.parseInt(valqb) <= Integer.parseInt(valqa)) return true;
         else if(signqb==8)
          if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) <= Integer.parseInt(valqa)) return true;
          break;   } // end case A < B
    case 4:{ // A >= B
         if(signqb==0||signqb==4)   // A=3  and b=2 ,b >= 2, b >= 1
            if(Integer.parseInt(valqb) > Integer.parseInt(valqa)) return true;
         else{
           if(signqb==2)
             { if(Integer.parseInt(valqb) >= Integer.parseInt(valqa)) return true;}
           else if(signqb==8)
               if(Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) > Integer.parseInt(valqa)) return true;
         }
          break;
            } // end case A >= B
    case 5:{ // A <= B
      if(signqb==0||signqb==4)   // A=3  and b=2 ,b >= 2, b >= 1
         if(Integer.parseInt(valqb) < Integer.parseInt(valqa)) return true;
      else{
        if(signqb==2)
          { if(Integer.parseInt(valqb) <= Integer.parseInt(valqa)) return true;}
        else if(signqb==8)
            if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) < Integer.parseInt(valqa)) return true;
      }
          break;
       } // end case A <= B
    default : return false;
  }// end Switch sign inter attribute
  return false;
}/// end eqlattq
boolean lessattq(String valqa,int signdb,int signqb,String valqb){
//A < valqa
  switch(signdb){
    case 0:{  //  A = B
        switch(signqb){
          case 0: if(Integer.parseInt(valqb)>= Integer.parseInt(valqa)) return true;  break;   // B = valqb
          case 1: return false; // B != valqb
          case 2: if(Integer.parseInt(valqb)>= Integer.parseInt(valqa)) return true; break;    // B > valqb
          case 3: return false;    // B < valqb
          case 4: if(Integer.parseInt(valqb)>= Integer.parseInt(valqa)) return true; break;    // B >= valqb
          case 5: return false;    // B <= valqb
          case 8: if (Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) >= Integer.parseInt(valqa))
                  return true;   // x <= B <= y
                  break;
          default: return false;  }
          break;
    } // end switch  case0  A=B
    case 1: case 3: case 5: { // A!=B
             return false;
    } // end switch case1 A != B
    case 2: case 4 :{ // A > B , A >= B
                if(signqb==0||signqb==2||signqb==4){   // A=3  and b=2 ,b > 2, b >= 1
                  if(Integer.parseInt(valqb) >= Integer.parseInt(valqa)) return true;
                  break;
                }
                else if(signqb==8){   // x <= B <= y
                  if (Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) >= Integer.parseInt(valqa))
                  return true;       //x >= valqa
                  break;
                }
                else return false;
    } // end case // A > B , A>=B
    default : return false;
  }// end Switch sign inter attribute
  return false;
}/// end lessattq

boolean moreattq(String valqa,int signdb,int signqb,String valqb){
  switch(signdb){
    case 0:case 3:case 5: {
            if(signqb==0||signqb==3||signqb==5)
            { if(Integer.parseInt(valqb) <= Integer.parseInt(valqa))  return true;}
            else
            if(signqb==8)
              if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) <= Integer.parseInt(valqa))  return true;
             }
            }
  return false;
} // end moreattq
boolean lesseqlattq(String valqa,int signdb,int signqb,String valqb){
//A < valqa
  switch(signdb){
    case 0:{  //  A = B
        switch(signqb){
          case 0: if(Integer.parseInt(valqb)> Integer.parseInt(valqa)) return true;  break;   // B = valqb
          case 1: return false; // B != valqb
          case 2: if(Integer.parseInt(valqb)>= Integer.parseInt(valqa)) return true; break;    // B > valqb
          case 3: return false;    // B < valqb
          case 4: if(Integer.parseInt(valqb)> Integer.parseInt(valqa)) return true; break;    // B >= valqb
          case 5: return false;    // B <= valqb
          case 8: if (Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) > Integer.parseInt(valqa))
                  return true;   // x <= B <= y
                  break;
          default: return false;  }
          break;
    } // end switch  case0  A=B
    case 1: case 3: case 5: { // A!=B
             return false;
    } // end switch case1 A != B
    case 2 :{ // A > B
             if(signqb==0||signqb==2||signqb==4){   // A=3  and b=2 ,b > 2, b >= 1
             if(Integer.parseInt(valqb) >= Integer.parseInt(valqa)) return true;
             break;
             }
             else if(signqb==8){   // x <= B <= y
             if (Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) >= Integer.parseInt(valqa))
             return true;       //x >= valqa
             break;
             }
             else return false;
    } // end case // A > B , A>=B
  case 4 :{ // A >= B
             if(signqb==0 || signqb==4){   // A=3  and b=2 ,b > 2, b >= 1
             if(Integer.parseInt(valqb) > Integer.parseInt(valqa)) return true;
             break;
           }
             else if(signqb==2){
             if(Integer.parseInt(valqb) >= Integer.parseInt(valqa)) return true;
             break;
           }
             else if(signqb==8){   // x <= B <= y
             if (Integer.parseInt(valqb.substring(0,valqb.indexOf("/"))) > Integer.parseInt(valqa))
             return true;       //x >= valqa
             break;
             }
           else return false;
    } // end case // A > B , A>=B
    default : return false;
  }// end Switch sign inter attribute
  return false;
}/// end lesseqlattq
boolean moreeqlattq(String valqa,int signdb,int signqb,String valqb){
  switch(signdb){
    case 0:case 5:{
       switch(signqb){
           case 0:case 5:
            if(Integer.parseInt(valqb) < Integer.parseInt(valqa))  return true; break;
           case 3:
           if(Integer.parseInt(valqb) <= Integer.parseInt(valqa))  return true; break;
           case 8:
           if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) < Integer.parseInt(valqa))  return true;
            break;
            default: break;
           }     break; }// end case0 and 5 of signFDdatabase

    case 3:{
      if(signqb==0||signqb==3||signqb==5)
          { if(Integer.parseInt(valqb) <= Integer.parseInt(valqa))  return true;}
          else
          if(signqb==8)
            if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) <= Integer.parseInt(valqa))  return true;
           break;
           } // end case 3 of SignFDdatabase
    default: break;
  }
  return false;
} // end moreeqlattq

boolean bwattq(String valqa,int signdb,int signqb,String valqb){
  int rig=Integer.parseInt(valqa.substring(valqa.indexOf("/")+1));
  int lef=Integer.parseInt(valqa.substring(0,valqa.indexOf("/")));
  switch(signdb){
    case 0:{   //A=B
      switch(signqb){
      case 0: if((lef > Integer.parseInt(valqb)) || Integer.parseInt(valqb) > rig)  return true; break;
      case 2: if(Integer.parseInt(valqb) >= rig)  return true; break;
      case 3: if(Integer.parseInt(valqb) > rig)  return true; break;
      case 4: if(Integer.parseInt(valqb) <= lef)  return true; break;
      case 5: if(Integer.parseInt(valqb) < lef)  return true; break;
      case 8:if(Integer.parseInt(valqb.substring(0,valqb.indexOf("/")))>rig || Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) < lef  )  return true;
            break;
      default: break;
           }  break; }// end case0 of signFDdatabase

    case 2:{
      if(signqb==0||signqb==2||signqb==4)
          { if(Integer.parseInt(valqb) >= rig)  return true;}
      else
      if(signqb==8)
            if(Integer.parseInt(valqb.substring(0,valqb.indexOf("/")))>= rig )  return true;
      break;
           } // end case 2 of SignFDdatabase
     case 4:{
       switch(signqb){
         case 0:case 4: if(Integer.parseInt(valqb) > rig)  return true; break;
         case 2: if(Integer.parseInt(valqb) >= rig)  return true; break;
         case 8: if(Integer.parseInt(valqb.substring(0,valqb.indexOf("/")))> rig )  return true;
                 break;
         default:  break;
       }// end switch
        break;
     }    // end case 4 of SignFDdatabase
   case 3:{
if(signqb==0||signqb==3||signqb==5)
    { if(Integer.parseInt(valqb) <= lef)  return true;}
else
if(signqb==8)
      if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) <= lef)  return true;
break;
     } // end case 2 of SignFDdatabase
case 5:{
 switch(signqb){
   case 0:case 4: if(Integer.parseInt(valqb) < lef)  return true; break;
   case 2: if(Integer.parseInt(valqb) <= lef)  return true; break;
   case 8: if(Integer.parseInt(valqb.substring(valqb.indexOf("/")+1)) < lef)  return true;
           break;
   default:  break;
 }// end switch
  break;
     }    // end case 4 of SignFDdatabase

    default: break;
  }
  return false;
} // end moreeqlattq

///---------------------------------------------------------
  void jClrOld_actionPerformed(ActionEvent e) {
    jTextOld.setText("");
    jTimeOld.setText("");
    jTextNew.setText("");
    jTimeNew.setText("");
    jrownew.setText("");
    jrowold.setText("");
    init_var();
    try{
    tableset1.setQuery("select null");
    tableset2.setQuery("select null");
    }
    catch(SQLException sqlException){
    JOptionPane.showMessageDialog(null,sqlException.getMessage() ,"Database Error",JOptionPane.ERROR_MESSAGE);
    this.init_var();
    }
  }
}