package sqoproj;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
//import javax.swing.border.*;
//import java.util.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class fd_con extends JFrame {
  String attr1,tbl1,val1,attr2,tbl2,val2,val3,val4,val5,val6;
  int sign1,sign2,sign3,sign4,sign5,sign6,type=0;
  String temp1,temp2,temp3,temp4,temp5,temp6,pred1,pred2;
  boolean press=true,start=false;
  ResultSet tmpset;
  checkatt check = new checkatt();
  dblink dbconnt = new dblink();
  dblinktb dbconnttb = new dblinktb();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private JTextField valtext1 = new JTextField();
  private JComboBox jComboBox1 = new JComboBox();
  private XYLayout xYLayout2 = new XYLayout();
  private XYLayout xYLayout3 = new XYLayout();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JLabel jLabel6 = new JLabel();
  private JPanel jPanel2 = new JPanel();
  private JComboBox jComboBox2 = new JComboBox();
  private JTextField valtext21 = new JTextField();
  private XYLayout xYLayout4 = new XYLayout();
  private JLabel jLabel7 = new JLabel();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private JTextField valtext22 = new JTextField();
  private JComboBox jComboBox3 = new JComboBox();
  private JLabel jLabel10 = new JLabel();
  private JLabel jLabel11 = new JLabel();
  private JButton buttonpred1 = new JButton();
  private JLabel jLabel5 = new JLabel();
  private JButton buttonpred2 = new JButton();
  private JLabel jLabel12 = new JLabel();
  private JTextArea showarea = new JTextArea();
  private JButton okmain = new JButton();
  private JButton bcancle = new JButton();
  private ButtonGroup radioGroup;
  private JButton ok1 = new JButton();
  private JButton ok2 = new JButton();
  private JComboBox jComboBox5 = new JComboBox();
  private JComboBox jComboBox6 = new JComboBox();
  private JComboBox jcombotable = new JComboBox();


  public fd_con() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
     this.setSize(new Dimension(660, 500));
    jLabel1.setText("Funtional Dependency Constraint");
    this.getContentPane().setLayout(xYLayout1);
    jPanel1.setLayout(xYLayout2);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    xYLayout3.setWidth(436);
    xYLayout3.setHeight(349);
    jLabel4.setText("Sign");
    jLabel3.setText("Attribute");
    jLabel2.setText("TABLE1");
    xYLayout1.setWidth(660);
    xYLayout1.setHeight(472);
    jRadioButton1.setText("=,<,>,<=,>=");
    jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jRadioButton1_actionPerformed(e);
      }
    });
    jLabel6.setText("Value");
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setLayout(xYLayout4);
    jLabel7.setText("Attribute");
    jRadioButton2.setText("value1< x <value2");
    jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jRadioButton2_actionPerformed(e);
      }
    });
    jLabel8.setText("Sign1");
    jLabel9.setToolTipText("");
    jLabel9.setText("value1");
    jLabel10.setText("value2");
    jLabel10.setToolTipText("");
    jLabel11.setText("Sign2");
    buttonpred1.setText("Predicate1");
    buttonpred1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonpred1_actionPerformed(e);
      }
    });
    buttonpred1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonpred1_actionPerformed(e);
      }
    });
    jLabel5.setText("-->");
    buttonpred2.setText("Predicate2");
    buttonpred2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonpred2_actionPerformed(e);
      }
    });
    buttonpred2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonpred2_actionPerformed(e);
      }
    });
    jLabel12.setText("Display Constraint");
    showarea.setBorder(BorderFactory.createLoweredBevelBorder());
    okmain.setText("OK");
    okmain.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okmain_actionPerformed(e);
      }
    });

    bcancle.setText("Cancel");
    bcancle.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bcancle_actionPerformed(e);
      }
    });

    ok1.setText("OK");
    ok1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok1_actionPerformed(e);
      }
    });
    ok2.setText("OK");
    ok2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok2_actionPerformed(e);
      }
    });

    jPanel1.add(jRadioButton1, new XYConstraints(12, 5, 82, 20));
    jPanel1.add(jComboBox1, new XYConstraints(251, 39, 50, 22));
    jPanel1.add(jLabel4, new XYConstraints(256, 14, -1, -1));
    jPanel1.add(jLabel6, new XYConstraints(322, 14, -1, -1));
    jPanel1.add(valtext1, new XYConstraints(317, 40, 93, -1));
    jPanel1.add(ok1, new XYConstraints(439, 37, 53, 23));
    jPanel1.add(jLabel3,  new XYConstraints(113, 16, -1, -1));
    jPanel1.add(jComboBox5, new XYConstraints(111, 39, 120, -1));
    this.getContentPane().add(jPanel2,     new XYConstraints(35, 213, 592, 79));
    jPanel2.add(jRadioButton2, new XYConstraints(10, 7, 114, 20));
    jPanel2.add(valtext21, new XYConstraints(130, 43, 70, -1));
    jPanel2.add(jComboBox2,  new XYConstraints(207, 43, 50, 22));
    jPanel2.add(jLabel8, new XYConstraints(206, 20, -1, -1));
    jPanel2.add(jComboBox6,   new XYConstraints(265, 42, 118, -1));
    jPanel2.add(ok2, new XYConstraints(529, 41, -1, 23));
    jPanel2.add(valtext22,  new XYConstraints(450, 41, 70, 22));
    jPanel2.add(jComboBox3,   new XYConstraints(391, 42, 50, 22));
    jPanel2.add(jLabel11,  new XYConstraints(389, 18, -1, -1));
    jPanel2.add(jLabel10, new XYConstraints(452, 16, -1, -1));
    jPanel2.add(jLabel7, new XYConstraints(264, 18, -1, -1));
    jPanel2.add(jLabel9, new XYConstraints(137, 19, -1, -1));
    this.getContentPane().add(jLabel12,   new XYConstraints(38, 309, 107, 20));
    this.getContentPane().add(buttonpred1, new XYConstraints(218, 70, -1, 32));
    this.getContentPane().add(jPanel1,  new XYConstraints(35, 122, 591, 76));
    this.getContentPane().add(jLabel5, new XYConstraints(324, 76, 38, 19));
    this.getContentPane().add(buttonpred2, new XYConstraints(351, 70, 94, 32));
    this.getContentPane().add(jLabel1, new XYConstraints(219, 15, 192, 36));
    this.getContentPane().add(showarea,    new XYConstraints(38, 347, 556, 64));
    this.getContentPane().add(jLabel2, new XYConstraints(37, 49, 47, -1));
    this.getContentPane().add(jcombotable,    new XYConstraints(39, 70, 135, 23));
    this.getContentPane().add(bcancle,  new XYConstraints(516, 432, 74, 26));
    this.getContentPane().add(okmain,  new XYConstraints(414, 432, 86, 26));
    this.setTitle("FUNTIONAL DEPENDENCY CONSTRAINTS");
    this.setLocation(50,50);
    jComboBox1.addItem("=");
    jComboBox1.addItem("!=");
    jComboBox1.addItem(">") ;
    jComboBox1.addItem("<") ;
    jComboBox1.addItem(">=");
    jComboBox1.addItem("<=");
    jComboBox1.addItem("in");
    jComboBox2.addItem("<");
    jComboBox2.addItem("<=");
    jComboBox3.addItem("<");
    jComboBox3.addItem("<=");
    this.tbinit();
    this.init();

  }
  void init(){
   ok1.setEnabled(false);
   buttonpred1.setEnabled(true);
   buttonpred2.setEnabled(false);
   ok2.setEnabled(false);
   jComboBox1.setEnabled(false);
   valtext1.setEnabled(false);
   jComboBox2.setEnabled(false);
   valtext21.setEnabled(false);
   valtext22.setEnabled(false);
   jComboBox3.setEnabled(false);
   jComboBox5.setEnabled(false);
   jComboBox6.setEnabled(false);
   jRadioButton1.setEnabled(false);
   jRadioButton2.setEnabled(false);
   jComboBox1.setSelectedIndex(-1);
   jComboBox2.setSelectedIndex(-1);
   jComboBox3.setSelectedIndex(-1);
   showarea.setText("");
   radioGroup = new ButtonGroup();
   radioGroup.add(jRadioButton1);
   radioGroup.add(jRadioButton2);
  }
  void clear(){
    valtext1.setText("");
    valtext21.setText("");
    valtext22.setText("");
    jComboBox1.setSelectedIndex(-1);
    jComboBox2.setSelectedIndex(-1);
    jComboBox3.setSelectedIndex(-1);
    jcombotable.setSelectedIndex(0);
    jComboBox5.setSelectedIndex(-1);
    jComboBox6.setSelectedIndex(-1);
   // jTextArea2.setText("");
  }
 public void tbinit(){
    try{
      String SQL ="SELECT DISTINCT table_name FROM information_schema.columns WHERE table_name in (select table_name FROM Information_Schema.Tables WHERE Table_Type='Base Table'and table_name <> 'dtproperties') ORDER BY table_name";
      tmpset = dbconnttb.GetResultset(SQL);
      int i=0;
      String t="";
      tmpset.first();
      String k=tmpset.getString(1);
      jcombotable.addItem(k) ;
      while (tmpset.next()) {
        k=tmpset.getString(1);
        jcombotable.addItem(k) ;
      }
      jcombotable.addItemListener(new java.awt.event.ItemListener() {
        public void itemStateChanged(ItemEvent e) {
          jcombotable_actionPerformed(e);
        }
      });
    }
      catch (SQLException sqlException){
        JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE);
        System.exit(1);
      }
}

void  getatt(JComboBox combo,JComboBox combo1){
  try {
   combo.removeAllItems();
   String tabname= ""+ combo1.getSelectedItem();
   String SQL2 ="SELECT * FROM "+ tabname +" ";
   tmpset = dbconnttb.GetResultset(SQL2);
   tmpset.first();
   ResultSetMetaData metaD=tmpset.getMetaData();
   int numbc = metaD.getColumnCount();
   for(int loop=1 ; loop <= numbc ; loop++)
   combo.addItem(""+ metaD.getColumnName(loop));
   }
    catch (SQLException sqlException ){
    JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
    System.exit(1);
    }
}

public void checkin(String valueatt,int type){
  int st=0;
   StringBuffer test =new StringBuffer();
   test.append(valueatt);
   boolean count=true;
   while((valueatt.indexOf("'",st) != -1)&&(count)){
     test.insert(valueatt.indexOf("'",st),"'");
     valueatt = test.toString();
     if(valueatt.length() > valueatt.indexOf("'",st) + 2)
     st=valueatt.indexOf("'",st) + 2;
     else {
       count=false;
       if(type==1)
       val1 = valueatt;
       if(type==2)
       val2 = valueatt;
     }
    }
}
  void jRadioButton1_actionPerformed(ActionEvent e) {
    if(jRadioButton1.isSelected()){
      jComboBox5.setEnabled(true);
      jComboBox1.setEnabled(true);
      valtext1.setEnabled(true);
      ok1.setEnabled(true);
      ok2.setEnabled(false);
      jComboBox6.setEnabled(false);
      jComboBox2.setEnabled(false);
      valtext21.setEnabled(false);
      valtext22.setEnabled(false);
      jComboBox3.setEnabled(false);
      this.getatt(jComboBox5,jcombotable);
      jComboBox6.setSelectedIndex(-1);
      type=1;
    }
  }

  void jRadioButton2_actionPerformed(ActionEvent e) {
    if(jRadioButton2.isSelected()){
      jComboBox5.setEnabled(false);
      jComboBox1.setEnabled(false);
      valtext1.setEnabled(false);
      ok1.setEnabled(false);
      ok2.setEnabled(true);
      jComboBox6.setEnabled(true);
      jComboBox2.setEnabled(true);
      valtext21.setEnabled(true);
      valtext22.setEnabled(true);
      jComboBox3.setEnabled(true);
      this.getatt(jComboBox6,jcombotable);
      jComboBox5.setSelectedIndex(-1);
      type=2;
    }
  }



  void buttonpred1_actionPerformed(ActionEvent e) {
    jRadioButton1.setEnabled(true);
    jRadioButton2.setEnabled(true);
  }

  void buttonpred2_actionPerformed(ActionEvent e) {
    jRadioButton1.setEnabled(true);
    jRadioButton2.setEnabled(true);
  }


  void okmain_actionPerformed(ActionEvent e) {
    String temp;
    temp1=val1;
    temp2=val2;
    this.checkin(temp1,1);
    this.checkin(temp2,2);
    if((!showarea.getText().equals("")) && (!attr1.equals("")) && (!attr2.equals("")) && (!tbl1.equals("")) && (!tbl2.equals("")) && sign1 != -1 && sign2 != -1 && (!val1.equals("")) && (!val2.equals(""))){
      String fdsql = "INSERT INTO fd_const VALUES ('" +
                   attr1 + "','" + tbl1 + "'," + sign1 + ",'" + val1 + "','" +
                   attr2 + "','" + tbl2 + "'," + sign2 + ",'" + val2 + "')";
      dbconnt.InsertData(fdsql);
      this.init();
      jLabel2.setText("TABLE1");
    }
    else{
      JOptionPane.showMessageDialog(null,"   Input Invalid");
    }
  }

  void bcancle_actionPerformed(ActionEvent e) {
    showarea.setText("");
    this.init();
    jLabel2.setText("TABLE1");
  }

  void ok1_actionPerformed(ActionEvent e) {
  String text_const = "";
  if((!jComboBox5.getSelectedItem().equals(""))&&(jComboBox1.getSelectedIndex()!=-1 )&&(!valtext1.getText().equals(""))){
   if(press && !start ){  // predicate1
     attr1 = ""+ jComboBox5.getSelectedItem();
     sign1 = jComboBox1.getSelectedIndex();
     temp1 = ""+jComboBox1.getSelectedItem();
     val1 = valtext1.getText();
     tbl1 = ""+ jcombotable.getSelectedItem();
     pred1=attr1+" "+temp1 +" "+val1;
     if(sign1==6) sign1 = 10;
     if(check.compare(attr1,tbl1,sign1,val1))
     {System.out.println("compare pass\n");
     clear();
     init();
     press = false;
     start = true;
     jLabel2.setText("TABLE2");
     buttonpred2.setEnabled(true);
     buttonpred1.setEnabled(false);
     }
     else {JOptionPane.showMessageDialog(null,"Values contradict"); }
   }           //end predicate1
  else{ // predicate2
    attr2 = ""+ jComboBox5.getSelectedItem();
    sign2 = jComboBox1.getSelectedIndex();
    temp2 = ""+jComboBox1.getSelectedItem();
    val2 = valtext1.getText();
    tbl2 = ""+ jcombotable.getSelectedItem();
    pred2 =attr2+" "+temp2 +" "+val2;
    if(sign2==6) sign2 = 10;
    if(check.compare(attr2,tbl2,sign2,val2))
    {
    System.out.println("compare pass\n");
    clear();
    init();
    press =true;
    start =false;
    text_const =  "         "+pred1+"  ->  "+pred2 ;
    showarea.setText(text_const) ;
    temp1 ="";
    temp2 ="";
    }
    else {JOptionPane.showMessageDialog(null,"Values contradict");}

  }
    radioGroup.remove(jRadioButton1);
    radioGroup.remove(jRadioButton2);
    jRadioButton1.setSelected(false);
    jRadioButton2.setSelected(false);
    radioGroup.add(jRadioButton1);
    radioGroup.add(jRadioButton2);

/*    if((press)){
      text_const =  "         "+pred1+"  ->  "+pred2 ;
      jTextArea2.setText(text_const) ;
      temp1 ="";
      temp2 ="";  }*/

  }  // if input valid
  else // input invalid
      JOptionPane.showMessageDialog(null,"   Input Invalid");

}

void ok2_actionPerformed(ActionEvent e) {
    String text_const = "";
    if((!jComboBox6.getSelectedItem().equals(""))&&(jComboBox2.getSelectedIndex()!=-1 )&&(jComboBox3.getSelectedIndex()!=-1 )&&(!valtext21.getText().equals(""))&&(!valtext22.getText().equals(""))){

         int vall,valr;
         vall= Integer.parseInt(valtext21.getText());
         valr= Integer.parseInt(valtext22.getText());
       ////////////////
      if(vall < valr){
        if(press && !start){
          attr1 = ""+ jComboBox6.getSelectedItem();
          sign3 = jComboBox2.getSelectedIndex();
          sign4 = jComboBox3.getSelectedIndex();
          temp3 = ""+jComboBox2.getSelectedItem();
          temp4 = ""+jComboBox3.getSelectedItem();
          val3 = valtext21.getText();
          val4 = valtext22.getText();
          tbl1 = ""+ jcombotable.getSelectedItem();
          pred1=val3+temp3+attr1+temp4 +val4;
          if(sign3 == 0 && sign4 == 0)sign1 = 6;   //  </<
          if(sign3 == 0 && sign4 == 1)sign1 = 7;    //  </<=
          if(sign3 == 1 && sign4 == 1)sign1 = 8;   //  <=/<=
          if(sign3 == 1 && sign4 == 0)sign1 = 9;  //  <=/<
          val1 = val3+"/"+val4;
          if(check.compare(attr1,tbl1,sign1,val1))
          {System.out.println("compare pass\n");
           clear();
           init();
           press = false;
           start = true;
           buttonpred2.setEnabled(true);
           buttonpred1.setEnabled(false);
           jLabel2.setText("TABLE2");}
          else JOptionPane.showMessageDialog(null,"Values contradict");

        }
       else{ // TABLE2
         attr2 = ""+ jComboBox6.getSelectedItem();
         sign5 = jComboBox2.getSelectedIndex();
         sign6 = jComboBox3.getSelectedIndex();
         temp5 = ""+jComboBox2.getSelectedItem();
         temp6 = ""+jComboBox3.getSelectedItem();
         val5 = valtext21.getText();
         val6 = valtext22.getText();
         tbl2 = ""+ jcombotable.getSelectedItem();
        pred2=val5+temp5+attr2+temp6 +val6;
         if(sign5 == 0 && sign6 == 0)sign2 = 6;     //  </<
         if(sign5 == 0 && sign6 == 1)sign2 = 7;   //  </<=
         if(sign5 == 1 && sign6 == 1)sign2 = 8;  //  <=/<=
         if(sign5 == 1 && sign6 == 0)sign2 = 9; //  <=/<
         val2 = val5+"/"+val6;
         if(check.compare(attr2,tbl2,sign2,val2))
         {System.out.println("compare pass\n");
          clear();
          init();
          press =true;
          start =false;
          text_const =  "  "+pred1+"  ->  "+pred2 ;
          showarea.setText(text_const) ;
          temp1 ="";
          temp2 =""; }
         else JOptionPane.showMessageDialog(null,"Values contradict");
         } // end else table2

       radioGroup.remove(jRadioButton1);
       radioGroup.remove(jRadioButton2);
       jRadioButton1.setSelected(false);
       jRadioButton2.setSelected(false);
       radioGroup.add(jRadioButton1);
       radioGroup.add(jRadioButton2);
     //  jcombotable.setSelectedIndex(0);

     /*  if(press){
         text_const =  "  "+pred1+"  ->  "+pred2 ;
         jTextArea2.setText(text_const) ;
         temp1 ="";
         temp2 =""; }*/
      }

      else { JOptionPane.showMessageDialog(null,"value not match");}
    //////////////////////////

    }
    else {
    JOptionPane.showMessageDialog(null,"   Input Invalid");
    }

}

  void jcombotable_actionPerformed(ItemEvent e) {
    if(e.getStateChange() == ItemEvent.SELECTED ){
    switch (type){
       case 1: {
         this.getatt(jComboBox5,jcombotable) ;
         jComboBox6.setSelectedIndex(-1);
         break;
       }
       case 2: {
         this.getatt(jComboBox6,jcombotable) ;
         jComboBox6.setSelectedIndex(-1);
         break;
       }
       default:
    }
    }
  }

}