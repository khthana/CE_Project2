package sqoproj;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame1 extends JFrame {
  private JPanel contentPane;
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private XYLayout xYLayout2 = new XYLayout();
  type_const typeframe = new type_const();
  us_query user = new us_query();
  admin passw = new admin();

  //Construct the frame
  public Frame1() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    jLabel1.setText("SELECT MODE");
    contentPane.setLayout(xYLayout2);
    this.setSize(new Dimension(400, 300));
    this.setTitle("MODE");
    jButton1.setText("ADMINISTRATOR INSERT CONSTRAINT");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setText("USER INSERT QUERY");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });

    contentPane.add(jButton1, new XYConstraints(66, 93, -1, -1));
    contentPane.add(jButton2,  new XYConstraints(67, 154, 260, -1));
    contentPane.add(jLabel1, new XYConstraints(148, 39, -1, -1));
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    passw.show();

  }

  void jButton2_actionPerformed(ActionEvent e) {
    user.show();
  }

}