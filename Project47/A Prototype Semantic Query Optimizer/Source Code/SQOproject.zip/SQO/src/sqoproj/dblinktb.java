package sqoproj;

import java.sql.*;
import javax.swing.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class dblinktb {
  Connection connection;
  Statement statement;
  String connectname="sun.jdbc.odbc.JdbcOdbcDriver";
  public dblinktb() {
      try{
           int x;
           Class.forName(connectname);
           connection = DriverManager.getConnection("jdbc:odbc:SQODB","sa","uahara");
           statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
         }catch(SQLException sqlException){
           JOptionPane.showMessageDialog(null,sqlException.toString(),"Error",JOptionPane.ERROR_MESSAGE);
         }catch(ClassNotFoundException classNotFound){
           classNotFound.toString();
         }
  }

  public ResultSet GetResultset(String squery) {
  try{
     return statement.executeQuery(squery);
   }catch(SQLException sqlException){
     JOptionPane.showMessageDialog(null,sqlException.toString(),"Error",JOptionPane.ERROR_MESSAGE);
     return null;
   }
  }

  public void InsertData(String sinst) {
  try{
    statement.executeUpdate(sinst);
  }catch(SQLException sqlException){
    JOptionPane.showMessageDialog(null,sqlException.toString(),"Insert Error",JOptionPane.ERROR_MESSAGE);
  }
  }

  public void Delete(String sql) {
    try{
     statement.executeUpdate(sql);
     connection.commit();
   }catch(SQLException sqlException){
     JOptionPane.showMessageDialog(null,sqlException.toString(),"Delete Error",JOptionPane.ERROR_MESSAGE);
  }
  }

  public void closedb(){
  try{
    statement.close();
    connection.close();
  }catch (SQLException sqlException){
    JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE);
   }System.exit(1);
  }


}