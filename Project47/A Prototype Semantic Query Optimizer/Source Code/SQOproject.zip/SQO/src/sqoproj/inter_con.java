package sqoproj;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class inter_con extends JFrame {
  String tb1;
  String tb2;
  String attr1;
  String attr2;
  int sign;
  ResultSet tmpset;
  dblink dbconnt = new dblink();
  dblinktb dbconnttb = new dblinktb();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private JLabel jLabel3 = new JLabel();
  private XYLayout xYLayout2 = new XYLayout();
  private JComboBox jComboBox1 = new JComboBox();
  private JLabel jLabel4 = new JLabel();
  private JButton jButton1 = new JButton();
  private JLabel jLabel5 = new JLabel();
  private JButton jButton2 = new JButton();
  private JButton jButton3 = new JButton();
  private JLabel jLabel6 = new JLabel();
  private JComboBox jComboBox2 = new JComboBox();
  private JComboBox jComboBox3 = new JComboBox();
  private JComboBox jComboBox4 = new JComboBox();
  private JComboBox jComboBox5 = new JComboBox();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea jTextArea1 = new JTextArea();
  private JPanel jPanel2 = new JPanel();

  public inter_con() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    jLabel1.setText("Inter-Attribute Constraint");
    this.getContentPane().setLayout(xYLayout1);
    jLabel2.setText("TABLE1");
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(xYLayout2);
    jLabel3.setText("Attribute1");
    jLabel4.setText("Attribute2");
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jLabel5.setText("Display Constraint");
    xYLayout1.setWidth(453);
    xYLayout1.setHeight(380);
    jButton2.setText("OK");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setText("Cancel");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jLabel6.setText("TABLE2");
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    this.getContentPane().add(jPanel1,         new XYConstraints(26, 130, 371, 80));
    jPanel1.add(jComboBox1,   new XYConstraints(127, 47, 61, -1));
    jPanel1.add(jLabel4, new XYConstraints(201, 22, -1, -1));
    jPanel1.add(jLabel3, new XYConstraints(14, 22, -1, -1));
    jPanel1.add(jButton1,              new XYConstraints(305, 48, 52, 22));
    jPanel1.add(jComboBox4, new XYConstraints(14, 50, 91, 20));
    jPanel1.add(jComboBox5, new XYConstraints(202, 48, 91, 20));
    this.getContentPane().add(jLabel2, new XYConstraints(25, 45, 46, 23));
    this.getContentPane().add(jComboBox3,    new XYConstraints(27, 74, 147, 22));
    this.getContentPane().add(jComboBox2, new XYConstraints(215, 73, 149, 24));
    this.getContentPane().add(jLabel6, new XYConstraints(212, 41, 46, 23));
    this.getContentPane().add(jLabel1,  new XYConstraints(134, 3, 136, 36));
    this.getContentPane().add(jScrollPane1,   new XYConstraints(31, 265, 279, 99));
    this.getContentPane().add(jPanel2,    new XYConstraints(21, 255, 299, 119));
    this.getContentPane().add(jLabel5,  new XYConstraints(19, 224, 104, 22));
    this.getContentPane().add(jButton3, new XYConstraints(331, 335, 76, 26));
    this.getContentPane().add(jButton2, new XYConstraints(330, 304, 76, 24));
    jScrollPane1.getViewport().add(jTextArea1, null);
    this.setSize(new Dimension(440, 450));
    this.setTitle("INTER-ATTRIBUTE CONSTRAINT");
    this.setLocation(150,100);
    jComboBox1.addItem("=");
    jComboBox1.addItem("!=");
    jComboBox1.addItem(">") ;
    jComboBox1.addItem("<") ;
    jComboBox1.addItem(">=");
    jComboBox1.addItem("<=");
    jComboBox1.setSelectedIndex(-1);
    this.tbinit();
    this.init();

  }
  void init(){
    jComboBox1.setSelectedIndex(-1);
    jComboBox2.setSelectedIndex(0);
    jComboBox3.setSelectedIndex(0);
    tb1="";
    tb2="";
    attr1="";
    attr2="";
    sign=-1;
  }

  public void tbinit(){
      try{
        String SQL ="SELECT DISTINCT table_name FROM information_schema.columns WHERE table_name in (select table_name FROM Information_Schema.Tables WHERE Table_Type='Base Table'and table_name <> 'dtproperties') ORDER BY table_name";
        tmpset = dbconnttb.GetResultset(SQL);
        int i=0;
        String t="";
        tmpset.first();
        String k=tmpset.getString(1);
        jComboBox2.addItem(k) ;
        jComboBox3.addItem(k) ;
        while (tmpset.next()) {
          k=tmpset.getString(1);
          jComboBox2.addItem(k) ;
          jComboBox3.addItem(k) ;
        }
      jComboBox3.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
          jComboBox3_actionPerformed(e);
        }
    });
      jComboBox2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
          jComboBox2_actionPerformed(e);
        }
    });

      }
        catch (SQLException sqlException){
          JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE);
          System.exit(1);
        }
}

void  getatt(JComboBox combo,JComboBox combo1){
  try {
   combo.removeAllItems();
   String tabname= ""+ combo1.getSelectedItem();
   String SQL2 ="SELECT * FROM "+ tabname +" ";
   tmpset = dbconnttb.GetResultset(SQL2);
   tmpset.first();
   ResultSetMetaData metaD=tmpset.getMetaData();
   int numbc = metaD.getColumnCount();
   for(int loop=1 ; loop <= numbc ; loop++)
   combo.addItem(""+ metaD.getColumnName(loop));
   }
    catch (SQLException sqlException ){
    JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
    System.exit(1);
    }
}
  void jButton1_actionPerformed(ActionEvent e) {

    String text_const ="";
    attr1 = ""+jComboBox4.getSelectedItem();
    attr2 = ""+jComboBox5.getSelectedItem();
    tb1 = ""+jComboBox3.getSelectedItem();
    tb2 = ""+jComboBox2.getSelectedItem();
    sign = jComboBox1.getSelectedIndex();
    if((!attr1.equals("")) && (!attr2.equals("")) && (!tb1.equals("")) && (!tb2.equals("")) && sign != -1){
      text_const =  "         "+""+jComboBox4.getSelectedItem()+jComboBox1.getSelectedItem()+""+jComboBox5.getSelectedItem();
      jTextArea1.setText(text_const);
    }
    else {
      JOptionPane.showMessageDialog(null,"   Input Invalid");
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    jTextArea1.setText("");
   /* String insql = "DELETE FROM inter_const WHERE sign in (-1,0,1,2,5)";
    dbconnt.Delete(insql);*/
  }

  void jButton2_actionPerformed(ActionEvent e) {
    if((!jTextArea1.getText().equals("")) && (!attr1.equals("")) && (!attr2.equals("")) && (!tb1.equals("")) && (!tb2.equals("")) && sign != -1){
    String insql = "INSERT INTO inter_const VALUES ('" +
          attr1 + "','" + attr2 + "','" + tb1 + "','" + tb2 + "', " + sign+ ")";
    dbconnt.InsertData(insql);
    this.init();
    }
    else{
       JOptionPane.showMessageDialog(null,"   Input Invalid");
    }
  }

  void jComboBox3_actionPerformed(ActionEvent e) {
    this.getatt(jComboBox4,jComboBox3);
  }

  void jComboBox2_actionPerformed(ActionEvent e) {
    this.getatt(jComboBox5,jComboBox2);
  }
}