package sqoproj;


import java.awt.*;
import java.sql.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.util.*;

public class checkatt {
  dblink dbcheck = new dblink();
ResultSet dbset;
  public checkatt() {

  }
public boolean compare(String addatt,String addtab,int addsign,String addval){
  String sql="select * from att_const where att= '"+ addatt +"' and tbl = '"+ addtab +"' ";
  dbset=dbcheck.GetResultset(sql);
  try{
    dbset.last();
   if(dbset.getRow()!= 0 ){

   int i=1;
   dbset.first();
   boolean con=true;
   int signdbc= dbset.getInt(3);
   dbset.first();
   System.out.println("attindb : "+dbset.getString(1)+
                      "\n table : "+dbset.getString(2)+
                      "\n sign : "+signdbc+
                      "\n value : "+dbset.getString(4)+
                      " - end - ");
  switch(addsign){
  case 0: System.out.println("case0");
          if(compeql(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break;   //'='
  case 1: System.out.println("case1");
          if(compnoteql(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'!='
  case 2: System.out.println("case2");//
          if(compmore(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break;  //'>'
  case 3: System.out.println("case3");//
          if(compless(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'<'
  case 4: System.out.println("case4");//
          if(compmoreeql(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'>='
  case 5: System.out.println("case5");//
          if(complesseql(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'<='
  case 6: System.out.println("case6");
          if(compbetween(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'<' -- '<'
  case 7:System.out.println("case7");//
          if(compbetweenr(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'<' -- '<='
  case 8:System.out.println("case8");//
          if(compbetweenlr(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'<=' -- '<='
  case 9: System.out.println("case9");//
          if(compbetweenl(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; //'<=' -- '<'
  case 10:System.out.println("case10");
          if(compin(dbset.getString(4).trim(),addval,signdbc))
          return true;
          break; // in
  default:  System.out.println("default");return false;
  }  // end switch

   // }  // end while
    return false;
  }
  else{
    System.out.println("no restrict constriant");
     return true;
  }
  }
    catch(SQLException sqlException ){
      System.out.print("error");
      JOptionPane.showMessageDialog(null,sqlException.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE );
      System.exit(1);
    }
  return false;
}

public boolean compeql(String valdb,String valadd,int signn){
switch (signn)
{
  case 0:  {  System.out.print("start");            //'='
              if(valdb.equals(valadd)) return true;
              System.out.print( valdb+" + "+ valadd);
              break;
           }
  case 1:  {
              if(valdb.equals(valadd)) return false;
              else return true;       //'!='
           }
  case 2:     if(Integer.parseInt(valadd) > Integer.parseInt(valdb))
              {  System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                 return true;}
              break;   //'>'
  case 3:  if(Integer.parseInt(valadd) < Integer.parseInt(valdb))
              {  System.out.print( Integer.parseInt(valadd)+" < "+ Integer.parseInt(valdb));
                 return true;}
           break;    //'<'
  case 4:  if(Integer.parseInt(valadd) >= Integer.parseInt(valdb))
                  {  System.out.print( Integer.parseInt(valadd)+" > "+ Integer.parseInt(valdb));
                 return true;}
          break;    //'>='
  case 5:
              if(Integer.parseInt(valadd) <= Integer.parseInt(valdb))
                  {  System.out.print( Integer.parseInt(valadd)+" < "+ Integer.parseInt(valdb));
                 return true;}
           break; //'<='
  case 6:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
              (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
           return true;
           break;
          //'<' -- '<'
  case 7:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd)) &&
              (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
          return true;
          break; //'<' -- '<='
  case 8:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
              (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd)))
           return true;
           break; //'<=' -- '<='
  case 9:  if((Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd)) &&
              (Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd)))
           return true;
           break; //'<=' -- '<'
  case 10: {
    //System.out.print("start");
          int ind=0;
          if(valdb.substring(1).equals("'"))
          {
          while(ind < valdb.length()){
            String word= valdb.substring(valdb.indexOf("'",ind)+1,valdb.indexOf("'",ind+1));
            if( word.equalsIgnoreCase(valadd)) return true;
            if (valdb.indexOf("'",valdb.indexOf("'",ind+1)+1) != -1)
            ind=(valdb.indexOf("'",valdb.indexOf("'",ind+1)+1)) ;
            else ind=valdb.length();
           }
          }  //if
          else
          { int end=0;
        if(valdb.indexOf(",") == -1){
        if( valdb.equalsIgnoreCase(valadd))
               return true; }
        else{
        boolean con=true;
        ind=0;
        end=(valdb.indexOf(",",1)) ;
        while(con){
        String word= valdb.substring(ind,end);
        System.out.print(word+" ");
        if( word.equalsIgnoreCase(valadd))
        { System.out.print(" ::true:: " +word);
          return true; }
        if(end==valdb.length()){
          System.out.print(" ::false:: " +word);
          con= false;
          return false; }
        ind=end+1;
        if (valdb.indexOf(",",ind+1) != -1)
          end=(valdb.indexOf(",",ind+1));
        else
          end=valdb.length();
          }
          }  // end else over one value
          }  //end else int or string
          break; // in}
          }
  default: return true;
}
return false;
}

public boolean compnoteql(String valdb,String valadd,int signn){
switch (signn)
{
  case 0:  System.out.print("start");            //'='
              if(!valdb.equals(valadd)) return true;
              System.out.print( valdb+" + "+ valadd);
              break;
  case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:  return true;
  default:  return true;
 }
return false;
}

public boolean compin(String valdb,String valadd,int signn){
switch (signn)
{
  case 0:                 //'='
          int ind1=1;
          if (valdb.indexOf("'",valdb.indexOf("'",ind1+1)+1) != -1)
            return false;
          else {
            if(valdb.equalsIgnoreCase(valadd)) return true;
               else return false;
                }
  case 10: {
    System.out.print("start in case 10");
          int ind=0,point=0;
          boolean have =false;
          while(point < valadd.length()){
            String subadd = valadd.substring(valadd.indexOf("'",point)+1,valadd.indexOf("'",point+1));
            System.out.print(" \n subadd :: "+subadd);
            ind=0;
            while(ind < valdb.length()){
            String word= valdb.substring(valdb.indexOf("'",ind)+1,valdb.indexOf("'",ind+1));
            if( word.equalsIgnoreCase(subadd)){
              have=true;
              return true;
            }
            if (valdb.indexOf("'",valdb.indexOf("'",ind+1)+1) != -1)
            ind=(valdb.indexOf("'",valdb.indexOf("'",ind+1)+1)) ;
            else ind=valdb.length();
            System.out.print(" | "+word+" :: "+subadd);
          }
          if (valadd.indexOf("'",valadd.indexOf("'",point+1)+1) != -1)
            point=(valadd.indexOf("'",valadd.indexOf("'",point+1)+1)) ;
            else point=valadd.length();
          }  // end while of valadd
          if (have)return true;
          else return false;        // in}
          }
   default: return true; }
}

public boolean compmore(String valdb,String valadd,int signn){
  int i,j;
   switch (signn){
     case 0:case 3:case 5:  if( Integer.parseInt(valdb) > Integer.parseInt(valadd))
                return true;  break;
     case 6:case 7:case 8:case 9:
     if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))
           return true;
           break;
    default : return true;
   }
return false;
}

public boolean compless(String valdb,String valadd,int signn){

   switch (signn){
     case 0:case 2:case 4:  if(Integer.parseInt(valdb) < Integer.parseInt(valadd))
          return true;  break;
     case 6:case 7:case 8:case 9:
     if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd))
           return true;
           break;
    default : return true;
   }
return false;

}
public boolean compmoreeql(String valdb,String valadd,int signn){
  int i,j;
   switch (signn){
     case 3: if( Integer.parseInt(valdb) > Integer.parseInt(valadd))
                return true;  break;
     case 0:case 5:  if( Integer.parseInt(valdb) >= Integer.parseInt(valadd))
                return true;  break;
     case 6:case 9:
     if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) > Integer.parseInt(valadd))
           return true;
           break;
     case 7:case 8:
     if(Integer.parseInt(valdb.substring(valdb.indexOf("/")+1)) >= Integer.parseInt(valadd))
           return true;
           break;

    default : return true;
   }
return false;
}
public boolean complesseql(String valdb,String valadd,int signn){
  int i,j;
   switch (signn){
     case 2: if(Integer.parseInt(valdb) < Integer.parseInt(valadd))
                return true;  break;
     case 0:case 4: if(Integer.parseInt(valdb) <= Integer.parseInt(valadd))
                return true;  break;
     case 6:case 7:
     if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) < Integer.parseInt(valadd))
           return true;
           break;
     case 8:case 9:
     if(Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))) <= Integer.parseInt(valadd))
           return true;
           break;

    default : return true;
   }
return false;
}

public boolean compbetween(String valdb,String valadd,int signn){
  switch(signn){
   case 0: if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb)
               && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
                 return true;
              break;
   case 2:case 4: if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
              return true;
              break;
  case 3:case 5: if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb))
    return true;
  case 6:case 7 :case 8:case 9: System.out.print("case6in between");

        if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
            && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
            || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
            && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
            || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
            && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
        return true;
        break;
   default: return true;
  }
  return false;
}
public boolean compbetweenl(String valdb,String valadd,int signn){  // <=  <

  switch(signn){
    case 0:  if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)
                && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
                 return true;
             break;
    case 2: System.out.print("case2");
            if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
            return true;
            break;
   case 3: if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb))
            return true;
            break;
   case 4:  System.out.print("case4");
      if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
            return true;
            break;
    case 5: System.out.print("case5");
            if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb))
            return true;
            break;
    case 6: System.out.print("case6");
            if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
            return true;
            break;

    case 7: System.out.print("case7");
            if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
             && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
             || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
              && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
             || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
              && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
              return true;
            break;

    case 8:  System.out.print("case8");
                        if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                            && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                            || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                            && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                            || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                            && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
             return true;
            break;
    case 9:System.out.print("case9");
                    if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                      && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                      || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                      && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                       || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                        && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
                                  return true;
            break;
    case 10:
    default: return true;
  }
  return false;
}
public boolean compbetweenlr(String valdb,String valadd,int signn){   // <=  <=
  switch(signn){
   case 0:  if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb)
            && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
            return true;
   case 2: System.out.print("case2");
         if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
         return true;
         break;
  case 3: if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb))
            return true;
            break;
   case 4:  System.out.print("case4");
         if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
         return true;
         break;
   case 5: System.out.print("case5");
         if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb))
         return true;
         break;
  case 6: System.out.print("case6");
            if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
            return true;
            break;

    case 7: System.out.print("case7");
            if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
             && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
             || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
              && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
             || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
              && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
              return true;
            break;

    case 8:  System.out.print("case8");
             if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
             && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
             || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
             && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
             || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
             && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
             return true;
            break;
    case 9:System.out.print("case8");
                    if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                      && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                      || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                      && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                       || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                        && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
                                  return true;
            break;
   default: return true;
  }
  return false;
}
public boolean compbetweenr(String valdb,String valadd,int signn){    //<  <=
  System.out.println("\n incase compare : "+valdb + " : " + valadd);
  switch(signn){
   case 0:  if(Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb)
               && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
                 return true;
                 break;
   case 2: System.out.print("case2");
       if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb))
       return true;
            break;
   case 3:case 5:
       if (Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb))
            return true;
            break;
   case 4:  System.out.print("case4");
   if (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb))
        return true;
        break;
   case 6: System.out.print("case6");
       if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
       && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
       || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
       && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
       || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
       && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
       return true;
   break;

     case 7: System.out.print("case7");
             if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
              && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
              || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
               && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
              || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
               && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
               return true;
             break;

     case 8:  System.out.print("case8");
         if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
         && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
         || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
         && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
         || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
         && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
          return true;
          break;
     case 9:System.out.print("case9");
                     if ((Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) < Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                        && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                        || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) <= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                        && Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) > Integer.parseInt(valdb.substring(0,valdb.indexOf("/"))))
                        || (Integer.parseInt(valadd.substring(valadd.indexOf("/")+1)) >= Integer.parseInt(valdb.substring(valdb.indexOf("/")+1))
                        && Integer.parseInt(valadd.substring(0,valadd.indexOf("/"))) <= Integer.parseInt(valdb.substring(0,valdb.indexOf("/")))))
            return true;
            break;
   default: return true;
  }
  return false;
}

///////////////
}  //end class
