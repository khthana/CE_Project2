package sqoproj;

import java.awt.*;
import java.sql.*;
import java.util.Timer;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class testtime extends JFrame {
dblinktb dbtemp = new dblinktb();
long firstTime,lastTime,elapseTime;
ResultSet resultSet;

  private JTextField text1 = new JTextField();
  private JTextField text2 = new JTextField();
  private JButton ok = new JButton();
  private JTextField first = new JTextField();
  private JTextField last = new JTextField();
  private JTextField elapse = new JTextField();
  private JTextField text3 = new JTextField();
  private JButton timefn = new JButton();
  private JTextField querytext = new JTextField();

  public testtime() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
public void timeofquery(){
firstTime = System.currentTimeMillis();
resultSet = dbtemp.GetResultset("SELECT * FROM  customer_tbl where cid < 2000 ");
lastTime  = System.currentTimeMillis();
elapseTime = lastTime-firstTime;
}
  private void jbInit() throws Exception {
    text1.setText("jTextField1");
    this.setSize(new Dimension(660, 500));
    text1.setBounds(new Rectangle(27, 41, 315, 33));
    this.getContentPane().setLayout(null);
    text2.setText("jTextField2");
    text2.setBounds(new Rectangle(25, 111, 317, 36));
    ok.setBounds(new Rectangle(55, 166, 66, 40));
    ok.setActionCommand("ok");
    ok.setText("jButton1");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    first.setText("jTextField3");
    first.setBounds(new Rectangle(41, 231, 117, 37));
    last.setText("jTextField4");
    last.setBounds(new Rectangle(163, 230, 101, 38));
    elapse.setText("jTextField5");
    elapse.setBounds(new Rectangle(273, 228, 95, 40));
    text3.setText("jTextField1");
    text3.setBounds(new Rectangle(189, 158, 95, 35));
    timefn.setBounds(new Rectangle(306, 171, 65, 38));
    timefn.setActionCommand("timefn");
    timefn.setText("jButton1");
    timefn.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        timefn_actionPerformed(e);
      }
    });
    querytext.setBounds(new Rectangle(41, 327, 459, 41));
    this.getContentPane().add(text1, null);
    this.getContentPane().add(text2, null);
    this.getContentPane().add(ok, null);
    this.getContentPane().add(first, null);
    this.getContentPane().add(last, null);
    this.getContentPane().add(elapse, null);
    this.getContentPane().add(text3, null);
    this.getContentPane().add(timefn, null);
    this.getContentPane().add(querytext, null);
  /*  firstTime = System.currentTimeMillis();
    resultSet = dbtemp.GetResultset("Select * from order_tbl");
    lastTime  = System.currentTimeMillis();
    elapseTime = lastTime-firstTime;
   text1.setText(firstTime+"");
   text2.setText(lastTime+"");
   text3.setText(elapseTime+"");
*/
  }

  void ok_actionPerformed(ActionEvent e) {

    firstTime = System.currentTimeMillis();
    resultSet = dbtemp.GetResultset(querytext.getText());
    lastTime  = System.currentTimeMillis();
    elapseTime = lastTime-firstTime;
    first.setText(firstTime+"");
    last.setText(lastTime+"");
    elapse.setText(elapseTime+"");

  }

  void timefn_actionPerformed(ActionEvent e) {

    timeofquery();
   first.setText(firstTime+":: 2");
    last.setText(lastTime+":: 2");
    elapse.setText(elapseTime+":: 2");
  }
}