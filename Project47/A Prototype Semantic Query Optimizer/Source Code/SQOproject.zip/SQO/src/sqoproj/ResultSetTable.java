package sqoproj;

import java.sql.*;
import java.util.*;
import javax.swing.table.*;

public class ResultSetTable extends AbstractTableModel{
  private Connection connection;
  private Statement statement;
  private ResultSet resultSet;
  private ResultSetMetaData metaData;
  private int numberOfRows;
  long firstTime,lastTime,elapseTime;  // for catch time

  private boolean connectedToDatabase = false;

  public ResultSetTable(String driver,String url,String query) throws SQLException, ClassNotFoundException
  {
    Class.forName(driver);
    connection = DriverManager.getConnection(url,"sa","uahara");
    statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

     connectedToDatabase = true;
     setQuery(query);
  }
  public Class getColumClass(int column)throws IllegalStateException{
    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to database");
    try{
      String className = metaData.getColumnClassName(column+1);
      return Class.forName( className );
    }
    catch ( Exception exception){
      exception.printStackTrace();
    }

    return Object.class;
  }

  public int getColumnCount()throws IllegalStateException{
    if (!connectedToDatabase)
    throw new IllegalStateException("Not Connected to database");
  try{
    return metaData.getColumnCount();
  }
  catch(SQLException sqlException){
    sqlException.printStackTrace();
  }
  return 0;
  } // end getColumnCount

  public String getColumnName(int column) throws  IllegalStateException{
    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to database");
    try{
      return metaData.getColumnName(column+1);
    }
    catch (SQLException sqlException){
    sqlException.printStackTrace();
    }
    return "";
    }

 public int getRowCount() throws  IllegalStateException{
     if (!connectedToDatabase)
        throw new IllegalStateException("Not Connected to database");
     return numberOfRows;
    }


  public Object getValueAt(int row, int column)throws  IllegalStateException{
      if (!connectedToDatabase)
        throw new IllegalStateException("Not Connected to database");
    try{
      resultSet.absolute(row+1);
      return resultSet.getObject( column+1 );
    }
    catch(SQLException sqlException){
    sqlException.printStackTrace();
    }
    return "";
    }

  public void setQuery(String query) throws  SQLException,IllegalStateException{
      if (!connectedToDatabase)
        throw new IllegalStateException("Not Connected to database");
      firstTime = System.currentTimeMillis();
      resultSet = statement.executeQuery(query);
      lastTime = System.currentTimeMillis();
      metaData = resultSet.getMetaData();
      resultSet.last();
      numberOfRows = resultSet.getRow();
      fireTableStructureChanged();
    }

  public long gettime()
  {
    elapseTime=lastTime-firstTime;
    lastTime=0;
    firstTime=0;
    return   elapseTime;  // for catch time
  }
  public void disconnectFromDatabase(){
    try{
      statement.close();
      connection.close();
    }
    catch( SQLException sqlException){
      sqlException.printStackTrace();
    }
    finally {
      connectedToDatabase = false;
    }
  }

    } // end class


