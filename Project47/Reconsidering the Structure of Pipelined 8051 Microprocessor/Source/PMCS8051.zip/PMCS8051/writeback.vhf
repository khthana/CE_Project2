--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : writeback.vhf
-- /___/   /\     Timestamp : 03/09/2005 06:05:17
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: writeback
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity writeback is
   port ( d11             : in    std_logic_vector (7 downto 0); 
          d22             : in    std_logic_vector (7 downto 0); 
          R_A             : in    std_logic_vector (7 downto 0); 
          R_B             : in    std_logic_vector (7 downto 0); 
          sel_addr_decode : in    std_logic; 
          sel_mux18       : in    std_logic; 
          w_addr          : out   std_logic_vector (7 downto 0); 
          w_data          : out   std_logic_vector (7 downto 0));
end writeback;

architecture BEHAVIORAL of writeback is
   component addr_decode
      port ( sel  : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component mux18
      port ( sel  : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
begin
   XLXI_1 : addr_decode
      port map (in1(7 downto 0)=>d11(7 downto 0),      
                in2(7 downto 0)=>d22(7 downto 0),      
                sel=>sel_addr_decode,      
                out1(7 downto 0)=>w_addr(7 downto 0));
   
   XLXI_3 : mux18
      port map (in1(7 downto 0)=>R_A(7 downto 0),      
                in2(7 downto 0)=>R_B(7 downto 0),      
                sel=>sel_mux18,      
                out1(7 downto 0)=>w_data(7 downto 0));
   
end BEHAVIORAL;


