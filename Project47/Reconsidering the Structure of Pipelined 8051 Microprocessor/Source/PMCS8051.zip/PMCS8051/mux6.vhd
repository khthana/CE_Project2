library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity MUX6 is
	port (  in1	: in std_logic_vector(7 downto 0);		-- from	direct_addr_dec
           in2	: in std_logic_vector(7 downto 0);		-- from	bit_addr_dec
           in3	: in std_logic_vector(7 downto 0);		-- from	Rn_addr_dec
           in4	: in std_logic_vector(7 downto 0);		-- from	R0_R1_COPY
           sel	: in std_logic_vector(1 downto 0);		-- from	CU
           out1 : out std_logic_vector(7 downto 0)	-- to	Int. Mem.
--			  out2 : out std_logic_vector(7 downto 0)		-- to Inst. Dec.
			  );
end MUX6;

architecture RTL of MUX6 is
begin
	process(in1,in2,in3,in4,sel)
	begin
		case sel is
		when "00" =>		-- Pass Address from Direct Addr. Dec.
			out1 <= in1;
--			out2 <= in1;
		when "01" =>		-- Pass Address from Bit Addr. Dec.
			out1 <= in2;
--			out2 <= in2;
		when "10" =>		-- Pass Address from Rn Addr. Dec.
			out1 <= in3;
--			out2 <= in3;
		when "11" =>		-- Pass Address from Ri Copy Dec.
			out1 <= in4;
--			out2 <= in4;
		when others =>
			out1 <= "--------";
--			out2 <= "ZZZZZZZZ";
		end case;
	end process;
end RTL;
