library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity que_state is
    Port (
		in1 			: in 	std_logic_vector(7 downto 0);
      out1 			: out std_logic_vector(7 downto 0);
     	out2 			: out std_logic_vector(7 downto 0);
      out3			: out std_logic_vector(7 downto 0);
		reset 		: IN 	std_logic;
	 iqc_out	: out std_logic_vector(1 DOWNTO 0); 		
--		M_out  : out std_logic_vector(1 downto 0);
		clock 		: IN 	std_logic

		);


end que_state;

architecture Behavioral of que_state is
-- STATE
	TYPE state_type IS (B1,B21,B22,B31,B32,B33);
	SIGNAL state, next_state : state_type;
--	SIGNAL BP_inst_que_code : std_logic_vector (4 DOWNTO 0):="ZZZZZ";
-- Que
	signal Mcode			: std_logic_vector(1 downto 0):="01";
	signal next_Mcode		: std_logic_vector(1 downto 0):="01";
	signal inst_que_code	: std_logic_vector(4 DOWNTO 0); 		

--	signal que_byte1		: std_logic_vector(7 downto 0):= "00000000";
--	signal que_byte2		: std_logic_vector(7 downto 0):= "--------";
--	signal que_byte3		: std_logic_vector(7 downto 0):= "--------";

	signal temp1: std_logic_vector(7 DOWNTO 0); 	 
	signal temp2: std_logic_vector(7 DOWNTO 0); 	 
--	signal temp3: std_logic_vector(7 DOWNTO 0); 	 
begin

	process( clock, reset, in1 )
	begin
		if reset = '1' then
			next_Mcode <= "01";
			temp1 <= "00000000";
		else
		case in1 is
	-- 1 downto 0 instruction length
			when "00000000" => next_Mcode <= "01";	-- 00000000 1 NOP
			when "00000001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "00000010" => next_Mcode <= "11";	-- 00000010 3 LJMP  code addr
			when "00000011" => next_Mcode <= "01";	-- 00000011 1 RR    A
			when "00000100" => next_Mcode <= "01";	-- 00000100 1 INC   A
			when "00000101" => next_Mcode <= "10";	-- 00000101 2 INC   data addr
			when "00000110" => next_Mcode <= "01";	-- 0000011i 1 INC   @Ri
			when "00000111" => next_Mcode <= "01";	-- 0000011i 1 INC   @Ri
			when "00001000" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001001" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001010" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001011" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001100" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001101" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001110" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00001111" => next_Mcode <= "01";	-- 00001rrr 1 INC   Rn
			when "00010000" => next_Mcode <= "11";	-- 00010000 3 JBC   bit addr, code addr
			when "00010001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "00010010" => next_Mcode <= "11";	-- 00010010 3 LCALL code addr
			when "00010011" => next_Mcode <= "01";	-- 00010011 1 RRC   A
			when "00010100" => next_Mcode <= "01";	-- 00010100 1 DEC   A
			when "00010101" => next_Mcode <= "10";	-- 00010101 2 DEC   data addr
			when "00010110" => next_Mcode <= "01";	-- 0001011i 1 DEC   @Ri
			when "00010111" => next_Mcode <= "01";	-- 0001011i 1 DEC   @Ri
			when "00011000" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011001" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011010" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011011" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011100" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011101" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011110" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00011111" => next_Mcode <= "01";	-- 00011rrr 1 DEC   Rn
			when "00100000" => next_Mcode <= "11";	-- 00100000 3 JB    bit addr, code addr
			when "00100001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "00100010" => next_Mcode <= "01";	-- 00100010 1 RET
			when "00100011" => next_Mcode <= "01";	-- 00100011 1 RL    A
			when "00100100" => next_Mcode <= "10";	-- 00100100 2 ADD   A,#data
			when "00100101" => next_Mcode <= "10";	-- 00100101 2 ADD   A,data addr
			when "00100110" => next_Mcode <= "01";	-- 0010011i 1 ADD   A,@Ri
			when "00100111" => next_Mcode <= "01";	-- 0010011i 1 ADD   A,@Ri
			when "00101000" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101001" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101010" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101011" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101100" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101101" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101110" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00101111" => next_Mcode <= "01";	-- 00101rrr 1 ADD   A,Rn
			when "00110000" => next_Mcode <= "11";	-- 00110000 3 JNB   bit addr, code addr
			when "00110001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "00110010" => next_Mcode <= "01";	-- 00110010 1 RETI
			when "00110011" => next_Mcode <= "01";	-- 00110011 1 RLC   A
			when "00110100" => next_Mcode <= "10";	-- 00110100 2 ADDC  A,#data
			when "00110101" => next_Mcode <= "10";	-- 00110101 2 ADDC  A,data addr
			when "00110110" => next_Mcode <= "01";	-- 0011011i 1 ADDC  A,@Ri
			when "00110111" => next_Mcode <= "01";	-- 0011011i 1 ADDC  A,@Ri
			when "00111000" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111001" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111010" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111011" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111100" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111101" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111110" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "00111111" => next_Mcode <= "01";	-- 00111rrr 1 ADDC  A,Rn
			when "01000000" => next_Mcode <= "10";	-- 01000000 2 JC    code addr
			when "01000001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "01000010" => next_Mcode <= "10";	-- 01000010 2 ORL   data addr,A
			when "01000011" => next_Mcode <= "11";	-- 01000011 3 ORL   data addr,#data
			when "01000100" => next_Mcode <= "10";	-- 01000100 2 ORL   A,#data
			when "01000101" => next_Mcode <= "10";	-- 01000101 2 ORL   A,data addr
			when "01000110" => next_Mcode <= "01";	-- 0100011i 1 ORL   A,@Ri
			when "01000111" => next_Mcode <= "01";	-- 0100011i 1 ORL   A,@Ri
			when "01001000" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001001" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001010" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001011" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001100" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001101" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001110" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01001111" => next_Mcode <= "01";	-- 01001rrr 1 ORL   A,Rn
			when "01010000" => next_Mcode <= "10";	-- 01010000 2 JNC   code addr
			when "01010001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "01010010" => next_Mcode <= "10";	-- 01010010 2 ANL   data addr,A
			when "01010011" => next_Mcode <= "11";	-- 01010011 3 ANL   data addr,#data
			when "01010100" => next_Mcode <= "10";	-- 01010100 2 ANL   A,#data
			when "01010101" => next_Mcode <= "10";	-- 01010101 2 ANL   A,data addr
			when "01010110" => next_Mcode <= "01";	-- 0101011i 1 ANL   A,@Ri
			when "01010111" => next_Mcode <= "01";	-- 0101011i 1 ANL   A,@Ri
			when "01011000" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011001" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011010" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011011" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011100" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011101" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011110" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01011111" => next_Mcode <= "01";	-- 01011rrr 1 ANL   A,Rn
			when "01100000" => next_Mcode <= "10";	-- 01100000 2 JZ    code addr
			when "01100001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "01100010" => next_Mcode <= "10";	-- 01100010 2 XRL   data addr,A
			when "01100011" => next_Mcode <= "11";	-- 01100011 3 XRL   data addr,#data
			when "01100100" => next_Mcode <= "10";	-- 01100100 2 XRL   A,#data
			when "01100101" => next_Mcode <= "10";	-- 01100101 2 XRL   A,data addr
			when "01100110" => next_Mcode <= "01";	-- 0110011i 1 XRL   A,@Ri
			when "01100111" => next_Mcode <= "01";	-- 0110011i 1 XRL   A,@Ri
			when "01101000" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101001" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101010" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101011" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101100" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101101" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101110" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01101111" => next_Mcode <= "01";	-- 01101rrr 1 XRL   A,Rn
			when "01110000" => next_Mcode <= "10";	-- 01110000 2 JNZ   code addr
			when "01110001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "01110010" => next_Mcode <= "10";	-- 01110010 2 ORL   C, bit addr
			when "01110011" => next_Mcode <= "01";	-- 01110011 1 JMP   @A+DPTR
			when "01110100" => next_Mcode <= "10";	-- 01110100 2 MOV   A,#data
			when "01110101" => next_Mcode <= "11";	-- 01110101 3 MOV   data addr,#data
			when "01110110" => next_Mcode <= "10";	-- 0111011i 2 MOV   @Ri,#data
			when "01110111" => next_Mcode <= "10";	-- 0111011i 2 MOV   @Ri,#data
			when "01111000" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111001" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111010" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111011" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111100" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111101" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111110" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "01111111" => next_Mcode <= "10";	-- 01111rrr 2 MOV   Rn,#data
			when "10000000" => next_Mcode <= "10";	-- 10000000 2 SJMP  code addr
			when "10000001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "10000010" => next_Mcode <= "10";	-- 10000010 2 ANL   C,bit addr
			when "10000011" => next_Mcode <= "11";	-- 10000011 1 MOVC  A,@A+PC
			when "10000100" => next_Mcode <= "01";	-- 10000100 1 DIV   AB
			when "10000101" => next_Mcode <= "11";	-- 10000101 3 MOV   data addr,data addr
			when "10000110" => next_Mcode <= "10";	-- 1000011i 2 MOV   data addr,@Ri
			when "10000111" => next_Mcode <= "10";	-- 1000011i 2 MOV   data addr,@Ri
			when "10001000" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001001" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001010" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001011" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001100" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001101" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001110" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10001111" => next_Mcode <= "10";	-- 10001rrr 2 MOV   data addr,Rn
			when "10010000" => next_Mcode <= "11";	-- 10010000 3 MOV   DPTR,#data
			when "10010001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "10010010" => next_Mcode <= "10";	-- 10010010 2 MOV   bit addr,C
			when "10010011" => next_Mcode <= "11";	-- 10010011 1 MOVC  A,@A+DPTR
			when "10010100" => next_Mcode <= "10";	-- 10010100 2 SUBB  A,#data
			when "10010101" => next_Mcode <= "10";	-- 10010101 2 SUBB  A,data addr
			when "10010110" => next_Mcode <= "01";	-- 1001011i 1 SUBB  A,@Ri
			when "10010111" => next_Mcode <= "01";	-- 1001011i 1 SUBB  A,@Ri
			when "10011000" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011001" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011010" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011011" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011100" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011101" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011110" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10011111" => next_Mcode <= "01";	-- 10011rrr 1 SUBB  A,Rn
			when "10100000" => next_Mcode <= "10";	-- 10100000 2 ORL   C,/bit addr
			when "10100001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "10100010" => next_Mcode <= "10";	-- 10100010 2 MOV   C,bit addr
			when "10100011" => next_Mcode <= "01";	-- 10100011 1 INC   DPTR
			when "10100100" => next_Mcode <= "01";	-- 10100100 1 MUL   AB
			when "10100101" => next_Mcode <= "01";	-- 10100101   reserved
			when "10100110" => next_Mcode <= "10";	-- 1010011i 2 MOV   @Ri,data addr
			when "10100111" => next_Mcode <= "10";	-- 1010011i 2 MOV   @Ri,data addr
			when "10101000" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101001" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101010" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101011" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101100" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101101" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101110" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10101111" => next_Mcode <= "10";	-- 10101rrr 2 MOV   Rn,data addr
			when "10110000" => next_Mcode <= "10";	-- 10110000 2 ANL   C,/bit addr
			when "10110001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "10110010" => next_Mcode <= "10";	-- 10110010 2 CPL   bit addr
			when "10110011" => next_Mcode <= "01";	-- 10110011 1 CPL   C
			when "10110100" => next_Mcode <= "11";	-- 10110100 3 CJNE  A,#data,code addr
			when "10110101" => next_Mcode <= "11";	-- 10110101 3 CJNE  A,data addr,code addr
			when "10110110" => next_Mcode <= "11";	-- 1011011i 3 CJNE  @Ri,#data,code addr
			when "10110111" => next_Mcode <= "11";	-- 1011011i 3 CJNE  @Ri,#data,code addr
			when "10111000" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111001" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111010" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111011" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111100" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111101" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111110" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "10111111" => next_Mcode <= "11";	-- 10111rrr 3 CJNE  Rn,#data,code addr
			when "11000000" => next_Mcode <= "10";	-- 11000000 2 PUSH  data addr
			when "11000001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "11000010" => next_Mcode <= "10";	-- 11000010 2 CLR   bit addr
			when "11000011" => next_Mcode <= "01";	-- 11000011 1 CLR   C
			when "11000100" => next_Mcode <= "01";	-- 11000100 1 SWAP  A
			when "11000101" => next_Mcode <= "10";	-- 11000101 2 XCH   A,data addr
			when "11000110" => next_Mcode <= "01";	-- 1100011i 1 XCH   A,@Ri
			when "11000111" => next_Mcode <= "01";	-- 1100011i 1 XCH   A,@Ri
			when "11001000" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001001" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001010" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001011" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001100" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001101" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001110" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11001111" => next_Mcode <= "01";	-- 11001rrr 1 XCH   A,Rn
			when "11010000" => next_Mcode <= "10";	-- 11010000 2 POP   data addr
			when "11010001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "11010010" => next_Mcode <= "10";	-- 11010010 2 SETB  bit addr
			when "11010011" => next_Mcode <= "01";	-- 11010011 1 SETB  C
			when "11010100" => next_Mcode <= "01";	-- 11010100 1 DA    A
			when "11010101" => next_Mcode <= "11";	-- 11010101 3 DJNZ  data addr, code addr
			when "11010110" => next_Mcode <= "01";	-- 1101011i 1 XCHD  A,@Ri
			when "11010111" => next_Mcode <= "01";	-- 1101011i 1 XCHD  A,@Ri
			when "11011000" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011001" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011010" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011011" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011100" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011101" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011110" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11011111" => next_Mcode <= "10";	-- 11011rrr 2 DJNZ  Rn,code addr
			when "11100000" => next_Mcode <= "01";	-- 11100000 1 MOVX  A,@DPTR
			when "11100001" => next_Mcode <= "10";	-- aaa00001 2 AJMP  code addr
			when "11100010" => next_Mcode <= "01";	-- 1110001i 1 MOVX  A,@Ri
			when "11100011" => next_Mcode <= "01";	-- 1110001i 1 MOVX  A,@Ri
			when "11100100" => next_Mcode <= "01";	-- 11100100 1 CLR   A
			when "11100101" => next_Mcode <= "10";	-- 11100101 2 MOV   A,data addr
			when "11100110" => next_Mcode <= "01";	-- 1110011i 1 MOV   A,@Ri
			when "11100111" => next_Mcode <= "01";	-- 1110011i 1 MOV   A,@Ri
			when "11101000" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11101001" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11101010" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11101011" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11101100" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn	
			when "11101101" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11101110" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11101111" => next_Mcode <= "01";	-- 11101rrr 1 MOV   A,Rn
			when "11110000" => next_Mcode <= "01";	-- 11110000 1 MOVX  @DPTR,A
			when "11110001" => next_Mcode <= "10";	-- aaa10001 2 ACALL code addr
			when "11110010" => next_Mcode <= "01";	-- 1111001i 1 MOVX  @Ri,A
			when "11110011" => next_Mcode <= "01";	-- 1111001i 1 MOVX  @Ri,A
			when "11110100" => next_Mcode <= "01";	-- 11110100 1 CPL   A
			when "11110101" => next_Mcode <= "10";	-- 11110101 2 MOV   data addr,A
			when "11110110" => next_Mcode <= "01";	-- 1111011i 1 MOV   @Ri,A
			when "11110111" => next_Mcode <= "01";	-- 1111011i 1 MOV   @Ri,A
			when "11111000" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111001" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111010" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111011" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111100" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111101" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111110" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when "11111111" => next_Mcode <= "01";	-- 11111rrr 1 MOV   Rn,A
			when others => next_Mcode <= "01";
		end case;
		temp1 <= in1;-- after 1 ps;
		end if;
	end process;
	Mcode <= next_Mcode	;
--	m_out <= next_Mcode ;

	PROCESS (CLOCK, next_state)--, que_byte1, que_byte2, que_byte3)
	BEGIN

		IF clock'event and clock = '1' THEN
			state <= next_state;
		END IF;
	END PROCESS;



	PROCESS (RESET,clock,state,Mcode,temp1)
	BEGIN
 		next_state<=B1;
		inst_que_code <= (std_logic_vector'("-----"));
		IF ( RESET='1' ) THEN
			next_state<=B1;
			inst_que_code <= (std_logic_vector'("-----"));
		ELSe--if clock = '1' THEN
			 CASE state IS
				WHEN B1 =>
					IF ( Mcode="01" ) THEN
						next_state<=B1;
						inst_que_code <= (std_logic_vector'("11100"));

					END IF;
					IF ( Mcode="10" ) THEN
						next_state<=B21;
						inst_que_code <= (std_logic_vector'("10100"));

					END IF;
					IF ( Mcode="11" ) THEN
						next_state<=B31;
						inst_que_code <= (std_logic_vector'("10100"));

					END IF;
				WHEN B21 =>
					next_state<=B22;
					inst_que_code <= (std_logic_vector'("01010"));

				WHEN B22 =>
					IF ( Mcode="01" ) THEN
						next_state<=B1;
						inst_que_code <= (std_logic_vector'("11100"));

					END IF;
					IF ( Mcode="10" ) THEN
						next_state<=B21;
						inst_que_code <= (std_logic_vector'("10100"));

					END IF;
					IF ( Mcode="11" ) THEN
						next_state<=B31;
						inst_que_code <= (std_logic_vector'("10100"));

					END IF;
				WHEN B31 =>
					next_state<=B32;
					inst_que_code <= (std_logic_vector'("00010"));
				
				WHEN B32 =>
					next_state<=B33;
					inst_que_code <= (std_logic_vector'("01001"));

				WHEN B33 =>
					IF ( Mcode="01" ) THEN
						next_state<=B1;
						inst_que_code <= (std_logic_vector'("11100"));

					END IF;
					IF ( Mcode="10" ) THEN
						next_state<=B21;
						inst_que_code <= (std_logic_vector'("10100"));

					END IF;
					IF ( Mcode="11" ) THEN
						next_state<=B31;
						inst_que_code <= (std_logic_vector'("10100"));

					END IF;
			END CASE;
		END IF;
		temp2 <= temp1;
	END PROCESS;
--	inst_que_code <= BP_inst_que_code  ;
	iqc_out <= inst_que_code(4 downto 3)  ; 

-- 	Process(inst_que_code, temp2, reset)
-- 	variable que_temp1 : std_logic_vector(7 downto 0);
-- 	variable que_temp2 : std_logic_vector(7 downto 0);
-- 	variable que_temp3 : std_logic_vector(7 downto 0);
--	begin
--		if reset = '1' then 
--			que_byte1 <= "00000000";
--			que_byte2 <= "--------";
--			que_byte3 <= "--------";
--		else
--			case inst_que_code(2 downto 0)is
--				when "100" 	=>	que_temp1 := temp2; que_temp2 := "--------"; que_temp3 := "--------";
--				when "010" 	=>	que_temp2 := temp2; que_temp3 := "--------";
--				when "001" 	=>	que_temp3 := temp2;
--				when others => null;
--			end case;
--    
--			que_byte1 <= que_temp1;
--			que_byte2 <= que_temp2;
--			que_byte3 <= que_temp3;
--
--		end if; 
--	end process;

--	que_byte1 <= temp2 when reset = '0' and inst_que_code(2 downto 0) = "100" 	else que_byte1 when reset = '0' and inst_que_code(2 downto 0) = "010" 	else que_byte1 when reset = '0' and inst_que_code(2 downto 0) = "001" else "00000000" ;
--	que_byte2 <= temp2 when reset = '0' and inst_que_code(1 downto 0) = "10" 	else que_byte2 when reset = '0' and inst_que_code(1 downto 0) = "01" 	else "--------" ;
--	que_byte3 <= temp2 when reset = '0' and inst_que_code(0) 			= '1' 	else "--------" ;


 	Process(clock, reset, inst_que_code )
 	variable que_BYTE1 : std_logic_vector(7 downto 0):="00000000";
 	variable que_BYTE2 : std_logic_vector(7 downto 0):="--------";
 	variable que_BYTE3 : std_logic_vector(7 downto 0):="--------";
 	begin
		if reset = '1' then
			out1 <= "00000000" ;
			out2 <= "--------" ;
			out3 <= "--------" ;
		elsif clock'event and clock = '1'	then
			if inst_que_code(0) = '1' then
				que_byte3 := temp2;
			end if;
			if inst_que_code(1) = '1' then
				que_byte2 := temp2;
				que_byte3 := "--------" ;
			end if;
			if inst_que_code(2) = '1' then
				que_byte1 := temp2;
				que_byte2 := "--------" ;
				que_byte3 := "--------" ;
			end if;
	 		if inst_que_code(3) = '1' then 
				out1 <= que_byte1 ;
				out2 <= que_byte2 ;
				out3 <= que_byte3 ;
			else
				out1 <= "00000000" ;
				out2 <= "--------" ;
				out3 <= "--------" ;
			end if;
	
		end if;														   
	end process;
end Behavioral;
