library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity PSW_REG is
	port(	data_in  	:in		std_logic_vector(7 downto 0);
			ACC_in  		:in		std_logic_vector(7 downto 0);
			data_out		:out   	std_logic_vector(7 downto 0);
			Carry_in		:in		std_logic;
			OverFlow_in	:in		std_logic;
			AUX_C_in		:in		std_logic;
			load_in		:in		std_logic;
			reset			:in		std_logic;
			clock			:in		std_logic
			);
end PSW_REG;

architecture rtl of PSW_REG is
		signal psw : std_logic_vector(7 downto 0):="00000000";

begin
--	psw <= data_in when load_in = '1' and reset = '0' else psw when load_in = '0' and reset = '0' else "00000000";
	process (clock, reset, data_in, load_in, psw)
	begin
		if (reset = '1') then
			psw <= "00000000";
--		elsif falling_edge(Clock) then
--		 	if (load_in = '1' ) then psw <= data_in; end if;
		elsif rising_edge(Clock) then
		 	if (load_in = '1' ) then psw <= data_in; -- end if; 
			else
				if Carry_in = '1' then 	psw(7) <= '1' ; elsif Carry_in = '0' then psw(7) <= '0' ; end if; 
				if AUX_C_in = '1' then 	psw(6) <= '1' ; elsif AUX_C_in = '0' then psw(6) <= '0' ; end if;  
				if OverFlow_in = '1' then 	psw(2) <= '1' ; elsif OverFlow_in = '0' then psw(2) <= '0' ; end if;  
--			psw(7) <= Carry_in;
--			psw(6) <= AUX_C_in;
--			psw(2) <= OverFlow_in;
				psw(0) <= ACC_in(7) xor ACC_in(6) xor ACC_in(5) xor ACC_in(4) xor ACC_in(3) xor ACC_in(2) xor ACC_in(1) xor ACC_in(0) ;
			end if;
		end if;
		data_out <= psw; 
	end process;
end rtl;