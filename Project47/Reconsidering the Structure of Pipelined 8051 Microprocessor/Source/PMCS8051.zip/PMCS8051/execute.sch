VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "spartan2"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL src1(7:0)
        SIGNAL src2(7:0)
        SIGNAL forward2(7:0)
        SIGNAL des1(7:0)
        SIGNAL des2(7:0)
        SIGNAL forward1(7:0)
        SIGNAL RA(7:0)
        SIGNAL RB(7:0)
        SIGNAL cy_out
        SIGNAL ac_out
        SIGNAL ov
        SIGNAL rst
        SIGNAL cy_in
        SIGNAL ac_in
        SIGNAL OPCode(3:0)
        SIGNAL sel_mux16(1:0)
        SIGNAL sel_mux17(1:0)
        SIGNAL AA(7:0)
        SIGNAL BB(7:0)
        SIGNAL D11(7:0)
        SIGNAL D22(7:0)
        SIGNAL s1(7:0)
        SIGNAL s2(7:0)
        SIGNAL D1(7:0)
        SIGNAL D2(7:0)
        SIGNAL sel_mux10
        SIGNAL do0(7:0)
        SIGNAL do1(7:0)
        SIGNAL sel_mux15
        SIGNAL mux15(7:0)
        SIGNAL r_addr0(7:0)
        SIGNAL w_addr0(7:0)
        SIGNAL r_addr1(7:0)
        SIGNAL w_addr1(7:0)
        SIGNAL sp_out(7:0)
        SIGNAL sp1(7:0)
        SIGNAL sp2(7:0)
        SIGNAL w_addr(7:0)
        SIGNAL r_addr(7:0)
        SIGNAL sel_mux11(1:0)
        SIGNAL sel_mux12(1:0)
        SIGNAL sel_mux13
        SIGNAL sel_mux14
        SIGNAL PC_l(7:0)
        SIGNAL PC_h(7:0)
        SIGNAL pc0(7:0)
        SIGNAL pc1(7:0)
        SIGNAL en
        SIGNAL sp_in(7:0)
        SIGNAL XLXN_2
        SIGNAL sel(3:0)
        PORT Output RA(7:0)
        PORT Output RB(7:0)
        PORT Output cy_out
        PORT Output ac_out
        PORT Output ov
        PORT Input rst
        PORT Input cy_in
        PORT Input ac_in
        PORT Input OPCode(3:0)
        PORT Input sel_mux16(1:0)
        PORT Input sel_mux17(1:0)
        PORT Input AA(7:0)
        PORT Input BB(7:0)
        PORT Output D11(7:0)
        PORT Output D22(7:0)
        PORT Input s1(7:0)
        PORT Input s2(7:0)
        PORT Input D1(7:0)
        PORT Input D2(7:0)
        PORT Input sel_mux10
        PORT Input sel_mux15
        PORT Output mux15(7:0)
        PORT Input w_addr(7:0)
        PORT Input r_addr(7:0)
        PORT Input sel_mux11(1:0)
        PORT Input sel_mux12(1:0)
        PORT Input sel_mux13
        PORT Input sel_mux14
        PORT Input PC_l(7:0)
        PORT Input PC_h(7:0)
        PORT Input en
        PORT Input XLXN_2
        PORT Input sel(3:0)
        BEGIN BLOCKDEF alu
            TIMESTAMP 2005 2 12 12 37 24
            RECTANGLE N 64 -448 320 0 
            LINE N 64 -416 0 -416 
            LINE N 64 -352 0 -352 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 320 -416 384 -416 
            LINE N 320 -320 384 -320 
            LINE N 320 -224 384 -224 
            LINE N 320 -128 384 -128 
            RECTANGLE N 320 -140 384 -116 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
        END BLOCKDEF
        BEGIN BLOCKDEF as1
            TIMESTAMP 2005 2 12 12 50 16
            RECTANGLE N 64 -64 320 0 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
        END BLOCKDEF
        BEGIN BLOCKDEF as2
            TIMESTAMP 2005 2 12 13 41 27
            RECTANGLE N 64 -64 320 0 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
        END BLOCKDEF
        BEGIN BLOCKDEF d11d22rarb
            TIMESTAMP 2005 2 12 12 51 21
            RECTANGLE N 64 -64 320 0 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
        END BLOCKDEF
        BEGIN BLOCKDEF forwarder
            TIMESTAMP 2005 2 13 16 54 23
            LINE N 64 32 0 32 
            RECTANGLE N 0 20 64 44 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -224 384 -224 
            RECTANGLE N 320 -236 384 -212 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
            RECTANGLE N 64 -256 320 64 
        END BLOCKDEF
        BEGIN BLOCKDEF internal_ram_bank
            TIMESTAMP 2005 2 12 1 26 26
            LINE N 64 32 0 32 
            RECTANGLE N 0 20 64 44 
            LINE N 64 96 0 96 
            RECTANGLE N 0 84 64 108 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -224 384 -224 
            RECTANGLE N 320 -236 384 -212 
            RECTANGLE N 64 -256 320 128 
        END BLOCKDEF
        BEGIN BLOCKDEF max1617
            TIMESTAMP 2005 2 10 20 32 49
            RECTANGLE N 64 -320 320 0 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -300 384 -276 
        END BLOCKDEF
        BEGIN BLOCKDEF mux10131415
            TIMESTAMP 2005 2 10 20 32 41
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -160 384 -160 
            RECTANGLE N 320 -172 384 -148 
        END BLOCKDEF
        BEGIN BLOCKDEF mux1112
            TIMESTAMP 2005 2 13 16 54 42
            RECTANGLE N 64 -256 320 0 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -224 384 -224 
            RECTANGLE N 320 -236 384 -212 
        END BLOCKDEF
        BEGIN BLOCKDEF latch
            TIMESTAMP 2005 2 13 16 54 30
            LINE N 64 160 0 160 
            LINE N 64 32 0 32 
            RECTANGLE N 0 20 64 44 
            LINE N 320 32 384 32 
            RECTANGLE N 320 20 384 44 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -108 384 -84 
            RECTANGLE N 64 -128 320 192 
        END BLOCKDEF
        BEGIN BLOCKDEF ifd8
            TIMESTAMP 2001 2 2 12 53 15
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            LINE N 0 -128 64 -128 
            LINE N 84 -128 64 -140 
            LINE N 64 -116 84 -128 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK mux_13 mux10131415
            PIN sel sel_mux13
            PIN in1(7:0) sp2(7:0)
            PIN in2(7:0) w_addr(7:0)
            PIN out1(7:0) w_addr1(7:0)
        END BLOCK
        BEGIN BLOCK mux_14 mux10131415
            PIN sel sel_mux14
            PIN in1(7:0) sp_out(7:0)
            PIN in2(7:0) r_addr(7:0)
            PIN out1(7:0) r_addr1(7:0)
        END BLOCK
        BEGIN BLOCK mux_11 mux1112
            PIN in1(7:0) sp1(7:0)
            PIN in2(7:0) sp2(7:0)
            PIN in3(7:0) w_addr(7:0)
            PIN sel(1:0) sel_mux11(1:0)
            PIN out1(7:0) w_addr0(7:0)
        END BLOCK
        BEGIN BLOCK mux_12 mux1112
            PIN in1(7:0) sp_out(7:0)
            PIN in2(7:0) sp1(7:0)
            PIN in3(7:0) r_addr(7:0)
            PIN sel(1:0) sel_mux12(1:0)
            PIN out1(7:0) r_addr0(7:0)
        END BLOCK
        BEGIN BLOCK mux17 max1617
            PIN in1(7:0) forward2(7:0)
            PIN in2(7:0) RA(7:0)
            PIN in3(7:0) RB(7:0)
            PIN in4(7:0) BB(7:0)
            PIN sel(1:0) sel_mux17(1:0)
            PIN out1(7:0) src2(7:0)
        END BLOCK
        BEGIN BLOCK mux16 max1617
            PIN in1(7:0) forward1(7:0)
            PIN in2(7:0) RA(7:0)
            PIN in3(7:0) RB(7:0)
            PIN in4(7:0) AA(7:0)
            PIN sel(1:0) sel_mux16(1:0)
            PIN out1(7:0) src1(7:0)
        END BLOCK
        BEGIN BLOCK Forwarder_m forwarder
            PIN s1(7:0) s1(7:0)
            PIN s2(7:0) s2(7:0)
            PIN d1(7:0) D11(7:0)
            PIN d2(7:0) D22(7:0)
            PIN out1(7:0) forward1(7:0)
            PIN out2(7:0) forward2(7:0)
            PIN sel(3:0) sel(3:0)
        END BLOCK
        BEGIN BLOCK RA_m d11d22rarb
            PIN in1(7:0) des1(7:0)
            PIN out1(7:0) RA(7:0)
        END BLOCK
        BEGIN BLOCK RB_m d11d22rarb
            PIN in1(7:0) des2(7:0)
            PIN out1(7:0) RB(7:0)
        END BLOCK
        BEGIN BLOCK D11_m d11d22rarb
            PIN in1(7:0) D1(7:0)
            PIN out1(7:0) D11(7:0)
        END BLOCK
        BEGIN BLOCK D22_m d11d22rarb
            PIN in1(7:0) D2(7:0)
            PIN out1(7:0) D22(7:0)
        END BLOCK
        BEGIN BLOCK mux_10 mux10131415
            PIN sel sel_mux10
            PIN in1(7:0) sp2(7:0)
            PIN in2(7:0) sp1(7:0)
            PIN out1(7:0) sp_in(7:0)
        END BLOCK
        BEGIN BLOCK as2_m as2
            PIN in1(7:0) sp_out(7:0)
            PIN out1(7:0) sp2(7:0)
        END BLOCK
        BEGIN BLOCK as1_m as1
            PIN in1(7:0) sp_out(7:0)
            PIN out1(7:0) sp1(7:0)
        END BLOCK
        BEGIN BLOCK bank1 internal_ram_bank
            PIN di(7:0) pc1(7:0)
            PIN do(7:0) do1(7:0)
            PIN w_addr(7:0) w_addr1(7:0)
            PIN r_addr(7:0) r_addr1(7:0)
        END BLOCK
        BEGIN BLOCK mux_15 mux10131415
            PIN sel sel_mux15
            PIN in1(7:0) do0(7:0)
            PIN in2(7:0) do1(7:0)
            PIN out1(7:0) mux15(7:0)
        END BLOCK
        BEGIN BLOCK bank0 internal_ram_bank
            PIN di(7:0) pc0(7:0)
            PIN do(7:0) do0(7:0)
            PIN w_addr(7:0) w_addr0(7:0)
            PIN r_addr(7:0) r_addr0(7:0)
        END BLOCK
        BEGIN BLOCK latch_m latch
            PIN in1(7:0) PC_h(7:0)
            PIN in2(7:0) PC_l(7:0)
            PIN out1(7:0) pc0(7:0)
            PIN out2(7:0) pc1(7:0)
            PIN en en
        END BLOCK
        BEGIN BLOCK alu_m alu
            PIN rst rst
            PIN src_cy cy_in
            PIN src_ac ac_in
            PIN op_code(3:0) OPCode(3:0)
            PIN src_1(7:0) src1(7:0)
            PIN src_2(7:0) src2(7:0)
            PIN des_cy cy_out
            PIN des_ac ac_out
            PIN des_ov ov
            PIN des_1(7:0) des1(7:0)
            PIN des_2(7:0) des2(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_5 ifd8
            PIN C XLXN_2
            PIN D(7:0) sp_in(7:0)
            PIN Q(7:0) sp_out(7:0)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN BRANCH src1(7:0)
            WIRE 2032 512 2288 512
        END BRANCH
        BEGIN BRANCH src2(7:0)
            WIRE 2032 896 2272 896
            WIRE 2272 576 2288 576
            WIRE 2272 576 2272 896
        END BRANCH
        BEGIN BRANCH forward2(7:0)
            WIRE 1184 896 1648 896
        END BRANCH
        BEGIN BRANCH des2(7:0)
            WIRE 2672 640 2912 640
        END BRANCH
        BEGIN INSTANCE mux17 1648 1184 R0
            BEGIN DISPLAY 0 -440 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE mux16 1648 800 R0
            BEGIN DISPLAY 0 -440 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE Forwarder_m 800 928 R0
        END INSTANCE
        BEGIN BRANCH forward1(7:0)
            WIRE 1184 704 1280 704
            WIRE 1280 512 1280 704
            WIRE 1280 512 1648 512
        END BRANCH
        BEGIN INSTANCE RB_m 2912 672 R0
            BEGIN DISPLAY 0 -56 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH RA(7:0)
            WIRE 1568 96 1568 576
            WIRE 1568 576 1648 576
            WIRE 1568 576 1568 960
            WIRE 1568 960 1648 960
            WIRE 1568 96 3328 96
            WIRE 3328 96 3328 544
            WIRE 3328 544 3392 544
            WIRE 3296 544 3328 544
        END BRANCH
        BEGIN BRANCH RB(7:0)
            WIRE 1536 64 3360 64
            WIRE 3360 64 3360 640
            WIRE 3360 640 3392 640
            WIRE 1536 64 1536 640
            WIRE 1536 640 1648 640
            WIRE 1536 640 1536 1024
            WIRE 1536 1024 1648 1024
            WIRE 3296 640 3360 640
        END BRANCH
        BEGIN BRANCH cy_out
            WIRE 2672 256 2704 256
        END BRANCH
        BEGIN BRANCH ac_out
            WIRE 2672 352 2704 352
        END BRANCH
        BEGIN BRANCH ov
            WIRE 2672 448 2704 448
        END BRANCH
        BEGIN BRANCH rst
            WIRE 2256 256 2288 256
        END BRANCH
        BEGIN BRANCH cy_in
            WIRE 2256 320 2288 320
        END BRANCH
        BEGIN BRANCH ac_in
            WIRE 2256 384 2288 384
        END BRANCH
        BEGIN BRANCH OPCode(3:0)
            WIRE 2256 448 2288 448
        END BRANCH
        BEGIN BRANCH sel_mux16(1:0)
            WIRE 1504 768 1648 768
        END BRANCH
        BEGIN BRANCH sel_mux17(1:0)
            WIRE 1504 1152 1648 1152
        END BRANCH
        BEGIN BRANCH AA(7:0)
            WIRE 1504 704 1648 704
        END BRANCH
        BEGIN BRANCH BB(7:0)
            WIRE 1504 1088 1648 1088
        END BRANCH
        BEGIN BRANCH D11(7:0)
            WIRE 576 80 704 80
            WIRE 704 80 704 832
            WIRE 704 832 800 832
            WIRE 704 80 752 80
        END BRANCH
        BEGIN BRANCH D22(7:0)
            WIRE 576 208 656 208
            WIRE 656 208 656 896
            WIRE 656 896 800 896
            WIRE 656 208 752 208
        END BRANCH
        BEGIN BRANCH s1(7:0)
            WIRE 608 704 800 704
        END BRANCH
        BEGIN BRANCH s2(7:0)
            WIRE 608 768 800 768
        END BRANCH
        BEGIN INSTANCE D11_m 192 112 R0
            BEGIN DISPLAY -20 -64 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE D22_m 192 240 R0
            BEGIN DISPLAY -20 -60 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH D1(7:0)
            WIRE 160 80 192 80
        END BRANCH
        BEGIN BRANCH D2(7:0)
            WIRE 160 208 192 208
        END BRANCH
        IOMARKER 2704 256 cy_out R0 28
        IOMARKER 2704 352 ac_out R0 28
        IOMARKER 2704 448 ov R0 28
        IOMARKER 2256 256 rst R180 28
        IOMARKER 2256 320 cy_in R180 28
        IOMARKER 2256 384 ac_in R180 28
        IOMARKER 2256 448 OPCode(3:0) R180 28
        IOMARKER 1504 768 sel_mux16(1:0) R180 28
        IOMARKER 1504 1152 sel_mux17(1:0) R180 28
        IOMARKER 1504 704 AA(7:0) R180 28
        IOMARKER 1504 1088 BB(7:0) R180 28
        IOMARKER 608 768 s2(7:0) R180 28
        IOMARKER 608 704 s1(7:0) R180 28
        IOMARKER 160 80 D1(7:0) R180 28
        IOMARKER 160 208 D2(7:0) R180 28
        IOMARKER 752 80 D11(7:0) R0 28
        IOMARKER 752 208 D22(7:0) R0 28
        IOMARKER 3392 544 RA(7:0) R0 28
        IOMARKER 3392 640 RB(7:0) R0 28
        BEGIN INSTANCE as2_m 512 2672 R0
        END INSTANCE
        BEGIN INSTANCE as1_m 512 2416 R0
        END INSTANCE
        BEGIN BRANCH sel_mux10
            WIRE 464 2032 480 2032
            WIRE 480 2032 496 2032
        END BRANCH
        IOMARKER 496 2032 sel_mux10 R0 28
        BEGIN BRANCH do0(7:0)
            WIRE 1792 1216 2800 1216
            WIRE 1792 1216 1792 1312
        END BRANCH
        BEGIN BRANCH sel_mux15
            WIRE 2704 1152 2800 1152
        END BRANCH
        BEGIN BRANCH mux15(7:0)
            WIRE 3184 1152 3312 1152
        END BRANCH
        BEGIN INSTANCE bank0 2016 1696 R270
            BEGIN DISPLAY 296 56 ATTR InstName
                ALIGNMENT VRIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE bank1 2816 1696 R270
            BEGIN DISPLAY 296 48 ATTR InstName
                ALIGNMENT VRIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH do1(7:0)
            WIRE 2592 1280 2800 1280
            WIRE 2592 1280 2592 1312
        END BRANCH
        BEGIN INSTANCE mux_12 2336 2256 R270
            BEGIN DISPLAY 296 -100 ATTR InstName
                ALIGNMENT VRIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH r_addr0(7:0)
            WIRE 2112 1696 2112 1872
        END BRANCH
        BEGIN BRANCH r_addr1(7:0)
            WIRE 2912 1696 2912 1712
            WIRE 2912 1712 3184 1712
            WIRE 3184 1712 3184 1872
        END BRANCH
        BEGIN BRANCH w_addr1(7:0)
            WIRE 2848 1696 2848 1856
        END BRANCH
        BEGIN BRANCH sp1(7:0)
            WIRE 464 1904 960 1904
            WIRE 960 1904 960 2384
            WIRE 960 2384 1584 2384
            WIRE 1584 2384 2176 2384
            WIRE 896 2384 960 2384
            WIRE 1584 2240 1584 2384
            WIRE 2176 2256 2176 2384
        END BRANCH
        BEGIN BRANCH w_addr(7:0)
            WIRE 1712 2240 1712 2560
            WIRE 1712 2560 2976 2560
            WIRE 2976 2560 3344 2560
            WIRE 2976 2240 2976 2560
        END BRANCH
        BEGIN BRANCH r_addr(7:0)
            WIRE 2240 2256 2240 2448
            WIRE 2240 2448 3312 2448
            WIRE 3312 2448 3344 2448
            WIRE 3312 2256 3312 2448
        END BRANCH
        BEGIN INSTANCE mux_11 1808 2240 R270
            BEGIN DISPLAY 296 -92 ATTR InstName
                ALIGNMENT VRIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH w_addr0(7:0)
            WIRE 1584 1776 1584 1856
            WIRE 1584 1776 2048 1776
            WIRE 2048 1696 2048 1776
        END BRANCH
        BEGIN BRANCH sel_mux11(1:0)
            WIRE 1776 2240 1776 2320
        END BRANCH
        BEGIN BRANCH sel_mux12(1:0)
            WIRE 2304 2256 2304 2320
        END BRANCH
        BEGIN INSTANCE mux_13 3008 2240 R270
            BEGIN DISPLAY 296 -96 ATTR InstName
                ALIGNMENT VRIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH sp2(7:0)
            WIRE 464 1968 1008 1968
            WIRE 1008 1968 1008 2640
            WIRE 1008 2640 1648 2640
            WIRE 1648 2640 2912 2640
            WIRE 896 2640 1008 2640
            WIRE 1648 2240 1648 2640
            WIRE 2912 2240 2912 2640
        END BRANCH
        BEGIN INSTANCE mux_14 3344 2256 R270
            BEGIN DISPLAY 56 4 ATTR InstName
                ALIGNMENT VRIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH sp_out(7:0)
            WIRE 464 2512 480 2512
            WIRE 480 2512 480 2640
            WIRE 480 2640 512 2640
            WIRE 480 2512 2112 2512
            WIRE 2112 2512 3248 2512
            WIRE 480 2384 512 2384
            WIRE 480 2384 480 2512
            WIRE 2112 2256 2112 2512
            WIRE 3248 2256 3248 2512
        END BRANCH
        IOMARKER 1776 2320 sel_mux11(1:0) R0 28
        IOMARKER 2304 2320 sel_mux12(1:0) R0 28
        BEGIN BRANCH sel_mux13
            WIRE 2848 2240 2848 2320
        END BRANCH
        BEGIN BRANCH sel_mux14
            WIRE 3184 2256 3184 2320
        END BRANCH
        IOMARKER 2848 2320 sel_mux13 R180 28
        IOMARKER 3184 2320 sel_mux14 R180 28
        IOMARKER 3344 2448 r_addr(7:0) R0 28
        IOMARKER 3344 2560 w_addr(7:0) R0 28
        IOMARKER 2704 1152 sel_mux15 R180 28
        IOMARKER 3312 1152 mux15(7:0) R0 28
        BEGIN INSTANCE mux_15 2800 1312 R0
            BEGIN DISPLAY 40 -260 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH PC_l(7:0)
            WIRE 848 1552 960 1552
        END BRANCH
        BEGIN BRANCH PC_h(7:0)
            WIRE 848 1488 960 1488
        END BRANCH
        IOMARKER 848 1552 PC_l(7:0) R180 28
        IOMARKER 848 1488 PC_h(7:0) R180 28
        BEGIN INSTANCE latch_m 960 1520 R0
        END INSTANCE
        BEGIN BRANCH pc0(7:0)
            WIRE 1344 1424 1424 1424
            WIRE 1424 1424 1424 1744
            WIRE 1424 1744 1984 1744
            WIRE 1984 1696 1984 1744
        END BRANCH
        BEGIN BRANCH pc1(7:0)
            WIRE 1344 1552 1360 1552
            WIRE 1360 1552 1360 1808
            WIRE 1360 1808 2784 1808
            WIRE 2784 1696 2784 1808
        END BRANCH
        BEGIN BRANCH des1(7:0)
            WIRE 2672 544 2688 544
            WIRE 2688 544 2912 544
        END BRANCH
        BEGIN INSTANCE RA_m 2912 576 R0
            BEGIN DISPLAY 0 -56 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN INSTANCE alu_m 2288 672 R0
        END INSTANCE
        BEGIN BRANCH en
            WIRE 848 1680 944 1680
            WIRE 944 1680 960 1680
        END BRANCH
        IOMARKER 848 1680 en R180 28
        BEGIN INSTANCE mux_10 464 1872 R180
            BEGIN DISPLAY 304 48 ATTR InstName
                ALIGNMENT RIGHT
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH sp_in(7:0)
            WIRE 64 2032 64 2512
            WIRE 64 2512 80 2512
            WIRE 64 2032 80 2032
        END BRANCH
        INSTANCE XLXI_5 80 2768 R0
        BEGIN BRANCH XLXN_2
            WIRE 48 2640 80 2640
        END BRANCH
        IOMARKER 48 2640 XLXN_2 R180 28
        BEGIN BRANCH sel(3:0)
            WIRE 608 960 784 960
            WIRE 784 960 800 960
        END BRANCH
        IOMARKER 608 960 sel(3:0) R180 28
    END SHEET
END SCHEMATIC
