library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity max1617 is
    Port ( --in1 : in std_logic_vector(7 downto 0);--forward
           in1 : in std_logic_vector(7 downto 0);--RA
           in2 : in std_logic_vector(7 downto 0);--RB
           in3 : in std_logic_vector(7 downto 0);--AA/BB
           out1 : out std_logic_vector(7 downto 0);
           sel : in std_logic_vector(1 downto 0));
end max1617;

architecture Behavioral of max1617 is

begin
	process(in1,in2,in3,sel)
	begin
		case  sel is
		when "00" => out1 <= in1;
		when "01" => out1 <= in2;
		when "10" => out1 <= in3;
		when "11" => out1 <= in3;
		when others => null;
		end case;
	end process;


end Behavioral;
