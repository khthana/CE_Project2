library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity Rn_Addr_Dec is
    Port ( 	inst_byte1	: in	std_logic_vector(2 downto 0);		-- Incoming Instruction Byte 1
	 			bank			: in	std_logic_vector(1 downto 0);		-- Incoming Current Bank of General Purpose Memory
	 			out1 			: out std_logic_vector(7 downto 0));	--	Outgoing Address of General Purpose Memory
end Rn_Addr_Dec;

architecture RTL of Rn_Addr_Dec is
begin
	process(inst_byte1,bank)
	begin
		case bank is
			when "00" 	=>	case inst_byte1(2 downto 0) is	-- Bank 0 Address 00-07
									when "000" => out1 <= "00000000";	
									when "001" => out1 <= "00000001";
									when "010" => out1 <= "00000010";
									when "011" => out1 <= "00000011";
									when "100" => out1 <= "00000100";
									when "101" => out1 <= "00000101";
									when "110" => out1 <= "00000110";
									when "111" => out1 <= "00000111";	
									when others => out1 <= "--------";
								end case;
			when "01"	=> case inst_byte1(2 downto 0) is	-- Bank 1 Address 08-0f
									when "000" => out1 <= "00001000";
									when "001" => out1 <= "00001001";
									when "010" => out1 <= "00001010";
									when "011" => out1 <= "00001011";
									when "100" => out1 <= "00001100";
									when "101" => out1 <= "00001101";
									when "110" => out1 <= "00001110";
									when "111" => out1 <= "00001111";
									when others => out1 <= "--------";
								end case;
			when "10"	=>	case inst_byte1(2 downto 0) is	-- Bank 2 Address 10-17
									when "000" => out1 <= "00010000";
									when "001" => out1 <= "00010001";
									when "010" => out1 <= "00010010";
									when "011" => out1 <= "00010011";
									when "100" => out1 <= "00010100";
									when "101" => out1 <= "00010101";
									when "110" => out1 <= "00010110";
									when "111" => out1 <= "00010111";
									when others => out1 <= "--------";
								end case;
			when "11"	=>	case inst_byte1(2 downto 0) is	-- Bank 3 Address 18-1f
									when "000" => out1 <= "00011000";
									when "001" => out1 <= "00011001";
									when "010" => out1 <= "00011010";
									when "011" => out1 <= "00011011";
									when "100" => out1 <= "00011100";
									when "101" => out1 <= "00011101";
									when "110" => out1 <= "00011110";
									when "111" => out1 <= "00011111";
									when others => out1 <= "--------";
								end case;
			when others => out1 <= "--------";	-- When no match bank return high impedance
		end case;
	end process;
end RTL;