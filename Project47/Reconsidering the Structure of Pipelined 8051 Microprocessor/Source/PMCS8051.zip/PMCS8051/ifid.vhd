library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity IFID is
	port (
			clk	: in std_logic;
			rst	: in std_logic;
			hold	: in std_logic;
			-- Data for Decode Stage
			in1 	: in std_logic_vector(7 downto 0);
			in2 	: in std_logic_vector(7 downto 0);
			in3 	: in std_logic_vector(7 downto 0);
			out1 	: out std_logic_vector(7 downto 0);
			out2 	: out std_logic_vector(7 downto 0);
			out3 	: out std_logic_vector(7 downto 0)
			);
end IFID;

architecture RTL of IFID is
begin
	process(rst,clk)
	begin
		if (rst = '1') then
			out1 <= "00000000";
			out2 <= "--------";
			out3 <= "--------";
		elsif (rising_edge(clk) and rst = '0') then
			out1 <= in1;
			out2 <= in2;
			out3 <= in3;
		end if;
	end process;
end RTL;
