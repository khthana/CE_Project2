library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity port0 is
	port(	data_in  	:in		std_logic_vector(7 downto 0);
			data_out		:out   	std_logic_vector(7 downto 0);
			port_in		:in		std_logic_vector(7 downto 0);
			port_out		:out		std_logic_vector(7 downto 0);
			load_in		:in		std_logic;
			reset			:in		std_logic;
			clock			:in		std_logic);
			
end port0;

architecture rtl of port0 is

begin

	process (data_in, reset, clock)
	begin
		if (reset = '1') then
			port_out <= "11111111";
			data_out <= "11111111";
		elsif (rising_edge(Clock) and load_in = '1' ) then
			data_out <= port_in;			
			port_out <= data_in;
		end if;
	end process;

end rtl;



