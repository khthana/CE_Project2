--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : xil_1644_5
-- /___/   /\     Timestamp : 02/11/2005 05:04:20
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: internal_ram_bank
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity internal_ram_bank is
   port ( 	w_addr : in    std_logic_vector (7 downto 0); 
				r_addr : in    std_logic_vector (7 downto 0); 
          	di      : in    std_logic_vector (7 downto 0); 
          	do      : out   std_logic_vector (7 downto 0));
end internal_ram_bank;

architecture BEHAVIORAL of internal_ram_bank is
begin
end BEHAVIORAL;

-- synopsys translate_off
configuration CFG_internal_ram_bank of  internal_ram_bank is
   for BEHAVIORAL
   end for;
end CFG_internal_ram_bank;
-- synopsys translate_on

