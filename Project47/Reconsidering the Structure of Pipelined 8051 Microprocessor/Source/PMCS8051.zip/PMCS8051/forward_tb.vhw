-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Mar 21 18:50:12 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY forward_tb IS
END forward_tb;

ARCHITECTURE testbench_arch OF forward_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT forwarder
		PORT (
			s1 : In  std_logic_vector (7 DOWNTO 0);
			s2 : In  std_logic_vector (7 DOWNTO 0);
			d1 : In  std_logic_vector (7 DOWNTO 0);
			d2 : In  std_logic_vector (7 DOWNTO 0);
			out1 : Out  std_logic_vector (1 DOWNTO 0);
			out2 : Out  std_logic_vector (1 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL s1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL s2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL d1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL d2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out1 : std_logic_vector (1 DOWNTO 0);
	SIGNAL out2 : std_logic_vector (1 DOWNTO 0);

BEGIN
	UUT : forwarder
	PORT MAP (
		s1 => s1,
		s2 => s2,
		d1 => d1,
		d2 => d2,
		out1 => out1,
		out2 => out2
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (1 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_out2(
			next_out2 : std_logic_vector (1 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out2 /= next_out2) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out2="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out2);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out2);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		s1 <= transport std_logic_vector'("00000000"); --0
		s2 <= transport std_logic_vector'("11111111"); --FF
		d1 <= transport std_logic_vector'("00000000"); --0
		d2 <= transport std_logic_vector'("11111111"); --FF
		-- --------------------
		WAIT FOR 100 ns; -- Time=100 ns
		s1 <= transport std_logic_vector'("00000001"); --1
		s2 <= transport std_logic_vector'("11111110"); --FE
		d1 <= transport std_logic_vector'("00000010"); --2
		d2 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 100 ns; -- Time=200 ns
		s1 <= transport std_logic_vector'("00000010"); --2
		s2 <= transport std_logic_vector'("11111101"); --FD
		d1 <= transport std_logic_vector'("00000100"); --4
		d2 <= transport std_logic_vector'("11111011"); --FB
		-- --------------------
		WAIT FOR 100 ns; -- Time=300 ns
		s1 <= transport std_logic_vector'("00000011"); --3
		s2 <= transport std_logic_vector'("11111100"); --FC
		d1 <= transport std_logic_vector'("00000110"); --6
		d2 <= transport std_logic_vector'("11111001"); --F9
		-- --------------------
		WAIT FOR 100 ns; -- Time=400 ns
		s1 <= transport std_logic_vector'("00000100"); --4
		s2 <= transport std_logic_vector'("11111011"); --FB
		d1 <= transport std_logic_vector'("00001000"); --8
		d2 <= transport std_logic_vector'("11110111"); --F7
		-- --------------------
		WAIT FOR 100 ns; -- Time=500 ns
		s1 <= transport std_logic_vector'("00000101"); --5
		s2 <= transport std_logic_vector'("11111010"); --FA
		d1 <= transport std_logic_vector'("00001010"); --A
		d2 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 100 ns; -- Time=600 ns
		s1 <= transport std_logic_vector'("00000110"); --6
		s2 <= transport std_logic_vector'("11111001"); --F9
		d1 <= transport std_logic_vector'("00000110"); --6
		d2 <= transport std_logic_vector'("11110011"); --F3
		-- --------------------
		WAIT FOR 100 ns; -- Time=700 ns
		s1 <= transport std_logic_vector'("00000111"); --7
		s2 <= transport std_logic_vector'("11111000"); --F8
		d1 <= transport std_logic_vector'("00001110"); --E
		d2 <= transport std_logic_vector'("11110001"); --F1
		-- --------------------
		WAIT FOR 100 ns; -- Time=800 ns
		s1 <= transport std_logic_vector'("00001000"); --8
		s2 <= transport std_logic_vector'("11110111"); --F7
		d1 <= transport std_logic_vector'("00010000"); --10
		d2 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 100 ns; -- Time=900 ns
		s1 <= transport std_logic_vector'("00001001"); --9
		s2 <= transport std_logic_vector'("11110110"); --F6
		d1 <= transport std_logic_vector'("00010010"); --12
		d2 <= transport std_logic_vector'("11101101"); --ED
		-- --------------------
		WAIT FOR 100 ns; -- Time=1000 ns
		s1 <= transport std_logic_vector'("00001010"); --A
		s2 <= transport std_logic_vector'("11110101"); --F5
		d1 <= transport std_logic_vector'("00010100"); --14
		d2 <= transport std_logic_vector'("00001010"); --A
		-- --------------------
		WAIT FOR 100 ns; -- Time=1100 ns
		s1 <= transport std_logic_vector'("00001011"); --B
		s2 <= transport std_logic_vector'("11110100"); --F4
		d1 <= transport std_logic_vector'("00010110"); --16
		d2 <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 100 ns; -- Time=1200 ns
		s1 <= transport std_logic_vector'("00001100"); --C
		s2 <= transport std_logic_vector'("11110011"); --F3
		d1 <= transport std_logic_vector'("00011000"); --18
		d2 <= transport std_logic_vector'("11100111"); --E7
		-- --------------------
		WAIT FOR 100 ns; -- Time=1300 ns
		s1 <= transport std_logic_vector'("00001101"); --D
		s2 <= transport std_logic_vector'("11110010"); --F2
		d1 <= transport std_logic_vector'("00011010"); --1A
		d2 <= transport std_logic_vector'("11100101"); --E5
		-- --------------------
		WAIT FOR 100 ns; -- Time=1400 ns
		s1 <= transport std_logic_vector'("00001110"); --E
		s2 <= transport std_logic_vector'("11110001"); --F1
		d1 <= transport std_logic_vector'("00011100"); --1C
		d2 <= transport std_logic_vector'("11100011"); --E3
		-- --------------------
		WAIT FOR 100 ns; -- Time=1500 ns
		s1 <= transport std_logic_vector'("00001111"); --F
		s2 <= transport std_logic_vector'("11110000"); --F0
		d1 <= transport std_logic_vector'("00001111"); --F
		d2 <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 100 ns; -- Time=1600 ns
		s1 <= transport std_logic_vector'("00010000"); --10
		s2 <= transport std_logic_vector'("11101111"); --EF
		d1 <= transport std_logic_vector'("00100000"); --20
		d2 <= transport std_logic_vector'("11011111"); --DF
		-- --------------------
		WAIT FOR 100 ns; -- Time=1700 ns
		s1 <= transport std_logic_vector'("00010001"); --11
		s2 <= transport std_logic_vector'("11101110"); --EE
		d1 <= transport std_logic_vector'("00100010"); --22
		d2 <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 100 ns; -- Time=1800 ns
		s1 <= transport std_logic_vector'("00010010"); --12
		s2 <= transport std_logic_vector'("11101101"); --ED
		d1 <= transport std_logic_vector'("00100100"); --24
		d2 <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 100 ns; -- Time=1900 ns
		s1 <= transport std_logic_vector'("00010011"); --13
		s2 <= transport std_logic_vector'("11101100"); --EC
		d1 <= transport std_logic_vector'("00100110"); --26
		d2 <= transport std_logic_vector'("11011001"); --D9
		-- --------------------
		WAIT FOR 100 ns; -- Time=2000 ns
		s1 <= transport std_logic_vector'("00010100"); --14
		s2 <= transport std_logic_vector'("11101011"); --EB
		d1 <= transport std_logic_vector'("00101000"); --28
		d2 <= transport std_logic_vector'("11010111"); --D7
		-- --------------------
		WAIT FOR 100 ns; -- Time=2100 ns
		s1 <= transport std_logic_vector'("00010101"); --15
		s2 <= transport std_logic_vector'("11101010"); --EA
		d1 <= transport std_logic_vector'("00101010"); --2A
		d2 <= transport std_logic_vector'("11010101"); --D5
		-- --------------------
		WAIT FOR 100 ns; -- Time=2200 ns
		s1 <= transport std_logic_vector'("00010110"); --16
		s2 <= transport std_logic_vector'("11101001"); --E9
		d1 <= transport std_logic_vector'("00101100"); --2C
		d2 <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 100 ns; -- Time=2300 ns
		s1 <= transport std_logic_vector'("00010111"); --17
		s2 <= transport std_logic_vector'("11101000"); --E8
		d1 <= transport std_logic_vector'("00101110"); --2E
		d2 <= transport std_logic_vector'("11010001"); --D1
		-- --------------------
		WAIT FOR 100 ns; -- Time=2400 ns
		s1 <= transport std_logic_vector'("00011000"); --18
		s2 <= transport std_logic_vector'("11100111"); --E7
		d1 <= transport std_logic_vector'("00110000"); --30
		d2 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 100 ns; -- Time=2500 ns
		s1 <= transport std_logic_vector'("00011001"); --19
		s2 <= transport std_logic_vector'("11100110"); --E6
		d1 <= transport std_logic_vector'("00110010"); --32
		d2 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 100 ns; -- Time=2600 ns
		s1 <= transport std_logic_vector'("00011010"); --1A
		s2 <= transport std_logic_vector'("11100101"); --E5
		d1 <= transport std_logic_vector'("00110100"); --34
		d2 <= transport std_logic_vector'("11001011"); --CB
		-- --------------------
		WAIT FOR 100 ns; -- Time=2700 ns
		s1 <= transport std_logic_vector'("00011011"); --1B
		s2 <= transport std_logic_vector'("11100100"); --E4
		d1 <= transport std_logic_vector'("00110110"); --36
		d2 <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 100 ns; -- Time=2800 ns
		s1 <= transport std_logic_vector'("00011100"); --1C
		s2 <= transport std_logic_vector'("11100011"); --E3
		d1 <= transport std_logic_vector'("00111000"); --38
		d2 <= transport std_logic_vector'("11000111"); --C7
		-- --------------------
		WAIT FOR 100 ns; -- Time=2900 ns
		s1 <= transport std_logic_vector'("00011101"); --1D
		s2 <= transport std_logic_vector'("11100010"); --E2
		d1 <= transport std_logic_vector'("00111010"); --3A
		d2 <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 100 ns; -- Time=3000 ns
		s1 <= transport std_logic_vector'("00011110"); --1E
		s2 <= transport std_logic_vector'("11100001"); --E1
		d1 <= transport std_logic_vector'("00111100"); --3C
		d2 <= transport std_logic_vector'("11000011"); --C3
		-- --------------------
		WAIT FOR 100 ns; -- Time=3100 ns
		s1 <= transport std_logic_vector'("00011111"); --1F
		s2 <= transport std_logic_vector'("11100000"); --E0
		d1 <= transport std_logic_vector'("00111110"); --3E
		d2 <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 100 ns; -- Time=3200 ns
		s1 <= transport std_logic_vector'("00100000"); --20
		s2 <= transport std_logic_vector'("11011111"); --DF
		d1 <= transport std_logic_vector'("01000000"); --40
		d2 <= transport std_logic_vector'("10111111"); --BF
		-- --------------------
		WAIT FOR 100 ns; -- Time=3300 ns
		s1 <= transport std_logic_vector'("00100001"); --21
		s2 <= transport std_logic_vector'("11011110"); --DE
		d1 <= transport std_logic_vector'("01000010"); --42
		d2 <= transport std_logic_vector'("10111101"); --BD
		-- --------------------
		WAIT FOR 100 ns; -- Time=3400 ns
		s1 <= transport std_logic_vector'("00100010"); --22
		s2 <= transport std_logic_vector'("11011101"); --DD
		d1 <= transport std_logic_vector'("01000100"); --44
		d2 <= transport std_logic_vector'("10111011"); --BB
		-- --------------------
		WAIT FOR 100 ns; -- Time=3500 ns
		s1 <= transport std_logic_vector'("00100011"); --23
		s2 <= transport std_logic_vector'("11011100"); --DC
		d1 <= transport std_logic_vector'("01000110"); --46
		d2 <= transport std_logic_vector'("10111001"); --B9
		-- --------------------
		WAIT FOR 100 ns; -- Time=3600 ns
		s1 <= transport std_logic_vector'("00100100"); --24
		s2 <= transport std_logic_vector'("11011011"); --DB
		d1 <= transport std_logic_vector'("01001000"); --48
		d2 <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 100 ns; -- Time=3700 ns
		s1 <= transport std_logic_vector'("00100101"); --25
		s2 <= transport std_logic_vector'("11011010"); --DA
		d1 <= transport std_logic_vector'("01001010"); --4A
		d2 <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 100 ns; -- Time=3800 ns
		s1 <= transport std_logic_vector'("00100110"); --26
		s2 <= transport std_logic_vector'("11011001"); --D9
		d1 <= transport std_logic_vector'("01001100"); --4C
		d2 <= transport std_logic_vector'("10110011"); --B3
		-- --------------------
		WAIT FOR 100 ns; -- Time=3900 ns
		s1 <= transport std_logic_vector'("00100111"); --27
		s2 <= transport std_logic_vector'("11011000"); --D8
		d1 <= transport std_logic_vector'("01001110"); --4E
		d2 <= transport std_logic_vector'("10110001"); --B1
		-- --------------------
		WAIT FOR 100 ns; -- Time=4000 ns
		s1 <= transport std_logic_vector'("00101000"); --28
		s2 <= transport std_logic_vector'("11010111"); --D7
		d1 <= transport std_logic_vector'("01010000"); --50
		d2 <= transport std_logic_vector'("10101111"); --AF
		-- --------------------
		WAIT FOR 100 ns; -- Time=4100 ns
		s1 <= transport std_logic_vector'("00101001"); --29
		s2 <= transport std_logic_vector'("11010110"); --D6
		d1 <= transport std_logic_vector'("01010010"); --52
		d2 <= transport std_logic_vector'("10101101"); --AD
		-- --------------------
		WAIT FOR 100 ns; -- Time=4200 ns
		s1 <= transport std_logic_vector'("00101010"); --2A
		s2 <= transport std_logic_vector'("11010101"); --D5
		d1 <= transport std_logic_vector'("01010100"); --54
		d2 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 100 ns; -- Time=4300 ns
		s1 <= transport std_logic_vector'("00101011"); --2B
		s2 <= transport std_logic_vector'("11010100"); --D4
		d1 <= transport std_logic_vector'("01010110"); --56
		d2 <= transport std_logic_vector'("10101001"); --A9
		-- --------------------
		WAIT FOR 100 ns; -- Time=4400 ns
		s1 <= transport std_logic_vector'("00101100"); --2C
		s2 <= transport std_logic_vector'("11010011"); --D3
		d1 <= transport std_logic_vector'("01011000"); --58
		d2 <= transport std_logic_vector'("10100111"); --A7
		-- --------------------
		WAIT FOR 100 ns; -- Time=4500 ns
		s1 <= transport std_logic_vector'("00101101"); --2D
		s2 <= transport std_logic_vector'("11010010"); --D2
		d1 <= transport std_logic_vector'("01011010"); --5A
		d2 <= transport std_logic_vector'("10100101"); --A5
		-- --------------------
		WAIT FOR 100 ns; -- Time=4600 ns
		s1 <= transport std_logic_vector'("00101110"); --2E
		s2 <= transport std_logic_vector'("11010001"); --D1
		d1 <= transport std_logic_vector'("01011100"); --5C
		d2 <= transport std_logic_vector'("10100011"); --A3
		-- --------------------
		WAIT FOR 100 ns; -- Time=4700 ns
		s1 <= transport std_logic_vector'("00101111"); --2F
		s2 <= transport std_logic_vector'("11010000"); --D0
		d1 <= transport std_logic_vector'("01011110"); --5E
		d2 <= transport std_logic_vector'("10100001"); --A1
		-- --------------------
		WAIT FOR 100 ns; -- Time=4800 ns
		s1 <= transport std_logic_vector'("00110000"); --30
		s2 <= transport std_logic_vector'("11001111"); --CF
		d1 <= transport std_logic_vector'("01100000"); --60
		d2 <= transport std_logic_vector'("10011111"); --9F
		-- --------------------
		WAIT FOR 100 ns; -- Time=4900 ns
		s1 <= transport std_logic_vector'("00110001"); --31
		s2 <= transport std_logic_vector'("11001110"); --CE
		d1 <= transport std_logic_vector'("01100010"); --62
		d2 <= transport std_logic_vector'("10011101"); --9D
		-- --------------------
		WAIT FOR 100 ns; -- Time=5000 ns
		s1 <= transport std_logic_vector'("00110010"); --32
		s2 <= transport std_logic_vector'("11001101"); --CD
		d1 <= transport std_logic_vector'("01100100"); --64
		d2 <= transport std_logic_vector'("10011011"); --9B
		-- --------------------
		WAIT FOR 100 ns; -- Time=5100 ns
		s1 <= transport std_logic_vector'("00110011"); --33
		s2 <= transport std_logic_vector'("11001100"); --CC
		d1 <= transport std_logic_vector'("01100110"); --66
		d2 <= transport std_logic_vector'("10011001"); --99
		-- --------------------
		WAIT FOR 100 ns; -- Time=5200 ns
		s1 <= transport std_logic_vector'("00110100"); --34
		s2 <= transport std_logic_vector'("11001011"); --CB
		d1 <= transport std_logic_vector'("01101000"); --68
		d2 <= transport std_logic_vector'("10010111"); --97
		-- --------------------
		WAIT FOR 100 ns; -- Time=5300 ns
		s1 <= transport std_logic_vector'("00110101"); --35
		s2 <= transport std_logic_vector'("11001010"); --CA
		d1 <= transport std_logic_vector'("01101010"); --6A
		d2 <= transport std_logic_vector'("10010101"); --95
		-- --------------------
		WAIT FOR 100 ns; -- Time=5400 ns
		s1 <= transport std_logic_vector'("00110110"); --36
		s2 <= transport std_logic_vector'("11001001"); --C9
		d1 <= transport std_logic_vector'("01101100"); --6C
		d2 <= transport std_logic_vector'("10010011"); --93
		-- --------------------
		WAIT FOR 100 ns; -- Time=5500 ns
		s1 <= transport std_logic_vector'("00110111"); --37
		s2 <= transport std_logic_vector'("11001000"); --C8
		d1 <= transport std_logic_vector'("01101110"); --6E
		d2 <= transport std_logic_vector'("10010001"); --91
		-- --------------------
		WAIT FOR 100 ns; -- Time=5600 ns
		s1 <= transport std_logic_vector'("00111000"); --38
		s2 <= transport std_logic_vector'("11000111"); --C7
		d1 <= transport std_logic_vector'("01110000"); --70
		d2 <= transport std_logic_vector'("10001111"); --8F
		-- --------------------
		WAIT FOR 100 ns; -- Time=5700 ns
		s1 <= transport std_logic_vector'("00111001"); --39
		s2 <= transport std_logic_vector'("11000110"); --C6
		d1 <= transport std_logic_vector'("01110010"); --72
		d2 <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 100 ns; -- Time=5800 ns
		s1 <= transport std_logic_vector'("00111010"); --3A
		s2 <= transport std_logic_vector'("11000101"); --C5
		d1 <= transport std_logic_vector'("01110100"); --74
		d2 <= transport std_logic_vector'("10001011"); --8B
		-- --------------------
		WAIT FOR 100 ns; -- Time=5900 ns
		s1 <= transport std_logic_vector'("00111011"); --3B
		s2 <= transport std_logic_vector'("11000100"); --C4
		d1 <= transport std_logic_vector'("01110110"); --76
		d2 <= transport std_logic_vector'("10001001"); --89
		-- --------------------
		WAIT FOR 100 ns; -- Time=6000 ns
		s1 <= transport std_logic_vector'("00111100"); --3C
		s2 <= transport std_logic_vector'("11000011"); --C3
		d1 <= transport std_logic_vector'("01111000"); --78
		d2 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 100 ns; -- Time=6100 ns
		s1 <= transport std_logic_vector'("00111101"); --3D
		s2 <= transport std_logic_vector'("11000010"); --C2
		d1 <= transport std_logic_vector'("01111010"); --7A
		d2 <= transport std_logic_vector'("10000101"); --85
		-- --------------------
		WAIT FOR 100 ns; -- Time=6200 ns
		s1 <= transport std_logic_vector'("00111110"); --3E
		s2 <= transport std_logic_vector'("11000001"); --C1
		d1 <= transport std_logic_vector'("01111100"); --7C
		d2 <= transport std_logic_vector'("10000011"); --83
		-- --------------------
		WAIT FOR 100 ns; -- Time=6300 ns
		s1 <= transport std_logic_vector'("00111111"); --3F
		s2 <= transport std_logic_vector'("11000000"); --C0
		d1 <= transport std_logic_vector'("01111110"); --7E
		d2 <= transport std_logic_vector'("10000001"); --81
		-- --------------------
		WAIT FOR 100 ns; -- Time=6400 ns
		s1 <= transport std_logic_vector'("01000000"); --40
		s2 <= transport std_logic_vector'("10111111"); --BF
		d1 <= transport std_logic_vector'("10000000"); --80
		d2 <= transport std_logic_vector'("01111111"); --7F
		-- --------------------
		WAIT FOR 100 ns; -- Time=6500 ns
		s1 <= transport std_logic_vector'("01000001"); --41
		s2 <= transport std_logic_vector'("10111110"); --BE
		d1 <= transport std_logic_vector'("10000010"); --82
		d2 <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 100 ns; -- Time=6600 ns
		s1 <= transport std_logic_vector'("01000010"); --42
		s2 <= transport std_logic_vector'("10111101"); --BD
		d1 <= transport std_logic_vector'("10000100"); --84
		d2 <= transport std_logic_vector'("01111011"); --7B
		-- --------------------
		WAIT FOR 100 ns; -- Time=6700 ns
		s1 <= transport std_logic_vector'("01000011"); --43
		s2 <= transport std_logic_vector'("10111100"); --BC
		d1 <= transport std_logic_vector'("10000110"); --86
		d2 <= transport std_logic_vector'("01111001"); --79
		-- --------------------
		WAIT FOR 100 ns; -- Time=6800 ns
		s1 <= transport std_logic_vector'("01000100"); --44
		s2 <= transport std_logic_vector'("10111011"); --BB
		d1 <= transport std_logic_vector'("10001000"); --88
		d2 <= transport std_logic_vector'("01110111"); --77
		-- --------------------
		WAIT FOR 100 ns; -- Time=6900 ns
		s1 <= transport std_logic_vector'("01000101"); --45
		s2 <= transport std_logic_vector'("10111010"); --BA
		d1 <= transport std_logic_vector'("10001010"); --8A
		d2 <= transport std_logic_vector'("01110101"); --75
		-- --------------------
		WAIT FOR 100 ns; -- Time=7000 ns
		s1 <= transport std_logic_vector'("01000110"); --46
		s2 <= transport std_logic_vector'("10111001"); --B9
		d1 <= transport std_logic_vector'("10001100"); --8C
		d2 <= transport std_logic_vector'("01110011"); --73
		-- --------------------
		WAIT FOR 100 ns; -- Time=7100 ns
		s1 <= transport std_logic_vector'("01000111"); --47
		s2 <= transport std_logic_vector'("10111000"); --B8
		d1 <= transport std_logic_vector'("10001110"); --8E
		d2 <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 100 ns; -- Time=7200 ns
		s1 <= transport std_logic_vector'("01001000"); --48
		s2 <= transport std_logic_vector'("10110111"); --B7
		d1 <= transport std_logic_vector'("10010000"); --90
		d2 <= transport std_logic_vector'("01101111"); --6F
		-- --------------------
		WAIT FOR 100 ns; -- Time=7300 ns
		s1 <= transport std_logic_vector'("01001001"); --49
		s2 <= transport std_logic_vector'("10110110"); --B6
		d1 <= transport std_logic_vector'("10010010"); --92
		d2 <= transport std_logic_vector'("01101101"); --6D
		-- --------------------
		WAIT FOR 100 ns; -- Time=7400 ns
		s1 <= transport std_logic_vector'("01001010"); --4A
		s2 <= transport std_logic_vector'("10110101"); --B5
		d1 <= transport std_logic_vector'("10010100"); --94
		d2 <= transport std_logic_vector'("01101011"); --6B
		-- --------------------
		WAIT FOR 100 ns; -- Time=7500 ns
		s1 <= transport std_logic_vector'("01001011"); --4B
		s2 <= transport std_logic_vector'("10110100"); --B4
		d1 <= transport std_logic_vector'("10010110"); --96
		d2 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 100 ns; -- Time=7600 ns
		s1 <= transport std_logic_vector'("01001100"); --4C
		s2 <= transport std_logic_vector'("10110011"); --B3
		d1 <= transport std_logic_vector'("10011000"); --98
		d2 <= transport std_logic_vector'("01100111"); --67
		-- --------------------
		WAIT FOR 100 ns; -- Time=7700 ns
		s1 <= transport std_logic_vector'("01001101"); --4D
		s2 <= transport std_logic_vector'("10110010"); --B2
		d1 <= transport std_logic_vector'("10011010"); --9A
		d2 <= transport std_logic_vector'("01100101"); --65
		-- --------------------
		WAIT FOR 100 ns; -- Time=7800 ns
		s1 <= transport std_logic_vector'("01001110"); --4E
		s2 <= transport std_logic_vector'("10110001"); --B1
		d1 <= transport std_logic_vector'("10011100"); --9C
		d2 <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 100 ns; -- Time=7900 ns
		s1 <= transport std_logic_vector'("01001111"); --4F
		s2 <= transport std_logic_vector'("10110000"); --B0
		d1 <= transport std_logic_vector'("10011110"); --9E
		d2 <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 100 ns; -- Time=8000 ns
		s1 <= transport std_logic_vector'("01010000"); --50
		s2 <= transport std_logic_vector'("10101111"); --AF
		d1 <= transport std_logic_vector'("10100000"); --A0
		d2 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ns; -- Time=8100 ns
		s1 <= transport std_logic_vector'("01010001"); --51
		s2 <= transport std_logic_vector'("10101110"); --AE
		d1 <= transport std_logic_vector'("10100010"); --A2
		d2 <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 100 ns; -- Time=8200 ns
		s1 <= transport std_logic_vector'("01010010"); --52
		s2 <= transport std_logic_vector'("10101101"); --AD
		d1 <= transport std_logic_vector'("10100100"); --A4
		d2 <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 100 ns; -- Time=8300 ns
		s1 <= transport std_logic_vector'("01010011"); --53
		s2 <= transport std_logic_vector'("10101100"); --AC
		d1 <= transport std_logic_vector'("10100110"); --A6
		d2 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 100 ns; -- Time=8400 ns
		s1 <= transport std_logic_vector'("01010100"); --54
		s2 <= transport std_logic_vector'("10101011"); --AB
		d1 <= transport std_logic_vector'("10101000"); --A8
		d2 <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 100 ns; -- Time=8500 ns
		s1 <= transport std_logic_vector'("01010101"); --55
		s2 <= transport std_logic_vector'("10101010"); --AA
		d1 <= transport std_logic_vector'("10101010"); --AA
		d2 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 100 ns; -- Time=8600 ns
		s1 <= transport std_logic_vector'("01010110"); --56
		s2 <= transport std_logic_vector'("10101001"); --A9
		d1 <= transport std_logic_vector'("10101100"); --AC
		d2 <= transport std_logic_vector'("01010011"); --53
		-- --------------------
		WAIT FOR 100 ns; -- Time=8700 ns
		s1 <= transport std_logic_vector'("01010111"); --57
		s2 <= transport std_logic_vector'("10101000"); --A8
		d1 <= transport std_logic_vector'("10101110"); --AE
		d2 <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 100 ns; -- Time=8800 ns
		s1 <= transport std_logic_vector'("01011000"); --58
		s2 <= transport std_logic_vector'("10100111"); --A7
		d1 <= transport std_logic_vector'("10110000"); --B0
		d2 <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 100 ns; -- Time=8900 ns
		s1 <= transport std_logic_vector'("01011001"); --59
		s2 <= transport std_logic_vector'("10100110"); --A6
		d1 <= transport std_logic_vector'("10110010"); --B2
		d2 <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 100 ns; -- Time=9000 ns
		s1 <= transport std_logic_vector'("01011010"); --5A
		s2 <= transport std_logic_vector'("10100101"); --A5
		d1 <= transport std_logic_vector'("10110100"); --B4
		d2 <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 100 ns; -- Time=9100 ns
		s1 <= transport std_logic_vector'("01011011"); --5B
		s2 <= transport std_logic_vector'("10100100"); --A4
		d1 <= transport std_logic_vector'("10110110"); --B6
		d2 <= transport std_logic_vector'("01001001"); --49
		-- --------------------
		WAIT FOR 100 ns; -- Time=9200 ns
		s1 <= transport std_logic_vector'("01011100"); --5C
		s2 <= transport std_logic_vector'("10100011"); --A3
		d1 <= transport std_logic_vector'("10111000"); --B8
		d2 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 100 ns; -- Time=9300 ns
		s1 <= transport std_logic_vector'("01011101"); --5D
		s2 <= transport std_logic_vector'("10100010"); --A2
		d1 <= transport std_logic_vector'("10111010"); --BA
		d2 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ns; -- Time=9400 ns
		s1 <= transport std_logic_vector'("01011110"); --5E
		s2 <= transport std_logic_vector'("10100001"); --A1
		d1 <= transport std_logic_vector'("10111100"); --BC
		d2 <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 100 ns; -- Time=9500 ns
		s1 <= transport std_logic_vector'("01011111"); --5F
		s2 <= transport std_logic_vector'("10100000"); --A0
		d1 <= transport std_logic_vector'("10111110"); --BE
		d2 <= transport std_logic_vector'("01000001"); --41
		-- --------------------
		WAIT FOR 100 ns; -- Time=9600 ns
		s1 <= transport std_logic_vector'("01100000"); --60
		s2 <= transport std_logic_vector'("10011111"); --9F
		d1 <= transport std_logic_vector'("11000000"); --C0
		d2 <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 100 ns; -- Time=9700 ns
		s1 <= transport std_logic_vector'("01100001"); --61
		s2 <= transport std_logic_vector'("10011110"); --9E
		d1 <= transport std_logic_vector'("11000010"); --C2
		d2 <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 100 ns; -- Time=9800 ns
		s1 <= transport std_logic_vector'("01100010"); --62
		s2 <= transport std_logic_vector'("10011101"); --9D
		d1 <= transport std_logic_vector'("11000100"); --C4
		d2 <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 100 ns; -- Time=9900 ns
		s1 <= transport std_logic_vector'("01100011"); --63
		s2 <= transport std_logic_vector'("10011100"); --9C
		d1 <= transport std_logic_vector'("11000110"); --C6
		d2 <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 100 ns; -- Time=10000 ns
		s1 <= transport std_logic_vector'("01100100"); --64
		s2 <= transport std_logic_vector'("10011011"); --9B
		d1 <= transport std_logic_vector'("11001000"); --C8
		d2 <= transport std_logic_vector'("00110111"); --37
		-- --------------------
		WAIT FOR 100 ns; -- Time=10100 ns
		s1 <= transport std_logic_vector'("01100101"); --65
		s2 <= transport std_logic_vector'("10011010"); --9A
		d1 <= transport std_logic_vector'("11001010"); --CA
		d2 <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 100 ns; -- Time=10200 ns
		s1 <= transport std_logic_vector'("01100110"); --66
		s2 <= transport std_logic_vector'("10011001"); --99
		d1 <= transport std_logic_vector'("11001100"); --CC
		d2 <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 100 ns; -- Time=10300 ns
		s1 <= transport std_logic_vector'("01100111"); --67
		s2 <= transport std_logic_vector'("10011000"); --98
		d1 <= transport std_logic_vector'("11001110"); --CE
		d2 <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 100 ns; -- Time=10400 ns
		s1 <= transport std_logic_vector'("01101000"); --68
		s2 <= transport std_logic_vector'("10010111"); --97
		d1 <= transport std_logic_vector'("11010000"); --D0
		d2 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 100 ns; -- Time=10500 ns
		s1 <= transport std_logic_vector'("01101001"); --69
		s2 <= transport std_logic_vector'("10010110"); --96
		d1 <= transport std_logic_vector'("11010010"); --D2
		d2 <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 100 ns; -- Time=10600 ns
		s1 <= transport std_logic_vector'("01101010"); --6A
		s2 <= transport std_logic_vector'("10010101"); --95
		d1 <= transport std_logic_vector'("11010100"); --D4
		d2 <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 100 ns; -- Time=10700 ns
		s1 <= transport std_logic_vector'("01101011"); --6B
		s2 <= transport std_logic_vector'("10010100"); --94
		d1 <= transport std_logic_vector'("11010110"); --D6
		d2 <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 100 ns; -- Time=10800 ns
		s1 <= transport std_logic_vector'("01101100"); --6C
		s2 <= transport std_logic_vector'("10010011"); --93
		d1 <= transport std_logic_vector'("11011000"); --D8
		d2 <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 100 ns; -- Time=10900 ns
		s1 <= transport std_logic_vector'("01101101"); --6D
		s2 <= transport std_logic_vector'("10010010"); --92
		d1 <= transport std_logic_vector'("11011010"); --DA
		d2 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ns; -- Time=11000 ns
		s1 <= transport std_logic_vector'("01101110"); --6E
		s2 <= transport std_logic_vector'("10010001"); --91
		d1 <= transport std_logic_vector'("11011100"); --DC
		d2 <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 100 ns; -- Time=11100 ns
		s1 <= transport std_logic_vector'("01101111"); --6F
		s2 <= transport std_logic_vector'("10010000"); --90
		d1 <= transport std_logic_vector'("11011110"); --DE
		d2 <= transport std_logic_vector'("00100001"); --21
		-- --------------------
		WAIT FOR 100 ns; -- Time=11200 ns
		s1 <= transport std_logic_vector'("01110000"); --70
		s2 <= transport std_logic_vector'("10001111"); --8F
		d1 <= transport std_logic_vector'("11100000"); --E0
		d2 <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 100 ns; -- Time=11300 ns
		s1 <= transport std_logic_vector'("01110001"); --71
		s2 <= transport std_logic_vector'("10001110"); --8E
		d1 <= transport std_logic_vector'("11100010"); --E2
		d2 <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 100 ns; -- Time=11400 ns
		s1 <= transport std_logic_vector'("01110010"); --72
		s2 <= transport std_logic_vector'("10001101"); --8D
		d1 <= transport std_logic_vector'("11100100"); --E4
		d2 <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 100 ns; -- Time=11500 ns
		s1 <= transport std_logic_vector'("01110011"); --73
		s2 <= transport std_logic_vector'("10001100"); --8C
		d1 <= transport std_logic_vector'("11100110"); --E6
		d2 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 100 ns; -- Time=11600 ns
		s1 <= transport std_logic_vector'("01110100"); --74
		s2 <= transport std_logic_vector'("10001011"); --8B
		d1 <= transport std_logic_vector'("11101000"); --E8
		d2 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 100 ns; -- Time=11700 ns
		s1 <= transport std_logic_vector'("01110101"); --75
		s2 <= transport std_logic_vector'("10001010"); --8A
		d1 <= transport std_logic_vector'("11101010"); --EA
		d2 <= transport std_logic_vector'("00010101"); --15
		-- --------------------
		WAIT FOR 100 ns; -- Time=11800 ns
		s1 <= transport std_logic_vector'("01110110"); --76
		s2 <= transport std_logic_vector'("10001001"); --89
		d1 <= transport std_logic_vector'("11101100"); --EC
		d2 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 100 ns; -- Time=11900 ns
		s1 <= transport std_logic_vector'("01110111"); --77
		s2 <= transport std_logic_vector'("10001000"); --88
		d1 <= transport std_logic_vector'("11101110"); --EE
		d2 <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 100 ns; -- Time=12000 ns
		s1 <= transport std_logic_vector'("01111000"); --78
		s2 <= transport std_logic_vector'("10000111"); --87
		d1 <= transport std_logic_vector'("11110000"); --F0
		d2 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 100 ns; -- Time=12100 ns
		s1 <= transport std_logic_vector'("01111001"); --79
		s2 <= transport std_logic_vector'("10000110"); --86
		d1 <= transport std_logic_vector'("11110010"); --F2
		d2 <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 100 ns; -- Time=12200 ns
		s1 <= transport std_logic_vector'("01111010"); --7A
		s2 <= transport std_logic_vector'("10000101"); --85
		d1 <= transport std_logic_vector'("11110100"); --F4
		d2 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 100 ns; -- Time=12300 ns
		s1 <= transport std_logic_vector'("01111011"); --7B
		s2 <= transport std_logic_vector'("10000100"); --84
		d1 <= transport std_logic_vector'("11110110"); --F6
		d2 <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ns; -- Time=12400 ns
		s1 <= transport std_logic_vector'("01111100"); --7C
		s2 <= transport std_logic_vector'("10000011"); --83
		d1 <= transport std_logic_vector'("11111000"); --F8
		d2 <= transport std_logic_vector'("00000111"); --7
		-- --------------------
		WAIT FOR 100 ns; -- Time=12500 ns
		s1 <= transport std_logic_vector'("01111101"); --7D
		s2 <= transport std_logic_vector'("10000010"); --82
		d1 <= transport std_logic_vector'("11111010"); --FA
		d2 <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 100 ns; -- Time=12600 ns
		s1 <= transport std_logic_vector'("01111110"); --7E
		s2 <= transport std_logic_vector'("10000001"); --81
		d1 <= transport std_logic_vector'("11111100"); --FC
		d2 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 100 ns; -- Time=12700 ns
		s1 <= transport std_logic_vector'("01111111"); --7F
		s2 <= transport std_logic_vector'("10000000"); --80
		d1 <= transport std_logic_vector'("11111110"); --FE
		d2 <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 100 ns; -- Time=12800 ns
		s1 <= transport std_logic_vector'("10000000"); --80
		s2 <= transport std_logic_vector'("01111111"); --7F
		d1 <= transport std_logic_vector'("00000000"); --0
		d2 <= transport std_logic_vector'("11111111"); --FF
		-- --------------------
		WAIT FOR 100 ns; -- Time=12900 ns
		s1 <= transport std_logic_vector'("10000001"); --81
		s2 <= transport std_logic_vector'("01111110"); --7E
		d1 <= transport std_logic_vector'("00000010"); --2
		d2 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 100 ns; -- Time=13000 ns
		s1 <= transport std_logic_vector'("10000010"); --82
		s2 <= transport std_logic_vector'("01111101"); --7D
		d1 <= transport std_logic_vector'("00000100"); --4
		d2 <= transport std_logic_vector'("11111011"); --FB
		-- --------------------
		WAIT FOR 100 ns; -- Time=13100 ns
		s1 <= transport std_logic_vector'("10000011"); --83
		s2 <= transport std_logic_vector'("01111100"); --7C
		d1 <= transport std_logic_vector'("00000110"); --6
		d2 <= transport std_logic_vector'("11111001"); --F9
		-- --------------------
		WAIT FOR 100 ns; -- Time=13200 ns
		s1 <= transport std_logic_vector'("10000100"); --84
		s2 <= transport std_logic_vector'("01111011"); --7B
		d1 <= transport std_logic_vector'("00001000"); --8
		d2 <= transport std_logic_vector'("11110111"); --F7
		-- --------------------
		WAIT FOR 100 ns; -- Time=13300 ns
		s1 <= transport std_logic_vector'("10000101"); --85
		s2 <= transport std_logic_vector'("01111010"); --7A
		d1 <= transport std_logic_vector'("00001010"); --A
		d2 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 100 ns; -- Time=13400 ns
		s1 <= transport std_logic_vector'("10000110"); --86
		s2 <= transport std_logic_vector'("01111001"); --79
		d1 <= transport std_logic_vector'("00001100"); --C
		d2 <= transport std_logic_vector'("11110011"); --F3
		-- --------------------
		WAIT FOR 100 ns; -- Time=13500 ns
		s1 <= transport std_logic_vector'("10000111"); --87
		s2 <= transport std_logic_vector'("01111000"); --78
		d1 <= transport std_logic_vector'("00001110"); --E
		d2 <= transport std_logic_vector'("11110001"); --F1
		-- --------------------
		WAIT FOR 100 ns; -- Time=13600 ns
		s1 <= transport std_logic_vector'("10001000"); --88
		s2 <= transport std_logic_vector'("01110111"); --77
		d1 <= transport std_logic_vector'("00010000"); --10
		d2 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 100 ns; -- Time=13700 ns
		s1 <= transport std_logic_vector'("10001001"); --89
		s2 <= transport std_logic_vector'("01110110"); --76
		d1 <= transport std_logic_vector'("00010010"); --12
		d2 <= transport std_logic_vector'("11101101"); --ED
		-- --------------------
		WAIT FOR 100 ns; -- Time=13800 ns
		s1 <= transport std_logic_vector'("10001010"); --8A
		s2 <= transport std_logic_vector'("01110101"); --75
		d1 <= transport std_logic_vector'("00010100"); --14
		d2 <= transport std_logic_vector'("11101011"); --EB
		-- --------------------
		WAIT FOR 100 ns; -- Time=13900 ns
		s1 <= transport std_logic_vector'("10001011"); --8B
		s2 <= transport std_logic_vector'("01110100"); --74
		d1 <= transport std_logic_vector'("00010110"); --16
		d2 <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 100 ns; -- Time=14000 ns
		s1 <= transport std_logic_vector'("10001100"); --8C
		s2 <= transport std_logic_vector'("01110011"); --73
		d1 <= transport std_logic_vector'("00011000"); --18
		d2 <= transport std_logic_vector'("11100111"); --E7
		-- --------------------
		WAIT FOR 100 ns; -- Time=14100 ns
		s1 <= transport std_logic_vector'("10001101"); --8D
		s2 <= transport std_logic_vector'("01110010"); --72
		d1 <= transport std_logic_vector'("00011010"); --1A
		d2 <= transport std_logic_vector'("11100101"); --E5
		-- --------------------
		WAIT FOR 100 ns; -- Time=14200 ns
		s1 <= transport std_logic_vector'("10001110"); --8E
		s2 <= transport std_logic_vector'("01110001"); --71
		d1 <= transport std_logic_vector'("00011100"); --1C
		d2 <= transport std_logic_vector'("11100011"); --E3
		-- --------------------
		WAIT FOR 100 ns; -- Time=14300 ns
		s1 <= transport std_logic_vector'("10001111"); --8F
		s2 <= transport std_logic_vector'("01110000"); --70
		d1 <= transport std_logic_vector'("00011110"); --1E
		d2 <= transport std_logic_vector'("11100001"); --E1
		-- --------------------
		WAIT FOR 100 ns; -- Time=14400 ns
		s1 <= transport std_logic_vector'("10010000"); --90
		s2 <= transport std_logic_vector'("01101111"); --6F
		d1 <= transport std_logic_vector'("00100000"); --20
		d2 <= transport std_logic_vector'("11011111"); --DF
		-- --------------------
		WAIT FOR 100 ns; -- Time=14500 ns
		s1 <= transport std_logic_vector'("10010001"); --91
		s2 <= transport std_logic_vector'("01101110"); --6E
		d1 <= transport std_logic_vector'("00100010"); --22
		d2 <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 100 ns; -- Time=14600 ns
		s1 <= transport std_logic_vector'("10010010"); --92
		s2 <= transport std_logic_vector'("01101101"); --6D
		d1 <= transport std_logic_vector'("00100100"); --24
		d2 <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 100 ns; -- Time=14700 ns
		s1 <= transport std_logic_vector'("10010011"); --93
		s2 <= transport std_logic_vector'("01101100"); --6C
		d1 <= transport std_logic_vector'("00100110"); --26
		d2 <= transport std_logic_vector'("11011001"); --D9
		-- --------------------
		WAIT FOR 100 ns; -- Time=14800 ns
		s1 <= transport std_logic_vector'("10010100"); --94
		s2 <= transport std_logic_vector'("01101011"); --6B
		d1 <= transport std_logic_vector'("00101000"); --28
		d2 <= transport std_logic_vector'("11010111"); --D7
		-- --------------------
		WAIT FOR 100 ns; -- Time=14900 ns
		s1 <= transport std_logic_vector'("10010101"); --95
		s2 <= transport std_logic_vector'("01101010"); --6A
		d1 <= transport std_logic_vector'("00101010"); --2A
		d2 <= transport std_logic_vector'("11010101"); --D5
		-- --------------------
		WAIT FOR 100 ns; -- Time=15000 ns
		s1 <= transport std_logic_vector'("10010110"); --96
		s2 <= transport std_logic_vector'("01101001"); --69
		d1 <= transport std_logic_vector'("00101100"); --2C
		d2 <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 100 ns; -- Time=15100 ns
		s1 <= transport std_logic_vector'("10010111"); --97
		s2 <= transport std_logic_vector'("01101000"); --68
		d1 <= transport std_logic_vector'("00101110"); --2E
		d2 <= transport std_logic_vector'("11010001"); --D1
		-- --------------------
		WAIT FOR 100 ns; -- Time=15200 ns
		s1 <= transport std_logic_vector'("10011000"); --98
		s2 <= transport std_logic_vector'("01100111"); --67
		d1 <= transport std_logic_vector'("00110000"); --30
		d2 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 100 ns; -- Time=15300 ns
		s1 <= transport std_logic_vector'("10011001"); --99
		s2 <= transport std_logic_vector'("01100110"); --66
		d1 <= transport std_logic_vector'("00110010"); --32
		d2 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 100 ns; -- Time=15400 ns
		s1 <= transport std_logic_vector'("10011010"); --9A
		s2 <= transport std_logic_vector'("01100101"); --65
		d1 <= transport std_logic_vector'("00110100"); --34
		d2 <= transport std_logic_vector'("11001011"); --CB
		-- --------------------
		WAIT FOR 100 ns; -- Time=15500 ns
		s1 <= transport std_logic_vector'("10011011"); --9B
		s2 <= transport std_logic_vector'("01100100"); --64
		d1 <= transport std_logic_vector'("00110110"); --36
		d2 <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 100 ns; -- Time=15600 ns
		s1 <= transport std_logic_vector'("10011100"); --9C
		s2 <= transport std_logic_vector'("01100011"); --63
		d1 <= transport std_logic_vector'("00111000"); --38
		d2 <= transport std_logic_vector'("11000111"); --C7
		-- --------------------
		WAIT FOR 100 ns; -- Time=15700 ns
		s1 <= transport std_logic_vector'("10011101"); --9D
		s2 <= transport std_logic_vector'("01100010"); --62
		d1 <= transport std_logic_vector'("00111010"); --3A
		d2 <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 100 ns; -- Time=15800 ns
		s1 <= transport std_logic_vector'("10011110"); --9E
		s2 <= transport std_logic_vector'("01100001"); --61
		d1 <= transport std_logic_vector'("00111100"); --3C
		d2 <= transport std_logic_vector'("11000011"); --C3
		-- --------------------
		WAIT FOR 100 ns; -- Time=15900 ns
		s1 <= transport std_logic_vector'("10011111"); --9F
		s2 <= transport std_logic_vector'("01100000"); --60
		d1 <= transport std_logic_vector'("00111110"); --3E
		d2 <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 100 ns; -- Time=16000 ns
		s1 <= transport std_logic_vector'("10100000"); --A0
		s2 <= transport std_logic_vector'("01011111"); --5F
		d1 <= transport std_logic_vector'("01000000"); --40
		d2 <= transport std_logic_vector'("10111111"); --BF
		-- --------------------
		WAIT FOR 100 ns; -- Time=16100 ns
		s1 <= transport std_logic_vector'("10100001"); --A1
		s2 <= transport std_logic_vector'("01011110"); --5E
		d1 <= transport std_logic_vector'("01000010"); --42
		d2 <= transport std_logic_vector'("10111101"); --BD
		-- --------------------
		WAIT FOR 100 ns; -- Time=16200 ns
		s1 <= transport std_logic_vector'("10100010"); --A2
		s2 <= transport std_logic_vector'("01011101"); --5D
		d1 <= transport std_logic_vector'("01000100"); --44
		d2 <= transport std_logic_vector'("10111011"); --BB
		-- --------------------
		WAIT FOR 100 ns; -- Time=16300 ns
		s1 <= transport std_logic_vector'("10100011"); --A3
		s2 <= transport std_logic_vector'("01011100"); --5C
		d1 <= transport std_logic_vector'("01000110"); --46
		d2 <= transport std_logic_vector'("10111001"); --B9
		-- --------------------
		WAIT FOR 100 ns; -- Time=16400 ns
		s1 <= transport std_logic_vector'("10100100"); --A4
		s2 <= transport std_logic_vector'("01011011"); --5B
		d1 <= transport std_logic_vector'("01001000"); --48
		d2 <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 100 ns; -- Time=16500 ns
		s1 <= transport std_logic_vector'("10100101"); --A5
		s2 <= transport std_logic_vector'("01011010"); --5A
		d1 <= transport std_logic_vector'("01001010"); --4A
		d2 <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 100 ns; -- Time=16600 ns
		s1 <= transport std_logic_vector'("10100110"); --A6
		s2 <= transport std_logic_vector'("01011001"); --59
		d1 <= transport std_logic_vector'("01001100"); --4C
		d2 <= transport std_logic_vector'("10110011"); --B3
		-- --------------------
		WAIT FOR 100 ns; -- Time=16700 ns
		s1 <= transport std_logic_vector'("10100111"); --A7
		s2 <= transport std_logic_vector'("01011000"); --58
		d1 <= transport std_logic_vector'("01001110"); --4E
		d2 <= transport std_logic_vector'("10110001"); --B1
		-- --------------------
		WAIT FOR 100 ns; -- Time=16800 ns
		s1 <= transport std_logic_vector'("10101000"); --A8
		s2 <= transport std_logic_vector'("01010111"); --57
		d1 <= transport std_logic_vector'("01010000"); --50
		d2 <= transport std_logic_vector'("10101111"); --AF
		-- --------------------
		WAIT FOR 100 ns; -- Time=16900 ns
		s1 <= transport std_logic_vector'("10101001"); --A9
		s2 <= transport std_logic_vector'("01010110"); --56
		d1 <= transport std_logic_vector'("01010010"); --52
		d2 <= transport std_logic_vector'("10101101"); --AD
		-- --------------------
		WAIT FOR 100 ns; -- Time=17000 ns
		s1 <= transport std_logic_vector'("10101010"); --AA
		s2 <= transport std_logic_vector'("01010101"); --55
		d1 <= transport std_logic_vector'("01010100"); --54
		d2 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 100 ns; -- Time=17100 ns
		s1 <= transport std_logic_vector'("10101011"); --AB
		s2 <= transport std_logic_vector'("01010100"); --54
		d1 <= transport std_logic_vector'("01010110"); --56
		d2 <= transport std_logic_vector'("10101001"); --A9
		-- --------------------
		WAIT FOR 100 ns; -- Time=17200 ns
		s1 <= transport std_logic_vector'("10101100"); --AC
		s2 <= transport std_logic_vector'("01010011"); --53
		d1 <= transport std_logic_vector'("01011000"); --58
		d2 <= transport std_logic_vector'("10100111"); --A7
		-- --------------------
		WAIT FOR 100 ns; -- Time=17300 ns
		s1 <= transport std_logic_vector'("10101101"); --AD
		s2 <= transport std_logic_vector'("01010010"); --52
		d1 <= transport std_logic_vector'("01011010"); --5A
		d2 <= transport std_logic_vector'("10100101"); --A5
		-- --------------------
		WAIT FOR 100 ns; -- Time=17400 ns
		s1 <= transport std_logic_vector'("10101110"); --AE
		s2 <= transport std_logic_vector'("01010001"); --51
		d1 <= transport std_logic_vector'("01011100"); --5C
		d2 <= transport std_logic_vector'("10100011"); --A3
		-- --------------------
		WAIT FOR 100 ns; -- Time=17500 ns
		s1 <= transport std_logic_vector'("10101111"); --AF
		s2 <= transport std_logic_vector'("01010000"); --50
		d1 <= transport std_logic_vector'("01011110"); --5E
		d2 <= transport std_logic_vector'("10100001"); --A1
		-- --------------------
		WAIT FOR 100 ns; -- Time=17600 ns
		s1 <= transport std_logic_vector'("10110000"); --B0
		s2 <= transport std_logic_vector'("01001111"); --4F
		d1 <= transport std_logic_vector'("01100000"); --60
		d2 <= transport std_logic_vector'("10011111"); --9F
		-- --------------------
		WAIT FOR 100 ns; -- Time=17700 ns
		s1 <= transport std_logic_vector'("10110001"); --B1
		s2 <= transport std_logic_vector'("01001110"); --4E
		d1 <= transport std_logic_vector'("01100010"); --62
		d2 <= transport std_logic_vector'("10011101"); --9D
		-- --------------------
		WAIT FOR 100 ns; -- Time=17800 ns
		s1 <= transport std_logic_vector'("10110010"); --B2
		s2 <= transport std_logic_vector'("01001101"); --4D
		d1 <= transport std_logic_vector'("01100100"); --64
		d2 <= transport std_logic_vector'("10011011"); --9B
		-- --------------------
		WAIT FOR 100 ns; -- Time=17900 ns
		s1 <= transport std_logic_vector'("10110011"); --B3
		s2 <= transport std_logic_vector'("01001100"); --4C
		d1 <= transport std_logic_vector'("01100110"); --66
		d2 <= transport std_logic_vector'("10011001"); --99
		-- --------------------
		WAIT FOR 100 ns; -- Time=18000 ns
		s1 <= transport std_logic_vector'("10110100"); --B4
		s2 <= transport std_logic_vector'("01001011"); --4B
		d1 <= transport std_logic_vector'("01101000"); --68
		d2 <= transport std_logic_vector'("10010111"); --97
		-- --------------------
		WAIT FOR 100 ns; -- Time=18100 ns
		s1 <= transport std_logic_vector'("10110101"); --B5
		s2 <= transport std_logic_vector'("01001010"); --4A
		d1 <= transport std_logic_vector'("01101010"); --6A
		d2 <= transport std_logic_vector'("10010101"); --95
		-- --------------------
		WAIT FOR 100 ns; -- Time=18200 ns
		s1 <= transport std_logic_vector'("10110110"); --B6
		s2 <= transport std_logic_vector'("01001001"); --49
		d1 <= transport std_logic_vector'("01101100"); --6C
		d2 <= transport std_logic_vector'("10010011"); --93
		-- --------------------
		WAIT FOR 100 ns; -- Time=18300 ns
		s1 <= transport std_logic_vector'("10110111"); --B7
		s2 <= transport std_logic_vector'("01001000"); --48
		d1 <= transport std_logic_vector'("01101110"); --6E
		d2 <= transport std_logic_vector'("10010001"); --91
		-- --------------------
		WAIT FOR 100 ns; -- Time=18400 ns
		s1 <= transport std_logic_vector'("10111000"); --B8
		s2 <= transport std_logic_vector'("01000111"); --47
		d1 <= transport std_logic_vector'("01110000"); --70
		d2 <= transport std_logic_vector'("10001111"); --8F
		-- --------------------
		WAIT FOR 100 ns; -- Time=18500 ns
		s1 <= transport std_logic_vector'("10111001"); --B9
		s2 <= transport std_logic_vector'("01000110"); --46
		d1 <= transport std_logic_vector'("01110010"); --72
		d2 <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 100 ns; -- Time=18600 ns
		s1 <= transport std_logic_vector'("10111010"); --BA
		s2 <= transport std_logic_vector'("01000101"); --45
		d1 <= transport std_logic_vector'("01110100"); --74
		d2 <= transport std_logic_vector'("10001011"); --8B
		-- --------------------
		WAIT FOR 100 ns; -- Time=18700 ns
		s1 <= transport std_logic_vector'("10111011"); --BB
		s2 <= transport std_logic_vector'("01000100"); --44
		d1 <= transport std_logic_vector'("01110110"); --76
		d2 <= transport std_logic_vector'("10001001"); --89
		-- --------------------
		WAIT FOR 100 ns; -- Time=18800 ns
		s1 <= transport std_logic_vector'("10111100"); --BC
		s2 <= transport std_logic_vector'("01000011"); --43
		d1 <= transport std_logic_vector'("01111000"); --78
		d2 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 100 ns; -- Time=18900 ns
		s1 <= transport std_logic_vector'("10111101"); --BD
		s2 <= transport std_logic_vector'("01000010"); --42
		d1 <= transport std_logic_vector'("01111010"); --7A
		d2 <= transport std_logic_vector'("10000101"); --85
		-- --------------------
		WAIT FOR 100 ns; -- Time=19000 ns
		s1 <= transport std_logic_vector'("10111110"); --BE
		s2 <= transport std_logic_vector'("01000001"); --41
		d1 <= transport std_logic_vector'("01111100"); --7C
		d2 <= transport std_logic_vector'("10000011"); --83
		-- --------------------
		WAIT FOR 100 ns; -- Time=19100 ns
		s1 <= transport std_logic_vector'("10111111"); --BF
		s2 <= transport std_logic_vector'("01000000"); --40
		d1 <= transport std_logic_vector'("01111110"); --7E
		d2 <= transport std_logic_vector'("10000001"); --81
		-- --------------------
		WAIT FOR 100 ns; -- Time=19200 ns
		s1 <= transport std_logic_vector'("11000000"); --C0
		s2 <= transport std_logic_vector'("00111111"); --3F
		d1 <= transport std_logic_vector'("10000000"); --80
		d2 <= transport std_logic_vector'("01111111"); --7F
		-- --------------------
		WAIT FOR 100 ns; -- Time=19300 ns
		s1 <= transport std_logic_vector'("11000001"); --C1
		s2 <= transport std_logic_vector'("00111110"); --3E
		d1 <= transport std_logic_vector'("10000010"); --82
		d2 <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 100 ns; -- Time=19400 ns
		s1 <= transport std_logic_vector'("11000010"); --C2
		s2 <= transport std_logic_vector'("00111101"); --3D
		d1 <= transport std_logic_vector'("10000100"); --84
		d2 <= transport std_logic_vector'("01111011"); --7B
		-- --------------------
		WAIT FOR 100 ns; -- Time=19500 ns
		s1 <= transport std_logic_vector'("11000011"); --C3
		s2 <= transport std_logic_vector'("00111100"); --3C
		d1 <= transport std_logic_vector'("10000110"); --86
		d2 <= transport std_logic_vector'("01111001"); --79
		-- --------------------
		WAIT FOR 100 ns; -- Time=19600 ns
		s1 <= transport std_logic_vector'("11000100"); --C4
		s2 <= transport std_logic_vector'("00111011"); --3B
		d1 <= transport std_logic_vector'("10001000"); --88
		d2 <= transport std_logic_vector'("01110111"); --77
		-- --------------------
		WAIT FOR 100 ns; -- Time=19700 ns
		s1 <= transport std_logic_vector'("11000101"); --C5
		s2 <= transport std_logic_vector'("00111010"); --3A
		d1 <= transport std_logic_vector'("10001010"); --8A
		d2 <= transport std_logic_vector'("01110101"); --75
		-- --------------------
		WAIT FOR 100 ns; -- Time=19800 ns
		s1 <= transport std_logic_vector'("11000110"); --C6
		s2 <= transport std_logic_vector'("00111001"); --39
		d1 <= transport std_logic_vector'("10001100"); --8C
		d2 <= transport std_logic_vector'("01110011"); --73
		-- --------------------
		WAIT FOR 100 ns; -- Time=19900 ns
		s1 <= transport std_logic_vector'("11000111"); --C7
		s2 <= transport std_logic_vector'("00111000"); --38
		d1 <= transport std_logic_vector'("10001110"); --8E
		d2 <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 100 ns; -- Time=20000 ns
		s1 <= transport std_logic_vector'("11001000"); --C8
		s2 <= transport std_logic_vector'("00110111"); --37
		d1 <= transport std_logic_vector'("10010000"); --90
		d2 <= transport std_logic_vector'("01101111"); --6F
		-- --------------------
		WAIT FOR 100 ns; -- Time=20100 ns
		s1 <= transport std_logic_vector'("11001001"); --C9
		s2 <= transport std_logic_vector'("00110110"); --36
		d1 <= transport std_logic_vector'("10010010"); --92
		d2 <= transport std_logic_vector'("01101101"); --6D
		-- --------------------
		WAIT FOR 100 ns; -- Time=20200 ns
		s1 <= transport std_logic_vector'("11001010"); --CA
		s2 <= transport std_logic_vector'("00110101"); --35
		d1 <= transport std_logic_vector'("10010100"); --94
		d2 <= transport std_logic_vector'("01101011"); --6B
		-- --------------------
		WAIT FOR 100 ns; -- Time=20300 ns
		s1 <= transport std_logic_vector'("11001011"); --CB
		s2 <= transport std_logic_vector'("00110100"); --34
		d1 <= transport std_logic_vector'("10010110"); --96
		d2 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 100 ns; -- Time=20400 ns
		s1 <= transport std_logic_vector'("11001100"); --CC
		s2 <= transport std_logic_vector'("00110011"); --33
		d1 <= transport std_logic_vector'("10011000"); --98
		d2 <= transport std_logic_vector'("01100111"); --67
		-- --------------------
		WAIT FOR 100 ns; -- Time=20500 ns
		s1 <= transport std_logic_vector'("11001101"); --CD
		s2 <= transport std_logic_vector'("00110010"); --32
		d1 <= transport std_logic_vector'("10011010"); --9A
		d2 <= transport std_logic_vector'("01100101"); --65
		-- --------------------
		WAIT FOR 100 ns; -- Time=20600 ns
		s1 <= transport std_logic_vector'("11001110"); --CE
		s2 <= transport std_logic_vector'("00110001"); --31
		d1 <= transport std_logic_vector'("10011100"); --9C
		d2 <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 100 ns; -- Time=20700 ns
		s1 <= transport std_logic_vector'("11001111"); --CF
		s2 <= transport std_logic_vector'("00110000"); --30
		d1 <= transport std_logic_vector'("10011110"); --9E
		d2 <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 100 ns; -- Time=20800 ns
		s1 <= transport std_logic_vector'("11010000"); --D0
		s2 <= transport std_logic_vector'("00101111"); --2F
		d1 <= transport std_logic_vector'("10100000"); --A0
		d2 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ns; -- Time=20900 ns
		s1 <= transport std_logic_vector'("11010001"); --D1
		s2 <= transport std_logic_vector'("00101110"); --2E
		d1 <= transport std_logic_vector'("10100010"); --A2
		d2 <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 100 ns; -- Time=21000 ns
		s1 <= transport std_logic_vector'("11010010"); --D2
		s2 <= transport std_logic_vector'("00101101"); --2D
		d1 <= transport std_logic_vector'("10100100"); --A4
		d2 <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 100 ns; -- Time=21100 ns
		s1 <= transport std_logic_vector'("11010011"); --D3
		s2 <= transport std_logic_vector'("00101100"); --2C
		d1 <= transport std_logic_vector'("10100110"); --A6
		d2 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 100 ns; -- Time=21200 ns
		s1 <= transport std_logic_vector'("11010100"); --D4
		s2 <= transport std_logic_vector'("00101011"); --2B
		d1 <= transport std_logic_vector'("10101000"); --A8
		d2 <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 100 ns; -- Time=21300 ns
		s1 <= transport std_logic_vector'("11010101"); --D5
		s2 <= transport std_logic_vector'("00101010"); --2A
		d1 <= transport std_logic_vector'("10101010"); --AA
		d2 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 100 ns; -- Time=21400 ns
		s1 <= transport std_logic_vector'("11010110"); --D6
		s2 <= transport std_logic_vector'("00101001"); --29
		d1 <= transport std_logic_vector'("10101100"); --AC
		d2 <= transport std_logic_vector'("01010011"); --53
		-- --------------------
		WAIT FOR 100 ns; -- Time=21500 ns
		s1 <= transport std_logic_vector'("11010111"); --D7
		s2 <= transport std_logic_vector'("00101000"); --28
		d1 <= transport std_logic_vector'("10101110"); --AE
		d2 <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 100 ns; -- Time=21600 ns
		s1 <= transport std_logic_vector'("11011000"); --D8
		s2 <= transport std_logic_vector'("00100111"); --27
		d1 <= transport std_logic_vector'("10110000"); --B0
		d2 <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 100 ns; -- Time=21700 ns
		s1 <= transport std_logic_vector'("11011001"); --D9
		s2 <= transport std_logic_vector'("00100110"); --26
		d1 <= transport std_logic_vector'("10110010"); --B2
		d2 <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 100 ns; -- Time=21800 ns
		s1 <= transport std_logic_vector'("11011010"); --DA
		s2 <= transport std_logic_vector'("00100101"); --25
		d1 <= transport std_logic_vector'("10110100"); --B4
		d2 <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 100 ns; -- Time=21900 ns
		s1 <= transport std_logic_vector'("11011011"); --DB
		s2 <= transport std_logic_vector'("00100100"); --24
		d1 <= transport std_logic_vector'("10110110"); --B6
		d2 <= transport std_logic_vector'("01001001"); --49
		-- --------------------
		WAIT FOR 100 ns; -- Time=22000 ns
		s1 <= transport std_logic_vector'("11011100"); --DC
		s2 <= transport std_logic_vector'("00100011"); --23
		d1 <= transport std_logic_vector'("10111000"); --B8
		d2 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 100 ns; -- Time=22100 ns
		s1 <= transport std_logic_vector'("11011101"); --DD
		s2 <= transport std_logic_vector'("00100010"); --22
		d1 <= transport std_logic_vector'("10111010"); --BA
		d2 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ns; -- Time=22200 ns
		s1 <= transport std_logic_vector'("11011110"); --DE
		s2 <= transport std_logic_vector'("00100001"); --21
		d1 <= transport std_logic_vector'("10111100"); --BC
		d2 <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 100 ns; -- Time=22300 ns
		s1 <= transport std_logic_vector'("11011111"); --DF
		s2 <= transport std_logic_vector'("00100000"); --20
		d1 <= transport std_logic_vector'("10111110"); --BE
		d2 <= transport std_logic_vector'("01000001"); --41
		-- --------------------
		WAIT FOR 100 ns; -- Time=22400 ns
		s1 <= transport std_logic_vector'("11100000"); --E0
		s2 <= transport std_logic_vector'("00011111"); --1F
		d1 <= transport std_logic_vector'("11000000"); --C0
		d2 <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 100 ns; -- Time=22500 ns
		s1 <= transport std_logic_vector'("11100001"); --E1
		s2 <= transport std_logic_vector'("00011110"); --1E
		d1 <= transport std_logic_vector'("11000010"); --C2
		d2 <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 100 ns; -- Time=22600 ns
		s1 <= transport std_logic_vector'("11100010"); --E2
		s2 <= transport std_logic_vector'("00011101"); --1D
		d1 <= transport std_logic_vector'("11000100"); --C4
		d2 <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 100 ns; -- Time=22700 ns
		s1 <= transport std_logic_vector'("11100011"); --E3
		s2 <= transport std_logic_vector'("00011100"); --1C
		d1 <= transport std_logic_vector'("11000110"); --C6
		d2 <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 100 ns; -- Time=22800 ns
		s1 <= transport std_logic_vector'("11100100"); --E4
		s2 <= transport std_logic_vector'("00011011"); --1B
		d1 <= transport std_logic_vector'("11001000"); --C8
		d2 <= transport std_logic_vector'("00110111"); --37
		-- --------------------
		WAIT FOR 100 ns; -- Time=22900 ns
		s1 <= transport std_logic_vector'("11100101"); --E5
		s2 <= transport std_logic_vector'("00011010"); --1A
		d1 <= transport std_logic_vector'("11001010"); --CA
		d2 <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 100 ns; -- Time=23000 ns
		s1 <= transport std_logic_vector'("11100110"); --E6
		s2 <= transport std_logic_vector'("00011001"); --19
		d1 <= transport std_logic_vector'("11001100"); --CC
		d2 <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 100 ns; -- Time=23100 ns
		s1 <= transport std_logic_vector'("11100111"); --E7
		s2 <= transport std_logic_vector'("00011000"); --18
		d1 <= transport std_logic_vector'("11001110"); --CE
		d2 <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 100 ns; -- Time=23200 ns
		s1 <= transport std_logic_vector'("11101000"); --E8
		s2 <= transport std_logic_vector'("00010111"); --17
		d1 <= transport std_logic_vector'("11010000"); --D0
		d2 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 100 ns; -- Time=23300 ns
		s1 <= transport std_logic_vector'("11101001"); --E9
		s2 <= transport std_logic_vector'("00010110"); --16
		d1 <= transport std_logic_vector'("11010010"); --D2
		d2 <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 100 ns; -- Time=23400 ns
		s1 <= transport std_logic_vector'("11101010"); --EA
		s2 <= transport std_logic_vector'("00010101"); --15
		d1 <= transport std_logic_vector'("11010100"); --D4
		d2 <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 100 ns; -- Time=23500 ns
		s1 <= transport std_logic_vector'("11101011"); --EB
		s2 <= transport std_logic_vector'("00010100"); --14
		d1 <= transport std_logic_vector'("11010110"); --D6
		d2 <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 100 ns; -- Time=23600 ns
		s1 <= transport std_logic_vector'("11101100"); --EC
		s2 <= transport std_logic_vector'("00010011"); --13
		d1 <= transport std_logic_vector'("11011000"); --D8
		d2 <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 100 ns; -- Time=23700 ns
		s1 <= transport std_logic_vector'("11101101"); --ED
		s2 <= transport std_logic_vector'("00010010"); --12
		d1 <= transport std_logic_vector'("11011010"); --DA
		d2 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ns; -- Time=23800 ns
		s1 <= transport std_logic_vector'("11101110"); --EE
		s2 <= transport std_logic_vector'("00010001"); --11
		d1 <= transport std_logic_vector'("11011100"); --DC
		d2 <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 100 ns; -- Time=23900 ns
		s1 <= transport std_logic_vector'("11101111"); --EF
		s2 <= transport std_logic_vector'("00010000"); --10
		d1 <= transport std_logic_vector'("11011110"); --DE
		d2 <= transport std_logic_vector'("00100001"); --21
		-- --------------------
		WAIT FOR 100 ns; -- Time=24000 ns
		s1 <= transport std_logic_vector'("11110000"); --F0
		s2 <= transport std_logic_vector'("00001111"); --F
		d1 <= transport std_logic_vector'("11100000"); --E0
		d2 <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 100 ns; -- Time=24100 ns
		s1 <= transport std_logic_vector'("11110001"); --F1
		s2 <= transport std_logic_vector'("00001110"); --E
		d1 <= transport std_logic_vector'("11100010"); --E2
		d2 <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 100 ns; -- Time=24200 ns
		s1 <= transport std_logic_vector'("11110010"); --F2
		s2 <= transport std_logic_vector'("00001101"); --D
		d1 <= transport std_logic_vector'("11100100"); --E4
		d2 <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 100 ns; -- Time=24300 ns
		s1 <= transport std_logic_vector'("11110011"); --F3
		s2 <= transport std_logic_vector'("00001100"); --C
		d1 <= transport std_logic_vector'("11100110"); --E6
		d2 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 100 ns; -- Time=24400 ns
		s1 <= transport std_logic_vector'("11110100"); --F4
		s2 <= transport std_logic_vector'("00001011"); --B
		d1 <= transport std_logic_vector'("11101000"); --E8
		d2 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 100 ns; -- Time=24500 ns
		s1 <= transport std_logic_vector'("11110101"); --F5
		s2 <= transport std_logic_vector'("00001010"); --A
		d1 <= transport std_logic_vector'("11101010"); --EA
		d2 <= transport std_logic_vector'("00010101"); --15
		-- --------------------
		WAIT FOR 100 ns; -- Time=24600 ns
		s1 <= transport std_logic_vector'("11110110"); --F6
		s2 <= transport std_logic_vector'("00001001"); --9
		d1 <= transport std_logic_vector'("11101100"); --EC
		d2 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 100 ns; -- Time=24700 ns
		s1 <= transport std_logic_vector'("11110111"); --F7
		s2 <= transport std_logic_vector'("00001000"); --8
		d1 <= transport std_logic_vector'("11101110"); --EE
		d2 <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 100 ns; -- Time=24800 ns
		s1 <= transport std_logic_vector'("11111000"); --F8
		s2 <= transport std_logic_vector'("00000111"); --7
		d1 <= transport std_logic_vector'("11110000"); --F0
		d2 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 100 ns; -- Time=24900 ns
		s1 <= transport std_logic_vector'("11111001"); --F9
		s2 <= transport std_logic_vector'("00000110"); --6
		d1 <= transport std_logic_vector'("11110010"); --F2
		d2 <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 100 ns; -- Time=25000 ns
		s1 <= transport std_logic_vector'("11111010"); --FA
		s2 <= transport std_logic_vector'("00000101"); --5
		d1 <= transport std_logic_vector'("11110100"); --F4
		d2 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 100 ns; -- Time=25100 ns
		s1 <= transport std_logic_vector'("11111011"); --FB
		s2 <= transport std_logic_vector'("00000100"); --4
		d1 <= transport std_logic_vector'("11110110"); --F6
		d2 <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ns; -- Time=25200 ns
		s1 <= transport std_logic_vector'("11111100"); --FC
		s2 <= transport std_logic_vector'("00000011"); --3
		d1 <= transport std_logic_vector'("11111000"); --F8
		d2 <= transport std_logic_vector'("00000111"); --7
		-- --------------------
		WAIT FOR 100 ns; -- Time=25300 ns
		s1 <= transport std_logic_vector'("11111101"); --FD
		s2 <= transport std_logic_vector'("00000010"); --2
		d1 <= transport std_logic_vector'("11111010"); --FA
		d2 <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 100 ns; -- Time=25400 ns
		s1 <= transport std_logic_vector'("11111110"); --FE
		s2 <= transport std_logic_vector'("00000001"); --1
		d1 <= transport std_logic_vector'("11111100"); --FC
		d2 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 250 ns; -- Time=25650 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION forwarder_cfg OF forward_tb IS
	FOR testbench_arch
	END FOR;
END forwarder_cfg;
