-- D:\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 08 05:41:18 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY mux6_tb IS
END mux6_tb;

ARCHITECTURE testbench_arch OF mux6_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT d_mux6
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			in2 : In  std_logic_vector (7 DOWNTO 0);
			in3 : In  std_logic_vector (7 DOWNTO 0);
			in4 : In  std_logic_vector (7 DOWNTO 0);
			sel : In  std_logic_vector (1 DOWNTO 0);
			out1 : Out  std_logic_vector (7 DOWNTO 0);
			out2 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in3 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in4 : std_logic_vector (7 DOWNTO 0);
	SIGNAL sel : std_logic_vector (1 DOWNTO 0);
	SIGNAL out1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out2 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : d_mux6
	PORT MAP (
		in1 => in1,
		in2 => in2,
		in3 => in3,
		in4 => in4,
		sel => sel,
		out1 => out1,
		out2 => out2
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_out2(
			next_out2 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out2 /= next_out2) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out2="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out2);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out2);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("10000011"); --83
		in2 <= transport std_logic_vector'("10000011"); --83
		in3 <= transport std_logic_vector'("10000010"); --82
		in4 <= transport std_logic_vector'("10000001"); --81
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("00100001"); --21
		in2 <= transport std_logic_vector'("00000110"); --6
		in3 <= transport std_logic_vector'("11101010"); --EA
		in4 <= transport std_logic_vector'("11001111"); --CF
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("10011100"); --9C
		in2 <= transport std_logic_vector'("01101111"); --6F
		in3 <= transport std_logic_vector'("01000011"); --43
		in4 <= transport std_logic_vector'("00010111"); --17
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("00011100"); --1C
		in2 <= transport std_logic_vector'("00111101"); --3D
		in3 <= transport std_logic_vector'("01011101"); --5D
		in4 <= transport std_logic_vector'("01111101"); --7D
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("00001100"); --C
		in2 <= transport std_logic_vector'("00101010"); --2A
		in3 <= transport std_logic_vector'("01001000"); --48
		in4 <= transport std_logic_vector'("01100110"); --66
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("00010100"); --14
		in2 <= transport std_logic_vector'("00110101"); --35
		in3 <= transport std_logic_vector'("01010111"); --57
		in4 <= transport std_logic_vector'("01111001"); --79
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("00011100"); --1C
		in2 <= transport std_logic_vector'("10011011"); --9B
		in3 <= transport std_logic_vector'("00011010"); --1A
		in4 <= transport std_logic_vector'("10011001"); --99
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("01001111"); --4F
		in2 <= transport std_logic_vector'("11011000"); --D8
		in3 <= transport std_logic_vector'("01100010"); --62
		in4 <= transport std_logic_vector'("11101100"); --EC
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("00010100"); --14
		in2 <= transport std_logic_vector'("10101010"); --AA
		in3 <= transport std_logic_vector'("01000000"); --40
		in4 <= transport std_logic_vector'("11010110"); --D6
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("00010110"); --16
		in2 <= transport std_logic_vector'("00001101"); --D
		in3 <= transport std_logic_vector'("00000101"); --5
		in4 <= transport std_logic_vector'("11111101"); --FD
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("00111100"); --3C
		in2 <= transport std_logic_vector'("00111111"); --3F
		in3 <= transport std_logic_vector'("01000010"); --42
		in4 <= transport std_logic_vector'("01000101"); --45
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		in2 <= transport std_logic_vector'("10111100"); --BC
		in3 <= transport std_logic_vector'("11001001"); --C9
		in4 <= transport std_logic_vector'("11010101"); --D5
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("11011011"); --DB
		in2 <= transport std_logic_vector'("01000010"); --42
		in3 <= transport std_logic_vector'("10101001"); --A9
		in4 <= transport std_logic_vector'("00010000"); --10
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("01100111"); --67
		in2 <= transport std_logic_vector'("11001101"); --CD
		in3 <= transport std_logic_vector'("00110100"); --34
		in4 <= transport std_logic_vector'("10011011"); --9B
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("00111011"); --3B
		in2 <= transport std_logic_vector'("10011011"); --9B
		in3 <= transport std_logic_vector'("11111100"); --FC
		in4 <= transport std_logic_vector'("01011100"); --5C
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("10000001"); --81
		in2 <= transport std_logic_vector'("00101001"); --29
		in3 <= transport std_logic_vector'("11010000"); --D0
		in4 <= transport std_logic_vector'("01111000"); --78
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("10100010"); --A2
		in2 <= transport std_logic_vector'("00110011"); --33
		in3 <= transport std_logic_vector'("11000011"); --C3
		in4 <= transport std_logic_vector'("01010100"); --54
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("01000111"); --47
		in2 <= transport std_logic_vector'("10110110"); --B6
		in3 <= transport std_logic_vector'("00100101"); --25
		in4 <= transport std_logic_vector'("10010100"); --94
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("01011001"); --59
		in2 <= transport std_logic_vector'("11110000"); --F0
		in3 <= transport std_logic_vector'("10000111"); --87
		in4 <= transport std_logic_vector'("00011101"); --1D
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("00000001"); --1
		in2 <= transport std_logic_vector'("01011101"); --5D
		in3 <= transport std_logic_vector'("10111001"); --B9
		in4 <= transport std_logic_vector'("00010110"); --16
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("10101000"); --A8
		in2 <= transport std_logic_vector'("10111011"); --BB
		in3 <= transport std_logic_vector'("11001110"); --CE
		in4 <= transport std_logic_vector'("11100010"); --E2
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("11110111"); --F7
		in2 <= transport std_logic_vector'("00000111"); --7
		in3 <= transport std_logic_vector'("00010111"); --17
		in4 <= transport std_logic_vector'("00100110"); --26
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("11010110"); --D6
		in2 <= transport std_logic_vector'("01111101"); --7D
		in3 <= transport std_logic_vector'("00100011"); --23
		in4 <= transport std_logic_vector'("11001001"); --C9
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("01110000"); --70
		in2 <= transport std_logic_vector'("10011010"); --9A
		in3 <= transport std_logic_vector'("11000100"); --C4
		in4 <= transport std_logic_vector'("11101110"); --EE
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("00101101"); --2D
		in2 <= transport std_logic_vector'("00011100"); --1C
		in3 <= transport std_logic_vector'("00001011"); --B
		in4 <= transport std_logic_vector'("11111010"); --FA
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("10110110"); --B6
		in2 <= transport std_logic_vector'("00000000"); --0
		in3 <= transport std_logic_vector'("01001001"); --49
		in4 <= transport std_logic_vector'("10010011"); --93
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("11110011"); --F3
		in2 <= transport std_logic_vector'("10000010"); --82
		in3 <= transport std_logic_vector'("00010000"); --10
		in4 <= transport std_logic_vector'("10011110"); --9E
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("00001111"); --F
		in2 <= transport std_logic_vector'("00011111"); --1F
		in3 <= transport std_logic_vector'("00101111"); --2F
		in4 <= transport std_logic_vector'("01000000"); --40
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("01110001"); --71
		in2 <= transport std_logic_vector'("10010101"); --95
		in3 <= transport std_logic_vector'("10111001"); --B9
		in4 <= transport std_logic_vector'("11011101"); --DD
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("11000100"); --C4
		in2 <= transport std_logic_vector'("11100001"); --E1
		in3 <= transport std_logic_vector'("11111110"); --FE
		in4 <= transport std_logic_vector'("00011011"); --1B
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("11101111"); --EF
		in2 <= transport std_logic_vector'("00111111"); --3F
		in3 <= transport std_logic_vector'("10001110"); --8E
		in4 <= transport std_logic_vector'("11011110"); --DE
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("00011100"); --1C
		in2 <= transport std_logic_vector'("00101100"); --2C
		in3 <= transport std_logic_vector'("00111100"); --3C
		in4 <= transport std_logic_vector'("01001100"); --4C
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("10110101"); --B5
		in2 <= transport std_logic_vector'("01100110"); --66
		in3 <= transport std_logic_vector'("00011000"); --18
		in4 <= transport std_logic_vector'("11001010"); --CA
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("01100001"); --61
		in2 <= transport std_logic_vector'("11101010"); --EA
		in3 <= transport std_logic_vector'("01110011"); --73
		in4 <= transport std_logic_vector'("11111100"); --FC
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("00001010"); --A
		in2 <= transport std_logic_vector'("11110100"); --F4
		in3 <= transport std_logic_vector'("11011110"); --DE
		in4 <= transport std_logic_vector'("11001000"); --C8
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("11011001"); --D9
		in2 <= transport std_logic_vector'("00000010"); --2
		in3 <= transport std_logic_vector'("00101010"); --2A
		in4 <= transport std_logic_vector'("01010011"); --53
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("00111000"); --38
		in2 <= transport std_logic_vector'("11010000"); --D0
		in3 <= transport std_logic_vector'("01101001"); --69
		in4 <= transport std_logic_vector'("00000001"); --1
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("11001110"); --CE
		in2 <= transport std_logic_vector'("01011100"); --5C
		in3 <= transport std_logic_vector'("11101010"); --EA
		in4 <= transport std_logic_vector'("01111000"); --78
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("10000101"); --85
		in2 <= transport std_logic_vector'("11100010"); --E2
		in3 <= transport std_logic_vector'("00111111"); --3F
		in4 <= transport std_logic_vector'("10011101"); --9D
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("10000110"); --86
		in2 <= transport std_logic_vector'("11100000"); --E0
		in3 <= transport std_logic_vector'("00111010"); --3A
		in4 <= transport std_logic_vector'("10010100"); --94
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("00111010"); --3A
		in2 <= transport std_logic_vector'("00010010"); --12
		in3 <= transport std_logic_vector'("11101010"); --EA
		in4 <= transport std_logic_vector'("11000011"); --C3
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("01001010"); --4A
		in2 <= transport std_logic_vector'("01110110"); --76
		in3 <= transport std_logic_vector'("10100010"); --A2
		in4 <= transport std_logic_vector'("11001110"); --CE
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("10011110"); --9E
		in2 <= transport std_logic_vector'("01001000"); --48
		in3 <= transport std_logic_vector'("11110010"); --F2
		in4 <= transport std_logic_vector'("10011011"); --9B
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("01100001"); --61
		in2 <= transport std_logic_vector'("00000110"); --6
		in3 <= transport std_logic_vector'("10101010"); --AA
		in4 <= transport std_logic_vector'("01001111"); --4F
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("11111011"); --FB
		in2 <= transport std_logic_vector'("01101100"); --6C
		in3 <= transport std_logic_vector'("11011101"); --DD
		in4 <= transport std_logic_vector'("01001110"); --4E
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("00010101"); --15
		in2 <= transport std_logic_vector'("01111000"); --78
		in3 <= transport std_logic_vector'("11011011"); --DB
		in4 <= transport std_logic_vector'("00111110"); --3E
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		in1 <= transport std_logic_vector'("10010111"); --97
		in2 <= transport std_logic_vector'("01100110"); --66
		in3 <= transport std_logic_vector'("00110101"); --35
		in4 <= transport std_logic_vector'("00000100"); --4
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		in1 <= transport std_logic_vector'("10101100"); --AC
		in2 <= transport std_logic_vector'("10110100"); --B4
		in3 <= transport std_logic_vector'("10111100"); --BC
		in4 <= transport std_logic_vector'("11000100"); --C4
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		in1 <= transport std_logic_vector'("10111100"); --BC
		in2 <= transport std_logic_vector'("00011110"); --1E
		in3 <= transport std_logic_vector'("10000001"); --81
		in4 <= transport std_logic_vector'("11100100"); --E4
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		in1 <= transport std_logic_vector'("01101111"); --6F
		in2 <= transport std_logic_vector'("10100010"); --A2
		in3 <= transport std_logic_vector'("11010110"); --D6
		in4 <= transport std_logic_vector'("00001001"); --9
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		in2 <= transport std_logic_vector'("01111101"); --7D
		in3 <= transport std_logic_vector'("01001010"); --4A
		in4 <= transport std_logic_vector'("00010111"); --17
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		in1 <= transport std_logic_vector'("10100110"); --A6
		in2 <= transport std_logic_vector'("00101011"); --2B
		in3 <= transport std_logic_vector'("10101111"); --AF
		in4 <= transport std_logic_vector'("00110100"); --34
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		in1 <= transport std_logic_vector'("10111011"); --BB
		in2 <= transport std_logic_vector'("01101001"); --69
		in3 <= transport std_logic_vector'("00010111"); --17
		in4 <= transport std_logic_vector'("11000101"); --C5
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		in1 <= transport std_logic_vector'("10011001"); --99
		in2 <= transport std_logic_vector'("00110101"); --35
		in3 <= transport std_logic_vector'("11010001"); --D1
		in4 <= transport std_logic_vector'("01101110"); --6E
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		in1 <= transport std_logic_vector'("00100111"); --27
		in2 <= transport std_logic_vector'("11001011"); --CB
		in3 <= transport std_logic_vector'("01110000"); --70
		in4 <= transport std_logic_vector'("00010100"); --14
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		in1 <= transport std_logic_vector'("10001111"); --8F
		in2 <= transport std_logic_vector'("10101001"); --A9
		in3 <= transport std_logic_vector'("11000100"); --C4
		in4 <= transport std_logic_vector'("11011110"); --DE
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		in1 <= transport std_logic_vector'("00111010"); --3A
		in2 <= transport std_logic_vector'("10001100"); --8C
		in3 <= transport std_logic_vector'("11011101"); --DD
		in4 <= transport std_logic_vector'("00101111"); --2F
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		in1 <= transport std_logic_vector'("11010010"); --D2
		in2 <= transport std_logic_vector'("01110000"); --70
		in3 <= transport std_logic_vector'("00001110"); --E
		in4 <= transport std_logic_vector'("10101101"); --AD
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		in1 <= transport std_logic_vector'("00111110"); --3E
		in2 <= transport std_logic_vector'("10010010"); --92
		in3 <= transport std_logic_vector'("11100111"); --E7
		in4 <= transport std_logic_vector'("00111100"); --3C
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		in1 <= transport std_logic_vector'("10101000"); --A8
		in2 <= transport std_logic_vector'("01110000"); --70
		in3 <= transport std_logic_vector'("00111001"); --39
		in4 <= transport std_logic_vector'("00000010"); --2
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("01111001"); --79
		in2 <= transport std_logic_vector'("11000111"); --C7
		in3 <= transport std_logic_vector'("00010101"); --15
		in4 <= transport std_logic_vector'("01100100"); --64
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		in1 <= transport std_logic_vector'("01011010"); --5A
		in2 <= transport std_logic_vector'("10010011"); --93
		in3 <= transport std_logic_vector'("11001101"); --CD
		in4 <= transport std_logic_vector'("00000110"); --6
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		in1 <= transport std_logic_vector'("00110100"); --34
		in2 <= transport std_logic_vector'("00010010"); --12
		in3 <= transport std_logic_vector'("11110000"); --F0
		in4 <= transport std_logic_vector'("11001110"); --CE
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		in2 <= transport std_logic_vector'("11000000"); --C0
		in3 <= transport std_logic_vector'("01010000"); --50
		in4 <= transport std_logic_vector'("11100000"); --E0
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		in1 <= transport std_logic_vector'("10110110"); --B6
		in2 <= transport std_logic_vector'("01011010"); --5A
		in3 <= transport std_logic_vector'("11111111"); --FF
		in4 <= transport std_logic_vector'("10100011"); --A3
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		in1 <= transport std_logic_vector'("01110001"); --71
		in2 <= transport std_logic_vector'("11011111"); --DF
		in3 <= transport std_logic_vector'("01001100"); --4C
		in4 <= transport std_logic_vector'("10111001"); --B9
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		in1 <= transport std_logic_vector'("01001001"); --49
		in2 <= transport std_logic_vector'("10001001"); --89
		in3 <= transport std_logic_vector'("11001010"); --CA
		in4 <= transport std_logic_vector'("00001010"); --A
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		in1 <= transport std_logic_vector'("01100110"); --66
		in2 <= transport std_logic_vector'("11010111"); --D7
		in3 <= transport std_logic_vector'("01001000"); --48
		in4 <= transport std_logic_vector'("10111001"); --B9
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		in1 <= transport std_logic_vector'("00110011"); --33
		in2 <= transport std_logic_vector'("10000110"); --86
		in3 <= transport std_logic_vector'("11011001"); --D9
		in4 <= transport std_logic_vector'("00101100"); --2C
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		in1 <= transport std_logic_vector'("01011000"); --58
		in2 <= transport std_logic_vector'("10010010"); --92
		in3 <= transport std_logic_vector'("11001101"); --CD
		in4 <= transport std_logic_vector'("00000111"); --7
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("10111101"); --BD
		in2 <= transport std_logic_vector'("00111001"); --39
		in3 <= transport std_logic_vector'("10110101"); --B5
		in4 <= transport std_logic_vector'("00110000"); --30
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		in1 <= transport std_logic_vector'("10001101"); --8D
		in2 <= transport std_logic_vector'("11110111"); --F7
		in3 <= transport std_logic_vector'("01100010"); --62
		in4 <= transport std_logic_vector'("11001100"); --CC
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		in2 <= transport std_logic_vector'("10001010"); --8A
		in3 <= transport std_logic_vector'("11100101"); --E5
		in4 <= transport std_logic_vector'("00111111"); --3F
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		in1 <= transport std_logic_vector'("01001110"); --4E
		in2 <= transport std_logic_vector'("11101110"); --EE
		in3 <= transport std_logic_vector'("10001111"); --8F
		in4 <= transport std_logic_vector'("00101111"); --2F
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		in1 <= transport std_logic_vector'("11010001"); --D1
		in2 <= transport std_logic_vector'("01100001"); --61
		in3 <= transport std_logic_vector'("11110001"); --F1
		in4 <= transport std_logic_vector'("10000001"); --81
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		in1 <= transport std_logic_vector'("11100010"); --E2
		in2 <= transport std_logic_vector'("01011111"); --5F
		in3 <= transport std_logic_vector'("11011100"); --DC
		in4 <= transport std_logic_vector'("01011001"); --59
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		in1 <= transport std_logic_vector'("11101010"); --EA
		in2 <= transport std_logic_vector'("10100110"); --A6
		in3 <= transport std_logic_vector'("01100010"); --62
		in4 <= transport std_logic_vector'("00011101"); --1D
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		in1 <= transport std_logic_vector'("10010011"); --93
		in2 <= transport std_logic_vector'("00110010"); --32
		in3 <= transport std_logic_vector'("11010010"); --D2
		in4 <= transport std_logic_vector'("01110010"); --72
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		in1 <= transport std_logic_vector'("11000100"); --C4
		in2 <= transport std_logic_vector'("01000001"); --41
		in3 <= transport std_logic_vector'("10111110"); --BE
		in4 <= transport std_logic_vector'("00111100"); --3C
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		in1 <= transport std_logic_vector'("10100111"); --A7
		in2 <= transport std_logic_vector'("01001111"); --4F
		in3 <= transport std_logic_vector'("11111000"); --F8
		in4 <= transport std_logic_vector'("10100001"); --A1
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("10100101"); --A5
		in2 <= transport std_logic_vector'("00011010"); --1A
		in3 <= transport std_logic_vector'("10010000"); --90
		in4 <= transport std_logic_vector'("00000101"); --5
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		in1 <= transport std_logic_vector'("01100111"); --67
		in2 <= transport std_logic_vector'("10011111"); --9F
		in3 <= transport std_logic_vector'("11010110"); --D6
		in4 <= transport std_logic_vector'("00001110"); --E
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		in1 <= transport std_logic_vector'("11010110"); --D6
		in2 <= transport std_logic_vector'("00011010"); --1A
		in3 <= transport std_logic_vector'("01011101"); --5D
		in4 <= transport std_logic_vector'("10100001"); --A1
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		in1 <= transport std_logic_vector'("00011011"); --1B
		in2 <= transport std_logic_vector'("00001000"); --8
		in3 <= transport std_logic_vector'("11110101"); --F5
		in4 <= transport std_logic_vector'("11100010"); --E2
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		in1 <= transport std_logic_vector'("10011111"); --9F
		in2 <= transport std_logic_vector'("00100111"); --27
		in3 <= transport std_logic_vector'("10101111"); --AF
		in4 <= transport std_logic_vector'("00110111"); --37
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		in2 <= transport std_logic_vector'("01110011"); --73
		in3 <= transport std_logic_vector'("11011100"); --DC
		in4 <= transport std_logic_vector'("01000101"); --45
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		in1 <= transport std_logic_vector'("01000111"); --47
		in2 <= transport std_logic_vector'("00101010"); --2A
		in3 <= transport std_logic_vector'("00001101"); --D
		in4 <= transport std_logic_vector'("11110000"); --F0
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		in1 <= transport std_logic_vector'("01111110"); --7E
		in2 <= transport std_logic_vector'("11001001"); --C9
		in3 <= transport std_logic_vector'("00010011"); --13
		in4 <= transport std_logic_vector'("01011110"); --5E
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		in1 <= transport std_logic_vector'("00011000"); --18
		in2 <= transport std_logic_vector'("00001100"); --C
		in3 <= transport std_logic_vector'("00000000"); --0
		in4 <= transport std_logic_vector'("11110100"); --F4
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		in1 <= transport std_logic_vector'("10111110"); --BE
		in2 <= transport std_logic_vector'("11110000"); --F0
		in3 <= transport std_logic_vector'("00100011"); --23
		in4 <= transport std_logic_vector'("01010110"); --56
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("01011000"); --58
		in2 <= transport std_logic_vector'("10110011"); --B3
		in3 <= transport std_logic_vector'("00001111"); --F
		in4 <= transport std_logic_vector'("01101010"); --6A
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		in1 <= transport std_logic_vector'("00010001"); --11
		in2 <= transport std_logic_vector'("11010010"); --D2
		in3 <= transport std_logic_vector'("10010011"); --93
		in4 <= transport std_logic_vector'("01010100"); --54
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		in1 <= transport std_logic_vector'("01010000"); --50
		in2 <= transport std_logic_vector'("00001001"); --9
		in3 <= transport std_logic_vector'("11000010"); --C2
		in4 <= transport std_logic_vector'("01111010"); --7A
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		in1 <= transport std_logic_vector'("11000000"); --C0
		in2 <= transport std_logic_vector'("01010110"); --56
		in3 <= transport std_logic_vector'("11101011"); --EB
		in4 <= transport std_logic_vector'("10000001"); --81
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		in1 <= transport std_logic_vector'("01001000"); --48
		in2 <= transport std_logic_vector'("11110101"); --F5
		in3 <= transport std_logic_vector'("10100001"); --A1
		in4 <= transport std_logic_vector'("01001110"); --4E
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		in1 <= transport std_logic_vector'("00010010"); --12
		in2 <= transport std_logic_vector'("01100011"); --63
		in3 <= transport std_logic_vector'("10110100"); --B4
		in4 <= transport std_logic_vector'("00000101"); --5
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		in1 <= transport std_logic_vector'("10001000"); --88
		in2 <= transport std_logic_vector'("01011110"); --5E
		in3 <= transport std_logic_vector'("00110101"); --35
		in4 <= transport std_logic_vector'("00001011"); --B
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		in1 <= transport std_logic_vector'("01010001"); --51
		in2 <= transport std_logic_vector'("11100011"); --E3
		in3 <= transport std_logic_vector'("01110101"); --75
		in4 <= transport std_logic_vector'("00000111"); --7
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		in1 <= transport std_logic_vector'("01010111"); --57
		in2 <= transport std_logic_vector'("00101110"); --2E
		in3 <= transport std_logic_vector'("00000101"); --5
		in4 <= transport std_logic_vector'("11011100"); --DC
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		in1 <= transport std_logic_vector'("11000011"); --C3
		in2 <= transport std_logic_vector'("10111101"); --BD
		in3 <= transport std_logic_vector'("10110110"); --B6
		in4 <= transport std_logic_vector'("10101111"); --AF
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 15 ns; -- Time=1005 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION d_mux6_cfg OF mux6_tb IS
	FOR testbench_arch
	END FOR;
END d_mux6_cfg;
