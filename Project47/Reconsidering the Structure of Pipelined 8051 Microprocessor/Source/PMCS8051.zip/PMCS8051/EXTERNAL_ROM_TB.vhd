
-- VHDL Test Bench Created from source file external_rom.vhd -- 00:15:25 09/06/2004
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends 
-- that these types always be used for the top-level I/O of a design in order 
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY external_rom_EXTERNAL_ROM_TB_vhd_tb IS
END external_rom_EXTERNAL_ROM_TB_vhd_tb;

ARCHITECTURE behavior OF external_rom_EXTERNAL_ROM_TB_vhd_tb IS 

	COMPONENT external_rom
	PORT(
		ADDRESS_BUS : IN std_logic_vector(15 downto 0);
		OE : IN std_logic;          
		DATA_BUS : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	SIGNAL ADDRESS_BUS :  std_logic_vector(15 downto 0);
	SIGNAL OE :  std_logic;
	SIGNAL DATA_BUS :  std_logic_vector(7 downto 0);

BEGIN

	uut: external_rom PORT MAP(
		ADDRESS_BUS => ADDRESS_BUS,
		OE => OE,
		DATA_BUS => DATA_BUS
	);


-- *** Test Bench - User Defined Section ***
	
	 ADDRESS_BUS <= "0000000000000000",
	 			 "0000000000000001" after 100 ns,
	 			 "0000000000000010" after 200 ns,
	 			 "0000000000000011" after 300 ns,
	 			 "0000000000000100" after 400 ns,
	 			 "0000000000000101" after 500 ns,
	 			 "0000000000000110" after 600 ns,
	 			 "0000000000000111" after 700 ns,
	 			 "0000000000001000" after 800 ns,
	 			 "0000000000001001" after 900 ns,
	 			 "0000000000001010" after 1000 ns,
	 			 "0000000000001011" after 1100 ns;
 	OE <= '0',
		 '1' after 155 ns,
		 '0' after 205 ns,
		 '1' after 255 ns,
		 '0' after 305 ns,
		 '1' after 355 ns,
		 '0' after 405 ns,
		 '1' after 455 ns,
		 '0' after 505 ns,
		 '1' after 555 ns,
		 '0' after 605 ns,
		 '1' after 655 ns;

  tb : PROCESS
   BEGIN
	   wait;
   END PROCESS;
-- *** End Test Bench - User Defined Section ***

END;
