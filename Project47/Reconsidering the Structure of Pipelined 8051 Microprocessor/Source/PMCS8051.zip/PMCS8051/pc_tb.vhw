-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Wed Mar 09 02:01:59 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY pc_tb IS
END pc_tb;

ARCHITECTURE testbench_arch OF pc_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT pc
		PORT (
			data_in16 : In  std_logic_vector (15 DOWNTO 0);
			data_out : Out  std_logic_vector (15 DOWNTO 0);
			load_in : In  std_logic;
			reset : In  std_logic;
			clock : In  std_logic
		);
	END COMPONENT;

	SIGNAL data_in16 : std_logic_vector (15 DOWNTO 0);
	SIGNAL data_out : std_logic_vector (15 DOWNTO 0);
	SIGNAL load_in : std_logic;
	SIGNAL reset : std_logic;
	SIGNAL clock : std_logic;

BEGIN
	UUT : pc
	PORT MAP (
		data_in16 => data_in16,
		data_out => data_out,
		load_in => load_in,
		reset => reset,
		clock => clock
	);

	PROCESS -- clock process for clock,
	BEGIN
		CLOCK_LOOP : LOOP
		clock <= transport '0';
		WAIT FOR 10 ps;
		clock <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clock <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clock
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_data_out(
			next_data_out : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out /= next_data_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps data_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		data_in16 <= transport std_logic_vector'("0000000000000000"); --0
		load_in <= transport '1';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		data_in16 <= transport std_logic_vector'("0000000000000001"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		data_in16 <= transport std_logic_vector'("0000000000000010"); --2
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		data_in16 <= transport std_logic_vector'("0000000000000011"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		data_in16 <= transport std_logic_vector'("0000000000000100"); --4
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		data_in16 <= transport std_logic_vector'("0000000000000101"); --5
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		data_in16 <= transport std_logic_vector'("0000000000000110"); --6
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		data_in16 <= transport std_logic_vector'("0000000000000111"); --7
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		data_in16 <= transport std_logic_vector'("0000000000001000"); --8
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		data_in16 <= transport std_logic_vector'("0000000000001001"); --9
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		data_in16 <= transport std_logic_vector'("0000000000001010"); --A
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		data_in16 <= transport std_logic_vector'("0000000000001011"); --B
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		data_in16 <= transport std_logic_vector'("0000000000001100"); --C
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		data_in16 <= transport std_logic_vector'("0000000000001101"); --D
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		data_in16 <= transport std_logic_vector'("0000000000001110"); --E
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		data_in16 <= transport std_logic_vector'("0000000000001111"); --F
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		data_in16 <= transport std_logic_vector'("0000000000010000"); --10
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		data_in16 <= transport std_logic_vector'("0000000000010001"); --11
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		data_in16 <= transport std_logic_vector'("0000000000010010"); --12
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		data_in16 <= transport std_logic_vector'("0000000000010011"); --13
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		data_in16 <= transport std_logic_vector'("0000000000010100"); --14
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		data_in16 <= transport std_logic_vector'("0000000000010101"); --15
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		data_in16 <= transport std_logic_vector'("0000000000010110"); --16
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		data_in16 <= transport std_logic_vector'("0000000000010111"); --17
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		data_in16 <= transport std_logic_vector'("0000000000011000"); --18
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		data_in16 <= transport std_logic_vector'("0000000000011001"); --19
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		data_in16 <= transport std_logic_vector'("0000000000011010"); --1A
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		data_in16 <= transport std_logic_vector'("0000000000011011"); --1B
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		data_in16 <= transport std_logic_vector'("0000000000011100"); --1C
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		data_in16 <= transport std_logic_vector'("0000000000011101"); --1D
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		data_in16 <= transport std_logic_vector'("0000000000011110"); --1E
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		data_in16 <= transport std_logic_vector'("0000000000011111"); --1F
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		data_in16 <= transport std_logic_vector'("0000000000100000"); --20
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		data_in16 <= transport std_logic_vector'("0000000000100001"); --21
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		data_in16 <= transport std_logic_vector'("0000000000100010"); --22
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		data_in16 <= transport std_logic_vector'("0000000000100011"); --23
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		data_in16 <= transport std_logic_vector'("0000000000100100"); --24
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		data_in16 <= transport std_logic_vector'("0000000000100101"); --25
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		data_in16 <= transport std_logic_vector'("0000000000100110"); --26
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		data_in16 <= transport std_logic_vector'("0000000000100111"); --27
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		data_in16 <= transport std_logic_vector'("0000000000101000"); --28
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		data_in16 <= transport std_logic_vector'("0000000000101001"); --29
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		data_in16 <= transport std_logic_vector'("0000000000101010"); --2A
		-- --------------------
		WAIT FOR 60 ps; -- Time=4260 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION pc_cfg OF pc_tb IS
	FOR testbench_arch
	END FOR;
END pc_cfg;
