-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Wed Mar 09 04:55:24 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY sp_tb IS
END sp_tb;

ARCHITECTURE testbench_arch OF sp_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT sp
		PORT (
			rst : In  std_logic;
			load_in : In  std_logic;
			in1 : In  std_logic_vector (7 DOWNTO 0);
			out1 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL rst : std_logic;
	SIGNAL load_in : std_logic;
	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out1 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : sp
	PORT MAP (
		rst => rst,
		load_in => load_in,
		in1 => in1,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		rst <= transport '0';
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 100 ns; -- Time=100 ns
		load_in <= transport '1';
		in1 <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 100 ns; -- Time=200 ns
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 100 ns; -- Time=300 ns
		load_in <= transport '1';
		in1 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 100 ns; -- Time=400 ns
		rst <= transport '1';
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 100 ns; -- Time=500 ns
		rst <= transport '0';
		in1 <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 100 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 100 ns; -- Time=700 ns
		load_in <= transport '1';
		in1 <= transport std_logic_vector'("00000111"); --7
		-- --------------------
		WAIT FOR 100 ns; -- Time=800 ns
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 100 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ns; -- Time=1000 ns
		load_in <= transport '1';
		in1 <= transport std_logic_vector'("00001010"); --A
		-- --------------------
		WAIT FOR 100 ns; -- Time=1100 ns
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 100 ns; -- Time=1200 ns
		in1 <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 100 ns; -- Time=1300 ns
		rst <= transport '1';
		load_in <= transport '1';
		in1 <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 100 ns; -- Time=1400 ns
		rst <= transport '0';
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 100 ns; -- Time=1500 ns
		load_in <= transport '1';
		in1 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 100 ns; -- Time=1600 ns
		rst <= transport '0';
		load_in <= transport '0';
		in1 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 100 ns; -- Time=1700 ns
		in1 <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 100 ns; -- Time=1800 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION sp_cfg OF sp_tb IS
	FOR testbench_arch
	END FOR;
END sp_cfg;
