-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 22 12:56:41 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY internal_ram_tb IS
END internal_ram_tb;

ARCHITECTURE testbench_arch OF internal_ram_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT internal_ram
		PORT (
			rst : In  std_logic;
			clk : In  std_logic;
			wr_bank0 : In  std_logic;
			r_addr_bank0 : In  std_logic_vector (6 DOWNTO 0);
			w_addr_bank0 : In  std_logic_vector (6 DOWNTO 0);
			di_bank0 : In  std_logic_vector (7 DOWNTO 0);
			do_bank0 : Out  std_logic_vector (7 DOWNTO 0);
			wr_bank1 : In  std_logic;
			r_addr_bank1 : In  std_logic_vector (6 DOWNTO 0);
			w_addr_bank1 : In  std_logic_vector (6 DOWNTO 0);
			di_bank1 : In  std_logic_vector (7 DOWNTO 0);
			do_bank1 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL rst : std_logic;
	SIGNAL clk : std_logic;
	SIGNAL wr_bank0 : std_logic;
	SIGNAL r_addr_bank0 : std_logic_vector (6 DOWNTO 0);
	SIGNAL w_addr_bank0 : std_logic_vector (6 DOWNTO 0);
	SIGNAL di_bank0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_bank0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL wr_bank1 : std_logic;
	SIGNAL r_addr_bank1 : std_logic_vector (6 DOWNTO 0);
	SIGNAL w_addr_bank1 : std_logic_vector (6 DOWNTO 0);
	SIGNAL di_bank1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_bank1 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : internal_ram
	PORT MAP (
		rst => rst,
		clk => clk,
		wr_bank0 => wr_bank0,
		r_addr_bank0 => r_addr_bank0,
		w_addr_bank0 => w_addr_bank0,
		di_bank0 => di_bank0,
		do_bank0 => do_bank0,
		wr_bank1 => wr_bank1,
		r_addr_bank1 => r_addr_bank1,
		w_addr_bank1 => w_addr_bank1,
		di_bank1 => di_bank1,
		do_bank1 => do_bank1
	);

	PROCESS -- clock process for clk,
	BEGIN
		CLOCK_LOOP : LOOP
		clk <= transport '0';
		WAIT FOR 10 ps;
		clk <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clk <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clk
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_do_bank0(
			next_do_bank0 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_bank0 /= next_do_bank0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_bank0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_bank0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_bank0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_do_bank1(
			next_do_bank1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_bank1 /= next_do_bank1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_bank1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_bank1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_bank1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		rst <= transport '1';
		wr_bank0 <= transport '1';
		r_addr_bank0 <= transport std_logic_vector'("1111111"); --7F
		w_addr_bank0 <= transport std_logic_vector'("1111110"); --7E
		di_bank0 <= transport std_logic_vector'("01101101"); --6D
		wr_bank1 <= transport '1';
		r_addr_bank1 <= transport std_logic_vector'("0000000"); --0
		w_addr_bank1 <= transport std_logic_vector'("0000001"); --1
		di_bank1 <= transport std_logic_vector'("01110000"); --70
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		r_addr_bank0 <= transport std_logic_vector'("1111110"); --7E
		w_addr_bank0 <= transport std_logic_vector'("1111101"); --7D
		di_bank0 <= transport std_logic_vector'("10110110"); --B6
		r_addr_bank1 <= transport std_logic_vector'("0000001"); --1
		w_addr_bank1 <= transport std_logic_vector'("0000010"); --2
		di_bank1 <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		rst <= transport '0';
		r_addr_bank0 <= transport std_logic_vector'("1111101"); --7D
		w_addr_bank0 <= transport std_logic_vector'("1111100"); --7C
		di_bank0 <= transport std_logic_vector'("00001111"); --F
		r_addr_bank1 <= transport std_logic_vector'("0000010"); --2
		w_addr_bank1 <= transport std_logic_vector'("0000011"); --3
		di_bank1 <= transport std_logic_vector'("11000000"); --C0
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		r_addr_bank0 <= transport std_logic_vector'("1111100"); --7C
		w_addr_bank0 <= transport std_logic_vector'("1111011"); --7B
		di_bank0 <= transport std_logic_vector'("00011111"); --1F
		r_addr_bank1 <= transport std_logic_vector'("0000011"); --3
		w_addr_bank1 <= transport std_logic_vector'("0000100"); --4
		di_bank1 <= transport std_logic_vector'("10011110"); --9E
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		r_addr_bank0 <= transport std_logic_vector'("1111011"); --7B
		w_addr_bank0 <= transport std_logic_vector'("1111010"); --7A
		di_bank0 <= transport std_logic_vector'("11010000"); --D0
		r_addr_bank1 <= transport std_logic_vector'("0000100"); --4
		w_addr_bank1 <= transport std_logic_vector'("0000010"); --2
		di_bank1 <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		r_addr_bank0 <= transport std_logic_vector'("1111010"); --7A
		w_addr_bank0 <= transport std_logic_vector'("1111001"); --79
		di_bank0 <= transport std_logic_vector'("01001011"); --4B
		r_addr_bank1 <= transport std_logic_vector'("0000101"); --5
		w_addr_bank1 <= transport std_logic_vector'("0000000"); --0
		di_bank1 <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		r_addr_bank0 <= transport std_logic_vector'("1111001"); --79
		w_addr_bank0 <= transport std_logic_vector'("0010000"); --10
		di_bank0 <= transport std_logic_vector'("11111001"); --F9
		r_addr_bank1 <= transport std_logic_vector'("0000110"); --6
		w_addr_bank1 <= transport std_logic_vector'("0000111"); --7
		di_bank1 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		r_addr_bank0 <= transport std_logic_vector'("1111000"); --78
		w_addr_bank0 <= transport std_logic_vector'("1110111"); --77
		di_bank0 <= transport std_logic_vector'("10000011"); --83
		r_addr_bank1 <= transport std_logic_vector'("0000111"); --7
		w_addr_bank1 <= transport std_logic_vector'("0001000"); --8
		di_bank1 <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		r_addr_bank0 <= transport std_logic_vector'("1110111"); --77
		w_addr_bank0 <= transport std_logic_vector'("1110110"); --76
		di_bank0 <= transport std_logic_vector'("11010001"); --D1
		r_addr_bank1 <= transport std_logic_vector'("0001000"); --8
		w_addr_bank1 <= transport std_logic_vector'("0001001"); --9
		di_bank1 <= transport std_logic_vector'("01111010"); --7A
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		r_addr_bank0 <= transport std_logic_vector'("1110110"); --76
		w_addr_bank0 <= transport std_logic_vector'("1110101"); --75
		di_bank0 <= transport std_logic_vector'("00001110"); --E
		r_addr_bank1 <= transport std_logic_vector'("0001001"); --9
		w_addr_bank1 <= transport std_logic_vector'("0001010"); --A
		di_bank1 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		r_addr_bank0 <= transport std_logic_vector'("1110101"); --75
		w_addr_bank0 <= transport std_logic_vector'("1110100"); --74
		di_bank0 <= transport std_logic_vector'("10100010"); --A2
		r_addr_bank1 <= transport std_logic_vector'("0001010"); --A
		w_addr_bank1 <= transport std_logic_vector'("0001011"); --B
		di_bank1 <= transport std_logic_vector'("10010101"); --95
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		r_addr_bank0 <= transport std_logic_vector'("1110100"); --74
		w_addr_bank0 <= transport std_logic_vector'("1110011"); --73
		di_bank0 <= transport std_logic_vector'("00110110"); --36
		r_addr_bank1 <= transport std_logic_vector'("0001011"); --B
		w_addr_bank1 <= transport std_logic_vector'("0001100"); --C
		di_bank1 <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		r_addr_bank0 <= transport std_logic_vector'("1110011"); --73
		w_addr_bank0 <= transport std_logic_vector'("1110010"); --72
		di_bank0 <= transport std_logic_vector'("10110010"); --B2
		r_addr_bank1 <= transport std_logic_vector'("0001100"); --C
		w_addr_bank1 <= transport std_logic_vector'("0001101"); --D
		di_bank1 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		r_addr_bank0 <= transport std_logic_vector'("1110010"); --72
		w_addr_bank0 <= transport std_logic_vector'("1110001"); --71
		di_bank0 <= transport std_logic_vector'("01000001"); --41
		r_addr_bank1 <= transport std_logic_vector'("0001101"); --D
		w_addr_bank1 <= transport std_logic_vector'("0001110"); --E
		di_bank1 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		r_addr_bank0 <= transport std_logic_vector'("1110001"); --71
		w_addr_bank0 <= transport std_logic_vector'("1110000"); --70
		di_bank0 <= transport std_logic_vector'("01001011"); --4B
		r_addr_bank1 <= transport std_logic_vector'("0001110"); --E
		w_addr_bank1 <= transport std_logic_vector'("0001111"); --F
		di_bank1 <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		r_addr_bank0 <= transport std_logic_vector'("1110000"); --70
		w_addr_bank0 <= transport std_logic_vector'("1101111"); --6F
		di_bank0 <= transport std_logic_vector'("01111000"); --78
		r_addr_bank1 <= transport std_logic_vector'("0001111"); --F
		w_addr_bank1 <= transport std_logic_vector'("0010000"); --10
		di_bank1 <= transport std_logic_vector'("11011001"); --D9
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		r_addr_bank0 <= transport std_logic_vector'("1101111"); --6F
		w_addr_bank0 <= transport std_logic_vector'("1101110"); --6E
		di_bank0 <= transport std_logic_vector'("10110011"); --B3
		r_addr_bank1 <= transport std_logic_vector'("0010000"); --10
		w_addr_bank1 <= transport std_logic_vector'("0010001"); --11
		di_bank1 <= transport std_logic_vector'("01110000"); --70
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		r_addr_bank0 <= transport std_logic_vector'("1101110"); --6E
		w_addr_bank0 <= transport std_logic_vector'("1101101"); --6D
		di_bank0 <= transport std_logic_vector'("00100011"); --23
		r_addr_bank1 <= transport std_logic_vector'("0010001"); --11
		w_addr_bank1 <= transport std_logic_vector'("0010010"); --12
		di_bank1 <= transport std_logic_vector'("01100111"); --67
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		r_addr_bank0 <= transport std_logic_vector'("1101101"); --6D
		w_addr_bank0 <= transport std_logic_vector'("1101100"); --6C
		di_bank0 <= transport std_logic_vector'("00110010"); --32
		r_addr_bank1 <= transport std_logic_vector'("0010010"); --12
		w_addr_bank1 <= transport std_logic_vector'("0010011"); --13
		di_bank1 <= transport std_logic_vector'("11010111"); --D7
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		r_addr_bank0 <= transport std_logic_vector'("1101100"); --6C
		w_addr_bank0 <= transport std_logic_vector'("1101011"); --6B
		di_bank0 <= transport std_logic_vector'("10001010"); --8A
		r_addr_bank1 <= transport std_logic_vector'("0010011"); --13
		w_addr_bank1 <= transport std_logic_vector'("0010100"); --14
		di_bank1 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		wr_bank0 <= transport '0';
		r_addr_bank0 <= transport std_logic_vector'("1101011"); --6B
		w_addr_bank0 <= transport std_logic_vector'("1101010"); --6A
		di_bank0 <= transport std_logic_vector'("00010010"); --12
		r_addr_bank1 <= transport std_logic_vector'("0010100"); --14
		w_addr_bank1 <= transport std_logic_vector'("0010101"); --15
		di_bank1 <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		r_addr_bank0 <= transport std_logic_vector'("1101010"); --6A
		w_addr_bank0 <= transport std_logic_vector'("1101001"); --69
		di_bank0 <= transport std_logic_vector'("11110100"); --F4
		r_addr_bank1 <= transport std_logic_vector'("0010101"); --15
		w_addr_bank1 <= transport std_logic_vector'("0010110"); --16
		di_bank1 <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		wr_bank0 <= transport '1';
		r_addr_bank0 <= transport std_logic_vector'("1101001"); --69
		w_addr_bank0 <= transport std_logic_vector'("1101000"); --68
		di_bank0 <= transport std_logic_vector'("10011001"); --99
		r_addr_bank1 <= transport std_logic_vector'("0010110"); --16
		w_addr_bank1 <= transport std_logic_vector'("0010111"); --17
		di_bank1 <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		r_addr_bank0 <= transport std_logic_vector'("1101000"); --68
		w_addr_bank0 <= transport std_logic_vector'("1100111"); --67
		di_bank0 <= transport std_logic_vector'("10101011"); --AB
		r_addr_bank1 <= transport std_logic_vector'("0010111"); --17
		w_addr_bank1 <= transport std_logic_vector'("0011000"); --18
		di_bank1 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		r_addr_bank0 <= transport std_logic_vector'("1100111"); --67
		w_addr_bank0 <= transport std_logic_vector'("1100110"); --66
		di_bank0 <= transport std_logic_vector'("00010001"); --11
		r_addr_bank1 <= transport std_logic_vector'("0011000"); --18
		w_addr_bank1 <= transport std_logic_vector'("0011001"); --19
		di_bank1 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		r_addr_bank0 <= transport std_logic_vector'("1100110"); --66
		w_addr_bank0 <= transport std_logic_vector'("1100101"); --65
		di_bank0 <= transport std_logic_vector'("11110101"); --F5
		wr_bank1 <= transport '0';
		r_addr_bank1 <= transport std_logic_vector'("0011001"); --19
		w_addr_bank1 <= transport std_logic_vector'("0011010"); --1A
		di_bank1 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		r_addr_bank0 <= transport std_logic_vector'("1100101"); --65
		w_addr_bank0 <= transport std_logic_vector'("1100100"); --64
		di_bank0 <= transport std_logic_vector'("11000000"); --C0
		r_addr_bank1 <= transport std_logic_vector'("0011010"); --1A
		w_addr_bank1 <= transport std_logic_vector'("0011011"); --1B
		di_bank1 <= transport std_logic_vector'("10000110"); --86
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		r_addr_bank0 <= transport std_logic_vector'("1100100"); --64
		w_addr_bank0 <= transport std_logic_vector'("1100011"); --63
		di_bank0 <= transport std_logic_vector'("00011011"); --1B
		r_addr_bank1 <= transport std_logic_vector'("0011011"); --1B
		w_addr_bank1 <= transport std_logic_vector'("0011100"); --1C
		di_bank1 <= transport std_logic_vector'("11011001"); --D9
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		r_addr_bank0 <= transport std_logic_vector'("1100011"); --63
		w_addr_bank0 <= transport std_logic_vector'("1100010"); --62
		di_bank0 <= transport std_logic_vector'("11101111"); --EF
		wr_bank1 <= transport '1';
		r_addr_bank1 <= transport std_logic_vector'("0011100"); --1C
		w_addr_bank1 <= transport std_logic_vector'("0011101"); --1D
		di_bank1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		r_addr_bank0 <= transport std_logic_vector'("1100010"); --62
		w_addr_bank0 <= transport std_logic_vector'("1100001"); --61
		di_bank0 <= transport std_logic_vector'("01100100"); --64
		r_addr_bank1 <= transport std_logic_vector'("0011101"); --1D
		w_addr_bank1 <= transport std_logic_vector'("0011110"); --1E
		di_bank1 <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		r_addr_bank0 <= transport std_logic_vector'("1100001"); --61
		w_addr_bank0 <= transport std_logic_vector'("1100000"); --60
		di_bank0 <= transport std_logic_vector'("11100101"); --E5
		r_addr_bank1 <= transport std_logic_vector'("0011110"); --1E
		w_addr_bank1 <= transport std_logic_vector'("0011111"); --1F
		di_bank1 <= transport std_logic_vector'("10100111"); --A7
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		r_addr_bank0 <= transport std_logic_vector'("1100000"); --60
		w_addr_bank0 <= transport std_logic_vector'("1011111"); --5F
		di_bank0 <= transport std_logic_vector'("00011010"); --1A
		r_addr_bank1 <= transport std_logic_vector'("0011111"); --1F
		w_addr_bank1 <= transport std_logic_vector'("0100000"); --20
		di_bank1 <= transport std_logic_vector'("11011010"); --DA
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		r_addr_bank0 <= transport std_logic_vector'("1011111"); --5F
		w_addr_bank0 <= transport std_logic_vector'("1011110"); --5E
		di_bank0 <= transport std_logic_vector'("11101100"); --EC
		r_addr_bank1 <= transport std_logic_vector'("0100000"); --20
		w_addr_bank1 <= transport std_logic_vector'("0100001"); --21
		di_bank1 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		r_addr_bank0 <= transport std_logic_vector'("1011110"); --5E
		w_addr_bank0 <= transport std_logic_vector'("1011101"); --5D
		di_bank0 <= transport std_logic_vector'("10000011"); --83
		r_addr_bank1 <= transport std_logic_vector'("0100001"); --21
		w_addr_bank1 <= transport std_logic_vector'("0100010"); --22
		di_bank1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		r_addr_bank0 <= transport std_logic_vector'("1011101"); --5D
		w_addr_bank0 <= transport std_logic_vector'("1011100"); --5C
		di_bank0 <= transport std_logic_vector'("01001010"); --4A
		r_addr_bank1 <= transport std_logic_vector'("0100010"); --22
		w_addr_bank1 <= transport std_logic_vector'("0100011"); --23
		di_bank1 <= transport std_logic_vector'("10100010"); --A2
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		r_addr_bank0 <= transport std_logic_vector'("1011100"); --5C
		w_addr_bank0 <= transport std_logic_vector'("1011011"); --5B
		di_bank0 <= transport std_logic_vector'("11101001"); --E9
		r_addr_bank1 <= transport std_logic_vector'("0100011"); --23
		w_addr_bank1 <= transport std_logic_vector'("0100100"); --24
		di_bank1 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		r_addr_bank0 <= transport std_logic_vector'("1011011"); --5B
		w_addr_bank0 <= transport std_logic_vector'("1011010"); --5A
		di_bank0 <= transport std_logic_vector'("01001000"); --48
		r_addr_bank1 <= transport std_logic_vector'("0100100"); --24
		w_addr_bank1 <= transport std_logic_vector'("0100101"); --25
		di_bank1 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		r_addr_bank0 <= transport std_logic_vector'("1011010"); --5A
		w_addr_bank0 <= transport std_logic_vector'("1011001"); --59
		di_bank0 <= transport std_logic_vector'("10010010"); --92
		r_addr_bank1 <= transport std_logic_vector'("0100101"); --25
		w_addr_bank1 <= transport std_logic_vector'("0100110"); --26
		di_bank1 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		r_addr_bank0 <= transport std_logic_vector'("1011001"); --59
		w_addr_bank0 <= transport std_logic_vector'("1011000"); --58
		di_bank0 <= transport std_logic_vector'("00101110"); --2E
		r_addr_bank1 <= transport std_logic_vector'("0100110"); --26
		w_addr_bank1 <= transport std_logic_vector'("0100111"); --27
		di_bank1 <= transport std_logic_vector'("10111001"); --B9
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		r_addr_bank0 <= transport std_logic_vector'("1011000"); --58
		w_addr_bank0 <= transport std_logic_vector'("1010111"); --57
		di_bank0 <= transport std_logic_vector'("11000111"); --C7
		r_addr_bank1 <= transport std_logic_vector'("0100111"); --27
		w_addr_bank1 <= transport std_logic_vector'("0101000"); --28
		di_bank1 <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		r_addr_bank0 <= transport std_logic_vector'("1010111"); --57
		w_addr_bank0 <= transport std_logic_vector'("1010110"); --56
		di_bank0 <= transport std_logic_vector'("01000100"); --44
		r_addr_bank1 <= transport std_logic_vector'("0101000"); --28
		w_addr_bank1 <= transport std_logic_vector'("0101001"); --29
		di_bank1 <= transport std_logic_vector'("11100011"); --E3
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		r_addr_bank0 <= transport std_logic_vector'("1010110"); --56
		w_addr_bank0 <= transport std_logic_vector'("1010101"); --55
		di_bank0 <= transport std_logic_vector'("11001111"); --CF
		r_addr_bank1 <= transport std_logic_vector'("0101001"); --29
		w_addr_bank1 <= transport std_logic_vector'("0101010"); --2A
		di_bank1 <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		wr_bank0 <= transport '0';
		r_addr_bank0 <= transport std_logic_vector'("1010101"); --55
		w_addr_bank0 <= transport std_logic_vector'("1010100"); --54
		di_bank0 <= transport std_logic_vector'("11010001"); --D1
		r_addr_bank1 <= transport std_logic_vector'("0101010"); --2A
		w_addr_bank1 <= transport std_logic_vector'("0101011"); --2B
		di_bank1 <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 100 ps; -- Time=4300 ps
		r_addr_bank0 <= transport std_logic_vector'("1010100"); --54
		w_addr_bank0 <= transport std_logic_vector'("1010011"); --53
		di_bank0 <= transport std_logic_vector'("11110100"); --F4
		r_addr_bank1 <= transport std_logic_vector'("0101011"); --2B
		w_addr_bank1 <= transport std_logic_vector'("0101100"); --2C
		di_bank1 <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 100 ps; -- Time=4400 ps
		wr_bank0 <= transport '1';
		r_addr_bank0 <= transport std_logic_vector'("1010011"); --53
		w_addr_bank0 <= transport std_logic_vector'("1010010"); --52
		di_bank0 <= transport std_logic_vector'("00011111"); --1F
		r_addr_bank1 <= transport std_logic_vector'("0101100"); --2C
		w_addr_bank1 <= transport std_logic_vector'("0101101"); --2D
		di_bank1 <= transport std_logic_vector'("01011010"); --5A
		-- --------------------
		WAIT FOR 100 ps; -- Time=4500 ps
		r_addr_bank0 <= transport std_logic_vector'("1010010"); --52
		w_addr_bank0 <= transport std_logic_vector'("1010001"); --51
		di_bank0 <= transport std_logic_vector'("01111100"); --7C
		r_addr_bank1 <= transport std_logic_vector'("0101101"); --2D
		w_addr_bank1 <= transport std_logic_vector'("0101110"); --2E
		di_bank1 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 100 ps; -- Time=4600 ps
		r_addr_bank0 <= transport std_logic_vector'("1010001"); --51
		w_addr_bank0 <= transport std_logic_vector'("1010000"); --50
		di_bank0 <= transport std_logic_vector'("01110100"); --74
		r_addr_bank1 <= transport std_logic_vector'("0101110"); --2E
		w_addr_bank1 <= transport std_logic_vector'("0101111"); --2F
		di_bank1 <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 100 ps; -- Time=4700 ps
		r_addr_bank0 <= transport std_logic_vector'("1010000"); --50
		w_addr_bank0 <= transport std_logic_vector'("1001111"); --4F
		di_bank0 <= transport std_logic_vector'("10110000"); --B0
		r_addr_bank1 <= transport std_logic_vector'("0101111"); --2F
		w_addr_bank1 <= transport std_logic_vector'("0110000"); --30
		di_bank1 <= transport std_logic_vector'("10010000"); --90
		-- --------------------
		WAIT FOR 100 ps; -- Time=4800 ps
		r_addr_bank0 <= transport std_logic_vector'("1001111"); --4F
		w_addr_bank0 <= transport std_logic_vector'("1001110"); --4E
		di_bank0 <= transport std_logic_vector'("00011001"); --19
		r_addr_bank1 <= transport std_logic_vector'("0110000"); --30
		w_addr_bank1 <= transport std_logic_vector'("0110001"); --31
		di_bank1 <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 100 ps; -- Time=4900 ps
		r_addr_bank0 <= transport std_logic_vector'("1001110"); --4E
		w_addr_bank0 <= transport std_logic_vector'("1001101"); --4D
		di_bank0 <= transport std_logic_vector'("11011000"); --D8
		r_addr_bank1 <= transport std_logic_vector'("0110001"); --31
		w_addr_bank1 <= transport std_logic_vector'("0110010"); --32
		di_bank1 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 100 ps; -- Time=5000 ps
		r_addr_bank0 <= transport std_logic_vector'("0111011"); --3B
		w_addr_bank0 <= transport std_logic_vector'("0001001"); --9
		di_bank0 <= transport std_logic_vector'("01010110"); --56
		r_addr_bank1 <= transport std_logic_vector'("1101110"); --6E
		w_addr_bank1 <= transport std_logic_vector'("0110010"); --32
		di_bank1 <= transport std_logic_vector'("00100001"); --21
		-- --------------------
		WAIT FOR 100 ps; -- Time=5100 ps
		r_addr_bank0 <= transport std_logic_vector'("0110010"); --32
		w_addr_bank0 <= transport std_logic_vector'("0110111"); --37
		di_bank0 <= transport std_logic_vector'("00111100"); --3C
		r_addr_bank1 <= transport std_logic_vector'("0101110"); --2E
		w_addr_bank1 <= transport std_logic_vector'("0110011"); --33
		di_bank1 <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 100 ps; -- Time=5200 ps
		rst <= transport '1';
		r_addr_bank0 <= transport std_logic_vector'("0010111"); --17
		w_addr_bank0 <= transport std_logic_vector'("1000101"); --45
		di_bank0 <= transport std_logic_vector'("01110010"); --72
		r_addr_bank1 <= transport std_logic_vector'("1101001"); --69
		w_addr_bank1 <= transport std_logic_vector'("0110100"); --34
		di_bank1 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 100 ps; -- Time=5300 ps
		r_addr_bank0 <= transport std_logic_vector'("1101011"); --6B
		w_addr_bank0 <= transport std_logic_vector'("0000111"); --7
		di_bank0 <= transport std_logic_vector'("00100011"); --23
		wr_bank1 <= transport '0';
		r_addr_bank1 <= transport std_logic_vector'("1001110"); --4E
		w_addr_bank1 <= transport std_logic_vector'("0110101"); --35
		di_bank1 <= transport std_logic_vector'("10110010"); --B2
		-- --------------------
		WAIT FOR 100 ps; -- Time=5400 ps
		rst <= transport '0';
		r_addr_bank0 <= transport std_logic_vector'("1101110"); --6E
		w_addr_bank0 <= transport std_logic_vector'("0010010"); --12
		di_bank0 <= transport std_logic_vector'("10110111"); --B7
		r_addr_bank1 <= transport std_logic_vector'("1001001"); --49
		w_addr_bank1 <= transport std_logic_vector'("0110110"); --36
		di_bank1 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ps; -- Time=5500 ps
		r_addr_bank0 <= transport std_logic_vector'("0100010"); --22
		w_addr_bank0 <= transport std_logic_vector'("0111100"); --3C
		di_bank0 <= transport std_logic_vector'("11010111"); --D7
		r_addr_bank1 <= transport std_logic_vector'("0001000"); --8
		w_addr_bank1 <= transport std_logic_vector'("0110111"); --37
		di_bank1 <= transport std_logic_vector'("01101110"); --6E
		-- --------------------
		WAIT FOR 100 ps; -- Time=5600 ps
		r_addr_bank0 <= transport std_logic_vector'("1001000"); --48
		w_addr_bank0 <= transport std_logic_vector'("0011010"); --1A
		di_bank0 <= transport std_logic_vector'("01101011"); --6B
		wr_bank1 <= transport '1';
		r_addr_bank1 <= transport std_logic_vector'("1110111"); --77
		w_addr_bank1 <= transport std_logic_vector'("0111000"); --38
		di_bank1 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ps; -- Time=5700 ps
		r_addr_bank0 <= transport std_logic_vector'("1100001"); --61
		w_addr_bank0 <= transport std_logic_vector'("1111111"); --7F
		di_bank0 <= transport std_logic_vector'("10011110"); --9E
		r_addr_bank1 <= transport std_logic_vector'("1000011"); --43
		w_addr_bank1 <= transport std_logic_vector'("0111001"); --39
		di_bank1 <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 100 ps; -- Time=5800 ps
		r_addr_bank0 <= transport std_logic_vector'("0101110"); --2E
		w_addr_bank0 <= transport std_logic_vector'("0000010"); --2
		di_bank0 <= transport std_logic_vector'("11010111"); --D7
		r_addr_bank1 <= transport std_logic_vector'("1011001"); --59
		w_addr_bank1 <= transport std_logic_vector'("0111010"); --3A
		di_bank1 <= transport std_logic_vector'("10000100"); --84
		-- --------------------
		WAIT FOR 100 ps; -- Time=5900 ps
		r_addr_bank0 <= transport std_logic_vector'("0101111"); --2F
		w_addr_bank0 <= transport std_logic_vector'("1111000"); --78
		di_bank0 <= transport std_logic_vector'("11000001"); --C1
		r_addr_bank1 <= transport std_logic_vector'("1100110"); --66
		w_addr_bank1 <= transport std_logic_vector'("0111011"); --3B
		di_bank1 <= transport std_logic_vector'("10011110"); --9E
		-- --------------------
		WAIT FOR 100 ps; -- Time=6000 ps
		r_addr_bank0 <= transport std_logic_vector'("0100110"); --26
		w_addr_bank0 <= transport std_logic_vector'("1110101"); --75
		di_bank0 <= transport std_logic_vector'("01000011"); --43
		r_addr_bank1 <= transport std_logic_vector'("1011000"); --58
		w_addr_bank1 <= transport std_logic_vector'("0111100"); --3C
		di_bank1 <= transport std_logic_vector'("00001010"); --A
		-- --------------------
		WAIT FOR 100 ps; -- Time=6100 ps
		r_addr_bank0 <= transport std_logic_vector'("0010101"); --15
		w_addr_bank0 <= transport std_logic_vector'("1001110"); --4E
		di_bank0 <= transport std_logic_vector'("10000111"); --87
		r_addr_bank1 <= transport std_logic_vector'("1011011"); --5B
		w_addr_bank1 <= transport std_logic_vector'("0111101"); --3D
		di_bank1 <= transport std_logic_vector'("10100010"); --A2
		-- --------------------
		WAIT FOR 100 ps; -- Time=6200 ps
		r_addr_bank0 <= transport std_logic_vector'("0111011"); --3B
		w_addr_bank0 <= transport std_logic_vector'("0011001"); --19
		di_bank0 <= transport std_logic_vector'("11110111"); --F7
		r_addr_bank1 <= transport std_logic_vector'("1011101"); --5D
		w_addr_bank1 <= transport std_logic_vector'("0111110"); --3E
		di_bank1 <= transport std_logic_vector'("01111110"); --7E
		-- --------------------
		WAIT FOR 100 ps; -- Time=6300 ps
		r_addr_bank0 <= transport std_logic_vector'("0011001"); --19
		w_addr_bank0 <= transport std_logic_vector'("0101010"); --2A
		di_bank0 <= transport std_logic_vector'("00111010"); --3A
		r_addr_bank1 <= transport std_logic_vector'("0001001"); --9
		w_addr_bank1 <= transport std_logic_vector'("0111111"); --3F
		di_bank1 <= transport std_logic_vector'("11111001"); --F9
		-- --------------------
		WAIT FOR 100 ps; -- Time=6400 ps
		wr_bank0 <= transport '0';
		r_addr_bank0 <= transport std_logic_vector'("1110010"); --72
		w_addr_bank0 <= transport std_logic_vector'("0010110"); --16
		r_addr_bank1 <= transport std_logic_vector'("1001110"); --4E
		w_addr_bank1 <= transport std_logic_vector'("1000000"); --40
		di_bank1 <= transport std_logic_vector'("10101010"); --AA
		-- --------------------
		WAIT FOR 100 ps; -- Time=6500 ps
		r_addr_bank0 <= transport std_logic_vector'("1000110"); --46
		w_addr_bank0 <= transport std_logic_vector'("0110011"); --33
		di_bank0 <= transport std_logic_vector'("00100000"); --20
		r_addr_bank1 <= transport std_logic_vector'("1011000"); --58
		w_addr_bank1 <= transport std_logic_vector'("1000001"); --41
		di_bank1 <= transport std_logic_vector'("01101011"); --6B
		-- --------------------
		WAIT FOR 100 ps; -- Time=6600 ps
		wr_bank0 <= transport '1';
		r_addr_bank0 <= transport std_logic_vector'("1010101"); --55
		w_addr_bank0 <= transport std_logic_vector'("0010101"); --15
		di_bank0 <= transport std_logic_vector'("01010110"); --56
		r_addr_bank1 <= transport std_logic_vector'("0010100"); --14
		w_addr_bank1 <= transport std_logic_vector'("1000010"); --42
		di_bank1 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ps; -- Time=6700 ps
		r_addr_bank0 <= transport std_logic_vector'("0100001"); --21
		w_addr_bank0 <= transport std_logic_vector'("0010010"); --12
		di_bank0 <= transport std_logic_vector'("10000011"); --83
		r_addr_bank1 <= transport std_logic_vector'("0110000"); --30
		w_addr_bank1 <= transport std_logic_vector'("1000011"); --43
		di_bank1 <= transport std_logic_vector'("10111111"); --BF
		-- --------------------
		WAIT FOR 100 ps; -- Time=6800 ps
		r_addr_bank0 <= transport std_logic_vector'("1101011"); --6B
		w_addr_bank0 <= transport std_logic_vector'("0111110"); --3E
		di_bank0 <= transport std_logic_vector'("10010001"); --91
		r_addr_bank1 <= transport std_logic_vector'("0011000"); --18
		w_addr_bank1 <= transport std_logic_vector'("1000100"); --44
		di_bank1 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ps; -- Time=6900 ps
		r_addr_bank0 <= transport std_logic_vector'("0110100"); --34
		w_addr_bank0 <= transport std_logic_vector'("1101110"); --6E
		di_bank0 <= transport std_logic_vector'("10101001"); --A9
		r_addr_bank1 <= transport std_logic_vector'("1111001"); --79
		w_addr_bank1 <= transport std_logic_vector'("1000101"); --45
		di_bank1 <= transport std_logic_vector'("10111111"); --BF
		-- --------------------
		WAIT FOR 100 ps; -- Time=7000 ps
		r_addr_bank0 <= transport std_logic_vector'("0111100"); --3C
		w_addr_bank0 <= transport std_logic_vector'("0111000"); --38
		di_bank0 <= transport std_logic_vector'("00110100"); --34
		r_addr_bank1 <= transport std_logic_vector'("1000001"); --41
		w_addr_bank1 <= transport std_logic_vector'("1000110"); --46
		di_bank1 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ps; -- Time=7100 ps
		r_addr_bank0 <= transport std_logic_vector'("0000110"); --6
		w_addr_bank0 <= transport std_logic_vector'("1110000"); --70
		di_bank0 <= transport std_logic_vector'("11011011"); --DB
		r_addr_bank1 <= transport std_logic_vector'("0011011"); --1B
		w_addr_bank1 <= transport std_logic_vector'("1000111"); --47
		di_bank1 <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 100 ps; -- Time=7200 ps
		r_addr_bank0 <= transport std_logic_vector'("1010001"); --51
		w_addr_bank0 <= transport std_logic_vector'("0101100"); --2C
		di_bank0 <= transport std_logic_vector'("10000110"); --86
		r_addr_bank1 <= transport std_logic_vector'("1110110"); --76
		w_addr_bank1 <= transport std_logic_vector'("1001000"); --48
		di_bank1 <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 100 ps; -- Time=7300 ps
		r_addr_bank0 <= transport std_logic_vector'("0011111"); --1F
		w_addr_bank0 <= transport std_logic_vector'("1000000"); --40
		di_bank0 <= transport std_logic_vector'("01100000"); --60
		r_addr_bank1 <= transport std_logic_vector'("1111110"); --7E
		w_addr_bank1 <= transport std_logic_vector'("1001001"); --49
		di_bank1 <= transport std_logic_vector'("11011110"); --DE
		-- --------------------
		WAIT FOR 100 ps; -- Time=7400 ps
		r_addr_bank0 <= transport std_logic_vector'("0110001"); --31
		w_addr_bank0 <= transport std_logic_vector'("1000001"); --41
		di_bank0 <= transport std_logic_vector'("11010001"); --D1
		r_addr_bank1 <= transport std_logic_vector'("0100001"); --21
		w_addr_bank1 <= transport std_logic_vector'("1001010"); --4A
		di_bank1 <= transport std_logic_vector'("10010001"); --91
		-- --------------------
		WAIT FOR 100 ps; -- Time=7500 ps
		r_addr_bank0 <= transport std_logic_vector'("0001000"); --8
		w_addr_bank0 <= transport std_logic_vector'("0000101"); --5
		di_bank0 <= transport std_logic_vector'("10000010"); --82
		r_addr_bank1 <= transport std_logic_vector'("0001011"); --B
		w_addr_bank1 <= transport std_logic_vector'("1001011"); --4B
		di_bank1 <= transport std_logic_vector'("10001110"); --8E
		-- --------------------
		WAIT FOR 100 ps; -- Time=7600 ps
		r_addr_bank0 <= transport std_logic_vector'("1100100"); --64
		w_addr_bank0 <= transport std_logic_vector'("0100000"); --20
		di_bank0 <= transport std_logic_vector'("01011011"); --5B
		r_addr_bank1 <= transport std_logic_vector'("0101001"); --29
		w_addr_bank1 <= transport std_logic_vector'("1001100"); --4C
		di_bank1 <= transport std_logic_vector'("01101101"); --6D
		-- --------------------
		WAIT FOR 100 ps; -- Time=7700 ps
		r_addr_bank0 <= transport std_logic_vector'("1001000"); --48
		w_addr_bank0 <= transport std_logic_vector'("1100111"); --67
		di_bank0 <= transport std_logic_vector'("10000111"); --87
		r_addr_bank1 <= transport std_logic_vector'("0101000"); --28
		w_addr_bank1 <= transport std_logic_vector'("1001101"); --4D
		di_bank1 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 100 ps; -- Time=7800 ps
		r_addr_bank0 <= transport std_logic_vector'("1110011"); --73
		w_addr_bank0 <= transport std_logic_vector'("1110000"); --70
		di_bank0 <= transport std_logic_vector'("01101110"); --6E
		r_addr_bank1 <= transport std_logic_vector'("1110110"); --76
		w_addr_bank1 <= transport std_logic_vector'("1001110"); --4E
		di_bank1 <= transport std_logic_vector'("01111000"); --78
		-- --------------------
		WAIT FOR 100 ps; -- Time=7900 ps
		r_addr_bank0 <= transport std_logic_vector'("1100111"); --67
		w_addr_bank0 <= transport std_logic_vector'("0010000"); --10
		di_bank0 <= transport std_logic_vector'("10111000"); --B8
		r_addr_bank1 <= transport std_logic_vector'("0111110"); --3E
		w_addr_bank1 <= transport std_logic_vector'("1001111"); --4F
		di_bank1 <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 100 ps; -- Time=8000 ps
		r_addr_bank0 <= transport std_logic_vector'("1100101"); --65
		w_addr_bank0 <= transport std_logic_vector'("1011010"); --5A
		di_bank0 <= transport std_logic_vector'("01010000"); --50
		r_addr_bank1 <= transport std_logic_vector'("1110000"); --70
		w_addr_bank1 <= transport std_logic_vector'("1010000"); --50
		di_bank1 <= transport std_logic_vector'("01111010"); --7A
		-- --------------------
		WAIT FOR 100 ps; -- Time=8100 ps
		r_addr_bank0 <= transport std_logic_vector'("1101110"); --6E
		w_addr_bank0 <= transport std_logic_vector'("0100101"); --25
		di_bank0 <= transport std_logic_vector'("01011101"); --5D
		wr_bank1 <= transport '0';
		r_addr_bank1 <= transport std_logic_vector'("0110110"); --36
		w_addr_bank1 <= transport std_logic_vector'("1010001"); --51
		di_bank1 <= transport std_logic_vector'("01111110"); --7E
		-- --------------------
		WAIT FOR 100 ps; -- Time=8200 ps
		r_addr_bank0 <= transport std_logic_vector'("1000010"); --42
		w_addr_bank0 <= transport std_logic_vector'("0000110"); --6
		di_bank0 <= transport std_logic_vector'("01001001"); --49
		r_addr_bank1 <= transport std_logic_vector'("1111111"); --7F
		w_addr_bank1 <= transport std_logic_vector'("1010010"); --52
		di_bank1 <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 100 ps; -- Time=8300 ps
		r_addr_bank0 <= transport std_logic_vector'("1100100"); --64
		w_addr_bank0 <= transport std_logic_vector'("1010001"); --51
		di_bank0 <= transport std_logic_vector'("10111110"); --BE
		r_addr_bank1 <= transport std_logic_vector'("1110110"); --76
		w_addr_bank1 <= transport std_logic_vector'("1010011"); --53
		di_bank1 <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ps; -- Time=8400 ps
		r_addr_bank0 <= transport std_logic_vector'("0010011"); --13
		w_addr_bank0 <= transport std_logic_vector'("0011011"); --1B
		di_bank0 <= transport std_logic_vector'("10100011"); --A3
		wr_bank1 <= transport '1';
		r_addr_bank1 <= transport std_logic_vector'("0001011"); --B
		w_addr_bank1 <= transport std_logic_vector'("1010100"); --54
		di_bank1 <= transport std_logic_vector'("10000010"); --82
		-- --------------------
		WAIT FOR 100 ps; -- Time=8500 ps
		r_addr_bank0 <= transport std_logic_vector'("1010001"); --51
		w_addr_bank0 <= transport std_logic_vector'("0111010"); --3A
		di_bank0 <= transport std_logic_vector'("00100010"); --22
		r_addr_bank1 <= transport std_logic_vector'("1101000"); --68
		w_addr_bank1 <= transport std_logic_vector'("1010101"); --55
		di_bank1 <= transport std_logic_vector'("01111111"); --7F
		-- --------------------
		WAIT FOR 100 ps; -- Time=8600 ps
		wr_bank0 <= transport '0';
		r_addr_bank0 <= transport std_logic_vector'("1011111"); --5F
		w_addr_bank0 <= transport std_logic_vector'("1000010"); --42
		di_bank0 <= transport std_logic_vector'("10100100"); --A4
		r_addr_bank1 <= transport std_logic_vector'("1111100"); --7C
		w_addr_bank1 <= transport std_logic_vector'("1010110"); --56
		di_bank1 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 100 ps; -- Time=8700 ps
		r_addr_bank0 <= transport std_logic_vector'("0111101"); --3D
		w_addr_bank0 <= transport std_logic_vector'("0001000"); --8
		di_bank0 <= transport std_logic_vector'("11010011"); --D3
		r_addr_bank1 <= transport std_logic_vector'("1110011"); --73
		w_addr_bank1 <= transport std_logic_vector'("1010111"); --57
		di_bank1 <= transport std_logic_vector'("10101000"); --A8
		-- --------------------
		WAIT FOR 100 ps; -- Time=8800 ps
		wr_bank0 <= transport '1';
		r_addr_bank0 <= transport std_logic_vector'("0101110"); --2E
		w_addr_bank0 <= transport std_logic_vector'("0100010"); --22
		di_bank0 <= transport std_logic_vector'("10010110"); --96
		r_addr_bank1 <= transport std_logic_vector'("0111010"); --3A
		w_addr_bank1 <= transport std_logic_vector'("1011000"); --58
		di_bank1 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 100 ps; -- Time=8900 ps
		r_addr_bank0 <= transport std_logic_vector'("0110001"); --31
		w_addr_bank0 <= transport std_logic_vector'("1100100"); --64
		di_bank0 <= transport std_logic_vector'("00010111"); --17
		r_addr_bank1 <= transport std_logic_vector'("1111110"); --7E
		w_addr_bank1 <= transport std_logic_vector'("1011001"); --59
		di_bank1 <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 100 ps; -- Time=9000 ps
		r_addr_bank0 <= transport std_logic_vector'("0001000"); --8
		w_addr_bank0 <= transport std_logic_vector'("1100100"); --64
		di_bank0 <= transport std_logic_vector'("10111111"); --BF
		r_addr_bank1 <= transport std_logic_vector'("0101101"); --2D
		w_addr_bank1 <= transport std_logic_vector'("1011010"); --5A
		di_bank1 <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 100 ps; -- Time=9100 ps
		r_addr_bank0 <= transport std_logic_vector'("0110100"); --34
		w_addr_bank0 <= transport std_logic_vector'("1110110"); --76
		di_bank0 <= transport std_logic_vector'("00110111"); --37
		r_addr_bank1 <= transport std_logic_vector'("1110011"); --73
		w_addr_bank1 <= transport std_logic_vector'("1011011"); --5B
		di_bank1 <= transport std_logic_vector'("00110010"); --32
		-- --------------------
		WAIT FOR 100 ps; -- Time=9200 ps
		r_addr_bank0 <= transport std_logic_vector'("1110110"); --76
		w_addr_bank0 <= transport std_logic_vector'("0101111"); --2F
		di_bank0 <= transport std_logic_vector'("01101000"); --68
		r_addr_bank1 <= transport std_logic_vector'("0111101"); --3D
		w_addr_bank1 <= transport std_logic_vector'("1011100"); --5C
		di_bank1 <= transport std_logic_vector'("10000101"); --85
		-- --------------------
		WAIT FOR 100 ps; -- Time=9300 ps
		r_addr_bank0 <= transport std_logic_vector'("1001111"); --4F
		w_addr_bank0 <= transport std_logic_vector'("1100101"); --65
		di_bank0 <= transport std_logic_vector'("01111010"); --7A
		r_addr_bank1 <= transport std_logic_vector'("0111001"); --39
		w_addr_bank1 <= transport std_logic_vector'("1011101"); --5D
		di_bank1 <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 100 ps; -- Time=9400 ps
		r_addr_bank0 <= transport std_logic_vector'("1111111"); --7F
		w_addr_bank0 <= transport std_logic_vector'("0101100"); --2C
		di_bank0 <= transport std_logic_vector'("11011000"); --D8
		r_addr_bank1 <= transport std_logic_vector'("1010011"); --53
		w_addr_bank1 <= transport std_logic_vector'("1011110"); --5E
		di_bank1 <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ps; -- Time=9500 ps
		r_addr_bank0 <= transport std_logic_vector'("0001001"); --9
		w_addr_bank0 <= transport std_logic_vector'("1011001"); --59
		di_bank0 <= transport std_logic_vector'("00101010"); --2A
		r_addr_bank1 <= transport std_logic_vector'("0111000"); --38
		w_addr_bank1 <= transport std_logic_vector'("1011111"); --5F
		di_bank1 <= transport std_logic_vector'("11100111"); --E7
		-- --------------------
		WAIT FOR 100 ps; -- Time=9600 ps
		r_addr_bank0 <= transport std_logic_vector'("0101100"); --2C
		w_addr_bank0 <= transport std_logic_vector'("0000010"); --2
		di_bank0 <= transport std_logic_vector'("01011001"); --59
		r_addr_bank1 <= transport std_logic_vector'("1010101"); --55
		w_addr_bank1 <= transport std_logic_vector'("1100000"); --60
		di_bank1 <= transport std_logic_vector'("11111111"); --FF
		-- --------------------
		WAIT FOR 100 ps; -- Time=9700 ps
		r_addr_bank0 <= transport std_logic_vector'("1101010"); --6A
		w_addr_bank0 <= transport std_logic_vector'("1111100"); --7C
		di_bank0 <= transport std_logic_vector'("10001101"); --8D
		r_addr_bank1 <= transport std_logic_vector'("1011000"); --58
		w_addr_bank1 <= transport std_logic_vector'("1100001"); --61
		di_bank1 <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 100 ps; -- Time=9800 ps
		r_addr_bank0 <= transport std_logic_vector'("0000100"); --4
		w_addr_bank0 <= transport std_logic_vector'("1011010"); --5A
		di_bank0 <= transport std_logic_vector'("00110001"); --31
		r_addr_bank1 <= transport std_logic_vector'("0101101"); --2D
		w_addr_bank1 <= transport std_logic_vector'("1100010"); --62
		di_bank1 <= transport std_logic_vector'("11010110"); --D6
		-- --------------------
		WAIT FOR 100 ps; -- Time=9900 ps
		r_addr_bank0 <= transport std_logic_vector'("1111010"); --7A
		w_addr_bank0 <= transport std_logic_vector'("1110011"); --73
		di_bank0 <= transport std_logic_vector'("11101101"); --ED
		r_addr_bank1 <= transport std_logic_vector'("0000001"); --1
		w_addr_bank1 <= transport std_logic_vector'("1100011"); --63
		di_bank1 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 60 ps; -- Time=9960 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION internal_ram_cfg OF internal_ram_tb IS
	FOR testbench_arch
	END FOR;
END internal_ram_cfg;
