-- E:\USERS\POLARBEAR\PROJECT\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Sat Feb 19 04:21:27 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_ARITH.ALL;
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY Rom_tb IS
END Rom_tb;

ARCHITECTURE testbench_arch OF Rom_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT external_rom
		PORT (
			rst : In  std_logic;
			clk : In  std_logic;
			ADDRESS_BUS : In  std_logic_vector (15 DOWNTO 0);
			OE : In  std_logic;
			DATA_BUS : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL rst : std_logic;
	SIGNAL clk : std_logic;
	SIGNAL ADDRESS_BUS : std_logic_vector (15 DOWNTO 0);
	SIGNAL OE : std_logic;
	SIGNAL DATA_BUS : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : external_rom
	PORT MAP (
		rst => rst,
		clk => clk,
		ADDRESS_BUS => ADDRESS_BUS,
		OE => OE,
		DATA_BUS => DATA_BUS
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_DATA_BUS(
			next_DATA_BUS : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (DATA_BUS /= next_DATA_BUS) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns DATA_BUS="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, DATA_BUS);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_DATA_BUS);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000000"); --0
		OE <= transport '1';
		clk <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000001"); --1
		OE <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000010"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000011"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000101"); --5
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000110"); --6
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000111"); --7
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001000"); --8
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001001"); --9
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001010"); --A
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001011"); --B
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		ADDRESS_BUS <= transport std_logic_vector'("ZZZZZZZZZZZZZZZZ"); --Z
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001101"); --D
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001110"); --E
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001111"); --F
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010000"); --10
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010001"); --11
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010010"); --12
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010011"); --13
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010100"); --14
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010101"); --15
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010110"); --16
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010111"); --17
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011000"); --18
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011001"); --19
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011010"); --1A
		OE <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011011"); --1B
		OE <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011100"); --1C
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011101"); --1D
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011110"); --1E
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011111"); --1F
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100000"); --20
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100001"); --21
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100010"); --22
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100011"); --23
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100100"); --24
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100101"); --25
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100110"); --26
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000100111"); --27
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101000"); --28
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101001"); --29
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101010"); --2A
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101011"); --2B
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101100"); --2C
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101101"); --2D
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101110"); --2E
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000101111"); --2F
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000110000"); --30
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000110001"); --31
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010011"); --13
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010100"); --14
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010101"); --15
		OE <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010110"); --16
		OE <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010111"); --17
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011000"); --18
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011001"); --19
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011010"); --1A
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011011"); --1B
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011100"); --1C
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011101"); --1D
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011110"); --1E
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000000"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000001"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000010"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000011"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000101"); --5
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000110"); --6
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000111"); --7
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001000"); --8
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001001"); --9
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001010"); --A
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001011"); --B
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001100"); --C
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001101"); --D
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001110"); --E
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000001111"); --F
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010000"); --10
		OE <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010001"); --11
		OE <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010010"); --12
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010011"); --13
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010100"); --14
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010101"); --15
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010110"); --16
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000010111"); --17
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011000"); --18
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011001"); --19
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011010"); --1A
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011011"); --1B
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011100"); --1C
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011101"); --1D
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000011110"); --1E
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000000"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000001"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000010"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000011"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000101"); --5
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		ADDRESS_BUS <= transport std_logic_vector'("0000000000000110"); --6
		-- --------------------
		WAIT FOR 25 ns; -- Time=1015 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION external_rom_cfg OF Rom_tb IS
	FOR testbench_arch
	END FOR;
END external_rom_cfg;
