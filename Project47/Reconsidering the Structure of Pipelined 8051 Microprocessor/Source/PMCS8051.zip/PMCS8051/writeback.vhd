library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity writeback is
    Port ( 	d11 			: in 	std_logic_vector (7 downto 0);
           	d22 			: in 	std_logic_vector (7 downto 0);
          	R_A			: in	std_logic_vector (7 downto 0); 
          	R_B			: in	std_logic_vector (7 downto 0); 
         	W_DPH 		: out std_logic;
         	W_DPL 		: out std_logic;
         	di_DPH		: out std_logic_vector (7 downto 0);
         	di_DPL		: out std_logic_vector (7 downto 0);
	         w_data0		: out	std_logic_vector (7 downto 0);
           	w_addr0 		: out std_logic_vector (7 downto 0);
			 	w_data1		: out	std_logic_vector (7 downto 0);
           	w_addr1 		: out std_logic_vector (7 downto 0);
--				wr_bank0		: out	std_logic;
--				wr_bank1 	: out	std_logic;
         	W_A 	 		: out	std_logic;
         	di_A		 	: out	std_logic_vector (7 downto 0);
         	W_B 	 		: out	std_logic;
         	di_B		 	: out	std_logic_vector (7 downto 0);
         	W_psw 	 	: out	std_logic;
         	di_psw	 	: out	std_logic_vector (7 downto 0);
         	load_rid		: out	std_logic;
         	din_rid	 	: out std_logic_vector (7 downto 0);
         	addr_rid	 	: out std_logic_vector (2 downto 0);
         	load_p0   	: out std_logic; 
				p0_in     	: out std_logic_vector (7 downto 0);
         	load_p1   	: out std_logic; 
         	p1_in     	: out std_logic_vector (7 downto 0);
         	load_p2   	: out std_logic; 
         	p2_in     	: out std_logic_vector (7 downto 0);
         	load_p3   	: out std_logic; 
         	p3_in     	: out std_logic_vector (7 downto 0)
--        	load_in 		: out std_logic;  --sp

--         	sel_mux11 	: out std_logic_vector (1 downto 0); 
--         	sel_mux12 	: out Std_logic_vector (1 downto 0); 
--         	sel_mux13 	: out std_logic; 
--         	sel_mux14 	: out  std_logic; 
				);
--           w_bank1 : out std_logic);
end writeback;

architecture Structural of writeback is

begin
	pin1: process(d11,d22,R_A,R_B)
	begin
 		W_A <= '0';
		W_B <= '0';	
		W_PSW <= '0';
		load_p3 <= '0';
		load_p2 <= '0';
		load_p1 <= '0';
		load_p0 <= '0';
		W_DPH <= '0';
		W_DPL <= '0';
--		wr_bank0 <= '0';
--		wr_bank1 <= '0';
		load_rid <= '0';
 		Di_A 		<= "00000000";
		Di_B 		<= "00000000";
		Di_PSW 	<= "00000000";
		p3_in 	<= "00000000";
		p2_in 	<= "00000000";
		p1_in 	<= "00000000";
		p0_in 	<= "00000000";
		Di_DPH 	<= "00000000";
	   Di_DPL 	<= "00000000";
		addr_rid <= "000";
		din_rid  <= "--------";
		load_rid <= '0';

		case  d11 is
			when "11100000" =>	W_A <= '1'; 	  		--ACC
										Di_A <= R_A;
			when "11110000" =>	W_B <= '1';				--B
										Di_B <= R_A;
			when "11010000" => 	W_PSW <= '1';			--PSW
										Di_PSW <= R_A;
			when "10110000" => 	load_p3 <= '1';		--P3
										p3_in <= R_A;
			when "10100000" => 	load_p2 <= '1';		--P2
										p2_in <= R_A;
			when "10010000" => 	load_p1 <= '1';		--P1
										p1_in <= R_A;
			when "10000000" => 	load_p0 <= '1';		--P0
										p0_in <= R_A;
--			when "10000001" => 	W_SP <= '1';			--SP
--										Di_PSW <= R_A;
			when "10000010" => 	W_DPH <= '1';			--DPH
										Di_DPH <= R_A;
			when "10000011" => 	W_DPL <= '1';			--DPl
										Di_DPL <= R_A;
			when others 	 =>	if d11(0) = '0' then  
											w_data0 <= R_A; 
											w_addr0 <= d11; 
--											wr_bank0 <= '1';
											case d11 is
												when "00000000" => addr_rid <= "000";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when "00001000" => addr_rid <= "010";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when "00010000" => addr_rid <= "100";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when "00011000" => addr_rid <= "110";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when others => load_rid <= '0';
											end case;
												
											 
										elsif d11(0) = '1' then  
											w_data1 <= R_A; 
											w_addr1 <= d11; 
--											wr_bank1 <= '1'; 
											case d11 is
												when "00000001" => addr_rid <= "001";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when "00001001" => addr_rid <= "011";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when "00010001" => addr_rid <= "101";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when "00011001" => addr_rid <= "111";
																		 din_rid <= R_A;
																		 load_rid <= '1';
												when others => load_rid <= '0';
											end case;

										end if;
		end case;
--	end process;

--	pin2: process(in2)
--	begin
		if d22 /= d11 then 
		case  d22 is
--			when "11100000" =>	W_A <= '1'; 	  		--ACC
--										Di_A <= R_A;
			when "11110000" =>	W_B <= '1';				--B
										Di_B <= R_B;
			when "11010000" => 	W_PSW <= '1';			--PSW
										Di_PSW <= R_B;
			when "10110000" => 	load_p3 <= '1';		--P3
										p3_in <= R_B;
			when "10100000" => 	load_p2 <= '1';		--P2
										p2_in <= R_B;
			when "10010000" => 	load_p1 <= '1';		--P1
										p1_in <= R_B;
			when "10000000" => 	load_p0 <= '1';		--P0
										p0_in <= R_B;
--			when "10000001" => 	W_SP <= '1';			--SP
--										Di_PSW <= R_A;
			when "10000010" => 	W_DPH <= '1';			--DPH
										Di_DPH <= R_B;
			when "10000011" => 	W_DPL <= '1';			--DPl
										Di_DPL <= R_B;
			when others 	 =>	if d22(0) = '0' then  
											w_data0 <= R_B; 
											w_addr0 <= d22; 
--											wr_bank0 <= '1';
											case d22 is
												when "00000000" => addr_rid <= "000";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when "00001000" => addr_rid <= "010";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when "00010000" => addr_rid <= "100";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when "00011000" => addr_rid <= "110";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when others => load_rid <= '0';
											end case;
												
											 
										elsif d22(0) = '1' then  
											w_data1 <= R_B; 
											w_addr1 <= d22; 
--											wr_bank1 <= '1'; 
											case d22 is
												when "00000001" => addr_rid <= "001";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when "00001001" => addr_rid <= "011";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when "00010001" => addr_rid <= "101";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when "00011001" => addr_rid <= "111";
																		 din_rid <= R_B;
																		 load_rid <= '1';
												when others => load_rid <= '0';
											end case;
										end if;
		end case;
		end if;
	end process;
end Structural;