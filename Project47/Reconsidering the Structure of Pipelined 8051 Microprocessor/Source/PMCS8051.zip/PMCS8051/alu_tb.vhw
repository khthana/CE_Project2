--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 7.1.01i
--  \   \         Application : ISE WebPACK
--  /   /         Filename : alu_tb.vhw
-- /___/   /\     Timestamp : Wed Apr 06 04:27:54 2005
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: alu_tb
--Device: Xilinx
--

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_ARITH.all;
use IEEE.std_logic_unsigned.all;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY alu_tb IS
END alu_tb;

ARCHITECTURE testbench_arch OF alu_tb IS
    FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";

    COMPONENT alu
        PORT (
            rst : In std_logic;
            op_code : In std_logic_vector (4 DownTo 0);
            src_1 : In std_logic_vector (7 DownTo 0);
            src_2 : In std_logic_vector (7 DownTo 0);
            src_cy : In std_logic;
            src_ac : In std_logic;
            des_1 : Out std_logic_vector (7 DownTo 0);
            des_2 : Out std_logic_vector (7 DownTo 0);
            des_cy : Out std_logic;
            des_ac : Out std_logic;
            des_ov : Out std_logic
        );
    END COMPONENT;

    SIGNAL rst : std_logic := '1';
    SIGNAL op_code : std_logic_vector (4 DownTo 0) := "00101";
    SIGNAL src_1 : std_logic_vector (7 DownTo 0) := "00000110";
    SIGNAL src_2 : std_logic_vector (7 DownTo 0) := "00000100";
    SIGNAL src_cy : std_logic := '1';
    SIGNAL src_ac : std_logic := '0';
    SIGNAL des_1 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL des_2 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL des_cy : std_logic := '0';
    SIGNAL des_ac : std_logic := '0';
    SIGNAL des_ov : std_logic := '1';

    SHARED VARIABLE TX_ERROR : INTEGER := 0;
    SHARED VARIABLE TX_OUT : LINE;

    BEGIN
        UUT : alu
        PORT MAP (
            rst => rst,
            op_code => op_code,
            src_1 => src_1,
            src_2 => src_2,
            src_cy => src_cy,
            src_ac => src_ac,
            des_1 => des_1,
            des_2 => des_2,
            des_cy => des_cy,
            des_ac => des_ac,
            des_ov => des_ov
        );

        PROCESS
            PROCEDURE CHECK_des_1(
                next_des_1 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (des_1 /= next_des_1) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns des_1="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, des_1);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_des_1);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_des_2(
                next_des_2 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (des_2 /= next_des_2) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns des_2="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, des_2);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_des_2);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_des_ac(
                next_des_ac : std_logic;
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (des_ac /= next_des_ac) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns des_ac="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, des_ac);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_des_ac);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_des_cy(
                next_des_cy : std_logic;
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (des_cy /= next_des_cy) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns des_cy="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, des_cy);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_des_cy);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_des_ov(
                next_des_ov : std_logic;
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (des_ov /= next_des_ov) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns des_ov="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, des_ov);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_des_ov);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            BEGIN
                -- -------------  Current Time:  10ns
                WAIT FOR 10 ns;
                op_code <= "11000";
                src_1 <= "00001100";
                src_2 <= "11010100";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 10);
                CHECK_des_ac('1', 10);
                CHECK_des_ov('0', 10);
                -- -------------------------------------
                -- -------------  Current Time:  20ns
                WAIT FOR 10 ns;
                rst <= '0';
                op_code <= "00101";
                src_1 <= "00001100";
                src_2 <= "10000110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 20);
                -- -------------------------------------
                -- -------------  Current Time:  30ns
                WAIT FOR 10 ns;
                op_code <= "11000";
                src_1 <= "01111000";
                src_2 <= "10111010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 30);
                CHECK_des_ac('1', 30);
                -- -------------------------------------
                -- -------------  Current Time:  40ns
                WAIT FOR 10 ns;
                op_code <= "00101";
                src_1 <= "11000000";
                src_2 <= "10010000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 40);
                CHECK_des_ac('0', 40);
                CHECK_des_ov('0', 40);
                -- -------------------------------------
                -- -------------  Current Time:  50ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "01101010";
                src_2 <= "10101110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 50);
                CHECK_des_ac('1', 50);
                CHECK_des_ov('1', 50);
                -- -------------------------------------
                -- -------------  Current Time:  60ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "00110110";
                src_2 <= "00110100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 60);
                CHECK_des_ac('0', 60);
                CHECK_des_ov('1', 60);
                -- -------------------------------------
                -- -------------  Current Time:  70ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "10110000";
                src_2 <= "11000100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 70);
                CHECK_des_ac('0', 70);
                CHECK_des_ov('0', 70);
                -- -------------------------------------
                -- -------------  Current Time:  80ns
                WAIT FOR 10 ns;
                op_code <= "11100";
                src_1 <= "01010100";
                src_2 <= "10000000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 80);
                CHECK_des_ac('0', 80);
                CHECK_des_ov('0', 80);
                -- -------------------------------------
                -- -------------  Current Time:  90ns
                WAIT FOR 10 ns;
                src_1 <= "00011010";
                src_2 <= "00001010";
                CHECK_des_cy('0', 90);
                CHECK_des_ac('1', 90);
                CHECK_des_ov('1', 90);
                -- -------------------------------------
                -- -------------  Current Time:  100ns
                WAIT FOR 10 ns;
                op_code <= "10010";
                src_1 <= "01111110";
                src_2 <= "10000100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 100);
                CHECK_des_ac('1', 100);
                CHECK_des_ov('1', 100);
                -- -------------------------------------
                -- -------------  Current Time:  110ns
                WAIT FOR 10 ns;
                op_code <= "01000";
                src_1 <= "01111000";
                src_2 <= "10010010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 110);
                CHECK_des_ac('1', 110);
                CHECK_des_ov('0', 110);
                -- -------------------------------------
                -- -------------  Current Time:  120ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "10000100";
                src_2 <= "01010010";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 120);
                CHECK_des_ac('0', 120);
                CHECK_des_ov('0', 120);
                -- -------------------------------------
                -- -------------  Current Time:  130ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "10011010";
                src_2 <= "01101000";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 130);
                CHECK_des_ac('1', 130);
                CHECK_des_ov('1', 130);
                -- -------------------------------------
                -- -------------  Current Time:  140ns
                WAIT FOR 10 ns;
                op_code <= "10100";
                src_1 <= "00110110";
                src_2 <= "11111000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 140);
                CHECK_des_ac('0', 140);
                CHECK_des_ov('1', 140);
                -- -------------------------------------
                -- -------------  Current Time:  150ns
                WAIT FOR 10 ns;
                op_code <= "10010";
                src_1 <= "01010010";
                src_2 <= "10100000";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 150);
                CHECK_des_ac('0', 150);
                CHECK_des_ov('1', 150);
                -- -------------------------------------
                -- -------------  Current Time:  160ns
                WAIT FOR 10 ns;
                op_code <= "00010";
                src_1 <= "01100110";
                src_2 <= "10000110";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 160);
                CHECK_des_ac('0', 160);
                CHECK_des_ov('1', 160);
                -- -------------------------------------
                -- -------------  Current Time:  170ns
                WAIT FOR 10 ns;
                op_code <= "10000";
                src_1 <= "01101100";
                src_2 <= "01001010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 170);
                CHECK_des_ac('1', 170);
                CHECK_des_ov('0', 170);
                -- -------------------------------------
                -- -------------  Current Time:  180ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "11100000";
                src_2 <= "00001110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 180);
                CHECK_des_ac('0', 180);
                CHECK_des_ov('0', 180);
                -- -------------------------------------
                -- -------------  Current Time:  190ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "10111010";
                src_2 <= "01110010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 190);
                CHECK_des_ac('1', 190);
                CHECK_des_ov('1', 190);
                -- -------------------------------------
                -- -------------  Current Time:  200ns
                WAIT FOR 10 ns;
                src_1 <= "01110110";
                src_2 <= "10011100";
                CHECK_des_cy('1', 200);
                CHECK_des_ac('0', 200);
                CHECK_des_ov('1', 200);
                -- -------------------------------------
                -- -------------  Current Time:  210ns
                WAIT FOR 10 ns;
                op_code <= "01110";
                src_1 <= "00001110";
                src_2 <= "00101110";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 210);
                CHECK_des_ac('1', 210);
                CHECK_des_ov('1', 210);
                -- -------------------------------------
                -- -------------  Current Time:  220ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "11111010";
                src_2 <= "01000110";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 220);
                CHECK_des_ac('1', 220);
                CHECK_des_ov('1', 220);
                -- -------------------------------------
                -- -------------  Current Time:  230ns
                WAIT FOR 10 ns;
                op_code <= "01100";
                src_1 <= "00110100";
                src_2 <= "10001000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 230);
                CHECK_des_ac('0', 230);
                CHECK_des_ov('0', 230);
                -- -------------------------------------
                -- -------------  Current Time:  240ns
                WAIT FOR 10 ns;
                op_code <= "11100";
                src_1 <= "00111000";
                src_2 <= "00010110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 240);
                CHECK_des_ac('1', 240);
                CHECK_des_ov('0', 240);
                -- -------------------------------------
                -- -------------  Current Time:  250ns
                WAIT FOR 10 ns;
                rst <= '1';
                op_code <= "11000";
                src_1 <= "00000000";
                src_2 <= "10010010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 250);
                CHECK_des_ac('0', 250);
                CHECK_des_ov('0', 250);
                -- -------------------------------------
                -- -------------  Current Time:  260ns
                WAIT FOR 10 ns;
                rst <= '0';
                op_code <= "01010";
                src_1 <= "00000100";
                src_2 <= "00100000";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 260);
                CHECK_des_ac('0', 260);
                CHECK_des_ov('0', 260);
                -- -------------------------------------
                -- -------------  Current Time:  270ns
                WAIT FOR 10 ns;
                op_code <= "11100";
                src_1 <= "00111110";
                src_2 <= "01011110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 270);
                CHECK_des_ac('1', 270);
                CHECK_des_ov('1', 270);
                -- -------------------------------------
                -- -------------  Current Time:  280ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "00101010";
                src_2 <= "01110010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 280);
                CHECK_des_ac('1', 280);
                CHECK_des_ov('1', 280);
                -- -------------------------------------
                -- -------------  Current Time:  290ns
                WAIT FOR 10 ns;
                op_code <= "01110";
                src_1 <= "11000010";
                src_2 <= "11111100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 290);
                CHECK_des_ac('0', 290);
                CHECK_des_ov('1', 290);
                -- -------------------------------------
                -- -------------  Current Time:  300ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "01111110";
                src_2 <= "00011100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 300);
                CHECK_des_ac('1', 300);
                CHECK_des_ov('1', 300);
                -- -------------------------------------
                -- -------------  Current Time:  310ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "01011000";
                src_2 <= "01111000";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 310);
                CHECK_des_ac('1', 310);
                CHECK_des_ov('0', 310);
                -- -------------------------------------
                -- -------------  Current Time:  320ns
                WAIT FOR 10 ns;
                op_code <= "00110";
                src_1 <= "11001100";
                src_2 <= "00110000";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 320);
                CHECK_des_ac('1', 320);
                CHECK_des_ov('0', 320);
                -- -------------------------------------
                -- -------------  Current Time:  330ns
                WAIT FOR 10 ns;
                op_code <= "10000";
                src_1 <= "11010100";
                src_2 <= "11100110";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 330);
                CHECK_des_ac('0', 330);
                CHECK_des_ov('0', 330);
                -- -------------------------------------
                -- -------------  Current Time:  340ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "11101000";
                src_2 <= "10111100";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 340);
                CHECK_des_ac('1', 340);
                CHECK_des_ov('0', 340);
                -- -------------------------------------
                -- -------------  Current Time:  350ns
                WAIT FOR 10 ns;
                op_code <= "00010";
                src_1 <= "00000100";
                src_2 <= "01010100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 350);
                CHECK_des_ac('0', 350);
                CHECK_des_ov('0', 350);
                -- -------------------------------------
                -- -------------  Current Time:  360ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "10100000";
                src_2 <= "11010010";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 360);
                CHECK_des_ac('0', 360);
                CHECK_des_ov('0', 360);
                -- -------------------------------------
                -- -------------  Current Time:  370ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "10111000";
                src_2 <= "11010100";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 370);
                CHECK_des_ac('1', 370);
                CHECK_des_ov('0', 370);
                -- -------------------------------------
                -- -------------  Current Time:  380ns
                WAIT FOR 10 ns;
                op_code <= "01110";
                src_1 <= "11000100";
                src_2 <= "01111110";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 380);
                CHECK_des_ac('0', 380);
                CHECK_des_ov('0', 380);
                -- -------------------------------------
                -- -------------  Current Time:  390ns
                WAIT FOR 10 ns;
                op_code <= "11000";
                src_1 <= "11000000";
                src_2 <= "01110100";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 390);
                CHECK_des_ac('0', 390);
                CHECK_des_ov('0', 390);
                -- -------------------------------------
                -- -------------  Current Time:  400ns
                WAIT FOR 10 ns;
                op_code <= "00010";
                src_1 <= "00100100";
                src_2 <= "11010100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 400);
                CHECK_des_ac('0', 400);
                CHECK_des_ov('0', 400);
                -- -------------------------------------
                -- -------------  Current Time:  410ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "11101100";
                src_2 <= "01000100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 410);
                CHECK_des_ac('1', 410);
                CHECK_des_ov('0', 410);
                -- -------------------------------------
                -- -------------  Current Time:  420ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "10010000";
                src_2 <= "11100100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 420);
                CHECK_des_ac('0', 420);
                CHECK_des_ov('0', 420);
                -- -------------------------------------
                -- -------------  Current Time:  430ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "00001100";
                src_2 <= "01010100";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 430);
                CHECK_des_ac('1', 430);
                CHECK_des_ov('0', 430);
                -- -------------------------------------
                -- -------------  Current Time:  440ns
                WAIT FOR 10 ns;
                op_code <= "10100";
                src_1 <= "11011000";
                src_2 <= "10111010";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 440);
                CHECK_des_ac('1', 440);
                CHECK_des_ov('0', 440);
                -- -------------------------------------
                -- -------------  Current Time:  450ns
                WAIT FOR 10 ns;
                op_code <= "00010";
                src_1 <= "11110000";
                src_2 <= "10110110";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 450);
                CHECK_des_ac('0', 450);
                CHECK_des_ov('0', 450);
                -- -------------------------------------
                -- -------------  Current Time:  460ns
                WAIT FOR 10 ns;
                op_code <= "10000";
                src_1 <= "11001100";
                src_2 <= "01101010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 460);
                CHECK_des_ac('1', 460);
                CHECK_des_ov('0', 460);
                -- -------------------------------------
                -- -------------  Current Time:  470ns
                WAIT FOR 10 ns;
                op_code <= "01000";
                src_1 <= "01101000";
                src_2 <= "01111000";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 470);
                CHECK_des_ac('1', 470);
                CHECK_des_ov('0', 470);
                -- -------------------------------------
                -- -------------  Current Time:  480ns
                WAIT FOR 10 ns;
                op_code <= "10010";
                src_1 <= "00111100";
                src_2 <= "00000010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 480);
                CHECK_des_ac('1', 480);
                CHECK_des_ov('0', 480);
                -- -------------------------------------
                -- -------------  Current Time:  490ns
                WAIT FOR 10 ns;
                op_code <= "11000";
                src_1 <= "01000100";
                src_2 <= "10101100";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 490);
                CHECK_des_ac('0', 490);
                CHECK_des_ov('0', 490);
                -- -------------------------------------
                -- -------------  Current Time:  500ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "11111010";
                src_2 <= "10010100";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 500);
                CHECK_des_ac('1', 500);
                CHECK_des_ov('1', 500);
                -- -------------------------------------
                -- -------------  Current Time:  510ns
                WAIT FOR 10 ns;
                rst <= '1';
                op_code <= "00010";
                src_1 <= "01010110";
                src_2 <= "01011110";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 510);
                CHECK_des_ac('0', 510);
                CHECK_des_ov('1', 510);
                -- -------------------------------------
                -- -------------  Current Time:  520ns
                WAIT FOR 10 ns;
                rst <= '0';
                op_code <= "11100";
                src_1 <= "11010010";
                src_2 <= "00101110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 520);
                CHECK_des_ac('0', 520);
                CHECK_des_ov('1', 520);
                -- -------------------------------------
                -- -------------  Current Time:  530ns
                WAIT FOR 10 ns;
                op_code <= "11000";
                src_1 <= "01101010";
                src_2 <= "10100010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 530);
                CHECK_des_ac('1', 530);
                CHECK_des_ov('1', 530);
                -- -------------------------------------
                -- -------------  Current Time:  540ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "10010110";
                src_2 <= "11100000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 540);
                CHECK_des_ac('0', 540);
                CHECK_des_ov('1', 540);
                -- -------------------------------------
                -- -------------  Current Time:  550ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "01010010";
                src_2 <= "10001000";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 550);
                CHECK_des_ac('0', 550);
                CHECK_des_ov('1', 550);
                -- -------------------------------------
                -- -------------  Current Time:  560ns
                WAIT FOR 10 ns;
                op_code <= "10010";
                src_1 <= "00011000";
                src_2 <= "10111010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 560);
                CHECK_des_ac('1', 560);
                CHECK_des_ov('0', 560);
                -- -------------------------------------
                -- -------------  Current Time:  570ns
                WAIT FOR 10 ns;
                op_code <= "00110";
                src_1 <= "11100000";
                src_2 <= "00011100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 570);
                CHECK_des_ac('0', 570);
                CHECK_des_ov('0', 570);
                -- -------------------------------------
                -- -------------  Current Time:  580ns
                WAIT FOR 10 ns;
                op_code <= "10010";
                src_1 <= "00100100";
                src_2 <= "11001110";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 580);
                CHECK_des_ac('0', 580);
                CHECK_des_ov('0', 580);
                -- -------------------------------------
                -- -------------  Current Time:  590ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "11100000";
                src_2 <= "01110010";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 590);
                CHECK_des_ac('0', 590);
                CHECK_des_ov('0', 590);
                -- -------------------------------------
                -- -------------  Current Time:  600ns
                WAIT FOR 10 ns;
                op_code <= "10100";
                src_1 <= "10001110";
                src_2 <= "00101010";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 600);
                CHECK_des_ac('1', 600);
                CHECK_des_ov('1', 600);
                -- -------------------------------------
                -- -------------  Current Time:  610ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "00100110";
                src_2 <= "10011010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 610);
                CHECK_des_ac('0', 610);
                CHECK_des_ov('1', 610);
                -- -------------------------------------
                -- -------------  Current Time:  620ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "00100100";
                src_2 <= "11100000";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 620);
                CHECK_des_ac('0', 620);
                CHECK_des_ov('0', 620);
                -- -------------------------------------
                -- -------------  Current Time:  630ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "10000000";
                src_2 <= "10100000";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 630);
                CHECK_des_ac('0', 630);
                CHECK_des_ov('0', 630);
                -- -------------------------------------
                -- -------------  Current Time:  640ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "10110100";
                src_2 <= "11111110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 640);
                CHECK_des_ac('0', 640);
                CHECK_des_ov('0', 640);
                -- -------------------------------------
                -- -------------  Current Time:  650ns
                WAIT FOR 10 ns;
                op_code <= "01000";
                src_1 <= "10111110";
                src_2 <= "10011000";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 650);
                CHECK_des_ac('1', 650);
                CHECK_des_ov('1', 650);
                -- -------------------------------------
                -- -------------  Current Time:  660ns
                WAIT FOR 10 ns;
                op_code <= "10000";
                src_1 <= "00010010";
                src_2 <= "10010100";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 660);
                CHECK_des_ac('0', 660);
                CHECK_des_ov('1', 660);
                -- -------------------------------------
                -- -------------  Current Time:  670ns
                WAIT FOR 10 ns;
                op_code <= "01100";
                src_1 <= "10101110";
                src_2 <= "10010000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 670);
                CHECK_des_ac('1', 670);
                CHECK_des_ov('1', 670);
                -- -------------------------------------
                -- -------------  Current Time:  680ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "00001100";
                src_2 <= "10110010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 680);
                CHECK_des_ac('1', 680);
                CHECK_des_ov('0', 680);
                -- -------------------------------------
                -- -------------  Current Time:  690ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "00100100";
                src_2 <= "10011010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 690);
                CHECK_des_ac('0', 690);
                CHECK_des_ov('0', 690);
                -- -------------------------------------
                -- -------------  Current Time:  700ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "01110010";
                src_2 <= "01101010";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 700);
                CHECK_des_ac('0', 700);
                CHECK_des_ov('1', 700);
                -- -------------------------------------
                -- -------------  Current Time:  710ns
                WAIT FOR 10 ns;
                src_1 <= "11101110";
                src_2 <= "11000100";
                CHECK_des_cy('1', 710);
                CHECK_des_ac('1', 710);
                CHECK_des_ov('1', 710);
                -- -------------------------------------
                -- -------------  Current Time:  720ns
                WAIT FOR 10 ns;
                op_code <= "01000";
                src_1 <= "00010100";
                src_2 <= "11001010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 720);
                CHECK_des_ac('0', 720);
                CHECK_des_ov('0', 720);
                -- -------------------------------------
                -- -------------  Current Time:  730ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "11011100";
                src_2 <= "00011110";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 730);
                CHECK_des_ac('1', 730);
                CHECK_des_ov('0', 730);
                -- -------------------------------------
                -- -------------  Current Time:  740ns
                WAIT FOR 10 ns;
                op_code <= "00010";
                src_1 <= "11000010";
                src_2 <= "11100010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 740);
                CHECK_des_ac('0', 740);
                CHECK_des_ov('1', 740);
                -- -------------------------------------
                -- -------------  Current Time:  750ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "10111110";
                src_2 <= "10111000";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 750);
                CHECK_des_ac('1', 750);
                CHECK_des_ov('1', 750);
                -- -------------------------------------
                -- -------------  Current Time:  760ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "01001100";
                src_2 <= "11000100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 760);
                CHECK_des_ac('1', 760);
                CHECK_des_ov('0', 760);
                -- -------------------------------------
                -- -------------  Current Time:  770ns
                WAIT FOR 10 ns;
                rst <= '1';
                op_code <= "00110";
                src_1 <= "01100100";
                src_2 <= "10100100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 770);
                CHECK_des_ac('0', 770);
                CHECK_des_ov('0', 770);
                -- -------------------------------------
                -- -------------  Current Time:  780ns
                WAIT FOR 10 ns;
                rst <= '0';
                op_code <= "01110";
                src_1 <= "10000010";
                src_2 <= "01111100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 780);
                CHECK_des_ac('0', 780);
                CHECK_des_ov('1', 780);
                -- -------------------------------------
                -- -------------  Current Time:  790ns
                WAIT FOR 10 ns;
                op_code <= "11100";
                src_1 <= "10011110";
                src_2 <= "11110000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 790);
                CHECK_des_ac('1', 790);
                CHECK_des_ov('1', 790);
                -- -------------------------------------
                -- -------------  Current Time:  800ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "00110100";
                src_2 <= "00100000";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 800);
                CHECK_des_ac('0', 800);
                CHECK_des_ov('0', 800);
                -- -------------------------------------
                -- -------------  Current Time:  810ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "00111110";
                src_2 <= "10101100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 810);
                CHECK_des_ac('1', 810);
                CHECK_des_ov('1', 810);
                -- -------------------------------------
                -- -------------  Current Time:  820ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "00110100";
                src_2 <= "10111010";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 820);
                CHECK_des_ac('0', 820);
                CHECK_des_ov('0', 820);
                -- -------------------------------------
                -- -------------  Current Time:  830ns
                WAIT FOR 10 ns;
                op_code <= "11100";
                src_1 <= "00010000";
                src_2 <= "11101010";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 830);
                CHECK_des_ac('0', 830);
                CHECK_des_ov('0', 830);
                -- -------------------------------------
                -- -------------  Current Time:  840ns
                WAIT FOR 10 ns;
                op_code <= "01110";
                src_1 <= "01001110";
                src_2 <= "01011110";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 840);
                CHECK_des_ac('1', 840);
                CHECK_des_ov('1', 840);
                -- -------------------------------------
                -- -------------  Current Time:  850ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "11100110";
                src_2 <= "10111000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 850);
                CHECK_des_ac('0', 850);
                CHECK_des_ov('1', 850);
                -- -------------------------------------
                -- -------------  Current Time:  860ns
                WAIT FOR 10 ns;
                op_code <= "01010";
                src_1 <= "01010100";
                src_2 <= "00011010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('0', 860);
                CHECK_des_ac('0', 860);
                CHECK_des_ov('0', 860);
                -- -------------------------------------
                -- -------------  Current Time:  870ns
                WAIT FOR 10 ns;
                op_code <= "01000";
                src_1 <= "10010010";
                src_2 <= "00100110";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 870);
                CHECK_des_ac('0', 870);
                CHECK_des_ov('1', 870);
                -- -------------------------------------
                -- -------------  Current Time:  880ns
                WAIT FOR 10 ns;
                src_1 <= "00011000";
                src_2 <= "00000000";
                CHECK_des_cy('0', 880);
                CHECK_des_ac('1', 880);
                CHECK_des_ov('0', 880);
                -- -------------------------------------
                -- -------------  Current Time:  890ns
                WAIT FOR 10 ns;
                op_code <= "10110";
                src_1 <= "11100000";
                src_2 <= "01000110";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('1', 890);
                CHECK_des_ac('0', 890);
                CHECK_des_ov('0', 890);
                -- -------------------------------------
                -- -------------  Current Time:  900ns
                WAIT FOR 10 ns;
                op_code <= "11010";
                src_1 <= "01100110";
                src_2 <= "00011110";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 900);
                CHECK_des_ac('0', 900);
                CHECK_des_ov('1', 900);
                -- -------------------------------------
                -- -------------  Current Time:  910ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "10100100";
                src_2 <= "00100110";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 910);
                CHECK_des_ac('0', 910);
                CHECK_des_ov('0', 910);
                -- -------------------------------------
                -- -------------  Current Time:  920ns
                WAIT FOR 10 ns;
                op_code <= "01110";
                src_1 <= "00010010";
                src_2 <= "10000100";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 920);
                CHECK_des_ac('0', 920);
                CHECK_des_ov('1', 920);
                -- -------------------------------------
                -- -------------  Current Time:  930ns
                WAIT FOR 10 ns;
                op_code <= "10100";
                src_1 <= "10101100";
                src_2 <= "11010110";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 930);
                CHECK_des_ac('1', 930);
                CHECK_des_ov('0', 930);
                -- -------------------------------------
                -- -------------  Current Time:  940ns
                WAIT FOR 10 ns;
                op_code <= "11000";
                src_1 <= "11101010";
                src_2 <= "01000010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('1', 940);
                CHECK_des_ac('1', 940);
                CHECK_des_ov('1', 940);
                -- -------------------------------------
                -- -------------  Current Time:  950ns
                WAIT FOR 10 ns;
                op_code <= "00100";
                src_1 <= "11000110";
                src_2 <= "01101000";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('0', 950);
                CHECK_des_ac('0', 950);
                CHECK_des_ov('1', 950);
                -- -------------------------------------
                -- -------------  Current Time:  960ns
                WAIT FOR 10 ns;
                op_code <= "00010";
                src_1 <= "10111100";
                src_2 <= "01101010";
                src_cy <= '0';
                src_ac <= '1';
                CHECK_des_cy('1', 960);
                CHECK_des_ac('1', 960);
                CHECK_des_ov('0', 960);
                -- -------------------------------------
                -- -------------  Current Time:  970ns
                WAIT FOR 10 ns;
                op_code <= "11110";
                src_1 <= "11000110";
                src_2 <= "11101010";
                src_cy <= '1';
                src_ac <= '1';
                CHECK_des_cy('0', 970);
                CHECK_des_ac('0', 970);
                CHECK_des_ov('1', 970);
                -- -------------------------------------
                -- -------------  Current Time:  980ns
                WAIT FOR 10 ns;
                op_code <= "00000";
                src_1 <= "01011100";
                src_2 <= "00001010";
                src_cy <= '0';
                src_ac <= '0';
                CHECK_des_cy('0', 980);
                CHECK_des_ac('1', 980);
                CHECK_des_ov('0', 980);
                -- -------------------------------------
                -- -------------  Current Time:  990ns
                WAIT FOR 10 ns;
                op_code <= "10100";
                src_1 <= "01111010";
                src_2 <= "01101100";
                src_cy <= '1';
                src_ac <= '0';
                CHECK_des_cy('1', 990);
                CHECK_des_ac('1', 990);
                CHECK_des_ov('1', 990);
                -- -------------------------------------
                -- -------------  Current Time:  1030ns
                WAIT FOR 40 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1040ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1290ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1300ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1550ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1560ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1810ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1820ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2070ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2080ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2330ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2340ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2590ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2600ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2850ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2860ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  3110ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  3120ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  3370ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  3380ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  3630ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  3640ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  3890ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  3900ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  4150ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  4160ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  4410ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  4420ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  4670ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  4680ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  4930ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  4940ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  5190ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  5200ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  5450ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  5460ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  5710ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  5720ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  5970ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  5980ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  6230ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  6240ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  6490ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  6500ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  6750ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  6760ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  7010ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  7020ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  7270ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  7280ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  7530ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  7540ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  7790ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  7800ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  8050ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  8060ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  8310ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  8320ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  8570ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  8580ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  8830ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  8840ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  9090ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  9100ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  9350ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  9360ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  9610ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  9620ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  9870ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  9880ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  10130ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  10140ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  10390ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  10400ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  10650ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  10660ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  10910ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  10920ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  11170ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  11180ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  11430ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  11440ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  11690ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  11700ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  11950ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  11960ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  12210ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  12220ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  12470ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  12480ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  12730ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  12740ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  12990ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  13000ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  13250ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  13260ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  13510ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  13520ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  13770ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  13780ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  14030ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  14040ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  14290ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  14300ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  14550ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  14560ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  14810ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  14820ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  15070ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  15080ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  15330ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  15340ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  15590ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  15600ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  15850ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  15860ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  16110ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  16120ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  16370ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  16380ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  16630ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  16640ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  16890ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  16900ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  17150ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  17160ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  17410ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  17420ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  17670ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  17680ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  17930ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  17940ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  18190ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  18200ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  18450ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  18460ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  18710ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  18720ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  18970ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  18980ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  19230ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  19240ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  19490ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  19500ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  19750ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  19760ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  20010ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  20020ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  20270ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  20280ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  20530ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  20540ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  20790ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  20800ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  21050ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  21060ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  21310ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  21320ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  21570ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  21580ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  21830ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  21840ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  22090ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  22100ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  22350ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  22360ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  22610ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  22620ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  22870ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  22880ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  23130ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  23140ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  23390ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  23400ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  23650ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  23660ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  23910ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  23920ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  24170ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  24180ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  24430ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  24440ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  24690ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  24700ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  24950ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  24960ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  25210ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  25220ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  25470ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  25480ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  25730ns
                WAIT FOR 250 ns;
                rst <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  25740ns
                WAIT FOR 10 ns;
                rst <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  25990ns
                WAIT FOR 250 ns;
                rst <= '1';

                IF (TX_ERROR = 0) THEN
                    STD.TEXTIO.write(TX_OUT, string'("No errors or warnings"));
                    STD.TEXTIO.writeline(RESULTS, TX_OUT);
                    ASSERT (FALSE) REPORT
                      "Simulation successful (not a failure).  No problems detected."
                      SEVERITY FAILURE;
                ELSE
                    STD.TEXTIO.write(TX_OUT, TX_ERROR);
                    STD.TEXTIO.write(TX_OUT,
                        string'(" errors found in simulation"));
                    STD.TEXTIO.writeline(RESULTS, TX_OUT);
                    ASSERT (FALSE) REPORT "Errors found during simulation"
                         SEVERITY FAILURE;
                END IF;
            END PROCESS;

    END testbench_arch;

