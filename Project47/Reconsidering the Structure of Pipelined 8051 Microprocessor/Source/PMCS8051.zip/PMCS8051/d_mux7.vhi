
-- VHDL Instantiation Created from source file d_mux7.vhd -- 06:10:56 12/30/2004
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT d_mux7
	PORT(
		in1 : IN std_logic_vector(7 downto 0);
		in2 : IN std_logic_vector(7 downto 0);
		in3 : IN std_logic_vector(7 downto 0);
		in4 : IN std_logic_vector(7 downto 0);
		in5 : IN std_logic_vector(7 downto 0);
		sel : IN std_logic_vector(2 downto 0);          
		out1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_d_mux7: d_mux7 PORT MAP(
		in1 => ,
		in2 => ,
		in3 => ,
		in4 => ,
		in5 => ,
		sel => ,
		out1 => 
	);


