library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rid is
	port(	data_in  	:in		std_logic_vector(7 downto 0);
			addr_in		:in   	std_logic_vector(2 downto 0);
			data_out1	:out   	std_logic_vector(7 downto 0);
			data_out2	:out   	std_logic_vector(7 downto 0);
			RS_in			:in		std_logic_vector(1 downto 0);
			load_in		:in		std_logic;
			rst			:in		std_logic;
			clk			:in		std_logic
			);
end rid;

architecture rtl of rid is
     type Clash is array(0 to 7) of std_logic_vector(7 downto 0);
     signal R0R1 : Clash ;

begin
    process(clk, rst, RS_in) 
	  variable temp0: std_logic_vector(2 downto 0);
	  variable temp1: std_logic_vector(2 downto 0);
    begin                        
	  	  temp0(2 downto 0) := RS_in(1 downto 0) & '0';      
	  	  temp1(2 downto 0) := RS_in(1 downto 0) & '1';
        if( clk'event and clk = '1') then              
           if( load_in = '1' ) then        
             R0R1(conv_integer(addr_in)) <= data_in;    
           end if;       
        end if;            
			 	 data_out1 <= R0R1(conv_integer(temp0));          
        	 	 data_out2 <= R0R1(conv_integer(temp1)); 
      end process;                       

end rtl;
