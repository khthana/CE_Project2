--------------------------------------------------------------------------------
-- Copyright (c) 1995-2005 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____
--  /   /\/   /
-- /___/  \  /    Vendor: Xilinx
-- \   \   \/     Version: H.39
--  \   \         Application: netgen
--  /   /         Filename: datapath_translate.vhd
-- /___/   /\     Timestamp: Thu Apr 07 06:01:00 2005
-- \   \  /  \ 
--  \___\/\___\
--             
-- Command	: -intstyle ise -rpw 100 -tpw 0 -ar Structure -xon true -w -ofmt vhdl -sim datapath.ngd datapath_translate.vhd 
-- Device	: 3s200tq144-4
-- Input file	: datapath.ngd
-- Output file	: datapath_translate.vhd
-- # of Entities	: 1
-- Design Name	: datapath
-- Xilinx	: C:/Xilinx
--             
-- Purpose:    
--     This VHDL netlist is a verification model and uses simulation 
--     primitives which may not represent the true implementation of the 
--     device, however the netlist is functionally correct and should not 
--     be modified. This file cannot be synthesized and should only be used 
--     with supported simulation tools.
--             
-- Reference:  
--     Development System Reference Guide, Chapter 23
--     Synthesis and Verification Design Guide, Chapter 6
--             
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library SIMPRIM;
use SIMPRIM.VCOMPONENTS.ALL;
use SIMPRIM.VPACKAGE.ALL;

entity datapath is
  port (
    Reset : in STD_LOGIC := 'X'; 
    rd : in STD_LOGIC := 'X'; 
    Clock : in STD_LOGIC := 'X'; 
    wr : in STD_LOGIC := 'X'; 
    int0 : in STD_LOGIC := 'X'; 
    int1 : in STD_LOGIC := 'X'; 
    port1_in : in STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port3_in : in STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port0_in : in STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port2_in : in STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port0_out : out STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port1_out : out STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port2_out : out STD_LOGIC_VECTOR ( 7 downto 0 ); 
    port3_out : out STD_LOGIC_VECTOR ( 7 downto 0 ) 
  );
end datapath;

architecture Structure of datapath is
  signal Reset_IBUF : STD_LOGIC; 
  signal Clock_BUFGP : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_7_cyo : STD_LOGIC; 
  signal W_A_from_writeback : STD_LOGIC; 
  signal cu_N0 : STD_LOGIC; 
  signal load_p2_from_writeback : STD_LOGIC; 
  signal CHOICE12765 : STD_LOGIC; 
  signal cu_N71 : STD_LOGIC; 
  signal port1_in_1_IBUF : STD_LOGIC; 
  signal port3_in_2_IBUF : STD_LOGIC; 
  signal port3_in_5_IBUF : STD_LOGIC; 
  signal CHOICE12600 : STD_LOGIC; 
  signal cu_PC_load_in : STD_LOGIC; 
  signal cu_N37 : STD_LOGIC; 
  signal W_DPL_from_writeback : STD_LOGIC; 
  signal cu_N12 : STD_LOGIC; 
  signal port3_in_7_IBUF : STD_LOGIC; 
  signal port2_in_7_IBUF : STD_LOGIC; 
  signal CHOICE11904 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_3_cyo : STD_LOGIC; 
  signal cu_n0329 : STD_LOGIC; 
  signal load_p3_from_writeback : STD_LOGIC; 
  signal cu_N59 : STD_LOGIC; 
  signal port0_in_0_IBUF : STD_LOGIC; 
  signal load_rid_from_writeback : STD_LOGIC; 
  signal N45 : STD_LOGIC; 
  signal W_DPH_from_writeback : STD_LOGIC; 
  signal cu_N65 : STD_LOGIC; 
  signal port3_in_4_IBUF : STD_LOGIC; 
  signal load_p0_from_writeback : STD_LOGIC; 
  signal port1_in_7_IBUF : STD_LOGIC; 
  signal exe_stage_alu_m_N29 : STD_LOGIC; 
  signal di_psw_from_writeback_3_Q : STD_LOGIC; 
  signal cu_n0333 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N77 : STD_LOGIC; 
  signal port3_in_1_IBUF : STD_LOGIC; 
  signal cu_sel_rd : STD_LOGIC; 
  signal CHOICE12299 : STD_LOGIC; 
  signal CHOICE12418 : STD_LOGIC; 
  signal N6219 : STD_LOGIC; 
  signal cu_N3 : STD_LOGIC; 
  signal port0_in_7_IBUF : STD_LOGIC; 
  signal port1_in_0_IBUF : STD_LOGIC; 
  signal W_psw_from_writeback : STD_LOGIC; 
  signal cu_n0076 : STD_LOGIC; 
  signal rom_Mrom_n0002_N20 : STD_LOGIC; 
  signal port2_in_1_IBUF : STD_LOGIC; 
  signal load_p1_from_writeback : STD_LOGIC; 
  signal W_B_from_writeback : STD_LOGIC; 
  signal port0_in_6_IBUF : STD_LOGIC; 
  signal port1_in_2_IBUF : STD_LOGIC; 
  signal port2_in_0_IBUF : STD_LOGIC; 
  signal cu_n0137 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_1_cyo : STD_LOGIC; 
  signal port1_in_3_IBUF : STD_LOGIC; 
  signal port1_in_4_IBUF : STD_LOGIC; 
  signal port0_in_1_IBUF : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net335 : STD_LOGIC; 
  signal port2_in_3_IBUF : STD_LOGIC; 
  signal port1_in_5_IBUF : STD_LOGIC; 
  signal port3_in_0_IBUF : STD_LOGIC; 
  signal port2_in_2_IBUF : STD_LOGIC; 
  signal port2_in_6_IBUF : STD_LOGIC; 
  signal port1_in_6_IBUF : STD_LOGIC; 
  signal port0_in_2_IBUF : STD_LOGIC; 
  signal port3_in_6_IBUF : STD_LOGIC; 
  signal port2_in_4_IBUF : STD_LOGIC; 
  signal port0_in_3_IBUF : STD_LOGIC; 
  signal port0_in_5_IBUF : STD_LOGIC; 
  signal port2_in_5_IBUF : STD_LOGIC; 
  signal cu_N63 : STD_LOGIC; 
  signal port0_in_4_IBUF : STD_LOGIC; 
  signal cu_N69 : STD_LOGIC; 
  signal cu_N62 : STD_LOGIC; 
  signal cu_N46 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N38 : STD_LOGIC; 
  signal exe_stage_alu_m_N39 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_6_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N36 : STD_LOGIC; 
  signal exe_stage_alu_m_N37 : STD_LOGIC; 
  signal cu_n0332 : STD_LOGIC; 
  signal port3_in_3_IBUF : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N79 : STD_LOGIC; 
  signal di_psw_from_writeback_4_Q : STD_LOGIC; 
  signal di_psw_from_writeback_5_Q : STD_LOGIC; 
  signal CHOICE12006 : STD_LOGIC; 
  signal di_psw_from_writeback_1_Q : STD_LOGIC; 
  signal CHOICE12248 : STD_LOGIC; 
  signal cu_N33 : STD_LOGIC; 
  signal CHOICE12790 : STD_LOGIC; 
  signal exe_stage_alu_m_N34 : STD_LOGIC; 
  signal cu_N21 : STD_LOGIC; 
  signal cu_n0328 : STD_LOGIC; 
  signal cu_n0335 : STD_LOGIC; 
  signal N6335 : STD_LOGIC; 
  signal cu_N45 : STD_LOGIC; 
  signal wb_stage_N25 : STD_LOGIC; 
  signal rom_Mrom_n0002_N46 : STD_LOGIC; 
  signal wb_stage_N64 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_96 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net333 : STD_LOGIC; 
  signal rom_Mrom_n0002_N3 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_134 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_139 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_123 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N57 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_6_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0000_3_cyo_rt : STD_LOGIC; 
  signal dec_stage_d_mux7_n0000 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_2_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N4 : STD_LOGIC; 
  signal exe_stage_alu_m_N60 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_3_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N81 : STD_LOGIC; 
  signal exe_stage_alu_m_N68 : STD_LOGIC; 
  signal wb_stage_N75 : STD_LOGIC; 
  signal exe_stage_alu_m_N84 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_0_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N89 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_0_cyo : STD_LOGIC; 
  signal rom_Mrom_n0002_N22 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N96 : STD_LOGIC; 
  signal exe_stage_alu_m_N27 : STD_LOGIC; 
  signal exe_stage_alu_m_N19 : STD_LOGIC; 
  signal dec_stage_d_mux7_N12 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_3_cyo : STD_LOGIC; 
  signal rom_Mrom_n0002_N21 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N104 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_4_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N99 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_n0198 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N90 : STD_LOGIC; 
  signal rom_Mrom_n0002_N64 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N97 : STD_LOGIC; 
  signal dec_stage_d_mux7_N13 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_3_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N24 : STD_LOGIC; 
  signal exe_stage_alu_m_N116 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N102 : STD_LOGIC; 
  signal exe_stage_alu_m_N91 : STD_LOGIC; 
  signal exe_stage_alu_m_N22 : STD_LOGIC; 
  signal exe_stage_alu_m_N110 : STD_LOGIC; 
  signal dec_stage_d_mux7_N10 : STD_LOGIC; 
  signal exe_stage_alu_m_N111 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_6_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_n0199 : STD_LOGIC; 
  signal exe_stage_alu_m_N114 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N23 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N95 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0217_3_cyo : STD_LOGIC; 
  signal N6241 : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo2 : STD_LOGIC; 
  signal exe_stage_alu_m_N71 : STD_LOGIC; 
  signal exe_stage_alu_m_N69 : STD_LOGIC; 
  signal exe_stage_alu_m_Eq_stage_cyo1 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N83 : STD_LOGIC; 
  signal N6338 : STD_LOGIC; 
  signal exe_stage_alu_m_N113 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_7_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N88 : STD_LOGIC; 
  signal N6126 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N28 : STD_LOGIC; 
  signal exe_stage_alu_m_N28 : STD_LOGIC; 
  signal exe_stage_alu_m_N112 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_n0197 : STD_LOGIC; 
  signal exe_stage_alu_m_N115 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_6_cyo : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N27 : STD_LOGIC; 
  signal exe_stage_alu_m_N31 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N33 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_6_cyo : STD_LOGIC; 
  signal wb_stage_N70 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N30 : STD_LOGIC; 
  signal exe_stage_alu_m_N32 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N101 : STD_LOGIC; 
  signal N44 : STD_LOGIC; 
  signal Eq_stage_cyo7 : STD_LOGIC; 
  signal N40 : STD_LOGIC; 
  signal Eq_stage_cyo8 : STD_LOGIC; 
  signal N41 : STD_LOGIC; 
  signal N42 : STD_LOGIC; 
  signal Eq_stage_cyo9 : STD_LOGIC; 
  signal exe_stage_Forwarder_m_n0005 : STD_LOGIC; 
  signal exe_stage_Forwarder_m_n0006 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0064_3_cyo : STD_LOGIC; 
  signal dec_stage_d_mux7_N11 : STD_LOGIC; 
  signal exe_stage_Forwarder_m_n0002 : STD_LOGIC; 
  signal exe_stage_Forwarder_m_n0003 : STD_LOGIC; 
  signal Eq_stage_cyo11 : STD_LOGIC; 
  signal N43 : STD_LOGIC; 
  signal Eq_stage_cyo10 : STD_LOGIC; 
  signal CHOICE12490 : STD_LOGIC; 
  signal CHOICE12133 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N26 : STD_LOGIC; 
  signal exe_stage_alu_m_N25 : STD_LOGIC; 
  signal exe_stage_alu_m_N24 : STD_LOGIC; 
  signal exe_stage_alu_m_N23 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N21 : STD_LOGIC; 
  signal exe_stage_alu_m_N20 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N18 : STD_LOGIC; 
  signal exe_stage_alu_m_N17 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0003_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0003_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0003_3_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N93 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0005_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0005_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0005_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo4 : STD_LOGIC; 
  signal exe_stage_alu_m_N5 : STD_LOGIC; 
  signal N6131 : STD_LOGIC; 
  signal exe_stage_alu_m_N951 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N0 : STD_LOGIC; 
  signal exe_stage_alu_m_N95 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N87 : STD_LOGIC; 
  signal N6127 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_n0144 : STD_LOGIC; 
  signal N6124 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N98 : STD_LOGIC; 
  signal exe_stage_alu_m_N79 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_3_cyo : STD_LOGIC; 
  signal rom_Mrom_n0002_N52 : STD_LOGIC; 
  signal rom_Mrom_n0002_N51 : STD_LOGIC; 
  signal rom_Mrom_n0002_N50 : STD_LOGIC; 
  signal exe_stage_alu_m_N88 : STD_LOGIC; 
  signal rom_Mrom_n0002_N49 : STD_LOGIC; 
  signal exe_stage_alu_m_N92 : STD_LOGIC; 
  signal rom_Mrom_n0002_N48 : STD_LOGIC; 
  signal exe_stage_alu_m_N101 : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo1 : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_0_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_1_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_2_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_3_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_4_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_5_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_6_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_7_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_8_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_9_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_10_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_11_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_12_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_13_cyo : STD_LOGIC; 
  signal datapath_fet_stage_next_PC_14_cyo : STD_LOGIC; 
  signal N30 : STD_LOGIC; 
  signal Eq_stage_cyo : STD_LOGIC; 
  signal N31 : STD_LOGIC; 
  signal Eq_stage_cyo1 : STD_LOGIC; 
  signal N32 : STD_LOGIC; 
  signal Eq_stage_cyo2 : STD_LOGIC; 
  signal N33 : STD_LOGIC; 
  signal N34 : STD_LOGIC; 
  signal Eq_stage_cyo3 : STD_LOGIC; 
  signal N35 : STD_LOGIC; 
  signal Eq_stage_cyo4 : STD_LOGIC; 
  signal N36 : STD_LOGIC; 
  signal Eq_stage_cyo5 : STD_LOGIC; 
  signal N37 : STD_LOGIC; 
  signal N38 : STD_LOGIC; 
  signal Eq_stage_cyo6 : STD_LOGIC; 
  signal N39 : STD_LOGIC; 
  signal N62 : STD_LOGIC; 
  signal N64 : STD_LOGIC; 
  signal N66 : STD_LOGIC; 
  signal N68 : STD_LOGIC; 
  signal N70 : STD_LOGIC; 
  signal N72 : STD_LOGIC; 
  signal N74 : STD_LOGIC; 
  signal N76 : STD_LOGIC; 
  signal N78 : STD_LOGIC; 
  signal N80 : STD_LOGIC; 
  signal N82 : STD_LOGIC; 
  signal N84 : STD_LOGIC; 
  signal N86 : STD_LOGIC; 
  signal N88 : STD_LOGIC; 
  signal N90 : STD_LOGIC; 
  signal N92 : STD_LOGIC; 
  signal CHOICE12474 : STD_LOGIC; 
  signal CHOICE11686 : STD_LOGIC; 
  signal CHOICE12652 : STD_LOGIC; 
  signal CHOICE12114 : STD_LOGIC; 
  signal CHOICE11695 : STD_LOGIC; 
  signal N6293 : STD_LOGIC; 
  signal exe_stage_alu_m_n0000_3_rt : STD_LOGIC; 
  signal CHOICE11709 : STD_LOGIC; 
  signal exe_stage_alu_m_n0000_2_rt : STD_LOGIC; 
  signal CHOICE11992 : STD_LOGIC; 
  signal exe_stage_alu_m_n0000_1_rt : STD_LOGIC; 
  signal CHOICE11708 : STD_LOGIC; 
  signal N5940 : STD_LOGIC; 
  signal CHOICE12556 : STD_LOGIC; 
  signal N5941 : STD_LOGIC; 
  signal CHOICE12768 : STD_LOGIC; 
  signal N5942 : STD_LOGIC; 
  signal CHOICE12544 : STD_LOGIC; 
  signal N5943 : STD_LOGIC; 
  signal CHOICE12644 : STD_LOGIC; 
  signal N5944 : STD_LOGIC; 
  signal CHOICE12515 : STD_LOGIC; 
  signal CHOICE12740 : STD_LOGIC; 
  signal CHOICE11918 : STD_LOGIC; 
  signal N5977 : STD_LOGIC; 
  signal CHOICE12540 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N48 : STD_LOGIC; 
  signal rom_Mrom_n0002_N47 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N39 : STD_LOGIC; 
  signal rom_Mrom_n0002_N94 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N50 : STD_LOGIC; 
  signal rom_Mrom_n0002_N95 : STD_LOGIC; 
  signal rom_Mrom_n0002_N96 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_N93 : STD_LOGIC; 
  signal rom_Mrom_n0002_N97 : STD_LOGIC; 
  signal dec_stage_d_instruction_decoder_n0200 : STD_LOGIC; 
  signal rom_Mrom_n0002_N82 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N42 : STD_LOGIC; 
  signal CHOICE12267 : STD_LOGIC; 
  signal exe_stage_alu_m_N52 : STD_LOGIC; 
  signal CHOICE12636 : STD_LOGIC; 
  signal exe_stage_alu_m_N51 : STD_LOGIC; 
  signal exe_stage_alu_m_N40 : STD_LOGIC; 
  signal CHOICE12576 : STD_LOGIC; 
  signal CHOICE12767 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_50 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_112 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_111 : STD_LOGIC; 
  signal exe_stage_alu_m_N48 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_110 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_109 : STD_LOGIC; 
  signal exe_stage_alu_m_N50 : STD_LOGIC; 
  signal exe_stage_alu_m_N59 : STD_LOGIC; 
  signal exe_stage_alu_m_N49 : STD_LOGIC; 
  signal exe_stage_alu_m_N56 : STD_LOGIC; 
  signal exe_stage_alu_m_N55 : STD_LOGIC; 
  signal exe_stage_alu_m_N53 : STD_LOGIC; 
  signal exe_stage_alu_m_N54 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net577 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net579 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0218_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N851 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net581 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_103 : STD_LOGIC; 
  signal wb_stage_n0075 : STD_LOGIC; 
  signal wb_stage_N58 : STD_LOGIC; 
  signal rom_Mrom_n0002_N18 : STD_LOGIC; 
  signal rom_Mrom_n0002_N1 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_133 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net553 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net547 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_98 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_99 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_140 : STD_LOGIC; 
  signal rom_Mrom_n0002_N4 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_104 : STD_LOGIC; 
  signal wb_stage_N74 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net615 : STD_LOGIC; 
  signal wb_stage_N67 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_247 : STD_LOGIC; 
  signal rom_Mrom_n0002_N76 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_14 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net537 : STD_LOGIC; 
  signal CHOICE12097 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net619 : STD_LOGIC; 
  signal rom_Mrom_n0002_N14 : STD_LOGIC; 
  signal mem_r_addr_b0_7_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net531 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_144 : STD_LOGIC; 
  signal CHOICE12777 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net337 : STD_LOGIC; 
  signal wb_stage_n0164 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net569 : STD_LOGIC; 
  signal rom_Mrom_n0002_N36 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_42 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net291 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_246 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_102 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net263 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net287 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_39 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net539 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_15 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_261 : STD_LOGIC; 
  signal CHOICE12152 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_264 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_92 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net247 : STD_LOGIC; 
  signal CHOICE12682 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net367 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_135 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net565 : STD_LOGIC; 
  signal wb_stage_N62 : STD_LOGIC; 
  signal rom_Mrom_n0002_N110 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_66 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net329 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_113 : STD_LOGIC; 
  signal N5929 : STD_LOGIC; 
  signal rom_Mrom_n0002_N111 : STD_LOGIC; 
  signal wb_stage_N111 : STD_LOGIC; 
  signal fet_stage_que_state_M_n0300 : STD_LOGIC; 
  signal fet_stage_que_state_M_N42 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_127 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net331 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net279 : STD_LOGIC; 
  signal rom_Mrom_n0002_N34 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net277 : STD_LOGIC; 
  signal CHOICE12648 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net349 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net275 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net617 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net627 : STD_LOGIC; 
  signal fet_stage_que_state_M_N27 : STD_LOGIC; 
  signal CHOICE12493 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net273 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_95 : STD_LOGIC; 
  signal N5925 : STD_LOGIC; 
  signal rom_Mrom_n0002_N62 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_111 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_94 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_110 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_93 : STD_LOGIC; 
  signal mem_r_addr_b0_1_Q : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_129 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_43 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net589 : STD_LOGIC; 
  signal mem_r_addr_b0_3_Q : STD_LOGIC; 
  signal CHOICE12328 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_96 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_248 : STD_LOGIC; 
  signal CHOICE12608 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_119 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net591 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net269 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net303 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net297 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net517 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_117 : STD_LOGIC; 
  signal fet_stage_que_state_M_state_FFd3_In : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net515 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net267 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net301 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net295 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net271 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net265 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net299 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_118 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_120 : STD_LOGIC; 
  signal rom_Mrom_n0002_N91 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net293 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net355 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_121 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net257 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net571 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_47 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net261 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net535 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_141 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_46 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_143 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net357 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net289 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_104 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net259 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_38 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_103 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_88 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_101 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_145 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_87 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net347 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net587 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_86 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_262 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net583 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net533 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_85 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_263 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net573 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_146 : STD_LOGIC; 
  signal rom_Mrom_n0002_N16 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net255 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net585 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net285 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net513 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_108 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net351 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net253 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net345 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net283 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_105 : STD_LOGIC; 
  signal N6156 : STD_LOGIC; 
  signal rom_Mrom_n0002_N37 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net251 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net245 : STD_LOGIC; 
  signal exwb_buff_out_D22_4_1 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net281 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net611 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net249 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net243 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net549 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net521 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_102 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_12 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net551 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net613 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net241 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_11 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net343 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_10 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net623 : STD_LOGIC; 
  signal rom_Mrom_n0002_N7 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_16 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_9 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net621 : STD_LOGIC; 
  signal rom_Mrom_n0002_N5 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut2_13 : STD_LOGIC; 
  signal CHOICE12606 : STD_LOGIC; 
  signal wb_stage_n0190 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net599 : STD_LOGIC; 
  signal N3364 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net359 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_107 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out17 : STD_LOGIC; 
  signal exwb_buff_out_D11_0_1 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net601 : STD_LOGIC; 
  signal CHOICE12793 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net361 : STD_LOGIC; 
  signal CHOICE12518 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net529 : STD_LOGIC; 
  signal N6309 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net363 : STD_LOGIC; 
  signal rom_Mrom_n0002_N17 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_101 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net341 : STD_LOGIC; 
  signal rom_Mrom_n0002_N6 : STD_LOGIC; 
  signal N5924 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_63 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net365 : STD_LOGIC; 
  signal rom_Mrom_n0002_N2 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net563 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_138 : STD_LOGIC; 
  signal CHOICE11700 : STD_LOGIC; 
  signal rom_Mrom_n0002_N109 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net527 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net567 : STD_LOGIC; 
  signal N6211 : STD_LOGIC; 
  signal rom_Mrom_n0002_N61 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net561 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_245 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_125 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_141 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_67 : STD_LOGIC; 
  signal rom_Mrom_n0002_N112 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out22 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_142 : STD_LOGIC; 
  signal fet_stage_que_state_M_state_FFd3 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out23 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_143 : STD_LOGIC; 
  signal N5927 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net339 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_62 : STD_LOGIC; 
  signal mem_r_addr_b0_6_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net597 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_136 : STD_LOGIC; 
  signal mem_r_addr_b0_4_Q : STD_LOGIC; 
  signal rom_Mrom_n0002_N63 : STD_LOGIC; 
  signal fet_stage_que_state_M_state_FFd1_In : STD_LOGIC; 
  signal mem_r_addr_b0_2_Q : STD_LOGIC; 
  signal mem_r_addr_b0_0_Q : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_109 : STD_LOGIC; 
  signal wb_stage_N35 : STD_LOGIC; 
  signal wb_stage_N22 : STD_LOGIC; 
  signal wb_stage_N2 : STD_LOGIC; 
  signal wb_stage_N12 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net603 : STD_LOGIC; 
  signal CHOICE12757 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net605 : STD_LOGIC; 
  signal rom_Mrom_n0002_N80 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net607 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_32 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_31 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_59 : STD_LOGIC; 
  signal wb_stage_N68 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_148 : STD_LOGIC; 
  signal wb_stage_N80 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_58 : STD_LOGIC; 
  signal wb_stage_N10 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_149 : STD_LOGIC; 
  signal wb_stage_n0150 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_128 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_152 : STD_LOGIC; 
  signal wb_stage_N01 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_127 : STD_LOGIC; 
  signal wb_stage_N26 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_153 : STD_LOGIC; 
  signal wb_stage_N38 : STD_LOGIC; 
  signal wb_stage_N9 : STD_LOGIC; 
  signal wb_stage_N61 : STD_LOGIC; 
  signal wb_stage_N71 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_30 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_29 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_28 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_27 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_26 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_269 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_270 : STD_LOGIC; 
  signal wb_stage_N51 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_126 : STD_LOGIC; 
  signal wb_stage_N311 : STD_LOGIC; 
  signal rom_Mrom_n0002_N106 : STD_LOGIC; 
  signal wb_stage_N56 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_125 : STD_LOGIC; 
  signal wb_stage_N7 : STD_LOGIC; 
  signal rom_Mrom_n0002_N107 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out19 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net575 : STD_LOGIC; 
  signal wb_stage_n0072 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net559 : STD_LOGIC; 
  signal wb_stage_n0073 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net525 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out18 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net557 : STD_LOGIC; 
  signal wb_stage_N66 : STD_LOGIC; 
  signal cu_n0311 : STD_LOGIC; 
  signal cu_n0327 : STD_LOGIC; 
  signal rom_Mrom_n0002_N65 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_271 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_272 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_122 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_123 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net555 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net523 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net609 : STD_LOGIC; 
  signal cu_N15 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_147 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_151 : STD_LOGIC; 
  signal cu_N14 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_154 : STD_LOGIC; 
  signal rom_Mrom_n0002_N67 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_94 : STD_LOGIC; 
  signal rom_Mrom_n0002_N66 : STD_LOGIC; 
  signal rom_Mrom_n0002_N33 : STD_LOGIC; 
  signal mem_PSW_n0008 : STD_LOGIC; 
  signal mem_PSW_n0009 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net635 : STD_LOGIC; 
  signal mem_PSW_n0010 : STD_LOGIC; 
  signal mem_PSW_n0007 : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_10_Q : STD_LOGIC; 
  signal wb_stage_N28 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net305 : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_9_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_31_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_30_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_29_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_28_Q : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_95 : STD_LOGIC; 
  signal fet_stage_que_state_M_N21 : STD_LOGIC; 
  signal rom_Mrom_n0002_N108 : STD_LOGIC; 
  signal exwb_buff_out_D22_5_1 : STD_LOGIC; 
  signal rom_Mrom_n0002_N19 : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_11_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_14_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_8_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_27_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_12_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_15_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_13_Q : STD_LOGIC; 
  signal rom_Mrom_n0002_N35 : STD_LOGIC; 
  signal wb_stage_N59 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out20 : STD_LOGIC; 
  signal rom_Mrom_n0002_N78 : STD_LOGIC; 
  signal cu_N58 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_51 : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_26_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_25_Q : STD_LOGIC; 
  signal mem_internal_ram_bank_n0018_24_Q : STD_LOGIC; 
  signal fet_stage_que_state_M_state_FFd1 : STD_LOGIC; 
  signal wb_stage_N63 : STD_LOGIC; 
  signal N6305 : STD_LOGIC; 
  signal CHOICE11680 : STD_LOGIC; 
  signal CHOICE11679 : STD_LOGIC; 
  signal exe_stage_alu_m_N64 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_6_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N65 : STD_LOGIC; 
  signal exe_stage_alu_m_N63 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0000_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N66 : STD_LOGIC; 
  signal exe_stage_alu_m_N62 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0000_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N67 : STD_LOGIC; 
  signal exe_stage_alu_m_N61 : STD_LOGIC; 
  signal fet_stage_que_state_M_N431 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_3_cyo : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_278 : STD_LOGIC; 
  signal exe_stage_alu_m_N80 : STD_LOGIC; 
  signal exe_stage_alu_m_N47 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N46 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_277 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N45 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_3_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N44 : STD_LOGIC; 
  signal exe_stage_alu_m_N43 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N41 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0055_6_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0073_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N58 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_279 : STD_LOGIC; 
  signal N6311 : STD_LOGIC; 
  signal CHOICE11925 : STD_LOGIC; 
  signal CHOICE11850 : STD_LOGIC; 
  signal N6344 : STD_LOGIC; 
  signal CHOICE12022 : STD_LOGIC; 
  signal CHOICE12157 : STD_LOGIC; 
  signal N6125 : STD_LOGIC; 
  signal N6273 : STD_LOGIC; 
  signal CHOICE12047 : STD_LOGIC; 
  signal CHOICE12049 : STD_LOGIC; 
  signal CHOICE12571 : STD_LOGIC; 
  signal CHOICE12779 : STD_LOGIC; 
  signal CHOICE12100 : STD_LOGIC; 
  signal CHOICE12020 : STD_LOGIC; 
  signal CHOICE11675 : STD_LOGIC; 
  signal CHOICE12293 : STD_LOGIC; 
  signal CHOICE12618 : STD_LOGIC; 
  signal CHOICE12669 : STD_LOGIC; 
  signal CHOICE12060 : STD_LOGIC; 
  signal CHOICE12667 : STD_LOGIC; 
  signal CHOICE11963 : STD_LOGIC; 
  signal CHOICE12570 : STD_LOGIC; 
  signal N6262 : STD_LOGIC; 
  signal N6175 : STD_LOGIC; 
  signal CHOICE12015 : STD_LOGIC; 
  signal CHOICE12772 : STD_LOGIC; 
  signal CHOICE12011 : STD_LOGIC; 
  signal CHOICE12807 : STD_LOGIC; 
  signal CHOICE12124 : STD_LOGIC; 
  signal N5928 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net637 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net307 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net639 : STD_LOGIC; 
  signal N6129 : STD_LOGIC; 
  signal exwb_buff_out_D11_6_1 : STD_LOGIC; 
  signal CHOICE11882 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net631 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_131 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_127 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net309 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net633 : STD_LOGIC; 
  signal fet_stage_que_state_M_state_FFd2 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_285 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_286 : STD_LOGIC; 
  signal mem_Inst_rid_Mram_R0R1_ren_inst_inv_0 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_287 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_288 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_130 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_126 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_280 : STD_LOGIC; 
  signal wb_stage_N41 : STD_LOGIC; 
  signal wb_stage_N36 : STD_LOGIC; 
  signal wb_stage_N32 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net311 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net541 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net543 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_102 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_232 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_231 : STD_LOGIC; 
  signal CHOICE11977 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net313 : STD_LOGIC; 
  signal CHOICE11906 : STD_LOGIC; 
  signal wb_stage_Neq_stage_cyo2 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net315 : STD_LOGIC; 
  signal wb_stage_N29 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out16 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net317 : STD_LOGIC; 
  signal wb_stage_N57 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net319 : STD_LOGIC; 
  signal wb_stage_N73 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_115 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_114 : STD_LOGIC; 
  signal CHOICE11972 : STD_LOGIC; 
  signal wb_stage_Neq_stage_cyo1 : STD_LOGIC; 
  signal wb_stage_N72 : STD_LOGIC; 
  signal wb_stage_N8 : STD_LOGIC; 
  signal wb_stage_N34 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_230 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_229 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_103 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net629 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_237 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_238 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_239 : STD_LOGIC; 
  signal wb_stage_N6 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_256 : STD_LOGIC; 
  signal wb_stage_N5 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_255 : STD_LOGIC; 
  signal wb_stage_n0076 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_254 : STD_LOGIC; 
  signal wb_stage_Neq_stage_cyo : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_253 : STD_LOGIC; 
  signal wb_stage_N78 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net519 : STD_LOGIC; 
  signal wb_stage_N4 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_117 : STD_LOGIC; 
  signal wb_stage_MUX_BLOCK_n0179_3_mmx_out24 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_118 : STD_LOGIC; 
  signal wb_stage_N82 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_119 : STD_LOGIC; 
  signal cu_N27 : STD_LOGIC; 
  signal cu_n0302 : STD_LOGIC; 
  signal cu_N68 : STD_LOGIC; 
  signal cu_n0303 : STD_LOGIC; 
  signal cu_N44 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut3_240 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_106 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_107 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_lut3_120 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_54 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net545 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_mux_f5_55 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net353 : STD_LOGIC; 
  signal N5931 : STD_LOGIC; 
  signal cu_N18 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net321 : STD_LOGIC; 
  signal wb_stage_N21 : STD_LOGIC; 
  signal wb_stage_N3 : STD_LOGIC; 
  signal CHOICE11787 : STD_LOGIC; 
  signal fet_stage_que_state_M_N24 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_118 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_mux_f5_119 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net625 : STD_LOGIC; 
  signal wb_stage_N60 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net593 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_net595 : STD_LOGIC; 
  signal cu_n0330 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net323 : STD_LOGIC; 
  signal CHOICE11839 : STD_LOGIC; 
  signal cu_N17 : STD_LOGIC; 
  signal N6177 : STD_LOGIC; 
  signal N5930 : STD_LOGIC; 
  signal cu_N39 : STD_LOGIC; 
  signal fet_stage_que_state_M_N211 : STD_LOGIC; 
  signal fet_stage_que_state_M_N39 : STD_LOGIC; 
  signal fet_stage_que_state_M_N9 : STD_LOGIC; 
  signal fet_stage_que_state_M_n0299 : STD_LOGIC; 
  signal CHOICE11664 : STD_LOGIC; 
  signal N5926 : STD_LOGIC; 
  signal N5932 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net325 : STD_LOGIC; 
  signal rom_Mrom_n0002_N32 : STD_LOGIC; 
  signal cu_N22 : STD_LOGIC; 
  signal rom_Mrom_n0002_N31 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_net327 : STD_LOGIC; 
  signal rom_Mrom_n0002_N81 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_111 : STD_LOGIC; 
  signal CHOICE12253 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_110 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_124 : STD_LOGIC; 
  signal rom_Mrom_n0002_N92 : STD_LOGIC; 
  signal rom_Mrom_n0002_inst_lut4_131 : STD_LOGIC; 
  signal rom_Mrom_n0002_N93 : STD_LOGIC; 
  signal N6128 : STD_LOGIC; 
  signal exwb_buff_out_R_A_4_1 : STD_LOGIC; 
  signal N6123 : STD_LOGIC; 
  signal exwb_buff_out_D22_0_1 : STD_LOGIC; 
  signal N6134 : STD_LOGIC; 
  signal N6132 : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_lut2_25 : STD_LOGIC; 
  signal dec_stage_d_mux7_N0 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N35 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N90 : STD_LOGIC; 
  signal exe_stage_alu_m_N89 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0218_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo3 : STD_LOGIC; 
  signal exe_stage_alu_m_N78 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo6 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N85 : STD_LOGIC; 
  signal exe_stage_alu_m_N861 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N711 : STD_LOGIC; 
  signal N6121 : STD_LOGIC; 
  signal exe_stage_alu_m_N107 : STD_LOGIC; 
  signal CHOICE11958 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo3 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0000_3_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0218_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_Eq_stage_cyo2 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_3_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo5 : STD_LOGIC; 
  signal exe_stage_alu_m_N94 : STD_LOGIC; 
  signal exe_stage_alu_m_N931 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0217_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0165_3_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N74 : STD_LOGIC; 
  signal exe_stage_alu_m_N73 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_1_cyo : STD_LOGIC; 
  signal N6285 : STD_LOGIC; 
  signal exe_stage_alu_m_N77 : STD_LOGIC; 
  signal exe_stage_alu_m_N86 : STD_LOGIC; 
  signal exe_stage_alu_m_N108 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_n0220 : STD_LOGIC; 
  signal exe_stage_alu_m_n0221 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo4 : STD_LOGIC; 
  signal exe_stage_alu_m_n0222 : STD_LOGIC; 
  signal exe_stage_alu_m_n0223 : STD_LOGIC; 
  signal exe_stage_alu_m_n0224 : STD_LOGIC; 
  signal exe_stage_alu_m_N911 : STD_LOGIC; 
  signal exe_stage_alu_m_n0230 : STD_LOGIC; 
  signal exe_stage_alu_m_n0226 : STD_LOGIC; 
  signal exe_stage_alu_m_n0227 : STD_LOGIC; 
  signal exe_stage_alu_m_N841 : STD_LOGIC; 
  signal CHOICE12524 : STD_LOGIC; 
  signal exe_stage_alu_m_n0233 : STD_LOGIC; 
  signal exe_stage_alu_m_n0229 : STD_LOGIC; 
  signal exe_stage_alu_m_N821 : STD_LOGIC; 
  signal exe_stage_alu_m_N581 : STD_LOGIC; 
  signal exe_stage_alu_m_N941 : STD_LOGIC; 
  signal CHOICE12190 : STD_LOGIC; 
  signal exe_stage_alu_m_n0241 : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_n0242 : STD_LOGIC; 
  signal exe_stage_alu_m_n0238 : STD_LOGIC; 
  signal exe_stage_alu_m_n0243 : STD_LOGIC; 
  signal exe_stage_alu_m_n0239 : STD_LOGIC; 
  signal exe_stage_alu_m_n0244 : STD_LOGIC; 
  signal exe_stage_alu_m_N120 : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo5 : STD_LOGIC; 
  signal exe_stage_alu_m_N76 : STD_LOGIC; 
  signal exe_stage_alu_m_N961 : STD_LOGIC; 
  signal exe_stage_alu_m_N72 : STD_LOGIC; 
  signal exe_stage_alu_m_N01 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0003_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_n0249 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_n0260 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0165_0_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo7 : STD_LOGIC; 
  signal exe_stage_alu_m_n0261 : STD_LOGIC; 
  signal exe_stage_alu_m_N99 : STD_LOGIC; 
  signal exe_stage_alu_m_n0262 : STD_LOGIC; 
  signal exe_stage_alu_m_N70 : STD_LOGIC; 
  signal exe_stage_alu_m_n0263 : STD_LOGIC; 
  signal exe_stage_alu_m_N106 : STD_LOGIC; 
  signal exe_stage_alu_m_N100 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0216_5_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N109 : STD_LOGIC; 
  signal exe_stage_alu_m_N96 : STD_LOGIC; 
  signal exe_stage_alu_m_N82 : STD_LOGIC; 
  signal exe_stage_alu_m_N103 : STD_LOGIC; 
  signal exe_stage_alu_m_N871 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0165_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N97 : STD_LOGIC; 
  signal exe_stage_alu_m_n0273 : STD_LOGIC; 
  signal exe_stage_alu_m_XNor_stage_cyo6 : STD_LOGIC; 
  signal exe_stage_alu_m_N621 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_6_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N104 : STD_LOGIC; 
  signal exe_stage_alu_m_N105 : STD_LOGIC; 
  signal exe_stage_alu_m_Eq_stage_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N75 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo1 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_cyo2 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0217_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_6_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0217_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_N87 : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0165_1_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_4_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0000_2_cyo : STD_LOGIC; 
  signal exe_stage_alu_m_n0287 : STD_LOGIC; 
  signal exe_stage_alu_m_N831 : STD_LOGIC; 
  signal exe_stage_alu_m_N102 : STD_LOGIC; 
  signal N701 : STD_LOGIC; 
  signal N721 : STD_LOGIC; 
  signal N741 : STD_LOGIC; 
  signal N761 : STD_LOGIC; 
  signal N781 : STD_LOGIC; 
  signal N801 : STD_LOGIC; 
  signal N81 : STD_LOGIC; 
  signal N83 : STD_LOGIC; 
  signal N6297 : STD_LOGIC; 
  signal N1425 : STD_LOGIC; 
  signal N1427 : STD_LOGIC; 
  signal CHOICE12008 : STD_LOGIC; 
  signal N6203 : STD_LOGIC; 
  signal N1481 : STD_LOGIC; 
  signal N1455 : STD_LOGIC; 
  signal N1423 : STD_LOGIC; 
  signal N1421 : STD_LOGIC; 
  signal N1419 : STD_LOGIC; 
  signal N1429 : STD_LOGIC; 
  signal N97 : STD_LOGIC; 
  signal N6231 : STD_LOGIC; 
  signal CHOICE10683 : STD_LOGIC; 
  signal CHOICE10964 : STD_LOGIC; 
  signal CHOICE10959 : STD_LOGIC; 
  signal CHOICE10966 : STD_LOGIC; 
  signal N1417 : STD_LOGIC; 
  signal N1415 : STD_LOGIC; 
  signal CHOICE10765 : STD_LOGIC; 
  signal CHOICE10896 : STD_LOGIC; 
  signal N6237 : STD_LOGIC; 
  signal CHOICE10613 : STD_LOGIC; 
  signal CHOICE10845 : STD_LOGIC; 
  signal CHOICE12499 : STD_LOGIC; 
  signal CHOICE10957 : STD_LOGIC; 
  signal CHOICE10612 : STD_LOGIC; 
  signal CHOICE11027 : STD_LOGIC; 
  signal CHOICE10875 : STD_LOGIC; 
  signal N6260 : STD_LOGIC; 
  signal CHOICE12282 : STD_LOGIC; 
  signal N923 : STD_LOGIC; 
  signal CHOICE10701 : STD_LOGIC; 
  signal N905 : STD_LOGIC; 
  signal CHOICE11022 : STD_LOGIC; 
  signal CHOICE12737 : STD_LOGIC; 
  signal CHOICE10945 : STD_LOGIC; 
  signal CHOICE11013 : STD_LOGIC; 
  signal N772 : STD_LOGIC; 
  signal CHOICE11020 : STD_LOGIC; 
  signal CHOICE10624 : STD_LOGIC; 
  signal CHOICE10619 : STD_LOGIC; 
  signal N6227 : STD_LOGIC; 
  signal CHOICE10842 : STD_LOGIC; 
  signal CHOICE10865 : STD_LOGIC; 
  signal N6199 : STD_LOGIC; 
  signal CHOICE10952 : STD_LOGIC; 
  signal N6205 : STD_LOGIC; 
  signal CHOICE10950 : STD_LOGIC; 
  signal N6201 : STD_LOGIC; 
  signal N6275 : STD_LOGIC; 
  signal N834 : STD_LOGIC; 
  signal N6195 : STD_LOGIC; 
  signal CHOICE11015 : STD_LOGIC; 
  signal CHOICE10696 : STD_LOGIC; 
  signal CHOICE10922 : STD_LOGIC; 
  signal N146 : STD_LOGIC; 
  signal N147 : STD_LOGIC; 
  signal N1337 : STD_LOGIC; 
  signal N6281 : STD_LOGIC; 
  signal N13411 : STD_LOGIC; 
  signal CHOICE10908 : STD_LOGIC; 
  signal N1343 : STD_LOGIC; 
  signal N1345 : STD_LOGIC; 
  signal CHOICE10910 : STD_LOGIC; 
  signal CHOICE12465 : STD_LOGIC; 
  signal N1339 : STD_LOGIC; 
  signal CHOICE11757 : STD_LOGIC; 
  signal N1347 : STD_LOGIC; 
  signal CHOICE11008 : STD_LOGIC; 
  signal CHOICE10702 : STD_LOGIC; 
  signal N6315 : STD_LOGIC; 
  signal N6235 : STD_LOGIC; 
  signal N6173 : STD_LOGIC; 
  signal N1335 : STD_LOGIC; 
  signal CHOICE11004 : STD_LOGIC; 
  signal CHOICE12554 : STD_LOGIC; 
  signal N6207 : STD_LOGIC; 
  signal N1333 : STD_LOGIC; 
  signal CHOICE10903 : STD_LOGIC; 
  signal N6223 : STD_LOGIC; 
  signal CHOICE11766 : STD_LOGIC; 
  signal N6221 : STD_LOGIC; 
  signal CHOICE10924 : STD_LOGIC; 
  signal N6264 : STD_LOGIC; 
  signal CHOICE11006 : STD_LOGIC; 
  signal CHOICE10743 : STD_LOGIC; 
  signal CHOICE10639 : STD_LOGIC; 
  signal CHOICE10849 : STD_LOGIC; 
  signal CHOICE10828 : STD_LOGIC; 
  signal CHOICE12424 : STD_LOGIC; 
  signal CHOICE10889 : STD_LOGIC; 
  signal CHOICE10868 : STD_LOGIC; 
  signal CHOICE10943 : STD_LOGIC; 
  signal CHOICE10873 : STD_LOGIC; 
  signal CHOICE10700 : STD_LOGIC; 
  signal CHOICE12745 : STD_LOGIC; 
  signal N6159 : STD_LOGIC; 
  signal N6266 : STD_LOGIC; 
  signal CHOICE10788 : STD_LOGIC; 
  signal CHOICE10646 : STD_LOGIC; 
  signal CHOICE12696 : STD_LOGIC; 
  signal CHOICE10999 : STD_LOGIC; 
  signal CHOICE10746 : STD_LOGIC; 
  signal CHOICE10901 : STD_LOGIC; 
  signal N826 : STD_LOGIC; 
  signal CHOICE11001 : STD_LOGIC; 
  signal CHOICE10779 : STD_LOGIC; 
  signal CHOICE10715 : STD_LOGIC; 
  signal CHOICE10917 : STD_LOGIC; 
  signal CHOICE10936 : STD_LOGIC; 
  signal CHOICE10882 : STD_LOGIC; 
  signal CHOICE12414 : STD_LOGIC; 
  signal CHOICE10987 : STD_LOGIC; 
  signal N771 : STD_LOGIC; 
  signal CHOICE10880 : STD_LOGIC; 
  signal N776 : STD_LOGIC; 
  signal CHOICE10915 : STD_LOGIC; 
  signal N768 : STD_LOGIC; 
  signal CHOICE10760 : STD_LOGIC; 
  signal CHOICE11872 : STD_LOGIC; 
  signal CHOICE10654 : STD_LOGIC; 
  signal CHOICE10994 : STD_LOGIC; 
  signal CHOICE10992 : STD_LOGIC; 
  signal CHOICE10709 : STD_LOGIC; 
  signal CHOICE12468 : STD_LOGIC; 
  signal CHOICE10816 : STD_LOGIC; 
  signal N6229 : STD_LOGIC; 
  signal CHOICE11690 : STD_LOGIC; 
  signal CHOICE10812 : STD_LOGIC; 
  signal CHOICE10850 : STD_LOGIC; 
  signal N6287 : STD_LOGIC; 
  signal CHOICE10728 : STD_LOGIC; 
  signal CHOICE10985 : STD_LOGIC; 
  signal CHOICE10658 : STD_LOGIC; 
  signal N824 : STD_LOGIC; 
  signal CHOICE10938 : STD_LOGIC; 
  signal N6120 : STD_LOGIC; 
  signal CHOICE12163 : STD_LOGIC; 
  signal N6225 : STD_LOGIC; 
  signal CHOICE11965 : STD_LOGIC; 
  signal CHOICE11833 : STD_LOGIC; 
  signal CHOICE10887 : STD_LOGIC; 
  signal N899 : STD_LOGIC; 
  signal CHOICE12130 : STD_LOGIC; 
  signal N897 : STD_LOGIC; 
  signal CHOICE11947 : STD_LOGIC; 
  signal N769 : STD_LOGIC; 
  signal CHOICE10980 : STD_LOGIC; 
  signal CHOICE10978 : STD_LOGIC; 
  signal N903 : STD_LOGIC; 
  signal N6233 : STD_LOGIC; 
  signal CHOICE10894 : STD_LOGIC; 
  signal CHOICE12632 : STD_LOGIC; 
  signal CHOICE10727 : STD_LOGIC; 
  signal CHOICE11643 : STD_LOGIC; 
  signal N6239 : STD_LOGIC; 
  signal CHOICE12316 : STD_LOGIC; 
  signal CHOICE10931 : STD_LOGIC; 
  signal N6283 : STD_LOGIC; 
  signal CHOICE10973 : STD_LOGIC; 
  signal CHOICE10858 : STD_LOGIC; 
  signal N910 : STD_LOGIC; 
  signal N6193 : STD_LOGIC; 
  signal CHOICE10929 : STD_LOGIC; 
  signal CHOICE10971 : STD_LOGIC; 
  signal CHOICE12337 : STD_LOGIC; 
  signal N6317 : STD_LOGIC; 
  signal CHOICE10780 : STD_LOGIC; 
  signal CHOICE10673 : STD_LOGIC; 
  signal CHOICE10827 : STD_LOGIC; 
  signal CHOICE11801 : STD_LOGIC; 
  signal N785 : STD_LOGIC; 
  signal N6245 : STD_LOGIC; 
  signal N901 : STD_LOGIC; 
  signal CHOICE12213 : STD_LOGIC; 
  signal CHOICE12086 : STD_LOGIC; 
  signal N6340 : STD_LOGIC; 
  signal N6185 : STD_LOGIC; 
  signal CHOICE10726 : STD_LOGIC; 
  signal CHOICE11657 : STD_LOGIC; 
  signal CHOICE11714 : STD_LOGIC; 
  signal CHOICE10864 : STD_LOGIC; 
  signal N6197 : STD_LOGIC; 
  signal CHOICE11261 : STD_LOGIC; 
  signal CHOICE11044 : STD_LOGIC; 
  signal CHOICE11425 : STD_LOGIC; 
  signal CHOICE11227 : STD_LOGIC; 
  signal CHOICE11439 : STD_LOGIC; 
  signal CHOICE11096 : STD_LOGIC; 
  signal N6135 : STD_LOGIC; 
  signal N6251 : STD_LOGIC; 
  signal CHOICE11130 : STD_LOGIC; 
  signal N6258 : STD_LOGIC; 
  signal CHOICE11045 : STD_LOGIC; 
  signal CHOICE11481 : STD_LOGIC; 
  signal CHOICE12550 : STD_LOGIC; 
  signal CHOICE12246 : STD_LOGIC; 
  signal CHOICE11394 : STD_LOGIC; 
  signal N6291 : STD_LOGIC; 
  signal CHOICE11571 : STD_LOGIC; 
  signal CHOICE11422 : STD_LOGIC; 
  signal CHOICE11417 : STD_LOGIC; 
  signal CHOICE11036 : STD_LOGIC; 
  signal CHOICE11218 : STD_LOGIC; 
  signal CHOICE11221 : STD_LOGIC; 
  signal CHOICE11233 : STD_LOGIC; 
  signal N6255 : STD_LOGIC; 
  signal CHOICE11568 : STD_LOGIC; 
  signal CHOICE11320 : STD_LOGIC; 
  signal CHOICE11364 : STD_LOGIC; 
  signal N6119 : STD_LOGIC; 
  signal CHOICE11418 : STD_LOGIC; 
  signal CHOICE11136 : STD_LOGIC; 
  signal CHOICE11042 : STD_LOGIC; 
  signal CHOICE11187 : STD_LOGIC; 
  signal CHOICE11100 : STD_LOGIC; 
  signal CHOICE11656 : STD_LOGIC; 
  signal CHOICE11183 : STD_LOGIC; 
  signal CHOICE11110 : STD_LOGIC; 
  signal CHOICE11106 : STD_LOGIC; 
  signal CHOICE12236 : STD_LOGIC; 
  signal N6313 : STD_LOGIC; 
  signal CHOICE11464 : STD_LOGIC; 
  signal CHOICE11120 : STD_LOGIC; 
  signal CHOICE11372 : STD_LOGIC; 
  signal CHOICE11557 : STD_LOGIC; 
  signal CHOICE11400 : STD_LOGIC; 
  signal CHOICE11219 : STD_LOGIC; 
  signal CHOICE11289 : STD_LOGIC; 
  signal CHOICE11504 : STD_LOGIC; 
  signal CHOICE11063 : STD_LOGIC; 
  signal N6217 : STD_LOGIC; 
  signal CHOICE12364 : STD_LOGIC; 
  signal CHOICE11397 : STD_LOGIC; 
  signal CHOICE11562 : STD_LOGIC; 
  signal CHOICE12734 : STD_LOGIC; 
  signal CHOICE11499 : STD_LOGIC; 
  signal CHOICE11473 : STD_LOGIC; 
  signal N6189 : STD_LOGIC; 
  signal CHOICE12733 : STD_LOGIC; 
  signal CHOICE11337 : STD_LOGIC; 
  signal CHOICE11275 : STD_LOGIC; 
  signal CHOICE11512 : STD_LOGIC; 
  signal CHOICE11175 : STD_LOGIC; 
  signal CHOICE11553 : STD_LOGIC; 
  signal CHOICE11432 : STD_LOGIC; 
  signal CHOICE12170 : STD_LOGIC; 
  signal CHOICE11455 : STD_LOGIC; 
  signal CHOICE12199 : STD_LOGIC; 
  signal CHOICE11195 : STD_LOGIC; 
  signal CHOICE12071 : STD_LOGIC; 
  signal CHOICE11546 : STD_LOGIC; 
  signal CHOICE11116 : STD_LOGIC; 
  signal CHOICE11551 : STD_LOGIC; 
  signal CHOICE11428 : STD_LOGIC; 
  signal CHOICE11312 : STD_LOGIC; 
  signal CHOICE11156 : STD_LOGIC; 
  signal CHOICE11082 : STD_LOGIC; 
  signal CHOICE11403 : STD_LOGIC; 
  signal CHOICE11358 : STD_LOGIC; 
  signal CHOICE11534 : STD_LOGIC; 
  signal CHOICE11230 : STD_LOGIC; 
  signal CHOICE11323 : STD_LOGIC; 
  signal CHOICE11068 : STD_LOGIC; 
  signal CHOICE11166 : STD_LOGIC; 
  signal CHOICE11488 : STD_LOGIC; 
  signal CHOICE11823 : STD_LOGIC; 
  signal N6167 : STD_LOGIC; 
  signal N6158 : STD_LOGIC; 
  signal CHOICE12656 : STD_LOGIC; 
  signal CHOICE11277 : STD_LOGIC; 
  signal CHOICE12612 : STD_LOGIC; 
  signal CHOICE11386 : STD_LOGIC; 
  signal CHOICE11540 : STD_LOGIC; 
  signal CHOICE11368 : STD_LOGIC; 
  signal CHOICE12658 : STD_LOGIC; 
  signal N2487 : STD_LOGIC; 
  signal CHOICE11140 : STD_LOGIC; 
  signal CHOICE11541 : STD_LOGIC; 
  signal CHOICE11085 : STD_LOGIC; 
  signal CHOICE11446 : STD_LOGIC; 
  signal CHOICE11160 : STD_LOGIC; 
  signal CHOICE12059 : STD_LOGIC; 
  signal CHOICE11224 : STD_LOGIC; 
  signal CHOICE11359 : STD_LOGIC; 
  signal CHOICE11522 : STD_LOGIC; 
  signal N6277 : STD_LOGIC; 
  signal CHOICE11492 : STD_LOGIC; 
  signal CHOICE11379 : STD_LOGIC; 
  signal CHOICE11245 : STD_LOGIC; 
  signal CHOICE11178 : STD_LOGIC; 
  signal N6122 : STD_LOGIC; 
  signal CHOICE11384 : STD_LOGIC; 
  signal CHOICE12283 : STD_LOGIC; 
  signal CHOICE11530 : STD_LOGIC; 
  signal N6257 : STD_LOGIC; 
  signal CHOICE11077 : STD_LOGIC; 
  signal CHOICE12180 : STD_LOGIC; 
  signal CHOICE11413 : STD_LOGIC; 
  signal N2491 : STD_LOGIC; 
  signal CHOICE11239 : STD_LOGIC; 
  signal N2485 : STD_LOGIC; 
  signal CHOICE11315 : STD_LOGIC; 
  signal CHOICE11329 : STD_LOGIC; 
  signal CHOICE11525 : STD_LOGIC; 
  signal N6171 : STD_LOGIC; 
  signal CHOICE11409 : STD_LOGIC; 
  signal CHOICE11702 : STD_LOGIC; 
  signal N2489 : STD_LOGIC; 
  signal N2493 : STD_LOGIC; 
  signal CHOICE11385 : STD_LOGIC; 
  signal CHOICE11285 : STD_LOGIC; 
  signal CHOICE11236 : STD_LOGIC; 
  signal N6187 : STD_LOGIC; 
  signal N6169 : STD_LOGIC; 
  signal CHOICE11090 : STD_LOGIC; 
  signal CHOICE11520 : STD_LOGIC; 
  signal CHOICE11347 : STD_LOGIC; 
  signal CHOICE11242 : STD_LOGIC; 
  signal CHOICE11150 : STD_LOGIC; 
  signal exwb_buff_out_D11_5_1 : STD_LOGIC; 
  signal N6271 : STD_LOGIC; 
  signal CHOICE11332 : STD_LOGIC; 
  signal CHOICE11146 : STD_LOGIC; 
  signal CHOICE11126 : STD_LOGIC; 
  signal CHOICE12229 : STD_LOGIC; 
  signal CHOICE11483 : STD_LOGIC; 
  signal CHOICE12067 : STD_LOGIC; 
  signal N2788 : STD_LOGIC; 
  signal N2790 : STD_LOGIC; 
  signal CHOICE12052 : STD_LOGIC; 
  signal CHOICE11785 : STD_LOGIC; 
  signal CHOICE12218 : STD_LOGIC; 
  signal N6183 : STD_LOGIC; 
  signal CHOICE12323 : STD_LOGIC; 
  signal CHOICE11981 : STD_LOGIC; 
  signal CHOICE11578 : STD_LOGIC; 
  signal CHOICE12863 : STD_LOGIC; 
  signal CHOICE12232 : STD_LOGIC; 
  signal CHOICE12860 : STD_LOGIC; 
  signal CHOICE12728 : STD_LOGIC; 
  signal CHOICE12686 : STD_LOGIC; 
  signal N6307 : STD_LOGIC; 
  signal CHOICE12858 : STD_LOGIC; 
  signal CHOICE11891 : STD_LOGIC; 
  signal CHOICE12034 : STD_LOGIC; 
  signal CHOICE12443 : STD_LOGIC; 
  signal CHOICE12710 : STD_LOGIC; 
  signal CHOICE12722 : STD_LOGIC; 
  signal CHOICE12449 : STD_LOGIC; 
  signal N6130 : STD_LOGIC; 
  signal CHOICE12317 : STD_LOGIC; 
  signal CHOICE12306 : STD_LOGIC; 
  signal CHOICE11620 : STD_LOGIC; 
  signal CHOICE12563 : STD_LOGIC; 
  signal CHOICE12258 : STD_LOGIC; 
  signal CHOICE11863 : STD_LOGIC; 
  signal CHOICE11844 : STD_LOGIC; 
  signal CHOICE12804 : STD_LOGIC; 
  signal CHOICE12821 : STD_LOGIC; 
  signal CHOICE11588 : STD_LOGIC; 
  signal CHOICE12440 : STD_LOGIC; 
  signal CHOICE12560 : STD_LOGIC; 
  signal CHOICE11775 : STD_LOGIC; 
  signal CHOICE12755 : STD_LOGIC; 
  signal CHOICE12137 : STD_LOGIC; 
  signal CHOICE12591 : STD_LOGIC; 
  signal N6155 : STD_LOGIC; 
  signal N6319 : STD_LOGIC; 
  signal N6301 : STD_LOGIC; 
  signal CHOICE11630 : STD_LOGIC; 
  signal N6163 : STD_LOGIC; 
  signal CHOICE12166 : STD_LOGIC; 
  signal CHOICE12730 : STD_LOGIC; 
  signal CHOICE11940 : STD_LOGIC; 
  signal CHOICE12367 : STD_LOGIC; 
  signal CHOICE11852 : STD_LOGIC; 
  signal CHOICE12596 : STD_LOGIC; 
  signal CHOICE11634 : STD_LOGIC; 
  signal CHOICE11827 : STD_LOGIC; 
  signal CHOICE12654 : STD_LOGIC; 
  signal CHOICE12119 : STD_LOGIC; 
  signal CHOICE12672 : STD_LOGIC; 
  signal CHOICE11886 : STD_LOGIC; 
  signal CHOICE12846 : STD_LOGIC; 
  signal CHOICE11724 : STD_LOGIC; 
  signal exwb_buff_out_D22_6_1 : STD_LOGIC; 
  signal CHOICE12196 : STD_LOGIC; 
  signal CHOICE12707 : STD_LOGIC; 
  signal CHOICE12081 : STD_LOGIC; 
  signal CHOICE12620 : STD_LOGIC; 
  signal N6181 : STD_LOGIC; 
  signal CHOICE11599 : STD_LOGIC; 
  signal CHOICE12849 : STD_LOGIC; 
  signal CHOICE12264 : STD_LOGIC; 
  signal CHOICE11896 : STD_LOGIC; 
  signal CHOICE11995 : STD_LOGIC; 
  signal CHOICE12818 : STD_LOGIC; 
  signal CHOICE11778 : STD_LOGIC; 
  signal CHOICE12642 : STD_LOGIC; 
  signal CHOICE12392 : STD_LOGIC; 
  signal N6253 : STD_LOGIC; 
  signal CHOICE12104 : STD_LOGIC; 
  signal CHOICE12398 : STD_LOGIC; 
  signal CHOICE11752 : STD_LOGIC; 
  signal N6303 : STD_LOGIC; 
  signal CHOICE12844 : STD_LOGIC; 
  signal N6243 : STD_LOGIC; 
  signal CHOICE11603 : STD_LOGIC; 
  signal CHOICE12223 : STD_LOGIC; 
  signal CHOICE11854 : STD_LOGIC; 
  signal CHOICE12318 : STD_LOGIC; 
  signal CHOICE11629 : STD_LOGIC; 
  signal CHOICE12348 : STD_LOGIC; 
  signal CHOICE11784 : STD_LOGIC; 
  signal CHOICE12185 : STD_LOGIC; 
  signal CHOICE12629 : STD_LOGIC; 
  signal CHOICE11605 : STD_LOGIC; 
  signal N6299 : STD_LOGIC; 
  signal CHOICE12091 : STD_LOGIC; 
  signal CHOICE12691 : STD_LOGIC; 
  signal CHOICE11759 : STD_LOGIC; 
  signal N6247 : STD_LOGIC; 
  signal CHOICE12281 : STD_LOGIC; 
  signal CHOICE11834 : STD_LOGIC; 
  signal N6215 : STD_LOGIC; 
  signal CHOICE12373 : STD_LOGIC; 
  signal CHOICE12271 : STD_LOGIC; 
  signal CHOICE11945 : STD_LOGIC; 
  signal CHOICE12288 : STD_LOGIC; 
  signal CHOICE11742 : STD_LOGIC; 
  signal CHOICE11741 : STD_LOGIC; 
  signal CHOICE11782 : STD_LOGIC; 
  signal N6295 : STD_LOGIC; 
  signal CHOICE12725 : STD_LOGIC; 
  signal CHOICE12835 : STD_LOGIC; 
  signal CHOICE12582 : STD_LOGIC; 
  signal CHOICE11899 : STD_LOGIC; 
  signal CHOICE12334 : STD_LOGIC; 
  signal CHOICE11621 : STD_LOGIC; 
  signal CHOICE11961 : STD_LOGIC; 
  signal CHOICE12247 : STD_LOGIC; 
  signal CHOICE11816 : STD_LOGIC; 
  signal CHOICE11954 : STD_LOGIC; 
  signal N6179 : STD_LOGIC; 
  signal CHOICE12389 : STD_LOGIC; 
  signal N6191 : STD_LOGIC; 
  signal CHOICE11982 : STD_LOGIC; 
  signal CHOICE12147 : STD_LOGIC; 
  signal CHOICE12302 : STD_LOGIC; 
  signal CHOICE12342 : STD_LOGIC; 
  signal CHOICE12832 : STD_LOGIC; 
  signal CHOICE12676 : STD_LOGIC; 
  signal CHOICE12718 : STD_LOGIC; 
  signal CHOICE11979 : STD_LOGIC; 
  signal CHOICE11909 : STD_LOGIC; 
  signal CHOICE12203 : STD_LOGIC; 
  signal exwb_buff_out_R_A_1_1 : STD_LOGIC; 
  signal N6354 : STD_LOGIC; 
  signal N6355 : STD_LOGIC; 
  signal N6356 : STD_LOGIC; 
  signal N6357 : STD_LOGIC; 
  signal N6358 : STD_LOGIC; 
  signal N6359 : STD_LOGIC; 
  signal N6360 : STD_LOGIC; 
  signal N6361 : STD_LOGIC; 
  signal N6362 : STD_LOGIC; 
  signal N6363 : STD_LOGIC; 
  signal N6364 : STD_LOGIC; 
  signal N6365 : STD_LOGIC; 
  signal N6366 : STD_LOGIC; 
  signal N6367 : STD_LOGIC; 
  signal N6368 : STD_LOGIC; 
  signal N6369 : STD_LOGIC; 
  signal N6370 : STD_LOGIC; 
  signal N6371 : STD_LOGIC; 
  signal N6372 : STD_LOGIC; 
  signal N6373 : STD_LOGIC; 
  signal N6374 : STD_LOGIC; 
  signal N6375 : STD_LOGIC; 
  signal N6376 : STD_LOGIC; 
  signal N6377 : STD_LOGIC; 
  signal N6378 : STD_LOGIC; 
  signal N6379 : STD_LOGIC; 
  signal N6380 : STD_LOGIC; 
  signal N6381 : STD_LOGIC; 
  signal N6382 : STD_LOGIC; 
  signal N6383 : STD_LOGIC; 
  signal N6384 : STD_LOGIC; 
  signal N6385 : STD_LOGIC; 
  signal N6386 : STD_LOGIC; 
  signal N6387 : STD_LOGIC; 
  signal N6388 : STD_LOGIC; 
  signal N6389 : STD_LOGIC; 
  signal N6390 : STD_LOGIC; 
  signal N6391 : STD_LOGIC; 
  signal N6392 : STD_LOGIC; 
  signal N6393 : STD_LOGIC; 
  signal N6394 : STD_LOGIC; 
  signal N6395 : STD_LOGIC; 
  signal N6396 : STD_LOGIC; 
  signal N6397 : STD_LOGIC; 
  signal N6398 : STD_LOGIC; 
  signal N6399 : STD_LOGIC; 
  signal N6400 : STD_LOGIC; 
  signal N6401 : STD_LOGIC; 
  signal N6402 : STD_LOGIC; 
  signal N6403 : STD_LOGIC; 
  signal N6404 : STD_LOGIC; 
  signal N6405 : STD_LOGIC; 
  signal N6406 : STD_LOGIC; 
  signal N6407 : STD_LOGIC; 
  signal N6408 : STD_LOGIC; 
  signal N6409 : STD_LOGIC; 
  signal N6410 : STD_LOGIC; 
  signal N6411 : STD_LOGIC; 
  signal N6412 : STD_LOGIC; 
  signal N6413 : STD_LOGIC; 
  signal N6414 : STD_LOGIC; 
  signal N6415 : STD_LOGIC; 
  signal N6416 : STD_LOGIC; 
  signal N6417 : STD_LOGIC; 
  signal N6418 : STD_LOGIC; 
  signal N6419 : STD_LOGIC; 
  signal N6420 : STD_LOGIC; 
  signal N6421 : STD_LOGIC; 
  signal N6422 : STD_LOGIC; 
  signal N6423 : STD_LOGIC; 
  signal N6424 : STD_LOGIC; 
  signal N6425 : STD_LOGIC; 
  signal N6426 : STD_LOGIC; 
  signal N6427 : STD_LOGIC; 
  signal N6428 : STD_LOGIC; 
  signal N6429 : STD_LOGIC; 
  signal N6430 : STD_LOGIC; 
  signal N6431 : STD_LOGIC; 
  signal N6432 : STD_LOGIC; 
  signal N6433 : STD_LOGIC; 
  signal N6434 : STD_LOGIC; 
  signal N6435 : STD_LOGIC; 
  signal N6436 : STD_LOGIC; 
  signal N6437 : STD_LOGIC; 
  signal N6438 : STD_LOGIC; 
  signal N6439 : STD_LOGIC; 
  signal N6440 : STD_LOGIC; 
  signal N6441 : STD_LOGIC; 
  signal N6442 : STD_LOGIC; 
  signal N6443 : STD_LOGIC; 
  signal N6444 : STD_LOGIC; 
  signal N6445 : STD_LOGIC; 
  signal N6446 : STD_LOGIC; 
  signal N6447 : STD_LOGIC; 
  signal N6448 : STD_LOGIC; 
  signal N6449 : STD_LOGIC; 
  signal N6450 : STD_LOGIC; 
  signal N6451 : STD_LOGIC; 
  signal N6452 : STD_LOGIC; 
  signal N6453 : STD_LOGIC; 
  signal N6454 : STD_LOGIC; 
  signal N6455 : STD_LOGIC; 
  signal N6456 : STD_LOGIC; 
  signal N6457 : STD_LOGIC; 
  signal N6458 : STD_LOGIC; 
  signal N6459 : STD_LOGIC; 
  signal N6460 : STD_LOGIC; 
  signal N6461 : STD_LOGIC; 
  signal N6462 : STD_LOGIC; 
  signal N6463 : STD_LOGIC; 
  signal N6464 : STD_LOGIC; 
  signal N6465 : STD_LOGIC; 
  signal N6466 : STD_LOGIC; 
  signal N6467 : STD_LOGIC; 
  signal N6468 : STD_LOGIC; 
  signal N6469 : STD_LOGIC; 
  signal N6470 : STD_LOGIC; 
  signal N6471 : STD_LOGIC; 
  signal N6472 : STD_LOGIC; 
  signal N6473 : STD_LOGIC; 
  signal N6474 : STD_LOGIC; 
  signal N6475 : STD_LOGIC; 
  signal N6476 : STD_LOGIC; 
  signal N6477 : STD_LOGIC; 
  signal N6478 : STD_LOGIC; 
  signal N6479 : STD_LOGIC; 
  signal N6480 : STD_LOGIC; 
  signal N6481 : STD_LOGIC; 
  signal N6482 : STD_LOGIC; 
  signal N6483 : STD_LOGIC; 
  signal N6484 : STD_LOGIC; 
  signal N6485 : STD_LOGIC; 
  signal N6486 : STD_LOGIC; 
  signal N6487 : STD_LOGIC; 
  signal N6488 : STD_LOGIC; 
  signal N6489 : STD_LOGIC; 
  signal N6490 : STD_LOGIC; 
  signal N6491 : STD_LOGIC; 
  signal N6492 : STD_LOGIC; 
  signal N6493 : STD_LOGIC; 
  signal N6494 : STD_LOGIC; 
  signal N6495 : STD_LOGIC; 
  signal N6496 : STD_LOGIC; 
  signal N6497 : STD_LOGIC; 
  signal N6498 : STD_LOGIC; 
  signal N6499 : STD_LOGIC; 
  signal N6500 : STD_LOGIC; 
  signal N6501 : STD_LOGIC; 
  signal N6502 : STD_LOGIC; 
  signal N6503 : STD_LOGIC; 
  signal N6504 : STD_LOGIC; 
  signal N6505 : STD_LOGIC; 
  signal N6506 : STD_LOGIC; 
  signal N6507 : STD_LOGIC; 
  signal N6508 : STD_LOGIC; 
  signal N6509 : STD_LOGIC; 
  signal N6510 : STD_LOGIC; 
  signal N6511 : STD_LOGIC; 
  signal N6512 : STD_LOGIC; 
  signal N6513 : STD_LOGIC; 
  signal N6514 : STD_LOGIC; 
  signal N6515 : STD_LOGIC; 
  signal N6516 : STD_LOGIC; 
  signal N6517 : STD_LOGIC; 
  signal N6518 : STD_LOGIC; 
  signal N6519 : STD_LOGIC; 
  signal N6520 : STD_LOGIC; 
  signal N6521 : STD_LOGIC; 
  signal N6522 : STD_LOGIC; 
  signal N6523 : STD_LOGIC; 
  signal N6524 : STD_LOGIC; 
  signal N6525 : STD_LOGIC; 
  signal N6526 : STD_LOGIC; 
  signal N6527 : STD_LOGIC; 
  signal N6528 : STD_LOGIC; 
  signal N6529 : STD_LOGIC; 
  signal N6530 : STD_LOGIC; 
  signal exe_stage_alu_m_n043342_O : STD_LOGIC; 
  signal Eq_stagelut_O : STD_LOGIC; 
  signal Eq_stagelut1_O : STD_LOGIC; 
  signal Eq_stagelut2_O : STD_LOGIC; 
  signal Eq_stagelut3_O : STD_LOGIC; 
  signal Eq_stagelut4_O : STD_LOGIC; 
  signal Eq_stagelut5_O : STD_LOGIC; 
  signal Eq_stagelut6_O : STD_LOGIC; 
  signal Eq_stagelut7_O : STD_LOGIC; 
  signal Eq_stagelut8_O : STD_LOGIC; 
  signal Eq_stagelut9_O : STD_LOGIC; 
  signal Eq_stagelut10_O : STD_LOGIC; 
  signal Eq_stagelut11_O : STD_LOGIC; 
  signal Eq_stagelut12_O : STD_LOGIC; 
  signal Eq_stagelut13_O : STD_LOGIC; 
  signal Eq_stagelut14_O : STD_LOGIC; 
  signal Eq_stagelut15_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044543_G_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043942_G_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043642_G_O : STD_LOGIC; 
  signal exe_stage_alu_m_n00201_SW0_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043015_O : STD_LOGIC; 
  signal exe_stage_alu_m_n0464150_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043078_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_6_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0028_0_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alulut6_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0037_0_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0046_0_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044243_G_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_1_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_2_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_3_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_4_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_5_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_6_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0010_0_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alulut5_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_2_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_3_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_4_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_5_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_alu_n0019_0_lut_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043312_SW1_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044743_G_O : STD_LOGIC; 
  signal exe_stage_alu_m_n0454197_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044943_G_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044543_F_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043942_F_O : STD_LOGIC; 
  signal exe_stage_alu_m_n043642_F_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044243_F_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044743_F_O : STD_LOGIC; 
  signal exe_stage_alu_m_n044943_F_O : STD_LOGIC; 
  signal int0_IBUF : STD_LOGIC; 
  signal int1_IBUF : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_255_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_254_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_253_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_252_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_251_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_250_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_249_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_248_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_192_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_247_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_246_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_245_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_244_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_243_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_242_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_241_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_240_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_239_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_238_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_237_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_236_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_64_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_65_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_66_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_67_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_68_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_69_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_70_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_71_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_235_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_234_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_233_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_232_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_72_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_73_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_74_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_75_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_76_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_77_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_78_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_79_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_80_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_81_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_82_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_83_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_84_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_85_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_86_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_87_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_193_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_199_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_198_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_231_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_230_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_229_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_88_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_89_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_90_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_91_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_92_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_93_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_94_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_95_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_228_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_227_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_226_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_225_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_224_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_96_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_97_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_98_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_99_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_100_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_101_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_102_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_103_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_197_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_196_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_104_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_105_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_106_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_107_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_108_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_109_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_110_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_111_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_195_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_194_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_223_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_222_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_112_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_113_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_114_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_115_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_116_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_117_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_118_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_119_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_221_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_220_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_219_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_218_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_217_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_216_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_120_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_121_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_122_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_123_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_124_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_125_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_126_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram0_inst_ramx_127_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_215_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_214_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_213_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_212_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_211_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_210_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_209_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_208_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_207_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_206_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_205_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_204_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_203_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_202_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_201_SPO : STD_LOGIC; 
  signal mem_internal_ram_bank_Mram_iram1_inst_ramx_200_SPO : STD_LOGIC; 
  signal Clock_BUFGP_IBUFG : STD_LOGIC; 
  signal GSR : STD_LOGIC; 
  signal exwb_buff_out_D11_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_Opcode_3_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_13_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_4_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_6_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_14_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_12_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_11_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_5_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_3_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_7_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_0_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_1_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_2_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_3_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_4_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_5_GSR_OR : STD_LOGIC; 
  signal ifid_buff_out1_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_7_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_7_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_Opcode_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_7_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_7_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_sel_mux11_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_en_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_7_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_7_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_en_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_2_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_3_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s2_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_2_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_3_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_s1_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_2_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_3_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d2_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_2_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_3_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_d1_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_2_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_3_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_B_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_2_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_3_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_4_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_5_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_A_6_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_Opcode_0_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_Opcode_1_GSR_OR : STD_LOGIC; 
  signal idex_buff_out_Opcode_2_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_7_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_10_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_9_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_8_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_15_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_0_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_1_GSR_OR : STD_LOGIC; 
  signal fet_stage_PC_M_data_out_2_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_1_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_6_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_4_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_1_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_0_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_7_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_6_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_5_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_4_GSR_OR : STD_LOGIC; 
  signal mem_PSW_psw_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_port_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P3_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_port_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P2_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_port_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P1_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_port_out_6_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_P0_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_DPL_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_DPH_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_B_data_out_5_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_7_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_0_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_1_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_2_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_3_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_4_GSR_OR : STD_LOGIC; 
  signal mem_R_A_data_out_5_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_2_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_3_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_0_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_2_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_6_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_6_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_5_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_3_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_2_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_4_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_1_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_0_GSR_OR : STD_LOGIC; 
  signal rom_DATA_BUS_7_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_3_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_2_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_0_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_6_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_3_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_2_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_0_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_6_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_5_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_4_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_en_0_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_5_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_5_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_4_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_4_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_3_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_7_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_en_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_5_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_0_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_7_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_B_0_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_7_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_6_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_sel_mux11_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_7_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_6_1_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_7_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_1_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_6_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_4_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_2_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_3_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_5_GSR_OR : STD_LOGIC; 
  signal fet_stage_que_state_M_out1_0_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_6_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_4_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_0_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D11_5_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_D22_4_1_GSR_OR : STD_LOGIC; 
  signal exwb_buff_out_R_A_1_1_GSR_OR : STD_LOGIC; 
  signal port3_out_1_OBUF_GTS_TRI : STD_LOGIC; 
  signal GTS : STD_LOGIC; 
  signal port2_out_0_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_3_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_4_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_5_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_6_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_4_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_7_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_0_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_6_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_1_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_7_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_2_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_1_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_3_OBUF_GTS_TRI : STD_LOGIC; 
  signal port2_out_2_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_5_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_4_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_2_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_5_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_0_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_6_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_3_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_2_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_5_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_4_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_7_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_0_OBUF_GTS_TRI : STD_LOGIC; 
  signal port0_out_1_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_6_OBUF_GTS_TRI : STD_LOGIC; 
  signal port1_out_7_OBUF_GTS_TRI : STD_LOGIC; 
  signal port3_out_3_OBUF_GTS_TRI : STD_LOGIC; 
  signal VCC : STD_LOGIC; 
  signal GND : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_6_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_6_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_6_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_6_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_7_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_0_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_1_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_2_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_3_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_4_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPL_data_out_5_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_7_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_0_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_1_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_2_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_3_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_4_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_DPH_data_out_5_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_7_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_0_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_1_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_2_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_3_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_4_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_B_data_out_5_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_7_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_0_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_1_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_2_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_3_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_4_C : STD_LOGIC; 
  signal NlwInverterSignal_mem_R_A_data_out_5_C : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_31_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_30_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_29_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_28_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_27_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_26_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_25_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_24_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_23_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_22_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_21_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_20_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_19_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_18_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_17_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_16_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_15_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_14_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_13_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_12_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_11_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_10_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_9_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_8_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_7_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_6_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_5_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_4_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_3_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_2_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_1_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_0_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_3_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_2_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_1_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_0_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_31_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_30_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_29_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_28_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_27_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_26_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_25_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_24_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_23_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_22_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_21_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_20_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_19_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_18_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_17_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_16_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_15_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_14_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_13_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_12_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_11_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_10_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_9_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_8_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_3_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_2_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_1_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_0_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_31_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_30_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_29_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_28_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_27_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_26_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_25_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_24_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_23_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_22_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_21_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_20_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_19_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_18_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_17_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_16_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_15_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_14_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_13_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_12_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_11_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_10_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_9_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_8_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_7_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_6_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_5_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_4_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_3_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_2_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_1_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_0_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_3_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_2_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_1_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_0_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_31_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_30_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_29_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_28_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_27_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_26_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_25_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_24_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_23_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_22_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_21_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_20_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_19_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_18_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_17_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_16_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_15_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_14_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_13_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_12_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_11_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_10_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_9_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_8_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_3_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_2_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_1_UNCONNECTED : STD_LOGIC; 
  signal NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_0_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_35_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_34_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_33_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_32_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_31_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_30_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_29_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_28_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_27_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_26_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_25_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_24_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_23_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_22_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_21_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_20_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_19_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_18_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_17_UNCONNECTED : STD_LOGIC; 
  signal NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_16_UNCONNECTED : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_1_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_0_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_3_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_4_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_5_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_6_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_4_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_7_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_0_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_6_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_1_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_7_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_2_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_1_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_3_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port2_out_2_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_5_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_4_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_2_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_5_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_0_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_6_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_3_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_2_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_5_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_4_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_7_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_0_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port0_out_1_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_6_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port1_out_7_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal NlwInverterSignal_port3_out_3_OBUF_GTS_TRI_CTL : STD_LOGIC; 
  signal write_addr1_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_alu_m_n0298 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal exe_stage_alu_m_n0217 : STD_LOGIC_VECTOR ( 3 downto 0 ); 
  signal exe_stage_alu_m_n0064 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal mem_R_DPH_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal rom_DATA_BUS : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exwb_buff_out_D11 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal write_addr0_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_DPL_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exwb_buff_out_R_A : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exwb_buff_out_R_B : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal cu_n0023 : STD_LOGIC_VECTOR ( 2 downto 0 ); 
  signal ifid_buff_out1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal wb_stage_din_rid : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_PSW_psw : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_P3_port_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_d1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal addressbus_from_fetch : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal alu_op_from_decode : STD_LOGIC_VECTOR ( 4 downto 0 ); 
  signal exwb_buff_out_D22 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal r_aa_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal d2_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal r_bb_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal s1_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_n0019 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_out3 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_out2 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_out1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal d1_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_s2 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_s1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_d2 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_B : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_A : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_sel_mux11 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal RA_out_from_execute : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal ifid_buff_out2 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal p3_in_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal p1_in_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal wb_stage_addr_rid : STD_LOGIC_VECTOR ( 2 downto 0 ); 
  signal di_A_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_P2_port_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal r_addr0_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_PC_M_data_out : STD_LOGIC_VECTOR ( 15 downto 0 ); 
  signal databus_from_mux19 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal write_data1_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal write_data0_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal cu_sel_jcall : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal mem_R_P1_port_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal pc_out_from_mem : STD_LOGIC_VECTOR ( 15 downto 8 ); 
  signal mem_R_P0_port_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal r0_from_mem : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal r1_from_mem : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal cu_sel_mux6 : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal mem_R_P1_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_P3_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_P0_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_P2_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_A_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal ifid_buff_out3 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal s2_from_decode : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal iqc_from_fetch : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal cu_EN_latch : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal cu_n0017 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal idex_buff_out_Opcode : STD_LOGIC_VECTOR ( 4 downto 0 ); 
  signal p2_in_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal RB_out_from_execute : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal p0_in_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal idex_buff_out_en : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal di_B_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal di_DPL_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal di_DPH_from_writeback : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exwb_buff_out_sel_mux11 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal cu_sel_mux12 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal exwb_buff_out_en : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal cu_sel_mux4 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal cu_sel_mux5 : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal cu_n0015 : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal cu_n0020 : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal wb_stage_n0069 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_n0023 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_R_B_data_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal cu_sel_mux8 : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal cu_sel_mux9 : STD_LOGIC_VECTOR ( 2 downto 0 ); 
  signal sp_out_from_mem : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal exe_stage_src1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_src2 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_alu_m_n0293 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal exe_stage_alu_m_n0055 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal fet_stage_source_PC : STD_LOGIC_VECTOR ( 15 downto 1 ); 
  signal exe_stage_alu_m_n0153 : STD_LOGIC_VECTOR ( 7 downto 5 ); 
  signal exe_stage_alu_m_n0028 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal exe_stage_alu_m_n0296 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal exe_stage_alu_m_n0297 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal exe_stage_alu_m_n0008 : STD_LOGIC_VECTOR ( 15 downto 0 ); 
  signal exe_stage_alu_m_n0216 : STD_LOGIC_VECTOR ( 7 downto 2 ); 
  signal fet_stage_next_PC : STD_LOGIC_VECTOR ( 15 downto 0 ); 
  signal wb_stage_n0068 : STD_LOGIC_VECTOR ( 2 downto 0 ); 
  signal fet_stage_Temp1_data : STD_LOGIC_VECTOR ( 12 downto 12 ); 
  signal exe_stage_alu_m_n0019 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal fet_stage_JCall_out : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal dec_stage_mux7_to_mux8_mux9 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal dec_stage_reg_indirect_to_mux6 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal dec_stage_bit_number_dec_to_mux9 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_alu_m_n0295 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal fet_stage_que_state_M_n0022 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_d_in1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_alu_m_n0037 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal mem_w_addr_b1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_que_byte1 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_alu_m_n0046 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal exe_stage_alu_m_n0299 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal exe_stage_alu_m_n0005 : STD_LOGIC_VECTOR ( 3 downto 0 ); 
  signal fet_stage_que_state_M_que_byte2 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal mem_d_in0 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal rom_n0003 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal wb_stage_n0184 : STD_LOGIC_VECTOR ( 6 downto 6 ); 
  signal mem_w_addr_b0 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal fet_stage_que_state_M_next_Mcode : STD_LOGIC_VECTOR ( 2 downto 2 ); 
  signal cu_n0022 : STD_LOGIC_VECTOR ( 1 downto 0 ); 
  signal cu_n0321 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal cu_n0018 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal exe_stage_alu_m_n0010 : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal exe_stage_alu_m_n0000 : STD_LOGIC_VECTOR ( 3 downto 1 ); 
  signal exe_stage_alu_m_n0165 : STD_LOGIC_VECTOR ( 4 downto 1 ); 
  signal wb_stage_n0183 : STD_LOGIC_VECTOR ( 7 downto 7 ); 
  signal cu_n0028 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal mem_PSW_Mxor_n0011_Xo : STD_LOGIC_VECTOR ( 5 downto 4 ); 
  signal cu_n0019 : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal exe_stage_alu_m_n0218 : STD_LOGIC_VECTOR ( 2 downto 0 ); 
  signal exe_stage_alu_m_Madd_n0166_Mxor_Result_1_Xo : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal exe_stage_alu_m_n0311 : STD_LOGIC_VECTOR ( 7 downto 1 ); 
  signal exe_stage_alu_m_n0073 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal exe_stage_alu_m_n0003 : STD_LOGIC_VECTOR ( 4 downto 0 ); 
  signal exe_stage_alu_m_n0167 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal exe_stage_alu_m_n0002 : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal exe_stage_alu_m_n0166 : STD_LOGIC_VECTOR ( 3 downto 3 ); 
  signal exe_stage_alu_m_n0214 : STD_LOGIC_VECTOR ( 2 downto 1 ); 
  signal exe_stage_alu_m_Madd_n0001_Mxor_Result_1_Xo : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal exe_stage_alu_m_Madd_n0214_n0013 : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal exe_stage_alu_m_n0001 : STD_LOGIC_VECTOR ( 3 downto 3 ); 
  signal exe_stage_alu_m_Madd_n0214_Mxor_Result_3_Xo : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal exe_stage_alu_m_n0215 : STD_LOGIC_VECTOR ( 0 downto 0 ); 
begin
  wb_stage_p3_in_2_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(2),
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(2)
    );
  dec_stage_d_reg_indirect_dec_out1_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(6),
      ADR2 => r1_from_mem(6),
      O => dec_stage_reg_indirect_to_mux6(6)
    );
  wb_stage_load_rid1 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_N38,
      ADR2 => wb_stage_n0184(6),
      ADR3 => wb_stage_N72,
      O => load_rid_from_writeback
    );
  port0_out_0_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(0),
      O => port0_out_0_OBUF_GTS_TRI
    );
  exwb_buff_out_D11_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(5),
      RST => exwb_buff_out_D11_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(5),
      CE => VCC,
      SET => GND
    );
  wb_stage_Ker121 : X_LUT3
    generic map(
      INIT => X"7F"
    )
    port map (
      ADR0 => wb_stage_N78,
      ADR1 => wb_stage_n0184(6),
      ADR2 => exwb_buff_out_D22(5),
      O => wb_stage_N12
    );
  ifid_buff_out2_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(6),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(6),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  idex_buff_out_Opcode_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => alu_op_from_decode(3),
      RST => idex_buff_out_Opcode_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_Opcode(3),
      CE => VCC,
      SET => GND
    );
  rom_Mrom_n0002_inst_lut4_1521 : X_LUT4
    generic map(
      INIT => X"B6DB"
    )
    port map (
      ADR0 => addressbus_from_fetch(2),
      ADR1 => addressbus_from_fetch(3),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(1),
      O => rom_Mrom_n0002_inst_lut4_152
    );
  cu_Ker18 : X_LUT4
    generic map(
      INIT => X"EEFE"
    )
    port map (
      ADR0 => N83,
      ADR1 => Reset_IBUF,
      ADR2 => cu_N22,
      ADR3 => ifid_buff_out1(7),
      O => cu_N18
    );
  mux19_databus_out1_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(6),
      O => databus_from_mux19(6)
    );
  fet_stage_source_PC_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(5),
      ADR2 => fet_stage_JCall_out(5),
      O => fet_stage_source_PC(5)
    );
  fet_stage_PC_M_data_out_13 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(13),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_13_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(13),
      SET => GND
    );
  exe_stage_alu_m_alu_n0217_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0217_0_cyo,
      I1 => exe_stage_alu_m_N104,
      O => exe_stage_alu_m_n0217(1)
    );
  fet_stage_PC_M_data_out_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(4),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(4),
      SET => GND
    );
  wb_stage_p0_in_0_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(0),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(0),
      ADR3 => N824,
      O => p0_in_from_writeback(0)
    );
  exe_stage_alu_m_des_cy60 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => CHOICE12006,
      ADR1 => mem_PSW_psw(7),
      ADR2 => exe_stage_alu_m_n0220,
      ADR3 => exe_stage_alu_m_alu_n0216_7_cyo,
      O => CHOICE12008
    );
  fet_stage_PC_M_data_out_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(6),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(6),
      SET => GND
    );
  fet_stage_PC_M_data_out_14 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(14),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_14_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(14),
      SET => GND
    );
  datapath_fet_stage_next_PC_15_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_14_cyo,
      I1 => fet_stage_source_PC(15),
      O => fet_stage_next_PC(15)
    );
  wb_stage_di_B_0_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(0),
      ADR2 => exwb_buff_out_R_A(0),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(0)
    );
  fet_stage_PC_M_data_out_12 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(12),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_12_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(12),
      SET => GND
    );
  wb_stage_di_B_2_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(2),
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(2)
    );
  rom_Mrom_n0002_inst_mux_f7_21_SW0 : X_LUT4
    generic map(
      INIT => X"E4FF"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(6),
      ADR2 => fet_stage_PC_M_data_out(6),
      ADR3 => addressbus_from_fetch(0),
      O => N6211
    );
  wb_stage_di_B_4_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(4),
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(4)
    );
  wb_stage_di_B_6_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(6)
    );
  wb_stage_addr_rid_2 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0068(2),
      CLK => wb_stage_n0190,
      O => wb_stage_addr_rid(2),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_n0069_0_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out24,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(0),
      ADR3 => wb_stage_N72,
      O => CHOICE11120
    );
  wb_stage_Ker731 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => exwb_buff_out_D22(1),
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D22(6),
      O => wb_stage_N73
    );
  wb_stage_n00611 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => wb_stage_N58,
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_D11(4),
      O => W_A_from_writeback
    );
  dec_stage_d_reg_indirect_dec_out1_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(5),
      ADR2 => r1_from_mem(5),
      O => dec_stage_reg_indirect_to_mux6(5)
    );
  dec_stage_d_reg_indirect_dec_out1_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(4),
      ADR2 => r1_from_mem(4),
      O => dec_stage_reg_indirect_to_mux6(4)
    );
  dec_stage_d_reg_indirect_dec_out1_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(3),
      ADR2 => r1_from_mem(3),
      O => dec_stage_reg_indirect_to_mux6(3)
    );
  dec_stage_d_reg_indirect_dec_out1_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(2),
      ADR2 => r1_from_mem(2),
      O => dec_stage_reg_indirect_to_mux6(2)
    );
  dec_stage_d_reg_indirect_dec_out1_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(1),
      ADR2 => r1_from_mem(1),
      O => dec_stage_reg_indirect_to_mux6(1)
    );
  dec_stage_d_reg_indirect_dec_out1_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(7),
      ADR2 => r1_from_mem(7),
      O => dec_stage_reg_indirect_to_mux6(7)
    );
  dec_stage_d_reg_indirect_dec_out1_0_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(0),
      ADR2 => r1_from_mem(0),
      O => dec_stage_reg_indirect_to_mux6(0)
    );
  dec_stage_d_mux9_out1_1_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12367,
      ADR2 => CHOICE12389,
      ADR3 => CHOICE12373,
      O => r_bb_from_decode(1)
    );
  dec_stage_d_mux9_out1_2_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12342,
      ADR2 => CHOICE12364,
      ADR3 => CHOICE12348,
      O => r_bb_from_decode(2)
    );
  dec_stage_d_mux9_out1_3_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12392,
      ADR2 => CHOICE12414,
      ADR3 => CHOICE12398,
      O => r_bb_from_decode(3)
    );
  dec_stage_d_mux9_out1_4_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12443,
      ADR2 => CHOICE12465,
      ADR3 => CHOICE12449,
      O => r_bb_from_decode(4)
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_561 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(2),
      O => dec_stage_bit_number_dec_to_mux9(7)
    );
  fet_stage_PC_M_data_out_11 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(11),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_11_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(11),
      SET => GND
    );
  port0_out_4_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(4),
      O => port0_out_4_OBUF_GTS_TRI
    );
  dec_stage_d_mux9_out1_0_199 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12418,
      ADR2 => CHOICE12440,
      ADR3 => CHOICE12424,
      O => r_bb_from_decode(0)
    );
  dec_stage_d_instruction_decoder_Ker48 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(3),
      ADR3 => N834,
      O => dec_stage_d_instruction_decoder_N48
    );
  fet_stage_PC_M_data_out_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(5),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(5),
      SET => GND
    );
  dec_stage_d_mux7_Ker121 : X_LUT3
    generic map(
      INIT => X"01"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => ifid_buff_out2(6),
      ADR2 => ifid_buff_out2(4),
      O => dec_stage_d_mux7_N12
    );
  fet_stage_PC_M_data_out_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(3),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(3),
      SET => GND
    );
  XST_GND : X_ZERO
    port map (
      O => fet_stage_Temp1_data(12)
    );
  XST_VCC : X_ONE
    port map (
      O => sp_out_from_mem(0)
    );
  port1_out_3_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(3),
      O => port1_out_3_OBUF_GTS_TRI
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_161 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(2),
      O => dec_stage_bit_number_dec_to_mux9(2)
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_81 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(2),
      O => dec_stage_bit_number_dec_to_mux9(1)
    );
  Eq_stagecy_rn_6 : X_MUX2
    port map (
      IB => Eq_stage_cyo5,
      IA => fet_stage_Temp1_data(12),
      SEL => N37,
      O => exe_stage_Forwarder_m_n0002
    );
  Eq_stagecy_rn_2 : X_MUX2
    port map (
      IB => Eq_stage_cyo2,
      IA => fet_stage_Temp1_data(12),
      SEL => N33,
      O => exe_stage_Forwarder_m_n0003
    );
  Eq_stagecy_rn_10 : X_MUX2
    port map (
      IB => Eq_stage_cyo8,
      IA => fet_stage_Temp1_data(12),
      SEL => N41,
      O => exe_stage_Forwarder_m_n0005
    );
  Eq_stagecy_rn_14 : X_MUX2
    port map (
      IB => Eq_stage_cyo11,
      IA => fet_stage_Temp1_data(12),
      SEL => N45,
      O => exe_stage_Forwarder_m_n0006
    );
  dec_stage_d_mux9_out1_5_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12468,
      ADR2 => CHOICE12490,
      ADR3 => CHOICE12474,
      O => r_bb_from_decode(5)
    );
  port1_out_2_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(2),
      O => port1_out_2_OBUF_GTS_TRI
    );
  ifid_buff_out1_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(7),
      RST => ifid_buff_out1_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(7),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out2_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(7),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(7),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(7),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(7),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out1_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(0),
      RST => ifid_buff_out1_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(0),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out1_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(1),
      RST => ifid_buff_out1_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(1),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out1_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(2),
      RST => ifid_buff_out1_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(2),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out1_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(3),
      RST => ifid_buff_out1_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(3),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out1_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(4),
      RST => ifid_buff_out1_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(4),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out1_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(5),
      RST => ifid_buff_out1_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(5),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out1_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out1(6),
      RST => ifid_buff_out1_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => ifid_buff_out1(6),
      CE => VCC,
      SET => GND
    );
  ifid_buff_out3_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(0),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(0),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(1),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(1),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(2),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(2),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(3),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(3),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(4),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(4),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(5),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(5),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out3_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out3(6),
      CLK => Clock_BUFGP,
      O => ifid_buff_out3(6),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out2_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(0),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(0),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out2_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(1),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(1),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out2_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(2),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(2),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out2_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(3),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(3),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out2_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(4),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(4),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  ifid_buff_out2_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_out2(5),
      CLK => Clock_BUFGP,
      O => ifid_buff_out2(5),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  idex_buff_out_A_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(7),
      RST => idex_buff_out_A_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(7),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(7),
      RST => idex_buff_out_B_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(7),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_Opcode_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => alu_op_from_decode(4),
      RST => idex_buff_out_Opcode_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_Opcode(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(7),
      RST => idex_buff_out_d1_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(7),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(7),
      RST => idex_buff_out_d2_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(7),
      CE => VCC,
      SET => GND
    );
  dec_stage_d_mux9_out1_6_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12518,
      ADR2 => CHOICE12540,
      ADR3 => CHOICE12524,
      O => r_bb_from_decode(6)
    );
  idex_buff_out_sel_mux11_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => sp_out_from_mem(0),
      RST => idex_buff_out_sel_mux11_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_sel_mux11(1),
      CE => VCC,
      SET => GND
    );
  mem_PSW_n00101_G : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => wb_stage_n0183(7),
      O => N6355
    );
  idex_buff_out_en_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_EN_latch(1),
      RST => idex_buff_out_en_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_en(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(7),
      RST => idex_buff_out_s1_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(7),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(7),
      RST => idex_buff_out_s2_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(7),
      CE => VCC,
      SET => GND
    );
  dec_stage_d_mux9_out1_7_194 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => cu_sel_mux9(0),
      ADR1 => CHOICE12493,
      ADR2 => CHOICE12515,
      ADR3 => CHOICE12499,
      O => r_bb_from_decode(7)
    );
  idex_buff_out_en_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_EN_latch(0),
      RST => idex_buff_out_en_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_en(0),
      CE => VCC,
      SET => GND
    );
  dec_stage_d_mux7_Ker0 : X_LUT4
    generic map(
      INIT => X"E4FF"
    )
    port map (
      ADR0 => N923,
      ADR1 => ifid_buff_out2(6),
      ADR2 => dec_stage_d_mux7_N10,
      ADR3 => dec_stage_d_mux7_n0000,
      O => dec_stage_d_mux7_N0
    );
  idex_buff_out_s2_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(0),
      RST => idex_buff_out_s2_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(1),
      RST => idex_buff_out_s2_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(2),
      RST => idex_buff_out_s2_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(2),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(3),
      RST => idex_buff_out_s2_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(3),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(4),
      RST => idex_buff_out_s2_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(5),
      RST => idex_buff_out_s2_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(5),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s2_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s2_from_decode(6),
      RST => idex_buff_out_s2_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s2(6),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(0),
      RST => idex_buff_out_s1_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(1),
      RST => idex_buff_out_s1_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(2),
      RST => idex_buff_out_s1_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(2),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(3),
      RST => idex_buff_out_s1_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(3),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(4),
      RST => idex_buff_out_s1_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(5),
      RST => idex_buff_out_s1_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(5),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_s1_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => s1_from_decode(6),
      RST => idex_buff_out_s1_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_s1(6),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(0),
      RST => idex_buff_out_d2_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(1),
      RST => idex_buff_out_d2_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(2),
      RST => idex_buff_out_d2_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(2),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(3),
      RST => idex_buff_out_d2_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(3),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(4),
      RST => idex_buff_out_d2_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(5),
      RST => idex_buff_out_d2_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(5),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d2_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d2_from_decode(6),
      RST => idex_buff_out_d2_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d2(6),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(0),
      RST => idex_buff_out_d1_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(1),
      RST => idex_buff_out_d1_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(2),
      RST => idex_buff_out_d1_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(2),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(3),
      RST => idex_buff_out_d1_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(3),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(4),
      RST => idex_buff_out_d1_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(5),
      RST => idex_buff_out_d1_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(5),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_d1_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => d1_from_decode(6),
      RST => idex_buff_out_d1_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_d1(6),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(0),
      RST => idex_buff_out_B_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(1),
      RST => idex_buff_out_B_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(2),
      RST => idex_buff_out_B_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(2),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(3),
      RST => idex_buff_out_B_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(3),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(4),
      RST => idex_buff_out_B_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(5),
      RST => idex_buff_out_B_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(5),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_B_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_bb_from_decode(6),
      RST => idex_buff_out_B_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_B(6),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(0),
      RST => idex_buff_out_A_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(1),
      RST => idex_buff_out_A_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(2),
      RST => idex_buff_out_A_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(2),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(3),
      RST => idex_buff_out_A_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(3),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(4),
      RST => idex_buff_out_A_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(4),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(5),
      RST => idex_buff_out_A_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(5),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_A_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => r_aa_from_decode(6),
      RST => idex_buff_out_A_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_A(6),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_Opcode_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => alu_op_from_decode(0),
      RST => idex_buff_out_Opcode_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_Opcode(0),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_Opcode_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => alu_op_from_decode(1),
      RST => idex_buff_out_Opcode_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_Opcode(1),
      CE => VCC,
      SET => GND
    );
  idex_buff_out_Opcode_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => alu_op_from_decode(2),
      RST => idex_buff_out_Opcode_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => idex_buff_out_Opcode(2),
      CE => VCC,
      SET => GND
    );
  fet_stage_PC_M_data_out_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(7),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(7),
      SET => GND
    );
  fet_stage_PC_M_data_out_10 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(10),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_10_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(10),
      SET => GND
    );
  fet_stage_PC_M_data_out_9 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(9),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_9_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(9),
      SET => GND
    );
  fet_stage_PC_M_data_out_8 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(8),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_8_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(8),
      SET => GND
    );
  fet_stage_PC_M_data_out_15 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(15),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_15_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(15),
      SET => GND
    );
  fet_stage_PC_M_data_out_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(0),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(0),
      SET => GND
    );
  fet_stage_PC_M_data_out_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(1),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(1),
      SET => GND
    );
  fet_stage_PC_M_data_out_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_next_PC(2),
      CE => cu_PC_load_in,
      RST => fet_stage_PC_M_data_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_PC_M_data_out(2),
      SET => GND
    );
  wb_stage_Ker281 : X_LUT4
    generic map(
      INIT => X"FF8F"
    )
    port map (
      ADR0 => wb_stage_n0150,
      ADR1 => wb_stage_N71,
      ADR2 => wb_stage_n0184(6),
      ADR3 => exwb_buff_out_D22(0),
      O => wb_stage_N28
    );
  port1_out_1_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(1),
      O => port1_out_1_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_n00001 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out2(7),
      ADR1 => ifid_buff_out2(2),
      ADR2 => ifid_buff_out2(3),
      O => dec_stage_d_mux7_n0000
    );
  port1_out_0_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(0),
      O => port1_out_0_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_0_152 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12248,
      ADR2 => CHOICE12236,
      ADR3 => CHOICE12267,
      O => dec_stage_mux7_to_mux8_mux9(0)
    );
  port2_out_7_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(7),
      O => port2_out_7_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_Ker101 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => ifid_buff_out2(0),
      ADR1 => ifid_buff_out2(1),
      O => dec_stage_d_mux7_N10
    );
  port2_out_6_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(6),
      O => port2_out_6_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_2_152 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12283,
      ADR2 => CHOICE12271,
      ADR3 => CHOICE12302,
      O => dec_stage_mux7_to_mux8_mux9(2)
    );
  port2_out_5_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(5),
      O => port2_out_5_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_3_143 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12081,
      ADR2 => CHOICE12071,
      ADR3 => CHOICE12100,
      O => dec_stage_mux7_to_mux8_mux9(3)
    );
  port2_out_4_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(4),
      O => port2_out_4_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_4_143 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12147,
      ADR2 => CHOICE12137,
      ADR3 => CHOICE12166,
      O => dec_stage_mux7_to_mux8_mux9(4)
    );
  port2_out_3_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(3),
      O => port2_out_3_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_5_143 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12114,
      ADR2 => CHOICE12104,
      ADR3 => CHOICE12133,
      O => dec_stage_mux7_to_mux8_mux9(5)
    );
  port2_out_2_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(2),
      O => port2_out_2_OBUF_GTS_TRI
    );
  fet_stage_source_PC_9_Q : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(9),
      ADR2 => N905,
      O => fet_stage_source_PC(9)
    );
  fet_stage_source_PC_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(6),
      ADR2 => fet_stage_JCall_out(6),
      O => fet_stage_source_PC(6)
    );
  fet_stage_source_PC_8_Q : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(8),
      ADR2 => N910,
      O => fet_stage_source_PC(8)
    );
  fet_stage_source_PC_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(7),
      ADR2 => fet_stage_JCall_out(7),
      O => fet_stage_source_PC(7)
    );
  dec_stage_d_mux7_out1_6_143 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12180,
      ADR2 => CHOICE12170,
      ADR3 => CHOICE12199,
      O => dec_stage_mux7_to_mux8_mux9(6)
    );
  port2_out_1_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(1),
      O => port2_out_1_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_7_143 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12213,
      ADR2 => CHOICE12203,
      ADR3 => CHOICE12232,
      O => dec_stage_mux7_to_mux8_mux9(7)
    );
  port2_out_0_OBUF : X_BUF
    port map (
      I => mem_R_P2_port_out(0),
      O => port2_out_0_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_out1_1_152 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_n0000,
      ADR1 => CHOICE12318,
      ADR2 => CHOICE12306,
      ADR3 => CHOICE12337,
      O => dec_stage_mux7_to_mux8_mux9(1)
    );
  port3_out_7_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(7),
      O => port3_out_7_OBUF_GTS_TRI
    );
  dec_stage_d_mux7_Ker131 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => ifid_buff_out2(0),
      ADR2 => ifid_buff_out2(1),
      ADR3 => ifid_buff_out2(4),
      O => dec_stage_d_mux7_N13
    );
  port3_out_6_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(6),
      O => port3_out_6_OBUF_GTS_TRI
    );
  dec_stage_d_instruction_decoder_Ker241 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(2),
      O => dec_stage_d_instruction_decoder_N24
    );
  port3_out_5_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(5),
      O => port3_out_5_OBUF_GTS_TRI
    );
  wb_stage_n0069_1_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11156,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11150,
      O => wb_stage_n0069(1)
    );
  port3_out_4_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(4),
      O => port3_out_4_OBUF_GTS_TRI
    );
  rom_Mrom_n0002_inst_mux_f6_68_SW0 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => addressbus_from_fetch(3),
      ADR1 => addressbus_from_fetch(4),
      ADR2 => addressbus_from_fetch(5),
      O => N5977
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_12111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(14),
      ADR2 => write_data0_from_writeback(6),
      O => N6357
    );
  r_aa_from_decode_7_1111_G : X_LUT4
    generic map(
      INIT => X"FB51"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => cu_sel_mux8(0),
      ADR2 => pc_out_from_mem(15),
      ADR3 => dec_stage_mux7_to_mux8_mux9(7),
      O => N6359
    );
  r_addr0_from_decode_0_1111_G : X_LUT4
    generic map(
      INIT => X"EC64"
    )
    port map (
      ADR0 => cu_sel_mux6(0),
      ADR1 => ifid_buff_out1(0),
      ADR2 => r0_from_mem(0),
      ADR3 => r1_from_mem(0),
      O => N6361
    );
  fet_stage_JCall_out_0_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(0),
      ADR2 => ifid_buff_out3(0),
      O => fet_stage_JCall_out(0)
    );
  wb_stage_di_DPH_6_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => N1333,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(6)
    );
  wb_stage_di_DPH_5_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => N1335,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(5)
    );
  wb_stage_di_DPH_4_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(4),
      ADR2 => N1337,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(4)
    );
  wb_stage_di_DPH_3_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(3),
      ADR2 => N1339,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(3)
    );
  wb_stage_di_DPH_2_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(2),
      ADR2 => N13411,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(2)
    );
  wb_stage_p0_in_6_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(6),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => N824,
      O => p0_in_from_writeback(6)
    );
  fet_stage_JCall_out_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(1),
      ADR2 => ifid_buff_out3(1),
      O => fet_stage_JCall_out(1)
    );
  fet_stage_JCall_out_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(2),
      ADR2 => ifid_buff_out3(2),
      O => fet_stage_JCall_out(2)
    );
  fet_stage_JCall_out_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(3),
      ADR2 => ifid_buff_out3(3),
      O => fet_stage_JCall_out(3)
    );
  fet_stage_JCall_out_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(4),
      ADR2 => ifid_buff_out3(4),
      O => fet_stage_JCall_out(4)
    );
  fet_stage_JCall_out_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(5),
      ADR2 => ifid_buff_out3(5),
      O => fet_stage_JCall_out(5)
    );
  fet_stage_JCall_out_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(6),
      ADR2 => ifid_buff_out3(6),
      O => fet_stage_JCall_out(6)
    );
  fet_stage_JCall_out_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out2(7),
      ADR2 => ifid_buff_out3(7),
      O => fet_stage_JCall_out(7)
    );
  wb_stage_di_DPH_7_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => N1343,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(7)
    );
  wb_stage_di_DPH_1_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(1),
      ADR2 => N1345,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(1)
    );
  mem_latch_m_Mmux_out1_d_in0_0_111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(0),
      ADR2 => write_data1_from_writeback(0),
      O => N6363
    );
  r_aa_from_decode_3_1111_G : X_LUT4
    generic map(
      INIT => X"FB51"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => cu_sel_mux8(0),
      ADR2 => pc_out_from_mem(11),
      ADR3 => dec_stage_mux7_to_mux8_mux9(3),
      O => N6365
    );
  r_addr0_from_decode_1_1111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => dec_stage_reg_indirect_to_mux6(1),
      O => N6367
    );
  r_addr0_from_decode_3_1111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(1),
      ADR1 => ifid_buff_out2(6),
      ADR2 => dec_stage_reg_indirect_to_mux6(3),
      O => N6369
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_11111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(13),
      ADR2 => write_data0_from_writeback(5),
      O => N6371
    );
  exe_stage_alu_m_n047629 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0239,
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N62,
      ADR3 => exwb_buff_out_R_A(0),
      O => CHOICE12556
    );
  r_aa_from_decode_0_111 : X_LUT3
    generic map(
      INIT => X"B1"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => N6344,
      ADR2 => dec_stage_mux7_to_mux8_mux9(0),
      O => r_aa_from_decode(0)
    );
  r_aa_from_decode_0_111_SW0 : X_LUT3
    generic map(
      INIT => X"1B"
    )
    port map (
      ADR0 => cu_sel_mux8(0),
      ADR1 => mem_R_A_data_out(0),
      ADR2 => pc_out_from_mem(8),
      O => N6344
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(1),
      ADR2 => write_data1_from_writeback(1),
      O => N6373
    );
  r_aa_from_decode_4_1111_G : X_LUT4
    generic map(
      INIT => X"FB51"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => cu_sel_mux8(0),
      ADR2 => pc_out_from_mem(12),
      ADR3 => dec_stage_mux7_to_mux8_mux9(4),
      O => N6375
    );
  exe_stage_alu_m_n04548_SW0 : X_LUT4
    generic map(
      INIT => X"FF02"
    )
    port map (
      ADR0 => N6340,
      ADR1 => CHOICE12745,
      ADR2 => CHOICE12757,
      ADR3 => Reset_IBUF,
      O => N6158
    );
  exe_stage_alu_m_n04548_SW0_SW0 : X_LUT2
    generic map(
      INIT => X"7"
    )
    port map (
      ADR0 => exe_stage_alu_m_N961,
      ADR1 => exe_stage_alu_m_n0227,
      O => N6340
    );
  r_aa_from_decode_1_111 : X_LUT3
    generic map(
      INIT => X"B1"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => N6338,
      ADR2 => dec_stage_mux7_to_mux8_mux9(1),
      O => r_aa_from_decode(1)
    );
  mem_r_addr_b0_6_11 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(6),
      O => mem_r_addr_b0_6_Q
    );
  mem_r_addr_b0_7_11 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(7),
      O => mem_r_addr_b0_7_Q
    );
  r_aa_from_decode_1_111_SW0 : X_LUT3
    generic map(
      INIT => X"1B"
    )
    port map (
      ADR0 => cu_sel_mux8(0),
      ADR1 => mem_R_A_data_out(1),
      ADR2 => pc_out_from_mem(9),
      O => N6338
    );
  rom_Mrom_n0002_inst_mux_f5_1531 : X_LUT4
    generic map(
      INIT => X"4924"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => N6125
    );
  fet_stage_source_PC_10_Q : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(10),
      ADR2 => N903,
      O => fet_stage_source_PC(10)
    );
  fet_stage_source_PC_11_1 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => fet_stage_PC_M_data_out(11),
      ADR1 => cu_sel_jcall(1),
      ADR2 => cu_sel_mux5(0),
      ADR3 => ifid_buff_out2(3),
      O => fet_stage_source_PC(11)
    );
  fet_stage_source_PC_12_1 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => fet_stage_PC_M_data_out(12),
      ADR1 => cu_sel_jcall(1),
      ADR2 => cu_sel_mux5(0),
      ADR3 => ifid_buff_out2(4),
      O => fet_stage_source_PC(12)
    );
  fet_stage_source_PC_13_1 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => fet_stage_PC_M_data_out(13),
      ADR1 => cu_sel_jcall(1),
      ADR2 => cu_sel_mux5(0),
      ADR3 => ifid_buff_out2(5),
      O => fet_stage_source_PC(13)
    );
  fet_stage_source_PC_14_1 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => fet_stage_PC_M_data_out(14),
      ADR1 => cu_sel_jcall(1),
      ADR2 => cu_sel_mux5(0),
      ADR3 => ifid_buff_out2(6),
      O => fet_stage_source_PC(14)
    );
  fet_stage_source_PC_15_1 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => fet_stage_PC_M_data_out(15),
      ADR1 => cu_sel_jcall(1),
      ADR2 => cu_sel_mux5(0),
      ADR3 => ifid_buff_out2(7),
      O => fet_stage_source_PC(15)
    );
  fet_stage_source_PC_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(1),
      ADR2 => fet_stage_JCall_out(1),
      O => fet_stage_source_PC(1)
    );
  fet_stage_source_PC_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(2),
      ADR2 => fet_stage_JCall_out(2),
      O => fet_stage_source_PC(2)
    );
  fet_stage_source_PC_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(3),
      ADR2 => fet_stage_JCall_out(3),
      O => fet_stage_source_PC(3)
    );
  fet_stage_source_PC_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(4),
      ADR2 => fet_stage_JCall_out(4),
      O => fet_stage_source_PC(4)
    );
  exe_stage_alu_m_n0221_SW0 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0153(7),
      ADR1 => exe_stage_alu_m_n0153(6),
      ADR2 => exe_stage_alu_m_n0153(5),
      O => N1481
    );
  wb_stage_W_B1 : X_LUT4
    generic map(
      INIT => X"D555"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(5),
      ADR3 => exwb_buff_out_D11(6),
      O => W_B_from_writeback
    );
  wb_stage_Ker741 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => exwb_buff_out_D11(2),
      ADR2 => exwb_buff_out_D11(3),
      O => wb_stage_N74
    );
  exe_stage_alu_m_n036434 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(4),
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(1),
      ADR3 => exe_stage_alu_m_N911,
      O => CHOICE11947
    );
  wb_stage_n0179_3_mmx_out221 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(2),
      ADR2 => exwb_buff_out_R_A(2),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out22
    );
  wb_stage_p0_in_4_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(4),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => N824,
      O => p0_in_from_writeback(4)
    );
  wb_stage_p0_in_1_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(1),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => N824,
      O => p0_in_from_writeback(1)
    );
  wb_stage_n00731 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => wb_stage_N75,
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => exwb_buff_out_D11(6),
      O => wb_stage_n0073
    );
  wb_stage_n00741 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_D11(6),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(5),
      O => wb_stage_n0183(7)
    );
  wb_stage_n00751 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => wb_stage_N75,
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => exwb_buff_out_D11(6),
      O => wb_stage_n0075
    );
  wb_stage_n00761 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => wb_stage_N58,
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => exwb_buff_out_D11(4),
      ADR3 => exwb_buff_out_D11(6),
      O => wb_stage_n0076
    );
  fet_stage_que_state_M_state_FFd2_In198_SW0 : X_LUT3
    generic map(
      INIT => X"DF"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => rom_DATA_BUS(6),
      ADR2 => cu_sel_rd,
      O => N6309
    );
  exe_stage_alu_m_n0273_SW0 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(4),
      ADR1 => exe_stage_alu_m_N841,
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => exe_stage_alu_m_n0241,
      O => CHOICE12767
    );
  wb_stage_di_DPH_6_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(6),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1333
    );
  wb_stage_p0_in_3_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(3),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => N824,
      O => p0_in_from_writeback(3)
    );
  wb_stage_n0179_3_mmx_out181 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(5),
      ADR2 => exwb_buff_out_R_A(5),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out18
    );
  wb_stage_di_B_7_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(7)
    );
  wb_stage_n0179_3_mmx_out171 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(6),
      ADR2 => exwb_buff_out_R_A(6),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out17
    );
  wb_stage_Ker311 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => exwb_buff_out_D11(4),
      ADR1 => exwb_buff_out_D11(5),
      O => wb_stage_N311
    );
  wb_stage_n0179_3_mmx_out161 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(7),
      ADR2 => exwb_buff_out_R_A(7),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out16
    );
  wb_stage_p2_in_3_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(3),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => N826,
      O => p2_in_from_writeback(3)
    );
  exe_stage_alu_m_Madd_n0001_Mxor_Result_3_Xo_1_1 : X_LUT4
    generic map(
      INIT => X"6AAA"
    )
    port map (
      ADR0 => exe_stage_alu_m_Madd_n0214_Mxor_Result_3_Xo(0),
      ADR1 => exe_stage_alu_m_n0214(2),
      ADR2 => exe_stage_alu_m_n0214(1),
      ADR3 => exe_stage_alu_m_Madd_n0001_Mxor_Result_1_Xo(0),
      O => exe_stage_alu_m_n0001(3)
    );
  wb_stage_Neq_stagelut1 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exwb_buff_out_D22(2),
      ADR1 => exwb_buff_out_D11(2),
      ADR2 => exwb_buff_out_D22(3),
      ADR3 => exwb_buff_out_D11(3),
      O => wb_stage_N3
    );
  wb_stage_Ker711 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => exwb_buff_out_D22(2),
      ADR2 => exwb_buff_out_D22(3),
      O => wb_stage_N71
    );
  wb_stage_Neq_stagecy_rn_0 : X_MUX2
    port map (
      IB => wb_stage_Neq_stage_cyo,
      IA => sp_out_from_mem(0),
      SEL => wb_stage_N3,
      O => wb_stage_Neq_stage_cyo1
    );
  wb_stage_p2_in_1_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(1),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => N826,
      O => p2_in_from_writeback(1)
    );
  wb_stage_Ker571 : X_LUT4
    generic map(
      INIT => X"020A"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_n0150,
      ADR2 => exwb_buff_out_D22(0),
      ADR3 => wb_stage_N71,
      O => wb_stage_N57
    );
  wb_stage_p3_in_0_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(0),
      ADR2 => exwb_buff_out_R_A(0),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(0)
    );
  wb_stage_Ker351 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => exwb_buff_out_D11(3),
      ADR2 => wb_stage_n0164,
      O => wb_stage_N35
    );
  wb_stage_Ker361 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => exwb_buff_out_D11(2),
      ADR2 => wb_stage_n0164,
      O => wb_stage_N36
    );
  wb_stage_Ker64_SW0 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => exwb_buff_out_D22(3),
      O => N1455
    );
  wb_stage_p2_in_6_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(6),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => N826,
      O => p2_in_from_writeback(6)
    );
  wb_stage_load_p0 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => wb_stage_N64,
      ADR1 => wb_stage_n0184(6),
      ADR2 => N6266,
      ADR3 => wb_stage_n0076,
      O => load_p0_from_writeback
    );
  dec_stage_d_instruction_decoder_Ker87 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(1),
      ADR2 => N6173,
      ADR3 => ifid_buff_out1(2),
      O => dec_stage_d_instruction_decoder_N87
    );
  wb_stage_n0179_3_mmx_out191 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(4),
      ADR2 => exwb_buff_out_R_A(4),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out19
    );
  wb_stage_n0179_3_mmx_out201 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(3),
      ADR2 => exwb_buff_out_R_A(3),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out20
    );
  wb_stage_Neq_stagecy : X_MUX2
    port map (
      IB => fet_stage_Temp1_data(12),
      IA => sp_out_from_mem(0),
      SEL => wb_stage_N2,
      O => wb_stage_Neq_stage_cyo
    );
  wb_stage_Ker781 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => wb_stage_N64,
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(6),
      O => wb_stage_N78
    );
  dec_stage_d_mux9_out1_4_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(4),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(4),
      O => N6377
    );
  dec_stage_d_instruction_decoder_alu_oprt_3_64 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => CHOICE11183,
      ADR1 => ifid_buff_out1(7),
      ADR2 => CHOICE11178,
      ADR3 => CHOICE11175,
      O => CHOICE11187
    );
  dec_stage_d_instruction_decoder_Ker881 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(4),
      O => dec_stage_d_instruction_decoder_N88
    );
  exe_stage_alu_m_Ker96_SW0 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => idex_buff_out_Opcode(1),
      O => N6297
    );
  exe_stage_alu_m_n034720 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0233,
      ADR1 => exe_stage_alu_m_n0243,
      ADR2 => exe_stage_alu_m_n0244,
      ADR3 => exe_stage_alu_m_n0242,
      O => CHOICE11834
    );
  exe_stage_alu_m_Ker951 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(1),
      ADR3 => idex_buff_out_Opcode(2),
      O => exe_stage_alu_m_N951
    );
  wb_stage_di_DPL_4_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(4),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1429
    );
  dec_stage_d_instruction_decoder_n019722 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N104,
      ADR1 => dec_stage_d_instruction_decoder_N28,
      ADR2 => ifid_buff_out1(0),
      ADR3 => dec_stage_d_instruction_decoder_N101,
      O => CHOICE11289
    );
  dec_stage_d_instruction_decoder_Ker93 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => N785,
      ADR2 => ifid_buff_out1(1),
      ADR3 => ifid_buff_out1(2),
      O => dec_stage_d_instruction_decoder_N93
    );
  wb_stage_Ker661 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => exwb_buff_out_D22(1),
      ADR1 => exwb_buff_out_D22(7),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D22(6),
      O => wb_stage_N66
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_13111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(15),
      ADR2 => write_data0_from_writeback(7),
      O => N6379
    );
  dec_stage_d_instruction_decoder_d2_1_33 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N96,
      ADR1 => CHOICE11568,
      ADR2 => dec_stage_d_instruction_decoder_N27,
      ADR3 => CHOICE11571,
      O => d2_from_decode(1)
    );
  wb_stage_Ker601 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => exwb_buff_out_D22(5),
      ADR1 => wb_stage_N34,
      ADR2 => exwb_buff_out_D22(4),
      ADR3 => exwb_buff_out_D22(6),
      O => wb_stage_N60
    );
  wb_stage_n00721 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(4),
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => wb_stage_N58,
      O => wb_stage_n0072
    );
  dec_stage_d_instruction_decoder_Ker791 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(7),
      O => dec_stage_d_instruction_decoder_N79
    );
  wb_stage_di_DPL_2_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(2),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1427
    );
  wb_stage_di_B_3_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(3),
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(3)
    );
  dec_stage_d_instruction_decoder_Ker41 : X_LUT3
    generic map(
      INIT => X"98"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(7),
      O => dec_stage_d_instruction_decoder_N4
    );
  wb_stage_di_B_5_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(5)
    );
  wb_stage_di_DPH_0_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N63,
      ADR1 => exwb_buff_out_R_B(0),
      ADR2 => N1347,
      ADR3 => wb_stage_N51,
      O => di_DPH_from_writeback(0)
    );
  wb_stage_load_p31 : X_LUT4
    generic map(
      INIT => X"55D5"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(5),
      ADR3 => exwb_buff_out_D11(6),
      O => load_p3_from_writeback
    );
  mem_PSW_n00091_G : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => wb_stage_n0183(7),
      O => N6381
    );
  wb_stage_di_psw_4_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(4),
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => wb_stage_n0183(7),
      O => di_psw_from_writeback_4_Q
    );
  dec_stage_d_instruction_decoder_Ker2356 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => CHOICE11520,
      ADR2 => CHOICE10780,
      ADR3 => CHOICE11512,
      O => CHOICE11522
    );
  r_aa_from_decode_2_111 : X_LUT3
    generic map(
      INIT => X"B1"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => N6335,
      ADR2 => dec_stage_mux7_to_mux8_mux9(2),
      O => r_aa_from_decode(2)
    );
  wb_stage_n0068_0_34 : X_LUT4
    generic map(
      INIT => X"AF23"
    )
    port map (
      ADR0 => wb_stage_n0164,
      ADR1 => wb_stage_n0184(6),
      ADR2 => wb_stage_N74,
      ADR3 => N6277,
      O => CHOICE11077
    );
  fet_stage_que_state_M_state_FFd2_In184 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => rom_DATA_BUS(0),
      ADR1 => rom_DATA_BUS(1),
      ADR2 => fet_stage_que_state_M_N9,
      ADR3 => cu_sel_rd,
      O => CHOICE11686
    );
  wb_stage_di_DPL_0_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(0),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1425
    );
  wb_stage_Ker801 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => wb_stage_N66,
      ADR1 => exwb_buff_out_D22(2),
      O => wb_stage_N80
    );
  dec_stage_d_instruction_decoder_Ker281 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(6),
      O => dec_stage_d_instruction_decoder_N28
    );
  wb_stage_w_addr1_3_5 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => exwb_buff_out_D22(0),
      ADR1 => wb_stage_N32,
      O => CHOICE11483
    );
  dec_stage_d_instruction_decoder_Ker901 : X_LUT3
    generic map(
      INIT => X"01"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(1),
      O => dec_stage_d_instruction_decoder_N90
    );
  wb_stage_Ker561 : X_LUT4
    generic map(
      INIT => X"40C0"
    )
    port map (
      ADR0 => wb_stage_n0150,
      ADR1 => wb_stage_n0184(6),
      ADR2 => exwb_buff_out_D22(0),
      ADR3 => wb_stage_N71,
      O => wb_stage_N56
    );
  wb_stage_Neq_stagelut2 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => exwb_buff_out_D11(4),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D11(5),
      O => wb_stage_N4
    );
  wb_stage_di_B_1_1 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_R_B(1),
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => wb_stage_N82,
      O => di_B_from_writeback(1)
    );
  wb_stage_di_DPL_6_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(6),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1423
    );
  wb_stage_di_DPL_7_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(7),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1421
    );
  wb_stage_di_DPL_5_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(5),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1419
    );
  wb_stage_di_DPL_3_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(3),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1417
    );
  exe_stage_alu_m_n0489246_SW0 : X_LUT4
    generic map(
      INIT => X"0103"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo1,
      ADR1 => CHOICE11882,
      ADR2 => CHOICE11925,
      ADR3 => exe_stage_alu_m_N821,
      O => N6175
    );
  wb_stage_w_addr1_0_1 : X_LUT3
    generic map(
      INIT => X"EF"
    )
    port map (
      ADR0 => write_addr1_from_writeback(0),
      ADR1 => wb_stage_N56,
      ADR2 => wb_stage_N111,
      O => write_addr1_from_writeback(0)
    );
  wb_stage_W_DPH : X_LUT4
    generic map(
      INIT => X"44F4"
    )
    port map (
      ADR0 => N6221,
      ADR1 => wb_stage_n0184(6),
      ADR2 => wb_stage_N68,
      ADR3 => exwb_buff_out_D11(0),
      O => W_DPH_from_writeback
    );
  fet_stage_que_state_M_next_Mcode_2_133_SW0 : X_LUT4
    generic map(
      INIT => X"E8EB"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => rom_DATA_BUS(1),
      ADR2 => rom_DATA_BUS(5),
      ADR3 => rom_DATA_BUS(4),
      O => N6291
    );
  wb_stage_Ker5 : X_LUT4
    generic map(
      INIT => X"FFF7"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_N71,
      ADR2 => exwb_buff_out_D22(0),
      ADR3 => N2790,
      O => wb_stage_N51
    );
  wb_stage_din_rid_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(1),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_Ker821 : X_LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      ADR0 => wb_stage_N12,
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => wb_stage_N75,
      O => wb_stage_N82
    );
  r_aa_from_decode_2_111_SW0 : X_LUT3
    generic map(
      INIT => X"1B"
    )
    port map (
      ADR0 => cu_sel_mux8(0),
      ADR1 => mem_R_A_data_out(2),
      ADR2 => pc_out_from_mem(10),
      O => N6335
    );
  fet_stage_que_state_M_inst_que_code_3_295 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11785,
      ADR1 => rom_DATA_BUS(7),
      ADR2 => N6307,
      ADR3 => CHOICE11759,
      O => CHOICE11787
    );
  datapath_fet_stage_next_PC_0_cy : X_MUX2
    port map (
      IB => fet_stage_Temp1_data(12),
      IA => sp_out_from_mem(0),
      SEL => fet_stage_next_PC(0),
      O => datapath_fet_stage_next_PC_0_cyo
    );
  port3_out_0_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(0),
      O => port3_out_0_OBUF_GTS_TRI
    );
  datapath_fet_stage_next_PC_1_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_0_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(1),
      O => datapath_fet_stage_next_PC_1_cyo
    );
  datapath_fet_stage_next_PC_1_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_0_cyo,
      I1 => fet_stage_source_PC(1),
      O => fet_stage_next_PC(1)
    );
  datapath_fet_stage_next_PC_2_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_1_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(2),
      O => datapath_fet_stage_next_PC_2_cyo
    );
  datapath_fet_stage_next_PC_2_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_1_cyo,
      I1 => fet_stage_source_PC(2),
      O => fet_stage_next_PC(2)
    );
  datapath_fet_stage_next_PC_3_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_2_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(3),
      O => datapath_fet_stage_next_PC_3_cyo
    );
  datapath_fet_stage_next_PC_3_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_2_cyo,
      I1 => fet_stage_source_PC(3),
      O => fet_stage_next_PC(3)
    );
  datapath_fet_stage_next_PC_4_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_3_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(4),
      O => datapath_fet_stage_next_PC_4_cyo
    );
  datapath_fet_stage_next_PC_4_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_3_cyo,
      I1 => fet_stage_source_PC(4),
      O => fet_stage_next_PC(4)
    );
  datapath_fet_stage_next_PC_5_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_4_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(5),
      O => datapath_fet_stage_next_PC_5_cyo
    );
  datapath_fet_stage_next_PC_5_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_4_cyo,
      I1 => fet_stage_source_PC(5),
      O => fet_stage_next_PC(5)
    );
  datapath_fet_stage_next_PC_6_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_5_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(6),
      O => datapath_fet_stage_next_PC_6_cyo
    );
  datapath_fet_stage_next_PC_6_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_5_cyo,
      I1 => fet_stage_source_PC(6),
      O => fet_stage_next_PC(6)
    );
  datapath_fet_stage_next_PC_7_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_6_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(7),
      O => datapath_fet_stage_next_PC_7_cyo
    );
  datapath_fet_stage_next_PC_7_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_6_cyo,
      I1 => fet_stage_source_PC(7),
      O => fet_stage_next_PC(7)
    );
  datapath_fet_stage_next_PC_8_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_7_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(8),
      O => datapath_fet_stage_next_PC_8_cyo
    );
  datapath_fet_stage_next_PC_8_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_7_cyo,
      I1 => fet_stage_source_PC(8),
      O => fet_stage_next_PC(8)
    );
  datapath_fet_stage_next_PC_9_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_8_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(9),
      O => datapath_fet_stage_next_PC_9_cyo
    );
  datapath_fet_stage_next_PC_9_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_8_cyo,
      I1 => fet_stage_source_PC(9),
      O => fet_stage_next_PC(9)
    );
  datapath_fet_stage_next_PC_10_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_9_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(10),
      O => datapath_fet_stage_next_PC_10_cyo
    );
  datapath_fet_stage_next_PC_10_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_9_cyo,
      I1 => fet_stage_source_PC(10),
      O => fet_stage_next_PC(10)
    );
  datapath_fet_stage_next_PC_11_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_10_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(11),
      O => datapath_fet_stage_next_PC_11_cyo
    );
  datapath_fet_stage_next_PC_11_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_10_cyo,
      I1 => fet_stage_source_PC(11),
      O => fet_stage_next_PC(11)
    );
  datapath_fet_stage_next_PC_12_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_11_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(12),
      O => datapath_fet_stage_next_PC_12_cyo
    );
  datapath_fet_stage_next_PC_12_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_11_cyo,
      I1 => fet_stage_source_PC(12),
      O => fet_stage_next_PC(12)
    );
  datapath_fet_stage_next_PC_13_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_12_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(13),
      O => datapath_fet_stage_next_PC_13_cyo
    );
  datapath_fet_stage_next_PC_13_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_12_cyo,
      I1 => fet_stage_source_PC(13),
      O => fet_stage_next_PC(13)
    );
  datapath_fet_stage_next_PC_14_cy : X_MUX2
    port map (
      IB => datapath_fet_stage_next_PC_13_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => fet_stage_source_PC(14),
      O => datapath_fet_stage_next_PC_14_cyo
    );
  datapath_fet_stage_next_PC_14_xor : X_XOR2
    port map (
      I0 => datapath_fet_stage_next_PC_13_cyo,
      I1 => fet_stage_source_PC(14),
      O => fet_stage_next_PC(14)
    );
  dec_stage_d_mux7_out1_5_63 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(5),
      ADR3 => mem_R_B_data_out(5),
      O => CHOICE12124
    );
  Eq_stagecy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => fet_stage_Temp1_data(12),
      SEL => N30,
      O => Eq_stage_cyo
    );
  Eq_stagecy_rn_0 : X_MUX2
    port map (
      IB => Eq_stage_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => N31,
      O => Eq_stage_cyo1
    );
  Eq_stagecy_rn_1 : X_MUX2
    port map (
      IB => Eq_stage_cyo1,
      IA => fet_stage_Temp1_data(12),
      SEL => N32,
      O => Eq_stage_cyo2
    );
  Eq_stagecy_rn_3 : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => fet_stage_Temp1_data(12),
      SEL => N34,
      O => Eq_stage_cyo3
    );
  Eq_stagecy_rn_4 : X_MUX2
    port map (
      IB => Eq_stage_cyo3,
      IA => fet_stage_Temp1_data(12),
      SEL => N35,
      O => Eq_stage_cyo4
    );
  Eq_stagecy_rn_5 : X_MUX2
    port map (
      IB => Eq_stage_cyo4,
      IA => fet_stage_Temp1_data(12),
      SEL => N36,
      O => Eq_stage_cyo5
    );
  Eq_stagecy_rn_7 : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => fet_stage_Temp1_data(12),
      SEL => N38,
      O => Eq_stage_cyo6
    );
  Eq_stagecy_rn_8 : X_MUX2
    port map (
      IB => Eq_stage_cyo6,
      IA => fet_stage_Temp1_data(12),
      SEL => N39,
      O => Eq_stage_cyo7
    );
  Eq_stagecy_rn_9 : X_MUX2
    port map (
      IB => Eq_stage_cyo7,
      IA => fet_stage_Temp1_data(12),
      SEL => N40,
      O => Eq_stage_cyo8
    );
  Eq_stagecy_rn_11 : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => fet_stage_Temp1_data(12),
      SEL => N42,
      O => Eq_stage_cyo9
    );
  Eq_stagecy_rn_12 : X_MUX2
    port map (
      IB => Eq_stage_cyo9,
      IA => fet_stage_Temp1_data(12),
      SEL => N43,
      O => Eq_stage_cyo10
    );
  Eq_stagecy_rn_13 : X_MUX2
    port map (
      IB => Eq_stage_cyo10,
      IA => fet_stage_Temp1_data(12),
      SEL => N44,
      O => Eq_stage_cyo11
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_01 : X_LUT3
    generic map(
      INIT => X"01"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(2),
      O => dec_stage_bit_number_dec_to_mux9(0)
    );
  fet_stage_que_state_M_que_byte3_5_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5931
    );
  port0_out_5_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(5),
      O => port0_out_5_OBUF_GTS_TRI
    );
  port0_out_6_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(6),
      O => port0_out_6_OBUF_GTS_TRI
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_241 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(2),
      O => dec_stage_bit_number_dec_to_mux9(3)
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_401 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(1),
      O => dec_stage_bit_number_dec_to_mux9(5)
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_321 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(1),
      O => dec_stage_bit_number_dec_to_mux9(4)
    );
  dec_stage_d_bit_number_dec_Mrom_out1_inst_lut4_481 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(0),
      O => dec_stage_bit_number_dec_to_mux9(6)
    );
  r_addr0_from_decode_7_1 : X_LUT4
    generic map(
      INIT => X"8380"
    )
    port map (
      ADR0 => dec_stage_reg_indirect_to_mux6(7),
      ADR1 => cu_sel_mux6(0),
      ADR2 => cu_sel_mux6(1),
      ADR3 => ifid_buff_out2(7),
      O => r_addr0_from_decode(7)
    );
  r_addr0_from_decode_6_1 : X_LUT4
    generic map(
      INIT => X"8380"
    )
    port map (
      ADR0 => dec_stage_reg_indirect_to_mux6(6),
      ADR1 => cu_sel_mux6(0),
      ADR2 => cu_sel_mux6(1),
      ADR3 => ifid_buff_out2(6),
      O => r_addr0_from_decode(6)
    );
  r_addr0_from_decode_5_1 : X_LUT4
    generic map(
      INIT => X"F232"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => cu_sel_mux6(1),
      ADR2 => cu_sel_mux6(0),
      ADR3 => dec_stage_reg_indirect_to_mux6(5),
      O => r_addr0_from_decode(5)
    );
  r_aa_from_decode_6_1111_G : X_LUT4
    generic map(
      INIT => X"FB51"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => cu_sel_mux8(0),
      ADR2 => pc_out_from_mem(14),
      ADR3 => dec_stage_mux7_to_mux8_mux9(6),
      O => N6383
    );
  r_aa_from_decode_5_1111_G : X_LUT4
    generic map(
      INIT => X"FB51"
    )
    port map (
      ADR0 => cu_sel_mux8(1),
      ADR1 => cu_sel_mux8(0),
      ADR2 => pc_out_from_mem(13),
      ADR3 => dec_stage_mux7_to_mux8_mux9(5),
      O => N6385
    );
  r_addr0_from_decode_2_1111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(1),
      ADR1 => ifid_buff_out2(5),
      ADR2 => dec_stage_reg_indirect_to_mux6(2),
      O => N6387
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_0111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(2),
      ADR2 => write_data1_from_writeback(2),
      O => N6389
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_1411_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(3),
      ADR2 => write_data1_from_writeback(3),
      O => N6391
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_6111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(8),
      ADR2 => write_data0_from_writeback(0),
      O => N6393
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_5111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(7),
      ADR2 => write_data1_from_writeback(7),
      O => N6395
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_7111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(9),
      ADR2 => write_data0_from_writeback(1),
      O => N6397
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_8111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(10),
      ADR2 => write_data0_from_writeback(2),
      O => N6399
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_9111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(11),
      ADR2 => write_data0_from_writeback(3),
      O => N6401
    );
  exe_stage_alu_m_alu_n0000_3_cyo_rt_0 : X_LUT2
    generic map(
      INIT => X"A"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_n0000_3_cyo,
      O => exe_stage_alu_m_alu_n0000_3_cyo_rt,
      ADR1 => GND
    );
  exe_stage_src1_7_21 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N76,
      ADR2 => exwb_buff_out_R_A(7),
      O => N5944
    );
  exe_stage_src1_6_21 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N74,
      ADR2 => exwb_buff_out_R_A(6),
      O => N5943
    );
  exe_stage_src1_0_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0003,
      ADR1 => idex_buff_out_A(0),
      ADR2 => exwb_buff_out_R_B(0),
      O => N62
    );
  exe_stage_src1_0_2 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N62,
      ADR2 => exwb_buff_out_R_A(0),
      O => exe_stage_src1(0)
    );
  exe_stage_src1_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0003,
      ADR1 => idex_buff_out_A(1),
      ADR2 => exwb_buff_out_R_B(1),
      O => N64
    );
  exe_stage_src1_1_2 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N64,
      ADR2 => exwb_buff_out_R_A(1),
      O => exe_stage_src1(1)
    );
  exe_stage_src1_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0003,
      ADR1 => idex_buff_out_A(2),
      ADR2 => exwb_buff_out_R_B(2),
      O => N66
    );
  exe_stage_src1_2_2 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N66,
      ADR2 => exwb_buff_out_R_A(2),
      O => exe_stage_src1(2)
    );
  exe_stage_src1_3_2 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N6494,
      ADR2 => exwb_buff_out_R_A(3),
      O => exe_stage_src1(3)
    );
  exe_stage_src1_4_2 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N6495,
      ADR2 => exwb_buff_out_R_A(4),
      O => exe_stage_src1(4)
    );
  exe_stage_src1_5_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(5),
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N6496,
      O => exe_stage_src1(5)
    );
  exe_stage_src1_6_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(6),
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N6497,
      O => exe_stage_src1(6)
    );
  exe_stage_src1_7_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(7),
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N6498,
      O => exe_stage_src1(7)
    );
  exe_stage_src2_0_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(0),
      ADR1 => exwb_buff_out_R_B(0),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N78
    );
  exe_stage_src2_0_2 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => N78,
      ADR2 => exwb_buff_out_R_A(0),
      O => exe_stage_src2(0)
    );
  exe_stage_src2_1_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(1),
      ADR1 => exwb_buff_out_R_B(1),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N80
    );
  exe_stage_src2_2_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(2),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N6500,
      O => exe_stage_src2(2)
    );
  exe_stage_src2_3_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(3),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N6501,
      O => exe_stage_src2(3)
    );
  exe_stage_src2_4_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(4),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N6502,
      O => exe_stage_src2(4)
    );
  exe_stage_src2_5_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(5),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N6503,
      O => exe_stage_src2(5)
    );
  exe_stage_src2_6_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(6),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N6504,
      O => exe_stage_src2(6)
    );
  exe_stage_src2_7_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(7),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N6505,
      O => exe_stage_src2(7)
    );
  dec_stage_d_instruction_decoder_s1_3_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out2(3),
      ADR1 => dec_stage_d_instruction_decoder_N99,
      O => s1_from_decode(3)
    );
  dec_stage_d_instruction_decoder_s1_4_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out2(4),
      ADR1 => dec_stage_d_instruction_decoder_N99,
      O => s1_from_decode(4)
    );
  dec_stage_d_instruction_decoder_n02001 : X_LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(5),
      ADR2 => dec_stage_d_instruction_decoder_N4,
      ADR3 => dec_stage_d_instruction_decoder_N95,
      O => dec_stage_d_instruction_decoder_n0200
    );
  dec_stage_d_instruction_decoder_s1_6_1 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N23,
      ADR1 => ifid_buff_out2(6),
      ADR2 => dec_stage_d_instruction_decoder_N102,
      O => s1_from_decode(6)
    );
  dec_stage_d_instruction_decoder_s1_7_1 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N23,
      ADR1 => ifid_buff_out2(7),
      ADR2 => dec_stage_d_instruction_decoder_N102,
      O => s1_from_decode(7)
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_118 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N90,
      ADR1 => ifid_buff_out1(4),
      ADR2 => dec_stage_d_instruction_decoder_N98,
      ADR3 => ifid_buff_out1(5),
      O => CHOICE11384
    );
  dec_stage_d_mux9_out1_7_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(15),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12493
    );
  rom_Mrom_n0002_inst_mux_f5_157 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_141,
      IB => N6119,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N92
    );
  rom_Mrom_n0002_inst_mux_f5_151 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_125,
      IB => N6120,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N62
    );
  rom_Mrom_n0002_inst_mux_f6_71 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N31,
      IB => rom_Mrom_n0002_N32,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N33
    );
  rom_Mrom_n0002_inst_mux_f6_67 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N4,
      IB => rom_Mrom_n0002_N5,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N6
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_161 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => mem_w_addr_b0(5),
      ADR1 => mem_w_addr_b0(6),
      ADR2 => mem_w_addr_b0(7),
      ADR3 => mem_w_addr_b0(0),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_16
    );
  exwb_buff_out_R_B_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(1),
      RST => exwb_buff_out_R_B_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(1),
      CE => VCC,
      SET => GND
    );
  wb_stage_di_A_4_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(4),
      O => di_A_from_writeback(4)
    );
  wb_stage_di_A_5_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(5),
      O => di_A_from_writeback(5)
    );
  wb_stage_di_A_6_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(6),
      O => di_A_from_writeback(6)
    );
  exe_stage_src1_5_21 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N72,
      ADR2 => exwb_buff_out_R_A(5),
      O => N5942
    );
  exe_stage_src1_4_21 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N70,
      ADR2 => exwb_buff_out_R_A(4),
      O => N5941
    );
  exe_stage_src1_3_21 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N68,
      ADR2 => exwb_buff_out_R_A(3),
      O => N5940
    );
  exe_stage_alu_m_n0000_1_rt_1 : X_LUT2
    generic map(
      INIT => X"A"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0000(1),
      O => exe_stage_alu_m_n0000_1_rt,
      ADR1 => GND
    );
  exe_stage_alu_m_n0000_2_rt_2 : X_LUT2
    generic map(
      INIT => X"A"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0000(2),
      O => exe_stage_alu_m_n0000_2_rt,
      ADR1 => GND
    );
  wb_stage_p2_in_5_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(5),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => N826,
      O => p2_in_from_writeback(5)
    );
  dec_stage_d_instruction_decoder_d2_4_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => ifid_buff_out2(4),
      ADR1 => dec_stage_d_instruction_decoder_N88,
      ADR2 => dec_stage_reg_indirect_to_mux6(4),
      ADR3 => ifid_buff_out1(1),
      O => CHOICE11446
    );
  fet_stage_que_state_M_inst_que_code_3_65_SW0 : X_LUT3
    generic map(
      INIT => X"F2"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => rom_DATA_BUS(2),
      ADR2 => rom_DATA_BUS(6),
      O => N6215
    );
  wb_stage_din_rid_2 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(2),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(2),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  dec_stage_d_instruction_decoder_d2_1_13 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(4),
      O => CHOICE11571
    );
  wb_stage_Ker321 : X_LUT4
    generic map(
      INIT => X"55D5"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => exwb_buff_out_D22(7),
      ADR2 => wb_stage_n0150,
      ADR3 => exwb_buff_out_D22(2),
      O => wb_stage_N32
    );
  dec_stage_d_instruction_decoder_Ker391 : X_LUT4
    generic map(
      INIT => X"F8C8"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N90,
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(5),
      ADR3 => ifid_buff_out1(3),
      O => dec_stage_d_instruction_decoder_N39
    );
  wb_stage_Ker341 : X_LUT2
    generic map(
      INIT => X"7"
    )
    port map (
      ADR0 => wb_stage_N64,
      ADR1 => wb_stage_n0184(6),
      O => wb_stage_N34
    );
  wb_stage_din_rid_3 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(3),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(3),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_n0179_3_mmx_out241 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(0),
      ADR2 => exwb_buff_out_R_A(0),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out24
    );
  wb_stage_Neq_stagelut : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exwb_buff_out_D22(0),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => exwb_buff_out_D22(1),
      ADR3 => exwb_buff_out_D11(1),
      O => wb_stage_N2
    );
  wb_stage_n0179_3_mmx_out231 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_din_rid(1),
      ADR2 => exwb_buff_out_R_A(1),
      O => wb_stage_MUX_BLOCK_n0179_3_mmx_out23
    );
  wb_stage_din_rid_4 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(4),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(4),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_addr_rid_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0068(0),
      CLK => wb_stage_n0190,
      O => wb_stage_addr_rid(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_n01641 : X_LUT4
    generic map(
      INIT => X"EFE2"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => exwb_buff_out_D11(1),
      ADR2 => wb_stage_N311,
      ADR3 => exwb_buff_out_D11(6),
      O => wb_stage_n0164
    );
  cu_n0023_0_32 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => CHOICE10696,
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      ADR3 => CHOICE10701,
      O => CHOICE10702
    );
  wb_stage_load_p2 : X_LUT4
    generic map(
      INIT => X"FF01"
    )
    port map (
      ADR0 => wb_stage_N34,
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => N776,
      ADR3 => wb_stage_n0072,
      O => load_p2_from_writeback
    );
  wb_stage_di_A_0_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(0),
      O => di_A_from_writeback(0)
    );
  mem_Inst_rid_Mram_R0R1_ren_inst_inv_01_INV_0 : X_INV
    port map (
      I => Reset_IBUF,
      O => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0
    );
  mem_w_addr_b0_5_1_F1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(5),
      O => mem_w_addr_b0(5)
    );
  mem_PSW_psw_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_PSW_n0008,
      RST => mem_PSW_psw_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(2),
      CE => VCC,
      SET => GND
    );
  port1_out_7_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(7),
      O => port1_out_7_OBUF_GTS_TRI
    );
  mem_R_P3_data_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_6_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(6),
      RST => GND
    );
  wb_stage_p1_in_5_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(5),
      ADR1 => wb_stage_N59,
      ADR2 => N6225,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(5)
    );
  wb_stage_load_p11 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => wb_stage_N59,
      ADR1 => wb_stage_n0073,
      ADR2 => wb_stage_N21,
      O => load_p1_from_writeback
    );
  wb_stage_p2_in_7_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(7),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => N826,
      O => p2_in_from_writeback(7)
    );
  mem_mux_13_out1_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => write_addr1_from_writeback(6),
      O => mem_w_addr_b1(6)
    );
  cu_n0019_0_1 : X_LUT4
    generic map(
      INIT => X"0301"
    )
    port map (
      ADR0 => cu_N46,
      ADR1 => cu_n0311,
      ADR2 => Reset_IBUF,
      ADR3 => cu_N15,
      O => cu_n0019(0)
    );
  mem_R_A_data_out_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(6),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_6_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_6_C,
      O => mem_R_A_data_out(6),
      SET => GND
    );
  mem_R_B_data_out_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(6),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_6_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_6_C,
      O => mem_R_B_data_out(6),
      SET => GND
    );
  mem_R_DPH_data_out_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(6),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_6_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_6_C,
      O => mem_R_DPH_data_out(6),
      SET => GND
    );
  mem_R_DPL_data_out_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(6),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_6_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_6_C,
      O => mem_R_DPL_data_out(6),
      SET => GND
    );
  wb_stage_p1_in_0_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(0),
      ADR1 => wb_stage_N59,
      ADR2 => N6227,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(0)
    );
  mem_R_P0_data_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_6_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(6),
      RST => GND
    );
  mem_R_P1_data_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_6_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(6),
      RST => GND
    );
  mem_R_P2_data_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_6_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(6),
      RST => GND
    );
  port1_out_6_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(6),
      O => port1_out_6_OBUF_GTS_TRI
    );
  dec_stage_d_instruction_decoder_d2_5_Q : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N95,
      ADR1 => dec_stage_reg_indirect_to_mux6(5),
      ADR2 => N768,
      ADR3 => N769,
      O => d2_from_decode(5)
    );
  wb_stage_p1_in_2_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(2),
      ADR1 => wb_stage_N59,
      ADR2 => N6229,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(2)
    );
  wb_stage_p1_in_4_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(4),
      ADR1 => wb_stage_N59,
      ADR2 => N6231,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(4)
    );
  wb_stage_p1_in_6_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(6),
      ADR1 => wb_stage_N59,
      ADR2 => N6233,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(6)
    );
  wb_stage_p0_in_7_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(7),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => N824,
      O => p0_in_from_writeback(7)
    );
  wb_stage_di_DPL_1_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(1),
      ADR2 => N1415,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(1)
    );
  wb_stage_di_DPL_3_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(3),
      ADR2 => N1417,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(3)
    );
  wb_stage_di_DPL_5_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => N1419,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(5)
    );
  port2_in_7_IBUF_3 : X_BUF
    port map (
      I => port2_in(7),
      O => port2_in_7_IBUF
    );
  exwb_buff_out_D11_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(4),
      RST => exwb_buff_out_D11_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(4),
      CE => VCC,
      SET => GND
    );
  mem_PSW_psw_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_psw_from_writeback_1_Q,
      CE => W_psw_from_writeback,
      RST => mem_PSW_psw_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(1),
      SET => GND
    );
  mem_PSW_psw_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_PSW_n0007,
      RST => mem_PSW_psw_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(0),
      CE => VCC,
      SET => GND
    );
  mem_PSW_n0007_4 : X_LUT4
    generic map(
      INIT => X"BE14"
    )
    port map (
      ADR0 => W_psw_from_writeback,
      ADR1 => mem_PSW_Mxor_n0011_Xo(4),
      ADR2 => mem_PSW_Mxor_n0011_Xo(5),
      ADR3 => N2788,
      O => mem_PSW_n0007
    );
  exe_stage_alu_m_n02491 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(1),
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => idex_buff_out_Opcode(0),
      O => exe_stage_alu_m_n0249
    );
  dec_stage_d_mux7_out1_0_36 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => CHOICE12247,
      ADR1 => ifid_buff_out2(5),
      ADR2 => ifid_buff_out2(6),
      ADR3 => ifid_buff_out2(4),
      O => CHOICE12248
    );
  wb_stage_di_DPL_7_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => N1421,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(7)
    );
  mem_PSW_psw_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_PSW_n0010,
      RST => mem_PSW_psw_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(7),
      CE => VCC,
      SET => GND
    );
  mem_PSW_psw_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_PSW_n0009,
      RST => mem_PSW_psw_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(6),
      CE => VCC,
      SET => GND
    );
  mem_PSW_psw_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_psw_from_writeback_5_Q,
      CE => W_psw_from_writeback,
      RST => mem_PSW_psw_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(5),
      SET => GND
    );
  mem_PSW_psw_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_psw_from_writeback_4_Q,
      CE => W_psw_from_writeback,
      RST => mem_PSW_psw_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(4),
      SET => GND
    );
  mem_PSW_psw_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_psw_from_writeback_3_Q,
      CE => W_psw_from_writeback,
      RST => mem_PSW_psw_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_PSW_psw(3),
      SET => GND
    );
  mem_R_P3_data_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_7_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(7),
      RST => GND
    );
  mem_R_P3_port_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(7),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(7),
      RST => GND
    );
  mem_R_P3_port_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(0),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(0),
      RST => GND
    );
  mem_R_P3_port_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(1),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(1),
      RST => GND
    );
  mem_R_P3_port_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(2),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(2),
      RST => GND
    );
  mem_R_P3_port_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(3),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(3),
      RST => GND
    );
  mem_R_P3_port_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(4),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(4),
      RST => GND
    );
  mem_R_P3_port_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(5),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(5),
      RST => GND
    );
  mem_R_P3_port_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p3_in_from_writeback(6),
      CE => load_p3_from_writeback,
      SET => mem_R_P3_port_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_port_out(6),
      RST => GND
    );
  mem_R_P3_data_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_0_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(0),
      RST => GND
    );
  mem_R_P3_data_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_1_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(1),
      RST => GND
    );
  mem_R_P3_data_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_2_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(2),
      RST => GND
    );
  mem_R_P3_data_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_3_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(3),
      RST => GND
    );
  mem_R_P3_data_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_4_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(4),
      RST => GND
    );
  mem_R_P3_data_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port3_in_5_IBUF,
      CE => load_p3_from_writeback,
      SET => mem_R_P3_data_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P3_data_out(5),
      RST => GND
    );
  mem_R_P2_data_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_7_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(7),
      RST => GND
    );
  mem_R_P2_port_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(7),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(7),
      RST => GND
    );
  mem_R_P2_port_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(0),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(0),
      RST => GND
    );
  mem_R_P2_port_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(1),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(1),
      RST => GND
    );
  mem_R_P2_port_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(2),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(2),
      RST => GND
    );
  mem_R_P2_port_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(3),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(3),
      RST => GND
    );
  mem_R_P2_port_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(4),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(4),
      RST => GND
    );
  mem_R_P2_port_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(5),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(5),
      RST => GND
    );
  mem_R_P2_port_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p2_in_from_writeback(6),
      CE => load_p2_from_writeback,
      SET => mem_R_P2_port_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_port_out(6),
      RST => GND
    );
  mem_R_P2_data_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_0_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(0),
      RST => GND
    );
  mem_R_P2_data_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_1_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(1),
      RST => GND
    );
  mem_R_P2_data_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_2_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(2),
      RST => GND
    );
  mem_R_P2_data_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_3_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(3),
      RST => GND
    );
  mem_R_P2_data_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_4_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(4),
      RST => GND
    );
  mem_R_P2_data_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port2_in_5_IBUF,
      CE => load_p2_from_writeback,
      SET => mem_R_P2_data_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P2_data_out(5),
      RST => GND
    );
  mem_R_P1_data_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_7_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(7),
      RST => GND
    );
  mem_R_P1_port_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(7),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(7),
      RST => GND
    );
  mem_R_P1_port_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(0),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(0),
      RST => GND
    );
  mem_R_P1_port_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(1),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(1),
      RST => GND
    );
  mem_R_P1_port_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(2),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(2),
      RST => GND
    );
  mem_R_P1_port_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(3),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(3),
      RST => GND
    );
  mem_R_P1_port_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(4),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(4),
      RST => GND
    );
  mem_R_P1_port_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(5),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(5),
      RST => GND
    );
  mem_R_P1_port_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p1_in_from_writeback(6),
      CE => load_p1_from_writeback,
      SET => mem_R_P1_port_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_port_out(6),
      RST => GND
    );
  mem_R_P1_data_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_0_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(0),
      RST => GND
    );
  mem_R_P1_data_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_1_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(1),
      RST => GND
    );
  mem_R_P1_data_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_2_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(2),
      RST => GND
    );
  mem_R_P1_data_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_3_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(3),
      RST => GND
    );
  mem_R_P1_data_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_4_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(4),
      RST => GND
    );
  mem_R_P1_data_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port1_in_5_IBUF,
      CE => load_p1_from_writeback,
      SET => mem_R_P1_data_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P1_data_out(5),
      RST => GND
    );
  mem_R_P0_data_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_7_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(7),
      RST => GND
    );
  mem_R_P0_port_out_7 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(7),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(7),
      RST => GND
    );
  mem_R_P0_port_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(0),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(0),
      RST => GND
    );
  mem_R_P0_port_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(1),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(1),
      RST => GND
    );
  mem_R_P0_port_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(2),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(2),
      RST => GND
    );
  mem_R_P0_port_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(3),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(3),
      RST => GND
    );
  mem_R_P0_port_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(4),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(4),
      RST => GND
    );
  mem_R_P0_port_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(5),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(5),
      RST => GND
    );
  mem_R_P0_port_out_6 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => p0_in_from_writeback(6),
      CE => load_p0_from_writeback,
      SET => mem_R_P0_port_out_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_port_out(6),
      RST => GND
    );
  mem_R_P0_data_out_0 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_0_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(0),
      RST => GND
    );
  mem_R_P0_data_out_1 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_1_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(1),
      RST => GND
    );
  mem_R_P0_data_out_2 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_2_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(2),
      RST => GND
    );
  mem_R_P0_data_out_3 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_3_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(3),
      RST => GND
    );
  mem_R_P0_data_out_4 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_4_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(4),
      RST => GND
    );
  mem_R_P0_data_out_5 : X_FF
    generic map(
      INIT => '1'
    )
    port map (
      I => port0_in_5_IBUF,
      CE => load_p0_from_writeback,
      SET => mem_R_P0_data_out_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => mem_R_P0_data_out(5),
      RST => GND
    );
  mem_R_DPL_data_out_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(7),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_7_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_7_C,
      O => mem_R_DPL_data_out(7),
      SET => GND
    );
  mem_R_DPL_data_out_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(0),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_0_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_0_C,
      O => mem_R_DPL_data_out(0),
      SET => GND
    );
  mem_R_DPL_data_out_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(1),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_1_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_1_C,
      O => mem_R_DPL_data_out(1),
      SET => GND
    );
  mem_R_DPL_data_out_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(2),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_2_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_2_C,
      O => mem_R_DPL_data_out(2),
      SET => GND
    );
  mem_R_DPL_data_out_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(3),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_3_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_3_C,
      O => mem_R_DPL_data_out(3),
      SET => GND
    );
  mem_R_DPL_data_out_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(4),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_4_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_4_C,
      O => mem_R_DPL_data_out(4),
      SET => GND
    );
  mem_R_DPL_data_out_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPL_from_writeback(5),
      CE => W_DPL_from_writeback,
      RST => mem_R_DPL_data_out_5_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPL_data_out_5_C,
      O => mem_R_DPL_data_out(5),
      SET => GND
    );
  mem_R_DPH_data_out_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(7),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_7_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_7_C,
      O => mem_R_DPH_data_out(7),
      SET => GND
    );
  mem_R_DPH_data_out_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(0),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_0_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_0_C,
      O => mem_R_DPH_data_out(0),
      SET => GND
    );
  mem_R_DPH_data_out_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(1),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_1_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_1_C,
      O => mem_R_DPH_data_out(1),
      SET => GND
    );
  mem_R_DPH_data_out_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(2),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_2_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_2_C,
      O => mem_R_DPH_data_out(2),
      SET => GND
    );
  mem_R_DPH_data_out_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(3),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_3_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_3_C,
      O => mem_R_DPH_data_out(3),
      SET => GND
    );
  mem_R_DPH_data_out_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(4),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_4_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_4_C,
      O => mem_R_DPH_data_out(4),
      SET => GND
    );
  mem_R_DPH_data_out_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_DPH_from_writeback(5),
      CE => W_DPH_from_writeback,
      RST => mem_R_DPH_data_out_5_GSR_OR,
      CLK => NlwInverterSignal_mem_R_DPH_data_out_5_C,
      O => mem_R_DPH_data_out(5),
      SET => GND
    );
  mem_R_B_data_out_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(7),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_7_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_7_C,
      O => mem_R_B_data_out(7),
      SET => GND
    );
  mem_R_B_data_out_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(0),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_0_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_0_C,
      O => mem_R_B_data_out(0),
      SET => GND
    );
  mem_R_B_data_out_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(1),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_1_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_1_C,
      O => mem_R_B_data_out(1),
      SET => GND
    );
  mem_R_B_data_out_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(2),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_2_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_2_C,
      O => mem_R_B_data_out(2),
      SET => GND
    );
  mem_R_B_data_out_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(3),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_3_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_3_C,
      O => mem_R_B_data_out(3),
      SET => GND
    );
  mem_R_B_data_out_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(4),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_4_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_4_C,
      O => mem_R_B_data_out(4),
      SET => GND
    );
  mem_R_B_data_out_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_B_from_writeback(5),
      CE => W_B_from_writeback,
      RST => mem_R_B_data_out_5_GSR_OR,
      CLK => NlwInverterSignal_mem_R_B_data_out_5_C,
      O => mem_R_B_data_out(5),
      SET => GND
    );
  mem_R_A_data_out_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(7),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_7_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_7_C,
      O => mem_R_A_data_out(7),
      SET => GND
    );
  mem_R_A_data_out_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(0),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_0_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_0_C,
      O => mem_R_A_data_out(0),
      SET => GND
    );
  mem_R_A_data_out_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(1),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_1_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_1_C,
      O => mem_R_A_data_out(1),
      SET => GND
    );
  mem_R_A_data_out_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(2),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_2_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_2_C,
      O => mem_R_A_data_out(2),
      SET => GND
    );
  mem_R_A_data_out_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(3),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_3_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_3_C,
      O => mem_R_A_data_out(3),
      SET => GND
    );
  mem_R_A_data_out_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(4),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_4_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_4_C,
      O => mem_R_A_data_out(4),
      SET => GND
    );
  mem_R_A_data_out_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => di_A_from_writeback(5),
      CE => W_A_from_writeback,
      RST => mem_R_A_data_out_5_GSR_OR,
      CLK => NlwInverterSignal_mem_R_A_data_out_5_C,
      O => mem_R_A_data_out(5),
      SET => GND
    );
  wb_stage_di_A_7_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(7),
      O => di_A_from_writeback(7)
    );
  mux19_databus_out1_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(4),
      O => databus_from_mux19(4)
    );
  wb_stage_di_DPL_6_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => N1423,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(6)
    );
  cu_sel_mux6_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0020(1),
      CLK => cu_n0330,
      O => cu_sel_mux6(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_66_5 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_141,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_142,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_66
    );
  cu_Ker141 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(1),
      ADR2 => cu_N39,
      ADR3 => ifid_buff_out1(2),
      O => cu_N14
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_130_6 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_285,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_286,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_130
    );
  wb_stage_din_rid_5 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(5),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(5),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  mem_PC_out_9_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_9_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_25_Q,
      O => pc_out_from_mem(9)
    );
  mux19_databus_out1_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(1),
      O => databus_from_mux19(1)
    );
  wb_stage_w_addr0_7_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE11022,
      ADR1 => CHOICE11027,
      O => write_addr0_from_writeback(7)
    );
  wb_stage_w_data1_6_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10966,
      ADR1 => CHOICE10971,
      O => write_data1_from_writeback(6)
    );
  wb_stage_p3_in_3_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(3),
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(3)
    );
  wb_stage_p3_in_4_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(4),
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(4)
    );
  cu_n03111 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(3),
      O => cu_n0311
    );
  wb_stage_p3_in_5_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(5)
    );
  wb_stage_p3_in_6_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(6)
    );
  cu_PC_load_in_7 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      CLK => cu_n0328,
      O => cu_PC_load_in,
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_p3_in_7_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(7)
    );
  wb_stage_w_addr0_0_1 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => wb_stage_N9,
      ADR1 => wb_stage_N28,
      ADR2 => write_addr0_from_writeback(0),
      O => write_addr0_from_writeback(0)
    );
  cu_n0022_1_1 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => cu_n0137,
      ADR1 => Reset_IBUF,
      O => cu_n0022(1)
    );
  wb_stage_w_addr0_7_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_D11(7),
      ADR3 => write_addr0_from_writeback(7),
      O => CHOICE11027
    );
  wb_stage_W_DPL : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N68,
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_n0184(6),
      ADR3 => N6223,
      O => W_DPL_from_writeback
    );
  cu_n03271 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => cu_n0321(1),
      O => cu_n0327
    );
  cu_n032920 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => cu_N46,
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(5),
      ADR3 => ifid_buff_out1(3),
      O => CHOICE10658
    );
  fet_stage_source_PC_9_SW0 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out2(1),
      O => N905
    );
  cu_EN_latch_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      CLK => cu_n0327,
      O => cu_EN_latch(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_w_data1_6_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => write_data1_from_writeback(6),
      O => CHOICE10971
    );
  fet_stage_source_PC_10_SW0 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out2(2),
      O => N903
    );
  cu_n0023_0_42 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE10702,
      ADR1 => Reset_IBUF,
      O => cu_n0023(0)
    );
  fet_stage_que_state_M_inst_que_code_3_194_G : X_LUT4
    generic map(
      INIT => X"B4FF"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => rom_DATA_BUS(4),
      ADR2 => rom_DATA_BUS(6),
      ADR3 => cu_sel_rd,
      O => N6403
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2881 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net637,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net639,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_288
    );
  wb_stage_di_psw_3_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(3),
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => wb_stage_n0183(7),
      O => di_psw_from_writeback_3_Q
    );
  wb_stage_Ker381 : X_LUT3
    generic map(
      INIT => X"D5"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_N71,
      ADR2 => wb_stage_n0150,
      O => wb_stage_N38
    );
  wb_stage_di_psw_5_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => wb_stage_n0183(7),
      O => di_psw_from_writeback_5_Q
    );
  wb_stage_n019043 : X_LUT4
    generic map(
      INIT => X"EEFE"
    )
    port map (
      ADR0 => N6199,
      ADR1 => exwb_buff_out_D11(3),
      ADR2 => CHOICE10683,
      ADR3 => exwb_buff_out_D22(2),
      O => wb_stage_n0190
    );
  wb_stage_Ker681 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(6),
      ADR1 => wb_stage_N74,
      ADR2 => wb_stage_N311,
      ADR3 => exwb_buff_out_D11(1),
      O => wb_stage_N68
    );
  wb_stage_w_addr1_6_32 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => CHOICE11709,
      ADR2 => CHOICE11708,
      ADR3 => CHOICE11714,
      O => write_addr1_from_writeback(6)
    );
  exe_stage_alu_m_n0364132 : X_LUT4
    generic map(
      INIT => X"FF82"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0153(7),
      ADR2 => exe_stage_alu_m_N581,
      ADR3 => CHOICE11965,
      O => CHOICE11972
    );
  wb_stage_p2_in_4_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(4),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => N826,
      O => p2_in_from_writeback(4)
    );
  wb_stage_di_psw_1_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(1),
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => wb_stage_n0183(7),
      O => di_psw_from_writeback_1_Q
    );
  dec_stage_d_instruction_decoder_s2_5_SW0 : X_LUT4
    generic map(
      INIT => X"1FBF"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(5),
      ADR2 => dec_stage_d_instruction_decoder_N87,
      ADR3 => r1_from_mem(5),
      O => N901
    );
  exe_stage_alu_m_n045446 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0242,
      ADR2 => exe_stage_alu_m_n0233,
      ADR3 => exe_stage_alu_m_n0243,
      O => CHOICE12733
    );
  wb_stage_Neq_stagecy_rn_1 : X_MUX2
    port map (
      IB => wb_stage_Neq_stage_cyo1,
      IA => sp_out_from_mem(0),
      SEL => wb_stage_N4,
      O => wb_stage_Neq_stage_cyo2
    );
  wb_stage_Neq_stagelut3 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exwb_buff_out_D22(6),
      ADR1 => exwb_buff_out_D11(6),
      ADR2 => exwb_buff_out_D22(7),
      ADR3 => exwb_buff_out_D11(7),
      O => wb_stage_N5
    );
  wb_stage_Ker101 : X_LUT3
    generic map(
      INIT => X"DF"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => exwb_buff_out_D22(5),
      ADR2 => wb_stage_N78,
      O => wb_stage_N10
    );
  wb_stage_w_addr1_3_2 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => exwb_buff_out_D22(0),
      ADR2 => exwb_buff_out_D22(3),
      O => CHOICE11481
    );
  wb_stage_addr_rid_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0068(1),
      CLK => wb_stage_n0190,
      O => wb_stage_addr_rid(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_din_rid_7 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(7),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(7),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_Ker67 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => exwb_buff_out_D11(2),
      ADR1 => exwb_buff_out_D11(1),
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => N701,
      O => wb_stage_N67
    );
  wb_stage_Ker701 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_D11(1),
      ADR1 => wb_stage_N74,
      ADR2 => exwb_buff_out_D11(5),
      O => wb_stage_N70
    );
  wb_stage_din_rid_6 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(6),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(6),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_n0333155 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => CHOICE10760,
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(4),
      ADR3 => N6201,
      O => CHOICE10765
    );
  cu_n032811 : X_LUT4
    generic map(
      INIT => X"8081"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(3),
      O => CHOICE10639
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2871 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net633,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net635,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_287
    );
  wb_stage_Ker611 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => wb_stage_N34,
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D22(6),
      O => wb_stage_N61
    );
  wb_stage_p2_in_2_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(2),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => N826,
      O => p2_in_from_writeback(2)
    );
  wb_stage_Neq_stagecy_rn_2 : X_MUX2
    port map (
      IB => wb_stage_Neq_stage_cyo2,
      IA => sp_out_from_mem(0),
      SEL => wb_stage_N5,
      O => wb_stage_n0184(6)
    );
  wb_stage_din_rid_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => wb_stage_n0069(0),
      CLK => wb_stage_n0190,
      O => wb_stage_din_rid(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_Ker25 : X_LUT4
    generic map(
      INIT => X"555D"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => exwb_buff_out_D11(1),
      ADR2 => exwb_buff_out_D11(3),
      ADR3 => N6260,
      O => wb_stage_N25
    );
  dec_stage_d_instruction_decoder_s2_7_SW0 : X_LUT4
    generic map(
      INIT => X"1FBF"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(7),
      ADR2 => dec_stage_d_instruction_decoder_N87,
      ADR3 => r1_from_mem(7),
      O => N899
    );
  wb_stage_n0069_7_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out16,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(7),
      ADR3 => wb_stage_N72,
      O => CHOICE11160
    );
  dec_stage_d_instruction_decoder_alu_oprt_3_78 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11187,
      ADR1 => Reset_IBUF,
      O => alu_op_from_decode(3)
    );
  wb_stage_Ker221 : X_LUT3
    generic map(
      INIT => X"5D"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => wb_stage_N70,
      ADR2 => exwb_buff_out_D11(6),
      O => wb_stage_N22
    );
  wb_stage_Ker621 : X_LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_N71,
      ADR2 => exwb_buff_out_D22(0),
      ADR3 => wb_stage_N73,
      O => wb_stage_N62
    );
  wb_stage_Ker631 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => wb_stage_N71,
      ADR1 => wb_stage_N73,
      ADR2 => wb_stage_n0184(6),
      ADR3 => exwb_buff_out_D22(0),
      O => wb_stage_N63
    );
  wb_stage_Ker64 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => exwb_buff_out_D22(0),
      ADR1 => exwb_buff_out_D22(2),
      ADR2 => exwb_buff_out_D22(1),
      ADR3 => N1455,
      O => wb_stage_N64
    );
  wb_stage_Ker291 : X_LUT4
    generic map(
      INIT => X"D5FF"
    )
    port map (
      ADR0 => exwb_buff_out_D22(0),
      ADR1 => wb_stage_n0150,
      ADR2 => wb_stage_N71,
      ADR3 => wb_stage_n0184(6),
      O => wb_stage_N29
    );
  wb_stage_Ker81 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => exwb_buff_out_D22(5),
      ADR1 => exwb_buff_out_D22(6),
      ADR2 => exwb_buff_out_D22(4),
      ADR3 => wb_stage_N34,
      O => wb_stage_N8
    );
  wb_stage_Ker72 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => wb_stage_N34,
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D22(6),
      O => wb_stage_N7
    );
  mem_w_addr_b0_6_1_F1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(6),
      O => mem_w_addr_b0(6)
    );
  port0_out_1_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(1),
      O => port0_out_1_OBUF_GTS_TRI
    );
  mem_w_addr_b0_7_1_F1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(7),
      O => mem_w_addr_b0(7)
    );
  port0_out_3_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(3),
      O => port0_out_3_OBUF_GTS_TRI
    );
  mem_w_addr_b0_0_1_F : X_LUT4
    generic map(
      INIT => X"6240"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => sp_out_from_mem(0),
      ADR3 => write_addr0_from_writeback(0),
      O => mem_w_addr_b0(0)
    );
  mem_w_addr_b0_4_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(4),
      O => mem_w_addr_b0(4)
    );
  mem_w_addr_b0_3_1 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(3),
      O => mem_w_addr_b0(3)
    );
  mem_w_addr_b0_2_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(2),
      O => mem_w_addr_b0(2)
    );
  mem_w_addr_b0_1_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => write_addr0_from_writeback(1),
      O => mem_w_addr_b0(1)
    );
  port1_out_5_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(5),
      O => port1_out_5_OBUF_GTS_TRI
    );
  mem_PC_out_10_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_10_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_26_Q,
      O => pc_out_from_mem(10)
    );
  mem_PC_out_11_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_11_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_27_Q,
      O => pc_out_from_mem(11)
    );
  mem_PC_out_12_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_12_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_28_Q,
      O => pc_out_from_mem(12)
    );
  mem_PC_out_13_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_13_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_29_Q,
      O => pc_out_from_mem(13)
    );
  mem_PC_out_14_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_14_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_30_Q,
      O => pc_out_from_mem(14)
    );
  mem_PC_out_15_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_15_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_31_Q,
      O => pc_out_from_mem(15)
    );
  exe_stage_alu_m_n0000_3_rt_8 : X_LUT2
    generic map(
      INIT => X"A"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0000(3),
      O => exe_stage_alu_m_n0000_3_rt,
      ADR1 => GND
    );
  dec_stage_d_mux7_out1_2_29 : X_LUT4
    generic map(
      INIT => X"FF8A"
    )
    port map (
      ADR0 => ifid_buff_out2(0),
      ADR1 => mem_R_DPL_data_out(2),
      ADR2 => ifid_buff_out2(1),
      ADR3 => CHOICE12281,
      O => CHOICE12282
    );
  rom_Mrom_n0002_inst_mux_f5_1621 : X_LUT4
    generic map(
      INIT => X"B6DB"
    )
    port map (
      ADR0 => addressbus_from_fetch(2),
      ADR1 => addressbus_from_fetch(3),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(1),
      O => N6124
    );
  fet_stage_que_state_M_inst_que_code_3_69_SW0_SW0 : X_LUT4
    generic map(
      INIT => X"EEFE"
    )
    port map (
      ADR0 => rom_DATA_BUS(1),
      ADR1 => rom_DATA_BUS(4),
      ADR2 => rom_DATA_BUS(0),
      ADR3 => rom_DATA_BUS(5),
      O => N6299
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_10111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(12),
      ADR2 => write_data0_from_writeback(4),
      O => N6405
    );
  exe_stage_alu_m_n043323 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => exe_stage_src1(1),
      ADR1 => exe_stage_alu_m_n0244,
      ADR2 => CHOICE12707,
      ADR3 => exe_stage_alu_m_N5,
      O => CHOICE12710
    );
  mux19_databus_out1_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(2),
      O => databus_from_mux19(2)
    );
  mem_PC_out_8_1 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => mem_internal_ram_bank_n0018_8_Q,
      ADR1 => mem_r_addr_b0_0_Q,
      ADR2 => Reset_IBUF,
      ADR3 => mem_internal_ram_bank_n0018_24_Q,
      O => pc_out_from_mem(8)
    );
  mux19_databus_out1_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(5),
      O => databus_from_mux19(5)
    );
  rom_n0003_4_1 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_Mrom_n0002_N67,
      ADR1 => cu_sel_rd,
      ADR2 => addressbus_from_fetch(7),
      O => rom_n0003(4)
    );
  exwb_buff_out_R_B_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(2),
      RST => exwb_buff_out_R_B_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(2),
      CE => VCC,
      SET => GND
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_251 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => mem_w_addr_b1(0),
      ADR1 => mem_w_addr_b1(5),
      ADR2 => mem_w_addr_b1(6),
      ADR3 => mem_w_addr_b1(7),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_25
    );
  exe_stage_alu_m_n0364204 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11982,
      ADR1 => Reset_IBUF,
      O => RA_out_from_execute(7)
    );
  exe_stage_alu_m_n043031 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0243,
      ADR1 => exe_stage_src2(0),
      ADR2 => exe_stage_alu_m_n0008(8),
      ADR3 => exe_stage_alu_m_n0224,
      O => CHOICE12772
    );
  exe_stage_alu_m_n0469122 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0165(3),
      ADR1 => exe_stage_alu_m_N851,
      ADR2 => exe_stage_alu_m_N911,
      ADR3 => N6311,
      O => CHOICE12618
    );
  fet_stage_que_state_M_inst_que_code_3_171 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => databus_from_mux19(1),
      ADR1 => CHOICE11757,
      ADR2 => databus_from_mux19(2),
      ADR3 => CHOICE11752,
      O => CHOICE11759
    );
  dec_stage_d_mux7_out1_4_63 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(4),
      ADR3 => mem_R_B_data_out(4),
      O => CHOICE12157
    );
  dec_stage_d_mux9_out1_6_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(14),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12518
    );
  exe_stage_alu_m_n047657 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12554,
      ADR1 => CHOICE12550,
      ADR2 => exe_stage_src1(4),
      ADR3 => N6177,
      O => CHOICE12563
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_4111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(6),
      ADR2 => write_data1_from_writeback(6),
      O => N6407
    );
  exe_stage_alu_m_n034719 : X_LUT4
    generic map(
      INIT => X"8828"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0153(6),
      ADR2 => exe_stage_alu_m_n0221,
      ADR3 => exe_stage_alu_m_n0153(5),
      O => CHOICE11833
    );
  fet_stage_que_state_M_state_FFd2_In132_SW0 : X_LUT4
    generic map(
      INIT => X"B1FF"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => rom_DATA_BUS(0),
      ADR2 => N6305,
      ADR3 => cu_sel_rd,
      O => N6185
    );
  wb_stage_n0150_G : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => exwb_buff_out_D22(1),
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D22(6),
      O => N6409
    );
  wb_stage_Ker751 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => exwb_buff_out_D11(4),
      ADR2 => exwb_buff_out_D11(1),
      ADR3 => wb_stage_N74,
      O => wb_stage_N75
    );
  fet_stage_que_state_M_inst_que_code_3_157 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => databus_from_mux19(5),
      ADR1 => databus_from_mux19(0),
      ADR2 => databus_from_mux19(4),
      ADR3 => fet_stage_que_state_M_N9,
      O => CHOICE11757
    );
  exe_stage_alu_m_n045992 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0220,
      ADR2 => exe_stage_src1(1),
      ADR3 => exe_stage_alu_m_N85,
      O => CHOICE12691
    );
  fet_stage_que_state_M_Ker431 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(5),
      O => fet_stage_que_state_M_N431
    );
  exe_stage_alu_m_n036418 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0001(3),
      ADR1 => exe_stage_alu_m_n0222,
      ADR2 => exe_stage_alu_m_n0166(3),
      ADR3 => exe_stage_alu_m_n0238,
      O => CHOICE11940
    );
  dec_stage_d_mux7_out1_5_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(13),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12104
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_2111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(4),
      ADR2 => write_data1_from_writeback(4),
      O => N6411
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_3111_G : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(5),
      ADR2 => write_data1_from_writeback(5),
      O => N6413
    );
  exe_stage_alu_m_n048936 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE12734,
      ADR1 => exe_stage_src2(5),
      ADR2 => CHOICE11886,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE11891
    );
  exe_stage_alu_m_n036491 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(7),
      ADR1 => exe_stage_alu_m_N871,
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => CHOICE11961,
      O => CHOICE11963
    );
  exe_stage_alu_m_n0364194 : X_LUT4
    generic map(
      INIT => X"FF82"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0223,
      ADR1 => exe_stage_alu_m_n0005(3),
      ADR2 => exe_stage_alu_m_n0215(0),
      ADR3 => CHOICE11981,
      O => CHOICE11982
    );
  exe_stage_alu_m_n0459129_SW1 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0165(1),
      ADR1 => exe_stage_alu_m_N851,
      ADR2 => exe_stage_alu_m_N911,
      ADR3 => CHOICE12691,
      O => N6295
    );
  exe_stage_alu_m_n043923 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => exe_stage_src1(3),
      ADR1 => exe_stage_alu_m_n0244,
      ADR2 => CHOICE12804,
      ADR3 => exe_stage_alu_m_N5,
      O => CHOICE12807
    );
  dec_stage_d_mux7_out1_3_63 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(3),
      ADR3 => mem_R_B_data_out(3),
      O => CHOICE12091
    );
  exe_stage_alu_m_des_cy90 : X_LUT4
    generic map(
      INIT => X"2232"
    )
    port map (
      ADR0 => CHOICE12008,
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => CHOICE12011,
      ADR3 => exe_stage_alu_m_N581,
      O => CHOICE12015
    );
  dec_stage_d_mux7_out1_2_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(10),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12271
    );
  dec_stage_d_mux9_out1_2_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(10),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12342
    );
  exe_stage_alu_m_n043051 : X_LUT3
    generic map(
      INIT => X"EC"
    )
    port map (
      ADR0 => CHOICE12777,
      ADR1 => CHOICE12772,
      ADR2 => exe_stage_alu_m_alu_n0073_7_cyo,
      O => CHOICE12779
    );
  datapath_fet_stage_next_PC_0_lut : X_LUT3
    generic map(
      INIT => X"1B"
    )
    port map (
      ADR0 => cu_sel_mux5(0),
      ADR1 => fet_stage_PC_M_data_out(0),
      ADR2 => fet_stage_JCall_out(0),
      O => fet_stage_next_PC(0)
    );
  dec_stage_d_mux9_out1_0_187_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(0),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(0),
      O => N6415
    );
  exe_stage_alu_m_des_ov153 : X_LUT4
    generic map(
      INIT => X"FF28"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0249,
      ADR1 => exe_stage_alu_m_n0166(3),
      ADR2 => exe_stage_alu_m_n0167(1),
      ADR3 => CHOICE12060,
      O => CHOICE12067
    );
  fet_stage_que_state_M_inst_que_code_3_143 : X_LUT4
    generic map(
      INIT => X"11F1"
    )
    port map (
      ADR0 => databus_from_mux19(7),
      ADR1 => databus_from_mux19(4),
      ADR2 => fet_stage_que_state_M_N21,
      ADR3 => databus_from_mux19(5),
      O => CHOICE11752
    );
  dec_stage_d_mux9_out1_7_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(7),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(7),
      O => N6417
    );
  dec_stage_d_mux7_out1_1_36 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => CHOICE12317,
      ADR1 => ifid_buff_out2(5),
      ADR2 => ifid_buff_out2(6),
      ADR3 => ifid_buff_out2(4),
      O => CHOICE12318
    );
  exe_stage_alu_m_n0459129 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => N6273,
      ADR1 => CHOICE12669,
      ADR2 => CHOICE12686,
      ADR3 => N6295,
      O => CHOICE12696
    );
  r_addr0_from_decode_4_1_G : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => cu_sel_mux6(1),
      ADR1 => ifid_buff_out1(0),
      ADR2 => r0_from_mem(4),
      ADR3 => r1_from_mem(4),
      O => N6419
    );
  dec_stage_d_mux7_out1_2_60 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(2),
      ADR3 => mem_R_A_data_out(2),
      O => CHOICE12288
    );
  exe_stage_alu_m_n03475 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_N941,
      ADR1 => exe_stage_alu_m_n0005(2),
      ADR2 => idex_buff_out_Opcode(4),
      O => CHOICE11827
    );
  exe_stage_alu_m_n0364157 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0215(0),
      ADR1 => exe_stage_alu_m_n0238,
      ADR2 => exe_stage_alu_m_n0166(3),
      ADR3 => CHOICE11977,
      O => CHOICE11979
    );
  dec_stage_d_mux9_out1_6_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(6),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(6),
      O => N6421
    );
  fet_stage_que_state_M_state_FFd2_In54 : X_LUT4
    generic map(
      INIT => X"FF2A"
    )
    port map (
      ADR0 => databus_from_mux19(0),
      ADR1 => databus_from_mux19(4),
      ADR2 => fet_stage_que_state_M_N27,
      ADR3 => CHOICE11656,
      O => CHOICE11657
    );
  fet_stage_que_state_M_next_Mcode_2_186 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => CHOICE11621,
      ADR1 => databus_from_mux19(3),
      ADR2 => CHOICE11605,
      ADR3 => CHOICE11629,
      O => CHOICE11630
    );
  exe_stage_alu_m_n048923 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_N861,
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => exe_stage_alu_m_n0263,
      O => CHOICE11886
    );
  dec_stage_d_mux7_out1_7_78 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(7),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(7),
      O => CHOICE12229
    );
  exe_stage_alu_m_n047692 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0220,
      ADR2 => exe_stage_src1(4),
      ADR3 => exe_stage_alu_m_n0216(4),
      O => CHOICE12570
    );
  fet_stage_que_state_M_state_FFd2_In50 : X_LUT4
    generic map(
      INIT => X"131F"
    )
    port map (
      ADR0 => databus_from_mux19(4),
      ADR1 => databus_from_mux19(7),
      ADR2 => databus_from_mux19(5),
      ADR3 => databus_from_mux19(2),
      O => CHOICE11656
    );
  dec_stage_d_mux9_out1_6_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(6),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(6),
      O => CHOICE12524
    );
  mem_r_addr_b0_0_1 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(0),
      O => mem_r_addr_b0_0_Q
    );
  mem_r_addr_b0_1_1 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(1),
      O => mem_r_addr_b0_1_Q
    );
  mem_r_addr_b0_2_1 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(2),
      O => mem_r_addr_b0_2_Q
    );
  mem_r_addr_b0_3_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(3),
      O => mem_r_addr_b0_3_Q
    );
  mem_r_addr_b0_4_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => cu_sel_mux12(1),
      ADR1 => r_addr0_from_decode(4),
      O => mem_r_addr_b0_4_Q
    );
  exe_stage_alu_m_n022612 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => exe_stage_src2(0),
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_src2(2),
      ADR3 => exe_stage_src2(3),
      O => CHOICE11816
    );
  port0_in_0_IBUF_9 : X_BUF
    port map (
      I => port0_in(0),
      O => port0_in_0_IBUF
    );
  mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0 : X_RAMB16_S36_S36
    generic map(
      WRITE_MODE_A => "NO_CHANGE",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000"
    )
    port map (
      CLKA => Clock_BUFGP,
      CLKB => Clock_BUFGP,
      ENA => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      ENB => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      SSRA => fet_stage_Temp1_data(12),
      SSRB => fet_stage_Temp1_data(12),
      WEA => load_rid_from_writeback,
      WEB => fet_stage_Temp1_data(12),
      GSR => GSR,
      ADDRA(8) => fet_stage_Temp1_data(12),
      ADDRA(7) => fet_stage_Temp1_data(12),
      ADDRA(6) => fet_stage_Temp1_data(12),
      ADDRA(5) => fet_stage_Temp1_data(12),
      ADDRA(4) => fet_stage_Temp1_data(12),
      ADDRA(3) => fet_stage_Temp1_data(12),
      ADDRA(2) => wb_stage_addr_rid(2),
      ADDRA(1) => wb_stage_addr_rid(1),
      ADDRA(0) => wb_stage_addr_rid(0),
      ADDRB(8) => fet_stage_Temp1_data(12),
      ADDRB(7) => fet_stage_Temp1_data(12),
      ADDRB(6) => fet_stage_Temp1_data(12),
      ADDRB(5) => fet_stage_Temp1_data(12),
      ADDRB(4) => fet_stage_Temp1_data(12),
      ADDRB(3) => fet_stage_Temp1_data(12),
      ADDRB(2) => mem_PSW_psw(4),
      ADDRB(1) => mem_PSW_psw(3),
      ADDRB(0) => sp_out_from_mem(0),
      DIA(31) => fet_stage_Temp1_data(12),
      DIA(30) => fet_stage_Temp1_data(12),
      DIA(29) => fet_stage_Temp1_data(12),
      DIA(28) => fet_stage_Temp1_data(12),
      DIA(27) => fet_stage_Temp1_data(12),
      DIA(26) => fet_stage_Temp1_data(12),
      DIA(25) => fet_stage_Temp1_data(12),
      DIA(24) => fet_stage_Temp1_data(12),
      DIA(23) => fet_stage_Temp1_data(12),
      DIA(22) => fet_stage_Temp1_data(12),
      DIA(21) => fet_stage_Temp1_data(12),
      DIA(20) => fet_stage_Temp1_data(12),
      DIA(19) => fet_stage_Temp1_data(12),
      DIA(18) => fet_stage_Temp1_data(12),
      DIA(17) => fet_stage_Temp1_data(12),
      DIA(16) => fet_stage_Temp1_data(12),
      DIA(15) => fet_stage_Temp1_data(12),
      DIA(14) => fet_stage_Temp1_data(12),
      DIA(13) => fet_stage_Temp1_data(12),
      DIA(12) => fet_stage_Temp1_data(12),
      DIA(11) => fet_stage_Temp1_data(12),
      DIA(10) => fet_stage_Temp1_data(12),
      DIA(9) => fet_stage_Temp1_data(12),
      DIA(8) => fet_stage_Temp1_data(12),
      DIA(7) => wb_stage_din_rid(7),
      DIA(6) => wb_stage_din_rid(6),
      DIA(5) => wb_stage_din_rid(5),
      DIA(4) => wb_stage_din_rid(4),
      DIA(3) => wb_stage_din_rid(3),
      DIA(2) => wb_stage_din_rid(2),
      DIA(1) => wb_stage_din_rid(1),
      DIA(0) => wb_stage_din_rid(0),
      DIB(31) => fet_stage_Temp1_data(12),
      DIB(30) => fet_stage_Temp1_data(12),
      DIB(29) => fet_stage_Temp1_data(12),
      DIB(28) => fet_stage_Temp1_data(12),
      DIB(27) => fet_stage_Temp1_data(12),
      DIB(26) => fet_stage_Temp1_data(12),
      DIB(25) => fet_stage_Temp1_data(12),
      DIB(24) => fet_stage_Temp1_data(12),
      DIB(23) => fet_stage_Temp1_data(12),
      DIB(22) => fet_stage_Temp1_data(12),
      DIB(21) => fet_stage_Temp1_data(12),
      DIB(20) => fet_stage_Temp1_data(12),
      DIB(19) => fet_stage_Temp1_data(12),
      DIB(18) => fet_stage_Temp1_data(12),
      DIB(17) => fet_stage_Temp1_data(12),
      DIB(16) => fet_stage_Temp1_data(12),
      DIB(15) => fet_stage_Temp1_data(12),
      DIB(14) => fet_stage_Temp1_data(12),
      DIB(13) => fet_stage_Temp1_data(12),
      DIB(12) => fet_stage_Temp1_data(12),
      DIB(11) => fet_stage_Temp1_data(12),
      DIB(10) => fet_stage_Temp1_data(12),
      DIB(9) => fet_stage_Temp1_data(12),
      DIB(8) => fet_stage_Temp1_data(12),
      DIB(7) => fet_stage_Temp1_data(12),
      DIB(6) => fet_stage_Temp1_data(12),
      DIB(5) => fet_stage_Temp1_data(12),
      DIB(4) => fet_stage_Temp1_data(12),
      DIB(3) => fet_stage_Temp1_data(12),
      DIB(2) => fet_stage_Temp1_data(12),
      DIB(1) => fet_stage_Temp1_data(12),
      DIB(0) => fet_stage_Temp1_data(12),
      DIPA(3) => fet_stage_Temp1_data(12),
      DIPA(2) => fet_stage_Temp1_data(12),
      DIPA(1) => fet_stage_Temp1_data(12),
      DIPA(0) => fet_stage_Temp1_data(12),
      DIPB(3) => fet_stage_Temp1_data(12),
      DIPB(2) => fet_stage_Temp1_data(12),
      DIPB(1) => fet_stage_Temp1_data(12),
      DIPB(0) => fet_stage_Temp1_data(12),
      DOA(31) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_31_UNCONNECTED,
      DOA(30) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_30_UNCONNECTED,
      DOA(29) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_29_UNCONNECTED,
      DOA(28) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_28_UNCONNECTED,
      DOA(27) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_27_UNCONNECTED,
      DOA(26) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_26_UNCONNECTED,
      DOA(25) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_25_UNCONNECTED,
      DOA(24) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_24_UNCONNECTED,
      DOA(23) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_23_UNCONNECTED,
      DOA(22) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_22_UNCONNECTED,
      DOA(21) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_21_UNCONNECTED,
      DOA(20) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_20_UNCONNECTED,
      DOA(19) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_19_UNCONNECTED,
      DOA(18) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_18_UNCONNECTED,
      DOA(17) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_17_UNCONNECTED,
      DOA(16) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_16_UNCONNECTED,
      DOA(15) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_15_UNCONNECTED,
      DOA(14) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_14_UNCONNECTED,
      DOA(13) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_13_UNCONNECTED,
      DOA(12) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_12_UNCONNECTED,
      DOA(11) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_11_UNCONNECTED,
      DOA(10) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_10_UNCONNECTED,
      DOA(9) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_9_UNCONNECTED,
      DOA(8) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_8_UNCONNECTED,
      DOA(7) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_7_UNCONNECTED,
      DOA(6) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_6_UNCONNECTED,
      DOA(5) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_5_UNCONNECTED,
      DOA(4) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_4_UNCONNECTED,
      DOA(3) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_3_UNCONNECTED,
      DOA(2) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_2_UNCONNECTED,
      DOA(1) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_1_UNCONNECTED,
      DOA(0) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOA_0_UNCONNECTED,
      DOPA(3) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_3_UNCONNECTED,
      DOPA(2) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_2_UNCONNECTED,
      DOPA(1) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_1_UNCONNECTED,
      DOPA(0) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPA_0_UNCONNECTED,
      DOB(31) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_31_UNCONNECTED,
      DOB(30) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_30_UNCONNECTED,
      DOB(29) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_29_UNCONNECTED,
      DOB(28) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_28_UNCONNECTED,
      DOB(27) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_27_UNCONNECTED,
      DOB(26) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_26_UNCONNECTED,
      DOB(25) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_25_UNCONNECTED,
      DOB(24) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_24_UNCONNECTED,
      DOB(23) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_23_UNCONNECTED,
      DOB(22) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_22_UNCONNECTED,
      DOB(21) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_21_UNCONNECTED,
      DOB(20) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_20_UNCONNECTED,
      DOB(19) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_19_UNCONNECTED,
      DOB(18) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_18_UNCONNECTED,
      DOB(17) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_17_UNCONNECTED,
      DOB(16) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_16_UNCONNECTED,
      DOB(15) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_15_UNCONNECTED,
      DOB(14) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_14_UNCONNECTED,
      DOB(13) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_13_UNCONNECTED,
      DOB(12) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_12_UNCONNECTED,
      DOB(11) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_11_UNCONNECTED,
      DOB(10) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_10_UNCONNECTED,
      DOB(9) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_9_UNCONNECTED,
      DOB(8) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOB_8_UNCONNECTED,
      DOB(7) => r1_from_mem(7),
      DOB(6) => r1_from_mem(6),
      DOB(5) => r1_from_mem(5),
      DOB(4) => r1_from_mem(4),
      DOB(3) => r1_from_mem(3),
      DOB(2) => r1_from_mem(2),
      DOB(1) => r1_from_mem(1),
      DOB(0) => r1_from_mem(0),
      DOPB(3) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_3_UNCONNECTED,
      DOPB(2) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_2_UNCONNECTED,
      DOPB(1) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_1_UNCONNECTED,
      DOPB(0) => NLW_mem_Inst_rid_Mram_R0R1_ren_inst_ramb_0_DOPB_0_UNCONNECTED
    );
  port2_in_6_IBUF_10 : X_BUF
    port map (
      I => port2_in(6),
      O => port2_in_6_IBUF
    );
  mem_Inst_rid_Mram_R0R1_inst_ramb_1 : X_RAMB16_S36_S36
    generic map(
      WRITE_MODE_A => "NO_CHANGE",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000"
    )
    port map (
      CLKA => Clock_BUFGP,
      CLKB => Clock_BUFGP,
      ENA => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      ENB => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      SSRA => fet_stage_Temp1_data(12),
      SSRB => fet_stage_Temp1_data(12),
      WEA => load_rid_from_writeback,
      WEB => fet_stage_Temp1_data(12),
      GSR => GSR,
      ADDRA(8) => fet_stage_Temp1_data(12),
      ADDRA(7) => fet_stage_Temp1_data(12),
      ADDRA(6) => fet_stage_Temp1_data(12),
      ADDRA(5) => fet_stage_Temp1_data(12),
      ADDRA(4) => fet_stage_Temp1_data(12),
      ADDRA(3) => fet_stage_Temp1_data(12),
      ADDRA(2) => wb_stage_addr_rid(2),
      ADDRA(1) => wb_stage_addr_rid(1),
      ADDRA(0) => wb_stage_addr_rid(0),
      ADDRB(8) => fet_stage_Temp1_data(12),
      ADDRB(7) => fet_stage_Temp1_data(12),
      ADDRB(6) => fet_stage_Temp1_data(12),
      ADDRB(5) => fet_stage_Temp1_data(12),
      ADDRB(4) => fet_stage_Temp1_data(12),
      ADDRB(3) => fet_stage_Temp1_data(12),
      ADDRB(2) => mem_PSW_psw(4),
      ADDRB(1) => mem_PSW_psw(3),
      ADDRB(0) => fet_stage_Temp1_data(12),
      DIA(31) => fet_stage_Temp1_data(12),
      DIA(30) => fet_stage_Temp1_data(12),
      DIA(29) => fet_stage_Temp1_data(12),
      DIA(28) => fet_stage_Temp1_data(12),
      DIA(27) => fet_stage_Temp1_data(12),
      DIA(26) => fet_stage_Temp1_data(12),
      DIA(25) => fet_stage_Temp1_data(12),
      DIA(24) => fet_stage_Temp1_data(12),
      DIA(23) => fet_stage_Temp1_data(12),
      DIA(22) => fet_stage_Temp1_data(12),
      DIA(21) => fet_stage_Temp1_data(12),
      DIA(20) => fet_stage_Temp1_data(12),
      DIA(19) => fet_stage_Temp1_data(12),
      DIA(18) => fet_stage_Temp1_data(12),
      DIA(17) => fet_stage_Temp1_data(12),
      DIA(16) => fet_stage_Temp1_data(12),
      DIA(15) => fet_stage_Temp1_data(12),
      DIA(14) => fet_stage_Temp1_data(12),
      DIA(13) => fet_stage_Temp1_data(12),
      DIA(12) => fet_stage_Temp1_data(12),
      DIA(11) => fet_stage_Temp1_data(12),
      DIA(10) => fet_stage_Temp1_data(12),
      DIA(9) => fet_stage_Temp1_data(12),
      DIA(8) => fet_stage_Temp1_data(12),
      DIA(7) => wb_stage_din_rid(7),
      DIA(6) => wb_stage_din_rid(6),
      DIA(5) => wb_stage_din_rid(5),
      DIA(4) => wb_stage_din_rid(4),
      DIA(3) => wb_stage_din_rid(3),
      DIA(2) => wb_stage_din_rid(2),
      DIA(1) => wb_stage_din_rid(1),
      DIA(0) => wb_stage_din_rid(0),
      DIB(31) => fet_stage_Temp1_data(12),
      DIB(30) => fet_stage_Temp1_data(12),
      DIB(29) => fet_stage_Temp1_data(12),
      DIB(28) => fet_stage_Temp1_data(12),
      DIB(27) => fet_stage_Temp1_data(12),
      DIB(26) => fet_stage_Temp1_data(12),
      DIB(25) => fet_stage_Temp1_data(12),
      DIB(24) => fet_stage_Temp1_data(12),
      DIB(23) => fet_stage_Temp1_data(12),
      DIB(22) => fet_stage_Temp1_data(12),
      DIB(21) => fet_stage_Temp1_data(12),
      DIB(20) => fet_stage_Temp1_data(12),
      DIB(19) => fet_stage_Temp1_data(12),
      DIB(18) => fet_stage_Temp1_data(12),
      DIB(17) => fet_stage_Temp1_data(12),
      DIB(16) => fet_stage_Temp1_data(12),
      DIB(15) => fet_stage_Temp1_data(12),
      DIB(14) => fet_stage_Temp1_data(12),
      DIB(13) => fet_stage_Temp1_data(12),
      DIB(12) => fet_stage_Temp1_data(12),
      DIB(11) => fet_stage_Temp1_data(12),
      DIB(10) => fet_stage_Temp1_data(12),
      DIB(9) => fet_stage_Temp1_data(12),
      DIB(8) => fet_stage_Temp1_data(12),
      DIB(7) => fet_stage_Temp1_data(12),
      DIB(6) => fet_stage_Temp1_data(12),
      DIB(5) => fet_stage_Temp1_data(12),
      DIB(4) => fet_stage_Temp1_data(12),
      DIB(3) => fet_stage_Temp1_data(12),
      DIB(2) => fet_stage_Temp1_data(12),
      DIB(1) => fet_stage_Temp1_data(12),
      DIB(0) => fet_stage_Temp1_data(12),
      DIPA(3) => fet_stage_Temp1_data(12),
      DIPA(2) => fet_stage_Temp1_data(12),
      DIPA(1) => fet_stage_Temp1_data(12),
      DIPA(0) => fet_stage_Temp1_data(12),
      DIPB(3) => fet_stage_Temp1_data(12),
      DIPB(2) => fet_stage_Temp1_data(12),
      DIPB(1) => fet_stage_Temp1_data(12),
      DIPB(0) => fet_stage_Temp1_data(12),
      DOA(31) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_31_UNCONNECTED,
      DOA(30) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_30_UNCONNECTED,
      DOA(29) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_29_UNCONNECTED,
      DOA(28) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_28_UNCONNECTED,
      DOA(27) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_27_UNCONNECTED,
      DOA(26) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_26_UNCONNECTED,
      DOA(25) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_25_UNCONNECTED,
      DOA(24) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_24_UNCONNECTED,
      DOA(23) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_23_UNCONNECTED,
      DOA(22) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_22_UNCONNECTED,
      DOA(21) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_21_UNCONNECTED,
      DOA(20) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_20_UNCONNECTED,
      DOA(19) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_19_UNCONNECTED,
      DOA(18) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_18_UNCONNECTED,
      DOA(17) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_17_UNCONNECTED,
      DOA(16) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_16_UNCONNECTED,
      DOA(15) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_15_UNCONNECTED,
      DOA(14) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_14_UNCONNECTED,
      DOA(13) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_13_UNCONNECTED,
      DOA(12) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_12_UNCONNECTED,
      DOA(11) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_11_UNCONNECTED,
      DOA(10) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_10_UNCONNECTED,
      DOA(9) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_9_UNCONNECTED,
      DOA(8) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_8_UNCONNECTED,
      DOA(7) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_7_UNCONNECTED,
      DOA(6) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_6_UNCONNECTED,
      DOA(5) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_5_UNCONNECTED,
      DOA(4) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_4_UNCONNECTED,
      DOA(3) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_3_UNCONNECTED,
      DOA(2) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_2_UNCONNECTED,
      DOA(1) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_1_UNCONNECTED,
      DOA(0) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOA_0_UNCONNECTED,
      DOPA(3) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_3_UNCONNECTED,
      DOPA(2) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_2_UNCONNECTED,
      DOPA(1) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_1_UNCONNECTED,
      DOPA(0) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPA_0_UNCONNECTED,
      DOB(31) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_31_UNCONNECTED,
      DOB(30) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_30_UNCONNECTED,
      DOB(29) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_29_UNCONNECTED,
      DOB(28) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_28_UNCONNECTED,
      DOB(27) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_27_UNCONNECTED,
      DOB(26) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_26_UNCONNECTED,
      DOB(25) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_25_UNCONNECTED,
      DOB(24) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_24_UNCONNECTED,
      DOB(23) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_23_UNCONNECTED,
      DOB(22) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_22_UNCONNECTED,
      DOB(21) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_21_UNCONNECTED,
      DOB(20) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_20_UNCONNECTED,
      DOB(19) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_19_UNCONNECTED,
      DOB(18) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_18_UNCONNECTED,
      DOB(17) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_17_UNCONNECTED,
      DOB(16) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_16_UNCONNECTED,
      DOB(15) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_15_UNCONNECTED,
      DOB(14) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_14_UNCONNECTED,
      DOB(13) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_13_UNCONNECTED,
      DOB(12) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_12_UNCONNECTED,
      DOB(11) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_11_UNCONNECTED,
      DOB(10) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_10_UNCONNECTED,
      DOB(9) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_9_UNCONNECTED,
      DOB(8) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOB_8_UNCONNECTED,
      DOB(7) => r0_from_mem(7),
      DOB(6) => r0_from_mem(6),
      DOB(5) => r0_from_mem(5),
      DOB(4) => r0_from_mem(4),
      DOB(3) => r0_from_mem(3),
      DOB(2) => r0_from_mem(2),
      DOB(1) => r0_from_mem(1),
      DOB(0) => r0_from_mem(0),
      DOPB(3) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_3_UNCONNECTED,
      DOPB(2) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_2_UNCONNECTED,
      DOPB(1) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_1_UNCONNECTED,
      DOPB(0) => NLW_mem_Inst_rid_Mram_R0R1_inst_ramb_1_DOPB_0_UNCONNECTED
    );
  rom_Mrom_n0002_inst_mux_f5_143 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_113,
      IB => N6121,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N34
    );
  mem_PSW_Mxor_n0011_Xo_4_1 : X_LUT4
    generic map(
      INIT => X"6996"
    )
    port map (
      ADR0 => mem_R_A_data_out(0),
      ADR1 => mem_R_A_data_out(1),
      ADR2 => mem_R_A_data_out(2),
      ADR3 => mem_R_A_data_out(3),
      O => mem_PSW_Mxor_n0011_Xo(4)
    );
  rom_Mrom_n0002_inst_mux_f6_80 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N91,
      IB => rom_Mrom_n0002_N92,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N93
    );
  mem_PSW_Mxor_n0011_Xo_5_1 : X_LUT4
    generic map(
      INIT => X"6996"
    )
    port map (
      ADR0 => mem_R_A_data_out(4),
      ADR1 => mem_R_A_data_out(5),
      ADR2 => mem_R_A_data_out(6),
      ADR3 => mem_R_A_data_out(7),
      O => mem_PSW_Mxor_n0011_Xo(5)
    );
  rom_Mrom_n0002_inst_mux_f7_1 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N3,
      IB => rom_Mrom_n0002_N6,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N7
    );
  rom_Mrom_n0002_inst_mux_f6_76 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N61,
      IB => rom_Mrom_n0002_N62,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N63
    );
  cu_n03351 : X_LUT4
    generic map(
      INIT => X"FF23"
    )
    port map (
      ADR0 => cu_N15,
      ADR1 => cu_n0311,
      ADR2 => cu_N46,
      ADR3 => Reset_IBUF,
      O => cu_n0335
    );
  wb_stage_di_A_2_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(2),
      O => di_A_from_writeback(2)
    );
  cu_sel_mux4_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0017(1),
      CLK => cu_n0328,
      O => cu_sel_mux4(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  wb_stage_p1_in_1_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(1),
      O => N6239
    );
  cu_sel_mux12_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0018(1),
      CLK => cu_n0329,
      O => cu_sel_mux12(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_sel_mux5_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0019(0),
      CLK => cu_n0328,
      O => cu_sel_mux5(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_sel_mux9_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0023(1),
      CLK => cu_n0333,
      O => cu_sel_mux9(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_sel_jcall_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0028(1),
      CLK => cu_n0335,
      O => cu_sel_jcall(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_Ker22 : X_LUT4
    generic map(
      INIT => X"A8AD"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => N81,
      ADR2 => ifid_buff_out1(3),
      ADR3 => N801,
      O => cu_N22
    );
  cu_Ker371 : X_LUT2
    generic map(
      INIT => X"7"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      O => cu_N37
    );
  cu_sel_mux9_2 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0023(2),
      CLK => cu_n0333,
      O => cu_sel_mux9(2),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_sel_mux8_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0022(1),
      CLK => cu_n0332,
      O => cu_sel_mux8(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_Ker651 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(2),
      O => cu_N65
    );
  cu_sel_mux8_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0022(0),
      CLK => cu_n0332,
      O => cu_sel_mux8(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_n0333168 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => cu_N44,
      ADR1 => cu_N45,
      ADR2 => CHOICE10765,
      O => cu_n0333
    );
  cu_n0020_1_Q : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => cu_N21,
      ADR1 => ifid_buff_out1(3),
      ADR2 => Reset_IBUF,
      ADR3 => N761,
      O => cu_n0020(1)
    );
  cu_n00761 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(6),
      ADR2 => cu_N62,
      ADR3 => cu_N37,
      O => cu_n0076
    );
  wb_stage_p1_in_3_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(3),
      O => N6237
    );
  dec_stage_d_instruction_decoder_Ker2335 : X_LUT4
    generic map(
      INIT => X"0103"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(7),
      ADR2 => N6251,
      ADR3 => ifid_buff_out1(4),
      O => CHOICE11520
    );
  dec_stage_d_instruction_decoder_n01441 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => dec_stage_d_instruction_decoder_N95,
      ADR2 => dec_stage_d_instruction_decoder_N28,
      ADR3 => dec_stage_d_instruction_decoder_N88,
      O => dec_stage_d_instruction_decoder_n0144
    );
  dec_stage_d_instruction_decoder_s2_2_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N2485,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(2),
      O => s2_from_decode(2)
    );
  dec_stage_d_instruction_decoder_s2_3_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N2487,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(3),
      O => s2_from_decode(3)
    );
  dec_stage_d_instruction_decoder_s2_6_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N897,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(6),
      O => s2_from_decode(6)
    );
  dec_stage_d_instruction_decoder_s2_7_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N899,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(7),
      O => s2_from_decode(7)
    );
  dec_stage_d_instruction_decoder_d1_3_5 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(3),
      ADR2 => dec_stage_d_instruction_decoder_n0199,
      ADR3 => mem_PSW_psw(3),
      O => CHOICE11233
    );
  dec_stage_d_instruction_decoder_s1_5_1 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N23,
      ADR1 => ifid_buff_out2(5),
      ADR2 => dec_stage_d_instruction_decoder_N102,
      O => s1_from_decode(5)
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2861 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net629,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net631,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_286
    );
  exwb_buff_out_D11_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(3),
      RST => exwb_buff_out_D11_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(3),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D11_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(1),
      RST => exwb_buff_out_D11_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(1),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D11_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(0),
      RST => exwb_buff_out_D11_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(0),
      CE => VCC,
      SET => GND
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2851 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net625,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net627,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_285
    );
  exe_stage_alu_m_n034784 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11844,
      ADR1 => exe_stage_src1(6),
      ADR2 => CHOICE11839,
      ADR3 => CHOICE11852,
      O => CHOICE11854
    );
  exe_stage_alu_m_alu_n0005_0_lut : X_LUT2
    generic map(
      INIT => X"6"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0218(0),
      ADR1 => exe_stage_alu_m_n0003(4),
      O => exe_stage_alu_m_N113
    );
  dec_stage_d_instruction_decoder_n019857 : X_LUT4
    generic map(
      INIT => X"44F4"
    )
    port map (
      ADR0 => N6189,
      ADR1 => ifid_buff_out1(6),
      ADR2 => dec_stage_d_instruction_decoder_N93,
      ADR3 => ifid_buff_out1(5),
      O => dec_stage_d_instruction_decoder_n0198
    );
  dec_stage_d_instruction_decoder_s2_4_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N2489,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(4),
      O => s2_from_decode(4)
    );
  dec_stage_d_instruction_decoder_s1_0_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out2(0),
      ADR1 => dec_stage_d_instruction_decoder_N99,
      O => s1_from_decode(0)
    );
  fet_stage_que_state_M_state_FFd2_In230 : X_LUT4
    generic map(
      INIT => X"020A"
    )
    port map (
      ADR0 => fet_stage_que_state_M_N27,
      ADR1 => rom_DATA_BUS(0),
      ADR2 => fet_stage_que_state_M_N9,
      ADR3 => cu_sel_rd,
      O => CHOICE11700
    );
  dec_stage_d_instruction_decoder_s2_5_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N901,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(5),
      O => s2_from_decode(5)
    );
  dec_stage_d_instruction_decoder_Ker1021 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => cu_N39,
      ADR2 => dec_stage_d_instruction_decoder_N79,
      ADR3 => ifid_buff_out1(1),
      O => dec_stage_d_instruction_decoder_N102
    );
  dec_stage_d_instruction_decoder_Ker951 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(3),
      O => dec_stage_d_instruction_decoder_N95
    );
  dec_stage_d_instruction_decoder_d1_7_13 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11329,
      ADR1 => dec_stage_d_instruction_decoder_n0198,
      ADR2 => ifid_buff_out2(7),
      ADR3 => dec_stage_d_instruction_decoder_n0197,
      O => CHOICE11332
    );
  fet_stage_que_state_M_inst_que_code_3_240 : X_LUT3
    generic map(
      INIT => X"57"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => rom_DATA_BUS(6),
      ADR2 => rom_DATA_BUS(7),
      O => CHOICE11782
    );
  dec_stage_d_instruction_decoder_n01991 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N4,
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(5),
      O => dec_stage_d_instruction_decoder_n0199
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_66 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(7),
      O => CHOICE11372
    );
  rom_Mrom_n0002_inst_lut4_1491 : X_LUT4
    generic map(
      INIT => X"BF6B"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_149
    );
  rom_Mrom_n0002_inst_lut4_1481 : X_LUT4
    generic map(
      INIT => X"D7BC"
    )
    port map (
      ADR0 => addressbus_from_fetch(3),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(1),
      O => rom_Mrom_n0002_inst_lut4_148
    );
  exe_stage_alu_m_n0347177 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11863,
      ADR1 => exe_stage_alu_m_alu_cyo6,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => N6241,
      O => CHOICE11872
    );
  rom_Mrom_n0002_inst_mux_f7_9 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N93,
      IB => rom_Mrom_n0002_N96,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N97
    );
  exe_stage_alu_m_n0489111 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => CHOICE11906,
      ADR1 => CHOICE11899,
      ADR2 => CHOICE11896,
      ADR3 => N6293,
      O => CHOICE11909
    );
  dec_stage_d_instruction_decoder_s2_1_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N2491,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(1),
      O => s2_from_decode(1)
    );
  rom_Mrom_n0002_inst_lut4_1511 : X_LUT4
    generic map(
      INIT => X"7DEB"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(0),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_151
    );
  rom_Mrom_n0002_inst_lut4_1471 : X_LUT4
    generic map(
      INIT => X"E492"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_147
    );
  rom_Mrom_n0002_inst_mux_f6_81 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N94,
      IB => rom_Mrom_n0002_N95,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N96
    );
  port2_in_2_IBUF_11 : X_BUF
    port map (
      I => port2_in(2),
      O => port2_in_2_IBUF
    );
  rom_Mrom_n0002_inst_mux_f5_159 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_145,
      IB => N6122,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N95
    );
  rom_Mrom_n0002_inst_mux_f5_158 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_143,
      IB => N6123,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N94
    );
  rom_Mrom_n0002_inst_mux_f6_82 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N106,
      IB => rom_Mrom_n0002_N107,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N108
    );
  rom_Mrom_n0002_inst_mux_f5_154 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_131,
      IB => sp_out_from_mem(0),
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N76
    );
  rom_Mrom_n0002_inst_mux_f5_162 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_151,
      IB => N6124,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N109
    );
  rom_Mrom_n0002_inst_mux_f5_163 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_153,
      IB => rom_Mrom_n0002_inst_lut4_154,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N110
    );
  dec_stage_d_mux9_out1_4_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(12),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12443
    );
  rom_Mrom_n0002_inst_lut4_1541 : X_LUT4
    generic map(
      INIT => X"6DB6"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_154
    );
  exe_stage_alu_m_n045442 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(0),
      ADR1 => exe_stage_alu_m_n0233,
      ADR2 => exe_stage_alu_m_n0273,
      O => CHOICE12730
    );
  rom_Mrom_n0002_inst_mux_f7_7 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N63,
      IB => rom_Mrom_n0002_N66,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N67
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_63 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_126,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_127,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_14_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_127_12 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_279,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_280,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_127
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_126_13 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_277,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_278,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_126
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2291 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net513,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net515,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_229
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2801 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net621,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net623,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_280
    );
  rom_Mrom_n0002_inst_lut4_1381 : X_LUT4
    generic map(
      INIT => X"7FFF"
    )
    port map (
      ADR0 => addressbus_from_fetch(2),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_138
    );
  rom_Mrom_n0002_inst_mux_f6_83 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N109,
      IB => rom_Mrom_n0002_N110,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N111
    );
  rom_Mrom_n0002_inst_lut4_1311 : X_LUT4
    generic map(
      INIT => X"FAAD"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_131
    );
  rom_Mrom_n0002_inst_mux_f6_77 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N64,
      IB => rom_Mrom_n0002_N65,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N66
    );
  rom_Mrom_n0002_inst_mux_f7_10 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N108,
      IB => rom_Mrom_n0002_N111,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N112
    );
  rom_Mrom_n0002_inst_mux_f5_153 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_129,
      IB => N6125,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N65
    );
  rom_Mrom_n0002_inst_mux_f5_152 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_127,
      IB => N6126,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N64
    );
  rom_Mrom_n0002_inst_mux_f5_148 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_121,
      IB => fet_stage_Temp1_data(12),
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N50
    );
  rom_Mrom_n0002_inst_mux_f5_147 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_120,
      IB => fet_stage_Temp1_data(12),
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N49
    );
  rom_Mrom_n0002_inst_mux_f5_146 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_119,
      IB => fet_stage_Temp1_data(12),
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N47
    );
  rom_Mrom_n0002_inst_mux_f5_145 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_117,
      IB => rom_Mrom_n0002_inst_lut4_118,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N46
    );
  rom_Mrom_n0002_inst_lut4_1201 : X_LUT4
    generic map(
      INIT => X"1880"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_120
    );
  rom_Mrom_n0002_inst_lut4_1191 : X_LUT4
    generic map(
      INIT => X"8808"
    )
    port map (
      ADR0 => addressbus_from_fetch(3),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(2),
      O => rom_Mrom_n0002_inst_lut4_119
    );
  rom_Mrom_n0002_inst_lut4_1171 : X_LUT4
    generic map(
      INIT => X"40C8"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(3),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(2),
      O => rom_Mrom_n0002_inst_lut4_117
    );
  dec_stage_d_mux7_out1_0_60 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(0),
      ADR3 => mem_R_A_data_out(0),
      O => CHOICE12253
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2791 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net617,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net619,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_279
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2781 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net613,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net615,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_278
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_301 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => mem_w_addr_b1(0),
      ADR1 => mem_w_addr_b1(5),
      ADR2 => mem_w_addr_b1(7),
      ADR3 => mem_w_addr_b1(6),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_30
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_311 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => mem_w_addr_b1(0),
      ADR1 => mem_w_addr_b1(6),
      ADR2 => mem_w_addr_b1(7),
      ADR3 => mem_w_addr_b1(5),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_31
    );
  mux19_databus_out1_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(3),
      O => databus_from_mux19(3)
    );
  mux19_databus_out1_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(7),
      O => databus_from_mux19(7)
    );
  rom_Mrom_n0002_inst_mux_f6_73 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N46,
      IB => rom_Mrom_n0002_N47,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N48
    );
  port0_out_7_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(7),
      O => port0_out_7_OBUF_GTS_TRI
    );
  rom_Mrom_n0002_inst_lut4_1181 : X_LUT4
    generic map(
      INIT => X"0006"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_118
    );
  rom_Mrom_n0002_inst_mux_f7_4 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N33,
      IB => rom_Mrom_n0002_N36,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N37
    );
  rom_Mrom_n0002_inst_lut4_1211 : X_LUT4
    generic map(
      INIT => X"0090"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_121
    );
  rom_Mrom_n0002_inst_mux_f6_72 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N34,
      IB => rom_Mrom_n0002_N35,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N36
    );
  rom_Mrom_n0002_inst_mux_f5_144 : X_MUX2
    port map (
      IA => N6127,
      IB => rom_Mrom_n0002_inst_lut4_146,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N35
    );
  rom_Mrom_n0002_inst_mux_f6_69 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N16,
      IB => rom_Mrom_n0002_N17,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N18
    );
  rom_Mrom_n0002_inst_mux_f5_138 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_103,
      IB => N6128,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N17
    );
  rom_Mrom_n0002_inst_lut4_1081 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_108
    );
  rom_Mrom_n0002_inst_lut4_1071 : X_LUT4
    generic map(
      INIT => X"2402"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_107
    );
  rom_Mrom_n0002_inst_lut4_1041 : X_LUT4
    generic map(
      INIT => X"4924"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_104
    );
  rom_Mrom_n0002_inst_lut4_1031 : X_LUT4
    generic map(
      INIT => X"2092"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_103
    );
  rom_Mrom_n0002_inst_lut4_1011 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_101
    );
  exwb_buff_out_D11_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(2),
      RST => exwb_buff_out_D11_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(2),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D22_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(6),
      RST => exwb_buff_out_D22_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(6),
      CE => VCC,
      SET => GND
    );
  rom_Mrom_n0002_inst_mux_f5_137 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_101,
      IB => rom_Mrom_n0002_inst_lut4_102,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N16
    );
  port3_in_1_IBUF_14 : X_BUF
    port map (
      I => port3_in(1),
      O => port3_in_1_IBUF
    );
  rom_Mrom_n0002_inst_lut4_1021 : X_LUT4
    generic map(
      INIT => X"4921"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_102
    );
  rom_Mrom_n0002_inst_mux_f7_21 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => N5977,
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(1),
      ADR3 => N6211,
      O => rom_Mrom_n0002_N14
    );
  rom_Mrom_n0002_inst_lut4_1051 : X_LUT4
    generic map(
      INIT => X"8412"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_105
    );
  fet_stage_que_state_M_next_Mcode_2_182 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => fet_stage_que_state_M_N27,
      ADR1 => databus_from_mux19(4),
      ADR2 => databus_from_mux19(6),
      ADR3 => fet_stage_que_state_M_N9,
      O => CHOICE11629
    );
  exe_stage_alu_m_des_ac_SW0 : X_LUT4
    generic map(
      INIT => X"135F"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0165(4),
      ADR1 => exe_stage_alu_m_alu_n0000_3_cyo,
      ADR2 => exe_stage_alu_m_n0249,
      ADR3 => exe_stage_alu_m_N951,
      O => N3364
    );
  rom_DATA_BUS_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(6),
      RST => rom_DATA_BUS_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(6),
      CE => VCC,
      SET => GND
    );
  rom_DATA_BUS_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(5),
      RST => rom_DATA_BUS_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(5),
      CE => VCC,
      SET => GND
    );
  rom_DATA_BUS_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(3),
      RST => rom_DATA_BUS_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(3),
      CE => VCC,
      SET => GND
    );
  rom_DATA_BUS_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(2),
      RST => rom_DATA_BUS_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(2),
      CE => VCC,
      SET => GND
    );
  rom_n0003_3_1 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => addressbus_from_fetch(7),
      ADR2 => rom_Mrom_n0002_N52,
      ADR3 => rom_Mrom_n0002_N14,
      O => rom_n0003(3)
    );
  rom_n0003_2_1 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_Mrom_n0002_N37,
      ADR1 => cu_sel_rd,
      ADR2 => addressbus_from_fetch(7),
      O => rom_n0003(2)
    );
  rom_n0003_1_1 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_Mrom_n0002_N22,
      ADR1 => cu_sel_rd,
      ADR2 => addressbus_from_fetch(7),
      O => rom_n0003(1)
    );
  rom_n0003_6_1 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_Mrom_n0002_N97,
      ADR1 => cu_sel_rd,
      ADR2 => addressbus_from_fetch(7),
      O => rom_n0003(6)
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_61 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_122,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_123,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_13_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_123_15 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_271,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_272,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_123
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_122_16 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_269,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_270,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_122
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2771 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net609,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net611,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_277
    );
  rom_DATA_BUS_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(4),
      RST => rom_DATA_BUS_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(4),
      CE => VCC,
      SET => GND
    );
  rom_DATA_BUS_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(1),
      RST => rom_DATA_BUS_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(1),
      CE => VCC,
      SET => GND
    );
  rom_n0003_5_1 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_Mrom_n0002_N82,
      ADR1 => cu_sel_rd,
      ADR2 => addressbus_from_fetch(7),
      O => rom_n0003(5)
    );
  rom_n0003_7_1 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_Mrom_n0002_N112,
      ADR1 => cu_sel_rd,
      ADR2 => addressbus_from_fetch(7),
      O => rom_n0003(7)
    );
  rom_DATA_BUS_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(0),
      RST => rom_DATA_BUS_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(0),
      CE => VCC,
      SET => GND
    );
  rom_DATA_BUS_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => rom_n0003(7),
      RST => rom_DATA_BUS_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => rom_DATA_BUS(7),
      CE => VCC,
      SET => GND
    );
  rom_Mrom_n0002_inst_mux_f5_160 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_147,
      IB => rom_Mrom_n0002_inst_lut4_148,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N106
    );
  exwb_buff_out_D22_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(3),
      RST => exwb_buff_out_D22_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(3),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D22_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(2),
      RST => exwb_buff_out_D22_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(2),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D22_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(0),
      RST => exwb_buff_out_D22_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(0),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(6),
      RST => exwb_buff_out_R_A_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(6),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(3),
      RST => exwb_buff_out_R_A_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(3),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(2),
      RST => exwb_buff_out_R_A_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(2),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(0),
      RST => exwb_buff_out_R_A_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(0),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_B_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(6),
      RST => exwb_buff_out_R_B_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(6),
      CE => VCC,
      SET => GND
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2721 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net605,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net607,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_272
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2711 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net601,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net603,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_271
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2701 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net597,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net599,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_270
    );
  mux19_databus_out1_0_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => rom_DATA_BUS(0),
      O => databus_from_mux19(0)
    );
  exwb_buff_out_D22_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(5),
      RST => exwb_buff_out_D22_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(5),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D22_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(4),
      RST => exwb_buff_out_D22_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(4),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_en_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_en(0),
      RST => exwb_buff_out_en_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_en(0),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D22_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(1),
      RST => exwb_buff_out_D22_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(1),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(5),
      RST => exwb_buff_out_R_A_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(5),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => N6506,
      RST => exwb_buff_out_R_A_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(1),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_B_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(5),
      RST => exwb_buff_out_R_B_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(5),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(4),
      RST => exwb_buff_out_R_A_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(4),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_B_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(4),
      RST => exwb_buff_out_R_B_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(4),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_B_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(3),
      RST => exwb_buff_out_R_B_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(3),
      CE => VCC,
      SET => GND
    );
  port0_in_2_IBUF_17 : X_BUF
    port map (
      I => port0_in(2),
      O => port0_in_2_IBUF
    );
  cu_n0028_1_Q : X_LUT4
    generic map(
      INIT => X"3323"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => Reset_IBUF,
      ADR2 => N721,
      ADR3 => ifid_buff_out1(2),
      O => cu_n0028(1)
    );
  cu_n0023_2_1 : X_LUT3
    generic map(
      INIT => X"32"
    )
    port map (
      ADR0 => cu_n0302,
      ADR1 => Reset_IBUF,
      ADR2 => cu_n0303,
      O => cu_n0023(2)
    );
  wb_stage_p1_in_7_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(7),
      O => N6235
    );
  cu_n0018_1_Q : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => N781,
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(4),
      ADR3 => cu_N17,
      O => cu_n0018(1)
    );
  cu_EN_latch_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0015(0),
      CLK => cu_n0327,
      O => cu_EN_latch(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_n0015_0_1 : X_LUT2
    generic map(
      INIT => X"1"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => cu_n0321(1),
      O => cu_n0015(0)
    );
  cu_n0017_1_Q : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => cu_N65,
      ADR2 => cu_N27,
      ADR3 => N97,
      O => cu_n0017(1)
    );
  exwb_buff_out_R_B_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(7),
      RST => exwb_buff_out_R_B_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(7),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_en_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_en(1),
      RST => exwb_buff_out_en_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_en(1),
      CE => VCC,
      SET => GND
    );
  wb_stage_n0068_0_34_SW0 : X_LUT4
    generic map(
      INIT => X"FF2F"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => exwb_buff_out_D22(3),
      ADR2 => wb_stage_N66,
      ADR3 => exwb_buff_out_D22(2),
      O => N6277
    );
  cu_n0022_0_1 : X_LUT3
    generic map(
      INIT => X"32"
    )
    port map (
      ADR0 => cu_N68,
      ADR1 => Reset_IBUF,
      ADR2 => cu_n0076,
      O => cu_n0022(0)
    );
  cu_sel_mux6_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0020(0),
      CLK => cu_n0330,
      O => cu_sel_mux6(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  exe_stage_alu_m_n02381 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exe_stage_alu_m_N911,
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(1),
      ADR3 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_n0238
    );
  wb_stage_p1_in_6_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(6),
      O => N6233
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_67_18 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_143,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_144,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_67
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_33 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_66,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_67,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_31_Q
    );
  dec_stage_d_mux7_out1_7_50 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(7),
      ADR3 => mem_R_A_data_out(7),
      O => CHOICE12218
    );
  dec_stage_d_mux7_out1_1_88 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(1),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(1),
      O => CHOICE12334
    );
  dec_stage_d_mux7_out1_4_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(12),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12137
    );
  exe_stage_alu_m_n0347215 : X_LUT4
    generic map(
      INIT => X"5554"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => CHOICE11872,
      ADR2 => CHOICE11833,
      ADR3 => CHOICE11827,
      O => RA_out_from_execute(6)
    );
  exwb_buff_out_D22_5_1_19 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(5),
      RST => exwb_buff_out_D22_5_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22_5_1,
      CE => VCC,
      SET => GND
    );
  exe_stage_alu_m_n047693 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12563,
      ADR1 => exe_stage_alu_m_n0008(4),
      ADR2 => exe_stage_alu_m_n0224,
      ADR3 => CHOICE12570,
      O => CHOICE12571
    );
  fet_stage_que_state_M_inst_que_code_3_69_SW0 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => rom_DATA_BUS(6),
      ADR2 => N6299,
      ADR3 => rom_DATA_BUS(0),
      O => N6183
    );
  dec_stage_d_mux7_out1_5_50 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(5),
      ADR3 => mem_R_A_data_out(5),
      O => CHOICE12119
    );
  exe_stage_alu_m_n046955 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12596,
      ADR1 => exe_stage_src1(3),
      ADR2 => CHOICE12606,
      ADR3 => CHOICE12600,
      O => CHOICE12608
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_91 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => mem_w_addr_b0(5),
      ADR1 => mem_w_addr_b0(6),
      ADR2 => mem_w_addr_b0(7),
      ADR3 => mem_w_addr_b0(0),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_9
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_101 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => mem_w_addr_b0(5),
      ADR1 => mem_w_addr_b0(6),
      ADR2 => mem_w_addr_b0(7),
      ADR3 => mem_w_addr_b0(0),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_10
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_111 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => mem_w_addr_b0(6),
      ADR1 => mem_w_addr_b0(5),
      ADR2 => mem_w_addr_b0(7),
      ADR3 => mem_w_addr_b0(0),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_11
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_121 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => mem_w_addr_b0(7),
      ADR1 => mem_w_addr_b0(5),
      ADR2 => mem_w_addr_b0(0),
      ADR3 => mem_w_addr_b0(6),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_12
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_131 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => mem_w_addr_b0(7),
      ADR1 => mem_w_addr_b0(5),
      ADR2 => mem_w_addr_b0(6),
      ADR3 => mem_w_addr_b0(0),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_13
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_141 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => mem_w_addr_b0(6),
      ADR1 => mem_w_addr_b0(7),
      ADR2 => mem_w_addr_b0(0),
      ADR3 => mem_w_addr_b0(5),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_14
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut2_151 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => mem_w_addr_b0(5),
      ADR1 => mem_w_addr_b0(7),
      ADR2 => mem_w_addr_b0(0),
      ADR3 => mem_w_addr_b0(6),
      O => mem_internal_ram_bank_Mram_iram0_inst_lut2_15
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_59 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_118,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_119,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_12_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_119_20 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_263,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_264,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_119
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_118_21 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_261,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_262,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_118
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2691 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net593,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net595,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_269
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_851 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net241,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net243,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_85
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_861 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net245,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net247,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_86
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_871 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net249,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net251,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_87
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_38_22 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_85,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_86,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_38
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_39_23 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_87,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_88,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_39
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_19 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_38,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_39,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_24_Q
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_881 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net253,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net255,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_88
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2641 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net589,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net591,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_264
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2631 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net585,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net587,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_263
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2621 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net581,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net583,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_262
    );
  cu_Ker681 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(7),
      ADR2 => cu_n0311,
      ADR3 => cu_N37,
      O => cu_N68
    );
  cu_Ker441 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(0),
      ADR3 => cu_N58,
      O => cu_N44
    );
  exwb_buff_out_D11_0_1_24 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(0),
      RST => exwb_buff_out_D11_0_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11_0_1,
      CE => VCC,
      SET => GND
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2611 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net577,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net579,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_261
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_931 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net257,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net259,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_93
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_941 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net261,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net263,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_94
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_951 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net265,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net267,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_95
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_42_25 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_93,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_94,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_42
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_43_26 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_95,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_96,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_43
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_21 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_42,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_43,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_25_Q
    );
  cu_Ker691 : X_LUT3
    generic map(
      INIT => X"06"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(7),
      O => cu_N69
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_961 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net269,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net271,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_96
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1011 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net273,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net275,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_101
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1021 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net277,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net279,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_102
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1031 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net281,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net283,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_103
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_46_27 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_101,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_102,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_46
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_47_28 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_103,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_104,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_47
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_23 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_46,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_47,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_26_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_57 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_114,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_115,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_11_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_115_29 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_255,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_256,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_115
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1041 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net285,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net287,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_104
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1091 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net289,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net291,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_109
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1101 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net293,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net295,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_110
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1111 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net297,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net299,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_111
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_50_30 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_109,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_110,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_50
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_51_31 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_111,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_112,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_51
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_25 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_50,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_51,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_27_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_114_32 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_253,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_254,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_114
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1121 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net301,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net303,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_112
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2561 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net573,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net575,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_256
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2551 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net569,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net571,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_255
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2541 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net565,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net567,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_254
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2531 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net561,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net563,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_253
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1171 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net305,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net307,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_117
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1181 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net309,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net311,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_118
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1191 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net313,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net315,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_119
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_54_33 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_117,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_118,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_54
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_55_34 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_119,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_120,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_55
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_27 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_54,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_55,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_28_Q
    );
  exwb_buff_out_R_A_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(7),
      RST => exwb_buff_out_R_A_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A(7),
      CE => VCC,
      SET => GND
    );
  cu_Ker151 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => cu_N59,
      O => cu_N15
    );
  cu_n0020_0_1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => cu_N3,
      ADR2 => ifid_buff_out1(3),
      ADR3 => cu_N65,
      O => cu_n0020(0)
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1201 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net317,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net319,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_120
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1251 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net321,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net323,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_125
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1261 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net325,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net327,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_126
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1271 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net329,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net331,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_127
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_58_35 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_125,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_126,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_58
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_59_36 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_127,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_128,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_59
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_29 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_58,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_59,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_29_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_55 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_110,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_111,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_10_Q
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1281 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net333,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net335,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_128
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1331 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net337,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net339,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_133
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1341 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net341,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net343,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_134
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1351 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net345,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net347,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_135
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_62_37 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_133,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_134,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_62
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f5_63_38 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_lut3_135,
      IB => mem_internal_ram_bank_Mram_iram0_inst_lut3_136,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_63
    );
  mem_internal_ram_bank_Mram_iram0_inst_mux_f6_31 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_62,
      IB => mem_internal_ram_bank_Mram_iram0_inst_mux_f5_63,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_30_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_111_39 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_247,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_248,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_111
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_110_40 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_245,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_246,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_110
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1361 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net349,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net351,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_136
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2481 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net557,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net559,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_248
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2471 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net553,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net555,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_247
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2461 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net549,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net551,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_246
    );
  wb_stage_p1_in_4_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(4),
      O => N6231
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2451 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net545,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net547,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_245
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1411 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net353,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net355,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_141
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1421 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net357,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net359,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_142
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1431 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net361,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net363,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_143
    );
  cu_n001618 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE10613,
      ADR1 => ifid_buff_out1(7),
      ADR2 => N6281,
      ADR3 => cu_N22,
      O => cu_n0321(1)
    );
  cu_n032946 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => CHOICE10654,
      ADR1 => ifid_buff_out1(4),
      ADR2 => CHOICE10658,
      ADR3 => cu_N17,
      O => cu_n0329
    );
  exwb_buff_out_R_B_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RB_out_from_execute(0),
      RST => exwb_buff_out_R_B_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_B(0),
      CE => VCC,
      SET => GND
    );
  exe_stage_alu_m_n046413 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0220,
      ADR2 => exe_stage_src1(2),
      ADR3 => exe_stage_alu_m_n0216(2),
      O => CHOICE12629
    );
  exwb_buff_out_D22_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(7),
      RST => exwb_buff_out_D22_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22(7),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D11_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(6),
      RST => exwb_buff_out_D11_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(6),
      CE => VCC,
      SET => GND
    );
  cu_Ker391 : X_LUT2
    generic map(
      INIT => X"7"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(5),
      O => cu_N39
    );
  cu_Ker461 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      O => cu_N46
    );
  cu_Ker12 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => N147,
      ADR1 => ifid_buff_out1(2),
      ADR2 => Reset_IBUF,
      ADR3 => N146,
      O => cu_N12
    );
  wb_stage_Ker721 : X_LUT4
    generic map(
      INIT => X"3010"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => exwb_buff_out_D22(2),
      ADR2 => wb_stage_N66,
      ADR3 => exwb_buff_out_D22(3),
      O => wb_stage_N72
    );
  wb_stage_p0_in_5_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(5),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => N824,
      O => p0_in_from_writeback(5)
    );
  exwb_buff_out_sel_mux11_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_sel_mux11(1),
      RST => exwb_buff_out_sel_mux11_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_sel_mux11(1),
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_D11_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(7),
      RST => exwb_buff_out_D11_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11(7),
      CE => VCC,
      SET => GND
    );
  cu_Ker17103 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => CHOICE10728,
      ADR2 => CHOICE10715,
      ADR3 => N6283,
      O => cu_N17
    );
  cu_Ker271 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(6),
      O => cu_N27
    );
  cu_Ker621 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(3),
      O => cu_N62
    );
  cu_Ker591 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(0),
      ADR3 => ifid_buff_out1(7),
      O => cu_N59
    );
  cu_Ker451 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(3),
      ADR3 => cu_N65,
      O => cu_N45
    );
  fet_stage_que_state_M_next_Mcode_2_133 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => CHOICE11620,
      ADR1 => cu_sel_rd,
      ADR2 => N6291,
      O => CHOICE11621
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_14 : X_LUT4
    generic map(
      INIT => X"9190"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(5),
      ADR3 => dec_stage_d_instruction_decoder_N90,
      O => CHOICE11394
    );
  dec_stage_d_instruction_decoder_Ker501 : X_LUT3
    generic map(
      INIT => X"57"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(7),
      O => dec_stage_d_instruction_decoder_N50
    );
  dec_stage_d_instruction_decoder_Ker1041 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(1),
      O => dec_stage_d_instruction_decoder_N104
    );
  dec_stage_d_instruction_decoder_Ker961 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => Reset_IBUF,
      O => dec_stage_d_instruction_decoder_N96
    );
  dec_stage_d_instruction_decoder_Ker771 : X_LUT3
    generic map(
      INIT => X"64"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(4),
      O => dec_stage_d_instruction_decoder_N77
    );
  dec_stage_d_instruction_decoder_Ker11 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(3),
      O => CHOICE10780
    );
  dec_stage_d_instruction_decoder_Ker059 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => CHOICE11439,
      ADR1 => ifid_buff_out1(3),
      ADR2 => CHOICE11432,
      ADR3 => CHOICE11428,
      O => dec_stage_d_instruction_decoder_N0
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_131_41 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_287,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_288,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_131
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_65 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_130,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_131,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_15_Q
    );
  rom_Mrom_n0002_inst_mux_f5_1381 : X_LUT4
    generic map(
      INIT => X"4924"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6128
    );
  rom_Mrom_n0002_inst_mux_f5_1441 : X_LUT4
    generic map(
      INIT => X"4924"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6127
    );
  cu_n0332181_SW0_G : X_LUT4
    generic map(
      INIT => X"111B"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(7),
      ADR3 => ifid_buff_out1(6),
      O => N6429
    );
  port2_in_5_IBUF_42 : X_BUF
    port map (
      I => port2_in(5),
      O => port2_in_5_IBUF
    );
  dec_stage_d_instruction_decoder_Ker99 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(6),
      ADR2 => N6264,
      ADR3 => dec_stage_d_instruction_decoder_N89,
      O => dec_stage_d_instruction_decoder_N99
    );
  rom_Mrom_n0002_inst_mux_f5_1571 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6119
    );
  dec_stage_d_instruction_decoder_Ker891 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(0),
      O => dec_stage_d_instruction_decoder_N89
    );
  dec_stage_d_instruction_decoder_d1_1_25 : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N6167,
      ADR2 => dec_stage_d_instruction_decoder_n0198,
      ADR3 => ifid_buff_out2(1),
      O => d1_from_decode(1)
    );
  dec_stage_d_instruction_decoder_s2_0_SW0 : X_LUT4
    generic map(
      INIT => X"135F"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => dec_stage_d_instruction_decoder_N87,
      ADR2 => dec_stage_d_instruction_decoder_N97,
      ADR3 => dec_stage_reg_indirect_to_mux6(0),
      O => N2493
    );
  fet_stage_que_state_M_state_FFd2_In23 : X_LUT4
    generic map(
      INIT => X"5445"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => fet_stage_que_state_M_state_FFd2,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => CHOICE11643
    );
  dec_stage_d_instruction_decoder_d2_2_24 : X_LUT4
    generic map(
      INIT => X"040E"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => CHOICE11464,
      ADR2 => N6271,
      ADR3 => ifid_buff_out1(4),
      O => d2_from_decode(2)
    );
  exwb_buff_out_D11_6_1_43 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(6),
      RST => exwb_buff_out_D11_6_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11_6_1,
      CE => VCC,
      SET => GND
    );
  dec_stage_d_instruction_decoder_Ker971 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => cu_N21,
      O => dec_stage_d_instruction_decoder_N97
    );
  dec_stage_d_instruction_decoder_d2_6_Q : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N95,
      ADR1 => dec_stage_reg_indirect_to_mux6(6),
      ADR2 => N771,
      ADR3 => N772,
      O => d2_from_decode(6)
    );
  port3_in_4_IBUF_44 : X_BUF
    port map (
      I => port3_in(4),
      O => port3_in_4_IBUF
    );
  dec_stage_d_instruction_decoder_s1_1_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out2(1),
      ADR1 => dec_stage_d_instruction_decoder_N99,
      O => s1_from_decode(1)
    );
  dec_stage_d_instruction_decoder_s2_1_SW0 : X_LUT4
    generic map(
      INIT => X"135F"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => dec_stage_d_instruction_decoder_N87,
      ADR2 => dec_stage_d_instruction_decoder_N97,
      ADR3 => dec_stage_reg_indirect_to_mux6(1),
      O => N2491
    );
  dec_stage_d_instruction_decoder_s1_2_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out2(2),
      ADR1 => dec_stage_d_instruction_decoder_N99,
      O => s1_from_decode(2)
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_129 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE11277,
      ADR1 => Reset_IBUF,
      ADR2 => CHOICE11261,
      ADR3 => ifid_buff_out1(4),
      O => alu_op_from_decode(1)
    );
  dec_stage_d_instruction_decoder_s2_0_Q : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N2493,
      ADR2 => dec_stage_d_instruction_decoder_N0,
      ADR3 => ifid_buff_out2(0),
      O => s2_from_decode(0)
    );
  dec_stage_d_instruction_decoder_s2_4_SW0 : X_LUT4
    generic map(
      INIT => X"135F"
    )
    port map (
      ADR0 => mem_PSW_psw(4),
      ADR1 => dec_stage_d_instruction_decoder_N87,
      ADR2 => dec_stage_d_instruction_decoder_N97,
      ADR3 => dec_stage_reg_indirect_to_mux6(4),
      O => N2489
    );
  dec_stage_d_instruction_decoder_Ker27 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(1),
      ADR3 => N6275,
      O => dec_stage_d_instruction_decoder_N27
    );
  wb_stage_n0069_0_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(0),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out24,
      O => CHOICE11126
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_73 : X_LUT4
    generic map(
      INIT => X"0A08"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(7),
      ADR3 => ifid_buff_out1(2),
      O => CHOICE11409
    );
  rom_Mrom_n0002_inst_mux_f5_156 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_139,
      IB => rom_Mrom_n0002_inst_lut4_140,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N91
    );
  rom_Mrom_n0002_inst_lut4_1461 : X_LUT4
    generic map(
      INIT => X"4924"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => rom_Mrom_n0002_inst_lut4_146
    );
  port3_in_0_IBUF_45 : X_BUF
    port map (
      I => port3_in(0),
      O => port3_in_0_IBUF
    );
  rom_Mrom_n0002_inst_lut4_1431 : X_LUT4
    generic map(
      INIT => X"2E94"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(3),
      ADR2 => addressbus_from_fetch(1),
      ADR3 => addressbus_from_fetch(2),
      O => rom_Mrom_n0002_inst_lut4_143
    );
  rom_Mrom_n0002_inst_lut4_1401 : X_LUT4
    generic map(
      INIT => X"942E"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(2),
      O => rom_Mrom_n0002_inst_lut4_140
    );
  rom_Mrom_n0002_inst_lut4_1391 : X_LUT4
    generic map(
      INIT => X"6E49"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_139
    );
  rom_Mrom_n0002_inst_mux_f7_8 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N78,
      IB => rom_Mrom_n0002_N81,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N82
    );
  rom_Mrom_n0002_inst_mux_f6_79 : X_MUX2
    port map (
      IA => sp_out_from_mem(0),
      IB => rom_Mrom_n0002_N80,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N81
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_53 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_106,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_107,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_9_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_107_46 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_239,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_240,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_107
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_106_47 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_237,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_238,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_106
    );
  mem_internal_ram_bank_Mram_iram0_inst_lut3_1441 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram0_net365,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram0_net367,
      O => mem_internal_ram_bank_Mram_iram0_inst_lut3_144
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2401 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net541,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net543,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_240
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2391 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net537,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net539,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_239
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2381 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net533,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net535,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_238
    );
  rom_Mrom_n0002_inst_lut4_1451 : X_LUT4
    generic map(
      INIT => X"6926"
    )
    port map (
      ADR0 => addressbus_from_fetch(2),
      ADR1 => addressbus_from_fetch(3),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(1),
      O => rom_Mrom_n0002_inst_lut4_145
    );
  port0_in_7_IBUF_48 : X_BUF
    port map (
      I => port0_in(7),
      O => port0_in_7_IBUF
    );
  dec_stage_d_mux9_out1_7_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(7),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(7),
      O => CHOICE12499
    );
  rom_Mrom_n0002_inst_mux_f5_155 : X_MUX2
    port map (
      IA => sp_out_from_mem(0),
      IB => rom_Mrom_n0002_inst_lut4_138,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N80
    );
  rom_Mrom_n0002_inst_lut4_1411 : X_LUT4
    generic map(
      INIT => X"F118"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(1),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_141
    );
  rom_Mrom_n0002_inst_mux_f5_161 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_149,
      IB => rom_Mrom_n0002_inst_lut4_152,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N107
    );
  rom_Mrom_n0002_inst_mux_f6_78 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N76,
      IB => sp_out_from_mem(0),
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N78
    );
  rom_Mrom_n0002_inst_mux_f5_150 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_123,
      IB => rom_Mrom_n0002_inst_lut4_124,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N61
    );
  port3_in_7_IBUF_49 : X_BUF
    port map (
      I => port3_in(7),
      O => port3_in_7_IBUF
    );
  port0_in_6_IBUF_50 : X_BUF
    port map (
      I => port0_in(6),
      O => port0_in_6_IBUF
    );
  rom_Mrom_n0002_inst_lut4_1271 : X_LUT4
    generic map(
      INIT => X"7412"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => rom_Mrom_n0002_inst_lut4_127
    );
  rom_Mrom_n0002_inst_lut4_1241 : X_LUT4
    generic map(
      INIT => X"924A"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_124
    );
  rom_Mrom_n0002_inst_lut4_1231 : X_LUT4
    generic map(
      INIT => X"DDC9"
    )
    port map (
      ADR0 => addressbus_from_fetch(2),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => rom_Mrom_n0002_inst_lut4_123
    );
  port3_in_3_IBUF_51 : X_BUF
    port map (
      I => port3_in(3),
      O => port3_in_3_IBUF
    );
  port2_in_1_IBUF_52 : X_BUF
    port map (
      I => port2_in(1),
      O => port2_in_1_IBUF
    );
  rom_Mrom_n0002_inst_mux_f5_1591 : X_LUT4
    generic map(
      INIT => X"4924"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => N6122
    );
  exe_stage_alu_m_n043312_SW0 : X_LUT4
    generic map(
      INIT => X"0503"
    )
    port map (
      ADR0 => N6156,
      ADR1 => N6155,
      ADR2 => CHOICE12710,
      ADR3 => exe_stage_alu_m_alu_cyo4,
      O => N6134
    );
  exe_stage_alu_m_alu_n0073_1_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(1),
      ADR1 => exe_stage_src1(1),
      ADR2 => exe_stage_alu_m_n0064(0),
      ADR3 => exe_stage_alu_m_alu_cyo4,
      O => exe_stage_alu_m_N58
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_281 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => mem_w_addr_b1(0),
      ADR1 => mem_w_addr_b1(6),
      ADR2 => mem_w_addr_b1(5),
      ADR3 => mem_w_addr_b1(7),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_28
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_321 : X_LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      ADR0 => mem_w_addr_b1(5),
      ADR1 => mem_w_addr_b1(6),
      ADR2 => mem_w_addr_b1(7),
      ADR3 => mem_w_addr_b1(0),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_32
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_261 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => mem_w_addr_b1(6),
      ADR1 => mem_w_addr_b1(5),
      ADR2 => mem_w_addr_b1(7),
      ADR3 => mem_w_addr_b1(0),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_26
    );
  rom_Mrom_n0002_inst_lut4_1291 : X_LUT4
    generic map(
      INIT => X"5294"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(3),
      ADR2 => addressbus_from_fetch(1),
      ADR3 => addressbus_from_fetch(2),
      O => rom_Mrom_n0002_inst_lut4_129
    );
  port0_in_5_IBUF_53 : X_BUF
    port map (
      I => port0_in(5),
      O => port0_in_5_IBUF
    );
  port2_in_0_IBUF_54 : X_BUF
    port map (
      I => port2_in(0),
      O => port2_in_0_IBUF
    );
  rom_Mrom_n0002_inst_lut4_1251 : X_LUT4
    generic map(
      INIT => X"5294"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(2),
      O => rom_Mrom_n0002_inst_lut4_125
    );
  rom_Mrom_n0002_inst_mux_f7_5 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N48,
      IB => rom_Mrom_n0002_N51,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N52
    );
  rom_Mrom_n0002_inst_mux_f6_74 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N49,
      IB => rom_Mrom_n0002_N50,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N51
    );
  rom_Mrom_n0002_inst_mux_f5_142 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_111,
      IB => N6129,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N32
    );
  rom_Mrom_n0002_inst_mux_f5_141 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_109,
      IB => rom_Mrom_n0002_inst_lut4_110,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N31
    );
  port3_in_2_IBUF_55 : X_BUF
    port map (
      I => port3_in(2),
      O => port3_in_2_IBUF
    );
  port0_in_4_IBUF_56 : X_BUF
    port map (
      I => port0_in(4),
      O => port0_in_4_IBUF
    );
  rom_Mrom_n0002_inst_lut4_1111 : X_LUT4
    generic map(
      INIT => X"0924"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_111
    );
  rom_Mrom_n0002_inst_lut4_1101 : X_LUT4
    generic map(
      INIT => X"9248"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_110
    );
  exe_stage_alu_m_n045418 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0230,
      ADR1 => exe_stage_src1(0),
      ADR2 => exe_stage_alu_m_N01,
      ADR3 => exe_stage_src2(0),
      O => CHOICE12722
    );
  rom_Mrom_n0002_inst_mux_f7_3 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N18,
      IB => rom_Mrom_n0002_N21,
      SEL => addressbus_from_fetch(6),
      O => rom_Mrom_n0002_N22
    );
  port3_in_6_IBUF_57 : X_BUF
    port map (
      I => port3_in(6),
      O => port3_in_6_IBUF
    );
  rom_Mrom_n0002_inst_lut4_1131 : X_LUT4
    generic map(
      INIT => X"2124"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_113
    );
  rom_Mrom_n0002_inst_lut4_1091 : X_LUT4
    generic map(
      INIT => X"4449"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_109
    );
  rom_Mrom_n0002_inst_mux_f6_70 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N19,
      IB => rom_Mrom_n0002_N20,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N21
    );
  port0_in_3_IBUF_58 : X_BUF
    port map (
      I => port0_in(3),
      O => port0_in_3_IBUF
    );
  rom_Mrom_n0002_inst_mux_f5_140 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_107,
      IB => rom_Mrom_n0002_inst_lut4_108,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N20
    );
  rom_Mrom_n0002_inst_mux_f5_139 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_105,
      IB => rom_Mrom_n0002_inst_lut4_104,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N19
    );
  rom_Mrom_n0002_inst_mux_f5_135 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_98,
      IB => rom_Mrom_n0002_inst_lut4_99,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N5
    );
  rom_Mrom_n0002_inst_mux_f5_134 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_96,
      IB => N6130,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N4
    );
  rom_Mrom_n0002_inst_mux_f5_133 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_94,
      IB => N6131,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N2
    );
  rom_Mrom_n0002_inst_mux_f5_132 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_inst_lut4_92,
      IB => rom_Mrom_n0002_inst_lut4_95,
      SEL => addressbus_from_fetch(4),
      O => rom_Mrom_n0002_N1
    );
  rom_Mrom_n0002_inst_lut4_991 : X_LUT4
    generic map(
      INIT => X"1EE7"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(1),
      O => rom_Mrom_n0002_inst_lut4_99
    );
  rom_Mrom_n0002_inst_lut4_981 : X_LUT4
    generic map(
      INIT => X"799A"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(1),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_98
    );
  rom_Mrom_n0002_inst_lut4_961 : X_LUT4
    generic map(
      INIT => X"C756"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(0),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_96
    );
  rom_Mrom_n0002_inst_lut4_951 : X_LUT4
    generic map(
      INIT => X"B6DB"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => rom_Mrom_n0002_inst_lut4_95
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f6_51 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_102,
      IB => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_103,
      SEL => mem_r_addr_b0_7_Q,
      O => mem_internal_ram_bank_n0018_8_Q
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_103_59 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_231,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_232,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_103
    );
  mem_internal_ram_bank_Mram_iram1_inst_mux_f5_102_60 : X_MUX2
    port map (
      IA => mem_internal_ram_bank_Mram_iram1_inst_lut3_229,
      IB => mem_internal_ram_bank_Mram_iram1_inst_lut3_230,
      SEL => mem_r_addr_b0_6_Q,
      O => mem_internal_ram_bank_Mram_iram1_inst_mux_f5_102
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2371 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net529,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net531,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_237
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2321 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net525,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net527,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_232
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2311 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net521,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net523,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_231
    );
  rom_Mrom_n0002_inst_mux_f6_66 : X_MUX2
    port map (
      IA => rom_Mrom_n0002_N1,
      IB => rom_Mrom_n0002_N2,
      SEL => addressbus_from_fetch(5),
      O => rom_Mrom_n0002_N3
    );
  rom_Mrom_n0002_inst_lut4_1531 : X_LUT4
    generic map(
      INIT => X"F6DF"
    )
    port map (
      ADR0 => addressbus_from_fetch(3),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(1),
      ADR3 => addressbus_from_fetch(0),
      O => rom_Mrom_n0002_inst_lut4_153
    );
  port1_in_1_IBUF_61 : X_BUF
    port map (
      I => port1_in(1),
      O => port1_in_1_IBUF
    );
  rom_Mrom_n0002_inst_lut4_941 : X_LUT4
    generic map(
      INIT => X"ED16"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => rom_Mrom_n0002_inst_lut4_94
    );
  exe_stage_alu_m_n044224 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12818,
      ADR1 => exe_stage_alu_m_N5,
      ADR2 => exe_stage_src1(4),
      ADR3 => N6243,
      O => CHOICE12821
    );
  port1_in_0_IBUF_62 : X_BUF
    port map (
      I => port1_in(0),
      O => port1_in_0_IBUF
    );
  rom_Mrom_n0002_inst_lut4_921 : X_LUT4
    generic map(
      INIT => X"5849"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => rom_Mrom_n0002_inst_lut4_92
    );
  wb_stage_di_A_3_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(3),
      O => di_A_from_writeback(3)
    );
  dec_stage_d_mux7_out1_2_116 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12293,
      ADR2 => CHOICE12288,
      ADR3 => CHOICE12299,
      O => CHOICE12302
    );
  exe_stage_alu_m_n022626 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => CHOICE11816,
      ADR1 => CHOICE11823,
      O => exe_stage_alu_m_n0226
    );
  port1_out_4_OBUF : X_BUF
    port map (
      I => mem_R_P1_port_out(4),
      O => port1_out_4_OBUF_GTS_TRI
    );
  port0_out_2_OBUF : X_BUF
    port map (
      I => mem_R_P0_port_out(2),
      O => port0_out_2_OBUF_GTS_TRI
    );
  fet_stage_MUX4_M_out1_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(7),
      ADR2 => fet_stage_PC_M_data_out(7),
      O => addressbus_from_fetch(7)
    );
  fet_stage_MUX4_M_out1_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(4),
      ADR2 => fet_stage_PC_M_data_out(4),
      O => addressbus_from_fetch(4)
    );
  fet_stage_MUX4_M_out1_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(3),
      ADR2 => fet_stage_PC_M_data_out(3),
      O => addressbus_from_fetch(3)
    );
  fet_stage_MUX4_M_out1_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(2),
      ADR2 => fet_stage_PC_M_data_out(2),
      O => addressbus_from_fetch(2)
    );
  fet_stage_MUX4_M_out1_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(6),
      ADR2 => fet_stage_PC_M_data_out(6),
      O => addressbus_from_fetch(6)
    );
  fet_stage_MUX4_M_out1_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(5),
      ADR2 => fet_stage_PC_M_data_out(5),
      O => addressbus_from_fetch(5)
    );
  wb_stage_Ker653 : X_LUT4
    generic map(
      INIT => X"FFF7"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_n0150,
      ADR2 => exwb_buff_out_D22(3),
      ADR3 => N6262,
      O => wb_stage_N6
    );
  wb_stage_p0_in_2_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(2),
      ADR1 => wb_stage_N61,
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => N824,
      O => p0_in_from_writeback(2)
    );
  fet_stage_MUX4_M_out1_0_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(0),
      ADR2 => fet_stage_PC_M_data_out(0),
      O => addressbus_from_fetch(0)
    );
  fet_stage_MUX4_M_out1_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux4(1),
      ADR1 => fet_stage_JCall_out(1),
      ADR2 => fet_stage_PC_M_data_out(1),
      O => addressbus_from_fetch(1)
    );
  wb_stage_Ker4 : X_LUT4
    generic map(
      INIT => X"FF7F"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_N64,
      ADR2 => exwb_buff_out_D22(4),
      ADR3 => N776,
      O => wb_stage_N41
    );
  wb_stage_n0068_0_61 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exwb_buff_out_D22(0),
      ADR1 => wb_stage_N80,
      ADR2 => wb_stage_n0184(6),
      ADR3 => wb_stage_N71,
      O => CHOICE11082
    );
  wb_stage_Ker21 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => exwb_buff_out_D22(6),
      ADR2 => wb_stage_N34,
      ADR3 => exwb_buff_out_D22(5),
      O => wb_stage_N21
    );
  wb_stage_p2_in_0_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(0),
      ADR1 => wb_stage_N60,
      ADR2 => exwb_buff_out_R_A(0),
      ADR3 => N826,
      O => p2_in_from_writeback(0)
    );
  wb_stage_Ker01 : X_LUT4
    generic map(
      INIT => X"082A"
    )
    port map (
      ADR0 => wb_stage_N26,
      ADR1 => wb_stage_N71,
      ADR2 => wb_stage_n0150,
      ADR3 => wb_stage_N80,
      O => wb_stage_N01
    );
  dec_stage_d_instruction_decoder_Ker2335_SW0 : X_LUT4
    generic map(
      INIT => X"0301"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(3),
      ADR3 => ifid_buff_out1(0),
      O => N6251
    );
  dec_stage_d_instruction_decoder_s2_3_SW0 : X_LUT4
    generic map(
      INIT => X"135F"
    )
    port map (
      ADR0 => mem_PSW_psw(3),
      ADR1 => dec_stage_d_instruction_decoder_N87,
      ADR2 => dec_stage_d_instruction_decoder_N97,
      ADR3 => dec_stage_reg_indirect_to_mux6(3),
      O => N2487
    );
  wb_stage_Ker581 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => wb_stage_N74,
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => exwb_buff_out_D11(1),
      O => wb_stage_N58
    );
  exe_stage_alu_m_alu_n0003_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0003_1_cyo,
      I1 => exe_stage_alu_m_N110,
      O => exe_stage_alu_m_n0003(2)
    );
  exe_stage_alu_m_alu_n0165_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0165_2_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_n0000_3_rt,
      O => exe_stage_alu_m_alu_n0165_3_cyo
    );
  exe_stage_alu_m_n00292 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo1,
      ADR1 => N6517,
      ADR2 => exe_stage_alu_m_n0028(6),
      O => exe_stage_alu_m_n0295(7)
    );
  exe_stage_alu_m_alu_n0217_1_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(1),
      ADR2 => exe_stage_src2(1),
      ADR3 => N64,
      O => exe_stage_alu_m_N104
    );
  exe_stage_alu_m_alucy_rn_0 : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_6_cyo,
      IA => exe_stage_alu_m_n0293(7),
      SEL => exe_stage_alu_m_N32,
      O => exe_stage_alu_m_alu_cyo1
    );
  exe_stage_alu_m_alucy_rn_1 : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_6_cyo,
      IA => exe_stage_alu_m_n0295(7),
      SEL => exe_stage_alu_m_N40,
      O => exe_stage_alu_m_alu_cyo2
    );
  exe_stage_alu_m_alucy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_6_cyo,
      IA => exe_stage_alu_m_n0296(7),
      SEL => exe_stage_alu_m_N24,
      O => exe_stage_alu_m_alu_cyo
    );
  exe_stage_alu_m_alucy_rn_2 : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_6_cyo,
      IA => exe_stage_alu_m_n0297(7),
      SEL => exe_stage_alu_m_N48,
      O => exe_stage_alu_m_alu_cyo3
    );
  exe_stage_alu_m_alucy_rn_3 : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_6_cyo,
      IA => exe_stage_alu_m_n0298(7),
      SEL => exe_stage_alu_m_N56,
      O => exe_stage_alu_m_alu_cyo4
    );
  exe_stage_alu_m_alu_n0073_7_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_6_cyo,
      I1 => exe_stage_alu_m_N64,
      O => exe_stage_alu_m_n0073(7)
    );
  exe_stage_alu_m_alu_n0217_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0217_1_cyo,
      IA => exe_stage_src1(2),
      SEL => exe_stage_alu_m_N105,
      O => exe_stage_alu_m_alu_n0217_2_cyo
    );
  exe_stage_alu_m_alu_n0003_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0003_0_cyo,
      I1 => exe_stage_alu_m_N109,
      O => exe_stage_alu_m_n0003(1)
    );
  exe_stage_alu_m_alu_n0165_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0165_3_cyo,
      I1 => exe_stage_alu_m_alu_n0000_3_cyo_rt,
      O => exe_stage_alu_m_n0165(4)
    );
  exe_stage_alu_m_alu_n0165_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0165_0_cyo,
      I1 => exe_stage_alu_m_n0000_1_rt,
      O => exe_stage_alu_m_n0165(1)
    );
  exe_stage_alu_m_alu_n0003_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0003_1_cyo,
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N110,
      O => exe_stage_alu_m_alu_n0003_2_cyo
    );
  exe_stage_alu_m_alu_n0000_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0000_2_cyo,
      I1 => exe_stage_alu_m_N68,
      O => exe_stage_alu_m_n0000(3)
    );
  exe_stage_alu_m_alu_n0165_0_cy : X_MUX2
    port map (
      IB => fet_stage_Temp1_data(12),
      IA => exe_stage_alu_m_N65,
      SEL => exe_stage_alu_m_N107,
      O => exe_stage_alu_m_alu_n0165_0_cyo
    );
  exe_stage_alu_m_alu_n0003_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0003_2_cyo,
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N111,
      O => exe_stage_alu_m_alu_n0003_3_cyo
    );
  exe_stage_alu_m_alu_n0003_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0003_3_cyo,
      I1 => exe_stage_alu_m_N112,
      O => exe_stage_alu_m_n0003(4)
    );
  exe_stage_alu_m_alucy_rn_4 : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_6_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N76,
      O => exe_stage_alu_m_alu_cyo5
    );
  dec_stage_d_mux9_out1_1_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(1),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(1),
      O => N6431
    );
  exe_stage_alu_m_n0476183 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12582,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_alu_cyo2,
      O => RA_out_from_execute(4)
    );
  exe_stage_alu_m_n0469158 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12620,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_alu_cyo,
      O => RA_out_from_execute(3)
    );
  dec_stage_d_mux7_out1_1_29 : X_LUT4
    generic map(
      INIT => X"FF8A"
    )
    port map (
      ADR0 => ifid_buff_out2(0),
      ADR1 => mem_R_DPL_data_out(1),
      ADR2 => ifid_buff_out2(1),
      ADR3 => CHOICE12316,
      O => CHOICE12317
    );
  exe_stage_alu_m_n046974 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_N01,
      ADR2 => exe_stage_src1(3),
      ADR3 => exe_stage_alu_m_N711,
      O => CHOICE12612
    );
  fet_stage_que_state_M_state_FFd2_In163 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => CHOICE11679,
      ADR1 => CHOICE11675,
      ADR2 => databus_from_mux19(6),
      ADR3 => CHOICE11657,
      O => CHOICE11680
    );
  exe_stage_alu_m_n045914 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0000(1),
      ADR1 => exe_stage_alu_m_N951,
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => CHOICE12667,
      O => CHOICE12669
    );
  exe_stage_alu_m_alu_n0217_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0217_1_cyo,
      I1 => exe_stage_alu_m_N105,
      O => exe_stage_alu_m_n0217(2)
    );
  exe_stage_alu_m_des_ov61 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(10),
      ADR1 => exe_stage_alu_m_n0008(11),
      ADR2 => exe_stage_alu_m_n0008(15),
      O => CHOICE12047
    );
  dec_stage_d_mux7_out1_4_29_G : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => mem_R_DPL_data_out(4),
      ADR2 => ifid_buff_out2(1),
      O => N6433
    );
  exe_stage_alu_m_alu_n0064_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(1),
      ADR3 => N78,
      O => exe_stage_alu_m_N49
    );
  rom_Mrom_n0002_inst_mux_f5_1581 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6123
    );
  rom_Mrom_n0002_inst_mux_f5_1331 : X_LUT4
    generic map(
      INIT => X"B6DB"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => N6131
    );
  dec_stage_d_mux7_out1_4_50 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(4),
      ADR3 => mem_R_A_data_out(4),
      O => CHOICE12152
    );
  exe_stage_alu_m_alucy_rn_5 : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_6_cyo,
      IA => exe_stage_alu_m_n0311(7),
      SEL => exe_stage_alu_m_N84,
      O => exe_stage_alu_m_alu_cyo6
    );
  exe_stage_alu_m_Mmult_n0008_inst_mult_0 : X_MULT18X18
    port map (
      A(17) => fet_stage_Temp1_data(12),
      A(16) => fet_stage_Temp1_data(12),
      A(15) => fet_stage_Temp1_data(12),
      A(14) => fet_stage_Temp1_data(12),
      A(13) => fet_stage_Temp1_data(12),
      A(12) => fet_stage_Temp1_data(12),
      A(11) => fet_stage_Temp1_data(12),
      A(10) => fet_stage_Temp1_data(12),
      A(9) => fet_stage_Temp1_data(12),
      A(8) => fet_stage_Temp1_data(12),
      A(7) => exe_stage_src1(7),
      A(6) => exe_stage_src1(6),
      A(5) => exe_stage_src1(5),
      A(4) => exe_stage_src1(4),
      A(3) => exe_stage_src1(3),
      A(2) => exe_stage_src1(2),
      A(1) => exe_stage_src1(1),
      A(0) => exe_stage_src1(0),
      B(17) => fet_stage_Temp1_data(12),
      B(16) => fet_stage_Temp1_data(12),
      B(15) => fet_stage_Temp1_data(12),
      B(14) => fet_stage_Temp1_data(12),
      B(13) => fet_stage_Temp1_data(12),
      B(12) => fet_stage_Temp1_data(12),
      B(11) => fet_stage_Temp1_data(12),
      B(10) => fet_stage_Temp1_data(12),
      B(9) => fet_stage_Temp1_data(12),
      B(8) => fet_stage_Temp1_data(12),
      B(7) => exe_stage_src2(7),
      B(6) => exe_stage_src2(6),
      B(5) => exe_stage_src2(5),
      B(4) => exe_stage_src2(4),
      B(3) => exe_stage_src2(3),
      B(2) => exe_stage_src2(2),
      B(1) => exe_stage_src2(1),
      B(0) => exe_stage_src2(0),
      P(35) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_35_UNCONNECTED,
      P(34) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_34_UNCONNECTED,
      P(33) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_33_UNCONNECTED,
      P(32) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_32_UNCONNECTED,
      P(31) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_31_UNCONNECTED,
      P(30) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_30_UNCONNECTED,
      P(29) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_29_UNCONNECTED,
      P(28) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_28_UNCONNECTED,
      P(27) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_27_UNCONNECTED,
      P(26) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_26_UNCONNECTED,
      P(25) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_25_UNCONNECTED,
      P(24) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_24_UNCONNECTED,
      P(23) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_23_UNCONNECTED,
      P(22) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_22_UNCONNECTED,
      P(21) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_21_UNCONNECTED,
      P(20) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_20_UNCONNECTED,
      P(19) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_19_UNCONNECTED,
      P(18) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_18_UNCONNECTED,
      P(17) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_17_UNCONNECTED,
      P(16) => NLW_exe_stage_alu_m_Mmult_n0008_inst_mult_0_P_16_UNCONNECTED,
      P(15) => exe_stage_alu_m_n0008(15),
      P(14) => exe_stage_alu_m_n0008(14),
      P(13) => exe_stage_alu_m_n0008(13),
      P(12) => exe_stage_alu_m_n0008(12),
      P(11) => exe_stage_alu_m_n0008(11),
      P(10) => exe_stage_alu_m_n0008(10),
      P(9) => exe_stage_alu_m_n0008(9),
      P(8) => exe_stage_alu_m_n0008(8),
      P(7) => exe_stage_alu_m_n0008(7),
      P(6) => exe_stage_alu_m_n0008(6),
      P(5) => exe_stage_alu_m_n0008(5),
      P(4) => exe_stage_alu_m_n0008(4),
      P(3) => exe_stage_alu_m_n0008(3),
      P(2) => exe_stage_alu_m_n0008(2),
      P(1) => exe_stage_alu_m_n0008(1),
      P(0) => exe_stage_alu_m_n0008(0)
    );
  exe_stage_alu_m_alu_n0216_7_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0216_6_cyo,
      I1 => N5944,
      O => exe_stage_alu_m_n0216(7)
    );
  fet_stage_que_state_M_inst_que_code_3_269 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => rom_DATA_BUS(3),
      ADR1 => cu_sel_rd,
      ADR2 => CHOICE11766,
      ADR3 => CHOICE11784,
      O => CHOICE11785
    );
  exe_stage_alu_m_alu_n0005_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0005_1_cyo,
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N115,
      O => exe_stage_alu_m_alu_n0005_2_cyo
    );
  exe_stage_alu_m_alu_n0218_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0218_1_cyo,
      I1 => exe_stage_alu_m_N89,
      O => exe_stage_alu_m_n0218(2)
    );
  exe_stage_alu_m_alu_n0003_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_alu_m_n0217(0),
      SEL => exe_stage_alu_m_N108,
      O => exe_stage_alu_m_alu_n0003_0_cyo
    );
  dec_stage_d_mux9_out1_2_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(2),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(2),
      O => N6435
    );
  exe_stage_alu_m_alu_n0005_1_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_n0218(1),
      O => exe_stage_alu_m_N114
    );
  exe_stage_alu_m_alu_n0003_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0003_0_cyo,
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N109,
      O => exe_stage_alu_m_alu_n0003_1_cyo
    );
  exe_stage_alu_m_Ker621 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0242,
      ADR1 => exe_stage_alu_m_n0233,
      ADR2 => exe_stage_alu_m_n0243,
      O => exe_stage_alu_m_N621
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_33_G : X_LUT3
    generic map(
      INIT => X"82"
    )
    port map (
      ADR0 => CHOICE10780,
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(6),
      O => N6437
    );
  exe_stage_alu_m_alu_n0165_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0165_2_cyo,
      I1 => exe_stage_alu_m_n0000_3_rt,
      O => exe_stage_alu_m_n0165(3)
    );
  exe_stage_alu_m_Madd_n0214_Mxor_Result_2_Xo_1_1 : X_LUT3
    generic map(
      INIT => X"96"
    )
    port map (
      ADR0 => exe_stage_src1(6),
      ADR1 => exe_stage_alu_m_Madd_n0214_n0013(0),
      ADR2 => exe_stage_src2(6),
      O => exe_stage_alu_m_n0214(2)
    );
  exe_stage_alu_m_n00341 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => N6523,
      ADR1 => exe_stage_alu_m_n0028(1),
      ADR2 => exe_stage_alu_m_alu_cyo1,
      O => exe_stage_alu_m_n0295(2)
    );
  exe_stage_alu_m_n02631 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0243,
      ADR1 => exe_stage_alu_m_n0244,
      ADR2 => exe_stage_alu_m_n0242,
      O => exe_stage_alu_m_n0263
    );
  exe_stage_alu_m_n034749 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0230,
      ADR1 => exe_stage_src1(6),
      ADR2 => exe_stage_alu_m_N01,
      ADR3 => exe_stage_src2(6),
      O => CHOICE11844
    );
  exe_stage_alu_m_n048913 : X_LUT3
    generic map(
      INIT => X"28"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0221,
      ADR2 => exe_stage_alu_m_n0153(5),
      O => CHOICE11882
    );
  exe_stage_alu_m_Ker941 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(1),
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => idex_buff_out_Opcode(2),
      O => exe_stage_alu_m_N941
    );
  exe_stage_alu_m_n00431 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => N6510,
      ADR1 => exe_stage_alu_m_n0037(1),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      O => exe_stage_alu_m_n0296(2)
    );
  exe_stage_alu_m_n00411 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => N6508,
      ADR1 => exe_stage_alu_m_alu_cyo2,
      ADR2 => exe_stage_alu_m_n0037(3),
      O => exe_stage_alu_m_n0296(4)
    );
  exe_stage_alu_m_n00501 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => N6507,
      ADR1 => exe_stage_alu_m_alu_cyo,
      ADR2 => exe_stage_alu_m_n0046(3),
      O => exe_stage_alu_m_n0297(4)
    );
  exe_stage_alu_m_n00391 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo2,
      ADR1 => N6522,
      ADR2 => exe_stage_alu_m_n0037(5),
      O => exe_stage_alu_m_n0296(6)
    );
  exe_stage_alu_m_n00381 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo2,
      ADR1 => exe_stage_alu_m_n0295(6),
      ADR2 => exe_stage_alu_m_n0037(6),
      O => exe_stage_alu_m_n0296(7)
    );
  dec_stage_d_mux7_Ker111 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out2(4),
      ADR1 => ifid_buff_out2(0),
      ADR2 => ifid_buff_out2(1),
      O => dec_stage_d_mux7_N11
    );
  exe_stage_alu_m_Ker851 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(1),
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_N851
    );
  exe_stage_alu_m_Ker96 : X_LUT4
    generic map(
      INIT => X"020A"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(2),
      ADR1 => CHOICE11816,
      ADR2 => N6297,
      ADR3 => CHOICE11823,
      O => exe_stage_alu_m_N961
    );
  exe_stage_alu_m_alu_n0005_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0005_2_cyo,
      I1 => exe_stage_alu_m_N116,
      O => exe_stage_alu_m_n0005(3)
    );
  exe_stage_alu_m_Ker821 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR1 => exe_stage_alu_m_N961,
      ADR2 => exe_stage_alu_m_n0227,
      O => exe_stage_alu_m_N821
    );
  exe_stage_alu_m_n02431 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exe_stage_alu_m_N931,
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => idex_buff_out_Opcode(1),
      O => exe_stage_alu_m_n0243
    );
  exe_stage_alu_m_n02421 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exe_stage_alu_m_N831,
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_n0242
    );
  exe_stage_alu_m_Ker931 : X_LUT2
    generic map(
      INIT => X"1"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(2),
      ADR1 => idex_buff_out_Opcode(0),
      O => exe_stage_alu_m_N931
    );
  exe_stage_alu_m_n02621 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => exe_stage_alu_m_N841,
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => exe_stage_alu_m_n0241,
      O => exe_stage_alu_m_n0262
    );
  exe_stage_alu_m_n02391 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exe_stage_alu_m_N851,
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => idex_buff_out_Opcode(2),
      O => exe_stage_alu_m_n0239
    );
  fet_stage_que_state_M_inst_que_code_3_65 : X_LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      ADR0 => rom_DATA_BUS(0),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(1),
      ADR3 => N6215,
      O => CHOICE11741
    );
  exe_stage_alu_m_n044924 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12858,
      ADR1 => exe_stage_alu_m_N5,
      ADR2 => exe_stage_src1(7),
      ADR3 => CHOICE12860,
      O => CHOICE12863
    );
  exe_stage_alu_m_des_cy68_G : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0216(7),
      ADR1 => mem_PSW_psw(7),
      ADR2 => exe_stage_alu_m_alu_n0216_7_cyo,
      O => N6439
    );
  exe_stage_alu_m_Ker831 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(1),
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => idex_buff_out_Opcode(3),
      O => exe_stage_alu_m_N831
    );
  cu_n0332254_G : X_LUT4
    generic map(
      INIT => X"EEFE"
    )
    port map (
      ADR0 => CHOICE10779,
      ADR1 => CHOICE10827,
      ADR2 => CHOICE10788,
      ADR3 => ifid_buff_out1(5),
      O => N6441
    );
  exe_stage_alu_m_n02331 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => exe_stage_alu_m_N861,
      ADR2 => idex_buff_out_Opcode(2),
      O => exe_stage_alu_m_n0233
    );
  exe_stage_alu_m_Ker841 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(1),
      O => exe_stage_alu_m_N841
    );
  exe_stage_alu_m_n02311 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(2),
      ADR1 => exe_stage_alu_m_N871,
      O => CHOICE12734
    );
  exe_stage_alu_m_n02301 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_N831,
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_n0230
    );
  exe_stage_alu_m_n02291 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_N841,
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_n0229
    );
  wb_stage_di_DPL_1_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(1),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N68,
      O => N1415
    );
  exe_stage_alu_m_Ker911 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(2),
      ADR1 => idex_buff_out_Opcode(0),
      O => exe_stage_alu_m_N911
    );
  exe_stage_alu_m_n02241 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => exe_stage_alu_m_N871,
      ADR1 => idex_buff_out_Opcode(2),
      O => exe_stage_alu_m_n0224
    );
  exe_stage_alu_m_n02231 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => exe_stage_alu_m_N941,
      ADR1 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_n0223
    );
  exe_stage_alu_m_n02611 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(4),
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(1),
      ADR3 => idex_buff_out_Opcode(3),
      O => exe_stage_alu_m_n0261
    );
  exe_stage_alu_m_n0221_63 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => mem_PSW_psw(7),
      ADR1 => exe_stage_alu_m_alu_n0216_7_cyo,
      ADR2 => exe_stage_alu_m_n0220,
      ADR3 => N1481,
      O => exe_stage_alu_m_n0221
    );
  exe_stage_alu_m_n02201 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => exe_stage_src1(3),
      ADR1 => exe_stage_src1(1),
      ADR2 => mem_PSW_psw(6),
      ADR3 => exe_stage_src1(2),
      O => exe_stage_alu_m_n0220
    );
  exe_stage_alu_m_n00301 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo1,
      ADR1 => N6515,
      ADR2 => exe_stage_alu_m_n0028(5),
      O => exe_stage_alu_m_n0295(6)
    );
  exe_stage_alu_m_n00251 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => N6513,
      ADR1 => exe_stage_alu_m_n0019(1),
      ADR2 => exe_stage_alu_m_alu_cyo6,
      O => exe_stage_alu_m_n0293(2)
    );
  fet_stage_que_state_M_next_Mcode_2_131 : X_LUT4
    generic map(
      INIT => X"5557"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => rom_DATA_BUS(0),
      ADR2 => rom_DATA_BUS(2),
      ADR3 => rom_DATA_BUS(6),
      O => CHOICE11620
    );
  exe_stage_alu_m_n00121 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo5,
      ADR1 => exe_stage_alu_m_n0010(5),
      O => exe_stage_alu_m_n0311(6)
    );
  exe_stage_alu_m_n00111 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo5,
      ADR1 => exe_stage_alu_m_n0010(6),
      O => exe_stage_alu_m_n0311(7)
    );
  dec_stage_d_mux7_out1_2_24 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(1),
      ADR1 => mem_R_P0_data_out(2),
      ADR2 => ifid_buff_out2(0),
      ADR3 => mem_R_DPH_data_out(2),
      O => CHOICE12281
    );
  exe_stage_alu_m_n02411 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(3),
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => idex_buff_out_Opcode(1),
      ADR3 => exe_stage_alu_m_N931,
      O => exe_stage_alu_m_n0241
    );
  exe_stage_alu_m_Madd_n0214_n00021 : X_LUT3
    generic map(
      INIT => X"E8"
    )
    port map (
      ADR0 => exe_stage_alu_m_Madd_n0214_n0013(0),
      ADR1 => exe_stage_src2(6),
      ADR2 => exe_stage_src1(6),
      O => exe_stage_alu_m_Madd_n0214_Mxor_Result_3_Xo(0)
    );
  dec_stage_d_mux9_out1_5_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(13),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12468
    );
  exe_stage_alu_m_alu_n0003_0_lut : X_LUT2
    generic map(
      INIT => X"9"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0217(0),
      ADR1 => mem_PSW_psw(7),
      O => exe_stage_alu_m_N108
    );
  exe_stage_alu_m_n00201 : X_LUT4
    generic map(
      INIT => X"F808"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo5,
      ADR1 => exe_stage_alu_m_n0010(5),
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(6),
      O => exe_stage_alu_m_n0293(7)
    );
  exe_stage_alu_m_alu_n0003_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N108,
      O => exe_stage_alu_m_n0003(0)
    );
  exe_stage_alu_m_n00321 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo1,
      ADR1 => N6511,
      ADR2 => exe_stage_alu_m_n0028(3),
      O => exe_stage_alu_m_n0295(4)
    );
  exe_stage_alu_m_Eq_stagecy_rn_2 : X_MUX2
    port map (
      IB => exe_stage_alu_m_Eq_stage_cyo2,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N102,
      O => exe_stage_alu_m_n0227
    );
  exe_stage_alu_m_alu_n0217_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0217_2_cyo,
      I1 => exe_stage_alu_m_N106,
      O => exe_stage_alu_m_n0217(3)
    );
  exe_stage_alu_m_alu_n0005_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0005_0_cyo,
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N114,
      O => exe_stage_alu_m_alu_n0005_1_cyo
    );
  wb_stage_n0068_2_15_G : X_LUT4
    generic map(
      INIT => X"51FB"
    )
    port map (
      ADR0 => wb_stage_N26,
      ADR1 => wb_stage_n0184(6),
      ADR2 => wb_stage_n0150,
      ADR3 => wb_stage_N67,
      O => N6443
    );
  exe_stage_alu_m_alu_n0217_3_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(3),
      ADR2 => exe_stage_src2(3),
      ADR3 => N68,
      O => exe_stage_alu_m_N106
    );
  exe_stage_alu_m_alu_n0217_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0217_2_cyo,
      IA => exe_stage_src1(3),
      SEL => exe_stage_alu_m_N106,
      O => exe_stage_alu_m_alu_n0217_3_cyo
    );
  exe_stage_alu_m_Ker861 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(3),
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => idex_buff_out_Opcode(1),
      O => exe_stage_alu_m_N861
    );
  exe_stage_alu_m_n0469133 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0003(3),
      ADR1 => exe_stage_alu_m_N941,
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => CHOICE12618,
      O => CHOICE12620
    );
  exe_stage_alu_m_Ker01 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_N861,
      ADR1 => exe_stage_alu_m_N931,
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => exe_stage_alu_m_N941,
      O => exe_stage_alu_m_N01
    );
  exe_stage_alu_m_n043623 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => exe_stage_src1(2),
      ADR1 => exe_stage_alu_m_n0244,
      ADR2 => CHOICE12790,
      ADR3 => exe_stage_alu_m_N5,
      O => CHOICE12793
    );
  exe_stage_alu_m_n0153_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0220,
      ADR1 => exe_stage_src1(5),
      ADR2 => exe_stage_alu_m_n0216(5),
      O => exe_stage_alu_m_n0153(5)
    );
  exe_stage_alu_m_n0153_6_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0220,
      ADR1 => exe_stage_src1(6),
      ADR2 => exe_stage_alu_m_n0216(6),
      O => exe_stage_alu_m_n0153(6)
    );
  exe_stage_alu_m_n0153_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0220,
      ADR1 => exe_stage_src1(7),
      ADR2 => exe_stage_alu_m_n0216(7),
      O => exe_stage_alu_m_n0153(7)
    );
  exe_stage_alu_m_n0364176 : X_LUT4
    generic map(
      INIT => X"EEFE"
    )
    port map (
      ADR0 => CHOICE11972,
      ADR1 => CHOICE11979,
      ADR2 => CHOICE11940,
      ADR3 => exe_stage_alu_m_n0215(0),
      O => CHOICE11981
    );
  exe_stage_alu_m_alu_n0217_2_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(2),
      ADR2 => exe_stage_src2(2),
      ADR3 => N66,
      O => exe_stage_alu_m_N105
    );
  exe_stage_alu_m_alu_n0003_4_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_alu_n0217_3_cyo,
      O => exe_stage_alu_m_N112
    );
  exe_stage_alu_m_alu_n0003_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0003_2_cyo,
      I1 => exe_stage_alu_m_N111,
      O => exe_stage_alu_m_n0003(3)
    );
  exe_stage_alu_m_n00691 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0298(2),
      ADR1 => exe_stage_alu_m_alu_cyo4,
      ADR2 => exe_stage_alu_m_n0064(2),
      O => exe_stage_alu_m_n0299(3)
    );
  exe_stage_alu_m_n00681 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => N6528,
      ADR1 => exe_stage_alu_m_alu_cyo4,
      ADR2 => exe_stage_alu_m_n0064(3),
      O => exe_stage_alu_m_n0299(4)
    );
  exe_stage_alu_m_n00671 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => N6524,
      ADR1 => exe_stage_alu_m_alu_cyo4,
      ADR2 => exe_stage_alu_m_n0064(4),
      O => exe_stage_alu_m_n0299(5)
    );
  exe_stage_alu_m_n00661 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo4,
      ADR1 => N6525,
      ADR2 => exe_stage_alu_m_n0064(5),
      O => exe_stage_alu_m_n0299(6)
    );
  exe_stage_alu_m_n00711 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(1),
      ADR1 => exe_stage_alu_m_n0064(0),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      O => exe_stage_alu_m_n0299(1)
    );
  exe_stage_alu_m_n00651 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo4,
      ADR1 => N6526,
      ADR2 => exe_stage_alu_m_n0064(6),
      O => exe_stage_alu_m_n0299(7)
    );
  exe_stage_alu_m_n00701 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => N6527,
      ADR1 => exe_stage_alu_m_n0064(1),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      O => exe_stage_alu_m_n0299(2)
    );
  exe_stage_alu_m_n00561 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo3,
      ADR1 => exe_stage_alu_m_n0297(6),
      ADR2 => exe_stage_alu_m_n0055(6),
      O => exe_stage_alu_m_n0298(7)
    );
  exe_stage_alu_m_n00611 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => N6530,
      ADR1 => exe_stage_alu_m_n0055(1),
      ADR2 => exe_stage_alu_m_alu_cyo3,
      O => exe_stage_alu_m_n0298(2)
    );
  exe_stage_alu_m_n00481 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo,
      ADR1 => N6509,
      ADR2 => exe_stage_alu_m_n0046(5),
      O => exe_stage_alu_m_n0297(6)
    );
  dec_stage_d_instruction_decoder_n019857_SW0_G : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(3),
      O => N6445
    );
  exe_stage_alu_m_n00471 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo,
      ADR1 => exe_stage_alu_m_n0296(6),
      ADR2 => exe_stage_alu_m_n0046(6),
      O => exe_stage_alu_m_n0297(7)
    );
  exe_stage_alu_m_n00521 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => N6520,
      ADR1 => exe_stage_alu_m_n0046(1),
      ADR2 => exe_stage_alu_m_alu_cyo,
      O => exe_stage_alu_m_n0297(2)
    );
  exe_stage_alu_m_Ker581 : X_LUT3
    generic map(
      INIT => X"57"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0221,
      ADR1 => exe_stage_alu_m_n0153(5),
      ADR2 => exe_stage_alu_m_n0153(6),
      O => exe_stage_alu_m_N581
    );
  exe_stage_alu_m_alu_n0005_2_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_n0218(2),
      O => exe_stage_alu_m_N115
    );
  exe_stage_alu_m_alu_n0005_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_alu_m_n0218(0),
      SEL => exe_stage_alu_m_N113,
      O => exe_stage_alu_m_alu_n0005_0_cyo
    );
  exe_stage_alu_m_alu_n0165_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0165_1_cyo,
      I1 => exe_stage_alu_m_n0000_2_rt,
      O => exe_stage_alu_m_n0165(2)
    );
  exe_stage_alu_m_n0273_64 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0241,
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => exe_stage_alu_m_N841,
      O => exe_stage_alu_m_n0273
    );
  exe_stage_alu_m_n0347177_SW0 : X_LUT4
    generic map(
      INIT => X"60A0"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0214(2),
      ADR1 => exe_stage_alu_m_Madd_n0166_Mxor_Result_1_Xo(0),
      ADR2 => exe_stage_alu_m_n0238,
      ADR3 => exe_stage_alu_m_n0214(1),
      O => N6241
    );
  exe_stage_alu_m_des_ov109_G : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(2),
      ADR1 => CHOICE12052,
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => idex_buff_out_Opcode(0),
      O => N6447
    );
  exe_stage_alu_m_Madd_n0166_n00001 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0287,
      ADR1 => exe_stage_alu_m_n0165(4),
      O => exe_stage_alu_m_Madd_n0166_Mxor_Result_1_Xo(0)
    );
  exe_stage_alu_m_alu_n0165_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0165_1_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_n0000_2_rt,
      O => exe_stage_alu_m_alu_n0165_2_cyo
    );
  exe_stage_alu_m_alu_n0003_3_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_n0217(3),
      O => exe_stage_alu_m_N111
    );
  exe_stage_alu_m_Madd_n0167_Mxor_Result_1_Xo_1_1 : X_LUT3
    generic map(
      INIT => X"E8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0166(3),
      ADR1 => exe_stage_src2(7),
      ADR2 => exe_stage_src1(7),
      O => exe_stage_alu_m_n0167(1)
    );
  exe_stage_alu_m_alu_n0005_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0005_1_cyo,
      I1 => exe_stage_alu_m_N115,
      O => exe_stage_alu_m_n0005(2)
    );
  exe_stage_alu_m_alu_n0165_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0165_0_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_n0000_1_rt,
      O => exe_stage_alu_m_alu_n0165_1_cyo
    );
  exe_stage_alu_m_Madd_n0002_Mxor_Result_1_Xo_1_1 : X_LUT3
    generic map(
      INIT => X"E8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0001(3),
      ADR1 => exe_stage_src2(7),
      ADR2 => exe_stage_src1(7),
      O => exe_stage_alu_m_n0002(1)
    );
  port3_out_2_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(2),
      O => port3_out_2_OBUF_GTS_TRI
    );
  exe_stage_alu_m_alu_n0165_0_lut : X_LUT2
    generic map(
      INIT => X"6"
    )
    port map (
      ADR0 => exe_stage_alu_m_N65,
      ADR1 => mem_PSW_psw(7),
      O => exe_stage_alu_m_N107
    );
  exe_stage_alu_m_n0464113 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0165(2),
      ADR1 => exe_stage_alu_m_N851,
      ADR2 => exe_stage_alu_m_N911,
      ADR3 => CHOICE12654,
      O => CHOICE12656
    );
  exe_stage_alu_m_Ker871 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(3),
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => idex_buff_out_Opcode(1),
      O => exe_stage_alu_m_N871
    );
  exe_stage_alu_m_alu_n0003_1_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_n0217(1),
      O => exe_stage_alu_m_N109
    );
  exe_stage_alu_m_Madd_n0214_n00011 : X_LUT4
    generic map(
      INIT => X"EC80"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_src2(5),
      ADR2 => exe_stage_src1(4),
      ADR3 => exe_stage_src1(5),
      O => exe_stage_alu_m_Madd_n0214_n0013(0)
    );
  exe_stage_alu_m_Madd_n0214_Mxor_Result_1_Xo_1_1 : X_LUT4
    generic map(
      INIT => X"9666"
    )
    port map (
      ADR0 => exe_stage_src1(5),
      ADR1 => exe_stage_src2(5),
      ADR2 => exe_stage_src1(4),
      ADR3 => exe_stage_src2(4),
      O => exe_stage_alu_m_n0214(1)
    );
  exe_stage_alu_m_alu_n0005_3_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_alu_n0218_2_cyo,
      O => exe_stage_alu_m_N116
    );
  exe_stage_alu_m_alu_n0003_2_lut_INV_0 : X_INV
    port map (
      I => exe_stage_alu_m_n0217(2),
      O => exe_stage_alu_m_N110
    );
  exe_stage_alu_m_alu_n0005_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0005_0_cyo,
      I1 => exe_stage_alu_m_N114,
      O => exe_stage_alu_m_n0005(1)
    );
  exe_stage_alu_m_alu_n0005_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N113,
      O => exe_stage_alu_m_n0005(0)
    );
  exe_stage_alu_m_n0347133_SW0 : X_LUT4
    generic map(
      INIT => X"60A0"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0214(2),
      ADR1 => exe_stage_alu_m_Madd_n0001_Mxor_Result_1_Xo(0),
      ADR2 => exe_stage_alu_m_n0222,
      ADR3 => exe_stage_alu_m_n0214(1),
      O => N6285
    );
  exe_stage_alu_m_Madd_n0001_n00001 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0287,
      ADR1 => exe_stage_alu_m_alu_n0000_3_cyo,
      O => exe_stage_alu_m_Madd_n0001_Mxor_Result_1_Xo(0)
    );
  exe_stage_alu_m_Madd_n0166_Mxor_Result_3_Xo_1_1 : X_LUT4
    generic map(
      INIT => X"6AAA"
    )
    port map (
      ADR0 => exe_stage_alu_m_Madd_n0214_Mxor_Result_3_Xo(0),
      ADR1 => exe_stage_alu_m_n0214(2),
      ADR2 => exe_stage_alu_m_n0214(1),
      ADR3 => exe_stage_alu_m_Madd_n0166_Mxor_Result_1_Xo(0),
      O => exe_stage_alu_m_n0166(3)
    );
  exe_stage_alu_m_alu_n0000_2_lut : X_LUT4
    generic map(
      INIT => X"1EB4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N66,
      ADR2 => exe_stage_src2(2),
      ADR3 => exwb_buff_out_R_A(2),
      O => exe_stage_alu_m_N67
    );
  exe_stage_alu_m_alu_n0046_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(3),
      SEL => exe_stage_alu_m_N17,
      O => exe_stage_alu_m_alu_n0046_0_cyo
    );
  exe_stage_alu_m_alu_n0046_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N17,
      O => exe_stage_alu_m_n0046(0)
    );
  exe_stage_alu_m_alu_n0037_1_lut : X_LUT4
    generic map(
      INIT => X"C399"
    )
    port map (
      ADR0 => exe_stage_src1(5),
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_n0028(0),
      ADR3 => exe_stage_alu_m_alu_cyo1,
      O => exe_stage_alu_m_N34
    );
  exe_stage_alu_m_alu_n0046_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_0_cyo,
      IA => exe_stage_alu_m_n0296(1),
      SEL => exe_stage_alu_m_N18,
      O => exe_stage_alu_m_alu_n0046_1_cyo
    );
  exe_stage_alu_m_alu_n0046_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0046_0_cyo,
      I1 => exe_stage_alu_m_N18,
      O => exe_stage_alu_m_n0046(1)
    );
  exe_stage_alu_m_alu_n0055_2_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0296(1),
      ADR2 => exe_stage_alu_m_n0046(1),
      ADR3 => exe_stage_alu_m_alu_cyo,
      O => exe_stage_alu_m_N43
    );
  exe_stage_alu_m_alu_n0046_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_1_cyo,
      IA => exe_stage_alu_m_n0296(2),
      SEL => exe_stage_alu_m_N19,
      O => exe_stage_alu_m_alu_n0046_2_cyo
    );
  exe_stage_alu_m_alu_n0046_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0046_1_cyo,
      I1 => exe_stage_alu_m_N19,
      O => exe_stage_alu_m_n0046(2)
    );
  exe_stage_alu_m_alu_n0037_3_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_n0293(2),
      ADR2 => exe_stage_alu_m_alu_cyo1,
      ADR3 => exe_stage_alu_m_n0028(2),
      O => exe_stage_alu_m_N36
    );
  exe_stage_alu_m_alu_n0046_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_2_cyo,
      IA => exe_stage_alu_m_n0296(3),
      SEL => exe_stage_alu_m_N20,
      O => exe_stage_alu_m_alu_n0046_3_cyo
    );
  exe_stage_alu_m_alu_n0046_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0046_2_cyo,
      I1 => exe_stage_alu_m_N20,
      O => exe_stage_alu_m_n0046(3)
    );
  exe_stage_alu_m_alulut2 : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_N120,
      ADR2 => exe_stage_alu_m_alu_cyo1,
      ADR3 => exe_stage_alu_m_n0028(6),
      O => exe_stage_alu_m_N40
    );
  exe_stage_alu_m_alu_n0046_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_3_cyo,
      IA => exe_stage_alu_m_n0296(4),
      SEL => exe_stage_alu_m_N21,
      O => exe_stage_alu_m_alu_n0046_4_cyo
    );
  exe_stage_alu_m_alu_n0046_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0046_3_cyo,
      I1 => exe_stage_alu_m_N21,
      O => exe_stage_alu_m_n0046(4)
    );
  exe_stage_alu_m_alu_n0046_4_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0295(3),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      ADR3 => exe_stage_alu_m_n0037(3),
      O => exe_stage_alu_m_N21
    );
  exe_stage_alu_m_alu_n0046_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_4_cyo,
      IA => exe_stage_alu_m_n0296(5),
      SEL => exe_stage_alu_m_N22,
      O => exe_stage_alu_m_alu_n0046_5_cyo
    );
  exe_stage_alu_m_alu_n0046_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0046_4_cyo,
      I1 => exe_stage_alu_m_N22,
      O => exe_stage_alu_m_n0046(5)
    );
  exe_stage_alu_m_alu_n0046_5_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => exe_stage_alu_m_n0295(4),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      ADR3 => exe_stage_alu_m_n0037(4),
      O => exe_stage_alu_m_N22
    );
  exe_stage_alu_m_alu_n0046_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0046_5_cyo,
      IA => exe_stage_alu_m_n0296(6),
      SEL => exe_stage_alu_m_N23,
      O => exe_stage_alu_m_alu_n0046_6_cyo
    );
  exe_stage_alu_m_alu_n0046_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0046_5_cyo,
      I1 => exe_stage_alu_m_N23,
      O => exe_stage_alu_m_n0046(6)
    );
  exe_stage_alu_m_alu_n0037_4_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0293(3),
      ADR2 => exe_stage_alu_m_alu_cyo1,
      ADR3 => exe_stage_alu_m_n0028(3),
      O => exe_stage_alu_m_N37
    );
  exe_stage_alu_m_n036449_G : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exe_stage_alu_m_N861,
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => mem_PSW_psw(7),
      O => N6449
    );
  exe_stage_alu_m_alu_n0028_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(5),
      SEL => exe_stage_alu_m_N25,
      O => exe_stage_alu_m_alu_n0028_0_cyo
    );
  exe_stage_alu_m_alu_n0028_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N25,
      O => exe_stage_alu_m_n0028(0)
    );
  exe_stage_alu_m_alu_n0073_2_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0298(1),
      ADR2 => exe_stage_alu_m_n0064(1),
      ADR3 => exe_stage_alu_m_alu_cyo4,
      O => exe_stage_alu_m_N59
    );
  exe_stage_alu_m_alu_n0028_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_0_cyo,
      IA => exe_stage_alu_m_n0293(1),
      SEL => exe_stage_alu_m_N26,
      O => exe_stage_alu_m_alu_n0028_1_cyo
    );
  exe_stage_alu_m_alu_n0028_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0028_0_cyo,
      I1 => exe_stage_alu_m_N26,
      O => exe_stage_alu_m_n0028(1)
    );
  exe_stage_alu_m_alu_n0019_1_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => N6499,
      ADR1 => exe_stage_src1(7),
      ADR2 => exe_stage_alu_m_n0010(0),
      ADR3 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_N78
    );
  exe_stage_alu_m_alu_n0028_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_1_cyo,
      IA => exe_stage_alu_m_n0293(2),
      SEL => exe_stage_alu_m_N27,
      O => exe_stage_alu_m_alu_n0028_2_cyo
    );
  exe_stage_alu_m_alu_n0028_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0028_1_cyo,
      I1 => exe_stage_alu_m_N27,
      O => exe_stage_alu_m_n0028(2)
    );
  exe_stage_alu_m_alu_n0028_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_2_cyo,
      IA => exe_stage_alu_m_n0293(3),
      SEL => exe_stage_alu_m_N28,
      O => exe_stage_alu_m_alu_n0028_3_cyo
    );
  exe_stage_alu_m_alu_n0028_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0028_2_cyo,
      I1 => exe_stage_alu_m_N28,
      O => exe_stage_alu_m_n0028(3)
    );
  exe_stage_alu_m_alu_n0037_5_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => N6512,
      ADR2 => exe_stage_alu_m_alu_cyo1,
      ADR3 => exe_stage_alu_m_n0028(4),
      O => exe_stage_alu_m_N38
    );
  exe_stage_alu_m_alu_n0028_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_3_cyo,
      IA => exe_stage_alu_m_n0293(4),
      SEL => exe_stage_alu_m_N29,
      O => exe_stage_alu_m_alu_n0028_4_cyo
    );
  exe_stage_alu_m_alu_n0028_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0028_3_cyo,
      I1 => exe_stage_alu_m_N29,
      O => exe_stage_alu_m_n0028(4)
    );
  exe_stage_alu_m_alu_n0028_4_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => N6516,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(3),
      O => exe_stage_alu_m_N29
    );
  exe_stage_alu_m_alu_n0028_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_4_cyo,
      IA => exe_stage_alu_m_n0293(5),
      SEL => exe_stage_alu_m_N30,
      O => exe_stage_alu_m_alu_n0028_5_cyo
    );
  exe_stage_alu_m_alu_n0028_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0028_4_cyo,
      I1 => exe_stage_alu_m_N30,
      O => exe_stage_alu_m_n0028(5)
    );
  exe_stage_alu_m_alu_n0028_5_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => N6518,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(4),
      O => exe_stage_alu_m_N30
    );
  exe_stage_alu_m_alu_n0028_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0028_5_cyo,
      IA => exe_stage_alu_m_n0293(6),
      SEL => exe_stage_alu_m_N31,
      O => exe_stage_alu_m_alu_n0028_6_cyo
    );
  exe_stage_alu_m_alu_n0028_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0028_5_cyo,
      I1 => exe_stage_alu_m_N31,
      O => exe_stage_alu_m_n0028(6)
    );
  exe_stage_alu_m_alulut1 : X_LUT4
    generic map(
      INIT => X"9C36"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo6,
      ADR1 => exe_stage_src2(7),
      ADR2 => N6132,
      ADR3 => exe_stage_alu_m_n0019(6),
      O => exe_stage_alu_m_N32
    );
  exe_stage_alu_m_alu_n0037_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(4),
      SEL => exe_stage_alu_m_N33,
      O => exe_stage_alu_m_alu_n0037_0_cyo
    );
  exe_stage_alu_m_alu_n0037_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N33,
      O => exe_stage_alu_m_n0037(0)
    );
  exe_stage_alu_m_alu_n0028_1_lut : X_LUT4
    generic map(
      INIT => X"C399"
    )
    port map (
      ADR0 => exe_stage_src1(6),
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_n0019(0),
      ADR3 => exe_stage_alu_m_alu_cyo6,
      O => exe_stage_alu_m_N26
    );
  exe_stage_alu_m_alu_n0037_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_0_cyo,
      IA => exe_stage_alu_m_n0295(1),
      SEL => exe_stage_alu_m_N34,
      O => exe_stage_alu_m_alu_n0037_1_cyo
    );
  exe_stage_alu_m_alu_n0037_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0037_0_cyo,
      I1 => exe_stage_alu_m_N34,
      O => exe_stage_alu_m_n0037(1)
    );
  exe_stage_alu_m_alu_n0028_2_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0311(1),
      ADR2 => exe_stage_alu_m_n0019(1),
      ADR3 => exe_stage_alu_m_alu_cyo6,
      O => exe_stage_alu_m_N27
    );
  exe_stage_alu_m_alu_n0037_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_1_cyo,
      IA => exe_stage_alu_m_n0295(2),
      SEL => exe_stage_alu_m_N35,
      O => exe_stage_alu_m_alu_n0037_2_cyo
    );
  exe_stage_alu_m_alu_n0037_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0037_1_cyo,
      I1 => exe_stage_alu_m_N35,
      O => exe_stage_alu_m_n0037(2)
    );
  exe_stage_alu_m_alu_n0028_3_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => N6514,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(2),
      O => exe_stage_alu_m_N28
    );
  exe_stage_alu_m_alu_n0037_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_2_cyo,
      IA => exe_stage_alu_m_n0295(3),
      SEL => exe_stage_alu_m_N36,
      O => exe_stage_alu_m_alu_n0037_3_cyo
    );
  exe_stage_alu_m_alu_n0037_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0037_2_cyo,
      I1 => exe_stage_alu_m_N36,
      O => exe_stage_alu_m_n0037(3)
    );
  exe_stage_alu_m_alu_n0028_6_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => N6519,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(5),
      O => exe_stage_alu_m_N31
    );
  exe_stage_alu_m_alu_n0037_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_3_cyo,
      IA => exe_stage_alu_m_n0295(4),
      SEL => exe_stage_alu_m_N37,
      O => exe_stage_alu_m_alu_n0037_4_cyo
    );
  exe_stage_alu_m_alu_n0037_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0037_3_cyo,
      I1 => exe_stage_alu_m_N37,
      O => exe_stage_alu_m_n0037(4)
    );
  exe_stage_alu_m_alu_n0037_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_4_cyo,
      IA => exe_stage_alu_m_n0295(5),
      SEL => exe_stage_alu_m_N38,
      O => exe_stage_alu_m_alu_n0037_5_cyo
    );
  exe_stage_alu_m_alu_n0037_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0037_4_cyo,
      I1 => exe_stage_alu_m_N38,
      O => exe_stage_alu_m_n0037(5)
    );
  exe_stage_alu_m_alulut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_n0295(6),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      ADR3 => exe_stage_alu_m_n0037(6),
      O => exe_stage_alu_m_N24
    );
  exe_stage_alu_m_alu_n0037_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0037_5_cyo,
      IA => exe_stage_alu_m_n0295(6),
      SEL => exe_stage_alu_m_N39,
      O => exe_stage_alu_m_alu_n0037_6_cyo
    );
  exe_stage_alu_m_alu_n0037_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0037_5_cyo,
      I1 => exe_stage_alu_m_N39,
      O => exe_stage_alu_m_n0037(6)
    );
  exe_stage_alu_m_alu_n0037_6_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0293(5),
      ADR2 => exe_stage_alu_m_alu_cyo1,
      ADR3 => exe_stage_alu_m_n0028(5),
      O => exe_stage_alu_m_N39
    );
  exe_stage_alu_m_n02871 : X_LUT4
    generic map(
      INIT => X"1EB4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => N86,
      ADR2 => exe_stage_src1(4),
      ADR3 => exwb_buff_out_R_A(4),
      O => exe_stage_alu_m_n0287
    );
  exe_stage_alu_m_alu_n0055_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(2),
      SEL => exe_stage_alu_m_N41,
      O => exe_stage_alu_m_alu_n0055_0_cyo
    );
  exe_stage_alu_m_alu_n0055_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N41,
      O => exe_stage_alu_m_n0055(0)
    );
  exe_stage_alu_m_alu_n0046_1_lut : X_LUT4
    generic map(
      INIT => X"C399"
    )
    port map (
      ADR0 => exe_stage_src1(4),
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_n0037(0),
      ADR3 => exe_stage_alu_m_alu_cyo2,
      O => exe_stage_alu_m_N18
    );
  exe_stage_alu_m_alu_n0055_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_0_cyo,
      IA => exe_stage_alu_m_n0297(1),
      SEL => exe_stage_alu_m_N42,
      O => exe_stage_alu_m_alu_n0055_1_cyo
    );
  exe_stage_alu_m_alu_n0055_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0055_0_cyo,
      I1 => exe_stage_alu_m_N42,
      O => exe_stage_alu_m_n0055(1)
    );
  exe_stage_alu_m_alu_n0037_2_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0293(1),
      ADR2 => exe_stage_alu_m_n0028(1),
      ADR3 => exe_stage_alu_m_alu_cyo1,
      O => exe_stage_alu_m_N35
    );
  exe_stage_alu_m_alu_n0055_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_1_cyo,
      IA => exe_stage_alu_m_n0297(2),
      SEL => exe_stage_alu_m_N43,
      O => exe_stage_alu_m_alu_n0055_2_cyo
    );
  exe_stage_alu_m_alu_n0055_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0055_1_cyo,
      I1 => exe_stage_alu_m_N43,
      O => exe_stage_alu_m_n0055(2)
    );
  exe_stage_alu_m_alu_n0064_4_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => N6521,
      ADR2 => exe_stage_alu_m_alu_cyo3,
      ADR3 => exe_stage_alu_m_n0055(3),
      O => exe_stage_alu_m_N53
    );
  exe_stage_alu_m_alu_n0055_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_2_cyo,
      IA => exe_stage_alu_m_n0297(3),
      SEL => exe_stage_alu_m_N44,
      O => exe_stage_alu_m_alu_n0055_3_cyo
    );
  exe_stage_alu_m_alu_n0055_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0055_2_cyo,
      I1 => exe_stage_alu_m_N44,
      O => exe_stage_alu_m_n0055(3)
    );
  exe_stage_alu_m_alu_n0055_3_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_n0296(2),
      ADR2 => exe_stage_alu_m_alu_cyo,
      ADR3 => exe_stage_alu_m_n0046(2),
      O => exe_stage_alu_m_N44
    );
  exe_stage_alu_m_alu_n0055_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_3_cyo,
      IA => exe_stage_alu_m_n0297(4),
      SEL => exe_stage_alu_m_N45,
      O => exe_stage_alu_m_alu_n0055_4_cyo
    );
  exe_stage_alu_m_alu_n0055_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0055_3_cyo,
      I1 => exe_stage_alu_m_N45,
      O => exe_stage_alu_m_n0055(4)
    );
  exe_stage_alu_m_alu_n0055_4_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0296(3),
      ADR2 => exe_stage_alu_m_alu_cyo,
      ADR3 => exe_stage_alu_m_n0046(3),
      O => exe_stage_alu_m_N45
    );
  exe_stage_alu_m_alu_n0055_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_4_cyo,
      IA => exe_stage_alu_m_n0297(5),
      SEL => exe_stage_alu_m_N46,
      O => exe_stage_alu_m_alu_n0055_5_cyo
    );
  exe_stage_alu_m_alu_n0055_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0055_4_cyo,
      I1 => exe_stage_alu_m_N46,
      O => exe_stage_alu_m_n0055(5)
    );
  exe_stage_alu_m_alu_n0055_5_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => exe_stage_alu_m_n0296(4),
      ADR2 => exe_stage_alu_m_alu_cyo,
      ADR3 => exe_stage_alu_m_n0046(4),
      O => exe_stage_alu_m_N46
    );
  exe_stage_alu_m_alu_n0055_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0055_5_cyo,
      IA => exe_stage_alu_m_n0297(6),
      SEL => exe_stage_alu_m_N47,
      O => exe_stage_alu_m_alu_n0055_6_cyo
    );
  exe_stage_alu_m_alu_n0055_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0055_5_cyo,
      I1 => exe_stage_alu_m_N47,
      O => exe_stage_alu_m_n0055(6)
    );
  exe_stage_alu_m_alu_n0055_6_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0296(5),
      ADR2 => exe_stage_alu_m_alu_cyo,
      ADR3 => exe_stage_alu_m_n0046(5),
      O => exe_stage_alu_m_N47
    );
  exe_stage_alu_m_alu_n0218_2_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(6),
      ADR2 => exe_stage_src2(6),
      ADR3 => N74,
      O => exe_stage_alu_m_N89
    );
  exe_stage_alu_m_alu_n0064_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(1),
      SEL => exe_stage_alu_m_N49,
      O => exe_stage_alu_m_alu_n0064_0_cyo
    );
  exe_stage_alu_m_alu_n0064_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N49,
      O => exe_stage_alu_m_n0064(0)
    );
  exe_stage_alu_m_alu_n0055_1_lut : X_LUT4
    generic map(
      INIT => X"C399"
    )
    port map (
      ADR0 => exe_stage_src1(3),
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_n0046(0),
      ADR3 => exe_stage_alu_m_alu_cyo,
      O => exe_stage_alu_m_N42
    );
  exe_stage_alu_m_alu_n0064_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_0_cyo,
      IA => exe_stage_alu_m_n0298(1),
      SEL => exe_stage_alu_m_N50,
      O => exe_stage_alu_m_alu_n0064_1_cyo
    );
  exe_stage_alu_m_alu_n0064_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0064_0_cyo,
      I1 => exe_stage_alu_m_N50,
      O => exe_stage_alu_m_n0064(1)
    );
  exe_stage_alu_m_alu_n0046_2_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0295(1),
      ADR2 => exe_stage_alu_m_n0037(1),
      ADR3 => exe_stage_alu_m_alu_cyo2,
      O => exe_stage_alu_m_N19
    );
  exe_stage_alu_m_alu_n0064_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_1_cyo,
      IA => exe_stage_alu_m_n0298(2),
      SEL => exe_stage_alu_m_N51,
      O => exe_stage_alu_m_alu_n0064_2_cyo
    );
  exe_stage_alu_m_alu_n0064_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0064_1_cyo,
      I1 => exe_stage_alu_m_N51,
      O => exe_stage_alu_m_n0064(2)
    );
  exe_stage_alu_m_alu_n0046_3_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_n0295(2),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      ADR3 => exe_stage_alu_m_n0037(2),
      O => exe_stage_alu_m_N20
    );
  exe_stage_alu_m_alu_n0064_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_2_cyo,
      IA => exe_stage_alu_m_n0298(3),
      SEL => exe_stage_alu_m_N52,
      O => exe_stage_alu_m_alu_n0064_3_cyo
    );
  exe_stage_alu_m_alu_n0064_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0064_2_cyo,
      I1 => exe_stage_alu_m_N52,
      O => exe_stage_alu_m_n0064(3)
    );
  exe_stage_alu_m_alu_n0046_6_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0295(5),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      ADR3 => exe_stage_alu_m_n0037(5),
      O => exe_stage_alu_m_N23
    );
  exe_stage_alu_m_alu_n0064_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_3_cyo,
      IA => exe_stage_alu_m_n0298(4),
      SEL => exe_stage_alu_m_N53,
      O => exe_stage_alu_m_alu_n0064_4_cyo
    );
  exe_stage_alu_m_alu_n0064_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0064_3_cyo,
      I1 => exe_stage_alu_m_N53,
      O => exe_stage_alu_m_n0064(4)
    );
  exe_stage_alu_m_alu_n0073_6_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0298(5),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      ADR3 => exe_stage_alu_m_n0064(5),
      O => exe_stage_alu_m_N63
    );
  exe_stage_alu_m_alu_n0064_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_4_cyo,
      IA => exe_stage_alu_m_n0298(5),
      SEL => exe_stage_alu_m_N54,
      O => exe_stage_alu_m_alu_n0064_5_cyo
    );
  exe_stage_alu_m_alu_n0064_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0064_4_cyo,
      I1 => exe_stage_alu_m_N54,
      O => exe_stage_alu_m_n0064(5)
    );
  exe_stage_alu_m_alu_n0064_5_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => exe_stage_alu_m_n0297(4),
      ADR2 => exe_stage_alu_m_alu_cyo3,
      ADR3 => exe_stage_alu_m_n0055(4),
      O => exe_stage_alu_m_N54
    );
  exe_stage_alu_m_alu_n0064_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0064_5_cyo,
      IA => exe_stage_alu_m_n0298(6),
      SEL => exe_stage_alu_m_N55,
      O => exe_stage_alu_m_alu_n0064_6_cyo
    );
  exe_stage_alu_m_alu_n0064_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0064_5_cyo,
      I1 => exe_stage_alu_m_N55,
      O => exe_stage_alu_m_n0064(6)
    );
  exe_stage_alu_m_alu_n0064_6_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => N6529,
      ADR2 => exe_stage_alu_m_alu_cyo3,
      ADR3 => exe_stage_alu_m_n0055(5),
      O => exe_stage_alu_m_N55
    );
  exe_stage_alu_m_n0215_0_1 : X_LUT4
    generic map(
      INIT => X"1EB4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => N92,
      ADR2 => exe_stage_src1(7),
      ADR3 => exwb_buff_out_R_A(7),
      O => exe_stage_alu_m_n0215(0)
    );
  exe_stage_alu_m_alu_n0073_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(0),
      SEL => exe_stage_alu_m_N57,
      O => exe_stage_alu_m_alu_n0073_0_cyo
    );
  exe_stage_alu_m_alu_n0073_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N57,
      O => exe_stage_alu_m_n0073(0)
    );
  exe_stage_alu_m_alu_n0064_1_lut : X_LUT4
    generic map(
      INIT => X"C399"
    )
    port map (
      ADR0 => exe_stage_src1(2),
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_n0055(0),
      ADR3 => exe_stage_alu_m_alu_cyo3,
      O => exe_stage_alu_m_N50
    );
  exe_stage_alu_m_alu_n0073_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_0_cyo,
      IA => exe_stage_alu_m_n0299(1),
      SEL => exe_stage_alu_m_N58,
      O => exe_stage_alu_m_alu_n0073_1_cyo
    );
  exe_stage_alu_m_alu_n0073_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_0_cyo,
      I1 => exe_stage_alu_m_N58,
      O => exe_stage_alu_m_n0073(1)
    );
  exe_stage_alu_m_alu_n0064_2_lut : X_LUT4
    generic map(
      INIT => X"A599"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0297(1),
      ADR2 => exe_stage_alu_m_n0055(1),
      ADR3 => exe_stage_alu_m_alu_cyo3,
      O => exe_stage_alu_m_N51
    );
  exe_stage_alu_m_alu_n0073_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_1_cyo,
      IA => exe_stage_alu_m_n0299(2),
      SEL => exe_stage_alu_m_N59,
      O => exe_stage_alu_m_alu_n0073_2_cyo
    );
  exe_stage_alu_m_alu_n0073_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_1_cyo,
      I1 => exe_stage_alu_m_N59,
      O => exe_stage_alu_m_n0073(2)
    );
  exe_stage_alu_m_alu_n0064_3_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_n0297(2),
      ADR2 => exe_stage_alu_m_alu_cyo3,
      ADR3 => exe_stage_alu_m_n0055(2),
      O => exe_stage_alu_m_N52
    );
  exe_stage_alu_m_alu_n0073_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_2_cyo,
      IA => exe_stage_alu_m_n0299(3),
      SEL => exe_stage_alu_m_N60,
      O => exe_stage_alu_m_alu_n0073_3_cyo
    );
  exe_stage_alu_m_alu_n0073_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_2_cyo,
      I1 => exe_stage_alu_m_N60,
      O => exe_stage_alu_m_n0073(3)
    );
  exe_stage_alu_m_alulut4 : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_n0297(6),
      ADR2 => exe_stage_alu_m_alu_cyo3,
      ADR3 => exe_stage_alu_m_n0055(6),
      O => exe_stage_alu_m_N56
    );
  exe_stage_alu_m_alu_n0073_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_3_cyo,
      IA => exe_stage_alu_m_n0299(4),
      SEL => exe_stage_alu_m_N61,
      O => exe_stage_alu_m_alu_n0073_4_cyo
    );
  exe_stage_alu_m_alu_n0073_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_3_cyo,
      I1 => exe_stage_alu_m_N61,
      O => exe_stage_alu_m_n0073(4)
    );
  exe_stage_alu_m_alu_n0073_4_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0298(3),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      ADR3 => exe_stage_alu_m_n0064(3),
      O => exe_stage_alu_m_N61
    );
  exe_stage_alu_m_alu_n0073_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_4_cyo,
      IA => exe_stage_alu_m_n0299(5),
      SEL => exe_stage_alu_m_N62,
      O => exe_stage_alu_m_alu_n0073_5_cyo
    );
  exe_stage_alu_m_alu_n0073_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_4_cyo,
      I1 => exe_stage_alu_m_N62,
      O => exe_stage_alu_m_n0073(5)
    );
  exe_stage_alu_m_alulut3 : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_n0296(6),
      ADR2 => exe_stage_alu_m_alu_cyo,
      ADR3 => exe_stage_alu_m_n0046(6),
      O => exe_stage_alu_m_N48
    );
  exe_stage_alu_m_alu_n0073_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_5_cyo,
      IA => exe_stage_alu_m_n0299(6),
      SEL => exe_stage_alu_m_N63,
      O => exe_stage_alu_m_alu_n0073_6_cyo
    );
  exe_stage_alu_m_alu_n0073_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0073_5_cyo,
      I1 => exe_stage_alu_m_N63,
      O => exe_stage_alu_m_n0073(6)
    );
  exe_stage_alu_m_alu_n0073_5_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => exe_stage_alu_m_n0298(4),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      ADR3 => exe_stage_alu_m_n0064(4),
      O => exe_stage_alu_m_N62
    );
  exe_stage_alu_m_alu_n0073_7_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0073_6_cyo,
      IA => exe_stage_alu_m_n0299(7),
      SEL => exe_stage_alu_m_N64,
      O => exe_stage_alu_m_alu_n0073_7_cyo
    );
  exe_stage_alu_m_alu_n0000_0_cy : X_MUX2
    port map (
      IB => fet_stage_Temp1_data(12),
      IA => exe_stage_src1(0),
      SEL => exe_stage_alu_m_N65,
      O => exe_stage_alu_m_alu_n0000_0_cyo
    );
  port3_out_1_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(1),
      O => port3_out_1_OBUF_GTS_TRI
    );
  exe_stage_alu_m_alu_n0000_0_lut : X_LUT4
    generic map(
      INIT => X"1EB4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => N78,
      ADR2 => exe_stage_src1(0),
      ADR3 => exwb_buff_out_R_A(0),
      O => exe_stage_alu_m_N65
    );
  exe_stage_alu_m_alu_n0000_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0000_0_cyo,
      IA => exe_stage_src1(1),
      SEL => exe_stage_alu_m_N66,
      O => exe_stage_alu_m_alu_n0000_1_cyo
    );
  exe_stage_alu_m_alu_n0000_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0000_0_cyo,
      I1 => exe_stage_alu_m_N66,
      O => exe_stage_alu_m_n0000(1)
    );
  exe_stage_alu_m_alu_n0000_1_lut : X_LUT4
    generic map(
      INIT => X"1EB4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N64,
      ADR2 => exe_stage_src2(1),
      ADR3 => exwb_buff_out_R_A(1),
      O => exe_stage_alu_m_N66
    );
  exe_stage_alu_m_alu_n0000_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0000_1_cyo,
      IA => exe_stage_src1(2),
      SEL => exe_stage_alu_m_N67,
      O => exe_stage_alu_m_alu_n0000_2_cyo
    );
  exe_stage_alu_m_alu_n0000_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0000_1_cyo,
      I1 => exe_stage_alu_m_N67,
      O => exe_stage_alu_m_n0000(2)
    );
  exe_stage_alu_m_alu_n0000_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0000_2_cyo,
      IA => exe_stage_src1(3),
      SEL => exe_stage_alu_m_N68,
      O => exe_stage_alu_m_alu_n0000_3_cyo
    );
  exe_stage_alu_m_alu_n0010_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(7),
      SEL => exe_stage_alu_m_N69,
      O => exe_stage_alu_m_alu_n0010_0_cyo
    );
  exe_stage_alu_m_alu_n0010_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N69,
      O => exe_stage_alu_m_n0010(0)
    );
  exe_stage_alu_m_alu_n0073_7_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_n0298(6),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      ADR3 => exe_stage_alu_m_n0064(6),
      O => exe_stage_alu_m_N64
    );
  exe_stage_alu_m_alu_n0010_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_0_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N70,
      O => exe_stage_alu_m_alu_n0010_1_cyo
    );
  exe_stage_alu_m_alu_n0010_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0010_0_cyo,
      I1 => exe_stage_alu_m_N70,
      O => exe_stage_alu_m_n0010(1)
    );
  exe_stage_alu_m_alu_n0010_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_1_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N71,
      O => exe_stage_alu_m_alu_n0010_2_cyo
    );
  exe_stage_alu_m_alu_n0010_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0010_1_cyo,
      I1 => exe_stage_alu_m_N71,
      O => exe_stage_alu_m_n0010(2)
    );
  exe_stage_alu_m_alu_n0010_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_2_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N72,
      O => exe_stage_alu_m_alu_n0010_3_cyo
    );
  exe_stage_alu_m_alu_n0010_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0010_2_cyo,
      I1 => exe_stage_alu_m_N72,
      O => exe_stage_alu_m_n0010(3)
    );
  exe_stage_alu_m_alu_n0010_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_3_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N73,
      O => exe_stage_alu_m_alu_n0010_4_cyo
    );
  exe_stage_alu_m_alu_n0010_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0010_3_cyo,
      I1 => exe_stage_alu_m_N73,
      O => exe_stage_alu_m_n0010(4)
    );
  exe_stage_alu_m_alu_n0010_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_4_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N74,
      O => exe_stage_alu_m_alu_n0010_5_cyo
    );
  exe_stage_alu_m_alu_n0010_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0010_4_cyo,
      I1 => exe_stage_alu_m_N74,
      O => exe_stage_alu_m_n0010(5)
    );
  exe_stage_alu_m_alu_n0010_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0010_5_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N75,
      O => exe_stage_alu_m_alu_n0010_6_cyo
    );
  exe_stage_alu_m_alu_n0010_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0010_5_cyo,
      I1 => exe_stage_alu_m_N75,
      O => exe_stage_alu_m_n0010(6)
    );
  exe_stage_alu_m_alu_n0019_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(6),
      SEL => exe_stage_alu_m_N77,
      O => exe_stage_alu_m_alu_n0019_0_cyo
    );
  exe_stage_alu_m_alu_n0019_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N77,
      O => exe_stage_alu_m_n0019(0)
    );
  exe_stage_alu_m_alu_n0073_3_lut : X_LUT4
    generic map(
      INIT => X"A959"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_n0298(2),
      ADR2 => exe_stage_alu_m_alu_cyo4,
      ADR3 => exe_stage_alu_m_n0064(2),
      O => exe_stage_alu_m_N60
    );
  exe_stage_alu_m_alu_n0019_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_0_cyo,
      IA => exe_stage_alu_m_n0311(1),
      SEL => exe_stage_alu_m_N78,
      O => exe_stage_alu_m_alu_n0019_1_cyo
    );
  exe_stage_alu_m_alu_n0019_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0019_0_cyo,
      I1 => exe_stage_alu_m_N78,
      O => exe_stage_alu_m_n0019(1)
    );
  exe_stage_alu_m_alu_n0019_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_1_cyo,
      IA => exe_stage_alu_m_n0311(2),
      SEL => exe_stage_alu_m_N79,
      O => exe_stage_alu_m_alu_n0019_2_cyo
    );
  exe_stage_alu_m_alu_n0019_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0019_1_cyo,
      I1 => exe_stage_alu_m_N79,
      O => exe_stage_alu_m_n0019(2)
    );
  exe_stage_alu_m_alu_n0019_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_2_cyo,
      IA => exe_stage_alu_m_n0311(3),
      SEL => exe_stage_alu_m_N80,
      O => exe_stage_alu_m_alu_n0019_3_cyo
    );
  exe_stage_alu_m_alu_n0019_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0019_2_cyo,
      I1 => exe_stage_alu_m_N80,
      O => exe_stage_alu_m_n0019(3)
    );
  exe_stage_alu_m_alu_n0019_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_3_cyo,
      IA => exe_stage_alu_m_n0311(4),
      SEL => exe_stage_alu_m_N81,
      O => exe_stage_alu_m_alu_n0019_4_cyo
    );
  exe_stage_alu_m_alu_n0019_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0019_3_cyo,
      I1 => exe_stage_alu_m_N81,
      O => exe_stage_alu_m_n0019(4)
    );
  exe_stage_alu_m_alu_n0019_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_4_cyo,
      IA => exe_stage_alu_m_n0311(5),
      SEL => exe_stage_alu_m_N82,
      O => exe_stage_alu_m_alu_n0019_5_cyo
    );
  exe_stage_alu_m_alu_n0019_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0019_4_cyo,
      I1 => exe_stage_alu_m_N82,
      O => exe_stage_alu_m_n0019(5)
    );
  exe_stage_alu_m_alu_n0019_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0019_5_cyo,
      IA => exe_stage_alu_m_n0311(6),
      SEL => exe_stage_alu_m_N83,
      O => exe_stage_alu_m_alu_n0019_6_cyo
    );
  exe_stage_alu_m_alu_n0019_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0019_5_cyo,
      I1 => exe_stage_alu_m_N83,
      O => exe_stage_alu_m_n0019(6)
    );
  exe_stage_alu_m_n04548_SW1 : X_LUT4
    generic map(
      INIT => X"FF01"
    )
    port map (
      ADR0 => CHOICE12745,
      ADR1 => exe_stage_alu_m_N961,
      ADR2 => CHOICE12757,
      ADR3 => Reset_IBUF,
      O => N6159
    );
  wb_stage_w_addr1_7_4 : X_LUT4
    generic map(
      INIT => X"8808"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N74,
      ADR3 => wb_stage_n0164,
      O => CHOICE11004
    );
  exe_stage_alu_m_alu_n0216_1_cy : X_MUX2
    port map (
      IB => fet_stage_Temp1_data(12),
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N85,
      O => exe_stage_alu_m_alu_n0216_1_cyo
    );
  port3_out_3_OBUF : X_BUF
    port map (
      I => mem_R_P3_port_out(3),
      O => port3_out_3_OBUF_GTS_TRI
    );
  exe_stage_alu_m_alu_n0216_1_lut : X_LUT3
    generic map(
      INIT => X"1B"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N64,
      ADR2 => exwb_buff_out_R_A(1),
      O => exe_stage_alu_m_N85
    );
  exe_stage_alu_m_alu_n0216_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0216_1_cyo,
      IA => sp_out_from_mem(0),
      SEL => exe_stage_alu_m_N86,
      O => exe_stage_alu_m_alu_n0216_2_cyo
    );
  exe_stage_alu_m_alu_n0216_2_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0216_1_cyo,
      I1 => exe_stage_alu_m_N86,
      O => exe_stage_alu_m_n0216(2)
    );
  exe_stage_alu_m_alu_n0216_3_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0216_2_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => N5940,
      O => exe_stage_alu_m_alu_n0216_3_cyo
    );
  exe_stage_alu_m_alu_n0216_3_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0216_2_cyo,
      I1 => N5940,
      O => exe_stage_alu_m_n0216(3)
    );
  exe_stage_alu_m_alu_n0216_4_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0216_3_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => N5941,
      O => exe_stage_alu_m_alu_n0216_4_cyo
    );
  exe_stage_alu_m_alu_n0216_4_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0216_3_cyo,
      I1 => N5941,
      O => exe_stage_alu_m_n0216(4)
    );
  exe_stage_alu_m_alu_n0216_5_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0216_4_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => N5942,
      O => exe_stage_alu_m_alu_n0216_5_cyo
    );
  exe_stage_alu_m_alu_n0216_5_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0216_4_cyo,
      I1 => N5942,
      O => exe_stage_alu_m_n0216(5)
    );
  exe_stage_alu_m_alu_n0216_6_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0216_5_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => N5943,
      O => exe_stage_alu_m_alu_n0216_6_cyo
    );
  exe_stage_alu_m_alu_n0216_6_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0216_5_cyo,
      I1 => N5943,
      O => exe_stage_alu_m_n0216(6)
    );
  exe_stage_alu_m_alu_n0216_7_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0216_6_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => N5944,
      O => exe_stage_alu_m_alu_n0216_7_cyo
    );
  exe_stage_alu_m_XNor_stagelut7 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(7),
      ADR2 => exe_stage_src2(7),
      ADR3 => N76,
      O => exe_stage_alu_m_N97
    );
  exe_stage_alu_m_alu_n0218_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(4),
      SEL => exe_stage_alu_m_N87,
      O => exe_stage_alu_m_alu_n0218_0_cyo
    );
  exe_stage_alu_m_alu_n0218_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N87,
      O => exe_stage_alu_m_n0218(0)
    );
  exe_stage_alu_m_alu_n0218_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(4),
      ADR2 => exe_stage_src1(4),
      ADR3 => N86,
      O => exe_stage_alu_m_N87
    );
  exe_stage_alu_m_alu_n0218_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0218_0_cyo,
      IA => exe_stage_src1(5),
      SEL => exe_stage_alu_m_N88,
      O => exe_stage_alu_m_alu_n0218_1_cyo
    );
  exe_stage_alu_m_alu_n0218_1_xor : X_XOR2
    port map (
      I0 => exe_stage_alu_m_alu_n0218_0_cyo,
      I1 => exe_stage_alu_m_N88,
      O => exe_stage_alu_m_n0218(1)
    );
  exe_stage_alu_m_alu_n0218_1_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(5),
      ADR2 => exe_stage_src2(5),
      ADR3 => N72,
      O => exe_stage_alu_m_N88
    );
  exe_stage_alu_m_alu_n0218_2_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0218_1_cyo,
      IA => exe_stage_src1(6),
      SEL => exe_stage_alu_m_N89,
      O => exe_stage_alu_m_alu_n0218_2_cyo
    );
  exe_stage_alu_m_n0364147 : X_LUT4
    generic map(
      INIT => X"FF02"
    )
    port map (
      ADR0 => exe_stage_alu_m_N951,
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => exe_stage_alu_m_n0001(3),
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE11977
    );
  exe_stage_alu_m_XNor_stagecy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(0),
      SEL => exe_stage_alu_m_N90,
      O => exe_stage_alu_m_XNor_stage_cyo
    );
  exe_stage_alu_m_XNor_stagelut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(0),
      ADR3 => N78,
      O => exe_stage_alu_m_N90
    );
  exe_stage_alu_m_XNor_stagecy_rn_0 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo,
      IA => exe_stage_src1(1),
      SEL => exe_stage_alu_m_N91,
      O => exe_stage_alu_m_XNor_stage_cyo1
    );
  exe_stage_alu_m_XNor_stagelut1 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(1),
      ADR2 => exe_stage_src2(1),
      ADR3 => N64,
      O => exe_stage_alu_m_N91
    );
  exe_stage_alu_m_XNor_stagecy_rn_1 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo1,
      IA => exe_stage_src1(2),
      SEL => exe_stage_alu_m_N92,
      O => exe_stage_alu_m_XNor_stage_cyo2
    );
  exe_stage_alu_m_XNor_stagelut2 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(2),
      ADR2 => exe_stage_src2(2),
      ADR3 => N66,
      O => exe_stage_alu_m_N92
    );
  exe_stage_alu_m_XNor_stagecy_rn_2 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo2,
      IA => exe_stage_src1(3),
      SEL => exe_stage_alu_m_N93,
      O => exe_stage_alu_m_XNor_stage_cyo3
    );
  exe_stage_alu_m_XNor_stagelut3 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(3),
      ADR2 => exe_stage_src2(3),
      ADR3 => N68,
      O => exe_stage_alu_m_N93
    );
  exe_stage_alu_m_XNor_stagecy_rn_3 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo3,
      IA => exe_stage_src1(4),
      SEL => exe_stage_alu_m_N94,
      O => exe_stage_alu_m_XNor_stage_cyo4
    );
  exe_stage_alu_m_XNor_stagelut4 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(4),
      ADR2 => exe_stage_src2(4),
      ADR3 => N70,
      O => exe_stage_alu_m_N94
    );
  exe_stage_alu_m_XNor_stagecy_rn_4 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo4,
      IA => exe_stage_src1(5),
      SEL => exe_stage_alu_m_N95,
      O => exe_stage_alu_m_XNor_stage_cyo5
    );
  exe_stage_alu_m_XNor_stagelut5 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(5),
      ADR2 => exe_stage_src2(5),
      ADR3 => N72,
      O => exe_stage_alu_m_N95
    );
  exe_stage_alu_m_XNor_stagecy_rn_5 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo5,
      IA => exe_stage_src1(6),
      SEL => exe_stage_alu_m_N96,
      O => exe_stage_alu_m_XNor_stage_cyo6
    );
  exe_stage_alu_m_XNor_stagelut6 : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => exwb_buff_out_R_A(6),
      ADR2 => exe_stage_src2(6),
      ADR3 => N74,
      O => exe_stage_alu_m_N96
    );
  exe_stage_alu_m_XNor_stagecy_rn_6 : X_MUX2
    port map (
      IB => exe_stage_alu_m_XNor_stage_cyo6,
      IA => exe_stage_src1(7),
      SEL => exe_stage_alu_m_N97,
      O => exe_stage_alu_m_XNor_stage_cyo7
    );
  exe_stage_alu_m_Eq_stagelut : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exe_stage_src1(0),
      ADR1 => exe_stage_src2(0),
      ADR2 => exe_stage_src1(1),
      ADR3 => exe_stage_src2(1),
      O => exe_stage_alu_m_N99
    );
  exe_stage_alu_m_Eq_stagecy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N99,
      O => exe_stage_alu_m_Eq_stage_cyo
    );
  exe_stage_alu_m_Eq_stagelut1 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exe_stage_src1(2),
      ADR1 => exe_stage_src2(2),
      ADR2 => exe_stage_src1(3),
      ADR3 => exe_stage_src2(3),
      O => exe_stage_alu_m_N100
    );
  exe_stage_alu_m_Eq_stagecy_rn_0 : X_MUX2
    port map (
      IB => exe_stage_alu_m_Eq_stage_cyo,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N100,
      O => exe_stage_alu_m_Eq_stage_cyo1
    );
  exe_stage_alu_m_Eq_stagelut2 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exe_stage_src1(4),
      ADR1 => exe_stage_src2(4),
      ADR2 => exe_stage_src1(5),
      ADR3 => exe_stage_src2(5),
      O => exe_stage_alu_m_N101
    );
  exe_stage_alu_m_Eq_stagecy_rn_1 : X_MUX2
    port map (
      IB => exe_stage_alu_m_Eq_stage_cyo1,
      IA => fet_stage_Temp1_data(12),
      SEL => exe_stage_alu_m_N101,
      O => exe_stage_alu_m_Eq_stage_cyo2
    );
  exe_stage_alu_m_Eq_stagelut3 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exe_stage_src1(6),
      ADR1 => exe_stage_src2(6),
      ADR2 => exe_stage_src1(7),
      ADR3 => exe_stage_src2(7),
      O => exe_stage_alu_m_N102
    );
  exe_stage_alu_m_alu_n0000_3_lut : X_LUT4
    generic map(
      INIT => X"1EB4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N68,
      ADR2 => exe_stage_src2(3),
      ADR3 => exwb_buff_out_R_A(3),
      O => exe_stage_alu_m_N68
    );
  exe_stage_alu_m_alu_n0217_0_cy : X_MUX2
    port map (
      IB => sp_out_from_mem(0),
      IA => exe_stage_src1(0),
      SEL => exe_stage_alu_m_N103,
      O => exe_stage_alu_m_alu_n0217_0_cyo
    );
  exe_stage_alu_m_alu_n0217_0_xor : X_XOR2
    port map (
      I0 => sp_out_from_mem(0),
      I1 => exe_stage_alu_m_N103,
      O => exe_stage_alu_m_n0217(0)
    );
  exe_stage_alu_m_alu_n0217_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(0),
      ADR3 => N78,
      O => exe_stage_alu_m_N103
    );
  exe_stage_alu_m_alu_n0217_1_cy : X_MUX2
    port map (
      IB => exe_stage_alu_m_alu_n0217_0_cyo,
      IA => exe_stage_src1(1),
      SEL => exe_stage_alu_m_N104,
      O => exe_stage_alu_m_alu_n0217_1_cyo
    );
  cu_n0137_65 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(2),
      ADR3 => N741,
      O => cu_n0137
    );
  wb_stage_di_A_1_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => W_A_from_writeback,
      ADR1 => exwb_buff_out_R_A(1),
      O => di_A_from_writeback(1)
    );
  cu_sel_rd_66 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => mem_Inst_rid_Mram_R0R1_ren_inst_inv_0,
      CLK => cu_n0017(1),
      O => cu_sel_rd,
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_Ker631 : X_LUT2
    generic map(
      INIT => X"1"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(3),
      O => cu_N63
    );
  cu_sel_mux9_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => cu_n0023(0),
      CLK => cu_n0333,
      O => cu_sel_mux9(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_n0023_1_1 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => cu_n0302,
      ADR1 => Reset_IBUF,
      ADR2 => cu_N59,
      ADR3 => cu_N71,
      O => cu_n0023(1)
    );
  port0_in_1_IBUF_67 : X_BUF
    port map (
      I => port0_in(1),
      O => port0_in_1_IBUF
    );
  mem_mux_13_out1_0_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => sp_out_from_mem(0),
      ADR2 => write_addr1_from_writeback(0),
      O => mem_w_addr_b1(0)
    );
  mem_mux_13_out1_7_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => write_addr1_from_writeback(7),
      O => mem_w_addr_b1(7)
    );
  mem_mux_13_out1_1_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => write_addr1_from_writeback(1),
      O => mem_w_addr_b1(1)
    );
  mem_mux_13_out1_2_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => write_addr1_from_writeback(2),
      O => mem_w_addr_b1(2)
    );
  mem_mux_13_out1_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => sp_out_from_mem(0),
      ADR2 => write_addr1_from_writeback(3),
      O => mem_w_addr_b1(3)
    );
  mem_mux_13_out1_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => write_addr1_from_writeback(4),
      O => mem_w_addr_b1(4)
    );
  mem_mux_13_out1_5_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_sel_mux11(1),
      ADR1 => fet_stage_Temp1_data(12),
      ADR2 => write_addr1_from_writeback(5),
      O => mem_w_addr_b1(5)
    );
  wb_stage_p1_in_7_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(7),
      ADR1 => wb_stage_N59,
      ADR2 => N6235,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(7)
    );
  wb_stage_p1_in_3_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(3),
      ADR1 => wb_stage_N59,
      ADR2 => N6237,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(3)
    );
  wb_stage_di_DPL_0_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(0),
      ADR2 => N1425,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(0)
    );
  wb_stage_di_DPL_2_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(2),
      ADR2 => N1427,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(2)
    );
  wb_stage_di_DPL_4_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_N62,
      ADR1 => exwb_buff_out_R_B(4),
      ADR2 => N1429,
      ADR3 => wb_stage_N6,
      O => di_DPL_from_writeback(4)
    );
  wb_stage_w_addr1_5_12 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_D22(5),
      ADR1 => wb_stage_N56,
      ADR2 => wb_stage_N29,
      ADR3 => CHOICE11578,
      O => write_addr1_from_writeback(5)
    );
  wb_stage_p1_in_1_Q : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(1),
      ADR1 => wb_stage_N59,
      ADR2 => N6239,
      ADR3 => wb_stage_N21,
      O => p1_in_from_writeback(1)
    );
  fet_stage_que_state_M_que_byte1_5 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(5),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(5),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_state_FFd2_In132_SW0_SW0 : X_LUT4
    generic map(
      INIT => X"FF1F"
    )
    port map (
      ADR0 => rom_DATA_BUS(0),
      ADR1 => rom_DATA_BUS(2),
      ADR2 => rom_DATA_BUS(4),
      ADR3 => rom_DATA_BUS(5),
      O => N6305
    );
  exe_stage_alu_m_n0489190 : X_LUT4
    generic map(
      INIT => X"FF28"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0238,
      ADR1 => exe_stage_alu_m_n0214(1),
      ADR2 => exe_stage_alu_m_Madd_n0166_Mxor_Result_1_Xo(0),
      ADR3 => CHOICE11918,
      O => CHOICE11925
    );
  exe_stage_alu_m_n00711_SW0 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exe_stage_src1(1),
      ADR1 => exe_stage_alu_m_N961,
      ADR2 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR3 => exe_stage_alu_m_n0227,
      O => N6155
    );
  fet_stage_que_state_M_out2_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(5),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(5),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_n0019_7_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(7),
      O => fet_stage_que_state_M_n0019(7)
    );
  fet_stage_que_state_M_que_byte2_5 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(5),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(5),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_state_FFd1_In1 : X_LUT3
    generic map(
      INIT => X"26"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd1,
      ADR1 => fet_stage_que_state_M_state_FFd3,
      ADR2 => fet_stage_que_state_M_state_FFd2,
      O => fet_stage_que_state_M_state_FFd1_In
    );
  fet_stage_que_state_M_que_byte3_7_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5924
    );
  fet_stage_que_state_M_state_FFd2_68 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5932,
      SRST => Reset_IBUF,
      SSET => CHOICE11634,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_state_FFd2,
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  cu_Ker31 : X_LUT4
    generic map(
      INIT => X"56F6"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(4),
      O => cu_N3
    );
  fet_stage_que_state_M_out2_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(4),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(4),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_n0023_5_1 : X_LUT4
    generic map(
      INIT => X"FF36"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd1,
      ADR1 => fet_stage_que_state_M_state_FFd3,
      ADR2 => fet_stage_que_state_M_state_FFd2,
      ADR3 => Reset_IBUF,
      O => fet_stage_que_state_M_N39
    );
  fet_stage_que_state_M_out3_5 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5931,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(5),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_out3_4 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5930,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(4),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_out2_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(3),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(3),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_out2_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(2),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(2),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_out2_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(1),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(1),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_state_FFd2_In3071 : X_LUT4
    generic map(
      INIT => X"AAA8"
    )
    port map (
      ADR0 => N6247,
      ADR1 => CHOICE11702,
      ADR2 => CHOICE11680,
      ADR3 => CHOICE11690,
      O => N5932
    );
  fet_stage_que_state_M_out2_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(0),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(0),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_n0023_5_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(5)
    );
  port1_in_4_IBUF_69 : X_BUF
    port map (
      I => port1_in(4),
      O => port1_in_4_IBUF
    );
  fet_stage_que_state_M_out3_3 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5929,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(3),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_out3_1 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5928,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(1),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_n0023_4_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(4),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(4)
    );
  port1_in_3_IBUF_70 : X_BUF
    port map (
      I => port1_in(3),
      O => port1_in_3_IBUF
    );
  fet_stage_que_state_M_out3_0 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5927,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(0),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_n0023_3_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(3),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(3)
    );
  fet_stage_que_state_M_n0023_7_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(7)
    );
  fet_stage_que_state_M_out1_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(7),
      RST => fet_stage_que_state_M_out1_7_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(7),
      CE => VCC,
      SET => GND
    );
  Reset_IBUF_71 : X_BUF
    port map (
      I => Reset,
      O => Reset_IBUF
    );
  fet_stage_que_state_M_state_FFd1_72 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_state_FFd1_In,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_state_FFd1,
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_n0019_0_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(0),
      O => fet_stage_que_state_M_n0019(0)
    );
  fet_stage_que_state_M_n0023_6_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(6),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(6)
    );
  fet_stage_que_state_M_n0019_1_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(1),
      O => fet_stage_que_state_M_n0019(1)
    );
  fet_stage_que_state_M_n0019_2_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(2),
      O => fet_stage_que_state_M_n0019(2)
    );
  fet_stage_que_state_M_out2_7 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(7),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(7),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte3_2_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(2),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5925
    );
  fet_stage_que_state_M_inst_que_code_3_340 : X_LUT4
    generic map(
      INIT => X"020B"
    )
    port map (
      ADR0 => CHOICE11787,
      ADR1 => fet_stage_que_state_M_state_FFd3,
      ADR2 => Reset_IBUF,
      ADR3 => N6287,
      O => iqc_from_fetch(0)
    );
  fet_stage_que_state_M_state_FFd3_73 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_state_FFd3_In,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_state_FFd3,
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_que_byte3_6_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(6),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5926
    );
  fet_stage_que_state_M_n0022_0_1 : X_LUT4
    generic map(
      INIT => X"FFEB"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => fet_stage_que_state_M_state_FFd2,
      ADR2 => fet_stage_que_state_M_state_FFd3,
      ADR3 => fet_stage_que_state_M_state_FFd1,
      O => fet_stage_que_state_M_N24
    );
  fet_stage_que_state_M_n0022_0_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(0),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(0)
    );
  dec_stage_d_mux7_out1_2_73 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(2),
      ADR3 => mem_R_B_data_out(2),
      O => CHOICE12293
    );
  fet_stage_que_state_M_n0022_1_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(1),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(1)
    );
  fet_stage_que_state_M_que_byte3_0_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(0),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5927
    );
  fet_stage_que_state_M_out1_1 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(1),
      RST => fet_stage_que_state_M_out1_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(1),
      CE => VCC,
      SET => GND
    );
  fet_stage_que_state_M_n0019_3_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(3),
      O => fet_stage_que_state_M_n0019(3)
    );
  fet_stage_que_state_M_n0019_4_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(4),
      O => fet_stage_que_state_M_n0019(4)
    );
  wb_stage_Ker591 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => wb_stage_N34,
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => exwb_buff_out_D22(6),
      O => wb_stage_N59
    );
  fet_stage_que_state_M_que_byte3_1_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(1),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5928
    );
  exe_stage_alu_m_n036480_SW0 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11958,
      ADR1 => exe_stage_src1(0),
      ADR2 => CHOICE11947,
      ADR3 => CHOICE11954,
      O => N6181
    );
  fet_stage_que_state_M_n0022_2_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(2),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(2)
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_110 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N101,
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(3),
      ADR3 => CHOICE11417,
      O => CHOICE11418
    );
  fet_stage_que_state_M_out1_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(6),
      RST => fet_stage_que_state_M_out1_6_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(6),
      CE => VCC,
      SET => GND
    );
  exe_stage_alu_m_n043317 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0243,
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_n0008(9),
      ADR3 => exe_stage_alu_m_n0224,
      O => CHOICE12707
    );
  fet_stage_que_state_M_inst_que_code_3_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(6),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(5),
      ADR3 => rom_DATA_BUS(0),
      O => CHOICE11724
    );
  exe_stage_alu_m_n04305 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => exe_stage_alu_m_N961,
      ADR1 => exe_stage_alu_m_n0227,
      O => CHOICE12765
    );
  fet_stage_que_state_M_n0022_3_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(3),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(3)
    );
  fet_stage_que_state_M_state_FFd2_In2 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd2,
      ADR1 => fet_stage_que_state_M_state_FFd3,
      O => CHOICE11634
    );
  fet_stage_que_state_M_que_byte3_3_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(3),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5929
    );
  fet_stage_que_state_M_n0022_4_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(4),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(4)
    );
  fet_stage_que_state_M_out1_4 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(4),
      RST => fet_stage_que_state_M_out1_4_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(4),
      CE => VCC,
      SET => GND
    );
  fet_stage_que_state_M_n0019_5_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(5),
      O => fet_stage_que_state_M_n0019(5)
    );
  dec_stage_d_mux7_out1_5_78 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(5),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(5),
      O => CHOICE12130
    );
  fet_stage_que_state_M_n0022_5_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(5)
    );
  exe_stage_alu_m_n045950 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE12734,
      ADR1 => exe_stage_src2(1),
      ADR2 => exe_stage_alu_m_N621,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE12682
    );
  fet_stage_que_state_M_n0022_6_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(6),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(6)
    );
  fet_stage_que_state_M_n0019_6_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => iqc_from_fetch(0),
      ADR1 => fet_stage_que_state_M_que_byte1(6),
      O => fet_stage_que_state_M_n0019(6)
    );
  fet_stage_que_state_M_next_Mcode_2_84_SW0 : X_LUT3
    generic map(
      INIT => X"DF"
    )
    port map (
      ADR0 => CHOICE11588,
      ADR1 => rom_DATA_BUS(1),
      ADR2 => rom_DATA_BUS(2),
      O => N6319
    );
  fet_stage_que_state_M_out3_6 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5926,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(6),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_out3_2 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5925,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(2),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  fet_stage_que_state_M_que_byte3_4_11 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => rom_DATA_BUS(4),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_state_FFd1,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => N5930
    );
  fet_stage_que_state_M_out1_2 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(2),
      RST => fet_stage_que_state_M_out1_2_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(2),
      CE => VCC,
      SET => GND
    );
  fet_stage_que_state_M_out1_3 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(3),
      RST => fet_stage_que_state_M_out1_3_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(3),
      CE => VCC,
      SET => GND
    );
  fet_stage_que_state_M_out1_5 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(5),
      RST => fet_stage_que_state_M_out1_5_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(5),
      CE => VCC,
      SET => GND
    );
  fet_stage_que_state_M_n0022_7_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N24,
      O => fet_stage_que_state_M_n0022(7)
    );
  port1_in_7_IBUF_74 : X_BUF
    port map (
      I => port1_in(7),
      O => port1_in_7_IBUF
    );
  fet_stage_que_state_M_out1_0 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0019(0),
      RST => fet_stage_que_state_M_out1_0_GSR_OR,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out1(0),
      CE => VCC,
      SET => GND
    );
  fet_stage_que_state_M_out2_6 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_que_byte2(6),
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out2(6),
      CE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_7 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(7),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(7),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_6 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(6),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(6),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(0),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(1),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_2 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(2),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(2),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_3 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(3),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(3),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte1_4 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0023(4),
      CLK => fet_stage_que_state_M_n0300,
      O => fet_stage_que_state_M_que_byte1(4),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_7 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(7),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(7),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_6 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(6),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(6),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_0 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(0),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(0),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_1 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(1),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(1),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_2 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(2),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(2),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_3 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(3),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(3),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_que_byte2_4 : X_LATCHE
    generic map(
      INIT => '0'
    )
    port map (
      I => fet_stage_que_state_M_n0022(4),
      CLK => fet_stage_que_state_M_n0299,
      O => fet_stage_que_state_M_que_byte2(4),
      GE => VCC,
      SET => GND,
      RST => GSR
    );
  fet_stage_que_state_M_n0023_2_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(2),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(2)
    );
  dec_stage_d_mux7_out1_6_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(14),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12170
    );
  fet_stage_que_state_M_state_FFd3_In1 : X_LUT4
    generic map(
      INIT => X"F5D4"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd3,
      ADR1 => fet_stage_que_state_M_state_FFd1,
      ADR2 => fet_stage_que_state_M_next_Mcode(2),
      ADR3 => fet_stage_que_state_M_state_FFd2,
      O => fet_stage_que_state_M_state_FFd3_In
    );
  fet_stage_que_state_M_n03001 : X_LUT4
    generic map(
      INIT => X"FFE9"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd1,
      ADR1 => fet_stage_que_state_M_state_FFd2,
      ADR2 => fet_stage_que_state_M_state_FFd3,
      ADR3 => Reset_IBUF,
      O => fet_stage_que_state_M_n0300
    );
  fet_stage_que_state_M_n02991 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd1,
      ADR1 => Reset_IBUF,
      ADR2 => fet_stage_que_state_M_state_FFd2,
      ADR3 => fet_stage_que_state_M_state_FFd3,
      O => fet_stage_que_state_M_n0299
    );
  port1_in_5_IBUF_75 : X_BUF
    port map (
      I => port1_in(5),
      O => port1_in_5_IBUF
    );
  fet_stage_que_state_M_n0023_1_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(1),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(1)
    );
  port1_in_6_IBUF_76 : X_BUF
    port map (
      I => port1_in(6),
      O => port1_in_6_IBUF
    );
  fet_stage_que_state_M_Ker271 : X_LUT3
    generic map(
      INIT => X"7F"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(7),
      O => fet_stage_que_state_M_N27
    );
  fet_stage_que_state_M_state_FFd2_In90 : X_LUT4
    generic map(
      INIT => X"0880"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(2),
      ADR3 => rom_DATA_BUS(7),
      O => CHOICE11664
    );
  wb_stage_p3_in_1_1 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N41,
      ADR1 => exwb_buff_out_R_B(1),
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => wb_stage_n0075,
      O => p3_in_from_writeback(1)
    );
  cu_Ker581 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(6),
      O => cu_N58
    );
  wb_stage_Ker67_SW0 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => exwb_buff_out_D11(7),
      O => N701
    );
  cu_Ker711 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(3),
      O => cu_N71
    );
  cu_n0028_1_SW0 : X_LUT3
    generic map(
      INIT => X"13"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(3),
      ADR2 => cu_N59,
      O => N721
    );
  cu_n0137_SW0 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(3),
      ADR3 => cu_N27,
      O => N741
    );
  cu_n0018_1_SW0 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(2),
      O => N781
    );
  cu_Ker22_SW0 : X_LUT4
    generic map(
      INIT => X"FDAF"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(0),
      O => N801
    );
  cu_Ker22_SW1 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(2),
      O => N81
    );
  cu_Ker18_SW0 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => cu_N33,
      ADR1 => ifid_buff_out1(6),
      ADR2 => cu_N0,
      ADR3 => cu_N44,
      O => N83
    );
  cu_n033319 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(5),
      O => CHOICE10743
    );
  wb_stage_w_addr0_7_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => wb_stage_N57,
      O => CHOICE11022
    );
  wb_stage_p1_in_2_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(2),
      O => N6229
    );
  wb_stage_w_data0_0_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(0),
      ADR1 => wb_stage_N57,
      O => CHOICE10924
    );
  wb_stage_w_addr0_6_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE11015,
      ADR1 => CHOICE11020,
      O => write_addr0_from_writeback(6)
    );
  wb_stage_p1_in_0_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(0),
      O => N6227
    );
  wb_stage_w_addr0_6_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => write_addr0_from_writeback(6),
      O => CHOICE11020
    );
  cu_n030311_SW0 : X_LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(2),
      ADR2 => CHOICE11372,
      ADR3 => cu_N63,
      O => N6203
    );
  wb_stage_w_data1_6_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(6),
      ADR1 => wb_stage_N56,
      O => CHOICE10966
    );
  wb_stage_w_data0_4_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(4),
      ADR1 => wb_stage_N57,
      O => CHOICE10889
    );
  wb_stage_w_data1_7_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10917,
      ADR1 => CHOICE10922,
      O => write_data1_from_writeback(7)
    );
  wb_stage_w_data1_5_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10959,
      ADR1 => CHOICE10964,
      O => write_data1_from_writeback(5)
    );
  wb_stage_p1_in_5_SW1 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => exwb_buff_out_D11(5),
      ADR1 => wb_stage_N75,
      ADR2 => exwb_buff_out_D11(6),
      ADR3 => exwb_buff_out_R_A(5),
      O => N6225
    );
  exe_stage_alu_m_n046418 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0260,
      ADR1 => exe_stage_src1(1),
      ADR2 => exe_stage_alu_m_n0261,
      ADR3 => exe_stage_src1(3),
      O => CHOICE12632
    );
  wb_stage_w_data1_5_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => write_data1_from_writeback(5),
      O => CHOICE10964
    );
  wb_stage_w_data1_7_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => write_data1_from_writeback(7),
      O => CHOICE10922
    );
  cu_n030311 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => cu_n0137,
      ADR1 => cu_n0076,
      ADR2 => cu_N68,
      ADR3 => N6203,
      O => cu_n0303
    );
  cu_n0017_1_SW0 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => cu_N59,
      ADR1 => cu_N63,
      ADR2 => ifid_buff_out1(4),
      ADR3 => cu_N18,
      O => N97
    );
  cu_n0330142 : X_LUT4
    generic map(
      INIT => X"0228"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(5),
      ADR3 => ifid_buff_out1(6),
      O => CHOICE10864
    );
  wb_stage_Ker25_SW1 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => exwb_buff_out_D11(4),
      ADR2 => exwb_buff_out_D11(2),
      ADR3 => exwb_buff_out_D11(6),
      O => N6260
    );
  fet_stage_que_state_M_n0023_0_2 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(0),
      ADR1 => cu_sel_rd,
      ADR2 => fet_stage_que_state_M_N39,
      O => fet_stage_que_state_M_n0023(0)
    );
  dec_stage_d_mux7_out1_4_78 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(4),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(4),
      O => CHOICE12163
    );
  wb_stage_w_addr0_4_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10882,
      ADR1 => CHOICE10887,
      O => write_addr0_from_writeback(4)
    );
  dec_stage_d_instruction_decoder_Ker87_SW2 : X_LUT4
    generic map(
      INIT => X"E121"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(5),
      ADR3 => ifid_buff_out1(4),
      O => N6173
    );
  wb_stage_w_addr0_4_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_D11(4),
      ADR3 => write_addr0_from_writeback(4),
      O => CHOICE10887
    );
  dec_stage_d_instruction_decoder_Ker48_SW0 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(5),
      O => N834
    );
  wb_stage_p2_in_0_SW0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => wb_stage_n0072,
      ADR1 => wb_stage_N8,
      O => N826
    );
  wb_stage_w_addr0_6_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(6),
      ADR1 => wb_stage_N57,
      O => CHOICE11015
    );
  wb_stage_p0_in_2_SW0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => wb_stage_n0076,
      ADR1 => wb_stage_N7,
      O => N824
    );
  exe_stage_alu_m_n034733 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE12734,
      ADR1 => exe_stage_src2(6),
      ADR2 => CHOICE11834,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE11839
    );
  wb_stage_w_addr0_5_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE11008,
      ADR1 => CHOICE11013,
      O => write_addr0_from_writeback(5)
    );
  cu_n033333 : X_LUT4
    generic map(
      INIT => X"2232"
    )
    port map (
      ADR0 => CHOICE10743,
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(1),
      O => CHOICE10746
    );
  wb_stage_w_addr0_5_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_D11(5),
      ADR3 => write_addr0_from_writeback(5),
      O => CHOICE11013
    );
  exe_stage_alu_m_n047637 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => exe_stage_src1(4),
      ADR1 => exe_stage_alu_m_n0230,
      ADR2 => exe_stage_alu_m_n0260,
      ADR3 => exe_stage_src1(3),
      O => CHOICE12560
    );
  dec_stage_d_mux7_out1_1_73 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(1),
      ADR3 => mem_R_B_data_out(1),
      O => CHOICE12328
    );
  cu_n033371_SW0 : X_LUT4
    generic map(
      INIT => X"AFA8"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(3),
      ADR3 => CHOICE10746,
      O => N6195
    );
  cu_n0332236_G : X_LUT4
    generic map(
      INIT => X"1544"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(5),
      O => N6453
    );
  cu_Ker3312 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => cu_N27,
      ADR2 => ifid_buff_out1(0),
      ADR3 => ifid_buff_out1(2),
      O => CHOICE10612
    );
  exe_stage_alu_m_n02221 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => exe_stage_alu_m_N841,
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(4),
      O => exe_stage_alu_m_n0222
    );
  wb_stage_w_data1_5_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(5),
      ADR1 => wb_stage_N56,
      O => CHOICE10959
    );
  exe_stage_alu_m_des_cy51 : X_LUT3
    generic map(
      INIT => X"57"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0153(7),
      ADR1 => exe_stage_alu_m_n0153(6),
      ADR2 => exe_stage_alu_m_n0153(5),
      O => CHOICE12006
    );
  exe_stage_alu_m_n036429 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0233,
      ADR1 => CHOICE12734,
      ADR2 => exe_stage_src2(7),
      ADR3 => exe_stage_alu_m_n0263,
      O => CHOICE11945
    );
  cu_Ker3316 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(4),
      ADR2 => cu_N65,
      ADR3 => CHOICE10612,
      O => CHOICE10613
    );
  wb_stage_w_data0_3_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10952,
      ADR1 => CHOICE10957,
      O => write_data0_from_writeback(3)
    );
  cu_Ker3321 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => CHOICE10613,
      O => cu_N33
    );
  wb_stage_w_data1_7_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(7),
      ADR1 => wb_stage_N56,
      O => CHOICE10917
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_119 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11384,
      ADR1 => ifid_buff_out1(3),
      ADR2 => CHOICE11379,
      O => CHOICE11385
    );
  wb_stage_w_data0_3_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => write_data0_from_writeback(3),
      O => CHOICE10957
    );
  dec_stage_d_mux9_out1_3_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(3),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(3),
      O => N6455
    );
  exe_stage_alu_m_n048963 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0260,
      ADR1 => exe_stage_src1(4),
      ADR2 => exe_stage_alu_m_n0261,
      ADR3 => exe_stage_src1(6),
      O => CHOICE11899
    );
  wb_stage_w_data0_7_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10910,
      ADR1 => CHOICE10915,
      O => write_data0_from_writeback(7)
    );
  cu_n030232 : X_LUT4
    generic map(
      INIT => X"AE04"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => N6193,
      ADR2 => ifid_buff_out1(0),
      ADR3 => CHOICE11372,
      O => CHOICE10673
    );
  wb_stage_w_addr0_5_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(5),
      ADR1 => wb_stage_N57,
      O => CHOICE11008
    );
  fet_stage_que_state_M_state_FFd2_In132 : X_LUT4
    generic map(
      INIT => X"31F5"
    )
    port map (
      ADR0 => N6185,
      ADR1 => cu_sel_rd,
      ADR2 => CHOICE11664,
      ADR3 => rom_DATA_BUS(6),
      O => CHOICE11675
    );
  exe_stage_alu_m_n02441 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(4),
      ADR1 => exe_stage_alu_m_N841,
      ADR2 => idex_buff_out_Opcode(2),
      O => exe_stage_alu_m_n0244
    );
  wb_stage_di_DPH_0_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(0),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1347
    );
  wb_stage_di_DPH_1_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(1),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1345
    );
  wb_stage_di_DPH_7_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(7),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1343
    );
  wb_stage_di_DPH_2_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(2),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N13411
    );
  wb_stage_di_DPH_3_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(3),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1339
    );
  wb_stage_di_DPH_4_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(4),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1337
    );
  wb_stage_di_DPH_5_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(5),
      ADR1 => wb_stage_N68,
      ADR2 => exwb_buff_out_D11(0),
      O => N1335
    );
  cu_Ker010 : X_LUT4
    generic map(
      INIT => X"FF2F"
    )
    port map (
      ADR0 => cu_N46,
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(5),
      O => CHOICE10619
    );
  wb_stage_W_DPL_SW1 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => wb_stage_N73,
      ADR1 => wb_stage_N71,
      ADR2 => exwb_buff_out_D22(0),
      O => N6223
    );
  wb_stage_W_DPH_SW1 : X_LUT3
    generic map(
      INIT => X"DF"
    )
    port map (
      ADR0 => wb_stage_N73,
      ADR1 => exwb_buff_out_D22(0),
      ADR2 => wb_stage_N71,
      O => N6221
    );
  cu_Ker1734 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => cu_N69,
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(0),
      O => CHOICE10715
    );
  wb_stage_w_addr1_7_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE11001,
      ADR1 => CHOICE11006,
      O => write_addr1_from_writeback(7)
    );
  wb_stage_w_data0_7_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(7),
      ADR3 => write_data0_from_writeback(7),
      O => CHOICE10915
    );
  wb_stage_w_addr1_7_11 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => CHOICE11004,
      ADR2 => wb_stage_N111,
      ADR3 => write_addr1_from_writeback(7),
      O => CHOICE11006
    );
  exe_stage_alu_m_n0489246 : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N6175,
      ADR2 => exe_stage_alu_m_n0005(1),
      ADR3 => exe_stage_alu_m_n0223,
      O => RA_out_from_execute(5)
    );
  port2_in_4_IBUF_77 : X_BUF
    port map (
      I => port2_in(4),
      O => port2_in_4_IBUF
    );
  cu_Ker17103_SW0 : X_LUT4
    generic map(
      INIT => X"B888"
    )
    port map (
      ADR0 => CHOICE10613,
      ADR1 => ifid_buff_out1(7),
      ADR2 => CHOICE10709,
      ADR3 => ifid_buff_out1(1),
      O => N6283
    );
  exe_stage_alu_m_n043617 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0243,
      ADR1 => exe_stage_src2(2),
      ADR2 => exe_stage_alu_m_n0008(10),
      ADR3 => exe_stage_alu_m_n0224,
      O => CHOICE12790
    );
  dec_stage_d_mux7_out1_3_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(11),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12071
    );
  wb_stage_n0068_1_43_SW0 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => wb_stage_N66,
      ADR1 => exwb_buff_out_D22(3),
      ADR2 => wb_stage_n0184(6),
      ADR3 => exwb_buff_out_D22(2),
      O => N6313
    );
  wb_stage_w_addr0_4_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => wb_stage_N57,
      O => CHOICE10882
    );
  dec_stage_d_mux7_out1_7_106 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12223,
      ADR2 => CHOICE12218,
      ADR3 => CHOICE12229,
      O => CHOICE12232
    );
  cu_Ker024 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => cu_N14,
      ADR2 => ifid_buff_out1(3),
      ADR3 => ifid_buff_out1(5),
      O => CHOICE10624
    );
  exe_stage_alu_m_n0469122_SW0 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => N6191,
      ADR1 => CHOICE12591,
      ADR2 => CHOICE12612,
      ADR3 => CHOICE12608,
      O => N6311
    );
  dec_stage_d_instruction_decoder_Ker93_SW0 : X_LUT3
    generic map(
      INIT => X"EF"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(7),
      O => N785
    );
  cu_Ker026 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE10624,
      ADR1 => ifid_buff_out1(2),
      ADR2 => CHOICE10619,
      O => cu_N0
    );
  cu_Ker12_SW0 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => cu_N39,
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(7),
      O => N146
    );
  cu_Ker1712 : X_LUT4
    generic map(
      INIT => X"64EC"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(4),
      O => CHOICE10709
    );
  wb_stage_w_addr0_1_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10875,
      ADR1 => CHOICE10880,
      O => write_addr0_from_writeback(1)
    );
  wb_stage_w_data0_3_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(3),
      ADR1 => wb_stage_N57,
      O => CHOICE10952
    );
  wb_stage_load_p2_SW0 : X_LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      ADR0 => exwb_buff_out_D22(5),
      ADR1 => exwb_buff_out_D22(6),
      O => N776
    );
  wb_stage_w_addr0_1_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_D11(1),
      ADR3 => write_addr0_from_writeback(1),
      O => CHOICE10880
    );
  wb_stage_w_addr1_7_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => wb_stage_N56,
      O => CHOICE11001
    );
  wb_stage_w_data0_2_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10945,
      ADR1 => CHOICE10950,
      O => write_data0_from_writeback(2)
    );
  cu_n0333155_SW0_SW0 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => N6195,
      ADR1 => ifid_buff_out1(6),
      ADR2 => cu_N14,
      O => N6317
    );
  wb_stage_w_data1_1_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10994,
      ADR1 => CHOICE10999,
      O => write_data1_from_writeback(1)
    );
  wb_stage_w_data0_2_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => write_data0_from_writeback(2),
      O => CHOICE10950
    );
  wb_stage_w_data1_1_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => write_data1_from_writeback(1),
      O => CHOICE10999
    );
  wb_stage_load_p0_SW1 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => exwb_buff_out_D22(5),
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(6),
      O => N6266
    );
  dec_stage_d_instruction_decoder_d2_6_SW1 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N96,
      ADR1 => ifid_buff_out1(1),
      ADR2 => dec_stage_d_instruction_decoder_N88,
      ADR3 => ifid_buff_out2(6),
      O => N772
    );
  dec_stage_d_instruction_decoder_Ker024 : X_LUT4
    generic map(
      INIT => X"020A"
    )
    port map (
      ADR0 => dec_stage_bit_number_dec_to_mux9(2),
      ADR1 => ifid_buff_out1(5),
      ADR2 => dec_stage_d_instruction_decoder_N79,
      ADR3 => ifid_buff_out1(4),
      O => CHOICE11439
    );
  dec_stage_d_instruction_decoder_d2_5_SW1 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N96,
      ADR1 => ifid_buff_out1(1),
      ADR2 => dec_stage_d_instruction_decoder_N88,
      ADR3 => ifid_buff_out2(5),
      O => N769
    );
  wb_stage_w_data0_7_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(7),
      ADR1 => wb_stage_N57,
      O => CHOICE10910
    );
  dec_stage_d_instruction_decoder_d2_6_SW0 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N88,
      ADR1 => ifid_buff_out2(6),
      ADR2 => ifid_buff_out1(6),
      ADR3 => Reset_IBUF,
      O => N771
    );
  cu_Ker211 : X_LUT4
    generic map(
      INIT => X"16BE"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(5),
      ADR3 => ifid_buff_out1(4),
      O => cu_N21
    );
  wb_stage_Ker653_SW0 : X_LUT4
    generic map(
      INIT => X"FF2F"
    )
    port map (
      ADR0 => CHOICE11801,
      ADR1 => exwb_buff_out_D22(0),
      ADR2 => exwb_buff_out_D22(7),
      ADR3 => exwb_buff_out_D22(2),
      O => N6262
    );
  cu_n001618_SW0 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => cu_N0,
      ADR2 => cu_N58,
      ADR3 => N6315,
      O => N6281
    );
  wb_stage_w_data0_6_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10903,
      ADR1 => CHOICE10908,
      O => write_data0_from_writeback(6)
    );
  wb_stage_n019013 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => wb_stage_n0150,
      ADR2 => exwb_buff_out_D22(3),
      ADR3 => wb_stage_N66,
      O => CHOICE10683
    );
  dec_stage_d_instruction_decoder_Ker99_SW1 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(5),
      O => N6264
    );
  wb_stage_w_data0_6_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(6),
      ADR3 => write_data0_from_writeback(6),
      O => CHOICE10908
    );
  dec_stage_d_instruction_decoder_Ker27_SW1 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(3),
      ADR3 => Reset_IBUF,
      O => N6275
    );
  cu_n0330173 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(4),
      ADR2 => cu_N58,
      ADR3 => N6205,
      O => cu_n0330
    );
  cu_n0332158 : X_LUT4
    generic map(
      INIT => X"11F1"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(4),
      O => CHOICE10812
    );
  cu_n033068 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => CHOICE10842,
      ADR2 => CHOICE10849,
      ADR3 => CHOICE10845,
      O => CHOICE10850
    );
  dec_stage_d_mux7_out1_0_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(8),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12236
    );
  wb_stage_w_data1_1_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(1),
      ADR1 => wb_stage_N56,
      O => CHOICE10994
    );
  cu_n033031 : X_LUT4
    generic map(
      INIT => X"1544"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(2),
      ADR3 => ifid_buff_out1(7),
      O => CHOICE10842
    );
  wb_stage_n019043_SW0 : X_LUT4
    generic map(
      INIT => X"FFF7"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => wb_stage_n0184(6),
      ADR2 => exwb_buff_out_D11(2),
      ADR3 => wb_stage_n0164,
      O => N6199
    );
  wb_stage_w_data1_0_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10987,
      ADR1 => CHOICE10992,
      O => write_data1_from_writeback(0)
    );
  wb_stage_w_data0_2_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(2),
      ADR1 => wb_stage_N57,
      O => CHOICE10945
    );
  wb_stage_w_data1_0_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(0),
      ADR3 => write_data1_from_writeback(0),
      O => CHOICE10992
    );
  cu_n0332267 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => cu_N44,
      ADR1 => cu_N12,
      ADR2 => CHOICE10828,
      O => cu_n0332
    );
  cu_n033239 : X_LUT4
    generic map(
      INIT => X"9210"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(7),
      O => CHOICE10779
    );
  wb_stage_w_data0_1_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10938,
      ADR1 => CHOICE10943,
      O => write_data0_from_writeback(1)
    );
  cu_n030254 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => CHOICE11372,
      ADR2 => ifid_buff_out1(2),
      ADR3 => CHOICE10673,
      O => cu_n0302
    );
  wb_stage_Ker111 : X_LUT3
    generic map(
      INIT => X"5D"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => wb_stage_N74,
      ADR2 => wb_stage_n0164,
      O => wb_stage_N111
    );
  wb_stage_w_data0_1_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(1),
      ADR3 => write_data0_from_writeback(1),
      O => CHOICE10943
    );
  wb_stage_w_addr0_1_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(1),
      ADR1 => wb_stage_N57,
      O => CHOICE10875
    );
  dec_stage_d_mux7_out1_0_88 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(0),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(0),
      O => CHOICE12264
    );
  cu_Ker1766 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(1),
      ADR3 => ifid_buff_out1(4),
      O => CHOICE10726
    );
  port3_in_5_IBUF_78 : X_BUF
    port map (
      I => port3_in(5),
      O => port3_in_5_IBUF
    );
  cu_n033065 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      O => CHOICE10849
    );
  wb_stage_w_addr1_1_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10868,
      ADR1 => CHOICE10873,
      O => write_addr1_from_writeback(1)
    );
  cu_n0330146 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => CHOICE10850,
      ADR1 => ifid_buff_out1(4),
      ADR2 => CHOICE10858,
      ADR3 => CHOICE10864,
      O => CHOICE10865
    );
  wb_stage_w_addr1_1_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_D11(1),
      ADR3 => write_addr1_from_writeback(1),
      O => CHOICE10873
    );
  cu_Ker1771 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => CHOICE10726,
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(5),
      O => CHOICE10727
    );
  cu_n0020_1_SW0 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(2),
      ADR2 => cu_N3,
      O => N761
    );
  cu_Ker1777 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10727,
      ADR1 => cu_N45,
      O => CHOICE10728
    );
  wb_stage_w_data1_0_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(0),
      ADR1 => wb_stage_N56,
      O => CHOICE10987
    );
  wb_stage_w_data0_6_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(6),
      ADR1 => wb_stage_N57,
      O => CHOICE10903
    );
  cu_n033269 : X_LUT4
    generic map(
      INIT => X"3010"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(1),
      O => CHOICE10788
    );
  wb_stage_w_data1_4_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10980,
      ADR1 => CHOICE10985,
      O => write_data1_from_writeback(4)
    );
  cu_n0332168 : X_LUT2
    generic map(
      INIT => X"1"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      O => CHOICE10816
    );
  wb_stage_w_data1_4_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => write_data1_from_writeback(4),
      O => CHOICE10985
    );
  wb_stage_w_data0_5_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10896,
      ADR1 => CHOICE10901,
      O => write_data0_from_writeback(5)
    );
  cu_n033037 : X_LUT3
    generic map(
      INIT => X"A2"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(2),
      O => CHOICE10845
    );
  wb_stage_w_data0_5_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(5),
      ADR3 => write_data0_from_writeback(5),
      O => CHOICE10901
    );
  wb_stage_w_data0_1_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(1),
      ADR1 => wb_stage_N57,
      O => CHOICE10938
    );
  wb_stage_n0068_2_34 : X_LUT4
    generic map(
      INIT => X"A2AA"
    )
    port map (
      ADR0 => wb_stage_N26,
      ADR1 => wb_stage_n0184(6),
      ADR2 => wb_stage_N71,
      ADR3 => wb_stage_N80,
      O => CHOICE11042
    );
  rom_Mrom_n0002_inst_mux_f5_1421 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6129
    );
  wb_stage_w_data1_3_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10931,
      ADR1 => CHOICE10936,
      O => write_data1_from_writeback(3)
    );
  cu_n001618_SW0_SW0 : X_LUT4
    generic map(
      INIT => X"AE04"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(0),
      ADR3 => ifid_buff_out1(2),
      O => N6315
    );
  wb_stage_w_data1_3_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(3),
      ADR3 => write_data1_from_writeback(3),
      O => CHOICE10936
    );
  cu_n032832 : X_LUT4
    generic map(
      INIT => X"FF02"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(1),
      ADR2 => cu_n0311,
      ADR3 => cu_N18,
      O => CHOICE10646
    );
  cu_n0333118 : X_LUT4
    generic map(
      INIT => X"AB01"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(1),
      ADR3 => ifid_buff_out1(6),
      O => CHOICE10760
    );
  cu_n0330173_SW0 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => cu_N45,
      ADR1 => cu_N12,
      ADR2 => CHOICE10865,
      O => N6205
    );
  dec_stage_d_mux7_out1_6_29_G : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => mem_R_DPL_data_out(6),
      ADR2 => ifid_buff_out2(1),
      O => N6457
    );
  exe_stage_alu_m_des_ov30 : X_LUT4
    generic map(
      INIT => X"0280"
    )
    port map (
      ADR0 => exe_stage_alu_m_N941,
      ADR1 => exe_stage_alu_m_n0005(3),
      ADR2 => exe_stage_src2(7),
      ADR3 => exe_stage_src1(7),
      O => CHOICE12034
    );
  exe_stage_alu_m_alu_n0055_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(2),
      ADR3 => N78,
      O => exe_stage_alu_m_N41
    );
  cu_n0023_0_11 : X_LUT4
    generic map(
      INIT => X"0A08"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => cu_N65,
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(3),
      O => CHOICE10696
    );
  cu_n033096 : X_LUT4
    generic map(
      INIT => X"888F"
    )
    port map (
      ADR0 => cu_N65,
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      ADR3 => N6207,
      O => CHOICE10858
    );
  dec_stage_d_mux7_out1_7_63 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(7),
      ADR3 => mem_R_B_data_out(7),
      O => CHOICE12223
    );
  wb_stage_w_data1_4_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(4),
      ADR1 => wb_stage_N56,
      O => CHOICE10980
    );
  exe_stage_alu_m_n046488 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(2),
      ADR1 => exe_stage_alu_m_n0224,
      ADR2 => exe_stage_alu_m_n0000(2),
      ADR3 => exe_stage_alu_m_n0222,
      O => CHOICE12652
    );
  cu_n032835 : X_LUT4
    generic map(
      INIT => X"FF02"
    )
    port map (
      ADR0 => CHOICE10639,
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(6),
      ADR3 => CHOICE10646,
      O => cu_n0328
    );
  wb_stage_w_data1_2_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10973,
      ADR1 => CHOICE10978,
      O => write_data1_from_writeback(2)
    );
  cu_n033096_SW0 : X_LUT3
    generic map(
      INIT => X"D5"
    )
    port map (
      ADR0 => cu_N62,
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(0),
      O => N6207
    );
  wb_stage_w_data1_2_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N29,
      ADR1 => wb_stage_N111,
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => write_data1_from_writeback(2),
      O => CHOICE10978
    );
  cu_n0333155_SW0 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE10613,
      ADR1 => ifid_buff_out1(7),
      ADR2 => Reset_IBUF,
      ADR3 => N6317,
      O => N6201
    );
  cu_Ker12_SW1 : X_LUT4
    generic map(
      INIT => X"1544"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(5),
      O => N147
    );
  wb_stage_w_addr1_1_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(1),
      ADR1 => wb_stage_N56,
      O => CHOICE10868
    );
  exe_stage_alu_m_n00211 : X_LUT4
    generic map(
      INIT => X"F808"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(4),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(5),
      O => exe_stage_alu_m_n0293(6)
    );
  wb_stage_w_data0_5_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(5),
      ADR1 => wb_stage_N57,
      O => CHOICE10896
    );
  mem_PSW_n00081_G : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(2),
      ADR2 => exwb_buff_out_R_A(2),
      ADR3 => wb_stage_n0183(7),
      O => N6459
    );
  dec_stage_d_mux7_out1_7_29_G : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => mem_R_DPL_data_out(7),
      ADR2 => ifid_buff_out2(1),
      O => N6461
    );
  wb_stage_w_data1_3_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(3),
      ADR1 => wb_stage_N56,
      O => CHOICE10931
    );
  cu_n0023_0_24 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => cu_N71,
      ADR1 => cu_N59,
      ADR2 => ifid_buff_out1(0),
      ADR3 => cu_N21,
      O => CHOICE10700
    );
  cu_n032912 : X_LUT4
    generic map(
      INIT => X"0301"
    )
    port map (
      ADR0 => cu_N46,
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(3),
      ADR3 => cu_N59,
      O => CHOICE10654
    );
  wb_stage_w_data0_4_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10889,
      ADR1 => CHOICE10894,
      O => write_data0_from_writeback(4)
    );
  cu_n0023_0_25 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => cu_n0303,
      ADR1 => CHOICE10700,
      O => CHOICE10701
    );
  dec_stage_d_mux7_Ker0_SW0 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => ifid_buff_out2(4),
      ADR1 => ifid_buff_out2(5),
      O => N923
    );
  wb_stage_w_data0_0_14 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => CHOICE10924,
      ADR1 => CHOICE10929,
      O => write_data0_from_writeback(0)
    );
  wb_stage_w_data0_4_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(4),
      ADR3 => write_data0_from_writeback(4),
      O => CHOICE10894
    );
  wb_stage_w_data0_0_13 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N28,
      ADR1 => wb_stage_N9,
      ADR2 => exwb_buff_out_R_A(0),
      ADR3 => write_data0_from_writeback(0),
      O => CHOICE10929
    );
  fet_stage_source_PC_8_SW0 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_jcall(1),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out2(0),
      O => N910
    );
  wb_stage_w_data1_2_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_R_B(2),
      ADR1 => wb_stage_N56,
      O => CHOICE10973
    );
  exe_stage_alu_m_alu_n0216_2_lut : X_LUT3
    generic map(
      INIT => X"1B"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N66,
      ADR2 => exwb_buff_out_R_A(2),
      O => exe_stage_alu_m_N86
    );
  wb_stage_w_addr0_2_45 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11551,
      ADR1 => CHOICE11557,
      ADR2 => CHOICE11562,
      O => write_addr0_from_writeback(2)
    );
  dec_stage_d_instruction_decoder_d2_3_24_G : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => mem_PSW_psw(3),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(6),
      O => N6463
    );
  wb_stage_n0069_0_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11126,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11120,
      O => wb_stage_n0069(0)
    );
  dec_stage_d_instruction_decoder_s2_2_SW0 : X_LUT4
    generic map(
      INIT => X"135F"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => dec_stage_d_instruction_decoder_N87,
      ADR2 => dec_stage_d_instruction_decoder_N97,
      ADR3 => dec_stage_reg_indirect_to_mux6(2),
      O => N2485
    );
  exe_stage_alu_m_n046426 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => exe_stage_src1(2),
      ADR1 => exe_stage_alu_m_n0230,
      ADR2 => exe_stage_src1(6),
      ADR3 => exe_stage_alu_m_n0239,
      O => CHOICE12636
    );
  exe_stage_alu_m_n046472 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_N01,
      ADR2 => exe_stage_src1(2),
      ADR3 => exe_stage_alu_m_N711,
      O => CHOICE12648
    );
  exe_stage_alu_m_des_ov118 : X_LUT4
    generic map(
      INIT => X"FF28"
    )
    port map (
      ADR0 => exe_stage_alu_m_N951,
      ADR1 => exe_stage_alu_m_n0002(1),
      ADR2 => exe_stage_alu_m_n0001(3),
      ADR3 => CHOICE12059,
      O => CHOICE12060
    );
  wb_stage_w_addr0_2_31 : X_LUT4
    generic map(
      INIT => X"AFA8"
    )
    port map (
      ADR0 => write_addr0_from_writeback(2),
      ADR1 => wb_stage_N35,
      ADR2 => exwb_buff_out_D11(0),
      ADR3 => exwb_buff_out_D11(2),
      O => CHOICE11562
    );
  dec_stage_d_instruction_decoder_d2_5_SW0 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N88,
      ADR1 => ifid_buff_out2(5),
      ADR2 => ifid_buff_out1(6),
      ADR3 => Reset_IBUF,
      O => N768
    );
  dec_stage_d_instruction_decoder_d1_1_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(1),
      ADR2 => dec_stage_d_instruction_decoder_n0199,
      ADR3 => ifid_buff_out1(1),
      O => CHOICE11337
    );
  rom_Mrom_n0002_inst_mux_f5_1431 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6121
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_102 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => CHOICE11413,
      ADR2 => ifid_buff_out1(5),
      ADR3 => CHOICE11409,
      O => CHOICE11417
    );
  dec_stage_d_instruction_decoder_alu_oprt_2_98 : X_LUT4
    generic map(
      INIT => X"0B01"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => N6171,
      ADR2 => Reset_IBUF,
      ADR3 => CHOICE11195,
      O => alu_op_from_decode(2)
    );
  wb_stage_n0069_2_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out22,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(2),
      ADR3 => wb_stage_N72,
      O => CHOICE11130
    );
  dec_stage_d_instruction_decoder_Ker2311 : X_LUT3
    generic map(
      INIT => X"91"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(4),
      ADR2 => ifid_buff_out1(7),
      O => CHOICE11512
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_291 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => mem_w_addr_b1(5),
      ADR1 => mem_w_addr_b1(7),
      ADR2 => mem_w_addr_b1(6),
      ADR3 => mem_w_addr_b1(0),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_29
    );
  dec_stage_d_instruction_decoder_n019712 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => CHOICE10780,
      ADR1 => ifid_buff_out1(6),
      ADR2 => dec_stage_d_instruction_decoder_N77,
      ADR3 => dec_stage_d_instruction_decoder_N50,
      O => CHOICE11285
    );
  dec_stage_d_instruction_decoder_d1_0_25_SW0 : X_LUT4
    generic map(
      INIT => X"0103"
    )
    port map (
      ADR0 => dec_stage_reg_indirect_to_mux6(0),
      ADR1 => CHOICE11384,
      ADR2 => CHOICE11347,
      ADR3 => dec_stage_d_instruction_decoder_n0200,
      O => N6169
    );
  wb_stage_Ker261 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => exwb_buff_out_D11(7),
      ADR1 => exwb_buff_out_D11(2),
      ADR2 => exwb_buff_out_D11(3),
      ADR3 => wb_stage_n0164,
      O => wb_stage_N26
    );
  wb_stage_n0069_7_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(7),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out16,
      O => CHOICE11166
    );
  dec_stage_d_instruction_decoder_d2_0_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => ifid_buff_out2(0),
      ADR1 => dec_stage_d_instruction_decoder_N88,
      ADR2 => dec_stage_reg_indirect_to_mux6(0),
      ADR3 => ifid_buff_out1(1),
      O => CHOICE11473
    );
  dec_stage_d_instruction_decoder_d1_3_14 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11230,
      ADR1 => dec_stage_d_instruction_decoder_n0200,
      ADR2 => dec_stage_reg_indirect_to_mux6(3),
      ADR3 => CHOICE11233,
      O => CHOICE11236
    );
  dec_stage_d_instruction_decoder_alu_oprt_3_16_SW0 : X_LUT4
    generic map(
      INIT => X"BDBF"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(7),
      O => N6187
    );
  exe_stage_alu_m_n0454141_G : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N70,
      ADR3 => exwb_buff_out_R_A(4),
      O => N6465
    );
  wb_stage_w_addr0_2_18 : X_LUT4
    generic map(
      INIT => X"FF8F"
    )
    port map (
      ADR0 => wb_stage_n0150,
      ADR1 => CHOICE11553,
      ADR2 => wb_stage_n0184(6),
      ADR3 => exwb_buff_out_D22(0),
      O => CHOICE11557
    );
  dec_stage_d_mux9_out1_2_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(2),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(2),
      O => CHOICE12348
    );
  wb_stage_n0069_3_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out20,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(3),
      ADR3 => wb_stage_N72,
      O => CHOICE11090
    );
  wb_stage_n0069_7_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11166,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11160,
      O => wb_stage_n0069(7)
    );
  dec_stage_d_mux7_out1_4_106 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12157,
      ADR2 => CHOICE12152,
      ADR3 => CHOICE12163,
      O => CHOICE12166
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_87_SW1 : X_LUT4
    generic map(
      INIT => X"FFF7"
    )
    port map (
      ADR0 => ifid_buff_out1(1),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(7),
      O => N6258
    );
  dec_stage_d_instruction_decoder_d1_5_10 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11312,
      ADR1 => dec_stage_d_instruction_decoder_n0198,
      ADR2 => ifid_buff_out2(5),
      ADR3 => dec_stage_d_instruction_decoder_n0197,
      O => CHOICE11315
    );
  dec_stage_d_instruction_decoder_alu_oprt_2_12 : X_LUT4
    generic map(
      INIT => X"AE04"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => dec_stage_d_instruction_decoder_N48,
      ADR2 => ifid_buff_out1(4),
      ADR3 => dec_stage_d_instruction_decoder_N39,
      O => CHOICE11195
    );
  dec_stage_d_instruction_decoder_d1_7_5_SW0 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0200,
      ADR1 => ifid_buff_out1(0),
      ADR2 => r0_from_mem(7),
      ADR3 => r1_from_mem(7),
      O => N6217
    );
  dec_stage_d_mux9_out1_0_15 : X_LUT3
    generic map(
      INIT => X"A2"
    )
    port map (
      ADR0 => cu_sel_mux9(1),
      ADR1 => cu_sel_mux9(2),
      ADR2 => pc_out_from_mem(8),
      O => CHOICE12418
    );
  dec_stage_d_instruction_decoder_Ker2374 : X_LUT4
    generic map(
      INIT => X"0A08"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N77,
      ADR1 => ifid_buff_out1(3),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(2),
      O => CHOICE11525
    );
  dec_stage_d_instruction_decoder_d1_3_21 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11236,
      ADR1 => Reset_IBUF,
      O => d1_from_decode(3)
    );
  fet_stage_que_state_M_next_Mcode_2_61_SW0 : X_LUT3
    generic map(
      INIT => X"DF"
    )
    port map (
      ADR0 => rom_DATA_BUS(1),
      ADR1 => rom_DATA_BUS(2),
      ADR2 => cu_sel_rd,
      O => N6303
    );
  fet_stage_que_state_M_inst_que_code_3_340_SW0 : X_LUT2
    generic map(
      INIT => X"1"
    )
    port map (
      ADR0 => fet_stage_que_state_M_state_FFd2,
      ADR1 => fet_stage_que_state_M_state_FFd1,
      O => N6287
    );
  wb_stage_w_addr0_2_8 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => exwb_buff_out_D22(7),
      ADR1 => exwb_buff_out_D22(3),
      O => CHOICE11553
    );
  dec_stage_d_instruction_decoder_Ker2385 : X_LUT4
    generic map(
      INIT => X"0090"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(7),
      ADR2 => dec_stage_d_instruction_decoder_N104,
      ADR3 => ifid_buff_out1(0),
      O => CHOICE11530
    );
  dec_stage_d_instruction_decoder_d2_2_24_SW0 : X_LUT3
    generic map(
      INIT => X"DF"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => Reset_IBUF,
      ADR2 => ifid_buff_out1(6),
      O => N6271
    );
  wb_stage_n0068_0_67 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => wb_stage_addr_rid(0),
      ADR1 => wb_stage_N38,
      ADR2 => wb_stage_N74,
      ADR3 => wb_stage_n0164,
      O => CHOICE11085
    );
  wb_stage_n0069_2_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(2),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out22,
      O => CHOICE11136
    );
  fet_stage_que_state_M_inst_que_code_3_69 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => rom_DATA_BUS(2),
      ADR1 => cu_sel_rd,
      ADR2 => N6183,
      ADR3 => CHOICE11741,
      O => CHOICE11742
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_48 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => CHOICE11364,
      ADR2 => ifid_buff_out1(4),
      ADR3 => CHOICE11359,
      O => CHOICE11368
    );
  exe_stage_alu_m_n022625 : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_src2(5),
      ADR2 => exe_stage_src2(6),
      ADR3 => exe_stage_src2(7),
      O => CHOICE11823
    );
  wb_stage_w_addr0_2_5 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => exwb_buff_out_D22(2),
      ADR2 => exwb_buff_out_D22(0),
      O => CHOICE11551
    );
  dec_stage_d_instruction_decoder_d1_5_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(5),
      ADR2 => dec_stage_d_instruction_decoder_n0200,
      ADR3 => dec_stage_reg_indirect_to_mux6(5),
      O => CHOICE11312
    );
  wb_stage_n0069_2_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11136,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11130,
      O => wb_stage_n0069(2)
    );
  wb_stage_w_addr1_2_44 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11492,
      ADR1 => CHOICE11499,
      ADR2 => CHOICE11504,
      O => write_addr1_from_writeback(2)
    );
  exe_stage_alu_m_n043917 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0243,
      ADR1 => exe_stage_src2(3),
      ADR2 => exe_stage_alu_m_n0008(11),
      ADR3 => exe_stage_alu_m_n0224,
      O => CHOICE12804
    );
  wb_stage_n0068_2_43 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => wb_stage_N72,
      ADR2 => wb_stage_n0184(6),
      ADR3 => CHOICE11044,
      O => CHOICE11045
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_81 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => dec_stage_d_instruction_decoder_N24,
      ADR2 => dec_stage_d_instruction_decoder_N90,
      ADR3 => ifid_buff_out1(2),
      O => CHOICE11413
    );
  wb_stage_n0069_3_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(3),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out20,
      O => CHOICE11096
    );
  wb_stage_n0068_2_50 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11045,
      ADR1 => wb_stage_addr_rid(2),
      ADR2 => CHOICE11036,
      O => wb_stage_n0068(2)
    );
  dec_stage_d_instruction_decoder_d1_4_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0198,
      ADR1 => ifid_buff_out2(4),
      O => CHOICE11239
    );
  port2_in_3_IBUF_79 : X_BUF
    port map (
      I => port2_in(3),
      O => port2_in_3_IBUF
    );
  wb_stage_w_addr0_3_26 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11540,
      ADR1 => CHOICE11541,
      ADR2 => CHOICE11546,
      O => write_addr0_from_writeback(3)
    );
  wb_stage_n0069_3_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11096,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11090,
      O => wb_stage_n0069(3)
    );
  dec_stage_d_instruction_decoder_d2_7_11 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N27,
      ADR1 => CHOICE11219,
      O => d2_from_decode(7)
    );
  dec_stage_d_mux9_out1_1_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(1),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(1),
      O => CHOICE12373
    );
  wb_stage_w_addr1_2_30 : X_LUT4
    generic map(
      INIT => X"EAE2"
    )
    port map (
      ADR0 => write_addr1_from_writeback(2),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => exwb_buff_out_D11(2),
      ADR3 => wb_stage_N35,
      O => CHOICE11504
    );
  dec_stage_d_mux7_out1_3_50 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(3),
      ADR3 => mem_R_A_data_out(3),
      O => CHOICE12086
    );
  wb_stage_n0069_5_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out18,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(5),
      ADR3 => wb_stage_N72,
      O => CHOICE11140
    );
  wb_stage_w_addr0_3_17 : X_LUT4
    generic map(
      INIT => X"AFA8"
    )
    port map (
      ADR0 => write_addr0_from_writeback(3),
      ADR1 => wb_stage_N36,
      ADR2 => exwb_buff_out_D11(0),
      ADR3 => exwb_buff_out_D11(3),
      O => CHOICE11546
    );
  dec_stage_d_instruction_decoder_Ker981 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(6),
      O => dec_stage_d_instruction_decoder_N98
    );
  dec_stage_d_instruction_decoder_d1_2_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0198,
      ADR1 => ifid_buff_out2(2),
      O => CHOICE11221
    );
  wb_stage_n0069_4_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out19,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(4),
      ADR3 => wb_stage_N72,
      O => CHOICE11100
    );
  dec_stage_d_instruction_decoder_d2_2_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => ifid_buff_out2(2),
      ADR1 => dec_stage_d_instruction_decoder_N88,
      ADR2 => dec_stage_reg_indirect_to_mux6(2),
      ADR3 => ifid_buff_out1(1),
      O => CHOICE11464
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_102 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(5),
      O => CHOICE11379
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_8 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => CHOICE11358,
      O => CHOICE11359
    );
  dec_stage_d_instruction_decoder_alu_oprt_3_16 : X_LUT3
    generic map(
      INIT => X"02"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N90,
      ADR1 => ifid_buff_out1(5),
      ADR2 => N6187,
      O => CHOICE11175
    );
  dec_stage_d_instruction_decoder_d1_6_10 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11320,
      ADR1 => dec_stage_d_instruction_decoder_n0198,
      ADR2 => ifid_buff_out2(6),
      ADR3 => dec_stage_d_instruction_decoder_n0197,
      O => CHOICE11323
    );
  exe_stage_alu_m_n045971 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(1),
      ADR1 => exe_stage_alu_m_N871,
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => N6179,
      O => CHOICE12686
    );
  dec_stage_d_instruction_decoder_alu_oprt_2_35_SW0 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => ifid_buff_out1(3),
      O => N6255
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_7 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(0),
      ADR3 => ifid_buff_out1(5),
      O => CHOICE11358
    );
  dec_stage_d_instruction_decoder_d1_5_16 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11315,
      ADR1 => Reset_IBUF,
      O => d1_from_decode(5)
    );
  dec_stage_d_instruction_decoder_d1_4_5 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(4),
      ADR2 => dec_stage_d_instruction_decoder_n0199,
      ADR3 => mem_PSW_psw(4),
      O => CHOICE11242
    );
  exe_stage_alu_m_n048958 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0230,
      ADR1 => exe_stage_src1(5),
      ADR2 => exe_stage_alu_m_N01,
      ADR3 => exe_stage_src2(5),
      O => CHOICE11896
    );
  dec_stage_d_instruction_decoder_Ker010 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(2),
      ADR2 => cu_N21,
      ADR3 => ifid_buff_out1(1),
      O => CHOICE11432
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_24 : X_LUT4
    generic map(
      INIT => X"8808"
    )
    port map (
      ADR0 => ifid_buff_out1(3),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(6),
      ADR3 => ifid_buff_out1(7),
      O => CHOICE11397
    );
  wb_stage_w_addr0_3_6 : X_LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      ADR0 => wb_stage_N32,
      ADR1 => exwb_buff_out_D22(0),
      O => CHOICE11541
    );
  dec_stage_d_instruction_decoder_d1_1_25_SW0 : X_LUT4
    generic map(
      INIT => X"0103"
    )
    port map (
      ADR0 => dec_stage_reg_indirect_to_mux6(1),
      ADR1 => CHOICE11384,
      ADR2 => CHOICE11337,
      ADR3 => dec_stage_d_instruction_decoder_n0200,
      O => N6167
    );
  wb_stage_w_addr0_3_5 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => exwb_buff_out_D22(3),
      ADR2 => exwb_buff_out_D22(0),
      O => CHOICE11540
    );
  wb_stage_w_addr1_2_16 : X_LUT4
    generic map(
      INIT => X"D5FF"
    )
    port map (
      ADR0 => exwb_buff_out_D22(0),
      ADR1 => CHOICE11553,
      ADR2 => wb_stage_n0150,
      ADR3 => wb_stage_n0184(6),
      O => CHOICE11499
    );
  dec_stage_d_instruction_decoder_alu_oprt_3_27 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N24,
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(4),
      O => CHOICE11178
    );
  dec_stage_d_instruction_decoder_d1_2_5 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(2),
      ADR2 => dec_stage_d_instruction_decoder_n0199,
      ADR3 => ifid_buff_out1(2),
      O => CHOICE11224
    );
  dec_stage_d_mux9_out1_3_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(11),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12392
    );
  dec_stage_d_instruction_decoder_d2_4_24_G : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => mem_PSW_psw(4),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(6),
      O => N6467
    );
  dec_stage_d_instruction_decoder_d1_6_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(6),
      ADR2 => dec_stage_d_instruction_decoder_n0200,
      ADR3 => dec_stage_reg_indirect_to_mux6(6),
      O => CHOICE11320
    );
  dec_stage_d_instruction_decoder_Ker101_G : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(5),
      O => N6469
    );
  wb_stage_n0069_5_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(5),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out18,
      O => CHOICE11146
    );
  dec_stage_d_instruction_decoder_Ker23130 : X_LUT3
    generic map(
      INIT => X"32"
    )
    port map (
      ADR0 => CHOICE11534,
      ADR1 => Reset_IBUF,
      ADR2 => CHOICE11522,
      O => dec_stage_d_instruction_decoder_N23
    );
  wb_stage_n0069_4_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(4),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out19,
      O => CHOICE11106
    );
  exwb_buff_out_D22_6_1_80 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(6),
      RST => exwb_buff_out_D22_6_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22_6_1,
      CE => VCC,
      SET => GND
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_87 : X_LUT4
    generic map(
      INIT => X"0426"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(2),
      ADR2 => N6257,
      ADR3 => N6258,
      O => CHOICE11275
    );
  wb_stage_Ker627 : X_LUT4
    generic map(
      INIT => X"01AF"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => exwb_buff_out_D22(5),
      ADR2 => exwb_buff_out_D22(6),
      ADR3 => exwb_buff_out_D22(1),
      O => CHOICE11801
    );
  wb_stage_n0069_4_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11106,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11100,
      O => wb_stage_n0069(4)
    );
  dec_stage_d_mux7_out1_6_50 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(6),
      ADR3 => mem_R_A_data_out(6),
      O => CHOICE12185
    );
  wb_stage_n0069_5_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11146,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11140,
      O => wb_stage_n0069(5)
    );
  wb_stage_n0068_2_36 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => CHOICE11042,
      ADR1 => exwb_buff_out_D11(4),
      ADR2 => wb_stage_N67,
      O => CHOICE11044
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_87_SW0 : X_LUT4
    generic map(
      INIT => X"FFF7"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(1),
      ADR3 => ifid_buff_out1(4),
      O => N6257
    );
  wb_stage_W_psw1 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => wb_stage_N78,
      ADR1 => wb_stage_n0184(6),
      ADR2 => exwb_buff_out_D22(5),
      ADR3 => wb_stage_n0183(7),
      O => W_psw_from_writeback
    );
  exe_stage_alu_m_n044224_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(12),
      ADR1 => exe_stage_alu_m_N871,
      ADR2 => idex_buff_out_Opcode(2),
      O => N6243
    );
  dec_stage_d_instruction_decoder_d1_7_20 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11332,
      ADR1 => Reset_IBUF,
      O => d1_from_decode(7)
    );
  dec_stage_d_instruction_decoder_Ker23104 : X_LUT4
    generic map(
      INIT => X"FF32"
    )
    port map (
      ADR0 => CHOICE11530,
      ADR1 => ifid_buff_out1(3),
      ADR2 => dec_stage_d_instruction_decoder_N101,
      ADR3 => CHOICE11525,
      O => CHOICE11534
    );
  wb_stage_n0068_1_43 : X_LUT4
    generic map(
      INIT => X"FF80"
    )
    port map (
      ADR0 => exwb_buff_out_D11(3),
      ADR1 => wb_stage_N67,
      ADR2 => CHOICE11042,
      ADR3 => N6313,
      O => CHOICE11063
    );
  dec_stage_d_instruction_decoder_d1_0_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0144,
      ADR1 => ifid_buff_out3(0),
      ADR2 => dec_stage_d_instruction_decoder_n0199,
      ADR3 => ifid_buff_out1(0),
      O => CHOICE11347
    );
  exe_stage_alu_m_n045428 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12718,
      ADR1 => exe_stage_alu_m_N65,
      ADR2 => exe_stage_alu_m_n0222,
      ADR3 => CHOICE12722,
      O => CHOICE12725
    );
  wb_stage_n0068_1_50 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11063,
      ADR1 => wb_stage_addr_rid(1),
      ADR2 => CHOICE11036,
      O => wb_stage_n0068(1)
    );
  wb_stage_n0069_6_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out17,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(6),
      ADR3 => wb_stage_N72,
      O => CHOICE11110
    );
  dec_stage_d_instruction_decoder_Ker00 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => dec_stage_d_instruction_decoder_N93,
      O => CHOICE11428
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_144 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11386,
      ADR1 => Reset_IBUF,
      O => alu_op_from_decode(4)
    );
  wb_stage_n0069_1_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => wb_stage_MUX_BLOCK_n0179_3_mmx_out23,
      ADR1 => wb_stage_N01,
      ADR2 => exwb_buff_out_R_B(1),
      ADR3 => wb_stage_N72,
      O => CHOICE11150
    );
  dec_stage_d_instruction_decoder_d2_3_4 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => ifid_buff_out2(3),
      ADR1 => dec_stage_d_instruction_decoder_N88,
      ADR2 => dec_stage_reg_indirect_to_mux6(3),
      ADR3 => ifid_buff_out1(1),
      O => CHOICE11455
    );
  wb_stage_w_addr1_2_2 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => exwb_buff_out_D22(0),
      ADR2 => exwb_buff_out_D22(2),
      O => CHOICE11492
    );
  wb_stage_w_addr1_4_11 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11422,
      ADR1 => wb_stage_N29,
      ADR2 => CHOICE11425,
      O => write_addr1_from_writeback(4)
    );
  dec_stage_d_instruction_decoder_d1_2_14 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11221,
      ADR1 => dec_stage_d_instruction_decoder_n0200,
      ADR2 => dec_stage_reg_indirect_to_mux6(2),
      ADR3 => CHOICE11224,
      O => CHOICE11227
    );
  dec_stage_d_instruction_decoder_d1_4_14 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11239,
      ADR1 => dec_stage_d_instruction_decoder_n0200,
      ADR2 => dec_stage_reg_indirect_to_mux6(4),
      ADR3 => CHOICE11242,
      O => CHOICE11245
    );
  dec_stage_d_instruction_decoder_alu_oprt_3_39 : X_LUT4
    generic map(
      INIT => X"2232"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N89,
      ADR1 => ifid_buff_out1(6),
      ADR2 => CHOICE10780,
      ADR3 => cu_N39,
      O => CHOICE11183
    );
  wb_stage_w_addr1_3_27 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11481,
      ADR1 => CHOICE11483,
      ADR2 => CHOICE11488,
      O => write_addr1_from_writeback(3)
    );
  wb_stage_n0068_0_7 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => wb_stage_N67,
      ADR1 => wb_stage_addr_rid(0),
      ADR2 => exwb_buff_out_D11(0),
      O => CHOICE11068
    );
  dec_stage_d_instruction_decoder_n019732 : X_LUT3
    generic map(
      INIT => X"F2"
    )
    port map (
      ADR0 => CHOICE11289,
      ADR1 => ifid_buff_out1(3),
      ADR2 => CHOICE11285,
      O => dec_stage_d_instruction_decoder_n0197
    );
  dec_stage_d_instruction_decoder_d1_7_5 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11384,
      ADR1 => dec_stage_d_instruction_decoder_n0144,
      ADR2 => ifid_buff_out3(7),
      ADR3 => N6217,
      O => CHOICE11329
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_98 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11275,
      ADR1 => ifid_buff_out1(3),
      O => CHOICE11277
    );
  exe_stage_alu_m_Ker51 : X_LUT4
    generic map(
      INIT => X"FF02"
    )
    port map (
      ADR0 => exe_stage_alu_m_N961,
      ADR1 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR2 => exe_stage_alu_m_n0227,
      ADR3 => exe_stage_alu_m_n0241,
      O => exe_stage_alu_m_N5
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_50 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE11400,
      ADR1 => ifid_buff_out1(4),
      ADR2 => CHOICE11394,
      ADR3 => ifid_buff_out1(2),
      O => CHOICE11403
    );
  wb_stage_w_addr1_4_5 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => exwb_buff_out_D11(4),
      ADR2 => write_addr1_from_writeback(4),
      ADR3 => wb_stage_N22,
      O => CHOICE11425
    );
  dec_stage_d_mux7_out1_6_106 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12190,
      ADR2 => CHOICE12185,
      ADR3 => CHOICE12196,
      O => CHOICE12199
    );
  wb_stage_w_addr1_3_17 : X_LUT4
    generic map(
      INIT => X"EAE2"
    )
    port map (
      ADR0 => write_addr1_from_writeback(3),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => exwb_buff_out_D11(3),
      ADR3 => wb_stage_N36,
      O => CHOICE11488
    );
  dec_stage_d_instruction_decoder_d1_2_21 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11227,
      ADR1 => Reset_IBUF,
      O => d1_from_decode(2)
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_132 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => CHOICE11368,
      ADR2 => CHOICE11385,
      ADR3 => CHOICE11372,
      O => CHOICE11386
    );
  dec_stage_d_instruction_decoder_alu_oprt_4_23 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(1),
      ADR3 => ifid_buff_out1(0),
      O => CHOICE11364
    );
  wb_stage_n0069_6_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(6),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out17,
      O => CHOICE11116
    );
  dec_stage_d_instruction_decoder_d1_3_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_n0198,
      ADR1 => ifid_buff_out2(3),
      O => CHOICE11230
    );
  cu_n030232_SW0 : X_LUT4
    generic map(
      INIT => X"0064"
    )
    port map (
      ADR0 => ifid_buff_out1(7),
      ADR1 => cu_N27,
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(3),
      O => N6193
    );
  wb_stage_n0069_6_23 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11116,
      ADR1 => wb_stage_n0184(6),
      ADR2 => CHOICE11110,
      O => wb_stage_n0069(6)
    );
  dec_stage_d_instruction_decoder_d1_4_21 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11245,
      ADR1 => Reset_IBUF,
      O => d1_from_decode(4)
    );
  dec_stage_d_instruction_decoder_d1_0_25 : X_LUT4
    generic map(
      INIT => X"5111"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N6169,
      ADR2 => dec_stage_d_instruction_decoder_n0198,
      ADR3 => ifid_buff_out2(0),
      O => d1_from_decode(0)
    );
  wb_stage_w_addr1_4_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => wb_stage_N56,
      O => CHOICE11422
    );
  dec_stage_d_instruction_decoder_d1_6_16 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11323,
      ADR1 => Reset_IBUF,
      O => d1_from_decode(6)
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_30 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N48,
      ADR1 => ifid_buff_out1(7),
      ADR2 => ifid_buff_out1(6),
      ADR3 => CHOICE11397,
      O => CHOICE11400
    );
  wb_stage_n0069_1_21 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => wb_stage_N38,
      ADR1 => wb_stage_N26,
      ADR2 => wb_stage_din_rid(1),
      ADR3 => wb_stage_MUX_BLOCK_n0179_3_mmx_out23,
      O => CHOICE11156
    );
  dec_stage_d_instruction_decoder_d2_0_24_G : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => ifid_buff_out1(0),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(6),
      O => N6471
    );
  dec_stage_d_instruction_decoder_alu_oprt_0_142 : X_LUT3
    generic map(
      INIT => X"32"
    )
    port map (
      ADR0 => CHOICE11418,
      ADR1 => Reset_IBUF,
      ADR2 => CHOICE11403,
      O => alu_op_from_decode(0)
    );
  exe_stage_alu_m_n04762 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(2),
      ADR1 => exe_stage_alu_m_alu_n0000_3_cyo,
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => exe_stage_alu_m_N841,
      O => CHOICE12544
    );
  mem_PSW_n0007_SW0 : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => wb_stage_N10,
      ADR1 => exwb_buff_out_R_B(0),
      ADR2 => wb_stage_n0183(7),
      ADR3 => exwb_buff_out_R_A(0),
      O => N2788
    );
  wb_stage_Ker5_SW0 : X_LUT4
    generic map(
      INIT => X"FFFD"
    )
    port map (
      ADR0 => exwb_buff_out_D22(1),
      ADR1 => exwb_buff_out_D22(4),
      ADR2 => exwb_buff_out_D22(6),
      ADR3 => exwb_buff_out_D22(5),
      O => N2790
    );
  exe_stage_alu_m_des_ov64 : X_LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(12),
      ADR1 => exe_stage_alu_m_n0008(8),
      ADR2 => exe_stage_alu_m_n0008(9),
      O => CHOICE12049
    );
  exe_stage_alu_m_n047624 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0233,
      ADR2 => exe_stage_alu_m_n0262,
      O => CHOICE12554
    );
  exe_stage_alu_m_n034763_SW0 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_src1(5),
      ADR1 => exe_stage_alu_m_n0260,
      ADR2 => exe_stage_src1(2),
      ADR3 => exe_stage_alu_m_n0239,
      O => N6163
    );
  fet_stage_que_state_M_inst_que_code_3_218_SW1 : X_LUT3
    generic map(
      INIT => X"F1"
    )
    port map (
      ADR0 => rom_DATA_BUS(4),
      ADR1 => rom_DATA_BUS(1),
      ADR2 => rom_DATA_BUS(2),
      O => N6301
    );
  exe_stage_alu_m_n044916 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_n0243,
      ADR2 => exe_stage_alu_m_n0244,
      O => CHOICE12860
    );
  rom_Mrom_n0002_inst_mux_f5_1341 : X_LUT4
    generic map(
      INIT => X"B6DB"
    )
    port map (
      ADR0 => addressbus_from_fetch(1),
      ADR1 => addressbus_from_fetch(2),
      ADR2 => addressbus_from_fetch(3),
      ADR3 => addressbus_from_fetch(0),
      O => N6130
    );
  exe_stage_alu_m_alu_n0073_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(0),
      ADR3 => N78,
      O => exe_stage_alu_m_N57
    );
  exe_stage_alu_m_n045971_SW0 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12672,
      ADR1 => CHOICE12682,
      ADR2 => exe_stage_src1(1),
      ADR3 => CHOICE12676,
      O => N6179
    );
  exe_stage_alu_m_n0454161 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => exe_stage_alu_m_N851,
      ADR1 => CHOICE12755,
      ADR2 => exe_stage_alu_m_N107,
      ADR3 => exe_stage_alu_m_N911,
      O => CHOICE12757
    );
  wb_stage_w_addr1_5_5 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => exwb_buff_out_D11(5),
      ADR2 => write_addr1_from_writeback(5),
      ADR3 => wb_stage_N25,
      O => CHOICE11578
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut3_2301 : X_LUT4
    generic map(
      INIT => X"EA2A"
    )
    port map (
      ADR0 => mem_internal_ram_bank_Mram_iram1_net517,
      ADR1 => cu_sel_mux12(1),
      ADR2 => r_addr0_from_decode(5),
      ADR3 => mem_internal_ram_bank_Mram_iram1_net519,
      O => mem_internal_ram_bank_Mram_iram1_inst_lut3_230
    );
  exe_stage_alu_m_n048974 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_N861,
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => exe_stage_alu_m_n0262,
      O => CHOICE11904
    );
  wb_stage_w_addr1_6_14 : X_LUT4
    generic map(
      INIT => X"22A2"
    )
    port map (
      ADR0 => write_addr1_from_writeback(6),
      ADR1 => exwb_buff_out_D11(0),
      ADR2 => wb_stage_N70,
      ADR3 => exwb_buff_out_D11(4),
      O => CHOICE11714
    );
  exe_stage_alu_m_n045931 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => exe_stage_src1(1),
      ADR1 => exe_stage_alu_m_n0230,
      ADR2 => exe_stage_src1(5),
      ADR3 => exe_stage_alu_m_n0239,
      O => CHOICE12676
    );
  exe_stage_alu_m_n0364103 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11963,
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_N821,
      O => CHOICE11965
    );
  fet_stage_que_state_M_inst_que_code_3_218 : X_LUT4
    generic map(
      INIT => X"555D"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => N6301,
      ADR2 => rom_DATA_BUS(5),
      ADR3 => rom_DATA_BUS(0),
      O => CHOICE11775
    );
  dec_stage_d_mux9_out1_1_12 : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => pc_out_from_mem(9),
      ADR1 => cu_sel_mux9(1),
      ADR2 => cu_sel_mux9(2),
      O => CHOICE12367
    );
  exe_stage_alu_m_n046453 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12632,
      ADR1 => exe_stage_src1(2),
      ADR2 => CHOICE12642,
      ADR3 => CHOICE12636,
      O => CHOICE12644
    );
  exe_stage_alu_m_des_cy170 : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE11995,
      ADR1 => idex_buff_out_Opcode(0),
      ADR2 => CHOICE12020,
      O => CHOICE12022
    );
  dec_stage_d_mux7_out1_6_78 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(6),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(6),
      O => CHOICE12196
    );
  fet_stage_que_state_M_state_FFd2_In160 : X_LUT3
    generic map(
      INIT => X"57"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => rom_DATA_BUS(1),
      ADR2 => rom_DATA_BUS(3),
      O => CHOICE11679
    );
  dec_stage_d_mux7_out1_1_60 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N13,
      ADR1 => ifid_buff_out2(6),
      ADR2 => mem_R_P2_data_out(1),
      ADR3 => mem_R_A_data_out(1),
      O => CHOICE12323
    );
  exe_stage_alu_m_n034758 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0233,
      ADR2 => exe_stage_alu_m_n0262,
      O => CHOICE11850
    );
  dec_stage_d_mux9_out1_0_120 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(0),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(0),
      O => CHOICE12424
    );
  dec_stage_d_instruction_decoder_d2_1_7_G : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_instruction_decoder_N95,
      ADR1 => ifid_buff_out1(0),
      ADR2 => r0_from_mem(1),
      ADR3 => r1_from_mem(1),
      O => N6473
    );
  fet_stage_que_state_M_state_FFd2_In198 : X_LUT4
    generic map(
      INIT => X"2232"
    )
    port map (
      ADR0 => CHOICE11686,
      ADR1 => N6309,
      ADR2 => fet_stage_que_state_M_N211,
      ADR3 => rom_DATA_BUS(4),
      O => CHOICE11690
    );
  wb_stage_n0068_0_77 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11082,
      ADR1 => CHOICE11068,
      ADR2 => CHOICE11077,
      ADR3 => CHOICE11085,
      O => wb_stage_n0068(0)
    );
  fet_stage_que_state_M_Ker21 : X_LUT4
    generic map(
      INIT => X"77F7"
    )
    port map (
      ADR0 => rom_DATA_BUS(7),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(4),
      ADR3 => rom_DATA_BUS(6),
      O => fet_stage_que_state_M_N21
    );
  fet_stage_que_state_M_inst_que_code_3_226 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => databus_from_mux19(1),
      ADR1 => databus_from_mux19(0),
      ADR2 => databus_from_mux19(3),
      ADR3 => databus_from_mux19(5),
      O => CHOICE11778
    );
  dec_stage_d_mux9_out1_3_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(3),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(3),
      O => CHOICE12398
    );
  dec_stage_d_mux9_out1_4_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(4),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(4),
      O => CHOICE12449
    );
  exe_stage_alu_m_n048982 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0239,
      ADR1 => exe_stage_src1(1),
      ADR2 => exe_stage_src2(5),
      ADR3 => CHOICE11904,
      O => CHOICE11906
    );
  exe_stage_alu_m_n045923 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0260,
      ADR1 => exe_stage_src1(0),
      ADR2 => exe_stage_alu_m_n0261,
      ADR3 => exe_stage_src1(2),
      O => CHOICE12672
    );
  exe_stage_alu_m_n034763 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11850,
      ADR1 => exe_stage_src1(7),
      ADR2 => exe_stage_alu_m_n0261,
      ADR3 => N6163,
      O => CHOICE11852
    );
  exe_stage_alu_m_n046947 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE12734,
      ADR1 => exe_stage_src2(3),
      ADR2 => exe_stage_alu_m_N621,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE12606
    );
  dec_stage_d_mux7_out1_0_24 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(1),
      ADR1 => mem_R_P0_data_out(0),
      ADR2 => ifid_buff_out2(0),
      ADR3 => mem_R_DPH_data_out(0),
      O => CHOICE12246
    );
  exe_stage_alu_m_n0489111_SW0 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => CHOICE11891,
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N72,
      ADR3 => exwb_buff_out_R_A(5),
      O => N6293
    );
  dec_stage_d_instruction_decoder_d2_7_8_G : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => CHOICE11218,
      ADR1 => ifid_buff_out1(0),
      ADR2 => r0_from_mem(7),
      ADR3 => r1_from_mem(7),
      O => N6475
    );
  exwb_buff_out_R_A_4_1_81 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(4),
      RST => exwb_buff_out_R_A_4_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A_4_1,
      CE => VCC,
      SET => GND
    );
  exe_stage_alu_m_n044724 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12844,
      ADR1 => exe_stage_alu_m_N5,
      ADR2 => exe_stage_src1(6),
      ADR3 => CHOICE12846,
      O => CHOICE12849
    );
  exe_stage_alu_m_n047657_SW0 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12560,
      ADR1 => exe_stage_src1(5),
      ADR2 => exe_stage_alu_m_n0261,
      ADR3 => CHOICE12556,
      O => N6177
    );
  fet_stage_que_state_M_next_Mcode_2_18 : X_LUT4
    generic map(
      INIT => X"9980"
    )
    port map (
      ADR0 => databus_from_mux19(4),
      ADR1 => databus_from_mux19(6),
      ADR2 => fet_stage_que_state_M_N42,
      ADR3 => fet_stage_que_state_M_N431,
      O => CHOICE11588
    );
  exe_stage_alu_m_n044216 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0243,
      ADR2 => exe_stage_alu_m_n0244,
      O => CHOICE12818
    );
  fet_stage_que_state_M_Ker91 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => rom_DATA_BUS(2),
      ADR2 => rom_DATA_BUS(3),
      O => fet_stage_que_state_M_N9
    );
  fet_stage_que_state_M_next_Mcode_2_197 : X_LUT2
    generic map(
      INIT => X"2"
    )
    port map (
      ADR0 => CHOICE11630,
      ADR1 => Reset_IBUF,
      O => fet_stage_que_state_M_next_Mcode(2)
    );
  exe_stage_alu_m_n047616 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0233,
      ADR1 => CHOICE12734,
      ADR2 => exe_stage_src2(4),
      ADR3 => exe_stage_alu_m_n0263,
      O => CHOICE12550
    );
  dec_stage_d_instruction_decoder_d2_7_5 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(3),
      ADR3 => ifid_buff_out1(6),
      O => CHOICE11218
    );
  exe_stage_alu_m_n0464125 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0003(2),
      ADR1 => exe_stage_alu_m_N941,
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => CHOICE12656,
      O => CHOICE12658
    );
  exe_stage_alu_m_n045439 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_N871,
      ADR1 => exe_stage_alu_m_n0008(0),
      ADR2 => idex_buff_out_Opcode(2),
      O => CHOICE12728
    );
  exe_stage_alu_m_des_cy138_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12015,
      ADR1 => idex_buff_out_Opcode(1),
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => exe_stage_src1(0),
      O => N6479
    );
  exe_stage_alu_m_n044716 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0243,
      ADR2 => exe_stage_alu_m_n0244,
      O => CHOICE12846
    );
  dec_stage_d_mux7_out1_0_29 : X_LUT4
    generic map(
      INIT => X"FF8A"
    )
    port map (
      ADR0 => ifid_buff_out2(0),
      ADR1 => mem_R_DPL_data_out(0),
      ADR2 => ifid_buff_out2(1),
      ADR3 => CHOICE12246,
      O => CHOICE12247
    );
  exe_stage_alu_m_n045911 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => exe_stage_src2(1),
      ADR1 => exe_stage_alu_m_N01,
      ADR2 => exe_stage_src1(1),
      ADR3 => exe_stage_alu_m_N711,
      O => CHOICE12667
    );
  dec_stage_d_instruction_decoder_s2_6_SW0 : X_LUT4
    generic map(
      INIT => X"1FBF"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => r0_from_mem(6),
      ADR2 => dec_stage_d_instruction_decoder_N87,
      ADR3 => r1_from_mem(6),
      O => N897
    );
  fet_stage_que_state_M_inst_que_code_3_256 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => CHOICE11782,
      ADR1 => CHOICE11775,
      ADR2 => Reset_IBUF,
      ADR3 => CHOICE11778,
      O => CHOICE11784
    );
  exe_stage_alu_m_n044913 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(15),
      ADR1 => exe_stage_alu_m_N871,
      ADR2 => idex_buff_out_Opcode(2),
      O => CHOICE12858
    );
  dec_stage_d_mux7_out1_3_78 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(3),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(3),
      O => CHOICE12097
    );
  exe_stage_alu_m_n045410 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0261,
      ADR1 => exe_stage_Forwarder_m_n0002,
      ADR2 => N64,
      ADR3 => exwb_buff_out_R_A(1),
      O => CHOICE12718
    );
  dec_stage_d_mux7_out1_7_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(15),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12203
    );
  exe_stage_alu_m_n0476113 : X_LUT4
    generic map(
      INIT => X"FF02"
    )
    port map (
      ADR0 => exe_stage_alu_m_N951,
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => exe_stage_alu_m_alu_n0000_3_cyo,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE12576
    );
  exe_stage_alu_m_n046445 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE12734,
      ADR1 => exe_stage_src2(2),
      ADR2 => exe_stage_alu_m_N621,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE12642
    );
  rom_n0003_0_1 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => addressbus_from_fetch(7),
      ADR2 => rom_Mrom_n0002_N7,
      ADR3 => rom_Mrom_n0002_N14,
      O => rom_n0003(0)
    );
  rom_Mrom_n0002_inst_mux_f5_1521 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6126
    );
  fet_stage_que_state_M_inst_que_code_3_295_SW0 : X_LUT4
    generic map(
      INIT => X"AA08"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => CHOICE11742,
      ADR2 => rom_DATA_BUS(3),
      ADR3 => CHOICE11724,
      O => N6307
    );
  dec_stage_d_instruction_decoder_alu_oprt_2_98_SW0_G : X_LUT4
    generic map(
      INIT => X"5F1F"
    )
    port map (
      ADR0 => N6255,
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(4),
      ADR3 => ifid_buff_out1(5),
      O => N6481
    );
  exe_stage_alu_m_n0454109 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12725,
      ADR1 => exe_stage_alu_m_n0003(0),
      ADR2 => exe_stage_alu_m_n0223,
      ADR3 => CHOICE12740,
      O => CHOICE12745
    );
  exe_stage_alu_m_des_ov72 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => CHOICE12047,
      ADR1 => CHOICE12049,
      ADR2 => exe_stage_alu_m_n0008(13),
      ADR3 => exe_stage_alu_m_n0008(14),
      O => CHOICE12052
    );
  rom_Mrom_n0002_inst_mux_f5_1511 : X_LUT4
    generic map(
      INIT => X"9249"
    )
    port map (
      ADR0 => addressbus_from_fetch(0),
      ADR1 => addressbus_from_fetch(1),
      ADR2 => addressbus_from_fetch(2),
      ADR3 => addressbus_from_fetch(3),
      O => N6120
    );
  exe_stage_alu_m_Ker711 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => exe_stage_alu_m_N861,
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => exe_stage_alu_m_n0273,
      O => exe_stage_alu_m_N711
    );
  wb_stage_Ker91 : X_LUT3
    generic map(
      INIT => X"F2"
    )
    port map (
      ADR0 => wb_stage_N74,
      ADR1 => wb_stage_n0164,
      ADR2 => exwb_buff_out_D11(0),
      O => wb_stage_N9
    );
  mem_internal_ram_bank_Mram_iram1_inst_lut2_271 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => mem_w_addr_b1(5),
      ADR1 => mem_w_addr_b1(6),
      ADR2 => mem_w_addr_b1(7),
      ADR3 => mem_w_addr_b1(0),
      O => mem_internal_ram_bank_Mram_iram1_inst_lut2_27
    );
  fet_stage_que_state_M_state_FFd2_In244 : X_LUT4
    generic map(
      INIT => X"A888"
    )
    port map (
      ADR0 => databus_from_mux19(6),
      ADR1 => CHOICE11700,
      ADR2 => databus_from_mux19(4),
      ADR3 => CHOICE11695,
      O => CHOICE11702
    );
  fet_stage_que_state_M_next_Mcode_2_46 : X_LUT4
    generic map(
      INIT => X"020A"
    )
    port map (
      ADR0 => databus_from_mux19(6),
      ADR1 => databus_from_mux19(5),
      ADR2 => databus_from_mux19(7),
      ADR3 => databus_from_mux19(4),
      O => CHOICE11599
    );
  exe_stage_alu_m_des_cy25 : X_LUT4
    generic map(
      INIT => X"088A"
    )
    port map (
      ADR0 => exe_stage_alu_m_N941,
      ADR1 => exe_stage_src2(7),
      ADR2 => exe_stage_src1(7),
      ADR3 => exe_stage_alu_m_n0005(3),
      O => CHOICE11992
    );
  exe_stage_alu_m_n036480 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE11945,
      ADR1 => exe_stage_src1(7),
      ADR2 => N6181,
      ADR3 => exe_stage_alu_m_n0230,
      O => CHOICE11961
    );
  dec_stage_d_mux7_out1_5_29_G : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => mem_R_DPL_data_out(5),
      ADR2 => ifid_buff_out2(1),
      O => N6483
    );
  exe_stage_alu_m_n046928 : X_LUT4
    generic map(
      INIT => X"F444"
    )
    port map (
      ADR0 => exe_stage_src1(3),
      ADR1 => exe_stage_alu_m_n0230,
      ADR2 => exe_stage_src1(7),
      ADR3 => exe_stage_alu_m_n0239,
      O => CHOICE12600
    );
  exe_stage_alu_m_n0489160_SW0 : X_LUT4
    generic map(
      INIT => X"0220"
    )
    port map (
      ADR0 => exe_stage_alu_m_N951,
      ADR1 => idex_buff_out_Opcode(4),
      ADR2 => exe_stage_alu_m_n0214(1),
      ADR3 => exe_stage_alu_m_Madd_n0001_Mxor_Result_1_Xo(0),
      O => N6219
    );
  exe_stage_alu_m_n0459129_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0003(1),
      ADR1 => exe_stage_alu_m_N941,
      ADR2 => idex_buff_out_Opcode(4),
      O => N6273
    );
  exe_stage_alu_m_n0476154_SW0_G : X_LUT4
    generic map(
      INIT => X"EEFE"
    )
    port map (
      ADR0 => CHOICE12576,
      ADR1 => CHOICE12571,
      ADR2 => exe_stage_alu_m_n0238,
      ADR3 => exe_stage_alu_m_n0165(4),
      O => N6485
    );
  fet_stage_que_state_M_state_FFd2_In215_G : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(3),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(5),
      O => N6487
    );
  fet_stage_que_state_M_Ker421 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(7),
      O => fet_stage_que_state_M_N42
    );
  dec_stage_d_mux7_out1_1_116 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12328,
      ADR2 => CHOICE12323,
      ADR3 => CHOICE12334,
      O => CHOICE12337
    );
  exe_stage_alu_m_n045482 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12728,
      ADR1 => exe_stage_src1(0),
      ADR2 => CHOICE12737,
      ADR3 => CHOICE12730,
      O => CHOICE12740
    );
  fet_stage_que_state_M_Ker211 : X_LUT4
    generic map(
      INIT => X"FBBF"
    )
    port map (
      ADR0 => rom_DATA_BUS(3),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(1),
      ADR3 => rom_DATA_BUS(2),
      O => fet_stage_que_state_M_N211
    );
  exe_stage_alu_m_n044524 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12832,
      ADR1 => exe_stage_alu_m_N5,
      ADR2 => exe_stage_src1(5),
      ADR3 => N6245,
      O => CHOICE12835
    );
  fet_stage_que_state_M_next_Mcode_2_61 : X_LUT4
    generic map(
      INIT => X"2232"
    )
    port map (
      ADR0 => CHOICE11599,
      ADR1 => N6303,
      ADR2 => fet_stage_que_state_M_N431,
      ADR3 => rom_DATA_BUS(6),
      O => CHOICE11603
    );
  fet_stage_que_state_M_state_FFd2_In3071_SW0 : X_LUT3
    generic map(
      INIT => X"A2"
    )
    port map (
      ADR0 => CHOICE11643,
      ADR1 => CHOICE11630,
      ADR2 => Reset_IBUF,
      O => N6247
    );
  dec_stage_d_mux7_out1_5_106 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12124,
      ADR2 => CHOICE12119,
      ADR3 => CHOICE12130,
      O => CHOICE12133
    );
  dec_stage_d_mux7_out1_3_29_G : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => mem_R_DPL_data_out(3),
      ADR2 => ifid_buff_out2(1),
      O => N6489
    );
  dec_stage_d_mux9_out1_5_117 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => dec_stage_mux7_to_mux8_mux9(5),
      ADR2 => cu_sel_mux9(1),
      ADR3 => ifid_buff_out3(5),
      O => CHOICE12474
    );
  exe_stage_alu_m_n036456 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => CHOICE11904,
      ADR2 => exe_stage_alu_m_n0239,
      ADR3 => exe_stage_src1(3),
      O => CHOICE11958
    );
  dec_stage_d_mux7_out1_1_24 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(1),
      ADR1 => mem_R_P0_data_out(1),
      ADR2 => ifid_buff_out2(0),
      ADR3 => mem_R_DPH_data_out(1),
      O => CHOICE12316
    );
  exe_stage_alu_m_n044713 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(14),
      ADR1 => exe_stage_alu_m_N871,
      ADR2 => idex_buff_out_Opcode(2),
      O => CHOICE12844
    );
  fet_stage_que_state_M_next_Mcode_2_84 : X_LUT4
    generic map(
      INIT => X"8808"
    )
    port map (
      ADR0 => cu_sel_rd,
      ADR1 => rom_DATA_BUS(0),
      ADR2 => N6319,
      ADR3 => CHOICE11603,
      O => CHOICE11605
    );
  exe_stage_alu_m_des_cy30 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0002(1),
      ADR1 => exe_stage_alu_m_N951,
      ADR2 => exe_stage_alu_m_n0167(1),
      ADR3 => exe_stage_alu_m_n0249,
      O => CHOICE11995
    );
  exe_stage_alu_m_n046920 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0260,
      ADR1 => exe_stage_src1(2),
      ADR2 => exe_stage_alu_m_n0261,
      ADR3 => exe_stage_src1(4),
      O => CHOICE12596
    );
  exe_stage_alu_m_n044516 : X_LUT3
    generic map(
      INIT => X"A8"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => exe_stage_alu_m_n0243,
      ADR2 => exe_stage_alu_m_n0244,
      O => CHOICE12832
    );
  fet_stage_que_state_M_out3_7 : X_SFF
    generic map(
      INIT => '0'
    )
    port map (
      I => N5924,
      SRST => Reset_IBUF,
      CLK => Clock_BUFGP,
      O => fet_stage_que_state_M_out3(7),
      CE => VCC,
      SET => GND,
      RST => GSR,
      SSET => GND
    );
  dec_stage_d_mux9_out1_5_182_G : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => mem_R_B_data_out(5),
      ADR2 => cu_sel_mux9(0),
      ADR3 => ifid_buff_out2(5),
      O => N6491
    );
  wb_stage_w_addr1_6_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D22(6),
      ADR1 => wb_stage_N56,
      O => CHOICE11708
    );
  dec_stage_d_mux7_out1_2_88 : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => ifid_buff_out2(5),
      ADR1 => mem_R_P1_data_out(2),
      ADR2 => ifid_buff_out2(6),
      ADR3 => mem_R_P3_data_out(2),
      O => CHOICE12299
    );
  exe_stage_alu_m_n044524_SW0 : X_LUT3
    generic map(
      INIT => X"08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0008(13),
      ADR1 => exe_stage_alu_m_N871,
      ADR2 => idex_buff_out_Opcode(2),
      O => N6245
    );
  wb_stage_w_addr1_6_1 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exwb_buff_out_D11(0),
      ADR1 => exwb_buff_out_D11(6),
      O => CHOICE11709
    );
  exwb_buff_out_D22_0_1_82 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(0),
      RST => exwb_buff_out_D22_0_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22_0_1,
      CE => VCC,
      SET => GND
    );
  exe_stage_alu_m_n045458 : X_LUT4
    generic map(
      INIT => X"FBF8"
    )
    port map (
      ADR0 => CHOICE12734,
      ADR1 => exe_stage_src2(0),
      ADR2 => CHOICE12733,
      ADR3 => exe_stage_alu_m_N01,
      O => CHOICE12737
    );
  dec_stage_d_mux7_out1_0_116 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12258,
      ADR2 => CHOICE12253,
      ADR3 => CHOICE12264,
      O => CHOICE12267
    );
  exe_stage_alu_m_n0476154 : X_LUT4
    generic map(
      INIT => X"FF08"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0005(0),
      ADR1 => exe_stage_alu_m_N941,
      ADR2 => idex_buff_out_Opcode(4),
      ADR3 => N6253,
      O => CHOICE12582
    );
  dec_stage_d_mux7_out1_2_36 : X_LUT4
    generic map(
      INIT => X"0002"
    )
    port map (
      ADR0 => CHOICE12282,
      ADR1 => ifid_buff_out2(5),
      ADR2 => ifid_buff_out2(6),
      ADR3 => ifid_buff_out2(4),
      O => CHOICE12283
    );
  exe_stage_alu_m_n0489160 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11909,
      ADR1 => exe_stage_alu_m_n0008(5),
      ADR2 => exe_stage_alu_m_n0224,
      ADR3 => N6219,
      O => CHOICE11918
    );
  dec_stage_d_mux7_out1_6_63 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(6),
      ADR3 => mem_R_B_data_out(6),
      O => CHOICE12190
    );
  exe_stage_alu_m_n0464101 : X_LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      ADR0 => CHOICE12629,
      ADR1 => CHOICE12644,
      ADR2 => CHOICE12648,
      ADR3 => CHOICE12652,
      O => CHOICE12654
    );
  dec_stage_d_mux7_out1_1_0 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => pc_out_from_mem(9),
      ADR1 => dec_stage_d_mux7_N0,
      O => CHOICE12306
    );
  exwb_buff_out_D11_5_1_83 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d1(5),
      RST => exwb_buff_out_D11_5_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D11_5_1,
      CE => VCC,
      SET => GND
    );
  exe_stage_alu_m_n043043 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0073(0),
      ADR1 => exe_stage_alu_m_N961,
      ADR2 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR3 => exe_stage_alu_m_n0227,
      O => CHOICE12777
    );
  dec_stage_d_mux7_out1_0_73 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => ifid_buff_out2(6),
      ADR1 => ifid_buff_out2(5),
      ADR2 => mem_PSW_psw(0),
      ADR3 => mem_R_B_data_out(0),
      O => CHOICE12258
    );
  exe_stage_alu_m_n0347133 : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE11854,
      ADR1 => exe_stage_alu_m_n0008(6),
      ADR2 => exe_stage_alu_m_n0224,
      ADR3 => N6285,
      O => CHOICE11863
    );
  exe_stage_alu_m_n046999_SW0 : X_LUT4
    generic map(
      INIT => X"F888"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0000(3),
      ADR1 => exe_stage_alu_m_n0222,
      ADR2 => exe_stage_alu_m_n0008(3),
      ADR3 => exe_stage_alu_m_n0224,
      O => N6191
    );
  port1_in_2_IBUF_84 : X_BUF
    port map (
      I => port1_in(2),
      O => port1_in_2_IBUF
    );
  dec_stage_d_mux7_out1_3_106 : X_LUT4
    generic map(
      INIT => X"FAF8"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N11,
      ADR1 => CHOICE12091,
      ADR2 => CHOICE12086,
      ADR3 => CHOICE12097,
      O => CHOICE12100
    );
  exe_stage_alu_m_n02601 : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(4),
      ADR1 => idex_buff_out_Opcode(1),
      ADR2 => idex_buff_out_Opcode(2),
      ADR3 => idex_buff_out_Opcode(3),
      O => exe_stage_alu_m_n0260
    );
  exe_stage_alu_m_n046913 : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0229,
      ADR1 => exe_stage_alu_m_n0220,
      ADR2 => exe_stage_src1(3),
      ADR3 => exe_stage_alu_m_n0216(3),
      O => CHOICE12591
    );
  exe_stage_alu_m_n00711_SW1 : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0064(0),
      ADR1 => exe_stage_alu_m_N961,
      ADR2 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR3 => exe_stage_alu_m_n0227,
      O => N6156
    );
  exwb_buff_out_D22_4_1_85 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => idex_buff_out_d2(4),
      RST => exwb_buff_out_D22_4_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_D22_4_1,
      CE => VCC,
      SET => GND
    );
  exwb_buff_out_R_A_1_1_86 : X_FF
    generic map(
      INIT => '0'
    )
    port map (
      I => RA_out_from_execute(1),
      RST => exwb_buff_out_R_A_1_1_GSR_OR,
      CLK => Clock_BUFGP,
      O => exwb_buff_out_R_A_1_1,
      CE => VCC,
      SET => GND
    );
  mem_PSW_n00101 : X_MUX2
    port map (
      IA => N6354,
      IB => N6355,
      SEL => W_psw_from_writeback,
      O => mem_PSW_n0010
    );
  mem_PSW_n00101_F : X_LUT3
    generic map(
      INIT => X"32"
    )
    port map (
      ADR0 => CHOICE12022,
      ADR1 => Reset_IBUF,
      ADR2 => CHOICE11992,
      O => N6354
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_12111 : X_MUX2
    port map (
      IA => N6356,
      IB => N6357,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(6)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_12111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(6),
      ADR2 => write_data1_from_writeback(6),
      O => N6356
    );
  r_aa_from_decode_7_1111 : X_MUX2
    port map (
      IA => N6358,
      IB => N6359,
      SEL => mem_R_A_data_out(7),
      O => r_aa_from_decode(7)
    );
  r_aa_from_decode_7_1111_F : X_LUT4
    generic map(
      INIT => X"B888"
    )
    port map (
      ADR0 => dec_stage_mux7_to_mux8_mux9(7),
      ADR1 => cu_sel_mux8(1),
      ADR2 => cu_sel_mux8(0),
      ADR3 => pc_out_from_mem(15),
      O => N6358
    );
  r_addr0_from_decode_0_1111 : X_MUX2
    port map (
      IA => N6360,
      IB => N6361,
      SEL => cu_sel_mux6(1),
      O => r_addr0_from_decode(0)
    );
  r_addr0_from_decode_0_1111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(0),
      ADR1 => ifid_buff_out2(0),
      ADR2 => ifid_buff_out2(3),
      O => N6360
    );
  mem_latch_m_Mmux_out1_d_in0_0_111 : X_MUX2
    port map (
      IA => N6362,
      IB => N6363,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(0)
    );
  mem_latch_m_Mmux_out1_d_in0_0_111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(8),
      ADR2 => write_data0_from_writeback(0),
      O => N6362
    );
  r_aa_from_decode_3_1111 : X_MUX2
    port map (
      IA => N6364,
      IB => N6365,
      SEL => mem_R_A_data_out(3),
      O => r_aa_from_decode(3)
    );
  r_aa_from_decode_3_1111_F : X_LUT4
    generic map(
      INIT => X"B888"
    )
    port map (
      ADR0 => dec_stage_mux7_to_mux8_mux9(3),
      ADR1 => cu_sel_mux8(1),
      ADR2 => cu_sel_mux8(0),
      ADR3 => pc_out_from_mem(11),
      O => N6364
    );
  r_addr0_from_decode_1_1111 : X_MUX2
    port map (
      IA => N6366,
      IB => N6367,
      SEL => cu_sel_mux6(1),
      O => r_addr0_from_decode(1)
    );
  r_addr0_from_decode_1_1111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(0),
      ADR1 => ifid_buff_out2(1),
      ADR2 => ifid_buff_out2(4),
      O => N6366
    );
  r_addr0_from_decode_3_1111 : X_MUX2
    port map (
      IA => N6368,
      IB => N6369,
      SEL => cu_sel_mux6(0),
      O => r_addr0_from_decode(3)
    );
  r_addr0_from_decode_3_1111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(1),
      ADR1 => ifid_buff_out2(3),
      ADR2 => mem_PSW_psw(3),
      O => N6368
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_11111 : X_MUX2
    port map (
      IA => N6370,
      IB => N6371,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(5)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_11111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(5),
      ADR2 => write_data1_from_writeback(5),
      O => N6370
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_111 : X_MUX2
    port map (
      IA => N6372,
      IB => N6373,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(1)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(9),
      ADR2 => write_data0_from_writeback(1),
      O => N6372
    );
  r_aa_from_decode_4_1111 : X_MUX2
    port map (
      IA => N6374,
      IB => N6375,
      SEL => mem_R_A_data_out(4),
      O => r_aa_from_decode(4)
    );
  r_aa_from_decode_4_1111_F : X_LUT4
    generic map(
      INIT => X"B888"
    )
    port map (
      ADR0 => dec_stage_mux7_to_mux8_mux9(4),
      ADR1 => cu_sel_mux8(1),
      ADR2 => cu_sel_mux8(0),
      ADR3 => pc_out_from_mem(12),
      O => N6374
    );
  dec_stage_d_mux9_out1_4_182 : X_MUX2
    port map (
      IA => N6376,
      IB => N6377,
      SEL => cu_sel_mux9(1),
      O => CHOICE12465
    );
  dec_stage_d_mux9_out1_4_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(12),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(4),
      O => N6376
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_13111 : X_MUX2
    port map (
      IA => N6378,
      IB => N6379,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(7)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_13111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(7),
      ADR2 => write_data1_from_writeback(7),
      O => N6378
    );
  mem_PSW_n00091 : X_MUX2
    port map (
      IA => N6380,
      IB => N6381,
      SEL => W_psw_from_writeback,
      O => mem_PSW_n0009
    );
  mem_PSW_n00091_F : X_LUT4
    generic map(
      INIT => X"1055"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => exe_stage_alu_m_n0003(4),
      ADR2 => exe_stage_alu_m_N941,
      ADR3 => N3364,
      O => N6380
    );
  r_aa_from_decode_6_1111 : X_MUX2
    port map (
      IA => N6382,
      IB => N6383,
      SEL => mem_R_A_data_out(6),
      O => r_aa_from_decode(6)
    );
  r_aa_from_decode_6_1111_F : X_LUT4
    generic map(
      INIT => X"B888"
    )
    port map (
      ADR0 => dec_stage_mux7_to_mux8_mux9(6),
      ADR1 => cu_sel_mux8(1),
      ADR2 => cu_sel_mux8(0),
      ADR3 => pc_out_from_mem(14),
      O => N6382
    );
  r_aa_from_decode_5_1111 : X_MUX2
    port map (
      IA => N6384,
      IB => N6385,
      SEL => mem_R_A_data_out(5),
      O => r_aa_from_decode(5)
    );
  r_aa_from_decode_5_1111_F : X_LUT4
    generic map(
      INIT => X"B888"
    )
    port map (
      ADR0 => dec_stage_mux7_to_mux8_mux9(5),
      ADR1 => cu_sel_mux8(1),
      ADR2 => cu_sel_mux8(0),
      ADR3 => pc_out_from_mem(13),
      O => N6384
    );
  r_addr0_from_decode_2_1111 : X_MUX2
    port map (
      IA => N6386,
      IB => N6387,
      SEL => cu_sel_mux6(0),
      O => r_addr0_from_decode(2)
    );
  r_addr0_from_decode_2_1111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(1),
      ADR1 => ifid_buff_out2(2),
      ADR2 => ifid_buff_out1(2),
      O => N6386
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_0111 : X_MUX2
    port map (
      IA => N6388,
      IB => N6389,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(2)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_0111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(10),
      ADR2 => write_data0_from_writeback(2),
      O => N6388
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_1411 : X_MUX2
    port map (
      IA => N6390,
      IB => N6391,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(3)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_1411_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(11),
      ADR2 => write_data0_from_writeback(3),
      O => N6390
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_6111 : X_MUX2
    port map (
      IA => N6392,
      IB => N6393,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(0)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_6111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(0),
      ADR2 => write_data1_from_writeback(0),
      O => N6392
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_5111 : X_MUX2
    port map (
      IA => N6394,
      IB => N6395,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(7)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_5111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(15),
      ADR2 => write_data0_from_writeback(7),
      O => N6394
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_7111 : X_MUX2
    port map (
      IA => N6396,
      IB => N6397,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(1)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_7111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(1),
      ADR2 => write_data1_from_writeback(1),
      O => N6396
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_8111 : X_MUX2
    port map (
      IA => N6398,
      IB => N6399,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(2)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_8111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(2),
      ADR2 => write_data1_from_writeback(2),
      O => N6398
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_9111 : X_MUX2
    port map (
      IA => N6400,
      IB => N6401,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(3)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_9111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(3),
      ADR2 => write_data1_from_writeback(3),
      O => N6400
    );
  fet_stage_que_state_M_inst_que_code_3_194 : X_MUX2
    port map (
      IA => N6402,
      IB => N6403,
      SEL => rom_DATA_BUS(7),
      O => CHOICE11766
    );
  fet_stage_que_state_M_inst_que_code_3_194_F : X_LUT4
    generic map(
      INIT => X"77F7"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(6),
      ADR3 => rom_DATA_BUS(4),
      O => N6402
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_10111 : X_MUX2
    port map (
      IA => N6404,
      IB => N6405,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in1(4)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_10111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(4),
      ADR2 => write_data1_from_writeback(4),
      O => N6404
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_4111 : X_MUX2
    port map (
      IA => N6406,
      IB => N6407,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(6)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_4111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(14),
      ADR2 => write_data0_from_writeback(6),
      O => N6406
    );
  wb_stage_n0150_87 : X_MUX2
    port map (
      IA => N6408,
      IB => N6409,
      SEL => exwb_buff_out_D22(0),
      O => wb_stage_n0150
    );
  wb_stage_n0150_F : X_LUT4
    generic map(
      INIT => X"01AF"
    )
    port map (
      ADR0 => exwb_buff_out_D22(4),
      ADR1 => exwb_buff_out_D22(5),
      ADR2 => exwb_buff_out_D22(6),
      ADR3 => exwb_buff_out_D22(1),
      O => N6408
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_2111 : X_MUX2
    port map (
      IA => N6410,
      IB => N6411,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(4)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_2111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(12),
      ADR2 => write_data0_from_writeback(4),
      O => N6410
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_3111 : X_MUX2
    port map (
      IA => N6412,
      IB => N6413,
      SEL => exwb_buff_out_en(0),
      O => mem_d_in0(5)
    );
  mem_latch_m_Mmux_out1_d_in0_0_d_in0_0_rn_3111_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exwb_buff_out_en(1),
      ADR1 => fet_stage_PC_M_data_out(13),
      ADR2 => write_data0_from_writeback(5),
      O => N6412
    );
  dec_stage_d_mux9_out1_0_187 : X_MUX2
    port map (
      IA => N6414,
      IB => N6415,
      SEL => cu_sel_mux9(1),
      O => CHOICE12440
    );
  dec_stage_d_mux9_out1_0_187_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(8),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(0),
      O => N6414
    );
  dec_stage_d_mux9_out1_7_182 : X_MUX2
    port map (
      IA => N6416,
      IB => N6417,
      SEL => cu_sel_mux9(1),
      O => CHOICE12515
    );
  dec_stage_d_mux9_out1_7_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(15),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(7),
      O => N6416
    );
  r_addr0_from_decode_4_1 : X_MUX2
    port map (
      IA => N6418,
      IB => N6419,
      SEL => cu_sel_mux6(0),
      O => r_addr0_from_decode(4)
    );
  r_addr0_from_decode_4_1_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => cu_sel_mux6(1),
      ADR1 => ifid_buff_out2(4),
      ADR2 => mem_PSW_psw(4),
      O => N6418
    );
  dec_stage_d_mux9_out1_6_182 : X_MUX2
    port map (
      IA => N6420,
      IB => N6421,
      SEL => cu_sel_mux9(1),
      O => CHOICE12540
    );
  dec_stage_d_mux9_out1_6_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(14),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(6),
      O => N6420
    );
  exe_stage_alu_m_n044543 : X_MUX2
    port map (
      IA => N6422,
      IB => N6423,
      SEL => exe_stage_alu_m_alu_n0073_7_cyo,
      O => RB_out_from_execute(5)
    );
  exe_stage_alu_m_n043942 : X_MUX2
    port map (
      IA => N6424,
      IB => N6425,
      SEL => exe_stage_alu_m_alu_n0073_7_cyo,
      O => RB_out_from_execute(3)
    );
  exe_stage_alu_m_n043642 : X_MUX2
    port map (
      IA => N6426,
      IB => N6427,
      SEL => exe_stage_alu_m_alu_n0073_7_cyo,
      O => RB_out_from_execute(2)
    );
  cu_n0332181_SW0 : X_MUX2
    port map (
      IA => N6428,
      IB => N6429,
      SEL => ifid_buff_out1(0),
      O => N6197
    );
  cu_n0332181_SW0_F : X_LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      ADR0 => ifid_buff_out1(4),
      ADR1 => ifid_buff_out1(5),
      ADR2 => ifid_buff_out1(7),
      ADR3 => ifid_buff_out1(6),
      O => N6428
    );
  dec_stage_d_mux9_out1_1_182 : X_MUX2
    port map (
      IA => N6430,
      IB => N6431,
      SEL => cu_sel_mux9(1),
      O => CHOICE12389
    );
  dec_stage_d_mux9_out1_1_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(9),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(1),
      O => N6430
    );
  dec_stage_d_mux7_out1_4_29 : X_MUX2
    port map (
      IA => N6432,
      IB => N6433,
      SEL => ifid_buff_out2(0),
      O => CHOICE12147
    );
  dec_stage_d_mux7_out1_4_29_F : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => ifid_buff_out2(1),
      ADR2 => mem_R_P0_data_out(4),
      ADR3 => mem_R_DPH_data_out(4),
      O => N6432
    );
  dec_stage_d_mux9_out1_2_182 : X_MUX2
    port map (
      IA => N6434,
      IB => N6435,
      SEL => cu_sel_mux9(1),
      O => CHOICE12364
    );
  dec_stage_d_mux9_out1_2_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(10),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(2),
      O => N6434
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_33 : X_MUX2
    port map (
      IA => N6436,
      IB => N6437,
      SEL => ifid_buff_out1(7),
      O => CHOICE11261
    );
  dec_stage_d_instruction_decoder_alu_oprt_1_33_F : X_LUT4
    generic map(
      INIT => X"44E4"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => dec_stage_d_instruction_decoder_N39,
      ADR2 => dec_stage_d_instruction_decoder_N24,
      ADR3 => ifid_buff_out1(5),
      O => N6436
    );
  exe_stage_alu_m_des_cy68 : X_MUX2
    port map (
      IA => N6438,
      IB => N6439,
      SEL => exe_stage_alu_m_n0220,
      O => CHOICE12011
    );
  exe_stage_alu_m_des_cy68_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0002,
      ADR1 => N76,
      ADR2 => mem_PSW_psw(7),
      ADR3 => exwb_buff_out_R_A(7),
      O => N6438
    );
  cu_n0332254 : X_MUX2
    port map (
      IA => N6440,
      IB => N6441,
      SEL => ifid_buff_out1(2),
      O => CHOICE10828
    );
  cu_n0332254_F : X_LUT3
    generic map(
      INIT => X"EA"
    )
    port map (
      ADR0 => CHOICE10827,
      ADR1 => CHOICE10779,
      ADR2 => ifid_buff_out1(3),
      O => N6440
    );
  wb_stage_n0068_2_15 : X_MUX2
    port map (
      IA => N6442,
      IB => N6443,
      SEL => wb_stage_N71,
      O => CHOICE11036
    );
  wb_stage_n0068_2_15_F : X_LUT4
    generic map(
      INIT => X"1535"
    )
    port map (
      ADR0 => wb_stage_n0184(6),
      ADR1 => wb_stage_N67,
      ADR2 => wb_stage_N26,
      ADR3 => wb_stage_N80,
      O => N6442
    );
  dec_stage_d_instruction_decoder_n019857_SW0 : X_MUX2
    port map (
      IA => N6444,
      IB => N6445,
      SEL => cu_N39,
      O => N6189
    );
  dec_stage_d_instruction_decoder_n019857_SW0_F : X_LUT4
    generic map(
      INIT => X"FFF7"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out1(2),
      ADR2 => ifid_buff_out1(1),
      ADR3 => ifid_buff_out1(3),
      O => N6444
    );
  exe_stage_alu_m_des_ov109 : X_MUX2
    port map (
      IA => N6446,
      IB => N6447,
      SEL => idex_buff_out_Opcode(1),
      O => CHOICE12059
    );
  exe_stage_alu_m_des_ov109_F : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => idex_buff_out_Opcode(2),
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => exe_stage_alu_m_n0226,
      O => N6446
    );
  exe_stage_alu_m_n036449 : X_MUX2
    port map (
      IA => N6448,
      IB => N6449,
      SEL => idex_buff_out_Opcode(2),
      O => CHOICE11954
    );
  exe_stage_alu_m_n036449_F : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => exe_stage_src1(6),
      ADR1 => idex_buff_out_Opcode(1),
      ADR2 => idex_buff_out_Opcode(3),
      ADR3 => idex_buff_out_Opcode(4),
      O => N6448
    );
  exe_stage_alu_m_n044243 : X_MUX2
    port map (
      IA => N6450,
      IB => N6451,
      SEL => exe_stage_alu_m_alu_n0073_7_cyo,
      O => RB_out_from_execute(4)
    );
  cu_n0332236 : X_MUX2
    port map (
      IA => N6452,
      IB => N6453,
      SEL => ifid_buff_out1(3),
      O => CHOICE10827
    );
  cu_n0332236_F : X_LUT4
    generic map(
      INIT => X"E444"
    )
    port map (
      ADR0 => ifid_buff_out1(2),
      ADR1 => N6197,
      ADR2 => CHOICE10816,
      ADR3 => CHOICE10812,
      O => N6452
    );
  dec_stage_d_mux9_out1_3_182 : X_MUX2
    port map (
      IA => N6454,
      IB => N6455,
      SEL => cu_sel_mux9(1),
      O => CHOICE12414
    );
  dec_stage_d_mux9_out1_3_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(11),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(3),
      O => N6454
    );
  dec_stage_d_mux7_out1_6_29 : X_MUX2
    port map (
      IA => N6456,
      IB => N6457,
      SEL => ifid_buff_out2(0),
      O => CHOICE12180
    );
  dec_stage_d_mux7_out1_6_29_F : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => ifid_buff_out2(1),
      ADR2 => mem_R_P0_data_out(6),
      ADR3 => mem_R_DPH_data_out(6),
      O => N6456
    );
  mem_PSW_n00081 : X_MUX2
    port map (
      IA => N6458,
      IB => N6459,
      SEL => W_psw_from_writeback,
      O => mem_PSW_n0008
    );
  mem_PSW_n00081_F : X_LUT3
    generic map(
      INIT => X"32"
    )
    port map (
      ADR0 => CHOICE12067,
      ADR1 => Reset_IBUF,
      ADR2 => CHOICE12034,
      O => N6458
    );
  dec_stage_d_mux7_out1_7_29 : X_MUX2
    port map (
      IA => N6460,
      IB => N6461,
      SEL => ifid_buff_out2(0),
      O => CHOICE12213
    );
  dec_stage_d_mux7_out1_7_29_F : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => ifid_buff_out2(1),
      ADR2 => mem_R_P0_data_out(7),
      ADR3 => mem_R_DPH_data_out(7),
      O => N6460
    );
  dec_stage_d_instruction_decoder_d2_3_24 : X_MUX2
    port map (
      IA => N6462,
      IB => N6463,
      SEL => ifid_buff_out1(3),
      O => d2_from_decode(3)
    );
  dec_stage_d_instruction_decoder_d2_3_24_F : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => CHOICE11455,
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(2),
      ADR3 => Reset_IBUF,
      O => N6462
    );
  exe_stage_alu_m_n0454141 : X_MUX2
    port map (
      IA => N6464,
      IB => N6465,
      SEL => idex_buff_out_Opcode(2),
      O => CHOICE12755
    );
  exe_stage_alu_m_n0454141_F : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => idex_buff_out_Opcode(0),
      ADR1 => exe_stage_src1(7),
      ADR2 => mem_PSW_psw(7),
      O => N6464
    );
  dec_stage_d_instruction_decoder_d2_4_24 : X_MUX2
    port map (
      IA => N6466,
      IB => N6467,
      SEL => ifid_buff_out1(3),
      O => d2_from_decode(4)
    );
  dec_stage_d_instruction_decoder_d2_4_24_F : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => CHOICE11446,
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(2),
      ADR3 => Reset_IBUF,
      O => N6466
    );
  dec_stage_d_instruction_decoder_Ker101 : X_MUX2
    port map (
      IA => N6468,
      IB => N6469,
      SEL => ifid_buff_out1(2),
      O => dec_stage_d_instruction_decoder_N101
    );
  dec_stage_d_instruction_decoder_Ker101_F : X_LUT4
    generic map(
      INIT => X"0400"
    )
    port map (
      ADR0 => ifid_buff_out1(6),
      ADR1 => ifid_buff_out1(1),
      ADR2 => ifid_buff_out1(7),
      ADR3 => ifid_buff_out1(0),
      O => N6468
    );
  dec_stage_d_instruction_decoder_d2_0_24 : X_MUX2
    port map (
      IA => N6470,
      IB => N6471,
      SEL => ifid_buff_out1(3),
      O => d2_from_decode(0)
    );
  dec_stage_d_instruction_decoder_d2_0_24_F : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => CHOICE11473,
      ADR1 => ifid_buff_out1(6),
      ADR2 => ifid_buff_out1(2),
      ADR3 => Reset_IBUF,
      O => N6470
    );
  dec_stage_d_instruction_decoder_d2_1_7 : X_MUX2
    port map (
      IA => N6472,
      IB => N6473,
      SEL => ifid_buff_out1(1),
      O => CHOICE11568
    );
  dec_stage_d_instruction_decoder_d2_1_7_F : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out2(1),
      ADR2 => dec_stage_d_instruction_decoder_N95,
      ADR3 => ifid_buff_out1(4),
      O => N6472
    );
  dec_stage_d_instruction_decoder_d2_7_8 : X_MUX2
    port map (
      IA => N6474,
      IB => N6475,
      SEL => ifid_buff_out1(1),
      O => CHOICE11219
    );
  dec_stage_d_instruction_decoder_d2_7_8_F : X_LUT4
    generic map(
      INIT => X"0080"
    )
    port map (
      ADR0 => ifid_buff_out1(0),
      ADR1 => ifid_buff_out2(7),
      ADR2 => CHOICE11218,
      ADR3 => ifid_buff_out1(4),
      O => N6474
    );
  exe_stage_alu_m_n044743 : X_MUX2
    port map (
      IA => N6476,
      IB => N6477,
      SEL => exe_stage_alu_m_alu_n0073_7_cyo,
      O => RB_out_from_execute(6)
    );
  exe_stage_alu_m_des_cy138 : X_MUX2
    port map (
      IA => N6478,
      IB => N6479,
      SEL => idex_buff_out_Opcode(2),
      O => CHOICE12020
    );
  exe_stage_alu_m_des_cy138_F : X_LUT3
    generic map(
      INIT => X"80"
    )
    port map (
      ADR0 => exe_stage_src1(7),
      ADR1 => idex_buff_out_Opcode(3),
      ADR2 => idex_buff_out_Opcode(1),
      O => N6478
    );
  dec_stage_d_instruction_decoder_alu_oprt_2_98_SW0 : X_MUX2
    port map (
      IA => N6480,
      IB => N6481,
      SEL => ifid_buff_out1(6),
      O => N6171
    );
  dec_stage_d_instruction_decoder_alu_oprt_2_98_SW0_F : X_LUT4
    generic map(
      INIT => X"2A7F"
    )
    port map (
      ADR0 => ifid_buff_out1(5),
      ADR1 => ifid_buff_out1(4),
      ADR2 => N6255,
      ADR3 => dec_stage_d_instruction_decoder_N89,
      O => N6480
    );
  dec_stage_d_mux7_out1_5_29 : X_MUX2
    port map (
      IA => N6482,
      IB => N6483,
      SEL => ifid_buff_out2(0),
      O => CHOICE12114
    );
  dec_stage_d_mux7_out1_5_29_F : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => ifid_buff_out2(1),
      ADR2 => mem_R_P0_data_out(5),
      ADR3 => mem_R_DPH_data_out(5),
      O => N6482
    );
  exe_stage_alu_m_n0476154_SW0 : X_MUX2
    port map (
      IA => N6484,
      IB => N6485,
      SEL => exe_stage_alu_m_n0287,
      O => N6253
    );
  exe_stage_alu_m_n0476154_SW0_F : X_LUT4
    generic map(
      INIT => X"FFEA"
    )
    port map (
      ADR0 => CHOICE12544,
      ADR1 => exe_stage_alu_m_n0238,
      ADR2 => exe_stage_alu_m_n0165(4),
      ADR3 => CHOICE12571,
      O => N6484
    );
  fet_stage_que_state_M_state_FFd2_In215 : X_MUX2
    port map (
      IA => N6486,
      IB => N6487,
      SEL => rom_DATA_BUS(7),
      O => CHOICE11695
    );
  fet_stage_que_state_M_state_FFd2_In215_F : X_LUT4
    generic map(
      INIT => X"8808"
    )
    port map (
      ADR0 => rom_DATA_BUS(5),
      ADR1 => cu_sel_rd,
      ADR2 => rom_DATA_BUS(0),
      ADR3 => fet_stage_que_state_M_N211,
      O => N6486
    );
  dec_stage_d_mux7_out1_3_29 : X_MUX2
    port map (
      IA => N6488,
      IB => N6489,
      SEL => ifid_buff_out2(0),
      O => CHOICE12081
    );
  dec_stage_d_mux7_out1_3_29_F : X_LUT4
    generic map(
      INIT => X"A820"
    )
    port map (
      ADR0 => dec_stage_d_mux7_N12,
      ADR1 => ifid_buff_out2(1),
      ADR2 => mem_R_P0_data_out(3),
      ADR3 => mem_R_DPH_data_out(3),
      O => N6488
    );
  dec_stage_d_mux9_out1_5_182 : X_MUX2
    port map (
      IA => N6490,
      IB => N6491,
      SEL => cu_sel_mux9(1),
      O => CHOICE12490
    );
  dec_stage_d_mux9_out1_5_182_F : X_LUT4
    generic map(
      INIT => X"0E04"
    )
    port map (
      ADR0 => cu_sel_mux9(2),
      ADR1 => pc_out_from_mem(13),
      ADR2 => cu_sel_mux9(0),
      ADR3 => dec_stage_bit_number_dec_to_mux9(5),
      O => N6490
    );
  exe_stage_alu_m_n044943 : X_MUX2
    port map (
      IA => N6492,
      IB => N6493,
      SEL => exe_stage_alu_m_alu_n0073_7_cyo,
      O => RB_out_from_execute(7)
    );
  exe_stage_alu_m_n043342_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043342_O,
      O => RB_out_from_execute(1)
    );
  exe_stage_alu_m_n043342 : X_LUT4
    generic map(
      INIT => X"0511"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => N6134,
      ADR2 => N6135,
      ADR3 => exe_stage_alu_m_alu_n0073_7_cyo,
      O => exe_stage_alu_m_n043342_O
    );
  Eq_stagelut_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut_O,
      O => N30
    );
  Eq_stagelut : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s1(1),
      ADR1 => idex_buff_out_s1(0),
      ADR2 => exwb_buff_out_D22(1),
      ADR3 => exwb_buff_out_D22_0_1,
      O => Eq_stagelut_O
    );
  Eq_stagelut1_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut1_O,
      O => N31
    );
  Eq_stagelut1 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s1(3),
      ADR1 => idex_buff_out_s1(2),
      ADR2 => exwb_buff_out_D22(3),
      ADR3 => exwb_buff_out_D22(2),
      O => Eq_stagelut1_O
    );
  Eq_stagelut2_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut2_O,
      O => N32
    );
  Eq_stagelut2 : X_LUT4
    generic map(
      INIT => X"8241"
    )
    port map (
      ADR0 => idex_buff_out_s1(5),
      ADR1 => idex_buff_out_s1(4),
      ADR2 => exwb_buff_out_D22_4_1,
      ADR3 => exwb_buff_out_D22_5_1,
      O => Eq_stagelut2_O
    );
  Eq_stagelut3_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut3_O,
      O => N33
    );
  Eq_stagelut3 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s1(7),
      ADR1 => idex_buff_out_s1(6),
      ADR2 => exwb_buff_out_D22(7),
      ADR3 => exwb_buff_out_D22_6_1,
      O => Eq_stagelut3_O
    );
  Eq_stagelut4_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut4_O,
      O => N34
    );
  Eq_stagelut4 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s1(1),
      ADR1 => idex_buff_out_s1(0),
      ADR2 => exwb_buff_out_D11(1),
      ADR3 => exwb_buff_out_D11_0_1,
      O => Eq_stagelut4_O
    );
  Eq_stagelut5_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut5_O,
      O => N35
    );
  Eq_stagelut5 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s1(3),
      ADR1 => idex_buff_out_s1(2),
      ADR2 => exwb_buff_out_D11(3),
      ADR3 => exwb_buff_out_D11(2),
      O => Eq_stagelut5_O
    );
  Eq_stagelut6_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut6_O,
      O => N36
    );
  Eq_stagelut6 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exwb_buff_out_D11_5_1,
      ADR1 => idex_buff_out_s1(5),
      ADR2 => idex_buff_out_s1(4),
      ADR3 => exwb_buff_out_D11(4),
      O => Eq_stagelut6_O
    );
  Eq_stagelut7_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut7_O,
      O => N37
    );
  Eq_stagelut7 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s1(7),
      ADR1 => idex_buff_out_s1(6),
      ADR2 => exwb_buff_out_D11(7),
      ADR3 => exwb_buff_out_D11_6_1,
      O => Eq_stagelut7_O
    );
  Eq_stagelut8_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut8_O,
      O => N38
    );
  Eq_stagelut8 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s2(1),
      ADR1 => idex_buff_out_s2(0),
      ADR2 => exwb_buff_out_D11(1),
      ADR3 => exwb_buff_out_D11_0_1,
      O => Eq_stagelut8_O
    );
  Eq_stagelut9_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut9_O,
      O => N39
    );
  Eq_stagelut9 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s2(3),
      ADR1 => idex_buff_out_s2(2),
      ADR2 => exwb_buff_out_D11(3),
      ADR3 => exwb_buff_out_D11(2),
      O => Eq_stagelut9_O
    );
  Eq_stagelut10_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut10_O,
      O => N40
    );
  Eq_stagelut10 : X_LUT4
    generic map(
      INIT => X"9009"
    )
    port map (
      ADR0 => exwb_buff_out_D11_5_1,
      ADR1 => idex_buff_out_s2(5),
      ADR2 => idex_buff_out_s2(4),
      ADR3 => exwb_buff_out_D11(4),
      O => Eq_stagelut10_O
    );
  Eq_stagelut11_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut11_O,
      O => N41
    );
  Eq_stagelut11 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s2(7),
      ADR1 => idex_buff_out_s2(6),
      ADR2 => exwb_buff_out_D11(7),
      ADR3 => exwb_buff_out_D11_6_1,
      O => Eq_stagelut11_O
    );
  Eq_stagelut12_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut12_O,
      O => N42
    );
  Eq_stagelut12 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s2(1),
      ADR1 => idex_buff_out_s2(0),
      ADR2 => exwb_buff_out_D22(1),
      ADR3 => exwb_buff_out_D22_0_1,
      O => Eq_stagelut12_O
    );
  Eq_stagelut13_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut13_O,
      O => N43
    );
  Eq_stagelut13 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s2(3),
      ADR1 => idex_buff_out_s2(2),
      ADR2 => exwb_buff_out_D22(3),
      ADR3 => exwb_buff_out_D22(2),
      O => Eq_stagelut13_O
    );
  Eq_stagelut14_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut14_O,
      O => N44
    );
  Eq_stagelut14 : X_LUT4
    generic map(
      INIT => X"8241"
    )
    port map (
      ADR0 => idex_buff_out_s2(5),
      ADR1 => idex_buff_out_s2(4),
      ADR2 => exwb_buff_out_D22_4_1,
      ADR3 => exwb_buff_out_D22_5_1,
      O => Eq_stagelut14_O
    );
  Eq_stagelut15_LUT4_L_BUF : X_BUF
    port map (
      I => Eq_stagelut15_O,
      O => N45
    );
  Eq_stagelut15 : X_LUT4
    generic map(
      INIT => X"8421"
    )
    port map (
      ADR0 => idex_buff_out_s2(7),
      ADR1 => idex_buff_out_s2(6),
      ADR2 => exwb_buff_out_D22(7),
      ADR3 => exwb_buff_out_D22_6_1,
      O => Eq_stagelut15_O
    );
  exe_stage_src1_3_1_LUT3_D_BUF : X_BUF
    port map (
      I => N68,
      O => N6494
    );
  exe_stage_src1_3_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0003,
      ADR1 => idex_buff_out_A(3),
      ADR2 => exwb_buff_out_R_B(3),
      O => N68
    );
  exe_stage_src1_4_1_LUT3_D_BUF : X_BUF
    port map (
      I => N70,
      O => N6495
    );
  exe_stage_src1_4_1 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0003,
      ADR1 => idex_buff_out_A(4),
      ADR2 => exwb_buff_out_R_B(4),
      O => N70
    );
  exe_stage_src1_5_1_LUT3_D_BUF : X_BUF
    port map (
      I => N72,
      O => N6496
    );
  exe_stage_src1_5_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_A(5),
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => exe_stage_Forwarder_m_n0003,
      O => N72
    );
  exe_stage_src1_6_1_LUT3_D_BUF : X_BUF
    port map (
      I => N74,
      O => N6497
    );
  exe_stage_src1_6_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_A(6),
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => exe_stage_Forwarder_m_n0003,
      O => N74
    );
  exe_stage_src1_7_1_LUT3_D_BUF : X_BUF
    port map (
      I => N76,
      O => N6498
    );
  exe_stage_src1_7_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_A(7),
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => exe_stage_Forwarder_m_n0003,
      O => N76
    );
  exe_stage_src2_1_2_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_src2(1),
      O => N6499
    );
  exe_stage_src2_1_2 : X_LUT3
    generic map(
      INIT => X"B8"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(1),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N80,
      O => exe_stage_src2(1)
    );
  exe_stage_src2_2_1_LUT3_D_BUF : X_BUF
    port map (
      I => N82,
      O => N6500
    );
  exe_stage_src2_2_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(2),
      ADR1 => exwb_buff_out_R_B(2),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N82
    );
  exe_stage_src2_3_1_LUT3_D_BUF : X_BUF
    port map (
      I => N84,
      O => N6501
    );
  exe_stage_src2_3_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(3),
      ADR1 => exwb_buff_out_R_B(3),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N84
    );
  exe_stage_src2_4_1_LUT3_D_BUF : X_BUF
    port map (
      I => N86,
      O => N6502
    );
  exe_stage_src2_4_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(4),
      ADR1 => exwb_buff_out_R_B(4),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N86
    );
  exe_stage_src2_5_1_LUT3_D_BUF : X_BUF
    port map (
      I => N88,
      O => N6503
    );
  exe_stage_src2_5_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(5),
      ADR1 => exwb_buff_out_R_B(5),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N88
    );
  exe_stage_src2_6_1_LUT3_D_BUF : X_BUF
    port map (
      I => N90,
      O => N6504
    );
  exe_stage_src2_6_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(6),
      ADR1 => exwb_buff_out_R_B(6),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N90
    );
  exe_stage_src2_7_1_LUT3_D_BUF : X_BUF
    port map (
      I => N92,
      O => N6505
    );
  exe_stage_src2_7_1 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => idex_buff_out_B(7),
      ADR1 => exwb_buff_out_R_B(7),
      ADR2 => exe_stage_Forwarder_m_n0006,
      O => N92
    );
  exe_stage_alu_m_n044543_G_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044543_G_O,
      O => N6423
    );
  exe_stage_alu_m_n044543_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12835,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0073(5),
      O => exe_stage_alu_m_n044543_G_O
    );
  exe_stage_alu_m_n043942_G_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043942_G_O,
      O => N6425
    );
  exe_stage_alu_m_n043942_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12807,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0073(3),
      O => exe_stage_alu_m_n043942_G_O
    );
  exe_stage_alu_m_n043642_G_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043642_G_O,
      O => N6427
    );
  exe_stage_alu_m_n043642_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12793,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0073(2),
      O => exe_stage_alu_m_n043642_G_O
    );
  exe_stage_alu_m_n00201_SW0_LUT2_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n00201_SW0_O,
      O => N6132
    );
  exe_stage_alu_m_n00201_SW0 : X_LUT2
    generic map(
      INIT => X"7"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(5),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_n00201_SW0_O
    );
  exe_stage_alu_m_n043015_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043015_O,
      O => CHOICE12768
    );
  exe_stage_alu_m_n043015 : X_LUT4
    generic map(
      INIT => X"FF2A"
    )
    port map (
      ADR0 => CHOICE12765,
      ADR1 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR2 => exe_stage_alu_m_alu_n0073_7_cyo,
      ADR3 => CHOICE12767,
      O => exe_stage_alu_m_n043015_O
    );
  exe_stage_alu_m_n0464150_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0464150_O,
      O => RA_out_from_execute(2)
    );
  exe_stage_alu_m_n0464150 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12658,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_alu_cyo3,
      O => exe_stage_alu_m_n0464150_O
    );
  exe_stage_alu_m_n0459153_LUT4_D_BUF : X_BUF
    port map (
      I => RA_out_from_execute(1),
      O => N6506
    );
  exe_stage_alu_m_n0459153 : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12696,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_alu_cyo4,
      O => RA_out_from_execute(1)
    );
  exe_stage_alu_m_n00421_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0296(3),
      O => N6507
    );
  exe_stage_alu_m_n00421 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0295(2),
      ADR1 => exe_stage_alu_m_alu_cyo2,
      ADR2 => exe_stage_alu_m_n0037(2),
      O => exe_stage_alu_m_n0296(3)
    );
  exe_stage_alu_m_n00331_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0295(3),
      O => N6508
    );
  exe_stage_alu_m_n00331 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0293(2),
      ADR1 => exe_stage_alu_m_alu_cyo1,
      ADR2 => exe_stage_alu_m_n0028(2),
      O => exe_stage_alu_m_n0295(3)
    );
  exe_stage_alu_m_n00401_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0296(5),
      O => N6509
    );
  exe_stage_alu_m_n00401 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo2,
      ADR1 => exe_stage_alu_m_n0295(4),
      ADR2 => exe_stage_alu_m_n0037(4),
      O => exe_stage_alu_m_n0296(5)
    );
  exe_stage_alu_m_n00351_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0295(1),
      O => N6510
    );
  exe_stage_alu_m_n00351 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(5),
      ADR1 => exe_stage_alu_m_n0028(0),
      ADR2 => exe_stage_alu_m_alu_cyo1,
      O => exe_stage_alu_m_n0295(1)
    );
  exe_stage_alu_m_n043078_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043078_O,
      O => RB_out_from_execute(0)
    );
  exe_stage_alu_m_n043078 : X_LUT4
    generic map(
      INIT => X"5540"
    )
    port map (
      ADR0 => Reset_IBUF,
      ADR1 => exe_stage_src1(0),
      ADR2 => CHOICE12768,
      ADR3 => CHOICE12779,
      O => exe_stage_alu_m_n043078_O
    );
  exe_stage_alu_m_n00241_LUT4_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0293(3),
      O => N6511
    );
  exe_stage_alu_m_n00241 : X_LUT4
    generic map(
      INIT => X"F808"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(1),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(2),
      O => exe_stage_alu_m_n0293(3)
    );
  exe_stage_alu_m_n00231_LUT4_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0293(4),
      O => N6512
    );
  exe_stage_alu_m_n00231 : X_LUT4
    generic map(
      INIT => X"F808"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(2),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(3),
      O => exe_stage_alu_m_n0293(4)
    );
  exe_stage_alu_m_n00171_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0311(1),
      O => N6513
    );
  exe_stage_alu_m_n00171 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(7),
      ADR1 => exe_stage_alu_m_n0010(0),
      ADR2 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_n0311(1)
    );
  exe_stage_alu_m_n00161_LUT2_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0311(2),
      O => N6514
    );
  exe_stage_alu_m_n00161 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(1),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_n0311(2)
    );
  exe_stage_alu_m_n00221_LUT4_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0293(5),
      O => N6515
    );
  exe_stage_alu_m_n00221 : X_LUT4
    generic map(
      INIT => X"F808"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(3),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(4),
      O => exe_stage_alu_m_n0293(5)
    );
  exe_stage_alu_m_n00151_LUT2_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0311(3),
      O => N6516
    );
  exe_stage_alu_m_n00151 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(2),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_n0311(3)
    );
  exe_stage_alu_m_n00291_LUT4_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_N120,
      O => N6517
    );
  exe_stage_alu_m_n00291 : X_LUT4
    generic map(
      INIT => X"F808"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(4),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_alu_cyo6,
      ADR3 => exe_stage_alu_m_n0019(5),
      O => exe_stage_alu_m_N120
    );
  exe_stage_alu_m_n00141_LUT2_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0311(4),
      O => N6518
    );
  exe_stage_alu_m_n00141 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0010(3),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_n0311(4)
    );
  exe_stage_alu_m_n00131_LUT2_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0311(5),
      O => N6519
    );
  exe_stage_alu_m_n00131 : X_LUT2
    generic map(
      INIT => X"8"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo5,
      ADR1 => exe_stage_alu_m_n0010(4),
      O => exe_stage_alu_m_n0311(5)
    );
  exe_stage_alu_m_n00441_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0296(1),
      O => N6520
    );
  exe_stage_alu_m_n00441 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(4),
      ADR1 => exe_stage_alu_m_n0037(0),
      ADR2 => exe_stage_alu_m_alu_cyo2,
      O => exe_stage_alu_m_n0296(1)
    );
  exe_stage_alu_m_n00511_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0297(3),
      O => N6521
    );
  exe_stage_alu_m_n00511 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0296(2),
      ADR1 => exe_stage_alu_m_alu_cyo,
      ADR2 => exe_stage_alu_m_n0046(2),
      O => exe_stage_alu_m_n0297(3)
    );
  exe_stage_alu_m_n00311_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0295(5),
      O => N6522
    );
  exe_stage_alu_m_n00311 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo1,
      ADR1 => exe_stage_alu_m_n0293(4),
      ADR2 => exe_stage_alu_m_n0028(4),
      O => exe_stage_alu_m_n0295(5)
    );
  exe_stage_alu_m_n00261_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0293(1),
      O => N6523
    );
  exe_stage_alu_m_n00261 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(6),
      ADR1 => exe_stage_alu_m_n0019(0),
      ADR2 => exe_stage_alu_m_alu_cyo6,
      O => exe_stage_alu_m_n0293(1)
    );
  exe_stage_alu_m_n00591_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0298(4),
      O => N6524
    );
  exe_stage_alu_m_n00591 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0297(3),
      ADR1 => exe_stage_alu_m_alu_cyo3,
      ADR2 => exe_stage_alu_m_n0055(3),
      O => exe_stage_alu_m_n0298(4)
    );
  exe_stage_alu_m_n00581_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0298(5),
      O => N6525
    );
  exe_stage_alu_m_n00581 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo3,
      ADR1 => exe_stage_alu_m_n0297(4),
      ADR2 => exe_stage_alu_m_n0055(4),
      O => exe_stage_alu_m_n0298(5)
    );
  exe_stage_alu_m_n00571_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0298(6),
      O => N6526
    );
  exe_stage_alu_m_n00571 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo3,
      ADR1 => exe_stage_alu_m_n0297(5),
      ADR2 => exe_stage_alu_m_n0055(5),
      O => exe_stage_alu_m_n0298(6)
    );
  exe_stage_alu_m_n00621_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0298(1),
      O => N6527
    );
  exe_stage_alu_m_n00621 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(2),
      ADR1 => exe_stage_alu_m_n0055(0),
      ADR2 => exe_stage_alu_m_alu_cyo3,
      O => exe_stage_alu_m_n0298(1)
    );
  exe_stage_alu_m_n00601_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0298(3),
      O => N6528
    );
  exe_stage_alu_m_n00601 : X_LUT3
    generic map(
      INIT => X"E2"
    )
    port map (
      ADR0 => exe_stage_alu_m_n0297(2),
      ADR1 => exe_stage_alu_m_alu_cyo3,
      ADR2 => exe_stage_alu_m_n0055(2),
      O => exe_stage_alu_m_n0298(3)
    );
  exe_stage_alu_m_n00491_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0297(5),
      O => N6529
    );
  exe_stage_alu_m_n00491 : X_LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      ADR0 => exe_stage_alu_m_alu_cyo,
      ADR1 => exe_stage_alu_m_n0296(4),
      ADR2 => exe_stage_alu_m_n0046(4),
      O => exe_stage_alu_m_n0297(5)
    );
  exe_stage_alu_m_n00531_LUT3_D_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0297(1),
      O => N6530
    );
  exe_stage_alu_m_n00531 : X_LUT3
    generic map(
      INIT => X"CA"
    )
    port map (
      ADR0 => exe_stage_src1(3),
      ADR1 => exe_stage_alu_m_n0046(0),
      ADR2 => exe_stage_alu_m_alu_cyo,
      O => exe_stage_alu_m_n0297(1)
    );
  exe_stage_alu_m_alu_n0019_6_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0019_6_lut_O,
      O => exe_stage_alu_m_N83
    );
  exe_stage_alu_m_alu_n0019_6_lut : X_LUT3
    generic map(
      INIT => X"95"
    )
    port map (
      ADR0 => exe_stage_src2(6),
      ADR1 => exe_stage_alu_m_n0010(5),
      ADR2 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_alu_n0019_6_lut_O
    );
  exe_stage_alu_m_alu_n0028_0_lut_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0028_0_lut_O,
      O => exe_stage_alu_m_N25
    );
  exe_stage_alu_m_alu_n0028_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(5),
      ADR3 => N78,
      O => exe_stage_alu_m_alu_n0028_0_lut_O
    );
  exe_stage_alu_m_alulut6_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alulut6_O,
      O => exe_stage_alu_m_N84
    );
  exe_stage_alu_m_alulut6 : X_LUT3
    generic map(
      INIT => X"95"
    )
    port map (
      ADR0 => exe_stage_src2(7),
      ADR1 => exe_stage_alu_m_alu_cyo5,
      ADR2 => exe_stage_alu_m_n0010(6),
      O => exe_stage_alu_m_alulut6_O
    );
  exe_stage_alu_m_alu_n0037_0_lut_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0037_0_lut_O,
      O => exe_stage_alu_m_N33
    );
  exe_stage_alu_m_alu_n0037_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(4),
      ADR3 => N78,
      O => exe_stage_alu_m_alu_n0037_0_lut_O
    );
  exe_stage_alu_m_alu_n0046_0_lut_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0046_0_lut_O,
      O => exe_stage_alu_m_N17
    );
  exe_stage_alu_m_alu_n0046_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(3),
      ADR3 => N78,
      O => exe_stage_alu_m_alu_n0046_0_lut_O
    );
  exe_stage_alu_m_n044243_G_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044243_G_O,
      O => N6451
    );
  exe_stage_alu_m_n044243_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12821,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0073(4),
      O => exe_stage_alu_m_n044243_G_O
    );
  exe_stage_alu_m_alu_n0010_1_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_1_lut_O,
      O => exe_stage_alu_m_N70
    );
  exe_stage_alu_m_alu_n0010_1_lut : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A_1_1,
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N80,
      O => exe_stage_alu_m_alu_n0010_1_lut_O
    );
  exe_stage_alu_m_alu_n0010_2_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_2_lut_O,
      O => exe_stage_alu_m_N71
    );
  exe_stage_alu_m_alu_n0010_2_lut : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(2),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N82,
      O => exe_stage_alu_m_alu_n0010_2_lut_O
    );
  exe_stage_alu_m_alu_n0010_3_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_3_lut_O,
      O => exe_stage_alu_m_N72
    );
  exe_stage_alu_m_alu_n0010_3_lut : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(3),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N84,
      O => exe_stage_alu_m_alu_n0010_3_lut_O
    );
  exe_stage_alu_m_alu_n0010_4_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_4_lut_O,
      O => exe_stage_alu_m_N73
    );
  exe_stage_alu_m_alu_n0010_4_lut : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A_4_1,
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N86,
      O => exe_stage_alu_m_alu_n0010_4_lut_O
    );
  exe_stage_alu_m_alu_n0010_5_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_5_lut_O,
      O => exe_stage_alu_m_N74
    );
  exe_stage_alu_m_alu_n0010_5_lut : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(5),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N88,
      O => exe_stage_alu_m_alu_n0010_5_lut_O
    );
  exe_stage_alu_m_alu_n0010_6_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_6_lut_O,
      O => exe_stage_alu_m_N75
    );
  exe_stage_alu_m_alu_n0010_6_lut : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(6),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N90,
      O => exe_stage_alu_m_alu_n0010_6_lut_O
    );
  exe_stage_alu_m_alu_n0010_0_lut_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0010_0_lut_O,
      O => exe_stage_alu_m_N69
    );
  exe_stage_alu_m_alu_n0010_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(7),
      ADR3 => N78,
      O => exe_stage_alu_m_alu_n0010_0_lut_O
    );
  exe_stage_alu_m_alulut5_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alulut5_O,
      O => exe_stage_alu_m_N76
    );
  exe_stage_alu_m_alulut5 : X_LUT3
    generic map(
      INIT => X"47"
    )
    port map (
      ADR0 => exwb_buff_out_R_A(7),
      ADR1 => exe_stage_Forwarder_m_n0005,
      ADR2 => N92,
      O => exe_stage_alu_m_alulut5_O
    );
  exe_stage_alu_m_alu_n0019_2_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0019_2_lut_O,
      O => exe_stage_alu_m_N79
    );
  exe_stage_alu_m_alu_n0019_2_lut : X_LUT3
    generic map(
      INIT => X"95"
    )
    port map (
      ADR0 => exe_stage_src2(2),
      ADR1 => exe_stage_alu_m_n0010(1),
      ADR2 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_alu_n0019_2_lut_O
    );
  exe_stage_alu_m_alu_n0019_3_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0019_3_lut_O,
      O => exe_stage_alu_m_N80
    );
  exe_stage_alu_m_alu_n0019_3_lut : X_LUT3
    generic map(
      INIT => X"95"
    )
    port map (
      ADR0 => exe_stage_src2(3),
      ADR1 => exe_stage_alu_m_n0010(2),
      ADR2 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_alu_n0019_3_lut_O
    );
  exe_stage_alu_m_alu_n0019_4_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0019_4_lut_O,
      O => exe_stage_alu_m_N81
    );
  exe_stage_alu_m_alu_n0019_4_lut : X_LUT3
    generic map(
      INIT => X"95"
    )
    port map (
      ADR0 => exe_stage_src2(4),
      ADR1 => exe_stage_alu_m_n0010(3),
      ADR2 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_alu_n0019_4_lut_O
    );
  exe_stage_alu_m_alu_n0019_5_lut_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0019_5_lut_O,
      O => exe_stage_alu_m_N82
    );
  exe_stage_alu_m_alu_n0019_5_lut : X_LUT3
    generic map(
      INIT => X"95"
    )
    port map (
      ADR0 => exe_stage_src2(5),
      ADR1 => exe_stage_alu_m_n0010(4),
      ADR2 => exe_stage_alu_m_alu_cyo5,
      O => exe_stage_alu_m_alu_n0019_5_lut_O
    );
  exe_stage_alu_m_alu_n0019_0_lut_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_alu_n0019_0_lut_O,
      O => exe_stage_alu_m_N77
    );
  exe_stage_alu_m_alu_n0019_0_lut : X_LUT4
    generic map(
      INIT => X"D287"
    )
    port map (
      ADR0 => exe_stage_Forwarder_m_n0005,
      ADR1 => exwb_buff_out_R_A(0),
      ADR2 => exe_stage_src1(6),
      ADR3 => N78,
      O => exe_stage_alu_m_alu_n0019_0_lut_O
    );
  exe_stage_alu_m_n043312_SW1_LUT3_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043312_SW1_O,
      O => N6135
    );
  exe_stage_alu_m_n043312_SW1 : X_LUT3
    generic map(
      INIT => X"13"
    )
    port map (
      ADR0 => exe_stage_alu_m_N821,
      ADR1 => CHOICE12710,
      ADR2 => exe_stage_alu_m_n0073(1),
      O => exe_stage_alu_m_n043312_SW1_O
    );
  exe_stage_alu_m_n044743_G_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044743_G_O,
      O => N6477
    );
  exe_stage_alu_m_n044743_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12849,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0073(6),
      O => exe_stage_alu_m_n044743_G_O
    );
  exe_stage_alu_m_n0454197_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n0454197_O,
      O => RA_out_from_execute(0)
    );
  exe_stage_alu_m_n0454197 : X_LUT4
    generic map(
      INIT => X"1B33"
    )
    port map (
      ADR0 => exe_stage_alu_m_XNor_stage_cyo7,
      ADR1 => N6158,
      ADR2 => N6159,
      ADR3 => exe_stage_alu_m_alu_n0073_7_cyo,
      O => exe_stage_alu_m_n0454197_O
    );
  exe_stage_alu_m_n044943_G_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044943_G_O,
      O => N6493
    );
  exe_stage_alu_m_n044943_G : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12863,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0073(7),
      O => exe_stage_alu_m_n044943_G_O
    );
  exe_stage_alu_m_n044543_F_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044543_F_O,
      O => N6422
    );
  exe_stage_alu_m_n044543_F : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12835,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0299(5),
      O => exe_stage_alu_m_n044543_F_O
    );
  exe_stage_alu_m_n043942_F_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043942_F_O,
      O => N6424
    );
  exe_stage_alu_m_n043942_F : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12807,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0299(3),
      O => exe_stage_alu_m_n043942_F_O
    );
  exe_stage_alu_m_n043642_F_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n043642_F_O,
      O => N6426
    );
  exe_stage_alu_m_n043642_F : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12793,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0299(2),
      O => exe_stage_alu_m_n043642_F_O
    );
  exe_stage_alu_m_n044243_F_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044243_F_O,
      O => N6450
    );
  exe_stage_alu_m_n044243_F : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12821,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0299(4),
      O => exe_stage_alu_m_n044243_F_O
    );
  exe_stage_alu_m_n044743_F_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044743_F_O,
      O => N6476
    );
  exe_stage_alu_m_n044743_F : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12849,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0299(6),
      O => exe_stage_alu_m_n044743_F_O
    );
  exe_stage_alu_m_n044943_F_LUT4_L_BUF : X_BUF
    port map (
      I => exe_stage_alu_m_n044943_F_O,
      O => N6492
    );
  exe_stage_alu_m_n044943_F : X_LUT4
    generic map(
      INIT => X"3222"
    )
    port map (
      ADR0 => CHOICE12863,
      ADR1 => Reset_IBUF,
      ADR2 => exe_stage_alu_m_N821,
      ADR3 => exe_stage_alu_m_n0299(7),
      O => exe_stage_alu_m_n044943_F_O
    );
  int0_IBUF_91 : X_BUF
    port map (
      I => int0,
      O => int0_IBUF
    );
  int1_IBUF_93 : X_BUF
    port map (
      I => int1,
      O => int1_IBUF
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_255_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net639
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_255_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_255_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_254_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net637
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_254_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_254_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_253_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net635
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_253_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_253_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_252_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net633
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_252_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_252_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_251_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net631
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_251_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_251_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_250_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net629
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_250_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_250_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_249_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net627
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_249_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_249_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_248_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net625
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_248_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_248_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_192_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net513
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_192_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_192_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_247_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net623
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_247_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_247_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_246_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net621
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_246_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_246_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_245_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net619
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_245_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_245_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_244_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net617
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_244_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_244_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_243_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net615
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_243_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_243_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_242_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net613
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_242_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_242_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_241_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net611
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_241_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_241_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_240_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net609
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_240_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_240_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_239_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net607
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_239_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_239_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_238_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net605
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_238_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_238_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_237_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net603
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_237_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_237_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_236_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net601
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_236_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_236_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_64_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net241
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_64_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_64_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_65_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net243
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_65_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_65_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_66_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net245
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_66_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_66_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_67_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net247
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_67_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_67_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_68_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net249
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_68_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_68_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_69_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net251
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_69_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_69_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_70_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net253
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_70_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_70_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_71_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net255
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_71_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_71_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_235_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net599
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_235_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_235_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_234_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net597
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_234_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_234_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_233_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net595
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_233_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_233_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_232_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net593
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_232_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_232_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_72_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net257
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_72_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_72_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_73_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net259
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_73_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_73_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_74_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net261
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_74_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_74_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_75_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net263
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_75_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_75_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_76_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net265
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_76_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_76_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_77_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net267
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_77_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_77_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_78_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net269
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_78_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_78_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_79_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net271
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_79_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_79_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_80_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net273
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_80_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_80_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_81_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net275
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_81_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_81_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_82_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net277
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_82_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_82_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_83_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net279
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_83_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_83_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_84_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net281
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_84_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_84_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_85_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net283
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_85_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_85_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_86_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net285
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_86_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_86_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_87_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net287
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_87_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_87_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_193_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net515
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_193_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_193_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_199_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net527
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_199_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_199_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_198_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net525
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_198_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_198_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_231_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net591
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_231_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_231_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_230_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net589
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_230_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_230_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_229_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net587
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_229_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_229_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_88_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net289
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_88_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_88_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_89_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net291
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_89_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_89_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_90_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net293
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_90_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_90_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_91_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net295
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_91_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_91_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_92_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net297
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_92_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_92_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_93_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net299
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_93_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_93_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_94_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net301
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_94_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_94_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_95_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net303
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_95_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_95_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_228_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net585
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_228_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_228_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_227_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net583
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_227_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_227_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_226_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net581
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_226_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_226_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_225_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net579
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_225_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_225_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_224_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net577
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_224_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_224_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_96_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net305
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_96_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_96_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_97_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net307
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_97_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_97_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_98_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net309
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_98_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_98_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_99_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net311
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_99_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_99_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_100_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net313
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_100_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_100_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_101_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net315
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_101_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_101_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_102_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net317
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_102_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_102_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_103_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net319
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_103_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(4),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_103_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_197_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net523
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_197_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_197_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_196_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net521
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_196_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_196_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_104_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net321
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_104_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_104_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_105_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net323
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_105_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_105_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_106_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net325
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_106_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_106_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_107_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net327
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_107_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_107_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_108_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net329
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_108_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_108_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_109_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net331
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_109_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_109_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_110_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net333
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_110_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_110_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_111_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net335
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_111_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(5),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_111_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_195_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net519
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_195_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_195_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_194_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net517
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_194_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(0),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_194_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_223_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net575
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_223_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_223_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_222_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net573
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_222_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_222_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_112_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net337
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_112_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_112_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_113_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net339
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_113_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_113_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_114_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net341
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_114_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_114_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_115_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net343
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_115_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_115_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_116_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net345
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_116_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_116_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_117_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net347
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_117_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_117_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_118_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net349
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_118_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_118_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_119_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net351
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_119_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(6),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_119_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_221_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net571
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_221_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_221_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_220_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net569
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_220_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_220_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_219_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net567
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_219_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_219_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_218_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net565
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_218_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_218_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_217_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net563
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_217_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_217_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_216_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net561
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_216_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(3),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_216_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_120_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_net353
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_120_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_9,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_120_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_121_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_net355
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_121_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_10,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_121_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_122_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_net357
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_122_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_11,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_122_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_123_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_net359
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_123_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_12,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_123_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_124_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_net361
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_124_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_13,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_124_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_125_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_net363
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_125_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_14,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_125_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_126_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_net365
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_126_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_15,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_126_SPO
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_127_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b0(1),
      WADR1 => mem_w_addr_b0(2),
      WADR2 => mem_w_addr_b0(3),
      WADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_net367
    );
  mem_internal_ram_bank_Mram_iram0_inst_ramx_127_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b0(1),
      ADR1 => mem_w_addr_b0(2),
      ADR2 => mem_w_addr_b0(3),
      ADR3 => mem_w_addr_b0(4),
      I => mem_d_in0(7),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram0_inst_lut2_16,
      O => mem_internal_ram_bank_Mram_iram0_inst_ramx_127_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_215_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net559
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_215_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_215_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_214_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net557
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_214_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_214_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_213_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net555
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_213_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_213_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_212_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net553
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_212_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_212_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_211_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net551
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_211_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_211_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_210_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net549
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_210_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_210_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_209_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net547
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_209_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_209_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_208_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net545
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_208_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(2),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_208_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_207_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_net543
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_207_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_32,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_207_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_206_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_net541
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_206_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_31,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_206_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_205_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_net539
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_205_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_30,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_205_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_204_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_net537
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_204_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_29,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_204_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_203_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_net535
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_203_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_28,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_203_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_202_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_net533
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_202_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_27,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_202_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_201_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_net531
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_201_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_26,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_201_SPO
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_200_X_RAMD16 : X_RAMD16
    generic map(
      INIT => X"0000"
    )
    port map (
      RADR0 => mem_r_addr_b0_1_Q,
      RADR1 => mem_r_addr_b0_2_Q,
      RADR2 => mem_r_addr_b0_3_Q,
      RADR3 => mem_r_addr_b0_4_Q,
      WADR0 => mem_w_addr_b1(1),
      WADR1 => mem_w_addr_b1(2),
      WADR2 => mem_w_addr_b1(3),
      WADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_net529
    );
  mem_internal_ram_bank_Mram_iram1_inst_ramx_200_X_RAMS16 : X_RAMS16
    generic map(
      INIT => X"0000"
    )
    port map (
      ADR0 => mem_w_addr_b1(1),
      ADR1 => mem_w_addr_b1(2),
      ADR2 => mem_w_addr_b1(3),
      ADR3 => mem_w_addr_b1(4),
      I => mem_d_in1(1),
      CLK => Clock_BUFGP,
      WE => mem_internal_ram_bank_Mram_iram1_inst_lut2_25,
      O => mem_internal_ram_bank_Mram_iram1_inst_ramx_200_SPO
    );
  Clock_BUFGP_BUFG : X_CKBUF
    port map (
      I => Clock_BUFGP_IBUFG,
      O => Clock_BUFGP
    );
  Clock_BUFGP_IBUFG_94 : X_CKBUF
    port map (
      I => Clock,
      O => Clock_BUFGP_IBUFG
    );
  exwb_buff_out_D11_5_GSR_OR_95 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_5_GSR_OR
    );
  idex_buff_out_Opcode_3_GSR_OR_96 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_Opcode_3_GSR_OR
    );
  fet_stage_PC_M_data_out_13_GSR_OR_97 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_13_GSR_OR
    );
  fet_stage_PC_M_data_out_4_GSR_OR_98 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_4_GSR_OR
    );
  fet_stage_PC_M_data_out_6_GSR_OR_99 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_6_GSR_OR
    );
  fet_stage_PC_M_data_out_14_GSR_OR_100 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_14_GSR_OR
    );
  fet_stage_PC_M_data_out_12_GSR_OR_101 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_12_GSR_OR
    );
  fet_stage_PC_M_data_out_11_GSR_OR_102 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_11_GSR_OR
    );
  fet_stage_PC_M_data_out_5_GSR_OR_103 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_5_GSR_OR
    );
  fet_stage_PC_M_data_out_3_GSR_OR_104 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_3_GSR_OR
    );
  ifid_buff_out1_7_GSR_OR_105 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_7_GSR_OR
    );
  ifid_buff_out1_0_GSR_OR_106 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_0_GSR_OR
    );
  ifid_buff_out1_1_GSR_OR_107 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_1_GSR_OR
    );
  ifid_buff_out1_2_GSR_OR_108 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_2_GSR_OR
    );
  ifid_buff_out1_3_GSR_OR_109 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_3_GSR_OR
    );
  ifid_buff_out1_4_GSR_OR_110 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_4_GSR_OR
    );
  ifid_buff_out1_5_GSR_OR_111 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_5_GSR_OR
    );
  ifid_buff_out1_6_GSR_OR_112 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => ifid_buff_out1_6_GSR_OR
    );
  idex_buff_out_A_7_GSR_OR_113 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_7_GSR_OR
    );
  idex_buff_out_B_7_GSR_OR_114 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_7_GSR_OR
    );
  idex_buff_out_Opcode_4_GSR_OR_115 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_Opcode_4_GSR_OR
    );
  idex_buff_out_d1_7_GSR_OR_116 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_7_GSR_OR
    );
  idex_buff_out_d2_7_GSR_OR_117 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_7_GSR_OR
    );
  idex_buff_out_sel_mux11_1_GSR_OR_118 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_sel_mux11_1_GSR_OR
    );
  idex_buff_out_en_1_GSR_OR_119 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_en_1_GSR_OR
    );
  idex_buff_out_s1_7_GSR_OR_120 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_7_GSR_OR
    );
  idex_buff_out_s2_7_GSR_OR_121 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_7_GSR_OR
    );
  idex_buff_out_en_0_GSR_OR_122 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_en_0_GSR_OR
    );
  idex_buff_out_s2_0_GSR_OR_123 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_0_GSR_OR
    );
  idex_buff_out_s2_1_GSR_OR_124 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_1_GSR_OR
    );
  idex_buff_out_s2_2_GSR_OR_125 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_2_GSR_OR
    );
  idex_buff_out_s2_3_GSR_OR_126 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_3_GSR_OR
    );
  idex_buff_out_s2_4_GSR_OR_127 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_4_GSR_OR
    );
  idex_buff_out_s2_5_GSR_OR_128 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_5_GSR_OR
    );
  idex_buff_out_s2_6_GSR_OR_129 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s2_6_GSR_OR
    );
  idex_buff_out_s1_0_GSR_OR_130 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_0_GSR_OR
    );
  idex_buff_out_s1_1_GSR_OR_131 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_1_GSR_OR
    );
  idex_buff_out_s1_2_GSR_OR_132 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_2_GSR_OR
    );
  idex_buff_out_s1_3_GSR_OR_133 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_3_GSR_OR
    );
  idex_buff_out_s1_4_GSR_OR_134 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_4_GSR_OR
    );
  idex_buff_out_s1_5_GSR_OR_135 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_5_GSR_OR
    );
  idex_buff_out_s1_6_GSR_OR_136 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_s1_6_GSR_OR
    );
  idex_buff_out_d2_0_GSR_OR_137 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_0_GSR_OR
    );
  idex_buff_out_d2_1_GSR_OR_138 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_1_GSR_OR
    );
  idex_buff_out_d2_2_GSR_OR_139 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_2_GSR_OR
    );
  idex_buff_out_d2_3_GSR_OR_140 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_3_GSR_OR
    );
  idex_buff_out_d2_4_GSR_OR_141 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_4_GSR_OR
    );
  idex_buff_out_d2_5_GSR_OR_142 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_5_GSR_OR
    );
  idex_buff_out_d2_6_GSR_OR_143 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d2_6_GSR_OR
    );
  idex_buff_out_d1_0_GSR_OR_144 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_0_GSR_OR
    );
  idex_buff_out_d1_1_GSR_OR_145 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_1_GSR_OR
    );
  idex_buff_out_d1_2_GSR_OR_146 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_2_GSR_OR
    );
  idex_buff_out_d1_3_GSR_OR_147 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_3_GSR_OR
    );
  idex_buff_out_d1_4_GSR_OR_148 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_4_GSR_OR
    );
  idex_buff_out_d1_5_GSR_OR_149 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_5_GSR_OR
    );
  idex_buff_out_d1_6_GSR_OR_150 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_d1_6_GSR_OR
    );
  idex_buff_out_B_0_GSR_OR_151 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_0_GSR_OR
    );
  idex_buff_out_B_1_GSR_OR_152 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_1_GSR_OR
    );
  idex_buff_out_B_2_GSR_OR_153 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_2_GSR_OR
    );
  idex_buff_out_B_3_GSR_OR_154 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_3_GSR_OR
    );
  idex_buff_out_B_4_GSR_OR_155 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_4_GSR_OR
    );
  idex_buff_out_B_5_GSR_OR_156 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_5_GSR_OR
    );
  idex_buff_out_B_6_GSR_OR_157 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_B_6_GSR_OR
    );
  idex_buff_out_A_0_GSR_OR_158 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_0_GSR_OR
    );
  idex_buff_out_A_1_GSR_OR_159 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_1_GSR_OR
    );
  idex_buff_out_A_2_GSR_OR_160 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_2_GSR_OR
    );
  idex_buff_out_A_3_GSR_OR_161 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_3_GSR_OR
    );
  idex_buff_out_A_4_GSR_OR_162 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_4_GSR_OR
    );
  idex_buff_out_A_5_GSR_OR_163 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_5_GSR_OR
    );
  idex_buff_out_A_6_GSR_OR_164 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_A_6_GSR_OR
    );
  idex_buff_out_Opcode_0_GSR_OR_165 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_Opcode_0_GSR_OR
    );
  idex_buff_out_Opcode_1_GSR_OR_166 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_Opcode_1_GSR_OR
    );
  idex_buff_out_Opcode_2_GSR_OR_167 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => idex_buff_out_Opcode_2_GSR_OR
    );
  fet_stage_PC_M_data_out_7_GSR_OR_168 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_7_GSR_OR
    );
  fet_stage_PC_M_data_out_10_GSR_OR_169 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_10_GSR_OR
    );
  fet_stage_PC_M_data_out_9_GSR_OR_170 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_9_GSR_OR
    );
  fet_stage_PC_M_data_out_8_GSR_OR_171 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_8_GSR_OR
    );
  fet_stage_PC_M_data_out_15_GSR_OR_172 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_15_GSR_OR
    );
  fet_stage_PC_M_data_out_0_GSR_OR_173 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_0_GSR_OR
    );
  fet_stage_PC_M_data_out_1_GSR_OR_174 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_1_GSR_OR
    );
  fet_stage_PC_M_data_out_2_GSR_OR_175 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_PC_M_data_out_2_GSR_OR
    );
  exwb_buff_out_R_B_1_GSR_OR_176 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_1_GSR_OR
    );
  mem_PSW_psw_2_GSR_OR_177 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_2_GSR_OR
    );
  mem_R_P3_data_out_6_GSR_OR_178 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_6_GSR_OR
    );
  mem_R_A_data_out_6_GSR_OR_179 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_6_GSR_OR
    );
  mem_R_B_data_out_6_GSR_OR_180 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_6_GSR_OR
    );
  mem_R_DPH_data_out_6_GSR_OR_181 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_6_GSR_OR
    );
  mem_R_DPL_data_out_6_GSR_OR_182 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_6_GSR_OR
    );
  mem_R_P0_data_out_6_GSR_OR_183 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_6_GSR_OR
    );
  mem_R_P1_data_out_6_GSR_OR_184 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_6_GSR_OR
    );
  mem_R_P2_data_out_6_GSR_OR_185 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_6_GSR_OR
    );
  exwb_buff_out_D11_4_GSR_OR_186 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_4_GSR_OR
    );
  mem_PSW_psw_1_GSR_OR_187 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_1_GSR_OR
    );
  mem_PSW_psw_0_GSR_OR_188 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_0_GSR_OR
    );
  mem_PSW_psw_7_GSR_OR_189 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_7_GSR_OR
    );
  mem_PSW_psw_6_GSR_OR_190 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_6_GSR_OR
    );
  mem_PSW_psw_5_GSR_OR_191 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_5_GSR_OR
    );
  mem_PSW_psw_4_GSR_OR_192 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_4_GSR_OR
    );
  mem_PSW_psw_3_GSR_OR_193 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_PSW_psw_3_GSR_OR
    );
  mem_R_P3_data_out_7_GSR_OR_194 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_7_GSR_OR
    );
  mem_R_P3_port_out_7_GSR_OR_195 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_7_GSR_OR
    );
  mem_R_P3_port_out_0_GSR_OR_196 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_0_GSR_OR
    );
  mem_R_P3_port_out_1_GSR_OR_197 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_1_GSR_OR
    );
  mem_R_P3_port_out_2_GSR_OR_198 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_2_GSR_OR
    );
  mem_R_P3_port_out_3_GSR_OR_199 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_3_GSR_OR
    );
  mem_R_P3_port_out_4_GSR_OR_200 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_4_GSR_OR
    );
  mem_R_P3_port_out_5_GSR_OR_201 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_5_GSR_OR
    );
  mem_R_P3_port_out_6_GSR_OR_202 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_port_out_6_GSR_OR
    );
  mem_R_P3_data_out_0_GSR_OR_203 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_0_GSR_OR
    );
  mem_R_P3_data_out_1_GSR_OR_204 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_1_GSR_OR
    );
  mem_R_P3_data_out_2_GSR_OR_205 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_2_GSR_OR
    );
  mem_R_P3_data_out_3_GSR_OR_206 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_3_GSR_OR
    );
  mem_R_P3_data_out_4_GSR_OR_207 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_4_GSR_OR
    );
  mem_R_P3_data_out_5_GSR_OR_208 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P3_data_out_5_GSR_OR
    );
  mem_R_P2_data_out_7_GSR_OR_209 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_7_GSR_OR
    );
  mem_R_P2_port_out_7_GSR_OR_210 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_7_GSR_OR
    );
  mem_R_P2_port_out_0_GSR_OR_211 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_0_GSR_OR
    );
  mem_R_P2_port_out_1_GSR_OR_212 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_1_GSR_OR
    );
  mem_R_P2_port_out_2_GSR_OR_213 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_2_GSR_OR
    );
  mem_R_P2_port_out_3_GSR_OR_214 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_3_GSR_OR
    );
  mem_R_P2_port_out_4_GSR_OR_215 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_4_GSR_OR
    );
  mem_R_P2_port_out_5_GSR_OR_216 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_5_GSR_OR
    );
  mem_R_P2_port_out_6_GSR_OR_217 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_port_out_6_GSR_OR
    );
  mem_R_P2_data_out_0_GSR_OR_218 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_0_GSR_OR
    );
  mem_R_P2_data_out_1_GSR_OR_219 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_1_GSR_OR
    );
  mem_R_P2_data_out_2_GSR_OR_220 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_2_GSR_OR
    );
  mem_R_P2_data_out_3_GSR_OR_221 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_3_GSR_OR
    );
  mem_R_P2_data_out_4_GSR_OR_222 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_4_GSR_OR
    );
  mem_R_P2_data_out_5_GSR_OR_223 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P2_data_out_5_GSR_OR
    );
  mem_R_P1_data_out_7_GSR_OR_224 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_7_GSR_OR
    );
  mem_R_P1_port_out_7_GSR_OR_225 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_7_GSR_OR
    );
  mem_R_P1_port_out_0_GSR_OR_226 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_0_GSR_OR
    );
  mem_R_P1_port_out_1_GSR_OR_227 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_1_GSR_OR
    );
  mem_R_P1_port_out_2_GSR_OR_228 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_2_GSR_OR
    );
  mem_R_P1_port_out_3_GSR_OR_229 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_3_GSR_OR
    );
  mem_R_P1_port_out_4_GSR_OR_230 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_4_GSR_OR
    );
  mem_R_P1_port_out_5_GSR_OR_231 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_5_GSR_OR
    );
  mem_R_P1_port_out_6_GSR_OR_232 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_port_out_6_GSR_OR
    );
  mem_R_P1_data_out_0_GSR_OR_233 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_0_GSR_OR
    );
  mem_R_P1_data_out_1_GSR_OR_234 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_1_GSR_OR
    );
  mem_R_P1_data_out_2_GSR_OR_235 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_2_GSR_OR
    );
  mem_R_P1_data_out_3_GSR_OR_236 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_3_GSR_OR
    );
  mem_R_P1_data_out_4_GSR_OR_237 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_4_GSR_OR
    );
  mem_R_P1_data_out_5_GSR_OR_238 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P1_data_out_5_GSR_OR
    );
  mem_R_P0_data_out_7_GSR_OR_239 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_7_GSR_OR
    );
  mem_R_P0_port_out_7_GSR_OR_240 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_7_GSR_OR
    );
  mem_R_P0_port_out_0_GSR_OR_241 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_0_GSR_OR
    );
  mem_R_P0_port_out_1_GSR_OR_242 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_1_GSR_OR
    );
  mem_R_P0_port_out_2_GSR_OR_243 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_2_GSR_OR
    );
  mem_R_P0_port_out_3_GSR_OR_244 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_3_GSR_OR
    );
  mem_R_P0_port_out_4_GSR_OR_245 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_4_GSR_OR
    );
  mem_R_P0_port_out_5_GSR_OR_246 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_5_GSR_OR
    );
  mem_R_P0_port_out_6_GSR_OR_247 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_port_out_6_GSR_OR
    );
  mem_R_P0_data_out_0_GSR_OR_248 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_0_GSR_OR
    );
  mem_R_P0_data_out_1_GSR_OR_249 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_1_GSR_OR
    );
  mem_R_P0_data_out_2_GSR_OR_250 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_2_GSR_OR
    );
  mem_R_P0_data_out_3_GSR_OR_251 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_3_GSR_OR
    );
  mem_R_P0_data_out_4_GSR_OR_252 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_4_GSR_OR
    );
  mem_R_P0_data_out_5_GSR_OR_253 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_P0_data_out_5_GSR_OR
    );
  mem_R_DPL_data_out_7_GSR_OR_254 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_7_GSR_OR
    );
  mem_R_DPL_data_out_0_GSR_OR_255 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_0_GSR_OR
    );
  mem_R_DPL_data_out_1_GSR_OR_256 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_1_GSR_OR
    );
  mem_R_DPL_data_out_2_GSR_OR_257 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_2_GSR_OR
    );
  mem_R_DPL_data_out_3_GSR_OR_258 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_3_GSR_OR
    );
  mem_R_DPL_data_out_4_GSR_OR_259 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_4_GSR_OR
    );
  mem_R_DPL_data_out_5_GSR_OR_260 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPL_data_out_5_GSR_OR
    );
  mem_R_DPH_data_out_7_GSR_OR_261 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_7_GSR_OR
    );
  mem_R_DPH_data_out_0_GSR_OR_262 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_0_GSR_OR
    );
  mem_R_DPH_data_out_1_GSR_OR_263 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_1_GSR_OR
    );
  mem_R_DPH_data_out_2_GSR_OR_264 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_2_GSR_OR
    );
  mem_R_DPH_data_out_3_GSR_OR_265 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_3_GSR_OR
    );
  mem_R_DPH_data_out_4_GSR_OR_266 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_4_GSR_OR
    );
  mem_R_DPH_data_out_5_GSR_OR_267 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_DPH_data_out_5_GSR_OR
    );
  mem_R_B_data_out_7_GSR_OR_268 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_7_GSR_OR
    );
  mem_R_B_data_out_0_GSR_OR_269 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_0_GSR_OR
    );
  mem_R_B_data_out_1_GSR_OR_270 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_1_GSR_OR
    );
  mem_R_B_data_out_2_GSR_OR_271 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_2_GSR_OR
    );
  mem_R_B_data_out_3_GSR_OR_272 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_3_GSR_OR
    );
  mem_R_B_data_out_4_GSR_OR_273 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_4_GSR_OR
    );
  mem_R_B_data_out_5_GSR_OR_274 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_B_data_out_5_GSR_OR
    );
  mem_R_A_data_out_7_GSR_OR_275 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_7_GSR_OR
    );
  mem_R_A_data_out_0_GSR_OR_276 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_0_GSR_OR
    );
  mem_R_A_data_out_1_GSR_OR_277 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_1_GSR_OR
    );
  mem_R_A_data_out_2_GSR_OR_278 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_2_GSR_OR
    );
  mem_R_A_data_out_3_GSR_OR_279 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_3_GSR_OR
    );
  mem_R_A_data_out_4_GSR_OR_280 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_4_GSR_OR
    );
  mem_R_A_data_out_5_GSR_OR_281 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => mem_R_A_data_out_5_GSR_OR
    );
  exwb_buff_out_R_B_2_GSR_OR_282 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_2_GSR_OR
    );
  exwb_buff_out_D11_3_GSR_OR_283 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_3_GSR_OR
    );
  exwb_buff_out_D11_1_GSR_OR_284 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_1_GSR_OR
    );
  exwb_buff_out_D11_0_GSR_OR_285 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_0_GSR_OR
    );
  exwb_buff_out_D11_2_GSR_OR_286 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_2_GSR_OR
    );
  exwb_buff_out_D22_6_GSR_OR_287 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_6_GSR_OR
    );
  rom_DATA_BUS_6_GSR_OR_288 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_6_GSR_OR
    );
  rom_DATA_BUS_5_GSR_OR_289 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_5_GSR_OR
    );
  rom_DATA_BUS_3_GSR_OR_290 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_3_GSR_OR
    );
  rom_DATA_BUS_2_GSR_OR_291 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_2_GSR_OR
    );
  rom_DATA_BUS_4_GSR_OR_292 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_4_GSR_OR
    );
  rom_DATA_BUS_1_GSR_OR_293 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_1_GSR_OR
    );
  rom_DATA_BUS_0_GSR_OR_294 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_0_GSR_OR
    );
  rom_DATA_BUS_7_GSR_OR_295 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => rom_DATA_BUS_7_GSR_OR
    );
  exwb_buff_out_D22_3_GSR_OR_296 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_3_GSR_OR
    );
  exwb_buff_out_D22_2_GSR_OR_297 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_2_GSR_OR
    );
  exwb_buff_out_D22_0_GSR_OR_298 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_0_GSR_OR
    );
  exwb_buff_out_R_A_6_GSR_OR_299 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_6_GSR_OR
    );
  exwb_buff_out_R_A_3_GSR_OR_300 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_3_GSR_OR
    );
  exwb_buff_out_R_A_2_GSR_OR_301 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_2_GSR_OR
    );
  exwb_buff_out_R_A_0_GSR_OR_302 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_0_GSR_OR
    );
  exwb_buff_out_R_B_6_GSR_OR_303 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_6_GSR_OR
    );
  exwb_buff_out_D22_5_GSR_OR_304 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_5_GSR_OR
    );
  exwb_buff_out_D22_4_GSR_OR_305 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_4_GSR_OR
    );
  exwb_buff_out_en_0_GSR_OR_306 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_en_0_GSR_OR
    );
  exwb_buff_out_D22_1_GSR_OR_307 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_1_GSR_OR
    );
  exwb_buff_out_R_A_5_GSR_OR_308 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_5_GSR_OR
    );
  exwb_buff_out_R_A_1_GSR_OR_309 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_1_GSR_OR
    );
  exwb_buff_out_R_B_5_GSR_OR_310 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_5_GSR_OR
    );
  exwb_buff_out_R_A_4_GSR_OR_311 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_4_GSR_OR
    );
  exwb_buff_out_R_B_4_GSR_OR_312 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_4_GSR_OR
    );
  exwb_buff_out_R_B_3_GSR_OR_313 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_3_GSR_OR
    );
  exwb_buff_out_R_B_7_GSR_OR_314 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_7_GSR_OR
    );
  exwb_buff_out_en_1_GSR_OR_315 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_en_1_GSR_OR
    );
  exwb_buff_out_D22_5_1_GSR_OR_316 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_5_1_GSR_OR
    );
  exwb_buff_out_D11_0_1_GSR_OR_317 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_0_1_GSR_OR
    );
  exwb_buff_out_R_A_7_GSR_OR_318 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_7_GSR_OR
    );
  exwb_buff_out_R_B_0_GSR_OR_319 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_B_0_GSR_OR
    );
  exwb_buff_out_D22_7_GSR_OR_320 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_7_GSR_OR
    );
  exwb_buff_out_D11_6_GSR_OR_321 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_6_GSR_OR
    );
  exwb_buff_out_sel_mux11_1_GSR_OR_322 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_sel_mux11_1_GSR_OR
    );
  exwb_buff_out_D11_7_GSR_OR_323 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_7_GSR_OR
    );
  exwb_buff_out_D11_6_1_GSR_OR_324 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_6_1_GSR_OR
    );
  fet_stage_que_state_M_out1_7_GSR_OR_325 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_7_GSR_OR
    );
  fet_stage_que_state_M_out1_1_GSR_OR_326 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_1_GSR_OR
    );
  fet_stage_que_state_M_out1_6_GSR_OR_327 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_6_GSR_OR
    );
  fet_stage_que_state_M_out1_4_GSR_OR_328 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_4_GSR_OR
    );
  fet_stage_que_state_M_out1_2_GSR_OR_329 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_2_GSR_OR
    );
  fet_stage_que_state_M_out1_3_GSR_OR_330 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_3_GSR_OR
    );
  fet_stage_que_state_M_out1_5_GSR_OR_331 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_5_GSR_OR
    );
  fet_stage_que_state_M_out1_0_GSR_OR_332 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => fet_stage_que_state_M_out1_0_GSR_OR
    );
  exwb_buff_out_D22_6_1_GSR_OR_333 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_6_1_GSR_OR
    );
  exwb_buff_out_R_A_4_1_GSR_OR_334 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_4_1_GSR_OR
    );
  exwb_buff_out_D22_0_1_GSR_OR_335 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_0_1_GSR_OR
    );
  exwb_buff_out_D11_5_1_GSR_OR_336 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D11_5_1_GSR_OR
    );
  exwb_buff_out_D22_4_1_GSR_OR_337 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_D22_4_1_GSR_OR
    );
  exwb_buff_out_R_A_1_1_GSR_OR_338 : X_OR2
    port map (
      I0 => Reset_IBUF,
      I1 => GSR,
      O => exwb_buff_out_R_A_1_1_GSR_OR
    );
  port3_out_1_OBUF_GTS_TRI_339 : X_TRI
    port map (
      I => port3_out_1_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_1_OBUF_GTS_TRI_CTL,
      O => port3_out(1)
    );
  port2_out_0_OBUF_GTS_TRI_340 : X_TRI
    port map (
      I => port2_out_0_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_0_OBUF_GTS_TRI_CTL,
      O => port2_out(0)
    );
  port2_out_3_OBUF_GTS_TRI_341 : X_TRI
    port map (
      I => port2_out_3_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_3_OBUF_GTS_TRI_CTL,
      O => port2_out(3)
    );
  port2_out_4_OBUF_GTS_TRI_342 : X_TRI
    port map (
      I => port2_out_4_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_4_OBUF_GTS_TRI_CTL,
      O => port2_out(4)
    );
  port2_out_5_OBUF_GTS_TRI_343 : X_TRI
    port map (
      I => port2_out_5_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_5_OBUF_GTS_TRI_CTL,
      O => port2_out(5)
    );
  port2_out_6_OBUF_GTS_TRI_344 : X_TRI
    port map (
      I => port2_out_6_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_6_OBUF_GTS_TRI_CTL,
      O => port2_out(6)
    );
  port3_out_4_OBUF_GTS_TRI_345 : X_TRI
    port map (
      I => port3_out_4_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_4_OBUF_GTS_TRI_CTL,
      O => port3_out(4)
    );
  port2_out_7_OBUF_GTS_TRI_346 : X_TRI
    port map (
      I => port2_out_7_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_7_OBUF_GTS_TRI_CTL,
      O => port2_out(7)
    );
  port1_out_0_OBUF_GTS_TRI_347 : X_TRI
    port map (
      I => port1_out_0_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_0_OBUF_GTS_TRI_CTL,
      O => port1_out(0)
    );
  port3_out_6_OBUF_GTS_TRI_348 : X_TRI
    port map (
      I => port3_out_6_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_6_OBUF_GTS_TRI_CTL,
      O => port3_out(6)
    );
  port1_out_1_OBUF_GTS_TRI_349 : X_TRI
    port map (
      I => port1_out_1_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_1_OBUF_GTS_TRI_CTL,
      O => port1_out(1)
    );
  port3_out_7_OBUF_GTS_TRI_350 : X_TRI
    port map (
      I => port3_out_7_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_7_OBUF_GTS_TRI_CTL,
      O => port3_out(7)
    );
  port1_out_2_OBUF_GTS_TRI_351 : X_TRI
    port map (
      I => port1_out_2_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_2_OBUF_GTS_TRI_CTL,
      O => port1_out(2)
    );
  port2_out_1_OBUF_GTS_TRI_352 : X_TRI
    port map (
      I => port2_out_1_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_1_OBUF_GTS_TRI_CTL,
      O => port2_out(1)
    );
  port1_out_3_OBUF_GTS_TRI_353 : X_TRI
    port map (
      I => port1_out_3_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_3_OBUF_GTS_TRI_CTL,
      O => port1_out(3)
    );
  port2_out_2_OBUF_GTS_TRI_354 : X_TRI
    port map (
      I => port2_out_2_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port2_out_2_OBUF_GTS_TRI_CTL,
      O => port2_out(2)
    );
  port3_out_5_OBUF_GTS_TRI_355 : X_TRI
    port map (
      I => port3_out_5_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_5_OBUF_GTS_TRI_CTL,
      O => port3_out(5)
    );
  port0_out_4_OBUF_GTS_TRI_356 : X_TRI
    port map (
      I => port0_out_4_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_4_OBUF_GTS_TRI_CTL,
      O => port0_out(4)
    );
  port3_out_2_OBUF_GTS_TRI_357 : X_TRI
    port map (
      I => port3_out_2_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_2_OBUF_GTS_TRI_CTL,
      O => port3_out(2)
    );
  port0_out_5_OBUF_GTS_TRI_358 : X_TRI
    port map (
      I => port0_out_5_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_5_OBUF_GTS_TRI_CTL,
      O => port0_out(5)
    );
  port3_out_0_OBUF_GTS_TRI_359 : X_TRI
    port map (
      I => port3_out_0_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_0_OBUF_GTS_TRI_CTL,
      O => port3_out(0)
    );
  port0_out_6_OBUF_GTS_TRI_360 : X_TRI
    port map (
      I => port0_out_6_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_6_OBUF_GTS_TRI_CTL,
      O => port0_out(6)
    );
  port0_out_3_OBUF_GTS_TRI_361 : X_TRI
    port map (
      I => port0_out_3_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_3_OBUF_GTS_TRI_CTL,
      O => port0_out(3)
    );
  port0_out_2_OBUF_GTS_TRI_362 : X_TRI
    port map (
      I => port0_out_2_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_2_OBUF_GTS_TRI_CTL,
      O => port0_out(2)
    );
  port1_out_5_OBUF_GTS_TRI_363 : X_TRI
    port map (
      I => port1_out_5_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_5_OBUF_GTS_TRI_CTL,
      O => port1_out(5)
    );
  port1_out_4_OBUF_GTS_TRI_364 : X_TRI
    port map (
      I => port1_out_4_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_4_OBUF_GTS_TRI_CTL,
      O => port1_out(4)
    );
  port0_out_7_OBUF_GTS_TRI_365 : X_TRI
    port map (
      I => port0_out_7_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_7_OBUF_GTS_TRI_CTL,
      O => port0_out(7)
    );
  port0_out_0_OBUF_GTS_TRI_366 : X_TRI
    port map (
      I => port0_out_0_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_0_OBUF_GTS_TRI_CTL,
      O => port0_out(0)
    );
  port0_out_1_OBUF_GTS_TRI_367 : X_TRI
    port map (
      I => port0_out_1_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port0_out_1_OBUF_GTS_TRI_CTL,
      O => port0_out(1)
    );
  port1_out_6_OBUF_GTS_TRI_368 : X_TRI
    port map (
      I => port1_out_6_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_6_OBUF_GTS_TRI_CTL,
      O => port1_out(6)
    );
  port1_out_7_OBUF_GTS_TRI_369 : X_TRI
    port map (
      I => port1_out_7_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port1_out_7_OBUF_GTS_TRI_CTL,
      O => port1_out(7)
    );
  port3_out_3_OBUF_GTS_TRI_370 : X_TRI
    port map (
      I => port3_out_3_OBUF_GTS_TRI,
      CTL => NlwInverterSignal_port3_out_3_OBUF_GTS_TRI_CTL,
      O => port3_out(3)
    );
  NlwBlock_datapath_VCC : X_ONE
    port map (
      O => VCC
    );
  NlwBlock_datapath_GND : X_ZERO
    port map (
      O => GND
    );
  NlwInverterBlock_mem_R_A_data_out_6_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_6_C
    );
  NlwInverterBlock_mem_R_B_data_out_6_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_6_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_6_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_6_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_6_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_6_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_7_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_7_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_0_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_0_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_1_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_1_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_2_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_2_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_3_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_3_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_4_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_4_C
    );
  NlwInverterBlock_mem_R_DPL_data_out_5_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPL_data_out_5_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_7_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_7_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_0_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_0_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_1_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_1_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_2_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_2_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_3_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_3_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_4_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_4_C
    );
  NlwInverterBlock_mem_R_DPH_data_out_5_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_DPH_data_out_5_C
    );
  NlwInverterBlock_mem_R_B_data_out_7_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_7_C
    );
  NlwInverterBlock_mem_R_B_data_out_0_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_0_C
    );
  NlwInverterBlock_mem_R_B_data_out_1_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_1_C
    );
  NlwInverterBlock_mem_R_B_data_out_2_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_2_C
    );
  NlwInverterBlock_mem_R_B_data_out_3_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_3_C
    );
  NlwInverterBlock_mem_R_B_data_out_4_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_4_C
    );
  NlwInverterBlock_mem_R_B_data_out_5_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_B_data_out_5_C
    );
  NlwInverterBlock_mem_R_A_data_out_7_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_7_C
    );
  NlwInverterBlock_mem_R_A_data_out_0_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_0_C
    );
  NlwInverterBlock_mem_R_A_data_out_1_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_1_C
    );
  NlwInverterBlock_mem_R_A_data_out_2_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_2_C
    );
  NlwInverterBlock_mem_R_A_data_out_3_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_3_C
    );
  NlwInverterBlock_mem_R_A_data_out_4_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_4_C
    );
  NlwInverterBlock_mem_R_A_data_out_5_C : X_INV
    port map (
      I => Clock_BUFGP,
      O => NlwInverterSignal_mem_R_A_data_out_5_C
    );
  NlwInverterBlock_port3_out_1_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_1_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_0_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_0_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_3_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_3_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_4_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_4_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_5_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_5_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_6_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_6_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_4_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_4_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_7_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_7_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_0_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_0_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_6_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_6_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_1_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_1_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_7_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_7_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_2_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_2_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_1_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_1_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_3_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_3_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port2_out_2_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port2_out_2_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_5_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_5_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_4_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_4_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_2_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_2_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_5_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_5_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_0_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_0_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_6_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_6_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_3_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_3_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_2_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_2_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_5_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_5_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_4_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_4_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_7_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_7_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_0_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_0_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port0_out_1_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port0_out_1_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_6_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_6_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port1_out_7_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port1_out_7_OBUF_GTS_TRI_CTL
    );
  NlwInverterBlock_port3_out_3_OBUF_GTS_TRI_CTL : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_port3_out_3_OBUF_GTS_TRI_CTL
    );
  NlwBlockROC : X_ROC
    generic map (ROC_WIDTH => 100 ns)
    port map (O => GSR);
  NlwBlockTOC : X_TOC
    port map (O => GTS);

end Structure;

