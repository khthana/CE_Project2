-- E:\USERS\POLARBEAR\PROJECT\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Feb 14 09:49:13 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY mux3_tb IS
END mux3_tb;

ARCHITECTURE testbench_arch OF mux3_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT mux3
		PORT (
			in1 : In  std_logic_vector (15 DOWNTO 0);
			in2 : In  std_logic_vector (7 DOWNTO 0);
			sel : In  std_logic;
			out1 : Out  std_logic_vector (15 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (15 DOWNTO 0);
	SIGNAL in2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL sel : std_logic;
	SIGNAL out1 : std_logic_vector (15 DOWNTO 0);

BEGIN
	UUT : mux3
	PORT MAP (
		in1 => in1,
		in2 => in2,
		sel => sel,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("1001000001111101"); --907D
		in2 <= transport std_logic_vector'("01111100"); --7C
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("0101111000101011"); --5E2B
		in2 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("1110001000001100"); --E20C
		in2 <= transport std_logic_vector'("11100000"); --E0
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("1011101000111101"); --BA3D
		in2 <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("1100100100011011"); --C91B
		in2 <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("0010111101000011"); --2F43
		in2 <= transport std_logic_vector'("01100101"); --65
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("0100110110010010"); --4D92
		in2 <= transport std_logic_vector'("00010001"); --11
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("1100010100100101"); --C525
		in2 <= transport std_logic_vector'("10101111"); --AF
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("0111011101011001"); --7759
		in2 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("1000010011001011"); --84CB
		in2 <= transport std_logic_vector'("11000011"); --C3
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("0100111001011001"); --4E59
		in2 <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("0111010100011110"); --751E
		in2 <= transport std_logic_vector'("00101010"); --2A
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("1101101001111000"); --DA78
		in2 <= transport std_logic_vector'("11011111"); --DF
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("1001111100000100"); --9F04
		in2 <= transport std_logic_vector'("01101011"); --6B
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("0010010010011111"); --249F
		in2 <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("0000101101100110"); --B66
		in2 <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("0011001110110111"); --33B7
		in2 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("1011111100101101"); --BF2D
		in2 <= transport std_logic_vector'("10011100"); --9C
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("0001000010100110"); --10A6
		in2 <= transport std_logic_vector'("00111101"); --3D
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("1100010100111111"); --C53F
		in2 <= transport std_logic_vector'("10011100"); --9C
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("1100000101010110"); --C156
		in2 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("0010010110000110"); --2586
		in2 <= transport std_logic_vector'("10010110"); --96
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("0101000010101101"); --50AD
		in2 <= transport std_logic_vector'("01010011"); --53
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("1110010111101001"); --E5E9
		in2 <= transport std_logic_vector'("00010010"); --12
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("1100010010010101"); --C495
		in2 <= transport std_logic_vector'("10000100"); --84
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("0000111101001111"); --F4F
		in2 <= transport std_logic_vector'("10011001"); --99
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("0010011011110101"); --26F5
		in2 <= transport std_logic_vector'("10000011"); --83
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("1010101010100010"); --AAA2
		in2 <= transport std_logic_vector'("10110010"); --B2
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("0111110110110100"); --7DB4
		in2 <= transport std_logic_vector'("11011000"); --D8
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("1011111111001001"); --BFC9
		in2 <= transport std_logic_vector'("11100110"); --E6
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("1101000110111100"); --D1BC
		in2 <= transport std_logic_vector'("00001100"); --C
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("0101010110101100"); --55AC
		in2 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("0010101111110100"); --2BF4
		in2 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("0111010000110011"); --7433
		in2 <= transport std_logic_vector'("10111100"); --BC
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("1001001001000100"); --9244
		in2 <= transport std_logic_vector'("00101110"); --2E
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("0010010001000110"); --2446
		in2 <= transport std_logic_vector'("01101110"); --6E
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("0000111010010100"); --E94
		in2 <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("0110111011001101"); --6ECD
		in2 <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("1010011111001100"); --A7CC
		in2 <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("0101100110110000"); --59B0
		in2 <= transport std_logic_vector'("00001010"); --A
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("0110011011010101"); --66D5
		in2 <= transport std_logic_vector'("10101101"); --AD
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("1110111011010111"); --EED7
		in2 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("0101001010010101"); --5295
		in2 <= transport std_logic_vector'("00111110"); --3E
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("0011010000101010"); --342A
		in2 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("0111001111110101"); --73F5
		in2 <= transport std_logic_vector'("01100110"); --66
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("0011001110010010"); --3392
		in2 <= transport std_logic_vector'("11110101"); --F5
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		in1 <= transport std_logic_vector'("1101001011011101"); --D2DD
		in2 <= transport std_logic_vector'("10101100"); --AC
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		in1 <= transport std_logic_vector'("1111001111110101"); --F3F5
		in2 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		in1 <= transport std_logic_vector'("0111011000110110"); --7636
		in2 <= transport std_logic_vector'("10011001"); --99
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		in1 <= transport std_logic_vector'("0111110100111101"); --7D3D
		in2 <= transport std_logic_vector'("01110000"); --70
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("0110100011100110"); --68E6
		in2 <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		in1 <= transport std_logic_vector'("1101100001010000"); --D850
		in2 <= transport std_logic_vector'("11010101"); --D5
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		in1 <= transport std_logic_vector'("1010111011010111"); --AED7
		in2 <= transport std_logic_vector'("10000101"); --85
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		in1 <= transport std_logic_vector'("0000110000011000"); --C18
		in2 <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		in1 <= transport std_logic_vector'("0101001011101111"); --52EF
		in2 <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		in1 <= transport std_logic_vector'("0010001001111011"); --227B
		in2 <= transport std_logic_vector'("10010110"); --96
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		in1 <= transport std_logic_vector'("0101101100011000"); --5B18
		in2 <= transport std_logic_vector'("01101010"); --6A
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		in1 <= transport std_logic_vector'("0010000101100011"); --2163
		in2 <= transport std_logic_vector'("00000001"); --1
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		in1 <= transport std_logic_vector'("1101001000111001"); --D239
		in2 <= transport std_logic_vector'("10001110"); --8E
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		in1 <= transport std_logic_vector'("0001000110110111"); --11B7
		in2 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("1011111000111010"); --BE3A
		in2 <= transport std_logic_vector'("10001000"); --88
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		in1 <= transport std_logic_vector'("1111101001011111"); --FA5F
		in2 <= transport std_logic_vector'("10011000"); --98
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		in1 <= transport std_logic_vector'("0010011100000010"); --2702
		in2 <= transport std_logic_vector'("11100001"); --E1
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		in1 <= transport std_logic_vector'("1110010101000010"); --E542
		in2 <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		in1 <= transport std_logic_vector'("0001011001111011"); --167B
		in2 <= transport std_logic_vector'("00100000"); --20
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		in1 <= transport std_logic_vector'("1101100101001010"); --D94A
		in2 <= transport std_logic_vector'("10111000"); --B8
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		in1 <= transport std_logic_vector'("1001000110001100"); --918C
		in2 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		in1 <= transport std_logic_vector'("1101111101011110"); --DF5E
		in2 <= transport std_logic_vector'("11001111"); --CF
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		in1 <= transport std_logic_vector'("1010001100011101"); --A31D
		in2 <= transport std_logic_vector'("01110000"); --70
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		in1 <= transport std_logic_vector'("1111111001100110"); --FE66
		in2 <= transport std_logic_vector'("10100001"); --A1
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("0101000100010111"); --5117
		in2 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		in1 <= transport std_logic_vector'("0011111001001011"); --3E4B
		in2 <= transport std_logic_vector'("10110101"); --B5
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		in1 <= transport std_logic_vector'("1010010101100000"); --A560
		in2 <= transport std_logic_vector'("10111010"); --BA
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		in1 <= transport std_logic_vector'("1010011111110011"); --A7F3
		in2 <= transport std_logic_vector'("10010011"); --93
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		in1 <= transport std_logic_vector'("1010011011100001"); --A6E1
		in2 <= transport std_logic_vector'("01110001"); --71
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		in1 <= transport std_logic_vector'("0100001001000111"); --4247
		in2 <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		in1 <= transport std_logic_vector'("0101110010000010"); --5C82
		in2 <= transport std_logic_vector'("00111110"); --3E
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		in1 <= transport std_logic_vector'("0001011000101111"); --162F
		in2 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		in1 <= transport std_logic_vector'("1101000000101100"); --D02C
		in2 <= transport std_logic_vector'("10101001"); --A9
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		in1 <= transport std_logic_vector'("0010101110010100"); --2B94
		in2 <= transport std_logic_vector'("00111100"); --3C
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("0000100111000101"); --9C5
		in2 <= transport std_logic_vector'("00111010"); --3A
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		in1 <= transport std_logic_vector'("1000101001011100"); --8A5C
		in2 <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		in1 <= transport std_logic_vector'("0000111100110110"); --F36
		in2 <= transport std_logic_vector'("01111010"); --7A
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		in1 <= transport std_logic_vector'("0011101001110001"); --3A71
		in2 <= transport std_logic_vector'("01011110"); --5E
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		in1 <= transport std_logic_vector'("1110101101101000"); --EB68
		in2 <= transport std_logic_vector'("11110000"); --F0
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		in1 <= transport std_logic_vector'("0100001110111001"); --43B9
		in2 <= transport std_logic_vector'("00100010"); --22
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		in1 <= transport std_logic_vector'("1010010001000010"); --A442
		in2 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		in1 <= transport std_logic_vector'("1010111000011110"); --AE1E
		in2 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		in1 <= transport std_logic_vector'("0100001010101011"); --42AB
		in2 <= transport std_logic_vector'("10011111"); --9F
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		in1 <= transport std_logic_vector'("1000001010000111"); --8287
		in2 <= transport std_logic_vector'("10111001"); --B9
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("1100111010001101"); --CE8D
		in2 <= transport std_logic_vector'("11101000"); --E8
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		in1 <= transport std_logic_vector'("1100011111011011"); --C7DB
		in2 <= transport std_logic_vector'("10011101"); --9D
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		in1 <= transport std_logic_vector'("0100111111001111"); --4FCF
		in2 <= transport std_logic_vector'("10001000"); --88
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		in1 <= transport std_logic_vector'("1000011000000100"); --8604
		in2 <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		in1 <= transport std_logic_vector'("1100110101011001"); --CD59
		in2 <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		in1 <= transport std_logic_vector'("1100011011101001"); --C6E9
		in2 <= transport std_logic_vector'("00111010"); --3A
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		in1 <= transport std_logic_vector'("0101000100010011"); --5113
		in2 <= transport std_logic_vector'("11101001"); --E9
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		in1 <= transport std_logic_vector'("1000111101110010"); --8F72
		in2 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		in1 <= transport std_logic_vector'("1110000111100101"); --E1E5
		in2 <= transport std_logic_vector'("10111011"); --BB
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		in1 <= transport std_logic_vector'("1110100110000111"); --E987
		in2 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 15 ns; -- Time=1005 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION mux3_cfg OF mux3_tb IS
	FOR testbench_arch
	END FOR;
END mux3_cfg;
