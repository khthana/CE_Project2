-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 15 18:17:17 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_SIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY nrv_tb IS
END nrv_tb;

ARCHITECTURE testbench_arch OF nrv_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT vdiv2
		PORT (
			GO : In  std_logic;
			IN_N : In  std_logic_vector (7 DOWNTO 0);
			IN_D : In  std_logic_vector (7 DOWNTO 0);
			EXT_CLK : In  std_logic;
			OUT_Q : Out  std_logic_vector (7 DOWNTO 0);
			OUT_R : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL GO : std_logic;
	SIGNAL IN_N : std_logic_vector (7 DOWNTO 0);
	SIGNAL IN_D : std_logic_vector (7 DOWNTO 0);
	SIGNAL EXT_CLK : std_logic;
	SIGNAL OUT_Q : std_logic_vector (7 DOWNTO 0);
	SIGNAL OUT_R : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : vdiv2
	PORT MAP (
		GO => GO,
		IN_N => IN_N,
		IN_D => IN_D,
		EXT_CLK => EXT_CLK,
		OUT_Q => OUT_Q,
		OUT_R => OUT_R
	);

	PROCESS -- clock process for EXT_CLK,
	BEGIN
		CLOCK_LOOP : LOOP
		EXT_CLK <= transport '0';
		WAIT FOR 10 ps;
		EXT_CLK <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		EXT_CLK <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for EXT_CLK
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_OUT_Q(
			next_OUT_Q : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (OUT_Q /= next_OUT_Q) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps OUT_Q="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, OUT_Q);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_OUT_Q);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_OUT_R(
			next_OUT_R : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (OUT_R /= next_OUT_R) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps OUT_R="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, OUT_R);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_OUT_R);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11111111"); --FF
		IN_D <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11111110"); --FE
		IN_D <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		IN_N <= transport std_logic_vector'("11111101"); --FD
		IN_D <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11111100"); --FC
		IN_D <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11111011"); --FB
		IN_D <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11111010"); --FA
		IN_D <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11111001"); --F9
		IN_D <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		IN_N <= transport std_logic_vector'("11111000"); --F8
		IN_D <= transport std_logic_vector'("00000111"); --7
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11110111"); --F7
		IN_D <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		IN_N <= transport std_logic_vector'("11110110"); --F6
		IN_D <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		IN_N <= transport std_logic_vector'("11110101"); --F5
		IN_D <= transport std_logic_vector'("00001010"); --A
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		IN_N <= transport std_logic_vector'("11110100"); --F4
		IN_D <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		IN_N <= transport std_logic_vector'("11110011"); --F3
		IN_D <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11110010"); --F2
		IN_D <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11110001"); --F1
		IN_D <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11110000"); --F0
		IN_D <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		IN_N <= transport std_logic_vector'("11101111"); --EF
		IN_D <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		IN_N <= transport std_logic_vector'("11101110"); --EE
		IN_D <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11101101"); --ED
		IN_D <= transport std_logic_vector'("00010010"); --12
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		IN_N <= transport std_logic_vector'("11101100"); --EC
		IN_D <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11101011"); --EB
		IN_D <= transport std_logic_vector'("00010100"); --14
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		IN_N <= transport std_logic_vector'("11101010"); --EA
		IN_D <= transport std_logic_vector'("00010101"); --15
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		IN_N <= transport std_logic_vector'("11101001"); --E9
		IN_D <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		IN_N <= transport std_logic_vector'("11101000"); --E8
		IN_D <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11100111"); --E7
		IN_D <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		IN_N <= transport std_logic_vector'("11100110"); --E6
		IN_D <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11100101"); --E5
		IN_D <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11100100"); --E4
		IN_D <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11100011"); --E3
		IN_D <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11100010"); --E2
		IN_D <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		IN_N <= transport std_logic_vector'("11100001"); --E1
		IN_D <= transport std_logic_vector'("00011110"); --1E
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11100000"); --E0
		IN_D <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		IN_N <= transport std_logic_vector'("11011111"); --DF
		IN_D <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		IN_N <= transport std_logic_vector'("11011110"); --DE
		IN_D <= transport std_logic_vector'("00100001"); --21
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		IN_N <= transport std_logic_vector'("11011101"); --DD
		IN_D <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		IN_N <= transport std_logic_vector'("11011100"); --DC
		IN_D <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11011011"); --DB
		IN_D <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11011010"); --DA
		IN_D <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		IN_N <= transport std_logic_vector'("11011001"); --D9
		IN_D <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11011000"); --D8
		IN_D <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11010111"); --D7
		IN_D <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		IN_N <= transport std_logic_vector'("11010110"); --D6
		IN_D <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11010101"); --D5
		IN_D <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 100 ps; -- Time=4300 ps
		IN_N <= transport std_logic_vector'("11010100"); --D4
		IN_D <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 100 ps; -- Time=4400 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11010011"); --D3
		IN_D <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 100 ps; -- Time=4500 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11010010"); --D2
		IN_D <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 100 ps; -- Time=4600 ps
		IN_N <= transport std_logic_vector'("11010001"); --D1
		IN_D <= transport std_logic_vector'("00101110"); --2E
		-- --------------------
		WAIT FOR 100 ps; -- Time=4700 ps
		IN_N <= transport std_logic_vector'("11010000"); --D0
		IN_D <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 100 ps; -- Time=4800 ps
		IN_N <= transport std_logic_vector'("11001111"); --CF
		IN_D <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 100 ps; -- Time=4900 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11001110"); --CE
		IN_D <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 100 ps; -- Time=5000 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11001101"); --CD
		IN_D <= transport std_logic_vector'("00110010"); --32
		-- --------------------
		WAIT FOR 100 ps; -- Time=5100 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11001100"); --CC
		IN_D <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 100 ps; -- Time=5200 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11001011"); --CB
		IN_D <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 100 ps; -- Time=5300 ps
		IN_N <= transport std_logic_vector'("11001010"); --CA
		IN_D <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 100 ps; -- Time=5400 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11001001"); --C9
		IN_D <= transport std_logic_vector'("00110110"); --36
		-- --------------------
		WAIT FOR 100 ps; -- Time=5500 ps
		IN_N <= transport std_logic_vector'("11001000"); --C8
		IN_D <= transport std_logic_vector'("00110111"); --37
		-- --------------------
		WAIT FOR 100 ps; -- Time=5600 ps
		IN_N <= transport std_logic_vector'("11000111"); --C7
		IN_D <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 100 ps; -- Time=5700 ps
		IN_N <= transport std_logic_vector'("11000110"); --C6
		IN_D <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 100 ps; -- Time=5800 ps
		IN_N <= transport std_logic_vector'("11000101"); --C5
		IN_D <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 100 ps; -- Time=5900 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11000100"); --C4
		IN_D <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 100 ps; -- Time=6000 ps
		IN_N <= transport std_logic_vector'("11000011"); --C3
		IN_D <= transport std_logic_vector'("00111100"); --3C
		-- --------------------
		WAIT FOR 100 ps; -- Time=6100 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11000010"); --C2
		IN_D <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 100 ps; -- Time=6200 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("11000001"); --C1
		IN_D <= transport std_logic_vector'("00111110"); --3E
		-- --------------------
		WAIT FOR 100 ps; -- Time=6300 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("11000000"); --C0
		IN_D <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 100 ps; -- Time=6400 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10111111"); --BF
		IN_D <= transport std_logic_vector'("01000000"); --40
		-- --------------------
		WAIT FOR 100 ps; -- Time=6500 ps
		IN_N <= transport std_logic_vector'("10111110"); --BE
		IN_D <= transport std_logic_vector'("01000001"); --41
		-- --------------------
		WAIT FOR 100 ps; -- Time=6600 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10111101"); --BD
		IN_D <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 100 ps; -- Time=6700 ps
		IN_N <= transport std_logic_vector'("10111100"); --BC
		IN_D <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 100 ps; -- Time=6800 ps
		IN_N <= transport std_logic_vector'("10111011"); --BB
		IN_D <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 100 ps; -- Time=6900 ps
		IN_N <= transport std_logic_vector'("10111010"); --BA
		IN_D <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ps; -- Time=7000 ps
		IN_N <= transport std_logic_vector'("10111001"); --B9
		IN_D <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 100 ps; -- Time=7100 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10111000"); --B8
		IN_D <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 100 ps; -- Time=7200 ps
		IN_N <= transport std_logic_vector'("10110111"); --B7
		IN_D <= transport std_logic_vector'("01001000"); --48
		-- --------------------
		WAIT FOR 100 ps; -- Time=7300 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10110110"); --B6
		IN_D <= transport std_logic_vector'("01001001"); --49
		-- --------------------
		WAIT FOR 100 ps; -- Time=7400 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10110101"); --B5
		IN_D <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 100 ps; -- Time=7500 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10110100"); --B4
		IN_D <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 100 ps; -- Time=7600 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10110011"); --B3
		IN_D <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 100 ps; -- Time=7700 ps
		IN_N <= transport std_logic_vector'("10110010"); --B2
		IN_D <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 100 ps; -- Time=7800 ps
		IN_N <= transport std_logic_vector'("10110001"); --B1
		IN_D <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 100 ps; -- Time=7900 ps
		IN_N <= transport std_logic_vector'("10110000"); --B0
		IN_D <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 100 ps; -- Time=8000 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10101111"); --AF
		IN_D <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 100 ps; -- Time=8100 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10101110"); --AE
		IN_D <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 100 ps; -- Time=8200 ps
		IN_N <= transport std_logic_vector'("10101101"); --AD
		IN_D <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 100 ps; -- Time=8300 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10101100"); --AC
		IN_D <= transport std_logic_vector'("01010011"); --53
		-- --------------------
		WAIT FOR 100 ps; -- Time=8400 ps
		IN_N <= transport std_logic_vector'("10101011"); --AB
		IN_D <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ps; -- Time=8500 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10101010"); --AA
		IN_D <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 100 ps; -- Time=8600 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10101001"); --A9
		IN_D <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 100 ps; -- Time=8700 ps
		IN_N <= transport std_logic_vector'("10101000"); --A8
		IN_D <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 100 ps; -- Time=8800 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10100111"); --A7
		IN_D <= transport std_logic_vector'("01011000"); --58
		-- --------------------
		WAIT FOR 100 ps; -- Time=8900 ps
		IN_N <= transport std_logic_vector'("10100110"); --A6
		IN_D <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 100 ps; -- Time=9000 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10100101"); --A5
		IN_D <= transport std_logic_vector'("01011010"); --5A
		-- --------------------
		WAIT FOR 100 ps; -- Time=9100 ps
		IN_N <= transport std_logic_vector'("10100100"); --A4
		IN_D <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 100 ps; -- Time=9200 ps
		IN_N <= transport std_logic_vector'("10100011"); --A3
		IN_D <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 100 ps; -- Time=9300 ps
		IN_N <= transport std_logic_vector'("10100010"); --A2
		IN_D <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 100 ps; -- Time=9400 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10100001"); --A1
		IN_D <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 100 ps; -- Time=9500 ps
		IN_N <= transport std_logic_vector'("10100000"); --A0
		IN_D <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ps; -- Time=9600 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10011111"); --9F
		IN_D <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 100 ps; -- Time=9700 ps
		GO <= transport '1';
		IN_N <= transport std_logic_vector'("10011110"); --9E
		IN_D <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 100 ps; -- Time=9800 ps
		GO <= transport '0';
		IN_N <= transport std_logic_vector'("10011101"); --9D
		IN_D <= transport std_logic_vector'("01100010"); --62
		-- --------------------
		WAIT FOR 100 ps; -- Time=9900 ps
		IN_N <= transport std_logic_vector'("10011100"); --9C
		IN_D <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 110 ps; -- Time=10010 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION vdiv2_cfg OF nrv_tb IS
	FOR testbench_arch
	END FOR;
END vdiv2_cfg;
