-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Mar 21 19:08:28 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY execute_tb IS
END execute_tb;

ARCHITECTURE testbench_arch OF execute_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT execute
		PORT (
			rst : In  std_logic;
			AA : In  std_logic_vector (7 DOWNTO 0);
			ac_in : In  std_logic;
			BB : In  std_logic_vector (7 DOWNTO 0);
			cy_in : In  std_logic;
			D1 : In  std_logic_vector (7 DOWNTO 0);
			D2 : In  std_logic_vector (7 DOWNTO 0);
			OPCode : In  std_logic_vector (4 DOWNTO 0);
			s1 : In  std_logic_vector (7 DOWNTO 0);
			s2 : In  std_logic_vector (7 DOWNTO 0);
			ac_out : Out  std_logic;
			cy_out : Out  std_logic;
			ov : Out  std_logic;
			RA_in : In  std_logic_vector (7 DOWNTO 0);
			RB_in : In  std_logic_vector (7 DOWNTO 0);
			RA_out : Out  std_logic_vector (7 DOWNTO 0);
			RB_out : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL rst : std_logic;
	SIGNAL AA : std_logic_vector (7 DOWNTO 0);
	SIGNAL ac_in : std_logic;
	SIGNAL BB : std_logic_vector (7 DOWNTO 0);
	SIGNAL cy_in : std_logic;
	SIGNAL D1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL D2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL OPCode : std_logic_vector (4 DOWNTO 0);
	SIGNAL s1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL s2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL ac_out : std_logic;
	SIGNAL cy_out : std_logic;
	SIGNAL ov : std_logic;
	SIGNAL RA_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL RB_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL RA_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL RB_out : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : execute
	PORT MAP (
		rst => rst,
		AA => AA,
		ac_in => ac_in,
		BB => BB,
		cy_in => cy_in,
		D1 => D1,
		D2 => D2,
		OPCode => OPCode,
		s1 => s1,
		s2 => s2,
		ac_out => ac_out,
		cy_out => cy_out,
		ov => ov,
		RA_in => RA_in,
		RB_in => RB_in,
		RA_out => RA_out,
		RB_out => RB_out
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_ac_out(
			next_ac_out : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (ac_out /= next_ac_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps ac_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, ac_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_ac_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_cy_out(
			next_cy_out : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (cy_out /= next_cy_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps cy_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, cy_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_cy_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_ov(
			next_ov : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (ov /= next_ov) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps ov="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, ov);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_ov);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_RA_out(
			next_RA_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (RA_out /= next_RA_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps RA_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, RA_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_RA_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_RB_out(
			next_RB_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (RB_out /= next_RB_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps RB_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, RB_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_RB_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		AA <= transport std_logic_vector'("00000000"); --0
		BB <= transport std_logic_vector'("00001010"); --A
		cy_in <= transport '1';
		rst <= transport '1';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01101010"); --6A
		D2 <= transport std_logic_vector'("01101001"); --69
		OPCode <= transport std_logic_vector'("01000"); --8
		s1 <= transport std_logic_vector'("01101000"); --68
		s2 <= transport std_logic_vector'("01100111"); --67
		RA_in <= transport std_logic_vector'("01100100"); --64
		RB_in <= transport std_logic_vector'("01100100"); --64
		-- --------------------
		WAIT FOR 10 ps; -- Time=10 ps
		AA <= transport std_logic_vector'("00000001"); --1
		BB <= transport std_logic_vector'("00001011"); --B
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00101110"); --2E
		D2 <= transport std_logic_vector'("00010010"); --12
		OPCode <= transport std_logic_vector'("00111"); --7
		s1 <= transport std_logic_vector'("11011100"); --DC
		s2 <= transport std_logic_vector'("11000001"); --C1
		RA_in <= transport std_logic_vector'("01010011"); --53
		RB_in <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 10 ps; -- Time=20 ps
		AA <= transport std_logic_vector'("00000010"); --2
		BB <= transport std_logic_vector'("00001100"); --C
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("00110001"); --31
		D2 <= transport std_logic_vector'("00000100"); --4
		OPCode <= transport std_logic_vector'("01000"); --8
		s1 <= transport std_logic_vector'("10101011"); --AB
		s2 <= transport std_logic_vector'("01111111"); --7F
		RA_in <= transport std_logic_vector'("11001101"); --CD
		RB_in <= transport std_logic_vector'("10100001"); --A1
		-- --------------------
		WAIT FOR 10 ps; -- Time=30 ps
		AA <= transport std_logic_vector'("00000011"); --3
		BB <= transport std_logic_vector'("00001101"); --D
		rst <= transport '0';
		D1 <= transport std_logic_vector'("10111111"); --BF
		D2 <= transport std_logic_vector'("11011111"); --DF
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("00011111"); --1F
		s2 <= transport std_logic_vector'("00111111"); --3F
		RA_in <= transport std_logic_vector'("11000000"); --C0
		RB_in <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 10 ps; -- Time=40 ps
		AA <= transport std_logic_vector'("00000100"); --4
		BB <= transport std_logic_vector'("00001110"); --E
		cy_in <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00000100"); --4
		D2 <= transport std_logic_vector'("10000100"); --84
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("11000001"); --C1
		s2 <= transport std_logic_vector'("11011111"); --DF
		RA_in <= transport std_logic_vector'("01010111"); --57
		RB_in <= transport std_logic_vector'("01110101"); --75
		-- --------------------
		WAIT FOR 10 ps; -- Time=50 ps
		AA <= transport std_logic_vector'("00000101"); --5
		BB <= transport std_logic_vector'("00001111"); --F
		D1 <= transport std_logic_vector'("01011000"); --58
		D2 <= transport std_logic_vector'("00010101"); --15
		OPCode <= transport std_logic_vector'("00111"); --7
		s1 <= transport std_logic_vector'("01011000"); --58
		s2 <= transport std_logic_vector'("01111010"); --7A
		RA_in <= transport std_logic_vector'("00000001"); --1
		RB_in <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 10 ps; -- Time=60 ps
		AA <= transport std_logic_vector'("00000110"); --6
		BB <= transport std_logic_vector'("00010000"); --10
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01110011"); --73
		D2 <= transport std_logic_vector'("00010000"); --10
		OPCode <= transport std_logic_vector'("00001"); --1
		s1 <= transport std_logic_vector'("11110000"); --F0
		s2 <= transport std_logic_vector'("01101111"); --6F
		RA_in <= transport std_logic_vector'("01101010"); --6A
		RB_in <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 10 ps; -- Time=70 ps
		AA <= transport std_logic_vector'("00000111"); --7
		BB <= transport std_logic_vector'("00010001"); --11
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("00110011"); --33
		D2 <= transport std_logic_vector'("10111100"); --BC
		OPCode <= transport std_logic_vector'("00110"); --6
		s1 <= transport std_logic_vector'("11010000"); --D0
		s2 <= transport std_logic_vector'("01011001"); --59
		RA_in <= transport std_logic_vector'("10000000"); --80
		RB_in <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 10 ps; -- Time=80 ps
		AA <= transport std_logic_vector'("00001000"); --8
		BB <= transport std_logic_vector'("00010010"); --12
		D1 <= transport std_logic_vector'("10111111"); --BF
		D2 <= transport std_logic_vector'("01010101"); --55
		OPCode <= transport std_logic_vector'("01011"); --B
		s1 <= transport std_logic_vector'("10000001"); --81
		s2 <= transport std_logic_vector'("00010111"); --17
		RA_in <= transport std_logic_vector'("01101110"); --6E
		RB_in <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ps; -- Time=90 ps
		AA <= transport std_logic_vector'("00001001"); --9
		BB <= transport std_logic_vector'("00010011"); --13
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("11100101"); --E5
		D2 <= transport std_logic_vector'("11011101"); --DD
		OPCode <= transport std_logic_vector'("00101"); --5
		s1 <= transport std_logic_vector'("11001100"); --CC
		s2 <= transport std_logic_vector'("11000100"); --C4
		RA_in <= transport std_logic_vector'("10100011"); --A3
		RB_in <= transport std_logic_vector'("10011011"); --9B
		-- --------------------
		WAIT FOR 10 ps; -- Time=100 ps
		AA <= transport std_logic_vector'("00001010"); --A
		BB <= transport std_logic_vector'("00010100"); --14
		D1 <= transport std_logic_vector'("10110010"); --B2
		D2 <= transport std_logic_vector'("10110101"); --B5
		OPCode <= transport std_logic_vector'("01000"); --8
		s1 <= transport std_logic_vector'("10111100"); --BC
		s2 <= transport std_logic_vector'("10111111"); --BF
		RA_in <= transport std_logic_vector'("11001011"); --CB
		RB_in <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 10 ps; -- Time=110 ps
		AA <= transport std_logic_vector'("00001011"); --B
		BB <= transport std_logic_vector'("00010101"); --15
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("00001011"); --B
		D2 <= transport std_logic_vector'("00010101"); --15
		OPCode <= transport std_logic_vector'("01011"); --B
		s1 <= transport std_logic_vector'("10010111"); --97
		s2 <= transport std_logic_vector'("10100011"); --A3
		RA_in <= transport std_logic_vector'("11010100"); --D4
		RB_in <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 10 ps; -- Time=120 ps
		AA <= transport std_logic_vector'("00001100"); --C
		BB <= transport std_logic_vector'("00010110"); --16
		cy_in <= transport '1';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("11101000"); --E8
		D2 <= transport std_logic_vector'("01001111"); --4F
		OPCode <= transport std_logic_vector'("00001"); --1
		s1 <= transport std_logic_vector'("11101000"); --E8
		s2 <= transport std_logic_vector'("01001111"); --4F
		RA_in <= transport std_logic_vector'("11101010"); --EA
		RB_in <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 10 ps; -- Time=130 ps
		AA <= transport std_logic_vector'("00001101"); --D
		BB <= transport std_logic_vector'("00010111"); --17
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01000011"); --43
		D2 <= transport std_logic_vector'("10101010"); --AA
		s1 <= transport std_logic_vector'("01111000"); --78
		s2 <= transport std_logic_vector'("11011110"); --DE
		RA_in <= transport std_logic_vector'("01111010"); --7A
		RB_in <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 10 ps; -- Time=140 ps
		AA <= transport std_logic_vector'("00001110"); --E
		BB <= transport std_logic_vector'("00011000"); --18
		cy_in <= transport '1';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00101101"); --2D
		D2 <= transport std_logic_vector'("10001101"); --8D
		OPCode <= transport std_logic_vector'("01110"); --E
		s1 <= transport std_logic_vector'("01001110"); --4E
		s2 <= transport std_logic_vector'("10101111"); --AF
		RA_in <= transport std_logic_vector'("00110001"); --31
		RB_in <= transport std_logic_vector'("10010001"); --91
		-- --------------------
		WAIT FOR 10 ps; -- Time=150 ps
		AA <= transport std_logic_vector'("00001111"); --F
		BB <= transport std_logic_vector'("00011001"); --19
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("10111111"); --BF
		D2 <= transport std_logic_vector'("01100110"); --66
		s1 <= transport std_logic_vector'("10110110"); --B6
		s2 <= transport std_logic_vector'("01011110"); --5E
		RA_in <= transport std_logic_vector'("11111100"); --FC
		RB_in <= transport std_logic_vector'("10100100"); --A4
		-- --------------------
		WAIT FOR 10 ps; -- Time=160 ps
		AA <= transport std_logic_vector'("00010000"); --10
		BB <= transport std_logic_vector'("00011010"); --1A
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("10000101"); --85
		D2 <= transport std_logic_vector'("00010110"); --16
		OPCode <= transport std_logic_vector'("00110"); --6
		s1 <= transport std_logic_vector'("00110111"); --37
		s2 <= transport std_logic_vector'("11000111"); --C7
		RA_in <= transport std_logic_vector'("00001001"); --9
		RB_in <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 10 ps; -- Time=170 ps
		AA <= transport std_logic_vector'("00010001"); --11
		BB <= transport std_logic_vector'("00011011"); --1B
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01001101"); --4D
		D2 <= transport std_logic_vector'("10111100"); --BC
		OPCode <= transport std_logic_vector'("01011"); --B
		s1 <= transport std_logic_vector'("10011010"); --9A
		s2 <= transport std_logic_vector'("00001001"); --9
		RA_in <= transport std_logic_vector'("11000100"); --C4
		RB_in <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 10 ps; -- Time=180 ps
		AA <= transport std_logic_vector'("00010010"); --12
		BB <= transport std_logic_vector'("00011100"); --1C
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("00100100"); --24
		D2 <= transport std_logic_vector'("10111011"); --BB
		OPCode <= transport std_logic_vector'("00010"); --2
		s1 <= transport std_logic_vector'("11101001"); --E9
		s2 <= transport std_logic_vector'("01111111"); --7F
		RA_in <= transport std_logic_vector'("11011011"); --DB
		RB_in <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 10 ps; -- Time=190 ps
		AA <= transport std_logic_vector'("00010011"); --13
		BB <= transport std_logic_vector'("00011101"); --1D
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("01010111"); --57
		D2 <= transport std_logic_vector'("10110011"); --B3
		OPCode <= transport std_logic_vector'("00000"); --0
		s1 <= transport std_logic_vector'("01101100"); --6C
		s2 <= transport std_logic_vector'("11001000"); --C8
		RA_in <= transport std_logic_vector'("00111001"); --39
		RB_in <= transport std_logic_vector'("10010110"); --96
		-- --------------------
		WAIT FOR 10 ps; -- Time=200 ps
		AA <= transport std_logic_vector'("00010100"); --14
		BB <= transport std_logic_vector'("00011110"); --1E
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("01110011"); --73
		D2 <= transport std_logic_vector'("10000110"); --86
		OPCode <= transport std_logic_vector'("01001"); --9
		s1 <= transport std_logic_vector'("10101101"); --AD
		s2 <= transport std_logic_vector'("11000000"); --C0
		RA_in <= transport std_logic_vector'("00001101"); --D
		RB_in <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 10 ps; -- Time=210 ps
		AA <= transport std_logic_vector'("00010101"); --15
		BB <= transport std_logic_vector'("00011111"); --1F
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01000100"); --44
		D2 <= transport std_logic_vector'("01010100"); --54
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("01110100"); --74
		s2 <= transport std_logic_vector'("10000100"); --84
		RA_in <= transport std_logic_vector'("11000011"); --C3
		RB_in <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 10 ps; -- Time=220 ps
		AA <= transport std_logic_vector'("00010110"); --16
		BB <= transport std_logic_vector'("00100000"); --20
		D1 <= transport std_logic_vector'("11011000"); --D8
		D2 <= transport std_logic_vector'("01111110"); --7E
		s1 <= transport std_logic_vector'("11001010"); --CA
		s2 <= transport std_logic_vector'("01110000"); --70
		RA_in <= transport std_logic_vector'("00001001"); --9
		RB_in <= transport std_logic_vector'("10101111"); --AF
		-- --------------------
		WAIT FOR 10 ps; -- Time=230 ps
		AA <= transport std_logic_vector'("00010111"); --17
		BB <= transport std_logic_vector'("00100001"); --21
		D1 <= transport std_logic_vector'("01111100"); --7C
		D2 <= transport std_logic_vector'("10100110"); --A6
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("11111001"); --F9
		s2 <= transport std_logic_vector'("00100011"); --23
		RA_in <= transport std_logic_vector'("11001010"); --CA
		RB_in <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 10 ps; -- Time=240 ps
		AA <= transport std_logic_vector'("00011000"); --18
		BB <= transport std_logic_vector'("00100010"); --22
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("10111100"); --BC
		D2 <= transport std_logic_vector'("10101011"); --AB
		OPCode <= transport std_logic_vector'("01011"); --B
		s1 <= transport std_logic_vector'("10001010"); --8A
		s2 <= transport std_logic_vector'("01111001"); --79
		RA_in <= transport std_logic_vector'("00110101"); --35
		RB_in <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 10 ps; -- Time=250 ps
		AA <= transport std_logic_vector'("00011001"); --19
		BB <= transport std_logic_vector'("00100011"); --23
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01100111"); --67
		D2 <= transport std_logic_vector'("10110001"); --B1
		s1 <= transport std_logic_vector'("01000101"); --45
		s2 <= transport std_logic_vector'("10001111"); --8F
		RA_in <= transport std_logic_vector'("10110110"); --B6
		RB_in <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 10 ps; -- Time=260 ps
		AA <= transport std_logic_vector'("00011010"); --1A
		BB <= transport std_logic_vector'("00100100"); --24
		D1 <= transport std_logic_vector'("10001000"); --88
		D2 <= transport std_logic_vector'("00010110"); --16
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("00110011"); --33
		s2 <= transport std_logic_vector'("11000001"); --C1
		RA_in <= transport std_logic_vector'("11111011"); --FB
		RB_in <= transport std_logic_vector'("10001001"); --89
		-- --------------------
		WAIT FOR 10 ps; -- Time=270 ps
		AA <= transport std_logic_vector'("00011011"); --1B
		BB <= transport std_logic_vector'("00100101"); --25
		cy_in <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("01101101"); --6D
		D2 <= transport std_logic_vector'("01111101"); --7D
		OPCode <= transport std_logic_vector'("01101"); --D
		s1 <= transport std_logic_vector'("10011110"); --9E
		s2 <= transport std_logic_vector'("10101110"); --AE
		RA_in <= transport std_logic_vector'("11110000"); --F0
		RB_in <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 10 ps; -- Time=280 ps
		AA <= transport std_logic_vector'("00011100"); --1C
		BB <= transport std_logic_vector'("00100110"); --26
		D1 <= transport std_logic_vector'("10100010"); --A2
		D2 <= transport std_logic_vector'("11000110"); --C6
		OPCode <= transport std_logic_vector'("01010"); --A
		s1 <= transport std_logic_vector'("00001110"); --E
		s2 <= transport std_logic_vector'("00110010"); --32
		RA_in <= transport std_logic_vector'("11000010"); --C2
		RB_in <= transport std_logic_vector'("11100101"); --E5
		-- --------------------
		WAIT FOR 10 ps; -- Time=290 ps
		AA <= transport std_logic_vector'("00011101"); --1D
		BB <= transport std_logic_vector'("00100111"); --27
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("11110110"); --F6
		D2 <= transport std_logic_vector'("00010011"); --13
		OPCode <= transport std_logic_vector'("00000"); --0
		s1 <= transport std_logic_vector'("01001101"); --4D
		s2 <= transport std_logic_vector'("01101010"); --6A
		RA_in <= transport std_logic_vector'("11011110"); --DE
		RB_in <= transport std_logic_vector'("11111011"); --FB
		-- --------------------
		WAIT FOR 10 ps; -- Time=300 ps
		AA <= transport std_logic_vector'("00011110"); --1E
		BB <= transport std_logic_vector'("00101000"); --28
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01110100"); --74
		D2 <= transport std_logic_vector'("11000011"); --C3
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("01100011"); --63
		s2 <= transport std_logic_vector'("10110011"); --B3
		RA_in <= transport std_logic_vector'("11110001"); --F1
		RB_in <= transport std_logic_vector'("01000001"); --41
		-- --------------------
		WAIT FOR 10 ps; -- Time=310 ps
		AA <= transport std_logic_vector'("00011111"); --1F
		BB <= transport std_logic_vector'("00101001"); --29
		D1 <= transport std_logic_vector'("01101010"); --6A
		D2 <= transport std_logic_vector'("01111010"); --7A
		OPCode <= transport std_logic_vector'("01010"); --A
		s1 <= transport std_logic_vector'("10011001"); --99
		s2 <= transport std_logic_vector'("10101001"); --A9
		RA_in <= transport std_logic_vector'("11101001"); --E9
		RB_in <= transport std_logic_vector'("11111001"); --F9
		-- --------------------
		WAIT FOR 10 ps; -- Time=320 ps
		AA <= transport std_logic_vector'("00100000"); --20
		BB <= transport std_logic_vector'("00101010"); --2A
		cy_in <= transport '1';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01100100"); --64
		D2 <= transport std_logic_vector'("00010110"); --16
		OPCode <= transport std_logic_vector'("01000"); --8
		s1 <= transport std_logic_vector'("01111010"); --7A
		s2 <= transport std_logic_vector'("00101011"); --2B
		RA_in <= transport std_logic_vector'("11110010"); --F2
		RB_in <= transport std_logic_vector'("10100100"); --A4
		-- --------------------
		WAIT FOR 10 ps; -- Time=330 ps
		AA <= transport std_logic_vector'("00100001"); --21
		BB <= transport std_logic_vector'("00101011"); --2B
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("00110001"); --31
		D2 <= transport std_logic_vector'("10111010"); --BA
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("11001100"); --CC
		s2 <= transport std_logic_vector'("01010101"); --55
		RA_in <= transport std_logic_vector'("01111001"); --79
		RB_in <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 10 ps; -- Time=340 ps
		AA <= transport std_logic_vector'("00100010"); --22
		BB <= transport std_logic_vector'("00101100"); --2C
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("11011100"); --DC
		D2 <= transport std_logic_vector'("11000110"); --C6
		OPCode <= transport std_logic_vector'("00000"); --0
		s1 <= transport std_logic_vector'("10011010"); --9A
		s2 <= transport std_logic_vector'("10000100"); --84
		RA_in <= transport std_logic_vector'("00101100"); --2C
		RB_in <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 10 ps; -- Time=350 ps
		AA <= transport std_logic_vector'("00100011"); --23
		BB <= transport std_logic_vector'("00101101"); --2D
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("10110011"); --B3
		D2 <= transport std_logic_vector'("11011100"); --DC
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("00101101"); --2D
		s2 <= transport std_logic_vector'("01010101"); --55
		RA_in <= transport std_logic_vector'("11110111"); --F7
		RB_in <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 10 ps; -- Time=360 ps
		AA <= transport std_logic_vector'("00100100"); --24
		BB <= transport std_logic_vector'("00101110"); --2E
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01000011"); --43
		D2 <= transport std_logic_vector'("11011011"); --DB
		s1 <= transport std_logic_vector'("00001100"); --C
		s2 <= transport std_logic_vector'("10100101"); --A5
		RA_in <= transport std_logic_vector'("00000111"); --7
		RB_in <= transport std_logic_vector'("10100000"); --A0
		-- --------------------
		WAIT FOR 10 ps; -- Time=370 ps
		AA <= transport std_logic_vector'("00100101"); --25
		BB <= transport std_logic_vector'("00101111"); --2F
		D1 <= transport std_logic_vector'("01011000"); --58
		D2 <= transport std_logic_vector'("11100110"); --E6
		OPCode <= transport std_logic_vector'("00101"); --5
		s1 <= transport std_logic_vector'("00000011"); --3
		s2 <= transport std_logic_vector'("10010001"); --91
		RA_in <= transport std_logic_vector'("11001001"); --C9
		RB_in <= transport std_logic_vector'("01011000"); --58
		-- --------------------
		WAIT FOR 10 ps; -- Time=380 ps
		AA <= transport std_logic_vector'("00100110"); --26
		BB <= transport std_logic_vector'("00110000"); --30
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("00000001"); --1
		D2 <= transport std_logic_vector'("01011110"); --5E
		OPCode <= transport std_logic_vector'("01011"); --B
		s1 <= transport std_logic_vector'("00011001"); --19
		s2 <= transport std_logic_vector'("01110110"); --76
		RA_in <= transport std_logic_vector'("11101011"); --EB
		RB_in <= transport std_logic_vector'("01001000"); --48
		-- --------------------
		WAIT FOR 10 ps; -- Time=390 ps
		AA <= transport std_logic_vector'("00100111"); --27
		BB <= transport std_logic_vector'("00110001"); --31
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("10001001"); --89
		D2 <= transport std_logic_vector'("11100011"); --E3
		OPCode <= transport std_logic_vector'("01101"); --D
		s1 <= transport std_logic_vector'("10010111"); --97
		s2 <= transport std_logic_vector'("11110001"); --F1
		RA_in <= transport std_logic_vector'("01011001"); --59
		RB_in <= transport std_logic_vector'("10110011"); --B3
		-- --------------------
		WAIT FOR 10 ps; -- Time=400 ps
		AA <= transport std_logic_vector'("00101000"); --28
		BB <= transport std_logic_vector'("00110010"); --32
		D1 <= transport std_logic_vector'("01111110"); --7E
		D2 <= transport std_logic_vector'("01010110"); --56
		OPCode <= transport std_logic_vector'("01110"); --E
		s1 <= transport std_logic_vector'("00000111"); --7
		s2 <= transport std_logic_vector'("11011111"); --DF
		RA_in <= transport std_logic_vector'("01000000"); --40
		RB_in <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 10 ps; -- Time=410 ps
		AA <= transport std_logic_vector'("00101001"); --29
		BB <= transport std_logic_vector'("00110011"); --33
		cy_in <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("10101100"); --AC
		D2 <= transport std_logic_vector'("11011000"); --D8
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("00110001"); --31
		s2 <= transport std_logic_vector'("01011101"); --5D
		RA_in <= transport std_logic_vector'("00001110"); --E
		RB_in <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 10 ps; -- Time=420 ps
		AA <= transport std_logic_vector'("00101010"); --2A
		BB <= transport std_logic_vector'("00110100"); --34
		D1 <= transport std_logic_vector'("00100001"); --21
		D2 <= transport std_logic_vector'("11001011"); --CB
		OPCode <= transport std_logic_vector'("00101"); --5
		s1 <= transport std_logic_vector'("00011110"); --1E
		s2 <= transport std_logic_vector'("11001000"); --C8
		RA_in <= transport std_logic_vector'("01101110"); --6E
		RB_in <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 10 ps; -- Time=430 ps
		AA <= transport std_logic_vector'("00101011"); --2B
		BB <= transport std_logic_vector'("00110101"); --35
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("00101011"); --2B
		D2 <= transport std_logic_vector'("11001111"); --CF
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("00011000"); --18
		s2 <= transport std_logic_vector'("10111101"); --BD
		RA_in <= transport std_logic_vector'("01001111"); --4F
		RB_in <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 10 ps; -- Time=440 ps
		AA <= transport std_logic_vector'("00101100"); --2C
		BB <= transport std_logic_vector'("00110110"); --36
		cy_in <= transport '1';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("01010100"); --54
		D2 <= transport std_logic_vector'("11000110"); --C6
		OPCode <= transport std_logic_vector'("00111"); --7
		s1 <= transport std_logic_vector'("10101000"); --A8
		s2 <= transport std_logic_vector'("00011001"); --19
		RA_in <= transport std_logic_vector'("11011101"); --DD
		RB_in <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 10 ps; -- Time=450 ps
		AA <= transport std_logic_vector'("00101101"); --2D
		BB <= transport std_logic_vector'("00110111"); --37
		D1 <= transport std_logic_vector'("01101100"); --6C
		D2 <= transport std_logic_vector'("11001111"); --CF
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("10010110"); --96
		s2 <= transport std_logic_vector'("11111001"); --F9
		RA_in <= transport std_logic_vector'("10000110"); --86
		RB_in <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 10 ps; -- Time=460 ps
		AA <= transport std_logic_vector'("00101110"); --2E
		BB <= transport std_logic_vector'("00111000"); --38
		cy_in <= transport '0';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01111111"); --7F
		D2 <= transport std_logic_vector'("01001101"); --4D
		OPCode <= transport std_logic_vector'("01100"); --C
		s1 <= transport std_logic_vector'("11101011"); --EB
		s2 <= transport std_logic_vector'("10111010"); --BA
		RA_in <= transport std_logic_vector'("11110110"); --F6
		RB_in <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 10 ps; -- Time=470 ps
		AA <= transport std_logic_vector'("00101111"); --2F
		BB <= transport std_logic_vector'("00111001"); --39
		cy_in <= transport '1';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("11011001"); --D9
		D2 <= transport std_logic_vector'("11100001"); --E1
		OPCode <= transport std_logic_vector'("01001"); --9
		s1 <= transport std_logic_vector'("11110001"); --F1
		s2 <= transport std_logic_vector'("11111001"); --F9
		RA_in <= transport std_logic_vector'("00011010"); --1A
		RB_in <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 10 ps; -- Time=480 ps
		AA <= transport std_logic_vector'("00110000"); --30
		BB <= transport std_logic_vector'("00111010"); --3A
		D1 <= transport std_logic_vector'("00001000"); --8
		D2 <= transport std_logic_vector'("01101011"); --6B
		OPCode <= transport std_logic_vector'("01110"); --E
		s1 <= transport std_logic_vector'("00110000"); --30
		s2 <= transport std_logic_vector'("10010011"); --93
		RA_in <= transport std_logic_vector'("00011111"); --1F
		RB_in <= transport std_logic_vector'("10000010"); --82
		-- --------------------
		WAIT FOR 10 ps; -- Time=490 ps
		AA <= transport std_logic_vector'("00110001"); --31
		BB <= transport std_logic_vector'("00111011"); --3B
		D1 <= transport std_logic_vector'("11011000"); --D8
		D2 <= transport std_logic_vector'("00001100"); --C
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("01110010"); --72
		s2 <= transport std_logic_vector'("10100110"); --A6
		RA_in <= transport std_logic_vector'("01110011"); --73
		RB_in <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 10 ps; -- Time=500 ps
		AA <= transport std_logic_vector'("00110010"); --32
		BB <= transport std_logic_vector'("00111100"); --3C
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01011000"); --58
		D2 <= transport std_logic_vector'("00100101"); --25
		OPCode <= transport std_logic_vector'("00010"); --2
		s1 <= transport std_logic_vector'("10111111"); --BF
		s2 <= transport std_logic_vector'("10001101"); --8D
		RA_in <= transport std_logic_vector'("11000001"); --C1
		RB_in <= transport std_logic_vector'("10001111"); --8F
		-- --------------------
		WAIT FOR 10 ps; -- Time=510 ps
		AA <= transport std_logic_vector'("00110011"); --33
		BB <= transport std_logic_vector'("00111101"); --3D
		cy_in <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("11010011"); --D3
		D2 <= transport std_logic_vector'("01011000"); --58
		OPCode <= transport std_logic_vector'("01100"); --C
		s1 <= transport std_logic_vector'("01100001"); --61
		s2 <= transport std_logic_vector'("11100110"); --E6
		RA_in <= transport std_logic_vector'("11111001"); --F9
		RB_in <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 10 ps; -- Time=520 ps
		AA <= transport std_logic_vector'("00110100"); --34
		BB <= transport std_logic_vector'("00111110"); --3E
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("11010111"); --D7
		D2 <= transport std_logic_vector'("10000101"); --85
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("11100000"); --E0
		s2 <= transport std_logic_vector'("10001110"); --8E
		RA_in <= transport std_logic_vector'("01000101"); --45
		RB_in <= transport std_logic_vector'("11110011"); --F3
		-- --------------------
		WAIT FOR 10 ps; -- Time=530 ps
		AA <= transport std_logic_vector'("00110101"); --35
		BB <= transport std_logic_vector'("00111111"); --3F
		rst <= transport '1';
		D1 <= transport std_logic_vector'("00110001"); --31
		D2 <= transport std_logic_vector'("11001101"); --CD
		OPCode <= transport std_logic_vector'("01010"); --A
		s1 <= transport std_logic_vector'("00000110"); --6
		s2 <= transport std_logic_vector'("10100010"); --A2
		RA_in <= transport std_logic_vector'("00010100"); --14
		RB_in <= transport std_logic_vector'("10110000"); --B0
		-- --------------------
		WAIT FOR 10 ps; -- Time=540 ps
		AA <= transport std_logic_vector'("00110110"); --36
		BB <= transport std_logic_vector'("01000000"); --40
		D1 <= transport std_logic_vector'("11101101"); --ED
		D2 <= transport std_logic_vector'("10010010"); --92
		OPCode <= transport std_logic_vector'("00110"); --6
		s1 <= transport std_logic_vector'("11011011"); --DB
		s2 <= transport std_logic_vector'("01111111"); --7F
		RA_in <= transport std_logic_vector'("00010001"); --11
		RB_in <= transport std_logic_vector'("10110110"); --B6
		-- --------------------
		WAIT FOR 10 ps; -- Time=550 ps
		AA <= transport std_logic_vector'("00110111"); --37
		BB <= transport std_logic_vector'("01000001"); --41
		cy_in <= transport '0';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01011010"); --5A
		D2 <= transport std_logic_vector'("01110100"); --74
		OPCode <= transport std_logic_vector'("01110"); --E
		s1 <= transport std_logic_vector'("10101000"); --A8
		s2 <= transport std_logic_vector'("11000011"); --C3
		RA_in <= transport std_logic_vector'("00101100"); --2C
		RB_in <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 10 ps; -- Time=560 ps
		AA <= transport std_logic_vector'("00111000"); --38
		BB <= transport std_logic_vector'("01000010"); --42
		cy_in <= transport '1';
		rst <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00000011"); --3
		D2 <= transport std_logic_vector'("01010100"); --54
		OPCode <= transport std_logic_vector'("00110"); --6
		s1 <= transport std_logic_vector'("11110111"); --F7
		s2 <= transport std_logic_vector'("01001001"); --49
		RA_in <= transport std_logic_vector'("10001111"); --8F
		RB_in <= transport std_logic_vector'("11100001"); --E1
		-- --------------------
		WAIT FOR 10 ps; -- Time=570 ps
		AA <= transport std_logic_vector'("00111001"); --39
		BB <= transport std_logic_vector'("01000011"); --43
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("10110110"); --B6
		OPCode <= transport std_logic_vector'("00010"); --2
		s1 <= transport std_logic_vector'("10010001"); --91
		s2 <= transport std_logic_vector'("00101111"); --2F
		RA_in <= transport std_logic_vector'("10101001"); --A9
		RB_in <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 10 ps; -- Time=580 ps
		AA <= transport std_logic_vector'("00111010"); --3A
		BB <= transport std_logic_vector'("01000100"); --44
		cy_in <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("01111111"); --7F
		D2 <= transport std_logic_vector'("11010100"); --D4
		OPCode <= transport std_logic_vector'("01001"); --9
		s1 <= transport std_logic_vector'("01111110"); --7E
		s2 <= transport std_logic_vector'("11010010"); --D2
		RA_in <= transport std_logic_vector'("00100110"); --26
		RB_in <= transport std_logic_vector'("01111010"); --7A
		-- --------------------
		WAIT FOR 10 ps; -- Time=590 ps
		AA <= transport std_logic_vector'("00111011"); --3B
		BB <= transport std_logic_vector'("01000101"); --45
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("10101101"); --AD
		D2 <= transport std_logic_vector'("01110101"); --75
		OPCode <= transport std_logic_vector'("01110"); --E
		s1 <= transport std_logic_vector'("00000111"); --7
		s2 <= transport std_logic_vector'("11010000"); --D0
		RA_in <= transport std_logic_vector'("11110011"); --F3
		RB_in <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ps; -- Time=600 ps
		AA <= transport std_logic_vector'("00111100"); --3C
		BB <= transport std_logic_vector'("01000110"); --46
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("11001011"); --CB
		D2 <= transport std_logic_vector'("00011001"); --19
		OPCode <= transport std_logic_vector'("00111"); --7
		s1 <= transport std_logic_vector'("10110110"); --B6
		s2 <= transport std_logic_vector'("00000100"); --4
		RA_in <= transport std_logic_vector'("00111101"); --3D
		RB_in <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 10 ps; -- Time=610 ps
		AA <= transport std_logic_vector'("00111101"); --3D
		BB <= transport std_logic_vector'("01000111"); --47
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("10100111"); --A7
		D2 <= transport std_logic_vector'("11100000"); --E0
		OPCode <= transport std_logic_vector'("01010"); --A
		s1 <= transport std_logic_vector'("01010011"); --53
		s2 <= transport std_logic_vector'("10001100"); --8C
		RA_in <= transport std_logic_vector'("01110010"); --72
		RB_in <= transport std_logic_vector'("10101100"); --AC
		-- --------------------
		WAIT FOR 10 ps; -- Time=620 ps
		AA <= transport std_logic_vector'("00111110"); --3E
		BB <= transport std_logic_vector'("01001000"); --48
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01001101"); --4D
		D2 <= transport std_logic_vector'("00101011"); --2B
		s1 <= transport std_logic_vector'("11101000"); --E8
		s2 <= transport std_logic_vector'("11000110"); --C6
		RA_in <= transport std_logic_vector'("00111110"); --3E
		RB_in <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 10 ps; -- Time=630 ps
		AA <= transport std_logic_vector'("00111111"); --3F
		BB <= transport std_logic_vector'("01001001"); --49
		D1 <= transport std_logic_vector'("00001100"); --C
		D2 <= transport std_logic_vector'("10011100"); --9C
		OPCode <= transport std_logic_vector'("01100"); --C
		s1 <= transport std_logic_vector'("10111101"); --BD
		s2 <= transport std_logic_vector'("01001101"); --4D
		RA_in <= transport std_logic_vector'("10001110"); --8E
		RB_in <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 10 ps; -- Time=640 ps
		AA <= transport std_logic_vector'("01000000"); --40
		BB <= transport std_logic_vector'("01001010"); --4A
		D1 <= transport std_logic_vector'("01101111"); --6F
		D2 <= transport std_logic_vector'("00010011"); --13
		OPCode <= transport std_logic_vector'("00111"); --7
		s1 <= transport std_logic_vector'("01011011"); --5B
		s2 <= transport std_logic_vector'("11111111"); --FF
		RA_in <= transport std_logic_vector'("10010000"); --90
		RB_in <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 10 ps; -- Time=650 ps
		AA <= transport std_logic_vector'("01000001"); --41
		BB <= transport std_logic_vector'("01001011"); --4B
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01000100"); --44
		D2 <= transport std_logic_vector'("10110001"); --B1
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("10001100"); --8C
		s2 <= transport std_logic_vector'("11111010"); --FA
		RA_in <= transport std_logic_vector'("10110000"); --B0
		RB_in <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 10 ps; -- Time=660 ps
		AA <= transport std_logic_vector'("01000010"); --42
		BB <= transport std_logic_vector'("01001100"); --4C
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("10011000"); --98
		D2 <= transport std_logic_vector'("11011000"); --D8
		OPCode <= transport std_logic_vector'("01000"); --8
		s1 <= transport std_logic_vector'("01011001"); --59
		s2 <= transport std_logic_vector'("10011001"); --99
		RA_in <= transport std_logic_vector'("10011011"); --9B
		RB_in <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 10 ps; -- Time=670 ps
		AA <= transport std_logic_vector'("01000011"); --43
		BB <= transport std_logic_vector'("01001101"); --4D
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("10110111"); --B7
		D2 <= transport std_logic_vector'("00101000"); --28
		OPCode <= transport std_logic_vector'("01001"); --9
		s1 <= transport std_logic_vector'("00001010"); --A
		s2 <= transport std_logic_vector'("01111011"); --7B
		RA_in <= transport std_logic_vector'("00111110"); --3E
		RB_in <= transport std_logic_vector'("10101111"); --AF
		-- --------------------
		WAIT FOR 10 ps; -- Time=680 ps
		AA <= transport std_logic_vector'("01000100"); --44
		BB <= transport std_logic_vector'("01001110"); --4E
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00101111"); --2F
		D2 <= transport std_logic_vector'("10000010"); --82
		OPCode <= transport std_logic_vector'("00101"); --5
		s1 <= transport std_logic_vector'("00101000"); --28
		RA_in <= transport std_logic_vector'("11000111"); --C7
		RB_in <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 10 ps; -- Time=690 ps
		AA <= transport std_logic_vector'("01000101"); --45
		BB <= transport std_logic_vector'("01001111"); --4F
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("11001101"); --CD
		D2 <= transport std_logic_vector'("00001000"); --8
		OPCode <= transport std_logic_vector'("00010"); --2
		s1 <= transport std_logic_vector'("01111101"); --7D
		s2 <= transport std_logic_vector'("10111000"); --B8
		RA_in <= transport std_logic_vector'("10100010"); --A2
		RB_in <= transport std_logic_vector'("11011100"); --DC
		-- --------------------
		WAIT FOR 10 ps; -- Time=700 ps
		AA <= transport std_logic_vector'("01000110"); --46
		BB <= transport std_logic_vector'("01010000"); --50
		cy_in <= transport '0';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("10011110"); --9E
		D2 <= transport std_logic_vector'("00011010"); --1A
		OPCode <= transport std_logic_vector'("00110"); --6
		s1 <= transport std_logic_vector'("00010001"); --11
		s2 <= transport std_logic_vector'("10001101"); --8D
		RA_in <= transport std_logic_vector'("01111100"); --7C
		RB_in <= transport std_logic_vector'("11111000"); --F8
		-- --------------------
		WAIT FOR 10 ps; -- Time=710 ps
		AA <= transport std_logic_vector'("01000111"); --47
		BB <= transport std_logic_vector'("01010001"); --51
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("11101111"); --EF
		D2 <= transport std_logic_vector'("01011001"); --59
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("00101110"); --2E
		s2 <= transport std_logic_vector'("10011000"); --98
		RA_in <= transport std_logic_vector'("01000010"); --42
		RB_in <= transport std_logic_vector'("10101101"); --AD
		-- --------------------
		WAIT FOR 10 ps; -- Time=720 ps
		AA <= transport std_logic_vector'("01001000"); --48
		BB <= transport std_logic_vector'("01010010"); --52
		cy_in <= transport '1';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01001100"); --4C
		D2 <= transport std_logic_vector'("10100111"); --A7
		OPCode <= transport std_logic_vector'("00010"); --2
		s1 <= transport std_logic_vector'("01011100"); --5C
		s2 <= transport std_logic_vector'("10110111"); --B7
		RA_in <= transport std_logic_vector'("00100010"); --22
		RB_in <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 10 ps; -- Time=730 ps
		AA <= transport std_logic_vector'("01001001"); --49
		BB <= transport std_logic_vector'("01010011"); --53
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("10000011"); --83
		D2 <= transport std_logic_vector'("00100100"); --24
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("01100101"); --65
		s2 <= transport std_logic_vector'("00000110"); --6
		RA_in <= transport std_logic_vector'("10001000"); --88
		RB_in <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 10 ps; -- Time=740 ps
		AA <= transport std_logic_vector'("01001010"); --4A
		BB <= transport std_logic_vector'("01010100"); --54
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("10100001"); --A1
		D2 <= transport std_logic_vector'("00110001"); --31
		OPCode <= transport std_logic_vector'("00001"); --1
		s1 <= transport std_logic_vector'("01010001"); --51
		s2 <= transport std_logic_vector'("11100001"); --E1
		RA_in <= transport std_logic_vector'("00100001"); --21
		RB_in <= transport std_logic_vector'("10110001"); --B1
		-- --------------------
		WAIT FOR 10 ps; -- Time=750 ps
		AA <= transport std_logic_vector'("01001011"); --4B
		BB <= transport std_logic_vector'("01010101"); --55
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("11110011"); --F3
		D2 <= transport std_logic_vector'("01110000"); --70
		OPCode <= transport std_logic_vector'("01101"); --D
		s1 <= transport std_logic_vector'("01101010"); --6A
		s2 <= transport std_logic_vector'("11100111"); --E7
		RA_in <= transport std_logic_vector'("11011011"); --DB
		RB_in <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 10 ps; -- Time=760 ps
		AA <= transport std_logic_vector'("01001100"); --4C
		BB <= transport std_logic_vector'("01010110"); --56
		cy_in <= transport '1';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00000101"); --5
		D2 <= transport std_logic_vector'("11000001"); --C1
		OPCode <= transport std_logic_vector'("01100"); --C
		s1 <= transport std_logic_vector'("00111000"); --38
		s2 <= transport std_logic_vector'("11110011"); --F3
		RA_in <= transport std_logic_vector'("11100001"); --E1
		RB_in <= transport std_logic_vector'("10011101"); --9D
		-- --------------------
		WAIT FOR 10 ps; -- Time=770 ps
		AA <= transport std_logic_vector'("01001101"); --4D
		BB <= transport std_logic_vector'("01010111"); --57
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("10100101"); --A5
		D2 <= transport std_logic_vector'("01000101"); --45
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("10000100"); --84
		s2 <= transport std_logic_vector'("00100100"); --24
		RA_in <= transport std_logic_vector'("10100010"); --A2
		RB_in <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 10 ps; -- Time=780 ps
		AA <= transport std_logic_vector'("01001110"); --4E
		BB <= transport std_logic_vector'("01011000"); --58
		cy_in <= transport '1';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("11100000"); --E0
		D2 <= transport std_logic_vector'("01011101"); --5D
		OPCode <= transport std_logic_vector'("01011"); --B
		s1 <= transport std_logic_vector'("01011000"); --58
		s2 <= transport std_logic_vector'("11010101"); --D5
		RA_in <= transport std_logic_vector'("11001011"); --CB
		RB_in <= transport std_logic_vector'("01001000"); --48
		-- --------------------
		WAIT FOR 10 ps; -- Time=790 ps
		AA <= transport std_logic_vector'("01001111"); --4F
		BB <= transport std_logic_vector'("01011001"); --59
		cy_in <= transport '0';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00000011"); --3
		D2 <= transport std_logic_vector'("10101011"); --AB
		OPCode <= transport std_logic_vector'("00100"); --4
		s1 <= transport std_logic_vector'("11111100"); --FC
		s2 <= transport std_logic_vector'("10100101"); --A5
		RA_in <= transport std_logic_vector'("01000111"); --47
		RB_in <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 10 ps; -- Time=800 ps
		AA <= transport std_logic_vector'("01010000"); --50
		BB <= transport std_logic_vector'("01011010"); --5A
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("10011010"); --9A
		D2 <= transport std_logic_vector'("00010000"); --10
		OPCode <= transport std_logic_vector'("00101"); --5
		s1 <= transport std_logic_vector'("11111010"); --FA
		s2 <= transport std_logic_vector'("01110000"); --70
		RA_in <= transport std_logic_vector'("01000101"); --45
		RB_in <= transport std_logic_vector'("10111010"); --BA
		-- --------------------
		WAIT FOR 10 ps; -- Time=810 ps
		AA <= transport std_logic_vector'("01010001"); --51
		BB <= transport std_logic_vector'("01011011"); --5B
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01110011"); --73
		D2 <= transport std_logic_vector'("10101011"); --AB
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("00011010"); --1A
		s2 <= transport std_logic_vector'("01010010"); --52
		RA_in <= transport std_logic_vector'("00110001"); --31
		RB_in <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ps; -- Time=820 ps
		AA <= transport std_logic_vector'("01010010"); --52
		BB <= transport std_logic_vector'("01011100"); --5C
		D1 <= transport std_logic_vector'("10011011"); --9B
		D2 <= transport std_logic_vector'("11011111"); --DF
		s1 <= transport std_logic_vector'("01100110"); --66
		s2 <= transport std_logic_vector'("10101010"); --AA
		RA_in <= transport std_logic_vector'("10111000"); --B8
		RB_in <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 10 ps; -- Time=830 ps
		AA <= transport std_logic_vector'("01010011"); --53
		BB <= transport std_logic_vector'("01011101"); --5D
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("01011111"); --5F
		D2 <= transport std_logic_vector'("01001100"); --4C
		OPCode <= transport std_logic_vector'("01001"); --9
		s1 <= transport std_logic_vector'("00100110"); --26
		s2 <= transport std_logic_vector'("00010011"); --13
		RA_in <= transport std_logic_vector'("11001000"); --C8
		RB_in <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 10 ps; -- Time=840 ps
		AA <= transport std_logic_vector'("01010100"); --54
		BB <= transport std_logic_vector'("01011110"); --5E
		D1 <= transport std_logic_vector'("01001100"); --4C
		D2 <= transport std_logic_vector'("11010100"); --D4
		OPCode <= transport std_logic_vector'("01100"); --C
		s1 <= transport std_logic_vector'("11100100"); --E4
		s2 <= transport std_logic_vector'("01101100"); --6C
		RA_in <= transport std_logic_vector'("10001101"); --8D
		RB_in <= transport std_logic_vector'("00010101"); --15
		-- --------------------
		WAIT FOR 10 ps; -- Time=850 ps
		AA <= transport std_logic_vector'("01010101"); --55
		BB <= transport std_logic_vector'("01011111"); --5F
		cy_in <= transport '1';
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("00101110"); --2E
		D2 <= transport std_logic_vector'("10010111"); --97
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("01101000"); --68
		s2 <= transport std_logic_vector'("11010001"); --D1
		RA_in <= transport std_logic_vector'("01110100"); --74
		RB_in <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 10 ps; -- Time=860 ps
		AA <= transport std_logic_vector'("01010110"); --56
		BB <= transport std_logic_vector'("01100000"); --60
		cy_in <= transport '0';
		ac_in <= transport '1';
		D1 <= transport std_logic_vector'("00010011"); --13
		D2 <= transport std_logic_vector'("11110110"); --F6
		OPCode <= transport std_logic_vector'("01001"); --9
		s1 <= transport std_logic_vector'("10111100"); --BC
		s2 <= transport std_logic_vector'("10011111"); --9F
		RA_in <= transport std_logic_vector'("00101010"); --2A
		RB_in <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 10 ps; -- Time=870 ps
		AA <= transport std_logic_vector'("01010111"); --57
		BB <= transport std_logic_vector'("01100001"); --61
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("01001000"); --48
		D2 <= transport std_logic_vector'("10010010"); --92
		OPCode <= transport std_logic_vector'("01101"); --D
		s1 <= transport std_logic_vector'("00101000"); --28
		s2 <= transport std_logic_vector'("01110010"); --72
		RA_in <= transport std_logic_vector'("10011101"); --9D
		RB_in <= transport std_logic_vector'("11101000"); --E8
		-- --------------------
		WAIT FOR 10 ps; -- Time=880 ps
		AA <= transport std_logic_vector'("01011000"); --58
		BB <= transport std_logic_vector'("01100010"); --62
		D1 <= transport std_logic_vector'("01011001"); --59
		D2 <= transport std_logic_vector'("01001101"); --4D
		OPCode <= transport std_logic_vector'("00001"); --1
		s1 <= transport std_logic_vector'("00110101"); --35
		s2 <= transport std_logic_vector'("00101001"); --29
		RA_in <= transport std_logic_vector'("11111001"); --F9
		RB_in <= transport std_logic_vector'("11101101"); --ED
		-- --------------------
		WAIT FOR 10 ps; -- Time=890 ps
		AA <= transport std_logic_vector'("01011001"); --59
		BB <= transport std_logic_vector'("01100011"); --63
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("00010101"); --15
		D2 <= transport std_logic_vector'("01000111"); --47
		OPCode <= transport std_logic_vector'("01010"); --A
		s1 <= transport std_logic_vector'("10101101"); --AD
		s2 <= transport std_logic_vector'("11100000"); --E0
		RA_in <= transport std_logic_vector'("10101011"); --AB
		RB_in <= transport std_logic_vector'("11011110"); --DE
		-- --------------------
		WAIT FOR 10 ps; -- Time=900 ps
		AA <= transport std_logic_vector'("01011010"); --5A
		BB <= transport std_logic_vector'("01100100"); --64
		ac_in <= transport '0';
		D1 <= transport std_logic_vector'("10000111"); --87
		D2 <= transport std_logic_vector'("11100010"); --E2
		OPCode <= transport std_logic_vector'("01101"); --D
		s1 <= transport std_logic_vector'("10011000"); --98
		s2 <= transport std_logic_vector'("11110100"); --F4
		RA_in <= transport std_logic_vector'("01100000"); --60
		RB_in <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ps; -- Time=910 ps
		AA <= transport std_logic_vector'("01011011"); --5B
		BB <= transport std_logic_vector'("01100101"); --65
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("11111101"); --FD
		D2 <= transport std_logic_vector'("10111110"); --BE
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("01000000"); --40
		s2 <= transport std_logic_vector'("00000001"); --1
		RA_in <= transport std_logic_vector'("00000110"); --6
		RB_in <= transport std_logic_vector'("11000111"); --C7
		-- --------------------
		WAIT FOR 10 ps; -- Time=920 ps
		AA <= transport std_logic_vector'("01011100"); --5C
		BB <= transport std_logic_vector'("01100110"); --66
		D1 <= transport std_logic_vector'("00000011"); --3
		D2 <= transport std_logic_vector'("10111100"); --BC
		OPCode <= transport std_logic_vector'("00101"); --5
		s1 <= transport std_logic_vector'("00101101"); --2D
		s2 <= transport std_logic_vector'("11100110"); --E6
		RA_in <= transport std_logic_vector'("11001001"); --C9
		RB_in <= transport std_logic_vector'("10000010"); --82
		-- --------------------
		WAIT FOR 10 ps; -- Time=930 ps
		AA <= transport std_logic_vector'("01011101"); --5D
		BB <= transport std_logic_vector'("01100111"); --67
		cy_in <= transport '0';
		D1 <= transport std_logic_vector'("01101000"); --68
		D2 <= transport std_logic_vector'("11111110"); --FE
		OPCode <= transport std_logic_vector'("00011"); --3
		s1 <= transport std_logic_vector'("00101001"); --29
		s2 <= transport std_logic_vector'("10111111"); --BF
		RA_in <= transport std_logic_vector'("00010110"); --16
		RB_in <= transport std_logic_vector'("10101100"); --AC
		-- --------------------
		WAIT FOR 10 ps; -- Time=940 ps
		AA <= transport std_logic_vector'("01011110"); --5E
		BB <= transport std_logic_vector'("01101000"); --68
		D1 <= transport std_logic_vector'("00110111"); --37
		D2 <= transport std_logic_vector'("11100011"); --E3
		OPCode <= transport std_logic_vector'("00000"); --0
		s1 <= transport std_logic_vector'("00111100"); --3C
		s2 <= transport std_logic_vector'("11101001"); --E9
		RA_in <= transport std_logic_vector'("10011011"); --9B
		RB_in <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 10 ps; -- Time=950 ps
		AA <= transport std_logic_vector'("01011111"); --5F
		BB <= transport std_logic_vector'("01101001"); --69
		cy_in <= transport '1';
		D1 <= transport std_logic_vector'("10111110"); --BE
		D2 <= transport std_logic_vector'("00001111"); --F
		OPCode <= transport std_logic_vector'("01111"); --F
		s1 <= transport std_logic_vector'("10110000"); --B0
		s2 <= transport std_logic_vector'("00000001"); --1
		RA_in <= transport std_logic_vector'("01000100"); --44
		RB_in <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 10 ps; -- Time=960 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION execute_cfg OF execute_tb IS
	FOR testbench_arch
	END FOR;
END execute_cfg;
