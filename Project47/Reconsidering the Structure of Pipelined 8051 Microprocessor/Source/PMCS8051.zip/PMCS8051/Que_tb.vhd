
-- VHDL Test Bench Created from source file que.vhd -- 06:34:49 09/09/2004
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends 
-- that these types always be used for the top-level I/O of a design in order 
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY que_Que_tb_vhd_tb IS
END que_Que_tb_vhd_tb;

ARCHITECTURE behavior OF que_Que_tb_vhd_tb IS 

	COMPONENT que
	PORT(
		in1 : IN std_logic_vector(7 downto 0);
		inst_que_code : IN std_logic_vector(4 downto 0);          
		out1 : OUT std_logic_vector(7 downto 0);
		out2 : OUT std_logic_vector(7 downto 0);
		out3 : OUT std_logic_vector(7 downto 0);
		MCode : OUT std_logic_vector(1 downto 0);
		clock : IN std_logic;
		reset : IN std_logic
		);
	END COMPONENT;

	COMPONENT state
	PORT(
		clock : IN std_logic;
		reset : IN std_logic;
		Mcode : IN std_logic_vector(1 downto 0);          
		inst_que_code : OUT std_logic_vector(4 downto 0)
		);
	END COMPONENT;

	SIGNAL clock :  std_logic:='1';
	SIGNAL reset :  std_logic;
	SIGNAL Mcode :  std_logic_vector(1 downto 0);
	SIGNAL inst_que_code :  std_logic_vector(4 downto 0);


	SIGNAL in1 :  std_logic_vector(7 downto 0);
	SIGNAL out1 :  std_logic_vector(7 downto 0);
	SIGNAL out2 :  std_logic_vector(7 downto 0);
	SIGNAL out3 :  std_logic_vector(7 downto 0);

BEGIN

	uut: que PORT MAP(
		in1 => in1,
		inst_que_code => inst_que_code,
		out1 => out1,
		out2 => out2,
		out3 => out3,
		MCode => MCode,
		clock => clock,
		reset => reset
	);
 	
	uut1: state PORT MAP(
		clock => clock,
		reset => reset,
		Mcode => Mcode,
		inst_que_code => inst_que_code
	);
	clock <= not clock after 5 ns;

	reset <= 	'1',
			'0' after 1 ns;

	in1 <= "ZZZZZZZZ",
		  "00000000" after 10 ns,
		  "00000011" after 20 ns,         --85
            "10010000" after 30 ns,         --90
            "00100000" after 40 ns,         --20
            "10010000" after 50 ns,         --90
            "10010000" after 60 ns,         --90
            "00000000" after 70 ns,         --78
            "00000000" after 80 ns,         --88
            "00010001" after 90 ns,         --11
            "10010000" after 100 ns,         --90
            "00100000" after 110 ns,         --20
            "10010000" after 120 ns,         --90
            "10010000" after 130 ns,         --90
            "00000000" after 140 ns,         --78
            "00000000" after 150 ns;         --88


-- *** Test Bench - User Defined Section ***
   tb : PROCESS
   BEGIN
      wait; -- will wait forever
   END PROCESS;
-- *** End Test Bench - User Defined Section ***

END;
