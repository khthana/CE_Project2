-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 22 23:50:55 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY mem_unit_tw IS
END mem_unit_tw;

ARCHITECTURE testbench_arch OF mem_unit_tw IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT mem_unit
		PORT (
			clk : In  std_logic;
			rst : In  std_logic;
			W_DPH : In  std_logic;
			W_DPL : In  std_logic;
			di_DPH : In  std_logic_vector (7 DOWNTO 0);
			di_DPL : In  std_logic_vector (7 DOWNTO 0);
			dptr : Out  std_logic_vector (15 DOWNTO 0);
			Din0 : In  std_logic_vector (7 DOWNTO 0);
			Din1 : In  std_logic_vector (7 DOWNTO 0);
			PC_in : In  std_logic_vector (15 DOWNTO 0);
			PC_out : Out  std_logic_vector (15 DOWNTO 0);
			en : In  std_logic_vector (1 DOWNTO 0);
			r_addr1 : In  std_logic_vector (7 DOWNTO 0);
			r_addr2 : In  std_logic_vector (7 DOWNTO 0);
			do_1 : Out  std_logic_vector (7 DOWNTO 0);
			do_2 : Out  std_logic_vector (7 DOWNTO 0);
			wr_bank0 : In  std_logic;
			wr_bank1 : In  std_logic;
			w_addr0 : In  std_logic_vector (7 DOWNTO 0);
			w_addr1 : In  std_logic_vector (7 DOWNTO 0);
			sel_as : In  std_logic;
			load_in : In  std_logic;
			sel_mux10 : In  std_logic;
			sel_mux11 : In  std_logic_vector (1 DOWNTO 0);
			sel_mux12 : In  std_logic_vector (1 DOWNTO 0);
			sel_mux13 : In  std_logic;
			sel_mux14 : In  std_logic;
			W_A : In  std_logic;
			di_A : In  std_logic_vector (7 DOWNTO 0);
			do_A : Out  std_logic_vector (7 DOWNTO 0);
			W_B : In  std_logic;
			di_B : In  std_logic_vector (7 DOWNTO 0);
			do_B : Out  std_logic_vector (7 DOWNTO 0);
			W_psw : In  std_logic;
			di_psw : In  std_logic_vector (7 DOWNTO 0);
			do_psw : Out  std_logic_vector (7 DOWNTO 0);
			Carry_in : In  std_logic;
			OverFlow_in : In  std_logic;
			AUX_C_in : In  std_logic;
			R0 : Out  std_logic_vector (7 DOWNTO 0);
			R1 : Out  std_logic_vector (7 DOWNTO 0);
			load_rid : In  std_logic;
			din_rid : In  std_logic_vector (7 DOWNTO 0);
			addr_rid : In  std_logic_vector (2 DOWNTO 0);
			load_p0 : In  std_logic;
			p0_in : In  std_logic_vector (7 DOWNTO 0);
			p0_out : Out  std_logic_vector (7 DOWNTO 0);
			port0_in : In  std_logic_vector (7 DOWNTO 0);
			port0_out : Out  std_logic_vector (7 DOWNTO 0);
			load_p1 : In  std_logic;
			p1_in : In  std_logic_vector (7 DOWNTO 0);
			p1_out : Out  std_logic_vector (7 DOWNTO 0);
			port1_in : In  std_logic_vector (7 DOWNTO 0);
			port1_out : Out  std_logic_vector (7 DOWNTO 0);
			load_p2 : In  std_logic;
			p2_in : In  std_logic_vector (7 DOWNTO 0);
			p2_out : Out  std_logic_vector (7 DOWNTO 0);
			port2_in : In  std_logic_vector (7 DOWNTO 0);
			port2_out : Out  std_logic_vector (7 DOWNTO 0);
			load_p3 : In  std_logic;
			p3_in : In  std_logic_vector (7 DOWNTO 0);
			p3_out : Out  std_logic_vector (7 DOWNTO 0);
			port3_in : In  std_logic_vector (7 DOWNTO 0);
			port3_out : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL clk : std_logic;
	SIGNAL rst : std_logic;
	SIGNAL W_DPH : std_logic;
	SIGNAL W_DPL : std_logic;
	SIGNAL di_DPH : std_logic_vector (7 DOWNTO 0);
	SIGNAL di_DPL : std_logic_vector (7 DOWNTO 0);
	SIGNAL dptr : std_logic_vector (15 DOWNTO 0);
	SIGNAL Din0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL Din1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL PC_in : std_logic_vector (15 DOWNTO 0);
	SIGNAL PC_out : std_logic_vector (15 DOWNTO 0);
	SIGNAL en : std_logic_vector (1 DOWNTO 0);
	SIGNAL r_addr1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL r_addr2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL wr_bank0 : std_logic;
	SIGNAL wr_bank1 : std_logic;
	SIGNAL w_addr0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_addr1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL sel_as : std_logic;
	SIGNAL load_in : std_logic;
	SIGNAL sel_mux10 : std_logic;
	SIGNAL sel_mux11 : std_logic_vector (1 DOWNTO 0);
	SIGNAL sel_mux12 : std_logic_vector (1 DOWNTO 0);
	SIGNAL sel_mux13 : std_logic;
	SIGNAL sel_mux14 : std_logic;
	SIGNAL W_A : std_logic;
	SIGNAL di_A : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_A : std_logic_vector (7 DOWNTO 0);
	SIGNAL W_B : std_logic;
	SIGNAL di_B : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_B : std_logic_vector (7 DOWNTO 0);
	SIGNAL W_psw : std_logic;
	SIGNAL di_psw : std_logic_vector (7 DOWNTO 0);
	SIGNAL do_psw : std_logic_vector (7 DOWNTO 0);
	SIGNAL Carry_in : std_logic;
	SIGNAL OverFlow_in : std_logic;
	SIGNAL AUX_C_in : std_logic;
	SIGNAL R0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL R1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_rid : std_logic;
	SIGNAL din_rid : std_logic_vector (7 DOWNTO 0);
	SIGNAL addr_rid : std_logic_vector (2 DOWNTO 0);
	SIGNAL load_p0 : std_logic;
	SIGNAL p0_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL p0_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL port0_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL port0_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_p1 : std_logic;
	SIGNAL p1_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL p1_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL port1_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL port1_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_p2 : std_logic;
	SIGNAL p2_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL p2_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL port2_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL port2_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_p3 : std_logic;
	SIGNAL p3_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL p3_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL port3_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL port3_out : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : mem_unit
	PORT MAP (
		clk => clk,
		rst => rst,
		W_DPH => W_DPH,
		W_DPL => W_DPL,
		di_DPH => di_DPH,
		di_DPL => di_DPL,
		dptr => dptr,
		Din0 => Din0,
		Din1 => Din1,
		PC_in => PC_in,
		PC_out => PC_out,
		en => en,
		r_addr1 => r_addr1,
		r_addr2 => r_addr2,
		do_1 => do_1,
		do_2 => do_2,
		wr_bank0 => wr_bank0,
		wr_bank1 => wr_bank1,
		w_addr0 => w_addr0,
		w_addr1 => w_addr1,
		sel_as => sel_as,
		load_in => load_in,
		sel_mux10 => sel_mux10,
		sel_mux11 => sel_mux11,
		sel_mux12 => sel_mux12,
		sel_mux13 => sel_mux13,
		sel_mux14 => sel_mux14,
		W_A => W_A,
		di_A => di_A,
		do_A => do_A,
		W_B => W_B,
		di_B => di_B,
		do_B => do_B,
		W_psw => W_psw,
		di_psw => di_psw,
		do_psw => do_psw,
		Carry_in => Carry_in,
		OverFlow_in => OverFlow_in,
		AUX_C_in => AUX_C_in,
		R0 => R0,
		R1 => R1,
		load_rid => load_rid,
		din_rid => din_rid,
		addr_rid => addr_rid,
		load_p0 => load_p0,
		p0_in => p0_in,
		p0_out => p0_out,
		port0_in => port0_in,
		port0_out => port0_out,
		load_p1 => load_p1,
		p1_in => p1_in,
		p1_out => p1_out,
		port1_in => port1_in,
		port1_out => port1_out,
		load_p2 => load_p2,
		p2_in => p2_in,
		p2_out => p2_out,
		port2_in => port2_in,
		port2_out => port2_out,
		load_p3 => load_p3,
		p3_in => p3_in,
		p3_out => p3_out,
		port3_in => port3_in,
		port3_out => port3_out
	);

	PROCESS -- clock process for clk,
	BEGIN
		CLOCK_LOOP : LOOP
		clk <= transport '0';
		WAIT FOR 10 ps;
		clk <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clk <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clk
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_PC_out(
			next_PC_out : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (PC_out /= next_PC_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps PC_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, PC_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_PC_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_dptr(
			next_dptr : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (dptr /= next_dptr) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps dptr="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, dptr);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_dptr);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_do_A(
			next_do_A : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_A /= next_do_A) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_A="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_A);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_A);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_do_B(
			next_do_B : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_B /= next_do_B) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_B="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_B);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_B);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_do_psw(
			next_do_psw : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_psw /= next_do_psw) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_psw="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_psw);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_psw);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_R0(
			next_R0 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (R0 /= next_R0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps R0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, R0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_R0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_R1(
			next_R1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (R1 /= next_R1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps R1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, R1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_R1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p0_out(
			next_p0_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p0_out /= next_p0_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p0_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p0_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p0_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p1_out(
			next_p1_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p1_out /= next_p1_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p1_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p1_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p1_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p2_out(
			next_p2_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p2_out /= next_p2_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p2_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p2_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p2_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p3_out(
			next_p3_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p3_out /= next_p3_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p3_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p3_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p3_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_do_1(
			next_do_1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_1 /= next_do_1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_do_2(
			next_do_2 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (do_2 /= next_do_2) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps do_2="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, do_2);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_do_2);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_port0_out(
			next_port0_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (port0_out /= next_port0_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps port0_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port0_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port0_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_port1_out(
			next_port1_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (port1_out /= next_port1_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps port1_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port1_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port1_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_port2_out(
			next_port2_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (port2_out /= next_port2_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps port2_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port2_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port2_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_port3_out(
			next_port3_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (port3_out /= next_port3_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps port3_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port3_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port3_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		rst <= transport '1';
		PC_in <= transport std_logic_vector'("1001101101010001"); --9B51
		Din0 <= transport std_logic_vector'("01010011"); --53
		Din1 <= transport std_logic_vector'("01010010"); --52
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00000000"); --0
		w_addr1 <= transport std_logic_vector'("01010000"); --50
		r_addr1 <= transport std_logic_vector'("00000000"); --0
		sel_as <= transport '0';
		sel_mux10 <= transport '0';
		sel_mux11 <= transport std_logic_vector'("10"); --2
		sel_mux12 <= transport std_logic_vector'("10"); --2
		sel_mux13 <= transport '1';
		sel_mux14 <= transport '1';
		wr_bank0 <= transport '1';
		wr_bank1 <= transport '1';
		load_in <= transport '0';
		W_psw <= transport '0';
		di_psw <= transport std_logic_vector'("00000000"); --0
		p0_in <= transport std_logic_vector'("00000000"); --0
		p1_in <= transport std_logic_vector'("00000000"); --0
		p2_in <= transport std_logic_vector'("00000000"); --0
		p3_in <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		PC_in <= transport std_logic_vector'("0000110101010110"); --D56
		Din0 <= transport std_logic_vector'("10001101"); --8D
		Din1 <= transport std_logic_vector'("01110001"); --71
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00000001"); --1
		w_addr1 <= transport std_logic_vector'("00111011"); --3B
		r_addr1 <= transport std_logic_vector'("00000001"); --1
		W_psw <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		PC_in <= transport std_logic_vector'("0110011111110010"); --67F2
		Din0 <= transport std_logic_vector'("01001011"); --4B
		Din1 <= transport std_logic_vector'("00011110"); --1E
		w_addr0 <= transport std_logic_vector'("00000010"); --2
		w_addr1 <= transport std_logic_vector'("11000101"); --C5
		r_addr1 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		rst <= transport '0';
		PC_in <= transport std_logic_vector'("0100101001000010"); --4A42
		Din0 <= transport std_logic_vector'("00000001"); --1
		Din1 <= transport std_logic_vector'("00100010"); --22
		w_addr0 <= transport std_logic_vector'("00000011"); --3
		w_addr1 <= transport std_logic_vector'("01100010"); --62
		r_addr1 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		PC_in <= transport std_logic_vector'("1001100010100010"); --98A2
		Din0 <= transport std_logic_vector'("01100110"); --66
		Din1 <= transport std_logic_vector'("10000100"); --84
		w_addr0 <= transport std_logic_vector'("00000100"); --4
		w_addr1 <= transport std_logic_vector'("11000001"); --C1
		r_addr1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		PC_in <= transport std_logic_vector'("0111000110110001"); --71B1
		Din0 <= transport std_logic_vector'("01101110"); --6E
		Din1 <= transport std_logic_vector'("10010000"); --90
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00000101"); --5
		w_addr1 <= transport std_logic_vector'("11010011"); --D3
		r_addr1 <= transport std_logic_vector'("00000101"); --5
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		PC_in <= transport std_logic_vector'("0011011101001011"); --374B
		Din0 <= transport std_logic_vector'("01001101"); --4D
		Din1 <= transport std_logic_vector'("11001100"); --CC
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00000110"); --6
		w_addr1 <= transport std_logic_vector'("11001010"); --CA
		r_addr1 <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		PC_in <= transport std_logic_vector'("1000100110001101"); --898D
		Din0 <= transport std_logic_vector'("01111010"); --7A
		Din1 <= transport std_logic_vector'("00000011"); --3
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00000111"); --7
		w_addr1 <= transport std_logic_vector'("00010111"); --17
		r_addr1 <= transport std_logic_vector'("00000111"); --7
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		PC_in <= transport std_logic_vector'("0100101011010100"); --4AD4
		Din0 <= transport std_logic_vector'("10101000"); --A8
		Din1 <= transport std_logic_vector'("00111110"); --3E
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00001000"); --8
		w_addr1 <= transport std_logic_vector'("01101010"); --6A
		r_addr1 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		PC_in <= transport std_logic_vector'("1001101110111101"); --9BBD
		Din0 <= transport std_logic_vector'("11001101"); --CD
		Din1 <= transport std_logic_vector'("11000101"); --C5
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00001001"); --9
		w_addr1 <= transport std_logic_vector'("10110101"); --B5
		r_addr1 <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		PC_in <= transport std_logic_vector'("1101110000100101"); --DC25
		Din0 <= transport std_logic_vector'("00011110"); --1E
		Din1 <= transport std_logic_vector'("00100010"); --22
		w_addr0 <= transport std_logic_vector'("00001010"); --A
		w_addr1 <= transport std_logic_vector'("00101000"); --28
		r_addr1 <= transport std_logic_vector'("00001010"); --A
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		PC_in <= transport std_logic_vector'("1010111000101001"); --AE29
		Din0 <= transport std_logic_vector'("00010000"); --10
		Din1 <= transport std_logic_vector'("00011101"); --1D
		w_addr0 <= transport std_logic_vector'("00001011"); --B
		w_addr1 <= transport std_logic_vector'("00110101"); --35
		r_addr1 <= transport std_logic_vector'("00001011"); --B
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		PC_in <= transport std_logic_vector'("1111001000100110"); --F226
		Din0 <= transport std_logic_vector'("01011000"); --58
		Din1 <= transport std_logic_vector'("10111111"); --BF
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00001100"); --C
		w_addr1 <= transport std_logic_vector'("10001100"); --8C
		r_addr1 <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		PC_in <= transport std_logic_vector'("1100101010111001"); --CAB9
		Din0 <= transport std_logic_vector'("11101011"); --EB
		Din1 <= transport std_logic_vector'("01010010"); --52
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00001101"); --D
		w_addr1 <= transport std_logic_vector'("00100000"); --20
		r_addr1 <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		PC_in <= transport std_logic_vector'("1001011010111111"); --96BF
		Din0 <= transport std_logic_vector'("11111110"); --FE
		Din1 <= transport std_logic_vector'("01011110"); --5E
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00001110"); --E
		w_addr1 <= transport std_logic_vector'("00011111"); --1F
		r_addr1 <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		PC_in <= transport std_logic_vector'("1111011101010101"); --F755
		Din0 <= transport std_logic_vector'("00000101"); --5
		Din1 <= transport std_logic_vector'("10101101"); --AD
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00001111"); --F
		w_addr1 <= transport std_logic_vector'("11111100"); --FC
		r_addr1 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		PC_in <= transport std_logic_vector'("1100111111011000"); --CFD8
		Din0 <= transport std_logic_vector'("10110111"); --B7
		Din1 <= transport std_logic_vector'("01000111"); --47
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00010000"); --10
		w_addr1 <= transport std_logic_vector'("01101000"); --68
		r_addr1 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		PC_in <= transport std_logic_vector'("0011111011100101"); --3EE5
		Din0 <= transport std_logic_vector'("00000111"); --7
		Din1 <= transport std_logic_vector'("01110110"); --76
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00010001"); --11
		w_addr1 <= transport std_logic_vector'("01010100"); --54
		r_addr1 <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		PC_in <= transport std_logic_vector'("1010011001011001"); --A659
		Din0 <= transport std_logic_vector'("00101011"); --2B
		Din1 <= transport std_logic_vector'("11000010"); --C2
		w_addr0 <= transport std_logic_vector'("00010010"); --12
		w_addr1 <= transport std_logic_vector'("11110000"); --F0
		r_addr1 <= transport std_logic_vector'("00010010"); --12
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		PC_in <= transport std_logic_vector'("1010011001010001"); --A651
		Din0 <= transport std_logic_vector'("10011000"); --98
		Din1 <= transport std_logic_vector'("11110101"); --F5
		w_addr0 <= transport std_logic_vector'("00010011"); --13
		w_addr1 <= transport std_logic_vector'("10101101"); --AD
		r_addr1 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		PC_in <= transport std_logic_vector'("0010000100101010"); --212A
		Din0 <= transport std_logic_vector'("00000011"); --3
		Din1 <= transport std_logic_vector'("00010111"); --17
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00010100"); --14
		w_addr1 <= transport std_logic_vector'("00111101"); --3D
		r_addr1 <= transport std_logic_vector'("00010100"); --14
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		PC_in <= transport std_logic_vector'("0011100010000001"); --3881
		Din0 <= transport std_logic_vector'("01100001"); --61
		Din1 <= transport std_logic_vector'("01110001"); --71
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00010101"); --15
		w_addr1 <= transport std_logic_vector'("10010001"); --91
		r_addr1 <= transport std_logic_vector'("00010101"); --15
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		PC_in <= transport std_logic_vector'("0100101100110011"); --4B33
		Din0 <= transport std_logic_vector'("11100111"); --E7
		Din1 <= transport std_logic_vector'("10001101"); --8D
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00010110"); --16
		w_addr1 <= transport std_logic_vector'("11011001"); --D9
		r_addr1 <= transport std_logic_vector'("00010110"); --16
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		PC_in <= transport std_logic_vector'("1111101101011101"); --FB5D
		Din0 <= transport std_logic_vector'("00001010"); --A
		Din1 <= transport std_logic_vector'("00110100"); --34
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00010111"); --17
		w_addr1 <= transport std_logic_vector'("10000111"); --87
		r_addr1 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		PC_in <= transport std_logic_vector'("0010100101011101"); --295D
		Din0 <= transport std_logic_vector'("01111110"); --7E
		Din1 <= transport std_logic_vector'("01101101"); --6D
		w_addr0 <= transport std_logic_vector'("00011000"); --18
		w_addr1 <= transport std_logic_vector'("01001100"); --4C
		r_addr1 <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		PC_in <= transport std_logic_vector'("1111011111001110"); --F7CE
		Din0 <= transport std_logic_vector'("00111010"); --3A
		Din1 <= transport std_logic_vector'("10000100"); --84
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00011001"); --19
		w_addr1 <= transport std_logic_vector'("00011000"); --18
		r_addr1 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		PC_in <= transport std_logic_vector'("1100010110001110"); --C58E
		Din0 <= transport std_logic_vector'("01110001"); --71
		Din1 <= transport std_logic_vector'("11111111"); --FF
		w_addr0 <= transport std_logic_vector'("00011010"); --1A
		w_addr1 <= transport std_logic_vector'("00011100"); --1C
		r_addr1 <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		PC_in <= transport std_logic_vector'("0011010010111010"); --34BA
		Din0 <= transport std_logic_vector'("10011001"); --99
		Din1 <= transport std_logic_vector'("10101010"); --AA
		w_addr0 <= transport std_logic_vector'("00011011"); --1B
		w_addr1 <= transport std_logic_vector'("11001010"); --CA
		r_addr1 <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		rst <= transport '1';
		PC_in <= transport std_logic_vector'("0010011010101111"); --26AF
		Din0 <= transport std_logic_vector'("01100111"); --67
		Din1 <= transport std_logic_vector'("10001011"); --8B
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00011100"); --1C
		w_addr1 <= transport std_logic_vector'("11010011"); --D3
		r_addr1 <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		PC_in <= transport std_logic_vector'("1011101100001011"); --BB0B
		Din0 <= transport std_logic_vector'("11010000"); --D0
		Din1 <= transport std_logic_vector'("11101110"); --EE
		w_addr0 <= transport std_logic_vector'("00011101"); --1D
		w_addr1 <= transport std_logic_vector'("00101000"); --28
		r_addr1 <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		PC_in <= transport std_logic_vector'("0101010010101001"); --54A9
		Din0 <= transport std_logic_vector'("00001001"); --9
		Din1 <= transport std_logic_vector'("01011001"); --59
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00011110"); --1E
		w_addr1 <= transport std_logic_vector'("11111000"); --F8
		r_addr1 <= transport std_logic_vector'("00011110"); --1E
		sel_mux10 <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		rst <= transport '0';
		PC_in <= transport std_logic_vector'("1001001110100111"); --93A7
		Din0 <= transport std_logic_vector'("10000111"); --87
		Din1 <= transport std_logic_vector'("10010111"); --97
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00011111"); --1F
		w_addr1 <= transport std_logic_vector'("10110111"); --B7
		r_addr1 <= transport std_logic_vector'("00011111"); --1F
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		PC_in <= transport std_logic_vector'("0101100001100010"); --5862
		Din0 <= transport std_logic_vector'("11111111"); --FF
		Din1 <= transport std_logic_vector'("10110001"); --B1
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00100000"); --20
		w_addr1 <= transport std_logic_vector'("00010100"); --14
		r_addr1 <= transport std_logic_vector'("00100000"); --20
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		PC_in <= transport std_logic_vector'("1100010001111000"); --C478
		Din0 <= transport std_logic_vector'("01100101"); --65
		Din1 <= transport std_logic_vector'("11101111"); --EF
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00100001"); --21
		w_addr1 <= transport std_logic_vector'("00000001"); --1
		r_addr1 <= transport std_logic_vector'("00100001"); --21
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		PC_in <= transport std_logic_vector'("0011100111000100"); --39C4
		Din0 <= transport std_logic_vector'("11110000"); --F0
		Din1 <= transport std_logic_vector'("11011010"); --DA
		w_addr0 <= transport std_logic_vector'("00100010"); --22
		w_addr1 <= transport std_logic_vector'("10101110"); --AE
		r_addr1 <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		PC_in <= transport std_logic_vector'("0101011101100100"); --5764
		Din0 <= transport std_logic_vector'("00010011"); --13
		Din1 <= transport std_logic_vector'("00111100"); --3C
		w_addr0 <= transport std_logic_vector'("00100011"); --23
		w_addr1 <= transport std_logic_vector'("10001101"); --8D
		r_addr1 <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		PC_in <= transport std_logic_vector'("1111111110110110"); --FFB6
		Din0 <= transport std_logic_vector'("10000101"); --85
		Din1 <= transport std_logic_vector'("00011101"); --1D
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00100100"); --24
		w_addr1 <= transport std_logic_vector'("01001110"); --4E
		r_addr1 <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		PC_in <= transport std_logic_vector'("0101001101010101"); --5355
		Din0 <= transport std_logic_vector'("00111001"); --39
		Din1 <= transport std_logic_vector'("11000111"); --C7
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00100101"); --25
		w_addr1 <= transport std_logic_vector'("11100011"); --E3
		r_addr1 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		PC_in <= transport std_logic_vector'("1011001000011111"); --B21F
		Din0 <= transport std_logic_vector'("01100101"); --65
		Din1 <= transport std_logic_vector'("11000010"); --C2
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00100110"); --26
		w_addr1 <= transport std_logic_vector'("01111101"); --7D
		r_addr1 <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		PC_in <= transport std_logic_vector'("1100000000110010"); --C032
		Din0 <= transport std_logic_vector'("01111110"); --7E
		Din1 <= transport std_logic_vector'("11011000"); --D8
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00100111"); --27
		w_addr1 <= transport std_logic_vector'("10001100"); --8C
		r_addr1 <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		PC_in <= transport std_logic_vector'("0101101111101001"); --5BE9
		Din0 <= transport std_logic_vector'("00111000"); --38
		Din1 <= transport std_logic_vector'("00010001"); --11
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00101000"); --28
		w_addr1 <= transport std_logic_vector'("11000001"); --C1
		r_addr1 <= transport std_logic_vector'("00101000"); --28
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		PC_in <= transport std_logic_vector'("1010011011100011"); --A6E3
		Din0 <= transport std_logic_vector'("10001010"); --8A
		Din1 <= transport std_logic_vector'("10110110"); --B6
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00101001"); --29
		w_addr1 <= transport std_logic_vector'("00001111"); --F
		r_addr1 <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		PC_in <= transport std_logic_vector'("0000001011111011"); --2FB
		Din0 <= transport std_logic_vector'("10101000"); --A8
		Din1 <= transport std_logic_vector'("01010001"); --51
		w_addr0 <= transport std_logic_vector'("00101010"); --2A
		w_addr1 <= transport std_logic_vector'("10100101"); --A5
		r_addr1 <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 100 ps; -- Time=4300 ps
		PC_in <= transport std_logic_vector'("0000111001001111"); --E4F
		Din0 <= transport std_logic_vector'("00000110"); --6
		Din1 <= transport std_logic_vector'("10101011"); --AB
		w_addr0 <= transport std_logic_vector'("00101011"); --2B
		w_addr1 <= transport std_logic_vector'("11110100"); --F4
		r_addr1 <= transport std_logic_vector'("00101011"); --2B
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4400 ps
		PC_in <= transport std_logic_vector'("1010110100111101"); --AD3D
		Din0 <= transport std_logic_vector'("01011011"); --5B
		Din1 <= transport std_logic_vector'("11001100"); --CC
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00101100"); --2C
		w_addr1 <= transport std_logic_vector'("10101110"); --AE
		r_addr1 <= transport std_logic_vector'("00101100"); --2C
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4500 ps
		PC_in <= transport std_logic_vector'("1111111101100000"); --FF60
		Din0 <= transport std_logic_vector'("10011010"); --9A
		Din1 <= transport std_logic_vector'("11111101"); --FD
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00101101"); --2D
		w_addr1 <= transport std_logic_vector'("11000100"); --C4
		r_addr1 <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 100 ps; -- Time=4600 ps
		PC_in <= transport std_logic_vector'("0110011010010111"); --6697
		Din0 <= transport std_logic_vector'("11111001"); --F9
		Din1 <= transport std_logic_vector'("11001000"); --C8
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00101110"); --2E
		w_addr1 <= transport std_logic_vector'("01100110"); --66
		r_addr1 <= transport std_logic_vector'("00101110"); --2E
		-- --------------------
		WAIT FOR 100 ps; -- Time=4700 ps
		PC_in <= transport std_logic_vector'("1000001011111101"); --82FD
		Din0 <= transport std_logic_vector'("11101101"); --ED
		Din1 <= transport std_logic_vector'("11110101"); --F5
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00101111"); --2F
		w_addr1 <= transport std_logic_vector'("00000110"); --6
		r_addr1 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 100 ps; -- Time=4800 ps
		PC_in <= transport std_logic_vector'("0011010011110001"); --34F1
		Din0 <= transport std_logic_vector'("00101011"); --2B
		Din1 <= transport std_logic_vector'("10001110"); --8E
		w_addr0 <= transport std_logic_vector'("00110000"); --30
		w_addr1 <= transport std_logic_vector'("01010100"); --54
		r_addr1 <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 100 ps; -- Time=4900 ps
		PC_in <= transport std_logic_vector'("1001111000001110"); --9E0E
		Din0 <= transport std_logic_vector'("10101000"); --A8
		Din1 <= transport std_logic_vector'("11011011"); --DB
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00110001"); --31
		w_addr1 <= transport std_logic_vector'("01000010"); --42
		r_addr1 <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 100 ps; -- Time=5000 ps
		PC_in <= transport std_logic_vector'("0010000000110011"); --2033
		Din0 <= transport std_logic_vector'("10011001"); --99
		Din1 <= transport std_logic_vector'("01100110"); --66
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00110010"); --32
		w_addr1 <= transport std_logic_vector'("00000000"); --0
		r_addr1 <= transport std_logic_vector'("00110010"); --32
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=5100 ps
		PC_in <= transport std_logic_vector'("0101101101111100"); --5B7C
		Din0 <= transport std_logic_vector'("01110010"); --72
		Din1 <= transport std_logic_vector'("11110111"); --F7
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00110011"); --33
		r_addr1 <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 100 ps; -- Time=5200 ps
		PC_in <= transport std_logic_vector'("0011000001000101"); --3045
		Din0 <= transport std_logic_vector'("11101010"); --EA
		Din1 <= transport std_logic_vector'("10010111"); --97
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00110100"); --34
		w_addr1 <= transport std_logic_vector'("11110011"); --F3
		r_addr1 <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 100 ps; -- Time=5300 ps
		PC_in <= transport std_logic_vector'("1100000100101101"); --C12D
		Din0 <= transport std_logic_vector'("11110100"); --F4
		Din1 <= transport std_logic_vector'("10010000"); --90
		w_addr0 <= transport std_logic_vector'("00110101"); --35
		w_addr1 <= transport std_logic_vector'("11001001"); --C9
		r_addr1 <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 100 ps; -- Time=5400 ps
		PC_in <= transport std_logic_vector'("0110111000001111"); --6E0F
		Din0 <= transport std_logic_vector'("11000110"); --C6
		Din1 <= transport std_logic_vector'("01101011"); --6B
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00110110"); --36
		w_addr1 <= transport std_logic_vector'("10110100"); --B4
		r_addr1 <= transport std_logic_vector'("00110110"); --36
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5500 ps
		PC_in <= transport std_logic_vector'("1101100100001010"); --D90A
		Din0 <= transport std_logic_vector'("11010110"); --D6
		Din1 <= transport std_logic_vector'("11110000"); --F0
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00110111"); --37
		w_addr1 <= transport std_logic_vector'("00100100"); --24
		r_addr1 <= transport std_logic_vector'("00110111"); --37
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5600 ps
		rst <= transport '1';
		PC_in <= transport std_logic_vector'("1110001001111010"); --E27A
		Din0 <= transport std_logic_vector'("11010111"); --D7
		Din1 <= transport std_logic_vector'("00101000"); --28
		w_addr0 <= transport std_logic_vector'("00111000"); --38
		w_addr1 <= transport std_logic_vector'("11001011"); --CB
		r_addr1 <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 100 ps; -- Time=5700 ps
		PC_in <= transport std_logic_vector'("1010101011111011"); --AAFB
		Din0 <= transport std_logic_vector'("10111111"); --BF
		Din1 <= transport std_logic_vector'("01011101"); --5D
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("00111001"); --39
		w_addr1 <= transport std_logic_vector'("10011010"); --9A
		r_addr1 <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 100 ps; -- Time=5800 ps
		PC_in <= transport std_logic_vector'("1001001101101100"); --936C
		Din0 <= transport std_logic_vector'("11000010"); --C2
		Din1 <= transport std_logic_vector'("00010111"); --17
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00111010"); --3A
		w_addr1 <= transport std_logic_vector'("11000001"); --C1
		r_addr1 <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 100 ps; -- Time=5900 ps
		rst <= transport '0';
		PC_in <= transport std_logic_vector'("0011110011101001"); --3CE9
		Din0 <= transport std_logic_vector'("01010111"); --57
		Din1 <= transport std_logic_vector'("00100000"); --20
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00111011"); --3B
		w_addr1 <= transport std_logic_vector'("10110010"); --B2
		r_addr1 <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 100 ps; -- Time=6000 ps
		PC_in <= transport std_logic_vector'("1000100111001110"); --89CE
		Din0 <= transport std_logic_vector'("00110010"); --32
		Din1 <= transport std_logic_vector'("10000000"); --80
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("00111100"); --3C
		w_addr1 <= transport std_logic_vector'("00011101"); --1D
		r_addr1 <= transport std_logic_vector'("00111100"); --3C
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=6100 ps
		PC_in <= transport std_logic_vector'("1001100010111010"); --98BA
		Din0 <= transport std_logic_vector'("01000111"); --47
		Din1 <= transport std_logic_vector'("10000001"); --81
		w_addr0 <= transport std_logic_vector'("00111101"); --3D
		w_addr1 <= transport std_logic_vector'("11110100"); --F4
		r_addr1 <= transport std_logic_vector'("00111101"); --3D
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6200 ps
		PC_in <= transport std_logic_vector'("1100110010001001"); --CC89
		Din0 <= transport std_logic_vector'("11001101"); --CD
		Din1 <= transport std_logic_vector'("10101011"); --AB
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("00111110"); --3E
		w_addr1 <= transport std_logic_vector'("01100111"); --67
		r_addr1 <= transport std_logic_vector'("00111110"); --3E
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6300 ps
		PC_in <= transport std_logic_vector'("1100010101011000"); --C558
		Din0 <= transport std_logic_vector'("00110111"); --37
		Din1 <= transport std_logic_vector'("11000111"); --C7
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("00111111"); --3F
		w_addr1 <= transport std_logic_vector'("11101000"); --E8
		r_addr1 <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 100 ps; -- Time=6400 ps
		PC_in <= transport std_logic_vector'("0110010110000011"); --6583
		Din0 <= transport std_logic_vector'("00111011"); --3B
		Din1 <= transport std_logic_vector'("11011111"); --DF
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01000000"); --40
		w_addr1 <= transport std_logic_vector'("00101000"); --28
		r_addr1 <= transport std_logic_vector'("01000000"); --40
		-- --------------------
		WAIT FOR 100 ps; -- Time=6500 ps
		PC_in <= transport std_logic_vector'("1100101110101001"); --CBA9
		Din0 <= transport std_logic_vector'("11001110"); --CE
		Din1 <= transport std_logic_vector'("00111100"); --3C
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01000001"); --41
		w_addr1 <= transport std_logic_vector'("00010111"); --17
		r_addr1 <= transport std_logic_vector'("01000001"); --41
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6600 ps
		PC_in <= transport std_logic_vector'("0101101110100110"); --5BA6
		Din0 <= transport std_logic_vector'("00100101"); --25
		Din1 <= transport std_logic_vector'("01100110"); --66
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01000010"); --42
		w_addr1 <= transport std_logic_vector'("11100110"); --E6
		r_addr1 <= transport std_logic_vector'("01000010"); --42
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6700 ps
		PC_in <= transport std_logic_vector'("1011001110010111"); --B397
		Din0 <= transport std_logic_vector'("10110101"); --B5
		Din1 <= transport std_logic_vector'("00100110"); --26
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01000011"); --43
		w_addr1 <= transport std_logic_vector'("00001000"); --8
		r_addr1 <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 100 ps; -- Time=6800 ps
		PC_in <= transport std_logic_vector'("1011011011011001"); --B6D9
		Din0 <= transport std_logic_vector'("00110011"); --33
		Din1 <= transport std_logic_vector'("10000110"); --86
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01000100"); --44
		w_addr1 <= transport std_logic_vector'("00101100"); --2C
		r_addr1 <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 100 ps; -- Time=6900 ps
		PC_in <= transport std_logic_vector'("1000010000001001"); --8409
		Din0 <= transport std_logic_vector'("10010100"); --94
		Din1 <= transport std_logic_vector'("11001110"); --CE
		w_addr0 <= transport std_logic_vector'("01000101"); --45
		w_addr1 <= transport std_logic_vector'("01000011"); --43
		r_addr1 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ps; -- Time=7000 ps
		PC_in <= transport std_logic_vector'("0111111000000011"); --7E03
		Din0 <= transport std_logic_vector'("00001100"); --C
		Din1 <= transport std_logic_vector'("10001000"); --88
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01000110"); --46
		w_addr1 <= transport std_logic_vector'("01111111"); --7F
		r_addr1 <= transport std_logic_vector'("01000110"); --46
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=7100 ps
		PC_in <= transport std_logic_vector'("0100011011100110"); --46E6
		Din0 <= transport std_logic_vector'("00010010"); --12
		Din1 <= transport std_logic_vector'("01111100"); --7C
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01000111"); --47
		w_addr1 <= transport std_logic_vector'("01010001"); --51
		r_addr1 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 100 ps; -- Time=7200 ps
		PC_in <= transport std_logic_vector'("1011110000001110"); --BC0E
		Din0 <= transport std_logic_vector'("01011001"); --59
		Din1 <= transport std_logic_vector'("10110100"); --B4
		w_addr0 <= transport std_logic_vector'("01001000"); --48
		w_addr1 <= transport std_logic_vector'("01101001"); --69
		r_addr1 <= transport std_logic_vector'("01001000"); --48
		-- --------------------
		WAIT FOR 100 ps; -- Time=7300 ps
		PC_in <= transport std_logic_vector'("0000001000011000"); --218
		Din0 <= transport std_logic_vector'("11010111"); --D7
		Din1 <= transport std_logic_vector'("01111000"); --78
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("01001001"); --49
		w_addr1 <= transport std_logic_vector'("10111001"); --B9
		r_addr1 <= transport std_logic_vector'("01001001"); --49
		-- --------------------
		WAIT FOR 100 ps; -- Time=7400 ps
		PC_in <= transport std_logic_vector'("0111100011100001"); --78E1
		Din0 <= transport std_logic_vector'("11000001"); --C1
		Din1 <= transport std_logic_vector'("01010001"); --51
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01001010"); --4A
		w_addr1 <= transport std_logic_vector'("01110001"); --71
		r_addr1 <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 100 ps; -- Time=7500 ps
		PC_in <= transport std_logic_vector'("1011111110000110"); --BF86
		Din0 <= transport std_logic_vector'("10001100"); --8C
		Din1 <= transport std_logic_vector'("00001001"); --9
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01001011"); --4B
		w_addr1 <= transport std_logic_vector'("00000011"); --3
		r_addr1 <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 100 ps; -- Time=7600 ps
		PC_in <= transport std_logic_vector'("1011100001100100"); --B864
		Din0 <= transport std_logic_vector'("11101101"); --ED
		Din1 <= transport std_logic_vector'("10101001"); --A9
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("01001100"); --4C
		w_addr1 <= transport std_logic_vector'("00100000"); --20
		r_addr1 <= transport std_logic_vector'("01001100"); --4C
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7700 ps
		PC_in <= transport std_logic_vector'("1000010100011000"); --8518
		Din0 <= transport std_logic_vector'("11011001"); --D9
		Din1 <= transport std_logic_vector'("01111000"); --78
		w_addr0 <= transport std_logic_vector'("01001101"); --4D
		w_addr1 <= transport std_logic_vector'("10111000"); --B8
		r_addr1 <= transport std_logic_vector'("01001101"); --4D
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7800 ps
		PC_in <= transport std_logic_vector'("1000011001111111"); --867F
		Din0 <= transport std_logic_vector'("10000100"); --84
		Din1 <= transport std_logic_vector'("00000010"); --2
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01001110"); --4E
		w_addr1 <= transport std_logic_vector'("11111100"); --FC
		r_addr1 <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 100 ps; -- Time=7900 ps
		PC_in <= transport std_logic_vector'("0101110010110110"); --5CB6
		Din0 <= transport std_logic_vector'("01100101"); --65
		Din1 <= transport std_logic_vector'("00001110"); --E
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01001111"); --4F
		w_addr1 <= transport std_logic_vector'("01011111"); --5F
		r_addr1 <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 100 ps; -- Time=8000 ps
		PC_in <= transport std_logic_vector'("1110100100011010"); --E91A
		Din0 <= transport std_logic_vector'("00101111"); --2F
		Din1 <= transport std_logic_vector'("10100101"); --A5
		w_addr0 <= transport std_logic_vector'("01010000"); --50
		w_addr1 <= transport std_logic_vector'("10001111"); --8F
		r_addr1 <= transport std_logic_vector'("01010000"); --50
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=8100 ps
		PC_in <= transport std_logic_vector'("0100110101001000"); --4D48
		Din0 <= transport std_logic_vector'("11011001"); --D9
		Din1 <= transport std_logic_vector'("00010000"); --10
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("01010001"); --51
		w_addr1 <= transport std_logic_vector'("10000000"); --80
		r_addr1 <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 100 ps; -- Time=8200 ps
		PC_in <= transport std_logic_vector'("1110101000011101"); --EA1D
		Din0 <= transport std_logic_vector'("10010110"); --96
		Din1 <= transport std_logic_vector'("11011010"); --DA
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01010010"); --52
		w_addr1 <= transport std_logic_vector'("01100001"); --61
		r_addr1 <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 100 ps; -- Time=8300 ps
		PC_in <= transport std_logic_vector'("0101111110110110"); --5FB6
		Din0 <= transport std_logic_vector'("11011100"); --DC
		Din1 <= transport std_logic_vector'("11001001"); --C9
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01010011"); --53
		w_addr1 <= transport std_logic_vector'("10100011"); --A3
		r_addr1 <= transport std_logic_vector'("01010011"); --53
		-- --------------------
		WAIT FOR 100 ps; -- Time=8400 ps
		rst <= transport '1';
		PC_in <= transport std_logic_vector'("1000111101110000"); --8F70
		Din0 <= transport std_logic_vector'("01100000"); --60
		Din1 <= transport std_logic_vector'("11101000"); --E8
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("01010100"); --54
		w_addr1 <= transport std_logic_vector'("11111000"); --F8
		r_addr1 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ps; -- Time=8500 ps
		PC_in <= transport std_logic_vector'("1001101111101000"); --9BE8
		Din0 <= transport std_logic_vector'("00010111"); --17
		Din1 <= transport std_logic_vector'("10000000"); --80
		w_addr0 <= transport std_logic_vector'("01010101"); --55
		w_addr1 <= transport std_logic_vector'("01010001"); --51
		r_addr1 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 100 ps; -- Time=8600 ps
		PC_in <= transport std_logic_vector'("1110001011111100"); --E2FC
		Din0 <= transport std_logic_vector'("00110110"); --36
		Din1 <= transport std_logic_vector'("00011001"); --19
		w_addr0 <= transport std_logic_vector'("01010110"); --56
		w_addr1 <= transport std_logic_vector'("11011110"); --DE
		r_addr1 <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 100 ps; -- Time=8700 ps
		rst <= transport '0';
		PC_in <= transport std_logic_vector'("0000011111000111"); --7C7
		Din0 <= transport std_logic_vector'("00110001"); --31
		Din1 <= transport std_logic_vector'("01111100"); --7C
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01010111"); --57
		w_addr1 <= transport std_logic_vector'("00010001"); --11
		r_addr1 <= transport std_logic_vector'("01010111"); --57
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8800 ps
		PC_in <= transport std_logic_vector'("1110101110100111"); --EBA7
		Din0 <= transport std_logic_vector'("10111111"); --BF
		Din1 <= transport std_logic_vector'("10110011"); --B3
		w_addr0 <= transport std_logic_vector'("01011000"); --58
		w_addr1 <= transport std_logic_vector'("10011011"); --9B
		r_addr1 <= transport std_logic_vector'("01011000"); --58
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8900 ps
		PC_in <= transport std_logic_vector'("1010111000111001"); --AE39
		Din0 <= transport std_logic_vector'("11010011"); --D3
		Din1 <= transport std_logic_vector'("00000110"); --6
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01011001"); --59
		w_addr1 <= transport std_logic_vector'("01101100"); --6C
		r_addr1 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 100 ps; -- Time=9000 ps
		PC_in <= transport std_logic_vector'("1011000101011010"); --B15A
		Din0 <= transport std_logic_vector'("10100100"); --A4
		Din1 <= transport std_logic_vector'("11111111"); --FF
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01011010"); --5A
		w_addr1 <= transport std_logic_vector'("10110101"); --B5
		r_addr1 <= transport std_logic_vector'("01011010"); --5A
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=9100 ps
		PC_in <= transport std_logic_vector'("1001010100100111"); --9527
		Din0 <= transport std_logic_vector'("10100101"); --A5
		Din1 <= transport std_logic_vector'("01100110"); --66
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01011011"); --5B
		w_addr1 <= transport std_logic_vector'("11101001"); --E9
		r_addr1 <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 100 ps; -- Time=9200 ps
		PC_in <= transport std_logic_vector'("0011110011111110"); --3CFE
		Din0 <= transport std_logic_vector'("10001100"); --8C
		Din1 <= transport std_logic_vector'("01000101"); --45
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01011100"); --5C
		w_addr1 <= transport std_logic_vector'("10110110"); --B6
		r_addr1 <= transport std_logic_vector'("01011100"); --5C
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9300 ps
		PC_in <= transport std_logic_vector'("1100011001111010"); --C67A
		Din0 <= transport std_logic_vector'("01001110"); --4E
		Din1 <= transport std_logic_vector'("11100100"); --E4
		w_addr0 <= transport std_logic_vector'("01011101"); --5D
		w_addr1 <= transport std_logic_vector'("00010000"); --10
		r_addr1 <= transport std_logic_vector'("01011101"); --5D
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9400 ps
		PC_in <= transport std_logic_vector'("1001010001111001"); --9479
		Din0 <= transport std_logic_vector'("00100000"); --20
		Din1 <= transport std_logic_vector'("11001101"); --CD
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01011110"); --5E
		w_addr1 <= transport std_logic_vector'("00100110"); --26
		r_addr1 <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 100 ps; -- Time=9500 ps
		PC_in <= transport std_logic_vector'("0100100000011000"); --4818
		Din0 <= transport std_logic_vector'("01110111"); --77
		Din1 <= transport std_logic_vector'("11001000"); --C8
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("01011111"); --5F
		w_addr1 <= transport std_logic_vector'("01101001"); --69
		r_addr1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ps; -- Time=9600 ps
		PC_in <= transport std_logic_vector'("1100001010110101"); --C2B5
		Din0 <= transport std_logic_vector'("00001000"); --8
		Din1 <= transport std_logic_vector'("11011110"); --DE
		en <= transport std_logic_vector'("01"); --1
		w_addr0 <= transport std_logic_vector'("01100000"); --60
		w_addr1 <= transport std_logic_vector'("10001011"); --8B
		r_addr1 <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 100 ps; -- Time=9700 ps
		PC_in <= transport std_logic_vector'("0010001111101011"); --23EB
		Din0 <= transport std_logic_vector'("11000111"); --C7
		Din1 <= transport std_logic_vector'("01011001"); --59
		en <= transport std_logic_vector'("11"); --3
		w_addr0 <= transport std_logic_vector'("01100001"); --61
		w_addr1 <= transport std_logic_vector'("01111101"); --7D
		r_addr1 <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 100 ps; -- Time=9800 ps
		PC_in <= transport std_logic_vector'("1100110110011000"); --CD98
		Din0 <= transport std_logic_vector'("11101011"); --EB
		Din1 <= transport std_logic_vector'("11000001"); --C1
		en <= transport std_logic_vector'("00"); --0
		w_addr0 <= transport std_logic_vector'("01100010"); --62
		w_addr1 <= transport std_logic_vector'("01101111"); --6F
		r_addr1 <= transport std_logic_vector'("01100010"); --62
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9900 ps
		PC_in <= transport std_logic_vector'("0101111111011010"); --5FDA
		Din0 <= transport std_logic_vector'("11100111"); --E7
		Din1 <= transport std_logic_vector'("11100000"); --E0
		en <= transport std_logic_vector'("10"); --2
		w_addr0 <= transport std_logic_vector'("01100011"); --63
		w_addr1 <= transport std_logic_vector'("11010011"); --D3
		r_addr1 <= transport std_logic_vector'("01100011"); --63
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=10000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=10500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=10900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=11000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=11200 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=11500 ps
		rst <= transport '0';
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=12000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=12100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=12300 ps
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=12400 ps
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=12500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=13000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=13100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=13200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=13500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=14000 ps
		rst <= transport '1';
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=14200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=14300 ps
		rst <= transport '0';
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=14500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=15000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=15300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=15400 ps
		sel_as <= transport '0';
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=15500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=16000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=16400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=16500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=16800 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 200 ps; -- Time=17000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=17100 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=17500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=17600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=18000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=18500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=18600 ps
		sel_as <= transport '1';
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=18700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=19000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=19500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=19600 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=19700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=19800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=19900 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=20000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=20500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=20800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=20900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=21000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=21500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=21600 ps
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=21700 ps
		sel_mux10 <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=21900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=22000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=22400 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=22500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=22700 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=23000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=23100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=23500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=24000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=24100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=24200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=24500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=24700 ps
		sel_mux10 <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=25000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=25200 ps
		rst <= transport '1';
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=25300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=25500 ps
		rst <= transport '0';
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=26000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=26300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=26400 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=26500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=27000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=27400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=27500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=28000 ps
		rst <= transport '1';
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=28300 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=28500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=28600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=29000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=29500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=29600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=29700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=30000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=30500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=30700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=30800 ps
		rst <= transport '1';
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=31000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=31100 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=31500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=31800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=31900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=32000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=32500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=32900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=33000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=33500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=33600 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=33900 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=34000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=34100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=34500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=35000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=35100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=35200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=35500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=36000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=36200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=36300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=36400 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=36500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=36700 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=37000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=37300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=37400 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=37500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=38000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=38400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=38500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=39000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=39200 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=39500 ps
		rst <= transport '0';
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=39600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=40000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=40500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=40600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=40700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=41000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=41500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=41700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=41800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=42000 ps
		rst <= transport '1';
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=42300 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=42500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=42800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=42900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=43000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=43500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=43900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=44000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=44500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=44800 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 200 ps; -- Time=45000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=45100 ps
		rst <= transport '0';
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=45500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=46000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=46100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=46200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=46500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=47000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=47200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=47300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=47500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=47600 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=47900 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=48000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=48300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=48400 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=48500 ps
		en <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=49000 ps
		en <= transport std_logic_vector'("11"); --3
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=49400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=49500 ps
		en <= transport std_logic_vector'("11"); --3
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=50000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=50400 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=50500 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=50600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=50700 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=51000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 600 ps; -- Time=51600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=51700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=52000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 700 ps; -- Time=52700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=52800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=53000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=53200 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=53500 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=53800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=53900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=54000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 900 ps; -- Time=54900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=55000 ps
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 1000 ps; -- Time=56000 ps
		rst <= transport '1';
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=56100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=56300 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 700 ps; -- Time=57000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=57100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=57200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 800 ps; -- Time=58000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=58200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=58300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=58800 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 200 ps; -- Time=59000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=59100 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=59300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=59400 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 600 ps; -- Time=60000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=60400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=60500 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=61000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=61500 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=61600 ps
		rst <= transport '1';
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=61900 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=62000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 600 ps; -- Time=62600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=62700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=63000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 700 ps; -- Time=63700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=63800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=64000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=64400 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=64700 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=64800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=64900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=65000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 900 ps; -- Time=65900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=66000 ps
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 1000 ps; -- Time=67000 ps
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=67100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=67200 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=67500 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=68000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=68100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=68200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 800 ps; -- Time=69000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=69200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=69300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 700 ps; -- Time=70000 ps
		rst <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=70300 ps
		rst <= transport '0';
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=70400 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 600 ps; -- Time=71000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=71400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=71500 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=72000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=72500 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=72600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=72800 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 200 ps; -- Time=73000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=73100 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=73600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=73700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=74000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 700 ps; -- Time=74700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=74800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=75000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 600 ps; -- Time=75600 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 200 ps; -- Time=75800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=75900 ps
		rst <= transport '0';
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=76000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 900 ps; -- Time=76900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=77000 ps
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 1000 ps; -- Time=78000 ps
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=78100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=78400 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=78700 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=79000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=79100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=79200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 800 ps; -- Time=80000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=80200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=80300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 700 ps; -- Time=81000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=81200 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=81300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=81400 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=81500 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=82000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=82400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=82500 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=83000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=83500 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=83600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=84000 ps
		rst <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=84300 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=84600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=84700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=85000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 700 ps; -- Time=85700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=85800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=86000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 800 ps; -- Time=86800 ps
		rst <= transport '1';
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=86900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=87000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=87100 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 800 ps; -- Time=87900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=88000 ps
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 1000 ps; -- Time=89000 ps
		sel_as <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=89100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=89600 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=89900 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=90000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=90100 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=90200 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 800 ps; -- Time=91000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=91200 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=91300 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 700 ps; -- Time=92000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=92300 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=92400 ps
		rst <= transport '1';
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=92700 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=93000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 400 ps; -- Time=93400 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=93500 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=94000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 500 ps; -- Time=94500 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=94600 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 400 ps; -- Time=95000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 200 ps; -- Time=95200 ps
		rst <= transport '1';
		-- --------------------
		WAIT FOR 300 ps; -- Time=95500 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=95600 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=95700 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 300 ps; -- Time=96000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 700 ps; -- Time=96700 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=96800 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 200 ps; -- Time=97000 ps
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 800 ps; -- Time=97800 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=97900 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=98000 ps
		rst <= transport '1';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 300 ps; -- Time=98300 ps
		rst <= transport '0';
		-- --------------------
		WAIT FOR 600 ps; -- Time=98900 ps
		sel_as <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=99000 ps
		sel_as <= transport '0';
		sel_mux11 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 1000 ps; -- Time=100000 ps
		sel_as <= transport '1';
		sel_mux12 <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=100100 ps
		sel_as <= transport '0';
		-- --------------------
		WAIT FOR 500 ps; -- Time=100600 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION mem_unit_cfg OF mem_unit_tw IS
	FOR testbench_arch
	END FOR;
END mem_unit_cfg;
