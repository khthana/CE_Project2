library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity xor_test is
    Port ( in1 : in std_logic_vector(7 downto 0);
           out1 : out std_logic);
end xor_test;

architecture Behavioral of xor_test is

begin
	process(in1)
	begin
		  out1 <= in1(7) xor in1(6) xor in1(5) xor in1(4) xor in1(3) xor in1(2) xor in1(1) xor in1(0);
	end process;
	
end Behavioral;
