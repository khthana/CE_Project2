library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;


entity temp1 is
	port(	data_in	:in		std_logic_vector(15 downto 0);
			data_out	:out   		std_logic_vector(15 downto 0);
			load_in	:in		std_logic);
			
end temp1;


architecture rtl of temp1 is
--signal temp : std_logic_vector(15 downto 0):= "0000000000000000";
begin
	process (data_in, load_in)
	begin
		if (load_in = '1' ) then
			data_out <= data_in;
		end if;
	end process;
end rtl;
