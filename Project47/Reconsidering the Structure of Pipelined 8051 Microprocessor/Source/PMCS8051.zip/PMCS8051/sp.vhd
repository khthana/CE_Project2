library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sp is
    Port ( 
	 			rst : in std_logic;
				load_in : in std_logic;
	 			in1 : in std_logic_vector(7 downto 0);
           	out1 : out std_logic_vector(7 downto 0));
end sp;

architecture rtl of sp is

begin
	process (in1, rst, load_in)
	begin
		if (rst = '1') then
			out1 <= "00000111";
		elsif ( load_in = '1' ) then
			out1 <= in1;
		end if;
	end process;
end rtl;
