library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity jcall_address_gen is
    Port ( in1 : in std_logic_vector(2 downto 0); --byte 1
           in2 : in std_logic_vector(7 downto 0);	--byte 2
           in3 : in std_logic_vector(7 downto 0);	--byte 3
           in4 : in std_logic_vector(15 downto 0); --temp
           out1 : out std_logic_vector(15 downto 0);
		 sel : in std_logic_vector(1 downto 0));
end jcall_address_gen;

architecture rtl of jcall_address_gen is

begin
	process(in1,in2,in3,in4,sel)
	begin
		case  sel is
		when "00" => out1(15 downto 0) <= in4(15 downto 11) & in1(2 downto 0) & in2(7 downto 0);
		when "11" => out1(15 downto 0) <= in2(7 downto 0) & in3(7 downto 0);
		when others => out1 <= in4;
		end case;
	end process;

end rtl;
