-- E:\USERS\POLARBEAR\PROJECT\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Feb 14 10:01:44 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY mux5_tb IS
END mux5_tb;

ARCHITECTURE testbench_arch OF mux5_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT mux5
		PORT (
			in1 : In  std_logic_vector (15 DOWNTO 0);
			in2 : In  std_logic_vector (15 DOWNTO 0);
			in3 : In  std_logic_vector (15 DOWNTO 0);
			sel : In  std_logic_vector (1 DOWNTO 0);
			out1 : Out  std_logic_vector (15 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (15 DOWNTO 0);
	SIGNAL in2 : std_logic_vector (15 DOWNTO 0);
	SIGNAL in3 : std_logic_vector (15 DOWNTO 0);
	SIGNAL sel : std_logic_vector (1 DOWNTO 0);
	SIGNAL out1 : std_logic_vector (15 DOWNTO 0);

BEGIN
	UUT : mux5
	PORT MAP (
		in1 => in1,
		in2 => in2,
		in3 => in3,
		sel => sel,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("1001000001111101"); --907D
		in2 <= transport std_logic_vector'("0101100001111100"); --587C
		in3 <= transport std_logic_vector'("0010000001111100"); --207C
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("0101111000101011"); --5E2B
		in2 <= transport std_logic_vector'("1000010100010000"); --8510
		in3 <= transport std_logic_vector'("1010110011110100"); --ACF4
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("1110001000001100"); --E20C
		in2 <= transport std_logic_vector'("0010010011100000"); --24E0
		in3 <= transport std_logic_vector'("0110011010110011"); --66B3
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("1011101000111101"); --BA3D
		in2 <= transport std_logic_vector'("1011100001011101"); --B85D
		in3 <= transport std_logic_vector'("1011011101111101"); --B77D
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("1100100100011011"); --C91B
		in2 <= transport std_logic_vector'("0000100000111001"); --839
		in3 <= transport std_logic_vector'("0100011101010111"); --4757
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("0010111101000011"); --2F43
		in2 <= transport std_logic_vector'("0001100001100101"); --1865
		in3 <= transport std_logic_vector'("0000000110000111"); --187
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("0100110110010010"); --4D92
		in2 <= transport std_logic_vector'("0010110100010001"); --2D11
		in3 <= transport std_logic_vector'("0000110010010000"); --C90
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("1100010100100101"); --C525
		in2 <= transport std_logic_vector'("1100110010101111"); --CCAF
		in3 <= transport std_logic_vector'("1101001100111001"); --D339
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("0111011101011001"); --7759
		in2 <= transport std_logic_vector'("1011101011101111"); --BAEF
		in3 <= transport std_logic_vector'("1111111010000101"); --FE85
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("1000010011001011"); --84CB
		in2 <= transport std_logic_vector'("1111110111000011"); --FDC3
		in3 <= transport std_logic_vector'("0111010110111011"); --75BB
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("0100111001011001"); --4E59
		in2 <= transport std_logic_vector'("1101100001011100"); --D85C
		in3 <= transport std_logic_vector'("0110001001011111"); --625F
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("0111010100011110"); --751E
		in2 <= transport std_logic_vector'("1101001000101010"); --D22A
		in3 <= transport std_logic_vector'("0010111100110110"); --2F36
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("1101101001111000"); --DA78
		in2 <= transport std_logic_vector'("1010111111011111"); --AFDF
		in3 <= transport std_logic_vector'("1000001101000101"); --8345
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("1001111100000100"); --9F04
		in2 <= transport std_logic_vector'("0111010001101011"); --746B
		in3 <= transport std_logic_vector'("0100100111010010"); --49D2
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("0010010010011111"); --249F
		in2 <= transport std_logic_vector'("0110011000000000"); --6600
		in3 <= transport std_logic_vector'("1010100001100000"); --A860
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("0000101101100110"); --B66
		in2 <= transport std_logic_vector'("0000101000001110"); --A0E
		in3 <= transport std_logic_vector'("0000101010110110"); --AB6
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("0011001110110111"); --33B7
		in2 <= transport std_logic_vector'("0010011001000111"); --2647
		in3 <= transport std_logic_vector'("0001100011011000"); --18D8
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("1011111100101101"); --BF2D
		in2 <= transport std_logic_vector'("1011110110011100"); --BD9C
		in3 <= transport std_logic_vector'("1011101100001011"); --BB0B
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("0001000010100110"); --10A6
		in2 <= transport std_logic_vector'("0001011000111101"); --163D
		in3 <= transport std_logic_vector'("0001110011010100"); --1CD4
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("1100010100111111"); --C53F
		in2 <= transport std_logic_vector'("1011010110011100"); --B59C
		in3 <= transport std_logic_vector'("1010010011111000"); --A4F8
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("1100000101010110"); --C156
		in2 <= transport std_logic_vector'("0101111101101001"); --5F69
		in3 <= transport std_logic_vector'("1111110001111100"); --FC7C
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("0010010110000110"); --2586
		in2 <= transport std_logic_vector'("0001100110010110"); --1996
		in3 <= transport std_logic_vector'("0000110110100110"); --DA6
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("0101000010101101"); --50AD
		in2 <= transport std_logic_vector'("0010100001010011"); --2853
		in3 <= transport std_logic_vector'("0000000011111001"); --F9
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("1110010111101001"); --E5E9
		in2 <= transport std_logic_vector'("0001000100010010"); --1112
		in3 <= transport std_logic_vector'("0011111000111100"); --3E3C
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("1100010010010101"); --C495
		in2 <= transport std_logic_vector'("1001101010000100"); --9A84
		in3 <= transport std_logic_vector'("0111000001110011"); --7073
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("0000111101001111"); --F4F
		in2 <= transport std_logic_vector'("1100011110011001"); --C799
		in3 <= transport std_logic_vector'("0111111011100011"); --7EE3
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("0010011011110101"); --26F5
		in2 <= transport std_logic_vector'("1101110110000011"); --DD83
		in3 <= transport std_logic_vector'("1001001100010001"); --9311
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("1010101010100010"); --AAA2
		in2 <= transport std_logic_vector'("0110000010110010"); --60B2
		in3 <= transport std_logic_vector'("0001011111000011"); --17C3
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("0111110110110100"); --7DB4
		in2 <= transport std_logic_vector'("0001100011011000"); --18D8
		in3 <= transport std_logic_vector'("1011001011111100"); --B2FC
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("1011111111001001"); --BFC9
		in2 <= transport std_logic_vector'("0000011111100110"); --7E6
		in3 <= transport std_logic_vector'("0100111100000011"); --4F03
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("1101000110111100"); --D1BC
		in2 <= transport std_logic_vector'("0111001100001100"); --730C
		in3 <= transport std_logic_vector'("0001010101011100"); --155C
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("0101010110101100"); --55AC
		in2 <= transport std_logic_vector'("1110001010111100"); --E2BC
		in3 <= transport std_logic_vector'("0110111111001100"); --6FCC
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("0010101111110100"); --2BF4
		in2 <= transport std_logic_vector'("0001011110100110"); --17A6
		in3 <= transport std_logic_vector'("0000010001011000"); --458
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("0111010000110011"); --7433
		in2 <= transport std_logic_vector'("0001100110111100"); --19BC
		in3 <= transport std_logic_vector'("1011111001000101"); --BE45
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("1001001001000100"); --9244
		in2 <= transport std_logic_vector'("0010110000101110"); --2C2E
		in3 <= transport std_logic_vector'("1100011100011000"); --C718
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("0010010001000110"); --2446
		in2 <= transport std_logic_vector'("1101010101101110"); --D56E
		in3 <= transport std_logic_vector'("1000011010010111"); --8697
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("0000111010010100"); --E94
		in2 <= transport std_logic_vector'("1101100100101101"); --D92D
		in3 <= transport std_logic_vector'("1010010111000101"); --A5C5
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("0110111011001101"); --6ECD
		in2 <= transport std_logic_vector'("0011111001011011"); --3E5B
		in3 <= transport std_logic_vector'("0000110111101001"); --DE9
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("1010011111001100"); --A7CC
		in2 <= transport std_logic_vector'("0100011100101010"); --472A
		in3 <= transport std_logic_vector'("1110100010000111"); --E887
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("0101100110110000"); --59B0
		in2 <= transport std_logic_vector'("0111101100001010"); --7B0A
		in3 <= transport std_logic_vector'("1001110101100100"); --9D64
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("0110011011010101"); --66D5
		in2 <= transport std_logic_vector'("1001111010101101"); --9EAD
		in3 <= transport std_logic_vector'("1101011010000101"); --D685
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("1110111011010111"); --EED7
		in2 <= transport std_logic_vector'("1011010100000011"); --B503
		in3 <= transport std_logic_vector'("0111110000101111"); --7C2F
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("0101001010010101"); --5295
		in2 <= transport std_logic_vector'("0000010100111110"); --53E
		in3 <= transport std_logic_vector'("1011100011101000"); --B8E8
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("0011010000101010"); --342A
		in2 <= transport std_logic_vector'("0001001111001111"); --13CF
		in3 <= transport std_logic_vector'("1111001001110100"); --F274
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("0111001111110101"); --73F5
		in2 <= transport std_logic_vector'("1010010001100110"); --A466
		in3 <= transport std_logic_vector'("1101010111010111"); --D5D7
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("0011001110010010"); --3392
		in2 <= transport std_logic_vector'("1011111011110101"); --BEF5
		in3 <= transport std_logic_vector'("0100100101011000"); --4958
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		in1 <= transport std_logic_vector'("1101001011011101"); --D2DD
		in2 <= transport std_logic_vector'("1010010010101100"); --A4AC
		in3 <= transport std_logic_vector'("0111011101111011"); --777B
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		in1 <= transport std_logic_vector'("1111001111110101"); --F3F5
		in2 <= transport std_logic_vector'("1101110111111101"); --DDFD
		in3 <= transport std_logic_vector'("1100011100000101"); --C705
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		in1 <= transport std_logic_vector'("0111011000110110"); --7636
		in2 <= transport std_logic_vector'("0010110110011001"); --2D99
		in3 <= transport std_logic_vector'("1110010011111100"); --E4FC
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		in1 <= transport std_logic_vector'("0111110100111101"); --7D3D
		in2 <= transport std_logic_vector'("1001100101110000"); --9970
		in3 <= transport std_logic_vector'("1011011010100011"); --B6A3
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("0110100011100110"); --68E6
		in2 <= transport std_logic_vector'("0110011010110100"); --66B4
		in3 <= transport std_logic_vector'("0110010110000001"); --6581
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		in1 <= transport std_logic_vector'("1101100001010000"); --D850
		in2 <= transport std_logic_vector'("0001101011010101"); --1AD5
		in3 <= transport std_logic_vector'("0101110001011001"); --5C59
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		in1 <= transport std_logic_vector'("1010111011010111"); --AED7
		in2 <= transport std_logic_vector'("0111100010000101"); --7885
		in3 <= transport std_logic_vector'("0100001000110010"); --4232
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		in1 <= transport std_logic_vector'("0000110000011000"); --C18
		in2 <= transport std_logic_vector'("1000011110110100"); --87B4
		in3 <= transport std_logic_vector'("0000001001010000"); --250
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		in1 <= transport std_logic_vector'("0101001011101111"); --52EF
		in2 <= transport std_logic_vector'("1000101110010100"); --8B94
		in3 <= transport std_logic_vector'("1100001100111000"); --C338
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		in1 <= transport std_logic_vector'("0010001001111011"); --227B
		in2 <= transport std_logic_vector'("0000100010010110"); --896
		in3 <= transport std_logic_vector'("1110111110110000"); --EFB0
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		in1 <= transport std_logic_vector'("0101101100011000"); --5B18
		in2 <= transport std_logic_vector'("1100010101101010"); --C56A
		in3 <= transport std_logic_vector'("0011000010111011"); --30BB
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		in1 <= transport std_logic_vector'("0010000101100011"); --2163
		in2 <= transport std_logic_vector'("1100011100000001"); --C701
		in3 <= transport std_logic_vector'("0110110110100000"); --6DA0
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		in1 <= transport std_logic_vector'("1101001000111001"); --D239
		in2 <= transport std_logic_vector'("0101000110001110"); --518E
		in3 <= transport std_logic_vector'("1101000011100010"); --D0E2
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		in1 <= transport std_logic_vector'("0001000110110111"); --11B7
		in2 <= transport std_logic_vector'("1110100110000000"); --E980
		in3 <= transport std_logic_vector'("1100001001001000"); --C248
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("1011111000111010"); --BE3A
		in2 <= transport std_logic_vector'("0101010110001000"); --5588
		in3 <= transport std_logic_vector'("1110110011010110"); --ECD6
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		in1 <= transport std_logic_vector'("1111101001011111"); --FA5F
		in2 <= transport std_logic_vector'("1001100110011000"); --9998
		in3 <= transport std_logic_vector'("0011011111010001"); --37D1
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		in1 <= transport std_logic_vector'("0010011100000010"); --2702
		in2 <= transport std_logic_vector'("1111101011100001"); --FAE1
		in3 <= transport std_logic_vector'("1100110010111111"); --CCBF
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		in1 <= transport std_logic_vector'("1110010101000010"); --E542
		in2 <= transport std_logic_vector'("1111110111010011"); --FDD3
		in3 <= transport std_logic_vector'("0001010001100011"); --1463
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		in1 <= transport std_logic_vector'("0001011001111011"); --167B
		in2 <= transport std_logic_vector'("0110011100100000"); --6720
		in3 <= transport std_logic_vector'("1011100011000100"); --B8C4
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		in1 <= transport std_logic_vector'("1101100101001010"); --D94A
		in2 <= transport std_logic_vector'("0011110110111000"); --3DB8
		in3 <= transport std_logic_vector'("1010000100100101"); --A125
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		in1 <= transport std_logic_vector'("1001000110001100"); --918C
		in2 <= transport std_logic_vector'("1100010111001101"); --C5CD
		in3 <= transport std_logic_vector'("1111100000001101"); --F80D
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		in1 <= transport std_logic_vector'("1101111101011110"); --DF5E
		in2 <= transport std_logic_vector'("1000001011001111"); --82CF
		in3 <= transport std_logic_vector'("0010011001000000"); --2640
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		in1 <= transport std_logic_vector'("1010001100011101"); --A31D
		in2 <= transport std_logic_vector'("0011101101110000"); --3B70
		in3 <= transport std_logic_vector'("1101001111000011"); --D3C3
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		in1 <= transport std_logic_vector'("1111111001100110"); --FE66
		in2 <= transport std_logic_vector'("1111010010100001"); --F4A1
		in3 <= transport std_logic_vector'("1110101011011100"); --EADC
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("0101000100010111"); --5117
		in2 <= transport std_logic_vector'("1111001010010010"); --F292
		in3 <= transport std_logic_vector'("1001001100001110"); --930E
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		in1 <= transport std_logic_vector'("0011111001001011"); --3E4B
		in2 <= transport std_logic_vector'("1011101010110101"); --BAB5
		in3 <= transport std_logic_vector'("0011011000011111"); --361F
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		in1 <= transport std_logic_vector'("1010010101100000"); --A560
		in2 <= transport std_logic_vector'("0001000110111010"); --11BA
		in3 <= transport std_logic_vector'("0111111000010101"); --7E15
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		in1 <= transport std_logic_vector'("1010011111110011"); --A7F3
		in2 <= transport std_logic_vector'("1111110110010011"); --FD93
		in3 <= transport std_logic_vector'("0101001000110100"); --5234
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		in1 <= transport std_logic_vector'("1010011011100001"); --A6E1
		in2 <= transport std_logic_vector'("1100000101110001"); --C171
		in3 <= transport std_logic_vector'("1101110100000001"); --DD01
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		in1 <= transport std_logic_vector'("0100001001000111"); --4247
		in2 <= transport std_logic_vector'("1110010011000100"); --E4C4
		in3 <= transport std_logic_vector'("1000011001000001"); --8641
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		in1 <= transport std_logic_vector'("0101110010000010"); --5C82
		in2 <= transport std_logic_vector'("0010101000111110"); --2A3E
		in3 <= transport std_logic_vector'("1111011111111001"); --F7F9
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		in1 <= transport std_logic_vector'("0001011000101111"); --162F
		in2 <= transport std_logic_vector'("1001100011001111"); --98CF
		in3 <= transport std_logic_vector'("0001101001101111"); --1A6F
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		in1 <= transport std_logic_vector'("1101000000101100"); --D02C
		in2 <= transport std_logic_vector'("0111001110101001"); --73A9
		in3 <= transport std_logic_vector'("0001011000100110"); --1626
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		in1 <= transport std_logic_vector'("0010101110010100"); --2B94
		in2 <= transport std_logic_vector'("0100000000111100"); --403C
		in3 <= transport std_logic_vector'("0101010111100101"); --55E5
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("0000100111000101"); --9C5
		in2 <= transport std_logic_vector'("1100010100111010"); --C53A
		in3 <= transport std_logic_vector'("1000000010110000"); --80B0
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		in1 <= transport std_logic_vector'("1000101001011100"); --8A5C
		in2 <= transport std_logic_vector'("0000010110010100"); --594
		in3 <= transport std_logic_vector'("1000000011001100"); --80CC
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		in1 <= transport std_logic_vector'("0000111100110110"); --F36
		in2 <= transport std_logic_vector'("0100011101111010"); --477A
		in3 <= transport std_logic_vector'("0111111010111110"); --7EBE
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		in1 <= transport std_logic_vector'("0011101001110001"); --3A71
		in2 <= transport std_logic_vector'("0000111101011110"); --F5E
		in3 <= transport std_logic_vector'("1110001101001011"); --E34B
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		in1 <= transport std_logic_vector'("1110101101101000"); --EB68
		in2 <= transport std_logic_vector'("0010001011110000"); --22F0
		in3 <= transport std_logic_vector'("0101100001111000"); --5878
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		in1 <= transport std_logic_vector'("0100001110111001"); --43B9
		in2 <= transport std_logic_vector'("1000010100100010"); --8522
		in3 <= transport std_logic_vector'("1100011010001011"); --C68B
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		in1 <= transport std_logic_vector'("1010010001000010"); --A442
		in2 <= transport std_logic_vector'("0111110100100101"); --7D25
		in3 <= transport std_logic_vector'("0101011000000111"); --5607
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		in1 <= transport std_logic_vector'("1010111000011110"); --AE1E
		in2 <= transport std_logic_vector'("1000111101101001"); --8F69
		in3 <= transport std_logic_vector'("0111000110110011"); --71B3
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		in1 <= transport std_logic_vector'("0100001010101011"); --42AB
		in2 <= transport std_logic_vector'("1000000110011111"); --819F
		in3 <= transport std_logic_vector'("1100000010010011"); --C093
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		in1 <= transport std_logic_vector'("1000001010000111"); --8287
		in2 <= transport std_logic_vector'("0101011110111001"); --57B9
		in3 <= transport std_logic_vector'("0010101111101100"); --2BEC
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("1100111010001101"); --CE8D
		in2 <= transport std_logic_vector'("0101010111101000"); --55E8
		in3 <= transport std_logic_vector'("1101110101000011"); --DD43
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		in1 <= transport std_logic_vector'("1100011111011011"); --C7DB
		in2 <= transport std_logic_vector'("0000001010011101"); --29D
		in3 <= transport std_logic_vector'("0011111001011110"); --3E5E
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		in1 <= transport std_logic_vector'("0100111111001111"); --4FCF
		in2 <= transport std_logic_vector'("0010001110001000"); --2388
		in3 <= transport std_logic_vector'("1111011001000000"); --F640
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		in1 <= transport std_logic_vector'("1000011000000100"); --8604
		in2 <= transport std_logic_vector'("1011101110011010"); --BB9A
		in3 <= transport std_logic_vector'("1111000000110000"); --F030
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		in1 <= transport std_logic_vector'("1100110101011001"); --CD59
		in2 <= transport std_logic_vector'("0001000000000101"); --1005
		in3 <= transport std_logic_vector'("0101001110110010"); --53B2
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		in1 <= transport std_logic_vector'("1100011011101001"); --C6E9
		in2 <= transport std_logic_vector'("1010100000111010"); --A83A
		in3 <= transport std_logic_vector'("1000101010001011"); --8A8B
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		in1 <= transport std_logic_vector'("0101000100010011"); --5113
		in2 <= transport std_logic_vector'("0100011011101001"); --46E9
		in3 <= transport std_logic_vector'("0011110011000000"); --3CC0
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		in1 <= transport std_logic_vector'("1000111101110010"); --8F72
		in2 <= transport std_logic_vector'("1111000100000100"); --F104
		in3 <= transport std_logic_vector'("0101001110010110"); --5396
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		in1 <= transport std_logic_vector'("1110000111100101"); --E1E5
		in2 <= transport std_logic_vector'("1110110110111011"); --EDBB
		in3 <= transport std_logic_vector'("1111100110010010"); --F992
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		in1 <= transport std_logic_vector'("1110100110000111"); --E987
		in2 <= transport std_logic_vector'("1011111110000000"); --BF80
		in3 <= transport std_logic_vector'("1001010101111010"); --957A
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 15 ns; -- Time=1005 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION mux5_cfg OF mux5_tb IS
	FOR testbench_arch
	END FOR;
END mux5_cfg;
