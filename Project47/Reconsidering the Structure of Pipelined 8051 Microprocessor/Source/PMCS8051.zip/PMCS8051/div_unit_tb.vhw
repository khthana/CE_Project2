-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Fri Mar 18 18:18:31 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY div_unit_tb IS
END div_unit_tb;

ARCHITECTURE testbench_arch OF div_unit_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT non_res_div_unit
		PORT (
			CLK : In  std_logic;
			DIVIDEND : In  std_logic_vector (7 DOWNTO 0);
			DIVISOR : In  std_logic_vector (7 DOWNTO 0);
			DIV_RESULT : Out  std_logic_vector (16 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL CLK : std_logic;
	SIGNAL DIVIDEND : std_logic_vector (7 DOWNTO 0);
	SIGNAL DIVISOR : std_logic_vector (7 DOWNTO 0);
	SIGNAL DIV_RESULT : std_logic_vector (16 DOWNTO 0);

BEGIN
	UUT : non_res_div_unit
	PORT MAP (
		CLK => CLK,
		DIVIDEND => DIVIDEND,
		DIVISOR => DIVISOR,
		DIV_RESULT => DIV_RESULT
	);

	PROCESS -- clock process for CLK,
	BEGIN
		CLOCK_LOOP : LOOP
		CLK <= transport '0';
		WAIT FOR 10 ns;
		CLK <= transport '1';
		WAIT FOR 10 ns;
		WAIT FOR 40 ns;
		CLK <= transport '0';
		WAIT FOR 40 ns;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for CLK
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_DIV_RESULT(
			next_DIV_RESULT : std_logic_vector (16 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (DIV_RESULT /= next_DIV_RESULT) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns DIV_RESULT="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, DIV_RESULT);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_DIV_RESULT);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		DIVIDEND <= transport std_logic_vector'("01110000"); --70
		DIVISOR <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 100 ns; -- Time=100 ns
		DIVIDEND <= transport std_logic_vector'("00100100"); --24
		DIVISOR <= transport std_logic_vector'("10001010"); --8A
		-- --------------------
		WAIT FOR 100 ns; -- Time=200 ns
		DIVIDEND <= transport std_logic_vector'("11000000"); --C0
		DIVISOR <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ns; -- Time=300 ns
		DIVIDEND <= transport std_logic_vector'("10011110"); --9E
		DIVISOR <= transport std_logic_vector'("01111111"); --7F
		-- --------------------
		WAIT FOR 100 ns; -- Time=400 ns
		DIVIDEND <= transport std_logic_vector'("01010111"); --57
		DIVISOR <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 100 ns; -- Time=500 ns
		DIVIDEND <= transport std_logic_vector'("11000100"); --C4
		DIVISOR <= transport std_logic_vector'("10111110"); --BE
		-- --------------------
		WAIT FOR 100 ns; -- Time=600 ns
		DIVIDEND <= transport std_logic_vector'("11111101"); --FD
		DIVISOR <= transport std_logic_vector'("01101100"); --6C
		-- --------------------
		WAIT FOR 100 ns; -- Time=700 ns
		DIVIDEND <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 160 ns; -- Time=860 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION non_res_div_unit_cfg OF div_unit_tb IS
	FOR testbench_arch
	END FOR;
END non_res_div_unit_cfg;
