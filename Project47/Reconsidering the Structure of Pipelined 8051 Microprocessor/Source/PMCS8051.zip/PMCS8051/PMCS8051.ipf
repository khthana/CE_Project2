JedecChain;
FileRevision(JESDxxA);
/* NoviceMode */
/* Active Mode BS */
/* Mode BS */
/* Cable ParallelIII lpt1 200000 */
 P ActionCode(Cfg)
  Device
   PartName(xcf01s)
   File("BYPASS")
  ;
 P ActionCode(Cfg)
  Device
   PartName(xc3s200)
   File("E:\Users\Polarbear\Project\PMCS8051\datapath.bit")
  ;
/* Mode SS */
/* Mode SM */
/* Mode BSFILE */
/* Mode HW140 */
ChainEnd;
