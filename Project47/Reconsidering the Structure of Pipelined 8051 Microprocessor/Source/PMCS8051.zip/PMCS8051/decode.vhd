library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;

entity decode is
   port (--clock		: in	std_logic;
			reset		: in	std_logic; 
			inst_b1	: in	std_logic_vector (7 downto 0);
   		inst_b2	: in	std_logic_vector (7 downto 0);
			inst_b3	: in	std_logic_vector (7 downto 0);
			s1			: out	std_logic_vector (7 downto 0);
			s2			: out	std_logic_vector (7 downto 0);
			d1			: out	std_logic_vector (7 downto 0);
			d2			: out	std_logic_vector (7 downto 0);
			alu_oprt	: out	std_logic_vector (4 downto 0);
			reg_aa	: out	std_logic_vector (7 downto 0);
			reg_bb	: out	std_logic_vector (7 downto 0);
			from_acc : in	std_logic_vector (7 downto 0);
			from_b	: in	std_logic_vector (7 downto 0);
			from_mem0: in	std_logic_vector (7 downto 0);
			from_psw : in	std_logic_vector (7 downto 0);
			from_p0	: in	std_logic_vector (7 downto 0);
			from_p1	: in	std_logic_vector (7 downto 0);
			from_p2	: in	std_logic_vector (7 downto 0);
			from_p3	: in	std_logic_vector (7 downto 0);
			from_sp	: in	std_logic_vector (7 downto 0);
			from_DPH	: in	std_logic_vector (7 downto 0);
			from_DPL	: in	std_logic_vector (7 downto 0);
--			from_mem1: in	std_logic_vector (7 downto 0);
--			from_mem : in	std_logic_vector (7 downto 0);
--			from_sfr : in	std_logic_vector (7 downto 0);
			sel_mux6 : in	std_logic_vector (1 downto 0);
--			sel_mux7	: in 	std_logic_vector (2 downto 0);
			sel_mux8	: in 	std_logic_vector (1 downto 0);
			sel_mux9	: in	std_logic_vector (2 downto 0);
			bank		: in	std_logic_vector (1 downto 0);
			r_addr0	: out	std_logic_vector (7 downto 0);
			sel_forward : out	std_logic_vector (1 downto 0);
			in_r0		: in 	std_logic_vector (7 downto 0);
			in_r1		: in 	std_logic_vector (7 downto 0)
			);
end decode;

architecture structural of decode is
   signal direct_addr_dec_to_mux6	: std_logic_vector(7 downto 0);
   signal bit_addr_dec_to_mux6		: std_logic_vector(7 downto 0);
   signal rn_addr_dec_to_mux6			: std_logic_vector(7 downto 0);
	signal reg_indirect_to_mux6		: std_logic_vector(7 downto 0);

   signal mux7_to_mux8_mux9			: std_logic_vector(7 downto 0);
   signal bit_number_dec_to_mux9		: std_logic_vector(7 downto 0);
	signal aa_from_mux8					: std_logic_vector(7 downto 0);
	signal bb_from_mux9					: std_logic_vector(7 downto 0);
   component bit_addr_dec
      port ( in1			: in	std_logic_vector (7 downto 0);
				out1			: out	std_logic_vector (7 downto 0));
   end component;
   component direct_addr_dec
      port ( in1			: in	std_logic_vector (7 downto 0); 
            out1 			: out	std_logic_vector (7 downto 0));
   end component;
   component instruction_decoder
      port (--clock			: in	std_logic;
				reset			: in	std_logic;
				inst_byte1	: in	std_logic_vector (7 downto 0);
				inst_byte2	: in	std_logic_vector (7 downto 0);
				inst_byte3	: in	std_logic_vector (7 downto 0);
            s1				: out std_logic_vector (7 downto 0); 
            s2				: out std_logic_vector (7 downto 0); 
            d1				: out std_logic_vector (7 downto 0); 
            d2				: out std_logic_vector (7 downto 0); 
            alu_oprt		: out std_logic_vector (4 downto 0);
				sel_forward : out	std_logic_vector (1 downto 0);
--				in_aa			: in	std_logic_vector (7 downto 0);
--				in_bb			: in	std_logic_vector (7 downto 0);
				in_Ri_dec	: in	std_logic_vector (7 downto 0);
				in_Rn_dec	: in	std_logic_vector (7 downto 0);
				in_bit_dec	: in	std_logic_vector (7 downto 0)
				);
   end component;
   component mux6
      port ( in1  		: in	std_logic_vector (7 downto 0); 
             in2  		: in	std_logic_vector (7 downto 0); 
             in3  		: in	std_logic_vector (7 downto 0); 
             in4  		: in	std_logic_vector (7 downto 0); 
             sel  		: in	std_logic_vector (1 downto 0); 
             out1 		: out	std_logic_vector (7 downto 0));
--				 out2 		: out	std_logic_vector (7 downto 0));
   end component;
   component mux7
	port (  in1		: in std_logic_vector(7 downto 0);		-- from	Acc.
           in2		: in std_logic_vector(7 downto 0);		-- from	Int. Mem.
           in3		: in std_logic_vector(7 downto 0);		-- from	psw
           in4		: in std_logic_vector(7 downto 0); 		-- from	B
           in5		: in std_logic_vector(7 downto 0); 		-- from	p0
           in6		: in std_logic_vector(7 downto 0); 		-- from	p1
           in7		: in std_logic_vector(7 downto 0); 		-- from	p2
           in8		: in std_logic_vector(7 downto 0); 		-- from	p3
           in9		: in std_logic_vector(7 downto 0); 		-- from	sp
           in10	: in std_logic_vector(7 downto 0); 		-- from	DPH
           in11	: in std_logic_vector(7 downto 0); 		-- from	DPL
           sel		: in std_logic_vector(7 downto 0);		-- from	Inst. Byte 2
           out1 	: out std_logic_vector(7 downto 0));	-- to		MUX9
   end component;
   component mux8
      port ( in1  		: in	std_logic_vector (7 downto 0); 
             in2  		: in	std_logic_vector (7 downto 0); 
             in3  		: in	std_logic_vector (7 downto 0); 
             sel  		: in	std_logic_vector (1 downto 0); 
             out1 		: out	std_logic_vector (7 downto 0));
   end component;
   component mux9
      port ( in1  		: in	std_logic_vector (7 downto 0); 
             in2  		: in	std_logic_vector (7 downto 0); 
             in3  		: in	std_logic_vector (7 downto 0); 
             in4  		: in	std_logic_vector (7 downto 0); 
             in5  		: in	std_logic_vector (7 downto 0); 
             in6  		: in	std_logic_vector (7 downto 0); 
             sel  		: in	std_logic_vector (2 downto 0); 
             out1 		: out	std_logic_vector (7 downto 0));
   end component;
   component reg_indirect_dec
      port ( inst_byte1	: in	std_logic;
				 in1			: in	std_logic_vector (7 downto 0);
				 in2			: in	std_logic_vector (7 downto 0);
				 out1 		: out	std_logic_vector (7 downto 0));
   end component;
   component rn_addr_dec
      port ( inst_byte1	: in	std_logic_vector (2 downto 0);
				 bank			: in	std_logic_vector (1 downto 0);
				 out1 		: out std_logic_vector (7 downto 0));
   end component;
   component bit_number_dec
      port ( in1			: in	std_logic_vector (7 downto 0); 
             out1 		: out	std_logic_vector (7 downto 0));
   end component;

begin
   d_bit_addr_dec : bit_addr_dec
      port map (in1(7 downto 0)			=>	inst_b2(7 downto 0),      
                out1(7 downto 0)			=>	bit_addr_dec_to_mux6(7 downto 0));
   d_direct_addr_dec : direct_addr_dec
      port map (in1(7 downto 0)			=>	inst_b2(7 downto 0),      
                out1(7 downto 0)			=>	direct_addr_dec_to_mux6(7 downto 0));
   d_instruction_decoder : instruction_decoder
      port map (--clock						=> clock,
					reset							=> reset,
					inst_byte1(7 downto 0)	=>	inst_b1(7 downto 0),
					inst_byte2(7 downto 0)	=> inst_b2(7 downto 0),
					inst_byte3(7 downto 0)	=> inst_b3(7 downto 0),      
               alu_oprt(4 downto 0)		=>	alu_oprt(4 downto 0),      
               d1(7 downto 0)				=>	d1(7 downto 0),      
               d2(7 downto 0)				=>	d2(7 downto 0),      
               s1(7 downto 0)				=>	s1(7 downto 0),      
               s2(7 downto 0)				=>	s2(7 downto 0),
					sel_forward(1 downto 0)	=> sel_forward(1 downto 0),
--					in_bb(7 downto 0)			=> bb_from_mux9(7 downto 0),
					in_Ri_dec(7 downto 0)	=> reg_indirect_to_mux6(7 downto 0),
					in_Rn_dec(7 downto 0)	=> rn_addr_dec_to_mux6(7 downto 0),
					in_bit_dec(7 downto 0)	=> bit_addr_dec_to_mux6(7 downto 0));
   d_mux6 : mux6
      port map (in1(7 downto 0)	=>	direct_addr_dec_to_mux6(7 downto 0),      
                in2(7 downto 0)	=>	bit_addr_dec_to_mux6(7 downto 0),      
                in3(7 downto 0)	=>	rn_addr_dec_to_mux6(7 downto 0),      
                in4(7 downto 0)	=>	reg_indirect_to_mux6(7 downto 0),      
                sel(1 downto 0)	=>	sel_mux6(1 downto 0),      
                out1(7 downto 0)	=>	r_addr0(7 downto 0));
   d_mux7 : mux7
      port map (in1(7 downto 0)	=>	from_acc(7 downto 0),      
					 in2(7 downto 0)	=> from_mem0(7 downto 0),
					 in3(7 downto 0)	=> from_psw(7 downto 0),      
                in4(7 downto 0)	=>	from_b(7 downto 0),      
                in5(7 downto 0)	=>	from_p0(7 downto 0),      
					 in6(7 downto 0)	=> from_p1(7 downto 0),
					 in7(7 downto 0)	=> from_p2(7 downto 0),      
                in8(7 downto 0)	=>	from_p3(7 downto 0),      
                in9(7 downto 0)	=>	from_sp(7 downto 0),      
					 in10(7 downto 0)	=> from_DPH(7 downto 0),
					 in11(7 downto 0)	=> from_DPL(7 downto 0),      
                sel(7 downto 0)	=>	inst_b2(7 downto 0),      
                out1(7 downto 0)	=>	mux7_to_mux8_mux9(7 downto 0));
   d_mux8 : mux8
      port map (in1(7 downto 0)	=>	from_acc(7 downto 0),      
                in2(7 downto 0)	=>	from_mem0(7 downto 0),      
                in3(7 downto 0)	=>	mux7_to_mux8_mux9(7 downto 0),      
                sel(1 downto 0)	=>	sel_mux8(1 downto 0),      
                out1(7 downto 0)	=>	aa_from_mux8(7 downto 0));
	d_mux9 : mux9
      port map (in1(7 downto 0)	=>	from_mem0(7 downto 0),      
                in2(7 downto 0)	=>	mux7_to_mux8_mux9(7 downto 0),      
                in3(7 downto 0)	=>	from_b(7 downto 0),      
                in4(7 downto 0)	=>	bit_number_dec_to_mux9(7 downto 0),      
                in5(7 downto 0)	=>	inst_b3(7 downto 0),     
                in6(7 downto 0)	=>	inst_b2(7 downto 0),      
                sel(2 downto 0)	=>	sel_mux9(2 downto 0),      
                out1(7 downto 0)	=>	bb_from_mux9(7 downto 0));
   d_reg_indirect_dec : reg_indirect_dec
      port map (inst_byte1		=> inst_b1(0),
					 in1(7 downto 0)	=>	in_r0(7 downto 0),
					 in2(7 downto 0)	=> in_r1(7 downto 0),
					 out1(7 downto 0)	=>	reg_indirect_to_mux6(7 downto 0));
   d_rn_addr_dec : rn_addr_dec
      port map (inst_byte1(2 downto 0) => inst_b1(2 downto 0),
					 bank(1 downto 0)			=>	bank(1 downto 0),
					 out1(7 downto 0)			=>	rn_addr_dec_to_mux6(7 downto 0));
   d_bit_number_dec : bit_number_dec
      port map (in1(7 downto 0)	=>	inst_b1(7 downto 0),      
                out1(7 downto 0)	=>	bit_number_dec_to_mux9(7 downto 0));					 
	reg_aa <= aa_from_mux8;
	reg_bb <= bb_from_mux9;
--	r_addr1 <= inst_b3;
end structural;