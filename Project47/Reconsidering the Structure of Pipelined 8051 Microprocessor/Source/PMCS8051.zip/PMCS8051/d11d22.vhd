library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity d11d22RaRb is
    Port ( in1 : in std_logic_vector(7 downto 0);
           out1 : out std_logic_vector(7 downto 0));
end d11d22RaRb;

architecture Behavioral of d11d22RaRb is

begin

		out1 <= in1;

end Behavioral;
