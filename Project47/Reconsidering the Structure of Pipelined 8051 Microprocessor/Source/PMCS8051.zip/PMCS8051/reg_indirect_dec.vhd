library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity Reg_Indirect_Dec is
    Port ( 	inst_byte1	: in	std_logic;		-- Incoming Instruction Byte 1
	 			in1			: in	std_logic_vector(7 downto 0);	-- R0
				in2			: in	std_logic_vector(7 downto 0);	-- R1
	 			out1			: out std_logic_vector(7 downto 0));-- 
end Reg_Indirect_Dec;

architecture RTL of Reg_Indirect_Dec is
begin
	process(inst_byte1,in1,in2)
	begin
		case inst_byte1 is
			when '0' => out1 <= in1;
			when '1' => out1 <= in2;
			when others => out1 <= "--------";
		end case;
	end process;
end RTL;