--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 7.1.01i
--  \   \         Application : ISE WebPACK
--  /   /         Filename : fetch_tb.vhw
-- /___/   /\     Timestamp : Fri Apr 01 22:47:01 2005
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: fetch_tb
--Device: Xilinx
--

library IEEE;
use IEEE.STD_LOGIC_unsigned.all;
library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY fetch_tb IS
END fetch_tb;

ARCHITECTURE testbench_arch OF fetch_tb IS
    FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";

    COMPONENT fetch
        PORT (
            from_internal_data_memory : In std_logic_vector (15 DownTo 0);
            sel_mux1 : In std_logic_vector (1 DownTo 0);
            sel_mux5 : In std_logic_vector (1 DownTo 0);
            clock : In std_logic;
            reset : In std_logic;
            PC_load_in16 : In std_logic;
            temp1_load_in : In std_logic;
            ex_byte1 : In std_logic_vector (2 DownTo 0);
            ex_byte2 : In std_logic_vector (7 DownTo 0);
            ex_byte3 : In std_logic_vector (7 DownTo 0);
            sel_jcall : In std_logic_vector (1 DownTo 0);
            sel_mux2 : In std_logic;
            acc_in : In std_logic_vector (7 DownTo 0);
            sel_mux3 : In std_logic;
            DPTR_in : In std_logic_vector (15 DownTo 0);
            sel_mux4 : In std_logic_vector (2 DownTo 0);
            iqc : Out std_logic_vector (1 DownTo 0);
            data_bus : In std_logic_vector (7 DownTo 0);
            address_bus : Out std_logic_vector (15 DownTo 0);
            pc_resent : Out std_logic_vector (15 DownTo 0);
            instruction_byte1 : Out std_logic_vector (7 DownTo 0);
            instruction_byte2 : Out std_logic_vector (7 DownTo 0);
            instruction_byte3 : Out std_logic_vector (7 DownTo 0)
        );
    END COMPONENT;

    SIGNAL from_internal_data_memory : std_logic_vector (15 DownTo 0) := "0000000000000000";
    SIGNAL sel_mux1 : std_logic_vector (1 DownTo 0) := "00";
    SIGNAL sel_mux5 : std_logic_vector (1 DownTo 0) := "00";
    SIGNAL clock : std_logic := '0';
    SIGNAL reset : std_logic := '0';
    SIGNAL PC_load_in16 : std_logic := '0';
    SIGNAL temp1_load_in : std_logic := '0';
    SIGNAL ex_byte1 : std_logic_vector (2 DownTo 0) := "000";
    SIGNAL ex_byte2 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL ex_byte3 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL sel_jcall : std_logic_vector (1 DownTo 0) := "00";
    SIGNAL sel_mux2 : std_logic := '0';
    SIGNAL acc_in : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL sel_mux3 : std_logic := '0';
    SIGNAL DPTR_in : std_logic_vector (15 DownTo 0) := "0000000000000000";
    SIGNAL sel_mux4 : std_logic_vector (2 DownTo 0) := "000";
    SIGNAL iqc : std_logic_vector (1 DownTo 0) := "00";
    SIGNAL data_bus : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL address_bus : std_logic_vector (15 DownTo 0) := "0000000000000000";
    SIGNAL pc_resent : std_logic_vector (15 DownTo 0) := "0000000000000000";
    SIGNAL instruction_byte1 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL instruction_byte2 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL instruction_byte3 : std_logic_vector (7 DownTo 0) := "00000000";

    SHARED VARIABLE TX_ERROR : INTEGER := 0;
    SHARED VARIABLE TX_OUT : LINE;

    constant PERIOD : time := 100000 ps;
    constant DUTY_CYCLE : real := 0.5;
    constant OFFSET : time := 0 ps;

    BEGIN
        UUT : fetch
        PORT MAP (
            from_internal_data_memory => from_internal_data_memory,
            sel_mux1 => sel_mux1,
            sel_mux5 => sel_mux5,
            clock => clock,
            reset => reset,
            PC_load_in16 => PC_load_in16,
            temp1_load_in => temp1_load_in,
            ex_byte1 => ex_byte1,
            ex_byte2 => ex_byte2,
            ex_byte3 => ex_byte3,
            sel_jcall => sel_jcall,
            sel_mux2 => sel_mux2,
            acc_in => acc_in,
            sel_mux3 => sel_mux3,
            DPTR_in => DPTR_in,
            sel_mux4 => sel_mux4,
            iqc => iqc,
            data_bus => data_bus,
            address_bus => address_bus,
            pc_resent => pc_resent,
            instruction_byte1 => instruction_byte1,
            instruction_byte2 => instruction_byte2,
            instruction_byte3 => instruction_byte3
        );

        PROCESS    -- clock process for clock
        BEGIN
            WAIT for OFFSET;
            CLOCK_LOOP : LOOP
                clock <= '0';
                WAIT FOR (PERIOD - (PERIOD * DUTY_CYCLE));
                clock <= '1';
                WAIT FOR (PERIOD * DUTY_CYCLE);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS
            PROCEDURE CHECK_address_bus(
                next_address_bus : std_logic_vector (15 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (address_bus /= next_address_bus) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps address_bus="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, address_bus);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_address_bus);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_instruction_byte1(
                next_instruction_byte1 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (instruction_byte1 /= next_instruction_byte1) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps instruction_byte1="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, instruction_byte1);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_instruction_byte1);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_instruction_byte2(
                next_instruction_byte2 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (instruction_byte2 /= next_instruction_byte2) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps instruction_byte2="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, instruction_byte2);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_instruction_byte2);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_instruction_byte3(
                next_instruction_byte3 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (instruction_byte3 /= next_instruction_byte3) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps instruction_byte3="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, instruction_byte3);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_instruction_byte3);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_iqc(
                next_iqc : std_logic_vector (1 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (iqc /= next_iqc) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps iqc="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, iqc);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_iqc);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_pc_resent(
                next_pc_resent : std_logic_vector (15 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (pc_resent /= next_pc_resent) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps pc_resent="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, pc_resent);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_pc_resent);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.writeline(RESULTS, TX_LOC);
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            BEGIN
                -- -------------  Current Time:  20000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00010010";
                data_bus <= "00000010";
                ex_byte2 <= "00000010";
                ex_byte3 <= "01000100";
                from_internal_data_memory <= "0000000000000010";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  40000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00010000";
                data_bus <= "00000100";
                ex_byte2 <= "00000100";
                ex_byte3 <= "01011100";
                from_internal_data_memory <= "0000000000000100";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  60000ps
                WAIT FOR 20000 ps;
                reset <= '0';
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00001110";
                data_bus <= "00000110";
                ex_byte2 <= "00000110";
                ex_byte3 <= "10111010";
                from_internal_data_memory <= "0000000000000110";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  80000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00001100";
                data_bus <= "00001000";
                ex_byte2 <= "00001000";
                ex_byte3 <= "01100100";
                from_internal_data_memory <= "0000000000001000";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  100000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00001010";
                data_bus <= "00001010";
                ex_byte2 <= "00001010";
                ex_byte3 <= "11011000";
                from_internal_data_memory <= "0000000000001010";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  120000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00001000";
                data_bus <= "00001100";
                ex_byte2 <= "00001100";
                ex_byte3 <= "00011010";
                from_internal_data_memory <= "0000000000001100";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  140000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00000110";
                data_bus <= "00001110";
                ex_byte2 <= "00001110";
                ex_byte3 <= "10101010";
                from_internal_data_memory <= "0000000000001110";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  160000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00001100";
                data_bus <= "00010000";
                ex_byte2 <= "00010000";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000010000";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  180000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00001110";
                data_bus <= "00010010";
                ex_byte2 <= "00010010";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000010010";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  200000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00010000";
                data_bus <= "00010100";
                ex_byte2 <= "00010100";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000010100";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  220000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                acc_in <= "00010010";
                data_bus <= "00010110";
                ex_byte2 <= "00000000";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000010110";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  240000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                acc_in <= "00010100";
                data_bus <= "00011000";
                ex_byte2 <= "00000010";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000011000";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  260000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                acc_in <= "00010110";
                data_bus <= "00011010";
                ex_byte2 <= "00000100";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000011010";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  280000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                acc_in <= "00011000";
                data_bus <= "00011100";
                ex_byte2 <= "00000110";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000011100";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  300000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                acc_in <= "00011010";
                data_bus <= "00011110";
                ex_byte2 <= "00001000";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000011110";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  320000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                acc_in <= "00011100";
                data_bus <= "00100000";
                ex_byte2 <= "00001010";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000100000";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  340000ps
                WAIT FOR 20000 ps;
                reset <= '1';
                DPTR_in <= "0000000000000010";
                acc_in <= "00011110";
                data_bus <= "00100010";
                ex_byte2 <= "00001100";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000100010";
                sel_mux4 <= "110";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  360000ps
                WAIT FOR 20000 ps;
                reset <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00100000";
                data_bus <= "00100100";
                ex_byte2 <= "00001110";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000100100";
                sel_mux4 <= "110";
                -- -------------------------------------
                -- -------------  Current Time:  380000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                acc_in <= "00100010";
                data_bus <= "00100110";
                ex_byte2 <= "00010000";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000100110";
                sel_mux4 <= "000";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  400000ps
                WAIT FOR 20000 ps;
                reset <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00100100";
                data_bus <= "00101000";
                ex_byte2 <= "00010010";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000101000";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  420000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00100110";
                data_bus <= "00101010";
                ex_byte2 <= "00010100";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000101010";
                sel_jcall <= "10";
                sel_mux4 <= "100";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  440000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "00101100";
                ex_byte2 <= "00000000";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000101100";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  460000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "00101110";
                ex_byte2 <= "00000010";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000101110";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  480000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "00110000";
                ex_byte2 <= "00000100";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000110000";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  500000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "00110010";
                ex_byte2 <= "00000110";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000110010";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  520000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "00110100";
                ex_byte2 <= "00001000";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000110100";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  540000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "00110110";
                ex_byte2 <= "00001010";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000110110";
                -- -------------------------------------
                -- -------------  Current Time:  560000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "10101000";
                data_bus <= "00111000";
                ex_byte2 <= "00001100";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000111000";
                sel_mux1 <= "00";
                sel_mux4 <= "000";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  580000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "01100010";
                data_bus <= "00111010";
                ex_byte2 <= "00001110";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000111010";
                sel_jcall <= "10";
                sel_mux1 <= "00";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  600000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "01110100";
                data_bus <= "00111100";
                ex_byte2 <= "00010000";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000000111100";
                sel_jcall <= "00";
                sel_mux1 <= "00";
                sel_mux4 <= "010";
                -- -------------------------------------
                -- -------------  Current Time:  620000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "01010110";
                data_bus <= "00111110";
                ex_byte2 <= "00010010";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000000111110";
                sel_jcall <= "10";
                sel_mux4 <= "110";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  640000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00000100";
                data_bus <= "01000000";
                ex_byte2 <= "00010100";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000001000000";
                sel_mux1 <= "00";
                sel_mux4 <= "110";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  660000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "11110110";
                data_bus <= "01000010";
                ex_byte2 <= "00000000";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000001000010";
                sel_mux1 <= "00";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  680000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "00101000";
                data_bus <= "01000100";
                ex_byte2 <= "00000010";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000001000100";
                sel_jcall <= "00";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  700000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "00010100";
                data_bus <= "01000110";
                ex_byte2 <= "00000100";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000001000110";
                sel_jcall <= "10";
                sel_mux4 <= "110";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  720000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000000";
                acc_in <= "10110000";
                data_bus <= "01001000";
                ex_byte2 <= "00000110";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000001001000";
                sel_mux1 <= "10";
                sel_mux4 <= "100";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  740000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000010";
                acc_in <= "01111100";
                data_bus <= "01001010";
                ex_byte2 <= "00001000";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000001001010";
                sel_jcall <= "00";
                sel_mux1 <= "10";
                sel_mux4 <= "000";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  760000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "01101110";
                data_bus <= "01001100";
                ex_byte2 <= "00001010";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000001001100";
                sel_mux1 <= "00";
                sel_mux4 <= "110";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  780000ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                acc_in <= "00000000";
                data_bus <= "01001110";
                ex_byte2 <= "00001100";
                ex_byte3 <= "00000000";
                from_internal_data_memory <= "0000000001001110";
                sel_mux4 <= "100";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  800000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000000";
                acc_in <= "00101110";
                data_bus <= "01010000";
                ex_byte2 <= "00001110";
                ex_byte3 <= "00000010";
                from_internal_data_memory <= "0000000001010000";
                sel_mux1 <= "10";
                sel_mux4 <= "000";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  820000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000010";
                acc_in <= "01110010";
                data_bus <= "01010010";
                ex_byte2 <= "00010000";
                ex_byte3 <= "01101000";
                from_internal_data_memory <= "0000000001010010";
                sel_mux1 <= "10";
                sel_mux4 <= "010";
                -- -------------------------------------
                -- -------------  Current Time:  840000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "11000100";
                data_bus <= "01010100";
                ex_byte2 <= "00010010";
                ex_byte3 <= "11001010";
                from_internal_data_memory <= "0000000001010100";
                sel_mux1 <= "00";
                sel_mux4 <= "100";
                -- -------------------------------------
                -- -------------  Current Time:  860000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000010";
                acc_in <= "10011110";
                data_bus <= "01010110";
                ex_byte2 <= "00010100";
                ex_byte3 <= "11000010";
                from_internal_data_memory <= "0000000001010110";
                sel_mux1 <= "10";
                sel_mux4 <= "010";
                -- -------------------------------------
                -- -------------  Current Time:  880000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "11111100";
                data_bus <= "01011000";
                ex_byte2 <= "00000000";
                ex_byte3 <= "01010110";
                from_internal_data_memory <= "0000000001011000";
                sel_mux1 <= "00";
                sel_mux4 <= "010";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  900000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000010";
                acc_in <= "01011000";
                data_bus <= "01011010";
                ex_byte2 <= "00000010";
                ex_byte3 <= "00000100";
                from_internal_data_memory <= "0000000001011010";
                sel_jcall <= "10";
                sel_mux1 <= "10";
                sel_mux4 <= "010";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  920000ps
                WAIT FOR 20000 ps;
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "10101010";
                data_bus <= "01011100";
                ex_byte2 <= "00000100";
                ex_byte3 <= "11010000";
                from_internal_data_memory <= "0000000001011100";
                sel_mux1 <= "00";
                sel_mux4 <= "010";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  940000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '1';
                DPTR_in <= "0000000000000010";
                acc_in <= "01101100";
                data_bus <= "01011110";
                ex_byte2 <= "00000110";
                ex_byte3 <= "00111100";
                from_internal_data_memory <= "0000000001011110";
                sel_jcall <= "00";
                sel_mux1 <= "10";
                sel_mux4 <= "110";
                -- -------------------------------------
                -- -------------  Current Time:  960000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                DPTR_in <= "0000000000000000";
                acc_in <= "10011010";
                data_bus <= "01100000";
                ex_byte2 <= "00001000";
                ex_byte3 <= "01001000";
                from_internal_data_memory <= "0000000001100000";
                sel_jcall <= "10";
                sel_mux4 <= "100";
                sel_mux5 <= "10";
                -- -------------------------------------
                -- -------------  Current Time:  980000ps
                WAIT FOR 20000 ps;
                PC_load_in16 <= '0';
                sel_mux2 <= '0';
                DPTR_in <= "0000000000000010";
                acc_in <= "10101110";
                data_bus <= "01100010";
                ex_byte2 <= "00001010";
                ex_byte3 <= "01111010";
                from_internal_data_memory <= "0000000001100010";
                sel_jcall <= "00";
                sel_mux1 <= "00";
                sel_mux4 <= "010";
                sel_mux5 <= "00";
                -- -------------------------------------
                -- -------------  Current Time:  1e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01100100";
                from_internal_data_memory <= "0000000001100100";
                -- -------------------------------------
                -- -------------  Current Time:  1.02e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01100110";
                from_internal_data_memory <= "0000000001100110";
                -- -------------------------------------
                -- -------------  Current Time:  1.04e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01101000";
                from_internal_data_memory <= "0000000001101000";
                -- -------------------------------------
                -- -------------  Current Time:  1.06e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01101010";
                from_internal_data_memory <= "0000000001101010";
                -- -------------------------------------
                -- -------------  Current Time:  1.08e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01101100";
                from_internal_data_memory <= "0000000001101100";
                -- -------------------------------------
                -- -------------  Current Time:  1.1e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01101110";
                from_internal_data_memory <= "0000000001101110";
                -- -------------------------------------
                -- -------------  Current Time:  1.12e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01110000";
                from_internal_data_memory <= "0000000001110000";
                -- -------------------------------------
                -- -------------  Current Time:  1.14e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01110010";
                from_internal_data_memory <= "0000000001110010";
                -- -------------------------------------
                -- -------------  Current Time:  1.16e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01110100";
                from_internal_data_memory <= "0000000001110100";
                -- -------------------------------------
                -- -------------  Current Time:  1.18e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01110110";
                from_internal_data_memory <= "0000000001110110";
                -- -------------------------------------
                -- -------------  Current Time:  1.2e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01111000";
                from_internal_data_memory <= "0000000001111000";
                -- -------------------------------------
                -- -------------  Current Time:  1.22e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01111010";
                from_internal_data_memory <= "0000000001111010";
                -- -------------------------------------
                -- -------------  Current Time:  1.24e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "01111100";
                from_internal_data_memory <= "0000000001111100";
                -- -------------------------------------
                -- -------------  Current Time:  1.26e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "01111110";
                from_internal_data_memory <= "0000000001111110";
                -- -------------------------------------
                -- -------------  Current Time:  1.28e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10000000";
                from_internal_data_memory <= "0000000010000000";
                -- -------------------------------------
                -- -------------  Current Time:  1.3e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10000010";
                from_internal_data_memory <= "0000000010000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.32e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10000100";
                from_internal_data_memory <= "0000000010000100";
                -- -------------------------------------
                -- -------------  Current Time:  1.34e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10000110";
                from_internal_data_memory <= "0000000010000110";
                -- -------------------------------------
                -- -------------  Current Time:  1.36e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10001000";
                from_internal_data_memory <= "0000000010001000";
                -- -------------------------------------
                -- -------------  Current Time:  1.38e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10001010";
                from_internal_data_memory <= "0000000010001010";
                -- -------------------------------------
                -- -------------  Current Time:  1.4e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10001100";
                from_internal_data_memory <= "0000000010001100";
                -- -------------------------------------
                -- -------------  Current Time:  1.42e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10001110";
                from_internal_data_memory <= "0000000010001110";
                -- -------------------------------------
                -- -------------  Current Time:  1.44e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10010000";
                from_internal_data_memory <= "0000000010010000";
                -- -------------------------------------
                -- -------------  Current Time:  1.46e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10010010";
                from_internal_data_memory <= "0000000010010010";
                -- -------------------------------------
                -- -------------  Current Time:  1.48e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10010100";
                from_internal_data_memory <= "0000000010010100";
                -- -------------------------------------
                -- -------------  Current Time:  1.5e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10010110";
                from_internal_data_memory <= "0000000010010110";
                -- -------------------------------------
                -- -------------  Current Time:  1.52e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10011000";
                from_internal_data_memory <= "0000000010011000";
                -- -------------------------------------
                -- -------------  Current Time:  1.54e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10011010";
                from_internal_data_memory <= "0000000010011010";
                -- -------------------------------------
                -- -------------  Current Time:  1.56e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10011100";
                from_internal_data_memory <= "0000000010011100";
                -- -------------------------------------
                -- -------------  Current Time:  1.58e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10011110";
                from_internal_data_memory <= "0000000010011110";
                -- -------------------------------------
                -- -------------  Current Time:  1.6e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10100000";
                from_internal_data_memory <= "0000000010100000";
                -- -------------------------------------
                -- -------------  Current Time:  1.62e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10100010";
                from_internal_data_memory <= "0000000010100010";
                -- -------------------------------------
                -- -------------  Current Time:  1.64e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10100100";
                from_internal_data_memory <= "0000000010100100";
                -- -------------------------------------
                -- -------------  Current Time:  1.66e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10100110";
                from_internal_data_memory <= "0000000010100110";
                -- -------------------------------------
                -- -------------  Current Time:  1.68e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10101000";
                from_internal_data_memory <= "0000000010101000";
                -- -------------------------------------
                -- -------------  Current Time:  1.7e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10101010";
                from_internal_data_memory <= "0000000010101010";
                -- -------------------------------------
                -- -------------  Current Time:  1.72e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10101100";
                from_internal_data_memory <= "0000000010101100";
                -- -------------------------------------
                -- -------------  Current Time:  1.74e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10101110";
                from_internal_data_memory <= "0000000010101110";
                -- -------------------------------------
                -- -------------  Current Time:  1.76e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10110000";
                from_internal_data_memory <= "0000000010110000";
                -- -------------------------------------
                -- -------------  Current Time:  1.78e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10110010";
                from_internal_data_memory <= "0000000010110010";
                -- -------------------------------------
                -- -------------  Current Time:  1.8e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10110100";
                from_internal_data_memory <= "0000000010110100";
                -- -------------------------------------
                -- -------------  Current Time:  1.82e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10110110";
                from_internal_data_memory <= "0000000010110110";
                -- -------------------------------------
                -- -------------  Current Time:  1.84e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10111000";
                from_internal_data_memory <= "0000000010111000";
                -- -------------------------------------
                -- -------------  Current Time:  1.86e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10111010";
                from_internal_data_memory <= "0000000010111010";
                -- -------------------------------------
                -- -------------  Current Time:  1.88e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "10111100";
                from_internal_data_memory <= "0000000010111100";
                -- -------------------------------------
                -- -------------  Current Time:  1.9e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "10111110";
                from_internal_data_memory <= "0000000010111110";
                -- -------------------------------------
                -- -------------  Current Time:  1.92e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "11000000";
                from_internal_data_memory <= "0000000011000000";
                -- -------------------------------------
                -- -------------  Current Time:  1.94e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "11000010";
                from_internal_data_memory <= "0000000011000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.96e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000000";
                data_bus <= "11000100";
                from_internal_data_memory <= "0000000011000100";
                -- -------------------------------------
                -- -------------  Current Time:  1.98e+006ps
                WAIT FOR 20000 ps;
                DPTR_in <= "0000000000000010";
                data_bus <= "11000110";
                from_internal_data_memory <= "0000000011000110";
                -- -------------------------------------
                -- -------------  Current Time:  2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011001000";
                -- -------------------------------------
                -- -------------  Current Time:  2.02e+006ps
                WAIT FOR 20000 ps;
                reset <= '1';
                from_internal_data_memory <= "0000000011001010";
                -- -------------------------------------
                -- -------------  Current Time:  2.04e+006ps
                WAIT FOR 20000 ps;
                reset <= '0';
                from_internal_data_memory <= "0000000011001100";
                -- -------------------------------------
                -- -------------  Current Time:  2.06e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011001110";
                -- -------------------------------------
                -- -------------  Current Time:  2.08e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011010000";
                -- -------------------------------------
                -- -------------  Current Time:  2.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011010010";
                -- -------------------------------------
                -- -------------  Current Time:  2.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011010100";
                -- -------------------------------------
                -- -------------  Current Time:  2.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011010110";
                -- -------------------------------------
                -- -------------  Current Time:  2.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011011000";
                -- -------------------------------------
                -- -------------  Current Time:  2.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011011010";
                -- -------------------------------------
                -- -------------  Current Time:  2.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011011100";
                -- -------------------------------------
                -- -------------  Current Time:  2.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011011110";
                -- -------------------------------------
                -- -------------  Current Time:  2.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011100000";
                -- -------------------------------------
                -- -------------  Current Time:  2.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011100010";
                -- -------------------------------------
                -- -------------  Current Time:  2.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011100100";
                -- -------------------------------------
                -- -------------  Current Time:  2.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011100110";
                -- -------------------------------------
                -- -------------  Current Time:  2.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011101000";
                -- -------------------------------------
                -- -------------  Current Time:  2.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011101010";
                -- -------------------------------------
                -- -------------  Current Time:  2.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011101100";
                -- -------------------------------------
                -- -------------  Current Time:  2.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011101110";
                -- -------------------------------------
                -- -------------  Current Time:  2.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011110000";
                -- -------------------------------------
                -- -------------  Current Time:  2.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011110010";
                -- -------------------------------------
                -- -------------  Current Time:  2.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011110100";
                -- -------------------------------------
                -- -------------  Current Time:  2.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011110110";
                -- -------------------------------------
                -- -------------  Current Time:  2.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011111000";
                -- -------------------------------------
                -- -------------  Current Time:  2.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011111010";
                -- -------------------------------------
                -- -------------  Current Time:  2.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011111100";
                -- -------------------------------------
                -- -------------  Current Time:  2.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000011111110";
                -- -------------------------------------
                -- -------------  Current Time:  2.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100000000";
                -- -------------------------------------
                -- -------------  Current Time:  2.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100000010";
                -- -------------------------------------
                -- -------------  Current Time:  2.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100000100";
                -- -------------------------------------
                -- -------------  Current Time:  2.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100000110";
                -- -------------------------------------
                -- -------------  Current Time:  2.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100001000";
                -- -------------------------------------
                -- -------------  Current Time:  2.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100001010";
                -- -------------------------------------
                -- -------------  Current Time:  2.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100001100";
                -- -------------------------------------
                -- -------------  Current Time:  2.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100001110";
                -- -------------------------------------
                -- -------------  Current Time:  2.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100010000";
                -- -------------------------------------
                -- -------------  Current Time:  2.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100010010";
                -- -------------------------------------
                -- -------------  Current Time:  2.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100010100";
                -- -------------------------------------
                -- -------------  Current Time:  2.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100010110";
                -- -------------------------------------
                -- -------------  Current Time:  2.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100011000";
                -- -------------------------------------
                -- -------------  Current Time:  2.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100011010";
                -- -------------------------------------
                -- -------------  Current Time:  2.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100011100";
                -- -------------------------------------
                -- -------------  Current Time:  2.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100011110";
                -- -------------------------------------
                -- -------------  Current Time:  2.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100100000";
                -- -------------------------------------
                -- -------------  Current Time:  2.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100100010";
                -- -------------------------------------
                -- -------------  Current Time:  2.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100100100";
                -- -------------------------------------
                -- -------------  Current Time:  2.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100100110";
                -- -------------------------------------
                -- -------------  Current Time:  2.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100101000";
                -- -------------------------------------
                -- -------------  Current Time:  2.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100101010";
                -- -------------------------------------
                -- -------------  Current Time:  3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100101100";
                -- -------------------------------------
                -- -------------  Current Time:  3.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100101110";
                -- -------------------------------------
                -- -------------  Current Time:  3.04e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100110000";
                -- -------------------------------------
                -- -------------  Current Time:  3.06e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100110010";
                -- -------------------------------------
                -- -------------  Current Time:  3.08e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100110100";
                -- -------------------------------------
                -- -------------  Current Time:  3.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100110110";
                -- -------------------------------------
                -- -------------  Current Time:  3.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100111000";
                -- -------------------------------------
                -- -------------  Current Time:  3.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100111010";
                -- -------------------------------------
                -- -------------  Current Time:  3.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100111100";
                -- -------------------------------------
                -- -------------  Current Time:  3.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000100111110";
                -- -------------------------------------
                -- -------------  Current Time:  3.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101000000";
                -- -------------------------------------
                -- -------------  Current Time:  3.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101000010";
                -- -------------------------------------
                -- -------------  Current Time:  3.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101000100";
                -- -------------------------------------
                -- -------------  Current Time:  3.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101000110";
                -- -------------------------------------
                -- -------------  Current Time:  3.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101001000";
                -- -------------------------------------
                -- -------------  Current Time:  3.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101001010";
                -- -------------------------------------
                -- -------------  Current Time:  3.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101001100";
                -- -------------------------------------
                -- -------------  Current Time:  3.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101001110";
                -- -------------------------------------
                -- -------------  Current Time:  3.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101010000";
                -- -------------------------------------
                -- -------------  Current Time:  3.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101010010";
                -- -------------------------------------
                -- -------------  Current Time:  3.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101010100";
                -- -------------------------------------
                -- -------------  Current Time:  3.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101010110";
                -- -------------------------------------
                -- -------------  Current Time:  3.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101011000";
                -- -------------------------------------
                -- -------------  Current Time:  3.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101011010";
                -- -------------------------------------
                -- -------------  Current Time:  3.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101011100";
                -- -------------------------------------
                -- -------------  Current Time:  3.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101011110";
                -- -------------------------------------
                -- -------------  Current Time:  3.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101100000";
                -- -------------------------------------
                -- -------------  Current Time:  3.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101100010";
                -- -------------------------------------
                -- -------------  Current Time:  3.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101100100";
                -- -------------------------------------
                -- -------------  Current Time:  3.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101100110";
                -- -------------------------------------
                -- -------------  Current Time:  3.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101101000";
                -- -------------------------------------
                -- -------------  Current Time:  3.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101101010";
                -- -------------------------------------
                -- -------------  Current Time:  3.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101101100";
                -- -------------------------------------
                -- -------------  Current Time:  3.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101101110";
                -- -------------------------------------
                -- -------------  Current Time:  3.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101110000";
                -- -------------------------------------
                -- -------------  Current Time:  3.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101110010";
                -- -------------------------------------
                -- -------------  Current Time:  3.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101110100";
                -- -------------------------------------
                -- -------------  Current Time:  3.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101110110";
                -- -------------------------------------
                -- -------------  Current Time:  3.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101111000";
                -- -------------------------------------
                -- -------------  Current Time:  3.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101111010";
                -- -------------------------------------
                -- -------------  Current Time:  3.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101111100";
                -- -------------------------------------
                -- -------------  Current Time:  3.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000101111110";
                -- -------------------------------------
                -- -------------  Current Time:  3.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110000000";
                -- -------------------------------------
                -- -------------  Current Time:  3.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110000010";
                -- -------------------------------------
                -- -------------  Current Time:  3.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110000100";
                -- -------------------------------------
                -- -------------  Current Time:  3.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110000110";
                -- -------------------------------------
                -- -------------  Current Time:  3.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110001000";
                -- -------------------------------------
                -- -------------  Current Time:  3.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110001010";
                -- -------------------------------------
                -- -------------  Current Time:  3.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110001100";
                -- -------------------------------------
                -- -------------  Current Time:  3.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110001110";
                -- -------------------------------------
                -- -------------  Current Time:  4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110010000";
                -- -------------------------------------
                -- -------------  Current Time:  4.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110010010";
                -- -------------------------------------
                -- -------------  Current Time:  4.04e+006ps
                WAIT FOR 20000 ps;
                reset <= '1';
                from_internal_data_memory <= "0000000110010100";
                -- -------------------------------------
                -- -------------  Current Time:  4.06e+006ps
                WAIT FOR 20000 ps;
                reset <= '0';
                from_internal_data_memory <= "0000000110010110";
                -- -------------------------------------
                -- -------------  Current Time:  4.08e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110011000";
                -- -------------------------------------
                -- -------------  Current Time:  4.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110011010";
                -- -------------------------------------
                -- -------------  Current Time:  4.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110011100";
                -- -------------------------------------
                -- -------------  Current Time:  4.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110011110";
                -- -------------------------------------
                -- -------------  Current Time:  4.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110100000";
                -- -------------------------------------
                -- -------------  Current Time:  4.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110100010";
                -- -------------------------------------
                -- -------------  Current Time:  4.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110100100";
                -- -------------------------------------
                -- -------------  Current Time:  4.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110100110";
                -- -------------------------------------
                -- -------------  Current Time:  4.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110101000";
                -- -------------------------------------
                -- -------------  Current Time:  4.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110101010";
                -- -------------------------------------
                -- -------------  Current Time:  4.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110101100";
                -- -------------------------------------
                -- -------------  Current Time:  4.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110101110";
                -- -------------------------------------
                -- -------------  Current Time:  4.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110110000";
                -- -------------------------------------
                -- -------------  Current Time:  4.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110110010";
                -- -------------------------------------
                -- -------------  Current Time:  4.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110110100";
                -- -------------------------------------
                -- -------------  Current Time:  4.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110110110";
                -- -------------------------------------
                -- -------------  Current Time:  4.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110111000";
                -- -------------------------------------
                -- -------------  Current Time:  4.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110111010";
                -- -------------------------------------
                -- -------------  Current Time:  4.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110111100";
                -- -------------------------------------
                -- -------------  Current Time:  4.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000110111110";
                -- -------------------------------------
                -- -------------  Current Time:  4.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111000000";
                -- -------------------------------------
                -- -------------  Current Time:  4.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111000010";
                -- -------------------------------------
                -- -------------  Current Time:  4.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111000100";
                -- -------------------------------------
                -- -------------  Current Time:  4.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111000110";
                -- -------------------------------------
                -- -------------  Current Time:  4.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111001000";
                -- -------------------------------------
                -- -------------  Current Time:  4.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111001010";
                -- -------------------------------------
                -- -------------  Current Time:  4.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111001100";
                -- -------------------------------------
                -- -------------  Current Time:  4.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111001110";
                -- -------------------------------------
                -- -------------  Current Time:  4.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111010000";
                -- -------------------------------------
                -- -------------  Current Time:  4.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111010010";
                -- -------------------------------------
                -- -------------  Current Time:  4.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111010100";
                -- -------------------------------------
                -- -------------  Current Time:  4.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111010110";
                -- -------------------------------------
                -- -------------  Current Time:  4.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111011000";
                -- -------------------------------------
                -- -------------  Current Time:  4.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111011010";
                -- -------------------------------------
                -- -------------  Current Time:  4.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111011100";
                -- -------------------------------------
                -- -------------  Current Time:  4.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111011110";
                -- -------------------------------------
                -- -------------  Current Time:  4.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111100000";
                -- -------------------------------------
                -- -------------  Current Time:  4.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111100010";
                -- -------------------------------------
                -- -------------  Current Time:  4.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111100100";
                -- -------------------------------------
                -- -------------  Current Time:  4.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111100110";
                -- -------------------------------------
                -- -------------  Current Time:  4.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111101000";
                -- -------------------------------------
                -- -------------  Current Time:  4.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111101010";
                -- -------------------------------------
                -- -------------  Current Time:  4.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111101100";
                -- -------------------------------------
                -- -------------  Current Time:  4.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111101110";
                -- -------------------------------------
                -- -------------  Current Time:  4.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111110000";
                -- -------------------------------------
                -- -------------  Current Time:  4.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111110010";
                -- -------------------------------------
                -- -------------  Current Time:  5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111110100";
                -- -------------------------------------
                -- -------------  Current Time:  5.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111110110";
                -- -------------------------------------
                -- -------------  Current Time:  5.04e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111111000";
                -- -------------------------------------
                -- -------------  Current Time:  5.06e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111111010";
                -- -------------------------------------
                -- -------------  Current Time:  5.08e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111111100";
                -- -------------------------------------
                -- -------------  Current Time:  5.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000000111111110";
                -- -------------------------------------
                -- -------------  Current Time:  5.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000000000";
                -- -------------------------------------
                -- -------------  Current Time:  5.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000000010";
                -- -------------------------------------
                -- -------------  Current Time:  5.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000000100";
                -- -------------------------------------
                -- -------------  Current Time:  5.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000000110";
                -- -------------------------------------
                -- -------------  Current Time:  5.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000001000";
                -- -------------------------------------
                -- -------------  Current Time:  5.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000001010";
                -- -------------------------------------
                -- -------------  Current Time:  5.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000001100";
                -- -------------------------------------
                -- -------------  Current Time:  5.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000001110";
                -- -------------------------------------
                -- -------------  Current Time:  5.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000010000";
                -- -------------------------------------
                -- -------------  Current Time:  5.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000010010";
                -- -------------------------------------
                -- -------------  Current Time:  5.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000010100";
                -- -------------------------------------
                -- -------------  Current Time:  5.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000010110";
                -- -------------------------------------
                -- -------------  Current Time:  5.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000011000";
                -- -------------------------------------
                -- -------------  Current Time:  5.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000011010";
                -- -------------------------------------
                -- -------------  Current Time:  5.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000011100";
                -- -------------------------------------
                -- -------------  Current Time:  5.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000011110";
                -- -------------------------------------
                -- -------------  Current Time:  5.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000100000";
                -- -------------------------------------
                -- -------------  Current Time:  5.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000100010";
                -- -------------------------------------
                -- -------------  Current Time:  5.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000100100";
                -- -------------------------------------
                -- -------------  Current Time:  5.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000100110";
                -- -------------------------------------
                -- -------------  Current Time:  5.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000101000";
                -- -------------------------------------
                -- -------------  Current Time:  5.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000101010";
                -- -------------------------------------
                -- -------------  Current Time:  5.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000101100";
                -- -------------------------------------
                -- -------------  Current Time:  5.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000101110";
                -- -------------------------------------
                -- -------------  Current Time:  5.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000110000";
                -- -------------------------------------
                -- -------------  Current Time:  5.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000110010";
                -- -------------------------------------
                -- -------------  Current Time:  5.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000110100";
                -- -------------------------------------
                -- -------------  Current Time:  5.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000110110";
                -- -------------------------------------
                -- -------------  Current Time:  5.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000111000";
                -- -------------------------------------
                -- -------------  Current Time:  5.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000111010";
                -- -------------------------------------
                -- -------------  Current Time:  5.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000111100";
                -- -------------------------------------
                -- -------------  Current Time:  5.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001000111110";
                -- -------------------------------------
                -- -------------  Current Time:  5.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001000000";
                -- -------------------------------------
                -- -------------  Current Time:  5.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001000010";
                -- -------------------------------------
                -- -------------  Current Time:  5.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001000100";
                -- -------------------------------------
                -- -------------  Current Time:  5.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001000110";
                -- -------------------------------------
                -- -------------  Current Time:  5.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001001000";
                -- -------------------------------------
                -- -------------  Current Time:  5.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001001010";
                -- -------------------------------------
                -- -------------  Current Time:  5.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001001100";
                -- -------------------------------------
                -- -------------  Current Time:  5.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001001110";
                -- -------------------------------------
                -- -------------  Current Time:  5.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001010000";
                -- -------------------------------------
                -- -------------  Current Time:  5.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001010010";
                -- -------------------------------------
                -- -------------  Current Time:  5.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001010100";
                -- -------------------------------------
                -- -------------  Current Time:  5.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001010110";
                -- -------------------------------------
                -- -------------  Current Time:  6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001011000";
                -- -------------------------------------
                -- -------------  Current Time:  6.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001011010";
                -- -------------------------------------
                -- -------------  Current Time:  6.04e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001011100";
                -- -------------------------------------
                -- -------------  Current Time:  6.06e+006ps
                WAIT FOR 20000 ps;
                reset <= '1';
                from_internal_data_memory <= "0000001001011110";
                -- -------------------------------------
                -- -------------  Current Time:  6.08e+006ps
                WAIT FOR 20000 ps;
                reset <= '0';
                from_internal_data_memory <= "0000001001100000";
                -- -------------------------------------
                -- -------------  Current Time:  6.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001100010";
                -- -------------------------------------
                -- -------------  Current Time:  6.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001100100";
                -- -------------------------------------
                -- -------------  Current Time:  6.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001100110";
                -- -------------------------------------
                -- -------------  Current Time:  6.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001101000";
                -- -------------------------------------
                -- -------------  Current Time:  6.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001101010";
                -- -------------------------------------
                -- -------------  Current Time:  6.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001101100";
                -- -------------------------------------
                -- -------------  Current Time:  6.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001101110";
                -- -------------------------------------
                -- -------------  Current Time:  6.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001110000";
                -- -------------------------------------
                -- -------------  Current Time:  6.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001110010";
                -- -------------------------------------
                -- -------------  Current Time:  6.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001110100";
                -- -------------------------------------
                -- -------------  Current Time:  6.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001110110";
                -- -------------------------------------
                -- -------------  Current Time:  6.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001111000";
                -- -------------------------------------
                -- -------------  Current Time:  6.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001111010";
                -- -------------------------------------
                -- -------------  Current Time:  6.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001111100";
                -- -------------------------------------
                -- -------------  Current Time:  6.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001001111110";
                -- -------------------------------------
                -- -------------  Current Time:  6.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010000000";
                -- -------------------------------------
                -- -------------  Current Time:  6.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010000010";
                -- -------------------------------------
                -- -------------  Current Time:  6.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010000100";
                -- -------------------------------------
                -- -------------  Current Time:  6.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010000110";
                -- -------------------------------------
                -- -------------  Current Time:  6.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010001000";
                -- -------------------------------------
                -- -------------  Current Time:  6.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010001010";
                -- -------------------------------------
                -- -------------  Current Time:  6.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010001100";
                -- -------------------------------------
                -- -------------  Current Time:  6.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010001110";
                -- -------------------------------------
                -- -------------  Current Time:  6.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010010000";
                -- -------------------------------------
                -- -------------  Current Time:  6.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010010010";
                -- -------------------------------------
                -- -------------  Current Time:  6.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010010100";
                -- -------------------------------------
                -- -------------  Current Time:  6.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010010110";
                -- -------------------------------------
                -- -------------  Current Time:  6.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010011000";
                -- -------------------------------------
                -- -------------  Current Time:  6.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010011010";
                -- -------------------------------------
                -- -------------  Current Time:  6.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010011100";
                -- -------------------------------------
                -- -------------  Current Time:  6.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010011110";
                -- -------------------------------------
                -- -------------  Current Time:  6.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010100000";
                -- -------------------------------------
                -- -------------  Current Time:  6.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010100010";
                -- -------------------------------------
                -- -------------  Current Time:  6.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010100100";
                -- -------------------------------------
                -- -------------  Current Time:  6.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010100110";
                -- -------------------------------------
                -- -------------  Current Time:  6.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010101000";
                -- -------------------------------------
                -- -------------  Current Time:  6.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010101010";
                -- -------------------------------------
                -- -------------  Current Time:  6.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010101100";
                -- -------------------------------------
                -- -------------  Current Time:  6.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010101110";
                -- -------------------------------------
                -- -------------  Current Time:  6.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010110000";
                -- -------------------------------------
                -- -------------  Current Time:  6.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010110010";
                -- -------------------------------------
                -- -------------  Current Time:  6.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010110100";
                -- -------------------------------------
                -- -------------  Current Time:  6.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010110110";
                -- -------------------------------------
                -- -------------  Current Time:  6.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010111000";
                -- -------------------------------------
                -- -------------  Current Time:  6.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010111010";
                -- -------------------------------------
                -- -------------  Current Time:  7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010111100";
                -- -------------------------------------
                -- -------------  Current Time:  7.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001010111110";
                -- -------------------------------------
                -- -------------  Current Time:  7.04e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011000000";
                -- -------------------------------------
                -- -------------  Current Time:  7.06e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011000010";
                -- -------------------------------------
                -- -------------  Current Time:  7.08e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011000100";
                -- -------------------------------------
                -- -------------  Current Time:  7.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011000110";
                -- -------------------------------------
                -- -------------  Current Time:  7.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011001000";
                -- -------------------------------------
                -- -------------  Current Time:  7.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011001010";
                -- -------------------------------------
                -- -------------  Current Time:  7.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011001100";
                -- -------------------------------------
                -- -------------  Current Time:  7.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011001110";
                -- -------------------------------------
                -- -------------  Current Time:  7.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011010000";
                -- -------------------------------------
                -- -------------  Current Time:  7.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011010010";
                -- -------------------------------------
                -- -------------  Current Time:  7.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011010100";
                -- -------------------------------------
                -- -------------  Current Time:  7.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011010110";
                -- -------------------------------------
                -- -------------  Current Time:  7.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011011000";
                -- -------------------------------------
                -- -------------  Current Time:  7.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011011010";
                -- -------------------------------------
                -- -------------  Current Time:  7.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011011100";
                -- -------------------------------------
                -- -------------  Current Time:  7.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011011110";
                -- -------------------------------------
                -- -------------  Current Time:  7.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011100000";
                -- -------------------------------------
                -- -------------  Current Time:  7.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011100010";
                -- -------------------------------------
                -- -------------  Current Time:  7.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011100100";
                -- -------------------------------------
                -- -------------  Current Time:  7.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011100110";
                -- -------------------------------------
                -- -------------  Current Time:  7.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011101000";
                -- -------------------------------------
                -- -------------  Current Time:  7.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011101010";
                -- -------------------------------------
                -- -------------  Current Time:  7.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011101100";
                -- -------------------------------------
                -- -------------  Current Time:  7.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011101110";
                -- -------------------------------------
                -- -------------  Current Time:  7.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011110000";
                -- -------------------------------------
                -- -------------  Current Time:  7.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011110010";
                -- -------------------------------------
                -- -------------  Current Time:  7.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011110100";
                -- -------------------------------------
                -- -------------  Current Time:  7.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011110110";
                -- -------------------------------------
                -- -------------  Current Time:  7.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011111000";
                -- -------------------------------------
                -- -------------  Current Time:  7.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011111010";
                -- -------------------------------------
                -- -------------  Current Time:  7.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011111100";
                -- -------------------------------------
                -- -------------  Current Time:  7.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001011111110";
                -- -------------------------------------
                -- -------------  Current Time:  7.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100000000";
                -- -------------------------------------
                -- -------------  Current Time:  7.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100000010";
                -- -------------------------------------
                -- -------------  Current Time:  7.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100000100";
                -- -------------------------------------
                -- -------------  Current Time:  7.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100000110";
                -- -------------------------------------
                -- -------------  Current Time:  7.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100001000";
                -- -------------------------------------
                -- -------------  Current Time:  7.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100001010";
                -- -------------------------------------
                -- -------------  Current Time:  7.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100001100";
                -- -------------------------------------
                -- -------------  Current Time:  7.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100001110";
                -- -------------------------------------
                -- -------------  Current Time:  7.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100010000";
                -- -------------------------------------
                -- -------------  Current Time:  7.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100010010";
                -- -------------------------------------
                -- -------------  Current Time:  7.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100010100";
                -- -------------------------------------
                -- -------------  Current Time:  7.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100010110";
                -- -------------------------------------
                -- -------------  Current Time:  7.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100011000";
                -- -------------------------------------
                -- -------------  Current Time:  7.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100011010";
                -- -------------------------------------
                -- -------------  Current Time:  7.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100011100";
                -- -------------------------------------
                -- -------------  Current Time:  7.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100011110";
                -- -------------------------------------
                -- -------------  Current Time:  8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100100000";
                -- -------------------------------------
                -- -------------  Current Time:  8.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100100010";
                -- -------------------------------------
                -- -------------  Current Time:  8.04e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100100100";
                -- -------------------------------------
                -- -------------  Current Time:  8.06e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100100110";
                -- -------------------------------------
                -- -------------  Current Time:  8.08e+006ps
                WAIT FOR 20000 ps;
                reset <= '1';
                from_internal_data_memory <= "0000001100101000";
                -- -------------------------------------
                -- -------------  Current Time:  8.1e+006ps
                WAIT FOR 20000 ps;
                reset <= '0';
                from_internal_data_memory <= "0000001100101010";
                -- -------------------------------------
                -- -------------  Current Time:  8.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100101100";
                -- -------------------------------------
                -- -------------  Current Time:  8.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100101110";
                -- -------------------------------------
                -- -------------  Current Time:  8.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100110000";
                -- -------------------------------------
                -- -------------  Current Time:  8.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100110010";
                -- -------------------------------------
                -- -------------  Current Time:  8.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100110100";
                -- -------------------------------------
                -- -------------  Current Time:  8.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100110110";
                -- -------------------------------------
                -- -------------  Current Time:  8.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100111000";
                -- -------------------------------------
                -- -------------  Current Time:  8.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100111010";
                -- -------------------------------------
                -- -------------  Current Time:  8.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100111100";
                -- -------------------------------------
                -- -------------  Current Time:  8.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001100111110";
                -- -------------------------------------
                -- -------------  Current Time:  8.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101000000";
                -- -------------------------------------
                -- -------------  Current Time:  8.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101000010";
                -- -------------------------------------
                -- -------------  Current Time:  8.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101000100";
                -- -------------------------------------
                -- -------------  Current Time:  8.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101000110";
                -- -------------------------------------
                -- -------------  Current Time:  8.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101001000";
                -- -------------------------------------
                -- -------------  Current Time:  8.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101001010";
                -- -------------------------------------
                -- -------------  Current Time:  8.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101001100";
                -- -------------------------------------
                -- -------------  Current Time:  8.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101001110";
                -- -------------------------------------
                -- -------------  Current Time:  8.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101010000";
                -- -------------------------------------
                -- -------------  Current Time:  8.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101010010";
                -- -------------------------------------
                -- -------------  Current Time:  8.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101010100";
                -- -------------------------------------
                -- -------------  Current Time:  8.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101010110";
                -- -------------------------------------
                -- -------------  Current Time:  8.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101011000";
                -- -------------------------------------
                -- -------------  Current Time:  8.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101011010";
                -- -------------------------------------
                -- -------------  Current Time:  8.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101011100";
                -- -------------------------------------
                -- -------------  Current Time:  8.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101011110";
                -- -------------------------------------
                -- -------------  Current Time:  8.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101100000";
                -- -------------------------------------
                -- -------------  Current Time:  8.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101100010";
                -- -------------------------------------
                -- -------------  Current Time:  8.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101100100";
                -- -------------------------------------
                -- -------------  Current Time:  8.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101100110";
                -- -------------------------------------
                -- -------------  Current Time:  8.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101101000";
                -- -------------------------------------
                -- -------------  Current Time:  8.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101101010";
                -- -------------------------------------
                -- -------------  Current Time:  8.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101101100";
                -- -------------------------------------
                -- -------------  Current Time:  8.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101101110";
                -- -------------------------------------
                -- -------------  Current Time:  8.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101110000";
                -- -------------------------------------
                -- -------------  Current Time:  8.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101110010";
                -- -------------------------------------
                -- -------------  Current Time:  8.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101110100";
                -- -------------------------------------
                -- -------------  Current Time:  8.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101110110";
                -- -------------------------------------
                -- -------------  Current Time:  8.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101111000";
                -- -------------------------------------
                -- -------------  Current Time:  8.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101111010";
                -- -------------------------------------
                -- -------------  Current Time:  8.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101111100";
                -- -------------------------------------
                -- -------------  Current Time:  8.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001101111110";
                -- -------------------------------------
                -- -------------  Current Time:  8.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110000000";
                -- -------------------------------------
                -- -------------  Current Time:  8.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110000010";
                -- -------------------------------------
                -- -------------  Current Time:  9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110000100";
                -- -------------------------------------
                -- -------------  Current Time:  9.02e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110000110";
                -- -------------------------------------
                -- -------------  Current Time:  9.04e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110001000";
                -- -------------------------------------
                -- -------------  Current Time:  9.06e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110001010";
                -- -------------------------------------
                -- -------------  Current Time:  9.08e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110001100";
                -- -------------------------------------
                -- -------------  Current Time:  9.1e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110001110";
                -- -------------------------------------
                -- -------------  Current Time:  9.12e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110010000";
                -- -------------------------------------
                -- -------------  Current Time:  9.14e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110010010";
                -- -------------------------------------
                -- -------------  Current Time:  9.16e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110010100";
                -- -------------------------------------
                -- -------------  Current Time:  9.18e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110010110";
                -- -------------------------------------
                -- -------------  Current Time:  9.2e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110011000";
                -- -------------------------------------
                -- -------------  Current Time:  9.22e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110011010";
                -- -------------------------------------
                -- -------------  Current Time:  9.24e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110011100";
                -- -------------------------------------
                -- -------------  Current Time:  9.26e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110011110";
                -- -------------------------------------
                -- -------------  Current Time:  9.28e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110100000";
                -- -------------------------------------
                -- -------------  Current Time:  9.3e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110100010";
                -- -------------------------------------
                -- -------------  Current Time:  9.32e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110100100";
                -- -------------------------------------
                -- -------------  Current Time:  9.34e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110100110";
                -- -------------------------------------
                -- -------------  Current Time:  9.36e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110101000";
                -- -------------------------------------
                -- -------------  Current Time:  9.38e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110101010";
                -- -------------------------------------
                -- -------------  Current Time:  9.4e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110101100";
                -- -------------------------------------
                -- -------------  Current Time:  9.42e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110101110";
                -- -------------------------------------
                -- -------------  Current Time:  9.44e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110110000";
                -- -------------------------------------
                -- -------------  Current Time:  9.46e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110110010";
                -- -------------------------------------
                -- -------------  Current Time:  9.48e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110110100";
                -- -------------------------------------
                -- -------------  Current Time:  9.5e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110110110";
                -- -------------------------------------
                -- -------------  Current Time:  9.52e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110111000";
                -- -------------------------------------
                -- -------------  Current Time:  9.54e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110111010";
                -- -------------------------------------
                -- -------------  Current Time:  9.56e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110111100";
                -- -------------------------------------
                -- -------------  Current Time:  9.58e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001110111110";
                -- -------------------------------------
                -- -------------  Current Time:  9.6e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111000000";
                -- -------------------------------------
                -- -------------  Current Time:  9.62e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111000010";
                -- -------------------------------------
                -- -------------  Current Time:  9.64e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111000100";
                -- -------------------------------------
                -- -------------  Current Time:  9.66e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111000110";
                -- -------------------------------------
                -- -------------  Current Time:  9.68e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111001000";
                -- -------------------------------------
                -- -------------  Current Time:  9.7e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111001010";
                -- -------------------------------------
                -- -------------  Current Time:  9.72e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111001100";
                -- -------------------------------------
                -- -------------  Current Time:  9.74e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111001110";
                -- -------------------------------------
                -- -------------  Current Time:  9.76e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111010000";
                -- -------------------------------------
                -- -------------  Current Time:  9.78e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111010010";
                -- -------------------------------------
                -- -------------  Current Time:  9.8e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111010100";
                -- -------------------------------------
                -- -------------  Current Time:  9.82e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111010110";
                -- -------------------------------------
                -- -------------  Current Time:  9.84e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111011000";
                -- -------------------------------------
                -- -------------  Current Time:  9.86e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111011010";
                -- -------------------------------------
                -- -------------  Current Time:  9.88e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111011100";
                -- -------------------------------------
                -- -------------  Current Time:  9.9e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111011110";
                -- -------------------------------------
                -- -------------  Current Time:  9.92e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111100000";
                -- -------------------------------------
                -- -------------  Current Time:  9.94e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111100010";
                -- -------------------------------------
                -- -------------  Current Time:  9.96e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111100100";
                -- -------------------------------------
                -- -------------  Current Time:  9.98e+006ps
                WAIT FOR 20000 ps;
                from_internal_data_memory <= "0000001111100110";
                -- -------------------------------------
                -- -------------  Current Time:  1.01e+007ps
                WAIT FOR 120000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.012e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.212e+007ps
                WAIT FOR 2e+006 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.214e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.414e+007ps
                WAIT FOR 2e+006 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.416e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.664e+007ps
                WAIT FOR 2.48e+006 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.666e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.716e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.718e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.768e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.77e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.82e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.822e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.872e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.874e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.924e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.926e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  1.976e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  1.978e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.028e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.03e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.08e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.082e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.132e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.134e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.184e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.186e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.236e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.238e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.288e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.29e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.34e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.342e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.392e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.394e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.444e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.446e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.496e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.498e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                -- -------------  Current Time:  2.548e+007ps
                WAIT FOR 500000 ps;
                reset <= '1';
                -- -------------------------------------
                -- -------------  Current Time:  2.55e+007ps
                WAIT FOR 20000 ps;
                reset <= '0';
                -- -------------------------------------
                WAIT FOR 2.754e+007 ps;

                IF (TX_ERROR = 0) THEN
                    STD.TEXTIO.write(TX_OUT, string'("No errors or warnings"));
                    STD.TEXTIO.writeline(RESULTS, TX_OUT);
                    ASSERT (FALSE) REPORT
                      "Simulation successful (not a failure).  No problems detected."
                      SEVERITY FAILURE;
                ELSE
                    STD.TEXTIO.write(TX_OUT, TX_ERROR);
                    STD.TEXTIO.write(TX_OUT,
                        string'(" errors found in simulation"));
                    STD.TEXTIO.writeline(RESULTS, TX_OUT);
                    ASSERT (FALSE) REPORT "Errors found during simulation"
                         SEVERITY FAILURE;
                END IF;
            END PROCESS;

    END testbench_arch;

