-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Sun Mar 20 11:12:00 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY as2_tb IS
END as2_tb;

ARCHITECTURE testbench_arch OF as2_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT as2
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			sel : In  std_logic;
			out1 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL sel : std_logic;
	SIGNAL out1 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : as2
	PORT MAP (
		in1 => in1,
		sel => sel,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("01111001"); --79
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=5 ns
		CHECK_out1("01111011",5); --7B
		-- --------------------
		WAIT FOR 5 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=15 ns
		CHECK_out1("10001001",15); --89
		-- --------------------
		WAIT FOR 5 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 5 ns; -- Time=25 ns
		CHECK_out1("00000100",25); --4
		-- --------------------
		WAIT FOR 5 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("11111111"); --FF
		-- --------------------
		WAIT FOR 5 ns; -- Time=35 ns
		CHECK_out1("11111111",35); --FF
		-- --------------------
		WAIT FOR 5 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("11010000"); --D0
		-- --------------------
		WAIT FOR 5 ns; -- Time=45 ns
		CHECK_out1("11010010",45); --D2
		-- --------------------
		WAIT FOR 5 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("00001101"); --D
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=55 ns
		CHECK_out1("00001111",55); --F
		-- --------------------
		WAIT FOR 5 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 5 ns; -- Time=65 ns
		CHECK_out1("10001110",65); --8E
		-- --------------------
		WAIT FOR 5 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 5 ns; -- Time=75 ns
		CHECK_out1("01100001",75); --61
		-- --------------------
		WAIT FOR 5 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("11011101"); --DD
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=85 ns
		CHECK_out1("11011111",85); --DF
		-- --------------------
		WAIT FOR 5 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("10011010"); --9A
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=95 ns
		CHECK_out1("10011100",95); --9C
		-- --------------------
		WAIT FOR 5 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("01101100"); --6C
		-- --------------------
		WAIT FOR 5 ns; -- Time=105 ns
		CHECK_out1("01101110",105); --6E
		-- --------------------
		WAIT FOR 5 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("01100111"); --67
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=115 ns
		CHECK_out1("01101001",115); --69
		-- --------------------
		WAIT FOR 5 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("11111111"); --FF
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=125 ns
		CHECK_out1("11100010",125); --E2
		-- --------------------
		WAIT FOR 5 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("01101101"); --6D
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=135 ns
		CHECK_out1("01101111",135); --6F
		-- --------------------
		WAIT FOR 5 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("11100010"); --E2
		-- --------------------
		WAIT FOR 5 ns; -- Time=145 ns
		CHECK_out1("11100100",145); --E4
		-- --------------------
		WAIT FOR 5 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 5 ns; -- Time=155 ns
		CHECK_out1("01010111",155); --57
		-- --------------------
		WAIT FOR 5 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("00011010"); --1A
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=165 ns
		CHECK_out1("00011100",165); --1C
		-- --------------------
		WAIT FOR 5 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("11000110"); --C6
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=175 ns
		CHECK_out1("11001000",175); --C8
		-- --------------------
		WAIT FOR 5 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 5 ns; -- Time=185 ns
		CHECK_out1("00110001",185); --31
		-- --------------------
		WAIT FOR 5 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 5 ns; -- Time=195 ns
		CHECK_out1("01101011",195); --6B
		-- --------------------
		WAIT FOR 5 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("11001010"); --CA
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=205 ns
		CHECK_out1("11001100",205); --CC
		-- --------------------
		WAIT FOR 5 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("11100110"); --E6
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=215 ns
		CHECK_out1("11101000",215); --E8
		-- --------------------
		WAIT FOR 5 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 5 ns; -- Time=225 ns
		CHECK_out1("10010100",225); --94
		-- --------------------
		WAIT FOR 5 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("11100100"); --E4
		-- --------------------
		WAIT FOR 5 ns; -- Time=235 ns
		CHECK_out1("11100110",235); --E6
		-- --------------------
		WAIT FOR 5 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 5 ns; -- Time=245 ns
		CHECK_out1("00110010",245); --32
		-- --------------------
		WAIT FOR 5 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=255 ns
		CHECK_out1("00001101",255); --D
		-- --------------------
		WAIT FOR 5 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 5 ns; -- Time=265 ns
		CHECK_out1("01001101",265); --4D
		-- --------------------
		WAIT FOR 5 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 5 ns; -- Time=275 ns
		CHECK_out1("00000110",275); --6
		-- --------------------
		WAIT FOR 5 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("10001100"); --8C
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=285 ns
		CHECK_out1("10001110",285); --8E
		-- --------------------
		WAIT FOR 5 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("01110111"); --77
		-- --------------------
		WAIT FOR 5 ns; -- Time=295 ns
		CHECK_out1("01111001",295); --79
		-- --------------------
		WAIT FOR 5 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 5 ns; -- Time=305 ns
		CHECK_out1("10011100",305); --9C
		-- --------------------
		WAIT FOR 5 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 5 ns; -- Time=315 ns
		CHECK_out1("00001101",315); --D
		-- --------------------
		WAIT FOR 5 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("00011111"); --1F
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=325 ns
		CHECK_out1("00100001",325); --21
		-- --------------------
		WAIT FOR 5 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 5 ns; -- Time=335 ns
		CHECK_out1("01101011",335); --6B
		-- --------------------
		WAIT FOR 5 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("11000000"); --C0
		-- --------------------
		WAIT FOR 5 ns; -- Time=345 ns
		CHECK_out1("11000010",345); --C2
		-- --------------------
		WAIT FOR 5 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 5 ns; -- Time=355 ns
		CHECK_out1("00111011",355); --3B
		-- --------------------
		WAIT FOR 5 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 5 ns; -- Time=365 ns
		CHECK_out1("00101001",365); --29
		-- --------------------
		WAIT FOR 5 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("00100010"); --22
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=375 ns
		CHECK_out1("00100100",375); --24
		-- --------------------
		WAIT FOR 5 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 5 ns; -- Time=385 ns
		CHECK_out1("11111110",385); --FE
		-- --------------------
		WAIT FOR 5 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("11001100"); --CC
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=395 ns
		CHECK_out1("11001110",395); --CE
		-- --------------------
		WAIT FOR 5 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("11100110"); --E6
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=405 ns
		CHECK_out1("11101000",405); --E8
		-- --------------------
		WAIT FOR 5 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 5 ns; -- Time=415 ns
		CHECK_out1("11100010",415); --E2
		-- --------------------
		WAIT FOR 5 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("10001110"); --8E
		-- --------------------
		WAIT FOR 5 ns; -- Time=425 ns
		CHECK_out1("10010000",425); --90
		-- --------------------
		WAIT FOR 5 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 5 ns; -- Time=435 ns
		CHECK_out1("00001000",435); --8
		-- --------------------
		WAIT FOR 5 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("10011100"); --9C
		-- --------------------
		WAIT FOR 5 ns; -- Time=445 ns
		CHECK_out1("10011110",445); --9E
		-- --------------------
		WAIT FOR 5 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("11100101"); --E5
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=455 ns
		CHECK_out1("11100111",455); --E7
		-- --------------------
		WAIT FOR 5 ns; -- Time=460 ns
		in1 <= transport std_logic_vector'("10110111"); --B7
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=465 ns
		CHECK_out1("10111001",465); --B9
		-- --------------------
		WAIT FOR 5 ns; -- Time=470 ns
		in1 <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 5 ns; -- Time=475 ns
		CHECK_out1("00101000",475); --28
		-- --------------------
		WAIT FOR 5 ns; -- Time=480 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 5 ns; -- Time=485 ns
		CHECK_out1("10001001",485); --89
		-- --------------------
		WAIT FOR 5 ns; -- Time=490 ns
		in1 <= transport std_logic_vector'("01110000"); --70
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=495 ns
		CHECK_out1("01110010",495); --72
		-- --------------------
		WAIT FOR 5 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("10110101"); --B5
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=505 ns
		CHECK_out1("10110111",505); --B7
		-- --------------------
		WAIT FOR 5 ns; -- Time=510 ns
		in1 <= transport std_logic_vector'("01101100"); --6C
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=515 ns
		CHECK_out1("01101110",515); --6E
		-- --------------------
		WAIT FOR 5 ns; -- Time=520 ns
		in1 <= transport std_logic_vector'("11101001"); --E9
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=525 ns
		CHECK_out1("11101011",525); --EB
		-- --------------------
		WAIT FOR 5 ns; -- Time=530 ns
		in1 <= transport std_logic_vector'("11000010"); --C2
		-- --------------------
		WAIT FOR 5 ns; -- Time=535 ns
		CHECK_out1("11000100",535); --C4
		-- --------------------
		WAIT FOR 5 ns; -- Time=540 ns
		in1 <= transport std_logic_vector'("11001010"); --CA
		-- --------------------
		WAIT FOR 5 ns; -- Time=545 ns
		CHECK_out1("11001100",545); --CC
		-- --------------------
		WAIT FOR 5 ns; -- Time=550 ns
		in1 <= transport std_logic_vector'("00011001"); --19
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=555 ns
		CHECK_out1("00011011",555); --1B
		-- --------------------
		WAIT FOR 5 ns; -- Time=560 ns
		in1 <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 5 ns; -- Time=565 ns
		CHECK_out1("00000011",565); --3
		-- --------------------
		WAIT FOR 5 ns; -- Time=570 ns
		in1 <= transport std_logic_vector'("00011001"); --19
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=575 ns
		CHECK_out1("00011011",575); --1B
		-- --------------------
		WAIT FOR 5 ns; -- Time=580 ns
		in1 <= transport std_logic_vector'("00110110"); --36
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=585 ns
		CHECK_out1("00111000",585); --38
		-- --------------------
		WAIT FOR 5 ns; -- Time=590 ns
		in1 <= transport std_logic_vector'("01101011"); --6B
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=595 ns
		CHECK_out1("01101101",595); --6D
		-- --------------------
		WAIT FOR 5 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("00010000"); --10
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=605 ns
		CHECK_out1("00010010",605); --12
		-- --------------------
		WAIT FOR 5 ns; -- Time=610 ns
		in1 <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 5 ns; -- Time=615 ns
		CHECK_out1("10111001",615); --B9
		-- --------------------
		WAIT FOR 5 ns; -- Time=620 ns
		in1 <= transport std_logic_vector'("00110111"); --37
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=625 ns
		CHECK_out1("00111001",625); --39
		-- --------------------
		WAIT FOR 5 ns; -- Time=630 ns
		in1 <= transport std_logic_vector'("10100100"); --A4
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=635 ns
		CHECK_out1("10100110",635); --A6
		-- --------------------
		WAIT FOR 5 ns; -- Time=640 ns
		in1 <= transport std_logic_vector'("01010100"); --54
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=645 ns
		CHECK_out1("01010110",645); --56
		-- --------------------
		WAIT FOR 5 ns; -- Time=650 ns
		in1 <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 5 ns; -- Time=655 ns
		CHECK_out1("11011101",655); --DD
		-- --------------------
		WAIT FOR 5 ns; -- Time=660 ns
		in1 <= transport std_logic_vector'("00001111"); --F
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=665 ns
		CHECK_out1("00010001",665); --11
		-- --------------------
		WAIT FOR 5 ns; -- Time=670 ns
		in1 <= transport std_logic_vector'("00000100"); --4
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=675 ns
		CHECK_out1("00000110",675); --6
		-- --------------------
		WAIT FOR 5 ns; -- Time=680 ns
		in1 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 5 ns; -- Time=685 ns
		CHECK_out1("00010001",685); --11
		-- --------------------
		WAIT FOR 5 ns; -- Time=690 ns
		in1 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 5 ns; -- Time=695 ns
		CHECK_out1("11001000",695); --C8
		-- --------------------
		WAIT FOR 5 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 5 ns; -- Time=705 ns
		CHECK_out1("11111111",705); --FF
		-- --------------------
		WAIT FOR 5 ns; -- Time=710 ns
		in1 <= transport std_logic_vector'("11001001"); --C9
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=715 ns
		CHECK_out1("11001011",715); --CB
		-- --------------------
		WAIT FOR 5 ns; -- Time=720 ns
		in1 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 5 ns; -- Time=725 ns
		CHECK_out1("10000010",725); --82
		-- --------------------
		WAIT FOR 5 ns; -- Time=730 ns
		in1 <= transport std_logic_vector'("10110110"); --B6
		-- --------------------
		WAIT FOR 5 ns; -- Time=735 ns
		CHECK_out1("10111000",735); --B8
		-- --------------------
		WAIT FOR 5 ns; -- Time=740 ns
		in1 <= transport std_logic_vector'("01000001"); --41
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=745 ns
		CHECK_out1("01000011",745); --43
		-- --------------------
		WAIT FOR 5 ns; -- Time=750 ns
		in1 <= transport std_logic_vector'("00110101"); --35
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=755 ns
		CHECK_out1("00110111",755); --37
		-- --------------------
		WAIT FOR 5 ns; -- Time=760 ns
		in1 <= transport std_logic_vector'("11100111"); --E7
		-- --------------------
		WAIT FOR 5 ns; -- Time=765 ns
		CHECK_out1("11101001",765); --E9
		-- --------------------
		WAIT FOR 5 ns; -- Time=770 ns
		in1 <= transport std_logic_vector'("11101101"); --ED
		-- --------------------
		WAIT FOR 5 ns; -- Time=775 ns
		CHECK_out1("11101111",775); --EF
		-- --------------------
		WAIT FOR 5 ns; -- Time=780 ns
		in1 <= transport std_logic_vector'("00011011"); --1B
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=785 ns
		CHECK_out1("00011101",785); --1D
		-- --------------------
		WAIT FOR 5 ns; -- Time=790 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=795 ns
		CHECK_out1("10001001",795); --89
		-- --------------------
		WAIT FOR 5 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("10000101"); --85
		-- --------------------
		WAIT FOR 5 ns; -- Time=805 ns
		CHECK_out1("10000111",805); --87
		-- --------------------
		WAIT FOR 5 ns; -- Time=810 ns
		in1 <= transport std_logic_vector'("10101010"); --AA
		-- --------------------
		WAIT FOR 5 ns; -- Time=815 ns
		CHECK_out1("10101100",815); --AC
		-- --------------------
		WAIT FOR 5 ns; -- Time=820 ns
		in1 <= transport std_logic_vector'("11001100"); --CC
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=825 ns
		CHECK_out1("11001110",825); --CE
		-- --------------------
		WAIT FOR 5 ns; -- Time=830 ns
		in1 <= transport std_logic_vector'("11111111"); --FF
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=835 ns
		CHECK_out1("00000001",835); --1
		-- --------------------
		WAIT FOR 5 ns; -- Time=840 ns
		in1 <= transport std_logic_vector'("10011001"); --99
		-- --------------------
		WAIT FOR 5 ns; -- Time=845 ns
		CHECK_out1("10011011",845); --9B
		-- --------------------
		WAIT FOR 5 ns; -- Time=850 ns
		in1 <= transport std_logic_vector'("00101110"); --2E
		-- --------------------
		WAIT FOR 5 ns; -- Time=855 ns
		CHECK_out1("00110000",855); --30
		-- --------------------
		WAIT FOR 5 ns; -- Time=860 ns
		in1 <= transport std_logic_vector'("10010011"); --93
		-- --------------------
		WAIT FOR 5 ns; -- Time=865 ns
		CHECK_out1("10010101",865); --95
		-- --------------------
		WAIT FOR 5 ns; -- Time=870 ns
		in1 <= transport std_logic_vector'("11011110"); --DE
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=875 ns
		CHECK_out1("11100000",875); --E0
		-- --------------------
		WAIT FOR 5 ns; -- Time=880 ns
		in1 <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 5 ns; -- Time=885 ns
		CHECK_out1("01100101",885); --65
		-- --------------------
		WAIT FOR 5 ns; -- Time=890 ns
		in1 <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 5 ns; -- Time=895 ns
		CHECK_out1("10111001",895); --B9
		-- --------------------
		WAIT FOR 5 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=905 ns
		CHECK_out1("10110010",905); --B2
		-- --------------------
		WAIT FOR 5 ns; -- Time=910 ns
		in1 <= transport std_logic_vector'("01100011"); --63
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=915 ns
		CHECK_out1("01100101",915); --65
		-- --------------------
		WAIT FOR 5 ns; -- Time=920 ns
		in1 <= transport std_logic_vector'("00100011"); --23
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=925 ns
		CHECK_out1("00100101",925); --25
		-- --------------------
		WAIT FOR 5 ns; -- Time=930 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 5 ns; -- Time=935 ns
		CHECK_out1("10001001",935); --89
		-- --------------------
		WAIT FOR 5 ns; -- Time=940 ns
		in1 <= transport std_logic_vector'("01100100"); --64
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=945 ns
		CHECK_out1("01100110",945); --66
		-- --------------------
		WAIT FOR 5 ns; -- Time=950 ns
		in1 <= transport std_logic_vector'("11001110"); --CE
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=955 ns
		CHECK_out1("11010000",955); --D0
		-- --------------------
		WAIT FOR 5 ns; -- Time=960 ns
		in1 <= transport std_logic_vector'("00011010"); --1A
		sel <= transport '1';
		-- --------------------
		WAIT FOR 5 ns; -- Time=965 ns
		CHECK_out1("00011100",965); --1C
		-- --------------------
		WAIT FOR 5 ns; -- Time=970 ns
		in1 <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 5 ns; -- Time=975 ns
		CHECK_out1("11011111",975); --DF
		-- --------------------
		WAIT FOR 5 ns; -- Time=980 ns
		in1 <= transport std_logic_vector'("11101101"); --ED
		sel <= transport '0';
		-- --------------------
		WAIT FOR 5 ns; -- Time=985 ns
		CHECK_out1("11101111",985); --EF
		-- --------------------
		WAIT FOR 5 ns; -- Time=990 ns
		in1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 5 ns; -- Time=995 ns
		CHECK_out1("01100001",995); --61
		-- --------------------
		WAIT FOR 15 ns; -- Time=1010 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION as2_cfg OF as2_tb IS
	FOR testbench_arch
	END FOR;
END as2_cfg;
