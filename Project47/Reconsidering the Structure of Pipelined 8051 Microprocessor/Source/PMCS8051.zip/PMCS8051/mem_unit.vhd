library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mem_unit is
port	(	clk			: in	std_logic;
			rst  			: in 	std_logic;
         W_DPH 	 	: in 	std_logic;
         W_DPL 	 	: in 	std_logic;
         di_DPH		: in 	std_logic_vector (7 downto 0);
         di_DPL		: in 	std_logic_vector (7 downto 0);
         do_DPH		: out	std_logic_vector (7 downto 0);
         do_DPL		: out	std_logic_vector (7 downto 0);
         Din0      	: in	std_logic_vector (7 downto 0); 
         Din1      	: in  std_logic_vector (7 downto 0); 
         PC_in     	: in  std_logic_vector (15 downto 0); 
         PC_out    	: out std_logic_vector (15 downto 0); 
         en        	: in	std_logic_vector (1 downto 0); 
         r_addr1 		 : in std_logic_vector(7 downto 0);
--         r_addr2 		 : in std_logic_vector(7 downto 0);
         do_1		 	 : out std_logic_vector(7 downto 0);
--         do_2		 	 : out std_logic_vector(7 downto 0);
--			wr_bank0  	: in 	std_logic;
--			wr_bank1  	: in 	std_logic;
         w_addr0   	: in  std_logic_vector (7 downto 0); 
         w_addr1   	: in	std_logic_vector (7 downto 0); 
			sel_as	  	: in	std_logic;          
         load_in   	: in  std_logic; 
--   		sp_in     	: in 	std_logic_vector (7 downto 0);
   		sp_out    	: out	std_logic_vector (7 downto 0);
			sel_mux10 	: in	std_logic; 
         sel_mux11 	: in  std_logic_vector (1 downto 0); 
         sel_mux12 	: in  Std_logic_vector (1 downto 0); 
         sel_mux13 	: in  std_logic; 
         sel_mux14 	: in  std_logic; 
--       sel_mux15 	: in  std_logic; 
--       mux15     	: out std_logic_vector (7 downto 0); 
         W_A 	 		: in	std_logic;
         di_A		 	: in 	std_logic_vector (7 downto 0);
         do_A	 		: out std_logic_vector (7 downto 0);
         W_B 	 		: in 	std_logic;
         di_B		 	: in 	std_logic_vector (7 downto 0);
         do_B	 		: out std_logic_vector (7 downto 0);
         W_psw 	 	: in 	std_logic;
         di_psw	 	: in 	std_logic_vector (7 downto 0);
         do_psw	 	: out std_logic_vector (7 downto 0);
			Carry_in		: in	std_logic;
			OverFlow_in	: in	std_logic;
			AUX_C_in		: in	std_logic;
         R0	 	 		: out std_logic_vector (7 downto 0);
         R1	 	 		: out std_logic_vector (7 downto 0);
         load_rid		: in	std_logic;
         din_rid	 	: in 	std_logic_vector (7 downto 0);
         addr_rid	 	: in 	std_logic_vector (2 downto 0);
         load_p0   	: in  std_logic; 
			p0_in     	: in  std_logic_vector (7 downto 0);
         p0_out    	: out std_logic_vector (7 downto 0);
			port0_in		: in	std_logic_vector (7 downto 0);
			port0_out	: out	std_logic_vector (7 downto 0);
         load_p1   	: in  std_logic; 
         p1_in     	: in  std_logic_vector (7 downto 0);
         p1_out    	: out std_logic_vector (7 downto 0);
			port1_in		: in	std_logic_vector (7 downto 0);
			port1_out	: out	std_logic_vector (7 downto 0);
         load_p2   	: in  std_logic; 
         p2_in     	: in  std_logic_vector (7 downto 0);
         p2_out    	: out std_logic_vector (7 downto 0);
			port2_in		: in	std_logic_vector (7 downto 0);
			port2_out	: out	std_logic_vector (7 downto 0);
         load_p3   	: in  std_logic; 
         p3_in     	: in  std_logic_vector (7 downto 0);
         p3_out    	: out std_logic_vector (7 downto 0);
			port3_in		: in	std_logic_vector (7 downto 0);
			port3_out	: out	std_logic_vector (7 downto 0)
		);
end mem_unit;

architecture Structural of mem_unit is
   signal sdo_A       : std_logic_vector (7 downto 0);
   signal sdo_B       : std_logic_vector (7 downto 0);
   signal sdo1       : std_logic_vector (7 downto 0);
   signal sdo2       : std_logic_vector (7 downto 0);
   signal sdo_DPH       : std_logic_vector (7 downto 0);
   signal sdo_DPL       : std_logic_vector (7 downto 0);
   signal d_in0     : std_logic_vector (7 downto 0);
   signal d_in1     : std_logic_vector (7 downto 0);
   signal r_addr_b0   : std_logic_vector (7 downto 0);
   signal r_addr_b1   : std_logic_vector (7 downto 0);
   signal w_addr_b0   : std_logic_vector (7 downto 0);
   signal w_addr_b1   : std_logic_vector (7 downto 0);
   signal sp_in_S       : std_logic_vector (7 downto 0);
   signal sp_out_S       : std_logic_vector (7 downto 0);
   signal sp1       : std_logic_vector (7 downto 0);
   signal sp2       : std_logic_vector (7 downto 0);
   signal r_addr2 		 : std_logic_vector(7 downto 0);

-- 	signal p0_out    	: std_logic_vector (7 downto 0);
-- 	signal p1_out    	: std_logic_vector (7 downto 0);
-- 	signal p2_out    	: std_logic_vector (7 downto 0);
-- 	signal p3_out    	: std_logic_vector (7 downto 0);
--   signal do_DPH       : std_logic_vector (7 downto 0);
--   signal do_DPL       : std_logic_vector (7 downto 0);
   signal sdo_psw       : std_logic_vector (7 downto 0);

	component PSW_REG is
		port(	data_in  	:in		std_logic_vector(7 downto 0);
				ACC_in  		:in		std_logic_vector(7 downto 0);
				data_out		:out   	std_logic_vector(7 downto 0);
				Carry_in		:in		std_logic;
				OverFlow_in	:in		std_logic;
				AUX_C_in		:in		std_logic;
				load_in		:in		std_logic;
				reset			:in		std_logic;
				clock			:in		std_logic
			);
	end component;

	component port0 is
		port(	data_in  	:in		std_logic_vector(7 downto 0);
				data_out		:out   	std_logic_vector(7 downto 0);
				port_in		:in		std_logic_vector(7 downto 0);
				port_out		:out		std_logic_vector(7 downto 0);
				load_in		:in		std_logic;
				reset			:in		std_logic;
				clock			:in		std_logic);
			
	end component;

	component G_register is
		port(	data_in  	:in		std_logic_vector(7 downto 0);
				data_out		:out   	std_logic_vector(7 downto 0);
				load_in		:in		std_logic;
				reset			:in		std_logic;
				clock			:in		std_logic);
		end component;

	component SP_register is
		port(	data_in  	:in		std_logic_vector(7 downto 0);
				data_out		:out   	std_logic_vector(7 downto 0);
				load_in		:in		std_logic;
				reset			:in		std_logic;
				clock			:in		std_logic);
		end component;


   component as1
      port ( in1  : in    std_logic_vector (7 downto 0);
				 sel  : in	  std_logic; 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component as2
      port ( in1  : in    std_logic_vector (7 downto 0); 
				 sel  : in	  std_logic; 
            out1 : out   std_logic_vector (7 downto 0));
   end component;

	component internal_ram 
   	port(
	 		rst          : in  STD_LOGIC;
         clk          : in  STD_LOGIC;

         r_addr1 		 : in std_logic_vector(7 downto 0);
         r_addr2 		 : in std_logic_vector(7 downto 0);
         do_1		 	 : out std_logic_vector(7 downto 0);
         do_2		 	 : out std_logic_vector(7 downto 0);

--         wr_bank0 	 : in std_logic;
         w_addr_bank0 : in std_logic_vector(7 downto 0);
         di_bank0		 : in std_logic_vector(7 downto 0);

--         wr_bank1		 : in std_logic;
         w_addr_bank1 : in std_logic_vector(7 downto 0);
			di_bank1		 : in std_logic_vector(7 downto 0)
			  );
   end component;

   component latch
      port ( in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             in4  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0); 
             out2 : out   std_logic_vector (7 downto 0); 
             en   : in    std_logic_vector (1 downto 0));
   end component;
   
   component mux10131415
      port ( sel  : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component mux1112
      port ( in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
 
	COMPONENT rid
	PORT(
		data_in : IN std_logic_vector(7 downto 0);
		addr_in : IN std_logic_vector(2 downto 0);
		RS_in : IN std_logic_vector(1 downto 0);
		load_in : IN std_logic;
		rst : IN std_logic;
		clk : IN std_logic;          
		data_out1 : OUT std_logic_vector(7 downto 0);
		data_out2 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

begin
	pc_out <= sdo1 & sdo2;
	do_1 <= sdo1;
--	do_2 <= sdo2;
	do_A <= sdo_A ;
	do_B <= sdo_B ;
	do_psw <= sdo_psw;
	do_DPH <= sdo_DPH;
	do_DPl <= sdo_DPl;
	sp_out <= sp_out_S;
	r_addr2 <= r_addr1 - 1;
--	process(r_addr1,p0_out,p1_out,p2_out,p3_out,sp_out,sdo_DPL,sdo_DPH,sdo_psw,sdo_A,sdo_B,sdo1) 
--	begin
--		case r_addr1 is
--			when "10000000" => do_1 <= p0_out;  --p0
--			when "10010000" => do_1 <= p1_out;  --p1
--			when "10100000" => do_1 <= p2_out;  --p2
--			when "10110000" => do_1 <= p3_out;  --p3
--			when "10000001" => do_1 <= sp_out;  --sp
--			when "10000010" => do_1 <= sdo_DPL; --DPL
--			when "10000011" => do_1 <= sdo_DPH; --DPH
--			when "11010000" => do_1 <= sdo_psw; --psw
--			when "11100000" => do_1 <= sdo_A; 	--R_A
--			when "11110000" => do_1 <= sdo_B; 	--R_B
--			when others => do_1 <= sdo1;
--		end case;
--	end process;
--	process(r_addr2,p0_out,p1_out,p2_out,p3_out,sp_out,sdo_DPL,sdo_DPH,sdo_psw,sdo_A,sdo_B,sdo2) 
--	begin
--		case r_addr2 is
--			when "10000000" => do_2 <= p0_out;  --p0
--			when "10010000" => do_2 <= p1_out;  --p1
--			when "10100000" => do_2 <= p2_out;  --p2
--			when "10110000" => do_2 <= p3_out;  --p3
--			when "10000001" => do_2 <= sp_out;  --sp
--			when "10000010" => do_2 <= sdo_DPL; --DPL
--			when "10000011" => do_2 <= sdo_DPH; --DPH
--			when "11010000" => do_2 <= sdo_psw; --psw
--			when "11100000" => do_2 <= sdo_A; 	--R_A
--			when "11110000" => do_2 <= sdo_B; 	--R_B
--			when others => do_2 <= sdo2;
--		end case;
--	end process;

   as1_m : as1
      port map (in1(7 downto 0)=>sp_out_S(7 downto 0),
					 sel => sel_as,      
                out1(7 downto 0)=>sp1(7 downto 0));
   
   as2_m : as2
      port map (in1(7 downto 0)=>sp_out_S(7 downto 0),      
					 sel => sel_as,      
                out1(7 downto 0)=>sp2(7 downto 0));

   internal_ram_bank : internal_ram 
      port map (
	 					rst => rst,
						clk => clk,

                  r_addr1(7 downto 0)=>r_addr_b0(7 downto 0),      
                	do_1(7 downto 0)=>sdo1(7 downto 0),
                	r_addr2(7 downto 0)=>r_addr_b1(7 downto 0),      
                	do_2(7 downto 0)=>sdo2(7 downto 0),

--						wr_bank0=>wr_bank0,
				 	   di_bank0(7 downto 0)=>d_in0(7 downto 0),      
                	w_addr_bank0(7 downto 0)=>w_addr_b0(7 downto 0),      
   				 
--						wr_bank1=>wr_bank1,
					 	di_bank1(7 downto 0)=>d_in1(7 downto 0),      
                	w_addr_bank1(7 downto 0)=>w_addr_b1(7 downto 0)
						);      


   latch_m : latch
      port map (en(1 downto 0)=>en(1 downto 0),      
                in1(7 downto 0)=>PC_in(15 downto 8),      
                in2(7 downto 0)=>PC_in(7 downto 0),      
                in3(7 downto 0)=>din0(7 downto 0),      
                in4(7 downto 0)=>din1(7 downto 0),      
                out1(7 downto 0)=>d_in0(7 downto 0),      
                out2(7 downto 0)=>d_in1(7 downto 0));
   
   mux_10 : mux10131415
      port map (in1(7 downto 0)=>sp2(7 downto 0),      
                in2(7 downto 0)=>sp1(7 downto 0),      
                sel=>sel_mux10,      
                out1(7 downto 0)=>sp_in_S(7 downto 0));
   
   mux_11 : mux1112
      port map (in1(7 downto 0)=>sp1(7 downto 0),      
                in2(7 downto 0)=>sp2(7 downto 0),      
                in3(7 downto 0)=>w_addr0(7 downto 0),      
                sel(1 downto 0)=>sel_mux11(1 downto 0),      
                out1(7 downto 0)=>w_addr_b0(7 downto 0));
   
   mux_12 : mux1112
      port map (in1(7 downto 0)=>sp_out_S(7 downto 0),      
                in2(7 downto 0)=>sp1(7 downto 0),      
                in3(7 downto 0)=>r_addr1 (7 downto 0),      
                sel(1 downto 0)=>sel_mux12(1 downto 0),      
                out1(7 downto 0)=>r_addr_b0(7 downto 0));
   
   mux_13 : mux10131415
      port map (in1(7 downto 0)=>sp2(7 downto 0),      
                in2(7 downto 0)=>w_addr1(7 downto 0),      
                sel=>sel_mux13,      
                out1(7 downto 0)=>w_addr_b1(7 downto 0));
   
   mux_14 : mux10131415
      port map (in1(7 downto 0)=>sp_out_S(7 downto 0),      
                in2(7 downto 0)=>r_addr2(7 downto 0),      
                sel=>sel_mux14,      
                out1(7 downto 0)=>r_addr_b1(7 downto 0));

	R_A : G_register
		port map (data_in(7 downto 0)=>di_A,
					 data_out(7 downto 0)=>sdo_A,
					 load_in=>W_A,
					 reset=>rst,
					 clock=>clk);
   
	R_B : G_register
		port map (data_in(7 downto 0)=>di_B,
					 data_out(7 downto 0)=>sdo_B,
					 load_in=>W_B,
					 reset=>rst,
					 clock=>clk);
   
	R_DPH : G_register
		port map (data_in(7 downto 0)=>di_DPH,
					 data_out(7 downto 0)=>sdo_DPH,
					 load_in=>W_DPH,
					 reset=>rst,
					 clock=>clk);
   
	R_DPL : G_register
		port map (data_in(7 downto 0)=>di_DPL,
					 data_out(7 downto 0)=>sdo_DPL,
					 load_in=>W_DPL,
					 reset=>rst,
					 clock=>clk);
   
   
	R_SP : SP_register
		port map (data_in(7 downto 0)=>sp_in_S,
					 data_out(7 downto 0)=>sp_out_S,
					 load_in=>load_in,
					 reset=>rst,
					 clock=>clk);
   
	R_P0 : port0
		port map (port_in=>port0_in,
					 port_out=>port0_out,
					 data_in(7 downto 0)=>p0_in,
					 data_out(7 downto 0)=>p0_out,
					 load_in=>load_p0,
					 reset=>rst,
					 clock=>clk);
   
	R_P1 : port0
		port map (port_in=>port1_in,
					 port_out=>port1_out,
					 data_in(7 downto 0)=>p1_in,
					 data_out(7 downto 0)=>p1_out,
					 load_in=>load_p1,
					 reset=>rst,
					 clock=>clk);
   
	R_P2 : port0
		port map (port_in=>port2_in,
					 port_out=>port2_out,
					 data_in(7 downto 0)=>p2_in,
					 data_out(7 downto 0)=>p2_out,
					 load_in=>load_p2,
					 reset=>rst,
					 clock=>clk);
   
	R_P3 : port0 
		port map (port_in=>port3_in,
					 port_out=>port3_out,
					 data_in(7 downto 0)=>p3_in,
					 data_out(7 downto 0)=>p3_out,
					 load_in=>load_p3,
					 reset=>rst,
					 clock=>clk);
   
	PSW : PSW_REG
 		port map	(data_in(7 downto 0)=>di_psw,
					 ACC_in(7 downto 0)=>sdo_A,
					 data_out(7 downto 0)=>sdo_psw,
					 Carry_in=>Carry_in,
					 OverFlow_in=>OverFlow_in,
					 AUX_C_in=>AUX_C_in,
					 load_in=>W_psw,
					 reset=>rst,
					 clock=>clk);
  
	Inst_rid: rid PORT MAP(
		data_in => din_rid,
		addr_in => addr_rid,
		data_out1 => R0,
		data_out2 => R1,
		RS_in => sdo_psw(4 downto 3),
		load_in => load_rid,
		rst => rst,
		clk => clk 
	);
end Structural;