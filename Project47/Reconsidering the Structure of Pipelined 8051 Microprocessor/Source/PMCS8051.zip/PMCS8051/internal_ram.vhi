
-- VHDL Instantiation Created from source file internal_ram.vhd -- 00:39:54 02/14/2005
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT internal_ram
	PORT(
		rst : IN std_logic;
		clk : IN std_logic;
		r_bit_addr : IN std_logic_vector(7 downto 0);
		w_bit_addr : IN std_logic_vector(7 downto 0);
		in_bit_data : IN std_logic;
		w_bit : IN std_logic;
		p0_in : IN std_logic_vector(7 downto 0);
		p1_in : IN std_logic_vector(7 downto 0);
		p2_in : IN std_logic_vector(7 downto 0);
		p3_in : IN std_logic_vector(7 downto 0);
		wr_bank0 : IN std_logic;
		r_addr_bank0 : IN std_logic_vector(7 downto 0);
		w_addr_bank0 : IN std_logic_vector(7 downto 0);
		di_bank0 : IN std_logic_vector(7 downto 0);
		wr_bank1 : IN std_logic;
		r_addr_bank1 : IN std_logic_vector(7 downto 0);
		w_addr_bank1 : IN std_logic_vector(7 downto 0);
		di_bank1 : IN std_logic_vector(7 downto 0);          
		out_bit_data : OUT std_logic;
		p0_out : OUT std_logic_vector(7 downto 0);
		p1_out : OUT std_logic_vector(7 downto 0);
		p2_out : OUT std_logic_vector(7 downto 0);
		p3_out : OUT std_logic_vector(7 downto 0);
		do_bank0 : OUT std_logic_vector(7 downto 0);
		do_bank1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_internal_ram: internal_ram PORT MAP(
		rst => ,
		clk => ,
		r_bit_addr => ,
		w_bit_addr => ,
		in_bit_data => ,
		out_bit_data => ,
		w_bit => ,
		p0_in => ,
		p0_out => ,
		p1_in => ,
		p1_out => ,
		p2_in => ,
		p2_out => ,
		p3_in => ,
		p3_out => ,
		wr_bank0 => ,
		r_addr_bank0 => ,
		w_addr_bank0 => ,
		di_bank0 => ,
		do_bank0 => ,
		wr_bank1 => ,
		r_addr_bank1 => ,
		w_addr_bank1 => ,
		di_bank1 => ,
		do_bank1 => 
	);


