-- E:\USERS\POLARBEAR\PROJECT\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Feb 14 07:10:53 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY sign_extender_tb IS
END sign_extender_tb;

ARCHITECTURE testbench_arch OF sign_extender_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT sign_extender
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			out1 : Out  std_logic_vector (15 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out1 : std_logic_vector (15 DOWNTO 0);

BEGIN
	UUT : sign_extender
	PORT MAP (
		in1 => in1,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("11001011"); --CB
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("00011110"); --1E
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("01111000"); --78
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("10011111"); --9F
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("10000110"); --86
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("10101101"); --AD
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("10010101"); --95
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("10100010"); --A2
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("10101100"); --AC
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("11001100"); --CC
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("11010101"); --D5
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("11010111"); --D7
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("10010101"); --95
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		in1 <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		in1 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		in1 <= transport std_logic_vector'("00110110"); --36
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		in1 <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		in1 <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		in1 <= transport std_logic_vector'("11010111"); --D7
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		in1 <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		in1 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		in1 <= transport std_logic_vector'("01111011"); --7B
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		in1 <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		in1 <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		in1 <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		in1 <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		in1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		in1 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		in1 <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		in1 <= transport std_logic_vector'("01111011"); --7B
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		in1 <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		in1 <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		in1 <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		in1 <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		in1 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		in1 <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		in1 <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		in1 <= transport std_logic_vector'("11110011"); --F3
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		in1 <= transport std_logic_vector'("11100001"); --E1
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		in1 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		in1 <= transport std_logic_vector'("10000010"); --82
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		in1 <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		in1 <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		in1 <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		in1 <= transport std_logic_vector'("00110110"); --36
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		in1 <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		in1 <= transport std_logic_vector'("01101000"); --68
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		in1 <= transport std_logic_vector'("10111001"); --B9
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		in1 <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		in1 <= transport std_logic_vector'("00011110"); --1E
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		in1 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		in1 <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		in1 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		in1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		in1 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		in1 <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		in1 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		in1 <= transport std_logic_vector'("01110010"); --72
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		in1 <= transport std_logic_vector'("11100101"); --E5
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 15 ns; -- Time=1005 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION sign_extender_cfg OF sign_extender_tb IS
	FOR testbench_arch
	END FOR;
END sign_extender_cfg;
