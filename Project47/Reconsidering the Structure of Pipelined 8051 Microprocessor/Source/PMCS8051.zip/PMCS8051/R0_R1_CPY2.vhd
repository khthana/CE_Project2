library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity R0_R1_CPY2 is
    Port ( in1 : in std_logic_vector(7 downto 0);
           out1 : out std_logic_vector(7 downto 0));
end R0_R1_CPY2;

architecture RTL of R0_R1_CPY2 is

begin


end RTL;
