library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;

entity datapath is
   port ( Clock		: in	std_logic; 
          Reset		: in	std_logic; 
          int0			: in	std_logic; 
          int1			: in	std_logic; 
          rd			: in	std_logic; 
          wr			: in	std_logic;
--			 acc			: out std_logic_vector (7 downto 0); 
          
			 port0_in	: in	std_logic_vector (7 downto 0); 
          port1_in	: in	std_logic_vector (7 downto 0); 
          port2_in	: in	std_logic_vector (7 downto 0); 
          port3_in	: in	std_logic_vector (7 downto 0); 
          port0_out	: out	std_logic_vector (7 downto 0); 
          port1_out	: out	std_logic_vector (7 downto 0); 
          port2_out	: out	std_logic_vector (7 downto 0); 
          port3_out	: out	std_logic_vector (7 downto 0));
end datapath;

architecture structural of datapath is

   signal inst_b1_from_fetch   	: std_logic_vector (7 downto 0);
   signal inst_b2_from_fetch   	: std_logic_vector (7 downto 0);
   signal inst_b3_from_fetch   	: std_logic_vector (7 downto 0);
   signal iqc_from_fetch 			: std_logic_vector (1 downto 0);
   signal pc_resent_from_fetch 	: std_logic_vector (15 downto 0);
   signal addressbus_from_fetch 	: std_logic_vector (15 downto 0);

	signal s1_from_decode 		: std_logic_vector (7 downto 0);
   signal s2_from_decode 		: std_logic_vector (7 downto 0);
	signal d1_from_decode		: std_logic_vector (7 downto 0);
   signal d2_from_decode		: std_logic_vector (7 downto 0);
   signal alu_op_from_decode	: std_logic_vector (4 downto 0);
   signal r_addr0_from_decode	: std_logic_vector (7 downto 0);
   signal sel_forward_from_decode	: std_logic_vector (1 downto 0);
   signal r_aa_from_decode 	: std_logic_vector (7 downto 0);
   signal r_bb_from_decode		: std_logic_vector (7 downto 0);
   
   signal ac_out_from_execute : std_logic;
   signal ov_from_execute 		: std_logic;
   signal cy_out_from_execute : std_logic;
   signal RB_out_from_execute : std_logic_vector (7 downto 0);
   signal RA_out_from_execute : std_logic_vector (7 downto 0);
	
	signal write_data0_from_writeback:std_logic_vector (7 downto 0);
   signal write_addr0_from_writeback:std_logic_vector (7 downto 0);
   signal write_data1_from_writeback:std_logic_vector (7 downto 0);
   signal write_addr1_from_writeback:std_logic_vector (7 downto 0);
	signal W_DPH_from_writeback		:std_logic;
	signal W_DPL_from_writeback		:std_logic;
	signal di_DPH_from_writeback		:std_logic_vector(7 downto 0);
	signal di_DPL_from_writeback		:std_logic_vector(7 downto 0);
	signal W_A_from_writeback			:std_logic;
	signal di_A_from_writeback 		:std_logic_vector(7 downto 0);
--	signal sp_in_from_writeback 		:std_logic_vector(7 downto 0);
	signal W_B_from_writeback			:std_logic;
	signal di_B_from_writeback 		:std_logic_vector(7 downto 0);
	signal W_psw_from_writeback		:std_logic;
	signal di_psw_from_writeback 		:std_logic_vector(7 downto 0);
	signal load_rid_from_writeback	:std_logic;
	signal din_rid_from_writeback 	:std_logic_vector(7 downto 0);
	signal addr_rid_from_writeback 	:std_logic_vector(2 downto 0);
	signal load_p0_from_writeback		:std_logic;
	signal p0_in_from_writeback		:std_logic_vector(7 downto 0);
	signal load_p1_from_writeback		:std_logic;
	signal p1_in_from_writeback		:std_logic_vector(7 downto 0);
	signal load_p2_from_writeback		:std_logic;
	signal p2_in_from_writeback		:std_logic_vector(7 downto 0);
	signal load_p3_from_writeback		:std_logic;
	signal p3_in_from_writeback		:std_logic_vector(7 downto 0);
--	signal wbank0_from_writeback		:std_logic;
--	signal wbank1_from_writeback		:std_logic;
	
   signal r0_from_mem 		:std_logic_vector (7 downto 0);
   signal r1_from_mem 		:std_logic_vector (7 downto 0);
   signal pc_out_from_mem 	:std_logic_vector (15 downto 0);
   signal dptr_from_mem		:std_logic_vector (15 downto 0);
	signal do_DPH_from_mem	:std_logic_vector(7 downto 0);
	signal do_DPL_from_mem	:std_logic_vector(7 downto 0);
	signal d0_from_mem		:std_logic_vector(7 downto 0);
--	signal d1_from_mem		:std_logic_vector(7 downto 0);
	signal do_A_from_mem		:std_logic_vector(7 downto 0);
	signal sp_out_from_mem		:std_logic_vector(7 downto 0);
	signal do_B_from_mem		:std_logic_vector(7 downto 0);
	signal do_psw_from_mem	:std_logic_vector(7 downto 0);
	signal p0_out_from_mem	:std_logic_vector(7 downto 0);
	signal p1_out_from_mem	:std_logic_vector(7 downto 0);
	signal p2_out_from_mem	:std_logic_vector(7 downto 0);
	signal p3_out_from_mem	:std_logic_vector(7 downto 0);
	
	signal sel_mux1_from_cu : std_logic_vector (1 downto 0);
   signal sel_mux2_from_cu : std_logic;
   signal sel_mux3_from_cu : std_logic;
   signal sel_mux4_from_cu : std_logic_vector (2 downto 0);
   signal sel_mux5_from_cu : std_logic_vector (1 downto 0);
   signal sel_mux6_from_cu : std_logic_vector (1 downto 0);
--   signal sel_mux7_from_cu : std_logic_vector (2 downto 0);
   signal sel_mux8_from_cu : std_logic_vector (1 downto 0);
   signal sel_mux9_from_cu : std_logic_vector (2 downto 0);
   signal sel_mux10_from_cu : std_logic;
   signal sel_mux11_from_cu : std_logic_vector (1 downto 0);
   signal sel_mux12_from_cu : std_logic_vector (1 downto 0);
   signal sel_mux13_from_cu : std_logic;
   signal sel_mux14_from_cu : std_logic;
	signal hold_from_cu : std_logic;
	signal pc_load_in_from_cu : std_logic;
   signal sel_as_from_cu : std_logic;
	signal sel_rd_from_cu : std_logic;
   signal en_latch_from_cu : std_logic_vector (1 downto 0);
   signal sel_jcall_from_cu : std_logic_vector (1 downto 0);
   signal tmp_load_in_from_cu : std_logic;
   signal sp_load_in_from_cu : std_logic;
	signal databus_from_cu : std_logic_vector (7 downto 0);
   
   signal inst_b1_from_ifid : std_logic_vector (7 downto 0);
   signal inst_b2_from_ifid : std_logic_vector (7 downto 0);
   signal inst_b3_from_ifid : std_logic_vector (7 downto 0);

	signal s1_from_idex				: std_logic_vector (7 downto 0);
   signal s2_from_idex  			: std_logic_vector (7 downto 0);
   signal out_A_from_idex  		: std_logic_vector (7 downto 0);
   signal out_B_from_idex  		: std_logic_vector (7 downto 0);
   signal out_d1_from_idex  		: std_logic_vector (7 downto 0);
   signal out_d2_from_idex  		: std_logic_vector (7 downto 0);
   signal out_sel_mux10_from_idex: std_logic;
   signal out_sel_mux11_from_idex: std_logic_vector (1 downto 0);
   signal out_sel_mux13_from_idex: std_logic;
   signal out_sp_load_from_idex 	: std_logic;
   signal out_en_from_idex 		: std_logic_vector (1 downto 0);
   signal out_sel_from_idex 		: std_logic_vector (1 downto 0);
   signal out_opcode_from_idex 	: std_logic_vector (4 downto 0);
   
	signal RA_from_exwb  		: std_logic_vector (7 downto 0);
   signal RB_from_exwb  		: std_logic_vector (7 downto 0);
   signal d11_from_exwb  		: std_logic_vector (7 downto 0);
   signal d22_from_exwb 		: std_logic_vector (7 downto 0);
   signal en_from_exwb 			: std_logic_vector (1 downto 0);
   signal sp_load_from_exwb 	: std_logic;
   signal sel_mux10_from_exwb : std_logic;
   signal sel_mux11_from_exwb : std_logic_vector (1 downto 0);
   signal sel_mux13_from_exwb : std_logic;

   signal databus_from_rom 	: std_logic_vector (7 downto 0);
   signal databus_from_mux19 	: std_logic_vector (7 downto 0);
   component writeback
      port (
				d11 			: in 	std_logic_vector (7 downto 0);
           	d22 			: in 	std_logic_vector (7 downto 0);
          	R_A			: in	std_logic_vector (7 downto 0); 
          	R_B			: in	std_logic_vector (7 downto 0); 
         	W_DPH 		: out std_logic;
         	W_DPL 		: out std_logic;
         	di_DPH		: out std_logic_vector (7 downto 0);
         	di_DPL		: out std_logic_vector (7 downto 0);
	         w_data0		: out	std_logic_vector (7 downto 0);
           	w_addr0 		: out std_logic_vector (7 downto 0);
			 	w_data1		: out	std_logic_vector (7 downto 0);
           	w_addr1 		: out std_logic_vector (7 downto 0);
--				wr_bank0		: out	std_logic;
--				wr_bank1 	: out	std_logic;
         	W_A 	 		: out	std_logic;
         	di_A		 	: out	std_logic_vector (7 downto 0);
         	W_B 	 		: out	std_logic;
         	di_B		 	: out	std_logic_vector (7 downto 0);
         	W_psw 	 	: out	std_logic;
         	di_psw	 	: out	std_logic_vector (7 downto 0);
         	load_rid		: out	std_logic;
         	din_rid	 	: out std_logic_vector (7 downto 0);
         	addr_rid	 	: out std_logic_vector (2 downto 0);
         	load_p0   	: out std_logic; 
				p0_in     	: out std_logic_vector (7 downto 0);
         	load_p1   	: out std_logic; 
         	p1_in     	: out std_logic_vector (7 downto 0);
         	load_p2   	: out std_logic; 
         	p2_in     	: out std_logic_vector (7 downto 0);
         	load_p3   	: out std_logic; 
         	p3_in     	: out std_logic_vector (7 downto 0)); 
--				R_A				  : in	 std_logic_vector(7 downto 0); 
--         	 R_B				  : in 	 std_logic_vector(7 downto 0); 
--           d11             : in    std_logic_vector (7 downto 0); 
--            d22             : in    std_logic_vector (7 downto 0); 
--         	 w_data0         : out	 std_logic_vector(7 downto 0);
--         	 w_addr0			  : out	 std_logic_vector(7 downto 0);
--          	 w_bank0			  : out	 std_logic;
--				 w_data1			  : out	 std_logic_vector(7 downto 0);
 --         	 w_addr1			  : out	 std_logic_vector(7 downto 0));
--          	 w_bank1			  : out	 std_logic);
   end component;
   component decode
   port (--clock		: in	std_logic;
			reset		: in	std_logic; 
			inst_b1	: in	std_logic_vector (7 downto 0);
   		inst_b2	: in	std_logic_vector (7 downto 0);
			inst_b3	: in	std_logic_vector (7 downto 0);
			s1			: out	std_logic_vector (7 downto 0);
			s2			: out	std_logic_vector (7 downto 0);
			d1			: out	std_logic_vector (7 downto 0);
			d2			: out	std_logic_vector (7 downto 0);
			alu_oprt	: out	std_logic_vector (4 downto 0);
			reg_aa	: out	std_logic_vector (7 downto 0);
			reg_bb	: out	std_logic_vector (7 downto 0);
			from_acc : in	std_logic_vector (7 downto 0);
			from_b	: in	std_logic_vector (7 downto 0);
			from_mem0: in	std_logic_vector (7 downto 0);
			from_psw : in	std_logic_vector (7 downto 0);
			from_p0	: in	std_logic_vector (7 downto 0);
			from_p1	: in	std_logic_vector (7 downto 0);
			from_p2	: in	std_logic_vector (7 downto 0);
			from_p3	: in	std_logic_vector (7 downto 0);
			from_sp	: in	std_logic_vector (7 downto 0);
			from_DPH	: in	std_logic_vector (7 downto 0);
			from_DPL	: in	std_logic_vector (7 downto 0);
--			from_mem1: in	std_logic_vector (7 downto 0);
--			from_mem : in	std_logic_vector (7 downto 0);
--			from_sfr : in	std_logic_vector (7 downto 0);
			sel_mux6 : in	std_logic_vector (1 downto 0);
--			sel_mux7	: in 	std_logic_vector (2 downto 0);
			sel_mux8	: in 	std_logic_vector (1 downto 0);
			sel_mux9	: in	std_logic_vector (2 downto 0);
			bank		: in	std_logic_vector (1 downto 0);
			r_addr0	: out	std_logic_vector (7 downto 0);
			sel_forward :out	std_logic_vector (1 downto 0);
			in_r0		: in 	std_logic_vector (7 downto 0);
			in_r1		: in 	std_logic_vector (7 downto 0)
			);
   end component;
   component fetch
      port ( clock                     : in    std_logic; 
             reset                     : in    std_logic; 
             PC_load_in16              : in    std_logic; 
             temp1_load_in             : in    std_logic; 
             sel_mux2                  : in    std_logic; 
             sel_mux3                  : in    std_logic; 
             from_internal_data_memory : in    std_logic_vector (15 downto 0); 
             sel_mux1                  : in    std_logic_vector (1 downto 0); 
             sel_mux5                  : in    std_logic_vector (1 downto 0); 
             ex_byte1                  : in    std_logic_vector (2 downto 0); 
             ex_byte2                  : in    std_logic_vector (7 downto 0); 
             ex_byte3                  : in    std_logic_vector (7 downto 0); 
             sel_jcall                 : in    std_logic_vector (1 downto 0); 
             acc_in                    : in    std_logic_vector (7 downto 0); 
             DPTR_in                   : in    std_logic_vector (15 downto 0); 
             sel_mux4                  : in    std_logic_vector (2 downto 0); 
             data_bus                  : in    std_logic_vector (7 downto 0); 
             address_bus               : out   std_logic_vector (15 downto 0); 
             pc_resent                 : out   std_logic_vector (15 downto 0); 
             instruction_byte1         : out   std_logic_vector (7 downto 0); 
             instruction_byte2         : out   std_logic_vector (7 downto 0); 
             instruction_byte3         : out   std_logic_vector (7 downto 0); 
             iqc                       : out   std_logic_vector (1 downto 0));
   end component;
   component mem_unit
      port (
				clk			: in	std_logic;
				rst  			: in 	std_logic;
				W_DPH 	 	: in 	std_logic;
         	W_DPL 	 	: in 	std_logic;
         	di_DPH		: in 	std_logic_vector (7 downto 0);
	         di_DPL		: in 	std_logic_vector (7 downto 0);
	         do_DPH		: out	std_logic_vector (7 downto 0);
	         do_DPL		: out	std_logic_vector (7 downto 0);
	         Din0      	: in	std_logic_vector (7 downto 0); 
	         Din1      	: in  std_logic_vector (7 downto 0); 
	         PC_in     	: in  std_logic_vector (15 downto 0); 
	         PC_out    	: out std_logic_vector (15 downto 0); 
	         en        	: in	std_logic_vector (1 downto 0); 
	         r_addr1 		 : in std_logic_vector(7 downto 0);
--	         r_addr2 		 : in std_logic_vector(7 downto 0);
	         do_1		 	 : out std_logic_vector(7 downto 0);
--	         do_2		 	 : out std_logic_vector(7 downto 0);
--				wr_bank0  	: in 	std_logic;
--				wr_bank1  	: in 	std_logic;
	         w_addr0   	: in  std_logic_vector (7 downto 0); 
	         w_addr1   	: in	std_logic_vector (7 downto 0); 
				sel_as	  	: in	std_logic;          
 --  			sp_in     	: in 	std_logic_vector (7 downto 0);
   			sp_out    	: out	std_logic_vector (7 downto 0);
	         load_in   	: in  std_logic; 
				sel_mux10 	: in	std_logic; 
	         sel_mux11 	: in  std_logic_vector (1 downto 0); 
	         sel_mux12 	: in  Std_logic_vector (1 downto 0); 
	         sel_mux13 	: in  std_logic; 
	         sel_mux14 	: in  std_logic; 
--       sel_mux15 	: in  std_logic; 
--       mux15     	: out std_logic_vector (7 downto 0); 
	         W_A 	 		: in	std_logic;
	         di_A		 	: in 	std_logic_vector (7 downto 0);
	         do_A	 		: out std_logic_vector (7 downto 0);
	         W_B 	 		: in 	std_logic;
	         di_B		 	: in 	std_logic_vector (7 downto 0);
	         do_B	 		: out std_logic_vector (7 downto 0);
	         W_psw 	 	: in 	std_logic;
	         di_psw	 	: in 	std_logic_vector (7 downto 0);
	         do_psw	 	: out std_logic_vector (7 downto 0);
				Carry_in		: in	std_logic;
				OverFlow_in	: in	std_logic;
				AUX_C_in		: in	std_logic;
	         R0	 	 		: out std_logic_vector (7 downto 0);
				R1	 	 		: out std_logic_vector (7 downto 0);
	         load_rid		: in	std_logic;
	         din_rid	 	: in 	std_logic_vector (7 downto 0);
	         addr_rid	 	: in 	std_logic_vector (2 downto 0);
	         load_p0   	: in  std_logic; 
				p0_in     	: in  std_logic_vector (7 downto 0);
	         p0_out    	: out std_logic_vector (7 downto 0);
				port0_in		: in	std_logic_vector (7 downto 0);
				port0_out	: out	std_logic_vector (7 downto 0);
	         load_p1   	: in  std_logic; 
	         p1_in     	: in  std_logic_vector (7 downto 0);
	         p1_out    	: out std_logic_vector (7 downto 0);
				port1_in		: in	std_logic_vector (7 downto 0);
				port1_out	: out	std_logic_vector (7 downto 0);
	         load_p2   	: in  std_logic; 
	         p2_in     	: in  std_logic_vector (7 downto 0);
	         p2_out    	: out std_logic_vector (7 downto 0);
				port2_in		: in	std_logic_vector (7 downto 0);
				port2_out	: out	std_logic_vector (7 downto 0);
	         load_p3   	: in  std_logic; 
	         p3_in     	: in  std_logic_vector (7 downto 0);
	         p3_out    	: out std_logic_vector (7 downto 0);
				port3_in		: in	std_logic_vector (7 downto 0);
				port3_out	: out	std_logic_vector (7 downto 0));
   end component;
   component exwb
      port ( clk              : in    std_logic; 
             rst              : in    std_logic; 
--             in_w_A           : in    std_logic; 
--             in_w_B           : in    std_logic; 
             in_sel_mux10     : in    std_logic; 
             in_sp_load       : in    std_logic; 
--             in_sel_mux18     : in    std_logic; 
--             in_sel_addr_dec  : in    std_logic; 
             in_sel_mux13     : in    std_logic; 
--             in_wbank0        : in    std_logic; 
--             in_wbank1        : in    std_logic; 
             in_D11           : in    std_logic_vector (7 downto 0); 
             in_D22           : in    std_logic_vector (7 downto 0); 
             in_R_A           : in    std_logic_vector (7 downto 0); 
             in_R_B           : in    std_logic_vector (7 downto 0); 
             in_sel_mux11     : in    std_logic_vector (1 downto 0); 
--             out_w_A          : out   std_logic; 
--             out_w_B          : out   std_logic; 
             out_sel_mux10    : out   std_logic; 
             out_sp_load      : out   std_logic; 
--             out_sel_mux18    : out   std_logic; 
--             out_sel_addr_dec : out   std_logic; 
             out_sel_mux13    : out   std_logic; 
--             out_wbank0       : out   std_logic; 
--             out_wbank1       : out   std_logic; 
             out_D11          : out   std_logic_vector (7 downto 0); 
             out_D22          : out   std_logic_vector (7 downto 0); 
             out_R_A          : out   std_logic_vector (7 downto 0); 
             out_R_B          : out   std_logic_vector (7 downto 0); 
             out_sel_mux11    : out   std_logic_vector (1 downto 0); 
             in_en            : in    std_logic_vector (1 downto 0); 
             out_en           : out   std_logic_vector (1 downto 0));
   end component;
   component execute
      port ( rst       : in    std_logic; 
             ac_in     : in    std_logic; 
             cy_in     : in    std_logic; 
             AA        : in    std_logic_vector (7 downto 0); 
             BB        : in    std_logic_vector (7 downto 0); 
             D1        : in    std_logic_vector (7 downto 0); 
             D2        : in    std_logic_vector (7 downto 0); 
             OPCode    : in    std_logic_vector (4 downto 0); 
             s1        : in    std_logic_vector (7 downto 0); 
             s2        : in    std_logic_vector (7 downto 0); 
--             sel_mux16 : in    std_logic_vector (1 downto 0); 
--             sel_mux17 : in    std_logic_vector (1 downto 0); 
             sel       : in    std_logic_vector (1 downto 0); 
             RA_in     : in    std_logic_vector (7 downto 0); 
             RB_in     : in    std_logic_vector (7 downto 0); 
             ac_out    : out   std_logic; 
             cy_out    : out   std_logic; 
             ov        : out   std_logic; 
             RA_out    : out   std_logic_vector (7 downto 0); 
             RB_out    : out   std_logic_vector (7 downto 0));
   end component;
   component ifid
      port ( clk  : in    std_logic; 
             rst  : in    std_logic; 
             hold : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0); 
             out2 : out   std_logic_vector (7 downto 0); 
             out3 : out   std_logic_vector (7 downto 0));
   end component;
   component idex
      port ( clk              : in    std_logic; 
             rst              : in    std_logic; 
--             in_w_A           : in    std_logic; 
--             in_w_B           : in    std_logic; 
             in_sel_mux10     : in    std_logic; 
             in_sp_load       : in    std_logic; 
--             in_sel_mux18     : in    std_logic; 
--             in_sel_addr_dec  : in    std_logic; 
             in_sel_mux13     : in    std_logic; 
--             in_wbank0        : in    std_logic; 
--             in_wbank1        : in    std_logic; 
             in_s1            : in    std_logic_vector (7 downto 0); 
             in_s2            : in    std_logic_vector (7 downto 0); 
             in_d1            : in    std_logic_vector (7 downto 0); 
             in_d2            : in    std_logic_vector (7 downto 0); 
             in_A             : in    std_logic_vector (7 downto 0); 
             in_B             : in    std_logic_vector (7 downto 0); 
             in_Opcode        : in    std_logic_vector (4 downto 0); 
             in_sel           : in    std_logic_vector (1 downto 0); 
--             in_sel_mux16     : in    std_logic_vector (1 downto 0); 
--             in_sel_mux17     : in    std_logic_vector (1 downto 0); 
             in_sel_mux11     : in    std_logic_vector (1 downto 0); 
             in_en            : in    std_logic_vector (1 downto 0); 
--             out_w_A          : out   std_logic; 
--             out_w_B          : out   std_logic; 
             out_sel_mux10    : out   std_logic; 
             out_sp_load      : out   std_logic; 
--             out_sel_mux18    : out   std_logic; 
--             out_sel_addr_dec : out   std_logic; 
             out_sel_mux13    : out   std_logic; 
--             out_wbank0       : out   std_logic; 
--             out_wbank1       : out   std_logic; 
             out_s1           : out   std_logic_vector (7 downto 0); 
             out_s2           : out   std_logic_vector (7 downto 0); 
             out_d1           : out   std_logic_vector (7 downto 0); 
             out_d2           : out   std_logic_vector (7 downto 0); 
             out_A            : out   std_logic_vector (7 downto 0); 
             out_B            : out   std_logic_vector (7 downto 0); 
             out_Opcode       : out   std_logic_vector (4 downto 0); 
             out_sel          : out   std_logic_vector (1 downto 0); 
--             out_sel_mux16    : out   std_logic_vector (1 downto 0); 
--             out_sel_mux17    : out   std_logic_vector (1 downto 0); 
             out_sel_mux11    : out   std_logic_vector (1 downto 0); 
             out_en           : out   std_logic_vector (1 downto 0));
   end component;
   component i8051rom
      port ( rst         : in    std_logic; 
             clk         : in    std_logic; 
             RD          : in    std_logic; 
             ADDRESS_BUS : in    std_logic_vector (15 downto 0); 
             DATA_BUS    : out   std_logic_vector (7 downto 0));
   end component;
   component control_unit
      port ( clk         : in    std_logic; 
             rst         : in    std_logic; 
--             ac_in       : in    std_logic; 
--             cy_in       : in    std_logic; 
             int0        : in    std_logic; 
             int1        : in    std_logic; 
--             ov          : in    std_logic; 
             wr          : in    std_logic; 
             rd          : in    std_logic; 
             byte1       : in    std_logic_vector (7 downto 0); 
             byte2       : in    std_logic_vector (7 downto 0); 
             byte3       : in    std_logic_vector (7 downto 0); 
--             psw_in      : in    std_logic_vector (7 downto 0); 
--             Acc_in      : in    std_logic_vector (7 downto 0); 
--             ac_out      : out   std_logic; 
--             cy_out      : out   std_logic;
--				 ov_out		 :	out	std_logic; 
             sel_mux2    : out   std_logic; 
             sel_mux3    : out   std_logic; 
             sel_mux10   : out   std_logic; 
             sel_mux13   : out   std_logic; 
             sel_mux14   : out   std_logic; 
--             sel_mux15   : out   std_logic; 
--             sel_mux18   : out   std_logic; 
--             sel_addr_de : out   std_logic; 
             sel_rd      : out   std_logic; 
             sel_as      : out   std_logic; 
--             w_psw       : out   std_logic; 
--             w_A         : out   std_logic; 
--             w_B         : out   std_logic; 
--             wbank0      : out   std_logic; 
--             wbank1      : out   std_logic; 
             hold        : out   std_logic; 
             PC_load_in  : out   std_logic; 
             tmp_load_in : out   std_logic; 
             sp_load_in  : out   std_logic; 
             sel_mux1    : out   std_logic_vector (1 downto 0); 
             sel_mux4    : out   std_logic_vector (2 downto 0); 
             sel_mux5    : out   std_logic_vector (1 downto 0); 
             sel_mux6    : out   std_logic_vector (1 downto 0); 
--             sel_mux7    : out   std_logic_vector (2 downto 0); 
             sel_mux8    : out   std_logic_vector (1 downto 0); 
             sel_mux9    : out   std_logic_vector (2 downto 0); 
             sel_mux11   : out   std_logic_vector (1 downto 0); 
             sel_mux12   : out   std_logic_vector (1 downto 0); 
--             sel_mux16   : out   std_logic_vector (1 downto 0); 
--             sel_mux17   : out   std_logic_vector (1 downto 0); 
--             sel_forward : out   std_logic_vector (3 downto 0); 
             sel_jcall   : out   std_logic_vector (1 downto 0); 
--             sel_bank    : out   std_logic_vector (1 downto 0); 
             EN_latch    : out   std_logic_vector (1 downto 0); 
--             psw_out     : out   std_logic_vector (7 downto 0); 
             data_bus    : out   std_logic_vector (7 downto 0); 
             iqc         : in    std_logic_vector (1 downto 0));
   end component;
   component mux19
      port ( sel  : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;

begin	
	dptr_from_mem <= do_DPH_from_mem(7 downto 0) & do_DPL_from_mem(7 downto 0);
--   acc <= do_A_from_mem(7 downto 0);


	wb_stage : writeback
      port map (
					 d11(7 downto 0)=>d11_from_exwb(7 downto 0),      
                d22(7 downto 0)=>d22_from_exwb(7 downto 0),      
                R_A(7 downto 0)=>RA_from_exwb(7 downto 0),      
                R_B(7 downto 0)=>RB_from_exwb(7 downto 0),      
					 W_DPH => W_DPH_from_writeback,
					 W_DPL => W_DPL_from_writeback,
					 di_DPH(7 downto 0) => di_DPH_from_writeback(7 downto 0),
					 di_DPL(7 downto 0) => di_DPL_from_writeback(7 downto 0),
					 w_addr0(7 downto 0)=>write_addr0_from_writeback(7 downto 0),      
                w_data0(7 downto 0)=>write_data0_from_writeback(7 downto 0),
                w_addr1(7 downto 0)=>write_addr1_from_writeback(7 downto 0),      
                w_data1(7 downto 0)=>write_data1_from_writeback(7 downto 0),
--					 wr_bank0 => wbank0_from_writeback,
--					 wr_bank1 => wbank1_from_writeback,
					 W_A => W_A_from_writeback,
   				 di_A(7 downto 0) => di_A_from_writeback (7 downto 0),
					 W_B => W_B_from_writeback,
					 di_B(7 downto 0) =>	di_B_from_writeback (7 downto 0),
					 W_psw => W_psw_from_writeback,
					 di_psw(7 downto 0) => di_psw_from_writeback (7 downto 0),
					 load_rid => load_rid_from_writeback,
					 din_rid(7 downto 0) =>	din_rid_from_writeback (7 downto 0),
					 addr_rid(2 downto 0) => addr_rid_from_writeback (2 downto 0),
					 load_p0 => load_p0_from_writeback,
					 p0_in(7 downto 0) => p0_in_from_writeback(7 downto 0),
					 load_p1 => load_p1_from_writeback,
					 p1_in(7 downto 0) => p1_in_from_writeback(7 downto 0),
					 load_p2 => load_p2_from_writeback,
					 p2_in(7 downto 0) => p2_in_from_writeback(7 downto 0),
					 load_p3 => load_p3_from_writeback,
					 p3_in(7 downto 0) => p3_in_from_writeback(7 downto 0)
					 );

	dec_stage : decode
      port map (bank(1 downto 0)=>do_psw_from_mem(4 downto 3),      
                from_acc(7 downto 0)=>do_A_from_mem(7 downto 0),      
                from_b(7 downto 0)=>do_B_from_mem(7 downto 0),      
                from_mem0(7 downto 0)=>d0_from_mem(7 downto 0),      
					 from_psw(7 downto 0)=>do_psw_from_mem(7 downto 0),
					 from_p0(7 downto 0)=>p0_out_from_mem(7 downto 0),
					 from_p1(7 downto 0)=>p1_out_from_mem(7 downto 0),
					 from_p2(7 downto 0)=>p2_out_from_mem(7 downto 0),
					 from_p3(7 downto 0)=>p3_out_from_mem(7 downto 0),
					 from_sp(7 downto 0)=>sp_out_from_mem(7 downto 0),
					 from_DPH(7 downto 0)=>do_DPH_from_mem(7 downto 0),
					 from_DPL(7 downto 0)=>do_DPL_from_mem(7 downto 0),
--                from_mem1(7 downto 0)=>d1_from_mem(7 downto 0),      
                inst_b1(7 downto 0)=>inst_b1_from_ifid(7 downto 0),      
                inst_b2(7 downto 0)=>inst_b2_from_ifid(7 downto 0),      
                inst_b3(7 downto 0)=>inst_b3_from_ifid(7 downto 0),      
                in_r0(7 downto 0)=>r0_from_mem(7 downto 0),      
                in_r1(7 downto 0)=>r1_from_mem(7 downto 0),      
                reset=>Reset,      
                sel_mux6(1 downto 0)=>sel_mux6_from_cu(1 downto 0),      
--                sel_mux7(2 downto 0)=>sel_mux7_from_cu(2 downto 0),      
                sel_mux8(1 downto 0)=>sel_mux8_from_cu(1 downto 0),      
                sel_mux9(2 downto 0)=>sel_mux9_from_cu(2 downto 0),      
                alu_oprt(4 downto 0)=>alu_op_from_decode(4 downto 0),      
                d1(7 downto 0)=>d1_from_decode(7 downto 0),      
                d2(7 downto 0)=>d2_from_decode(7 downto 0),      
                reg_aa(7 downto 0)=>r_aa_from_decode(7 downto 0),      
                reg_bb(7 downto 0)=>r_bb_from_decode(7 downto 0),      
                r_addr0(7 downto 0)=>r_addr0_from_decode(7 downto 0),      
                sel_forward(1 downto 0)=>sel_forward_from_decode(1 downto 0),      
                s1(7 downto 0)=>s1_from_decode(7 downto 0),      
                s2(7 downto 0)=>s2_from_decode(7 downto 0));
					    
   fet_stage : fetch
      port map (acc_in(7 downto 0)=>do_A_from_mem(7 downto 0),      
                clock=>Clock,      
                data_bus(7 downto 0)=>databus_from_mux19(7 downto 0),      
                DPTR_in(15 downto 0)=>dptr_from_mem,     
                ex_byte1(2 downto 0)=>inst_b1_from_ifid(7 downto 5),      
                ex_byte2(7 downto 0)=>inst_b2_from_ifid(7 downto 0),      
                ex_byte3(7 downto 0)=>inst_b3_from_ifid(7 downto 0),      
                from_internal_data_memory(15 downto 0)=>pc_out_from_mem(15 downto 0),      
                PC_load_in16=>pc_load_in_from_cu,      
                reset=>Reset,      
                sel_jcall(1 downto 0)=>sel_jcall_from_cu(1 downto 0),      
                sel_mux1(1 downto 0)=>sel_mux1_from_cu(1 downto 0),      
                sel_mux2=>sel_mux2_from_cu,      
                sel_mux3=>sel_mux3_from_cu,      
                sel_mux4(2 downto 0)=>sel_mux4_from_cu(2 downto 0),      
                sel_mux5(1 downto 0)=>sel_mux5_from_cu(1 downto 0),      
                temp1_load_in=>tmp_load_in_from_cu,      
                address_bus(15 downto 0)=>addressbus_from_fetch(15 downto 0),      
                instruction_byte1(7 downto 0)=>inst_b1_from_fetch(7 downto 0),      
                instruction_byte2(7 downto 0)=>inst_b2_from_fetch(7 downto 0),      
                instruction_byte3(7 downto 0)=>inst_b3_from_fetch(7 downto 0),      
                iqc(1 downto 0)=>iqc_from_fetch(1 downto 0),      
                pc_resent(15 downto 0)=>pc_resent_from_fetch(15 downto 0));
   
   mem : mem_unit
      port map (
					 clk=>Clock,      
                rst=>Reset,      
                W_DPH => W_DPH_from_writeback,
					 W_DPL => W_DPL_from_writeback,
					 di_DPH(7 downto 0) => di_DPH_from_writeback(7 downto 0),
					 di_DPL(7 downto 0) => di_DPL_from_writeback(7 downto 0),
					 do_DPH(7 downto 0) => do_DPH_from_mem(7 downto 0),
					 do_DPL(7 downto 0) => do_DPL_from_mem(7 downto 0),
					 Din0(7 downto 0)=>write_data0_from_writeback(7 downto 0),      
                Din1(7 downto 0)=>write_data1_from_writeback(7 downto 0),      
					 PC_in(15 downto 0)=>pc_resent_from_fetch(15 downto 0),
					 PC_out(15 downto 0)=>pc_out_from_mem(15 downto 0),
					 en(1 downto 0)=>en_from_exwb(1 downto 0),
					 r_addr1(7 downto 0)=>r_addr0_from_decode(7 downto 0),
--					 r_addr2(7 downto 0)=>r_addr1_from_decode(7 downto 0),
					 do_1(7 downto 0)=>d0_from_mem(7 downto 0),
--					 do_2(7 downto 0)=>d1_from_mem(7 downto 0),
--					 wr_bank0 => wbank0_from_writeback,
--					 wr_bank1 => wbank1_from_writeback,
					 w_addr0 => write_addr0_from_writeback(7 downto 0),
					 w_addr1 => write_addr1_from_writeback(7 downto 0),
	             sel_as=>sel_as_from_cu,
					 load_in =>sp_load_from_exwb,
--                sp_in(7 downto 0) => sp_in_from_writeback(7 downto 0),
   				 sp_out(7 downto 0) => sp_out_from_mem(7 downto 0),
					 sel_mux10=>sel_mux10_from_exwb,      
                sel_mux11(1 downto 0)=>sel_mux11_from_exwb(1 downto 0),      
                sel_mux12(1 downto 0)=>sel_mux12_from_cu(1 downto 0),      
                sel_mux13=>sel_mux13_from_exwb,      
					 sel_mux14=>sel_mux14_from_cu,
					 W_A => W_A_from_writeback,
					 di_A(7 downto 0) => di_A_from_writeback(7 downto 0),
					 do_A(7 downto 0)	=> do_A_from_mem(7 downto 0),
					 W_B => W_B_from_writeback,
					 di_B(7 downto 0) => di_B_from_writeback(7 downto 0),
					 do_B(7 downto 0)	=> do_B_from_mem(7 downto 0),
					 W_psw => W_psw_from_writeback,
					 di_psw(7 downto 0) => di_psw_from_writeback(7 downto 0),
					 do_psw(7 downto 0)	=> do_psw_from_mem(7 downto 0),
					 Carry_in => cy_out_from_execute,
					 OverFlow_in => ov_from_execute,
					 AUX_C_in => ac_out_from_execute,
					 R0(7 downto 0)=>r0_from_mem(7 downto 0),
					 R1(7 downto 0)=>r1_from_mem(7 downto 0),
					 load_rid => load_rid_from_writeback,
					 din_rid(7 downto 0) =>	din_rid_from_writeback (7 downto 0),
					 addr_rid(2 downto 0) => addr_rid_from_writeback (2 downto 0),
					 load_p0 => load_p0_from_writeback,
					 p0_in(7 downto 0) => p0_in_from_writeback(7 downto 0),
					 p0_out(7 downto 0) => p0_out_from_mem(7 downto 0),
					 port0_in(7 downto 0) => port0_in(7 downto 0),
					 port0_out(7 downto 0) => port0_out(7 downto 0),
					 load_p1 => load_p1_from_writeback,
					 p1_in(7 downto 0) => p1_in_from_writeback(7 downto 0),
					 p1_out(7 downto 0) => p1_out_from_mem(7 downto 0),
					 port1_in(7 downto 0) => port1_in(7 downto 0),
					 port1_out(7 downto 0) => port1_out(7 downto 0),
					 load_p2 => load_p2_from_writeback,
					 p2_in(7 downto 0) => p2_in_from_writeback(7 downto 0),
					 p2_out(7 downto 0) => p2_out_from_mem(7 downto 0),
					 port2_in(7 downto 0) => port2_in(7 downto 0),
					 port2_out(7 downto 0) => port2_out(7 downto 0),
 					 load_p3 => load_p3_from_writeback,
					 p3_in(7 downto 0) => p3_in_from_writeback(7 downto 0),
					 p3_out(7 downto 0) => p3_out_from_mem(7 downto 0),
					 port3_in(7 downto 0) => port3_in(7 downto 0),
					 port3_out(7 downto 0) => port3_out(7 downto 0)
					 );
   
   exwb_buff : exwb
      port map (clk=>Clock,      
                in_D11(7 downto 0)=>out_d1_from_idex(7 downto 0),      
                in_D22(7 downto 0)=>out_d2_from_idex(7 downto 0),      
                in_en(1 downto 0)=>out_en_from_idex(1 downto 0),      
                in_R_A(7 downto 0)=>RA_out_from_execute(7 downto 0),      
                in_R_B(7 downto 0)=>RB_out_from_execute(7 downto 0),      
--                in_sel_addr_dec=>XLXN_472,      
                in_sel_mux11(1 downto 0)=>out_sel_mux11_from_idex(1 downto 0),      
                in_sel_mux13=>out_sel_mux13_from_idex,      
--                in_sel_mux18=>XLXN_473,      
                in_sel_mux10=>out_sel_mux10_from_idex,      
                in_sp_load=>out_sp_load_from_idex,      
--                in_wbank0=>out_wbank0_from_idex,      
--                in_wbank1=>out_wbank1_from_idex,      
--                in_w_A=>XLXN_560,      
--                in_w_B=>XLXN_559,      
                rst=>Reset,      
                out_D11(7 downto 0)=>d11_from_exwb(7 downto 0),      
                out_D22(7 downto 0)=>d22_from_exwb(7 downto 0),      
                out_en(1 downto 0)=>en_from_exwb(1 downto 0),      
                out_R_A(7 downto 0)=>RA_from_exwb(7 downto 0),      
                out_R_B(7 downto 0)=>RB_from_exwb(7 downto 0),      
--                out_sel_addr_dec=>XLXN_482,      
                out_sel_mux11(1 downto 0)=>sel_mux11_from_exwb(1 downto 0),      
                out_sel_mux13=>sel_mux13_from_exwb,      
--                out_sel_mux18=>XLXN_483,      
                out_sel_mux10=>sel_mux10_from_exwb,      
                out_sp_load=>sp_load_from_exwb);      
--                out_wbank0=>wbank0_from_exwb,      
--                out_wbank1=>wbank1_from_exwb);      
--                out_w_A=>XLXN_611,      
--                out_w_B=>XLXN_610
						
   
   exe_stage : execute
      port map (AA(7 downto 0)=>out_A_from_idex(7 downto 0),      
                ac_in=>do_psw_from_mem(6),      
                BB(7 downto 0)=>out_B_from_idex(7 downto 0),      
                cy_in=>do_psw_from_mem(7),      
                D1(7 downto 0)=>d11_from_exwb(7 downto 0),      
                D2(7 downto 0)=>d22_from_exwb(7 downto 0),      
                OPCode(4 downto 0)=>out_opcode_from_idex(4 downto 0),      
                RA_in(7 downto 0)=>RA_from_exwb(7 downto 0),      
                RB_in(7 downto 0)=>RB_from_exwb(7 downto 0),      
                rst=>Reset,      
                sel(1 downto 0)=>out_sel_from_idex(1 downto 0),      
--                sel_mux16(1 downto 0)=>out_sel_mux16_from_idex(1 downto 0),      
--                sel_mux17(1 downto 0)=>out_sel_mux17_from_idex(1 downto 0),      
                s1(7 downto 0)=>s1_from_idex(7 downto 0),      
                s2(7 downto 0)=>s2_from_idex(7 downto 0),      
                ac_out=>ac_out_from_execute,      
                cy_out=>cy_out_from_execute,      
                ov=>ov_from_execute,      
                RA_out(7 downto 0)=>RA_out_from_execute(7 downto 0),      
                RB_out(7 downto 0)=>RB_out_from_execute(7 downto 0));
   
   ifid_buff : ifid
      port map (clk=>Clock,      
                hold=>hold_from_cu,      
                in1(7 downto 0)=>inst_b1_from_fetch(7 downto 0),      
                in2(7 downto 0)=>inst_b2_from_fetch(7 downto 0),      
                in3(7 downto 0)=>inst_b3_from_fetch(7 downto 0),      
                rst=>Reset,      
                out1(7 downto 0)=>inst_b1_from_ifid(7 downto 0),      
                out2(7 downto 0)=>inst_b2_from_ifid(7 downto 0),      
                out3(7 downto 0)=>inst_b3_from_ifid(7 downto 0));
   
   idex_buff : idex
      port map (clk=>Clock,      
                in_A(7 downto 0)=>r_aa_from_decode(7 downto 0),      
                in_B(7 downto 0)=>r_bb_from_decode(7 downto 0),      
                in_d1(7 downto 0)=>d1_from_decode(7 downto 0),      
                in_d2(7 downto 0)=>d2_from_decode(7 downto 0),      
                in_en(1 downto 0)=>en_latch_from_cu(1 downto 0),      
                in_Opcode(4 downto 0)=>alu_op_from_decode(4 downto 0),      
                in_sel(1 downto 0)=>sel_forward_from_decode(1 downto 0),      
--                in_sel_addr_dec=>XLXN_490,      
                in_sel_mux11(1 downto 0)=>sel_mux11_from_cu(1 downto 0),      
                in_sel_mux13=>sel_mux13_from_cu,      
--                in_sel_mux16(1 downto 0)=>sel_mux16_from_cu(1 downto 0),      
--                in_sel_mux17(1 downto 0)=>sel_mux17_from_cu(1 downto 0),      
--                in_sel_mux18=>XLXN_491,      
                in_sel_mux10=>sel_mux10_from_cu,      
                in_sp_load=>sp_load_in_from_cu,      
                in_s1(7 downto 0)=>s1_from_decode(7 downto 0),      
                in_s2(7 downto 0)=>s2_from_decode(7 downto 0),      
  --              in_wbank0=>wbank0_from_cu,      
--                in_wbank1=>wbank1_from_cu,      
--                in_w_A=>XLXN_548,      
--                in_w_B=>XLXN_550,      
                rst=>Reset,      
                out_A(7 downto 0)=>out_A_from_idex(7 downto 0),      
                out_B(7 downto 0)=>out_B_from_idex(7 downto 0),      
                out_d1(7 downto 0)=>out_d1_from_idex(7 downto 0),      
                out_d2(7 downto 0)=>out_d2_from_idex(7 downto 0),      
                out_en(1 downto 0)=>out_en_from_idex(1 downto 0),      
                out_Opcode(4 downto 0)=>out_opcode_from_idex(4 downto 0),      
                out_sel(1 downto 0)=>out_sel_from_idex(1 downto 0),      
--                out_sel_addr_dec=>XLXN_472,      
                out_sel_mux11(1 downto 0)=>out_sel_mux11_from_idex(1 downto 0),      
                out_sel_mux13=>out_sel_mux13_from_idex,      
--                out_sel_mux16(1 downto 0)=>out_sel_mux16_from_idex(1 downto 0),      
--                out_sel_mux17(1 downto 0)=>out_sel_mux17_from_idex(1 downto 0),      
--                out_sel_mux18=>XLXN_473,      
                out_sel_mux10=>out_sel_mux10_from_idex,      
                out_sp_load=>out_sp_load_from_idex,      
                out_s1(7 downto 0)=>s1_from_idex(7 downto 0),      
                out_s2(7 downto 0)=>s2_from_idex(7 downto 0));      
--                out_wbank0=>out_wbank0_from_idex,      
--                out_wbank1=>out_wbank1_from_idex);      
--                out_w_A=>XLXN_560,      
--                out_w_B=>XLXN_559);
   
   rom : i8051rom
      port map (ADDRESS_BUS(15 downto 0)=>addressbus_from_fetch(15 downto 0),      
                clk=>Clock,      
                RD=>sel_rd_from_cu,      
                rst=>Reset,      
                DATA_BUS(7 downto 0)=>databus_from_rom(7 downto 0));
   
   cu : control_unit
      port map (--ac_in=>ac_out_from_execute,      
                byte1(7 downto 0)=>inst_b1_from_ifid(7 downto 0),      
                byte2(7 downto 0)=>inst_b2_from_ifid(7 downto 0),      
                byte3(7 downto 0)=>inst_b3_from_ifid(7 downto 0),      
                clk=>Clock,      
                --cy_in=>cy_out_from_execute,      
                int0=>int0,      
                int1=>int1,      
                iqc(1 downto 0)=>iqc_from_fetch(1 downto 0),      
--                ov=>ov_from_execute,      
                --psw_in(7 downto 0)=>psw_from_mem(7 downto 0),      
					 --Acc_in(7 downto 0)=>acc_from_mem(7 downto 0),
                rd=>rd,      
                rst=>Reset,      
                wr=>wr,
--					 ov_out=>ov_from_cu,      
--                ac_out=>ac_from_cu,      
--                cy_out=>cy_from_ex,      
                data_bus(7 downto 0)=>databus_from_cu(7 downto 0),      
                EN_latch(1 downto 0)=>en_latch_from_cu(1 downto 0),      
                hold=>hold_from_cu,      
                PC_load_in=>pc_load_in_from_cu,      
                --psw_out(7 downto 0)=>psw_from_cu(7 downto 0),      
--                sel_addr_de=>XLXN_490,      
                sel_as=>sel_as_from_cu,      
--                sel_bank(1 downto 0)=>bank_from_cu(1 downto 0),      
--                sel_forward(3 downto 0)=>sel_forward_from_cu(3 downto 0),      
                sel_jcall(1 downto 0)=>sel_jcall_from_cu(1 downto 0),      
                sel_mux1(1 downto 0)=>sel_mux1_from_cu(1 downto 0),      
                sel_mux2=>sel_mux2_from_cu,      
                sel_mux3=>sel_mux3_from_cu,      
                sel_mux4(2 downto 0)=>sel_mux4_from_cu(2 downto 0),      
                sel_mux5(1 downto 0)=>sel_mux5_from_cu(1 downto 0),      
                sel_mux6(1 downto 0)=>sel_mux6_from_cu(1 downto 0),      
--                sel_mux7(2 downto 0)=>sel_mux7_from_cu(2 downto 0),      
                sel_mux8(1 downto 0)=>sel_mux8_from_cu(1 downto 0),      
                sel_mux9(2 downto 0)=>sel_mux9_from_cu(2 downto 0),      
                sel_mux10=>sel_mux10_from_cu,      
                sel_mux11(1 downto 0)=>sel_mux11_from_cu(1 downto 0),      
                sel_mux12(1 downto 0)=>sel_mux12_from_cu(1 downto 0),      
                sel_mux13=>sel_mux13_from_cu,      
                sel_mux14=>sel_mux14_from_cu,      
--                sel_mux15=>XLXN_589,      
--                sel_mux16(1 downto 0)=>sel_mux16_from_cu(1 downto 0),      
--                sel_mux17(1 downto 0)=>sel_mux17_from_cu(1 downto 0),      
--                sel_mux18=>XLXN_491,      
                sel_rd=>sel_rd_from_cu,      
                sp_load_in=>sp_load_in_from_cu,      
                tmp_load_in=>tmp_load_in_from_cu);      
--                wbank0=>wbank0_from_cu,      
--                wbank1=>wbank1_from_cu);      
--                w_A=>XLXN_548,      
--                w_B=>XLXN_550,      
                --w_psw=>write_psw_from_cu);
   
   mux19_databus : mux19
      port map (in1(7 downto 0)=>databus_from_cu(7 downto 0),      
                in2(7 downto 0)=>databus_from_rom(7 downto 0),      
                sel=>sel_rd_from_cu,      
                out1(7 downto 0)=>databus_from_mux19(7 downto 0));
   
end structural;