--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : xil_3172_5
-- /___/   /\     Timestamp : 02/13/2005 10:36:47
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: internal_ram
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity internal_ram is
   port ( clk          : in    std_logic; 
          di_bank0     : in    std_logic_vector (7 downto 0); 
          di_bank1     : in    std_logic_vector (7 downto 0); 
          in_bit_data  : in    std_logic; 
          p0_in        : in    std_logic_vector (7 downto 0); 
          p1_in        : in    std_logic_vector (7 downto 0); 
          p2_in        : in    std_logic_vector (7 downto 0); 
          p3_in        : in    std_logic_vector (7 downto 0); 
          rst          : in    std_logic; 
          r_addr_bank0 : in    std_logic_vector (7 downto 0); 
          r_addr_bank1 : in    std_logic_vector (7 downto 0); 
          r_bit_addr   : in    std_logic_vector (7 downto 0); 
          sp_in        : in    std_logic_vector (7 downto 0); 
          wr_bank0     : in    std_logic; 
          wr_bank1     : in    std_logic; 
          w_addr_bank0 : in    std_logic_vector (7 downto 0); 
          w_addr_bank1 : in    std_logic_vector (7 downto 0); 
          w_bit        : in    std_logic; 
          w_bit_addr   : in    std_logic_vector (7 downto 0); 
          w_sp         : in    std_logic; 
          do_bank0     : out   std_logic_vector (7 downto 0); 
          do_bank1     : out   std_logic_vector (7 downto 0); 
          out_bit_data : out   std_logic; 
          p0_out       : out   std_logic_vector (7 downto 0); 
          p1_out       : out   std_logic_vector (7 downto 0); 
          p2_out       : out   std_logic_vector (7 downto 0); 
          p3_out       : out   std_logic_vector (7 downto 0); 
          sp_out       : out   std_logic_vector (7 downto 0));
end internal_ram;

architecture BEHAVIORAL of internal_ram is
begin
end BEHAVIORAL;

-- synopsys translate_off
configuration CFG_internal_ram of  internal_ram is
   for BEHAVIORAL
   end for;
end CFG_internal_ram;
-- synopsys translate_on

