-- VHDL model created from test.sch - Tue Aug 24 21:04:56 2004


library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity test is
   port (
       		 from_internal_data_memory 				: in std_logic_vector(15 downto 0);
       		 sel_mux1				: in std_logic_vector(1 downto 0);
                 sel_mux5						: in std_logic_vector(1 downto 0); 
   		 clock				: in std_logic;
   		 reset				: in std_logic;
   		 PC_data_in8				: in std_logic_vector(7 downto 0);
      		 PC_load_in8h				: in std_logic;
      		 PC_load_in8l				: in std_logic;
      		 PC_load_in16				: in std_logic;
   		 temp1_load_in				: in std_logic;
    		 ex_byte2				: in std_logic_vector(7 downto 0);
    		 ex_byte3				: in std_logic_vector(7 downto 0);
  		 sel_jcall				: in std_logic;
      		 sel_mux2				: in std_logic;
 		 acc_in				: in std_logic_vector(7 downto 0); 
      		 sel_mux3				: in std_logic;
 		 DPTR_in				: in std_logic_vector(15 downto 0);
       		 sel_mux4				: in std_logic_vector(2 downto 0);
 		 data_bus				: in std_logic_vector(7 downto 0);
 		 address_bus				: out std_logic_vector(15 downto 0);
 		 instruction_byte1				: out std_logic_vector(7 downto 0);	 
 		 instruction_byte2				: out std_logic_vector(7 downto 0);	 
 		 instruction_byte3				: out std_logic_vector(7 downto 0));
end test;

architecture BEHAVIORAL of test is
   signal PC_IN  			 : std_logic_vector (15 downto 0);
   signal source_PC  		 	: std_logic_vector (15 downto 0);
   signal next_PC  		 	 : std_logic_vector (15 downto 0);
   signal PC_data 			 : std_logic_vector (15 downto 0);
   signal sign_ex_in 			 : std_logic_vector (7 downto 0);
   signal sign_ex_out 		 : std_logic_vector (15 downto 0);
   signal source_adder2 	: std_logic_vector (15 downto 0);
   signal Temp1_data 			 : std_logic_vector (15 downto 0);
   signal JCall_out 			 : std_logic_vector (15 downto 0);
   signal out_adder2 			 : std_logic_vector (15 downto 0);

   component mux1
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component pc
      port ( load_in16 : in    std_logic; 
             load_in8h : in    std_logic; 
             load_in8l : in    std_logic; 
             data_in16 : in    std_logic_vector (15 downto 0); 
             clock     : in    std_logic; 
             reset     : in    std_logic; 
             data_out  : out   std_logic_vector (15 downto 0); 
             data_in8  : in    std_logic_vector (7 downto 0));
   end component;
   
   component adder1
      port ( in1  : in    std_logic_vector (15 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component temp1
      port ( load_in  : in    std_logic; 
             data_in  : in    std_logic_vector (15 downto 0); 
             data_out : out   std_logic_vector (15 downto 0));
   end component;
   
   component jcall_address_gen
      port ( out1 : out   std_logic_vector (15 downto 0); 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic);
   end component;
   
   component mux2
      port ( out1 : out   std_logic_vector (7 downto 0); 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             sel  : in    std_logic);
   end component;
   
   component sing_extender
      port ( in1  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component mux3
      port ( out1 : out   std_logic_vector (15 downto 0); 
             sel  : in    std_logic; 
             in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (7 downto 0));
   end component;
   
   component adder2
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component mux4
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             in4  : in    std_logic_vector (15 downto 0); 
             in5  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector (2 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component instruction_queue
      port ( clock : in    std_logic; 
             reset : in    std_logic; 
             in1   : in    std_logic_vector (7 downto 0); 
             out1  : out   std_logic_vector (7 downto 0); 
             out2  : out   std_logic_vector (7 downto 0); 
             out3  : out   std_logic_vector (7 downto 0));
   end component;
   
   component mux5
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
begin
   XLXI_1 : mux1
      port map ( in1(15 downto 0)=>next_PC(15 downto 0),
      		 in2(15 downto 0)=>from_internal_data_memory,
      		 in3(15 downto 0)=>Temp1_data(15 downto 0),
      		 sel(1 downto 0)=>sel_mux1,
      		 out1(15 downto 0)=>PC_IN(15 downto 0));
 
   XLXI_2 : mux5
      port map ( in1(15 downto 0)=>PC_data(15 downto 0),
      		 in2(15 downto 0)=>JCall_out(15 downto 0), 
      		 in3(15 downto 0)=>out_adder2(15 downto 0),
                 sel(1 downto 0)=>sel_mux5(1 downto 0), 
                 out1(15 downto 0)=>source_PC(15 downto 0));
   
   XLXI_3 : pc
      port map (	clock=>clock,
      		 data_in8(7 downto 0)=>PC_data_in8(7 downto 0),
      		 data_in16(15 downto 0)=>PC_IN(15 downto 0),
      		 load_in8h=>PC_load_in8h,
      		 load_in8l=>PC_load_in8l,
      		 load_in16=>PC_load_in16,
      		 reset=>reset,
      		 data_out(15 downto 0)=>PC_data(15 downto 0));
   
   XLXI_4 : adder1
      port map (	in1(15 downto 0)=>source_PC(15 downto 0),
      		 out1(15 downto 0)=>next_PC(15 downto 0));
   
   XLXI_5 : temp1
      port map (	data_in(15 downto 0)=>PC_data(15 downto 0),
      		 load_in=>temp1_load_in,
      		 data_out(15 downto 0)=>Temp1_data(15 downto 0));
   
   XLXI_6 : jcall_address_gen
      port map (	in1(7 downto 0)=>ex_byte2,
      		 in2(7 downto 0)=>ex_byte3,
      		 in3(15 downto 0)=>PC_data(15 downto 0),
      		 sel=>sel_jcall,
      		 out1(15 downto 0)=>JCall_out(15 downto 0));
   
   XLXI_7 : mux2
      port map (	in1(7 downto 0)=>ex_byte2,
      		 in2(7 downto 0)=>ex_byte3,
      		 sel=>sel_mux2,
      		 out1(7 downto 0)=>sign_ex_in(7 downto 0));
   
   XLXI_8 : sing_extender
      port map ( in1(7 downto 0)=>sign_ex_in(7 downto 0),
      		 out1(15 downto 0)=>sign_ex_out(15 downto 0));
   
   XLXI_9 : mux3
      port map (	in1(15 downto 0)=>sign_ex_out(15 downto 0),
      		 in2(7 downto 0)=>acc_in(7 downto 0),
      		 sel=>sel_mux3,
      		 out1(15 downto 0)=>source_adder2(15 downto 0));
   
   XLXI_10 : adder2
      port map (	in1(15 downto 0)=>Temp1_data(15 downto 0),
      		 in2(15 downto 0)=>source_adder2(15 downto 0), 
      		 out1(15 downto 0)=>out_adder2(15 downto 0));
   
   XLXI_11 : mux4
      port map (	in1(15 downto 0)=>JCall_out(15 downto 0), 
      		 in2(15 downto 0)=>Temp1_data(15 downto 0), 
      		 in3(15 downto 0)=>PC_data(15 downto 0),
            		 in4(15 downto 0)=>DPTR_in(15 downto 0), 
            		 in5(15 downto 0)=>out_adder2(15 downto 0),
            		 sel(2 downto 0)=>sel_mux4(2 downto 0), 
            		 out1(15 downto 0)=>address_bus(15 downto 0));
   
   XLXI_12 : instruction_queue
      port map ( clock=>clock, 
      		 in1(7 downto 0)=>data_bus(7 downto 0), 
      		 reset=>reset, 
      		 out1(7 downto 0)=>instruction_byte1(7 downto 0), 
      		 out2(7 downto 0)=>instruction_byte2(7 downto 0), 
      		 out3(7 downto 0)=>instruction_byte3(7 downto 0));
   
   
end BEHAVIORAL;


