VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtexe"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1(7:0)
        SIGNAL XLXN_2(7:0)
        SIGNAL XLXN_3(7:0)
        SIGNAL XLXN_281(7:0)
        SIGNAL XLXN_14(7:0)
        SIGNAL XLXN_15(7:0)
        SIGNAL XLXN_18(7:0)
        SIGNAL XLXN_19(7:0)
        SIGNAL XLXN_69(7:0)
        SIGNAL XLXN_70(7:0)
        SIGNAL XLXN_73(7:0)
        SIGNAL XLXN_75(7:0)
        SIGNAL XLXN_77(7:0)
        SIGNAL XLXN_438
        SIGNAL XLXN_441
        SIGNAL XLXN_443(1:0)
        SIGNAL XLXN_444
        SIGNAL XLXN_445
        SIGNAL XLXN_446(2:0)
        SIGNAL XLXN_447(1:0)
        SIGNAL XLXN_452(1:0)
        SIGNAL XLXN_456
        SIGNAL XLXN_461(1:0)
        SIGNAL XLXN_462(2:0)
        SIGNAL XLXN_465(2:0)
        SIGNAL XLXN_467(1:0)
        SIGNAL XLXN_472
        SIGNAL XLXN_473
        SIGNAL XLXN_478
        SIGNAL XLXN_479
        SIGNAL XLXN_480
        SIGNAL XLXN_481(1:0)
        SIGNAL XLXN_482
        SIGNAL XLXN_483
        SIGNAL XLXN_487
        SIGNAL XLXN_485
        SIGNAL XLXN_521(3:0)
        SIGNAL XLXN_522(1:0)
        SIGNAL XLXN_523(1:0)
        SIGNAL XLXN_72(7:0)
        SIGNAL XLXN_71(7:0)
        SIGNAL XLXN_130(7:0)
        SIGNAL XLXN_61(7:0)
        SIGNAL XLXN_62(7:0)
        SIGNAL XLXN_63(7:0)
        SIGNAL XLXN_64(7:0)
        SIGNAL XLXN_59(7:0)
        SIGNAL XLXN_490
        SIGNAL XLXN_491
        SIGNAL XLXN_512
        SIGNAL XLXN_515
        SIGNAL XLXN_518
        SIGNAL XLXN_513(1:0)
        SIGNAL XLXN_541(1:0)
        SIGNAL XLXN_542(1:0)
        SIGNAL XLXN_543(3:0)
        SIGNAL XLXN_545
        SIGNAL XLXN_546
        SIGNAL XLXN_547
        SIGNAL XLXN_548
        SIGNAL XLXN_550
        SIGNAL XLXN_552
        SIGNAL XLXN_554
        SIGNAL XLXN_556(7:0)
        SIGNAL XLXN_557
        SIGNAL XLXN_558
        SIGNAL XLXN_559
        SIGNAL XLXN_560
        SIGNAL XLXN_562
        SIGNAL XLXN_565(1:0)
        SIGNAL XLXN_566(15:0)
        SIGNAL XLXN_568(15:0)
        SIGNAL XLXN_573(15:0)
        SIGNAL XLXN_574(7:0)
        SIGNAL XLXN_575(7:0)
        SIGNAL XLXN_577(7:0)
        SIGNAL XLXN_583(7:0)
        SIGNAL XLXN_584(7:0)
        SIGNAL XLXN_585(7:0)
        SIGNAL XLXN_588
        SIGNAL XLXN_589
        SIGNAL XLXN_590(7:0)
        SIGNAL XLXN_592(7:0)
        SIGNAL XLXN_593
        SIGNAL XLXN_594(7:0)
        SIGNAL XLXN_597(7:0)
        SIGNAL XLXN_599(7:0)
        SIGNAL XLXN_600(7:0)
        SIGNAL XLXN_601(1:0)
        SIGNAL XLXN_603
        SIGNAL XLXN_604
        SIGNAL XLXN_605
        SIGNAL XLXN_606(1:0)
        SIGNAL XLXN_607
        SIGNAL XLXN_608
        SIGNAL XLXN_610
        SIGNAL XLXN_611
        SIGNAL XLXN_613(15:0)
        SIGNAL XLXN_615(1:0)
        SIGNAL XLXN_617(1:0)
        SIGNAL XLXN_618(4:0)
        SIGNAL XLXN_619(4:0)
        SIGNAL Reset
        SIGNAL Clock
        SIGNAL P3_in(7:0)
        SIGNAL P2_in(7:0)
        SIGNAL P1_in(7:0)
        SIGNAL P0_in(7:0)
        SIGNAL P0_out(7:0)
        SIGNAL P1_out(7:0)
        SIGNAL P2_out(7:0)
        SIGNAL P3_out(7:0)
        SIGNAL XLXN_626(7:0)
        SIGNAL XLXN_627
        SIGNAL XLXN_628(7:0)
        SIGNAL int0
        SIGNAL int1
        SIGNAL wr
        SIGNAL rd
        SIGNAL XLXN_786(7:0)
        SIGNAL XLXN_788(1:0)
        SIGNAL XLXN_791(7:0)
        SIGNAL XLXN_798(7:0)
        SIGNAL XLXN_799(1:0)
        SIGNAL XLXN_800(1:0)
        PORT Input Reset
        PORT Input Clock
        PORT Input P3_in(7:0)
        PORT Input P2_in(7:0)
        PORT Input P1_in(7:0)
        PORT Input P0_in(7:0)
        PORT Output P0_out(7:0)
        PORT Output P1_out(7:0)
        PORT Output P2_out(7:0)
        PORT Output P3_out(7:0)
        PORT Input int0
        PORT Input int1
        PORT Input wr
        PORT Input rd
        BEGIN BLOCKDEF writeback
            TIMESTAMP 2005 3 13 15 18 38
            LINE N 368 416 432 416 
            RECTANGLE N 368 404 432 428 
            LINE N 368 480 432 480 
            RECTANGLE N 368 468 432 492 
            LINE N 368 288 432 288 
            RECTANGLE N 368 276 432 300 
            LINE N 368 352 432 352 
            RECTANGLE N 368 340 432 364 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -288 0 -288 
            LINE N 64 -352 0 -352 
            RECTANGLE N 64 -384 368 512 
        END BLOCKDEF
        BEGIN BLOCKDEF decode_stage
            TIMESTAMP 2005 3 13 15 7 56
            LINE N 64 352 0 352 
            RECTANGLE N 0 340 64 364 
            LINE N 64 416 0 416 
            RECTANGLE N 0 404 64 428 
            LINE N 352 352 416 352 
            RECTANGLE N 352 340 416 364 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            RECTANGLE N 0 -428 64 -404 
            LINE N 64 -352 0 -352 
            RECTANGLE N 0 -364 64 -340 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -300 64 -276 
            LINE N 352 -480 416 -480 
            RECTANGLE N 352 -492 416 -468 
            LINE N 352 -416 416 -416 
            RECTANGLE N 352 -428 416 -404 
            LINE N 352 -352 416 -352 
            RECTANGLE N 352 -364 416 -340 
            LINE N 352 -288 416 -288 
            RECTANGLE N 352 -300 416 -276 
            LINE N 352 -224 416 -224 
            RECTANGLE N 352 -236 416 -212 
            LINE N 352 -160 416 -160 
            RECTANGLE N 352 -172 416 -148 
            LINE N 352 -96 416 -96 
            RECTANGLE N 352 -108 416 -84 
            LINE N 64 96 0 96 
            RECTANGLE N 0 84 64 108 
            LINE N 64 160 0 160 
            RECTANGLE N 0 148 64 172 
            LINE N 64 224 0 224 
            RECTANGLE N 0 212 64 236 
            LINE N 64 288 0 288 
            RECTANGLE N 0 276 64 300 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 32 0 32 
            RECTANGLE N 0 20 64 44 
            RECTANGLE N 64 -504 352 448 
        END BLOCKDEF
        BEGIN BLOCKDEF execute
            TIMESTAMP 2005 3 13 15 54 33
            LINE N 64 16 0 16 
            RECTANGLE N 0 4 64 28 
            LINE N 64 80 0 80 
            RECTANGLE N 0 68 64 92 
            LINE N 64 -752 0 -752 
            RECTANGLE N 0 -764 64 -740 
            LINE N 64 -688 0 -688 
            RECTANGLE N 0 -700 64 -676 
            LINE N 64 -624 0 -624 
            RECTANGLE N 0 -636 64 -612 
            LINE N 64 -560 0 -560 
            RECTANGLE N 0 -572 64 -548 
            LINE N 64 -496 0 -496 
            RECTANGLE N 0 -508 64 -484 
            LINE N 64 -432 0 -432 
            RECTANGLE N 0 -444 64 -420 
            LINE N 64 -368 0 -368 
            RECTANGLE N 0 -380 64 -356 
            LINE N 64 -176 0 -176 
            RECTANGLE N 0 -188 64 -164 
            LINE N 64 -304 0 -304 
            LINE N 64 -240 0 -240 
            LINE N 64 -112 0 -112 
            RECTANGLE N 0 -124 64 -100 
            LINE N 64 -48 0 -48 
            RECTANGLE N 0 -60 64 -36 
            LINE N 368 -48 432 -48 
            RECTANGLE N 64 -852 368 116 
            LINE N 368 -752 432 -752 
            RECTANGLE N 368 -764 432 -740 
            LINE N 368 -688 432 -688 
            RECTANGLE N 368 -700 432 -676 
            LINE N 64 -816 0 -816 
            LINE N 368 -112 432 -112 
            LINE N 368 -176 432 -176 
        END BLOCKDEF
        BEGIN BLOCKDEF fetch
            TIMESTAMP 2005 3 15 8 3 28
            LINE N 432 112 496 112 
            RECTANGLE N 432 100 496 124 
            LINE N 432 48 496 48 
            RECTANGLE N 432 36 496 60 
            LINE N 64 -928 0 -928 
            LINE N 64 -864 0 -864 
            LINE N 64 -800 0 -800 
            LINE N 432 -992 496 -992 
            RECTANGLE N 432 -1004 496 -980 
            LINE N 432 -928 496 -928 
            RECTANGLE N 432 -940 496 -916 
            LINE N 432 -864 496 -864 
            RECTANGLE N 432 -876 496 -852 
            LINE N 64 -992 0 -992 
            LINE N 64 -672 0 -672 
            RECTANGLE N 0 -684 64 -660 
            LINE N 64 -480 0 -480 
            RECTANGLE N 0 -492 64 -468 
            LINE N 64 -416 0 -416 
            RECTANGLE N 0 -428 64 -404 
            LINE N 64 -608 0 -608 
            LINE N 64 -544 0 -544 
            LINE N 64 -272 0 -272 
            RECTANGLE N 0 -284 64 -260 
            LINE N 64 -208 0 -208 
            RECTANGLE N 0 -220 64 -196 
            LINE N 64 -336 0 -336 
            RECTANGLE N 0 -348 64 -324 
            LINE N 432 -16 496 -16 
            RECTANGLE N 432 -28 496 -4 
            LINE N 64 -736 0 -736 
            RECTANGLE N 0 -748 64 -724 
            LINE N 64 -80 0 -80 
            RECTANGLE N 0 -92 64 -68 
            LINE N 64 -16 0 -16 
            RECTANGLE N 0 -28 64 -4 
            LINE N 0 48 64 48 
            RECTANGLE N 0 36 64 60 
            LINE N 64 -144 0 -144 
            RECTANGLE N 0 -156 64 -132 
            RECTANGLE N 64 -1024 432 144 
        END BLOCKDEF
        BEGIN BLOCKDEF ifid
            TIMESTAMP 2005 3 13 15 29 32
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -160 384 -160 
            RECTANGLE N 320 -172 384 -148 
            LINE N 320 -224 384 -224 
            RECTANGLE N 320 -236 384 -212 
            RECTANGLE N 64 -460 320 -64 
            LINE N 64 -352 0 -352 
            LINE N 64 -416 0 -416 
            LINE N 64 -288 0 -288 
        END BLOCKDEF
        BEGIN BLOCKDEF idex
            TIMESTAMP 2005 3 13 15 56 6
            LINE N 64 -416 0 -416 
            RECTANGLE N 0 -428 64 -404 
            LINE N 64 -352 0 -352 
            RECTANGLE N 0 -364 64 -340 
            LINE N 64 -288 0 -288 
            RECTANGLE N 0 -300 64 -276 
            LINE N 64 -224 0 -224 
            RECTANGLE N 0 -236 64 -212 
            LINE N 384 -416 448 -416 
            RECTANGLE N 384 -428 448 -404 
            LINE N 384 -352 448 -352 
            RECTANGLE N 384 -364 448 -340 
            LINE N 384 -288 448 -288 
            RECTANGLE N 384 -300 448 -276 
            LINE N 384 -224 448 -224 
            RECTANGLE N 384 -236 448 -212 
            LINE N 384 -160 448 -160 
            RECTANGLE N 384 -172 448 -148 
            LINE N 384 -96 448 -96 
            RECTANGLE N 384 -108 448 -84 
            LINE N 384 -32 448 -32 
            RECTANGLE N 384 -44 448 -20 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -864 0 -864 
            LINE N 64 -800 0 -800 
            LINE N 384 -864 448 -864 
            LINE N 384 -800 448 -800 
            LINE N 64 -1248 0 -1248 
            RECTANGLE N 0 -1260 64 -1236 
            LINE N 384 -1248 448 -1248 
            RECTANGLE N 384 -1260 448 -1236 
            LINE N 64 -1184 0 -1184 
            LINE N 64 -1120 0 -1120 
            LINE N 64 -1056 0 -1056 
            LINE N 384 -1184 448 -1184 
            LINE N 384 -1120 448 -1120 
            LINE N 384 -1056 448 -1056 
            LINE N 64 160 0 160 
            RECTANGLE N 0 148 64 172 
            LINE N 64 224 0 224 
            RECTANGLE N 0 212 64 236 
            LINE N 384 160 448 160 
            RECTANGLE N 384 148 448 172 
            LINE N 384 224 448 224 
            RECTANGLE N 384 212 448 236 
            LINE N 64 288 0 288 
            RECTANGLE N 0 276 64 300 
            LINE N 384 288 448 288 
            RECTANGLE N 384 276 448 300 
            LINE N 64 -1504 0 -1504 
            LINE N 64 -1440 0 -1440 
            LINE N 64 -1376 0 -1376 
            LINE N 64 -1312 0 -1312 
            LINE N 384 -1504 448 -1504 
            LINE N 384 -1440 448 -1440 
            LINE N 384 -1376 448 -1376 
            LINE N 384 -1312 448 -1312 
            LINE N 64 -672 0 -672 
            LINE N 64 -608 0 -608 
            RECTANGLE N 64 -1536 384 332 
            LINE N 64 -992 0 -992 
            RECTANGLE N 0 -1004 64 -980 
            LINE N 384 -992 448 -992 
            RECTANGLE N 384 -1004 448 -980 
        END BLOCKDEF
        BEGIN BLOCKDEF mem_unit
            TIMESTAMP 2005 3 13 15 30 13
            LINE N 320 864 384 864 
            RECTANGLE N 320 852 384 876 
            LINE N 320 -384 384 -384 
            RECTANGLE N 320 -396 384 -372 
            LINE N 320 800 384 800 
            RECTANGLE N 320 788 384 812 
            LINE N 320 -320 384 -320 
            RECTANGLE N 320 -332 384 -308 
            LINE N 320 -448 384 -448 
            RECTANGLE N 320 -460 384 -436 
            LINE N 320 -512 384 -512 
            RECTANGLE N 320 -524 384 -500 
            LINE N 320 608 384 608 
            RECTANGLE N 320 596 384 620 
            LINE N 320 672 384 672 
            RECTANGLE N 320 660 384 684 
            LINE N 320 480 384 480 
            RECTANGLE N 320 468 384 492 
            LINE N 320 544 384 544 
            RECTANGLE N 320 532 384 556 
            LINE N 320 736 384 736 
            RECTANGLE N 320 724 384 748 
            LINE N 64 736 0 736 
            RECTANGLE N 0 724 64 748 
            RECTANGLE N 0 788 64 812 
            LINE N 64 800 0 800 
            LINE N 64 480 0 480 
            LINE N 64 544 0 544 
            LINE N 64 -1440 0 -1440 
            RECTANGLE N 0 -1452 64 -1428 
            LINE N 64 -1376 0 -1376 
            RECTANGLE N 0 -1388 64 -1364 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -480 0 -480 
            LINE N 64 -416 0 -416 
            LINE N 64 -352 0 -352 
            LINE N 64 -672 0 -672 
            LINE N 64 -608 0 -608 
            LINE N 64 -544 0 -544 
            LINE N 64 -864 0 -864 
            RECTANGLE N 0 -876 64 -852 
            LINE N 64 -800 0 -800 
            RECTANGLE N 0 -812 64 -788 
            LINE N 64 -736 0 -736 
            RECTANGLE N 0 -748 64 -724 
            LINE N 64 -928 0 -928 
            RECTANGLE N 0 -940 64 -916 
            LINE N 64 32 0 32 
            RECTANGLE N 0 20 64 44 
            LINE N 64 96 0 96 
            RECTANGLE N 0 84 64 108 
            LINE N 64 160 0 160 
            LINE N 64 224 0 224 
            LINE N 64 288 0 288 
            LINE N 64 -32 0 -32 
            LINE N 64 -1248 0 -1248 
            RECTANGLE N 0 -1260 64 -1236 
            LINE N 64 -1184 0 -1184 
            RECTANGLE N 0 -1196 64 -1172 
            LINE N 64 -1120 0 -1120 
            RECTANGLE N 0 -1132 64 -1108 
            LINE N 64 -1056 0 -1056 
            RECTANGLE N 0 -1068 64 -1044 
            LINE N 320 -864 384 -864 
            RECTANGLE N 320 -876 384 -852 
            LINE N 64 352 0 352 
            RECTANGLE N 64 -1472 320 896 
        END BLOCKDEF
        BEGIN BLOCKDEF exwb
            TIMESTAMP 2005 3 13 15 45 39
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -224 384 -224 
            RECTANGLE N 320 -236 384 -212 
            LINE N 320 -160 384 -160 
            RECTANGLE N 320 -172 384 -148 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
            LINE N 64 -864 0 -864 
            LINE N 64 -800 0 -800 
            LINE N 64 -736 0 -736 
            LINE N 320 -864 384 -864 
            LINE N 320 -800 384 -800 
            LINE N 320 -736 384 -736 
            LINE N 64 -544 0 -544 
            LINE N 64 -480 0 -480 
            LINE N 64 -928 0 -928 
            RECTANGLE N 0 -940 64 -916 
            LINE N 320 -928 384 -928 
            RECTANGLE N 320 -940 384 -916 
            LINE N 64 -416 0 -416 
            RECTANGLE N 0 -428 64 -404 
            LINE N 64 -352 0 -352 
            RECTANGLE N 0 -364 64 -340 
            LINE N 320 -352 384 -352 
            LINE N 320 -288 384 -288 
            LINE N 64 160 0 160 
            LINE N 64 224 0 224 
            LINE N 64 -1184 0 -1184 
            LINE N 64 -1120 0 -1120 
            LINE N 64 -1056 0 -1056 
            LINE N 64 -992 0 -992 
            LINE N 320 -1184 384 -1184 
            LINE N 320 -1120 384 -1120 
            LINE N 320 -1056 384 -1056 
            LINE N 320 -992 384 -992 
            RECTANGLE N 64 -1308 320 256 
            LINE N 64 -672 0 -672 
            RECTANGLE N 0 -684 64 -660 
            LINE N 320 -672 384 -672 
            RECTANGLE N 320 -684 384 -660 
        END BLOCKDEF
        BEGIN BLOCKDEF i8051rom
            TIMESTAMP 2005 3 12 10 9 48
            RECTANGLE N 64 -256 320 0 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -224 384 -224 
            RECTANGLE N 320 -236 384 -212 
        END BLOCKDEF
        BEGIN BLOCKDEF contorl_unit
            TIMESTAMP 2005 3 15 8 3 11
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -288 0 -288 
            LINE N 64 -224 0 -224 
            LINE N 320 -288 384 -288 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -224 384 -224 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -32 384 -32 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -160 384 -160 
            LINE N 320 -480 384 -480 
            LINE N 320 -416 384 -416 
            LINE N 320 -608 384 -608 
            LINE N 320 -672 384 -672 
            LINE N 320 -1184 384 -1184 
            RECTANGLE N 320 -1196 384 -1172 
            LINE N 320 -1120 384 -1120 
            RECTANGLE N 320 -1132 384 -1108 
            LINE N 320 -1056 384 -1056 
            RECTANGLE N 320 -1068 384 -1044 
            LINE N 320 -992 384 -992 
            RECTANGLE N 320 -1004 384 -980 
            LINE N 320 -1248 384 -1248 
            RECTANGLE N 320 -1260 384 -1236 
            LINE N 320 -928 384 -928 
            RECTANGLE N 320 -940 384 -916 
            LINE N 320 -864 384 -864 
            LINE N 320 -800 384 -800 
            LINE N 320 -1632 384 -1632 
            LINE N 320 -1568 384 -1568 
            LINE N 320 -1760 384 -1760 
            LINE N 320 -1824 384 -1824 
            LINE N 320 -1504 384 -1504 
            RECTANGLE N 320 -1516 384 -1492 
            LINE N 320 -2016 384 -2016 
            RECTANGLE N 320 -2028 384 -2004 
            LINE N 320 -1952 384 -1952 
            LINE N 320 -2208 384 -2208 
            LINE N 320 -2144 384 -2144 
            LINE N 64 -2592 0 -2592 
            RECTANGLE N 0 -2604 64 -2580 
            LINE N 64 -2528 0 -2528 
            LINE N 64 -2464 0 -2464 
            LINE N 64 -2400 0 -2400 
            LINE N 320 -544 384 -544 
            RECTANGLE N 320 -556 384 -532 
            LINE N 320 -2400 384 -2400 
            LINE N 320 -2464 384 -2464 
            LINE N 320 -2720 384 -2720 
            LINE N 320 -2656 384 -2656 
            RECTANGLE N 320 -2668 384 -2644 
            LINE N 320 -1376 384 -1376 
            RECTANGLE N 320 -1388 384 -1364 
            LINE N 320 -1440 384 -1440 
            RECTANGLE N 320 -1452 384 -1428 
            LINE N 320 -2272 384 -2272 
            LINE N 320 -2336 384 -2336 
            LINE N 320 -736 384 -736 
            LINE N 320 -2080 384 -2080 
            RECTANGLE N 320 -2092 384 -2068 
            LINE N 64 -1056 0 -1056 
            LINE N 64 -992 0 -992 
            LINE N 64 -928 0 -928 
            LINE N 64 -864 0 -864 
            LINE N 320 -352 384 -352 
            RECTANGLE N 320 -364 384 -340 
            RECTANGLE N 64 -2816 320 0 
            LINE N 64 -352 0 -352 
            RECTANGLE N 0 -364 64 -340 
        END BLOCKDEF
        BEGIN BLOCKDEF mux10131415
            TIMESTAMP 2005 2 10 20 32 42
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -160 384 -160 
            RECTANGLE N 320 -172 384 -148 
        END BLOCKDEF
        BEGIN BLOCK XLXI_8 mem_unit
            PIN clk Clock
            PIN rst Reset
            PIN sel_as XLXN_562
            PIN sel_mux10 XLXN_608
            PIN sel_mux13 XLXN_605
            PIN sel_mux14 XLXN_588
            PIN sel_mux15 XLXN_589
            PIN wr_bank0 XLXN_604
            PIN wr_bank1 XLXN_603
            PIN load_in XLXN_607
            PIN W_A XLXN_611
            PIN W_B XLXN_610
            PIN W_psw XLXN_593
            PIN Din0(7:0) XLXN_594(7:0)
            PIN Din1(7:0) XLXN_594(7:0)
            PIN PC_in(15:0) XLXN_573(15:0)
            PIN r_addr(7:0) XLXN_585(7:0)
            PIN w_addr(7:0) XLXN_597(7:0)
            PIN en(1:0) XLXN_601(1:0)
            PIN sel_mux11(1:0) XLXN_606(1:0)
            PIN sel_mux12(1:0) XLXN_565(1:0)
            PIN di_A(7:0) XLXN_600(7:0)
            PIN di_B(7:0) XLXN_599(7:0)
            PIN di_psw(7:0) XLXN_592(7:0)
            PIN p0_in(7:0) P0_in(7:0)
            PIN p1_in(7:0) P1_in(7:0)
            PIN p2_in(7:0) P2_in(7:0)
            PIN p3_in(7:0) P3_in(7:0)
            PIN PC_out(15:0) XLXN_566(15:0)
            PIN dptr(15:0) XLXN_568(15:0)
            PIN mux15(7:0) XLXN_577(7:0)
            PIN do_A(7:0) XLXN_574(7:0)
            PIN do_B(7:0) XLXN_575(7:0)
            PIN do_psw(7:0) XLXN_590(7:0)
            PIN R0(7:0) XLXN_583(7:0)
            PIN R1(7:0) XLXN_584(7:0)
            PIN p0_out(7:0) P0_out(7:0)
            PIN p1_out(7:0) P1_out(7:0)
            PIN p2_out(7:0) P2_out(7:0)
            PIN p3_out(7:0) P3_out(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_21 i8051rom
            PIN rst Reset
            PIN clk Clock
            PIN rd XLXN_627
            PIN ADDRESS_BUS(15:0) XLXN_613(15:0)
            PIN DATA_BUS(7:0) XLXN_628(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_4 fetch
            PIN clock Clock
            PIN reset Reset
            PIN PC_load_in16 XLXN_438
            PIN temp1_load_in XLXN_441
            PIN sel_mux2 XLXN_444
            PIN sel_mux3 XLXN_445
            PIN from_internal_data_memory(15:0) XLXN_566(15:0)
            PIN sel_mux1(1:0) XLXN_443(1:0)
            PIN sel_mux5(1:0) XLXN_447(1:0)
            PIN ex_byte1(7:0) XLXN_281(7:0)
            PIN ex_byte2(7:0) XLXN_798(7:0)
            PIN ex_byte3(7:0) XLXN_791(7:0)
            PIN sel_jcall(1:0) XLXN_788(1:0)
            PIN acc_in(7:0) XLXN_574(7:0)
            PIN DPTR_in(15:0) XLXN_568(15:0)
            PIN sel_mux4(2:0) XLXN_446(2:0)
            PIN data_bus(7:0) XLXN_786(7:0)
            PIN address_bus(15:0) XLXN_613(15:0)
            PIN pc_resent(15:0) XLXN_573(15:0)
            PIN instruction_byte1(7:0) XLXN_3(7:0)
            PIN instruction_byte2(7:0) XLXN_2(7:0)
            PIN instruction_byte3(7:0) XLXN_1(7:0)
            PIN iqc(1:0) XLXN_799(1:0)
        END BLOCK
        BEGIN BLOCK XLXI_15 ifid
            PIN clk Clock
            PIN rst Reset
            PIN hold XLXN_456
            PIN in1(7:0) XLXN_3(7:0)
            PIN in2(7:0) XLXN_2(7:0)
            PIN in3(7:0) XLXN_1(7:0)
            PIN out1(7:0) XLXN_281(7:0)
            PIN out2(7:0) XLXN_798(7:0)
            PIN out3(7:0) XLXN_791(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_14 execute
            PIN rst Reset
            PIN ac_in XLXN_485
            PIN cy_in XLXN_487
            PIN AA(7:0) XLXN_18(7:0)
            PIN BB(7:0) XLXN_19(7:0)
            PIN D1(7:0) XLXN_73(7:0)
            PIN D2(7:0) XLXN_556(7:0)
            PIN OPCode(4:0) XLXN_618(4:0)
            PIN s1(7:0) XLXN_14(7:0)
            PIN s2(7:0) XLXN_15(7:0)
            PIN sel_mux16(1:0) XLXN_523(1:0)
            PIN sel_mux17(1:0) XLXN_522(1:0)
            PIN sel(3:0) XLXN_521(3:0)
            PIN RA_in(7:0) XLXN_75(7:0)
            PIN RB_in(7:0) XLXN_77(7:0)
            PIN ac_out XLXN_547
            PIN cy_out XLXN_546
            PIN ov XLXN_545
            PIN RA_out(7:0) XLXN_70(7:0)
            PIN RB_out(7:0) XLXN_69(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_1 writeback
            PIN sel_addr_decode XLXN_482
            PIN sel_mux18 XLXN_483
            PIN d11(7:0) XLXN_73(7:0)
            PIN d22(7:0) XLXN_556(7:0)
            PIN R_A(7:0) XLXN_75(7:0)
            PIN R_B(7:0) XLXN_77(7:0)
            PIN w_addr(7:0) XLXN_597(7:0)
            PIN w_data(7:0) XLXN_594(7:0)
            PIN out_A(7:0) XLXN_600(7:0)
            PIN out_B(7:0) XLXN_599(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_2 decode_stage
            PIN reset Reset
            PIN inst_b1(7:0) XLXN_281(7:0)
            PIN inst_b2(7:0) XLXN_798(7:0)
            PIN inst_b3(7:0) XLXN_791(7:0)
            PIN from_acc(7:0) XLXN_574(7:0)
            PIN from_b(7:0) XLXN_575(7:0)
            PIN from_mem(7:0) XLXN_577(7:0)
            PIN from_sfr(7:0) XLXN_577(7:0)
            PIN sel_mux6(1:0) XLXN_467(1:0)
            PIN sel_mux7(2:0) XLXN_465(2:0)
            PIN sel_mux8(1:0) XLXN_461(1:0)
            PIN sel_mux9(2:0) XLXN_462(2:0)
            PIN bank(1:0) XLXN_452(1:0)
            PIN s1(7:0) XLXN_59(7:0)
            PIN s2(7:0) XLXN_64(7:0)
            PIN d1(7:0) XLXN_63(7:0)
            PIN d2(7:0) XLXN_62(7:0)
            PIN alu_oprt(4:0) XLXN_619(4:0)
            PIN reg_aa(7:0) XLXN_61(7:0)
            PIN reg_bb(7:0) XLXN_130(7:0)
            PIN in_r0(7:0) XLXN_583(7:0)
            PIN in_r1(7:0) XLXN_584(7:0)
            PIN r_addr(7:0) XLXN_585(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_9 exwb
            PIN clk Clock
            PIN rst Reset
            PIN in_w_A XLXN_560
            PIN in_w_B XLXN_559
            PIN in_sel_nux10 XLXN_558
            PIN in_sp_load XLXN_557
            PIN in_sel_mux18 XLXN_473
            PIN in_sel_addr_dec XLXN_472
            PIN in_sel_mux13 XLXN_480
            PIN in_wbank0 XLXN_479
            PIN in_wbank1 XLXN_478
            PIN in_D11(7:0) XLXN_71(7:0)
            PIN in_D22(7:0) XLXN_72(7:0)
            PIN in_R_A(7:0) XLXN_70(7:0)
            PIN in_R_B(7:0) XLXN_69(7:0)
            PIN in_sel_mux11(1:0) XLXN_481(1:0)
            PIN out_w_A XLXN_611
            PIN out_w_B XLXN_610
            PIN out_sel_nux10 XLXN_608
            PIN out_sp_load XLXN_607
            PIN out_sel_mux18 XLXN_483
            PIN out_sel_addr_dec XLXN_482
            PIN out_sel_mux13 XLXN_605
            PIN out_wbank0 XLXN_604
            PIN out_wbank1 XLXN_603
            PIN out_D11(7:0) XLXN_73(7:0)
            PIN out_D22(7:0) XLXN_556(7:0)
            PIN out_R_A(7:0) XLXN_75(7:0)
            PIN out_R_B(7:0) XLXN_77(7:0)
            PIN out_sel_mux11(1:0) XLXN_606(1:0)
            PIN in_en(1:0) XLXN_617(1:0)
            PIN out_en(1:0) XLXN_601(1:0)
        END BLOCK
        BEGIN BLOCK XLXI_22 contorl_unit
            PIN clk Clock
            PIN rst Reset
            PIN ac_in XLXN_547
            PIN cy_in XLXN_546
            PIN int0 int0
            PIN int1 int1
            PIN ov XLXN_545
            PIN wr wr
            PIN rd rd
            PIN byte1(7:0) XLXN_281(7:0)
            PIN byte2(7:0) XLXN_798(7:0)
            PIN byte3(7:0) XLXN_791(7:0)
            PIN psw_in(7:0) XLXN_590(7:0)
            PIN ac_out XLXN_485
            PIN cy_out XLXN_487
            PIN sel_mux2 XLXN_444
            PIN sel_mux3 XLXN_445
            PIN sel_mux10 XLXN_552
            PIN sel_mux13 XLXN_518
            PIN sel_mux14 XLXN_588
            PIN sel_mux15 XLXN_589
            PIN sel_mux18 XLXN_491
            PIN sel_addr_de XLXN_490
            PIN sel_rd XLXN_627
            PIN sel_as XLXN_562
            PIN w_psw XLXN_593
            PIN w_A XLXN_548
            PIN w_B XLXN_550
            PIN wbank0 XLXN_515
            PIN wbank1 XLXN_512
            PIN hold XLXN_456
            PIN PC_load_in XLXN_438
            PIN tmp_load_in XLXN_441
            PIN sp_load_in XLXN_554
            PIN sel_mux1(1:0) XLXN_443(1:0)
            PIN sel_mux4(2:0) XLXN_446(2:0)
            PIN sel_mux5(1:0) XLXN_447(1:0)
            PIN sel_mux6(1:0) XLXN_467(1:0)
            PIN sel_mux7(2:0) XLXN_465(2:0)
            PIN sel_mux8(1:0) XLXN_461(1:0)
            PIN sel_mux9(2:0) XLXN_462(2:0)
            PIN sel_mux11(1:0) XLXN_513(1:0)
            PIN sel_mux12(1:0) XLXN_565(1:0)
            PIN sel_mux16(1:0) XLXN_541(1:0)
            PIN sel_mux17(1:0) XLXN_542(1:0)
            PIN sel_forward(3:0) XLXN_543(3:0)
            PIN sel_jcall(1:0) XLXN_788(1:0)
            PIN sel_bank(1:0) XLXN_452(1:0)
            PIN EN_latch(1:0) XLXN_615(1:0)
            PIN psw_out(7:0) XLXN_592(7:0)
            PIN data_bus(7:0) XLXN_626(7:0)
            PIN iqc(1:0) XLXN_799(1:0)
        END BLOCK
        BEGIN BLOCK XLXI_20 idex
            PIN clk Clock
            PIN rst Reset
            PIN in_w_A XLXN_548
            PIN in_w_B XLXN_550
            PIN in_sel_nux10 XLXN_552
            PIN in_sp_load XLXN_554
            PIN in_sel_mux18 XLXN_491
            PIN in_sel_addr_dec XLXN_490
            PIN in_sel_mux13 XLXN_518
            PIN in_wbank0 XLXN_515
            PIN in_wbank1 XLXN_512
            PIN in_s1(7:0) XLXN_59(7:0)
            PIN in_s2(7:0) XLXN_64(7:0)
            PIN in_d1(7:0) XLXN_63(7:0)
            PIN in_d2(7:0) XLXN_62(7:0)
            PIN in_A(7:0) XLXN_61(7:0)
            PIN in_B(7:0) XLXN_130(7:0)
            PIN in_Opcode(4:0) XLXN_619(4:0)
            PIN in_sel(3:0) XLXN_543(3:0)
            PIN in_sel_mux16(1:0) XLXN_541(1:0)
            PIN in_sel_mux17(1:0) XLXN_542(1:0)
            PIN in_sel_mux11(1:0) XLXN_513(1:0)
            PIN in_en(1:0) XLXN_615(1:0)
            PIN out_w_A XLXN_560
            PIN out_w_B XLXN_559
            PIN out_sel_nux10 XLXN_558
            PIN out_sp_load XLXN_557
            PIN out_sel_mux18 XLXN_473
            PIN out_sel_addr_dec XLXN_472
            PIN out_sel_mux13 XLXN_480
            PIN out_wbank0 XLXN_479
            PIN out_wbank1 XLXN_478
            PIN out_s1(7:0) XLXN_14(7:0)
            PIN out_s2(7:0) XLXN_15(7:0)
            PIN out_d1(7:0) XLXN_71(7:0)
            PIN out_d2(7:0) XLXN_72(7:0)
            PIN out_A(7:0) XLXN_18(7:0)
            PIN out_B(7:0) XLXN_19(7:0)
            PIN out_Opcode(4:0) XLXN_618(4:0)
            PIN out_sel(3:0) XLXN_521(3:0)
            PIN out_sel_mux16(1:0) XLXN_523(1:0)
            PIN out_sel_mux17(1:0) XLXN_522(1:0)
            PIN out_sel_mux11(1:0) XLXN_481(1:0)
            PIN out_en(1:0) XLXN_617(1:0)
        END BLOCK
        BEGIN BLOCK XLXI_25 mux10131415
            PIN sel XLXN_627
            PIN in1(7:0) XLXN_626(7:0)
            PIN in2(7:0) XLXN_628(7:0)
            PIN out1(7:0) XLXN_786(7:0)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 7040 5440
        BEGIN INSTANCE XLXI_8 3408 4432 R90
        END INSTANCE
        BEGIN BRANCH XLXN_1(7:0)
            WIRE 1104 3120 1248 3120
        END BRANCH
        BEGIN BRANCH XLXN_2(7:0)
            WIRE 1104 3056 1248 3056
        END BRANCH
        BEGIN BRANCH XLXN_3(7:0)
            WIRE 1104 2992 1248 2992
        END BRANCH
        BEGIN INSTANCE XLXI_21 1376 4352 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_4 608 3984 R0
        END INSTANCE
        BEGIN BRANCH XLXN_281(7:0)
            WIRE 368 3840 608 3840
            WIRE 368 3840 368 5008
            WIRE 368 5008 1856 5008
            WIRE 1632 2992 1696 2992
            WIRE 1696 2992 1856 2992
            WIRE 1856 2992 2112 2992
            WIRE 1856 2992 1856 5008
            WIRE 1696 544 1952 544
            WIRE 1952 544 1952 656
            WIRE 1696 544 1696 2992
        END BRANCH
        BEGIN INSTANCE XLXI_15 1248 3216 R0
        END INSTANCE
        BEGIN BRANCH XLXN_14(7:0)
            WIRE 3888 2928 4624 2928
        END BRANCH
        BEGIN BRANCH XLXN_15(7:0)
            WIRE 3888 2992 4624 2992
        END BRANCH
        BEGIN BRANCH XLXN_18(7:0)
            WIRE 3888 3184 4624 3184
        END BRANCH
        BEGIN BRANCH XLXN_19(7:0)
            WIRE 3888 3248 4624 3248
        END BRANCH
        BEGIN INSTANCE XLXI_14 4624 3680 R0
        END INSTANCE
        BEGIN BRANCH XLXN_69(7:0)
            WIRE 5056 2992 5120 2992
        END BRANCH
        BEGIN BRANCH XLXN_70(7:0)
            WIRE 5056 2928 5120 2928
        END BRANCH
        BEGIN BRANCH XLXN_73(7:0)
            WIRE 4464 1424 5984 1424
            WIRE 5984 1424 5984 2800
            WIRE 5984 2800 6384 2800
            WIRE 4464 1424 4464 3056
            WIRE 4464 3056 4624 3056
            WIRE 5504 2800 5984 2800
        END BRANCH
        BEGIN INSTANCE XLXI_1 6384 3024 R0
        END INSTANCE
        BEGIN BRANCH XLXN_75(7:0)
            WIRE 4432 1392 6016 1392
            WIRE 6016 1392 6016 2928
            WIRE 6016 2928 6384 2928
            WIRE 4432 1392 4432 3696
            WIRE 4432 3696 4624 3696
            WIRE 5504 2928 6016 2928
        END BRANCH
        BEGIN BRANCH XLXN_77(7:0)
            WIRE 4400 1360 6048 1360
            WIRE 6048 1360 6048 2992
            WIRE 6048 2992 6384 2992
            WIRE 4400 1360 4400 3760
            WIRE 4400 3760 4624 3760
            WIRE 5504 2992 6048 2992
        END BRANCH
        BEGIN INSTANCE XLXI_2 2112 3408 R0
        END INSTANCE
        BEGIN BRANCH XLXN_438
            WIRE 560 1296 2272 1296
            WIRE 560 1296 560 3120
            WIRE 560 3120 608 3120
            WIRE 2272 1040 2272 1296
        END BRANCH
        BEGIN BRANCH XLXN_441
            WIRE 528 1264 2208 1264
            WIRE 528 1264 528 3184
            WIRE 528 3184 608 3184
            WIRE 2208 1040 2208 1264
        END BRANCH
        BEGIN BRANCH XLXN_443(1:0)
            WIRE 464 1200 2080 1200
            WIRE 464 1200 464 3312
            WIRE 464 3312 608 3312
            WIRE 2080 1040 2080 1200
        END BRANCH
        BEGIN BRANCH XLXN_444
            WIRE 432 1168 2016 1168
            WIRE 432 1168 432 3376
            WIRE 432 3376 608 3376
            WIRE 2016 1040 2016 1168
        END BRANCH
        BEGIN BRANCH XLXN_445
            WIRE 400 1136 1952 1136
            WIRE 400 1136 400 3440
            WIRE 400 3440 608 3440
            WIRE 1952 1040 1952 1136
        END BRANCH
        BEGIN BRANCH XLXN_446(2:0)
            WIRE 368 1104 1888 1104
            WIRE 368 1104 368 3504
            WIRE 368 3504 608 3504
            WIRE 1888 1040 1888 1104
        END BRANCH
        BEGIN BRANCH XLXN_447(1:0)
            WIRE 336 1072 336 3568
            WIRE 336 3568 608 3568
            WIRE 336 1072 1824 1072
            WIRE 1824 1040 1824 1072
        END BRANCH
        BEGIN BRANCH XLXN_452(1:0)
            WIRE 1920 1424 3040 1424
            WIRE 1920 1424 1920 3440
            WIRE 1920 3440 2112 3440
            WIRE 3040 1040 3040 1424
        END BRANCH
        BEGIN BRANCH XLXN_456
            WIRE 1184 1392 1184 2928
            WIRE 1184 2928 1248 2928
            WIRE 1184 1392 2464 1392
            WIRE 2464 1040 2464 1392
        END BRANCH
        BEGIN BRANCH XLXN_461(1:0)
            WIRE 1984 1488 2848 1488
            WIRE 1984 1488 1984 3312
            WIRE 1984 3312 2112 3312
            WIRE 2848 1040 2848 1488
        END BRANCH
        BEGIN BRANCH XLXN_462(2:0)
            WIRE 1952 1456 2784 1456
            WIRE 1952 1456 1952 3376
            WIRE 1952 3376 2112 3376
            WIRE 2784 1040 2784 1456
        END BRANCH
        BEGIN BRANCH XLXN_465(2:0)
            WIRE 2016 1520 2912 1520
            WIRE 2016 1520 2016 3248
            WIRE 2016 3248 2112 3248
            WIRE 2912 1040 2912 1520
        END BRANCH
        BEGIN BRANCH XLXN_467(1:0)
            WIRE 2048 1552 2976 1552
            WIRE 2048 1552 2048 3184
            WIRE 2048 3184 2112 3184
            WIRE 2976 1040 2976 1552
        END BRANCH
        BEGIN BRANCH XLXN_472
            WIRE 3888 2544 5120 2544
        END BRANCH
        BEGIN BRANCH XLXN_473
            WIRE 3888 2480 5120 2480
        END BRANCH
        BEGIN BRANCH XLXN_478
            WIRE 3888 2288 5120 2288
        END BRANCH
        BEGIN BRANCH XLXN_479
            WIRE 3888 2224 5120 2224
        END BRANCH
        BEGIN BRANCH XLXN_480
            WIRE 3888 2160 5120 2160
        END BRANCH
        BEGIN BRANCH XLXN_481(1:0)
            WIRE 3888 2096 5120 2096
        END BRANCH
        BEGIN BRANCH XLXN_482
            WIRE 5504 2736 6384 2736
        END BRANCH
        BEGIN BRANCH XLXN_483
            WIRE 5504 2672 6384 2672
        END BRANCH
        BEGIN INSTANCE XLXI_9 5120 3024 R0
        END INSTANCE
        BEGIN BRANCH XLXN_487
            WIRE 3360 1040 3360 1168
            WIRE 3360 1168 4528 1168
            WIRE 4528 1168 4528 3376
            WIRE 4528 3376 4624 3376
        END BRANCH
        BEGIN INSTANCE XLXI_22 1792 656 R90
        END INSTANCE
        BEGIN BRANCH XLXN_485
            WIRE 3424 1040 3424 1136
            WIRE 3424 1136 4560 1136
            WIRE 4560 1136 4560 3440
            WIRE 4560 3440 4624 3440
        END BRANCH
        BEGIN BRANCH XLXN_521(3:0)
            WIRE 3888 3632 4624 3632
        END BRANCH
        BEGIN BRANCH XLXN_522(1:0)
            WIRE 3888 3568 4624 3568
        END BRANCH
        BEGIN BRANCH XLXN_523(1:0)
            WIRE 3888 3504 4624 3504
        END BRANCH
        BEGIN BRANCH XLXN_72(7:0)
            WIRE 3888 3120 4368 3120
            WIRE 4368 2672 5120 2672
            WIRE 4368 2672 4368 3120
        END BRANCH
        BEGIN BRANCH XLXN_71(7:0)
            WIRE 3888 3056 4336 3056
            WIRE 4336 2608 5120 2608
            WIRE 4336 2608 4336 3056
        END BRANCH
        BEGIN BRANCH XLXN_130(7:0)
            WIRE 2528 3312 3440 3312
        END BRANCH
        BEGIN BRANCH XLXN_61(7:0)
            WIRE 2528 3248 3440 3248
        END BRANCH
        BEGIN BRANCH XLXN_62(7:0)
            WIRE 2528 3120 3440 3120
        END BRANCH
        BEGIN BRANCH XLXN_63(7:0)
            WIRE 2528 3056 3440 3056
        END BRANCH
        BEGIN BRANCH XLXN_64(7:0)
            WIRE 2528 2992 3440 2992
        END BRANCH
        BEGIN BRANCH XLXN_59(7:0)
            WIRE 2528 2928 3440 2928
        END BRANCH
        BEGIN BRANCH XLXN_490
            WIRE 3184 1232 3616 1232
            WIRE 3184 1232 3184 2544
            WIRE 3184 2544 3440 2544
            WIRE 3616 1040 3616 1232
        END BRANCH
        BEGIN BRANCH XLXN_491
            WIRE 3216 1200 3552 1200
            WIRE 3216 1200 3216 2480
            WIRE 3216 2480 3440 2480
            WIRE 3552 1040 3552 1200
        END BRANCH
        BEGIN BRANCH XLXN_512
            WIRE 3280 1296 3936 1296
            WIRE 3280 1296 3280 2288
            WIRE 3280 2288 3440 2288
            WIRE 3936 1040 3936 1296
        END BRANCH
        BEGIN BRANCH XLXN_515
            WIRE 3312 1328 4000 1328
            WIRE 3312 1328 3312 2224
            WIRE 3312 2224 3440 2224
            WIRE 4000 1040 4000 1328
        END BRANCH
        BEGIN BRANCH XLXN_518
            WIRE 3344 1360 3744 1360
            WIRE 3344 1360 3344 2160
            WIRE 3344 2160 3440 2160
            WIRE 3744 1040 3744 1360
        END BRANCH
        BEGIN BRANCH XLXN_513(1:0)
            WIRE 3376 1392 3808 1392
            WIRE 3376 1392 3376 2096
            WIRE 3376 2096 3440 2096
            WIRE 3808 1040 3808 1392
        END BRANCH
        BEGIN INSTANCE XLXI_20 3440 3344 R0
        END INSTANCE
        BEGIN BRANCH XLXN_541(1:0)
            WIRE 3168 1040 3168 3504
            WIRE 3168 3504 3440 3504
        END BRANCH
        BEGIN BRANCH XLXN_542(1:0)
            WIRE 3232 1040 3232 3568
            WIRE 3232 3568 3440 3568
        END BRANCH
        BEGIN BRANCH XLXN_543(3:0)
            WIRE 3296 1040 3296 3632
            WIRE 3296 3632 3440 3632
        END BRANCH
        BEGIN BRANCH XLXN_545
            WIRE 4192 448 5920 448
            WIRE 5920 448 5920 3632
            WIRE 4192 448 4192 656
            WIRE 5056 3632 5920 3632
        END BRANCH
        BEGIN BRANCH XLXN_546
            WIRE 4256 480 5888 480
            WIRE 5888 480 5888 3568
            WIRE 4256 480 4256 656
            WIRE 5056 3568 5888 3568
        END BRANCH
        BEGIN BRANCH XLXN_547
            WIRE 4320 512 5856 512
            WIRE 5856 512 5856 3504
            WIRE 4320 512 4320 656
            WIRE 5056 3504 5856 3504
        END BRANCH
        BEGIN BRANCH XLXN_548
            WIRE 3136 1424 3136 1840
            WIRE 3136 1840 3440 1840
            WIRE 3136 1424 4064 1424
            WIRE 4064 1040 4064 1424
        END BRANCH
        BEGIN BRANCH XLXN_550
            WIRE 3104 1456 3104 1904
            WIRE 3104 1904 3440 1904
            WIRE 3104 1456 4128 1456
            WIRE 4128 1040 4128 1456
        END BRANCH
        BEGIN BRANCH XLXN_552
            WIRE 3072 1488 4192 1488
            WIRE 3072 1488 3072 1968
            WIRE 3072 1968 3440 1968
            WIRE 4192 1040 4192 1488
        END BRANCH
        BEGIN BRANCH XLXN_554
            WIRE 3040 1520 3040 2032
            WIRE 3040 2032 3440 2032
            WIRE 3040 1520 4256 1520
            WIRE 4256 1040 4256 1520
        END BRANCH
        BEGIN BRANCH XLXN_556(7:0)
            WIRE 4496 1456 4496 3120
            WIRE 4496 3120 4624 3120
            WIRE 4496 1456 5952 1456
            WIRE 5952 1456 5952 2864
            WIRE 5952 2864 6384 2864
            WIRE 5504 2864 5952 2864
        END BRANCH
        BEGIN BRANCH XLXN_557
            WIRE 3888 2032 5120 2032
        END BRANCH
        BEGIN BRANCH XLXN_558
            WIRE 3888 1968 5120 1968
        END BRANCH
        BEGIN BRANCH XLXN_559
            WIRE 3888 1904 5120 1904
        END BRANCH
        BEGIN BRANCH XLXN_560
            WIRE 3888 1840 5120 1840
        END BRANCH
        BEGIN BRANCH XLXN_562
            WIRE 2528 1040 2528 1136
            WIRE 2528 1136 2592 1136
            WIRE 2592 1136 2592 4032
            WIRE 2592 4032 3056 4032
            WIRE 3056 4032 3056 4432
        END BRANCH
        BEGIN BRANCH XLXN_565(1:0)
            WIRE 2720 1040 2720 3936
            WIRE 2720 3936 3312 3936
            WIRE 3312 3936 3312 4432
        END BRANCH
        BEGIN BRANCH XLXN_566(15:0)
            WIRE 432 3648 608 3648
            WIRE 432 3648 432 4944
            WIRE 432 4944 2608 4944
            WIRE 2608 4816 2608 4944
        END BRANCH
        BEGIN BRANCH XLXN_568(15:0)
            WIRE 464 3712 608 3712
            WIRE 464 3712 464 4912
            WIRE 464 4912 2544 4912
            WIRE 2544 4816 2544 4912
        END BRANCH
        BEGIN BRANCH XLXN_573(15:0)
            WIRE 1104 4032 1184 4032
            WIRE 1184 4032 1184 4384
            WIRE 1184 4384 2608 4384
            WIRE 2608 4384 2608 4432
        END BRANCH
        BEGIN BRANCH XLXN_574(7:0)
            WIRE 400 3776 608 3776
            WIRE 400 3776 400 4976
            WIRE 400 4976 1920 4976
            WIRE 1920 4976 2928 4976
            WIRE 1920 3504 2112 3504
            WIRE 1920 3504 1920 4976
            WIRE 2928 4816 2928 4976
        END BRANCH
        BEGIN BRANCH XLXN_575(7:0)
            WIRE 1952 3568 2112 3568
            WIRE 1952 3568 1952 5008
            WIRE 1952 5008 2864 5008
            WIRE 2864 4816 2864 5008
        END BRANCH
        BEGIN BRANCH XLXN_577(7:0)
            WIRE 1984 3632 2112 3632
            WIRE 1984 3632 1984 3696
            WIRE 1984 3696 1984 5040
            WIRE 1984 5040 2672 5040
            WIRE 1984 3696 2112 3696
            WIRE 2672 4816 2672 5040
        END BRANCH
        BEGIN BRANCH XLXN_583(7:0)
            WIRE 2016 3760 2016 5072
            WIRE 2016 5072 2800 5072
            WIRE 2016 3760 2112 3760
            WIRE 2800 4816 2800 5072
        END BRANCH
        BEGIN BRANCH XLXN_584(7:0)
            WIRE 2048 3824 2112 3824
            WIRE 2048 3824 2048 5104
            WIRE 2048 5104 2736 5104
            WIRE 2736 4816 2736 5104
        END BRANCH
        BEGIN BRANCH XLXN_585(7:0)
            WIRE 2528 3760 2560 3760
            WIRE 2560 3760 2560 4352
            WIRE 2560 4352 2672 4352
            WIRE 2672 4352 2672 4432
        END BRANCH
        BEGIN BRANCH XLXN_588
            WIRE 2656 1040 2656 3968
            WIRE 2656 3968 3184 3968
            WIRE 3184 3968 3184 4432
        END BRANCH
        BEGIN BRANCH XLXN_589
            WIRE 2592 1040 2592 1104
            WIRE 2592 1104 2624 1104
            WIRE 2624 1104 2624 4000
            WIRE 2624 4000 3120 4000
            WIRE 3120 4000 3120 4432
        END BRANCH
        BEGIN BRANCH XLXN_590(7:0)
            WIRE 4272 4816 4272 4880
            WIRE 4272 4880 5824 4880
            WIRE 4384 544 5824 544
            WIRE 5824 544 5824 4880
            WIRE 4384 544 4384 656
        END BRANCH
        BEGIN BRANCH XLXN_592(7:0)
            WIRE 4272 3952 5760 3952
            WIRE 4272 3952 4272 4432
            WIRE 4448 1040 4448 1104
            WIRE 4448 1104 5760 1104
            WIRE 5760 1104 5760 3952
        END BRANCH
        BEGIN BRANCH XLXN_593
            WIRE 3952 3920 5792 3920
            WIRE 3952 3920 3952 4432
            WIRE 4512 1040 4512 1072
            WIRE 4512 1072 5792 1072
            WIRE 5792 1072 5792 3920
        END BRANCH
        BEGIN BRANCH XLXN_594(7:0)
            WIRE 4784 4384 4848 4384
            WIRE 4848 4384 4848 4432
            WIRE 4784 4384 4784 4432
            WIRE 4848 3984 6848 3984
            WIRE 4848 3984 4848 4384
            WIRE 6816 3504 6848 3504
            WIRE 6848 3504 6848 3984
        END BRANCH
        BEGIN BRANCH XLXN_597(7:0)
            WIRE 4336 4016 4336 4432
            WIRE 4336 4016 6880 4016
            WIRE 6816 3440 6880 3440
            WIRE 6880 3440 6880 4016
        END BRANCH
        BEGIN BRANCH XLXN_599(7:0)
            WIRE 4144 4048 6912 4048
            WIRE 4144 4048 4144 4432
            WIRE 6816 3376 6912 3376
            WIRE 6912 3376 6912 4048
        END BRANCH
        BEGIN BRANCH XLXN_600(7:0)
            WIRE 4208 4080 6944 4080
            WIRE 4208 4080 4208 4432
            WIRE 6816 3312 6944 3312
            WIRE 6944 3312 6944 4080
        END BRANCH
        BEGIN BRANCH XLXN_601(1:0)
            WIRE 3568 4112 5552 4112
            WIRE 3568 4112 3568 4432
            WIRE 5504 2352 5552 2352
            WIRE 5552 2352 5552 4112
        END BRANCH
        BEGIN BRANCH XLXN_603
            WIRE 3824 4144 5584 4144
            WIRE 3824 4144 3824 4432
            WIRE 5504 2288 5584 2288
            WIRE 5584 2288 5584 4144
        END BRANCH
        BEGIN BRANCH XLXN_604
            WIRE 3888 4176 5616 4176
            WIRE 3888 4176 3888 4432
            WIRE 5504 2224 5616 2224
            WIRE 5616 2224 5616 4176
        END BRANCH
        BEGIN BRANCH XLXN_605
            WIRE 3248 4208 5648 4208
            WIRE 3248 4208 3248 4432
            WIRE 5504 2160 5648 2160
            WIRE 5648 2160 5648 4208
        END BRANCH
        BEGIN BRANCH XLXN_606(1:0)
            WIRE 3376 4240 5680 4240
            WIRE 3376 4240 3376 4432
            WIRE 5504 2096 5680 2096
            WIRE 5680 2096 5680 4240
        END BRANCH
        BEGIN BRANCH XLXN_607
            WIRE 3760 4272 5712 4272
            WIRE 3760 4272 3760 4432
            WIRE 5504 2032 5712 2032
            WIRE 5712 2032 5712 4272
        END BRANCH
        BEGIN BRANCH XLXN_608
            WIRE 3440 3824 3440 4432
            WIRE 3440 3824 6080 3824
            WIRE 5504 1968 6080 1968
            WIRE 6080 1968 6080 3824
        END BRANCH
        BEGIN BRANCH XLXN_610
            WIRE 4016 3856 6112 3856
            WIRE 4016 3856 4016 4432
            WIRE 5504 1904 6112 1904
            WIRE 6112 1904 6112 3856
        END BRANCH
        BEGIN BRANCH XLXN_611
            WIRE 4080 3888 6144 3888
            WIRE 4080 3888 4080 4432
            WIRE 5504 1840 6144 1840
            WIRE 6144 1840 6144 3888
        END BRANCH
        BEGIN BRANCH XLXN_613(15:0)
            WIRE 1104 3968 1216 3968
            WIRE 1216 3968 1216 4320
            WIRE 1216 4320 1376 4320
        END BRANCH
        BEGIN BRANCH XLXN_615(1:0)
            WIRE 3248 1264 3248 2352
            WIRE 3248 2352 3440 2352
            WIRE 3248 1264 3872 1264
            WIRE 3872 1040 3872 1264
        END BRANCH
        BEGIN BRANCH XLXN_617(1:0)
            WIRE 3888 2352 5120 2352
        END BRANCH
        BEGIN BRANCH XLXN_618(4:0)
            WIRE 3888 3312 4624 3312
        END BRANCH
        BEGIN BRANCH XLXN_619(4:0)
            WIRE 2528 3184 3440 3184
        END BRANCH
        BEGIN BRANCH Reset
            WIRE 160 3056 576 3056
            WIRE 576 3056 608 3056
            WIRE 576 640 2016 640
            WIRE 2016 640 2016 656
            WIRE 576 640 576 2624
            WIRE 576 2624 576 2864
            WIRE 576 2864 576 3056
            WIRE 576 2864 1232 2864
            WIRE 1232 2864 1248 2864
            WIRE 1232 2864 1232 3984
            WIRE 1232 3984 1232 4128
            WIRE 1232 4128 1376 4128
            WIRE 1232 3984 2864 3984
            WIRE 2864 3984 2864 4432
            WIRE 576 2624 1680 2624
            WIRE 1680 2624 1680 2928
            WIRE 1680 2928 2112 2928
            WIRE 1680 2624 2560 2624
            WIRE 2560 2624 2560 2736
            WIRE 2560 2736 3440 2736
            WIRE 2560 1776 2560 2624
            WIRE 2560 1776 3952 1776
            WIRE 3952 1776 3952 2864
            WIRE 3952 2864 4624 2864
            WIRE 2864 3904 2864 3984
            WIRE 2864 3904 5104 3904
            WIRE 5104 3248 5104 3904
            WIRE 5104 3248 5120 3248
        END BRANCH
        BEGIN BRANCH Clock
            WIRE 160 2992 272 2992
            WIRE 272 2992 608 2992
            WIRE 272 464 2080 464
            WIRE 2080 464 2080 656
            WIRE 272 464 272 2672
            WIRE 272 2672 272 2800
            WIRE 272 2800 272 2992
            WIRE 272 2800 1248 2800
            WIRE 272 2672 2928 2672
            WIRE 2928 2672 3440 2672
            WIRE 2928 2672 2928 3872
            WIRE 2928 3872 2928 4016
            WIRE 2928 4016 2928 4432
            WIRE 2928 3872 5088 3872
            WIRE 1312 4016 1312 4192
            WIRE 1312 4192 1376 4192
            WIRE 1312 4016 2928 4016
            WIRE 5088 3184 5088 3872
            WIRE 5088 3184 5120 3184
        END BRANCH
        BEGIN BRANCH P3_in(7:0)
            WIRE 4464 4288 4464 4432
            WIRE 4464 4288 6288 4288
        END BRANCH
        BEGIN BRANCH P2_in(7:0)
            WIRE 4528 4304 4528 4432
            WIRE 4528 4304 6128 4304
            WIRE 6128 4304 6128 4336
            WIRE 6128 4336 6288 4336
        END BRANCH
        BEGIN BRANCH P1_in(7:0)
            WIRE 4592 4320 4592 4432
            WIRE 4592 4320 6112 4320
            WIRE 6112 4320 6112 4384
            WIRE 6112 4384 6288 4384
        END BRANCH
        BEGIN BRANCH P0_in(7:0)
            WIRE 4656 4336 4656 4432
            WIRE 4656 4336 6096 4336
            WIRE 6096 4336 6096 4432
            WIRE 6096 4432 6288 4432
        END BRANCH
        BEGIN BRANCH P0_out(7:0)
            WIRE 3920 4816 3920 4976
            WIRE 3920 4976 4048 4976
        END BRANCH
        BEGIN BRANCH P1_out(7:0)
            WIRE 3856 4816 3856 5024
            WIRE 3856 5024 4048 5024
        END BRANCH
        BEGIN BRANCH P2_out(7:0)
            WIRE 3792 4816 3792 5072
            WIRE 3792 5072 4048 5072
        END BRANCH
        BEGIN BRANCH P3_out(7:0)
            WIRE 3728 4816 3728 5120
            WIRE 3728 5120 4048 5120
        END BRANCH
        BEGIN BRANCH XLXN_626(7:0)
            WIRE 1328 4656 1824 4656
            WIRE 1824 2832 2336 2832
            WIRE 1824 2832 1824 4656
            WIRE 2336 1040 2336 2832
        END BRANCH
        BEGIN INSTANCE XLXI_25 1328 4560 R180
        END INSTANCE
        BEGIN BRANCH XLXN_627
            WIRE 1152 1360 1152 4256
            WIRE 1152 4256 1376 4256
            WIRE 1152 4256 1152 4432
            WIRE 1152 4432 1488 4432
            WIRE 1488 4432 1488 4720
            WIRE 1152 1360 2400 1360
            WIRE 1328 4720 1488 4720
            WIRE 2400 1040 2400 1360
        END BRANCH
        BEGIN BRANCH XLXN_628(7:0)
            WIRE 1328 4592 1808 4592
            WIRE 1760 4128 1808 4128
            WIRE 1808 4128 1808 4592
        END BRANCH
        BEGIN BRANCH int0
            WIRE 2848 624 2848 656
            WIRE 2848 624 3088 624
        END BRANCH
        BEGIN BRANCH int1
            WIRE 2784 576 2784 656
            WIRE 2784 576 3088 576
        END BRANCH
        BEGIN BRANCH wr
            WIRE 2720 528 2720 656
            WIRE 2720 528 3088 528
        END BRANCH
        BEGIN BRANCH rd
            WIRE 2656 480 2656 656
            WIRE 2656 480 3088 480
        END BRANCH
        IOMARKER 6288 4288 P3_in(7:0) R0 28
        IOMARKER 6288 4336 P2_in(7:0) R0 28
        IOMARKER 6288 4384 P1_in(7:0) R0 28
        IOMARKER 6288 4432 P0_in(7:0) R0 28
        IOMARKER 4048 4976 P0_out(7:0) R0 28
        IOMARKER 4048 5024 P1_out(7:0) R0 28
        IOMARKER 4048 5072 P2_out(7:0) R0 28
        IOMARKER 4048 5120 P3_out(7:0) R0 28
        IOMARKER 3088 480 rd R0 28
        IOMARKER 3088 528 wr R0 28
        IOMARKER 3088 576 int1 R0 28
        IOMARKER 3088 624 int0 R0 28
        BEGIN BRANCH XLXN_786(7:0)
            WIRE 496 4032 496 4720
            WIRE 496 4720 944 4720
            WIRE 496 4032 608 4032
        END BRANCH
        BEGIN BRANCH XLXN_788(1:0)
            WIRE 496 1232 2144 1232
            WIRE 496 1232 496 3248
            WIRE 496 3248 608 3248
            WIRE 2144 1040 2144 1232
        END BRANCH
        BEGIN BRANCH XLXN_791(7:0)
            WIRE 304 3968 608 3968
            WIRE 304 3968 304 5072
            WIRE 304 5072 1888 5072
            WIRE 1632 3120 1760 3120
            WIRE 1760 3120 1888 3120
            WIRE 1888 3120 2112 3120
            WIRE 1888 3120 1888 5072
            WIRE 1760 608 1824 608
            WIRE 1824 608 1824 656
            WIRE 1760 608 1760 3120
        END BRANCH
        BEGIN BRANCH XLXN_798(7:0)
            WIRE 336 3904 608 3904
            WIRE 336 3904 336 5040
            WIRE 336 5040 1872 5040
            WIRE 1632 3056 1728 3056
            WIRE 1728 3056 1872 3056
            WIRE 1872 3056 2112 3056
            WIRE 1872 3056 1872 5040
            WIRE 1728 576 1888 576
            WIRE 1888 576 1888 656
            WIRE 1728 576 1728 3056
        END BRANCH
        BEGIN BRANCH XLXN_799(1:0)
            WIRE 240 432 240 3072
            WIRE 240 3072 240 4432
            WIRE 240 4432 1136 4432
            WIRE 240 432 2144 432
            WIRE 2144 432 2144 656
            WIRE 1104 4096 1136 4096
            WIRE 1136 4096 1136 4432
        END BRANCH
        IOMARKER 160 3056 Reset R180 28
        IOMARKER 160 2992 Clock R180 28
    END SHEET
END SCHEMATIC
