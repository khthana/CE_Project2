library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity MUX7 is
	port (  in1		: in std_logic_vector(7 downto 0);		-- from	Acc.
           in2		: in std_logic_vector(7 downto 0);		-- from	Int. Mem.
           in3		: in std_logic_vector(7 downto 0);		-- from	psw
           in4		: in std_logic_vector(7 downto 0); 		-- from	B
           in5		: in std_logic_vector(7 downto 0); 		-- from	p0
           in6		: in std_logic_vector(7 downto 0); 		-- from	p1
           in7		: in std_logic_vector(7 downto 0); 		-- from	p2
           in8		: in std_logic_vector(7 downto 0); 		-- from	p3
           in9		: in std_logic_vector(7 downto 0); 		-- from	sp
           in10	: in std_logic_vector(7 downto 0); 		-- from	DPH
           in11	: in std_logic_vector(7 downto 0); 		-- from	DPL
           sel		: in std_logic_vector(7 downto 0);		-- from	Inst. Byte 2
           out1 	: out std_logic_vector(7 downto 0));	-- to		MUX9
end MUX7;

architecture RTL of MUX7 is
begin
	process(in1,in2,in3,in4,in5,in6,in7,in8,in9,in10,in11,sel)
	begin
		case sel is
			when "11100000" => out1 <= in1; 	 --R_A
			when "11010000" => out1 <= in3;   --psw
			when "11110000" => out1 <= in4; 	 --R_B
			when "10000000" => out1 <= in5;   --p0
			when "10010000" => out1 <= in6;   --p1
			when "10100000" => out1 <= in7;   --p2
			when "10110000" => out1 <= in8;   --p3
			when "10000001" => out1 <= in9;   --sp
			when "10000010" => out1 <= in10;  --DPL
			when "10000011" => out1 <= in11;  --DPH
			when others => out1 <= in2;
		end case;
	end process;
end RTL;
