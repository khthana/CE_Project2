library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sign_extender is
    Port ( in1 : in std_logic_vector(7 downto 0);
           out1 : out std_logic_vector(15 downto 0));
end sign_extender;

architecture rtl of sign_extender is
begin
     	Process(in1)
			variable v1 : SIGNED (15 downto 0);
		begin
        if( in1(7) = '1' ) then
            v1 := SIGNED("11111111" & in1);
        else
            v1 := SIGNED("00000000" & in1);
        end if;
        out1 <= STD_LOGIC_vector(v1);
	end process;

end rtl;
