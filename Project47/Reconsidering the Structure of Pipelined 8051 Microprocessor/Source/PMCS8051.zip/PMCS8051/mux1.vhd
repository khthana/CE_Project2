library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux1 is
    Port ( in1 : in std_logic_vector(15 downto 0);
           in2 : in std_logic_vector(15 downto 0);
           in3 : in std_logic_vector(15 downto 0);
           sel : in std_logic_vector(1 downto 0);
           out1 : out std_logic_vector(15 downto 0));
end mux1;

architecture rtl of mux1 is
begin
	process(in1,in2,in3,sel)
	begin
		case  sel is
		when "00" => out1 <= in1;
		when "01" => out1 <= in2;
		when "10" => out1 <= in3;
		when others => out1 <= in1;
		end case;
	end process;
end rtl;
