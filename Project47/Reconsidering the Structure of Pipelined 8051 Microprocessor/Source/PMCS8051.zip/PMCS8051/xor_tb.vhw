-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Sat Mar 19 09:47:37 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY xor_tb IS
END xor_tb;

ARCHITECTURE testbench_arch OF xor_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT xor_test
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			out1 : Out  std_logic
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out1 : std_logic;

BEGIN
	UUT : xor_test
	PORT MAP (
		in1 => in1,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ps; -- Time=10 ps
		in1 <= transport std_logic_vector'("00010010"); --12
		-- --------------------
		WAIT FOR 10 ps; -- Time=20 ps
		in1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ps; -- Time=30 ps
		in1 <= transport std_logic_vector'("11011111"); --DF
		-- --------------------
		WAIT FOR 10 ps; -- Time=40 ps
		in1 <= transport std_logic_vector'("10000100"); --84
		-- --------------------
		WAIT FOR 10 ps; -- Time=50 ps
		in1 <= transport std_logic_vector'("00010101"); --15
		-- --------------------
		WAIT FOR 10 ps; -- Time=60 ps
		in1 <= transport std_logic_vector'("11110010"); --F2
		-- --------------------
		WAIT FOR 10 ps; -- Time=70 ps
		in1 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ps; -- Time=80 ps
		in1 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 10 ps; -- Time=90 ps
		in1 <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 10 ps; -- Time=100 ps
		in1 <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 10 ps; -- Time=110 ps
		in1 <= transport std_logic_vector'("01111111"); --7F
		-- --------------------
		WAIT FOR 10 ps; -- Time=120 ps
		in1 <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 10 ps; -- Time=130 ps
		in1 <= transport std_logic_vector'("10101010"); --AA
		-- --------------------
		WAIT FOR 10 ps; -- Time=140 ps
		in1 <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 10 ps; -- Time=150 ps
		in1 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ps; -- Time=160 ps
		in1 <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 10 ps; -- Time=170 ps
		in1 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ps; -- Time=180 ps
		in1 <= transport std_logic_vector'("10111011"); --BB
		-- --------------------
		WAIT FOR 10 ps; -- Time=190 ps
		in1 <= transport std_logic_vector'("10110011"); --B3
		-- --------------------
		WAIT FOR 10 ps; -- Time=200 ps
		in1 <= transport std_logic_vector'("10000110"); --86
		-- --------------------
		WAIT FOR 10 ps; -- Time=210 ps
		in1 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 10 ps; -- Time=220 ps
		in1 <= transport std_logic_vector'("01111110"); --7E
		-- --------------------
		WAIT FOR 10 ps; -- Time=230 ps
		in1 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 10 ps; -- Time=240 ps
		in1 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 10 ps; -- Time=250 ps
		in1 <= transport std_logic_vector'("10110001"); --B1
		-- --------------------
		WAIT FOR 10 ps; -- Time=260 ps
		in1 <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 10 ps; -- Time=270 ps
		in1 <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 10 ps; -- Time=280 ps
		in1 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 10 ps; -- Time=290 ps
		in1 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 10 ps; -- Time=300 ps
		in1 <= transport std_logic_vector'("11000011"); --C3
		-- --------------------
		WAIT FOR 10 ps; -- Time=310 ps
		in1 <= transport std_logic_vector'("01111010"); --7A
		-- --------------------
		WAIT FOR 10 ps; -- Time=320 ps
		in1 <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 10 ps; -- Time=330 ps
		in1 <= transport std_logic_vector'("10111010"); --BA
		-- --------------------
		WAIT FOR 10 ps; -- Time=340 ps
		in1 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 10 ps; -- Time=350 ps
		in1 <= transport std_logic_vector'("11011100"); --DC
		-- --------------------
		WAIT FOR 10 ps; -- Time=360 ps
		in1 <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 10 ps; -- Time=370 ps
		in1 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 10 ps; -- Time=380 ps
		in1 <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 10 ps; -- Time=390 ps
		in1 <= transport std_logic_vector'("11100011"); --E3
		-- --------------------
		WAIT FOR 10 ps; -- Time=400 ps
		in1 <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 10 ps; -- Time=410 ps
		in1 <= transport std_logic_vector'("11011000"); --D8
		-- --------------------
		WAIT FOR 10 ps; -- Time=420 ps
		in1 <= transport std_logic_vector'("11001011"); --CB
		-- --------------------
		WAIT FOR 10 ps; -- Time=430 ps
		in1 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 10 ps; -- Time=440 ps
		in1 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 10 ps; -- Time=450 ps
		in1 <= transport std_logic_vector'("11001111"); --CF
		-- --------------------
		WAIT FOR 10 ps; -- Time=460 ps
		in1 <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 10 ps; -- Time=470 ps
		in1 <= transport std_logic_vector'("11100001"); --E1
		-- --------------------
		WAIT FOR 10 ps; -- Time=480 ps
		in1 <= transport std_logic_vector'("01101011"); --6B
		-- --------------------
		WAIT FOR 10 ps; -- Time=490 ps
		in1 <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 10 ps; -- Time=500 ps
		in1 <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 10 ps; -- Time=510 ps
		in1 <= transport std_logic_vector'("01011000"); --58
		-- --------------------
		WAIT FOR 10 ps; -- Time=520 ps
		in1 <= transport std_logic_vector'("10000101"); --85
		-- --------------------
		WAIT FOR 10 ps; -- Time=530 ps
		in1 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 10 ps; -- Time=540 ps
		in1 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 10 ps; -- Time=550 ps
		in1 <= transport std_logic_vector'("01110100"); --74
		-- --------------------
		WAIT FOR 10 ps; -- Time=560 ps
		in1 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 20 ps; -- Time=580 ps
		in1 <= transport std_logic_vector'("11010100"); --D4
		-- --------------------
		WAIT FOR 10 ps; -- Time=590 ps
		in1 <= transport std_logic_vector'("01110101"); --75
		-- --------------------
		WAIT FOR 10 ps; -- Time=600 ps
		in1 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 10 ps; -- Time=610 ps
		in1 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 10 ps; -- Time=620 ps
		in1 <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 10 ps; -- Time=630 ps
		in1 <= transport std_logic_vector'("10011100"); --9C
		-- --------------------
		WAIT FOR 10 ps; -- Time=640 ps
		in1 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 10 ps; -- Time=650 ps
		in1 <= transport std_logic_vector'("10110001"); --B1
		-- --------------------
		WAIT FOR 10 ps; -- Time=660 ps
		in1 <= transport std_logic_vector'("11011000"); --D8
		-- --------------------
		WAIT FOR 10 ps; -- Time=670 ps
		in1 <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 10 ps; -- Time=680 ps
		in1 <= transport std_logic_vector'("10000010"); --82
		-- --------------------
		WAIT FOR 10 ps; -- Time=690 ps
		in1 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 10 ps; -- Time=700 ps
		in1 <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 10 ps; -- Time=710 ps
		in1 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 10 ps; -- Time=720 ps
		in1 <= transport std_logic_vector'("10100111"); --A7
		-- --------------------
		WAIT FOR 10 ps; -- Time=730 ps
		in1 <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 10 ps; -- Time=740 ps
		in1 <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 10 ps; -- Time=750 ps
		in1 <= transport std_logic_vector'("01110000"); --70
		-- --------------------
		WAIT FOR 10 ps; -- Time=760 ps
		in1 <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 10 ps; -- Time=770 ps
		in1 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 10 ps; -- Time=780 ps
		in1 <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 10 ps; -- Time=790 ps
		in1 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 10 ps; -- Time=800 ps
		in1 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 10 ps; -- Time=810 ps
		in1 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 10 ps; -- Time=820 ps
		in1 <= transport std_logic_vector'("11011111"); --DF
		-- --------------------
		WAIT FOR 10 ps; -- Time=830 ps
		in1 <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 10 ps; -- Time=840 ps
		in1 <= transport std_logic_vector'("11010100"); --D4
		-- --------------------
		WAIT FOR 10 ps; -- Time=850 ps
		in1 <= transport std_logic_vector'("10010111"); --97
		-- --------------------
		WAIT FOR 10 ps; -- Time=860 ps
		in1 <= transport std_logic_vector'("11110110"); --F6
		-- --------------------
		WAIT FOR 10 ps; -- Time=870 ps
		in1 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 10 ps; -- Time=880 ps
		in1 <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 10 ps; -- Time=890 ps
		in1 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 10 ps; -- Time=900 ps
		in1 <= transport std_logic_vector'("11100010"); --E2
		-- --------------------
		WAIT FOR 10 ps; -- Time=910 ps
		in1 <= transport std_logic_vector'("10111110"); --BE
		-- --------------------
		WAIT FOR 10 ps; -- Time=920 ps
		in1 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 10 ps; -- Time=930 ps
		in1 <= transport std_logic_vector'("11111110"); --FE
		-- --------------------
		WAIT FOR 10 ps; -- Time=940 ps
		in1 <= transport std_logic_vector'("11100011"); --E3
		-- --------------------
		WAIT FOR 10 ps; -- Time=950 ps
		in1 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 10 ps; -- Time=960 ps
		in1 <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 10 ps; -- Time=970 ps
		in1 <= transport std_logic_vector'("11111001"); --F9
		-- --------------------
		WAIT FOR 10 ps; -- Time=980 ps
		in1 <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 10 ps; -- Time=990 ps
		in1 <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 15 ps; -- Time=1005 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION xor_test_cfg OF xor_tb IS
	FOR testbench_arch
	END FOR;
END xor_test_cfg;
