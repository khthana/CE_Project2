-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 22 21:50:45 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY psw_reg_tb IS
END psw_reg_tb;

ARCHITECTURE testbench_arch OF psw_reg_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT psw_reg
		PORT (
			data_in : In  std_logic_vector (7 DOWNTO 0);
			ACC_in : In  std_logic_vector (7 DOWNTO 0);
			data_out : Out  std_logic_vector (7 DOWNTO 0);
			Carry_in : In  std_logic;
			OverFlow_in : In  std_logic;
			AUX_C_in : In  std_logic;
			load_in : In  std_logic;
			reset : In  std_logic;
			clock : In  std_logic
		);
	END COMPONENT;

	SIGNAL data_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL ACC_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL data_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL Carry_in : std_logic;
	SIGNAL OverFlow_in : std_logic;
	SIGNAL AUX_C_in : std_logic;
	SIGNAL load_in : std_logic;
	SIGNAL reset : std_logic;
	SIGNAL clock : std_logic;

BEGIN
	UUT : psw_reg
	PORT MAP (
		data_in => data_in,
		ACC_in => ACC_in,
		data_out => data_out,
		Carry_in => Carry_in,
		OverFlow_in => OverFlow_in,
		AUX_C_in => AUX_C_in,
		load_in => load_in,
		reset => reset,
		clock => clock
	);

	PROCESS -- clock process for clock,
	BEGIN
		CLOCK_LOOP : LOOP
		clock <= transport '0';
		WAIT FOR 10 ps;
		clock <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clock <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clock
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_data_out(
			next_data_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out /= next_data_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps data_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		data_in <= transport std_logic_vector'("01010001"); --51
		ACC_in <= transport std_logic_vector'("01010000"); --50
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		load_in <= transport '0';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		data_in <= transport std_logic_vector'("01010110"); --56
		ACC_in <= transport std_logic_vector'("00111011"); --3B
		Carry_in <= transport '1';
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		data_in <= transport std_logic_vector'("11110010"); --F2
		ACC_in <= transport std_logic_vector'("11000101"); --C5
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		data_in <= transport std_logic_vector'("01000010"); --42
		ACC_in <= transport std_logic_vector'("01100010"); --62
		Carry_in <= transport '0';
		OverFlow_in <= transport '0';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		data_in <= transport std_logic_vector'("10100010"); --A2
		ACC_in <= transport std_logic_vector'("11000001"); --C1
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		data_in <= transport std_logic_vector'("10110001"); --B1
		ACC_in <= transport std_logic_vector'("11010011"); --D3
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		data_in <= transport std_logic_vector'("01001011"); --4B
		ACC_in <= transport std_logic_vector'("11001010"); --CA
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		data_in <= transport std_logic_vector'("10001101"); --8D
		ACC_in <= transport std_logic_vector'("00010111"); --17
		Carry_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		data_in <= transport std_logic_vector'("11010100"); --D4
		ACC_in <= transport std_logic_vector'("01101010"); --6A
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		data_in <= transport std_logic_vector'("10111101"); --BD
		ACC_in <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		data_in <= transport std_logic_vector'("00100101"); --25
		ACC_in <= transport std_logic_vector'("00101000"); --28
		Carry_in <= transport '1';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		data_in <= transport std_logic_vector'("00101001"); --29
		ACC_in <= transport std_logic_vector'("00110101"); --35
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		data_in <= transport std_logic_vector'("00100110"); --26
		ACC_in <= transport std_logic_vector'("10001100"); --8C
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		data_in <= transport std_logic_vector'("10111001"); --B9
		ACC_in <= transport std_logic_vector'("00100000"); --20
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		data_in <= transport std_logic_vector'("10111111"); --BF
		ACC_in <= transport std_logic_vector'("00011111"); --1F
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		data_in <= transport std_logic_vector'("01010101"); --55
		ACC_in <= transport std_logic_vector'("11111100"); --FC
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		data_in <= transport std_logic_vector'("11011000"); --D8
		ACC_in <= transport std_logic_vector'("01101000"); --68
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		data_in <= transport std_logic_vector'("11100101"); --E5
		ACC_in <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		data_in <= transport std_logic_vector'("01011001"); --59
		ACC_in <= transport std_logic_vector'("11110000"); --F0
		Carry_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		data_in <= transport std_logic_vector'("01010001"); --51
		ACC_in <= transport std_logic_vector'("10101101"); --AD
		Carry_in <= transport '1';
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		data_in <= transport std_logic_vector'("00101010"); --2A
		ACC_in <= transport std_logic_vector'("00111101"); --3D
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		data_in <= transport std_logic_vector'("10000001"); --81
		ACC_in <= transport std_logic_vector'("10010001"); --91
		OverFlow_in <= transport '1';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		data_in <= transport std_logic_vector'("00110011"); --33
		ACC_in <= transport std_logic_vector'("11011001"); --D9
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '0';
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		data_in <= transport std_logic_vector'("01011101"); --5D
		ACC_in <= transport std_logic_vector'("10000111"); --87
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		ACC_in <= transport std_logic_vector'("01001100"); --4C
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		data_in <= transport std_logic_vector'("11001110"); --CE
		ACC_in <= transport std_logic_vector'("00011000"); --18
		Carry_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		data_in <= transport std_logic_vector'("10001110"); --8E
		ACC_in <= transport std_logic_vector'("00011100"); --1C
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		data_in <= transport std_logic_vector'("10111010"); --BA
		ACC_in <= transport std_logic_vector'("11001010"); --CA
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		data_in <= transport std_logic_vector'("10101111"); --AF
		ACC_in <= transport std_logic_vector'("11010011"); --D3
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		data_in <= transport std_logic_vector'("00001011"); --B
		ACC_in <= transport std_logic_vector'("00101000"); --28
		OverFlow_in <= transport '0';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		data_in <= transport std_logic_vector'("10101001"); --A9
		ACC_in <= transport std_logic_vector'("11111000"); --F8
		Carry_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		data_in <= transport std_logic_vector'("10100111"); --A7
		ACC_in <= transport std_logic_vector'("10110111"); --B7
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		data_in <= transport std_logic_vector'("01100010"); --62
		ACC_in <= transport std_logic_vector'("00010100"); --14
		Carry_in <= transport '0';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		data_in <= transport std_logic_vector'("01111000"); --78
		ACC_in <= transport std_logic_vector'("00000001"); --1
		AUX_C_in <= transport '0';
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		data_in <= transport std_logic_vector'("11000100"); --C4
		ACC_in <= transport std_logic_vector'("10101110"); --AE
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		data_in <= transport std_logic_vector'("01100100"); --64
		ACC_in <= transport std_logic_vector'("10001101"); --8D
		Carry_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		data_in <= transport std_logic_vector'("10110110"); --B6
		ACC_in <= transport std_logic_vector'("01001110"); --4E
		OverFlow_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		data_in <= transport std_logic_vector'("01010101"); --55
		ACC_in <= transport std_logic_vector'("11100011"); --E3
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		data_in <= transport std_logic_vector'("00011111"); --1F
		ACC_in <= transport std_logic_vector'("01111101"); --7D
		Carry_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		data_in <= transport std_logic_vector'("00110010"); --32
		ACC_in <= transport std_logic_vector'("10001100"); --8C
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '0';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		data_in <= transport std_logic_vector'("11101001"); --E9
		ACC_in <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		data_in <= transport std_logic_vector'("11100011"); --E3
		ACC_in <= transport std_logic_vector'("00001111"); --F
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		data_in <= transport std_logic_vector'("11111011"); --FB
		ACC_in <= transport std_logic_vector'("10100101"); --A5
		Carry_in <= transport '0';
		OverFlow_in <= transport '0';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4300 ps
		data_in <= transport std_logic_vector'("01001111"); --4F
		ACC_in <= transport std_logic_vector'("11110100"); --F4
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4400 ps
		data_in <= transport std_logic_vector'("00111101"); --3D
		ACC_in <= transport std_logic_vector'("10101110"); --AE
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '1';
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4500 ps
		data_in <= transport std_logic_vector'("01100000"); --60
		ACC_in <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 100 ps; -- Time=4600 ps
		data_in <= transport std_logic_vector'("10010111"); --97
		ACC_in <= transport std_logic_vector'("01100110"); --66
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4700 ps
		data_in <= transport std_logic_vector'("11111101"); --FD
		ACC_in <= transport std_logic_vector'("00000110"); --6
		Carry_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4800 ps
		data_in <= transport std_logic_vector'("11110001"); --F1
		ACC_in <= transport std_logic_vector'("01010100"); --54
		Carry_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4900 ps
		data_in <= transport std_logic_vector'("00001110"); --E
		ACC_in <= transport std_logic_vector'("01000010"); --42
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5000 ps
		data_in <= transport std_logic_vector'("00110011"); --33
		ACC_in <= transport std_logic_vector'("00000000"); --0
		OverFlow_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5100 ps
		data_in <= transport std_logic_vector'("01111100"); --7C
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5200 ps
		data_in <= transport std_logic_vector'("01000101"); --45
		ACC_in <= transport std_logic_vector'("11110011"); --F3
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5300 ps
		data_in <= transport std_logic_vector'("00101101"); --2D
		ACC_in <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 100 ps; -- Time=5400 ps
		data_in <= transport std_logic_vector'("00001111"); --F
		ACC_in <= transport std_logic_vector'("10110100"); --B4
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5500 ps
		data_in <= transport std_logic_vector'("00001010"); --A
		ACC_in <= transport std_logic_vector'("00100100"); --24
		Carry_in <= transport '1';
		load_in <= transport '0';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5600 ps
		data_in <= transport std_logic_vector'("01111010"); --7A
		ACC_in <= transport std_logic_vector'("11001011"); --CB
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5700 ps
		data_in <= transport std_logic_vector'("11111011"); --FB
		ACC_in <= transport std_logic_vector'("10011010"); --9A
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5800 ps
		data_in <= transport std_logic_vector'("01101100"); --6C
		ACC_in <= transport std_logic_vector'("11000001"); --C1
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5900 ps
		data_in <= transport std_logic_vector'("11101001"); --E9
		ACC_in <= transport std_logic_vector'("10110010"); --B2
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6000 ps
		data_in <= transport std_logic_vector'("11001110"); --CE
		ACC_in <= transport std_logic_vector'("00011101"); --1D
		Carry_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6100 ps
		data_in <= transport std_logic_vector'("10111010"); --BA
		ACC_in <= transport std_logic_vector'("11110100"); --F4
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6200 ps
		data_in <= transport std_logic_vector'("10001001"); --89
		ACC_in <= transport std_logic_vector'("01100111"); --67
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6300 ps
		data_in <= transport std_logic_vector'("01011000"); --58
		ACC_in <= transport std_logic_vector'("11101000"); --E8
		Carry_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6400 ps
		data_in <= transport std_logic_vector'("10000011"); --83
		ACC_in <= transport std_logic_vector'("00101000"); --28
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6500 ps
		data_in <= transport std_logic_vector'("10101001"); --A9
		ACC_in <= transport std_logic_vector'("00010111"); --17
		AUX_C_in <= transport '1';
		load_in <= transport '1';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6600 ps
		data_in <= transport std_logic_vector'("10100110"); --A6
		ACC_in <= transport std_logic_vector'("11100110"); --E6
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6700 ps
		data_in <= transport std_logic_vector'("10010111"); --97
		ACC_in <= transport std_logic_vector'("00001000"); --8
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6800 ps
		data_in <= transport std_logic_vector'("11011001"); --D9
		ACC_in <= transport std_logic_vector'("00101100"); --2C
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6900 ps
		data_in <= transport std_logic_vector'("00001001"); --9
		ACC_in <= transport std_logic_vector'("01000011"); --43
		Carry_in <= transport '0';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7000 ps
		data_in <= transport std_logic_vector'("00000011"); --3
		ACC_in <= transport std_logic_vector'("01111111"); --7F
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7100 ps
		data_in <= transport std_logic_vector'("11100110"); --E6
		ACC_in <= transport std_logic_vector'("01010001"); --51
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7200 ps
		data_in <= transport std_logic_vector'("00001110"); --E
		ACC_in <= transport std_logic_vector'("01101001"); --69
		Carry_in <= transport '0';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7300 ps
		data_in <= transport std_logic_vector'("00011000"); --18
		ACC_in <= transport std_logic_vector'("10111001"); --B9
		Carry_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7400 ps
		data_in <= transport std_logic_vector'("11100001"); --E1
		ACC_in <= transport std_logic_vector'("01110001"); --71
		OverFlow_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7500 ps
		data_in <= transport std_logic_vector'("10000110"); --86
		ACC_in <= transport std_logic_vector'("00000011"); --3
		Carry_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7600 ps
		data_in <= transport std_logic_vector'("01100100"); --64
		ACC_in <= transport std_logic_vector'("00100000"); --20
		Carry_in <= transport '1';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7700 ps
		data_in <= transport std_logic_vector'("00011000"); --18
		ACC_in <= transport std_logic_vector'("10111000"); --B8
		AUX_C_in <= transport '1';
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7800 ps
		data_in <= transport std_logic_vector'("01111111"); --7F
		ACC_in <= transport std_logic_vector'("11111100"); --FC
		Carry_in <= transport '0';
		AUX_C_in <= transport '0';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7900 ps
		data_in <= transport std_logic_vector'("10110110"); --B6
		ACC_in <= transport std_logic_vector'("01011111"); --5F
		Carry_in <= transport '1';
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8000 ps
		data_in <= transport std_logic_vector'("00011010"); --1A
		ACC_in <= transport std_logic_vector'("10001111"); --8F
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8100 ps
		data_in <= transport std_logic_vector'("01001000"); --48
		ACC_in <= transport std_logic_vector'("10000000"); --80
		OverFlow_in <= transport '1';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8200 ps
		data_in <= transport std_logic_vector'("00011101"); --1D
		ACC_in <= transport std_logic_vector'("01100001"); --61
		Carry_in <= transport '0';
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8300 ps
		data_in <= transport std_logic_vector'("10110110"); --B6
		ACC_in <= transport std_logic_vector'("10100011"); --A3
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8400 ps
		data_in <= transport std_logic_vector'("01110000"); --70
		ACC_in <= transport std_logic_vector'("11111000"); --F8
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8500 ps
		data_in <= transport std_logic_vector'("11101000"); --E8
		ACC_in <= transport std_logic_vector'("01010001"); --51
		Carry_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8600 ps
		data_in <= transport std_logic_vector'("11111100"); --FC
		ACC_in <= transport std_logic_vector'("11011110"); --DE
		Carry_in <= transport '1';
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8700 ps
		data_in <= transport std_logic_vector'("11000111"); --C7
		ACC_in <= transport std_logic_vector'("00010001"); --11
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8800 ps
		data_in <= transport std_logic_vector'("10100111"); --A7
		ACC_in <= transport std_logic_vector'("10011011"); --9B
		Carry_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8900 ps
		data_in <= transport std_logic_vector'("00111001"); --39
		ACC_in <= transport std_logic_vector'("01101100"); --6C
		AUX_C_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9000 ps
		data_in <= transport std_logic_vector'("01011010"); --5A
		ACC_in <= transport std_logic_vector'("10110101"); --B5
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9100 ps
		data_in <= transport std_logic_vector'("00100111"); --27
		ACC_in <= transport std_logic_vector'("11101001"); --E9
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		AUX_C_in <= transport '0';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9200 ps
		data_in <= transport std_logic_vector'("11111110"); --FE
		ACC_in <= transport std_logic_vector'("10110110"); --B6
		Carry_in <= transport '1';
		OverFlow_in <= transport '0';
		AUX_C_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9300 ps
		data_in <= transport std_logic_vector'("01111010"); --7A
		ACC_in <= transport std_logic_vector'("00010000"); --10
		Carry_in <= transport '0';
		OverFlow_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9400 ps
		data_in <= transport std_logic_vector'("01111001"); --79
		ACC_in <= transport std_logic_vector'("00100110"); --26
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9500 ps
		data_in <= transport std_logic_vector'("00011000"); --18
		ACC_in <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 100 ps; -- Time=9600 ps
		data_in <= transport std_logic_vector'("10110101"); --B5
		ACC_in <= transport std_logic_vector'("10001011"); --8B
		OverFlow_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9700 ps
		data_in <= transport std_logic_vector'("11101011"); --EB
		ACC_in <= transport std_logic_vector'("01111101"); --7D
		Carry_in <= transport '1';
		OverFlow_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9800 ps
		data_in <= transport std_logic_vector'("10011000"); --98
		ACC_in <= transport std_logic_vector'("01101111"); --6F
		Carry_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9900 ps
		data_in <= transport std_logic_vector'("11011010"); --DA
		ACC_in <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 210 ps; -- Time=10110 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION psw_reg_cfg OF psw_reg_tb IS
	FOR testbench_arch
	END FOR;
END psw_reg_cfg;
