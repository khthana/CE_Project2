library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on
	  
entity execute is
   port ( 
			 rst		  : in 	 std_logic; 	
			 AA        : in    std_logic_vector (7 downto 0); 
          ac_in     : in    std_logic; 
          BB        : in    std_logic_vector (7 downto 0); 
          cy_in     : in    std_logic; 
          D1        : in    std_logic_vector (7 downto 0); 
          D2        : in    std_logic_vector (7 downto 0); 
          OPCode    : in    std_logic_vector (4 downto 0); 

			 s1 		  : in std_logic_vector (7 downto 0);
          s2 		  : in std_logic_vector (7 downto 0);
          ac_out    : out   std_logic; 
          cy_out    : out   std_logic; 
--        sel_mux16 : in 	 std_logic_vector (1 downto 0);
--        sel_mux17 : in 	 std_logic_vector (1 downto 0);
			 sel		  : in 	 std_logic_vector (1 downto 0);

          ov        : out   std_logic;
			  
          RA_in     : in   std_logic_vector (7 downto 0); 
          RB_in     : in   std_logic_vector (7 downto 0);
          RA_out    : out   std_logic_vector (7 downto 0); 
          RB_out    : out   std_logic_vector (7 downto 0));
end execute;

architecture structual of execute is

   signal des1      : std_logic_vector (7 downto 0);
   signal des2      : std_logic_vector (7 downto 0);
   signal sel_mux16  : std_logic_vector (1 downto 0);
   signal sel_mux17  : std_logic_vector (1 downto 0);
   signal src1      : std_logic_vector (7 downto 0);
   signal src2      : std_logic_vector (7 downto 0);
   component alu
      port ( rst     : in    std_logic; 
             src_cy  : in    std_logic; 
             src_ac  : in    std_logic; 
             op_code : in    std_logic_vector (4 downto 0); 
             src_1   : in    std_logic_vector (7 downto 0); 
             src_2   : in    std_logic_vector (7 downto 0); 
             des_cy  : out   std_logic; 
             des_ac  : out   std_logic; 
             des_ov  : out   std_logic; 
             des_1   : out   std_logic_vector (7 downto 0); 
             des_2   : out   std_logic_vector (7 downto 0));
   end component;
   
   
   component d11d22rarb
      port ( in1  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component forwarder
      port ( s1   : in    std_logic_vector (7 downto 0); 
             s2   : in    std_logic_vector (7 downto 0); 
             d1   : in    std_logic_vector (7 downto 0); 
             d2   : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (1 downto 0); 
             out2 : out   std_logic_vector (1 downto 0); 
             sel  : in    std_logic_vector (1 downto 0));
   end component;
   
   component mux1617
      port ( in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
--             in4  : in    std_logic_vector (7 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   
begin
   RA_out(7 downto 0) <= des1(7 downto 0);
   RB_out(7 downto 0) <= des2(7 downto 0);
   alu_m : alu
      port map (op_code(4 downto 0)=>OPCode(4 downto 0),      
                rst=>rst,      
                src_ac=>ac_in,      
                src_cy=>cy_in,      
                src_1(7 downto 0)=>src1(7 downto 0),      
                src_2(7 downto 0)=>src2(7 downto 0),      
                des_ac=>ac_out,      
                des_cy=>cy_out,      
                des_ov=>ov,      
                des_1(7 downto 0)=>des1(7 downto 0),      
                des_2(7 downto 0)=>des2(7 downto 0));
   
  
  
   Forwarder_m : forwarder
      port map (d1(7 downto 0)=>D1(7 downto 0),      
                d2(7 downto 0)=>D2(7 downto 0),      
                sel(1 downto 0)=>sel(1 downto 0),      
                s1(7 downto 0)=>s1(7 downto 0),      
                s2(7 downto 0)=>s2(7 downto 0),      
                out1(1 downto 0)=>sel_mux16(1 downto 0),      
                out2(1 downto 0)=>sel_mux17(1 downto 0));
   
   mux16 : mux1617
      port map (--in1(7 downto 0)=>forward1(7 downto 0),      
                in1(7 downto 0)=>RA_in(7 downto 0),      
                in2(7 downto 0)=>RB_in(7 downto 0),      
                in3(7 downto 0)=>AA(7 downto 0),      
                sel(1 downto 0)=>sel_mux16(1 downto 0),      
                out1(7 downto 0)=>src1(7 downto 0));
   
   mux17 : mux1617
      port map (--in1(7 downto 0)=>forward2(7 downto 0),      
                in1(7 downto 0)=>RA_in(7 downto 0),      
                in2(7 downto 0)=>RB_in(7 downto 0),      
                in3(7 downto 0)=>BB(7 downto 0),      
                sel(1 downto 0)=>sel_mux17(1 downto 0),      
                out1(7 downto 0)=>src2(7 downto 0));
   
   
end structual;



