library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity EXWB is
port	(
			clk	: in std_logic;
			rst	: in std_logic;
			-- Data for Writeback State
			in_D11 	: in	std_logic_vector(7 downto 0);
			in_D22 	: in	std_logic_vector(7 downto 0);
			in_R_A 	: in	std_logic_vector(7 downto 0);
			in_R_B 	: in	std_logic_vector(7 downto 0);
			out_D11 	: out std_logic_vector(7 downto 0);
			out_D22 	: out std_logic_vector(7 downto 0);
			out_R_A 	: out std_logic_vector(7 downto 0);
			out_R_B 	: out std_logic_vector(7 downto 0);
			-- Control signal	for Writeback Stage
--			in_w_A				: in std_logic;
--			in_w_B				: in std_logic;
			in_sel_mux10		: in std_logic;
			in_sp_load			: in std_logic;
--			in_sel_mux18		: in	std_logic;
--			in_sel_addr_dec	: in	std_logic;
			in_sel_mux11		: in	std_logic_vector(1 downto 0);
			in_sel_mux13		: in	std_logic;
--			in_wbank0			: in	std_logic;
--			in_wbank1			: in	std_logic;
			in_en					: in	std_logic_vector(1 downto 0);
--			out_w_A				: out std_logic;
--			out_w_B				: out std_logic;
			out_sel_mux10		: out std_logic;
			out_sp_load			: out std_logic;
--			out_sel_mux18		: out	std_logic;
--			out_sel_addr_dec	: out	std_logic;
			out_sel_mux11		: out	std_logic_vector(1 downto 0);
			out_sel_mux13		: out	std_logic;
--			out_wbank0			: out	std_logic;
--			out_wbank1			: out	std_logic;
			out_en				: out	std_logic_vector(1 downto 0)
			);
end EXWB;

architecture RTL of EXWB is
begin
	process(rst,clk)
	begin
		if (rst = '1') then
			out_D11 <= "00000000";
			out_D22 <= "00000000";
			out_R_A <= "00000000";
			out_R_B <= "00000000";
--			out_sel_mux18 <= '0';
--			out_sel_addr_dec <= '0';
			out_sel_mux11 <= "00";
			out_sel_mux13 <= '0';
--			out_wbank0 <= '0';
--			out_wbank1 <= '0';
			out_en <= "00";
		elsif (rising_edge(Clk) and rst = '0' ) then
			out_D11 <= in_D11;
			out_D22 <= in_D22;
			out_R_A <= in_R_A;
			out_R_B <= in_R_B;
--			out_sel_mux18 <= in_sel_mux18;
--			out_sel_addr_dec <= in_sel_addr_dec;
			out_sel_mux11 <= in_sel_mux11;
			out_sel_mux13 <= in_sel_mux13;
--			out_wbank0 <= in_wbank0;
--			out_wbank1 <= in_wbank1;
			out_en <= in_en;
		end if;
	end process;
end RTL;
