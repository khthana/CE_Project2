
-- VHDL Instantiation Created from source file d_mux8.vhd -- 06:18:50 12/30/2004
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT d_mux8
	PORT(
		in1 : IN std_logic_vector(7 downto 0);
		in2 : IN std_logic_vector(7 downto 0);
		in3 : IN std_logic_vector(7 downto 0);
		sel : IN std_logic_vector(1 downto 0);          
		out1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_d_mux8: d_mux8 PORT MAP(
		in1 => ,
		in2 => ,
		in3 => ,
		sel => ,
		out1 => 
	);


