--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : execute.vhf
-- /___/   /\     Timestamp : 02/14/2005 00:27:42
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: IFD_MXILINX_execute
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity IFD_MXILINX_execute is
   port ( C : in    std_logic; 
          D : in    std_logic; 
          Q : out   std_logic);
end IFD_MXILINX_execute;

architecture BEHAVIORAL of IFD_MXILINX_execute is
   attribute INIT       : string ;
   attribute BOX_TYPE   : string ;
   attribute IOB        : string ;
   signal D_IN   : std_logic;
   signal XLXN_1 : std_logic;
   signal XLXN_2 : std_logic;
   component FDCE
      -- synopsys translate_off
      generic( INIT : bit :=  '0');
      -- synopsys translate_on
      port ( C   : in    std_logic; 
             CE  : in    std_logic; 
             CLR : in    std_logic; 
             D   : in    std_logic; 
             Q   : out   std_logic);
   end component;
   attribute INIT of FDCE : component is "0";
   attribute BOX_TYPE of FDCE : component is "BLACK_BOX";
   
   component IBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of IBUF : component is "BLACK_BOX";
   
   component VCC
      port ( P : out   std_logic);
   end component;
   attribute BOX_TYPE of VCC : component is "BLACK_BOX";
   
   component GND
      port ( G : out   std_logic);
   end component;
   attribute BOX_TYPE of GND : component is "BLACK_BOX";
   
   attribute IOB of I_36_15 : label is "TRUE";
begin
   I_36_15 : FDCE
      port map (C=>C,      
                CE=>XLXN_2,      
                CLR=>XLXN_1,      
                D=>D_IN,      
                Q=>Q);
   
   I_36_24 : IBUF
      port map (I=>D,      
                O=>D_IN);
   
   I_36_26 : VCC
      port map (P=>XLXN_2);
   
   I_36_29 : GND
      port map (G=>XLXN_1);
   
end BEHAVIORAL;


--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : execute.vhf
-- /___/   /\     Timestamp : 02/14/2005 00:27:42
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: IFD8_MXILINX_execute
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity IFD8_MXILINX_execute is
   port ( C : in    std_logic; 
          D : in    std_logic_vector (7 downto 0); 
          Q : out   std_logic_vector (7 downto 0));
end IFD8_MXILINX_execute;

architecture BEHAVIORAL of IFD8_MXILINX_execute is
   attribute HU_SET     : string ;
   component IFD_MXILINX_execute
      port ( C : in    std_logic; 
             D : in    std_logic; 
             Q : out   std_logic);
   end component;
   
   attribute HU_SET of I_Q0 : label is "I_Q0_7";
   attribute HU_SET of I_Q1 : label is "I_Q1_6";
   attribute HU_SET of I_Q2 : label is "I_Q2_5";
   attribute HU_SET of I_Q3 : label is "I_Q3_4";
   attribute HU_SET of I_Q4 : label is "I_Q4_3";
   attribute HU_SET of I_Q5 : label is "I_Q5_2";
   attribute HU_SET of I_Q6 : label is "I_Q6_1";
   attribute HU_SET of I_Q7 : label is "I_Q7_0";
begin
   I_Q0 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(0),      
                Q=>Q(0));
   
   I_Q1 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(1),      
                Q=>Q(1));
   
   I_Q2 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(2),      
                Q=>Q(2));
   
   I_Q3 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(3),      
                Q=>Q(3));
   
   I_Q4 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(4),      
                Q=>Q(4));
   
   I_Q5 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(5),      
                Q=>Q(5));
   
   I_Q6 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(6),      
                Q=>Q(6));
   
   I_Q7 : IFD_MXILINX_execute
      port map (C=>C,      
                D=>D(7),      
                Q=>Q(7));
   
end BEHAVIORAL;


--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : execute.vhf
-- /___/   /\     Timestamp : 02/14/2005 00:27:42
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: execute
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity execute is
   port ( AA        : in    std_logic_vector (7 downto 0); 
          ac_in     : in    std_logic; 
          BB        : in    std_logic_vector (7 downto 0); 
          cy_in     : in    std_logic; 
          D1        : in    std_logic_vector (7 downto 0); 
          D2        : in    std_logic_vector (7 downto 0); 
          en        : in    std_logic; 
          OPCode    : in    std_logic_vector (3 downto 0); 
          PC_h      : in    std_logic_vector (7 downto 0); 
          PC_l      : in    std_logic_vector (7 downto 0); 
          rst       : in    std_logic; 
          r_addr    : in    std_logic_vector (7 downto 0); 
          sel       : in    std_logic_vector (3 downto 0); 
          sel_mux10 : in    std_logic; 
          sel_mux11 : in    std_logic_vector (1 downto 0); 
          sel_mux12 : in    std_logic_vector (1 downto 0); 
          sel_mux13 : in    std_logic; 
          sel_mux14 : in    std_logic; 
          sel_mux15 : in    std_logic; 
          sel_mux16 : in    std_logic_vector (1 downto 0); 
          sel_mux17 : in    std_logic_vector (1 downto 0); 
          s1        : in    std_logic_vector (7 downto 0); 
          s2        : in    std_logic_vector (7 downto 0); 
          w_addr    : in    std_logic_vector (7 downto 0); 
          XLXN_2    : in    std_logic; 
          ac_out    : out   std_logic; 
          cy_out    : out   std_logic; 
          D11       : out   std_logic_vector (7 downto 0); 
          D22       : out   std_logic_vector (7 downto 0); 
          mux15     : out   std_logic_vector (7 downto 0); 
          ov        : out   std_logic; 
          RA        : out   std_logic_vector (7 downto 0); 
          RB        : out   std_logic_vector (7 downto 0));
end execute;

architecture BEHAVIORAL of execute is
   attribute HU_SET     : string ;
   signal des1      : std_logic_vector (7 downto 0);
   signal des2      : std_logic_vector (7 downto 0);
   signal do0       : std_logic_vector (7 downto 0);
   signal do1       : std_logic_vector (7 downto 0);
   signal forward1  : std_logic_vector (7 downto 0);
   signal forward2  : std_logic_vector (7 downto 0);
   signal pc0       : std_logic_vector (7 downto 0);
   signal pc1       : std_logic_vector (7 downto 0);
   signal r_addr0   : std_logic_vector (7 downto 0);
   signal r_addr1   : std_logic_vector (7 downto 0);
   signal sp_in     : std_logic_vector (7 downto 0);
   signal sp_out    : std_logic_vector (7 downto 0);
   signal sp1       : std_logic_vector (7 downto 0);
   signal sp2       : std_logic_vector (7 downto 0);
   signal src1      : std_logic_vector (7 downto 0);
   signal src2      : std_logic_vector (7 downto 0);
   signal w_addr0   : std_logic_vector (7 downto 0);
   signal w_addr1   : std_logic_vector (7 downto 0);
   signal RA_DUMMY  : std_logic_vector (7 downto 0);
   signal RB_DUMMY  : std_logic_vector (7 downto 0);
   signal D11_DUMMY : std_logic_vector (7 downto 0);
   signal D22_DUMMY : std_logic_vector (7 downto 0);
   component alu
      port ( rst     : in    std_logic; 
             src_cy  : in    std_logic; 
             src_ac  : in    std_logic; 
             op_code : in    std_logic_vector (3 downto 0); 
             src_1   : in    std_logic_vector (7 downto 0); 
             src_2   : in    std_logic_vector (7 downto 0); 
             des_cy  : out   std_logic; 
             des_ac  : out   std_logic; 
             des_ov  : out   std_logic; 
             des_1   : out   std_logic_vector (7 downto 0); 
             des_2   : out   std_logic_vector (7 downto 0));
   end component;
   
   component as1
      port ( in1  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component as2
      port ( in1  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component internal_ram_bank
      port ( di     : in    std_logic_vector (7 downto 0); 
             do     : out   std_logic_vector (7 downto 0); 
             w_addr : in    std_logic_vector (7 downto 0); 
             r_addr : in    std_logic_vector (7 downto 0));
   end component;
   
   component d11d22rarb
      port ( in1  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component forwarder
      port ( s1   : in    std_logic_vector (7 downto 0); 
             s2   : in    std_logic_vector (7 downto 0); 
             d1   : in    std_logic_vector (7 downto 0); 
             d2   : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0); 
             out2 : out   std_logic_vector (7 downto 0); 
             sel  : in    std_logic_vector (3 downto 0));
   end component;
   
   component latch
      port ( in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0); 
             out2 : out   std_logic_vector (7 downto 0); 
             en   : in    std_logic);
   end component;
   
   component mux10131415
      port ( sel  : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component mux1112
      port ( in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component max1617
      port ( in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             in4  : in    std_logic_vector (7 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
   component IFD8_MXILINX_execute
      port ( C : in    std_logic; 
             D : in    std_logic_vector (7 downto 0); 
             Q : out   std_logic_vector (7 downto 0));
   end component;
   
   attribute HU_SET of XLXI_5 : label is "XLXI_5_8";
begin
   D11(7 downto 0) <= D11_DUMMY(7 downto 0);
   D22(7 downto 0) <= D22_DUMMY(7 downto 0);
   RA(7 downto 0) <= RA_DUMMY(7 downto 0);
   RB(7 downto 0) <= RB_DUMMY(7 downto 0);
   alu_m : alu
      port map (op_code(3 downto 0)=>OPCode(3 downto 0),      
                rst=>rst,      
                src_ac=>ac_in,      
                src_cy=>cy_in,      
                src_1(7 downto 0)=>src1(7 downto 0),      
                src_2(7 downto 0)=>src2(7 downto 0),      
                des_ac=>ac_out,      
                des_cy=>cy_out,      
                des_ov=>ov,      
                des_1(7 downto 0)=>des1(7 downto 0),      
                des_2(7 downto 0)=>des2(7 downto 0));
   
   as1_m : as1
      port map (in1(7 downto 0)=>sp_out(7 downto 0),      
                out1(7 downto 0)=>sp1(7 downto 0));
   
   as2_m : as2
      port map (in1(7 downto 0)=>sp_out(7 downto 0),      
                out1(7 downto 0)=>sp2(7 downto 0));
   
   bank0 : internal_ram_bank
      port map (di(7 downto 0)=>pc0(7 downto 0),      
                r_addr(7 downto 0)=>r_addr0(7 downto 0),      
                w_addr(7 downto 0)=>w_addr0(7 downto 0),      
                do(7 downto 0)=>do0(7 downto 0));
   
   bank1 : internal_ram_bank
      port map (di(7 downto 0)=>pc1(7 downto 0),      
                r_addr(7 downto 0)=>r_addr1(7 downto 0),      
                w_addr(7 downto 0)=>w_addr1(7 downto 0),      
                do(7 downto 0)=>do1(7 downto 0));
   
   D11_m : d11d22rarb
      port map (in1(7 downto 0)=>D1(7 downto 0),      
                out1(7 downto 0)=>D11_DUMMY(7 downto 0));
   
   D22_m : d11d22rarb
      port map (in1(7 downto 0)=>D2(7 downto 0),      
                out1(7 downto 0)=>D22_DUMMY(7 downto 0));
   
   Forwarder_m : forwarder
      port map (d1(7 downto 0)=>D11_DUMMY(7 downto 0),      
                d2(7 downto 0)=>D22_DUMMY(7 downto 0),      
                sel(3 downto 0)=>sel(3 downto 0),      
                s1(7 downto 0)=>s1(7 downto 0),      
                s2(7 downto 0)=>s2(7 downto 0),      
                out1(7 downto 0)=>forward1(7 downto 0),      
                out2(7 downto 0)=>forward2(7 downto 0));
   
   latch_m : latch
      port map (en=>en,      
                in1(7 downto 0)=>PC_h(7 downto 0),      
                in2(7 downto 0)=>PC_l(7 downto 0),      
                out1(7 downto 0)=>pc0(7 downto 0),      
                out2(7 downto 0)=>pc1(7 downto 0));
   
   mux_10 : mux10131415
      port map (in1(7 downto 0)=>sp2(7 downto 0),      
                in2(7 downto 0)=>sp1(7 downto 0),      
                sel=>sel_mux10,      
                out1(7 downto 0)=>sp_in(7 downto 0));
   
   mux_11 : mux1112
      port map (in1(7 downto 0)=>sp1(7 downto 0),      
                in2(7 downto 0)=>sp2(7 downto 0),      
                in3(7 downto 0)=>w_addr(7 downto 0),      
                sel(1 downto 0)=>sel_mux11(1 downto 0),      
                out1(7 downto 0)=>w_addr0(7 downto 0));
   
   mux_12 : mux1112
      port map (in1(7 downto 0)=>sp_out(7 downto 0),      
                in2(7 downto 0)=>sp1(7 downto 0),      
                in3(7 downto 0)=>r_addr(7 downto 0),      
                sel(1 downto 0)=>sel_mux12(1 downto 0),      
                out1(7 downto 0)=>r_addr0(7 downto 0));
   
   mux_13 : mux10131415
      port map (in1(7 downto 0)=>sp2(7 downto 0),      
                in2(7 downto 0)=>w_addr(7 downto 0),      
                sel=>sel_mux13,      
                out1(7 downto 0)=>w_addr1(7 downto 0));
   
   mux_14 : mux10131415
      port map (in1(7 downto 0)=>sp_out(7 downto 0),      
                in2(7 downto 0)=>r_addr(7 downto 0),      
                sel=>sel_mux14,      
                out1(7 downto 0)=>r_addr1(7 downto 0));
   
   mux_15 : mux10131415
      port map (in1(7 downto 0)=>do0(7 downto 0),      
                in2(7 downto 0)=>do1(7 downto 0),      
                sel=>sel_mux15,      
                out1(7 downto 0)=>mux15(7 downto 0));
   
   mux16 : max1617
      port map (in1(7 downto 0)=>forward1(7 downto 0),      
                in2(7 downto 0)=>RA_DUMMY(7 downto 0),      
                in3(7 downto 0)=>RB_DUMMY(7 downto 0),      
                in4(7 downto 0)=>AA(7 downto 0),      
                sel(1 downto 0)=>sel_mux16(1 downto 0),      
                out1(7 downto 0)=>src1(7 downto 0));
   
   mux17 : max1617
      port map (in1(7 downto 0)=>forward2(7 downto 0),      
                in2(7 downto 0)=>RA_DUMMY(7 downto 0),      
                in3(7 downto 0)=>RB_DUMMY(7 downto 0),      
                in4(7 downto 0)=>BB(7 downto 0),      
                sel(1 downto 0)=>sel_mux17(1 downto 0),      
                out1(7 downto 0)=>src2(7 downto 0));
   
   RA_m : d11d22rarb
      port map (in1(7 downto 0)=>des1(7 downto 0),      
                out1(7 downto 0)=>RA_DUMMY(7 downto 0));
   
   RB_m : d11d22rarb
      port map (in1(7 downto 0)=>des2(7 downto 0),      
                out1(7 downto 0)=>RB_DUMMY(7 downto 0));
   
   XLXI_5 : IFD8_MXILINX_execute
      port map (C=>XLXN_2,      
                D(7 downto 0)=>sp_in(7 downto 0),      
                Q(7 downto 0)=>sp_out(7 downto 0));
   
end BEHAVIORAL;


