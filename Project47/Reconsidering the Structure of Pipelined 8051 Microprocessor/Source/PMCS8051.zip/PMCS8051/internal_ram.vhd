library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity internal_ram is
    port(
	 		rst          : in  STD_LOGIC;
         clk          : in  STD_LOGIC;

         r_addr1 		 : in std_logic_vector(7 downto 0);
         r_addr2 		 : in std_logic_vector(7 downto 0);
         do_1		 	 : out std_logic_vector(7 downto 0);
         do_2		 	 : out std_logic_vector(7 downto 0);

--         wr_bank0 	 : in std_logic;
         w_addr_bank0 : in std_logic_vector(7 downto 0);
         di_bank0		 : in std_logic_vector(7 downto 0);

--         wr_bank1		 : in std_logic;
         w_addr_bank1 : in std_logic_vector(7 downto 0);
			di_bank1		 : in std_logic_vector(7 downto 0)
			);
end internal_ram;

architecture RTL of internal_ram is

    type IRAM_TYPE is array (0 to 127) of std_logic_vector (7 downto 0) ;
    
    signal iram0 : IRAM_TYPE ;
    signal iram1 : IRAM_TYPE ;

begin
	process (clk)
	begin
		if (clk'event and clk = '1') then
--			if (wr_bank0 = '1') then
				if w_addr_bank0(0) = '0' then
					iram0(conv_integer(w_addr_bank0(7 downto 1))) <= di_bank0;
--				elsif w_addr_bank0(0) = '1' then
--					iram1(conv_integer(w_addr_bank0(7 downto 1))) <= di_bank0;
--				end if; 
				end if;
--			if (wr_bank1 = '1') then
				if w_addr_bank1(0) = '1' then
--					iram0(conv_integer(w_addr_bank1(7 downto 1))) <= di_bank1;
--				elsif w_addr_bank1(0) = '1' then
					iram1(conv_integer(w_addr_bank1(7 downto 1))) <= di_bank1;
--				end if; 
				end if;
		end if;													
	end process;

--	process (rst)
--	begin
--		if (rst = '1') then
--			for i in 0 to 127 loop
--				iram0(i) <= "--------";   
--				iram1(i) <= "--------";   
--			end loop;
--		end if;
--	end process;
			do_1 <= iram0(conv_integer(r_addr1(7 downto 1))) when (rst = '0') and (r_addr1(0) = '0') else iram1(conv_integer(r_addr1(7 downto 1))) when (rst = '0') and (r_addr1(0) = '1') else "--------";
			do_2 <= iram0(conv_integer(r_addr2(7 downto 1))) when (rst = '0') and (r_addr2(0) = '0') else iram1(conv_integer(r_addr2(7 downto 1))) when (rst = '0') and (r_addr2(0) = '1') else "--------";
end RTL;
