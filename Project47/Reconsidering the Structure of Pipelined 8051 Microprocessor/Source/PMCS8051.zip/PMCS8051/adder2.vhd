library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity adder2 is
    Port ( in1 : in std_logic_vector(15 downto 0);
           in2 : in std_logic_vector(15 downto 0);
           out1 : out std_logic_vector(15 downto 0));
end adder2;

architecture rtl of adder2 is

begin
 	process(in1, in2)
		variable v1, v2 : SIGNED (15 downto 0);
	begin
		v1:=SIGNED(in1);
		v2:=SIGNED(in2);
		v1:=v1+v2;
      out1 <= STD_LOGIC_vector(v1);
	end process;

end rtl;
