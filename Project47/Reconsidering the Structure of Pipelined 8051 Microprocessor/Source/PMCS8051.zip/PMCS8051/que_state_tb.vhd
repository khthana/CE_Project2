
-- VHDL Test Bench Created from source file que_state.vhd -- 20:08:15 10/08/2004
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends 
-- that these types always be used for the top-level I/O of a design in order 
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY que_state_que_state_tb_vhd_tb IS
END que_state_que_state_tb_vhd_tb;

ARCHITECTURE behavior OF que_state_que_state_tb_vhd_tb IS 

	COMPONENT que_state
	PORT(
		in1 : IN std_logic_vector(7 downto 0);
		reset : IN std_logic;
		clock : IN std_logic;          
--	 iqc_out	: out std_logic_vector(4 DOWNTO 0); 		
--		M_out  : out std_logic_vector(1 downto 0);
		out1 : OUT std_logic_vector(7 downto 0);
		out2 : OUT std_logic_vector(7 downto 0);
		out3 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	SIGNAL in1 :  std_logic_vector(7 downto 0);
	SIGNAL out1 :  std_logic_vector(7 downto 0);
	SIGNAL out2 :  std_logic_vector(7 downto 0);
	SIGNAL out3 :  std_logic_vector(7 downto 0);
	SIGNAL reset :  std_logic;
	SIGNAL clock :  std_logic:='1';
--	signal iqc_out	: std_logic_vector(4 DOWNTO 0):="ZZZZZ"; 		
--	signal M_out			: std_logic_vector(1 downto 0):="ZZ";

BEGIN

	uut: que_state PORT MAP(
		in1 => in1,
		out1 => out1,
		out2 => out2,
		out3 => out3,
		reset => reset,
--		 iqc_out	=>  iqc_out	,
--		 M_out => M_out,
		clock => clock

	);

  	clock <= not clock after 5 ns;

	reset <= 	'1',
			'0' after 1 ns;

	in1 <= "00000000",
		    "00111011" after 10 ns,
		    "00000000" after 20 ns,         --85
          "01000000" after 30 ns,         --90
          "00111011" after 40 ns,         --20
          "00111011" after 50 ns,         --90
          "10010000" after 60 ns,         --90
          "00000000" after 70 ns,         --78
          "00000000" after 80 ns,         --88
          "00010001" after 90 ns,         --11
          "10010000" after 100 ns,         --90
          "00100000" after 110 ns,         --20
          "10010000" after 120 ns,         --90
          "10010000" after 130 ns,         --90
          "00000000" after 140 ns,         --78
          "00000000" after 150 ns;         --88


-- *** Test Bench - User Defined Section ***
   tb : PROCESS
   BEGIN
      wait; -- will wait forever
   END PROCESS;
-- *** End Test Bench - User Defined Section ***

END;
