library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux4 is
    Port ( in1 : in std_logic_vector(15 downto 0);--jcall
           in2 : in std_logic_vector(15 downto 0);--temp
           in3 : in std_logic_vector(15 downto 0);--pc
           in4 : in std_logic_vector(15 downto 0);--dptr
           in5 : in std_logic_vector(15 downto 0);--adder2
           sel : in std_logic_vector(2 downto 0);
           out1 : out std_logic_vector(15 downto 0));
end mux4;

architecture rtl of mux4 is
begin
	process(in1,in2,in3,in4,in5,sel)
	begin
		case  sel is
		when "000" => out1 <= in1;
		when "001" => out1 <= in2;
		when "010" => out1 <= in3;
		when "011" => out1 <= in4;
		when "100" => out1 <= in5;
		when others => out1 <= in3;
		end case;
	end process;
end rtl;
