library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux2 is
    Port ( in1 : in std_logic_vector(7 downto 0);	--byte 2
           in2 : in std_logic_vector(7 downto 0);	--byte 3
           sel : in std_logic;
           out1 : out std_logic_vector(7 downto 0));
end mux2;

architecture rtl of mux2 is
begin
	process(in1,in2,sel)
	begin
		case  sel is
		when '0' => out1 <= in1;
		when '1' => out1 <= in2;
		when others => out1 <= in1;
		end case;
	end process;

end rtl;
