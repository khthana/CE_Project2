library IEEE;
use IEEE.std_logic_1164.ALL;
use IEEE.std_logic_ARITH.ALL;
use IEEE.std_logic_UNSIGNED.ALL;

entity Instruction_Decoder is
	port (--clock			: in	std_logic;
			reset			: in	std_logic;
			inst_byte1	: in	std_logic_vector(7 downto 0);-- from Inst. Byte 1
			inst_byte2	: in	std_logic_vector(7 downto 0);-- from Inst. Byte 2
			inst_byte3	: in	std_logic_vector(7 downto 0);
         s1 			: out std_logic_vector(7 downto 0);-- to	S1
         s2 			: out std_logic_vector(7 downto 0);-- to	S2
         d1 			: out std_logic_vector(7 downto 0);-- to	D1
         d2 			: out std_logic_vector(7 downto 0);-- to	D2
		 	alu_oprt 	: out std_logic_vector(4 downto 0);-- to	ALU_Operation
			sel_forward : out	std_logic_vector (1 downto 0);
--			in_bb			: in	std_logic_vector(7 downto 0);
			in_Ri_dec	: in	std_logic_vector(7 downto 0);
			in_Rn_dec	: in 	std_logic_vector(7 downto 0);
			in_bit_dec	: in 	std_logic_vector(7 downto 0)
			);
end Instruction_Decoder;

architecture RTL of Instruction_Decoder is

    constant R_B    : std_logic_vector (7 downto 0) := "11110000"; 
    constant R_ACC  : std_logic_vector (7 downto 0) := "11100000"; 
    constant R_PSW  : std_logic_vector (7 downto 0) := "11010000"; 
    constant R_IP   : std_logic_vector (7 downto 0) := "10111000";
    constant R_IE   : std_logic_vector (7 downto 0) := "10101000";
    constant R_SP   : std_logic_vector (7 downto 0) := "10000001";
    constant R_P0   : std_logic_vector (7 downto 0) := "10000000"; 
    constant R_P1   : std_logic_vector (7 downto 0) := "10010000";
    constant R_P2   : std_logic_vector (7 downto 0) := "10100000";
    constant R_P3   : std_logic_vector (7 downto 0) := "10110000";
    constant R_DPL  : std_logic_vector (7 downto 0) := "10000010";
    constant R_DPH  : std_logic_vector (7 downto 0) := "10000011";
	 constant DC		: std_logic_vector(7 downto 0) := "--------";
--    constant R_PCON : std_logic_vector (7 downto 0) := "10000111";
--    constant R_SCON : std_logic_vector (7 downto 0) := "10011000";
--    constant R_SBUF : std_logic_vector (7 downto 0) := "10011001";
--    constant R_TCON : std_logic_vector (7 downto 0) := "10001000";
--		constant R_TMOD : std_logic_vector (7 downto 0) := "10001001";
--    constant R_TL0  : std_logic_vector (7 downto 0) := "10001010";
--    constant R_TL1  : std_logic_vector (7 downto 0) := "10001011";
--    constant R_TH0  : std_logic_vector (7 downto 0) := "10001100";
--    constant R_TH1  : std_logic_vector (7 downto 0) := "10001101";

	 constant ALU_OPC_NONE   : std_logic_vector (4 downto 0) := "00000";
    constant ALU_OPC_ADD    : std_logic_vector (4 downto 0) := "00001";
    constant ALU_OPC_SUB    : std_logic_vector (4 downto 0) := "00010";
    constant ALU_OPC_MUL    : std_logic_vector (4 downto 0) := "00011";
    constant ALU_OPC_DIV    : std_logic_vector (4 downto 0) := "00100";
    constant ALU_OPC_DA     : std_logic_vector (4 downto 0) := "00101";
    constant ALU_OPC_NOT    : std_logic_vector (4 downto 0) := "00110";
    constant ALU_OPC_ANL    : std_logic_vector (4 downto 0) := "00111";
    constant ALU_OPC_XOR    : std_logic_vector (4 downto 0) := "01000";
    constant ALU_OPC_ORL    : std_logic_vector (4 downto 0) := "01001";
    constant ALU_OPC_RL     : std_logic_vector (4 downto 0) := "01010";
    constant ALU_OPC_RLC    : std_logic_vector (4 downto 0) := "01011";
    constant ALU_OPC_RR     : std_logic_vector (4 downto 0) := "01100";
    constant ALU_OPC_RRC    : std_logic_vector (4 downto 0) := "01101";

	 constant ALU_OPC_ADDC   : std_logic_vector (4 downto 0) := "01110";
    constant ALU_OPC_SWAP   : std_logic_vector (4 downto 0) := "01111";
    constant ALU_OPC_XCH    : std_logic_vector (4 downto 0) := "10000";
	 constant ALU_OPC_XCHD   : std_logic_vector (4 downto 0) := "10001";
	 constant ALU_OPC_NOTB   : std_logic_vector (4 downto 0) := "10010";
	 constant ALU_OPC_COMP   : std_logic_vector (4 downto 0) := "10011";
	 constant ALU_OPC_COMPB  : std_logic_vector (4 downto 0) := "10100";
	 constant ALU_OPC_MOVE   : std_logic_vector (4 downto 0) := "10101";
	 constant ALU_OPC_MOVE_A : std_logic_vector (4 downto 0) := "10110";
	 constant ALU_OPC_CLR	 : std_logic_vector (4 downto 0) := "10111";
	 constant ALU_OPC_MOVE_16: std_logic_vector (4 downto 0) := "11000";



begin
	process(reset,inst_byte1,inst_byte2,inst_byte3,in_Ri_dec,in_Rn_dec,in_bit_dec)
	begin
		if reset = '1' then
			s1			<= DC;
			s2			<= DC;
			d1			<= DC;
			d2			<= DC;
			alu_oprt <= "-----";
			sel_forward <= "00";
		elsif reset = '0' then
			sel_forward <= "00";
--			if clock'event and clock = '1' then
				case inst_byte1(7 downto 0) is
--1 ACALL addr11
--				when	"00010001"|"00110001"|"01010001"|"01110001"|
--						"10010001"|"10110001"|"11010001"|"11110001"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--***2 ADD A,Rn
				when	"00101000"|"00101001"|"00101010"|"00101011"|
						"00101100"|"00101101"|"00101110"|"00101111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADD;
							sel_forward <= "11";

--***3 ADD A,direct
				when	"00100101" 	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADD;
							sel_forward <= "11";

--***4 ADD A,@Ri
				when	"00100110"|"00100111" =>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADD;
							sel_forward <= "11";

--***5 ADD A,#data
				when	"00100100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADD;
							sel_forward <= "10";

--***6 ADDC A,Rn
				when	"00111000"|"00111001"|"00111010"|"00111011"|
						"00111100"|"00111101"|"00111110"|"00111111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADDC;
							sel_forward <= "11";

--***7 ADDC A,direct
				when	"00110101"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADDC;
							sel_forward <= "11";
--***8 ADDC A,@Ri
				when	"00110110"|"00110111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADDC;
							sel_forward <= "11";
--***9 ADDC A,#data
				when	"00110100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADDC;
							sel_forward <= "10";
--***10 AJMP addr11
				when	"00000001"|"00100001"|"01000001"|"01100001"|
						"10000001"|"10100001"|"11000001"|"11100001"	=>
				 			s1 <= DC;
							s2 <= DC;
							d1 <= DC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_NONE;
							sel_forward <= "00";
--***11 ANL A,Rn
				when	"01011000"|"01011001"|"01011010"|"01011011"|
						"01011100"|"01011101"|"01011110"|"01011111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ANL;
							sel_forward <= "11";
--***12 ANL A,direct
				when	"01010101"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ANL;
							sel_forward <= "11";
--***13 ANL A,@Ri
				when	"01010110"|"01010111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ANL;
							sel_forward <= "11";
--***14 ANL A,#data
				when	"01010100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ANL;
							sel_forward <= "10";
--***15 ANL direct,A
				when	"01010010"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ANL;
							sel_forward <= "11";
--***16 ANL direct,#data
				when	"01010011"	=>
							s1 <= inst_byte2;
							s2 <= DC;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ANL;
							sel_forward <= "10";
--17 ANL C,bit
--				when	"10000010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ANL;
--							sel_forward <= "00";
--18 ANL C,/bit
--				when	"10110000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ANL;
--							sel_forward <= "00";
--19 CJNE A,direct,rel
--				when	"10110101"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMP;
--							sel_forward <= "00";
--20 CJNE A,#data,rel
--				when	"10110100"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMP;
--							sel_forward <= "00";
--21 CJNE Rn,#data,rel
--				when	"10111000"|"10111001"|"10111010"|"10111011"|
--						"10111100"|"10111101"|"10111110"|"10111111"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMP;
--							sel_forward <= "00";
--22 CJNE @Ri,#data,rel
--				when	"10110110"|"10110111"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMP;
--							sel_forward <= "00";
--***23 CLR A
				when	"11100100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_CLR;
							sel_forward <= "10";
--24 CLR C
--				when	"11000011"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--25 CLR bit
--				when	"11000010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_bit_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--***26 CPL A
				when	"11110100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_NOT;
							sel_forward <= "10";
--27 CPL C
--				when	"10110011"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NOTB;
--							sel_forward <= "00";
--28 CPL bit
--				when	"10110010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_bit_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NOTB;
--							sel_forward <= "00";
--***29 DA A
				when	"11010100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_DA;
							sel_forward <= "10";
--***30 DEC A
				when	"00010100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_SUB;
							sel_forward <= "10";
--31 DEC Rn
--				when	"00011000"|"00011001"|"00011010"|"00011011"|
--						"00011100"|"00011101"|"00011110"|"00011111"	=>
--							s1 <= in_Rn_dec;
--							s2 <= DC;
--							d1 <= in_Rn_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_SUB;
--							sel_forward <= "10";
--32 DEC direct
--				when	"00010101"	=>
--							s1 <= inst_byte2;
--							s2 <= DC;
--							d1 <= inst_byte2;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_SUB;
--							sel_forward <= "10";
--33 DEC @Ri
--				when	"00010110"|"00010111"	=>
--							s1 <= in_Ri_dec;
--							s2 <= DC;
--							d1 <= in_Ri_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_SUB;
--							sel_forward <= "10";
--34 DIV AB
--				when	"10000100"	=>
--							s1 <= R_ACC;
--							s2 <= R_B;
--							d1 <= R_ACC;
--							d2 <= R_B;
--							alu_oprt <= ALU_OPC_DIV;
--							sel_forward <= "11";
--35 DJNZ Rn,rel
--				when	"11011000"|"11011001"|"11011010"|"11011011"|
--						"11011100"|"11011101"|"11011110"|"11011111"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--36 DJNZ direct,rel
--				when	"11010101"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";

--***37 INC A
				when	"00000100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ADD;
							sel_forward <= "10";
--38 INC Rn
--				when	"00001000"|"00001001"|"00001010"|"00001011"|
--						"00001100"|"00001101"|"00001110"|"00001111"	=>
--							s1 <= in_Rn_dec;
--							s2 <= DC;
--							d1 <= in_Rn_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ADD;
--							sel_forward <= "10";	
--39 INC direct
--				when	"00000101"	=>
--							s1 <= inst_byte2;
--							s2 <= DC;
--							d1 <= inst_byte2;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ADD;
--							sel_forward <= "10";
--40 INC @Ri
--				when	"00000110"|"00000111"	=>
--							s1 <= in_Ri_dec;
--							s2 <= DC;
--							d1 <= in_Ri_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ADD;
--							sel_forward <= "10";
--41 INC DPTR
--				when	"10100011"	=>
--							s1 <= R_DPH;
--							s2 <= R_DPL;
--							d1 <= R_DPH;
--							d2 <= R_DPL;
--							alu_oprt <= ALU_OPC_ADD;
--							sel_forward <= "11";
--42 JB bit,rel
--				when	"00100000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= in_bb;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--43 JBC bit,rel
--				when	"00010000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= in_bb;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--44 JC rel
--				when	"01000000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= in_bb;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--45 JMP @A+DPTR
--				when	"01110011"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--46 JNB bit,rel
--				when	"00110000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--47 JNC rel
--				when	"01010000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--
--48 JNZ rel
--				when	"01110000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--49 JZ rel
--				when	"01100000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_COMPB;
--							sel_forward <= "00";
--50 LCALL addr16
--				when	"00010010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--***51 LJMP addr16
				when	"00000010"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= DC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_NONE;
							sel_forward <= "00";
--***52 MOV A,Rn
				when	"11101000"|"11101001"|"11101010"|"11101011"|
						"11101100"|"11101101"|"11101110"|"11101111"	=>
							s1 <= DC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***53 MOV A,direct
				when	"11100101"	=>
							s1 <= DC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***54 MOV A,@Ri
				when	"11100110"|"11100111"	=>
							s1 <= DC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***55 MOV A,#data
				when	"01110100"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "00";
--***56 MOV Rn,A
				when	"11111000"|"11111001"|"11111010"|"11111011"|
						"11111100"|"11111101"|"11111110"|"11111111"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= in_Rn_dec;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE_A;
							sel_forward <= "10";
--***57 MOV Rn,direct
				when	"10101000"|"10101001"|"10101010"|"10101011"|
						"10101100"|"10101101"|"10101110"|"10101111"	=>
							s1 <= DC;
							s2 <= inst_byte2;
							d1 <= in_Rn_dec;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***58 MOV Rn,#data
				when	"01111000"|"01111001"|"01111010"|"01111011"|
						"01111100"|"01111101"|"01111110"|"01111111"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= in_Rn_dec;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "00";
--***59 MOV direct,A
				when	"11110101"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE_A;
							sel_forward <= "10";
--***60 MOV direct,Rn
				when	"10001000"|"10001001"|"10001010"|"10001011"|
						"10001100"|"10001101"|"10001110"|"10001111"	=>
							s1 <= DC;
							s2 <= in_Rn_dec;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***61 MOV direct,direct
				when	"10000101"	=>
							s1 <= DC;
							s2 <= inst_byte2;
							d1 <= inst_byte3;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***62 MOV direct,@Ri
				when	"10000110"|"10000111"	=>
							s1 <= DC;
							s2 <= in_Ri_dec;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***63 MOV direct,#data
				when	"01110101"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "00";
--***64 MOV @Ri,A
				when	"11110110"|"11110111"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= in_Ri_dec;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE_A;
							sel_forward <= "10";
--***65 MOV @Ri,direct
				when	"10100110"|"10100111"	=>
							s1 <= DC;
							s2 <= inst_byte2;
							d1 <= in_Ri_dec;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "01";
--***66 MOV @Ri,#data
				when	"01110110"|"01110111"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= in_Ri_dec;
							d2 <= DC;
							alu_oprt <= ALU_OPC_MOVE;
							sel_forward <= "00";
--67 MOV C,bit
--				when	"10100010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--68 MOV bit,C
--				when	"10010010"	=>
--							s1 <= in_bit_dec;
--							s2 <= DC;
--							d1 <= in_bit_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--69 MOV DPTR,#data16
				when	"10010000"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= R_DPH;
							d2 <= R_DPL;
							alu_oprt <= ALU_OPC_MOVE_16;
							sel_forward <= "00";
--70 MOVC A,@A+DPTR
--				when	"10010011"	=>
--							s1 <= R_ACC;
--							s2 <= DC;
--							d1 <= R_ACC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--71 MOVC A,@A+PC
--				when	"10000011"	=>
--							s1 <= R_ACC;
--							s2 <= DC;
--							d1 <= R_ACC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";

--72 MOVX A,@Ri
--				when	"11100010"|"11100011"	=>
--							s1 <= R_ACC;
--							s2 <= DC;
--							d1 <= R_ACC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--73 MOVX A,@DPTR
--				when	"11100000"	=>
--							s1 <= R_ACC;
--							s2 <= DC;
--							d1 <= R_ACC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--74 MOVX @Ri,A
--				when	"11110010"|"11110011"	=>
--							s1 <= R_ACC;
--							s2 <= DC;
--							d1 <= in_Ri_dec;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--75 MOVX @DPTR,A
--				when	"11110000"	=>
--							s1 <= R_ACC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";
--76 MUL AB
--				when	"10100100"	=>
--							s1 <= R_ACC;
--							s2 <= R_B;
--							d1 <= R_ACC;
--							d2 <= R_B;
--							alu_oprt <= ALU_OPC_MUL;
--							sel_forward <= "11";
--***77 NOP
				when	"00000000"	=>
							s1 <= DC;
							s2 <= DC;
							d1 <= DC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_NONE;
							sel_forward <= "00";
--***78 ORL A,Rn
				when	"01001000"|"01001001"|"01001010"|"01001011"|
						"01001100"|"01001101"|"01001110"|"01001111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ORL;
							sel_forward <= "11";
--***79 ORL A,direct
				when	"01000101"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ORL;
							sel_forward <= "11";
--***80 ORL A,@Ri
				when	"01000110"|"01000111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ORL;
							sel_forward <= "11";
--***81 ORL A,#data
				when	"01000100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ORL;
							sel_forward <= "10";
--***82 ORL direct,A
				when	"01000010"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ORL;
							sel_forward <= "11";
--***83 ORL direct,#data
				when	"01000011"	=>
							s1 <= inst_byte2;
							s2 <= DC;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_ORL;
							sel_forward <= "10";
--84 ORL C,bit
--				when	"01110010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ORL;
--							sel_forward <= "00";
--85 ORL C,/bit
--				when	"10100000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_ORL;
--							sel_forward <= "00";

--86 POP direct
--				when	"11010000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= inst_byte2;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--87 PUSH direct
--				when	"11000000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";

--88 RET
--				when	"00100010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--89 RETI
--				when	"00110010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";
--***90 RL A
				when	"00100011"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_RL;
							sel_forward <= "10";
--***91 RLC A
				when	"00110011"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_RLC;
							sel_forward <= "10";
--***92 RR A
				when	"00000011"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_RR;
							sel_forward <= "10";
--***93 RRC A
				when	"00010011"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_RRC;
							sel_forward <= "10";

--94 SETB C
--				when	"11010011"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "00";

--95 SETB bit
--				when	"11010010"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= in_aa;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";

--96 SJMP rel
--				when	"10000000"	=>
--							s1 <= DC;
--							s2 <= DC;
--							d1 <= DC;
--							d2 <= DC;
--							alu_oprt <= ALU_OPC_NONE;
--							sel_forward <= "10";

--***97 SUBB A,Rn
				when	"10011000"|"10011001"|"10011010"|"10011011"|
						"10011100"|"10011101"|"10011110"|"10011111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_SUB;
							sel_forward <= "11";
--***98 SUBB A,direct
				when	"10010101"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_SUB;
							sel_forward <= "11";
--***99 SUBB A,@Ri
				when	"10010110"|"10010111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_SUB;
							sel_forward <= "11";
--***100 SUBB A,#data
				when	"10010100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_SUB;
							sel_forward <= "10";
--***101 SWAP A
				when	"11000100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_SWAP;
							sel_forward <= "10";
--***102 XCH A,Rn
				when	"11001000"|"11001001"|"11001010"|"11001011"|
						"11001100"|"11001101"|"11001110"|"11001111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= in_Rn_dec;
							alu_oprt <= ALU_OPC_XCH;
							sel_forward <= "11";
--***103 XCH A,direct
				when	"11000101"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= inst_byte2;
							alu_oprt <= ALU_OPC_XCH;
							sel_forward <= "11";
--***104 XCH A,@Ri
				when	"11000110"|"11000111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= in_Ri_dec;
							alu_oprt <= ALU_OPC_XCH;
							sel_forward <= "11";
--***105 XCHD A,@Ri
				when	"11010110"|"11010111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= in_Ri_dec;
							alu_oprt <= ALU_OPC_XCHD;
							sel_forward <= "11";

--***106 XRL A,Rn
				when	"01101000"|"01101001"|"01101010"|"01101011"|
						"01101100"|"01101101"|"01101110"|"01101111"	=>
							s1 <= R_ACC;
							s2 <= in_Rn_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_XOR;
							sel_forward <= "11";
--***107 XRL A,direct
				when	"01100101"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_XOR;
							sel_forward <= "11";
--***108 XRL A,@Ri
				when	"01100110"|"01100111"	=>
							s1 <= R_ACC;
							s2 <= in_Ri_dec;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_XOR;
							sel_forward <= "11";
--***109 XRL A,#data
				when	"01100100"	=>
							s1 <= R_ACC;
							s2 <= DC;
							d1 <= R_ACC;
							d2 <= DC;
							alu_oprt <= ALU_OPC_XOR;
							sel_forward <= "10";
--***110 XRL direct,A
				when	"01100010"	=>
							s1 <= R_ACC;
							s2 <= inst_byte2;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_XOR;
							sel_forward <= "11";
--***111 XRL direct,#data
				when	"01100011"	=>
							s1 <= inst_byte2;
							s2 <= DC;
							d1 <= inst_byte2;
							d2 <= DC;
							alu_oprt <= ALU_OPC_XOR;
							sel_forward <= "10";
--112 No command use this value
				when	"10100101" =>
							s1 <= DC;
							s2 <= DC;
							d1 <= DC;
							d2 <= DC;
							alu_oprt <= "-----";
							sel_forward <= "00";
				--------------------------------------------------------------------
				when others =>	-- null;
							s1 <= DC;
							s2 <= DC;
							d1 <= DC;
							d2 <= DC;
							alu_oprt <= "-----";
				--------------------------------------------------------------------
				end case;
--			end if;
	end if;
	end process;
end RTL;