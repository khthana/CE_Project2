library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux18 is
    Port ( in1 : in std_logic_vector(7 downto 0);
           in2 : in std_logic_vector(7 downto 0);
           sel : in std_logic;
           out1 : out std_logic_vector(7 downto 0));
end mux18;

architecture RTL of mux18 is
begin
process(in1,in2,sel)
	begin
		case  sel is
		when '0' => out1 <= in1;
		when '1' => out1 <= in2;
		when others => out1 <= in1;
		end case;
	end process;                                       
end RTL;
