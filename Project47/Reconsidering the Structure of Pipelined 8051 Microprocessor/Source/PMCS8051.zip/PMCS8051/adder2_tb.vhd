
-- VHDL Test Bench Created from source file adder2.vhd -- 03:25:52 09/06/2004
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends 
-- that these types always be used for the top-level I/O of a design in order 
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY adder2_adder2_tb_vhd_tb IS
END adder2_adder2_tb_vhd_tb;

ARCHITECTURE behavior OF adder2_adder2_tb_vhd_tb IS 

	COMPONENT adder2
	PORT(
		in1 : IN std_logic_vector(15 downto 0);
		in2 : IN std_logic_vector(15 downto 0);          
		out1 : OUT std_logic_vector(15 downto 0)
		);
	END COMPONENT;

	SIGNAL in1 :  std_logic_vector(15 downto 0);
	SIGNAL in2 :  std_logic_vector(15 downto 0);
	SIGNAL out1 :  std_logic_vector(15 downto 0);

BEGIN

	uut: adder2 PORT MAP(
		in1 => in1,
		in2 => in2,
		out1 => out1
	);


-- *** Test Bench - User Defined Section ***
	in1 <= "0000000000000000",
		  "0000000000000001" after 10 ns,
		  "0000000000000010" after 20 ns,
		  "0000000000000100" after 30 ns,
		  "0000000000001000" after 40 ns,
		  "0000000000010000" after 50 ns,
		  "0000000000100000" after 60 ns,
		  "0000000001000000" after 70 ns,
		  "0000000010000000" after 80 ns,
		  "0000000100000000" after 90 ns,
		  "0000001000000000" after 100 ns,
		  "0000010000000000" after 110 ns,
		  "0000100000000000" after 120 ns,
		  "0001000000000000" after 130 ns,
		  "0010000000000000" after 140 ns,
		  "0100000000000000" after 150 ns,
		  "1000000000000000" after 160 ns,
		  "0000000000000000" after 170 ns,
		  "0000000011111111" after 180 ns,
		  "1111111100000000" after 190 ns,
		  "1111111111111111" after 200 ns,
		  "0000000000000111" after 210 ns,
		  "0000000000000000" after 220 ns;
 	
	in2 <= "0000000000000000",
		  "1000000000000000" after 10 ns,
		  "0100000000000000" after 20 ns,
		  "0010000000000000" after 30 ns,
		  "0001000000000000" after 40 ns,
		  "0000100000000000" after 50 ns,
		  "0000010000000000" after 60 ns,
		  "0000001000000000" after 70 ns,
		  "0000000100000000" after 80 ns,
		  "0000000010000000" after 90 ns,
		  "0000000010000000" after 100 ns,
		  "0000000001000000" after 110 ns,
		  "0000000000100000" after 120 ns,
		  "0000000000010000" after 130 ns,
		  "0000000000001000" after 140 ns,
		  "0000000000000100" after 150 ns,
		  "0000000000000010" after 160 ns,
		  "0000000000000001" after 170 ns,
		  "ZZZZZZZZZZZZZZZZ" after 180 ns,
		  "1111111111000000" after 190 ns,
		  "1111111111111111" after 200 ns,
		  "1111111111110001" after 210 ns,
		  "0000000000000000" after 220 ns;


   tb : PROCESS
   BEGIN
      wait; -- will wait forever
   END PROCESS;
-- *** End Test Bench - User Defined Section ***

END;
