library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity IDEX is
	port (
			clk	: in std_logic;
			rst	: in std_logic;
			-- Data for Excute Stage 
			in_s1 		: in std_logic_vector(7 downto 0);
			in_s2 		: in std_logic_vector(7 downto 0);
			in_d1 		: in std_logic_vector(7 downto 0);
			in_d2 		: in std_logic_vector(7 downto 0);
			in_A 			: in std_logic_vector(7 downto 0);
			in_B 			: in std_logic_vector(7 downto 0);
			in_Opcode	: in std_logic_vector(4 downto 0);
			out_s1 		: out std_logic_vector(7 downto 0);
			out_s2 		: out std_logic_vector(7 downto 0);
			out_d1 		: out std_logic_vector(7 downto 0);
			out_d2 		: out std_logic_vector(7 downto 0);
			out_A 		: out std_logic_vector(7 downto 0);
			out_B 		: out std_logic_vector(7 downto 0);
			out_Opcode 	: out std_logic_vector(4 downto 0);
			-- Control signal for Execute Stage
--			in_ov					: in	std_logic;
--			in_ac					: in	std_logic;
			in_sel				: in	std_logic_vector(1 downto 0);
--			in_sel_mux16		: in	std_logic_vector(1 downto 0);
--			in_sel_mux17		: in	std_logic_vector(1 downto 0);
--			out_ov				: out	std_logic;
--			out_ac				: out	std_logic;
			out_sel				: out	std_logic_vector(1 downto 0);
--			out_sel_mux16		: out	std_logic_vector(1 downto 0);
--			out_sel_mux17		: out	std_logic_vector(1 downto 0);
			-- Control signal	for Writeback Stage
--			in_w_A				: in std_logic;
--			in_w_B				: in std_logic;
			in_sel_mux10		: in std_logic;
			in_sp_load			: in std_logic;
--			in_sel_mux18		: in	std_logic;
--			in_sel_addr_dec	: in	std_logic;
			in_sel_mux11		: in	std_logic_vector(1 downto 0);
			in_sel_mux13		: in	std_logic;
--			in_wbank0			: in	std_logic;
--			in_wbank1			: in	std_logic;
			in_en					: in	std_logic_vector(1 downto 0);
--			out_w_A				: out std_logic;
--			out_w_B				: out std_logic;
			out_sel_mux10		: out std_logic;
			out_sp_load			: out std_logic;
--			out_sel_mux18		: out	std_logic;
--			out_sel_addr_dec	: out	std_logic;
			out_sel_mux11		: out	std_logic_vector(1 downto 0);
			out_sel_mux13		: out	std_logic;
--			out_wbank0			: out	std_logic;
--			out_wbank1			: out	std_logic;
			out_en				: out	std_logic_vector(1 downto 0)
			);
end IDEX;

architecture RTL of IDEX is
begin
	process(rst,clk)
	begin
		if (rst = '1') then
			out_s1 <= "00000000";
			out_s2 <= "00000000";
			out_d1 <= "00000000";
			out_d2 <= "00000000";
			out_A <= "00000000";
			out_B	<= "00000000";
			out_Opcode <= "00000";
--			out_ov <= '0';
--			out_ac <= '0';
			out_sel <= "00";
--			out_sel_mux16 <= "00";
--			out_sel_mux17 <= "00";
--			out_sel_mux18 <= '0';
--			out_sel_addr_dec <= '0';
			out_sel_mux10 <='0';
			out_sp_load	<='0';
			out_sel_mux11 <= "00";
			out_sel_mux13 <= '0';
--			out_wbank0 <= '0';
--			out_wbank1 <= '0';
			out_en <= "00";
		elsif (rising_edge(clk) and rst = '0' ) then
			out_s1 <= in_s1;
			out_s2 <= in_s2;
			out_d1 <= in_d1;
			out_d2 <= in_d2;
			out_A <= in_A;
			out_B <= in_B;
			out_Opcode <= in_Opcode;
--			out_ov <= in_ov;
--			out_ac <= in_ac;
			out_sel <= in_sel;
--			out_sel_mux16 <= in_sel_mux16;
--			out_sel_mux17 <= in_sel_mux17;
			out_sel_mux10 <=in_sel_mux10;
			out_sp_load	<= in_sp_load;			
--			out_sel_mux18 <= in_sel_mux18;
--			out_sel_addr_dec <= in_sel_addr_dec;
			out_sel_mux11 <= in_sel_mux11;
			out_sel_mux13 <= in_sel_mux13;
--			out_wbank0 <= in_wbank0;
--			out_wbank1 <= in_wbank1;
			out_en <= in_en;
		end if;
	end process;
end RTL;