-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 22 23:50:59 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY rid_tw IS
END rid_tw;

ARCHITECTURE testbench_arch OF rid_tw IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT rid
		PORT (
			data_in : In  std_logic_vector (7 DOWNTO 0);
			addr_in : In  std_logic_vector (2 DOWNTO 0);
			data_out1 : Out  std_logic_vector (7 DOWNTO 0);
			data_out2 : Out  std_logic_vector (7 DOWNTO 0);
			RS_in : In  std_logic_vector (1 DOWNTO 0);
			load_in : In  std_logic;
			rst : In  std_logic;
			clk : In  std_logic
		);
	END COMPONENT;

	SIGNAL data_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL addr_in : std_logic_vector (2 DOWNTO 0);
	SIGNAL data_out1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL data_out2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL RS_in : std_logic_vector (1 DOWNTO 0);
	SIGNAL load_in : std_logic;
	SIGNAL rst : std_logic;
	SIGNAL clk : std_logic;

BEGIN
	UUT : rid
	PORT MAP (
		data_in => data_in,
		addr_in => addr_in,
		data_out1 => data_out1,
		data_out2 => data_out2,
		RS_in => RS_in,
		load_in => load_in,
		rst => rst,
		clk => clk
	);

	PROCESS -- clock process for clk,
	BEGIN
		CLOCK_LOOP : LOOP
		clk <= transport '0';
		WAIT FOR 10 ps;
		clk <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clk <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clk
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_data_out1(
			next_data_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out1 /= next_data_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps data_out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_data_out2(
			next_data_out2 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out2 /= next_data_out2) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps data_out2="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out2);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out2);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		data_in <= transport std_logic_vector'("00000000"); --0
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		load_in <= transport '0';
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		data_in <= transport std_logic_vector'("00000001"); --1
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		data_in <= transport std_logic_vector'("00000010"); --2
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		data_in <= transport std_logic_vector'("00000011"); --3
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		data_in <= transport std_logic_vector'("00000100"); --4
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		data_in <= transport std_logic_vector'("00000101"); --5
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		data_in <= transport std_logic_vector'("00000110"); --6
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		data_in <= transport std_logic_vector'("00000111"); --7
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		data_in <= transport std_logic_vector'("00001000"); --8
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		data_in <= transport std_logic_vector'("00001001"); --9
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		data_in <= transport std_logic_vector'("00001010"); --A
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		data_in <= transport std_logic_vector'("00001011"); --B
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		data_in <= transport std_logic_vector'("00001100"); --C
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		data_in <= transport std_logic_vector'("00001101"); --D
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		data_in <= transport std_logic_vector'("00001110"); --E
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		data_in <= transport std_logic_vector'("00001111"); --F
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		data_in <= transport std_logic_vector'("00010000"); --10
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		data_in <= transport std_logic_vector'("00010001"); --11
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		data_in <= transport std_logic_vector'("00010010"); --12
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		data_in <= transport std_logic_vector'("00010011"); --13
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		data_in <= transport std_logic_vector'("00010100"); --14
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		data_in <= transport std_logic_vector'("00010101"); --15
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		data_in <= transport std_logic_vector'("00010110"); --16
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		data_in <= transport std_logic_vector'("00010111"); --17
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		data_in <= transport std_logic_vector'("00011000"); --18
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		data_in <= transport std_logic_vector'("00011001"); --19
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		data_in <= transport std_logic_vector'("00011010"); --1A
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		data_in <= transport std_logic_vector'("00011011"); --1B
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		data_in <= transport std_logic_vector'("00011100"); --1C
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		data_in <= transport std_logic_vector'("00011101"); --1D
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		load_in <= transport '1';
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		data_in <= transport std_logic_vector'("00011110"); --1E
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		data_in <= transport std_logic_vector'("00011111"); --1F
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		data_in <= transport std_logic_vector'("00100000"); --20
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		data_in <= transport std_logic_vector'("00100001"); --21
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		data_in <= transport std_logic_vector'("00100010"); --22
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		data_in <= transport std_logic_vector'("00100011"); --23
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		data_in <= transport std_logic_vector'("00100100"); --24
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		data_in <= transport std_logic_vector'("00100101"); --25
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		data_in <= transport std_logic_vector'("00100110"); --26
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		data_in <= transport std_logic_vector'("00100111"); --27
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		data_in <= transport std_logic_vector'("00101000"); --28
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		data_in <= transport std_logic_vector'("00101001"); --29
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		data_in <= transport std_logic_vector'("00101010"); --2A
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		load_in <= transport '0';
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4300 ps
		data_in <= transport std_logic_vector'("00101011"); --2B
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=4400 ps
		data_in <= transport std_logic_vector'("00101100"); --2C
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=4500 ps
		data_in <= transport std_logic_vector'("00101101"); --2D
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=4600 ps
		data_in <= transport std_logic_vector'("00101110"); --2E
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=4700 ps
		data_in <= transport std_logic_vector'("00101111"); --2F
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4800 ps
		data_in <= transport std_logic_vector'("00110000"); --30
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=4900 ps
		data_in <= transport std_logic_vector'("00110001"); --31
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=5000 ps
		data_in <= transport std_logic_vector'("00110010"); --32
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=5100 ps
		data_in <= transport std_logic_vector'("00110011"); --33
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=5200 ps
		data_in <= transport std_logic_vector'("00110100"); --34
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5300 ps
		data_in <= transport std_logic_vector'("00110101"); --35
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=5400 ps
		data_in <= transport std_logic_vector'("00110110"); --36
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=5500 ps
		data_in <= transport std_logic_vector'("00110111"); --37
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5600 ps
		data_in <= transport std_logic_vector'("00111000"); --38
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=5700 ps
		data_in <= transport std_logic_vector'("00111001"); --39
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=5800 ps
		data_in <= transport std_logic_vector'("00111010"); --3A
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=5900 ps
		data_in <= transport std_logic_vector'("00111011"); --3B
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=6000 ps
		data_in <= transport std_logic_vector'("00111100"); --3C
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=6100 ps
		data_in <= transport std_logic_vector'("00111101"); --3D
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=6200 ps
		data_in <= transport std_logic_vector'("00111110"); --3E
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=6300 ps
		data_in <= transport std_logic_vector'("00111111"); --3F
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=6400 ps
		data_in <= transport std_logic_vector'("01000000"); --40
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=6500 ps
		data_in <= transport std_logic_vector'("01000001"); --41
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6600 ps
		data_in <= transport std_logic_vector'("01000010"); --42
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=6700 ps
		data_in <= transport std_logic_vector'("01000011"); --43
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=6800 ps
		data_in <= transport std_logic_vector'("01000100"); --44
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6900 ps
		data_in <= transport std_logic_vector'("01000101"); --45
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=7000 ps
		data_in <= transport std_logic_vector'("01000110"); --46
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=7100 ps
		data_in <= transport std_logic_vector'("01000111"); --47
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=7200 ps
		data_in <= transport std_logic_vector'("01001000"); --48
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=7300 ps
		data_in <= transport std_logic_vector'("01001001"); --49
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=7400 ps
		data_in <= transport std_logic_vector'("01001010"); --4A
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=7500 ps
		data_in <= transport std_logic_vector'("01001011"); --4B
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=7600 ps
		data_in <= transport std_logic_vector'("01001100"); --4C
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=7700 ps
		data_in <= transport std_logic_vector'("01001101"); --4D
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=7800 ps
		data_in <= transport std_logic_vector'("01001110"); --4E
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7900 ps
		data_in <= transport std_logic_vector'("01001111"); --4F
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=8000 ps
		data_in <= transport std_logic_vector'("01010000"); --50
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=8100 ps
		data_in <= transport std_logic_vector'("01010001"); --51
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8200 ps
		data_in <= transport std_logic_vector'("01010010"); --52
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=8300 ps
		data_in <= transport std_logic_vector'("01010011"); --53
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=8400 ps
		data_in <= transport std_logic_vector'("01010100"); --54
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=8500 ps
		data_in <= transport std_logic_vector'("01010101"); --55
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=8600 ps
		data_in <= transport std_logic_vector'("01010110"); --56
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=8700 ps
		data_in <= transport std_logic_vector'("01010111"); --57
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=8800 ps
		data_in <= transport std_logic_vector'("01011000"); --58
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=8900 ps
		data_in <= transport std_logic_vector'("01011001"); --59
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=9000 ps
		data_in <= transport std_logic_vector'("01011010"); --5A
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=9100 ps
		data_in <= transport std_logic_vector'("01011011"); --5B
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		rst <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9200 ps
		data_in <= transport std_logic_vector'("01011100"); --5C
		addr_in <= transport std_logic_vector'("100"); --4
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=9300 ps
		data_in <= transport std_logic_vector'("01011101"); --5D
		addr_in <= transport std_logic_vector'("101"); --5
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=9400 ps
		data_in <= transport std_logic_vector'("01011110"); --5E
		addr_in <= transport std_logic_vector'("110"); --6
		RS_in <= transport std_logic_vector'("01"); --1
		rst <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9500 ps
		data_in <= transport std_logic_vector'("01011111"); --5F
		addr_in <= transport std_logic_vector'("111"); --7
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 100 ps; -- Time=9600 ps
		data_in <= transport std_logic_vector'("01100000"); --60
		addr_in <= transport std_logic_vector'("000"); --0
		RS_in <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 100 ps; -- Time=9700 ps
		data_in <= transport std_logic_vector'("01100001"); --61
		addr_in <= transport std_logic_vector'("001"); --1
		RS_in <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 100 ps; -- Time=9800 ps
		data_in <= transport std_logic_vector'("01100010"); --62
		addr_in <= transport std_logic_vector'("010"); --2
		RS_in <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 100 ps; -- Time=9900 ps
		data_in <= transport std_logic_vector'("01100011"); --63
		addr_in <= transport std_logic_vector'("011"); --3
		RS_in <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 110 ps; -- Time=10010 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION rid_cfg OF rid_tw IS
	FOR testbench_arch
	END FOR;
END rid_cfg;
