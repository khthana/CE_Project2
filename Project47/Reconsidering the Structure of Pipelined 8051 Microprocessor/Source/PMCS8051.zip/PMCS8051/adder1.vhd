library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity adder1 is
    Port ( in1 : in std_logic_vector(15 downto 0);
           out1 : out std_logic_vector(15 downto 0));
end adder1;

architecture rtl of adder1 is

begin
	process(in1)
	begin
		out1 <= in1 + 1;
	end process;	

end rtl;
