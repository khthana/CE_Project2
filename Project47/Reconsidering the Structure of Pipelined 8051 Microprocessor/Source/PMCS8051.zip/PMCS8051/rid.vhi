
-- VHDL Instantiation Created from source file rid.vhd -- 23:42:00 03/22/2005
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT rid
	PORT(
		data_in : IN std_logic_vector(7 downto 0);
		addr_in : IN std_logic_vector(2 downto 0);
		RS_in : IN std_logic_vector(1 downto 0);
		load_in : IN std_logic;
		rst : IN std_logic;
		clk : IN std_logic;          
		data_out1 : OUT std_logic_vector(7 downto 0);
		data_out2 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_rid: rid PORT MAP(
		data_in => ,
		addr_in => ,
		data_out1 => ,
		data_out2 => ,
		RS_in => ,
		load_in => ,
		rst => ,
		clk => 
	);


