-- E:\USERS\POLARBEAR\PROJECT\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Feb 14 08:16:27 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY temp_tb IS
END temp_tb;

ARCHITECTURE testbench_arch OF temp_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT temp1
		PORT (
			data_in : In  std_logic_vector (15 DOWNTO 0);
			data_out : Out  std_logic_vector (15 DOWNTO 0);
			load_in : In  std_logic
		);
	END COMPONENT;

	SIGNAL data_in : std_logic_vector (15 DOWNTO 0);
	SIGNAL data_out : std_logic_vector (15 DOWNTO 0);
	SIGNAL load_in : std_logic;

BEGIN
	UUT : temp1
	PORT MAP (
		data_in => data_in,
		data_out => data_out,
		load_in => load_in
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_data_out(
			next_data_out : std_logic_vector (15 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out /= next_data_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns data_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		data_in <= transport std_logic_vector'("0000000000000000"); --0
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		data_in <= transport std_logic_vector'("0000000000000001"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		data_in <= transport std_logic_vector'("0000000000000010"); --2
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		data_in <= transport std_logic_vector'("0000000000000011"); --3
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		data_in <= transport std_logic_vector'("0000000000000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		data_in <= transport std_logic_vector'("0000000000000101"); --5
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		data_in <= transport std_logic_vector'("0000000000000110"); --6
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		data_in <= transport std_logic_vector'("0000000000000111"); --7
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		data_in <= transport std_logic_vector'("0000000000001000"); --8
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		data_in <= transport std_logic_vector'("0000000000001001"); --9
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		data_in <= transport std_logic_vector'("0000000000001010"); --A
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		data_in <= transport std_logic_vector'("0000000000001011"); --B
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		data_in <= transport std_logic_vector'("0000000000001100"); --C
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		data_in <= transport std_logic_vector'("0000000000001101"); --D
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		data_in <= transport std_logic_vector'("0000000000001110"); --E
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		data_in <= transport std_logic_vector'("0000000000001111"); --F
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		data_in <= transport std_logic_vector'("0000000000010000"); --10
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		data_in <= transport std_logic_vector'("0000000000010001"); --11
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		data_in <= transport std_logic_vector'("0000000000010010"); --12
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		data_in <= transport std_logic_vector'("0000000000010011"); --13
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		data_in <= transport std_logic_vector'("0000000000010100"); --14
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		data_in <= transport std_logic_vector'("0000000000010101"); --15
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		data_in <= transport std_logic_vector'("0000000000010110"); --16
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		data_in <= transport std_logic_vector'("0000000000010111"); --17
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		data_in <= transport std_logic_vector'("0000000000011000"); --18
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		data_in <= transport std_logic_vector'("0000000000011001"); --19
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		data_in <= transport std_logic_vector'("0000000000011010"); --1A
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		data_in <= transport std_logic_vector'("0000000000011011"); --1B
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		data_in <= transport std_logic_vector'("0000000000011100"); --1C
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		data_in <= transport std_logic_vector'("0000000000011101"); --1D
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		data_in <= transport std_logic_vector'("0000000000011110"); --1E
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		data_in <= transport std_logic_vector'("0000000000011111"); --1F
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		data_in <= transport std_logic_vector'("0000000000100000"); --20
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		data_in <= transport std_logic_vector'("0000000000100001"); --21
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		data_in <= transport std_logic_vector'("0000000000100010"); --22
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		data_in <= transport std_logic_vector'("0000000000100011"); --23
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		data_in <= transport std_logic_vector'("0000000000100100"); --24
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		data_in <= transport std_logic_vector'("0000000000100101"); --25
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		data_in <= transport std_logic_vector'("0000000000100110"); --26
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		data_in <= transport std_logic_vector'("0000000000100111"); --27
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		data_in <= transport std_logic_vector'("0000000000101000"); --28
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		data_in <= transport std_logic_vector'("0000000000101001"); --29
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		data_in <= transport std_logic_vector'("0000000000101010"); --2A
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		data_in <= transport std_logic_vector'("0000000000101011"); --2B
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		data_in <= transport std_logic_vector'("0000000000101100"); --2C
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		data_in <= transport std_logic_vector'("0000000000101101"); --2D
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		data_in <= transport std_logic_vector'("0000000000101110"); --2E
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		data_in <= transport std_logic_vector'("0000000000101111"); --2F
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		data_in <= transport std_logic_vector'("0000000000110000"); --30
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		data_in <= transport std_logic_vector'("0000000000110001"); --31
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		data_in <= transport std_logic_vector'("0000000000110010"); --32
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		data_in <= transport std_logic_vector'("0000000000110011"); --33
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		data_in <= transport std_logic_vector'("0000000000110100"); --34
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		data_in <= transport std_logic_vector'("0000000000110101"); --35
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		data_in <= transport std_logic_vector'("0000000000110110"); --36
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		data_in <= transport std_logic_vector'("0000000000110111"); --37
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		data_in <= transport std_logic_vector'("0000000000111000"); --38
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		data_in <= transport std_logic_vector'("0000000000111001"); --39
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		data_in <= transport std_logic_vector'("0000000000111010"); --3A
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		data_in <= transport std_logic_vector'("0000000000111011"); --3B
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		data_in <= transport std_logic_vector'("0000000000111100"); --3C
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		data_in <= transport std_logic_vector'("0000000000111101"); --3D
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		data_in <= transport std_logic_vector'("0000000000111110"); --3E
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		data_in <= transport std_logic_vector'("0000000000111111"); --3F
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		data_in <= transport std_logic_vector'("0000000001000000"); --40
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		data_in <= transport std_logic_vector'("0000000001000001"); --41
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		data_in <= transport std_logic_vector'("0000000001000010"); --42
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		data_in <= transport std_logic_vector'("0000000001000011"); --43
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		data_in <= transport std_logic_vector'("0000000001000100"); --44
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		data_in <= transport std_logic_vector'("0000000001000101"); --45
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		data_in <= transport std_logic_vector'("0000000001000110"); --46
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		data_in <= transport std_logic_vector'("0000000001000111"); --47
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		data_in <= transport std_logic_vector'("0000000001001000"); --48
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		data_in <= transport std_logic_vector'("0000000001001001"); --49
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		data_in <= transport std_logic_vector'("0000000001001010"); --4A
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		data_in <= transport std_logic_vector'("0000000001001011"); --4B
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		data_in <= transport std_logic_vector'("0000000001001100"); --4C
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		data_in <= transport std_logic_vector'("0000000001001101"); --4D
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		data_in <= transport std_logic_vector'("0000000001001110"); --4E
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		data_in <= transport std_logic_vector'("0000000001001111"); --4F
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		data_in <= transport std_logic_vector'("0000000001010000"); --50
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		data_in <= transport std_logic_vector'("0000000001010001"); --51
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		data_in <= transport std_logic_vector'("0000000001010010"); --52
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		data_in <= transport std_logic_vector'("0000000001010011"); --53
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		data_in <= transport std_logic_vector'("0000000001010100"); --54
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		data_in <= transport std_logic_vector'("0000000001010101"); --55
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		data_in <= transport std_logic_vector'("0000000001010110"); --56
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		data_in <= transport std_logic_vector'("0000000001010111"); --57
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		data_in <= transport std_logic_vector'("0000000001011000"); --58
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		data_in <= transport std_logic_vector'("0000000001011001"); --59
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		data_in <= transport std_logic_vector'("0000000001011010"); --5A
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		data_in <= transport std_logic_vector'("0000000001011011"); --5B
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		data_in <= transport std_logic_vector'("0000000001011100"); --5C
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		data_in <= transport std_logic_vector'("0000000001011101"); --5D
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		data_in <= transport std_logic_vector'("0000000001011110"); --5E
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		data_in <= transport std_logic_vector'("0000000001011111"); --5F
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		data_in <= transport std_logic_vector'("0000000001100000"); --60
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		data_in <= transport std_logic_vector'("0000000001100001"); --61
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		data_in <= transport std_logic_vector'("0000000001100010"); --62
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		data_in <= transport std_logic_vector'("0000000001100011"); --63
		-- --------------------
		WAIT FOR 15 ns; -- Time=1005 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION temp1_cfg OF temp_tb IS
	FOR testbench_arch
	END FOR;
END temp1_cfg;
