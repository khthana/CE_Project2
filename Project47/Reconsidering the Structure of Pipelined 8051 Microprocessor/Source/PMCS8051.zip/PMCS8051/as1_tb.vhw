-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Sun Mar 20 11:06:35 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY as1_tb IS
END as1_tb;

ARCHITECTURE testbench_arch OF as1_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT as1
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			sel : In  std_logic;
			out1 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL sel : std_logic;
	SIGNAL out1 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : as1
	PORT MAP (
		in1 => in1,
		sel => sel,
		out1 => out1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("01111001"); --79
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("11010000"); --D0
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("00001101"); --D
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("11011101"); --DD
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("01101100"); --6C
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("01100111"); --67
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("01101101"); --6D
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("11100010"); --E2
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("00011010"); --1A
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("11001010"); --CA
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("11100100"); --E4
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("01001011"); --4B
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("01110111"); --77
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("11000000"); --C0
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("00111001"); --39
		sel <= transport '0';
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("11001100"); --CC
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("10001110"); --8E
		sel <= transport '1';
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("10011100"); --9C
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("11100101"); --E5
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION as1_cfg OF as1_tb IS
	FOR testbench_arch
	END FOR;
END as1_cfg;
