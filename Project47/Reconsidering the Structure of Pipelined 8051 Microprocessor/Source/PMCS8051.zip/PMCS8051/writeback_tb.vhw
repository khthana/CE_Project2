-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Wed Mar 23 12:30:56 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY writeback_tb IS
END writeback_tb;

ARCHITECTURE testbench_arch OF writeback_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT writeback
		PORT (
			d11 : In  std_logic_vector (7 DOWNTO 0);
			d22 : In  std_logic_vector (7 DOWNTO 0);
			R_A : In  std_logic_vector (7 DOWNTO 0);
			R_B : In  std_logic_vector (7 DOWNTO 0);
			W_DPH : Out  std_logic;
			W_DPL : Out  std_logic;
			di_DPH : Out  std_logic_vector (7 DOWNTO 0);
			di_DPL : Out  std_logic_vector (7 DOWNTO 0);
			w_data0 : Out  std_logic_vector (7 DOWNTO 0);
			w_addr0 : Out  std_logic_vector (7 DOWNTO 0);
			w_data1 : Out  std_logic_vector (7 DOWNTO 0);
			w_addr1 : Out  std_logic_vector (7 DOWNTO 0);
			wr_bank0 : Out  std_logic;
			wr_bank1 : Out  std_logic;
			W_A : Out  std_logic;
			di_A : Out  std_logic_vector (7 DOWNTO 0);
			W_B : Out  std_logic;
			di_B : Out  std_logic_vector (7 DOWNTO 0);
			W_psw : Out  std_logic;
			di_psw : Out  std_logic_vector (7 DOWNTO 0);
			load_rid : Out  std_logic;
			din_rid : Out  std_logic_vector (7 DOWNTO 0);
			addr_rid : Out  std_logic_vector (2 DOWNTO 0);
			load_p0 : Out  std_logic;
			p0_in : Out  std_logic_vector (7 DOWNTO 0);
			load_p1 : Out  std_logic;
			p1_in : Out  std_logic_vector (7 DOWNTO 0);
			load_p2 : Out  std_logic;
			p2_in : Out  std_logic_vector (7 DOWNTO 0);
			load_p3 : Out  std_logic;
			p3_in : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL d11 : std_logic_vector (7 DOWNTO 0);
	SIGNAL d22 : std_logic_vector (7 DOWNTO 0);
	SIGNAL R_A : std_logic_vector (7 DOWNTO 0);
	SIGNAL R_B : std_logic_vector (7 DOWNTO 0);
	SIGNAL W_DPH : std_logic;
	SIGNAL W_DPL : std_logic;
	SIGNAL di_DPH : std_logic_vector (7 DOWNTO 0);
	SIGNAL di_DPL : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_data0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_addr0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_data1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_addr1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL wr_bank0 : std_logic;
	SIGNAL wr_bank1 : std_logic;
	SIGNAL W_A : std_logic;
	SIGNAL di_A : std_logic_vector (7 DOWNTO 0);
	SIGNAL W_B : std_logic;
	SIGNAL di_B : std_logic_vector (7 DOWNTO 0);
	SIGNAL W_psw : std_logic;
	SIGNAL di_psw : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_rid : std_logic;
	SIGNAL din_rid : std_logic_vector (7 DOWNTO 0);
	SIGNAL addr_rid : std_logic_vector (2 DOWNTO 0);
	SIGNAL load_p0 : std_logic;
	SIGNAL p0_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_p1 : std_logic;
	SIGNAL p1_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_p2 : std_logic;
	SIGNAL p2_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_p3 : std_logic;
	SIGNAL p3_in : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : writeback
	PORT MAP (
		d11 => d11,
		d22 => d22,
		R_A => R_A,
		R_B => R_B,
		W_DPH => W_DPH,
		W_DPL => W_DPL,
		di_DPH => di_DPH,
		di_DPL => di_DPL,
		w_data0 => w_data0,
		w_addr0 => w_addr0,
		w_data1 => w_data1,
		w_addr1 => w_addr1,
		wr_bank0 => wr_bank0,
		wr_bank1 => wr_bank1,
		W_A => W_A,
		di_A => di_A,
		W_B => W_B,
		di_B => di_B,
		W_psw => W_psw,
		di_psw => di_psw,
		load_rid => load_rid,
		din_rid => din_rid,
		addr_rid => addr_rid,
		load_p0 => load_p0,
		p0_in => p0_in,
		load_p1 => load_p1,
		p1_in => p1_in,
		load_p2 => load_p2,
		p2_in => p2_in,
		load_p3 => load_p3,
		p3_in => p3_in
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_w_data0(
			next_w_data0 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (w_data0 /= next_w_data0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps w_data0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, w_data0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_w_data0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_w_addr0(
			next_w_addr0 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (w_addr0 /= next_w_addr0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps w_addr0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, w_addr0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_w_addr0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_w_data1(
			next_w_data1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (w_data1 /= next_w_data1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps w_data1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, w_data1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_w_data1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_w_addr1(
			next_w_addr1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (w_addr1 /= next_w_addr1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps w_addr1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, w_addr1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_w_addr1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_W_DPH(
			next_W_DPH : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (W_DPH /= next_W_DPH) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps W_DPH="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, W_DPH);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_W_DPH);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_W_DPL(
			next_W_DPL : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (W_DPL /= next_W_DPL) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps W_DPL="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, W_DPL);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_W_DPL);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_di_DPH(
			next_di_DPH : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (di_DPH /= next_di_DPH) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps di_DPH="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, di_DPH);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_di_DPH);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_di_DPL(
			next_di_DPL : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (di_DPL /= next_di_DPL) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps di_DPL="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, di_DPL);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_di_DPL);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_wr_bank0(
			next_wr_bank0 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (wr_bank0 /= next_wr_bank0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps wr_bank0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, wr_bank0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_wr_bank0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_wr_bank1(
			next_wr_bank1 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (wr_bank1 /= next_wr_bank1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps wr_bank1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, wr_bank1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_wr_bank1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_W_A(
			next_W_A : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (W_A /= next_W_A) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps W_A="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, W_A);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_W_A);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_di_A(
			next_di_A : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (di_A /= next_di_A) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps di_A="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, di_A);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_di_A);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_W_B(
			next_W_B : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (W_B /= next_W_B) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps W_B="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, W_B);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_W_B);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_di_B(
			next_di_B : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (di_B /= next_di_B) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps di_B="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, di_B);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_di_B);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_W_psw(
			next_W_psw : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (W_psw /= next_W_psw) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps W_psw="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, W_psw);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_W_psw);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_di_psw(
			next_di_psw : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (di_psw /= next_di_psw) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps di_psw="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, di_psw);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_di_psw);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_load_rid(
			next_load_rid : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (load_rid /= next_load_rid) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps load_rid="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, load_rid);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_load_rid);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_din_rid(
			next_din_rid : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (din_rid /= next_din_rid) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps din_rid="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, din_rid);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_din_rid);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_addr_rid(
			next_addr_rid : std_logic_vector (2 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (addr_rid /= next_addr_rid) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps addr_rid="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, addr_rid);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_addr_rid);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_load_p0(
			next_load_p0 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (load_p0 /= next_load_p0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps load_p0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, load_p0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_load_p0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p0_in(
			next_p0_in : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p0_in /= next_p0_in) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p0_in="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p0_in);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p0_in);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_load_p1(
			next_load_p1 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (load_p1 /= next_load_p1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps load_p1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, load_p1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_load_p1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p1_in(
			next_p1_in : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p1_in /= next_p1_in) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p1_in="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p1_in);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p1_in);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_load_p2(
			next_load_p2 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (load_p2 /= next_load_p2) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps load_p2="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, load_p2);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_load_p2);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p2_in(
			next_p2_in : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p2_in /= next_p2_in) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p2_in="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p2_in);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p2_in);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_load_p3(
			next_load_p3 : std_logic;
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (load_p3 /= next_load_p3) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps load_p3="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, load_p3);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_load_p3);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_p3_in(
			next_p3_in : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (p3_in /= next_p3_in) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps p3_in="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, p3_in);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_p3_in);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		d11 <= transport std_logic_vector'("01010011"); --53
		d22 <= transport std_logic_vector'("01010010"); --52
		R_A <= transport std_logic_vector'("01010001"); --51
		R_B <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 10 ps; -- Time=10 ps
		d11 <= transport std_logic_vector'("10001101"); --8D
		d22 <= transport std_logic_vector'("01110001"); --71
		R_A <= transport std_logic_vector'("01010110"); --56
		R_B <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 10 ps; -- Time=20 ps
		d11 <= transport std_logic_vector'("01001011"); --4B
		d22 <= transport std_logic_vector'("00011110"); --1E
		R_A <= transport std_logic_vector'("11110010"); --F2
		R_B <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 10 ps; -- Time=30 ps
		d11 <= transport std_logic_vector'("00000001"); --1
		d22 <= transport std_logic_vector'("--------"); ---
		R_A <= transport std_logic_vector'("01000010"); --42
		R_B <= transport std_logic_vector'("01100010"); --62
		-- --------------------
		WAIT FOR 10 ps; -- Time=40 ps
		d11 <= transport std_logic_vector'("01100110"); --66
		d22 <= transport std_logic_vector'("10000100"); --84
		R_A <= transport std_logic_vector'("10100010"); --A2
		R_B <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 10 ps; -- Time=50 ps
		d11 <= transport std_logic_vector'("01101110"); --6E
		d22 <= transport std_logic_vector'("10010000"); --90
		R_A <= transport std_logic_vector'("10110001"); --B1
		R_B <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 10 ps; -- Time=60 ps
		d11 <= transport std_logic_vector'("01001101"); --4D
		d22 <= transport std_logic_vector'("11001100"); --CC
		R_A <= transport std_logic_vector'("01001011"); --4B
		R_B <= transport std_logic_vector'("11001010"); --CA
		-- --------------------
		WAIT FOR 10 ps; -- Time=70 ps
		d11 <= transport std_logic_vector'("01111010"); --7A
		d22 <= transport std_logic_vector'("00000011"); --3
		R_A <= transport std_logic_vector'("10001101"); --8D
		R_B <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 10 ps; -- Time=80 ps
		d11 <= transport std_logic_vector'("10101000"); --A8
		d22 <= transport std_logic_vector'("00111110"); --3E
		R_A <= transport std_logic_vector'("11010100"); --D4
		R_B <= transport std_logic_vector'("--------"); ---
		-- --------------------
		WAIT FOR 10 ps; -- Time=90 ps
		d11 <= transport std_logic_vector'("11001101"); --CD
		d22 <= transport std_logic_vector'("11000101"); --C5
		R_A <= transport std_logic_vector'("10111101"); --BD
		R_B <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 10 ps; -- Time=100 ps
		d11 <= transport std_logic_vector'("00011110"); --1E
		d22 <= transport std_logic_vector'("00100010"); --22
		R_A <= transport std_logic_vector'("00100101"); --25
		R_B <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 10 ps; -- Time=110 ps
		d11 <= transport std_logic_vector'("00010000"); --10
		d22 <= transport std_logic_vector'("--------"); ---
		R_A <= transport std_logic_vector'("00101001"); --29
		R_B <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 10 ps; -- Time=120 ps
		d11 <= transport std_logic_vector'("11100000"); --E0
		d22 <= transport std_logic_vector'("10111111"); --BF
		R_A <= transport std_logic_vector'("00100110"); --26
		R_B <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 10 ps; -- Time=130 ps
		d11 <= transport std_logic_vector'("--------"); ---
		d22 <= transport std_logic_vector'("--------"); ---
		R_A <= transport std_logic_vector'("10111001"); --B9
		R_B <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 10 ps; -- Time=140 ps
		d11 <= transport std_logic_vector'("11111110"); --FE
		d22 <= transport std_logic_vector'("01011110"); --5E
		R_A <= transport std_logic_vector'("10111111"); --BF
		R_B <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 10 ps; -- Time=150 ps
		d11 <= transport std_logic_vector'("00000101"); --5
		d22 <= transport std_logic_vector'("10101101"); --AD
		R_A <= transport std_logic_vector'("01010101"); --55
		R_B <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 10 ps; -- Time=160 ps
		d11 <= transport std_logic_vector'("10110111"); --B7
		d22 <= transport std_logic_vector'("01000111"); --47
		R_A <= transport std_logic_vector'("11011000"); --D8
		R_B <= transport std_logic_vector'("01101000"); --68
		-- --------------------
		WAIT FOR 10 ps; -- Time=170 ps
		d11 <= transport std_logic_vector'("00000111"); --7
		d22 <= transport std_logic_vector'("01110110"); --76
		R_A <= transport std_logic_vector'("11100101"); --E5
		R_B <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 10 ps; -- Time=180 ps
		d11 <= transport std_logic_vector'("00101011"); --2B
		d22 <= transport std_logic_vector'("11000010"); --C2
		R_A <= transport std_logic_vector'("01011001"); --59
		R_B <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 10 ps; -- Time=190 ps
		d11 <= transport std_logic_vector'("10011000"); --98
		d22 <= transport std_logic_vector'("11110101"); --F5
		R_A <= transport std_logic_vector'("01010001"); --51
		R_B <= transport std_logic_vector'("10101101"); --AD
		-- --------------------
		WAIT FOR 10 ps; -- Time=200 ps
		d11 <= transport std_logic_vector'("00000011"); --3
		d22 <= transport std_logic_vector'("00010111"); --17
		R_A <= transport std_logic_vector'("00101010"); --2A
		R_B <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 10 ps; -- Time=210 ps
		d11 <= transport std_logic_vector'("01100001"); --61
		d22 <= transport std_logic_vector'("01110001"); --71
		R_A <= transport std_logic_vector'("10000001"); --81
		R_B <= transport std_logic_vector'("10010001"); --91
		-- --------------------
		WAIT FOR 10 ps; -- Time=220 ps
		d11 <= transport std_logic_vector'("11100111"); --E7
		d22 <= transport std_logic_vector'("10001101"); --8D
		R_A <= transport std_logic_vector'("00110011"); --33
		R_B <= transport std_logic_vector'("11011001"); --D9
		-- --------------------
		WAIT FOR 10 ps; -- Time=230 ps
		d11 <= transport std_logic_vector'("00001010"); --A
		d22 <= transport std_logic_vector'("00110100"); --34
		R_A <= transport std_logic_vector'("01011101"); --5D
		R_B <= transport std_logic_vector'("10000111"); --87
		-- --------------------
		WAIT FOR 10 ps; -- Time=240 ps
		d11 <= transport std_logic_vector'("01111110"); --7E
		d22 <= transport std_logic_vector'("01101101"); --6D
		R_B <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 10 ps; -- Time=250 ps
		d11 <= transport std_logic_vector'("00111010"); --3A
		d22 <= transport std_logic_vector'("10000100"); --84
		R_A <= transport std_logic_vector'("11001110"); --CE
		R_B <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 10 ps; -- Time=260 ps
		d11 <= transport std_logic_vector'("01110001"); --71
		d22 <= transport std_logic_vector'("11111111"); --FF
		R_A <= transport std_logic_vector'("10001110"); --8E
		R_B <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 10 ps; -- Time=270 ps
		d11 <= transport std_logic_vector'("10011001"); --99
		d22 <= transport std_logic_vector'("10101010"); --AA
		R_A <= transport std_logic_vector'("10111010"); --BA
		R_B <= transport std_logic_vector'("11001010"); --CA
		-- --------------------
		WAIT FOR 10 ps; -- Time=280 ps
		d11 <= transport std_logic_vector'("01100111"); --67
		d22 <= transport std_logic_vector'("10001011"); --8B
		R_A <= transport std_logic_vector'("10101111"); --AF
		R_B <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 10 ps; -- Time=290 ps
		d11 <= transport std_logic_vector'("11010000"); --D0
		d22 <= transport std_logic_vector'("11101110"); --EE
		R_A <= transport std_logic_vector'("00001011"); --B
		R_B <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 10 ps; -- Time=300 ps
		d11 <= transport std_logic_vector'("00001001"); --9
		d22 <= transport std_logic_vector'("01011001"); --59
		R_A <= transport std_logic_vector'("10101001"); --A9
		R_B <= transport std_logic_vector'("11111000"); --F8
		-- --------------------
		WAIT FOR 10 ps; -- Time=310 ps
		d11 <= transport std_logic_vector'("10000111"); --87
		d22 <= transport std_logic_vector'("10010111"); --97
		R_A <= transport std_logic_vector'("10100111"); --A7
		R_B <= transport std_logic_vector'("10110111"); --B7
		-- --------------------
		WAIT FOR 10 ps; -- Time=320 ps
		d11 <= transport std_logic_vector'("11111111"); --FF
		d22 <= transport std_logic_vector'("10110001"); --B1
		R_A <= transport std_logic_vector'("01100010"); --62
		R_B <= transport std_logic_vector'("00010100"); --14
		-- --------------------
		WAIT FOR 10 ps; -- Time=330 ps
		d11 <= transport std_logic_vector'("01100101"); --65
		d22 <= transport std_logic_vector'("11101111"); --EF
		R_A <= transport std_logic_vector'("01111000"); --78
		R_B <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 10 ps; -- Time=340 ps
		d11 <= transport std_logic_vector'("11110000"); --F0
		d22 <= transport std_logic_vector'("11011010"); --DA
		R_A <= transport std_logic_vector'("11000100"); --C4
		R_B <= transport std_logic_vector'("10101110"); --AE
		-- --------------------
		WAIT FOR 10 ps; -- Time=350 ps
		d11 <= transport std_logic_vector'("00010011"); --13
		d22 <= transport std_logic_vector'("00111100"); --3C
		R_A <= transport std_logic_vector'("01100100"); --64
		R_B <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 10 ps; -- Time=360 ps
		d11 <= transport std_logic_vector'("10000101"); --85
		d22 <= transport std_logic_vector'("00011101"); --1D
		R_A <= transport std_logic_vector'("10110110"); --B6
		R_B <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 10 ps; -- Time=370 ps
		d11 <= transport std_logic_vector'("00111001"); --39
		d22 <= transport std_logic_vector'("11000111"); --C7
		R_A <= transport std_logic_vector'("01010101"); --55
		R_B <= transport std_logic_vector'("11100011"); --E3
		-- --------------------
		WAIT FOR 10 ps; -- Time=380 ps
		d11 <= transport std_logic_vector'("01100101"); --65
		d22 <= transport std_logic_vector'("11000010"); --C2
		R_A <= transport std_logic_vector'("00011111"); --1F
		R_B <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 10 ps; -- Time=390 ps
		d11 <= transport std_logic_vector'("01111110"); --7E
		d22 <= transport std_logic_vector'("11011000"); --D8
		R_A <= transport std_logic_vector'("00110010"); --32
		R_B <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 10 ps; -- Time=400 ps
		d11 <= transport std_logic_vector'("00111000"); --38
		d22 <= transport std_logic_vector'("00010001"); --11
		R_A <= transport std_logic_vector'("11101001"); --E9
		R_B <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 10 ps; -- Time=410 ps
		d11 <= transport std_logic_vector'("10001010"); --8A
		d22 <= transport std_logic_vector'("10110110"); --B6
		R_A <= transport std_logic_vector'("11100011"); --E3
		R_B <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 10 ps; -- Time=420 ps
		d11 <= transport std_logic_vector'("10101000"); --A8
		d22 <= transport std_logic_vector'("01010001"); --51
		R_A <= transport std_logic_vector'("11111011"); --FB
		R_B <= transport std_logic_vector'("10100101"); --A5
		-- --------------------
		WAIT FOR 10 ps; -- Time=430 ps
		d11 <= transport std_logic_vector'("00000110"); --6
		d22 <= transport std_logic_vector'("10101011"); --AB
		R_A <= transport std_logic_vector'("01001111"); --4F
		R_B <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 10 ps; -- Time=440 ps
		d11 <= transport std_logic_vector'("01011011"); --5B
		d22 <= transport std_logic_vector'("11001100"); --CC
		R_A <= transport std_logic_vector'("00111101"); --3D
		R_B <= transport std_logic_vector'("10101110"); --AE
		-- --------------------
		WAIT FOR 10 ps; -- Time=450 ps
		d11 <= transport std_logic_vector'("10011010"); --9A
		d22 <= transport std_logic_vector'("11111101"); --FD
		R_A <= transport std_logic_vector'("01100000"); --60
		R_B <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 10 ps; -- Time=460 ps
		d11 <= transport std_logic_vector'("11111001"); --F9
		d22 <= transport std_logic_vector'("11001000"); --C8
		R_A <= transport std_logic_vector'("10010111"); --97
		R_B <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ps; -- Time=470 ps
		d11 <= transport std_logic_vector'("11101101"); --ED
		d22 <= transport std_logic_vector'("11110101"); --F5
		R_A <= transport std_logic_vector'("11111101"); --FD
		R_B <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 10 ps; -- Time=480 ps
		d11 <= transport std_logic_vector'("00101011"); --2B
		d22 <= transport std_logic_vector'("10001110"); --8E
		R_A <= transport std_logic_vector'("11110001"); --F1
		R_B <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 10 ps; -- Time=490 ps
		d11 <= transport std_logic_vector'("10101000"); --A8
		d22 <= transport std_logic_vector'("11011011"); --DB
		R_A <= transport std_logic_vector'("00001110"); --E
		R_B <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 10 ps; -- Time=500 ps
		d11 <= transport std_logic_vector'("10011001"); --99
		d22 <= transport std_logic_vector'("01100110"); --66
		R_A <= transport std_logic_vector'("00110011"); --33
		R_B <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 10 ps; -- Time=510 ps
		d11 <= transport std_logic_vector'("01110010"); --72
		d22 <= transport std_logic_vector'("11110111"); --F7
		R_A <= transport std_logic_vector'("01111100"); --7C
		-- --------------------
		WAIT FOR 10 ps; -- Time=520 ps
		d11 <= transport std_logic_vector'("11101010"); --EA
		d22 <= transport std_logic_vector'("10010111"); --97
		R_A <= transport std_logic_vector'("01000101"); --45
		R_B <= transport std_logic_vector'("11110011"); --F3
		-- --------------------
		WAIT FOR 10 ps; -- Time=530 ps
		d11 <= transport std_logic_vector'("11110100"); --F4
		d22 <= transport std_logic_vector'("10010000"); --90
		R_A <= transport std_logic_vector'("00101101"); --2D
		R_B <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 10 ps; -- Time=540 ps
		d11 <= transport std_logic_vector'("11000110"); --C6
		d22 <= transport std_logic_vector'("01101011"); --6B
		R_A <= transport std_logic_vector'("00001111"); --F
		R_B <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 10 ps; -- Time=550 ps
		d11 <= transport std_logic_vector'("11010110"); --D6
		d22 <= transport std_logic_vector'("11110000"); --F0
		R_A <= transport std_logic_vector'("00001010"); --A
		R_B <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 10 ps; -- Time=560 ps
		d11 <= transport std_logic_vector'("11010111"); --D7
		d22 <= transport std_logic_vector'("00101000"); --28
		R_A <= transport std_logic_vector'("01111010"); --7A
		R_B <= transport std_logic_vector'("11001011"); --CB
		-- --------------------
		WAIT FOR 10 ps; -- Time=570 ps
		d11 <= transport std_logic_vector'("10111111"); --BF
		d22 <= transport std_logic_vector'("01011101"); --5D
		R_A <= transport std_logic_vector'("11111011"); --FB
		R_B <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 10 ps; -- Time=580 ps
		d11 <= transport std_logic_vector'("11000010"); --C2
		d22 <= transport std_logic_vector'("00010111"); --17
		R_A <= transport std_logic_vector'("01101100"); --6C
		R_B <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 10 ps; -- Time=590 ps
		d11 <= transport std_logic_vector'("01010111"); --57
		d22 <= transport std_logic_vector'("00100000"); --20
		R_A <= transport std_logic_vector'("11101001"); --E9
		R_B <= transport std_logic_vector'("10110010"); --B2
		-- --------------------
		WAIT FOR 10 ps; -- Time=600 ps
		d11 <= transport std_logic_vector'("00110010"); --32
		d22 <= transport std_logic_vector'("10000000"); --80
		R_A <= transport std_logic_vector'("11001110"); --CE
		R_B <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 10 ps; -- Time=610 ps
		d11 <= transport std_logic_vector'("01000111"); --47
		d22 <= transport std_logic_vector'("10000001"); --81
		R_A <= transport std_logic_vector'("10111010"); --BA
		R_B <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 10 ps; -- Time=620 ps
		d11 <= transport std_logic_vector'("11001101"); --CD
		d22 <= transport std_logic_vector'("10101011"); --AB
		R_A <= transport std_logic_vector'("10001001"); --89
		R_B <= transport std_logic_vector'("01100111"); --67
		-- --------------------
		WAIT FOR 10 ps; -- Time=630 ps
		d11 <= transport std_logic_vector'("00110111"); --37
		d22 <= transport std_logic_vector'("11000111"); --C7
		R_A <= transport std_logic_vector'("01011000"); --58
		R_B <= transport std_logic_vector'("11101000"); --E8
		-- --------------------
		WAIT FOR 10 ps; -- Time=640 ps
		d11 <= transport std_logic_vector'("00111011"); --3B
		d22 <= transport std_logic_vector'("11011111"); --DF
		R_A <= transport std_logic_vector'("10000011"); --83
		R_B <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 10 ps; -- Time=650 ps
		d11 <= transport std_logic_vector'("11001110"); --CE
		d22 <= transport std_logic_vector'("00111100"); --3C
		R_A <= transport std_logic_vector'("10101001"); --A9
		R_B <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 10 ps; -- Time=660 ps
		d11 <= transport std_logic_vector'("00100101"); --25
		d22 <= transport std_logic_vector'("01100110"); --66
		R_A <= transport std_logic_vector'("10100110"); --A6
		R_B <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 10 ps; -- Time=670 ps
		d11 <= transport std_logic_vector'("10110101"); --B5
		d22 <= transport std_logic_vector'("00100110"); --26
		R_A <= transport std_logic_vector'("10010111"); --97
		R_B <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 10 ps; -- Time=680 ps
		d11 <= transport std_logic_vector'("00110011"); --33
		d22 <= transport std_logic_vector'("10000110"); --86
		R_A <= transport std_logic_vector'("11011001"); --D9
		R_B <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 10 ps; -- Time=690 ps
		d11 <= transport std_logic_vector'("10010100"); --94
		d22 <= transport std_logic_vector'("11001110"); --CE
		R_A <= transport std_logic_vector'("00001001"); --9
		R_B <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 10 ps; -- Time=700 ps
		d11 <= transport std_logic_vector'("00001100"); --C
		d22 <= transport std_logic_vector'("10001000"); --88
		R_A <= transport std_logic_vector'("00000011"); --3
		R_B <= transport std_logic_vector'("01111111"); --7F
		-- --------------------
		WAIT FOR 10 ps; -- Time=710 ps
		d11 <= transport std_logic_vector'("00010010"); --12
		d22 <= transport std_logic_vector'("01111100"); --7C
		R_A <= transport std_logic_vector'("11100110"); --E6
		R_B <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 10 ps; -- Time=720 ps
		d11 <= transport std_logic_vector'("01011001"); --59
		d22 <= transport std_logic_vector'("10110100"); --B4
		R_A <= transport std_logic_vector'("00001110"); --E
		R_B <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ps; -- Time=730 ps
		d11 <= transport std_logic_vector'("11010111"); --D7
		d22 <= transport std_logic_vector'("01111000"); --78
		R_A <= transport std_logic_vector'("00011000"); --18
		R_B <= transport std_logic_vector'("10111001"); --B9
		-- --------------------
		WAIT FOR 10 ps; -- Time=740 ps
		d11 <= transport std_logic_vector'("11000001"); --C1
		d22 <= transport std_logic_vector'("01010001"); --51
		R_A <= transport std_logic_vector'("11100001"); --E1
		R_B <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 10 ps; -- Time=750 ps
		d11 <= transport std_logic_vector'("10001100"); --8C
		d22 <= transport std_logic_vector'("00001001"); --9
		R_A <= transport std_logic_vector'("10000110"); --86
		R_B <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 10 ps; -- Time=760 ps
		d11 <= transport std_logic_vector'("11101101"); --ED
		d22 <= transport std_logic_vector'("10101001"); --A9
		R_A <= transport std_logic_vector'("01100100"); --64
		R_B <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 10 ps; -- Time=770 ps
		d11 <= transport std_logic_vector'("11011001"); --D9
		d22 <= transport std_logic_vector'("01111000"); --78
		R_A <= transport std_logic_vector'("00011000"); --18
		R_B <= transport std_logic_vector'("10111000"); --B8
		-- --------------------
		WAIT FOR 10 ps; -- Time=780 ps
		d11 <= transport std_logic_vector'("10000100"); --84
		d22 <= transport std_logic_vector'("00000010"); --2
		R_A <= transport std_logic_vector'("01111111"); --7F
		R_B <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 10 ps; -- Time=790 ps
		d11 <= transport std_logic_vector'("01100101"); --65
		d22 <= transport std_logic_vector'("00001110"); --E
		R_A <= transport std_logic_vector'("10110110"); --B6
		R_B <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 10 ps; -- Time=800 ps
		d11 <= transport std_logic_vector'("00101111"); --2F
		d22 <= transport std_logic_vector'("10100101"); --A5
		R_A <= transport std_logic_vector'("00011010"); --1A
		R_B <= transport std_logic_vector'("10001111"); --8F
		-- --------------------
		WAIT FOR 10 ps; -- Time=810 ps
		d11 <= transport std_logic_vector'("11011001"); --D9
		d22 <= transport std_logic_vector'("00010000"); --10
		R_A <= transport std_logic_vector'("01001000"); --48
		R_B <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 10 ps; -- Time=820 ps
		d11 <= transport std_logic_vector'("10010110"); --96
		d22 <= transport std_logic_vector'("11011010"); --DA
		R_A <= transport std_logic_vector'("00011101"); --1D
		R_B <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 10 ps; -- Time=830 ps
		d11 <= transport std_logic_vector'("11011100"); --DC
		d22 <= transport std_logic_vector'("11001001"); --C9
		R_A <= transport std_logic_vector'("10110110"); --B6
		R_B <= transport std_logic_vector'("10100011"); --A3
		-- --------------------
		WAIT FOR 10 ps; -- Time=840 ps
		d11 <= transport std_logic_vector'("01100000"); --60
		d22 <= transport std_logic_vector'("11101000"); --E8
		R_A <= transport std_logic_vector'("01110000"); --70
		R_B <= transport std_logic_vector'("11111000"); --F8
		-- --------------------
		WAIT FOR 10 ps; -- Time=850 ps
		d11 <= transport std_logic_vector'("00010111"); --17
		d22 <= transport std_logic_vector'("10000000"); --80
		R_A <= transport std_logic_vector'("11101000"); --E8
		R_B <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 10 ps; -- Time=860 ps
		d11 <= transport std_logic_vector'("00110110"); --36
		d22 <= transport std_logic_vector'("00011001"); --19
		R_A <= transport std_logic_vector'("11111100"); --FC
		R_B <= transport std_logic_vector'("11011110"); --DE
		-- --------------------
		WAIT FOR 10 ps; -- Time=870 ps
		d11 <= transport std_logic_vector'("00110001"); --31
		d22 <= transport std_logic_vector'("01111100"); --7C
		R_A <= transport std_logic_vector'("11000111"); --C7
		R_B <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 10 ps; -- Time=880 ps
		d11 <= transport std_logic_vector'("10111111"); --BF
		d22 <= transport std_logic_vector'("10110011"); --B3
		R_A <= transport std_logic_vector'("10100111"); --A7
		R_B <= transport std_logic_vector'("10011011"); --9B
		-- --------------------
		WAIT FOR 10 ps; -- Time=890 ps
		d11 <= transport std_logic_vector'("11010011"); --D3
		d22 <= transport std_logic_vector'("00000110"); --6
		R_A <= transport std_logic_vector'("00111001"); --39
		R_B <= transport std_logic_vector'("01101100"); --6C
		-- --------------------
		WAIT FOR 10 ps; -- Time=900 ps
		d11 <= transport std_logic_vector'("10100100"); --A4
		d22 <= transport std_logic_vector'("11111111"); --FF
		R_A <= transport std_logic_vector'("01011010"); --5A
		R_B <= transport std_logic_vector'("10110101"); --B5
		-- --------------------
		WAIT FOR 10 ps; -- Time=910 ps
		d11 <= transport std_logic_vector'("10100101"); --A5
		d22 <= transport std_logic_vector'("01100110"); --66
		R_A <= transport std_logic_vector'("00100111"); --27
		R_B <= transport std_logic_vector'("11101001"); --E9
		-- --------------------
		WAIT FOR 10 ps; -- Time=920 ps
		d11 <= transport std_logic_vector'("10001100"); --8C
		d22 <= transport std_logic_vector'("01000101"); --45
		R_A <= transport std_logic_vector'("11111110"); --FE
		R_B <= transport std_logic_vector'("10110110"); --B6
		-- --------------------
		WAIT FOR 10 ps; -- Time=930 ps
		d11 <= transport std_logic_vector'("01001110"); --4E
		d22 <= transport std_logic_vector'("11100100"); --E4
		R_A <= transport std_logic_vector'("01111010"); --7A
		R_B <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 10 ps; -- Time=940 ps
		d11 <= transport std_logic_vector'("00100000"); --20
		d22 <= transport std_logic_vector'("11001101"); --CD
		R_A <= transport std_logic_vector'("01111001"); --79
		R_B <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 10 ps; -- Time=950 ps
		d11 <= transport std_logic_vector'("01110111"); --77
		d22 <= transport std_logic_vector'("11001000"); --C8
		R_A <= transport std_logic_vector'("00011000"); --18
		R_B <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 10 ps; -- Time=960 ps
		d11 <= transport std_logic_vector'("00001000"); --8
		d22 <= transport std_logic_vector'("11011110"); --DE
		R_A <= transport std_logic_vector'("10110101"); --B5
		R_B <= transport std_logic_vector'("10001011"); --8B
		-- --------------------
		WAIT FOR 10 ps; -- Time=970 ps
		d11 <= transport std_logic_vector'("11000111"); --C7
		d22 <= transport std_logic_vector'("01011001"); --59
		R_A <= transport std_logic_vector'("11101011"); --EB
		R_B <= transport std_logic_vector'("01111101"); --7D
		-- --------------------
		WAIT FOR 10 ps; -- Time=980 ps
		d11 <= transport std_logic_vector'("11101011"); --EB
		d22 <= transport std_logic_vector'("11000001"); --C1
		R_A <= transport std_logic_vector'("10011000"); --98
		R_B <= transport std_logic_vector'("01101111"); --6F
		-- --------------------
		WAIT FOR 10 ps; -- Time=990 ps
		d11 <= transport std_logic_vector'("11100111"); --E7
		d22 <= transport std_logic_vector'("11100000"); --E0
		R_A <= transport std_logic_vector'("11011010"); --DA
		R_B <= transport std_logic_vector'("11010011"); --D3
		-- --------------------
		WAIT FOR 15 ps; -- Time=1005 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION writeback_cfg OF writeback_tb IS
	FOR testbench_arch
	END FOR;
END writeback_cfg;
