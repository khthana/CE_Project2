--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 7.1.01i
--  \   \         Application : ISE WebPACK
--  /   /         Filename : g_reg_tb.vhw
-- /___/   /\     Timestamp : Thu Mar 31 02:09:37 2005
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: g_reg_tb
--Device: Xilinx
--

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY g_reg_tb IS
END g_reg_tb;

ARCHITECTURE testbench_arch OF g_reg_tb IS
    COMPONENT g_register
        PORT (
            data_in : In std_logic_vector (7 DownTo 0);
            data_out : Out std_logic_vector (7 DownTo 0);
            load_in : In std_logic;
            reset : In std_logic;
            clock : In std_logic
        );
    END COMPONENT;

    SIGNAL data_in : std_logic_vector (7 DownTo 0) := "10000011";
    SIGNAL data_out : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL load_in : std_logic := '0';
    SIGNAL reset : std_logic := '1';
    SIGNAL clock : std_logic := '0';

    SHARED VARIABLE TX_ERROR : INTEGER := 0;
    SHARED VARIABLE TX_OUT : LINE;

    constant PERIOD : time := 200 ps;
    constant DUTY_CYCLE : real := 0.5;
    constant OFFSET : time := 0 ps;

    BEGIN
        UUT : g_register
        PORT MAP (
            data_in => data_in,
            data_out => data_out,
            load_in => load_in,
            reset => reset,
            clock => clock
        );

        PROCESS    -- clock process for clock
        BEGIN
            WAIT for OFFSET;
            CLOCK_LOOP : LOOP
                clock <= '0';
                WAIT FOR (PERIOD - (PERIOD * DUTY_CYCLE));
                clock <= '1';
                WAIT FOR (PERIOD * DUTY_CYCLE);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS
            PROCEDURE CHECK_data_out(
                next_data_out : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (data_out /= next_data_out) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps data_out="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            BEGIN
                -- -------------  Current Time:  85ps
                WAIT FOR 85 ps;
                data_in <= "01011111";
                -- -------------------------------------
                -- -------------  Current Time:  285ps
                WAIT FOR 200 ps;
                data_in <= "11001000";
                -- -------------------------------------
                -- -------------  Current Time:  485ps
                WAIT FOR 200 ps;
                reset <= '0';
                data_in <= "00100101";
                -- -------------------------------------
                -- -------------  Current Time:  685ps
                WAIT FOR 200 ps;
                data_in <= "00111110";
                -- -------------------------------------
                -- -------------  Current Time:  885ps
                WAIT FOR 200 ps;
                data_in <= "10101010";
                -- -------------------------------------
                -- -------------  Current Time:  1085ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01100101";
                -- -------------------------------------
                -- -------------  Current Time:  1285ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "11110100";
                -- -------------------------------------
                -- -------------  Current Time:  1485ps
                WAIT FOR 200 ps;
                data_in <= "10101010";
                -- -------------------------------------
                -- -------------  Current Time:  1685ps
                WAIT FOR 200 ps;
                data_in <= "00001111";
                -- -------------------------------------
                -- -------------  Current Time:  1885ps
                WAIT FOR 200 ps;
                data_in <= "10010010";
                -- -------------------------------------
                -- -------------  Current Time:  2085ps
                WAIT FOR 200 ps;
                data_in <= "01001001";
                -- -------------------------------------
                -- -------------  Current Time:  2285ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01011101";
                -- -------------------------------------
                -- -------------  Current Time:  2485ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10010010";
                -- -------------------------------------
                -- -------------  Current Time:  2685ps
                WAIT FOR 200 ps;
                data_in <= "00000111";
                -- -------------------------------------
                -- -------------  Current Time:  2885ps
                WAIT FOR 200 ps;
                data_in <= "00111100";
                -- -------------------------------------
                -- -------------  Current Time:  3085ps
                WAIT FOR 200 ps;
                data_in <= "11111000";
                -- -------------------------------------
                -- -------------  Current Time:  3285ps
                WAIT FOR 200 ps;
                data_in <= "01100111";
                -- -------------------------------------
                -- -------------  Current Time:  3485ps
                WAIT FOR 200 ps;
                load_in <= '1';
                reset <= '1';
                data_in <= "10111110";
                -- -------------------------------------
                -- -------------  Current Time:  3685ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10111000";
                -- -------------------------------------
                -- -------------  Current Time:  3885ps
                WAIT FOR 200 ps;
                reset <= '0';
                data_in <= "00000101";
                -- -------------------------------------
                -- -------------  Current Time:  4085ps
                WAIT FOR 200 ps;
                data_in <= "11010000";
                -- -------------------------------------
                -- -------------  Current Time:  4285ps
                WAIT FOR 200 ps;
                data_in <= "01011011";
                -- -------------------------------------
                -- -------------  Current Time:  4485ps
                WAIT FOR 200 ps;
                data_in <= "00001111";
                -- -------------------------------------
                -- -------------  Current Time:  4685ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "10010000";
                -- -------------------------------------
                -- -------------  Current Time:  4885ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "00011101";
                -- -------------------------------------
                -- -------------  Current Time:  5085ps
                WAIT FOR 200 ps;
                data_in <= "11101110";
                -- -------------------------------------
                -- -------------  Current Time:  5285ps
                WAIT FOR 200 ps;
                data_in <= "11110010";
                -- -------------------------------------
                -- -------------  Current Time:  5485ps
                WAIT FOR 200 ps;
                data_in <= "00100101";
                -- -------------------------------------
                -- -------------  Current Time:  5685ps
                WAIT FOR 200 ps;
                data_in <= "10101100";
                -- -------------------------------------
                -- -------------  Current Time:  5885ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "11111000";
                -- -------------------------------------
                -- -------------  Current Time:  6085ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "01100111";
                -- -------------------------------------
                -- -------------  Current Time:  6285ps
                WAIT FOR 200 ps;
                data_in <= "11001010";
                -- -------------------------------------
                -- -------------  Current Time:  6485ps
                WAIT FOR 200 ps;
                data_in <= "00011001";
                -- -------------------------------------
                -- -------------  Current Time:  6685ps
                WAIT FOR 200 ps;
                data_in <= "00000101";
                -- -------------------------------------
                -- -------------  Current Time:  6885ps
                WAIT FOR 200 ps;
                reset <= '1';
                data_in <= "11000010";
                -- -------------------------------------
                -- -------------  Current Time:  7085ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01011111";
                -- -------------------------------------
                -- -------------  Current Time:  7285ps
                WAIT FOR 200 ps;
                load_in <= '0';
                reset <= '0';
                data_in <= "11000100";
                -- -------------------------------------
                -- -------------  Current Time:  7485ps
                WAIT FOR 200 ps;
                data_in <= "10100000";
                -- -------------------------------------
                -- -------------  Current Time:  7685ps
                WAIT FOR 200 ps;
                data_in <= "00111111";
                -- -------------------------------------
                -- -------------  Current Time:  7885ps
                WAIT FOR 200 ps;
                data_in <= "11101010";
                -- -------------------------------------
                -- -------------  Current Time:  8085ps
                WAIT FOR 200 ps;
                data_in <= "01100010";
                -- -------------------------------------
                -- -------------  Current Time:  8285ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01110101";
                -- -------------------------------------
                -- -------------  Current Time:  8485ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10101000";
                -- -------------------------------------
                -- -------------  Current Time:  8685ps
                WAIT FOR 200 ps;
                data_in <= "00000011";
                -- -------------------------------------
                -- -------------  Current Time:  8885ps
                WAIT FOR 200 ps;
                data_in <= "01010111";
                -- -------------------------------------
                -- -------------  Current Time:  9085ps
                WAIT FOR 200 ps;
                data_in <= "11001000";
                -- -------------------------------------
                -- -------------  Current Time:  9285ps
                WAIT FOR 200 ps;
                data_in <= "01011101";
                -- -------------------------------------
                -- -------------  Current Time:  9485ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "10010111";
                -- -------------------------------------
                -- -------------  Current Time:  9685ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10000010";
                -- -------------------------------------
                -- -------------  Current Time:  9885ps
                WAIT FOR 200 ps;
                data_in <= "01111101";
                -- -------------------------------------
                -- -------------  Current Time:  10085ps
                WAIT FOR 200 ps;
                data_in <= "11110000";
                -- -------------------------------------
                -- -------------  Current Time:  10285ps
                WAIT FOR 200 ps;
                reset <= '1';
                data_in <= "01100000";
                -- -------------------------------------
                -- -------------  Current Time:  10485ps
                WAIT FOR 200 ps;
                data_in <= "00111111";
                -- -------------------------------------
                -- -------------  Current Time:  10685ps
                WAIT FOR 200 ps;
                load_in <= '1';
                reset <= '0';
                data_in <= "10111010";
                -- -------------------------------------
                -- -------------  Current Time:  10885ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "01000001";
                -- -------------------------------------
                -- -------------  Current Time:  11085ps
                WAIT FOR 200 ps;
                data_in <= "11010101";
                -- -------------------------------------
                -- -------------  Current Time:  11285ps
                WAIT FOR 200 ps;
                data_in <= "10011010";
                -- -------------------------------------
                -- -------------  Current Time:  11485ps
                WAIT FOR 200 ps;
                data_in <= "00000111";
                -- -------------------------------------
                -- -------------  Current Time:  11685ps
                WAIT FOR 200 ps;
                data_in <= "10010101";
                -- -------------------------------------
                -- -------------  Current Time:  11885ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "11011000";
                -- -------------------------------------
                -- -------------  Current Time:  12085ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "01101101";
                -- -------------------------------------
                -- -------------  Current Time:  12285ps
                WAIT FOR 200 ps;
                data_in <= "10110010";
                -- -------------------------------------
                -- -------------  Current Time:  12485ps
                WAIT FOR 200 ps;
                data_in <= "00100010";
                -- -------------------------------------
                -- -------------  Current Time:  12685ps
                WAIT FOR 200 ps;
                data_in <= "00101101";
                -- -------------------------------------
                -- -------------  Current Time:  12885ps
                WAIT FOR 200 ps;
                data_in <= "11110000";
                -- -------------------------------------
                -- -------------  Current Time:  13085ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01100011";
                -- -------------------------------------
                -- -------------  Current Time:  13285ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10001111";
                -- -------------------------------------
                -- -------------  Current Time:  13485ps
                WAIT FOR 200 ps;
                data_in <= "10011000";
                -- -------------------------------------
                -- -------------  Current Time:  13685ps
                WAIT FOR 200 ps;
                reset <= '1';
                data_in <= "00000101";
                -- -------------------------------------
                -- -------------  Current Time:  13885ps
                WAIT FOR 200 ps;
                data_in <= "11000111";
                -- -------------------------------------
                -- -------------  Current Time:  14085ps
                WAIT FOR 200 ps;
                reset <= '0';
                data_in <= "01011010";
                -- -------------------------------------
                -- -------------  Current Time:  14285ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "00000111";
                -- -------------------------------------
                -- -------------  Current Time:  14485ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10100000";
                -- -------------------------------------
                -- -------------  Current Time:  14685ps
                WAIT FOR 200 ps;
                data_in <= "00111000";
                -- -------------------------------------
                -- -------------  Current Time:  14885ps
                WAIT FOR 200 ps;
                data_in <= "11101111";
                -- -------------------------------------
                -- -------------  Current Time:  15085ps
                WAIT FOR 200 ps;
                data_in <= "11100010";
                -- -------------------------------------
                -- -------------  Current Time:  15285ps
                WAIT FOR 200 ps;
                data_in <= "00110101";
                -- -------------------------------------
                -- -------------  Current Time:  15485ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "10101101";
                -- -------------------------------------
                -- -------------  Current Time:  15685ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10010010";
                -- -------------------------------------
                -- -------------  Current Time:  15885ps
                WAIT FOR 200 ps;
                data_in <= "01010111";
                -- -------------------------------------
                -- -------------  Current Time:  16085ps
                WAIT FOR 200 ps;
                data_in <= "11001111";
                -- -------------------------------------
                -- -------------  Current Time:  16285ps
                WAIT FOR 200 ps;
                data_in <= "00011000";
                -- -------------------------------------
                -- -------------  Current Time:  16485ps
                WAIT FOR 200 ps;
                data_in <= "00010101";
                -- -------------------------------------
                -- -------------  Current Time:  16685ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "10001010";
                -- -------------------------------------
                -- -------------  Current Time:  16885ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "01111010";
                -- -------------------------------------
                -- -------------  Current Time:  17085ps
                WAIT FOR 200 ps;
                reset <= '1';
                data_in <= "11110101";
                -- -------------------------------------
                -- -------------  Current Time:  17285ps
                WAIT FOR 200 ps;
                data_in <= "10100000";
                -- -------------------------------------
                -- -------------  Current Time:  17485ps
                WAIT FOR 200 ps;
                reset <= '0';
                data_in <= "00111110";
                -- -------------------------------------
                -- -------------  Current Time:  17685ps
                WAIT FOR 200 ps;
                data_in <= "11111111";
                -- -------------------------------------
                -- -------------  Current Time:  17885ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01000000";
                -- -------------------------------------
                -- -------------  Current Time:  18085ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "01011101";
                -- -------------------------------------
                -- -------------  Current Time:  18285ps
                WAIT FOR 200 ps;
                data_in <= "10011101";
                -- -------------------------------------
                -- -------------  Current Time:  18485ps
                WAIT FOR 200 ps;
                data_in <= "00000010";
                -- -------------------------------------
                -- -------------  Current Time:  18685ps
                WAIT FOR 200 ps;
                data_in <= "01010111";
                -- -------------------------------------
                -- -------------  Current Time:  18885ps
                WAIT FOR 200 ps;
                data_in <= "11011000";
                -- -------------------------------------
                -- -------------  Current Time:  19085ps
                WAIT FOR 200 ps;
                load_in <= '1';
                data_in <= "01101000";
                -- -------------------------------------
                -- -------------  Current Time:  19285ps
                WAIT FOR 200 ps;
                load_in <= '0';
                data_in <= "10110111";
                -- -------------------------------------
                -- -------------  Current Time:  19485ps
                WAIT FOR 200 ps;
                data_in <= "10101010";
                -- -------------------------------------
                -- -------------  Current Time:  19685ps
                WAIT FOR 200 ps;
                data_in <= "01101100";
                -- -------------------------------------
                -- -------------  Current Time:  1.02889e+006ps
                WAIT FOR 1.0092e+006 ps;
                data_in <= "01101101";
                -- -------------------------------------
                -- -------------  Current Time:  1.02909e+006ps
                WAIT FOR 200 ps;
                data_in <= "01101001";
                -- -------------------------------------

                IF (TX_ERROR = 0) THEN
                    STD.TEXTIO.write(TX_OUT, string'("No errors or warnings"));
                    ASSERT (FALSE) REPORT
                      "Simulation successful (not a failure).  No problems detected."
                      SEVERITY FAILURE;
                ELSE
                    STD.TEXTIO.write(TX_OUT, TX_ERROR);
                    STD.TEXTIO.write(TX_OUT,
                        string'(" errors found in simulation"));
                    ASSERT (FALSE) REPORT "Errors found during simulation"
                         SEVERITY FAILURE;
                END IF;
            END PROCESS;

    END testbench_arch;

