-- Xilinx Vhdl netlist produced by netgen application (version G.31a)
-- Command       : -intstyle ise -rpw 100 -tpw 0 -ar Structure -xon true -w -ofmt vhdl -sim external_rom.ngd external_rom_translate.vhd 
-- Input file    : external_rom.ngd
-- Output file   : external_rom_translate.vhd
-- Design name   : external_rom
-- # of Entities : 1
-- Xilinx        : E:/Programming/Xilinx
-- Device        : 2s15tq144-5q

-- This vhdl netlist is a simulation model and uses simulation 
-- primitives which may not represent the true implementation of the 
-- device, however the netlist is functionally correct and should not 
-- be modified. This file cannot be synthesized and should only be used 
-- with supported simulation tools.

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library SIMPRIM;
use SIMPRIM.VCOMPONENTS.ALL;
use SIMPRIM.VPACKAGE.ALL;

entity external_rom is
  port (
    OE : in STD_LOGIC := 'X'; 
    ADDRESS_BUS : in STD_LOGIC_VECTOR ( 15 downto 0 ); 
    DATA_BUS : out STD_LOGIC_VECTOR ( 7 downto 0 ) 
  );
end external_rom;

architecture Structure of external_rom is
  signal OE_IBUF : STD_LOGIC; 
  signal ADDRESS_BUS_4_IBUF : STD_LOGIC; 
  signal DATA_BUS_1_OBUFT : STD_LOGIC; 
  signal DATA_BUS_0_OBUFT : STD_LOGIC; 
  signal ADDRESS_BUS_3_IBUF : STD_LOGIC; 
  signal Mmux_n0002_net224 : STD_LOGIC; 
  signal DATA_BUS_7_OBUFT : STD_LOGIC; 
  signal DATA_BUS_6_OBUFT : STD_LOGIC; 
  signal DATA_BUS_5_OBUFT : STD_LOGIC; 
  signal Mmux_n0002_net238 : STD_LOGIC; 
  signal DATA_BUS_4_OBUFT : STD_LOGIC; 
  signal DATA_BUS_3_OBUFT : STD_LOGIC; 
  signal DATA_BUS_2_OBUFT : STD_LOGIC; 
  signal ADDRESS_BUS_0_IBUF : STD_LOGIC; 
  signal ADDRESS_BUS_1_IBUF : STD_LOGIC; 
  signal ADDRESS_BUS_2_IBUF : STD_LOGIC; 
  signal Mmux_n0002_net194 : STD_LOGIC; 
  signal Mmux_n0002_net58 : STD_LOGIC; 
  signal Mmux_n0002_net44 : STD_LOGIC; 
  signal Mmux_n0002_net164 : STD_LOGIC; 
  signal Mmux_n0002_net148 : STD_LOGIC; 
  signal Mmux_n0002_net28 : STD_LOGIC; 
  signal Mmux_n0002_net88 : STD_LOGIC; 
  signal Mmux_n0002_net14 : STD_LOGIC; 
  signal Mmux_n0002_net118 : STD_LOGIC; 
  signal Mmux_n0002_net74 : STD_LOGIC; 
  signal Mmux_n0002_net134 : STD_LOGIC; 
  signal Mmux_n0002_net178 : STD_LOGIC; 
  signal Mmux_n0002_net208 : STD_LOGIC; 
  signal Mmux_n0002_net104 : STD_LOGIC; 
  signal GTS : STD_LOGIC; 
  signal DATA_BUS_0_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_5_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_2_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_1_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_4_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_6_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_3_OBUFT_GTS_AND : STD_LOGIC; 
  signal DATA_BUS_7_OBUFT_GTS_AND : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_0_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_0_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_5_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_5_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_2_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_2_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_1_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_1_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_4_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_4_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_6_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_6_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_3_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_3_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_7_OBUFT_GTS_AND_IN0 : STD_LOGIC; 
  signal NlwInverterSignal_DATA_BUS_7_OBUFT_GTS_AND_IN1 : STD_LOGIC; 
begin
  Mmux_n0002_inst_mux_f5_8 : X_MUX2
    port map (
      IA => Mmux_n0002_net14,
      IB => Mmux_n0002_net28,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_0_OBUFT
    );
  DATA_BUS_7_OBUFT_0 : X_TRI
    port map (
      I => DATA_BUS_7_OBUFT,
      CTL => DATA_BUS_7_OBUFT_GTS_AND,
      O => DATA_BUS(7)
    );
  Mmux_n0002_inst_lut3_671 : X_LUT4
    generic map(
      INIT => X"3C78"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_1_IBUF,
      ADR2 => ADDRESS_BUS_2_IBUF,
      ADR3 => ADDRESS_BUS_0_IBUF,
      O => Mmux_n0002_net118
    );
  DATA_BUS_6_OBUFT_1 : X_TRI
    port map (
      I => DATA_BUS_6_OBUFT,
      CTL => DATA_BUS_6_OBUFT_GTS_AND,
      O => DATA_BUS(6)
    );
  Mmux_n0002_inst_lut3_1181 : X_LUT4
    generic map(
      INIT => X"7C78"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_1_IBUF,
      ADR2 => ADDRESS_BUS_2_IBUF,
      ADR3 => ADDRESS_BUS_0_IBUF,
      O => Mmux_n0002_net208
    );
  DATA_BUS_5_OBUFT_2 : X_TRI
    port map (
      I => DATA_BUS_5_OBUFT,
      CTL => DATA_BUS_5_OBUFT_GTS_AND,
      O => DATA_BUS(5)
    );
  DATA_BUS_0_OBUFT_3 : X_TRI
    port map (
      I => DATA_BUS_0_OBUFT,
      CTL => DATA_BUS_0_OBUFT_GTS_AND,
      O => DATA_BUS(0)
    );
  DATA_BUS_1_OBUFT_4 : X_TRI
    port map (
      I => DATA_BUS_1_OBUFT,
      CTL => DATA_BUS_1_OBUFT_GTS_AND,
      O => DATA_BUS(1)
    );
  DATA_BUS_2_OBUFT_5 : X_TRI
    port map (
      I => DATA_BUS_2_OBUFT,
      CTL => DATA_BUS_2_OBUFT_GTS_AND,
      O => DATA_BUS(2)
    );
  DATA_BUS_3_OBUFT_6 : X_TRI
    port map (
      I => DATA_BUS_3_OBUFT,
      CTL => DATA_BUS_3_OBUFT_GTS_AND,
      O => DATA_BUS(3)
    );
  DATA_BUS_4_OBUFT_7 : X_TRI
    port map (
      I => DATA_BUS_4_OBUFT,
      CTL => DATA_BUS_4_OBUFT_GTS_AND,
      O => DATA_BUS(4)
    );
  Mmux_n0002_inst_mux_f5_62 : X_MUX2
    port map (
      IA => Mmux_n0002_net194,
      IB => Mmux_n0002_net208,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_6_OBUFT
    );
  Mmux_n0002_inst_mux_f5_71 : X_MUX2
    port map (
      IA => Mmux_n0002_net224,
      IB => Mmux_n0002_net238,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_7_OBUFT
    );
  Mmux_n0002_inst_lut3_1101 : X_LUT4
    generic map(
      INIT => X"2422"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_1_IBUF,
      ADR2 => ADDRESS_BUS_2_IBUF,
      ADR3 => ADDRESS_BUS_0_IBUF,
      O => Mmux_n0002_net194
    );
  Mmux_n0002_inst_mux_f5_26 : X_MUX2
    port map (
      IA => Mmux_n0002_net74,
      IB => Mmux_n0002_net88,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_2_OBUFT
    );
  Mmux_n0002_inst_lut3_421 : X_LUT4
    generic map(
      INIT => X"04C1"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net74
    );
  Mmux_n0002_inst_lut3_501 : X_LUT4
    generic map(
      INIT => X"5E34"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_2_IBUF,
      ADR3 => ADDRESS_BUS_1_IBUF,
      O => Mmux_n0002_net88
    );
  Mmux_n0002_inst_lut3_161 : X_LUT4
    generic map(
      INIT => X"0341"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net28
    );
  Mmux_n0002_inst_mux_f5_53 : X_MUX2
    port map (
      IA => Mmux_n0002_net164,
      IB => Mmux_n0002_net178,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_5_OBUFT
    );
  Mmux_n0002_inst_mux_f5_17 : X_MUX2
    port map (
      IA => Mmux_n0002_net44,
      IB => Mmux_n0002_net58,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_1_OBUFT
    );
  ADDRESS_BUS_3_IBUF_8 : X_BUF
    port map (
      I => ADDRESS_BUS(3),
      O => ADDRESS_BUS_3_IBUF
    );
  Mmux_n0002_inst_lut3_331 : X_LUT4
    generic map(
      INIT => X"F760"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net58
    );
  Mmux_n0002_inst_lut3_1011 : X_LUT4
    generic map(
      INIT => X"FDC0"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net178
    );
  Mmux_n0002_inst_lut3_1351 : X_LUT4
    generic map(
      INIT => X"7C38"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_2_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_0_IBUF,
      O => Mmux_n0002_net238
    );
  ADDRESS_BUS_0_IBUF_9 : X_BUF
    port map (
      I => ADDRESS_BUS(0),
      O => ADDRESS_BUS_0_IBUF
    );
  Mmux_n0002_inst_mux_f5_44 : X_MUX2
    port map (
      IA => Mmux_n0002_net134,
      IB => Mmux_n0002_net148,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_4_OBUFT
    );
  ADDRESS_BUS_4_IBUF_10 : X_BUF
    port map (
      I => ADDRESS_BUS(4),
      O => ADDRESS_BUS_4_IBUF
    );
  Mmux_n0002_inst_lut3_1271 : X_LUT4
    generic map(
      INIT => X"B993"
    )
    port map (
      ADR0 => ADDRESS_BUS_2_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_3_IBUF,
      ADR3 => ADDRESS_BUS_1_IBUF,
      O => Mmux_n0002_net224
    );
  OE_IBUF_11 : X_BUF
    port map (
      I => OE,
      O => OE_IBUF
    );
  ADDRESS_BUS_1_IBUF_12 : X_BUF
    port map (
      I => ADDRESS_BUS(1),
      O => ADDRESS_BUS_1_IBUF
    );
  Mmux_n0002_inst_lut3_761 : X_LUT4
    generic map(
      INIT => X"5C3A"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_2_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_0_IBUF,
      O => Mmux_n0002_net134
    );
  Mmux_n0002_inst_lut3_591 : X_LUT4
    generic map(
      INIT => X"2E02"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net104
    );
  Mmux_n0002_inst_lut3_810 : X_LUT4
    generic map(
      INIT => X"0441"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net14
    );
  Mmux_n0002_inst_mux_f5_35 : X_MUX2
    port map (
      IA => Mmux_n0002_net104,
      IB => Mmux_n0002_net118,
      SEL => ADDRESS_BUS_4_IBUF,
      O => DATA_BUS_3_OBUFT
    );
  Mmux_n0002_inst_lut3_931 : X_LUT4
    generic map(
      INIT => X"9E4A"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_0_IBUF,
      ADR2 => ADDRESS_BUS_1_IBUF,
      ADR3 => ADDRESS_BUS_2_IBUF,
      O => Mmux_n0002_net164
    );
  Mmux_n0002_inst_lut3_251 : X_LUT4
    generic map(
      INIT => X"2120"
    )
    port map (
      ADR0 => ADDRESS_BUS_0_IBUF,
      ADR1 => ADDRESS_BUS_1_IBUF,
      ADR2 => ADDRESS_BUS_2_IBUF,
      ADR3 => ADDRESS_BUS_3_IBUF,
      O => Mmux_n0002_net44
    );
  Mmux_n0002_inst_lut3_841 : X_LUT4
    generic map(
      INIT => X"3979"
    )
    port map (
      ADR0 => ADDRESS_BUS_3_IBUF,
      ADR1 => ADDRESS_BUS_1_IBUF,
      ADR2 => ADDRESS_BUS_2_IBUF,
      ADR3 => ADDRESS_BUS_0_IBUF,
      O => Mmux_n0002_net148
    );
  ADDRESS_BUS_2_IBUF_13 : X_BUF
    port map (
      I => ADDRESS_BUS(2),
      O => ADDRESS_BUS_2_IBUF
    );
  DATA_BUS_0_OBUFT_GTS_AND_15 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_0_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_0_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_0_OBUFT_GTS_AND
    );
  DATA_BUS_5_OBUFT_GTS_AND_16 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_5_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_5_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_5_OBUFT_GTS_AND
    );
  DATA_BUS_2_OBUFT_GTS_AND_17 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_2_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_2_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_2_OBUFT_GTS_AND
    );
  DATA_BUS_1_OBUFT_GTS_AND_18 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_1_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_1_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_1_OBUFT_GTS_AND
    );
  DATA_BUS_4_OBUFT_GTS_AND_19 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_4_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_4_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_4_OBUFT_GTS_AND
    );
  DATA_BUS_6_OBUFT_GTS_AND_20 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_6_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_6_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_6_OBUFT_GTS_AND
    );
  DATA_BUS_3_OBUFT_GTS_AND_21 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_3_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_3_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_3_OBUFT_GTS_AND
    );
  DATA_BUS_7_OBUFT_GTS_AND_22 : X_AND2
    port map (
      I0 => NlwInverterSignal_DATA_BUS_7_OBUFT_GTS_AND_IN0,
      I1 => NlwInverterSignal_DATA_BUS_7_OBUFT_GTS_AND_IN1,
      O => DATA_BUS_7_OBUFT_GTS_AND
    );
  NlwInverterBlock_DATA_BUS_0_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_0_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_0_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_0_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_5_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_5_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_5_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_5_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_2_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_2_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_2_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_2_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_1_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_1_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_1_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_1_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_4_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_4_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_4_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_4_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_6_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_6_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_6_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_6_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_3_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_3_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_3_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_3_OBUFT_GTS_AND_IN1
    );
  NlwInverterBlock_DATA_BUS_7_OBUFT_GTS_AND_IN0 : X_INV
    port map (
      I => OE_IBUF,
      O => NlwInverterSignal_DATA_BUS_7_OBUFT_GTS_AND_IN0
    );
  NlwInverterBlock_DATA_BUS_7_OBUFT_GTS_AND_IN1 : X_INV
    port map (
      I => GTS,
      O => NlwInverterSignal_DATA_BUS_7_OBUFT_GTS_AND_IN1
    );
  NlwBlockTOC : X_TOC
    port map (O => GTS);

end Structure;

