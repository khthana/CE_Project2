
-- VHDL Instantiation Created from source file execute.vhd -- 05:56:23 03/14/2005
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT execute
	PORT(
		rst : IN std_logic;
		AA : IN std_logic_vector(7 downto 0);
		ac_in : IN std_logic;
		BB : IN std_logic_vector(7 downto 0);
		cy_in : IN std_logic;
		D1 : IN std_logic_vector(7 downto 0);
		D2 : IN std_logic_vector(7 downto 0);
		OPCode : IN std_logic_vector(4 downto 0);
		s1 : IN std_logic_vector(7 downto 0);
		s2 : IN std_logic_vector(7 downto 0);
		sel_mux16 : IN std_logic_vector(1 downto 0);
		sel_mux17 : IN std_logic_vector(1 downto 0);
		sel : IN std_logic_vector(3 downto 0);
		RA_in : IN std_logic_vector(7 downto 0);
		RB_in : IN std_logic_vector(7 downto 0);          
		ac_out : OUT std_logic;
		cy_out : OUT std_logic;
		ov : OUT std_logic;
		RA_out : OUT std_logic_vector(7 downto 0);
		RB_out : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_execute: execute PORT MAP(
		rst => ,
		AA => ,
		ac_in => ,
		BB => ,
		cy_in => ,
		D1 => ,
		D2 => ,
		OPCode => ,
		s1 => ,
		s2 => ,
		ac_out => ,
		cy_out => ,
		sel_mux16 => ,
		sel_mux17 => ,
		sel => ,
		ov => ,
		RA_in => ,
		RB_in => ,
		RA_out => ,
		RB_out => 
	);


