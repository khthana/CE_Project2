library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;


entity pc is
	port(	data_in16	:in		std_logic_vector(15 downto 0);
			data_out		:out   	std_logic_vector(15 downto 0);
			load_in		:in		std_logic;
			reset			:in		std_logic;
			clock			:in		std_logic);
			
end pc;


architecture rtl of pc is
begin
	process (data_in16, reset, clock)
	begin
		if (reset = '1') then
			data_out <= "0000000000000000";
		elsif (rising_edge(Clock) and load_in = '1' ) then
			data_out <= data_in16;
		end if;
	end process;
end rtl;

