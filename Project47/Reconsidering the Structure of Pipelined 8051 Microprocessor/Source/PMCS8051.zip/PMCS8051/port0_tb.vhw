-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 22 19:38:16 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY port0_tb IS
END port0_tb;

ARCHITECTURE testbench_arch OF port0_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT port0
		PORT (
			data_in : In  std_logic_vector (7 DOWNTO 0);
			data_out : Out  std_logic_vector (7 DOWNTO 0);
			port_inout : InOut  std_logic_vector (7 DOWNTO 0);
			load_in : In  std_logic;
			reset : In  std_logic;
			clock : In  std_logic
		);
	END COMPONENT;

	SIGNAL data_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL data_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL port_inout : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_in : std_logic;
	SIGNAL reset : std_logic;
	SIGNAL clock : std_logic;

BEGIN
	UUT : port0
	PORT MAP (
		data_in => data_in,
		data_out => data_out,
		port_inout => port_inout,
		load_in => load_in,
		reset => reset,
		clock => clock
	);

	PROCESS -- clock process for clock,
	BEGIN
		CLOCK_LOOP : LOOP
		clock <= transport '0';
		WAIT FOR 10 ps;
		clock <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clock <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clock
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_data_out(
			next_data_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out /= next_data_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps data_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_port_inout(
			next_port_inout : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (port_inout /= next_port_inout) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps port_inout="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port_inout);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port_inout);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		data_in <= transport std_logic_vector'("00000000"); --0
		load_in <= transport '1';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=20 ps
		CHECK_port_inout("01010001",20); --51
		-- --------------------
		WAIT FOR 80 ps; -- Time=100 ps
		data_in <= transport std_logic_vector'("00000001"); --1
		-- --------------------
		WAIT FOR 20 ps; -- Time=120 ps
		CHECK_port_inout("01010110",120); --56
		-- --------------------
		WAIT FOR 80 ps; -- Time=200 ps
		data_in <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 20 ps; -- Time=220 ps
		CHECK_port_inout("11110010",220); --F2
		-- --------------------
		WAIT FOR 80 ps; -- Time=300 ps
		data_in <= transport std_logic_vector'("00000011"); --3
		reset <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=320 ps
		CHECK_port_inout("01000010",320); --42
		-- --------------------
		WAIT FOR 80 ps; -- Time=400 ps
		data_in <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 20 ps; -- Time=420 ps
		CHECK_port_inout("10100010",420); --A2
		-- --------------------
		WAIT FOR 80 ps; -- Time=500 ps
		data_in <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 20 ps; -- Time=520 ps
		CHECK_port_inout("10110001",520); --B1
		-- --------------------
		WAIT FOR 80 ps; -- Time=600 ps
		data_in <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 20 ps; -- Time=620 ps
		CHECK_port_inout("01001011",620); --4B
		-- --------------------
		WAIT FOR 80 ps; -- Time=700 ps
		data_in <= transport std_logic_vector'("00000111"); --7
		-- --------------------
		WAIT FOR 20 ps; -- Time=720 ps
		CHECK_port_inout("10001101",720); --8D
		-- --------------------
		WAIT FOR 80 ps; -- Time=800 ps
		data_in <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 20 ps; -- Time=820 ps
		CHECK_port_inout("11010100",820); --D4
		-- --------------------
		WAIT FOR 80 ps; -- Time=900 ps
		data_in <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 20 ps; -- Time=920 ps
		CHECK_port_inout("10111101",920); --BD
		-- --------------------
		WAIT FOR 80 ps; -- Time=1000 ps
		data_in <= transport std_logic_vector'("00001010"); --A
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=1020 ps
		CHECK_port_inout("00100101",1020); --25
		-- --------------------
		WAIT FOR 80 ps; -- Time=1100 ps
		data_in <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 20 ps; -- Time=1120 ps
		CHECK_port_inout("00101001",1120); --29
		-- --------------------
		WAIT FOR 80 ps; -- Time=1200 ps
		data_in <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 20 ps; -- Time=1220 ps
		CHECK_port_inout("00100110",1220); --26
		-- --------------------
		WAIT FOR 80 ps; -- Time=1300 ps
		data_in <= transport std_logic_vector'("00001101"); --D
		-- --------------------
		WAIT FOR 20 ps; -- Time=1320 ps
		CHECK_port_inout("10111001",1320); --B9
		-- --------------------
		WAIT FOR 80 ps; -- Time=1400 ps
		data_in <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 20 ps; -- Time=1420 ps
		CHECK_port_inout("10111111",1420); --BF
		-- --------------------
		WAIT FOR 80 ps; -- Time=1500 ps
		data_in <= transport std_logic_vector'("00001111"); --F
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=1520 ps
		CHECK_port_inout("01010101",1520); --55
		-- --------------------
		WAIT FOR 80 ps; -- Time=1600 ps
		data_in <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 20 ps; -- Time=1620 ps
		CHECK_port_inout("11011000",1620); --D8
		-- --------------------
		WAIT FOR 80 ps; -- Time=1700 ps
		data_in <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 20 ps; -- Time=1720 ps
		CHECK_port_inout("11100101",1720); --E5
		-- --------------------
		WAIT FOR 80 ps; -- Time=1800 ps
		data_in <= transport std_logic_vector'("00010010"); --12
		reset <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=1820 ps
		CHECK_port_inout("01011001",1820); --59
		-- --------------------
		WAIT FOR 80 ps; -- Time=1900 ps
		data_in <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 20 ps; -- Time=1920 ps
		CHECK_port_inout("01010001",1920); --51
		-- --------------------
		WAIT FOR 80 ps; -- Time=2000 ps
		data_in <= transport std_logic_vector'("00010100"); --14
		-- --------------------
		WAIT FOR 20 ps; -- Time=2020 ps
		CHECK_port_inout("00101010",2020); --2A
		-- --------------------
		WAIT FOR 80 ps; -- Time=2100 ps
		data_in <= transport std_logic_vector'("00010101"); --15
		reset <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=2120 ps
		CHECK_port_inout("10000001",2120); --81
		-- --------------------
		WAIT FOR 80 ps; -- Time=2200 ps
		data_in <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 20 ps; -- Time=2220 ps
		CHECK_port_inout("00110011",2220); --33
		-- --------------------
		WAIT FOR 80 ps; -- Time=2300 ps
		data_in <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 20 ps; -- Time=2320 ps
		CHECK_port_inout("01011101",2320); --5D
		-- --------------------
		WAIT FOR 80 ps; -- Time=2400 ps
		data_in <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		data_in <= transport std_logic_vector'("00011001"); --19
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=2520 ps
		CHECK_port_inout("11001110",2520); --CE
		-- --------------------
		WAIT FOR 80 ps; -- Time=2600 ps
		data_in <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 20 ps; -- Time=2620 ps
		CHECK_port_inout("10001110",2620); --8E
		-- --------------------
		WAIT FOR 80 ps; -- Time=2700 ps
		data_in <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 20 ps; -- Time=2720 ps
		CHECK_port_inout("10111010",2720); --BA
		-- --------------------
		WAIT FOR 80 ps; -- Time=2800 ps
		data_in <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 20 ps; -- Time=2820 ps
		CHECK_port_inout("10101111",2820); --AF
		-- --------------------
		WAIT FOR 80 ps; -- Time=2900 ps
		data_in <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 20 ps; -- Time=2920 ps
		CHECK_port_inout("00001011",2920); --B
		-- --------------------
		WAIT FOR 80 ps; -- Time=3000 ps
		data_in <= transport std_logic_vector'("00011110"); --1E
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=3020 ps
		CHECK_port_inout("10101001",3020); --A9
		-- --------------------
		WAIT FOR 80 ps; -- Time=3100 ps
		data_in <= transport std_logic_vector'("00011111"); --1F
		-- --------------------
		WAIT FOR 20 ps; -- Time=3120 ps
		CHECK_port_inout("10100111",3120); --A7
		-- --------------------
		WAIT FOR 80 ps; -- Time=3200 ps
		data_in <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 20 ps; -- Time=3220 ps
		CHECK_port_inout("01100010",3220); --62
		-- --------------------
		WAIT FOR 80 ps; -- Time=3300 ps
		data_in <= transport std_logic_vector'("00100001"); --21
		-- --------------------
		WAIT FOR 20 ps; -- Time=3320 ps
		CHECK_port_inout("01111000",3320); --78
		-- --------------------
		WAIT FOR 80 ps; -- Time=3400 ps
		data_in <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 20 ps; -- Time=3420 ps
		CHECK_port_inout("11000100",3420); --C4
		-- --------------------
		WAIT FOR 80 ps; -- Time=3500 ps
		data_in <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 20 ps; -- Time=3520 ps
		CHECK_port_inout("01100100",3520); --64
		-- --------------------
		WAIT FOR 80 ps; -- Time=3600 ps
		data_in <= transport std_logic_vector'("00100100"); --24
		reset <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=3620 ps
		CHECK_port_inout("10110110",3620); --B6
		-- --------------------
		WAIT FOR 80 ps; -- Time=3700 ps
		data_in <= transport std_logic_vector'("00100101"); --25
		-- --------------------
		WAIT FOR 20 ps; -- Time=3720 ps
		CHECK_port_inout("01010101",3720); --55
		-- --------------------
		WAIT FOR 80 ps; -- Time=3800 ps
		data_in <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 20 ps; -- Time=3820 ps
		CHECK_port_inout("00011111",3820); --1F
		-- --------------------
		WAIT FOR 80 ps; -- Time=3900 ps
		data_in <= transport std_logic_vector'("00100111"); --27
		reset <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=3920 ps
		CHECK_port_inout("00110010",3920); --32
		-- --------------------
		WAIT FOR 80 ps; -- Time=4000 ps
		data_in <= transport std_logic_vector'("00101000"); --28
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=4020 ps
		CHECK_port_inout("11101001",4020); --E9
		-- --------------------
		WAIT FOR 80 ps; -- Time=4100 ps
		data_in <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 20 ps; -- Time=4120 ps
		CHECK_port_inout("11100011",4120); --E3
		-- --------------------
		WAIT FOR 80 ps; -- Time=4200 ps
		data_in <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 20 ps; -- Time=4220 ps
		CHECK_port_inout("11111011",4220); --FB
		-- --------------------
		WAIT FOR 80 ps; -- Time=4300 ps
		data_in <= transport std_logic_vector'("00101011"); --2B
		-- --------------------
		WAIT FOR 20 ps; -- Time=4320 ps
		CHECK_port_inout("01001111",4320); --4F
		-- --------------------
		WAIT FOR 80 ps; -- Time=4400 ps
		data_in <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 20 ps; -- Time=4420 ps
		CHECK_port_inout("00111101",4420); --3D
		-- --------------------
		WAIT FOR 80 ps; -- Time=4500 ps
		data_in <= transport std_logic_vector'("00101101"); --2D
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=4520 ps
		CHECK_port_inout("01100000",4520); --60
		-- --------------------
		WAIT FOR 80 ps; -- Time=4600 ps
		data_in <= transport std_logic_vector'("00101110"); --2E
		-- --------------------
		WAIT FOR 20 ps; -- Time=4620 ps
		CHECK_port_inout("10010111",4620); --97
		-- --------------------
		WAIT FOR 80 ps; -- Time=4700 ps
		data_in <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 20 ps; -- Time=4720 ps
		CHECK_port_inout("11111101",4720); --FD
		-- --------------------
		WAIT FOR 80 ps; -- Time=4800 ps
		data_in <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 20 ps; -- Time=4820 ps
		CHECK_port_inout("11110001",4820); --F1
		-- --------------------
		WAIT FOR 80 ps; -- Time=4900 ps
		data_in <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 20 ps; -- Time=4920 ps
		CHECK_port_inout("00001110",4920); --E
		-- --------------------
		WAIT FOR 80 ps; -- Time=5000 ps
		data_in <= transport std_logic_vector'("00110010"); --32
		-- --------------------
		WAIT FOR 20 ps; -- Time=5020 ps
		CHECK_port_inout("00110011",5020); --33
		-- --------------------
		WAIT FOR 80 ps; -- Time=5100 ps
		data_in <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 20 ps; -- Time=5120 ps
		CHECK_port_inout("01111100",5120); --7C
		-- --------------------
		WAIT FOR 80 ps; -- Time=5200 ps
		data_in <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 20 ps; -- Time=5220 ps
		CHECK_port_inout("01000101",5220); --45
		-- --------------------
		WAIT FOR 80 ps; -- Time=5300 ps
		data_in <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 20 ps; -- Time=5320 ps
		CHECK_port_inout("00101101",5320); --2D
		-- --------------------
		WAIT FOR 80 ps; -- Time=5400 ps
		data_in <= transport std_logic_vector'("00110110"); --36
		reset <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=5420 ps
		CHECK_port_inout("00001111",5420); --F
		-- --------------------
		WAIT FOR 80 ps; -- Time=5500 ps
		data_in <= transport std_logic_vector'("00110111"); --37
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=5520 ps
		CHECK_port_inout("00001010",5520); --A
		-- --------------------
		WAIT FOR 80 ps; -- Time=5600 ps
		data_in <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 20 ps; -- Time=5620 ps
		CHECK_port_inout("01111010",5620); --7A
		-- --------------------
		WAIT FOR 80 ps; -- Time=5700 ps
		data_in <= transport std_logic_vector'("00111001"); --39
		reset <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=5720 ps
		CHECK_port_inout("11111011",5720); --FB
		-- --------------------
		WAIT FOR 80 ps; -- Time=5800 ps
		data_in <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 20 ps; -- Time=5820 ps
		CHECK_port_inout("01101100",5820); --6C
		-- --------------------
		WAIT FOR 80 ps; -- Time=5900 ps
		data_in <= transport std_logic_vector'("00111011"); --3B
		-- --------------------
		WAIT FOR 20 ps; -- Time=5920 ps
		CHECK_port_inout("11101001",5920); --E9
		-- --------------------
		WAIT FOR 80 ps; -- Time=6000 ps
		data_in <= transport std_logic_vector'("00111100"); --3C
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=6020 ps
		CHECK_port_inout("11001110",6020); --CE
		-- --------------------
		WAIT FOR 80 ps; -- Time=6100 ps
		data_in <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 20 ps; -- Time=6120 ps
		CHECK_port_inout("10111010",6120); --BA
		-- --------------------
		WAIT FOR 80 ps; -- Time=6200 ps
		data_in <= transport std_logic_vector'("00111110"); --3E
		-- --------------------
		WAIT FOR 20 ps; -- Time=6220 ps
		CHECK_port_inout("10001001",6220); --89
		-- --------------------
		WAIT FOR 80 ps; -- Time=6300 ps
		data_in <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 20 ps; -- Time=6320 ps
		CHECK_port_inout("01011000",6320); --58
		-- --------------------
		WAIT FOR 80 ps; -- Time=6400 ps
		data_in <= transport std_logic_vector'("01000000"); --40
		-- --------------------
		WAIT FOR 20 ps; -- Time=6420 ps
		CHECK_port_inout("10000011",6420); --83
		-- --------------------
		WAIT FOR 80 ps; -- Time=6500 ps
		data_in <= transport std_logic_vector'("01000001"); --41
		-- --------------------
		WAIT FOR 20 ps; -- Time=6520 ps
		CHECK_port_inout("10101001",6520); --A9
		-- --------------------
		WAIT FOR 80 ps; -- Time=6600 ps
		data_in <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 20 ps; -- Time=6620 ps
		CHECK_port_inout("10100110",6620); --A6
		-- --------------------
		WAIT FOR 80 ps; -- Time=6700 ps
		data_in <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 20 ps; -- Time=6720 ps
		CHECK_port_inout("10010111",6720); --97
		-- --------------------
		WAIT FOR 80 ps; -- Time=6800 ps
		data_in <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 20 ps; -- Time=6820 ps
		CHECK_port_inout("11011001",6820); --D9
		-- --------------------
		WAIT FOR 80 ps; -- Time=6900 ps
		data_in <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 20 ps; -- Time=6920 ps
		CHECK_port_inout("00001001",6920); --9
		-- --------------------
		WAIT FOR 80 ps; -- Time=7000 ps
		data_in <= transport std_logic_vector'("01000110"); --46
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=7020 ps
		CHECK_port_inout("00000011",7020); --3
		-- --------------------
		WAIT FOR 80 ps; -- Time=7100 ps
		data_in <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 20 ps; -- Time=7120 ps
		CHECK_port_inout("11100110",7120); --E6
		-- --------------------
		WAIT FOR 80 ps; -- Time=7200 ps
		data_in <= transport std_logic_vector'("01001000"); --48
		reset <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=7220 ps
		CHECK_port_inout("00001110",7220); --E
		-- --------------------
		WAIT FOR 80 ps; -- Time=7300 ps
		data_in <= transport std_logic_vector'("01001001"); --49
		-- --------------------
		WAIT FOR 20 ps; -- Time=7320 ps
		CHECK_port_inout("00011000",7320); --18
		-- --------------------
		WAIT FOR 80 ps; -- Time=7400 ps
		data_in <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 20 ps; -- Time=7420 ps
		CHECK_port_inout("11100001",7420); --E1
		-- --------------------
		WAIT FOR 80 ps; -- Time=7500 ps
		data_in <= transport std_logic_vector'("01001011"); --4B
		load_in <= transport '1';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=7520 ps
		CHECK_port_inout("10000110",7520); --86
		-- --------------------
		WAIT FOR 80 ps; -- Time=7600 ps
		data_in <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 20 ps; -- Time=7620 ps
		CHECK_port_inout("01100100",7620); --64
		-- --------------------
		WAIT FOR 80 ps; -- Time=7700 ps
		data_in <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 20 ps; -- Time=7720 ps
		CHECK_port_inout("00011000",7720); --18
		-- --------------------
		WAIT FOR 80 ps; -- Time=7800 ps
		data_in <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 20 ps; -- Time=7820 ps
		CHECK_port_inout("01111111",7820); --7F
		-- --------------------
		WAIT FOR 80 ps; -- Time=7900 ps
		data_in <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 20 ps; -- Time=7920 ps
		CHECK_port_inout("10110110",7920); --B6
		-- --------------------
		WAIT FOR 80 ps; -- Time=8000 ps
		data_in <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 20 ps; -- Time=8020 ps
		CHECK_port_inout("00011010",8020); --1A
		-- --------------------
		WAIT FOR 80 ps; -- Time=8100 ps
		data_in <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 20 ps; -- Time=8120 ps
		CHECK_port_inout("01001000",8120); --48
		-- --------------------
		WAIT FOR 80 ps; -- Time=8200 ps
		data_in <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 20 ps; -- Time=8220 ps
		CHECK_port_inout("00011101",8220); --1D
		-- --------------------
		WAIT FOR 80 ps; -- Time=8300 ps
		data_in <= transport std_logic_vector'("01010011"); --53
		-- --------------------
		WAIT FOR 20 ps; -- Time=8320 ps
		CHECK_port_inout("10110110",8320); --B6
		-- --------------------
		WAIT FOR 80 ps; -- Time=8400 ps
		data_in <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 20 ps; -- Time=8420 ps
		CHECK_port_inout("01110000",8420); --70
		-- --------------------
		WAIT FOR 80 ps; -- Time=8500 ps
		data_in <= transport std_logic_vector'("01010101"); --55
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=8520 ps
		CHECK_port_inout("11101000",8520); --E8
		-- --------------------
		WAIT FOR 80 ps; -- Time=8600 ps
		data_in <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 20 ps; -- Time=8620 ps
		CHECK_port_inout("11111100",8620); --FC
		-- --------------------
		WAIT FOR 80 ps; -- Time=8700 ps
		data_in <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 20 ps; -- Time=8720 ps
		CHECK_port_inout("11000111",8720); --C7
		-- --------------------
		WAIT FOR 80 ps; -- Time=8800 ps
		data_in <= transport std_logic_vector'("01011000"); --58
		-- --------------------
		WAIT FOR 20 ps; -- Time=8820 ps
		CHECK_port_inout("10100111",8820); --A7
		-- --------------------
		WAIT FOR 80 ps; -- Time=8900 ps
		data_in <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 20 ps; -- Time=8920 ps
		CHECK_port_inout("00111001",8920); --39
		-- --------------------
		WAIT FOR 80 ps; -- Time=9000 ps
		data_in <= transport std_logic_vector'("01011010"); --5A
		load_in <= transport '1';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 20 ps; -- Time=9020 ps
		CHECK_port_inout("01011010",9020); --5A
		-- --------------------
		WAIT FOR 80 ps; -- Time=9100 ps
		data_in <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 20 ps; -- Time=9120 ps
		CHECK_port_inout("00100111",9120); --27
		-- --------------------
		WAIT FOR 80 ps; -- Time=9200 ps
		data_in <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 20 ps; -- Time=9220 ps
		CHECK_port_inout("11111110",9220); --FE
		-- --------------------
		WAIT FOR 80 ps; -- Time=9300 ps
		data_in <= transport std_logic_vector'("01011101"); --5D
		reset <= transport '0';
		-- --------------------
		WAIT FOR 20 ps; -- Time=9320 ps
		CHECK_port_inout("01111010",9320); --7A
		-- --------------------
		WAIT FOR 80 ps; -- Time=9400 ps
		data_in <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 20 ps; -- Time=9420 ps
		CHECK_port_inout("01111001",9420); --79
		-- --------------------
		WAIT FOR 80 ps; -- Time=9500 ps
		data_in <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 20 ps; -- Time=9520 ps
		CHECK_port_inout("00011000",9520); --18
		-- --------------------
		WAIT FOR 80 ps; -- Time=9600 ps
		data_in <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 20 ps; -- Time=9620 ps
		CHECK_port_inout("10110101",9620); --B5
		-- --------------------
		WAIT FOR 80 ps; -- Time=9700 ps
		data_in <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 20 ps; -- Time=9720 ps
		CHECK_port_inout("11101011",9720); --EB
		-- --------------------
		WAIT FOR 80 ps; -- Time=9800 ps
		data_in <= transport std_logic_vector'("01100010"); --62
		-- --------------------
		WAIT FOR 20 ps; -- Time=9820 ps
		CHECK_port_inout("10011000",9820); --98
		-- --------------------
		WAIT FOR 80 ps; -- Time=9900 ps
		data_in <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 20 ps; -- Time=9920 ps
		CHECK_port_inout("11011010",9920); --DA
		-- --------------------
		WAIT FOR 80 ps; -- Time=10000 ps
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 160 ps; -- Time=10160 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION port0_cfg OF port0_tb IS
	FOR testbench_arch
	END FOR;
END port0_cfg;
