-- VHDL model created from test.sch - Tue Aug 24 21:04:56 2004


library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
use IEEE.STD_LOGIC_unsigned.all;
-- synopsys translate_off
-- library UNISIM;
-- use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity fetch is
   port (
				from_internal_data_memory	: in std_logic_vector(15 downto 0);
       		sel_mux1							: in std_logic_vector(1 downto 0);
            sel_mux5							: in std_logic_vector(1 downto 0); 
   		 	clock								: in std_logic;
   		 	reset								: in std_logic;
      		PC_load_in16					: in std_logic;
   		 	temp1_load_in					: in std_logic;
    		 	ex_byte1							: in std_logic_vector(7 downto 0);
    		 	ex_byte2							: in std_logic_vector(7 downto 0);
    		 	ex_byte3							: in std_logic_vector(7 downto 0);
  		 		sel_jcall						: in std_logic_vector(1 downto 0);
      		sel_mux2							: in std_logic;
 		 		acc_in							: in std_logic_vector(7 downto 0); 
      		sel_mux3							: in std_logic;
 		 		DPTR_in							: in std_logic_vector(15 downto 0);
       		sel_mux4							: in std_logic_vector(2 downto 0);
--		 		sel_rd							: in std_logic;
	 			iqc							: out std_logic_vector(1 DOWNTO 0); 		

 
  		 data_bus					: in std_logic_vector(7 downto 0);
 		 address_bus				: out std_logic_vector(15 downto 0);
		 pc_resent					: out	std_logic_vector(15 downto 0);

		 		instruction_byte1				: out std_logic_vector(7 downto 0);	 
 		 		instruction_byte2				: out std_logic_vector(7 downto 0);	 
 		 		instruction_byte3				: out std_logic_vector(7 downto 0));
end fetch;

architecture structural  of fetch is

   signal PC_IN  			 	: std_logic_vector (15 downto 0);
   signal source_PC  		: std_logic_vector (15 downto 0);
   signal next_PC  		 	: std_logic_vector (15 downto 0);
   signal PC_data 			: std_logic_vector (15 downto 0);
   signal sign_ex_in 		: std_logic_vector (7 downto 0);
   signal sign_ex_out 		: std_logic_vector (15 downto 0);
   signal source_adder2 	: std_logic_vector (15 downto 0);
   signal Temp1_data 		: std_logic_vector (15 downto 0);
   signal JCall_out 			: std_logic_vector (15 downto 0);
   signal out_adder2 		: std_logic_vector (15 downto 0);
   signal DATABUS 			: std_logic_vector (7 downto 0);
   signal ADDRESSBUS 		: std_logic_vector (15 downto 0);
   signal A_DPTR		 		: std_logic_vector (15 downto 0);

--   component I8051ROM 
--	 port (  clk : in    std_logic; 
--            rst : in    std_logic; 
--				ADDRESS_BUS : in  std_logic_vector(15 downto 0);
--      	   rd          : in  std_logic;
--      	   DATA_BUS    : out std_logic_vector(7 downto 0));
--   end component;

   component mux1
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component pc
      port ( clock : in    std_logic; 
             data_in16 : in    std_logic_vector (15 downto 0); 
             reset     : in    std_logic; 
             load_in     : in    std_logic; 
             data_out  : out   std_logic_vector (15 downto 0));
   end component;
   
   component adder1
      port ( in1  : in    std_logic_vector (15 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component temp1
      port ( load_in  : in    std_logic; 
             data_in  : in    std_logic_vector (15 downto 0); 
             data_out : out   std_logic_vector (15 downto 0));
   end component;
   
   component jcall_address_gen
      port ( out1 : out   std_logic_vector (15 downto 0); 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             in4  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector(1 downto 0));
   end component;
   
   component mux2
      port ( out1 : out   std_logic_vector (7 downto 0); 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             sel  : in    std_logic);
   end component;
   
   component sign_extender
      port ( in1  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component mux3
      port ( out1 : out   std_logic_vector (15 downto 0); 
             sel  : in    std_logic; 
             in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (7 downto 0));
   end component;
   
   component adder2
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component mux4
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             in4  : in    std_logic_vector (15 downto 0); 
             in5  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector (2 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
   component que_state
      port ( clock : in    std_logic; 
             reset : in    std_logic; 
             in1   : in    std_logic_vector (7 downto 0); 
             out1  : out   std_logic_vector (7 downto 0); 
             out2  : out   std_logic_vector (7 downto 0); 
             out3  : out   std_logic_vector (7 downto 0);
			 	 iqc_out	: out std_logic_vector(1 DOWNTO 0));
   end component;
   
   component mux5
      port ( in1  : in    std_logic_vector (15 downto 0); 
             in2  : in    std_logic_vector (15 downto 0); 
             in3  : in    std_logic_vector (15 downto 0); 
             in4  : in    std_logic_vector (15 downto 0); 
             sel  : in    std_logic_vector (1 downto 0); 
             out1 : out   std_logic_vector (15 downto 0));
   end component;
   
begin
	pc_resent(15 downto 0) <= pc_data(15 downto 0);
  	address_bus(15 downto 0) <= addressbus(15 downto 0);
  	databus(7 downto 0) <= data_bus(7 downto 0);
	A_DPTR <= DPTR_in + ACC_in ; 
--   ROM : I8051ROM 
--	 port map ( clk=>clock, 
--      		 	rst=>reset,
--					ADDRESS_BUS(15 downto 0)=>ADDRESSBUS(15 downto 0),
--      	      rd=>sel_rd,
--      	      DATA_BUS(7 downto 0)=>DATABUS(7 downto 0));
  
     MUX1_M : mux1
      port map ( in1(15 downto 0)=>next_PC(15 downto 0),
      		 in2(15 downto 0)=>from_internal_data_memory,
      		 in3(15 downto 0)=>Temp1_data(15 downto 0),
      		 sel(1 downto 0)=>sel_mux1,
      		 out1(15 downto 0)=>PC_IN(15 downto 0));
 
   MUX5_M : mux5
      port map ( in1(15 downto 0)=>PC_data(15 downto 0),
      		 in2(15 downto 0)=>JCall_out(15 downto 0), 
      		 in3(15 downto 0)=>out_adder2(15 downto 0),
      		 in4(15 downto 0)=>A_DPtR(15 downto 0),
                 sel(1 downto 0)=>sel_mux5(1 downto 0), 
                 out1(15 downto 0)=>source_PC(15 downto 0));
   
   PC_M : pc
      port map (
      		 data_in16(15 downto 0)=>PC_IN(15 downto 0),
      		 clock=>clock,
      		 reset=>reset,
      		 load_in=>pc_load_in16,
      		 data_out(15 downto 0)=>PC_data(15 downto 0));
   
   ADDER1_M : adder1
      port map (	in1(15 downto 0)=>source_PC(15 downto 0),
      		 out1(15 downto 0)=>next_PC(15 downto 0));
   
   TEMP1_M : temp1
      port map (	data_in(15 downto 0)=>PC_data(15 downto 0),
      		 load_in=>temp1_load_in,
      		 data_out(15 downto 0)=>Temp1_data(15 downto 0));
   
   JCALL_ADDRESS_GEN_M : jcall_address_gen
      port map (	in1(7 downto 0)=>ex_byte1,
      		 in2(7 downto 0)=>ex_byte2,
      		 in3(7 downto 0)=>ex_byte3,
      		 in4(15 downto 0)=>PC_data(15 downto 0),
      		 sel(1 downto 0)=>sel_jcall(1 downto 0),
      		 out1(15 downto 0)=>JCall_out(15 downto 0));
   
   MUX2_M : mux2
      port map (	in1(7 downto 0)=>ex_byte2,
      		 in2(7 downto 0)=>ex_byte3,
      		 sel=>sel_mux2,
      		 out1(7 downto 0)=>sign_ex_in(7 downto 0));
   
   SIGN_EXTENDER_M : sign_extender
      port map ( in1(7 downto 0)=>sign_ex_in(7 downto 0),
      		 out1(15 downto 0)=>sign_ex_out(15 downto 0));
   
   MUX3_M : mux3
      port map (	in1(15 downto 0)=>sign_ex_out(15 downto 0),
      		 in2(7 downto 0)=>acc_in(7 downto 0),
      		 sel=>sel_mux3,
      		 out1(15 downto 0)=>source_adder2(15 downto 0));
   
   ADDER2_M : adder2
      port map (	in1(15 downto 0)=>Temp1_data(15 downto 0),
      		 in2(15 downto 0)=>source_adder2(15 downto 0), 
      		 out1(15 downto 0)=>out_adder2(15 downto 0));
   
   MUX4_M : mux4
      port map (	in1(15 downto 0)=>JCall_out(15 downto 0), 
      		 in2(15 downto 0)=>Temp1_data(15 downto 0), 
      		 in3(15 downto 0)=>PC_data(15 downto 0),
            		 in4(15 downto 0)=>A_DPTR(15 downto 0), 
            		 in5(15 downto 0)=>out_adder2(15 downto 0),
            		 sel(2 downto 0)=>sel_mux4(2 downto 0), 
            		 out1(15 downto 0)=>addressbus(15 downto 0));
   
   que_state_M : que_state
      port map ( clock=>clock, 
      		 in1(7 downto 0)=>databus(7 downto 0), 
      		 reset=>reset, 
      		 out1(7 downto 0)=>instruction_byte1(7 downto 0), 
      		 out2(7 downto 0)=>instruction_byte2(7 downto 0), 
      		 out3(7 downto 0)=>instruction_byte3(7 downto 0),
				 iqc_out(1 DOWNTO 0)	=>iqc(1 DOWNTO 0) 		
);
   
   
end structural ;

