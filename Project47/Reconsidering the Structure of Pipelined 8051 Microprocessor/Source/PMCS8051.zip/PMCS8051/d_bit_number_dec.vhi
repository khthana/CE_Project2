
-- VHDL Instantiation Created from source file d_bit_number_dec.vhd -- 20:31:29 12/30/2004
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT d_bit_number_dec
	PORT(
		in1 : IN std_logic_vector(7 downto 0);          
		out1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_d_bit_number_dec: d_bit_number_dec PORT MAP(
		in1 => ,
		out1 => 
	);


