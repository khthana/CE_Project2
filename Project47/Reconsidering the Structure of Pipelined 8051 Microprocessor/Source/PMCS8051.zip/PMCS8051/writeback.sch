VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtexe"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL sel_addr_decode
        SIGNAL d11(7:0)
        SIGNAL d22(7:0)
        SIGNAL sel_mux18
        SIGNAL R_A(7:0)
        SIGNAL w_addr(7:0)
        SIGNAL w_data(7:0)
        SIGNAL R_B(7:0)
        PORT Input sel_addr_decode
        PORT Input d11(7:0)
        PORT Input d22(7:0)
        PORT Input sel_mux18
        PORT Input R_A(7:0)
        PORT Output w_addr(7:0)
        PORT Output w_data(7:0)
        PORT Input R_B(7:0)
        BEGIN BLOCKDEF addr_decode
            TIMESTAMP 2005 3 8 22 55 57
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -32 0 -32 
            RECTANGLE N 0 -44 64 -20 
            LINE N 320 -160 384 -160 
            RECTANGLE N 320 -172 384 -148 
        END BLOCKDEF
        BEGIN BLOCKDEF mux18
            TIMESTAMP 2005 3 8 22 58 30
            RECTANGLE N 64 -208 320 -4 
            LINE N 64 -176 0 -176 
            LINE N 64 -112 0 -112 
            RECTANGLE N 0 -124 64 -100 
            LINE N 64 -48 0 -48 
            RECTANGLE N 0 -60 64 -36 
            LINE N 384 -176 320 -176 
            RECTANGLE N 320 -188 384 -164 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 addr_decode
            PIN sel sel_addr_decode
            PIN in1(7:0) d11(7:0)
            PIN in2(7:0) d22(7:0)
            PIN out1(7:0) w_addr(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 mux18
            PIN sel sel_mux18
            PIN in1(7:0) R_A(7:0)
            PIN in2(7:0) R_B(7:0)
            PIN out1(7:0) w_data(7:0)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_1 608 656 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3 624 976 R0
        END INSTANCE
        BEGIN BRANCH sel_addr_decode
            WIRE 576 496 608 496
        END BRANCH
        IOMARKER 576 496 sel_addr_decode R180 28
        BEGIN BRANCH d11(7:0)
            WIRE 576 560 608 560
        END BRANCH
        IOMARKER 576 560 d11(7:0) R180 28
        BEGIN BRANCH d22(7:0)
            WIRE 576 624 608 624
        END BRANCH
        IOMARKER 576 624 d22(7:0) R180 28
        BEGIN BRANCH sel_mux18
            WIRE 592 800 624 800
        END BRANCH
        IOMARKER 592 800 sel_mux18 R180 28
        BEGIN BRANCH R_A(7:0)
            WIRE 480 864 576 864
            WIRE 576 864 608 864
            WIRE 608 864 624 864
        END BRANCH
        BEGIN BRANCH w_addr(7:0)
            WIRE 992 496 1024 496
        END BRANCH
        IOMARKER 1024 496 w_addr(7:0) R0 28
        BEGIN BRANCH w_data(7:0)
            WIRE 1008 800 1040 800
        END BRANCH
        IOMARKER 1040 800 w_data(7:0) R0 28
        IOMARKER 480 864 R_A(7:0) R180 28
        IOMARKER 480 928 R_B(7:0) R180 28
        BEGIN BRANCH R_B(7:0)
            WIRE 480 928 512 928
            WIRE 512 928 608 928
            WIRE 608 928 624 928
        END BRANCH
    END SHEET
END SCHEMATIC
