
-- VHDL Instantiation Created from source file d_mux6.vhd -- 06:10:48 12/30/2004
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT d_mux6
	PORT(
		in1 : IN std_logic_vector(7 downto 0);
		in2 : IN std_logic_vector(7 downto 0);
		in3 : IN std_logic_vector(7 downto 0);
		in4 : IN std_logic_vector(7 downto 0);
		sel : IN std_logic_vector(1 downto 0);          
		out1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_d_mux6: d_mux6 PORT MAP(
		in1 => ,
		in2 => ,
		in3 => ,
		in4 => ,
		sel => ,
		out1 => 
	);


