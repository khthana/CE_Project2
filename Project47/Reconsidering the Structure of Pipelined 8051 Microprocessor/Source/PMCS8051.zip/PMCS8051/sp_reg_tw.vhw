-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Tue Mar 22 14:23:13 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY sp_reg_tw IS
END sp_reg_tw;

ARCHITECTURE testbench_arch OF sp_reg_tw IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT sp_register
		PORT (
			data_in : In  std_logic_vector (7 DOWNTO 0);
			data_out : Out  std_logic_vector (7 DOWNTO 0);
			load_in : In  std_logic;
			reset : In  std_logic;
			clock : In  std_logic
		);
	END COMPONENT;

	SIGNAL data_in : std_logic_vector (7 DOWNTO 0);
	SIGNAL data_out : std_logic_vector (7 DOWNTO 0);
	SIGNAL load_in : std_logic;
	SIGNAL reset : std_logic;
	SIGNAL clock : std_logic;

BEGIN
	UUT : sp_register
	PORT MAP (
		data_in => data_in,
		data_out => data_out,
		load_in => load_in,
		reset => reset,
		clock => clock
	);

	PROCESS -- clock process for clock,
	BEGIN
		CLOCK_LOOP : LOOP
		clock <= transport '0';
		WAIT FOR 10 ps;
		clock <= transport '1';
		WAIT FOR 10 ps;
		WAIT FOR 40 ps;
		clock <= transport '0';
		WAIT FOR 40 ps;
		END LOOP CLOCK_LOOP;
	END PROCESS;

	PROCESS   -- Process for clock
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_data_out(
			next_data_out : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (data_out /= next_data_out) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps data_out="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, data_out);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_data_out);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		data_in <= transport std_logic_vector'("00000111"); --7
		load_in <= transport '0';
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=100 ps
		data_in <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 100 ps; -- Time=200 ps
		data_in <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 100 ps; -- Time=300 ps
		data_in <= transport std_logic_vector'("00001010"); --A
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=400 ps
		data_in <= transport std_logic_vector'("00001011"); --B
		-- --------------------
		WAIT FOR 100 ps; -- Time=500 ps
		data_in <= transport std_logic_vector'("00001100"); --C
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=600 ps
		data_in <= transport std_logic_vector'("00001101"); --D
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=700 ps
		data_in <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 100 ps; -- Time=800 ps
		data_in <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 100 ps; -- Time=900 ps
		data_in <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 100 ps; -- Time=1000 ps
		data_in <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 100 ps; -- Time=1100 ps
		data_in <= transport std_logic_vector'("00010010"); --12
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1200 ps
		data_in <= transport std_logic_vector'("00010011"); --13
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1300 ps
		data_in <= transport std_logic_vector'("00010100"); --14
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1400 ps
		data_in <= transport std_logic_vector'("00010101"); --15
		-- --------------------
		WAIT FOR 100 ps; -- Time=1500 ps
		data_in <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 100 ps; -- Time=1600 ps
		data_in <= transport std_logic_vector'("00010111"); --17
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1700 ps
		data_in <= transport std_logic_vector'("00011000"); --18
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1800 ps
		data_in <= transport std_logic_vector'("00011001"); --19
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=1900 ps
		data_in <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 100 ps; -- Time=2000 ps
		data_in <= transport std_logic_vector'("00011011"); --1B
		-- --------------------
		WAIT FOR 100 ps; -- Time=2100 ps
		data_in <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 100 ps; -- Time=2200 ps
		data_in <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 100 ps; -- Time=2300 ps
		data_in <= transport std_logic_vector'("00011110"); --1E
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2400 ps
		data_in <= transport std_logic_vector'("00011111"); --1F
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2500 ps
		data_in <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 100 ps; -- Time=2600 ps
		data_in <= transport std_logic_vector'("00100001"); --21
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=2700 ps
		data_in <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 100 ps; -- Time=2800 ps
		data_in <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 100 ps; -- Time=2900 ps
		data_in <= transport std_logic_vector'("00100100"); --24
		load_in <= transport '1';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3000 ps
		data_in <= transport std_logic_vector'("00100101"); --25
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3100 ps
		data_in <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ps; -- Time=3200 ps
		data_in <= transport std_logic_vector'("00100111"); --27
		-- --------------------
		WAIT FOR 100 ps; -- Time=3300 ps
		data_in <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 100 ps; -- Time=3400 ps
		data_in <= transport std_logic_vector'("00101001"); --29
		-- --------------------
		WAIT FOR 100 ps; -- Time=3500 ps
		data_in <= transport std_logic_vector'("00101010"); --2A
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3600 ps
		data_in <= transport std_logic_vector'("00101011"); --2B
		load_in <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=3700 ps
		data_in <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 100 ps; -- Time=3800 ps
		data_in <= transport std_logic_vector'("00101101"); --2D
		-- --------------------
		WAIT FOR 100 ps; -- Time=3900 ps
		data_in <= transport std_logic_vector'("00101110"); --2E
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4000 ps
		data_in <= transport std_logic_vector'("00101111"); --2F
		-- --------------------
		WAIT FOR 100 ps; -- Time=4100 ps
		data_in <= transport std_logic_vector'("00110000"); --30
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4200 ps
		data_in <= transport std_logic_vector'("00110001"); --31
		load_in <= transport '0';
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4300 ps
		data_in <= transport std_logic_vector'("00110010"); --32
		-- --------------------
		WAIT FOR 100 ps; -- Time=4400 ps
		data_in <= transport std_logic_vector'("00110011"); --33
		-- --------------------
		WAIT FOR 100 ps; -- Time=4500 ps
		data_in <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 100 ps; -- Time=4600 ps
		data_in <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 100 ps; -- Time=4700 ps
		data_in <= transport std_logic_vector'("00110110"); --36
		load_in <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=4800 ps
		data_in <= transport std_logic_vector'("00110111"); --37
		-- --------------------
		WAIT FOR 100 ps; -- Time=4900 ps
		data_in <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 100 ps; -- Time=5000 ps
		data_in <= transport std_logic_vector'("00111001"); --39
		-- --------------------
		WAIT FOR 100 ps; -- Time=5100 ps
		data_in <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 100 ps; -- Time=5200 ps
		data_in <= transport std_logic_vector'("00111011"); --3B
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5300 ps
		data_in <= transport std_logic_vector'("00111100"); --3C
		-- --------------------
		WAIT FOR 100 ps; -- Time=5400 ps
		data_in <= transport std_logic_vector'("00111101"); --3D
		-- --------------------
		WAIT FOR 100 ps; -- Time=5500 ps
		data_in <= transport std_logic_vector'("00111110"); --3E
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=5600 ps
		data_in <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 100 ps; -- Time=5700 ps
		data_in <= transport std_logic_vector'("01000000"); --40
		-- --------------------
		WAIT FOR 100 ps; -- Time=5800 ps
		data_in <= transport std_logic_vector'("01000001"); --41
		-- --------------------
		WAIT FOR 100 ps; -- Time=5900 ps
		data_in <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 100 ps; -- Time=6000 ps
		data_in <= transport std_logic_vector'("01000011"); --43
		-- --------------------
		WAIT FOR 100 ps; -- Time=6100 ps
		data_in <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 100 ps; -- Time=6200 ps
		data_in <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 100 ps; -- Time=6300 ps
		data_in <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 100 ps; -- Time=6400 ps
		data_in <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 100 ps; -- Time=6500 ps
		data_in <= transport std_logic_vector'("01001000"); --48
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6600 ps
		data_in <= transport std_logic_vector'("01001001"); --49
		-- --------------------
		WAIT FOR 100 ps; -- Time=6700 ps
		data_in <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 100 ps; -- Time=6800 ps
		data_in <= transport std_logic_vector'("01001011"); --4B
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=6900 ps
		data_in <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 100 ps; -- Time=7000 ps
		data_in <= transport std_logic_vector'("01001101"); --4D
		-- --------------------
		WAIT FOR 100 ps; -- Time=7100 ps
		data_in <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 100 ps; -- Time=7200 ps
		data_in <= transport std_logic_vector'("01001111"); --4F
		-- --------------------
		WAIT FOR 100 ps; -- Time=7300 ps
		data_in <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 100 ps; -- Time=7400 ps
		data_in <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 100 ps; -- Time=7500 ps
		data_in <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 100 ps; -- Time=7600 ps
		data_in <= transport std_logic_vector'("01010011"); --53
		-- --------------------
		WAIT FOR 100 ps; -- Time=7700 ps
		data_in <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ps; -- Time=7800 ps
		data_in <= transport std_logic_vector'("01010101"); --55
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=7900 ps
		data_in <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 100 ps; -- Time=8000 ps
		data_in <= transport std_logic_vector'("01010111"); --57
		-- --------------------
		WAIT FOR 100 ps; -- Time=8100 ps
		data_in <= transport std_logic_vector'("01011000"); --58
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=8200 ps
		data_in <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 100 ps; -- Time=8300 ps
		data_in <= transport std_logic_vector'("01011010"); --5A
		-- --------------------
		WAIT FOR 100 ps; -- Time=8400 ps
		data_in <= transport std_logic_vector'("01011011"); --5B
		-- --------------------
		WAIT FOR 100 ps; -- Time=8500 ps
		data_in <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 100 ps; -- Time=8600 ps
		data_in <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 100 ps; -- Time=8700 ps
		data_in <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 100 ps; -- Time=8800 ps
		data_in <= transport std_logic_vector'("01011111"); --5F
		-- --------------------
		WAIT FOR 100 ps; -- Time=8900 ps
		data_in <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 100 ps; -- Time=9000 ps
		data_in <= transport std_logic_vector'("01100001"); --61
		-- --------------------
		WAIT FOR 100 ps; -- Time=9100 ps
		data_in <= transport std_logic_vector'("01100010"); --62
		reset <= transport '1';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9200 ps
		data_in <= transport std_logic_vector'("01100011"); --63
		-- --------------------
		WAIT FOR 100 ps; -- Time=9300 ps
		data_in <= transport std_logic_vector'("01100100"); --64
		-- --------------------
		WAIT FOR 100 ps; -- Time=9400 ps
		data_in <= transport std_logic_vector'("01100101"); --65
		reset <= transport '0';
		-- --------------------
		WAIT FOR 100 ps; -- Time=9500 ps
		data_in <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 100 ps; -- Time=9600 ps
		data_in <= transport std_logic_vector'("01100111"); --67
		-- --------------------
		WAIT FOR 100 ps; -- Time=9700 ps
		data_in <= transport std_logic_vector'("01101000"); --68
		-- --------------------
		WAIT FOR 100 ps; -- Time=9800 ps
		data_in <= transport std_logic_vector'("01101001"); --69
		-- --------------------
		WAIT FOR 100 ps; -- Time=9900 ps
		data_in <= transport std_logic_vector'("01101010"); --6A
		-- --------------------
		WAIT FOR 110 ps; -- Time=10010 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION sp_register_cfg OF sp_reg_tw IS
	FOR testbench_arch
	END FOR;
END sp_register_cfg;
