library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity MUX9 is
	port (in1 : in std_logic_vector(7 downto 0);		-- from	Int. Mem.
           in2 : in std_logic_vector(7 downto 0);		-- from	MUX7
           in3 : in std_logic_vector(7 downto 0);		-- from	B
           in4 : in std_logic_vector(7 downto 0);		-- from	bit_number_dec
           in5 : in std_logic_vector(7 downto 0);		-- from	Inst. Byte 3
           in6 : in std_logic_vector(7 downto 0);		-- from	Inst. Byte 2
           sel : in std_logic_vector(2 downto 0);		-- from	CU
           out1 : out std_logic_vector(7 downto 0));	-- to 	BB
end MUX9;

architecture RTL of MUX9 is
begin
	process(in1,in2,in3,in4,in5,in6,sel)
	begin
		case  sel is
		when "000" => out1 <= in1;
		when "001" => out1 <= in2;
		when "010" => out1 <= in3;
		when "011" => out1 <= "00000001";
		when "100" => out1 <= in4;
		when "101" => out1 <= in5;
		when "110" => out1 <= in6;
		when others =>out1 <= in1;
		end case;
	end process;
end RTL;
