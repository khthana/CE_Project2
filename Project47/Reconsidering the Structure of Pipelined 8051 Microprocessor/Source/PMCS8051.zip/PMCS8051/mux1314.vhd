library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux1314 is
    Port ( in1 : in std_logic_vector(7 downto 0);
           in2 : in std_logic_vector(7 downto 0);
           out1 : out std_logic_vector(7 downto 0);
           sel : in std_logic);
end mux1314;

architecture Behavioral of mux1314 is

begin


end Behavioral;
