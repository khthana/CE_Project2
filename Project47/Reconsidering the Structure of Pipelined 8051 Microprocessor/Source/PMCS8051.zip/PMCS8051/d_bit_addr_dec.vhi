
-- VHDL Instantiation Created from source file d_bit_addr_dec.vhd -- 18:36:13 02/12/2005
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT d_bit_addr_dec
	PORT(
		in1 : IN std_logic_vector(7 downto 0);          
		out1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	Inst_d_bit_addr_dec: d_bit_addr_dec PORT MAP(
		in1 => ,
		out1 => 
	);


