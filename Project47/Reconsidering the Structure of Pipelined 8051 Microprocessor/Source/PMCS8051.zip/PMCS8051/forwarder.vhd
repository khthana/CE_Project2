library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity forwarder is
    Port ( s1 : in std_logic_vector(7 downto 0);
           s2 : in std_logic_vector(7 downto 0);
           d1 : in std_logic_vector(7 downto 0);
           d2 : in std_logic_vector(7 downto 0);
           sel : in std_logic_vector(1 downto 0);
           out1 : out std_logic_vector(1 downto 0);
           out2 : out std_logic_vector(1 downto 0));
end forwarder;
  
architecture rtl of forwarder is
--	signal dtmp1, dtmp2 : std_logic_vector(7 downto 0);
begin
--		dtmp1 <= d1 or "00000000";
--		dtmp2 <= d2 or "00000000";

--		out1 <= "00" when (s1 = d1) else "01"	when (s1 = d2) else "10"; 
--		out2 <= "00" when (s2 = d1) else "01"	when (s2 = d2) else "10"; 
		process(s1, s2, d1, d2, sel)
		begin
--					out1 <= "10";
--					out2 <= "10";
			case sel	is
				when "00" 	=> out1 <= "10";
									out2 <= "10"; 	
				when "01" 	=>	out1 <= "10";
									if		(s2 = d1) 		then 	out2 <= "00";	
									elsif (s2 = d2)		then	out2 <= "01"; 
									else	out2 <= "10"; 	end if;

				when "10" 	=>	if 	(s1 = d1) 		then	out1 <= "00";	
									elsif (s1 = d2)		then 	out1 <= "01"; 
									else 	out1 <= "10"; 	end if;
									out2 <= "10"; 	
	
				when "11" 	=>	if 	(s1 = d1) 		then	out1 <= "00";	
									elsif (s1 = d2)		then 	out1 <= "01"; 
									else 	out1 <= "10"; 	end if;
									if		(s2 = d1) 		then 	out2 <= "00";	
									elsif (s2 = d2)		then	out2 <= "01"; 
									else	out2 <= "10"; 	end if;
				when others => out1 <= "10";
									out2 <= "10"; 	
			end case;



--			dtmp1 <= d1;
--			dtmp2 <= d2;
--			case s1 is
--				when "--------" 	=> out1 <= "10";
--				when d1			=> out1 <= "00";
--				when d2			=> out1 <= "01";
--				when others 		=>	out1 <= "10";
--			end case;

--			case s2 is
--				when "--------" 	=> out2 <= "10";
--				when d1			=> out2 <= "00";
--				when d2 			=> out2 <= "01";
--				when others 		=>	out2 <= "10";
--			end case;

		end process;
end rtl;
