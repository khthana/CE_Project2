-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Mon Mar 21 18:52:58 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY max1617_tb IS
END max1617_tb;

ARCHITECTURE testbench_arch OF max1617_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT max1617
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			in2 : In  std_logic_vector (7 DOWNTO 0);
			in3 : In  std_logic_vector (7 DOWNTO 0);
			out1 : Out  std_logic_vector (7 DOWNTO 0);
			sel : In  std_logic_vector (1 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in3 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL sel : std_logic_vector (1 DOWNTO 0);

BEGIN
	UUT : max1617
	PORT MAP (
		in1 => in1,
		in2 => in2,
		in3 => in3,
		out1 => out1,
		sel => sel
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("01111000"); --78
		in2 <= transport std_logic_vector'("01111000"); --78
		in3 <= transport std_logic_vector'("01110111"); --77
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=10 ns
		in1 <= transport std_logic_vector'("01101100"); --6C
		in2 <= transport std_logic_vector'("01010000"); --50
		in3 <= transport std_logic_vector'("00110101"); --35
		-- --------------------
		WAIT FOR 10 ns; -- Time=20 ns
		in1 <= transport std_logic_vector'("11010101"); --D5
		in2 <= transport std_logic_vector'("10101001"); --A9
		in3 <= transport std_logic_vector'("01111100"); --7C
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=30 ns
		in1 <= transport std_logic_vector'("00011110"); --1E
		in2 <= transport std_logic_vector'("00111110"); --3E
		in3 <= transport std_logic_vector'("01011110"); --5E
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=40 ns
		in1 <= transport std_logic_vector'("11101110"); --EE
		in2 <= transport std_logic_vector'("00001100"); --C
		in3 <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 10 ns; -- Time=50 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		in2 <= transport std_logic_vector'("01010001"); --51
		in3 <= transport std_logic_vector'("01110011"); --73
		-- --------------------
		WAIT FOR 10 ns; -- Time=60 ns
		in1 <= transport std_logic_vector'("00001010"); --A
		in2 <= transport std_logic_vector'("10001001"); --89
		in3 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 10 ns; -- Time=70 ns
		in1 <= transport std_logic_vector'("11101001"); --E9
		in2 <= transport std_logic_vector'("01110010"); --72
		in3 <= transport std_logic_vector'("11111100"); --FC
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=80 ns
		in1 <= transport std_logic_vector'("01110011"); --73
		in2 <= transport std_logic_vector'("00001001"); --9
		in3 <= transport std_logic_vector'("10011111"); --9F
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=90 ns
		in1 <= transport std_logic_vector'("10010010"); --92
		in2 <= transport std_logic_vector'("10001010"); --8A
		in3 <= transport std_logic_vector'("10000001"); --81
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("01101111"); --6F
		in2 <= transport std_logic_vector'("01110010"); --72
		in3 <= transport std_logic_vector'("01110101"); --75
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=110 ns
		in1 <= transport std_logic_vector'("01110011"); --73
		in2 <= transport std_logic_vector'("01111111"); --7F
		in3 <= transport std_logic_vector'("10001011"); --8B
		-- --------------------
		WAIT FOR 10 ns; -- Time=120 ns
		in1 <= transport std_logic_vector'("01000111"); --47
		in2 <= transport std_logic_vector'("10101110"); --AE
		in3 <= transport std_logic_vector'("00010100"); --14
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=130 ns
		in1 <= transport std_logic_vector'("11010100"); --D4
		in2 <= transport std_logic_vector'("00111011"); --3B
		in3 <= transport std_logic_vector'("10100001"); --A1
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=140 ns
		in1 <= transport std_logic_vector'("01000011"); --43
		in2 <= transport std_logic_vector'("10100011"); --A3
		in3 <= transport std_logic_vector'("00000100"); --4
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=150 ns
		in1 <= transport std_logic_vector'("11111101"); --FD
		in2 <= transport std_logic_vector'("10100100"); --A4
		in3 <= transport std_logic_vector'("01001100"); --4C
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=160 ns
		in1 <= transport std_logic_vector'("10101010"); --AA
		in2 <= transport std_logic_vector'("00111011"); --3B
		in3 <= transport std_logic_vector'("11001011"); --CB
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=170 ns
		in1 <= transport std_logic_vector'("00110101"); --35
		in2 <= transport std_logic_vector'("10100100"); --A4
		in3 <= transport std_logic_vector'("00010011"); --13
		-- --------------------
		WAIT FOR 10 ns; -- Time=180 ns
		in1 <= transport std_logic_vector'("11000110"); --C6
		in2 <= transport std_logic_vector'("01011100"); --5C
		in3 <= transport std_logic_vector'("11110011"); --F3
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=190 ns
		in1 <= transport std_logic_vector'("11000101"); --C5
		in2 <= transport std_logic_vector'("00100010"); --22
		in3 <= transport std_logic_vector'("01111110"); --7E
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("11011101"); --DD
		in2 <= transport std_logic_vector'("11110000"); --F0
		in3 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=210 ns
		in1 <= transport std_logic_vector'("11110101"); --F5
		in2 <= transport std_logic_vector'("00000101"); --5
		in3 <= transport std_logic_vector'("00010101"); --15
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=220 ns
		in1 <= transport std_logic_vector'("00111000"); --38
		in2 <= transport std_logic_vector'("11011110"); --DE
		in3 <= transport std_logic_vector'("10000100"); --84
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=230 ns
		in1 <= transport std_logic_vector'("00001101"); --D
		in2 <= transport std_logic_vector'("00110111"); --37
		in3 <= transport std_logic_vector'("01100001"); --61
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=240 ns
		in1 <= transport std_logic_vector'("00011111"); --1F
		in2 <= transport std_logic_vector'("00001110"); --E
		in3 <= transport std_logic_vector'("11111101"); --FD
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=250 ns
		in1 <= transport std_logic_vector'("01010101"); --55
		in2 <= transport std_logic_vector'("10011111"); --9F
		in3 <= transport std_logic_vector'("11101001"); --E9
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=260 ns
		in1 <= transport std_logic_vector'("11011001"); --D9
		in2 <= transport std_logic_vector'("01101000"); --68
		in3 <= transport std_logic_vector'("11110110"); --F6
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=270 ns
		in1 <= transport std_logic_vector'("00010101"); --15
		in2 <= transport std_logic_vector'("00100101"); --25
		in3 <= transport std_logic_vector'("00110101"); --35
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=280 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		in2 <= transport std_logic_vector'("11010100"); --D4
		in3 <= transport std_logic_vector'("11111000"); --F8
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=290 ns
		in1 <= transport std_logic_vector'("10010100"); --94
		in2 <= transport std_logic_vector'("10110001"); --B1
		in3 <= transport std_logic_vector'("11001110"); --CE
		-- --------------------
		WAIT FOR 10 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("11101010"); --EA
		in2 <= transport std_logic_vector'("00111010"); --3A
		in3 <= transport std_logic_vector'("10001010"); --8A
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=310 ns
		in1 <= transport std_logic_vector'("00011011"); --1B
		in2 <= transport std_logic_vector'("00101011"); --2B
		in3 <= transport std_logic_vector'("00111011"); --3B
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=320 ns
		in1 <= transport std_logic_vector'("11010000"); --D0
		in2 <= transport std_logic_vector'("10000010"); --82
		in3 <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 10 ns; -- Time=330 ns
		in1 <= transport std_logic_vector'("11110010"); --F2
		in2 <= transport std_logic_vector'("01111011"); --7B
		in3 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 10 ns; -- Time=340 ns
		in1 <= transport std_logic_vector'("10101010"); --AA
		in2 <= transport std_logic_vector'("10010100"); --94
		in3 <= transport std_logic_vector'("01111110"); --7E
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=350 ns
		in1 <= transport std_logic_vector'("01100001"); --61
		in2 <= transport std_logic_vector'("10001010"); --8A
		in3 <= transport std_logic_vector'("10110010"); --B2
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=360 ns
		in1 <= transport std_logic_vector'("11000000"); --C0
		in2 <= transport std_logic_vector'("01011000"); --58
		in3 <= transport std_logic_vector'("11110001"); --F1
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=370 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		in2 <= transport std_logic_vector'("00111110"); --3E
		in3 <= transport std_logic_vector'("11001100"); --CC
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=380 ns
		in1 <= transport std_logic_vector'("01011001"); --59
		in2 <= transport std_logic_vector'("10110111"); --B7
		in3 <= transport std_logic_vector'("00010100"); --14
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=390 ns
		in1 <= transport std_logic_vector'("00100110"); --26
		in2 <= transport std_logic_vector'("10000000"); --80
		in3 <= transport std_logic_vector'("11011010"); --DA
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("10111111"); --BF
		in2 <= transport std_logic_vector'("10010111"); --97
		in3 <= transport std_logic_vector'("01101111"); --6F
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=410 ns
		in1 <= transport std_logic_vector'("00001100"); --C
		in2 <= transport std_logic_vector'("00111001"); --39
		in3 <= transport std_logic_vector'("01100101"); --65
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=420 ns
		in1 <= transport std_logic_vector'("00111000"); --38
		in2 <= transport std_logic_vector'("11100010"); --E2
		in3 <= transport std_logic_vector'("10001011"); --8B
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=430 ns
		in1 <= transport std_logic_vector'("10101010"); --AA
		in2 <= transport std_logic_vector'("01001111"); --4F
		in3 <= transport std_logic_vector'("11110100"); --F4
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=440 ns
		in1 <= transport std_logic_vector'("00001101"); --D
		in2 <= transport std_logic_vector'("01111110"); --7E
		in3 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 10 ns; -- Time=450 ns
		in1 <= transport std_logic_vector'("01001000"); --48
		in2 <= transport std_logic_vector'("10101100"); --AC
		in3 <= transport std_logic_vector'("00001111"); --F
		-- --------------------
		WAIT FOR 10 ns; -- Time=460 ns
		in1 <= transport std_logic_vector'("10000110"); --86
		in2 <= transport std_logic_vector'("01010101"); --55
		in3 <= transport std_logic_vector'("00100011"); --23
		-- --------------------
		WAIT FOR 10 ns; -- Time=470 ns
		in1 <= transport std_logic_vector'("00101110"); --2E
		in2 <= transport std_logic_vector'("00110110"); --36
		in3 <= transport std_logic_vector'("00111110"); --3E
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=480 ns
		in1 <= transport std_logic_vector'("11101010"); --EA
		in2 <= transport std_logic_vector'("01001101"); --4D
		in3 <= transport std_logic_vector'("10110000"); --B0
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=490 ns
		in1 <= transport std_logic_vector'("10100100"); --A4
		in2 <= transport std_logic_vector'("11010111"); --D7
		in3 <= transport std_logic_vector'("00001010"); --A
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("10000011"); --83
		in2 <= transport std_logic_vector'("01010000"); --50
		in3 <= transport std_logic_vector'("00011101"); --1D
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=510 ns
		in1 <= transport std_logic_vector'("11110001"); --F1
		in2 <= transport std_logic_vector'("01110110"); --76
		in3 <= transport std_logic_vector'("11111010"); --FA
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=520 ns
		in1 <= transport std_logic_vector'("10010111"); --97
		in2 <= transport std_logic_vector'("01000101"); --45
		in3 <= transport std_logic_vector'("11110010"); --F2
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=530 ns
		in1 <= transport std_logic_vector'("01011110"); --5E
		in2 <= transport std_logic_vector'("11111010"); --FA
		in3 <= transport std_logic_vector'("10010111"); --97
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=540 ns
		in1 <= transport std_logic_vector'("01101111"); --6F
		in2 <= transport std_logic_vector'("00010011"); --13
		in3 <= transport std_logic_vector'("10111000"); --B8
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=550 ns
		in1 <= transport std_logic_vector'("00110011"); --33
		in2 <= transport std_logic_vector'("01001101"); --4D
		in3 <= transport std_logic_vector'("01100111"); --67
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=560 ns
		in1 <= transport std_logic_vector'("01010011"); --53
		in2 <= transport std_logic_vector'("10100100"); --A4
		in3 <= transport std_logic_vector'("11110110"); --F6
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=570 ns
		in1 <= transport std_logic_vector'("10111000"); --B8
		in2 <= transport std_logic_vector'("01010110"); --56
		in3 <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 10 ns; -- Time=580 ns
		in1 <= transport std_logic_vector'("10001010"); --8A
		in2 <= transport std_logic_vector'("11011111"); --DF
		in3 <= transport std_logic_vector'("00110100"); --34
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=590 ns
		in1 <= transport std_logic_vector'("00110100"); --34
		in2 <= transport std_logic_vector'("11111101"); --FD
		in3 <= transport std_logic_vector'("11000110"); --C6
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("01011110"); --5E
		in2 <= transport std_logic_vector'("10101100"); --AC
		in3 <= transport std_logic_vector'("11111011"); --FB
		-- --------------------
		WAIT FOR 10 ns; -- Time=610 ns
		in1 <= transport std_logic_vector'("11110001"); --F1
		in2 <= transport std_logic_vector'("00101010"); --2A
		in3 <= transport std_logic_vector'("01100011"); --63
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=620 ns
		in1 <= transport std_logic_vector'("00010101"); --15
		in2 <= transport std_logic_vector'("11110011"); --F3
		in3 <= transport std_logic_vector'("11010001"); --D1
		-- --------------------
		WAIT FOR 10 ns; -- Time=630 ns
		in1 <= transport std_logic_vector'("00110101"); --35
		in2 <= transport std_logic_vector'("11000101"); --C5
		in3 <= transport std_logic_vector'("01010101"); --55
		-- --------------------
		WAIT FOR 10 ns; -- Time=640 ns
		in1 <= transport std_logic_vector'("11111000"); --F8
		in2 <= transport std_logic_vector'("10011100"); --9C
		in3 <= transport std_logic_vector'("01000001"); --41
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=650 ns
		in1 <= transport std_logic_vector'("01001001"); --49
		in2 <= transport std_logic_vector'("10110110"); --B6
		in3 <= transport std_logic_vector'("00100100"); --24
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=660 ns
		in1 <= transport std_logic_vector'("01001111"); --4F
		in2 <= transport std_logic_vector'("10010000"); --90
		in3 <= transport std_logic_vector'("11010000"); --D0
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=670 ns
		in1 <= transport std_logic_vector'("01110101"); --75
		in2 <= transport std_logic_vector'("11100101"); --E5
		in3 <= transport std_logic_vector'("01010110"); --56
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=680 ns
		in1 <= transport std_logic_vector'("01100010"); --62
		in2 <= transport std_logic_vector'("10110101"); --B5
		in3 <= transport std_logic_vector'("00001000"); --8
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=690 ns
		in1 <= transport std_logic_vector'("00000000"); --0
		in2 <= transport std_logic_vector'("00111011"); --3B
		in3 <= transport std_logic_vector'("01110101"); --75
		-- --------------------
		WAIT FOR 10 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("01111000"); --78
		in2 <= transport std_logic_vector'("11110100"); --F4
		in3 <= transport std_logic_vector'("01110000"); --70
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=710 ns
		in1 <= transport std_logic_vector'("00110100"); --34
		in2 <= transport std_logic_vector'("10011110"); --9E
		in3 <= transport std_logic_vector'("00001001"); --9
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=720 ns
		in1 <= transport std_logic_vector'("11011011"); --DB
		in2 <= transport std_logic_vector'("00110110"); --36
		in3 <= transport std_logic_vector'("10010000"); --90
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=730 ns
		in1 <= transport std_logic_vector'("01010111"); --57
		in2 <= transport std_logic_vector'("11110111"); --F7
		in3 <= transport std_logic_vector'("10011000"); --98
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=740 ns
		in1 <= transport std_logic_vector'("11010001"); --D1
		in2 <= transport std_logic_vector'("01100001"); --61
		in3 <= transport std_logic_vector'("11110001"); --F1
		-- --------------------
		WAIT FOR 10 ns; -- Time=750 ns
		in1 <= transport std_logic_vector'("10110010"); --B2
		in2 <= transport std_logic_vector'("00101111"); --2F
		in3 <= transport std_logic_vector'("10101100"); --AC
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=760 ns
		in1 <= transport std_logic_vector'("10100011"); --A3
		in2 <= transport std_logic_vector'("01011110"); --5E
		in3 <= transport std_logic_vector'("00011010"); --1A
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=770 ns
		in1 <= transport std_logic_vector'("10001101"); --8D
		in2 <= transport std_logic_vector'("00101100"); --2C
		in3 <= transport std_logic_vector'("11001100"); --CC
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=780 ns
		in1 <= transport std_logic_vector'("10011001"); --99
		in2 <= transport std_logic_vector'("00010110"); --16
		in3 <= transport std_logic_vector'("10010011"); --93
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=790 ns
		in1 <= transport std_logic_vector'("00110000"); --30
		in2 <= transport std_logic_vector'("11011000"); --D8
		in3 <= transport std_logic_vector'("10000001"); --81
		-- --------------------
		WAIT FOR 10 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("11111010"); --FA
		in2 <= transport std_logic_vector'("01110000"); --70
		in3 <= transport std_logic_vector'("11100101"); --E5
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=810 ns
		in1 <= transport std_logic_vector'("11100010"); --E2
		in2 <= transport std_logic_vector'("00011010"); --1A
		in3 <= transport std_logic_vector'("01010001"); --51
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=820 ns
		in1 <= transport std_logic_vector'("00010000"); --10
		in2 <= transport std_logic_vector'("01010011"); --53
		in3 <= transport std_logic_vector'("10010111"); --97
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=830 ns
		in1 <= transport std_logic_vector'("11101100"); --EC
		in2 <= transport std_logic_vector'("11011001"); --D9
		in3 <= transport std_logic_vector'("11000111"); --C7
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=840 ns
		in1 <= transport std_logic_vector'("00100001"); --21
		in2 <= transport std_logic_vector'("10101001"); --A9
		in3 <= transport std_logic_vector'("00110001"); --31
		-- --------------------
		WAIT FOR 10 ns; -- Time=850 ns
		in1 <= transport std_logic_vector'("10010110"); --96
		in2 <= transport std_logic_vector'("11111111"); --FF
		in3 <= transport std_logic_vector'("01101000"); --68
		-- --------------------
		WAIT FOR 10 ns; -- Time=860 ns
		in1 <= transport std_logic_vector'("01110110"); --76
		in2 <= transport std_logic_vector'("01011001"); --59
		in3 <= transport std_logic_vector'("00111100"); --3C
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=870 ns
		in1 <= transport std_logic_vector'("00101000"); --28
		in2 <= transport std_logic_vector'("01110011"); --73
		in3 <= transport std_logic_vector'("10111110"); --BE
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=880 ns
		in1 <= transport std_logic_vector'("01010111"); --57
		in2 <= transport std_logic_vector'("01001011"); --4B
		in3 <= transport std_logic_vector'("00111111"); --3F
		-- --------------------
		WAIT FOR 10 ns; -- Time=890 ns
		in1 <= transport std_logic_vector'("11101010"); --EA
		in2 <= transport std_logic_vector'("00011101"); --1D
		in3 <= transport std_logic_vector'("01010000"); --50
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		in2 <= transport std_logic_vector'("01100111"); --67
		in3 <= transport std_logic_vector'("11000010"); --C2
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=910 ns
		in1 <= transport std_logic_vector'("00100100"); --24
		in2 <= transport std_logic_vector'("11100101"); --E5
		in3 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 10 ns; -- Time=920 ns
		in1 <= transport std_logic_vector'("11011100"); --DC
		in2 <= transport std_logic_vector'("10010101"); --95
		in3 <= transport std_logic_vector'("01001101"); --4D
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=930 ns
		in1 <= transport std_logic_vector'("00011101"); --1D
		in2 <= transport std_logic_vector'("10110011"); --B3
		in3 <= transport std_logic_vector'("01001001"); --49
		sel <= transport std_logic_vector'("00"); --0
		-- --------------------
		WAIT FOR 10 ns; -- Time=940 ns
		in1 <= transport std_logic_vector'("00010000"); --10
		in2 <= transport std_logic_vector'("10111101"); --BD
		in3 <= transport std_logic_vector'("01101001"); --69
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=950 ns
		in1 <= transport std_logic_vector'("00011110"); --1E
		in2 <= transport std_logic_vector'("01101111"); --6F
		in3 <= transport std_logic_vector'("11000000"); --C0
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 10 ns; -- Time=960 ns
		in1 <= transport std_logic_vector'("11110000"); --F0
		in2 <= transport std_logic_vector'("11000111"); --C7
		in3 <= transport std_logic_vector'("10011101"); --9D
		sel <= transport std_logic_vector'("10"); --2
		-- --------------------
		WAIT FOR 10 ns; -- Time=970 ns
		in1 <= transport std_logic_vector'("01101111"); --6F
		in2 <= transport std_logic_vector'("00000001"); --1
		in3 <= transport std_logic_vector'("10010011"); --93
		sel <= transport std_logic_vector'("11"); --3
		-- --------------------
		WAIT FOR 10 ns; -- Time=980 ns
		in1 <= transport std_logic_vector'("11000100"); --C4
		in2 <= transport std_logic_vector'("10011011"); --9B
		in3 <= transport std_logic_vector'("01110010"); --72
		-- --------------------
		WAIT FOR 10 ns; -- Time=990 ns
		in1 <= transport std_logic_vector'("01011000"); --58
		in2 <= transport std_logic_vector'("01010001"); --51
		in3 <= transport std_logic_vector'("01001011"); --4B
		sel <= transport std_logic_vector'("01"); --1
		-- --------------------
		WAIT FOR 15 ns; -- Time=1005 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION max1617_cfg OF max1617_tb IS
	FOR testbench_arch
	END FOR;
END max1617_cfg;
