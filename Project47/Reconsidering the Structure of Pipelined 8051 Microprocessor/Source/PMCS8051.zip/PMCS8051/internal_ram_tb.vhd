
-- VHDL Test Bench Created from source file internal_ram.vhd -- 04:23:44 02/13/2005
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends 
-- that these types always be used for the top-level I/O of a design in order 
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY internal_ram_internal_ram_tb_vhd_tb IS
END internal_ram_internal_ram_tb_vhd_tb;

ARCHITECTURE behavior OF internal_ram_internal_ram_tb_vhd_tb IS 

	COMPONENT internal_ram
	PORT(
		rst : IN std_logic;
		clk : IN std_logic;
      r_bit_addr : in  std_logic_vector (7 downto 0);
      w_bit_addr : in  std_logic_vector (7 downto 0);
		in_bit_data : IN std_logic;
		w_bit : IN std_logic;
		p0_in : IN std_logic_vector(7 downto 0);
		p1_in : IN std_logic_vector(7 downto 0);
		p2_in : IN std_logic_vector(7 downto 0);
		p3_in : IN std_logic_vector(7 downto 0);
--      w_p0 : in  STD_LOGIC;
--      w_p1 : in  STD_LOGIC;
--      w_p2 : in  STD_LOGIC;
--      w_p3 : in  STD_LOGIC;
		wr_bank0 : IN std_logic;
		r_addr_bank0 : IN std_logic_vector(7 downto 0);
		w_addr_bank0 : IN std_logic_vector(7 downto 0);
		di_bank0 : IN std_logic_vector(7 downto 0);
		wr_bank1 : IN std_logic;
		r_addr_bank1 : IN std_logic_vector(7 downto 0);
		w_addr_bank1 : IN std_logic_vector(7 downto 0);
		di_bank1 : IN std_logic_vector(7 downto 0);          
		out_bit_data : OUT std_logic;
		p0_out : OUT std_logic_vector(7 downto 0);
		p1_out : OUT std_logic_vector(7 downto 0);
		p2_out : OUT std_logic_vector(7 downto 0);
		p3_out : OUT std_logic_vector(7 downto 0);
		do_bank0 : OUT std_logic_vector(7 downto 0);
		do_bank1 : OUT std_logic_vector(7 downto 0)
		);
	END COMPONENT;

	SIGNAL rst :  std_logic;
	SIGNAL clk :  std_logic:='1';
	SIGNAL r_bit_addr :  std_logic_vector(7 downto 0);
	SIGNAL w_bit_addr :  std_logic_vector(7 downto 0);
	SIGNAL in_bit_data :  std_logic;
	SIGNAL out_bit_data :  std_logic;
	SIGNAL w_bit :  std_logic;
	SIGNAL p0_in :  std_logic_vector(7 downto 0);
	SIGNAL p0_out :  std_logic_vector(7 downto 0);
	SIGNAL p1_in :  std_logic_vector(7 downto 0);
	SIGNAL p1_out :  std_logic_vector(7 downto 0);
	SIGNAL p2_in :  std_logic_vector(7 downto 0);
	SIGNAL p2_out :  std_logic_vector(7 downto 0);
	SIGNAL p3_in :  std_logic_vector(7 downto 0);
	SIGNAL p3_out :  std_logic_vector(7 downto 0);
	SIGNAL wr_bank0 :  std_logic;
	SIGNAL r_addr_bank0 :  std_logic_vector(7 downto 0);
	SIGNAL w_addr_bank0 :  std_logic_vector(7 downto 0);
	SIGNAL di_bank0 :  std_logic_vector(7 downto 0);
	SIGNAL do_bank0 :  std_logic_vector(7 downto 0);
	SIGNAL wr_bank1 :  std_logic;
	SIGNAL r_addr_bank1 :  std_logic_vector(7 downto 0);
	SIGNAL w_addr_bank1 :  std_logic_vector(7 downto 0);
	SIGNAL di_bank1 :  std_logic_vector(7 downto 0);
	SIGNAL do_bank1 :  std_logic_vector(7 downto 0);
--	SIGNAL w_p0 : STD_LOGIC;
--	SIGNAL w_p1 : STD_LOGIC;
--	SIGNAL w_p2 : STD_LOGIC;
--	SIGNAL w_p3 : STD_LOGIC;
BEGIN

	uut: internal_ram PORT MAP(
		rst => rst,
		clk => clk,
		r_bit_addr => r_bit_addr,
		w_bit_addr => w_bit_addr,
		in_bit_data => in_bit_data,
		out_bit_data => out_bit_data,
		w_bit => w_bit,
		p0_in => p0_in,
		p0_out => p0_out,
		p1_in => p1_in,
		p1_out => p1_out,
		p2_in => p2_in,
		p2_out => p2_out,
		p3_in => p3_in,
		p3_out => p3_out,
		wr_bank0 => wr_bank0,
		r_addr_bank0 => r_addr_bank0,
		w_addr_bank0 => w_addr_bank0,
		di_bank0 => di_bank0,
		do_bank0 => do_bank0,
		wr_bank1 => wr_bank1,
		r_addr_bank1 => r_addr_bank1,
		w_addr_bank1 => w_addr_bank1,
		di_bank1 => di_bank1,
		do_bank1 => do_bank1
--		w_p0 => w_p0,
--		w_p1 => w_p1,
--		w_p2 => w_p2,
--		w_p3 => w_p3
	);

   	clk <= not clk after 5 ps;

		rst <=	'1',
					'0' after 10 ps;

		r_addr_bank0 <=			"00000000",
					"00000001" after 10 ps,
					"00000010" after 20 ps,
					"00000011" after 30 ps,
					"00000100" after 40 ps,
					"00000101" after 50 ps,
					"00000110" after 60 ps,
					"00000111" after 70 ps,
					"00001000" after 80 ps,
					"00001001" after 90 ps,
					"00001010" after 100 ps,
					"00001011" after 110 ps,
					"00001100" after 120 ps,
					"00001101" after 130 ps,
					
					"00000000" after 140 ps,
					
					"00000001" after 270 ps,
					"00000010" after 280 ps,
					"00000011" after 290 ps,
					"00000100" after 300 ps,
					"00000101" after 310 ps,
					"00000110" after 320 ps,
					"00000111" after 330 ps,
					"00001000" after 340 ps,
					"00001001" after 350 ps,
					"00001010" after 360 ps,
					"00001011" after 370 ps,
					"00001100" after 380 ps,
					"00001101" after 390 ps,
					"00000000" after 400 ps;


		w_addr_bank0 <=	"00000000",		
					"00000001" after 140 ps,
					"00000010" after 150 ps,
					"00000011" after 160 ps,
					"00000100" after 170 ps,
					"00000101" after 180 ps,
					"00000110" after 190 ps,
					"00000111" after 200 ps,
					"00001000" after 210 ps,
					"00001001" after 220 ps,
					"00001010" after 230 ps,
					"00001011" after 240 ps,
					"00001100" after 250 ps,
					"00001101" after 260 ps,
					"00000000" after 270 ps;


 		r_addr_bank1 <=			"00000000",
					"10000001" after 10 ps,
					"10000010" after 20 ps,
					"10000011" after 30 ps,
					"10000100" after 40 ps,
					"10000101" after 50 ps,
					"10000110" after 60 ps,
					"10000111" after 70 ps,
					"10001000" after 80 ps,
					"10001001" after 90 ps,
					"10001010" after 100 ps,
					"10001011" after 110 ps,
					"10001100" after 120 ps,
					"10001101" after 130 ps,
					
					"00000000" after 140 ps,

					"10000001" after 270 ps,
					"10000010" after 280 ps,
					"10000011" after 290 ps,
					"10000100" after 300 ps,
					"10000101" after 310 ps,
					"10000110" after 320 ps,
					"10000111" after 330 ps,
					"10001000" after 340 ps,
					"10001001" after 350 ps,
					"10001010" after 360 ps,
					"10001011" after 370 ps,
					"10001100" after 380 ps,
					"10001101" after 390 ps,
					"00000000" after 400 ps;

		w_addr_bank1 <=	"00000000",		
					"10000001" after 140 ps,
					"10000010" after 150 ps,
					"10000011" after 160 ps,
					"10000100" after 170 ps,
					"10000101" after 180 ps,
					"10000110" after 190 ps,
					"10000111" after 200 ps,
					"10001000" after 210 ps,
					"10001001" after 220 ps,
					"10001010" after 230 ps,
					"10001011" after 240 ps,
					"10001100" after 250 ps,
					"10001101" after 260 ps,
					"00000000" after 270 ps;

		r_bit_addr <= 			"00000000",
					"00000001" after 10 ps,
					"00000010" after 20 ps,
					"00000011" after 30 ps,
					"00000100" after 40 ps,
					"00000011" after 50 ps,
					"00000100" after 60 ps,
					"00000111" after 70 ps,
					"10000000" after 80 ps,
					"10001000" after 90 ps,
					"10010000" after 100 ps,
					"10011000" after 110 ps,
					"10100000" after 120 ps,
					"10011000" after 130 ps,
					"10100000" after 140 ps,
					"00000000" after 150 ps;

		w_bit_addr <= 			"00000000",
					"00000011" after 30 ps,
					"00000100" after 40 ps,
					"00000000" after 50 ps,
					"10010000" after 100 ps,
					"10011000" after 110 ps,
					"10100000" after 120 ps,
					"00000000" after 130 ps;

		di_bank1 <= "--------",
						"11001100" after 140 ps,
						"11111111" after 150 ps,
						"00110011" after 160 ps,
						"00000000" after 170 ps;
		di_bank0 <= "--------",
						"10101010" after 140 ps,
						"00000000" after 150 ps,
						"01010101" after 160 ps,
						"--------" after 170 ps;
		in_bit_data <=		'-' ,
								'1' after 30 ps,
								'1' after 40 ps,
								'-' after 50 ps,
								'1' after 110 ps,
								'1' after 120 ps,
								'-' after 130 ps;

		p0_in <= "00000000";
		p1_in <= "00000000";
		p2_in <= "00000000";
		p3_in <= "00000000";

		wr_bank0 <= 		'0',
				'1' after 140 ps,
				'0' after 170 ps;
		wr_bank1 <= 		'0',
				'1' after 140 ps,
				'0' after 170 ps;
		w_bit <= 		'0',
				'1' after 30 ps,
				'0' after 50 ps,
				'1' after 110 ps,
				'0' after 130 ps;




-- *** Test Bench - User Defined Section ***
   tb : PROCESS
   BEGIN
      wait ; -- will wait forever
   END PROCESS;
-- *** End Test Bench - User Defined Section ***

END;
