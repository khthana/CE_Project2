-- E:\USERS\POLARBEAR\PROJECT\FATCHM
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Sun Feb 13 23:09:07 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY latch_tb IS
END latch_tb;

ARCHITECTURE testbench_arch OF latch_tb IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT latch
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			in2 : In  std_logic_vector (7 DOWNTO 0);
			en : In  std_logic;
			out1 : Out  std_logic_vector (7 DOWNTO 0);
			out2 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL en : std_logic;
	SIGNAL out1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL out2 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : latch
	PORT MAP (
		in1 => in1,
		in2 => in2,
		en => en,
		out1 => out1,
		out2 => out2
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_out1(
			next_out1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out1 /= next_out1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_out2(
			next_out2 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (out2 /= next_out2) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ns out2="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out2);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out2);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("00000001"); --1
		in2 <= transport std_logic_vector'("00000000"); --0
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=100 ns
		in1 <= transport std_logic_vector'("00000011"); --3
		in2 <= transport std_logic_vector'("00000010"); --2
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=200 ns
		in1 <= transport std_logic_vector'("00000101"); --5
		in2 <= transport std_logic_vector'("00000100"); --4
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=300 ns
		in1 <= transport std_logic_vector'("00000111"); --7
		in2 <= transport std_logic_vector'("00000110"); --6
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=400 ns
		in1 <= transport std_logic_vector'("00001001"); --9
		in2 <= transport std_logic_vector'("00001000"); --8
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=500 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		in2 <= transport std_logic_vector'("00001010"); --A
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=600 ns
		in1 <= transport std_logic_vector'("00001101"); --D
		in2 <= transport std_logic_vector'("00001100"); --C
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=700 ns
		in1 <= transport std_logic_vector'("00001111"); --F
		in2 <= transport std_logic_vector'("00001110"); --E
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=800 ns
		in1 <= transport std_logic_vector'("00001000"); --8
		in2 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 100 ns; -- Time=900 ns
		in1 <= transport std_logic_vector'("00001001"); --9
		in2 <= transport std_logic_vector'("00010010"); --12
		-- --------------------
		WAIT FOR 100 ns; -- Time=1000 ns
		in1 <= transport std_logic_vector'("00001010"); --A
		in2 <= transport std_logic_vector'("00010100"); --14
		-- --------------------
		WAIT FOR 100 ns; -- Time=1100 ns
		in1 <= transport std_logic_vector'("00001011"); --B
		in2 <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 100 ns; -- Time=1200 ns
		in1 <= transport std_logic_vector'("00001100"); --C
		in2 <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 100 ns; -- Time=1300 ns
		in1 <= transport std_logic_vector'("00001101"); --D
		in2 <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 100 ns; -- Time=1400 ns
		in1 <= transport std_logic_vector'("00001110"); --E
		in2 <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 100 ns; -- Time=1500 ns
		in1 <= transport std_logic_vector'("00001111"); --F
		in2 <= transport std_logic_vector'("00011110"); --1E
		-- --------------------
		WAIT FOR 100 ns; -- Time=1600 ns
		in1 <= transport std_logic_vector'("00010000"); --10
		in2 <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 100 ns; -- Time=1700 ns
		in1 <= transport std_logic_vector'("00010001"); --11
		in2 <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 100 ns; -- Time=1800 ns
		in1 <= transport std_logic_vector'("00010010"); --12
		in2 <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 100 ns; -- Time=1900 ns
		in1 <= transport std_logic_vector'("00010011"); --13
		in2 <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ns; -- Time=2000 ns
		in1 <= transport std_logic_vector'("00010100"); --14
		in2 <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 100 ns; -- Time=2100 ns
		in1 <= transport std_logic_vector'("00010101"); --15
		in2 <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 100 ns; -- Time=2200 ns
		in1 <= transport std_logic_vector'("00010110"); --16
		in2 <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 100 ns; -- Time=2300 ns
		in1 <= transport std_logic_vector'("00010111"); --17
		in2 <= transport std_logic_vector'("00101110"); --2E
		-- --------------------
		WAIT FOR 100 ns; -- Time=2400 ns
		in1 <= transport std_logic_vector'("00011000"); --18
		in2 <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 100 ns; -- Time=2500 ns
		in1 <= transport std_logic_vector'("00011001"); --19
		in2 <= transport std_logic_vector'("00110010"); --32
		-- --------------------
		WAIT FOR 100 ns; -- Time=2600 ns
		in1 <= transport std_logic_vector'("00011010"); --1A
		in2 <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 100 ns; -- Time=2700 ns
		in1 <= transport std_logic_vector'("00011011"); --1B
		in2 <= transport std_logic_vector'("00110110"); --36
		-- --------------------
		WAIT FOR 100 ns; -- Time=2800 ns
		in1 <= transport std_logic_vector'("00011100"); --1C
		in2 <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 100 ns; -- Time=2900 ns
		in1 <= transport std_logic_vector'("00011101"); --1D
		in2 <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 100 ns; -- Time=3000 ns
		in1 <= transport std_logic_vector'("00011110"); --1E
		in2 <= transport std_logic_vector'("00111100"); --3C
		-- --------------------
		WAIT FOR 100 ns; -- Time=3100 ns
		in1 <= transport std_logic_vector'("00011111"); --1F
		in2 <= transport std_logic_vector'("00111110"); --3E
		-- --------------------
		WAIT FOR 100 ns; -- Time=3200 ns
		in1 <= transport std_logic_vector'("00100000"); --20
		in2 <= transport std_logic_vector'("01000000"); --40
		-- --------------------
		WAIT FOR 100 ns; -- Time=3300 ns
		in1 <= transport std_logic_vector'("00100001"); --21
		in2 <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 100 ns; -- Time=3400 ns
		in1 <= transport std_logic_vector'("00100010"); --22
		in2 <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 100 ns; -- Time=3500 ns
		in1 <= transport std_logic_vector'("00100011"); --23
		in2 <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 100 ns; -- Time=3600 ns
		in1 <= transport std_logic_vector'("00100100"); --24
		in2 <= transport std_logic_vector'("01001000"); --48
		-- --------------------
		WAIT FOR 100 ns; -- Time=3700 ns
		in1 <= transport std_logic_vector'("00100101"); --25
		in2 <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 100 ns; -- Time=3800 ns
		in1 <= transport std_logic_vector'("00100110"); --26
		in2 <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 100 ns; -- Time=3900 ns
		in1 <= transport std_logic_vector'("00100111"); --27
		in2 <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 100 ns; -- Time=4000 ns
		in1 <= transport std_logic_vector'("00101000"); --28
		in2 <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 100 ns; -- Time=4100 ns
		in1 <= transport std_logic_vector'("00101001"); --29
		in2 <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 100 ns; -- Time=4200 ns
		in1 <= transport std_logic_vector'("00101010"); --2A
		in2 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ns; -- Time=4300 ns
		in1 <= transport std_logic_vector'("00101011"); --2B
		in2 <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 100 ns; -- Time=4400 ns
		in1 <= transport std_logic_vector'("00101100"); --2C
		in2 <= transport std_logic_vector'("01011000"); --58
		-- --------------------
		WAIT FOR 100 ns; -- Time=4500 ns
		in1 <= transport std_logic_vector'("00101101"); --2D
		in2 <= transport std_logic_vector'("01011010"); --5A
		-- --------------------
		WAIT FOR 100 ns; -- Time=4600 ns
		in1 <= transport std_logic_vector'("00101110"); --2E
		in2 <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 100 ns; -- Time=4700 ns
		in1 <= transport std_logic_vector'("00101111"); --2F
		in2 <= transport std_logic_vector'("01011110"); --5E
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=4800 ns
		in1 <= transport std_logic_vector'("00110000"); --30
		in2 <= transport std_logic_vector'("01100000"); --60
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=4900 ns
		in1 <= transport std_logic_vector'("00110001"); --31
		in2 <= transport std_logic_vector'("01100010"); --62
		-- --------------------
		WAIT FOR 100 ns; -- Time=5000 ns
		in1 <= transport std_logic_vector'("00110010"); --32
		in2 <= transport std_logic_vector'("01100100"); --64
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=5100 ns
		in1 <= transport std_logic_vector'("00110011"); --33
		in2 <= transport std_logic_vector'("01100110"); --66
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=5200 ns
		in1 <= transport std_logic_vector'("00110100"); --34
		in2 <= transport std_logic_vector'("01101000"); --68
		-- --------------------
		WAIT FOR 100 ns; -- Time=5300 ns
		in1 <= transport std_logic_vector'("00110101"); --35
		in2 <= transport std_logic_vector'("01101010"); --6A
		-- --------------------
		WAIT FOR 100 ns; -- Time=5400 ns
		in1 <= transport std_logic_vector'("00110110"); --36
		in2 <= transport std_logic_vector'("01101100"); --6C
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=5500 ns
		in1 <= transport std_logic_vector'("00110111"); --37
		in2 <= transport std_logic_vector'("01101110"); --6E
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=5600 ns
		in1 <= transport std_logic_vector'("00111000"); --38
		in2 <= transport std_logic_vector'("01110000"); --70
		-- --------------------
		WAIT FOR 100 ns; -- Time=5700 ns
		in1 <= transport std_logic_vector'("00111001"); --39
		in2 <= transport std_logic_vector'("01110010"); --72
		-- --------------------
		WAIT FOR 100 ns; -- Time=5800 ns
		in1 <= transport std_logic_vector'("00111010"); --3A
		in2 <= transport std_logic_vector'("01110100"); --74
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=5900 ns
		in1 <= transport std_logic_vector'("00111011"); --3B
		in2 <= transport std_logic_vector'("01110110"); --76
		-- --------------------
		WAIT FOR 100 ns; -- Time=6000 ns
		in1 <= transport std_logic_vector'("00111100"); --3C
		in2 <= transport std_logic_vector'("01111000"); --78
		-- --------------------
		WAIT FOR 100 ns; -- Time=6100 ns
		in1 <= transport std_logic_vector'("00111101"); --3D
		in2 <= transport std_logic_vector'("01111010"); --7A
		-- --------------------
		WAIT FOR 100 ns; -- Time=6200 ns
		in1 <= transport std_logic_vector'("00111110"); --3E
		in2 <= transport std_logic_vector'("01111100"); --7C
		-- --------------------
		WAIT FOR 100 ns; -- Time=6300 ns
		in1 <= transport std_logic_vector'("00111111"); --3F
		in2 <= transport std_logic_vector'("01111110"); --7E
		-- --------------------
		WAIT FOR 100 ns; -- Time=6400 ns
		in1 <= transport std_logic_vector'("01000000"); --40
		in2 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 100 ns; -- Time=6500 ns
		in1 <= transport std_logic_vector'("01000001"); --41
		in2 <= transport std_logic_vector'("10000010"); --82
		-- --------------------
		WAIT FOR 100 ns; -- Time=6600 ns
		in1 <= transport std_logic_vector'("01000010"); --42
		in2 <= transport std_logic_vector'("10000100"); --84
		-- --------------------
		WAIT FOR 100 ns; -- Time=6700 ns
		in1 <= transport std_logic_vector'("01000011"); --43
		in2 <= transport std_logic_vector'("10000110"); --86
		-- --------------------
		WAIT FOR 100 ns; -- Time=6800 ns
		in1 <= transport std_logic_vector'("01000100"); --44
		in2 <= transport std_logic_vector'("10001000"); --88
		-- --------------------
		WAIT FOR 100 ns; -- Time=6900 ns
		in1 <= transport std_logic_vector'("01000101"); --45
		in2 <= transport std_logic_vector'("10001010"); --8A
		-- --------------------
		WAIT FOR 100 ns; -- Time=7000 ns
		in1 <= transport std_logic_vector'("01000110"); --46
		in2 <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 100 ns; -- Time=7100 ns
		in1 <= transport std_logic_vector'("01000111"); --47
		in2 <= transport std_logic_vector'("10001110"); --8E
		-- --------------------
		WAIT FOR 100 ns; -- Time=7200 ns
		in1 <= transport std_logic_vector'("01001000"); --48
		in2 <= transport std_logic_vector'("10010000"); --90
		-- --------------------
		WAIT FOR 100 ns; -- Time=7300 ns
		in1 <= transport std_logic_vector'("01001001"); --49
		in2 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 100 ns; -- Time=7400 ns
		in1 <= transport std_logic_vector'("01001010"); --4A
		in2 <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 100 ns; -- Time=7500 ns
		in1 <= transport std_logic_vector'("01001011"); --4B
		in2 <= transport std_logic_vector'("10010110"); --96
		-- --------------------
		WAIT FOR 100 ns; -- Time=7600 ns
		in1 <= transport std_logic_vector'("01001100"); --4C
		in2 <= transport std_logic_vector'("10011000"); --98
		-- --------------------
		WAIT FOR 100 ns; -- Time=7700 ns
		in1 <= transport std_logic_vector'("01001101"); --4D
		in2 <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 100 ns; -- Time=7800 ns
		in1 <= transport std_logic_vector'("01001110"); --4E
		in2 <= transport std_logic_vector'("10011100"); --9C
		-- --------------------
		WAIT FOR 100 ns; -- Time=7900 ns
		in1 <= transport std_logic_vector'("01001111"); --4F
		in2 <= transport std_logic_vector'("10011110"); --9E
		-- --------------------
		WAIT FOR 100 ns; -- Time=8000 ns
		in1 <= transport std_logic_vector'("01010000"); --50
		in2 <= transport std_logic_vector'("10100000"); --A0
		-- --------------------
		WAIT FOR 100 ns; -- Time=8100 ns
		in1 <= transport std_logic_vector'("01010001"); --51
		in2 <= transport std_logic_vector'("10100010"); --A2
		-- --------------------
		WAIT FOR 100 ns; -- Time=8200 ns
		in1 <= transport std_logic_vector'("01010010"); --52
		in2 <= transport std_logic_vector'("10100100"); --A4
		-- --------------------
		WAIT FOR 100 ns; -- Time=8300 ns
		in1 <= transport std_logic_vector'("01010011"); --53
		in2 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 100 ns; -- Time=8400 ns
		in1 <= transport std_logic_vector'("01010100"); --54
		in2 <= transport std_logic_vector'("10101000"); --A8
		-- --------------------
		WAIT FOR 100 ns; -- Time=8500 ns
		in1 <= transport std_logic_vector'("01010101"); --55
		in2 <= transport std_logic_vector'("10101010"); --AA
		-- --------------------
		WAIT FOR 100 ns; -- Time=8600 ns
		in1 <= transport std_logic_vector'("01010110"); --56
		in2 <= transport std_logic_vector'("10101100"); --AC
		-- --------------------
		WAIT FOR 100 ns; -- Time=8700 ns
		in1 <= transport std_logic_vector'("01010111"); --57
		in2 <= transport std_logic_vector'("10101110"); --AE
		-- --------------------
		WAIT FOR 100 ns; -- Time=8800 ns
		in1 <= transport std_logic_vector'("01011000"); --58
		in2 <= transport std_logic_vector'("10110000"); --B0
		-- --------------------
		WAIT FOR 100 ns; -- Time=8900 ns
		in1 <= transport std_logic_vector'("01011001"); --59
		in2 <= transport std_logic_vector'("10110010"); --B2
		-- --------------------
		WAIT FOR 100 ns; -- Time=9000 ns
		in1 <= transport std_logic_vector'("01011010"); --5A
		in2 <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 100 ns; -- Time=9100 ns
		in1 <= transport std_logic_vector'("01011011"); --5B
		in2 <= transport std_logic_vector'("10110110"); --B6
		-- --------------------
		WAIT FOR 100 ns; -- Time=9200 ns
		in1 <= transport std_logic_vector'("01011100"); --5C
		in2 <= transport std_logic_vector'("10111000"); --B8
		-- --------------------
		WAIT FOR 100 ns; -- Time=9300 ns
		in1 <= transport std_logic_vector'("01011101"); --5D
		in2 <= transport std_logic_vector'("10111010"); --BA
		-- --------------------
		WAIT FOR 100 ns; -- Time=9400 ns
		in1 <= transport std_logic_vector'("01011110"); --5E
		in2 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 100 ns; -- Time=9500 ns
		in1 <= transport std_logic_vector'("01011111"); --5F
		in2 <= transport std_logic_vector'("10111110"); --BE
		-- --------------------
		WAIT FOR 100 ns; -- Time=9600 ns
		in1 <= transport std_logic_vector'("01100000"); --60
		in2 <= transport std_logic_vector'("11000000"); --C0
		-- --------------------
		WAIT FOR 100 ns; -- Time=9700 ns
		in1 <= transport std_logic_vector'("01100001"); --61
		in2 <= transport std_logic_vector'("11000010"); --C2
		-- --------------------
		WAIT FOR 100 ns; -- Time=9800 ns
		in1 <= transport std_logic_vector'("01100010"); --62
		in2 <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 100 ns; -- Time=9900 ns
		in1 <= transport std_logic_vector'("01100011"); --63
		in2 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 100 ns; -- Time=10000 ns
		in1 <= transport std_logic_vector'("01100100"); --64
		in2 <= transport std_logic_vector'("11001000"); --C8
		-- --------------------
		WAIT FOR 100 ns; -- Time=10100 ns
		in1 <= transport std_logic_vector'("01100101"); --65
		in2 <= transport std_logic_vector'("11001010"); --CA
		-- --------------------
		WAIT FOR 100 ns; -- Time=10200 ns
		in1 <= transport std_logic_vector'("01100110"); --66
		in2 <= transport std_logic_vector'("11001100"); --CC
		-- --------------------
		WAIT FOR 100 ns; -- Time=10300 ns
		in1 <= transport std_logic_vector'("01100111"); --67
		in2 <= transport std_logic_vector'("11001110"); --CE
		-- --------------------
		WAIT FOR 100 ns; -- Time=10400 ns
		in1 <= transport std_logic_vector'("01101000"); --68
		in2 <= transport std_logic_vector'("11010000"); --D0
		-- --------------------
		WAIT FOR 100 ns; -- Time=10500 ns
		in1 <= transport std_logic_vector'("01101001"); --69
		in2 <= transport std_logic_vector'("11010010"); --D2
		-- --------------------
		WAIT FOR 100 ns; -- Time=10600 ns
		in1 <= transport std_logic_vector'("01101010"); --6A
		in2 <= transport std_logic_vector'("11010100"); --D4
		-- --------------------
		WAIT FOR 100 ns; -- Time=10700 ns
		in1 <= transport std_logic_vector'("01101011"); --6B
		in2 <= transport std_logic_vector'("11010110"); --D6
		-- --------------------
		WAIT FOR 100 ns; -- Time=10800 ns
		in1 <= transport std_logic_vector'("01101100"); --6C
		in2 <= transport std_logic_vector'("11011000"); --D8
		-- --------------------
		WAIT FOR 100 ns; -- Time=10900 ns
		in1 <= transport std_logic_vector'("01101101"); --6D
		in2 <= transport std_logic_vector'("11011010"); --DA
		-- --------------------
		WAIT FOR 100 ns; -- Time=11000 ns
		in1 <= transport std_logic_vector'("01101110"); --6E
		in2 <= transport std_logic_vector'("11011100"); --DC
		-- --------------------
		WAIT FOR 100 ns; -- Time=11100 ns
		in1 <= transport std_logic_vector'("01101111"); --6F
		in2 <= transport std_logic_vector'("11011110"); --DE
		-- --------------------
		WAIT FOR 100 ns; -- Time=11200 ns
		in1 <= transport std_logic_vector'("01110000"); --70
		in2 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 100 ns; -- Time=11300 ns
		in1 <= transport std_logic_vector'("01110001"); --71
		in2 <= transport std_logic_vector'("11100010"); --E2
		-- --------------------
		WAIT FOR 100 ns; -- Time=11400 ns
		in1 <= transport std_logic_vector'("01110010"); --72
		in2 <= transport std_logic_vector'("11100100"); --E4
		-- --------------------
		WAIT FOR 100 ns; -- Time=11500 ns
		in1 <= transport std_logic_vector'("01110011"); --73
		in2 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 100 ns; -- Time=11600 ns
		in1 <= transport std_logic_vector'("01110100"); --74
		in2 <= transport std_logic_vector'("11101000"); --E8
		-- --------------------
		WAIT FOR 100 ns; -- Time=11700 ns
		in1 <= transport std_logic_vector'("01110101"); --75
		in2 <= transport std_logic_vector'("11101010"); --EA
		-- --------------------
		WAIT FOR 100 ns; -- Time=11800 ns
		in1 <= transport std_logic_vector'("01110110"); --76
		in2 <= transport std_logic_vector'("11101100"); --EC
		-- --------------------
		WAIT FOR 100 ns; -- Time=11900 ns
		in1 <= transport std_logic_vector'("01110111"); --77
		in2 <= transport std_logic_vector'("11101110"); --EE
		-- --------------------
		WAIT FOR 100 ns; -- Time=12000 ns
		in1 <= transport std_logic_vector'("01111000"); --78
		in2 <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 100 ns; -- Time=12100 ns
		in1 <= transport std_logic_vector'("01111001"); --79
		in2 <= transport std_logic_vector'("11110010"); --F2
		-- --------------------
		WAIT FOR 100 ns; -- Time=12200 ns
		in1 <= transport std_logic_vector'("01111010"); --7A
		in2 <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 100 ns; -- Time=12300 ns
		in1 <= transport std_logic_vector'("01111011"); --7B
		in2 <= transport std_logic_vector'("11110110"); --F6
		-- --------------------
		WAIT FOR 100 ns; -- Time=12400 ns
		in1 <= transport std_logic_vector'("01111100"); --7C
		in2 <= transport std_logic_vector'("11111000"); --F8
		-- --------------------
		WAIT FOR 100 ns; -- Time=12500 ns
		in1 <= transport std_logic_vector'("01111101"); --7D
		in2 <= transport std_logic_vector'("11111010"); --FA
		-- --------------------
		WAIT FOR 100 ns; -- Time=12600 ns
		in1 <= transport std_logic_vector'("01111110"); --7E
		in2 <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 100 ns; -- Time=12700 ns
		in1 <= transport std_logic_vector'("01111111"); --7F
		in2 <= transport std_logic_vector'("11111110"); --FE
		-- --------------------
		WAIT FOR 100 ns; -- Time=12800 ns
		in1 <= transport std_logic_vector'("10000000"); --80
		in2 <= transport std_logic_vector'("00000000"); --0
		-- --------------------
		WAIT FOR 100 ns; -- Time=12900 ns
		in1 <= transport std_logic_vector'("10000001"); --81
		in2 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 100 ns; -- Time=13000 ns
		in1 <= transport std_logic_vector'("10000010"); --82
		in2 <= transport std_logic_vector'("00000100"); --4
		-- --------------------
		WAIT FOR 100 ns; -- Time=13100 ns
		in1 <= transport std_logic_vector'("10000011"); --83
		in2 <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 100 ns; -- Time=13200 ns
		in1 <= transport std_logic_vector'("10000100"); --84
		in2 <= transport std_logic_vector'("00001000"); --8
		-- --------------------
		WAIT FOR 100 ns; -- Time=13300 ns
		in1 <= transport std_logic_vector'("10000101"); --85
		in2 <= transport std_logic_vector'("00001010"); --A
		-- --------------------
		WAIT FOR 100 ns; -- Time=13400 ns
		in1 <= transport std_logic_vector'("10000110"); --86
		in2 <= transport std_logic_vector'("00001100"); --C
		-- --------------------
		WAIT FOR 100 ns; -- Time=13500 ns
		in1 <= transport std_logic_vector'("10000111"); --87
		in2 <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 100 ns; -- Time=13600 ns
		in1 <= transport std_logic_vector'("10001000"); --88
		in2 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 100 ns; -- Time=13700 ns
		in1 <= transport std_logic_vector'("10001001"); --89
		in2 <= transport std_logic_vector'("00010010"); --12
		-- --------------------
		WAIT FOR 100 ns; -- Time=13800 ns
		in1 <= transport std_logic_vector'("10001010"); --8A
		in2 <= transport std_logic_vector'("00010100"); --14
		-- --------------------
		WAIT FOR 100 ns; -- Time=13900 ns
		in1 <= transport std_logic_vector'("10001011"); --8B
		in2 <= transport std_logic_vector'("00010110"); --16
		-- --------------------
		WAIT FOR 100 ns; -- Time=14000 ns
		in1 <= transport std_logic_vector'("10001100"); --8C
		in2 <= transport std_logic_vector'("00011000"); --18
		-- --------------------
		WAIT FOR 100 ns; -- Time=14100 ns
		in1 <= transport std_logic_vector'("10001101"); --8D
		in2 <= transport std_logic_vector'("00011010"); --1A
		-- --------------------
		WAIT FOR 100 ns; -- Time=14200 ns
		in1 <= transport std_logic_vector'("10001110"); --8E
		in2 <= transport std_logic_vector'("00011100"); --1C
		-- --------------------
		WAIT FOR 100 ns; -- Time=14300 ns
		in1 <= transport std_logic_vector'("10001111"); --8F
		in2 <= transport std_logic_vector'("00011110"); --1E
		-- --------------------
		WAIT FOR 100 ns; -- Time=14400 ns
		in1 <= transport std_logic_vector'("10010000"); --90
		in2 <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 100 ns; -- Time=14500 ns
		in1 <= transport std_logic_vector'("10010001"); --91
		in2 <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 100 ns; -- Time=14600 ns
		in1 <= transport std_logic_vector'("10010010"); --92
		in2 <= transport std_logic_vector'("00100100"); --24
		-- --------------------
		WAIT FOR 100 ns; -- Time=14700 ns
		in1 <= transport std_logic_vector'("10010011"); --93
		in2 <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 100 ns; -- Time=14800 ns
		in1 <= transport std_logic_vector'("10010100"); --94
		in2 <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 100 ns; -- Time=14900 ns
		in1 <= transport std_logic_vector'("10010101"); --95
		in2 <= transport std_logic_vector'("00101010"); --2A
		-- --------------------
		WAIT FOR 100 ns; -- Time=15000 ns
		in1 <= transport std_logic_vector'("10010110"); --96
		in2 <= transport std_logic_vector'("00101100"); --2C
		-- --------------------
		WAIT FOR 100 ns; -- Time=15100 ns
		in1 <= transport std_logic_vector'("10010111"); --97
		in2 <= transport std_logic_vector'("00101110"); --2E
		-- --------------------
		WAIT FOR 100 ns; -- Time=15200 ns
		in1 <= transport std_logic_vector'("10011000"); --98
		in2 <= transport std_logic_vector'("00110000"); --30
		-- --------------------
		WAIT FOR 100 ns; -- Time=15300 ns
		in1 <= transport std_logic_vector'("10011001"); --99
		in2 <= transport std_logic_vector'("00110010"); --32
		-- --------------------
		WAIT FOR 100 ns; -- Time=15400 ns
		in1 <= transport std_logic_vector'("10011010"); --9A
		in2 <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 100 ns; -- Time=15500 ns
		in1 <= transport std_logic_vector'("10011011"); --9B
		in2 <= transport std_logic_vector'("00110110"); --36
		-- --------------------
		WAIT FOR 100 ns; -- Time=15600 ns
		in1 <= transport std_logic_vector'("10011100"); --9C
		in2 <= transport std_logic_vector'("00111000"); --38
		-- --------------------
		WAIT FOR 100 ns; -- Time=15700 ns
		in1 <= transport std_logic_vector'("10011101"); --9D
		in2 <= transport std_logic_vector'("00111010"); --3A
		-- --------------------
		WAIT FOR 100 ns; -- Time=15800 ns
		in1 <= transport std_logic_vector'("10011110"); --9E
		in2 <= transport std_logic_vector'("00111100"); --3C
		-- --------------------
		WAIT FOR 100 ns; -- Time=15900 ns
		in1 <= transport std_logic_vector'("10011111"); --9F
		in2 <= transport std_logic_vector'("00111110"); --3E
		-- --------------------
		WAIT FOR 100 ns; -- Time=16000 ns
		in1 <= transport std_logic_vector'("10100000"); --A0
		in2 <= transport std_logic_vector'("01000000"); --40
		-- --------------------
		WAIT FOR 100 ns; -- Time=16100 ns
		in1 <= transport std_logic_vector'("10100001"); --A1
		in2 <= transport std_logic_vector'("01000010"); --42
		-- --------------------
		WAIT FOR 100 ns; -- Time=16200 ns
		in1 <= transport std_logic_vector'("10100010"); --A2
		in2 <= transport std_logic_vector'("01000100"); --44
		-- --------------------
		WAIT FOR 100 ns; -- Time=16300 ns
		in1 <= transport std_logic_vector'("10100011"); --A3
		in2 <= transport std_logic_vector'("01000110"); --46
		-- --------------------
		WAIT FOR 100 ns; -- Time=16400 ns
		in1 <= transport std_logic_vector'("10100100"); --A4
		in2 <= transport std_logic_vector'("01001000"); --48
		-- --------------------
		WAIT FOR 100 ns; -- Time=16500 ns
		in1 <= transport std_logic_vector'("10100101"); --A5
		in2 <= transport std_logic_vector'("01001010"); --4A
		-- --------------------
		WAIT FOR 100 ns; -- Time=16600 ns
		in1 <= transport std_logic_vector'("10100110"); --A6
		in2 <= transport std_logic_vector'("01001100"); --4C
		-- --------------------
		WAIT FOR 100 ns; -- Time=16700 ns
		in1 <= transport std_logic_vector'("10100111"); --A7
		in2 <= transport std_logic_vector'("01001110"); --4E
		-- --------------------
		WAIT FOR 100 ns; -- Time=16800 ns
		in1 <= transport std_logic_vector'("10101000"); --A8
		in2 <= transport std_logic_vector'("01010000"); --50
		-- --------------------
		WAIT FOR 100 ns; -- Time=16900 ns
		in1 <= transport std_logic_vector'("10101001"); --A9
		in2 <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 100 ns; -- Time=17000 ns
		in1 <= transport std_logic_vector'("10101010"); --AA
		in2 <= transport std_logic_vector'("01010100"); --54
		-- --------------------
		WAIT FOR 100 ns; -- Time=17100 ns
		in1 <= transport std_logic_vector'("10101011"); --AB
		in2 <= transport std_logic_vector'("01010110"); --56
		-- --------------------
		WAIT FOR 100 ns; -- Time=17200 ns
		in1 <= transport std_logic_vector'("10101100"); --AC
		in2 <= transport std_logic_vector'("01011000"); --58
		-- --------------------
		WAIT FOR 100 ns; -- Time=17300 ns
		in1 <= transport std_logic_vector'("10101101"); --AD
		in2 <= transport std_logic_vector'("01011010"); --5A
		-- --------------------
		WAIT FOR 100 ns; -- Time=17400 ns
		in1 <= transport std_logic_vector'("10101110"); --AE
		in2 <= transport std_logic_vector'("01011100"); --5C
		-- --------------------
		WAIT FOR 100 ns; -- Time=17500 ns
		in1 <= transport std_logic_vector'("10101111"); --AF
		in2 <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 100 ns; -- Time=17600 ns
		in1 <= transport std_logic_vector'("10110000"); --B0
		in2 <= transport std_logic_vector'("01100000"); --60
		-- --------------------
		WAIT FOR 100 ns; -- Time=17700 ns
		in1 <= transport std_logic_vector'("10110001"); --B1
		in2 <= transport std_logic_vector'("01100010"); --62
		-- --------------------
		WAIT FOR 100 ns; -- Time=17800 ns
		in1 <= transport std_logic_vector'("10110010"); --B2
		in2 <= transport std_logic_vector'("01100100"); --64
		-- --------------------
		WAIT FOR 100 ns; -- Time=17900 ns
		in1 <= transport std_logic_vector'("10110011"); --B3
		in2 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 100 ns; -- Time=18000 ns
		in1 <= transport std_logic_vector'("10110100"); --B4
		in2 <= transport std_logic_vector'("01101000"); --68
		-- --------------------
		WAIT FOR 100 ns; -- Time=18100 ns
		in1 <= transport std_logic_vector'("10110101"); --B5
		in2 <= transport std_logic_vector'("01101010"); --6A
		-- --------------------
		WAIT FOR 100 ns; -- Time=18200 ns
		in1 <= transport std_logic_vector'("10110110"); --B6
		in2 <= transport std_logic_vector'("01101100"); --6C
		-- --------------------
		WAIT FOR 100 ns; -- Time=18300 ns
		in1 <= transport std_logic_vector'("10110111"); --B7
		in2 <= transport std_logic_vector'("01101110"); --6E
		-- --------------------
		WAIT FOR 100 ns; -- Time=18400 ns
		in1 <= transport std_logic_vector'("10111000"); --B8
		in2 <= transport std_logic_vector'("01110000"); --70
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=18500 ns
		in1 <= transport std_logic_vector'("10111001"); --B9
		in2 <= transport std_logic_vector'("01110010"); --72
		-- --------------------
		WAIT FOR 100 ns; -- Time=18600 ns
		in1 <= transport std_logic_vector'("10111010"); --BA
		in2 <= transport std_logic_vector'("01110100"); --74
		-- --------------------
		WAIT FOR 100 ns; -- Time=18700 ns
		in1 <= transport std_logic_vector'("10111011"); --BB
		in2 <= transport std_logic_vector'("01110110"); --76
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=18800 ns
		in1 <= transport std_logic_vector'("10111100"); --BC
		in2 <= transport std_logic_vector'("01111000"); --78
		-- --------------------
		WAIT FOR 100 ns; -- Time=18900 ns
		in1 <= transport std_logic_vector'("10111101"); --BD
		in2 <= transport std_logic_vector'("01111010"); --7A
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=19000 ns
		in1 <= transport std_logic_vector'("10111110"); --BE
		in2 <= transport std_logic_vector'("01111100"); --7C
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=19100 ns
		in1 <= transport std_logic_vector'("10111111"); --BF
		in2 <= transport std_logic_vector'("01111110"); --7E
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=19200 ns
		in1 <= transport std_logic_vector'("11000000"); --C0
		in2 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 100 ns; -- Time=19300 ns
		in1 <= transport std_logic_vector'("11000001"); --C1
		in2 <= transport std_logic_vector'("10000010"); --82
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=19400 ns
		in1 <= transport std_logic_vector'("11000010"); --C2
		in2 <= transport std_logic_vector'("10000100"); --84
		-- --------------------
		WAIT FOR 100 ns; -- Time=19500 ns
		in1 <= transport std_logic_vector'("11000011"); --C3
		in2 <= transport std_logic_vector'("10000110"); --86
		en <= transport '1';
		-- --------------------
		WAIT FOR 100 ns; -- Time=19600 ns
		in1 <= transport std_logic_vector'("11000100"); --C4
		in2 <= transport std_logic_vector'("10001000"); --88
		-- --------------------
		WAIT FOR 100 ns; -- Time=19700 ns
		in1 <= transport std_logic_vector'("11000101"); --C5
		in2 <= transport std_logic_vector'("10001010"); --8A
		en <= transport '0';
		-- --------------------
		WAIT FOR 100 ns; -- Time=19800 ns
		in1 <= transport std_logic_vector'("11000110"); --C6
		in2 <= transport std_logic_vector'("10001100"); --8C
		-- --------------------
		WAIT FOR 100 ns; -- Time=19900 ns
		in1 <= transport std_logic_vector'("11000111"); --C7
		in2 <= transport std_logic_vector'("10001110"); --8E
		-- --------------------
		WAIT FOR 100 ns; -- Time=20000 ns
		in1 <= transport std_logic_vector'("11001000"); --C8
		in2 <= transport std_logic_vector'("10010000"); --90
		-- --------------------
		WAIT FOR 100 ns; -- Time=20100 ns
		in1 <= transport std_logic_vector'("11001001"); --C9
		in2 <= transport std_logic_vector'("10010010"); --92
		-- --------------------
		WAIT FOR 100 ns; -- Time=20200 ns
		in1 <= transport std_logic_vector'("11001010"); --CA
		in2 <= transport std_logic_vector'("10010100"); --94
		-- --------------------
		WAIT FOR 100 ns; -- Time=20300 ns
		in1 <= transport std_logic_vector'("11001011"); --CB
		in2 <= transport std_logic_vector'("10010110"); --96
		-- --------------------
		WAIT FOR 100 ns; -- Time=20400 ns
		in1 <= transport std_logic_vector'("11001100"); --CC
		in2 <= transport std_logic_vector'("10011000"); --98
		-- --------------------
		WAIT FOR 100 ns; -- Time=20500 ns
		in1 <= transport std_logic_vector'("11001101"); --CD
		in2 <= transport std_logic_vector'("10011010"); --9A
		-- --------------------
		WAIT FOR 100 ns; -- Time=20600 ns
		in1 <= transport std_logic_vector'("11001110"); --CE
		in2 <= transport std_logic_vector'("10011100"); --9C
		-- --------------------
		WAIT FOR 100 ns; -- Time=20700 ns
		in1 <= transport std_logic_vector'("11001111"); --CF
		in2 <= transport std_logic_vector'("10011110"); --9E
		-- --------------------
		WAIT FOR 100 ns; -- Time=20800 ns
		in1 <= transport std_logic_vector'("11010000"); --D0
		in2 <= transport std_logic_vector'("10100000"); --A0
		-- --------------------
		WAIT FOR 100 ns; -- Time=20900 ns
		in1 <= transport std_logic_vector'("11010001"); --D1
		in2 <= transport std_logic_vector'("10100010"); --A2
		-- --------------------
		WAIT FOR 100 ns; -- Time=21000 ns
		in1 <= transport std_logic_vector'("11010010"); --D2
		in2 <= transport std_logic_vector'("10100100"); --A4
		-- --------------------
		WAIT FOR 100 ns; -- Time=21100 ns
		in1 <= transport std_logic_vector'("11010011"); --D3
		in2 <= transport std_logic_vector'("10100110"); --A6
		-- --------------------
		WAIT FOR 100 ns; -- Time=21200 ns
		in1 <= transport std_logic_vector'("11010100"); --D4
		in2 <= transport std_logic_vector'("10101000"); --A8
		-- --------------------
		WAIT FOR 100 ns; -- Time=21300 ns
		in1 <= transport std_logic_vector'("11010101"); --D5
		in2 <= transport std_logic_vector'("10101010"); --AA
		-- --------------------
		WAIT FOR 100 ns; -- Time=21400 ns
		in1 <= transport std_logic_vector'("11010110"); --D6
		in2 <= transport std_logic_vector'("10101100"); --AC
		-- --------------------
		WAIT FOR 100 ns; -- Time=21500 ns
		in1 <= transport std_logic_vector'("11010111"); --D7
		in2 <= transport std_logic_vector'("10101110"); --AE
		-- --------------------
		WAIT FOR 100 ns; -- Time=21600 ns
		in1 <= transport std_logic_vector'("11011000"); --D8
		in2 <= transport std_logic_vector'("10110000"); --B0
		-- --------------------
		WAIT FOR 100 ns; -- Time=21700 ns
		in1 <= transport std_logic_vector'("11011001"); --D9
		in2 <= transport std_logic_vector'("10110010"); --B2
		-- --------------------
		WAIT FOR 100 ns; -- Time=21800 ns
		in1 <= transport std_logic_vector'("11011010"); --DA
		in2 <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 100 ns; -- Time=21900 ns
		in1 <= transport std_logic_vector'("11011011"); --DB
		in2 <= transport std_logic_vector'("10110110"); --B6
		-- --------------------
		WAIT FOR 100 ns; -- Time=22000 ns
		in1 <= transport std_logic_vector'("11011100"); --DC
		in2 <= transport std_logic_vector'("10111000"); --B8
		-- --------------------
		WAIT FOR 100 ns; -- Time=22100 ns
		in1 <= transport std_logic_vector'("11011101"); --DD
		in2 <= transport std_logic_vector'("10111010"); --BA
		-- --------------------
		WAIT FOR 100 ns; -- Time=22200 ns
		in1 <= transport std_logic_vector'("11011110"); --DE
		in2 <= transport std_logic_vector'("10111100"); --BC
		-- --------------------
		WAIT FOR 100 ns; -- Time=22300 ns
		in1 <= transport std_logic_vector'("11011111"); --DF
		in2 <= transport std_logic_vector'("10111110"); --BE
		-- --------------------
		WAIT FOR 100 ns; -- Time=22400 ns
		in1 <= transport std_logic_vector'("11100000"); --E0
		in2 <= transport std_logic_vector'("11000000"); --C0
		-- --------------------
		WAIT FOR 100 ns; -- Time=22500 ns
		in1 <= transport std_logic_vector'("11100001"); --E1
		in2 <= transport std_logic_vector'("11000010"); --C2
		-- --------------------
		WAIT FOR 100 ns; -- Time=22600 ns
		in1 <= transport std_logic_vector'("11100010"); --E2
		in2 <= transport std_logic_vector'("11000100"); --C4
		-- --------------------
		WAIT FOR 100 ns; -- Time=22700 ns
		in1 <= transport std_logic_vector'("11100011"); --E3
		in2 <= transport std_logic_vector'("11000110"); --C6
		-- --------------------
		WAIT FOR 100 ns; -- Time=22800 ns
		in1 <= transport std_logic_vector'("11100100"); --E4
		in2 <= transport std_logic_vector'("11001000"); --C8
		-- --------------------
		WAIT FOR 100 ns; -- Time=22900 ns
		in1 <= transport std_logic_vector'("11100101"); --E5
		in2 <= transport std_logic_vector'("11001010"); --CA
		-- --------------------
		WAIT FOR 100 ns; -- Time=23000 ns
		in1 <= transport std_logic_vector'("11100110"); --E6
		in2 <= transport std_logic_vector'("11001100"); --CC
		-- --------------------
		WAIT FOR 100 ns; -- Time=23100 ns
		in1 <= transport std_logic_vector'("11100111"); --E7
		in2 <= transport std_logic_vector'("11001110"); --CE
		-- --------------------
		WAIT FOR 100 ns; -- Time=23200 ns
		in1 <= transport std_logic_vector'("11101000"); --E8
		in2 <= transport std_logic_vector'("11010000"); --D0
		-- --------------------
		WAIT FOR 100 ns; -- Time=23300 ns
		in1 <= transport std_logic_vector'("11101001"); --E9
		in2 <= transport std_logic_vector'("11010010"); --D2
		-- --------------------
		WAIT FOR 100 ns; -- Time=23400 ns
		in1 <= transport std_logic_vector'("11101010"); --EA
		in2 <= transport std_logic_vector'("11010100"); --D4
		-- --------------------
		WAIT FOR 100 ns; -- Time=23500 ns
		in1 <= transport std_logic_vector'("11101011"); --EB
		in2 <= transport std_logic_vector'("11010110"); --D6
		-- --------------------
		WAIT FOR 100 ns; -- Time=23600 ns
		in1 <= transport std_logic_vector'("11101100"); --EC
		in2 <= transport std_logic_vector'("11011000"); --D8
		-- --------------------
		WAIT FOR 100 ns; -- Time=23700 ns
		in1 <= transport std_logic_vector'("11101101"); --ED
		in2 <= transport std_logic_vector'("11011010"); --DA
		-- --------------------
		WAIT FOR 100 ns; -- Time=23800 ns
		in1 <= transport std_logic_vector'("11101110"); --EE
		in2 <= transport std_logic_vector'("11011100"); --DC
		-- --------------------
		WAIT FOR 100 ns; -- Time=23900 ns
		in1 <= transport std_logic_vector'("11101111"); --EF
		in2 <= transport std_logic_vector'("11011110"); --DE
		-- --------------------
		WAIT FOR 100 ns; -- Time=24000 ns
		in1 <= transport std_logic_vector'("11110000"); --F0
		in2 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 100 ns; -- Time=24100 ns
		in1 <= transport std_logic_vector'("11110001"); --F1
		in2 <= transport std_logic_vector'("11100010"); --E2
		-- --------------------
		WAIT FOR 100 ns; -- Time=24200 ns
		in1 <= transport std_logic_vector'("11110010"); --F2
		in2 <= transport std_logic_vector'("11100100"); --E4
		-- --------------------
		WAIT FOR 100 ns; -- Time=24300 ns
		in1 <= transport std_logic_vector'("11110011"); --F3
		in2 <= transport std_logic_vector'("11100110"); --E6
		-- --------------------
		WAIT FOR 100 ns; -- Time=24400 ns
		in1 <= transport std_logic_vector'("11110100"); --F4
		in2 <= transport std_logic_vector'("11101000"); --E8
		-- --------------------
		WAIT FOR 100 ns; -- Time=24500 ns
		in1 <= transport std_logic_vector'("11110101"); --F5
		in2 <= transport std_logic_vector'("11101010"); --EA
		-- --------------------
		WAIT FOR 100 ns; -- Time=24600 ns
		in1 <= transport std_logic_vector'("11110110"); --F6
		in2 <= transport std_logic_vector'("11101100"); --EC
		-- --------------------
		WAIT FOR 100 ns; -- Time=24700 ns
		in1 <= transport std_logic_vector'("11110111"); --F7
		in2 <= transport std_logic_vector'("11101110"); --EE
		-- --------------------
		WAIT FOR 100 ns; -- Time=24800 ns
		in1 <= transport std_logic_vector'("11111000"); --F8
		in2 <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 100 ns; -- Time=24900 ns
		in1 <= transport std_logic_vector'("11111001"); --F9
		in2 <= transport std_logic_vector'("11110010"); --F2
		-- --------------------
		WAIT FOR 100 ns; -- Time=25000 ns
		in1 <= transport std_logic_vector'("11111010"); --FA
		in2 <= transport std_logic_vector'("11110100"); --F4
		-- --------------------
		WAIT FOR 100 ns; -- Time=25100 ns
		in1 <= transport std_logic_vector'("11111011"); --FB
		in2 <= transport std_logic_vector'("11110110"); --F6
		-- --------------------
		WAIT FOR 100 ns; -- Time=25200 ns
		in1 <= transport std_logic_vector'("11111100"); --FC
		in2 <= transport std_logic_vector'("11111000"); --F8
		-- --------------------
		WAIT FOR 100 ns; -- Time=25300 ns
		in1 <= transport std_logic_vector'("11111101"); --FD
		in2 <= transport std_logic_vector'("11111010"); --FA
		-- --------------------
		WAIT FOR 100 ns; -- Time=25400 ns
		in1 <= transport std_logic_vector'("11111110"); --FE
		in2 <= transport std_logic_vector'("11111100"); --FC
		-- --------------------
		WAIT FOR 150 ns; -- Time=25550 ns
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION latch_cfg OF latch_tb IS
	FOR testbench_arch
	END FOR;
END latch_cfg;
