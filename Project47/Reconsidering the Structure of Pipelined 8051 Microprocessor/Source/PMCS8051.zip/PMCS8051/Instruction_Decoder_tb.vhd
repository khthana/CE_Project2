library ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY D_Instruction_Decoder_tb IS
END D_Instruction_Decoder_tb;

ARCHITECTURE RTL OF D_Instruction_Decoder_tb IS 

	COMPONENT D_Instruction_Decoder
	PORT( clock			: in	std_logic;
			reset			: in	std_logic;
			inst_byte1	: in	std_logic_vector(7 downto 0);-- from	Inst. Byte 1
         s1 			: out std_logic_vector(7 downto 0);-- to	S1
         s2 			: out std_logic_vector(7 downto 0);-- to	S2
         d1 			: out std_logic_vector(7 downto 0);-- to	D1
         d2 			: out std_logic_vector(7 downto 0);-- to	D2
		 	alu_oprt 	: out std_logic_vector(3 downto 0);-- to	ALU_Operation
			sel_mux6		: out std_logic_vector(1 downto 0);-- to sel mux6
			sel_mux7		: out std_logic_vector(2 downto 0);-- to sel mux7
			sel_mux8		: out std_logic_vector(1 downto 0);-- to sel mux8
			sel_mux9		: out std_logic_vector(2 downto 0);-- to sel mux9
			from_mux6	: in	std_logic_vector(7 downto 0)
			);
	END COMPONENT;

	signal clock			: std_logic:='1';
	signal reset			: std_logic;
	signal inst_byte1		: std_logic_vector(7 downto 0);-- from	Inst. Byte 1
   signal s1 				: std_logic_vector(7 downto 0);-- to	S1
   signal s2 				: std_logic_vector(7 downto 0);-- to	S2
   signal d1 				: std_logic_vector(7 downto 0);-- to	D1
   signal d2 				: std_logic_vector(7 downto 0);-- to	D2
	signal alu_oprt 		: std_logic_vector(3 downto 0);-- to	ALU_Operation
	signal sel_mux6		: std_logic_vector(1 downto 0);-- to sel mux6
	signal sel_mux7		: std_logic_vector(2 downto 0);-- to sel mux7
	signal sel_mux8		: std_logic_vector(1 downto 0);-- to sel mux8
	signal sel_mux9		: std_logic_vector(2 downto 0);-- to sel mux9
	signal from_mux6		: std_logic_vector(7 downto 0);-- addr from mux6
	
BEGIN
	uut: D_Instruction_Decoder
	port map
		(	clock			=> clock,
			reset			=> reset,
			inst_byte1	=> inst_byte1,
			s1				=>	s1,
			s2				=>	s2,
			d1				=>	d1,
			d2				=>	d2,
			alu_oprt		=> alu_oprt,
			sel_mux6		=> sel_mux6,
			sel_mux7		=> sel_mux7,
			sel_mux8		=> sel_mux8,
			sel_mux9		=> sel_mux9,
			from_mux6	=> from_mux6);



		clock <= not clock after 5 ns;

	
	         	
--          		"00111011" after 50 ns,  	
--          		"10010000" after 60 ns,  	
--						"00000000" after 70 ns,         	
--          		"00000000" after 80 ns,         	
--         			"00010001" after 90 ns,        
--          		"10010000" after 100 ns,    
--         			"00100000" after 110 ns,     
--          		"10010000" after 120 ns,      
--          		"10010000" after 130 ns,     
--          		"00000000" after 140 ns,     
--          		"00000000" after 150 ns;   

	

-- *** Test Bench - User Defined Section ***
   tb : PROCESS
   BEGIN
		

		reset <=	'1',
				'0' after 10 ns,
				'1' after 55 ns,
				'0' after 65 ns;

		inst_byte1 <= 	"ZZZZZZZZ"; wait for 10 ns;
		inst_byte1 <=	"00000000"; wait for 10 ns;
		inst_byte1 <=	"00101000"; wait for 10 ns;         	
   	inst_byte1 <=	"00000000"; wait for 10 ns;         	
		inst_byte1 <=	"00101000"; wait for 10 ns;
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"00101000"; wait for 10 ns;	-- ADD A,Rn
		inst_byte1 <=	"00101001"; wait for 10 ns;
		inst_byte1 <=	"00101010"; wait for 10 ns;
		inst_byte1 <=	"00101011"; wait for 10 ns;
		inst_byte1 <=	"00101100"; wait for 10 ns;
		inst_byte1 <=	"00101101"; wait for 10 ns;
		inst_byte1 <=	"00101110"; wait for 10 ns;
		inst_byte1 <=	"00101111"; wait for 10 ns;
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"00111000"; wait for 10 ns;	-- ADDC A,Rn
		inst_byte1 <=	"00111001"; wait for 10 ns;
		inst_byte1 <=	"00111010"; wait for 10 ns;
		inst_byte1 <=	"00111011"; wait for 10 ns;
		inst_byte1 <=	"00111100"; wait for 10 ns;
		inst_byte1 <=	"00111101"; wait for 10 ns;
		inst_byte1 <=	"00111110"; wait for 10 ns;
		inst_byte1 <=	"00111111"; wait for 10 ns;
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"01011000"; wait for 10 ns;	-- ANL A,Rn
		inst_byte1 <=	"01011001"; wait for 10 ns;
		inst_byte1 <=	"01011010"; wait for 10 ns;
		inst_byte1 <=	"01011011"; wait for 10 ns;
		inst_byte1 <=	"01011100"; wait for 10 ns;
		inst_byte1 <=	"01011101"; wait for 10 ns;
		inst_byte1 <=	"01011110"; wait for 10 ns;
		inst_byte1 <=	"01011111"; wait for 10 ns;
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"01001000"; wait for 10 ns;	-- ORL A,Rn
		inst_byte1 <=	"01001001"; wait for 10 ns;
		inst_byte1 <=	"01001010"; wait for 10 ns;
		inst_byte1 <=	"01001011"; wait for 10 ns;
		inst_byte1 <=	"01001100"; wait for 10 ns;
		inst_byte1 <=	"01001101"; wait for 10 ns;
		inst_byte1 <=	"01001110"; wait for 10 ns;
		inst_byte1 <=	"01001111"; wait for 10 ns;
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		
		inst_byte1 <=	"00100011"; wait for 10 ns;	--	RL	A
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"00110011"; wait for 10 ns;	-- RLC A
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"00000011"; wait for 10 ns;	-- RR A
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		inst_byte1 <=	"00010011"; wait for 10 ns;	-- RRC A
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;

		inst_byte1 <=	"10001000"; wait for 10 ns;	-- SUBB A,Rn
		inst_byte1 <=	"10001001"; wait for 10 ns;
		inst_byte1 <=	"10001010"; wait for 10 ns;
		inst_byte1 <=	"10001011"; wait for 10 ns;
		inst_byte1 <=	"10001100"; wait for 10 ns;
		inst_byte1 <=	"10001101"; wait for 10 ns;
		inst_byte1 <=	"10001110"; wait for 10 ns;
		inst_byte1 <=	"10001111"; wait for 10 ns;
		inst_byte1 <=	"ZZZZZZZZ"; wait for 20 ns;
		
		
		


      wait; -- will wait forever
   END PROCESS;
-- *** End Test Bench - User Defined Section ***
END;