--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 7.1.01i
--  \   \         Application : ISE WebPACK
--  /   /         Filename : que_state_tb.vhw
-- /___/   /\     Timestamp : Sat Apr 09 21:29:28 2005
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: que_state_tb
--Device: Xilinx
--

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY que_state_tb IS
END que_state_tb;

ARCHITECTURE testbench_arch OF que_state_tb IS
    COMPONENT que_state
        PORT (
            in1 : In std_logic_vector (7 DownTo 0);
            out1 : Out std_logic_vector (7 DownTo 0);
            out2 : Out std_logic_vector (7 DownTo 0);
            out3 : Out std_logic_vector (7 DownTo 0);
            reset : In std_logic;
            iqc_out : Out std_logic_vector (1 DownTo 0);
            clock : In std_logic
        );
    END COMPONENT;

    SIGNAL in1 : std_logic_vector (7 DownTo 0) := "01011111";
    SIGNAL out1 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL out2 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL out3 : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL reset : std_logic := '1';
    SIGNAL iqc_out : std_logic_vector (1 DownTo 0) := "00";
    SIGNAL clock : std_logic := '0';

    SHARED VARIABLE TX_ERROR : INTEGER := 0;
    SHARED VARIABLE TX_OUT : LINE;

    constant PERIOD : time := 10000 ps;
    constant DUTY_CYCLE : real := 0.5;
    constant OFFSET : time := 1000 ps;

    BEGIN
        UUT : que_state
        PORT MAP (
            in1 => in1,
            out1 => out1,
            out2 => out2,
            out3 => out3,
            reset => reset,
            iqc_out => iqc_out,
            clock => clock
        );

        PROCESS    -- clock process for clock
        BEGIN
            WAIT for OFFSET;
            CLOCK_LOOP : LOOP
                clock <= '0';
                WAIT FOR (PERIOD - (PERIOD * DUTY_CYCLE));
                clock <= '1';
                WAIT FOR (PERIOD * DUTY_CYCLE);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS
            PROCEDURE CHECK_iqc_out(
                next_iqc_out : std_logic_vector (1 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (iqc_out /= next_iqc_out) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps iqc_out="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, iqc_out);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_iqc_out);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_out1(
                next_out1 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (out1 /= next_out1) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps out1="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out1);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out1);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_out2(
                next_out2 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (out2 /= next_out2) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps out2="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out2);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out2);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_out3(
                next_out3 : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (out3 /= next_out3) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ps out3="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, out3);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_out3);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            BEGIN
                -- -------------  Current Time:  5000ps
                WAIT FOR 5000 ps;
                in1 <= "11001000";
                -- -------------------------------------
                -- -------------  Current Time:  15000ps
                WAIT FOR 10000 ps;
                reset <= '0';
                in1 <= "10010001";
                -- -------------------------------------
                -- -------------  Current Time:  25000ps
                WAIT FOR 10000 ps;
                in1 <= "00011101";
                -- -------------------------------------
                -- -------------  Current Time:  35000ps
                WAIT FOR 10000 ps;
                in1 <= "11101010";
                -- -------------------------------------
                -- -------------  Current Time:  45000ps
                WAIT FOR 10000 ps;
                in1 <= "01110011";
                -- -------------------------------------
                -- -------------  Current Time:  55000ps
                WAIT FOR 10000 ps;
                in1 <= "01110100";
                -- -------------------------------------
                -- -------------  Current Time:  65000ps
                WAIT FOR 10000 ps;
                in1 <= "10101000";
                -- -------------------------------------
                -- -------------  Current Time:  75000ps
                WAIT FOR 10000 ps;
                in1 <= "00111111";
                -- -------------------------------------
                -- -------------  Current Time:  85000ps
                WAIT FOR 10000 ps;
                in1 <= "01100110";
                -- -------------------------------------
                -- -------------  Current Time:  95000ps
                WAIT FOR 10000 ps;
                in1 <= "11001000";
                -- -------------------------------------
                -- -------------  Current Time:  105000ps
                WAIT FOR 10000 ps;
                in1 <= "00011101";
                -- -------------------------------------
                -- -------------  Current Time:  115000ps
                WAIT FOR 10000 ps;
                in1 <= "10000010";
                -- -------------------------------------
                -- -------------  Current Time:  125000ps
                WAIT FOR 10000 ps;
                in1 <= "10000011";
                -- -------------------------------------
                -- -------------  Current Time:  135000ps
                WAIT FOR 10000 ps;
                in1 <= "01011111";
                -- -------------------------------------
                -- -------------  Current Time:  145000ps
                WAIT FOR 10000 ps;
                in1 <= "11001000";
                -- -------------------------------------
                -- -------------  Current Time:  155000ps
                WAIT FOR 10000 ps;
                in1 <= "00100101";
                -- -------------------------------------
                -- -------------  Current Time:  165000ps
                WAIT FOR 10000 ps;
                in1 <= "00111110";
                -- -------------------------------------
                -- -------------  Current Time:  175000ps
                WAIT FOR 10000 ps;
                in1 <= "10101010";
                -- -------------------------------------
                -- -------------  Current Time:  185000ps
                WAIT FOR 10000 ps;
                in1 <= "01100101";
                -- -------------------------------------
                -- -------------  Current Time:  195000ps
                WAIT FOR 10000 ps;
                in1 <= "11110100";
                -- -------------------------------------
                -- -------------  Current Time:  205000ps
                WAIT FOR 10000 ps;
                in1 <= "10101010";
                -- -------------------------------------
                -- -------------  Current Time:  215000ps
                WAIT FOR 10000 ps;
                in1 <= "00001111";
                -- -------------------------------------
                -- -------------  Current Time:  225000ps
                WAIT FOR 10000 ps;
                in1 <= "10010010";
                -- -------------------------------------
                -- -------------  Current Time:  235000ps
                WAIT FOR 10000 ps;
                in1 <= "01001001";
                -- -------------------------------------
                -- -------------  Current Time:  245000ps
                WAIT FOR 10000 ps;
                in1 <= "01011101";
                -- -------------------------------------
                -- -------------  Current Time:  255000ps
                WAIT FOR 10000 ps;
                in1 <= "10010010";
                -- -------------------------------------
                -- -------------  Current Time:  265000ps
                WAIT FOR 10000 ps;
                reset <= '1';
                in1 <= "00000111";
                -- -------------------------------------
                -- -------------  Current Time:  275000ps
                WAIT FOR 10000 ps;
                in1 <= "00111100";
                -- -------------------------------------
                -- -------------  Current Time:  285000ps
                WAIT FOR 10000 ps;
                reset <= '0';
                in1 <= "11111000";
                -- -------------------------------------
                -- -------------  Current Time:  295000ps
                WAIT FOR 10000 ps;
                in1 <= "01100111";
                -- -------------------------------------
                -- -------------  Current Time:  305000ps
                WAIT FOR 10000 ps;
                in1 <= "10111110";
                -- -------------------------------------
                -- -------------  Current Time:  315000ps
                WAIT FOR 10000 ps;
                in1 <= "10111000";
                -- -------------------------------------
                -- -------------  Current Time:  325000ps
                WAIT FOR 10000 ps;
                in1 <= "00000101";
                -- -------------------------------------
                -- -------------  Current Time:  335000ps
                WAIT FOR 10000 ps;
                in1 <= "11010000";
                -- -------------------------------------
                -- -------------  Current Time:  345000ps
                WAIT FOR 10000 ps;
                in1 <= "01011011";
                -- -------------------------------------
                -- -------------  Current Time:  355000ps
                WAIT FOR 10000 ps;
                in1 <= "00001111";
                -- -------------------------------------
                -- -------------  Current Time:  365000ps
                WAIT FOR 10000 ps;
                in1 <= "10010000";
                -- -------------------------------------
                -- -------------  Current Time:  375000ps
                WAIT FOR 10000 ps;
                in1 <= "00011101";
                -- -------------------------------------
                -- -------------  Current Time:  385000ps
                WAIT FOR 10000 ps;
                in1 <= "11101110";
                -- -------------------------------------
                -- -------------  Current Time:  395000ps
                WAIT FOR 10000 ps;
                in1 <= "11110010";
                -- -------------------------------------
                -- -------------  Current Time:  405000ps
                WAIT FOR 10000 ps;
                in1 <= "00100101";
                -- -------------------------------------
                -- -------------  Current Time:  415000ps
                WAIT FOR 10000 ps;
                in1 <= "10101100";
                -- -------------------------------------
                -- -------------  Current Time:  425000ps
                WAIT FOR 10000 ps;
                in1 <= "11111000";
                -- -------------------------------------
                -- -------------  Current Time:  435000ps
                WAIT FOR 10000 ps;
                in1 <= "01100111";
                -- -------------------------------------
                -- -------------  Current Time:  445000ps
                WAIT FOR 10000 ps;
                in1 <= "11001010";
                -- -------------------------------------
                -- -------------  Current Time:  455000ps
                WAIT FOR 10000 ps;
                in1 <= "00011001";
                -- -------------------------------------
                -- -------------  Current Time:  465000ps
                WAIT FOR 10000 ps;
                in1 <= "00000101";
                -- -------------------------------------
                -- -------------  Current Time:  475000ps
                WAIT FOR 10000 ps;
                in1 <= "11000010";
                -- -------------------------------------
                -- -------------  Current Time:  485000ps
                WAIT FOR 10000 ps;
                in1 <= "01011111";
                -- -------------------------------------
                -- -------------  Current Time:  495000ps
                WAIT FOR 10000 ps;
                in1 <= "11000100";
                -- -------------------------------------
                -- -------------  Current Time:  505000ps
                WAIT FOR 10000 ps;
                in1 <= "10100000";
                -- -------------------------------------
                -- -------------  Current Time:  515000ps
                WAIT FOR 10000 ps;
                in1 <= "00111111";
                -- -------------------------------------
                -- -------------  Current Time:  525000ps
                WAIT FOR 10000 ps;
                in1 <= "11101010";
                -- -------------------------------------
                -- -------------  Current Time:  535000ps
                WAIT FOR 10000 ps;
                reset <= '1';
                in1 <= "01100010";
                -- -------------------------------------
                -- -------------  Current Time:  1.415e+006ps
                WAIT FOR 880000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.435e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.455e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01100010";
                -- -------------------------------------
                -- -------------  Current Time:  1.475e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.495e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01100010";
                -- -------------------------------------
                -- -------------  Current Time:  1.515e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.535e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.555e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01100010";
                -- -------------------------------------
                -- -------------  Current Time:  1.575e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.595e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000010";
                -- -------------------------------------
                -- -------------  Current Time:  1.615e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000000";
                -- -------------------------------------
                -- -------------  Current Time:  1.635e+006ps
                WAIT FOR 20000 ps;
                in1 <= "00001000";
                -- -------------------------------------
                -- -------------  Current Time:  1.655e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01111010";
                -- -------------------------------------
                -- -------------  Current Time:  1.675e+006ps
                WAIT FOR 20000 ps;
                in1 <= "00110010";
                -- -------------------------------------
                -- -------------  Current Time:  1.695e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01011100";
                -- -------------------------------------
                -- -------------  Current Time:  1.715e+006ps
                WAIT FOR 20000 ps;
                in1 <= "00100110";
                -- -------------------------------------
                -- -------------  Current Time:  1.735e+006ps
                WAIT FOR 20000 ps;
                in1 <= "10111100";
                -- -------------------------------------
                -- -------------  Current Time:  1.755e+006ps
                WAIT FOR 20000 ps;
                in1 <= "11000110";
                -- -------------------------------------
                -- -------------  Current Time:  1.775e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01101110";
                -- -------------------------------------
                -- -------------  Current Time:  1.795e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01100000";
                -- -------------------------------------
                -- -------------  Current Time:  1.815e+006ps
                WAIT FOR 20000 ps;
                in1 <= "11000110";
                -- -------------------------------------
                -- -------------  Current Time:  1.835e+006ps
                WAIT FOR 20000 ps;
                in1 <= "01000110";
                -- -------------------------------------
                -- -------------  Current Time:  1.855e+006ps
                WAIT FOR 20000 ps;
                in1 <= "00001110";
                -- -------------------------------------
                -- -------------  Current Time:  1.875e+006ps
                WAIT FOR 20000 ps;
                in1 <= "11001000";
                -- -------------------------------------
                -- -------------  Current Time:  1.895e+006ps
                WAIT FOR 20000 ps;
                in1 <= "10011100";
                -- -------------------------------------
                -- -------------  Current Time:  1.915e+006ps
                WAIT FOR 20000 ps;
                in1 <= "00110100";
                -- -------------------------------------
                -- -------------  Current Time:  1.935e+006ps
                WAIT FOR 20000 ps;
                in1 <= "10111010";
                -- -------------------------------------
                -- -------------  Current Time:  1.955e+006ps
                WAIT FOR 20000 ps;
                in1 <= "11011010";
                -- -------------------------------------
                -- -------------  Current Time:  1.975e+006ps
                WAIT FOR 20000 ps;
                in1 <= "10111110";
                -- -------------------------------------
                -- -------------  Current Time:  1.995e+006ps
                WAIT FOR 20000 ps;
                in1 <= "10000000";
                -- -------------------------------------
                -- -------------  Current Time:  2.015e+006ps
                WAIT FOR 20000 ps;
                in1 <= "11011000";
                -- -------------------------------------

                IF (TX_ERROR = 0) THEN
                    STD.TEXTIO.write(TX_OUT, string'("No errors or warnings"));
                    ASSERT (FALSE) REPORT
                      "Simulation successful (not a failure).  No problems detected."
                      SEVERITY FAILURE;
                ELSE
                    STD.TEXTIO.write(TX_OUT, TX_ERROR);
                    STD.TEXTIO.write(TX_OUT,
                        string'(" errors found in simulation"));
                    ASSERT (FALSE) REPORT "Errors found during simulation"
                         SEVERITY FAILURE;
                END IF;
            END PROCESS;

    END testbench_arch;

