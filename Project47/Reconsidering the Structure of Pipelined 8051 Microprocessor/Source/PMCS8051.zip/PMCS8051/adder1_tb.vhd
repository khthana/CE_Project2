
-- VHDL Test Bench Created from source file adder1.vhd -- 01:26:29 09/06/2004
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends 
-- that these types always be used for the top-level I/O of a design in order 
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY adder1_adder1_TB_vhd_tb IS
END adder1_adder1_TB_vhd_tb;

ARCHITECTURE behavior OF adder1_adder1_TB_vhd_tb IS 

	COMPONENT adder1
	PORT(
		in1 : IN std_logic_vector(15 downto 0);          
		out1 : OUT std_logic_vector(15 downto 0)
		);
	END COMPONENT;

	SIGNAL in1 :  std_logic_vector(15 downto 0);
	SIGNAL out1 :  std_logic_vector(15 downto 0);

BEGIN

	uut: adder1 PORT MAP(
		in1 => in1,
		out1 => out1
	);
-- *** Test Bench - User Defined Section ***
	in1 <= "0000000000000000",
		  "0000000000000001" after 100 ns;
		  		  
   tb : PROCESS
   BEGIN
--		if in1 = "0000000000000001" then
--			in1 <= out1  ;
--			wait for 1 ns;
--		end if;
      wait; -- will wait forever
   END PROCESS;
-- *** End Test Bench - User Defined Section ***

END;
