-- E:\USERS\POLARBEAR\PROJECT\PMCS8051
-- VHDL Test Bench created by
-- HDL Bencher 6.1i
-- Sat Mar 19 23:57:05 2005
-- 
-- Notes:
-- 1) This testbench has been automatically generated from
--   your Test Bench Waveform
-- 2) To use this as a user modifiable testbench do the following:
--   - Save it as a file with a .vhd extension (i.e. File->Save As...)
--   - Add it to your project as a testbench source (i.e. Project->Add Source...)
-- 

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY addr_decode_tw IS
END addr_decode_tw;

ARCHITECTURE testbench_arch OF addr_decode_tw IS
-- If you get a compiler error on the following line,
-- from the menu do Options->Configuration select VHDL 87
FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";
	COMPONENT addr_decode
		PORT (
			in1 : In  std_logic_vector (7 DOWNTO 0);
			in2 : In  std_logic_vector (7 DOWNTO 0);
			w_addr0 : Out  std_logic_vector (7 DOWNTO 0);
			w_addr1 : Out  std_logic_vector (7 DOWNTO 0)
		);
	END COMPONENT;

	SIGNAL in1 : std_logic_vector (7 DOWNTO 0);
	SIGNAL in2 : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_addr0 : std_logic_vector (7 DOWNTO 0);
	SIGNAL w_addr1 : std_logic_vector (7 DOWNTO 0);

BEGIN
	UUT : addr_decode
	PORT MAP (
		in1 => in1,
		in2 => in2,
		w_addr0 => w_addr0,
		w_addr1 => w_addr1
	);

	PROCESS
		VARIABLE TX_OUT : LINE;
		VARIABLE TX_ERROR : INTEGER := 0;

		PROCEDURE CHECK_w_addr0(
			next_w_addr0 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (w_addr0 /= next_w_addr0) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps w_addr0="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, w_addr0);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_w_addr0);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		PROCEDURE CHECK_w_addr1(
			next_w_addr1 : std_logic_vector (7 DOWNTO 0);
			TX_TIME : INTEGER
		) IS
			VARIABLE TX_STR : String(1 to 4096);
			VARIABLE TX_LOC : LINE;
		BEGIN
			-- If compiler error ("/=" is ambiguous) occurs in the next line of code
			-- change compiler settings to use explicit declarations only
			IF (w_addr1 /= next_w_addr1) THEN 
				STD.TEXTIO.write(TX_LOC,string'("Error at time="));
				STD.TEXTIO.write(TX_LOC, TX_TIME);
				STD.TEXTIO.write(TX_LOC,string'("ps w_addr1="));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, w_addr1);
				STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
				IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_w_addr1);
				STD.TEXTIO.write(TX_LOC, string'(" "));
				TX_STR(TX_LOC.all'range) := TX_LOC.all;
				STD.TEXTIO.writeline(results, TX_LOC);
				STD.TEXTIO.Deallocate(TX_LOC);
				ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
				TX_ERROR := TX_ERROR + 1;
			END IF;
		END;

		BEGIN
		-- --------------------
		in1 <= transport std_logic_vector'("01010011"); --53
		in2 <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 10 ps; -- Time=10 ps
		in1 <= transport std_logic_vector'("10001101"); --8D
		in2 <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 10 ps; -- Time=20 ps
		in1 <= transport std_logic_vector'("01001011"); --4B
		in2 <= transport std_logic_vector'("00011110"); --1E
		-- --------------------
		WAIT FOR 10 ps; -- Time=30 ps
		in1 <= transport std_logic_vector'("00000001"); --1
		in2 <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 10 ps; -- Time=40 ps
		in1 <= transport std_logic_vector'("01100110"); --66
		in2 <= transport std_logic_vector'("10000100"); --84
		-- --------------------
		WAIT FOR 10 ps; -- Time=50 ps
		in1 <= transport std_logic_vector'("01101110"); --6E
		in2 <= transport std_logic_vector'("10010000"); --90
		-- --------------------
		WAIT FOR 10 ps; -- Time=60 ps
		in1 <= transport std_logic_vector'("01001101"); --4D
		in2 <= transport std_logic_vector'("11001100"); --CC
		-- --------------------
		WAIT FOR 10 ps; -- Time=70 ps
		in1 <= transport std_logic_vector'("01111010"); --7A
		in2 <= transport std_logic_vector'("00000011"); --3
		-- --------------------
		WAIT FOR 10 ps; -- Time=80 ps
		in1 <= transport std_logic_vector'("10101000"); --A8
		in2 <= transport std_logic_vector'("00111110"); --3E
		-- --------------------
		WAIT FOR 10 ps; -- Time=90 ps
		in1 <= transport std_logic_vector'("11001101"); --CD
		in2 <= transport std_logic_vector'("11000101"); --C5
		-- --------------------
		WAIT FOR 10 ps; -- Time=100 ps
		in1 <= transport std_logic_vector'("00011110"); --1E
		in2 <= transport std_logic_vector'("00100010"); --22
		-- --------------------
		WAIT FOR 10 ps; -- Time=110 ps
		in1 <= transport std_logic_vector'("00010000"); --10
		in2 <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 10 ps; -- Time=120 ps
		in1 <= transport std_logic_vector'("01011000"); --58
		in2 <= transport std_logic_vector'("10111111"); --BF
		-- --------------------
		WAIT FOR 10 ps; -- Time=130 ps
		in1 <= transport std_logic_vector'("11101011"); --EB
		in2 <= transport std_logic_vector'("01010010"); --52
		-- --------------------
		WAIT FOR 10 ps; -- Time=140 ps
		in1 <= transport std_logic_vector'("11111110"); --FE
		in2 <= transport std_logic_vector'("01011110"); --5E
		-- --------------------
		WAIT FOR 10 ps; -- Time=150 ps
		in1 <= transport std_logic_vector'("00000101"); --5
		in2 <= transport std_logic_vector'("10101101"); --AD
		-- --------------------
		WAIT FOR 10 ps; -- Time=160 ps
		in1 <= transport std_logic_vector'("10110111"); --B7
		in2 <= transport std_logic_vector'("01000111"); --47
		-- --------------------
		WAIT FOR 10 ps; -- Time=170 ps
		in1 <= transport std_logic_vector'("00000111"); --7
		in2 <= transport std_logic_vector'("01110110"); --76
		-- --------------------
		WAIT FOR 10 ps; -- Time=180 ps
		in1 <= transport std_logic_vector'("00101011"); --2B
		in2 <= transport std_logic_vector'("11000010"); --C2
		-- --------------------
		WAIT FOR 10 ps; -- Time=190 ps
		in1 <= transport std_logic_vector'("10011000"); --98
		in2 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 10 ps; -- Time=200 ps
		in1 <= transport std_logic_vector'("00000011"); --3
		in2 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 10 ps; -- Time=210 ps
		in1 <= transport std_logic_vector'("01100001"); --61
		in2 <= transport std_logic_vector'("01110001"); --71
		-- --------------------
		WAIT FOR 10 ps; -- Time=220 ps
		in1 <= transport std_logic_vector'("11100111"); --E7
		in2 <= transport std_logic_vector'("10001101"); --8D
		-- --------------------
		WAIT FOR 10 ps; -- Time=230 ps
		in1 <= transport std_logic_vector'("00001010"); --A
		in2 <= transport std_logic_vector'("00110100"); --34
		-- --------------------
		WAIT FOR 10 ps; -- Time=240 ps
		in1 <= transport std_logic_vector'("01111110"); --7E
		in2 <= transport std_logic_vector'("01101101"); --6D
		-- --------------------
		WAIT FOR 10 ps; -- Time=250 ps
		in1 <= transport std_logic_vector'("00111010"); --3A
		in2 <= transport std_logic_vector'("10000100"); --84
		-- --------------------
		WAIT FOR 10 ps; -- Time=260 ps
		in1 <= transport std_logic_vector'("01110001"); --71
		in2 <= transport std_logic_vector'("11111111"); --FF
		-- --------------------
		WAIT FOR 10 ps; -- Time=270 ps
		in1 <= transport std_logic_vector'("10011001"); --99
		in2 <= transport std_logic_vector'("10101010"); --AA
		-- --------------------
		WAIT FOR 10 ps; -- Time=280 ps
		in1 <= transport std_logic_vector'("01100111"); --67
		in2 <= transport std_logic_vector'("10001011"); --8B
		-- --------------------
		WAIT FOR 10 ps; -- Time=290 ps
		in1 <= transport std_logic_vector'("11010000"); --D0
		in2 <= transport std_logic_vector'("11101110"); --EE
		-- --------------------
		WAIT FOR 10 ps; -- Time=300 ps
		in1 <= transport std_logic_vector'("00001001"); --9
		in2 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 10 ps; -- Time=310 ps
		in1 <= transport std_logic_vector'("10000111"); --87
		in2 <= transport std_logic_vector'("10010111"); --97
		-- --------------------
		WAIT FOR 10 ps; -- Time=320 ps
		in1 <= transport std_logic_vector'("11111111"); --FF
		in2 <= transport std_logic_vector'("10110001"); --B1
		-- --------------------
		WAIT FOR 10 ps; -- Time=330 ps
		in1 <= transport std_logic_vector'("01100101"); --65
		in2 <= transport std_logic_vector'("11101111"); --EF
		-- --------------------
		WAIT FOR 10 ps; -- Time=340 ps
		in1 <= transport std_logic_vector'("11110000"); --F0
		in2 <= transport std_logic_vector'("11011010"); --DA
		-- --------------------
		WAIT FOR 10 ps; -- Time=350 ps
		in1 <= transport std_logic_vector'("00010011"); --13
		in2 <= transport std_logic_vector'("00111100"); --3C
		-- --------------------
		WAIT FOR 10 ps; -- Time=360 ps
		in1 <= transport std_logic_vector'("10000101"); --85
		in2 <= transport std_logic_vector'("00011101"); --1D
		-- --------------------
		WAIT FOR 10 ps; -- Time=370 ps
		in1 <= transport std_logic_vector'("00111001"); --39
		in2 <= transport std_logic_vector'("11000111"); --C7
		-- --------------------
		WAIT FOR 10 ps; -- Time=380 ps
		in1 <= transport std_logic_vector'("01100101"); --65
		in2 <= transport std_logic_vector'("11000010"); --C2
		-- --------------------
		WAIT FOR 10 ps; -- Time=390 ps
		in1 <= transport std_logic_vector'("01111110"); --7E
		in2 <= transport std_logic_vector'("11011000"); --D8
		-- --------------------
		WAIT FOR 10 ps; -- Time=400 ps
		in1 <= transport std_logic_vector'("00111000"); --38
		in2 <= transport std_logic_vector'("00010001"); --11
		-- --------------------
		WAIT FOR 10 ps; -- Time=410 ps
		in1 <= transport std_logic_vector'("10001010"); --8A
		in2 <= transport std_logic_vector'("10110110"); --B6
		-- --------------------
		WAIT FOR 10 ps; -- Time=420 ps
		in1 <= transport std_logic_vector'("10101000"); --A8
		in2 <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 10 ps; -- Time=430 ps
		in1 <= transport std_logic_vector'("00000110"); --6
		in2 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 10 ps; -- Time=440 ps
		in1 <= transport std_logic_vector'("01011011"); --5B
		in2 <= transport std_logic_vector'("11001100"); --CC
		-- --------------------
		WAIT FOR 10 ps; -- Time=450 ps
		in1 <= transport std_logic_vector'("10011010"); --9A
		in2 <= transport std_logic_vector'("11111101"); --FD
		-- --------------------
		WAIT FOR 10 ps; -- Time=460 ps
		in1 <= transport std_logic_vector'("11111001"); --F9
		in2 <= transport std_logic_vector'("11001000"); --C8
		-- --------------------
		WAIT FOR 10 ps; -- Time=470 ps
		in1 <= transport std_logic_vector'("11101101"); --ED
		in2 <= transport std_logic_vector'("11110101"); --F5
		-- --------------------
		WAIT FOR 10 ps; -- Time=480 ps
		in1 <= transport std_logic_vector'("00101011"); --2B
		in2 <= transport std_logic_vector'("10001110"); --8E
		-- --------------------
		WAIT FOR 10 ps; -- Time=490 ps
		in1 <= transport std_logic_vector'("10101000"); --A8
		in2 <= transport std_logic_vector'("11011011"); --DB
		-- --------------------
		WAIT FOR 10 ps; -- Time=500 ps
		in1 <= transport std_logic_vector'("10011001"); --99
		in2 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ps; -- Time=510 ps
		in1 <= transport std_logic_vector'("01110010"); --72
		in2 <= transport std_logic_vector'("11110111"); --F7
		-- --------------------
		WAIT FOR 10 ps; -- Time=520 ps
		in1 <= transport std_logic_vector'("11101010"); --EA
		in2 <= transport std_logic_vector'("10010111"); --97
		-- --------------------
		WAIT FOR 10 ps; -- Time=530 ps
		in1 <= transport std_logic_vector'("11110100"); --F4
		in2 <= transport std_logic_vector'("10010000"); --90
		-- --------------------
		WAIT FOR 10 ps; -- Time=540 ps
		in1 <= transport std_logic_vector'("11000110"); --C6
		in2 <= transport std_logic_vector'("01101011"); --6B
		-- --------------------
		WAIT FOR 10 ps; -- Time=550 ps
		in1 <= transport std_logic_vector'("11010110"); --D6
		in2 <= transport std_logic_vector'("11110000"); --F0
		-- --------------------
		WAIT FOR 10 ps; -- Time=560 ps
		in1 <= transport std_logic_vector'("11010111"); --D7
		in2 <= transport std_logic_vector'("00101000"); --28
		-- --------------------
		WAIT FOR 10 ps; -- Time=570 ps
		in1 <= transport std_logic_vector'("10111111"); --BF
		in2 <= transport std_logic_vector'("01011101"); --5D
		-- --------------------
		WAIT FOR 10 ps; -- Time=580 ps
		in1 <= transport std_logic_vector'("11000010"); --C2
		in2 <= transport std_logic_vector'("00010111"); --17
		-- --------------------
		WAIT FOR 10 ps; -- Time=590 ps
		in1 <= transport std_logic_vector'("01010111"); --57
		in2 <= transport std_logic_vector'("00100000"); --20
		-- --------------------
		WAIT FOR 10 ps; -- Time=600 ps
		in1 <= transport std_logic_vector'("00110010"); --32
		in2 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 10 ps; -- Time=610 ps
		in1 <= transport std_logic_vector'("01000111"); --47
		in2 <= transport std_logic_vector'("10000001"); --81
		-- --------------------
		WAIT FOR 10 ps; -- Time=620 ps
		in1 <= transport std_logic_vector'("11001101"); --CD
		in2 <= transport std_logic_vector'("10101011"); --AB
		-- --------------------
		WAIT FOR 10 ps; -- Time=630 ps
		in1 <= transport std_logic_vector'("00110111"); --37
		in2 <= transport std_logic_vector'("11000111"); --C7
		-- --------------------
		WAIT FOR 10 ps; -- Time=640 ps
		in1 <= transport std_logic_vector'("00111011"); --3B
		in2 <= transport std_logic_vector'("11011111"); --DF
		-- --------------------
		WAIT FOR 10 ps; -- Time=650 ps
		in1 <= transport std_logic_vector'("11001110"); --CE
		in2 <= transport std_logic_vector'("00111100"); --3C
		-- --------------------
		WAIT FOR 10 ps; -- Time=660 ps
		in1 <= transport std_logic_vector'("00100101"); --25
		in2 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ps; -- Time=670 ps
		in1 <= transport std_logic_vector'("10110101"); --B5
		in2 <= transport std_logic_vector'("00100110"); --26
		-- --------------------
		WAIT FOR 10 ps; -- Time=680 ps
		in1 <= transport std_logic_vector'("00110011"); --33
		in2 <= transport std_logic_vector'("10000110"); --86
		-- --------------------
		WAIT FOR 10 ps; -- Time=690 ps
		in1 <= transport std_logic_vector'("10010100"); --94
		in2 <= transport std_logic_vector'("11001110"); --CE
		-- --------------------
		WAIT FOR 10 ps; -- Time=700 ps
		in1 <= transport std_logic_vector'("00001100"); --C
		in2 <= transport std_logic_vector'("10001000"); --88
		-- --------------------
		WAIT FOR 10 ps; -- Time=710 ps
		in1 <= transport std_logic_vector'("00010010"); --12
		in2 <= transport std_logic_vector'("01111100"); --7C
		-- --------------------
		WAIT FOR 10 ps; -- Time=720 ps
		in1 <= transport std_logic_vector'("01011001"); --59
		in2 <= transport std_logic_vector'("10110100"); --B4
		-- --------------------
		WAIT FOR 10 ps; -- Time=730 ps
		in1 <= transport std_logic_vector'("11010111"); --D7
		in2 <= transport std_logic_vector'("01111000"); --78
		-- --------------------
		WAIT FOR 10 ps; -- Time=740 ps
		in1 <= transport std_logic_vector'("11000001"); --C1
		in2 <= transport std_logic_vector'("01010001"); --51
		-- --------------------
		WAIT FOR 10 ps; -- Time=750 ps
		in1 <= transport std_logic_vector'("10001100"); --8C
		in2 <= transport std_logic_vector'("00001001"); --9
		-- --------------------
		WAIT FOR 10 ps; -- Time=760 ps
		in1 <= transport std_logic_vector'("11101101"); --ED
		in2 <= transport std_logic_vector'("10101001"); --A9
		-- --------------------
		WAIT FOR 10 ps; -- Time=770 ps
		in1 <= transport std_logic_vector'("11011001"); --D9
		in2 <= transport std_logic_vector'("01111000"); --78
		-- --------------------
		WAIT FOR 10 ps; -- Time=780 ps
		in1 <= transport std_logic_vector'("10000100"); --84
		in2 <= transport std_logic_vector'("00000010"); --2
		-- --------------------
		WAIT FOR 10 ps; -- Time=790 ps
		in1 <= transport std_logic_vector'("01100101"); --65
		in2 <= transport std_logic_vector'("00001110"); --E
		-- --------------------
		WAIT FOR 10 ps; -- Time=800 ps
		in1 <= transport std_logic_vector'("00101111"); --2F
		in2 <= transport std_logic_vector'("10100101"); --A5
		-- --------------------
		WAIT FOR 10 ps; -- Time=810 ps
		in1 <= transport std_logic_vector'("11011001"); --D9
		in2 <= transport std_logic_vector'("00010000"); --10
		-- --------------------
		WAIT FOR 10 ps; -- Time=820 ps
		in1 <= transport std_logic_vector'("10010110"); --96
		in2 <= transport std_logic_vector'("11011010"); --DA
		-- --------------------
		WAIT FOR 10 ps; -- Time=830 ps
		in1 <= transport std_logic_vector'("11011100"); --DC
		in2 <= transport std_logic_vector'("11001001"); --C9
		-- --------------------
		WAIT FOR 10 ps; -- Time=840 ps
		in1 <= transport std_logic_vector'("01100000"); --60
		in2 <= transport std_logic_vector'("11101000"); --E8
		-- --------------------
		WAIT FOR 10 ps; -- Time=850 ps
		in1 <= transport std_logic_vector'("00010111"); --17
		in2 <= transport std_logic_vector'("10000000"); --80
		-- --------------------
		WAIT FOR 10 ps; -- Time=860 ps
		in1 <= transport std_logic_vector'("00110110"); --36
		in2 <= transport std_logic_vector'("00011001"); --19
		-- --------------------
		WAIT FOR 10 ps; -- Time=870 ps
		in1 <= transport std_logic_vector'("00110001"); --31
		in2 <= transport std_logic_vector'("01111100"); --7C
		-- --------------------
		WAIT FOR 10 ps; -- Time=880 ps
		in1 <= transport std_logic_vector'("10111111"); --BF
		in2 <= transport std_logic_vector'("10110011"); --B3
		-- --------------------
		WAIT FOR 10 ps; -- Time=890 ps
		in1 <= transport std_logic_vector'("11010011"); --D3
		in2 <= transport std_logic_vector'("00000110"); --6
		-- --------------------
		WAIT FOR 10 ps; -- Time=900 ps
		in1 <= transport std_logic_vector'("10100100"); --A4
		in2 <= transport std_logic_vector'("11111111"); --FF
		-- --------------------
		WAIT FOR 10 ps; -- Time=910 ps
		in1 <= transport std_logic_vector'("10100101"); --A5
		in2 <= transport std_logic_vector'("01100110"); --66
		-- --------------------
		WAIT FOR 10 ps; -- Time=920 ps
		in1 <= transport std_logic_vector'("10001100"); --8C
		in2 <= transport std_logic_vector'("01000101"); --45
		-- --------------------
		WAIT FOR 10 ps; -- Time=930 ps
		in1 <= transport std_logic_vector'("01001110"); --4E
		in2 <= transport std_logic_vector'("11100100"); --E4
		-- --------------------
		WAIT FOR 10 ps; -- Time=940 ps
		in1 <= transport std_logic_vector'("00100000"); --20
		in2 <= transport std_logic_vector'("11001101"); --CD
		-- --------------------
		WAIT FOR 10 ps; -- Time=950 ps
		in1 <= transport std_logic_vector'("01110111"); --77
		in2 <= transport std_logic_vector'("11001000"); --C8
		-- --------------------
		WAIT FOR 10 ps; -- Time=960 ps
		in1 <= transport std_logic_vector'("00001000"); --8
		in2 <= transport std_logic_vector'("11011110"); --DE
		-- --------------------
		WAIT FOR 10 ps; -- Time=970 ps
		in1 <= transport std_logic_vector'("11000111"); --C7
		in2 <= transport std_logic_vector'("01011001"); --59
		-- --------------------
		WAIT FOR 10 ps; -- Time=980 ps
		in1 <= transport std_logic_vector'("11101011"); --EB
		in2 <= transport std_logic_vector'("11000001"); --C1
		-- --------------------
		WAIT FOR 10 ps; -- Time=990 ps
		in1 <= transport std_logic_vector'("11100111"); --E7
		in2 <= transport std_logic_vector'("11100000"); --E0
		-- --------------------
		WAIT FOR 15 ps; -- Time=1005 ps
		-- --------------------

		IF (TX_ERROR = 0) THEN 
			STD.TEXTIO.write(TX_OUT,string'("No errors or warnings"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Simulation successful (not a failure).  No problems detected. "
				SEVERITY FAILURE;
		ELSE
			STD.TEXTIO.write(TX_OUT, TX_ERROR);
			STD.TEXTIO.write(TX_OUT, string'(
				" errors found in simulation"));
			STD.TEXTIO.writeline(results, TX_OUT);
			ASSERT (FALSE) REPORT
				"Errors found during simulation"
				SEVERITY FAILURE;
		END IF;
	END PROCESS;
END testbench_arch;

CONFIGURATION addr_decode_cfg OF addr_decode_tw IS
	FOR testbench_arch
	END FOR;
END addr_decode_cfg;
