onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -format Logic -label Clock -radix binary /decode_stage/clock
add wave -noupdate -format Logic -label Reset -radix binary /decode_stage/reset
add wave -noupdate -format Literal -label Inst_b1 -radix binary /decode_stage/inst_b1
add wave -noupdate -format Literal -label Inst_b2 -radix binary /decode_stage/inst_b2
add wave -noupdate -format Literal -label Inst_b3 -radix binary /decode_stage/inst_b3
add wave -noupdate -format Literal /decode_stage/s1
add wave -noupdate -format Literal /decode_stage/s2
add wave -noupdate -format Literal /decode_stage/d1
add wave -noupdate -format Literal /decode_stage/d2
add wave -noupdate -format Literal /decode_stage/alu_oprt
add wave -noupdate -format Literal /decode_stage/reg_aa
add wave -noupdate -format Literal /decode_stage/reg_bb
add wave -noupdate -format Literal /decode_stage/from_acc
add wave -noupdate -format Literal /decode_stage/from_b
add wave -noupdate -format Literal /decode_stage/from_mem
add wave -noupdate -format Literal /decode_stage/from_sfr
add wave -noupdate -format Literal /decode_stage/to_mem
add wave -noupdate -format Literal /decode_stage/reg_indirect_dec_to_r0_r1_cpy2
add wave -noupdate -format Literal /decode_stage/direct_addr_dec_to_mux6
add wave -noupdate -format Literal /decode_stage/bit_addr_dec_to_mux6
add wave -noupdate -format Literal /decode_stage/rn_addr_dec_to_mux6
add wave -noupdate -format Literal /decode_stage/r0_r1_cpy2_to_mux6
add wave -noupdate -format Literal /decode_stage/mux7_to_mux8_mux9
add wave -noupdate -format Literal /decode_stage/bit_number_dec_to_mux9
add wave -noupdate -format Literal /decode_stage/sel_mux6
add wave -noupdate -format Literal /decode_stage/sel_mux7
add wave -noupdate -format Literal /decode_stage/sel_mux8
add wave -noupdate -format Literal /decode_stage/sel_mux9
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ps} 0}
WaveRestoreZoom {0 ps} {2860 ps}
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
