--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 7.1.01i
--  \   \         Application : ISE WebPACK
--  /   /         Filename : datapath_tb.vhw
-- /___/   /\     Timestamp : Thu Apr 07 06:00:57 2005
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: datapath_tb
--Device: Xilinx
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE STD.TEXTIO.ALL;

ENTITY datapath_tb IS
END datapath_tb;

ARCHITECTURE testbench_arch OF datapath_tb IS
    COMPONENT datapath
        PORT (
            Clock : In std_logic;
            Reset : In std_logic;
            int0 : In std_logic;
            int1 : In std_logic;
            rd : In std_logic;
            wr : In std_logic;
            port0_in : In std_logic_vector (7 DownTo 0);
            port1_in : In std_logic_vector (7 DownTo 0);
            port2_in : In std_logic_vector (7 DownTo 0);
            port3_in : In std_logic_vector (7 DownTo 0);
            port0_out : Out std_logic_vector (7 DownTo 0);
            port1_out : Out std_logic_vector (7 DownTo 0);
            port2_out : Out std_logic_vector (7 DownTo 0);
            port3_out : Out std_logic_vector (7 DownTo 0)
        );
    END COMPONENT;

    SIGNAL Clock : std_logic := '0';
    SIGNAL Reset : std_logic := '0';
    SIGNAL int0 : std_logic := '0';
    SIGNAL int1 : std_logic := '0';
    SIGNAL rd : std_logic := '0';
    SIGNAL wr : std_logic := '0';
    SIGNAL port0_in : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port1_in : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port2_in : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port3_in : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port0_out : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port1_out : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port2_out : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL port3_out : std_logic_vector (7 DownTo 0) := "00000000";

    SHARED VARIABLE TX_ERROR : INTEGER := 0;
    SHARED VARIABLE TX_OUT : LINE;

    constant PERIOD : time := 100 ns;
    constant DUTY_CYCLE : real := 0.5;
    constant OFFSET : time := 0 ns;

    BEGIN
        UUT : datapath
        PORT MAP (
            Clock => Clock,
            Reset => Reset,
            int0 => int0,
            int1 => int1,
            rd => rd,
            wr => wr,
            port0_in => port0_in,
            port1_in => port1_in,
            port2_in => port2_in,
            port3_in => port3_in,
            port0_out => port0_out,
            port1_out => port1_out,
            port2_out => port2_out,
            port3_out => port3_out
        );

        PROCESS    -- clock process for Clock
        BEGIN
            WAIT for OFFSET;
            CLOCK_LOOP : LOOP
                Clock <= '0';
                WAIT FOR (PERIOD - (PERIOD * DUTY_CYCLE));
                Clock <= '1';
                WAIT FOR (PERIOD * DUTY_CYCLE);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS
            PROCEDURE CHECK_port0_out(
                next_port0_out : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (port0_out /= next_port0_out) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns port0_out="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port0_out);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port0_out);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_port1_out(
                next_port1_out : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (port1_out /= next_port1_out) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns port1_out="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port1_out);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port1_out);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_port2_out(
                next_port2_out : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (port2_out /= next_port2_out) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns port2_out="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port2_out);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port2_out);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            PROCEDURE CHECK_port3_out(
                next_port3_out : std_logic_vector (7 DownTo 0);
                TX_TIME : INTEGER
            ) IS
                VARIABLE TX_STR : String(1 to 4096);
                VARIABLE TX_LOC : LINE;
                BEGIN
                IF (port3_out /= next_port3_out) THEN
                    STD.TEXTIO.write(TX_LOC, string'("Error at time="));
                    STD.TEXTIO.write(TX_LOC, TX_TIME);
                    STD.TEXTIO.write(TX_LOC, string'("ns port3_out="));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, port3_out);
                    STD.TEXTIO.write(TX_LOC, string'(", Expected = "));
                    IEEE.STD_LOGIC_TEXTIO.write(TX_LOC, next_port3_out);
                    STD.TEXTIO.write(TX_LOC, string'(" "));
                    TX_STR(TX_LOC.all'range) := TX_LOC.all;
                    STD.TEXTIO.Deallocate(TX_LOC);
                    ASSERT (FALSE) REPORT TX_STR SEVERITY ERROR;
                    TX_ERROR := TX_ERROR + 1;
                END IF;
            END;
            BEGIN
                WAIT FOR 1240 ns;

                IF (TX_ERROR = 0) THEN
                    STD.TEXTIO.write(TX_OUT, string'("No errors or warnings"));
                    ASSERT (FALSE) REPORT
                      "Simulation successful (not a failure).  No problems detected."
                      SEVERITY FAILURE;
                ELSE
                    STD.TEXTIO.write(TX_OUT, TX_ERROR);
                    STD.TEXTIO.write(TX_OUT,
                        string'(" errors found in simulation"));
                    ASSERT (FALSE) REPORT "Errors found during simulation"
                         SEVERITY FAILURE;
                END IF;
            END PROCESS;

    END testbench_arch;

