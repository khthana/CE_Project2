--------------------------------------------------------------------------------
-- Copyright (c) 1995-2003 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 6.3.03i
--  \   \         Application : 
--  /   /         Filename : datapath.vhf
-- /___/   /\     Timestamp : 03/17/2005 13:48:36
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: datapath
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
-- synopsys translate_off
library UNISIM;
use UNISIM.Vcomponents.ALL;
-- synopsys translate_on

entity datapath is
   port ( Clock  : in    std_logic; 
          int0   : in    std_logic; 
          int1   : in    std_logic; 
          P0_in  : in    std_logic_vector (7 downto 0); 
          P1_in  : in    std_logic_vector (7 downto 0); 
          P2_in  : in    std_logic_vector (7 downto 0); 
          P3_in  : in    std_logic_vector (7 downto 0); 
          rd     : in    std_logic; 
          Reset  : in    std_logic; 
          wr     : in    std_logic; 
          P0_out : out   std_logic_vector (7 downto 0); 
          P1_out : out   std_logic_vector (7 downto 0); 
          P2_out : out   std_logic_vector (7 downto 0); 
          P3_out : out   std_logic_vector (7 downto 0));
end datapath;

architecture BEHAVIORAL of datapath is
   signal XLXN_1   : std_logic_vector (7 downto 0);
   signal XLXN_2   : std_logic_vector (7 downto 0);
   signal XLXN_3   : std_logic_vector (7 downto 0);
   signal XLXN_14  : std_logic_vector (7 downto 0);
   signal XLXN_15  : std_logic_vector (7 downto 0);
   signal XLXN_18  : std_logic_vector (7 downto 0);
   signal XLXN_19  : std_logic_vector (7 downto 0);
   signal XLXN_59  : std_logic_vector (7 downto 0);
   signal XLXN_61  : std_logic_vector (7 downto 0);
   signal XLXN_62  : std_logic_vector (7 downto 0);
   signal XLXN_63  : std_logic_vector (7 downto 0);
   signal XLXN_64  : std_logic_vector (7 downto 0);
   signal XLXN_69  : std_logic_vector (7 downto 0);
   signal XLXN_70  : std_logic_vector (7 downto 0);
   signal XLXN_71  : std_logic_vector (7 downto 0);
   signal XLXN_72  : std_logic_vector (7 downto 0);
   signal XLXN_73  : std_logic_vector (7 downto 0);
   signal XLXN_75  : std_logic_vector (7 downto 0);
   signal XLXN_77  : std_logic_vector (7 downto 0);
   signal XLXN_130 : std_logic_vector (7 downto 0);
   signal XLXN_281 : std_logic_vector (7 downto 0);
   signal XLXN_438 : std_logic;
   signal XLXN_441 : std_logic;
   signal XLXN_443 : std_logic_vector (1 downto 0);
   signal XLXN_444 : std_logic;
   signal XLXN_445 : std_logic;
   signal XLXN_446 : std_logic_vector (2 downto 0);
   signal XLXN_447 : std_logic_vector (1 downto 0);
   signal XLXN_452 : std_logic_vector (1 downto 0);
   signal XLXN_456 : std_logic;
   signal XLXN_461 : std_logic_vector (1 downto 0);
   signal XLXN_462 : std_logic_vector (2 downto 0);
   signal XLXN_465 : std_logic_vector (2 downto 0);
   signal XLXN_467 : std_logic_vector (1 downto 0);
   signal XLXN_472 : std_logic;
   signal XLXN_473 : std_logic;
   signal XLXN_478 : std_logic;
   signal XLXN_479 : std_logic;
   signal XLXN_480 : std_logic;
   signal XLXN_481 : std_logic_vector (1 downto 0);
   signal XLXN_482 : std_logic;
   signal XLXN_483 : std_logic;
   signal XLXN_485 : std_logic;
   signal XLXN_487 : std_logic;
   signal XLXN_490 : std_logic;
   signal XLXN_491 : std_logic;
   signal XLXN_512 : std_logic;
   signal XLXN_513 : std_logic_vector (1 downto 0);
   signal XLXN_515 : std_logic;
   signal XLXN_518 : std_logic;
   signal XLXN_521 : std_logic_vector (3 downto 0);
   signal XLXN_522 : std_logic_vector (1 downto 0);
   signal XLXN_523 : std_logic_vector (1 downto 0);
   signal XLXN_541 : std_logic_vector (1 downto 0);
   signal XLXN_542 : std_logic_vector (1 downto 0);
   signal XLXN_543 : std_logic_vector (3 downto 0);
   signal XLXN_545 : std_logic;
   signal XLXN_546 : std_logic;
   signal XLXN_547 : std_logic;
   signal XLXN_548 : std_logic;
   signal XLXN_550 : std_logic;
   signal XLXN_552 : std_logic;
   signal XLXN_554 : std_logic;
   signal XLXN_556 : std_logic_vector (7 downto 0);
   signal XLXN_557 : std_logic;
   signal XLXN_558 : std_logic;
   signal XLXN_559 : std_logic;
   signal XLXN_560 : std_logic;
   signal XLXN_562 : std_logic;
   signal XLXN_565 : std_logic_vector (1 downto 0);
   signal XLXN_566 : std_logic_vector (15 downto 0);
   signal XLXN_568 : std_logic_vector (15 downto 0);
   signal XLXN_573 : std_logic_vector (15 downto 0);
   signal XLXN_574 : std_logic_vector (7 downto 0);
   signal XLXN_575 : std_logic_vector (7 downto 0);
   signal XLXN_577 : std_logic_vector (7 downto 0);
   signal XLXN_583 : std_logic_vector (7 downto 0);
   signal XLXN_584 : std_logic_vector (7 downto 0);
   signal XLXN_585 : std_logic_vector (7 downto 0);
   signal XLXN_588 : std_logic;
   signal XLXN_589 : std_logic;
   signal XLXN_590 : std_logic_vector (7 downto 0);
   signal XLXN_592 : std_logic_vector (7 downto 0);
   signal XLXN_593 : std_logic;
   signal XLXN_594 : std_logic_vector (7 downto 0);
   signal XLXN_597 : std_logic_vector (7 downto 0);
   signal XLXN_599 : std_logic_vector (7 downto 0);
   signal XLXN_600 : std_logic_vector (7 downto 0);
   signal XLXN_601 : std_logic_vector (1 downto 0);
   signal XLXN_603 : std_logic;
   signal XLXN_604 : std_logic;
   signal XLXN_605 : std_logic;
   signal XLXN_606 : std_logic_vector (1 downto 0);
   signal XLXN_607 : std_logic;
   signal XLXN_608 : std_logic;
   signal XLXN_610 : std_logic;
   signal XLXN_611 : std_logic;
   signal XLXN_613 : std_logic_vector (15 downto 0);
   signal XLXN_615 : std_logic_vector (1 downto 0);
   signal XLXN_617 : std_logic_vector (1 downto 0);
   signal XLXN_618 : std_logic_vector (4 downto 0);
   signal XLXN_619 : std_logic_vector (4 downto 0);
   signal XLXN_626 : std_logic_vector (7 downto 0);
   signal XLXN_627 : std_logic;
   signal XLXN_628 : std_logic_vector (7 downto 0);
   signal XLXN_786 : std_logic_vector (7 downto 0);
   signal XLXN_788 : std_logic_vector (1 downto 0);
   signal XLXN_791 : std_logic_vector (7 downto 0);
   signal XLXN_798 : std_logic_vector (7 downto 0);
   signal XLXN_799 : std_logic_vector (1 downto 0);
   component writeback
      port ( sel_addr_decode : in    std_logic; 
             sel_mux18       : in    std_logic; 
             d11             : in    std_logic_vector (7 downto 0); 
             d22             : in    std_logic_vector (7 downto 0); 
             R_A             : in    std_logic_vector (7 downto 0); 
             R_B             : in    std_logic_vector (7 downto 0); 
             w_addr          : out   std_logic_vector (7 downto 0); 
             w_data          : out   std_logic_vector (7 downto 0); 
             out_A           : out   std_logic_vector (7 downto 0); 
             out_B           : out   std_logic_vector (7 downto 0));
   end component;
   
   component decode_stage
      port ( reset    : in    std_logic; 
             inst_b1  : in    std_logic_vector (7 downto 0); 
             inst_b2  : in    std_logic_vector (7 downto 0); 
             inst_b3  : in    std_logic_vector (7 downto 0); 
             from_acc : in    std_logic_vector (7 downto 0); 
             from_b   : in    std_logic_vector (7 downto 0); 
             from_mem : in    std_logic_vector (7 downto 0); 
             from_sfr : in    std_logic_vector (7 downto 0); 
             sel_mux6 : in    std_logic_vector (1 downto 0); 
             sel_mux7 : in    std_logic_vector (2 downto 0); 
             sel_mux8 : in    std_logic_vector (1 downto 0); 
             sel_mux9 : in    std_logic_vector (2 downto 0); 
             bank     : in    std_logic_vector (1 downto 0); 
             s1       : out   std_logic_vector (7 downto 0); 
             s2       : out   std_logic_vector (7 downto 0); 
             d1       : out   std_logic_vector (7 downto 0); 
             d2       : out   std_logic_vector (7 downto 0); 
             alu_oprt : out   std_logic_vector (4 downto 0); 
             reg_aa   : out   std_logic_vector (7 downto 0); 
             reg_bb   : out   std_logic_vector (7 downto 0); 
             in_r0    : in    std_logic_vector (7 downto 0); 
             in_r1    : in    std_logic_vector (7 downto 0); 
             r_addr   : out   std_logic_vector (7 downto 0));
   end component;
   
   component fetch
      port ( clock                     : in    std_logic; 
             reset                     : in    std_logic; 
             PC_load_in16              : in    std_logic; 
             temp1_load_in             : in    std_logic; 
             sel_mux2                  : in    std_logic; 
             sel_mux3                  : in    std_logic; 
             from_internal_data_memory : in    std_logic_vector (15 downto 0); 
             sel_mux1                  : in    std_logic_vector (1 downto 0); 
             sel_mux5                  : in    std_logic_vector (1 downto 0); 
             ex_byte1                  : in    std_logic_vector (7 downto 0); 
             ex_byte2                  : in    std_logic_vector (7 downto 0); 
             ex_byte3                  : in    std_logic_vector (7 downto 0); 
             sel_jcall                 : in    std_logic_vector (1 downto 0); 
             acc_in                    : in    std_logic_vector (7 downto 0); 
             DPTR_in                   : in    std_logic_vector (15 downto 0); 
             sel_mux4                  : in    std_logic_vector (2 downto 0); 
             data_bus                  : in    std_logic_vector (7 downto 0); 
             address_bus               : out   std_logic_vector (15 downto 0); 
             pc_resent                 : out   std_logic_vector (15 downto 0); 
             instruction_byte1         : out   std_logic_vector (7 downto 0); 
             instruction_byte2         : out   std_logic_vector (7 downto 0); 
             instruction_byte3         : out   std_logic_vector (7 downto 0); 
             iqc                       : out   std_logic_vector (1 downto 0));
   end component;
   
   component mem_unit
      port ( clk       : in    std_logic; 
             rst       : in    std_logic; 
             sel_as    : in    std_logic; 
             sel_mux10 : in    std_logic; 
             sel_mux13 : in    std_logic; 
             sel_mux14 : in    std_logic; 
             sel_mux15 : in    std_logic; 
             wr_bank0  : in    std_logic; 
             wr_bank1  : in    std_logic; 
             load_in   : in    std_logic; 
             W_A       : in    std_logic; 
             W_B       : in    std_logic; 
             W_psw     : in    std_logic; 
             Din0      : in    std_logic_vector (7 downto 0); 
             Din1      : in    std_logic_vector (7 downto 0); 
             PC_in     : in    std_logic_vector (15 downto 0); 
             r_addr    : in    std_logic_vector (7 downto 0); 
             w_addr    : in    std_logic_vector (7 downto 0); 
             en        : in    std_logic_vector (1 downto 0); 
             sel_mux11 : in    std_logic_vector (1 downto 0); 
             sel_mux12 : in    std_logic_vector (1 downto 0); 
             di_A      : in    std_logic_vector (7 downto 0); 
             di_B      : in    std_logic_vector (7 downto 0); 
             di_psw    : in    std_logic_vector (7 downto 0); 
             p0_in     : in    std_logic_vector (7 downto 0); 
             p1_in     : in    std_logic_vector (7 downto 0); 
             p2_in     : in    std_logic_vector (7 downto 0); 
             p3_in     : in    std_logic_vector (7 downto 0); 
             PC_out    : out   std_logic_vector (15 downto 0); 
             dptr      : out   std_logic_vector (15 downto 0); 
             mux15     : out   std_logic_vector (7 downto 0); 
             do_A      : out   std_logic_vector (7 downto 0); 
             do_B      : out   std_logic_vector (7 downto 0); 
             do_psw    : out   std_logic_vector (7 downto 0); 
             R0        : out   std_logic_vector (7 downto 0); 
             R1        : out   std_logic_vector (7 downto 0); 
             p0_out    : out   std_logic_vector (7 downto 0); 
             p1_out    : out   std_logic_vector (7 downto 0); 
             p2_out    : out   std_logic_vector (7 downto 0); 
             p3_out    : out   std_logic_vector (7 downto 0));
   end component;
   
   component exwb
      port ( clk              : in    std_logic; 
             rst              : in    std_logic; 
             in_w_A           : in    std_logic; 
             in_w_B           : in    std_logic; 
             in_sel_nux10     : in    std_logic; 
             in_sp_load       : in    std_logic; 
             in_sel_mux18     : in    std_logic; 
             in_sel_addr_dec  : in    std_logic; 
             in_sel_mux13     : in    std_logic; 
             in_wbank0        : in    std_logic; 
             in_wbank1        : in    std_logic; 
             in_D11           : in    std_logic_vector (7 downto 0); 
             in_D22           : in    std_logic_vector (7 downto 0); 
             in_R_A           : in    std_logic_vector (7 downto 0); 
             in_R_B           : in    std_logic_vector (7 downto 0); 
             in_sel_mux11     : in    std_logic_vector (1 downto 0); 
             out_w_A          : out   std_logic; 
             out_w_B          : out   std_logic; 
             out_sel_nux10    : out   std_logic; 
             out_sp_load      : out   std_logic; 
             out_sel_mux18    : out   std_logic; 
             out_sel_addr_dec : out   std_logic; 
             out_sel_mux13    : out   std_logic; 
             out_wbank0       : out   std_logic; 
             out_wbank1       : out   std_logic; 
             out_D11          : out   std_logic_vector (7 downto 0); 
             out_D22          : out   std_logic_vector (7 downto 0); 
             out_R_A          : out   std_logic_vector (7 downto 0); 
             out_R_B          : out   std_logic_vector (7 downto 0); 
             out_sel_mux11    : out   std_logic_vector (1 downto 0); 
             in_en            : in    std_logic_vector (1 downto 0); 
             out_en           : out   std_logic_vector (1 downto 0));
   end component;
   
   component execute
      port ( rst       : in    std_logic; 
             ac_in     : in    std_logic; 
             cy_in     : in    std_logic; 
             AA        : in    std_logic_vector (7 downto 0); 
             BB        : in    std_logic_vector (7 downto 0); 
             D1        : in    std_logic_vector (7 downto 0); 
             D2        : in    std_logic_vector (7 downto 0); 
             OPCode    : in    std_logic_vector (4 downto 0); 
             s1        : in    std_logic_vector (7 downto 0); 
             s2        : in    std_logic_vector (7 downto 0); 
             sel_mux16 : in    std_logic_vector (1 downto 0); 
             sel_mux17 : in    std_logic_vector (1 downto 0); 
             sel       : in    std_logic_vector (3 downto 0); 
             RA_in     : in    std_logic_vector (7 downto 0); 
             RB_in     : in    std_logic_vector (7 downto 0); 
             ac_out    : out   std_logic; 
             cy_out    : out   std_logic; 
             ov        : out   std_logic; 
             RA_out    : out   std_logic_vector (7 downto 0); 
             RB_out    : out   std_logic_vector (7 downto 0));
   end component;
   
   component ifid
      port ( clk  : in    std_logic; 
             rst  : in    std_logic; 
             hold : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             in3  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0); 
             out2 : out   std_logic_vector (7 downto 0); 
             out3 : out   std_logic_vector (7 downto 0));
   end component;
   
   component idex
      port ( clk              : in    std_logic; 
             rst              : in    std_logic; 
             in_w_A           : in    std_logic; 
             in_w_B           : in    std_logic; 
             in_sel_nux10     : in    std_logic; 
             in_sp_load       : in    std_logic; 
             in_sel_mux18     : in    std_logic; 
             in_sel_addr_dec  : in    std_logic; 
             in_sel_mux13     : in    std_logic; 
             in_wbank0        : in    std_logic; 
             in_wbank1        : in    std_logic; 
             in_s1            : in    std_logic_vector (7 downto 0); 
             in_s2            : in    std_logic_vector (7 downto 0); 
             in_d1            : in    std_logic_vector (7 downto 0); 
             in_d2            : in    std_logic_vector (7 downto 0); 
             in_A             : in    std_logic_vector (7 downto 0); 
             in_B             : in    std_logic_vector (7 downto 0); 
             in_Opcode        : in    std_logic_vector (4 downto 0); 
             in_sel           : in    std_logic_vector (3 downto 0); 
             in_sel_mux16     : in    std_logic_vector (1 downto 0); 
             in_sel_mux17     : in    std_logic_vector (1 downto 0); 
             in_sel_mux11     : in    std_logic_vector (1 downto 0); 
             in_en            : in    std_logic_vector (1 downto 0); 
             out_w_A          : out   std_logic; 
             out_w_B          : out   std_logic; 
             out_sel_nux10    : out   std_logic; 
             out_sp_load      : out   std_logic; 
             out_sel_mux18    : out   std_logic; 
             out_sel_addr_dec : out   std_logic; 
             out_sel_mux13    : out   std_logic; 
             out_wbank0       : out   std_logic; 
             out_wbank1       : out   std_logic; 
             out_s1           : out   std_logic_vector (7 downto 0); 
             out_s2           : out   std_logic_vector (7 downto 0); 
             out_d1           : out   std_logic_vector (7 downto 0); 
             out_d2           : out   std_logic_vector (7 downto 0); 
             out_A            : out   std_logic_vector (7 downto 0); 
             out_B            : out   std_logic_vector (7 downto 0); 
             out_Opcode       : out   std_logic_vector (4 downto 0); 
             out_sel          : out   std_logic_vector (3 downto 0); 
             out_sel_mux16    : out   std_logic_vector (1 downto 0); 
             out_sel_mux17    : out   std_logic_vector (1 downto 0); 
             out_sel_mux11    : out   std_logic_vector (1 downto 0); 
             out_en           : out   std_logic_vector (1 downto 0));
   end component;
   
   component i8051rom
      port ( rst         : in    std_logic; 
             clk         : in    std_logic; 
             rd          : in    std_logic; 
             ADDRESS_BUS : in    std_logic_vector (15 downto 0); 
             DATA_BUS    : out   std_logic_vector (7 downto 0));
   end component;
   
   component contorl_unit
      port ( clk         : in    std_logic; 
             rst         : in    std_logic; 
             ac_in       : in    std_logic; 
             cy_in       : in    std_logic; 
             int0        : in    std_logic; 
             int1        : in    std_logic; 
             ov          : in    std_logic; 
             wr          : in    std_logic; 
             rd          : in    std_logic; 
             byte1       : in    std_logic_vector (7 downto 0); 
             byte2       : in    std_logic_vector (7 downto 0); 
             byte3       : in    std_logic_vector (7 downto 0); 
             psw_in      : in    std_logic_vector (7 downto 0); 
             ac_out      : out   std_logic; 
             cy_out      : out   std_logic; 
             sel_mux2    : out   std_logic; 
             sel_mux3    : out   std_logic; 
             sel_mux10   : out   std_logic; 
             sel_mux13   : out   std_logic; 
             sel_mux14   : out   std_logic; 
             sel_mux15   : out   std_logic; 
             sel_mux18   : out   std_logic; 
             sel_addr_de : out   std_logic; 
             sel_rd      : out   std_logic; 
             sel_as      : out   std_logic; 
             w_psw       : out   std_logic; 
             w_A         : out   std_logic; 
             w_B         : out   std_logic; 
             wbank0      : out   std_logic; 
             wbank1      : out   std_logic; 
             hold        : out   std_logic; 
             PC_load_in  : out   std_logic; 
             tmp_load_in : out   std_logic; 
             sp_load_in  : out   std_logic; 
             sel_mux1    : out   std_logic_vector (1 downto 0); 
             sel_mux4    : out   std_logic_vector (2 downto 0); 
             sel_mux5    : out   std_logic_vector (1 downto 0); 
             sel_mux6    : out   std_logic_vector (1 downto 0); 
             sel_mux7    : out   std_logic_vector (2 downto 0); 
             sel_mux8    : out   std_logic_vector (1 downto 0); 
             sel_mux9    : out   std_logic_vector (2 downto 0); 
             sel_mux11   : out   std_logic_vector (1 downto 0); 
             sel_mux12   : out   std_logic_vector (1 downto 0); 
             sel_mux16   : out   std_logic_vector (1 downto 0); 
             sel_mux17   : out   std_logic_vector (1 downto 0); 
             sel_forward : out   std_logic_vector (3 downto 0); 
             sel_jcall   : out   std_logic_vector (1 downto 0); 
             sel_bank    : out   std_logic_vector (1 downto 0); 
             EN_latch    : out   std_logic_vector (1 downto 0); 
             psw_out     : out   std_logic_vector (7 downto 0); 
             data_bus    : out   std_logic_vector (7 downto 0); 
             iqc         : in    std_logic_vector (1 downto 0));
   end component;
   
   component mux10131415
      port ( sel  : in    std_logic; 
             in1  : in    std_logic_vector (7 downto 0); 
             in2  : in    std_logic_vector (7 downto 0); 
             out1 : out   std_logic_vector (7 downto 0));
   end component;
   
begin
   XLXI_1 : writeback
      port map (d11(7 downto 0)=>XLXN_73(7 downto 0),      
                d22(7 downto 0)=>XLXN_556(7 downto 0),      
                R_A(7 downto 0)=>XLXN_75(7 downto 0),      
                R_B(7 downto 0)=>XLXN_77(7 downto 0),      
                sel_addr_decode=>XLXN_482,      
                sel_mux18=>XLXN_483,      
                out_A(7 downto 0)=>XLXN_600(7 downto 0),      
                out_B(7 downto 0)=>XLXN_599(7 downto 0),      
                w_addr(7 downto 0)=>XLXN_597(7 downto 0),      
                w_data(7 downto 0)=>XLXN_594(7 downto 0));
   
   XLXI_2 : decode_stage
      port map (bank(1 downto 0)=>XLXN_452(1 downto 0),      
                from_acc(7 downto 0)=>XLXN_574(7 downto 0),      
                from_b(7 downto 0)=>XLXN_575(7 downto 0),      
                from_mem(7 downto 0)=>XLXN_577(7 downto 0),      
                from_sfr(7 downto 0)=>XLXN_577(7 downto 0),      
                inst_b1(7 downto 0)=>XLXN_281(7 downto 0),      
                inst_b2(7 downto 0)=>XLXN_798(7 downto 0),      
                inst_b3(7 downto 0)=>XLXN_791(7 downto 0),      
                in_r0(7 downto 0)=>XLXN_583(7 downto 0),      
                in_r1(7 downto 0)=>XLXN_584(7 downto 0),      
                reset=>Reset,      
                sel_mux6(1 downto 0)=>XLXN_467(1 downto 0),      
                sel_mux7(2 downto 0)=>XLXN_465(2 downto 0),      
                sel_mux8(1 downto 0)=>XLXN_461(1 downto 0),      
                sel_mux9(2 downto 0)=>XLXN_462(2 downto 0),      
                alu_oprt(4 downto 0)=>XLXN_619(4 downto 0),      
                d1(7 downto 0)=>XLXN_63(7 downto 0),      
                d2(7 downto 0)=>XLXN_62(7 downto 0),      
                reg_aa(7 downto 0)=>XLXN_61(7 downto 0),      
                reg_bb(7 downto 0)=>XLXN_130(7 downto 0),      
                r_addr(7 downto 0)=>XLXN_585(7 downto 0),      
                s1(7 downto 0)=>XLXN_59(7 downto 0),      
                s2(7 downto 0)=>XLXN_64(7 downto 0));
   
   XLXI_4 : fetch
      port map (acc_in(7 downto 0)=>XLXN_574(7 downto 0),      
                clock=>Clock,      
                data_bus(7 downto 0)=>XLXN_786(7 downto 0),      
                DPTR_in(15 downto 0)=>XLXN_568(15 downto 0),      
                ex_byte1(7 downto 0)=>XLXN_281(7 downto 0),      
                ex_byte2(7 downto 0)=>XLXN_798(7 downto 0),      
                ex_byte3(7 downto 0)=>XLXN_791(7 downto 0),      
                from_internal_data_memory(15 downto 0)=>XLXN_566(15 downto 0),      
                PC_load_in16=>XLXN_438,      
                reset=>Reset,      
                sel_jcall(1 downto 0)=>XLXN_788(1 downto 0),      
                sel_mux1(1 downto 0)=>XLXN_443(1 downto 0),      
                sel_mux2=>XLXN_444,      
                sel_mux3=>XLXN_445,      
                sel_mux4(2 downto 0)=>XLXN_446(2 downto 0),      
                sel_mux5(1 downto 0)=>XLXN_447(1 downto 0),      
                temp1_load_in=>XLXN_441,      
                address_bus(15 downto 0)=>XLXN_613(15 downto 0),      
                instruction_byte1(7 downto 0)=>XLXN_3(7 downto 0),      
                instruction_byte2(7 downto 0)=>XLXN_2(7 downto 0),      
                instruction_byte3(7 downto 0)=>XLXN_1(7 downto 0),      
                iqc(1 downto 0)=>XLXN_799(1 downto 0),      
                pc_resent(15 downto 0)=>XLXN_573(15 downto 0));
   
   XLXI_8 : mem_unit
      port map (clk=>Clock,      
                Din0(7 downto 0)=>XLXN_594(7 downto 0),      
                Din1(7 downto 0)=>XLXN_594(7 downto 0),      
                di_A(7 downto 0)=>XLXN_600(7 downto 0),      
                di_B(7 downto 0)=>XLXN_599(7 downto 0),      
                di_psw(7 downto 0)=>XLXN_592(7 downto 0),      
                en(1 downto 0)=>XLXN_601(1 downto 0),      
                load_in=>XLXN_607,      
                PC_in(15 downto 0)=>XLXN_573(15 downto 0),      
                p0_in(7 downto 0)=>P0_in(7 downto 0),      
                p1_in(7 downto 0)=>P1_in(7 downto 0),      
                p2_in(7 downto 0)=>P2_in(7 downto 0),      
                p3_in(7 downto 0)=>P3_in(7 downto 0),      
                rst=>Reset,      
                r_addr(7 downto 0)=>XLXN_585(7 downto 0),      
                sel_as=>XLXN_562,      
                sel_mux10=>XLXN_608,      
                sel_mux11(1 downto 0)=>XLXN_606(1 downto 0),      
                sel_mux12(1 downto 0)=>XLXN_565(1 downto 0),      
                sel_mux13=>XLXN_605,      
                sel_mux14=>XLXN_588,      
                sel_mux15=>XLXN_589,      
                wr_bank0=>XLXN_604,      
                wr_bank1=>XLXN_603,      
                W_A=>XLXN_611,      
                w_addr(7 downto 0)=>XLXN_597(7 downto 0),      
                W_B=>XLXN_610,      
                W_psw=>XLXN_593,      
                do_A(7 downto 0)=>XLXN_574(7 downto 0),      
                do_B(7 downto 0)=>XLXN_575(7 downto 0),      
                do_psw(7 downto 0)=>XLXN_590(7 downto 0),      
                dptr(15 downto 0)=>XLXN_568(15 downto 0),      
                mux15(7 downto 0)=>XLXN_577(7 downto 0),      
                PC_out(15 downto 0)=>XLXN_566(15 downto 0),      
                p0_out(7 downto 0)=>P0_out(7 downto 0),      
                p1_out(7 downto 0)=>P1_out(7 downto 0),      
                p2_out(7 downto 0)=>P2_out(7 downto 0),      
                p3_out(7 downto 0)=>P3_out(7 downto 0),      
                R0(7 downto 0)=>XLXN_583(7 downto 0),      
                R1(7 downto 0)=>XLXN_584(7 downto 0));
   
   XLXI_9 : exwb
      port map (clk=>Clock,      
                in_D11(7 downto 0)=>XLXN_71(7 downto 0),      
                in_D22(7 downto 0)=>XLXN_72(7 downto 0),      
                in_en(1 downto 0)=>XLXN_617(1 downto 0),      
                in_R_A(7 downto 0)=>XLXN_70(7 downto 0),      
                in_R_B(7 downto 0)=>XLXN_69(7 downto 0),      
                in_sel_addr_dec=>XLXN_472,      
                in_sel_mux11(1 downto 0)=>XLXN_481(1 downto 0),      
                in_sel_mux13=>XLXN_480,      
                in_sel_mux18=>XLXN_473,      
                in_sel_nux10=>XLXN_558,      
                in_sp_load=>XLXN_557,      
                in_wbank0=>XLXN_479,      
                in_wbank1=>XLXN_478,      
                in_w_A=>XLXN_560,      
                in_w_B=>XLXN_559,      
                rst=>Reset,      
                out_D11(7 downto 0)=>XLXN_73(7 downto 0),      
                out_D22(7 downto 0)=>XLXN_556(7 downto 0),      
                out_en(1 downto 0)=>XLXN_601(1 downto 0),      
                out_R_A(7 downto 0)=>XLXN_75(7 downto 0),      
                out_R_B(7 downto 0)=>XLXN_77(7 downto 0),      
                out_sel_addr_dec=>XLXN_482,      
                out_sel_mux11(1 downto 0)=>XLXN_606(1 downto 0),      
                out_sel_mux13=>XLXN_605,      
                out_sel_mux18=>XLXN_483,      
                out_sel_nux10=>XLXN_608,      
                out_sp_load=>XLXN_607,      
                out_wbank0=>XLXN_604,      
                out_wbank1=>XLXN_603,      
                out_w_A=>XLXN_611,      
                out_w_B=>XLXN_610);
   
   XLXI_14 : execute
      port map (AA(7 downto 0)=>XLXN_18(7 downto 0),      
                ac_in=>XLXN_485,      
                BB(7 downto 0)=>XLXN_19(7 downto 0),      
                cy_in=>XLXN_487,      
                D1(7 downto 0)=>XLXN_73(7 downto 0),      
                D2(7 downto 0)=>XLXN_556(7 downto 0),      
                OPCode(4 downto 0)=>XLXN_618(4 downto 0),      
                RA_in(7 downto 0)=>XLXN_75(7 downto 0),      
                RB_in(7 downto 0)=>XLXN_77(7 downto 0),      
                rst=>Reset,      
                sel(3 downto 0)=>XLXN_521(3 downto 0),      
                sel_mux16(1 downto 0)=>XLXN_523(1 downto 0),      
                sel_mux17(1 downto 0)=>XLXN_522(1 downto 0),      
                s1(7 downto 0)=>XLXN_14(7 downto 0),      
                s2(7 downto 0)=>XLXN_15(7 downto 0),      
                ac_out=>XLXN_547,      
                cy_out=>XLXN_546,      
                ov=>XLXN_545,      
                RA_out(7 downto 0)=>XLXN_70(7 downto 0),      
                RB_out(7 downto 0)=>XLXN_69(7 downto 0));
   
   XLXI_15 : ifid
      port map (clk=>Clock,      
                hold=>XLXN_456,      
                in1(7 downto 0)=>XLXN_3(7 downto 0),      
                in2(7 downto 0)=>XLXN_2(7 downto 0),      
                in3(7 downto 0)=>XLXN_1(7 downto 0),      
                rst=>Reset,      
                out1(7 downto 0)=>XLXN_281(7 downto 0),      
                out2(7 downto 0)=>XLXN_798(7 downto 0),      
                out3(7 downto 0)=>XLXN_791(7 downto 0));
   
   XLXI_20 : idex
      port map (clk=>Clock,      
                in_A(7 downto 0)=>XLXN_61(7 downto 0),      
                in_B(7 downto 0)=>XLXN_130(7 downto 0),      
                in_d1(7 downto 0)=>XLXN_63(7 downto 0),      
                in_d2(7 downto 0)=>XLXN_62(7 downto 0),      
                in_en(1 downto 0)=>XLXN_615(1 downto 0),      
                in_Opcode(4 downto 0)=>XLXN_619(4 downto 0),      
                in_sel(3 downto 0)=>XLXN_543(3 downto 0),      
                in_sel_addr_dec=>XLXN_490,      
                in_sel_mux11(1 downto 0)=>XLXN_513(1 downto 0),      
                in_sel_mux13=>XLXN_518,      
                in_sel_mux16(1 downto 0)=>XLXN_541(1 downto 0),      
                in_sel_mux17(1 downto 0)=>XLXN_542(1 downto 0),      
                in_sel_mux18=>XLXN_491,      
                in_sel_nux10=>XLXN_552,      
                in_sp_load=>XLXN_554,      
                in_s1(7 downto 0)=>XLXN_59(7 downto 0),      
                in_s2(7 downto 0)=>XLXN_64(7 downto 0),      
                in_wbank0=>XLXN_515,      
                in_wbank1=>XLXN_512,      
                in_w_A=>XLXN_548,      
                in_w_B=>XLXN_550,      
                rst=>Reset,      
                out_A(7 downto 0)=>XLXN_18(7 downto 0),      
                out_B(7 downto 0)=>XLXN_19(7 downto 0),      
                out_d1(7 downto 0)=>XLXN_71(7 downto 0),      
                out_d2(7 downto 0)=>XLXN_72(7 downto 0),      
                out_en(1 downto 0)=>XLXN_617(1 downto 0),      
                out_Opcode(4 downto 0)=>XLXN_618(4 downto 0),      
                out_sel(3 downto 0)=>XLXN_521(3 downto 0),      
                out_sel_addr_dec=>XLXN_472,      
                out_sel_mux11(1 downto 0)=>XLXN_481(1 downto 0),      
                out_sel_mux13=>XLXN_480,      
                out_sel_mux16(1 downto 0)=>XLXN_523(1 downto 0),      
                out_sel_mux17(1 downto 0)=>XLXN_522(1 downto 0),      
                out_sel_mux18=>XLXN_473,      
                out_sel_nux10=>XLXN_558,      
                out_sp_load=>XLXN_557,      
                out_s1(7 downto 0)=>XLXN_14(7 downto 0),      
                out_s2(7 downto 0)=>XLXN_15(7 downto 0),      
                out_wbank0=>XLXN_479,      
                out_wbank1=>XLXN_478,      
                out_w_A=>XLXN_560,      
                out_w_B=>XLXN_559);
   
   XLXI_21 : i8051rom
      port map (ADDRESS_BUS(15 downto 0)=>XLXN_613(15 downto 0),      
                clk=>Clock,      
                rd=>XLXN_627,      
                rst=>Reset,      
                DATA_BUS(7 downto 0)=>XLXN_628(7 downto 0));
   
   XLXI_22 : contorl_unit
      port map (ac_in=>XLXN_547,      
                byte1(7 downto 0)=>XLXN_281(7 downto 0),      
                byte2(7 downto 0)=>XLXN_798(7 downto 0),      
                byte3(7 downto 0)=>XLXN_791(7 downto 0),      
                clk=>Clock,      
                cy_in=>XLXN_546,      
                int0=>int0,      
                int1=>int1,      
                iqc(1 downto 0)=>XLXN_799(1 downto 0),      
                ov=>XLXN_545,      
                psw_in(7 downto 0)=>XLXN_590(7 downto 0),      
                rd=>rd,      
                rst=>Reset,      
                wr=>wr,      
                ac_out=>XLXN_485,      
                cy_out=>XLXN_487,      
                data_bus(7 downto 0)=>XLXN_626(7 downto 0),      
                EN_latch(1 downto 0)=>XLXN_615(1 downto 0),      
                hold=>XLXN_456,      
                PC_load_in=>XLXN_438,      
                psw_out(7 downto 0)=>XLXN_592(7 downto 0),      
                sel_addr_de=>XLXN_490,      
                sel_as=>XLXN_562,      
                sel_bank(1 downto 0)=>XLXN_452(1 downto 0),      
                sel_forward(3 downto 0)=>XLXN_543(3 downto 0),      
                sel_jcall(1 downto 0)=>XLXN_788(1 downto 0),      
                sel_mux1(1 downto 0)=>XLXN_443(1 downto 0),      
                sel_mux2=>XLXN_444,      
                sel_mux3=>XLXN_445,      
                sel_mux4(2 downto 0)=>XLXN_446(2 downto 0),      
                sel_mux5(1 downto 0)=>XLXN_447(1 downto 0),      
                sel_mux6(1 downto 0)=>XLXN_467(1 downto 0),      
                sel_mux7(2 downto 0)=>XLXN_465(2 downto 0),      
                sel_mux8(1 downto 0)=>XLXN_461(1 downto 0),      
                sel_mux9(2 downto 0)=>XLXN_462(2 downto 0),      
                sel_mux10=>XLXN_552,      
                sel_mux11(1 downto 0)=>XLXN_513(1 downto 0),      
                sel_mux12(1 downto 0)=>XLXN_565(1 downto 0),      
                sel_mux13=>XLXN_518,      
                sel_mux14=>XLXN_588,      
                sel_mux15=>XLXN_589,      
                sel_mux16(1 downto 0)=>XLXN_541(1 downto 0),      
                sel_mux17(1 downto 0)=>XLXN_542(1 downto 0),      
                sel_mux18=>XLXN_491,      
                sel_rd=>XLXN_627,      
                sp_load_in=>XLXN_554,      
                tmp_load_in=>XLXN_441,      
                wbank0=>XLXN_515,      
                wbank1=>XLXN_512,      
                w_A=>XLXN_548,      
                w_B=>XLXN_550,      
                w_psw=>XLXN_593);
   
   XLXI_25 : mux10131415
      port map (in1(7 downto 0)=>XLXN_626(7 downto 0),      
                in2(7 downto 0)=>XLXN_628(7 downto 0),      
                sel=>XLXN_627,      
                out1(7 downto 0)=>XLXN_786(7 downto 0));
   
end BEHAVIORAL;


