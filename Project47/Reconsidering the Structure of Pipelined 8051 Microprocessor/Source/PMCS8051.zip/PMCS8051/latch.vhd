library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

--  Uncomment the following lines to use the declarations that are
--  provided for instantiating Xilinx primitive components.
--library UNISIM;
--use UNISIM.VComponents.all;

entity latch is
    Port ( in1 : in std_logic_vector(7 downto 0);--pch
	 		  in2 : in std_logic_vector(7 downto 0);--pcl
	 		  in3 : in std_logic_vector(7 downto 0);--d0
	 		  in4 : in std_logic_vector(7 downto 0);--d1
			  
           en : in std_logic_vector(1 downto 0);

           out1 : out std_logic_vector(7 downto 0);
           out2 : out std_logic_vector(7 downto 0));
end latch;

architecture Behavioral of latch is

begin
		process(en, in1, in2, in3, in4)
		begin
				case en is
					when "00" =>	out1 <= in1;
										out2 <= in2;
					when "01" =>	out1 <= in2;
										out2 <= in1;
					when "10" =>	out1 <= in3;
										out2 <= in4;
					when "11" =>	out1 <= in4;
										out2 <= in3;
					when others => null;
				end case;
		end process;
end Behavioral;
