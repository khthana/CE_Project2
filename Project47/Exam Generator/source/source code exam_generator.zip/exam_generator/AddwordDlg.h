#if !defined(AFX_ADDWORDDLG_H__EEB1910D_A8DB_49D0_B455_34457D90E84E__INCLUDED_)
#define AFX_ADDWORDDLG_H__EEB1910D_A8DB_49D0_B455_34457D90E84E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddwordDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddwordDlg dialog

class CAddwordDlg : public CDialog
{
// Construction
public:
	CAddwordDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddwordDlg)
	enum { IDD = IDD_ADDWORD };
	CString	m_newword;
	BOOL	m_noun;
	BOOL	m_verb;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddwordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddwordDlg)
	virtual void OnOK();
	afx_msg void OnAdd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDWORDDLG_H__EEB1910D_A8DB_49D0_B455_34457D90E84E__INCLUDED_)
