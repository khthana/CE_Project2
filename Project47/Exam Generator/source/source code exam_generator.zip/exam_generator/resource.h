//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by exam_generator.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EXAM_GENERATOR_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_ADDWORD                     129
#define IDD_DATAEXAM                    130
#define IDR_MENU1                       131
#define IDC_SOURCE                      1000
#define IDC_RESULT                      1001
#define IDC_COUNT                       1002
#define IDC_ADDKEY                      1003
#define IDC_DELKEY                      1004
#define IDC_BROWSE                      1005
#define IDC_WRAP                        1006
#define IDC_WORD                        1006
#define IDC_EXAM                        1007
#define IDC_NEWWORD                     1008
#define IDC_DELKEY2                     1008
#define IDC_ADD                         1009
#define IDC_EDIT1                       1010
#define IDC_EDIT2                       1011
#define IDC_EDIT3                       1012
#define IDC_EDIT4                       1013
#define IDC_EDIT5                       1014
#define IDC_NOUN                        1016
#define IDC_NOTNOUN                     1017
#define IDC_SPLIT                       1018
#define IDC_EDIT6                       1019
#define IDC_COMBO1                      1020
#define IDC_VERB                        1022
#define IDC_ADDTOKEY                    1023
#define IDC_CO                          1024
#define IDC_CH                          1025
#define IDC_IN                          1026
#define IDC_DE                          1027
#define IDC_TR                          1028
#define IDC_NCO                         1029
#define IDC_NCH                         1030
#define IDC_EDITDATA                    1031
#define IDC_TYPE                        1032
#define IDC_RADIO2                      1033
#define IDC_LEN                         1034
#define IDC_FRE                         1035
#define ID_KEYWORD_SHOWCONJ             32772
#define ID_SORT_FOUND                   32773
#define ID_SORT_ALA                     32774
#define ID_SORT_ALD                     32775
#define ID_SORT_AMA                     32776
#define ID_SORT_AMD                     32777
#define INPUT_DATA                      32778
#define IDC_ADDNEW                      32780
#define IDC_SAVE                        32781
#define IDC_LOAD                        32782
#define IDC_SAVE_EXAM                   32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
