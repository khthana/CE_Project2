#include <stdlib.h>
#include <string.h>


/*class Tnode
find--> find word 's' in tree 'p' return pointer to that node
insert--> insert word 's' in tree 'p' return pointer to new node
*/
typedef struct Tnode* Tptr;
struct Tnode
{
	char data;
	int st;
	Tptr child,next;

Tnode()
{
	st=10000;
	child=NULL;
	next=NULL;
}

~Tnode()
{
	if(child!=NULL)
		delete child;
	if(next!=NULL)
		delete next;
}

Tptr walk(Tptr p,char s)
{
	if(!p)
	{
		return NULL;
	}
	if(s==p->data)
	{
		return p;
	}
	else 
	{
		return walk(p->next,s);
	}
}

Tptr find(Tptr p,char* s)
{
	Tptr o=p;
	while(*s&&o)
	{
		o=walk(o,*s);
		if(strlen(s)>1&&o)
		{
			o=o->child;
		}
		s++;
	}
	return o;
}

Tptr insert(Tptr p,char* s,int type)
{
	if(p==NULL)
	{
		p=new Tnode;
		p->data=*s;
		p->st=10000;
		p->next=p->child=NULL;
	}
	else
	{
		if(p->data>*s)
		{
			Tptr t=p;
			p=new Tnode;
			p->data=*s;
			p->st=10000;
			p->next=t;
			p->child=NULL;
		}
	}
	if(*s != p->data)
	{
		p->next=insert(p->next,s,type);
	}
	else
	{
		if(*s==p->data)
		{
			if(strlen(s)>1)
			{
				p->child=insert(p->child,++s,type);
			}
			else
			{
				p->st=type;
			}
		}
	}
	return p;
}

CString print(Tptr p)
{
	CString aa;
	if(p->st!=10000)
	{
		return p->data;
	}
	else
	{
		if(p->child!=NULL)
		{
			aa=print(p->child);
			if(aa!="")
			{
				return (p->data)+aa;
			}
		}
		if(p->next!=NULL)
		{
			aa=print(p->next);
			return aa;
		}
		else
		{
			return "";
		}
	}
	return "";
}

};
