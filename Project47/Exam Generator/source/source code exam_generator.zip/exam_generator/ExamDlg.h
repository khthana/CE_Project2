#if !defined(AFX_EXAMDLG_H__B37E8861_7357_4DA7_A76D_E47A7284542B__INCLUDED_)
#define AFX_EXAMDLG_H__B37E8861_7357_4DA7_A76D_E47A7284542B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExamDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExamDlg dialog

class CExamDlg : public CDialog
{
// Construction
public:
	int nch;
	CExamDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CExamDlg)
	enum { IDD = IDD_DATAEXAM };
	int		m_in;
	int		m_co;
	int		m_de;
	int		m_tr;
	int		m_ch;
	int		m_nco;
	CString	m_nch;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExamDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExamDlg)
	virtual void OnOK();
	afx_msg void OnChangeEdit1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXAMDLG_H__B37E8861_7357_4DA7_A76D_E47A7284542B__INCLUDED_)
