// ExamDlg.cpp : implementation file
//

#include "stdafx.h"
#include "exam_generator.h"
#include "ExamDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExamDlg dialog


CExamDlg::CExamDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExamDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExamDlg)
	m_in = 0;
	m_co = 0;
	m_de = 0;
	m_tr = 0;
	m_ch = 0;
	m_nco = 0;
	m_nch = _T("4");
	//}}AFX_DATA_INIT
}


void CExamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExamDlg)
	DDX_Text(pDX, IDC_EDIT2, m_in);
	DDV_MinMaxInt(pDX, m_in, 0, 10000);
	DDX_Text(pDX, IDC_EDIT1, m_co);
	DDV_MinMaxInt(pDX, m_co, 0, 10000);
	DDX_Text(pDX, IDC_EDIT3, m_de);
	DDV_MinMaxInt(pDX, m_de, 0, 10000);
	DDX_Text(pDX, IDC_EDIT4, m_tr);
	DDV_MinMaxInt(pDX, m_tr, 0, 10000);
	DDX_Text(pDX, IDC_EDIT5, m_ch);
	DDV_MinMaxInt(pDX, m_ch, 0, 10000);
	DDX_Text(pDX, IDC_EDIT6, m_nco);
	DDV_MinMaxInt(pDX, m_nco, 0, 10000);
	DDX_CBString(pDX, IDC_COMBO1, m_nch);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExamDlg, CDialog)
	//{{AFX_MSG_MAP(CExamDlg)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExamDlg message handlers

void CExamDlg::OnOK() 
{
	// TODO: Add extra validation here
	int re=IDOK;
	CString mess="";
	UpdateData(true);
	if(m_nco<m_co)
	{
		mess="-�ӹǹ������͡�ͧ����ͺ�Ѻ���е�ͧ�����ҧ������ҡѺ�ӹǹ�Ӷ��";
		m_nco=m_co;
	}
	if((m_nch!="2")&&(m_nch!="3")&&(m_nch!="4")&&(m_nch!="5")&&(m_nch!="6"))
	{
		if(mess!="")
			mess=mess+"\n";
		mess=mess+"-�ӹǹ������͡�ͧ����ͺẺ������͡�е�ͧ���������ҧ 2-6 ������͡";
		m_nch="4";
	}
	if(mess!="")
	{
		mess=mess+"\n                     �����������¹�繤�ҷ���������";
		re=AfxMessageBox(mess,MB_OKCANCEL);
	}
	UpdateData(false);
	switch(m_nch[0])
	{
	case('2'): nch=2; break;
	case('3'): nch=3; break;
	case('4'): nch=4; break;
	case('5'): nch=5; break;
	case('6'): nch=6; break;
	}
	if(re==IDOK)
	{
		CDialog::OnOK();
	}
}


void CExamDlg::OnChangeEdit1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	if(m_nco<m_co)
		m_nco=m_co;
	UpdateData(false);
}
