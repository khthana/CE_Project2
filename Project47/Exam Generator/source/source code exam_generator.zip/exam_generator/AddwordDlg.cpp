// AddwordDlg.cpp : implementation file
//

#include "stdafx.h"
#include "exam_generator.h"
#include "AddwordDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddwordDlg dialog


CAddwordDlg::CAddwordDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddwordDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddwordDlg)
	m_newword = _T("");
	m_noun = FALSE;
	m_verb = FALSE;
	//}}AFX_DATA_INIT
}


void CAddwordDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddwordDlg)
	DDX_Text(pDX, IDC_NEWWORD, m_newword);
	DDV_MaxChars(pDX, m_newword, 100);
	DDX_Check(pDX, IDC_NOUN, m_noun);
	DDX_Check(pDX, IDC_VERB, m_verb);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddwordDlg, CDialog)
	//{{AFX_MSG_MAP(CAddwordDlg)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddwordDlg message handlers

void CAddwordDlg::OnOK() 
{
	// TODO: Add extra validation here
	OnAdd();
	CDialog::OnOK();
}

void CAddwordDlg::OnAdd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	int noun=0,verb=0;
	if(m_newword.GetLength()!=0)
	{
		CString pname=AfxGetApp()->m_pszHelpFilePath;
		int sp=pname.ReverseFind('\\');
		pname.Delete(sp+1,pname.GetLength()-(sp+1));
		ofstream outfile1(pname+"newspelldict",ios::app);
		if(m_noun)
		{
			noun=1;
		}
		if(m_verb)
		{
			verb=1;
		}
		outfile1<<m_newword<<" "<<noun<<verb<<"\n";
		outfile1.close();
		m_newword="";
	}
	m_noun=false;
	m_verb=false;
	UpdateData(FALSE);
}
