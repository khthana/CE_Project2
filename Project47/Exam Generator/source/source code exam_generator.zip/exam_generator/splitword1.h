#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <string.h>
#include "dict.h"



class Node
{
public:
	char* str;
	int amount;
	Node* next;

	Node(char* a,int b)
	{
		str=new char[strlen(a)];
		str=strcpy(str,a);
		amount=b;
		next=NULL;
	}
	~Node()
	{
		if(next!=NULL)
		{
			delete next;
		}
	}
	int add(void)
	{
		amount++;
		return amount;
	}
};

class List
{	
public:
	Node *first,*last,*now;
	int count;
	List()
	{
		first=new Node("",0);
		last=first;
		now=first;
		count=0;
	}
	~List()
	{
		if(first!=NULL)
		{
			delete first;
			first=NULL;
		}
	}
	void addnode(char* a)
	{
		last->next=new Node(a,1);
		last=last->next;
		count=count+1;
	}
	void addptr(char* a,int b,Node* c)
	{
		Node* n=new Node(a,b);
		n->next=c->next;
		c->next=n;
		if(c==last)
		{
			last=n;
		}
		count=count+1;
	}
	void searchword(char* a)
	{
		bool find=false;
		now=first;
		int count;
		do
		{
			if (strcmp(now->str,a)==0)
			{
				count=now->add();
				if(count>first->amount)
				{
					first->amount=count;
				}
				find=true;
				break;
			}
			else
			{
				now=now->next;
			}
		}
		while(now!=NULL);
		if (!find)
		{
			addnode(a);
		}
	}

	bool findword(char* a)
	{
		bool find=false;
		now=first;
		int count;
		do
		{
			if (strcmp(now->str,a)==0)
			{
				count=now->add();
				if(count>first->amount)
				{
					first->amount=count;
				}
				find=true;
				break;
			}
			else
			{
				now=now->next;
			}
		}
		while((now!=NULL)||(find==true));
		return find;

	}

	void print (void)
	{
		CString pname=AfxGetApp()->m_pszHelpFilePath;
		int sp=pname.ReverseFind('\\');
		pname.Delete(sp+1,pname.GetLength()-(sp+1));
		ofstream outfile(pname+"thcount",ios::out);
		if(count!=0)
		{
			now=first->next;
			do
			{
				outfile<<now->str<<"\t"<<now->amount<<"\n";
				now=now->next;
			}
			while(now!=NULL);
		}
		outfile.close();
	}
};

