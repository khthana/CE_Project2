// exam_generator.h : main header file for the EXAM_GENERATOR application
//

#if !defined(AFX_EXAM_GENERATOR_H__12B433C3_6BD9_46EB_9C85_632311743476__INCLUDED_)
#define AFX_EXAM_GENERATOR_H__12B433C3_6BD9_46EB_9C85_632311743476__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include "splitword1.h"


/////////////////////////////////////////////////////////////////////////////
// CExam_generatorApp:
// See exam_generator.cpp for the implementation of this class
//

class CExam_generatorApp : public CWinApp
{
public:
	CExam_generatorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExam_generatorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CExam_generatorApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXAM_GENERATOR_H__12B433C3_6BD9_46EB_9C85_632311743476__INCLUDED_)
