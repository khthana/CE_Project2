// Examgen.h: interface for the Examgen class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXAMGEN_H__140029D3_BB54_4C59_9490_8E44917A5907__INCLUDED_)
#define AFX_EXAMGEN_H__140029D3_BB54_4C59_9490_8E44917A5907__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Examgen  
{
public:
	Examgen(List* a,int co,int n_co,int in,int de,int tr,int ch,int n_ch);
	CString Descripe(CString sen);
	CString Insertword(CString sen);
	CString Couple(CString sen);
	CString True_False(CString sen);
	CString Choice(CString sen,int n_ch);
private:
	CString tostring(int value);


};

#endif // !defined(AFX_EXAMGEN_H__140029D3_BB54_4C59_9490_8E44917A5907__INCLUDED_)
