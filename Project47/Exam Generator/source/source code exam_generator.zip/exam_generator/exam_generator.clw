; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CExam_generatorDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "exam_generator.h"

ClassCount=5
Class1=CExam_generatorApp
Class2=CExam_generatorDlg
Class3=CAboutDlg

ResourceCount=8
Resource1=IDD_DATAEXAM
Resource2=IDR_MAINFRAME
Resource3=IDD_EXAM_GENERATOR_DIALOG
Resource4=IDD_ABOUTBOX
Resource5=IDD_ABOUTBOX (English (U.S.))
Resource6=IDD_ADDWORD
Resource7=IDD_EXAM_GENERATOR_DIALOG (English (U.S.))
Class4=CAddwordDlg
Class5=CExamDlg
Resource8=IDR_MENU1

[CLS:CExam_generatorApp]
Type=0
HeaderFile=exam_generator.h
ImplementationFile=exam_generator.cpp
Filter=N

[CLS:CExam_generatorDlg]
Type=0
HeaderFile=exam_generatorDlg.h
ImplementationFile=exam_generatorDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_EDITDATA

[CLS:CAboutDlg]
Type=0
HeaderFile=exam_generatorDlg.h
ImplementationFile=exam_generatorDlg.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_EXAM_GENERATOR_DIALOG]
Type=1
Class=CExam_generatorDlg
ControlCount=42
Control1=IDC_SOURCE,edit,1353777604
Control2=IDC_RESULT,edit,1353777604
Control3=IDC_COUNT,listbox,1352728833
Control4=IDC_ADDKEY,button,1342242816
Control5=IDC_BROWSE,button,1342242816
Control6=IDC_SPLIT,button,1342242816
Control7=IDC_EXAM,button,1342242816
Control8=IDC_EDIT1,edit,1350631552
Control9=IDC_WORD,listbox,1352728833
Control10=IDC_ADDTOKEY,button,1342242816
Control11=IDC_DELKEY,button,1342242816
Control12=IDC_DELKEY2,button,1342242816
Control13=IDC_STATIC,button,1342177287
Control14=IDC_STATIC,static,1342308352
Control15=IDC_STATIC,static,1342308352
Control16=IDC_STATIC,static,1342308352
Control17=IDC_STATIC,static,1342308352
Control18=IDC_STATIC,static,1342308352
Control19=IDC_CO,static,1342308352
Control20=IDC_CH,static,1342308352
Control21=IDC_IN,static,1342308352
Control22=IDC_DE,static,1342308352
Control23=IDC_TR,static,1342308352
Control24=IDC_STATIC,static,1342308352
Control25=IDC_STATIC,static,1342308352
Control26=IDC_STATIC,static,1342308352
Control27=IDC_STATIC,static,1342308352
Control28=IDC_STATIC,static,1342308352
Control29=IDC_STATIC,static,1342308352
Control30=IDC_NCO,static,1342308352
Control31=IDC_NCH,static,1342308352
Control32=IDC_STATIC,static,1342308352
Control33=IDC_STATIC,static,1342308352
Control34=IDC_EDITDATA,button,1342242816
Control35=IDC_STATIC,static,1342308352
Control36=IDC_LEN,edit,1350631552
Control37=IDC_STATIC,static,1342308352
Control38=IDC_TYPE,button,1342308361
Control39=IDC_RADIO2,button,1342177289
Control40=IDC_FRE,edit,1350631552
Control41=IDC_STATIC,static,1342308352
Control42=IDC_STATIC,button,1342308359

[DLG:IDD_EXAM_GENERATOR_DIALOG (English (U.S.))]
Type=1
Class=CExam_generatorDlg
ControlCount=18
Control1=IDC_SOURCE,edit,1353777604
Control2=IDC_RESULT,edit,1353777604
Control3=IDC_COUNT,listbox,1352728833
Control4=IDC_ADDKEY,button,1342242816
Control5=IDC_BROWSE,button,1342242816
Control6=IDC_SPLIT,button,1342242816
Control7=IDC_EXAM,button,1342242816
Control8=IDC_EDIT1,edit,1350631552
Control9=IDC_WORD,listbox,1352728833
Control10=IDC_ADDTOKEY,button,1342242816
Control11=IDC_DELKEY,button,1342242816
Control12=IDC_DELKEY2,button,1342242816
Control13=IDC_STATIC,button,1342177287
Control14=IDC_STATIC,static,1342308352
Control15=IDC_STATIC,static,1342308352
Control16=IDC_STATIC,static,1342308352
Control17=IDC_STATIC,static,1342308352
Control18=IDC_STATIC,static,1342308352

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_ADDWORD]
Type=1
Class=CAddwordDlg
ControlCount=7
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_NEWWORD,edit,1350631552
Control4=IDC_ADD,button,1342242816
Control5=IDC_STATIC,button,1342177287
Control6=IDC_NOUN,button,1342242819
Control7=IDC_VERB,button,1342242819

[MNU:IDR_MENU1]
Type=1
Class=?
Command1=IDC_BROWSE
Command2=IDC_SAVE
Command3=IDC_LOAD
Command4=IDC_SAVE_EXAM
Command5=IDC_WRAP
Command6=ID_SORT_FOUND
Command7=ID_SORT_ALA
Command8=ID_SORT_ALD
Command9=ID_SORT_AMA
Command10=ID_SORT_AMD
Command11=INPUT_DATA
Command12=IDC_EXAM
Command13=IDC_ADDNEW
CommandCount=13

[CLS:CAddwordDlg]
Type=0
HeaderFile=AddwordDlg.h
ImplementationFile=AddwordDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_NOUN
VirtualFilter=dWC

[DLG:IDD_DATAEXAM]
Type=1
Class=CExamDlg
ControlCount=15
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308352
Control6=IDC_EDIT1,edit,1350639744
Control7=IDC_EDIT2,edit,1350639744
Control8=IDC_EDIT3,edit,1350639744
Control9=IDC_STATIC,static,1342308352
Control10=IDC_EDIT4,edit,1350639744
Control11=IDC_STATIC,static,1342308352
Control12=IDC_EDIT5,edit,1350639744
Control13=IDC_EDIT6,edit,1350631552
Control14=IDC_COMBO1,combobox,1344340226
Control15=IDC_STATIC,static,1342308352

[CLS:CExamDlg]
Type=0
HeaderFile=ExamDlg.h
ImplementationFile=ExamDlg.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_EDIT1

