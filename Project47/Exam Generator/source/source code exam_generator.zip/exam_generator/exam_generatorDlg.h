// exam_generatorDlg.h : header file
//

#if !defined(AFX_EXAM_GENERATORDLG_H__968314AA_3DFA_4299_9673_07E9201A31F3__INCLUDED_)
#define AFX_EXAM_GENERATORDLG_H__968314AA_3DFA_4299_9673_07E9201A31F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CExam_generatorDlg dialog

class CExam_generatorDlg : public CDialog
{
	bool bbrowse,bsplit,bexam,bexam_save,first_b;
	CString file_name;
// Construction
public:
	CExam_generatorDlg(CWnd* pParent = NULL);	// standard constructor
	void Sort(int cur);
	void UpdateWord();
	void UpdateKey();
	CString tostring(int value);

//	CString tostring(int value);

// Dialog Data
	//{{AFX_DATA(CExam_generatorDlg)
	enum { IDD = IDD_EXAM_GENERATOR_DIALOG };
	CListBox	m_word;
	CListBox	m_count;
	CString	m_result;
	CString	m_source;
	CString	m_addkey;
	CString	m_ch;
	CString	m_co;
	CString	m_de;
	CString	m_in;
	CString	m_nch;
	CString	m_nco;
	CString	m_tr;
	int		m_fre;
	int		m_type;
	UINT	m_len;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExam_generatorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CExam_generatorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBrowse();
	afx_msg void OnExam();
	afx_msg void OnSortAla();
	afx_msg void OnSortAld();
	afx_msg void OnSortAma();
	afx_msg void OnSortAmd();
	afx_msg void OnSortFound();
	afx_msg void OnAddnew();
	afx_msg void OnAddkey();
	afx_msg void OnDelkey();
	afx_msg void OnData();
	afx_msg void OnSplit();
	afx_msg void OnSaveCon();
	afx_msg void OnLoadcon();
	afx_msg void OnSaveExam();
	afx_msg void OnAddtokey();
	afx_msg void OnChangeSource();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXAM_GENERATORDLG_H__968314AA_3DFA_4299_9673_07E9201A31F3__INCLUDED_)
