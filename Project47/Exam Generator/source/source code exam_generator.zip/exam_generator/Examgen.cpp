// Examgen.cpp: implementation of the Examgen class.
//
//////////////////////////////////////////////////////////////////////

//#include <afx.h>
#include "stdafx.h"
#include "splitword1.h"
#include "Examgen.h"
#include "SepWord.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

List* keyword;

ofstream outfile1,outfile2,outfile3,outfile4,outfile5;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Examgen::Examgen(List* a,int co,int n_co,int in,int de,int tr,int ch,int n_ch)
{
	int ran,cos,step,count,n_sen=0;
	keyword=a;
	CString ques,str;
	int point_temp;
	CString pname=AfxGetApp()->m_pszHelpFilePath;
	int sp=pname.ReverseFind('\\');
	pname.Delete(sp+1,pname.GetLength()-(sp+1));
	outfile1.open(pname+"�����.txt",ios::out);
	outfile2.open(pname+"������.txt",ios::out);
	outfile3.open(pname+"�Ѻ���.txt",ios::out);
	outfile4.open(pname+"�١�Դ.txt",ios::out);
	outfile5.open(pname+"������͡.txt",ios::out);
	
	fstream infile1(pname+"th2",ios::in);
	fstream infile(pname+"test text.txt",ios::out);
	infile.close();
	infile.open(pname+"test text.txt",ios::out|ios::in);

	char chr[100]="";
	while(infile1>>chr)
	{
		infile<<chr<<" ";
	}

	infile.clear();
	infile.seekg(0, ios::beg);

	while(infile>>chr)
	{	
		if(strncmp(chr,"\\\\",2)==0)
		{
			n_sen++;
		}
	}
	infile.clear();
	infile.seekg(0, ios::beg);
	srand( (unsigned)time( NULL ) );
	ran=rand();

///////Couple/////////
	char* chr1=new char[1000];
	char chr2=' ';
	List* question;
	question=new List();
	if(co==0)
	{
		step=n_sen;
	}
	else
	{
		step=n_sen/co;
	}
	if(step==0) {step++;}
	cos=ran%step;
	count=co;
	int old_p=0,point=0;
	while((n_sen>0)&&(count>0)&&(step>0))
	{
		while((n_sen>0)&&(count>0)&&(infile>>chr))
		{	
			ques="";
			if(strncmp(chr,"\\\\",2)==0)
			{
				old_p=point;
				point=infile.tellg()-strlen(chr);
				if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Couple(str);
						cos=0;
					}
				}
				if(ques!="")
				{
					strcpy(chr1,"");
					for(int i=0;i<ques.GetLength();i++)
					{
						chr2=ques[i];
						chr1=strncat(chr1,&chr2,1);
					}
					question->addnode(chr1);
					n_sen--;
					count--;
					infile.clear();
					point_temp=infile.tellg();
					infile.seekp(old_p+2);
					infile<<"@";
					infile.seekg(point_temp);
						
				}
				str=chr;
			}
			else
			{
				str=str+" "+chr;
			}
		}
		ques="";
		if((n_sen>0)&&(count>0))
		{
			old_p=point;
			point=0;
			if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Couple(str);
						cos=0;
					}
				}
			if(ques!="")
			{
				strcpy(chr1,"");
				for(int i=0;i<ques.GetLength();i++)
				{
					chr2=ques[i];
					chr1=strncat(chr1,&chr2,1);
				}
				question->addnode(chr1);
				n_sen--;
				count--;
				infile.clear();
				point_temp=infile.tellg();
				infile.seekp(old_p+2);
				infile<<"@";
				infile.seekg(point_temp);
			}
		}
		step--;
		cos--;
		infile.clear();
		infile.seekg(0, ios::beg);
	}
	delete chr1;
	/////
	if(n_co>keyword->count)
	{
		n_co=keyword->count;
	}
	while(n_co>co)
	{
		keyword->now=keyword->first;
		count=(keyword->count-co)/(n_co-co+1);
		while((keyword->now!=keyword->last)&&(n_co>co))
		{
			keyword->now=keyword->now->next;
			if((keyword->now->amount!=2)&&(rand()%count==0))
			{
				keyword->now->amount=2;
				n_co--;
			}
		}
	}
	count=1;
	keyword->now=keyword->first;
	question->now=question->first;
	while(question->now!=question->last)
	{
		question->now=question->now->next;
		outfile3<<count<<". "<<question->now->str<<"\n";
		count++;
	}
	chr2='�';
	if(count!=1)
	{
		outfile3<<"\n";
		while(keyword->now!=keyword->last)
		{
			keyword->now=keyword->now->next;
			if(keyword->now->amount==2)
			{
				outfile3<<chr2<<". "<<keyword->now->str<<"\n";
				chr2++;
			}
		}
	}

	infile.clear();
	infile.seekg(0, ios::beg);
	
	///////Multiple Choice/////////
	if(ch==0)
	{
		step=n_sen;
	}
	else
	{
		step=n_sen/ch;
	}
	if(step==0) {step++;}
	cos=ran%step;
	count=ch;
	old_p=0,point=0;
		while((n_sen>0)&&(count>0)&&(step>0))
	{
		while((n_sen>0)&&(count>0)&&(infile>>chr))
		{	
			ques="";
			if(strncmp(chr,"\\\\",2)==0)
			{
				old_p=point;
				point=infile.tellg()-strlen(chr);
				if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Choice(str,n_ch);
						cos=0;
					}
				}
				if(ques!="")
				{
					outfile5<<ch-count+1<<". "<<ques<<"\n";
					n_sen--;
					count--;
					infile.clear();
					point_temp=infile.tellg();
					infile.seekp(old_p+2);
					infile<<"@";
					infile.seekg(point_temp);
				}
				str=chr;
			}
			else
			{
				str=str+" "+chr;
			}
		}
		ques="";
		if((n_sen>0)&&(count>0))
		{
			old_p=point;
			point=0;
			if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Choice(str,n_ch);
						cos=0;
					}
				}
			if(ques!="")
			{
				outfile5<<ch-count+1<<". "<<ques<<"\n";
				n_sen--;
				count--;
				infile.clear();
				point_temp=infile.tellg();
				infile.seekp(old_p+2);
				infile<<"@";
				infile.seekg(point_temp);
			}
		}
		step--;
		cos--;
		infile.clear();
		infile.seekg(0, ios::beg);
	}

	infile.clear();
	infile.seekg(0, ios::beg);
	
	///////True or False/////////
	if(tr==0)
	{
		step=n_sen;
	}
	else
	{
		step=n_sen/tr;
	}
	if(step==0) {step++;}
	cos=ran%step;
	count=tr;
	old_p=0,point=0;
	while((n_sen>0)&&(count>0)&&(step>0))
	{
		while((n_sen>0)&&(count>0)&&(infile>>chr))
		{
			ques="";
			if(strncmp(chr,"\\\\",2)==0)
			{
				old_p=point;
				point=infile.tellg()-strlen(chr);
				if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=True_False(str);
						cos=0;
					}
				}
				if(ques!="")
				{
					outfile4<<tr-count+1<<". "<<ques<<"\n";
					n_sen--;
					count--;
					infile.clear();
					point_temp=infile.tellg();
					infile.seekp(old_p+2);
					infile<<"@";
					infile.seekg(point_temp);
				}
				str=chr;
			}
			else
			{
				str=str+" "+chr;
			}
		}
		ques="";
		if((n_sen>0)&&(count>0))
		{
			old_p=point;
			point=0;
			if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=True_False(str);
						cos=0;
					}
				}
			if(ques!="")
			{
					outfile4<<tr-count+1<<". "<<ques<<"\n";
					n_sen--;
					count--;
					infile.clear();
					point_temp=infile.tellg();
					infile.seekp(old_p+2);
					infile<<"@";
					infile.seekg(point_temp);
			}
		}
		step--;
		cos--;
		infile.clear();
		infile.seekg(0, ios::beg);
	}

	infile.clear();
	infile.seekg(0, ios::beg);
	
	///////Insertword/////////
	if(in==0)
	{
		step=n_sen;
	}
	else
	{
		step=n_sen/in;
	}
	if(step==0) {step++;}
	cos=ran%step;
	count=in;
	old_p=0,point=0;
		while((n_sen>0)&&(count>0)&&(step>0))
	{
		while((n_sen>0)&&(count>0)&&(infile>>chr))
		{	
			ques="";
			if(strncmp(chr,"\\\\",2)==0)
			{
				old_p=point;
				point=infile.tellg()-strlen(chr);
				if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Insertword(str);
						cos=0;
					}
				}
				if(ques!="")
				{
					outfile1<<in-count+1<<". "<<ques<<"\n";
					n_sen--;
					count--;
					infile.clear();
					point_temp=infile.tellg();
					infile.seekp(old_p+2);
					infile<<"@";
					infile.seekg(point_temp);
				}
				str=chr;
			}
			else
			{
				str=str+" "+chr;
			}
		}
		ques="";
		if((n_sen>0)&&(count>0))
		{
			old_p=point;
			point=0;
			if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Insertword(str);
						cos=0;
					}
				}
			if(ques!="")
			{
				outfile1<<in-count+1<<". "<<ques<<"\n";
				n_sen--;
				count--;
				infile.clear();
				point_temp=infile.tellg();
				infile.seekp(old_p+2);
				infile<<"@";
				infile.seekg(point_temp);
			}
		}
		step--;
		cos--;
		infile.clear();
		infile.seekg(0, ios::beg);
	}

	infile.clear();
	infile.seekg(0, ios::beg);

	///////Descripe/////////
	if(de==0)
	{
		step=n_sen;
	}
	else
	{
		step=n_sen/de;
	}
	if(step==0) {step++;}
	cos=ran%step;
	count=de;
	old_p=0,point=0;
	while((n_sen>0)&&(count>0)&&(step>0))
	{
		str="";
		while((n_sen>0)&&(count>0)&&(infile>>chr))
		{	
			ques="";
			if(strncmp(chr,"\\\\",2)==0)
			{
				old_p=point;
				point=infile.tellg()-strlen(chr);
				if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Descripe(str);
						cos=0;
					}
				}
				if(ques!="")
				{
						outfile2<<de-count+1<<". "<<ques<<"\n";
						n_sen--;
						count--;
						infile.clear();
						point_temp=infile.tellg();
						infile.seekp(old_p+2);
						infile<<"@";
						infile.seekg(point_temp);
						
				}
				str=chr;
			}
			else
			{
				str=str+" "+chr;
			}
		}
		ques="";
		if((n_sen>0)&&(count>0))
		{
			old_p=point;
			point=0;
			if(str.GetLength()>2)
				if(str[2]!='@')
				{
					cos++;
					if(cos==step)
					{
						ques=Descripe(str);
						cos=0;
					}
				}
			if(ques!="")
			{
					outfile2<<de-count+1<<". "<<ques<<"\n";
					n_sen--;
					count--;
					infile.clear();
					point_temp=infile.tellg();
					infile.seekp(old_p+2);
					infile<<"@";
					infile.seekg(point_temp);
			}
		}
		step--;
		cos--;
		infile.clear();
		infile.seekg(0, ios::beg);
	}

	infile.clear();
	infile.seekg(0, ios::beg);


		

	infile.close();
	outfile1.close();
	outfile2.close();
	outfile3.close();
	outfile4.close();
	outfile5.close();
//	AfxMessageBox("Generate Exam Complete!");
}


CString Examgen::Descripe(CString sen)
{
	CString temp,ques=sen;
	int pos=0;
	keyword->now=keyword->first;
	
	if(strncmp(ques,"\\\\",2)==0)
	{
	ques=sen;
	pos=sen.Find("����");
	if (pos>=0)
	{
		ques.Delete(pos,sen.GetLength()-pos);
		ques+="�������ú�ҧ";
		ques.Delete(0,2);
	}
	else
	{
		ques=sen;
		pos=sen.Find("���¶֧");
		if (pos>=0)
		{
			ques.Delete(pos,sen.GetLength()-pos);
			ques+="���¶֧����";
			ques.Delete(0,2);
		}
		else
		{
			ques=sen;
			pos=sen.Find("���¡���");
			if (pos>=0)
			{
				ques.Delete(pos,sen.GetLength()-pos);
				ques+="���¡�������";
				ques.Delete(0,2);
			}
			else
			{
				ques=sen;
				pos=sen.Find("�����");
				if (pos>=0)
				{
					ques.Delete(pos,sen.GetLength()-pos);
					ques+="���������";
					ques.Delete(0,2);
				}
				else
				{
					ques=sen;
					pos=sen.Find("����");
					if (pos>=0)
					{
						ques.Delete(pos,sen.GetLength()-pos);
						ques+="�����˵��";
						ques.Delete(0,2);
					}
					else
					{
						ques=sen;
						pos=sen.Find("����");
						if (pos>=0)
						{
							ques.Delete(pos,sen.GetLength()-pos);
							ques+="��������";
							ques.Delete(0,2);
						}
						else
						{
							ques=sen;
							pos=sen.Find("���ͧ�ҡ");
							if (pos>=0)
							{
								ques.Delete(pos,sen.GetLength()-pos);
								ques+="���ͧ�ҡ����";
								ques.Delete(0,2);
							}
						}
					}
				}
			}
		}
	}
	}
	while((keyword->now!=keyword->last)&&(ques==sen))
	{
		pos=-1;
		keyword->now=keyword->now->next;
		ques=sen;
		pos=sen.Find(keyword->now->str);
		if ((pos>=0)&&!((keyword->now->str[0]<'z')&&(keyword->now->str[0]>'A')))
		{
			ques.Delete(pos,strlen(keyword->now->str));
			ques.Insert(pos,"����");
			temp=ques;
			pos=pos+4;
			bool end=true;
			do
			{
				end=true;
				if(pos<temp.GetLength())
				{
					while((temp[pos]==' ')||(temp[pos]=='\t'))
					{
						temp.Delete(pos);
					}
					if(temp.Find(",",pos)==pos)
					{
						temp.Delete(pos);
					}
					if(temp.Find("���",pos)==pos)
					{
						temp.Delete(pos,3);
					}
					if(temp.Find("����",pos)==pos)
					{
						temp.Delete(pos,4);
					}
					while((pos<temp.GetLength())&&((temp[pos]==' ')||(temp[pos]=='\t')))
						temp.Delete(pos);
					Node* f=keyword->first->next;
					while((f!=keyword->last->next)&&end)
					{
						if(temp.Find(f->str,pos)==pos)
						{
							temp.Delete(pos,strlen(f->str));
							ques=temp;
							end=false;
						}
						f=f->next;
					}
				}
			}while(!end);
			if(strncmp(ques,"\\\\",2)==0)
				ques.Delete(0,2);
			//remove
			int pos1=ques.Find("���",pos);
			if(pos1==ques.GetLength()-3)
				ques.Delete(pos1,ques.GetLength()-pos1);
			else
			{
				int pos1=ques.Find("����",pos);
				if(pos1==ques.GetLength()-6)
					ques.Delete(pos1,ques.GetLength()-pos1);
				else
				{
					int pos1=ques.Find("��Сͺ����",pos);
					if(pos1==ques.GetLength()-10)
						ques.Delete(pos1,ques.GetLength()-pos1);
					else
					{
						int pos1=ques.Find("�ѧ���",pos);
						if(pos1==ques.GetLength()-6)
							ques.Delete(pos1,ques.GetLength()-pos1);
						else
						{
							int pos1=ques.Find("��",pos);
							if(pos1==ques.GetLength()-6)
								ques.Delete(pos1,ques.GetLength()-pos1);
						}
					}
				}
			}
			pos1=-1;
		}
	}

	if(strncmp(ques,"\\\\",2)==0)
	{
		ques="";
	}
	if(((ques.GetLength()==6)&&(ques.Find("����")==2))||
		((ques.GetLength()==4)&&(ques.Find("����")==0)))
	{
		ques=="";
	}
	return ques;
}

CString Examgen::Insertword(CString sen)
{
	CString temp,ques="";
	int pos=0;
	keyword->now=keyword->first;
	int con=0;
	while(keyword->now!=keyword->last)
	{
		keyword->now=keyword->now->next;
		pos=sen.Find(keyword->now->str,con);
		if (pos>=0)
		{
			ques=sen;
			int l=strlen(keyword->now->str);
			ques.Delete(pos,l);
			for(int i=0;i<l;i++)
			{
				ques.Insert(pos,"__");
			}
			temp=ques;
			pos=pos+(2*l);
			bool end=true;
			do
			{
				end=true;
				if(pos<temp.GetLength())
				{
					while((temp[pos]==' ')||(temp[pos]=='\t'))
					{
						pos=pos+1;
					}
					if(temp.Find(",",pos)==pos)
					{
						pos=pos+1;
					}
					if(temp.Find("���",pos)==pos)
					{
						pos=pos+3;
					}
					if(temp.Find("����",pos)==pos)
					{
						pos=pos+4;
					}
					while((pos<temp.GetLength())&&((temp[pos]==' ')||(temp[pos]=='\t')))
					{
						pos=pos+1;
					}
					Node* f=keyword->first->next;
					while((f!=keyword->last->next)&&end)
					{
						if(temp.Find(f->str,pos)==pos)
						{
							int m=strlen(f->str);
							temp.Delete(pos,m);
							for(int i=0;i<m;i++)
							{
								temp.Insert(pos,"__");
							}
							ques=temp;
							end=false;
							con=pos+(2*m)-(ques.GetLength()-sen.GetLength());
						}
						f=f->next;
					}
				}
			}while(!end);

			if(strncmp(ques,"\\\\",2)==0)
				ques.Delete(0,2);
			if(rand()%2==0)
			{
				break;
			}
		}
	}
	//remove
	int pos1=ques.Find("���",pos);
	if(pos1==ques.GetLength()-3)
		ques.Delete(pos1,ques.GetLength()-pos1);
		else
		{
			int pos1=ques.Find("����",pos);
			if(pos1==ques.GetLength()-6)
				ques.Delete(pos1,ques.GetLength()-pos1);
			else
			{
				int pos1=ques.Find("��Сͺ����",pos);
				if(pos1==ques.GetLength()-10)
					ques.Delete(pos1,ques.GetLength()-pos1);
				else
				{
					int pos1=ques.Find("�ѧ���",pos);
					if(pos1==ques.GetLength()-6)
						ques.Delete(pos1,ques.GetLength()-pos1);
					else
					{
						int pos1=ques.Find("��",pos);
						if(pos1==ques.GetLength()-6)
							ques.Delete(pos1,ques.GetLength()-pos1);
					}

				}
			}
		}
	return ques;
}

CString Examgen::Couple(CString sen)
{
	CString temp,ques="";
	int aa,st,en,pos;
	keyword->now=keyword->first;
	while((keyword->now!=keyword->last)&&(ques==""))
	{
		do
		{
		keyword->now=keyword->now->next;
		}while((keyword->now->amount==2)&&(keyword->now!=keyword->last));
		if(keyword->now->amount!=2)
		{
			pos=0;
			st=0;
			ques=sen;
			aa=sen.Find(keyword->now->str);
			if (aa>=0)
			{
				int l=strlen(keyword->now->str);
				pos=aa+l;
				if(pos<sen.GetLength())
				{
						while((sen[pos]==' ')||(sen[pos]=='\t'))
						{
							pos=pos+1;
						}
						st=pos;
						if(sen.Find("(",pos)==pos)
						{
							pos=sen.Find(")",st)+1;
						}
						while((pos<sen.GetLength())&&((sen[pos]==' ')||(sen[pos]=='\t')))
						{
							pos=pos+1;
						}
						if(sen.Find("���",pos)==pos)
						{
							pos=pos+3;
						}
						else
						if(sen.Find("���¡���",pos)==pos)
						{
							pos=pos+8;
						}
						else
						if(sen.Find("��",pos)==pos)
						{
							pos=pos+4;
						}
						else
						if(sen.Find("���¶֧",pos)==pos)
						{
							pos=pos+7;
						}
						else
						{
							pos=st;
						}
	
						if(sen.Find("(",pos)==pos)
						{
							pos=pos+1;
							en=sen.Find(")",pos);
						}
						else
						{
							if(pos!=st)
								en=sen.Find(" ",pos);
							else
								pos=0;
						}
						
						if(en<0)
						{
							en=sen.GetLength();
						}
						
						if(pos!=0)
						{
							bool secondwd=false;
							ques="";
							//ques=(keyword->now->str);
							//ques=ques+"\n";
							for(int i=pos;i<en;i++)
							{
								if(sen[i]!=' ')
								{
									ques=ques+sen[i];
									secondwd=true;
									keyword->now->amount=2;
								}
							}
							if(!secondwd)
							{
								ques="";
							}
						}
						else
							ques="";
				}
				else
					ques="";
			}
			else
				ques="";
		}
	}

	keyword->now=keyword->first;
	while((keyword->now!=keyword->last)&&(ques==""))
	{
		do
		{
		keyword->now=keyword->now->next;
		}while((keyword->now->amount==2)&&(keyword->now!=keyword->last));
		if(keyword->now->amount!=2)
		{
			pos=0;
			st=0;
			ques=sen;
			aa=sen.Find(keyword->now->str);
			if (aa>=0)
			{
				pos=aa;
				if(pos>0)
				{
						while((pos>0)&&((sen[pos]==' ')||(sen[pos]=='\t')))
						{
							pos=pos-1;
						}
						if(sen.Find("���",pos-3)==pos-3)
						{
							pos=pos-3;
						}
						else
						if(sen.Find("���¡���",pos-8)==pos-8)
						{
							pos=pos-8;
						}
						else
						if(sen.Find("��",pos-4)==pos-4)
						{
							pos=pos-4;
						}
						else
						if(sen.Find("���¶֧",pos-7)==pos-7)
						{
							pos=pos-7;
						}
						else
						{
							pos=-1;
						}
						
				
						
						if(pos>0)
						{
							ques=sen;
							ques.Delete(pos,sen.GetLength()-pos);
							keyword->now->amount=2;
						}
						else
							ques="";
				}
				else
					ques="";
			}
			else
				ques="";
		}
	}
	if(strncmp(ques,"\\\\",2)==0)
		ques="";

	return ques;
}

CString Examgen::True_False(CString sen)
{
	CString ques;
	int pos=-1,lpos,len;
	len=sen.GetLength();
	ques="";


	///////number//////////
	int value=0;
	if((rand()%6==0))
	{
		ques=sen;
		ques.Delete(0,2);
	}
	else
	{
		pos=sen.FindOneOf("1234567890");
		if(pos!=-1)
		{
			lpos=pos;
			while((lpos<len)&&(sen[lpos]>='0')&&(sen[lpos]<='9'))
			{
				switch(sen[lpos])
				{
				case '0': value=value*10;	break;
				case '1': value=value*10+1;	break;
				case '2': value=value*10+2;	break;
				case '3': value=value*10+3;	break;
				case '4': value=value*10+4;	break;
				case '5': value=value*10+5;	break;
				case '6': value=value*10+6;	break;
				case '7': value=value*10+7;	break;
				case '8': value=value*10+8;	break;
				case '9': value=value*10+9;	break;
				}
				lpos++;
			}
			ques=sen;
			ques.Delete(pos,lpos-pos);
			
			//////choice////////
			int pvalue;
			int ran=rand();
			int ran1=rand();
			if(value<10)
			{
				ran=ran%5;
				switch(ran)
				{
				case(0): pvalue=value/5;		break;
				case(1): pvalue=(value*2)/5;	break;
				case(2): pvalue=(value*3)/5;	break;
				case(3): pvalue=(value*4)/5;	break;
				case(4): pvalue=value;			break;
				}
			}
			else
			{
				if(value<100)
				{
					ran=ran%5;
					switch(ran)
					{
					case(0): pvalue=value/10;		break;
					case(1): pvalue=(value*2)/10;	break;
					case(2): pvalue=(value*3)/10;	break;
					case(3): pvalue=(value*4)/10;	break;
					case(4): pvalue=(value*5)/10;	break;
					}
				}
				else
				{
					if(value<1000)
					{
						ran=ran%5;
						switch(ran)
						{
						case(0): pvalue=value/20;		break;
						case(1): pvalue=(value*2)/20;	break;
						case(2): pvalue=(value*3)/20;	break;
						case(3): pvalue=(value*4)/20;	break;
						case(4): pvalue=(value*5)/20;	break;
						}
					}
					else
					{
						ran=ran%5;
						switch(ran)
						{
						case(0): pvalue=value/100;		break;
						case(1): pvalue=(value*2)/100;	break;
						case(2): pvalue=(value*3)/100;	break;
						case(3): pvalue=(value*4)/100;	break;
						case(4): pvalue=(value*5)/100;	break;
						}
					}
				}
			}
			if(pvalue==0)
			{
				pvalue++;
			}
			if(value>pvalue)
			{
				ran1=ran1%3;
			}
			else
			{
				ran1=ran1%2;
			}
			switch(ran1)
			{
			case(1): value=value+pvalue;	break;
			case(2): value=value-pvalue;	break;
			}
			ques.Insert(pos,tostring(value));
			if(strncmp(ques,"\\\\",2)==0)
				ques.Delete(0,2);
		}
		////other word////
		if(ques=="")
		{
			pos=sen.Find("���");
			if(pos!=-1)
			{
				ques=sen;
				ques.Delete(pos,3);
				ques.Delete(0,2);
			}
			else
			{
				int wd=0;
				while((pos==-1)&&(wd<9))
				{
					switch(wd)
					{
					case(0): pos=sen.Find("��"); break;
					case(1): pos=sen.Find("gxHo"); break;
					case(2): pos=sen.Find("wfh"); break;
					case(3): pos=sen.Find("9hv'"); break;
					case(4): pos=sen.Find(",u"); break;
					case(5): pos=sen.Find("���"); break;
					case(6): pos=sen.Find("�١"); break;
					case(7): pos=sen.Find("�Ҩ��"); break;
					case(8): pos=sen.Find("��"); break;
					}
					wd++;
				}
				if(pos!=-1)
				{
					ques==sen;
					switch(wd)
					{
					case(5): sen.Insert(pos+4,"w,j"); break;
					case(8): sen.Delete(pos,3);
						sen.Insert(pos+2,"w,j"); break;
					case(9): sen.Insert(pos+2,"w,j"); break;
					default: sen.Insert(pos,"w,j");
					}
					ques.Delete(0,2);
				}
			}
		}
	}
	//remove
	if(pos<0)
	{
		pos=0;
	}
			int pos1=ques.Find("���",pos);
			if(pos1!=-1)
				ques.Delete(pos1,ques.GetLength()-pos1);
			else
			{
				int pos1=ques.Find("����",pos);
				if(pos1!=-1)
					ques.Delete(pos1,ques.GetLength()-pos1);
				else
				{
					int pos1=ques.Find("��Сͺ����",pos);
					if(pos1!=-1)
						ques.Delete(pos1,ques.GetLength()-pos1);
					else
					{
						int pos1=ques.Find("�ѧ���",pos);
						if(pos1!=-1)
							ques.Delete(pos1,ques.GetLength()-pos1);
						else
						{
							int pos1=ques.Find("��",pos);
							if(pos1!=-1)
								ques.Delete(pos1,ques.GetLength()-pos1);
						}
					}
				}
			}
	
	return ques;
}

CString Examgen::Choice(CString sen,int n_ch)
{
	CString ques;
	int pos,lpos,len;
	len=sen.GetLength();
	ques="";


	///////number//////////
	int value=0;

		pos=sen.FindOneOf("1234567890");
		if(pos!=-1)
		{
			lpos=pos;
			while((lpos<len)&&(sen[lpos]>='0')&&(sen[lpos]<='9'))
			{
				switch(sen[lpos])
				{
				case '0': value=value*10;	break;
				case '1': value=value*10+1;	break;
				case '2': value=value*10+2;	break;
				case '3': value=value*10+3;	break;
				case '4': value=value*10+4;	break;
				case '5': value=value*10+5;	break;
				case '6': value=value*10+6;	break;
				case '7': value=value*10+7;	break;
				case '8': value=value*10+8;	break;
				case '9': value=value*10+9;	break;
				}
				lpos++;
			}
			ques=sen;
			ques.Delete(pos,lpos-pos);
			ques.Insert(pos,"________");
			//remove
			int pos1=ques.Find("���",pos);
			if(pos1!=-1)
				ques.Delete(pos1,ques.GetLength()-pos1);
			else
			{
				int pos1=ques.Find("����",pos);
				if(pos1!=-1)
					ques.Delete(pos1,ques.GetLength()-pos1);
				else
				{
					int pos1=ques.Find("��Сͺ����",pos);
					if(pos1!=-1)
						ques.Delete(pos1,ques.GetLength()-pos1);
					else
					{
						int pos1=ques.Find("�ѧ���",pos);
						if(pos1!=-1)
							ques.Delete(pos1,ques.GetLength()-pos1);
						else
						{
							int pos1=ques.Find("��",pos);
							if(pos1==ques.GetLength()-6)
								ques.Delete(pos1,ques.GetLength()-pos1);
						}
					}
				}
			}
			ques=ques+"\n";
			if(strncmp(ques,"\\\\",2)==0)
				ques.Delete(0,2);			
			
			//////choice////////
			int pvalue;
			int ran=rand();
			int ran1=rand();
			if(value<100)
			{
				ran=ran%5;
				switch(ran)
				{
				case(0): pvalue=value/10;		break;
				case(1): pvalue=(value*2)/10;	break;
				case(2): pvalue=(value*3)/10;	break;
				case(3): pvalue=(value*4)/10;	break;
				case(4): pvalue=(value*5)/10;	break;
				}
			}
			else
			{
				if(value<1000)
				{
					ran=ran%5;
					switch(ran)
					{
					case(0): pvalue=value/20;		break;
					case(1): pvalue=(value*2)/20;	break;
					case(2): pvalue=(value*3)/20;	break;
					case(3): pvalue=(value*4)/20;	break;
					case(4): pvalue=(value*5)/20;	break;
					}
				}
				else
				{
					ran=ran%5;
					switch(ran)
					{
					case(0): pvalue=value/100;		break;
					case(1): pvalue=(value*2)/100;	break;
					case(2): pvalue=(value*3)/100;	break;
					case(3): pvalue=(value*4)/100;	break;
					case(4): pvalue=(value*5)/100;	break;
					}
				}
			}
			if(pvalue==0)
			{
				pvalue++;
			}
			int m_ch=n_ch;
			m_ch=value/pvalue;
			if(m_ch>5)
			{
				m_ch=5;
			}
			ran1=ran1%m_ch;
			switch(ran1)
			{
			case(0):	ques=ques+"�."+tostring(value)+"\n";
						ques=ques+"�."+tostring(value+pvalue)+"\n";
						if(n_ch>2)ques=ques+"�."+tostring(value+(2*pvalue))+"\n";
						if(n_ch>3)ques=ques+"�."+tostring(value+(3*pvalue))+"\n";	
						if(n_ch>4)ques=ques+"�."+tostring(value+(4*pvalue))+"\n";
						if(n_ch>5)ques=ques+"�."+tostring(value+(5*pvalue))+"\n";
						break;
			case(1):	ques=ques+"�."+tostring(value-pvalue)+"\n";
						ques=ques+"�."+tostring(value)+"\n";
						if(n_ch>2)ques=ques+"�."+tostring(value+pvalue)+"\n";
						if(n_ch>3)ques=ques+"�."+tostring(value+(2*pvalue))+"\n";	
						if(n_ch>4)ques=ques+"�."+tostring(value+(3*pvalue))+"\n";	
						if(n_ch>5)ques=ques+"�."+tostring(value+(4*pvalue))+"\n";
						break;
			case(2):	ques=ques+"�."+tostring(value-(2*pvalue))+"\n";
						ques=ques+"�."+tostring(value-pvalue)+"\n";
						if(n_ch>2)ques=ques+"�."+tostring(value)+"\n";
						if(n_ch>3)ques=ques+"�."+tostring(value+pvalue)+"\n";
						if(n_ch>4)ques=ques+"�."+tostring(value+(2*pvalue))+"\n";	
						if(n_ch>5)ques=ques+"�."+tostring(value+(3*pvalue))+"\n";	
						break;
			case(3):	ques=ques+"�."+tostring(value-(3*pvalue))+"\n";
						ques=ques+"�."+tostring(value-(2*pvalue))+"\n";
						if(n_ch>2)ques=ques+"�."+tostring(value-pvalue)+"\n";
						if(n_ch>3)ques=ques+"�."+tostring(value)+"\n";
						if(n_ch>4)ques=ques+"�."+tostring(value+pvalue)+"\n";	
						if(n_ch>5)ques=ques+"�."+tostring(value+(2*pvalue))+"\n";
						break;
			case(4):	ques=ques+"�."+tostring(value-(4*pvalue))+"\n";
						ques=ques+"�."+tostring(value-(3*pvalue))+"\n";
						if(n_ch>2)ques=ques+"�."+tostring(value-(2*pvalue))+"\n";
						if(n_ch>3)ques=ques+"�."+tostring(value-pvalue)+"\n";
						if(n_ch>4)ques=ques+"�."+tostring(value)+"\n";
						if(n_ch>5)ques=ques+"�."+tostring(value+pvalue)+"\n";	
						break;
			case(5):	ques=ques+"�."+tostring(value-(5*pvalue))+"\n";
						ques=ques+"�."+tostring(value-(4*pvalue))+"\n";
						if(n_ch>2)ques=ques+"�."+tostring(value-(3*pvalue))+"\n";
						if(n_ch>3)ques=ques+"�."+tostring(value-(2*pvalue))+"\n";
						if(n_ch>4)ques=ques+"�."+tostring(value-pvalue)+"\n";
						if(n_ch>5)ques=ques+"�."+tostring(value)+"\n";
						break;
			}
		}


	return ques;
}

CString Examgen::tostring(int value)
{
	CString ans="";
	int temp;
	char ch;
	if(value==0)
	{
		ans="0";
	}
	while(value>0)
	{
		temp=value%10;
		value=value/10;
		ch='0';
		ch=ch+temp;
		ans=ch+ans;
	}
	return ans;
}