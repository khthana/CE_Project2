// SepWord.cpp: implementation of the SepWord class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "exam_generator.h"
#include "SepWord.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SepWord::SepWord()
{
	a=NULL;
	dictionary=new Tnode();

	pname=AfxGetApp()->m_pszHelpFilePath;
	int sp=pname.ReverseFind('\\');
	pname.Delete(sp+1,pname.GetLength()-(sp+1));

	char dictwd[100]="";
	int valwd=0;
	ifstream infile1(pname+"thspelldict",ios::in);
	if(infile1>>dictwd)
	{
		infile1>>valwd;
		a=dictionary->insert(a,dictwd,valwd);
		while(infile1>>dictwd)
		{
			infile1>>valwd;
			dictionary->insert(a,dictwd,valwd);
		}
	}
	infile1.close();
	ifstream inlong(pname+"dlong",ios::in);
	inlong>>dlong;
	inlong.close();
////////////////////////
/*	ofstream op(pname+"thd",ios::out);
	CString aa;
	char *cc=new char[dlong];
	int bb;
	Tptr dd;
	aa=dictionary->print(a);
	while(aa!="")
	{
		op<<aa;
		op<<" ";
		strcpy(cc,aa);
		dd=dictionary->find(a,cc);
		bb=dd->st;
		dd->st=10000;
		switch(bb)
		{
		case(0):op<<"00"; break;
		case(1):op<<"01"; break;
		case(10):op<<"10"; break;
		case(11):op<<"11"; break;
		}
		op<<'\n';
		aa=dictionary->print(a);
	}
	op.close();*/
}

SepWord::~SepWord()
{
	delete dictionary;
	delete l;
}

void SepWord::newdict()
{
	char dictwd[100]="";
	int valwd=0;
	ifstream infile1(pname+"newspelldict",ios::in);
	ofstream outfile(pname+"thspelldict",ios::app);
	while(infile1>>dictwd)
	{
		infile1>>valwd;
		if((strlen(dictwd)>0)&&((!dictionary->find(a,dictwd))||((dictionary->find(a,dictwd))->st==10000)))
			{
				dictionary->insert(a,dictwd,valwd);
				outfile<<dictwd<<" "<<valwd<<"\n";
				int l=strlen(dictwd);
				if(l>dlong)
				{
					dlong=l;
					ofstream outlong(pname+"dlong",ios::out);
					outlong<<dlong;
					outlong.close();
				}
			}
	}
	outfile.close();
	infile1.close();
}


void SepWord::strdel(char* str,int a)
{
	int len=strlen(str);
	for(int i=0;i<=len;i++)
	{
		str[i]=str[i+a];
	}
}


void SepWord::count (void)
{
	char str[100];
	ifstream infile(pname+"thspell",ios::in | ios::nocreate);
	l=new List();
	while(infile>>str)
	{
		if((str[0]!='!')&&(str[0]!='@')&&(str[0]!='#')&&(str[0]!='$')&&(str[0]!='%')&&
			(str[0]!='^')&&(str[0]!='&')&&(str[0]!='�')&&(str[0]!='*')&&(str[0]!='(')&&
			(str[0]!=')')&&(str[0]!='_')&&(str[0]!='-')&&(str[0]!='+')&&(str[0]!='=')&&
			(str[0]!='[')&&(str[0]!=']')&&(str[0]!='{')&&(str[0]!='}')&&/*(str[0]!='\;')&&*/
			(str[0]!=':')&&(str[0]!='\'')&&(str[0]!='"')&&(str[0]!='\\')&&(str[0]!='|')&&
			(str[0]!='<')&&(str[0]!='>')&&(str[0]!=',')&&(str[0]!='.')&&(str[0]!='/')&&
			(str[0]!='?')&&(str[0]!='1')&&(str[0]!='2')&&(str[0]!='3')&&(str[0]!='4')&&
			(str[0]!='5')&&(str[0]!='6')&&(str[0]!='7')&&(str[0]!='8')&&(str[0]!='9')&&
			(str[0]!='0')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&
			(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&
			(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&
			(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&
			(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&
			(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�')&&(str[0]!='�'))
		{
			while((str[0]==' ')||(str[0]=='\t'))
			{
				for(unsigned i=0;i<strlen(str);i++)
				{
					str[i]=str[i+1];
				}
			}
			if(str!="")
			{
				l->searchword(str);
			}
		}
	}
	infile.close();
	l->print();
}


char* SepWord::splitword(const char* str)
{
	//deep++;
	if(deep>mostdeep){mostdeep=deep;}
	char copy[100]="",temp[100]="",input[500]="",o[500]="",o1[500]="";
	char* output;
	bool found=false,fstfound=false;
	int split1=0,point=0;
	// copy string to input
	strcpy(input,str);
	//find first word
	

	//longest
	point=strlen(str);
	if (point>dlong) {point=dlong;}
	while((point>=0)&&(!found))
	{
		strncpy(copy,str,point);
		copy[point]=NULL;
		Tptr diction=dictionary->find(a,copy);
			if((diction!=NULL)&&(diction->st!=10000))
			{
				found=true;
				fstfound=true;
				split1=point;
			}
		point--;

/*	//shortest
	while((point<=26)&&(!found)&&(point<=strlen(str)))
	{
		ifstream infile1("thspelldict",ios::in);
		strncpy(copy,str,point);
		while(infile1>>temp)
		{
			if(strcmp(copy,temp)==0)
			{
				found=true;
				fstfound=true;
				split1=point;
				break;
			}
		}
		infile1.close();
		point++;
*/

		if (found)
		{
			//delete first word from string input
			strdel(input,split1);

			deep=tempdeep+split1;


			//split back word
			if(strcmp(input,"")!=0)
			{
				tempdeep=deep;
				output=splitword(input);
				tempdeep=tempdeep-split1;
				deep=deep-split1;
				if(strcmp(output,"")!=0)
				{
					// complete split
					strncpy(o,str,split1);
					output=strcat(strcat(o," "),output);
				}
				else
				{
					found=false;
					strcpy(input,str);
				}
			}
			else
			{
				output=strncpy(o,str,split1);
			}
			if(strcmp(output,"")!=0)
			{
				strcpy(o1," ");
			}
			else
			{
				strcpy(o1,"");
			}
			output=strcat(o1,output);
		}
	}

	if(!fstfound)
	{
		//if not found first word
		if((mostdeep==deep)&&(up))
		{
			up=false;
			output=temp;
			strcpy(output,"");
			strncpy(o,str,1);
			strdel(input,1);

			deep=tempdeep+1;

			if(strcmp(input,"")!=0)
			{
				tempdeep=deep;
				output=splitword(input);
				while(strcmp(output,"")==0)
				{
					//mostdeep=deep;					
					//deep=0;
					up=true;
					tempdeep=deep;
					output=splitword(input);
				}
				output=strcat(o,output);
			}
			else
			{
				output=o;
			}
		}
		else
		{
			output="";
		}
	}
	return output;
}


void SepWord::splitfile(void)
{
	precal();
	ifstream infile(pname+"th1",ios::in);		//input file(after pre-calculate)
	ofstream outfile(pname+"thspell",ios::out);	//split word file
	ofstream outfile1(pname+"th2",ios::out);	//split sentence file
	char str[500],input[500];
	char output[500],wo[100];
	char lastch;
	CString wor,wor1,wor2;
	int posi;
	int countlong=0;
	bool newpara=false,not_new=false;
	up=false;
	// insert one word per time
	while(infile>>str)
	{
		//if have '\\' is new paragraph delete it and remember that
		if(strncmp(str,"\\\\",2)==0)
		{
			newpara=true;
			wor=str;
			wor.Delete(0,2);
			while(wor.Find(' ')==0)
			{
				wor.Delete(0,1);
			}
			strcpy(str,wor);
		}
		//check empty string
		if(strcmp(str,"")!=0)
		{
			tempdeep=0;
			deep=0;
			mostdeep=0;
			strcpy(input,str);
			strcpy(output,"");
			//split the word
			strcpy(output,splitword(input));
			//if can not split do it again and not come back
			while(strcmp(output,"")==0)
			{
				//mostdeep=deep;
				up=true;
				deep=0;
				tempdeep=0;
				strcpy(output,splitword(input));
			}
			//write it to file
			outfile.write(output,strlen(output));
			outfile.write(" ",1);
			//new line
			countlong=countlong+strlen(output);
			if(countlong>80)
			{
				countlong=0;
				outfile.write("\n",1);
			}

			////split sentence////
			wor=output;
			//get one splited word
			//delete space(front)
			posi=wor.Find(' ');
			while(posi==0)
			{
				wor.Delete(0,1);
				posi=wor.Find(' ');
			}
			posi=wor.ReverseFind(' ');
			//delete space(back)
			while(posi==wor.GetLength()-1)
			{
				wor.Delete(posi-1,1);
				posi=wor.ReverseFind(' ');
			}
			wor1=wor;
			//get first word
			posi=wor1.Find(' ');
			if(posi!=-1)
			{
				wor1.Delete(posi,wor1.GetLength()-posi);
			}
			//get last word
			wor2=wor;
			posi=wor2.ReverseFind(' ');
			if(posi!=-1)
			{
				wor2.Delete(0,posi+1);
			}
			strcpy(wo,wor1);
			//find in dictionary
			Tptr dnode=dictionary->find(a,wo);
			//new sentence if it is new paragraph or the word is noun
			if(newpara)
			{
				outfile1.write("\n\\\\",3);
			}
			else
			{
				if(dnode!=NULL)
				{
					if(!not_new)
					{
						if(dnode->st/100!=1)
						{
							if((dnode->st/10)%10==1)
							{
								strcpy(wo,wor);
								if(dictionary->find(a,wo)==NULL)
								{
									outfile1.write("\\\\",2);
								}
							}
						}
					}
				}
			}
			//write sentence
			outfile1.write(str,strlen(str));
			outfile1.write(" ",1);
			//check last character
			lastch=wor1[wor1.GetLength()-1];
			if(((lastch>='0')&&(lastch<='9'))||(lastch==','))
			{
				not_new=true;
			}
			else
			{
				not_new=false;
			}
		}
		newpara=false;
	}
	infile.close();
	outfile.close();
	count();
}

void SepWord::precal(void)
{
	ifstream infile(pname+"th",ios::in);
	ofstream outfile(pname+"th1",ios::out);
	char chr1[10000]="";
	CString para;
	while(infile.getline(chr1,10000))
	{	
		para=chr1;
		int n=para.GetLength();
		while((n>0)&&((para[n-1]==13)||(para[n-1]==10)))
		{
			para.Delete(n-1,1);
			n--;
		}
		n=0;

		while((para.GetLength()>n)&&((para[0]==' ')||(para[0]=='\t')))
		{
			para.Delete(0,1);
		}

		if(para.GetLength()>0)
		{
			if(para[0]=='-')
			{
				para.Delete(0,1);
			}
		}
		if((para.GetLength()>2)&&((para[1]=='.')||(para[1]==')'))&&((para[0]<='0')||(para[0]>='9')))
		{
			para.Delete(0,2);
		}
		n=0;
		while((para.GetLength()>n)&&(para[n]>='0')&&(para[n]<='9'))
		{
			n++;
			if((para.GetLength()>n)&&((para[n]=='.')||(para[n]==')')||(para[n]==']')||(para[n]=='}')))
			{
				n++;
				while((para.GetLength()>n)&&(para[n]>='0')&&(para[n]<='9'))
				{
					while((para.GetLength()>n)&&(para[n]>='0')&&(para[n]<='9'))
					{
						n++;
					}
					if((para.GetLength()>n)&&((para[n]=='.')||(para[n]==')')||(para[n]==']')||(para[n]=='}')))
					{
						n++;
					}
				}
				para.Delete(0,n);
			}
		}
		n=0;

		if(para.GetLength()>1)
		{
			if((para[2]=='.')||(para[2]==')')||(para[2]==']')||(para[2]=='}'))
			{
				para.Delete(0,2);
			}
		}
		n=0;

		while((para.GetLength()>n)&&((para[n]==' ')||(para[n]=='\t')))
		{
			para.Delete(0,1);
		}
		if(para.GetLength()!=0)
		{
			outfile<<"\\\\";
			outfile<<para;
			outfile<<'\n';
		}
	}
	outfile.close();
}
