// exam_generatorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "exam_generator.h"
#include "exam_generatorDlg.h"
#include "AddwordDlg.h"
#include "ExamDlg.h"
#include "Examgen.h"
#include "Sepword.h"
#include "Afxtempl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

SepWord *mydict;
CExamDlg exam_dlg;
List *non_key;
CMenu* mmenu,*submenu1,*submenu2,*submenu3;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExam_generatorDlg dialog

CExam_generatorDlg::CExam_generatorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExam_generatorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExam_generatorDlg)
	m_result = _T("");
	m_source = _T("");
	m_addkey = _T("");
	m_ch = _T("");
	m_co = _T("");
	m_de = _T("");
	m_in = _T("");
	m_nch = _T("");
	m_nco = _T("");
	m_tr = _T("");
	m_fre = 0;
	m_type = -1;
	m_len = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExam_generatorDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExam_generatorDlg)
	DDX_Control(pDX, IDC_WORD, m_word);
	DDX_Control(pDX, IDC_COUNT, m_count);
	DDX_Text(pDX, IDC_RESULT, m_result);
	DDX_Text(pDX, IDC_SOURCE, m_source);
	DDX_Text(pDX, IDC_EDIT1, m_addkey);
	DDX_Text(pDX, IDC_CH, m_ch);
	DDX_Text(pDX, IDC_CO, m_co);
	DDX_Text(pDX, IDC_DE, m_de);
	DDX_Text(pDX, IDC_IN, m_in);
	DDX_Text(pDX, IDC_NCH, m_nch);
	DDX_Text(pDX, IDC_NCO, m_nco);
	DDX_Text(pDX, IDC_TR, m_tr);
	DDX_Text(pDX, IDC_FRE, m_fre);
	DDV_MinMaxInt(pDX, m_fre, 0, 100);
	DDX_Radio(pDX, IDC_TYPE, m_type);
	DDX_Text(pDX, IDC_LEN, m_len);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CExam_generatorDlg, CDialog)
	//{{AFX_MSG_MAP(CExam_generatorDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_EXAM, OnExam)
	ON_COMMAND(ID_SORT_ALA, OnSortAla)
	ON_COMMAND(ID_SORT_ALD, OnSortAld)
	ON_COMMAND(ID_SORT_AMA, OnSortAma)
	ON_COMMAND(ID_SORT_AMD, OnSortAmd)
	ON_COMMAND(ID_SORT_FOUND, OnSortFound)
	ON_COMMAND(IDC_ADDNEW, OnAddnew)
	ON_BN_CLICKED(IDC_ADDKEY, OnAddkey)
	ON_BN_CLICKED(IDC_DELKEY, OnDelkey)
	ON_COMMAND(INPUT_DATA, OnData)
	ON_BN_CLICKED(IDC_SPLIT, OnSplit)
	ON_COMMAND(IDC_SAVE, OnSaveCon)
	ON_COMMAND(IDC_LOAD, OnLoadcon)
	ON_COMMAND(IDC_SAVE_EXAM, OnSaveExam)
	ON_BN_CLICKED(IDC_ADDTOKEY, OnAddtokey)
	ON_BN_CLICKED(IDC_DELKEY2, OnDelkey)
	ON_BN_CLICKED(IDC_EDITDATA, OnData)
	ON_EN_CHANGE(IDC_SOURCE, OnChangeSource)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExam_generatorDlg message handlers

BOOL CExam_generatorDlg::OnInitDialog()
{

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	bbrowse=true;
	bsplit=true;
	bexam=true;
	bexam_save=true;
	first_b=true;
	mydict=new SepWord();
	CDialog::OnInitDialog();
	non_key=new List();
	ifstream infile2(mydict->pname+"thnonkey",ios::in);
	ofstream clr;
	clr.open(mydict->pname+"th",ios::out);
	clr.close();
	char wdtemp[100];
	while(infile2>>wdtemp)
	{
		if(!non_key->findword(wdtemp))
		{
			non_key->addnode(wdtemp);
		}
	}


	mmenu = GetMenu();
	submenu1 = mmenu->GetSubMenu(0);
	submenu2 = mmenu->GetSubMenu(1);
	submenu3 = submenu2->GetSubMenu(1);
	m_co="0";
	m_nco="0";
	m_in="0";
	m_de="0";
	m_tr="0";
	m_ch="0";
	m_nch="0";
	m_type=0;
	m_len=10;
	m_fre=10;
	UpdateData(false);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CExam_generatorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExam_generatorDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExam_generatorDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CExam_generatorDlg::OnBrowse() 
{
	// TODO: Add your control notification handler code here
	int re=IDCANCEL;
	if((bsplit==false)||(bexam_save==false))
	{
		re=AfxMessageBox("����������ش�ѧ���١�ѹ�֡\n�� ok �����׹�ѹ����Դ file ���� �� cancel ����¡��ԡ",MB_OKCANCEL);
	}
	else
	{
		re=IDOK;
	}
	if(re==IDOK)
	{
		UpdateData(true);
		m_source="";
		CFileDialog dlgOpen(TRUE, NULL, NULL, OFN_HIDEREADONLY, (LPCTSTR)"Text Files (*.txt)|*.txt|");
		if(dlgOpen.DoModal()==IDOK)
		{
			bbrowse=false;
			bsplit=false;
			bexam=false;
			first_b=false;
			char wdtemp[501]="";
			file_name=dlgOpen.GetPathName();
			ifstream infile1(file_name,ios::binary | ios::nocreate);
			while(infile1)
			{
				for(int i=0;i<=500;i++)
				{
					wdtemp[i]=0;
				}
				infile1.read(wdtemp, 500);
				m_source=m_source+wdtemp;
			}
			infile1.close();
			m_result="";
			
			m_count.ResetContent();
			m_word.ResetContent();
	
	//		m_keylist.ResetContent( );
			UpdateData(FALSE);
		}
	}
}

void CExam_generatorDlg::OnSplit() 
{
	// TODO: Add your control notification handler code here
	bbrowse=true;
	bsplit=false;
	bexam=false;
	UpdateData(true);
	m_result="";
	m_count.ResetContent();
	m_word.ResetContent();
//	m_keylist.ResetContent( );
	ofstream outfile1(mydict->pname+"th",ios::out);
	outfile1<<m_source;
	outfile1.close();

	mydict->splitfile();
	
	
	//show result
	char wdtemp[101]="";
	ifstream infile1(mydict->pname+"thspell",ios::binary | ios::nocreate);
	while(infile1)
	{
		for(int i=0;i<=100;i++)
		{
			wdtemp[i]=0;
		}
		infile1.read(wdtemp, 100);
		m_result=m_result+wdtemp;
	}
	infile1.close();
	UpdateData(false);
	Sort(4);
	UpdateKey();
	UpdateWord();
	submenu3->EnableMenuItem(ID_SORT_ALA, MF_BYCOMMAND | MF_UNCHECKED);
	submenu3->EnableMenuItem(ID_SORT_ALD, MF_BYCOMMAND | MF_UNCHECKED);
	submenu3->EnableMenuItem(ID_SORT_AMA, MF_BYCOMMAND | MF_UNCHECKED);
	submenu3->EnableMenuItem(ID_SORT_AMD, MF_BYCOMMAND | MF_CHECKED);
	submenu3->EnableMenuItem(ID_SORT_FOUND, MF_BYCOMMAND | MF_UNCHECKED);

	UpdateData(FALSE);
}

void CExam_generatorDlg::OnExam() 
{
	// TODO: Add your command handler code here
	int re;
	if(bbrowse==false)
	{
		if(first_b==false)
		{
			re=AfxMessageBox("�ա������¹�ŧ file input ��ѧ�ҡ������ҧ key ���駷������\n�س��ͧ���������������������",
				MB_YESNO);
		}
		else
		{
			re=IDYES;
		}

		if(re==IDYES)
		{
			UpdateData(true);
			ofstream outfile1(mydict->pname+"th",ios::out);
			outfile1<<m_source;
			outfile1.close();
			mydict->splitfile();
		}
		else
		{
			UpdateData(false);
		}
	}
	UpdateData(true);
	bbrowse=true;
	bexam=true;
	bexam_save=false;

	List *key;
	char str[100];
	key=new List();

	for(int i=0;i<m_count.GetCount();i++)
	{
		m_count.GetText(i,str);
		key->addnode(str);
	}
	Examgen ex1(key,exam_dlg.m_co,exam_dlg.m_nco,exam_dlg.m_in,exam_dlg.m_de,exam_dlg.m_tr,exam_dlg.m_ch,exam_dlg.nch);
	delete key;

	//write exam in the box
	ifstream infile1(mydict->pname+"�Ѻ���.txt",ios::binary | ios::nocreate);
	ifstream infile2(mydict->pname+"������͡.txt",ios::binary | ios::nocreate);
	ifstream infile3(mydict->pname+"�����.txt",ios::binary | ios::nocreate);
	ifstream infile4(mydict->pname+"������.txt",ios::binary | ios::nocreate);
	ifstream infile5(mydict->pname+"�١�Դ.txt",ios::binary | ios::nocreate);
	m_result="";
	bool first=true;
	char wdtemp[501]="";
	char c13=13,c10=10;
	while(infile1)
	{
		for(int i=0;i<=500;i++)
		{
			wdtemp[i]=0;
		}
		infile1.read(wdtemp, 500);
		if((first)&&(strlen(wdtemp)!=0))
		{
			m_result=m_result+"���Ѻ���⨷��Ѻ������͡��������������ش";
			m_result=m_result+c13+c10;
			first=false;
		}
		m_result=m_result+wdtemp;
	}
	if(!first)
	{
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
	}
	first=true;
	while(infile2)
	{
		for(int i=0;i<=500;i++)
		{
			wdtemp[i]=0;
		}
		infile2.read(wdtemp, 500);
		if((first)&&(strlen(wdtemp)!=0))
		{
			m_result=m_result+"�����͡������͡��������������ش��§˹�觢��";
			m_result=m_result+c13+c10;
			first=false;
		}
		m_result=m_result+wdtemp;
	}
	if(!first)
	{
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
	}
	first=true;
	while(infile3)
	{
		for(int i=0;i<=500;i++)
		{
			wdtemp[i]=0;
		}
		infile3.read(wdtemp, 500);
		if((first)&&(strlen(wdtemp)!=0))
		{
			m_result=m_result+"�������ŧ㹪�ͧ��ҧ����˹����";
			m_result=m_result+c13+c10;
			first=false;
		}
		m_result=m_result+wdtemp;
	}
	if(!first)
	{
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
	}
	first=true;
	while(infile4)
	{
		for(int i=0;i<=500;i++)
		{
			wdtemp[i]=0;
		}
		infile4.read(wdtemp, 500);
		if((first)&&(strlen(wdtemp)!=0))
		{
			m_result=m_result+"���ͺ�Ӷ�����仹�����١��ͧ";
			m_result=m_result+c13+c10;
			first=false;
		}
		m_result=m_result+wdtemp;
	}
	if(!first)
	{
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
		m_result=m_result+c13+c10;
	}
	first=true;
	while(infile5)
	{
		for(int i=0;i<=500;i++)
		{
			wdtemp[i]=0;
		}
		infile5.read(wdtemp, 500);
		if((first)&&(strlen(wdtemp)!=0))
		{
			m_result=m_result+"���ͺ��Ң�ͤ������仹��١���ͼԴ";
			m_result=m_result+c13+c10;
			first=false;
		}
		m_result=m_result+wdtemp;
	}
	UpdateData(false);

	infile1.close();
	infile2.close();
	infile3.close();
	infile4.close();
	infile5.close();
}

void CExam_generatorDlg::OnSortAla() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	if(submenu3->GetMenuState(ID_SORT_ALA, MF_BYCOMMAND)!=MF_CHECKED)
	{
		Sort(1);
		UpdateWord();
		submenu3->EnableMenuItem(ID_SORT_ALA, MF_BYCOMMAND | MF_CHECKED);
		submenu3->EnableMenuItem(ID_SORT_ALD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_FOUND, MF_BYCOMMAND | MF_UNCHECKED);
	}
}

void CExam_generatorDlg::OnSortAld() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	if(submenu3->GetMenuState(ID_SORT_ALD, MF_BYCOMMAND)!=MF_CHECKED)
	{
		Sort(2);
		UpdateWord();
		submenu3->EnableMenuItem(ID_SORT_ALA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_ALD, MF_BYCOMMAND | MF_CHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_FOUND, MF_BYCOMMAND | MF_UNCHECKED);
	}
}

void CExam_generatorDlg::OnSortAma() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	if(submenu3->GetMenuState(ID_SORT_AMA, MF_BYCOMMAND)!=MF_CHECKED)
	{
		Sort(3);
		UpdateWord();
		submenu3->EnableMenuItem(ID_SORT_ALA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_ALD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMA, MF_BYCOMMAND | MF_CHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_FOUND, MF_BYCOMMAND | MF_UNCHECKED);
	}
}

void CExam_generatorDlg::OnSortAmd() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	if(submenu3->GetMenuState(ID_SORT_AMD, MF_BYCOMMAND)!=MF_CHECKED)
	{
		Sort(4);
		UpdateWord();
		submenu3->EnableMenuItem(ID_SORT_ALA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_ALD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMD, MF_BYCOMMAND | MF_CHECKED);
		submenu3->EnableMenuItem(ID_SORT_FOUND, MF_BYCOMMAND | MF_UNCHECKED);
	}
}

void CExam_generatorDlg::OnSortFound() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	if(submenu3->GetMenuState(ID_SORT_FOUND, MF_BYCOMMAND)!=MF_CHECKED)
	{
		Sort(0);
		UpdateWord();
		submenu3->EnableMenuItem(ID_SORT_ALA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_ALD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMA, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_AMD, MF_BYCOMMAND | MF_UNCHECKED);
		submenu3->EnableMenuItem(ID_SORT_FOUND, MF_BYCOMMAND | MF_CHECKED);
	}
}

void CExam_generatorDlg::OnAddnew() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	CAddwordDlg dlg;
	CString pname=AfxGetApp()->m_pszHelpFilePath;
	int sp=pname.ReverseFind('\\');
	pname.Delete(sp+1,pname.GetLength()-(sp+1));
	ofstream outfile1(pname+"newspelldict",ios::out);
	outfile1.close();
	int nResponse = dlg.DoModal();
	if(nResponse==IDOK)
	{
		mydict->newdict();
	}
}

void CExam_generatorDlg::Sort(int cur) 
{
	// TODO: Add your control notification handler code here
	int max_word;
	List* l=mydict->l;
	List* sort=new List();
	Node *a,*b,*o;
	
	max_word=l->first->amount;
	//amount of key word
	max_word=max_word/10;
	if(max_word<=0)
	{
		max_word=1;
	}
	
	if(l->count!=0)
	{
		o=l->first;
		switch(cur)
		{
			case 0:
				l->print();
				break;
			case 1:
				do
				{
					o=o->next;
					a=sort->first;
					b=a;
					while(b!=sort->last)
					{
						b=a->next;
						if(strcmp(o->str,b->str)<0)
						{
							break;
						}
						a=a->next;
					}
					sort->addptr(o->str,o->amount,a);
				}while(o!=l->last);
				sort->print();
				break;
			case 2: 
				do
				{
					o=o->next;
					a=sort->first;
					b=a;
					while(b!=sort->last)
					{
						b=a->next;
						if(strcmp(o->str,b->str)>0)
						{
							break;
						}
						a=a->next;
					}
					sort->addptr(o->str,o->amount,a);
				}while(o!=l->last);
				sort->print();
				break;
			case 3: 
				do
				{
					o=o->next;
					a=sort->first;
					b=a;
					while(b!=sort->last)
					{
						b=a->next;
						if(o->amount<=b->amount)
						{
							while((o->amount==b->amount)&&(a!=sort->last))
							{
								if(strcmp(o->str,b->str)>0)
								{
									break;
								}
								a=a->next;
								if(a!=sort->last)
								{
									b=a->next;
								}
							}
							break;
						}
						a=a->next;
					}
					sort->addptr(o->str,o->amount,a);
				}while(o!=l->last);
				sort->print();
				break;
			case 4: 
				do
				{
					o=o->next;
					a=sort->first;
					b=a;
					while(b!=sort->last)
					{
						b=a->next;
						if(o->amount>=b->amount)
						{
							while((o->amount==b->amount)&&(a!=sort->last))
							{
								if(strcmp(o->str,b->str)<0)
								{
									break;
								}
								a=a->next;
								if(a!=sort->last)
								{
									b=a->next;
								}
							}
							break;
						}
						a=a->next;
					}
					sort->addptr(o->str,o->amount,a);
				}while(o!=l->last);
				sort->print();
				break;
		}
	}
	delete sort;
}

void CExam_generatorDlg::UpdateKey()
{
	UpdateData(true);
	char wdtemp[101]="";
	ifstream infile(mydict->pname+"thcount", ios::in);
	m_count.ResetContent();
	int count_word;
	Tnode* point;
	int max_word=mydict->l->first->amount;
	max_word=max_word*m_fre/100;

	while(infile>>wdtemp)
	{
		infile>>count_word;
		int i=strlen(wdtemp);
		while((i>0)&&(wdtemp[0]==-96))
		{
			for(int j=0;j<i;j++)
			{
				wdtemp[j]=wdtemp[j+1];
			}
		}
		point=mydict->dictionary->find(mydict->a,wdtemp);
		if(((!non_key->findword(wdtemp))&&
			(!((point!=NULL)&&(point->st==1))))&&(strlen(wdtemp)>1))
			{
			if(m_type==0)
			{
				if((strlen(wdtemp)>m_len))
				{
					m_count.AddString(wdtemp);
				}
			}
			else
			{
				if(count_word>=max_word)
				{
					m_count.AddString(wdtemp);
				}
			}
			}








		for(int j=0;j<=100;j++)
		{
			wdtemp[i]=0;
		}
	}
	//point=NULL;
	infile.close();
	UpdateData(FALSE);
}

void CExam_generatorDlg::UpdateWord()
{
	char wdtemp[101]="";
	char wdtemp1[101]="";
	ifstream infile(mydict->pname+"thcount", ios::in);
	m_word.ResetContent();
	//Tnode* point;
	while(infile>>wdtemp)
	{
		infile>>wdtemp1;
		int i=strlen(wdtemp);
		while((i>0)&&(wdtemp[0]==-96))
		{
			for(int j=0;j<i;j++)
			{
				wdtemp[j]=wdtemp[j+1];
			}
		}
		if((m_count.FindString(-1,wdtemp)== LB_ERR)&&(strlen(wdtemp)>1))
		{
			//strcat(wdtemp,"\t");
			//strcat(wdtemp,tostring(count_word));
			int a=6-strlen(wdtemp1);
			while(a>0)
			{
				strcat(wdtemp1,"  ");
				a--;
			}
			m_word.AddString(strcat(wdtemp1,wdtemp));
		}
		for(int j=0;j<=100;j++)
		{
			wdtemp[i]=0;
		}
	}
	//point=NULL;
	infile.close();
	UpdateData(FALSE);
}

void CExam_generatorDlg::OnAddkey() 
{
	// TODO: Add your control notification handler code here
	bsplit=false;
	bexam=false;
	UpdateData(TRUE);
	if(m_count.FindStringExact(-1,m_addkey)==LB_ERR)
	{
		m_count.AddString(m_addkey);
	}
	int pos=0;
	int nIndex=m_word.GetCount();
	CString temp;
	for(int i=0;i<nIndex;i++)
	{
		m_word.GetText(i,temp);
		pos=temp.Find(" ");
		temp.Delete(0,pos);
		while((temp[0]==' ')||(temp[0]=='\t'))
		{
			temp.Delete(0,1);
		}
		if(temp==m_addkey)
		{
			m_word.DeleteString(i);
			break;
		}
	}
	m_addkey="";
	UpdateData(FALSE);
}

void CExam_generatorDlg::OnDelkey() 
{
	// TODO: Add your control notification handler code here
	bsplit=false;
	bexam=false;
	UpdateData(true);
	int nIndex = m_count.GetCurSel();
	int nCount = m_count.GetCount();
	if ((nIndex != LB_ERR) && (nCount >= 1))
	{
	   m_count.DeleteString(nIndex);
	}
	if ((nIndex == LB_ERR) && (nCount >= 1))
	{
		for(int i=0;i<nCount;i++)
		{
			m_count.DeleteString(0);
		}
	}
	UpdateWord();
}

void CExam_generatorDlg::OnData() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	int nResponse = exam_dlg.DoModal();
	if(nResponse==IDOK)
	{
		bsplit=false;
		bexam=false;
		m_co=tostring(exam_dlg.m_co);
		m_nco=tostring(exam_dlg.m_nco);
		m_in=tostring(exam_dlg.m_in);
		m_de=tostring(exam_dlg.m_de);
		m_tr=tostring(exam_dlg.m_tr);
		m_ch=tostring(exam_dlg.m_ch);
		m_nch=tostring(exam_dlg.nch);
		UpdateData(false);
	}
}


CString CExam_generatorDlg::tostring(int value)
{
	CString ans="";
	int temp;
	char ch;
	if(value==0)
	{
		ans="0";
	}
	while(value>0)
	{
		temp=value%10;
		value=value/10;
		ch='0';
		ch=ch+temp;
		ans=ch+ans;
	}
	return ans;
}

void CExam_generatorDlg::OnSaveCon() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	int re=IDCANCEL;
	if(bbrowse==false)
	{
		re=AfxMessageBox("�ա������¹�ŧ file input ��ѧ�ҡ������ҧ key ���駷������\n�� OK �����׹�ѹ���кѹ�֡�����Ŵѧ�����",
			MB_OKCANCEL);
	}
	else
	{
		re=IDOK;
	}
	if(re==IDOK)
	{
		CFileDialog dlgSave(FALSE, (LPCTSTR)"abc", NULL, OFN_HIDEREADONLY, (LPCTSTR)"Exam Config Files (*.abc)|*.abc|");
		CString file_name_save;
		char chr1[10000]="";
		if(dlgSave.DoModal()==IDOK)
		{
			bbrowse=true;
			bsplit=true;
			file_name_save=dlgSave.GetPathName();
			ofstream outfile(file_name_save, ios::out);
			ifstream infile(mydict->pname+"th", ios::in);
				while(infile.getline(chr1,10000))
			{
				outfile<<chr1<<"\n";
			}
			outfile<<"%%%%\n";
			for(int i=0;i<m_count.GetCount();i++)
			{
				m_count.GetText(i,chr1);
				outfile<<chr1<<"\n";
			}
			outfile<<"%%%%\n";
			outfile<<exam_dlg.m_co<<"\n"
				<<exam_dlg.m_in<<"\n"
				<<exam_dlg.m_de<<"\n"
				<<exam_dlg.m_tr<<"\n"
				<<exam_dlg.m_ch<<"\n";
		}
	}
}

void CExam_generatorDlg::OnLoadcon() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	int re=IDCANCEL;
	if((bsplit==false)||(bexam_save==false))
	{
		re=AfxMessageBox("����������ش�ѧ���١�ѹ�֡\n�� ok �����׹�ѹ����Դ file ���� �� cancel ����¡��ԡ",MB_OKCANCEL);
	}
	else
	{
		re=IDOK;
	}
	if(re==IDOK)
	{	
		CFileDialog dlgLoad(true, (LPCTSTR)"abc", NULL, OFN_HIDEREADONLY, (LPCTSTR)"Exam Config Files (*.abc)|*.abc|");
		CString file_name_load;
		char chr1[10000]="";
		if(dlgLoad.DoModal()==IDOK)
		{
			bsplit=true;
			bexam_save=true;
			bbrowse=true;
			bexam_save=true;
			file_name_load=dlgLoad.GetPathName();
			ifstream infile(file_name_load, ios::in);
			ofstream outfile(mydict->pname+"th", ios::out);
			while(infile.getline(chr1,10000))
			{
				if(strcmp(chr1,"%%%%"))
				{
					outfile<<chr1<<"\n";
				}
				else
				{
					break;
				}			
			}
			char wdtemp[501]="";
			ifstream infile1(mydict->pname+"th",ios::binary | ios::nocreate);
			while(infile1)
			{
				for(int i=0;i<=500;i++)
				{
					wdtemp[i]=0;
				}
				infile1.read(wdtemp, 500);
				m_source=m_source+wdtemp;
			}
			infile1.close();
			UpdateData(false);
			OnSplit();
			m_count.ResetContent();
			while(infile.getline(chr1,10000))
			{
				if(strcmp(chr1,"%%%%"))
				{
					m_count.AddString(chr1);
				}
				else
				{
					break;
				}	
			}
			infile>>exam_dlg.m_co;
			infile>>exam_dlg.m_in;
			infile>>exam_dlg.m_de;
			infile>>exam_dlg.m_tr;
			infile>>exam_dlg.m_ch;
			infile.close();
			outfile.close();
			m_result="";
			UpdateData(false);
		}
	}
}

void CExam_generatorDlg::OnSaveExam() 
{
	// TODO: Add your command handler code here
	UpdateData(true);
	int re=IDCANCEL;
	if(bexam==false)
	{
		re=AfxMessageBox("�ա������¹�ŧ key word ���� file input ��ѧ�ҡ������ҧ����ͺ\n�� OK �����׹�ѹ���кѹ�֡�����Ŵѧ�����",
			MB_OKCANCEL);
	}
	else
	{
		re=IDOK;
	}
	if(re==IDOK)
	{
		bexam_save=true;
		CFileDialog dlgSave(FALSE, (LPCTSTR)"txt", NULL, OFN_HIDEREADONLY, (LPCTSTR)"Text Files (*.txt)|*.txt|");
		CString file_name_save;
		if(dlgSave.DoModal()==IDOK)
		{
			file_name_save=dlgSave.GetPathName();
			ofstream outfile(file_name_save, ios::out);
			outfile<<m_result;
		}
	}
}

void CExam_generatorDlg::OnAddtokey() 
{
	// TODO: Add your control notification handler code here
	bsplit=false;
	bexam=false;
	UpdateData(true);
	// Get the indexes of all the selected items.
	CString wd="";
	int pos=0;
	int nIndex = m_word.GetCurSel();
	int nCount = m_word.GetCount();
	if ((nIndex != LB_ERR) && (nCount >= 1))
	{
		m_word.GetText(nIndex,wd);
		pos=wd.Find(" ");
		if(pos!=-1)
		{
			wd.Delete(0,pos+1);
			while((wd[0]==' ')||(wd[0]=='\t'))
			{
				wd.Delete(0,1);
			}
		}
		m_count.AddString(wd);
		m_word.DeleteString(nIndex);
	}
	UpdateData(FALSE);
}

void CExam_generatorDlg::OnChangeSource() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	bbrowse=false;
	bsplit=false;
	bexam=false;
}

