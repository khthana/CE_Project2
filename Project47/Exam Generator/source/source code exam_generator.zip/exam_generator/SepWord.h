// SepWord.h: interface for the SepWord class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SEPWORD_H__E37888DD_6D02_4589_AF09_D265D0ADEF3D__INCLUDED_)
#define AFX_SEPWORD_H__E37888DD_6D02_4589_AF09_D265D0ADEF3D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class SepWord  
{
	int deep,mostdeep,tempdeep;
	bool up;
	int dlong;

public:
	Tptr a;
	Tptr dictionary;
	CString pname;
	List* l;

	SepWord();
	virtual ~SepWord();
	void strdel(char* str,int a);
	void count ();
	char* splitword(const char* str);
	void splitfile();
	void newdict();
	void precal();


};

#endif // !defined(AFX_SEPWORD_H__E37888DD_6D02_4589_AF09_D265D0ADEF3D__INCLUDED_)
