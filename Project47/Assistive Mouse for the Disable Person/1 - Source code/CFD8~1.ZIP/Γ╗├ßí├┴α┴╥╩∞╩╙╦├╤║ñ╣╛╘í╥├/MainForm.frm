VERSION 5.00
Object = "{70FC09CF-91C5-4B6C-83F5-953A5B5D40AC}#1.0#0"; "VideoOCXTools.ocx"
Object = "{A91E1E76-6AE7-11D4-AD08-A8AB2E818B70}#1.0#0"; "VideoOCX.ocx"
Begin VB.Form Form1 
   BorderStyle     =   5  'Sizable ToolWindow
   Caption         =   "AssistiveMouse"
   ClientHeight    =   3630
   ClientLeft      =   2055
   ClientTop       =   4035
   ClientWidth     =   11190
   Icon            =   "MainForm.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   242
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   746
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Frame3 
      Caption         =   "Voice Control"
      Height          =   3375
      Left            =   7560
      TabIndex        =   12
      Top             =   120
      Width           =   3495
      Begin VB.TextBox txtSpeech 
         Height          =   2175
         Left            =   240
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   13
         Top             =   360
         Width           =   3015
      End
      Begin VB.CommandButton btnStop 
         Caption         =   "Stop"
         Default         =   -1  'True
         Height          =   375
         Left            =   1920
         TabIndex        =   10
         Top             =   2760
         Width           =   1215
      End
      Begin VB.CommandButton btnStart 
         Caption         =   "Start"
         Height          =   375
         Left            =   360
         TabIndex        =   9
         Top             =   2760
         Width           =   1215
      End
   End
   Begin VB.HScrollBar ThresholdValue 
      Height          =   255
      Left            =   4080
      Max             =   255
      TabIndex        =   4
      Top             =   840
      Value           =   128
      Width           =   3015
   End
   Begin VB.CommandButton StopButton 
      Caption         =   "Stop"
      Height          =   375
      Index           =   1
      Left            =   2520
      TabIndex        =   3
      Top             =   2880
      Width           =   855
   End
   Begin VB.CommandButton StartButton 
      Caption         =   "Start"
      Height          =   375
      Index           =   0
      Left            =   1440
      TabIndex        =   2
      Top             =   2880
      Width           =   855
   End
   Begin VB.CommandButton DriverButton 
      Caption         =   "Driver"
      Height          =   375
      Left            =   360
      TabIndex        =   1
      Top             =   2880
      Width           =   855
   End
   Begin VIDEOOCXLib.VideoOCX VideoOCX 
      Height          =   2250
      Left            =   360
      TabIndex        =   0
      Top             =   480
      Width           =   3000
      _Version        =   65536
      _ExtentX        =   5292
      _ExtentY        =   3969
      _StockProps     =   0
      ScaledDisplay   =   0   'False
      SaveAudio       =   -1  'True
      Driver          =   0
      ControlWidth    =   200
      ControlHeight   =   150
      Mode            =   0
   End
   Begin VB.Frame Frame1 
      Caption         =   "Camera Control"
      Height          =   3375
      Left            =   120
      TabIndex        =   11
      Top             =   120
      Width           =   3495
   End
   Begin VB.Timer CaptureTimer 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   0
      Top             =   0
   End
   Begin VB.Frame Frame2 
      Caption         =   "Adjustment Control "
      Height          =   3375
      Left            =   3840
      TabIndex        =   14
      Top             =   120
      Width           =   3495
      Begin VB.HScrollBar sizeValue 
         Height          =   255
         Left            =   240
         Max             =   30
         Min             =   10
         TabIndex        =   5
         Top             =   1560
         Value           =   10
         Width           =   3015
      End
      Begin VB.CommandButton FreeButton 
         Caption         =   "Free"
         Height          =   375
         Left            =   2400
         TabIndex        =   8
         Top             =   2760
         Width           =   855
      End
      Begin VB.CommandButton LockButton 
         Caption         =   "Lock"
         Height          =   375
         Left            =   1320
         TabIndex        =   7
         Top             =   2760
         Width           =   855
      End
      Begin VB.CommandButton SwitchButton 
         Caption         =   "Switch"
         Height          =   375
         Left            =   240
         TabIndex        =   6
         Top             =   2760
         Width           =   855
      End
      Begin VB.Label speedString 
         Caption         =   "2"
         Height          =   255
         Left            =   960
         TabIndex        =   20
         Top             =   2040
         Width           =   735
      End
      Begin VB.Label Label3 
         Caption         =   "Speed :"
         Height          =   255
         Left            =   240
         TabIndex        =   19
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label sizeString 
         Caption         =   "10"
         Height          =   255
         Left            =   1320
         TabIndex        =   18
         Top             =   1200
         Width           =   1935
      End
      Begin VB.Label Label2 
         Caption         =   "Size (10-30) :"
         Height          =   255
         Left            =   240
         TabIndex        =   17
         Top             =   1200
         Width           =   1215
      End
      Begin VB.Label ThresholdString 
         Caption         =   "128"
         Height          =   255
         Left            =   1680
         TabIndex        =   16
         Top             =   360
         Width           =   1575
      End
      Begin VB.Label Label1 
         Caption         =   "Threshold (0-255) :"
         Height          =   255
         Left            =   240
         TabIndex        =   15
         Top             =   360
         Width           =   1455
      End
   End
   Begin VIDEOOCXTOOLSLib.VideoOCXTools VideoOCXTools 
      Left            =   3480
      Top             =   0
      _Version        =   65536
      _ExtentX        =   847
      _ExtentY        =   847
      _StockProps     =   0
   End
   Begin VB.Menu mnuPopup 
      Caption         =   "Popup"
      Visible         =   0   'False
      Begin VB.Menu mnuShow 
         Caption         =   "&Show"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "&Exit"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'------------------------------------------------------
' Speech Recognize
'------------------------------------------------------

Option Explicit

Dim WithEvents RecoContext As SpSharedRecoContext
Attribute RecoContext.VB_VarHelpID = -1
Dim Grammar As SpeechLib.ISpeechRecoGrammar

'Dim MenuRule As SpeechLib.ISpeechGrammarRule
'Dim cpRecoEngine As ISpeechRecognizerStatus
Dim MenuCommands As SpeechLib.ISpeechGrammarRule

Dim PropValue As Variant

Dim m_bRecoRunning As Boolean
Dim m_cChars As Integer
Dim ruleName As Long

Private Declare Function GetCursorPos Lib "USER32.DLL" (lpPoint As POINTAPI) As Long
Private Declare Function SetCursorPos Lib "USER32.DLL" (ByVal x As Long, ByVal y As Long) As Long

Dim lpPoint As POINTAPI

Private Declare Sub mouse_event Lib "USER32.DLL" (ByVal dwFlags As Long, _
                                                  ByVal dx As Long, _
                                                  ByVal dy As Long, _
                                                  ByVal cButtons As Long, _
                                                  ByVal dwExtraInfo As Long)

Private Const MOUSEEVENTF_LEFTDOWN = &H2
Private Const MOUSEEVENTF_LEFTUP = &H4
Private Const MOUSEEVENTF_RIGHTDOWN = &H8
Private Const MOUSEEVENTF_RIGHTUP = &H10

Private Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal hWndInsertAfter As Long, ByVal x As Long, y, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long

Private Const HWND_TOPMOST = -1
Private Const SWP_NOMOVE = &H2
Private Const SWP_NOSIZE = &H1
Private Const TOPMOST_FLAGS = SWP_NOMOVE Or SWP_NOSIZE

Public Sub MakeTopMost(hwnd As Long)
   SetWindowPos hwnd, HWND_TOPMOST, 0, 0, 0, 0, TOPMOST_FLAGS
End Sub


Private Sub Form_Load()
    'Away on top
    Call MakeTopMost(hwnd)
    
    SetState False
    m_cChars = 0
    PropValue = 0
    
    lock_flag = False
    state_flag = False
    switch_flag = True
    size = 20
    speed = 1
'------------------------------------------------------
' System Tray
'------------------------------------------------------
With IconData

.cbSize = Len(IconData)
' The length of the NOTIFYICONDATA type

.hIcon = Me.Icon
' A reference to the form's icon

.hwnd = Me.hwnd
' hWnd of the form

.szTip = "AssistiveMouse" & Chr(0)
' Tooltip string delimited with a null character

.uCallbackMessage = WM_MOUSEMOVE
' The icon we're placing will send messages to the MouseMove event

.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
' It will have message handling and a tooltip

.uID = vbNull
' uID is not used by VB, so it's set to a Null value

End With

End Sub

Private Sub btnStart_Click()
    Debug.Assert Not m_bRecoRunning
 
    If (RecoContext Is Nothing) Then
        Debug.Print "Initializing SAPI reco context object..."
        
        Set RecoContext = New SpSharedRecoContext
        Set Grammar = RecoContext.CreateGrammar(0)
        Set MenuCommands = Grammar.Rules.Add("MenuCommands", SRATopLevel Or SRADynamic, 1)
      
        'MenuRule = Grammar.Rules.Add("MenuCommands", SpeechRuleAttributes.SRATopLevel Or SpeechRuleAttributes.SRADynamic, 1)
              
        MenuCommands.InitialState.AddWordTransition Nothing, "click", "", SGLexical, "click", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "doubleclick", "", SGLexical, "doubleclick", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "rightclick", "", SGLexical, "rightclick", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "drag", "", SGLexical, "drag", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "drop", "", SGLexical, "drop", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "switch", "", SGLexical, "switch", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "lock", "", SGLexical, "lock", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "free", "", SGLexical, "free", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "hidden", "", SGLexical, "hidden", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "show", "", SGLexical, "show", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "speed", "", SGLexical, "speed", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "slow", "", SGLexical, "slow", 1, 0, 1
        MenuCommands.InitialState.AddWordTransition Nothing, "exit", "", SGLexical, "exit", 1, 0, 1

        Grammar.Rules.Commit
        Grammar.CmdSetRuleState "MenuCommands", SGDSActive
        'Grammar.DictationLoad
    End If
    
    'Grammar.DictationSetState SGDSActive
    SetState True
    state_flag = True
End Sub

Private Sub btnStop_Click()
    'Debug.Assert m_bRecoRunning
    'Grammar.DictationSetState SGDSInactive
    SetState False
    state_flag = False
End Sub

' This function handles Recognition event from the reco context object.
' Recognition event is fired when the speech recognition engines recognizes
' a sequences of words.
Private Sub RecoContext_Recognition(ByVal StreamNumber As Long, _
                                    ByVal StreamPosition As Variant, _
                                    ByVal RecognitionType As SpeechRecognitionType, _
                                    ByVal Result As ISpeechRecoResult _
                                    )
    If (state_flag) Then
    
        Dim strText As String
        strText = Result.PhraseInfo.GetText
    
        If (strText = "click") Then
            Call mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            Call mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        ElseIf (strText = "doubleclick") Then
            Call mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            Call mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
            Call mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            Call mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        ElseIf (strText = "rightclick") Then
            Call mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
            Call mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
        ElseIf (strText = "drag") Then
            Call mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        ElseIf (strText = "drop") Then
            Call mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        ElseIf (strText = "switch") Then
            SwitchButton_Click
        ElseIf (strText = "lock") Then
            LockButton_Click
        ElseIf (strText = "free") Then
            FreeButton_Click
        ElseIf (strText = "hidden") Then
            mnuHidden_Click
        ElseIf (strText = "show") Then
            mnuShow_Click
        ElseIf (strText = "speed") Then
            speed = speed * 2
            speedString.Caption = Format(speed)
        ElseIf (strText = "slow") Then
            If (speed > 1) Then
                speed = speed / 2
                speedString.Caption = Format(speed)
            ElseIf (speed < 1) Then
                speed = 1
                speedString.Caption = Format(speed)
            End If
        ElseIf (strText = "exit") Then
            mnuExit_Click
        End If
    
        Debug.Print "Recognition: " & strText & ", " & _
            StreamNumber & ", " & StreamPosition
    
        ' Append the new text to the text box, and add a space at the end of the
        ' text so that it looks better
        txtSpeech.SelStart = m_cChars
        txtSpeech.SelText = strText & " "
        m_cChars = m_cChars + 1 + Len(strText)
    
    End If
    
End Sub

' This function handles the state of Start and Stop buttons according to
' whether dictation is running.
Private Sub SetState(ByVal bNewState As Boolean)
    m_bRecoRunning = bNewState
    btnStart.Enabled = Not m_bRecoRunning
    btnStop.Enabled = m_bRecoRunning
End Sub


'------------------------------------------------------
' Camera
'------------------------------------------------------

Private Sub CaptureTimer_Timer()

    ' Timer for capturing. Handles VideoOCXTools - functions
    
    ' Capture an image
    If (VideoOCX.Capture(capture_image)) Then
    
        ' if capturing was successful...
        VideoOCX.ToGray capture_image, process_image
        VideoOCXTools.Threshold process_image, ThresholdValue.Value, process_image
        
        If (lock_flag) Then
            matrix_array = VideoOCX.GetMatrix(process_image)
            
            Dim y As Integer
            Dim x As Integer
            Dim xStart As Integer
            Dim xFinish As Integer
            Dim yStart As Integer
            Dim yFinish As Integer
            Dim pTop As Integer
            Dim pDown As Integer
            Dim pLeft As Integer
            Dim pRight As Integer
            Dim bAmount As Integer
            Dim DoWhileLoop As Boolean
            Dim nc_down_top As Integer      '0=nc 1=down  2=top
            Dim nc_right_left As Integer    '0=nc 1=right 2=left
            
            nc_down_top = 0
            nc_right_left = 0

            xStart = (99 - sizeValue.Value)
            xFinish = (99 + sizeValue.Value)
            yStart = (74 - sizeValue.Value)
            yFinish = (74 + sizeValue.Value)
            bAmount = 0
            DoWhileLoop = True
            'check top
            pTop = yStart
            Do While (DoWhileLoop)
                If (pTop - 1 > -1) Then
                    pTop = pTop - 1
                Else
                    DoWhileLoop = False
                End If
                For x = xStart - 1 To xFinish + 1 Step 1
                    If (matrix_array(x, pTop) = 0) Then
                        bAmount = bAmount + 1
                    End If
                Next
                If (bAmount < 3) Then
                    DoWhileLoop = False
                Else
                    bAmount = 0
                End If
            Loop
            'check down
            If (pTop = yStart - 1) Then
                bAmount = 0
                DoWhileLoop = True
                pDown = yFinish
                Do While (DoWhileLoop)
                    If (pDown + 1 < 200) Then
                        pDown = pDown + 1
                    Else
                        DoWhileLoop = False
                    End If
                    For x = xStart - 1 To xFinish + 1 Step 1
                        If (matrix_array(x, pDown) = 0) Then
                            bAmount = bAmount + 1
                        End If
                    Next
                    If (bAmount < 3) Then
                        DoWhileLoop = False
                    Else
                        bAmount = 0
                    End If
                Loop
                If (pDown <> yFinish + 1) Then
                    nc_down_top = 1
                End If
            Else
                nc_down_top = 2
            End If
            'check left
            bAmount = 0
            DoWhileLoop = True
            pLeft = xStart
            Do While (DoWhileLoop)
                If (pLeft - 1 > -1) Then
                    pLeft = pLeft - 1
                Else
                    DoWhileLoop = False
                End If
                For y = yStart - 1 To yFinish + 1 Step 1
                    If (matrix_array(pLeft, y) = 0) Then
                        bAmount = bAmount + 1
                    End If
                Next
                If (bAmount < 3) Then
                    DoWhileLoop = False
                Else
                    bAmount = 0
                End If
            Loop
            'check right
            If (pLeft = xStart - 1) Then
                bAmount = 0
                DoWhileLoop = True
                pRight = xFinish
                Do While (DoWhileLoop)
                    If (pRight + 1 < 150) Then
                        pRight = pRight + 1
                    Else
                        DoWhileLoop = False
                    End If
                    For y = yStart - 1 To yFinish + 1 Step 1
                        If (matrix_array(pRight, y) = 0) Then
                            bAmount = bAmount + 1
                        End If
                    Next
                    If (bAmount < 3) Then
                        DoWhileLoop = False
                    Else
                        bAmount = 0
                    End If
                Loop
                If (pRight <> xFinish + 1) Then
                    nc_right_left = 1
                End If
            Else
                nc_right_left = 2
            End If
            
            Dim x0 As Integer
            Dim y0 As Integer
            Dim x1 As Integer
            Dim y1 As Integer
            
            If (nc_down_top = 0) Then
                y0 = 74 - sizeValue.Value
                y1 = 74 + sizeValue.Value
            ElseIf (nc_down_top = 1) Then
                y0 = pDown - (sizeValue.Value * 2)
                y1 = pDown
            ElseIf (nc_down_top = 2) Then
                y0 = pTop
                y1 = pTop + (sizeValue.Value * 2)
            End If
            
            If (nc_right_left = 0) Then
                x0 = 99 - sizeValue.Value
                x1 = 99 + sizeValue.Value
            ElseIf (nc_right_left = 1) Then
                x0 = pRight - (sizeValue.Value * 2)
                x1 = pRight
            ElseIf (nc_right_left = 2) Then
                x0 = pLeft
                x1 = pLeft + (sizeValue.Value * 2)
            End If
           
            VideoOCXTools.DrawRectangle capture_image, x0, y0, x1, y1, 0, 0, 255
            VideoOCXTools.DrawRectangle process_image, x0, y0, x1, y1, 0, 0, 255

            Dim returnVal As Long
            If ((nc_right_left = 2) And (nc_down_top = 2)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                returnVal = SetCursorPos(lpPoint.x + (1 * speed), lpPoint.y - (1 * speed))
                End If
            ElseIf ((nc_right_left = 2) And (nc_down_top = 1)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                    returnVal = SetCursorPos(lpPoint.x + (1 * speed), lpPoint.y + (1 * speed))
                End If
            ElseIf ((nc_right_left = 1) And (nc_down_top = 1)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                    returnVal = SetCursorPos(lpPoint.x - (1 * speed), lpPoint.y + (1 * speed))
                End If
            ElseIf ((nc_right_left = 1) And (nc_down_top = 2)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                    returnVal = SetCursorPos(lpPoint.x - (1 * speed), lpPoint.y - (1 * speed))
                End If
            ElseIf ((nc_right_left = 2) And (nc_down_top = 0)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                returnVal = SetCursorPos(lpPoint.x + (1 * speed), lpPoint.y)
                End If
            ElseIf ((nc_right_left = 1) And (nc_down_top = 0)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                    returnVal = SetCursorPos(lpPoint.x - (1 * speed), lpPoint.y)
                End If
            ElseIf ((nc_right_left = 0) And (nc_down_top = 2)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                    returnVal = SetCursorPos(lpPoint.x, lpPoint.y - (1 * speed))
                End If
            ElseIf ((nc_right_left = 0) And (nc_down_top = 1)) Then
                If (GetCursorPos(lpPoint) <> 0) Then
                    returnVal = SetCursorPos(lpPoint.x, lpPoint.y + (1 * speed))
                End If
            End If
           
           VideoOCX.ReleaseMatrixToImageHandle process_image
           
        End If

        VideoOCXTools.DrawLine capture_image, 99, 0, 99, 149, 255, 0, 0
        VideoOCXTools.DrawLine capture_image, 0, 74, 199, 74, 255, 0, 0
        VideoOCXTools.DrawLine process_image, 99, 0, 99, 149, 255, 0, 0
        VideoOCXTools.DrawLine process_image, 0, 74, 199, 74, 255, 0, 0
        VideoOCXTools.DrawRectangle capture_image, 99 - sizeValue.Value, 74 - sizeValue.Value, 99 + sizeValue.Value, 74 + sizeValue.Value, 255, 0, 0
        VideoOCXTools.DrawRectangle process_image, 99 - sizeValue.Value, 74 - sizeValue.Value, 99 + sizeValue.Value, 74 + sizeValue.Value, 255, 0, 0
       
        If switch_flag Then
            VideoOCX.Show capture_image
        Else
             VideoOCX.Show process_image
        End If
        
    End If
    
End Sub

Private Sub DriverButton_Click()

    ' Select Video Driver
    VideoOCX.ShowDriverDlg
   
End Sub

Private Sub StartButton_Click(Index As Integer)
    
    ' Init VideoOCX Control, allocate memory and start grabbing
    
    ' Only if not running...
    If (Not CaptureTimer.Enabled) Then
    
        ' Disable internal error messages in VideoOCX
        VideoOCX.SetErrorMessages False
    
        ' Init control
        If (Not VideoOCX.Init) Then
        
            ' Init failed. Display error message and end sub
            MsgBox VideoOCX.GetLastErrorString, vbOKOnly, "VideoOCX Error(Init)"
            End
            
        End If
        
        ' Allocate memory for global image handle
        capture_image = VideoOCX.GetColorImageHandle
        process_image = VideoOCX.GetGrayImageHandle
        
        ' Start Capture mode
        If (Not VideoOCX.Start) Then
        
            ' Start failed. Display error message and end sub
            MsgBox VideoOCX.GetLastErrorString, vbOKOnly, "VideoOCX Error(Start)"
            End
            
        End If
        
        ' Start capture timer
        CaptureTimer.Enabled = True
        
        MsgBox "Initial & start capture mode complete.", vbOKOnly, "AssistiveMouse"
    End If
    
End Sub

Private Sub StopButton_Click(Index As Integer)

    ' Stop capturing, free memory and close the VideoOCX control
   
    ' only if running...
    If (CaptureTimer.Enabled) Then
        
        ' Stop Timer
        CaptureTimer.Enabled = False
        
        ' end Capture mode
        If (Not VideoOCX.Stop) Then
        
            ' Start failed. Display error message and end sub
            MsgBox VideoOCX.GetLastErrorString, vbOKOnly, "VideoOCX Error(Stop)"
            End
            
        End If
        
        ' free memory
        VideoOCX.ReleaseImageHandle capture_image
        VideoOCX.ReleaseImageHandle process_image
    
        ' close control
        If (Not VideoOCX.Close) Then
        
            ' Close failed. Display error message and end sub
            MsgBox VideoOCX.GetLastErrorString, vbOKOnly, "VideoOCX Error(Close)"
            End
            
        End If
        
        MsgBox "Stop & close capture mode complete.", vbOKOnly, "AssistiveMouse"
    End If

End Sub

Private Sub sizeValue_Change()
    sizeString.Caption = Format(sizeValue.Value)
End Sub

Private Sub sizeValue_Scroll()
    sizeValue_Change
End Sub

Private Sub SwitchButton_Click()
    If switch_flag Then
        switch_flag = False
    Else
        switch_flag = True
    End If
End Sub

Private Sub ThresholdValue_Change()
    ThresholdString.Caption = Format(ThresholdValue.Value)
End Sub

Private Sub ThresholdValue_Scroll()
    ThresholdValue_Change
End Sub

Private Sub FreeButton_Click()
    lock_flag = False
End Sub

Private Sub LockButton_Click()
    lock_flag = True
End Sub

'------------------------------------------------------
' System Tray
'------------------------------------------------------

Private Sub Form_Resize()

If Me.WindowState = 1 Then

'The user has minimized his window

Call Shell_NotifyIcon(NIM_ADD, IconData)

' Add the form's icon to the tray

Me.Hide

' Hide the button at the taskbar

End If

End Sub

Private Sub mnuExit_Click()

Unload Me
' Unload the form

End
' Just to be sure the program has ended

End Sub

Private Sub mnuShow_Click()

'Me.WindowState = vbNormal
Shell_NotifyIcon NIM_DELETE, IconData
'Me.Show

If WindowState = vbNormal Then
    Form1.Move 1995, 3735, 11310, 4035
    Frame1.Height = 225
    DriverButton.Visible = True
    StartButton(0).Visible = True
    StopButton(1).Visible = True
End If

End Sub

Private Sub mnuHidden_Click()

'Me.WindowState = 1
Call Shell_NotifyIcon(NIM_ADD, IconData)
'Me.Hide

If WindowState = vbNormal Then
    Form1.Move 11550, 0, 3850, 3500
    Frame1.Height = 190
    DriverButton.Visible = False
    StartButton(0).Visible = False
    StopButton(1).Visible = False
End If

End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)

Dim Msg As Long

Msg = x
' The message is passed to the X value

' You must set your form's ScaleMode property to pixels in order to get the correct message

If Msg = WM_LBUTTONDBLCLK Then
' The user has double-clicked your icon

Call mnuShow_Click
' Show the window

ElseIf Msg = WM_RBUTTONDOWN Then
' Right-click

PopupMenu mnuPopup
' Popup the menu

End If

End Sub

Private Sub Form_Unload(Cancel As Integer)

Shell_NotifyIcon NIM_DELETE, IconData

End Sub
