package project;

import javax.swing.*;
import java.util.*;

public class statementSQL {

  private String query;
  private String select;
  private String table[] = new String[255];
  private String from;
  private String where;
  private String where_expr[] = new String[255];
  private String boolean_connector[] = new String[255];
  private String order_by;
  private String having;
  private String group_by;
  private int ifrom;
  private int iwhere;
  private int igroup_by;
  private int ihaving;
  private int iorder_by;
  private int ntable;
  private int nwhere_expr;
  private boolean mul_or;
  private boolean mul_and;
  private Vector v;
  private Vector vt;
  private Vector value;

  public statementSQL() {
    query = "";
    select = "";
    from = "";
    where = "";
    order_by = "";
    having = "";
    group_by = "";
    ntable = 0;
    nwhere_expr = 0;
    v = new Vector();
    vt = new Vector();
    value = new Vector();
    mul_or = mul_and = false;
    ifrom = iwhere = igroup_by = ihaving = iorder_by = -1;
  }


  public statementSQL(String sql) {
    setSql(sql);
  }

  public String getColumn() {
    StringBuffer temp = new StringBuffer(v.toString());
    temp.delete(0,1);
    return v.elementAt(0).toString();
  }

  public String getSql() { //return sql
    return query;
  }

  public int getNumberOfTable() {
    return ntable;
  }

  public String getSelectString() { // return string select to string before "from"
    return select;
  }

  public String getTable(int i) { // return table string
    return table[i];
  }

  public int getNumberOfExpression() {
    return nwhere_expr;
  }

  public String getFrom() {
    return from;
  }

  public String getWhere() {
    return where.replaceFirst(" where", "WHERE");
  }

  public String getValue() {
    StringBuffer temp = new StringBuffer(value.toString());
    temp.delete(0,1);
    return v.elementAt(0).toString()+" IN ("+temp.toString().replaceAll("]",")");
  }

  public String getGroup_by() {
    return group_by;
  }

  public String getHaving() {
    return having;
  }

  public String getOrder_by() {
    return order_by;
  }

  public void setSql(String sql) { //set sql
    query = sql.replaceAll("\n", " ");
    query = query.replaceAll("\t", " ");
    while (query.indexOf("  ") != -1) {
      query = query.replaceAll("  ", " "); //replace two whitespace with one whitespace
    }
    query = query.toLowerCase();
    select = "";
    from = "";
    ntable = 0;
    nwhere_expr = 0;
    mul_or = mul_and = false;
    set_index();
    set_string(sql);
    set_where_expr();
    SplitFrom();
  }

  private void set_index() {
    ifrom = query.indexOf(" from ");
    iwhere = query.indexOf(" where ");
    igroup_by = query.indexOf(" group by ");
    ihaving = query.indexOf(" having ");
    iorder_by = query.indexOf(" order by ");
  }

  private void set_string(String oldsql) { //set  all string
    int end;
    select = query.substring(0, ifrom).toLowerCase();
    select = select.replaceFirst("select", "");
    if (iwhere == -1) {
      this.where = "";
    }
    else {
      if (igroup_by != -1)
        end = igroup_by;
      else if (ihaving != -1)
        end = ihaving;
      else if (iorder_by != -1)
        end = iorder_by;
      else
        end = query.length();
      this.where = query.substring(iwhere, end);
     StringBuffer buf = new StringBuffer(oldsql.substring(iwhere, end));
     int is,ie;
     while(buf.indexOf("'")!=-1){
       is=buf.indexOf("'");
       ie=buf.indexOf("'",is+1);
       this.where=this.where.replaceFirst(buf.substring(is,ie).toLowerCase(),buf.substring(is,ie));
       buf.delete(is,ie+1);
     }
    }
    //set group by string
    if (igroup_by == -1) {
      this.group_by = "";
    }
    else {
      if (ihaving != -1)
        end = ihaving;
      else if (iorder_by != -1)
        end = iorder_by;
      else
        end = query.length();
      this.group_by = query.substring(igroup_by, end);
    }
    //set having string
    if (ihaving == -1) {
      this.having = "";
    }
    else {
      if (iorder_by != -1)
        end = iorder_by;
      else
        end = query.length();
      this.having = query.substring(ihaving, end);
    }
    //set order by string
    if (iorder_by == -1) {
      this.order_by = "";
    }
    else {
      this.order_by = query.substring(iorder_by, query.length());
    }
  }

  public boolean IsCatesian() {
    if (iwhere == -1 && ntable >= 2)
      return true;
    return false;
  }

  public boolean IsAllJoin() {
    int compare_index;
    String s, left, right;
    v.clear();
    v.ensureCapacity(ntable);
    value.clear();
    for (int i = 0; i < nwhere_expr; i++) {
      s = where_expr[i];
      if (s.indexOf("=") != -1)
        compare_index = s.indexOf("=");
      else
        continue;

      left = s.substring(0, compare_index);
      right = s.substring(compare_index + 1);

      if (left.indexOf("'") != -1 || right.indexOf("'") != -1) {
        if (left.indexOf("'") != -1)
          v.add(right);
        else
          v.add(left);
        continue;
      }
      else {
        try {
          Double.parseDouble(left);
          if (!value.contains(left)) {
            value.add(left);
          }
        }
        catch (NumberFormatException ne) {
          if (!v.contains(left)) {
            v.add(left);
            if (!value.contains(right)) {
              value.add(right);
            }
          }
        }
        try {
          Double.parseDouble(right);
          if (!value.contains(right)) {
            value.add(right);
          }
        }
        catch (NumberFormatException ne) {
          if (!v.contains(right)) {
            v.add(right);
            if (!value.contains(left)) {
              value.add(left);
            }
          }
        }
      }
    }

    if (v.size()==1){
     return true;
    }
    return false;
  }


  public boolean IsMultipleOR() {
    if (ntable == 1 && mul_or && nwhere_expr > 1)
      return true;
    return false;
  }

  private void set_where_expr() {
    if (iwhere == -1) {
      return;
    }
    StringBuffer sbuf = new StringBuffer(where.replaceFirst(" where ", ""));
    int ior = sbuf.indexOf(" or ");
    int iand = sbuf.indexOf(" and ");

    if (ior == iand && iand == -1) { //have 1 expression
      nwhere_expr = 1;
      where_expr[0] = sbuf.toString();
    }
    else if (ior != -1 && iand != -1) { //All expression connected by both AND and OR; cut only OR
      int start = 0;
      while (ior != -1) {
        nwhere_expr++;
        where_expr[nwhere_expr - 1] = sbuf.substring(start, ior);
        boolean_connector[nwhere_expr - 1] = "OR";
        start = ior + 4; //ignored " or "
        ior = sbuf.indexOf(" or ", start);
      }
      where_expr[nwhere_expr] = sbuf.substring(start);
      nwhere_expr++;
      mul_or = mul_and = false;
    }
    else if (ior != -1) { //all expression connected by OR
      int start = 0;
      while (ior != -1) {
        nwhere_expr++;
        where_expr[nwhere_expr - 1] = sbuf.substring(start, ior);
        boolean_connector[nwhere_expr - 1] = "OR";
        start = ior + 4; //ignored " or "
        ior = sbuf.indexOf(" or ", start);
      }
      where_expr[nwhere_expr] = sbuf.substring(start);
      nwhere_expr++;
      mul_or = true;
    }
    else if (iand != -1) { //all expression connected by AND
      int start = 0;
      while (iand != -1) {
        nwhere_expr++;
        where_expr[nwhere_expr - 1] = sbuf.substring(start, iand);
        boolean_connector[nwhere_expr - 1] = "AND";
        start = iand + 5; //ignored " and "
        iand = sbuf.indexOf(" and ", start);
      }
      where_expr[nwhere_expr] = sbuf.substring(start);
      nwhere_expr++;
      mul_and = true;
    }
    where = new String("WHERE ");
    for (int t = 0; t < nwhere_expr - 1; t++) {
      where += where_expr[t] + "\n" + boolean_connector[t] + " ";
    }
    where += where_expr[nwhere_expr - 1];
  }

  private void SplitFrom() {
    try {
      int begin = ifrom + 6;
      int end;
      if (iwhere != -1)
        end = iwhere;
      else if (igroup_by != -1)
        end = igroup_by;
      else if (ihaving != -1)
        end = ihaving;
      else if (iorder_by != -1)
        end = iorder_by;
      else
        end = query.length();

      StringTokenizer tokens = new StringTokenizer(query.substring(begin,end).replaceAll(",", " , "));
      from = query.substring(begin, end);
      while (tokens.hasMoreElements()) {
        table[ntable] = tokens.nextToken();
        while (table[ntable].indexOf(",") == -1 && tokens.hasMoreElements()) {
          table[ntable] += " " + tokens.nextToken();
        }
        table[ntable] = table[ntable].replaceAll(",", "");
        ntable++;
      }

      //set vector table
      vt.clear();
      vt.ensureCapacity(ntable);
      for (int i = 0; i < ntable; i++) {
        if (table[i].indexOf(" ") != -1) { //have   synonym
          vt.add(table[i].substring(table[i].indexOf(" ") + 1).replaceAll(" ",""));
        }
        else
          vt.add(table[i].replaceAll(" ",""));
      }
    }
    catch (Exception e) {
      JOptionPane.showMessageDialog(null, e.toString());
    }
  }

  //swap table
  public void swapTable(int first, int second) {
    String tmp = table[first];
    table[first] = table[second];
    table[second] = tmp;
  }

  public boolean IsCountStar() {
    if ((select .replaceAll(" ","").equals("count(*)") ) && (iwhere == -1) && (ntable >= 2)) {
      return true;
    }


    return false;

  }



}