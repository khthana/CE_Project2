package project;

import java.sql.*;
import javax.swing.*;
import java.util.*;


public class Statistic {

  private Connection statConnection;
  private Statement stat_stmt;
  private PreparedStatement psNumRow, psIsIndex ;
  private ResultSet resultSet;

  private String stat_driver = new String("com.borland.datastore.jdbc.DataStoreDriver");
  private String stat_url = new String("jdbc:borland:dslocal:jdatastore\\statistic.jds");


  public Statistic() {
    try {
      Class.forName(stat_driver);
      statConnection = DriverManager.getConnection(stat_url, "null", "null");
      stat_stmt = statConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

    }
    catch (SQLException sqlException) {
      JOptionPane.showMessageDialog(null, sqlException.getMessage(),
                                    "Datastore Error", JOptionPane.ERROR_MESSAGE);
      System.exit(1);
    }
    catch (ClassNotFoundException classNotFound) {
      JOptionPane.showMessageDialog(null, classNotFound.getMessage(),
                                    "Driver Not Found",
                                    JOptionPane.ERROR_MESSAGE);
      System.exit(1);
    }

  }

  public int getNumRow(String temp) {
    int num=0;
    int index = 0;
    String table;
    index = temp.indexOf(" ");
    if (index==-1) {
      table = temp;
    } else
      table = temp.substring(0, index);


    try{
      psNumRow  = statConnection.prepareStatement("SELECT ROW FROM TABLE_INFO WHERE TABLE_NAME =?");
      psNumRow .setString(1,table);
      resultSet = psNumRow .executeQuery();
      resultSet.next();
      num =  resultSet.getInt(1);

    }catch (SQLException e) {
       JOptionPane.showMessageDialog(null,e.toString().substring(27) ,"Error",JOptionPane.ERROR_MESSAGE );
    } catch(NullPointerException e){
      JOptionPane.showMessageDialog(null,e.toString().substring(27) ,"Error",JOptionPane.ERROR_MESSAGE );
    }

    return num;
  }

  public boolean isIndex(String tempTB, String column) {
    int num=0;
    int index = 0;
    String table;
    index = tempTB.indexOf(" ");
    if (index==-1) {
      table = tempTB;
    } else
      table = tempTB.substring(0, index);
      column=column.replaceAll(" ","");
    try{
      psIsIndex  = statConnection.prepareStatement("SELECT ISINDEX FROM COLUMN_INFO WHERE TABLE_NAME =? AND COLUMN_NAME=?");
      psIsIndex .setString(1,table);
      psIsIndex .setString(2,column);
      resultSet= psIsIndex .executeQuery();
      resultSet.next();
      num =  resultSet.getInt(1);
  }catch (SQLException e) {
     JOptionPane.showMessageDialog(null,e.toString().substring(27) ,"Error",JOptionPane.ERROR_MESSAGE );
  } catch(NullPointerException e){
    JOptionPane.showMessageDialog(null,e.toString().substring(27) ,"Error",JOptionPane.ERROR_MESSAGE );
  }

  if (num==1) {
    return true;
  }
   return false;

  }

}