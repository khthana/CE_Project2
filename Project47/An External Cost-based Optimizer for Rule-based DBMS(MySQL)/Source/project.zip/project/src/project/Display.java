  package project;

  import java.awt.*;
  import java.awt.event.*;
  import javax.swing.*;
  import java.sql.*;
  import javax.swing.table.*;
  import java.util.*;
  import java.io.*;

  public class Display extends JFrame {
    JPanel contentPane;
    JTextArea edit_f = new JTextArea();
    JTextArea opm_f = new JTextArea();
    JScrollPane jScrollPane2 = new JScrollPane();
    JScrollPane jScrollPane3 = new JScrollPane();
    JButton connect_db = new JButton();
    JButton submit_q = new JButton();

    DBconnect connect = new DBconnect(this);
    Optimizer optimizer = new Optimizer();

    JTable resultTable = new JTable(15,6);
    JScrollPane jScrollPane1 = new JScrollPane(resultTable);

    private  int ifrom = -1;
  private int iselect = -1;
  private int iparen = -1;
   private int iparen2 =-1;
  private String txt="";
   private String temp="";

   private int count=0;


 // private DBconnect tableModel;
  static final String DEFAULT_QUERY = "SELECT * FROM categories WHERE CategoryID = 450";
  JButton exit_db = new JButton();
  JLabel numRow = new JLabel();
  JLabel timeShow = new JLabel();
  JButton analyze = new JButton();
  JButton dynamic = new JButton();
  JButton static_b = new JButton();
  JCheckBox opOrNot = new JCheckBox();

    //Construct the frame
    public Display() {
      enableEvents(AWTEvent.WINDOW_EVENT_MASK);
      try {
	jbInit();
      }
      catch(Exception e) {
	e.printStackTrace();
      }
    }

    //Component initialization
    private void jbInit() throws Exception  {
      contentPane = (JPanel) this.getContentPane();
      contentPane.setLayout(null);

      edit_f.setBackground(UIManager.getColor("ToolTip.background"));
//    edit_f.setEditable(true);
      edit_f.setText("");
      edit_f.setWrapStyleWord(true);
      edit_f.setLineWrap(true);
      jScrollPane2.setBounds(new Rectangle(4, 60, 288, 281));

      this.setSize(new Dimension(666, 680));
      this.setTitle("External Cost-based Optimizer for MySQL");

    opm_f.setBackground(SystemColor.info);
    opm_f.setEnabled(true);
    opm_f.setEditable(false);
    opm_f.setText("");
    opm_f.setWrapStyleWord(true);
    opm_f.setLineWrap(true);
    jScrollPane3.setBounds(new Rectangle(356, 58, 288, 284));

    jScrollPane1.setBounds(new Rectangle(1, 353, 644, 250));
    connect_db.setBackground(new Color(255, 212, 210));
    connect_db.setBounds(new Rectangle(6, 9, 93, 40));
    connect_db.setText("CONNECT");
    connect_db.addActionListener(new Display_connect_db_actionAdapter(this));
    submit_q.setBackground(new Color(255, 212, 210));
    submit_q.setBounds(new Rectangle(296, 185, 56, 32));
    submit_q.setText("OK");
    submit_q.addActionListener(new Display_submit_q_actionAdapter(this));
    exit_db.addActionListener(new Display_exit_db_actionAdapter(this));
    exit_db.setText("EXIT");
    exit_db.addActionListener(new Display_exit_db_actionAdapter(this));
    exit_db.setBounds(new Rectangle(553, 8, 93, 40));
    exit_db.setPreferredSize(new Dimension(55, 25));
    exit_db.setBackground(new Color(255, 212, 210));
    numRow.setBackground(SystemColor.scrollbar);
    numRow.setFont(new java.awt.Font("Dialog", 1, 13));
    numRow.setForeground(new Color(68, 97, 121));
    numRow.setHorizontalAlignment(SwingConstants.CENTER);
    numRow.setText("Number of rows ::");
    numRow.setBounds(new Rectangle(3, 610, 248, 26));
    resultTable.setBackground(new Color(188, 227, 247));
    resultTable.setEnabled(false);
    resultTable.setFont(new java.awt.Font("Dialog", 0, 12));
    timeShow.setFont(new java.awt.Font("Dialog", 1, 13));
    timeShow.setForeground(new Color(68, 97, 121));
    timeShow.setHorizontalAlignment(SwingConstants.CENTER);
    timeShow.setText("Time ::");
    timeShow.setBounds(new Rectangle(422, 611, 224, 26));
    analyze.addActionListener(new Display_analyze_actionAdapter(this));
    analyze.setText("ANALYZE");
    analyze.addActionListener(new Display_analyze_actionAdapter(this));
    analyze.setBounds(new Rectangle(280, 9, 93, 40));
    analyze.setBackground(new Color(255, 212, 210));
    dynamic.setBackground(new Color(255, 212, 210));
    dynamic.setBounds(new Rectangle(141, 8, 93, 40));
    dynamic.addActionListener(new Display_dynamic_actionAdapter(this));
    dynamic.setText("DYNAMIC");
    dynamic.addActionListener(new Display_dynamic_actionAdapter(this));
    dynamic.addActionListener(new Display_dynamic_actionAdapter(this));
    static_b.setBackground(new Color(255, 212, 210));
    static_b.setBounds(new Rectangle(420, 10, 91, 39));
    static_b.setEnabled(false);
    static_b.setToolTipText("");
    static_b.setText("STATIC");
    static_b.addActionListener(new Display_static_b_actionAdapter(this));
    opOrNot.setFont(new java.awt.Font("Dialog", 1, 13));
    opOrNot.setForeground(new Color(68, 97, 127));
    opOrNot.setText("optimize");
    opOrNot.setBounds(new Rectangle(286, 614, 90, 25));
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(submit_q, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(numRow, null);
    jScrollPane1.getViewport().add(resultTable, null);
    jScrollPane3.getViewport().add(opm_f, null);
    jScrollPane3.getViewport().add(opm_f, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
    jScrollPane2.getViewport().add(edit_f, null);
    jScrollPane2.getViewport().add(edit_f, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
    contentPane.add(timeShow, null);
    contentPane.add(exit_db, null);
    contentPane.add(connect_db, null);
    contentPane.add(analyze, null);
    contentPane.add(dynamic, null);
    contentPane.add(static_b, null);
    contentPane.add(opOrNot, null);

    exit_db.setEnabled(true);
    edit_f.setEnabled(true);
    analyze.setEnabled(false);
    dynamic.setEnabled(false);
    submit_q.setEnabled(false);

  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  void connect_db_actionPerformed(ActionEvent e) {
    connect.connectDB();
    resultTable.setModel(connect);
    analyze.setEnabled(true);
    dynamic.setEnabled(true);
    static_b.setEnabled(true);
    connect_db.setEnabled(false);
    edit_f.setEditable(false);

  }

  void submit_q_actionPerformed(ActionEvent e) {
    String sql;

    if (opOrNot.isSelected()) {
    sql = optimizer.Optimize(edit_f.getText());
  }
  else {
    sql = edit_f.getText();
  }

      opm_f.setText(sql);
      connect.setQuery(opm_f.getText());

    numRow.setText("Number of rows :: "+connect.getRowCount());
  timeShow.setText("Time ::  "+connect.getTime()+" ms.");

  }

  void exit_db_actionPerformed(ActionEvent e) {
    if (connect.isConnectedToDatabase()) {
      connect.disconnectFromDatabase();
    }
    System.exit(0);
  }

  void analyze_actionPerformed(ActionEvent e) {
    analyze.setEnabled(false);
    exit_db.setEnabled(false);
    edit_f.setEnabled(false);
    opm_f.setEnabled(false);
    analyze.setEnabled(false);
    dynamic.setEnabled(false);
    static_b.setEnabled(false);
    submit_q.setEnabled(false);

      connect.CheckDB();

      analyze.setEnabled(true);
      static_b.setEnabled(true);
      dynamic.setEnabled(true);
      exit_db.setEnabled(true);
      numRow.setText("Number of rows :: ");
      timeShow.setText("Time ::  ");

  }

  void dynamic_actionPerformed(ActionEvent e) {

    edit_f.setEnabled(true);
    edit_f.setEditable(true);
    opm_f.setEnabled(true);
    static_b.setEnabled(true);
    submit_q.setEnabled(true);
    exit_db.setEnabled(true);


  }


  private void openFile() {
   JFileChooser fileChooser = new JFileChooser();
   fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

   int result = fileChooser.showOpenDialog(this);

   if (result==JFileChooser.CANCEL_OPTION)
     return;

   File fileName = fileChooser.getSelectedFile();

   if (fileName == null || fileName.getName().equals("'"))
     JOptionPane.showMessageDialog(this,"Invalid File Name", "Invalid File Name", JOptionPane.ERROR_MESSAGE);
   else {
     if (fileName.isFile()) {
       try {
         BufferedReader input = new BufferedReader(
             new FileReader(fileName));
         StringBuffer buffer1 = new StringBuffer();
         StringBuffer buffer2 = new StringBuffer();
         String text;

         PrintStream MyTempFile = null;

        MyTempFile = new PrintStream(new FileOutputStream(fileName.getParent()+"\\temp.java"));

         while ( (text = input.readLine() ) != null) {
           buffer1.append(text + "\n");
           txt = checkSQL(text);
           MyTempFile.println(txt);

         }

         edit_f.append(buffer1.toString());

         MyTempFile.close();

         PrintStream file =  new PrintStream(  new FileOutputStream(fileName.getPath()  )  );
         File myTemp = new File(fileName.getParent()+"\\temp.java");

         BufferedReader fromTemp = new BufferedReader(new FileReader(myTemp));

            while ( (text = fromTemp.readLine() ) != null) {
              buffer2.append(text + "\n");
           file.println(text);

         }
         fromTemp.close();
         opm_f.append(buffer2.toString());
         file.close();

           myTemp.delete();
            }
         catch (IOException ioexception) {
           JOptionPane.showMessageDialog(this,"File Error","File Error", JOptionPane.ERROR_MESSAGE);

         }
     }
     else {
       JOptionPane.showMessageDialog(null,"This is not file.","ERROR",JOptionPane.ERROR_MESSAGE);
     }
   }


 }

 public String checkSQL(String word) {
   String word_temp;
   word_temp = word;
   word = word.toLowerCase();
   while (word.indexOf("  ") != -1) {
     word = word.replaceAll("  ", " ");
   }
   set_index(word);

   if ( (iparen != -1) && (iselect != -1) && (ifrom != -1)  && (iparen2 !=-1)) {
     String str="";

      txt = word.substring(iparen+2,iparen2);

      txt = optimizer.Optimize(txt);
      txt = txt.replaceAll("\n"," ");

      str =word_temp.substring(iparen2,word.length());

    temp = word_temp.substring(0,iparen+2)+txt+str;
    while (temp.indexOf("  ") != -1) {
       temp = temp.replaceAll("  ", " "); //replace two whitespace with one whitespace
     }

   }
   else {
     temp = word_temp;
   }

   return temp;
 }

 private void set_index(String word) {
   iparen = word.indexOf("(\"");
   iselect = word.indexOf("select ");
   ifrom = word.indexOf(" from ");
   iparen2 = word.indexOf("\")");

 }

  void static_b_actionPerformed(ActionEvent e) {
    edit_f.setEnabled(true);
    edit_f.setEditable(false);
    analyze.setEnabled(true);
    dynamic.setEnabled(true);
    submit_q.setEnabled(false);
    exit_db.setEnabled(true);
    opm_f.setEnabled(true);
    edit_f.setText("");
    opm_f.setText("");

    openFile();

  }


}

class Display_connect_db_actionAdapter implements java.awt.event.ActionListener {
  Display adaptee;

  Display_connect_db_actionAdapter(Display adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.connect_db_actionPerformed(e);
  }
}

class Display_submit_q_actionAdapter implements java.awt.event.ActionListener {
  Display adaptee;

  Display_submit_q_actionAdapter(Display adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.submit_q_actionPerformed(e);
  }
}

class Display_exit_db_actionAdapter implements java.awt.event.ActionListener {
  Display adaptee;

  Display_exit_db_actionAdapter(Display adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.exit_db_actionPerformed(e);
  }
}

class Display_analyze_actionAdapter implements java.awt.event.ActionListener {
  Display adaptee;

  Display_analyze_actionAdapter(Display adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.analyze_actionPerformed(e);
  }
}

class Display_dynamic_actionAdapter implements java.awt.event.ActionListener {
  Display adaptee;

  Display_dynamic_actionAdapter(Display adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.dynamic_actionPerformed(e);
  }
}

class Display_static_b_actionAdapter implements java.awt.event.ActionListener {
  Display adaptee;

  Display_static_b_actionAdapter(Display adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.static_b_actionPerformed(e);
  }
}
