package project;

import java.sql.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.*;

public class DBconnect extends AbstractTableModel {

  private Connection connection, statConnection, statconnection;
  private Statement statement, stat_stmt, statement2, statement3, statement4, stat_statement, stat_statement2;
  private String user;
  private ResultSet Tb_resultSet, CountRw_resultSet, Column_resultSet, Index_resultSet, stat_resultSet, Delete_resultSet;
  private PreparedStatement psTablerowInsert , psColumnInsert , psIsindexInsert, psIndexnameInsert, psStatInsertTable;
  private PreparedStatement psStatInsertColumn;
  private ResultSetMetaData metaData;
  private int numberOfRows;
  JFrame parent = new JFrame();
  long startTime,stopTime,time;


//  Statistic stat = new Statistic();

  String driver = new String("com.mysql.jdbc.Driver");
  String url    = new String( "jdbc:mysql://127.0.0.1:3306/test8");

  String stat_driver = new String("com.borland.datastore.jdbc.DataStoreDriver");
  String stat_url = new String("jdbc:borland:dslocal:jdatastore\\statistic.jds");
  String query  = new String("SELECT * FROM TABLE_INFO");

//  jdbc:borland:dslocal:jdatastore\\statistic.jds", "null","null

  private boolean connectedToDatabase = false;

  public DBconnect() {
  }

  public DBconnect(JFrame temp) {
    parent = temp;
  }

  public boolean connectDB () {
      try {
        user = JOptionPane.showInputDialog("Enter your user");
        Class.forName(driver);
        connection = DriverManager.getConnection(url,user,null);

        Class.forName(stat_driver);
        statConnection = DriverManager.getConnection(stat_url, "null", "null");


        statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        statement2 = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        statement3 = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        statement4 = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

        stat_statement2 = statConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        stat_stmt = statConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        stat_statement = statConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

        connectedToDatabase = true;

        if(connectedToDatabase){
         CheckDB();
          statSetQuery(query);
          }

      }
      catch (SQLException sqlException) {
        JOptionPane.showMessageDialog(null, sqlException.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
      }
      catch (ClassNotFoundException classNotFound) {
        JOptionPane.showMessageDialog(null, classNotFound.getMessage(),
                                      "Driver Not Found",
                                      JOptionPane.ERROR_MESSAGE);
        System.exit(1);
      }

      return false;
  }

  public Class getColumnClass( int column ) throws IllegalStateException
  {
     // ensure database connection is available
     if ( !connectedToDatabase )
        throw new IllegalStateException( "Not Connected to Database" );

     // determine Java class of column
     try {
        String className = metaData.getColumnClassName( column + 1 );

        // return Class object that represents className
        return Class.forName( className );
     }

     // catch SQLExceptions and ClassNotFoundExceptions
     catch ( Exception exception ) {
        exception.printStackTrace();
     }

     // if problems occur above, assume type Object
     return Object.class;
  }

  // get number of columns in ResultSet
  public int getColumnCount() throws IllegalStateException
  {
     // ensure database connection is available
     if ( !connectedToDatabase )
        throw new IllegalStateException( "Not Connected to Database" );

     // determine number of columns
     try {
        return metaData.getColumnCount();
     }

     // catch SQLExceptions and print error message
     catch ( SQLException sqlException ) {
        sqlException.printStackTrace();
     }

     // if problems occur above, return 0 for number of columns
     return 0;
  }

  // get name of a particular column in ResultSet
  public String getColumnName( int column ) throws IllegalStateException
  {
     // ensure database connection is available
     if ( !connectedToDatabase )
        throw new IllegalStateException( "Not Connected to Database" );

     // determine column name
     try {
        return metaData.getColumnName( column + 1 );
     }

     // catch SQLExceptions and print error message
     catch ( SQLException sqlException ) {
        sqlException.printStackTrace();
     }

     // if problems, return empty string for column name
     return "";
  }

  // return number of rows in ResultSet
  public int getRowCount() throws IllegalStateException
  {
     // ensure database connection is available
     if ( !connectedToDatabase )
        throw new IllegalStateException( "Not Connected to Database" );

     return numberOfRows;
  }

  // obtain value in particular row and column
  public Object getValueAt( int row, int column )
     throws IllegalStateException
  {
     // ensure database connection is available

     if ( !connectedToDatabase )
        throw new IllegalStateException( "Not Connected to Database" );

     // obtain a value at specified ResultSet row and column
     try {
        Tb_resultSet.absolute( row + 1 );
        return Tb_resultSet.getObject( column + 1 );
     }

     // catch SQLExceptions and print error message
     catch ( SQLException sqlException ) {
        sqlException.printStackTrace();
     }

     // if problems, return empty string object
     return "";
  }

  public void setQuery( String query )
  {
    try{
        // ensure database connection is available
        if (!connectedToDatabase)
          throw new IllegalStateException("Not Connected to Database");

        startTime = System.currentTimeMillis();

        // specify query and execute it
        Tb_resultSet = statement.executeQuery(query);

        stopTime = System.currentTimeMillis();
       time = stopTime - startTime;

        // obtain meta data for ResultSet
        metaData = Tb_resultSet.getMetaData();

        // determine number of rows in ResultSet
        Tb_resultSet.last();                                            // move to last row
        numberOfRows = Tb_resultSet.getRow();   // get row number

        // notify JTable that model has changed
        fireTableStructureChanged();
    }
    catch (SQLException sqlException) {
      JOptionPane.showMessageDialog(parent,sqlException.toString().substring(32) ,"Error",JOptionPane.DEFAULT_OPTION );
    }
  }

  public void disconnectFromDatabase() {
 //   if (!connectedToDatabase)
 //     throw new IllegalStateException("Not Connected to Database");

    //close Statement and Connection
    try{
      statement.close();
      connection.close();
    }

    //catch SQLExceptions and print error message
    catch (SQLException sqlException) {
      sqlException.printStackTrace();
    }

    //update database connection status
    finally {
      connectedToDatabase = false;
    }
  }

  public boolean isConnectedToDatabase() {
    return connectedToDatabase;
  }

  public void statSetQuery(String query) {
    try{
      Tb_resultSet = stat_stmt.executeQuery(query);

         // obtain meta data for ResultSet
         metaData = Tb_resultSet.getMetaData();

         // determine number of rows in ResultSet
         Tb_resultSet.last(); // move to last row
         numberOfRows = Tb_resultSet.getRow(); // get row number
         // notify JTable that model has changed
         fireTableStructureChanged();
     } catch (SQLException e) {
       JOptionPane.showMessageDialog(parent,e.toString().substring(32) ,"Error",JOptionPane.DEFAULT_OPTION );

     }

  }

  public long getTime() {
    return  time;
  }

public void Analyze() {
    try{
      int num_tb=0, num_column=0, num_index=0, isindex = 0;
      String tbName="", colName="", colType="", colIndex="", colIndexName="", indexName="";
      int count_row=0;
      int tb_stat=0, col_stat=0, index_stat=0, indname_stat=0;
           // ensure database connection is available
           if (!connectedToDatabase)
             throw new IllegalStateException("Not Connected to Database");

      // find Number Of Table in DB
      Tb_resultSet = statement.executeQuery("show table status from test8");
      metaData = Tb_resultSet.getMetaData();
      Tb_resultSet.last();
      num_tb = Tb_resultSet.getRow();
/*      System.out.println(num_tb);*/

      Tb_resultSet.first();
      for(int i=1; i<=num_tb; i++){ // loop of table
        //get Table_Name from DB
        tbName = Tb_resultSet.getString(1);
/*        System.out.println(tbName);*/

        //get count(*) of each table
        CountRw_resultSet = statement2.executeQuery("select count(*) from test8."+tbName);
        CountRw_resultSet.next();
        count_row = CountRw_resultSet.getInt(1);

        // update NumberOfRow in TABLE_INFO
        psTablerowInsert = statConnection.prepareStatement("UPDATE TABLE_INFO SET ROW = ? WHERE TABLE_NAME = ?");
        psTablerowInsert.setInt(1, count_row);
        psTablerowInsert.setString(2,tbName);
        tb_stat = psTablerowInsert.executeUpdate();

        // find Number of Column in Table
        Column_resultSet = statement3.executeQuery("show columns from test8."+tbName);
        Column_resultSet.last();
        num_column = Column_resultSet.getRow();
/*        System.out.println(num_column);*/

        Column_resultSet.first();
        for(int j=1; j<=num_column; j++){ // loop of column

          colName = Column_resultSet.getString(1);
          colName = colName.toLowerCase();
          colType = Column_resultSet.getString(2);
          colIndex = Column_resultSet.getString(4);
          if(colIndex.equals("PRI") || colIndex.equals("MUL")) isindex = 1; else isindex = 0;

          // update column in COLUMN_INFO
          psColumnInsert = statConnection.prepareStatement("UPDATE COLUMN_INFO SET DATATYPE = ? WHERE TABLE_NAME = ? AND COLUMN_NAME = ?");
          psColumnInsert.setString(1,colType);
          psColumnInsert.setString(2,tbName);
          psColumnInsert.setString(3,colName);
          col_stat = psColumnInsert.executeUpdate();

          psIsindexInsert = statConnection.prepareStatement("UPDATE COLUMN_INFO SET ISINDEX = ? WHERE TABLE_NAME = ? AND COLUMN_NAME = ?");
          psIsindexInsert.setInt(1,isindex);
          psIsindexInsert.setString(2,tbName);
          psIsindexInsert.setString(3,colName);
          index_stat = psIsindexInsert.executeUpdate();

          // find indexName
          if(isindex == 1){
            Index_resultSet = statement4.executeQuery("show index from test8." +
                tbName);
            Index_resultSet.last();
            num_index = Index_resultSet.getRow();
/*            System.out.println(num_index);*/

            Index_resultSet.first();
            for (int k = 1; k <= num_index; k++) {
              colIndexName = Index_resultSet.getString(5);
              if (colName.equals(colIndexName))
                indexName = Index_resultSet.getString(3);

/*              System.out.println(indexName);*/
              Index_resultSet.next();
            }
          } else indexName = "";

          // update INDEX_NAME in COLUMN_INFO
          psIndexnameInsert = statConnection.prepareStatement("UPDATE COLUMN_INFO SET INDEX_NAME = ? WHERE TABLE_NAME = ? AND COLUMN_NAME = ?");
          psIndexnameInsert.setString(1,indexName);
          psIndexnameInsert.setString(2,tbName);
          psIndexnameInsert.setString(3,colName);
          indname_stat = psIndexnameInsert.executeUpdate();

          Column_resultSet.next();
        }

        Tb_resultSet.next();
      }

       psTablerowInsert .close();
       psColumnInsert.close();
       psIsindexInsert.close();
       psIndexnameInsert.close();
//       connection.commit();
       statSetQuery(query);
       }
       catch (SQLException sqlException) {
         JOptionPane.showMessageDialog(parent,sqlException.toString().substring(32) ,"Error",JOptionPane.DEFAULT_OPTION );
       }

  }

  public void CheckDB(){
    try{
      int num_tb=0, num_tb_stat=0;
      String table="", stat_tb="";
      boolean isexist = false, iscreate = false;
    if (!connectedToDatabase)
             throw new IllegalStateException("Not Connected to Database");

      // find Number Of Table in DB
      Tb_resultSet = statement.executeQuery("show table status from test8");
      Tb_resultSet.last();
      num_tb = Tb_resultSet.getRow();

      stat_resultSet = stat_statement.executeQuery("select * from TABLE_INFO");
      stat_resultSet.last();
      num_tb_stat = stat_resultSet.getRow();
/*      System.out.println(num_tb_stat);*/

      stat_resultSet.first();
      if(num_tb == num_tb_stat){
        for(int i=1; i<=num_tb_stat; i++){
          stat_tb = stat_resultSet.getString(1);

          Tb_resultSet.first();
          for(int j=1; j<=num_tb; j++){
            table = Tb_resultSet.getString(1);
            if(table.equals(stat_tb)){isexist = true;}
            Tb_resultSet.next();
          }

          if(isexist == false){
            iscreate = true;
          }
          stat_resultSet.next();
          isexist = false;
        }
      } else iscreate = true;

        if(iscreate){
          this.CreateDB(Tb_resultSet, num_tb);
        } else this.Analyze();

    }
    catch (SQLException sqlException) {
           JOptionPane.showMessageDialog(parent,sqlException.toString().substring(32) ,"Error",JOptionPane.DEFAULT_OPTION );
    }
  }

public void CreateDB(ResultSet result, int num_tb){
  try{
    String table="", colName="";
    int num_column=0;
    if (!connectedToDatabase)
            throw new IllegalStateException("Not Connected to Database");



          int del = stat_statement2.executeUpdate("delete from TABLE_INFO");
          del = stat_statement2.executeUpdate("delete from COLUMN_INFO");
          psStatInsertTable = statConnection.prepareStatement("insert into TABLE_INFO values(?,0)");
          psStatInsertColumn = statConnection.prepareStatement("insert into COLUMN_INFO values(?,?,null,0,null)");

          result.first();
          for(int i=1; i<=num_tb; i++){
            table = result.getString(1);

            psStatInsertTable.setString(1,table);
            psStatInsertTable.executeUpdate();

            // find Number of Column in Table
            Column_resultSet = statement3.executeQuery("show columns from test8."+table);
            Column_resultSet.last();
            num_column = Column_resultSet.getRow();
/*            System.out.println(num_column);*/

            Column_resultSet.first();
            for(int j=1; j<=num_column; j++){
              colName = Column_resultSet.getString(1);
              colName = colName.toLowerCase();

              psStatInsertColumn.setString(1,table);
              psStatInsertColumn.setString(2,colName);
              psStatInsertColumn.executeUpdate();

              Column_resultSet.next();
            }


            result.next();
          }

          this.Analyze();

  } catch (SQLException e){
    JOptionPane.showMessageDialog(parent,e.toString().substring(32) ,"Error",JOptionPane.DEFAULT_OPTION );
  }
}

}
