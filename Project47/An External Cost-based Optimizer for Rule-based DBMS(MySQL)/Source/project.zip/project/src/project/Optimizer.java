package project;

import javax.swing.*;

public class Optimizer {

  private String input;
  private String output;
  private statementSQL sqlstmt = new statementSQL();
  private Statistic stat = new Statistic();

  public Optimizer() {
  }

  public String getInput() {
    return input;
  }

  public void setInput(String input) {
    this.input = input;
  }

  public String getOutput() {
    return output;
  }

  public void setOutput(String output) {
    this.output = output;
  }

  private void OptimizeCatesian() {
    int row[] = new int[sqlstmt.getNumberOfTable()];
    int temp;
    for (int i = 0; i < sqlstmt.getNumberOfTable(); i++) {
      row[i] = stat.getNumRow(sqlstmt.getTable(i));
    }

    output = "SELECT " + sqlstmt.getSelectString() + "\nFROM ";
    for (int i = 0; i < row.length - 1; i++) {
      for (int j = 0; j < row.length - 1 - i; j++) {
        if (row[j + 1] < row[j]) { // compare the two neighbors
          //swap
          temp = row[j];
          row[j] = row[j + 1];
          row[j + 1] = temp;
          sqlstmt.swapTable(j, j + 1);
        }
      }
    }
    String from = sqlstmt.getTable(0);
    for (int i = 1; i < sqlstmt.getNumberOfTable(); i++) {
      from += " STRAIGHT_JOIN " + sqlstmt.getTable(i);
    }
    output += from + "\n" + sqlstmt.getWhere() + "\n" + sqlstmt.getGroup_by() +
        "\n" + sqlstmt.getHaving() + "\n" + sqlstmt.getOrder_by();
  }

  public String Optimize(String input) {

    sqlstmt.setSql(input);

    if (sqlstmt.IsCountStar()) {
    optimizeCountStar();
    }
    else if(sqlstmt.IsCatesian()) {
      OptimizeCatesian();
    }
    else if (sqlstmt.IsMultipleOR())  {
      if (sqlstmt.IsAllJoin()){
        if (!stat.isIndex(sqlstmt.getTable(0),sqlstmt.getColumn())) {
          output = "SELECT " + sqlstmt.getSelectString() +
              "\nFROM " + sqlstmt.getFrom() + "\n" + "WHERE " +
              sqlstmt.getValue() + "\n" +
              sqlstmt.getGroup_by() + "\n" + sqlstmt.getHaving() + "\n" +
              sqlstmt.getOrder_by();
        }
        else {
          output = "SELECT " + sqlstmt.getSelectString() +
              "\nFROM " + sqlstmt.getFrom() + "\n" + sqlstmt.getWhere() + "\n" +
              sqlstmt.getGroup_by() + "\n" + sqlstmt.getHaving() + "\n" +
              sqlstmt.getOrder_by();
        }
      }
      else{
        output = "SELECT " + sqlstmt.getSelectString() +
            "\nFROM " + sqlstmt.getFrom() + "\n" + sqlstmt.getWhere() + "\n" +
            sqlstmt.getGroup_by() + "\n" + sqlstmt.getHaving() + "\n" +
            sqlstmt.getOrder_by();

      }
    }

    else {
      output = "SELECT " + sqlstmt.getSelectString() +
          "\nFROM " + sqlstmt.getFrom() + "\n" + sqlstmt.getWhere() + "\n" +
          sqlstmt.getGroup_by() + "\n" + sqlstmt.getHaving() + "\n" +
          sqlstmt.getOrder_by();
//    }

    }

    return output;
  }

public void optimizeCountStar() {
    int row[] = new int[sqlstmt.getNumberOfTable()];
    int temp;
    for (int i = 0; i < sqlstmt.getNumberOfTable(); i++) {
      row[i] = stat.getNumRow(sqlstmt.getTable(i));
    }

    output = "SELECT" + sqlstmt.getSelectString() + "\nFROM ";
    for (int i = 0; i < row.length - 1; i++) {
      for (int j = 0; j < row.length - 1 - i; j++) {
        if (row[j + 1] > row[j]) { // compare the two neighbors
          //swap
          temp = row[j];
          row[j] = row[j + 1];
          row[j + 1] = temp;
          sqlstmt.swapTable(j, j + 1);
        }
      }
    }

    String from = sqlstmt.getTable(0);
    for (int i = 1; i < sqlstmt.getNumberOfTable(); i++) {
      from += "," + sqlstmt.getTable(i);
    }
    output += from + "\n" + sqlstmt.getWhere() + "\n" + sqlstmt.getGroup_by() +
        "\n" + sqlstmt.getHaving() + "\n" + sqlstmt.getOrder_by();
  }






}