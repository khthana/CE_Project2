// PreProgramDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PreProgram.h"
#include "PreProgramDlg.h"
#include "Info.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreProgramDlg dialog

CPreProgramDlg::CPreProgramDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPreProgramDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
}

void CPreProgramDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreProgramDlg)
	DDX_Control(pDX, IDC_TEST, m_Test);
	DDX_Control(pDX, IDC_STOP, m_Stop);
	DDX_Control(pDX, IDC_INIT, m_Init);
	DDX_Control(pDX, IDC_CONFIG, m_Config);
	DDX_Control(pDX, IDC_CHECKVALUE, m_CheckValue);
	DDX_Control(pDX, IDC_VIDEOOCXCTRL1, m_video);
	DDX_Control(pDX, IDC_VIDEOOCXTOOLSCTRL1, m_videoTool);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPreProgramDlg, CDialog)
	//{{AFX_MSG_MAP(CPreProgramDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONFIG, OnConfig)
	ON_BN_CLICKED(IDC_INIT, OnInit)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_CHECKVALUE, OnCheckvalue)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_WM_SIZE()
	ON_MESSAGE(WM_USER,OnIcon)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreProgramDlg message handlers

BOOL CPreProgramDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;
	m_GrayImage = 0;
	m_GrayResultImage = 0;
	m_GrayHelperImage = 0;
	m_Running = false;
	FDPointFinger = -1;
	CPointFinger = -1;
	PointFinger = -1;
	m_state = 0;
	countBClick = 0;
	countClick = 0;
	countDBClick = 0;
	countOutScreen = 0;
	TempClickPoint = -1;
	DragDrop = false;
	outClick = false;
	Capture1 = 0;
	Capture2 = 0;
	TempCap = 0;
	checkFirst = true;
	CountScreen = 0;
	check_hide = false;
	IO = 0;
	FlagIn = false;
	countOut = 0;

	m_CheckValue.EnableWindow(false);
	m_Test.EnableWindow(false);
	m_Stop.EnableWindow(false);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPreProgramDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPreProgramDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

UINT CaptureThread(LPVOID pParam)
{
	CPreProgramDlg *parent;
	parent = (CPreProgramDlg *)pParam;

	while (parent->m_Running) {
		switch (parent->m_Status) {
		case RUNNING :
			if (parent->m_video.Capture(parent->m_Image))		
				parent->m_video.Show(parent->m_Image);
			break;
		case CHECKVALUE :
			if (parent->m_video.Capture(parent->m_Image)) {
				BYTE *data = (BYTE*)parent->m_video.GetDataPointer(parent->m_Image);
				int size = parent->m_video.GetImageDataSize(parent->m_Image);
				int width = parent->m_video.GetWidth();
				int height = parent->m_video.GetHeight();

				for (int i=0; i<size; i++) {
					if ((i%3)==0) {
						if (!parent->InScreen1(i/3,width,height)) {
							data[i] = 255;
							data[i+1] = 255;
							data[i+2] = 255;
						}
					}
				}

				data[parent->Inf.Point1*3] = 255;
				data[parent->Inf.Point1*3+1] = 0;
				data[parent->Inf.Point1*3+2] = 0;
				data[parent->Inf.Point2*3] = 255;
				data[parent->Inf.Point2*3+1] = 0;
				data[parent->Inf.Point2*3+2] = 0;
				data[parent->Inf.Point3*3] = 255;
				data[parent->Inf.Point3*3+1] = 0;
				data[parent->Inf.Point3*3+2] = 0;
				data[parent->Inf.Point4*3] = 255;
				data[parent->Inf.Point4*3+1] = 0;
				data[parent->Inf.Point4*3+2] = 0;
				data[parent->Inf.Point5*3] = 255;
				data[parent->Inf.Point5*3+1] = 0;
				data[parent->Inf.Point5*3+2] = 0;
				data[parent->Inf.Point6*3] = 255;
				data[parent->Inf.Point6*3+1] = 0;
				data[parent->Inf.Point6*3+2] = 0;
				data[parent->Inf.Point7*3] = 255;
				data[parent->Inf.Point7*3+1] = 0;
				data[parent->Inf.Point7*3+2] = 0;
				data[parent->Inf.Point8*3] = 255;
				data[parent->Inf.Point8*3+1] = 0;
				data[parent->Inf.Point8*3+2] = 0;

				data[parent->Inf.FingerPoint1*3] = 0;
				data[parent->Inf.FingerPoint1*3+1] = 0;
				data[parent->Inf.FingerPoint1*3+2] = 255;
				data[parent->Inf.FingerPoint2*3] = 0;
				data[parent->Inf.FingerPoint2*3+1] = 0;
				data[parent->Inf.FingerPoint2*3+2] = 255;
				data[parent->Inf.FingerPoint3*3] = 0;
				data[parent->Inf.FingerPoint3*3+1] = 0;
				data[parent->Inf.FingerPoint3*3+2] = 255;
				data[parent->Inf.FingerPoint4*3] = 0;
				data[parent->Inf.FingerPoint4*3+1] = 0;
				data[parent->Inf.FingerPoint4*3+2] = 255;
				data[parent->Inf.FingerPoint5*3] = 0;
				data[parent->Inf.FingerPoint5*3+1] = 0;
				data[parent->Inf.FingerPoint5*3+2] = 255;
				data[parent->Inf.FingerPoint6*3] = 0;
				data[parent->Inf.FingerPoint6*3+1] = 0;
				data[parent->Inf.FingerPoint6*3+2] = 255;
				data[parent->Inf.FingerPoint7*3] = 0;
				data[parent->Inf.FingerPoint7*3+1] = 0;
				data[parent->Inf.FingerPoint7*3+2] = 255;
				data[parent->Inf.FingerPoint8*3] = 0;
				data[parent->Inf.FingerPoint8*3+1] = 0;
				data[parent->Inf.FingerPoint8*3+2] = 255;

				data[parent->Inf.Base1] = 255;
				data[parent->Inf.Base1+1] = 0;
				data[parent->Inf.Base1+2] = 0;
			
				parent->m_video.Show(parent->m_Image);
			}
			break;
		
		case TEST :

			if (parent->checkFirst) {
				if (parent->m_video.Capture(parent->Capture1)) {
					parent->checkFirst = false;
				}
			}else {
				if (parent->m_video.Capture(parent->Capture2)) {
					// Color	
					BYTE *d1 = (BYTE*)parent->m_video.GetDataPointer(parent->Capture1); 
					BYTE *d2 = (BYTE*)parent->m_video.GetDataPointer(parent->Capture2); 
					BYTE *Cdata = (BYTE*)parent->m_video.GetDataPointer(parent->TempCap); 
					int width = parent->m_video.GetWidth();
					int height = parent->m_video.GetHeight();
					int Csize = parent->m_video.GetImageDataSize(parent->Capture2);

					// Gray Image
					BYTE *Gdata;
					int Gsize;
					if (parent->m_video.ToGray(parent->m_Image,parent->m_GrayImage)) {
						Gdata = (BYTE*)parent->m_video.GetDataPointer(parent->m_GrayImage);
						Gsize = parent->m_video.GetImageDataSize(parent->m_GrayImage);
					}else {
						parent->MessageBox("ToGray Error",NULL,MB_OK);
					}

					// Frame Difference
					for (int i=0; i<Csize; i++) {
						int temp = (int)d2[i] - (int)d1[i];
						if (temp>255) {
							temp = 255;
						}else if (temp<0) {
							temp = -temp;
						}
						Cdata[i] = temp;
							
					}

					// remove noise //
					parent->RemoveNoiseColor(Cdata,width,height,Csize);

					// dilation //
					parent->Dilation(Cdata,width,height,Gsize);

				if (parent->m_state == 0) {
					// find point from frame differnce
					int Cs = 30;
					long tempPoint = parent->FindFDiffPoint(Cdata,Cs,width,height,Gsize,d2,d1);

					if (tempPoint != -1) {
						parent->FDPointFinger = tempPoint;

						int Cs = 30*3;
						parent->CPointFinger = parent->FindColorPoint(d2,Cs,width,height,d1);

						if ( (parent->CPointFinger == -1) || (parent->CheckPointClose(parent->CPointFinger/3,parent->FDPointFinger,width,height,5)) ){
							parent->countOutScreen = 0;
							parent->CheckStateMouse(width,height);
							
						}else if ( (parent->CPointFinger != -1) && (!parent->CheckPointClose(parent->CPointFinger/3,parent->FDPointFinger,width,height,5)) ){
							parent->CheckOutScreen(width,height);
						}
					
		
					}else {
						parent->CheckOutScreen(width,height);
					}

				}else {

					parent->IO = parent->checkframe(Cdata,width,height,d2); // 0 = out

					if (parent->IO == 0) {
						parent->IO = parent->checkframe1(Cdata,width,height,d2);
					}

					parent->CheckStateMouse(width,height);

				}
			
					parent->FDPointFinger = -1;
					parent->CPointFinger = -1;
				
					for (i=0; i<Csize; i++) {
						d1[i] = d2[i];
					}
				}
			}
			break;
		}
	}

	return(0);
}

void CPreProgramDlg::OnConfig() // To configuration
{
	// TODO: Add your control notification handler code here
	m_config = new ProgramConfig();

	m_config->GetHandleVideo(&m_video,&m_videoTool);
	m_config->GetInfo(&Inf);
	m_config->ShowWindow(SW_SHOW);

	m_CheckValue.EnableWindow(true);
	m_Test.EnableWindow(true);
	m_Stop.EnableWindow(false);

}

void CPreProgramDlg::OnInit()  // set interface of webcam
{
	// TODO: Add your control notification handler code here
	// if control was initialized before, do nothing:
	if (m_Image != 0)
		return;
	
	// disable internal error message display
	m_video.SetErrorMessages(0);

	if (!m_video.Init())
	{
		// Error while trying to init control
		MessageBox(m_video.GetLastErrorString(), "VideoOCX Error", MB_OK);
		return;		// exit
	}

	// allocate memory for all images that will be needed to demonstrate VideoOCXTools - features
	//  Make sure you free the resources later using VideoOCX::ReleaseImageHandle(long).
	m_Image = m_video.GetColorImageHandle();
	m_ResultImage = m_video.GetColorImageHandle();
	m_HelperImage = m_video.GetColorImageHandle();
	m_GrayImage = m_video.GetGrayImageHandle();
	m_GrayResultImage = m_video.GetGrayImageHandle();
	m_GrayHelperImage = m_video.GetGrayImageHandle();
	Sleep(100);		// make sure VideoOCX has time to be properly initialized

	if (m_video.Start()){
		m_Running = TRUE;
		m_Status = RUNNING;
		AfxBeginThread(CaptureThread, this);	// start capture thread
	}

	m_Init.EnableWindow(false);
	m_Stop.EnableWindow(true);
	m_Config.EnableWindow(false);
}

void CPreProgramDlg::OnStop()  // stop interface of webcam
{
	// TODO: Add your control notification handler code here
	m_Running = FALSE;	// tell thread to end
	Sleep(250);			// wait for thread to end

	// end capture mode
	if (!m_video.Stop())
	{
		// error
		MessageBox(m_video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
	
	// free memory
	m_video.ReleaseImageHandle(m_Image);
	m_video.ReleaseImageHandle(m_ResultImage);
	m_video.ReleaseImageHandle(m_HelperImage);
	m_video.ReleaseImageHandle(m_GrayImage);
	m_video.ReleaseImageHandle(m_GrayResultImage);
	m_video.ReleaseImageHandle(m_GrayHelperImage);
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;
	m_GrayImage = 0;
	m_GrayResultImage = 0;
	m_GrayHelperImage = 0;

	//	close video connection and free memory

	if (!m_video.Close())
	{
		// error while closing video connection
		MessageBox(m_video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}

	m_Init.EnableWindow(true);
	m_Config.EnableWindow(true);
	m_Stop.EnableWindow(false);
	m_CheckValue.EnableWindow(false);
	m_Test.EnableWindow(false);
}

void CPreProgramDlg::OnCheckvalue() 
{
	// TODO: Add your control notification handler code here
	if (m_Status == CHECKVALUE)
		m_Status = RUNNING;
	else
		m_Status = CHECKVALUE;
}

bool CPreProgramDlg::InScreen(long point, int width, int height) // check point in screen
{
	int xxx = point % width;
	int yyy = point / width;
	int count = 0;

	if ( ((height/2)-Inf.LeftUpY) >= (Inf.m1*((width/2)-Inf.LeftUpX)) ) {
		if ((yyy-Inf.LeftUpY) >= (Inf.m1*(xxx-Inf.LeftUpX))) {
			count++;
		}
	}else {
		if ((yyy-Inf.LeftUpY) <= (Inf.m1*(xxx-Inf.LeftUpX))) {
			count++;
		}
	}

	if (((height/2)-Inf.LeftDownY) >= (Inf.m2*((width/2)-Inf.LeftDownX))) {
		if ((yyy-Inf.LeftDownY) >= (Inf.m2*(xxx-Inf.LeftDownX))) {
			count++;
		}
	}else {
		if ((yyy-Inf.LeftDownY) >= (Inf.m2*(xxx-Inf.LeftDownX))) {
			count++;
		}
	}

	if (((height/2)-Inf.LeftUpY) <= (Inf.m3*((width/2)-Inf.LeftUpX))) {
		if ((yyy-Inf.LeftUpY) <= (Inf.m3*(xxx-Inf.LeftUpX))) {
			count++;
		}
	}else {
		if ((yyy-Inf.LeftUpY) >= (Inf.m3*(xxx-Inf.LeftUpX+20))) {
			count++;
		}
	}

	if (((height/2)-Inf.RightUpY) >= (Inf.m4*((width/2)-Inf.RightUpX))) {
		if ((yyy-Inf.RightUpY) >= (Inf.m4*(xxx-Inf.RightUpX))) {
			count++;
		}
	}else {
		if ((yyy-Inf.RightUpY) <= (Inf.m4*(xxx-Inf.RightUpX))) {
			count++;
		}
	}

	if (count == 4) {
		return true;
	}

	return false;
}

bool CPreProgramDlg::InScreen1(long point, int width, int height) // check point in edge screen
{
	int xxx = point % width;
	int yyy = point / width;
	int count = 0;

	if ( (xxx<0) || (xxx>width-1) || (yyy<0) || (yyy>height-1) ) {
		return false;
	}

	if ( ((height/2)-Inf.LeftUpY-20) >= (Inf.m1*((width/2)-Inf.LeftUpX)) ) {
		if ((yyy-Inf.LeftUpY-20) >= (Inf.m1*(xxx-Inf.LeftUpX))) {
			count++;
		}
	}else {
		if ((yyy-Inf.LeftUpY-20) <= (Inf.m1*(xxx-Inf.LeftUpX))) {
			count++;
		}
	}

	if (((height/2)-Inf.LeftDownY+15) >= (Inf.m2*((width/2)-Inf.LeftDownX))) {
		if ((yyy-Inf.LeftDownY+15) >= (Inf.m2*(xxx-Inf.LeftDownX))) {
			count++;
		}
	}else {
		if ((yyy-Inf.LeftDownY+15) >= (Inf.m2*(xxx-Inf.LeftDownX))) {
			count++;
		}
	}

	if (((height/2)-Inf.LeftUpY) <= (Inf.m3*((width/2)-Inf.LeftUpX+20))) {
		if ((yyy-Inf.LeftUpY) <= (Inf.m3*(xxx-Inf.LeftUpX+20))) {
			count++;
		}
	}else {
		if ((yyy-Inf.LeftUpY) >= (Inf.m3*(xxx-Inf.LeftUpX+20))) {
			count++;
		}
	}

	if (((height/2)-Inf.RightUpY) >= (Inf.m4*((width/2)-Inf.RightUpX-20))) {
		if ((yyy-Inf.RightUpY) >= (Inf.m4*(xxx-Inf.RightUpX-20))) {
			count++;
		}
	}else {
		if ((yyy-Inf.RightUpY) <= (Inf.m4*(xxx-Inf.RightUpX-20))) {
			count++;
		}
	}

	if (count == 4) {
		return true;
	}

	return false;
}

long CPreProgramDlg::FindColorPoint(BYTE *Cdata, int size, int width, int height,BYTE* d1)
{
	int s = size; // 30*3
	int *tempdata = new int[width*height*3];
	long begin;
	long end;
	long tempPointC = -1;

	for (int j = 0; j < width*height*3; j++){
		tempdata[j] = Cdata[j];
	}

	if (PointFinger != -1) {

		begin = (PointFinger - (width*20) - 10)*3;
		end = (PointFinger + (width*10) + 20)*3;
	
	}else {
		begin = (FDPointFinger - (width*20) - 10)*3;
		end = (FDPointFinger + (width*10) + 20)*3;
	}	

	for (int i=begin; i<=end; i++) {
		if ( (i%3) == 0 ) {
			if ( InScreen(i/3,width,height) ) {
				// white balance
				int ref1 = Inf.BaseB1 - tempdata[Inf.Base1];
				int ref2 = Inf.BaseG1 - tempdata[Inf.Base1+1];
				int ref3 = Inf.BaseR1 - tempdata[Inf.Base1+2];

				int temp = tempdata[i] + ref1;
				if (temp < 0)
					tempdata[i] = 0;
				else if (temp > 255)
					tempdata[i] = 255;
				else
					tempdata[i] = temp;

				temp = tempdata[i+1] + ref2;
				if (temp < 0)
					tempdata[i+1] = 0;
				else if (temp > 255)
					tempdata[i+1] = 255;
				else
					tempdata[i+1] = temp;

				temp = tempdata[i+2] + ref3;
				if (temp < 0)
					tempdata[i+2] = 0;
				else if (temp > 255)
					tempdata[i+2] = 255;
				else
					tempdata[i+2] = temp;

				if ( ((tempdata[i+2] - tempdata[i+1]) >= 0) && ((tempdata[i+1] - tempdata[i]) >= 0) &&
					 (tempdata[i+2] >= Inf.MinR) && (tempdata[i+2] <= Inf.MaxR) &&
					 (tempdata[i+1] >= Inf.MinG) && (tempdata[i+1] <= Inf.MaxG) &&
					 (tempdata[i] >= Inf.MinB) && (tempdata[i] <= Inf.MaxB) &&
					 ((tempdata[i+2]-tempdata[i+1]) >= Inf.MinDifRG) && ((tempdata[i+2]-tempdata[i+1]) <= Inf.MaxDifRG) &&
					 ((tempdata[i+1]-tempdata[i]) >= Inf.MinDifGB) && ((tempdata[i+1]-tempdata[i]) <= Inf.MaxDifGB) &&
					 ((tempdata[i+2]-tempdata[i]) >= Inf.MinDifRB) && ((tempdata[i+2]-tempdata[i]) <= Inf.MaxDifRB) ) {
							
					if (i > tempPointC) {
						tempPointC = i;
					}

				}
			}
				
		}

		s--;
		if (s == 0) {
			s = size;
			i = i+(width-(size/3))*3;
		}
	}

	delete tempdata;

	return tempPointC;
}

bool CPreProgramDlg::CheckPointClose(long Point1, long Point2, int width, int height, int size)
{
	int Cx = Point1 % width;
	int Cy = Point1 / width;
	int Gx = Point2 % width;
	int Gy = Point2 / width;

	if ( ((Cx-Gx) >= -size) && ((Cx-Gx) <= size) &&
		 ((Cy-Gy) >= -size) && ((Cy-Gy) <= size) ) {	
			
		return true;

	}else{
		return false;								
	}

	return false;
}

void CPreProgramDlg::CheckStateMouse(int width,int height)
{	
	int Fx = FDPointFinger % width;
	int Fy = FDPointFinger / width;
	int Cx = (CPointFinger/3) % width;
	int Cy = (CPointFinger/3) / width;
	Fx = (Fx + Cx)/2;
	Fy = (Fy + Cy)/2;

	switch (m_state) {
	case 0 :
		if (PointFinger == FDPointFinger) {
			countBClick++;
			if (countBClick >= Inf.FrameRate) {
				m_state = 1;
				TempClickPoint = FDPointFinger;
				
			}
		}else{
			PointFinger = FDPointFinger;
			MouseSignal(0,width,height);
			if (DragDrop) {
				ClearValue();
				DragDrop = true;
			}else {
				ClearValue();
			}
							
		}
		break;
	case 1 :
		
		if (outClick) {
			CountScreen = 0;
			countClick++;
			if (countClick <= Inf.FrameRate) {
				
				if (IO == 1) {
					if (DragDrop) {
						m_state = 0;
						outClick = false;
						ClearValue();
						MouseSignal(4,width,height);
					}else{
						m_state = 2;
						outClick = false;
						MouseSignal(1,width,height);
					}
				}
			}else {
				
				if (DragDrop) {
					m_state = 0;
					ClearValue();
					DragDrop = true;
				}else {
					PointFinger = -1;
					m_state = 0;
					ClearValue();
				}
				
			}
		}else {
			if (FlagIn) {
				if (IO == 0) {
					outClick = true;
					FlagIn = false;
					
				}
			}else {
				if (IO == 1) {
					FlagIn = true;
				}
			}

			countOut++;
			if (countOut >= Inf.FrameRate*2) {
				PointFinger = -1;
				m_state = 0;
				ClearValue();
			}
		}
		break;

	case 2 :
		countDBClick++;
		if (countDBClick <= Inf.FrameRate) {
			if (outClick) {			
				if (IO == 1) {			
					outClick = false;
					MouseSignal(1,width,height);
					
					ClearValue();
					m_state = 0;
					
				}
			}else {
				if (FlagIn) {
					if (IO == 0) {
						outClick = true;
						FlagIn = false;
					}
				}else {
					if (IO == 1) {
						FlagIn = true;
					}
				}
			}
		}else {
			PointFinger = -1;
			if (!outClick) {
				ClearValue();
				DragDrop = true;
				m_state = 0;
				outClick = false;
				MouseSignal(3,width,height);
			}else {
				PointFinger = -1;
				m_state = 0;
				ClearValue();
			}
		}
		break;
	}
}

void CPreProgramDlg::MouseSignal(int p, int width, int height)
{
	double x;
	double y;
	double TempX1;
	double TempY1;
	double TempX2;
	double TempY2;
	long PosX;
	long PosY;


	LPPOINT point = &pt;
	if (GetCursorPos(point)) {
		switch (p) {
		case 0 : // Move Mouse
			x = PointFinger % width;
			y = height - (PointFinger / width);

			// Tranformation
			TempX1 = ( (x*x*x*Inf.PointXConstant[0]) + (y*y*y*Inf.PointXConstant[1]) + (x*x*y*Inf.PointXConstant[2]) + (x*y*y*Inf.PointXConstant[3]) + (x*y*Inf.PointXConstant[4]) + (x*Inf.PointXConstant[5]) + (y*Inf.PointXConstant[6]) + (Inf.PointXConstant[7]) );
			TempY1 = ( (x*x*x*Inf.PointYConstant[0]) + (y*y*y*Inf.PointYConstant[1]) + (x*x*y*Inf.PointYConstant[2]) + (x*y*y*Inf.PointYConstant[3]) + (x*y*Inf.PointYConstant[4]) + (x*Inf.PointYConstant[5]) + (y*Inf.PointYConstant[6]) + (Inf.PointYConstant[7]) );

			TempX2 = ( (TempX1*TempX1*TempX1*Inf.XConstant[0]) + (TempY1*TempY1*TempY1*Inf.XConstant[1]) + (TempX1*TempX1*TempY1*Inf.XConstant[2]) + (TempX1*TempY1*TempY1*Inf.XConstant[3]) + (TempX1*TempY1*Inf.XConstant[4]) + (TempX1*Inf.XConstant[5]) + (TempY1*Inf.XConstant[6]) + (Inf.XConstant[7]) );
			TempY2 = ( (TempX1*TempX1*TempX1*Inf.YConstant[0]) + (TempY1*TempY1*TempY1*Inf.YConstant[1]) + (TempX1*TempX1*TempY1*Inf.YConstant[2]) + (TempX1*TempY1*TempY1*Inf.YConstant[3]) + (TempX1*TempY1*Inf.YConstant[4]) + (TempX1*Inf.YConstant[5]) + (TempY1*Inf.YConstant[6]) + (Inf.YConstant[7]) );

			PosX = (long) TempX2;
			PosY = (long) TempY2;

			SetCursorPos(PosX,PosY);

			break;
		case 1 : // Click
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			break;

		case 2 : // Double Click
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			break;

		case 3 : // Left Down
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			break;

		case 4 : // Left UP
			in.type = INPUT_MOUSE;
			in.mi.dx = point->x;
			in.mi.dy = point->y;
			in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
			in.mi.mouseData = 0;
			in.mi.time = 0;
			SendInput(1,&in,sizeof(in));
			break;
		}
	}else {
		MessageBox("Error : Get Cursor",NULL,MB_OK);
	}
}

void CPreProgramDlg::ClearValue()
{
	countBClick = 0;
	countClick = 0;
	countDBClick = 0;
	countOut = 0;
	TempClickPoint = -1;
	DragDrop = false;
	outClick = false;
}

void CPreProgramDlg::CheckOutScreen(int width,int height)
{
	countOutScreen++;
	if (countOutScreen > Inf.FrameRate*2) {
		PointFinger = -1;
		m_state = 0;
		countOutScreen = 0;
		
	}

	
}

void CPreProgramDlg::OnTest() 
{
	// TODO: Add your control notification handler code here
	if (m_Status == TEST) {
		m_Status = RUNNING;
	}else {
		m_Status = TEST;
		Capture1 = m_video.CreateColorImageHandle(m_video.GetWidth(),m_video.GetHeight());
		Capture2 = m_video.CreateColorImageHandle(m_video.GetWidth(),m_video.GetHeight());
		TempCap = m_video.CreateColorImageHandle(m_video.GetWidth(),m_video.GetHeight());

		ShowWindow(SW_MINIMIZE);
		check_hide = true;
	}

}

void CPreProgramDlg::RemoveNoiseColor(BYTE *data, int x, int y, int size)
{
	int a[320*240*3];

	for (int i = 0; i < size; i++){
		if (data[i] > 40)
			data[i] = 1;
		else
			data[i] = 0;
		a[i] = data[i];
	}

	for (i = 0; i < y; i++){
		for (int j = 0; j < x*3; j++){
			int i1 = i*3;
			int i2 = (i+1)*3;
			int i3 = (i-1)*3;

			if ((i == 0) && (j == 0))
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i2*x)+j] + a[(i2*x)+j+3]
	 							+ a[(i1*x)+j+3];
			else if ((i == 0) && (j == (x-1)))
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i2*x)+j] + a[(i1*x)+j-3] + a[(i2*x)+j-3];
			else if (i == 0)
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i2*x)+j] + a[(i2*x)+j+3] + a[(i1*x)+j+3] + a[(i1*x)+j-3] + a[(i2*x)+j-3];
			else if ((i == (y-1)) && (i == 0))
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i1*x)+j+3] + a[(i3*x)+j] + a[(i3*x)+j+3];
			else if ((i == (y-1)) && (j == (x-1)))
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i3*x)+j] + a[(i3*x)+j-3] + a[(i1*x)+j-3];
			else if (i == (y-1))
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i3*x)+j] + a[(i3*x)+j-3] + a[(i1*x)+j-3] + a[(i1*x)+j+3] + a[(i3*x)+j+3];
			else if (j == 0)
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i3*x)+j] + a[(i1*x)+j+3] + a[(i3*x)+j+3] + a[(i2*x)+j] + a[(i2*x)+j+3];
			else if (j == (x-1))
				data[(i1*x)+j] = a[(i1*x)+j] + a[(i3*x)+j] + a[(i3*x)+j-3] + a[(i1*x)+j-3] + a[(i2*x)+j-3] + a[(i2*x)+j];
			else{
				int ans = a[(i1*x)+j] + a[(i3*x)+j] + a[(i3*x)+j-3]
							+ a[(i1*x)+j-3] + a[(i2*x)+j-3] + a[(i2*x)+j]
							+ a[(i2*x)+j+3] + a[(i3*x)+j+3] + a[(i1*x)+j+3];
						
				data[(i1*x)+j] = ans; 
						
			}
			if (data[(i1*x)+j] > 4)
					data[(i1*x)+j] = 255;
				else
					data[(i1*x)+j] = 0;					
		}
				
	}
}

long CPreProgramDlg::FindFDiffPoint(BYTE *Cdata, int size, int width, int height, int Gsize,BYTE *Pic,BYTE* d1)
{
	int s = size; // 30
	long tempPoint = -1;
	int *tempdata = new int[width*height*3];

	for (int j = 0; j < Gsize*3; j++){
		tempdata[j] = Pic[j];
	}

	if (PointFinger != -1) { 
		long begin = PointFinger - (width*20) - 10;
		long end = PointFinger + (width*10) + 20;
		for (int i=begin; i<=end; i++) {
			if ( InScreen1(i,width,height) ) {
				// white balance
				int ref1 = Inf.BaseB1 - tempdata[Inf.Base1];
				int ref2 = Inf.BaseG1 - tempdata[Inf.Base1+1];
				int ref3 = Inf.BaseR1 - tempdata[Inf.Base1+2];
			
				int temp = tempdata[i*3] + ref1;
				if (temp < 0)
					tempdata[i*3] = 0;
				else if (temp > 255)
					tempdata[i*3] = 255;
				else
					tempdata[i*3] = temp;

				temp = tempdata[i*3+1] + ref2;
				if (temp < 0)
					tempdata[i*3+1] = 0;
				else if (temp > 255)
					tempdata[i*3+1] = 255;
				else
					tempdata[i*3+1] = temp;

				temp = tempdata[i*3+2] + ref3;
				if (temp < 0)
					tempdata[i*3+2] = 0;
				else if (temp > 255)
					tempdata[i*3+2] = 255;
				else
					tempdata[i*3+2] = temp;


				if ( (Cdata[i*3] == 255) || (Cdata[i*3+1] == 255) || (Cdata[i*3+2] == 255) ) {
					if ( ((tempdata[i*3+2] - tempdata[i*3+1]) >= 0) && ((tempdata[i*3+1] - tempdata[i*3]) >= 0) &&
						 (tempdata[i*3+2] >= Inf.MinR) && (tempdata[i*3+2] <= Inf.MaxR) &&
						 (tempdata[i*3+1] >= Inf.MinG) && (tempdata[i*3+1] <= Inf.MaxG) &&
						 (tempdata[i*3] >= Inf.MinB) && (tempdata[i*3] <= Inf.MaxB) &&
						 ((tempdata[i*3+2]-tempdata[i*3+1]) >= Inf.MinDifRG) && ((tempdata[i*3+2]-tempdata[i*3+1]) <= Inf.MaxDifRG) &&
						 ((tempdata[i*3+1]-tempdata[i*3]) >= Inf.MinDifGB) && ((tempdata[i*3+1]-tempdata[i*3]) <= Inf.MaxDifGB) &&
						 ((tempdata[i*3+2]-tempdata[i*3]) >= Inf.MinDifRB) && ((tempdata[i*3+2]-tempdata[i*3]) <= Inf.MaxDifRB) ) {
							
						if (i > tempPoint) {
							tempPoint = i;
						}

					}
				}
				
									
			}
				
			s--;
			if (s == 0) {
				s = size;
				i = i+(width-size);
			}
				
		}

		if (tempPoint == -1) {
			tempPoint = PointFinger;
		}

		
	}else {
		for (int i=0; i<Gsize; i++) {
			if ( InScreen1(i,width,height)  ) {
				// white balance
				int ref1 = Inf.BaseB1 - tempdata[Inf.Base1];
				int ref2 = Inf.BaseG1 - tempdata[Inf.Base1+1];
				int ref3 = Inf.BaseR1 - tempdata[Inf.Base1+2];
				

				int temp = tempdata[i*3] + ref1;
				if (temp < 0)
					tempdata[i*3] = 0;
				else if (temp > 255)
					tempdata[i*3] = 255;
				else
					tempdata[i*3] = temp;

				temp = tempdata[i*3+1] + ref2;
				if (temp < 0)
					tempdata[i*3+1] = 0;
				else if (temp > 255)
					tempdata[i*3+1] = 255;
				else
					tempdata[i*3+1] = temp;

				temp = tempdata[i*3+2] + ref3;
				if (temp < 0)
					tempdata[i*3+2] = 0;
				else if (temp > 255)
					tempdata[i*3+2] = 255;
				else
					tempdata[i*3+2] = temp;


				if ( (Cdata[i*3] == 255) || (Cdata[i*3+1] == 255) || (Cdata[i*3+2] == 255) ) {
					if ( ((tempdata[i*3+2] - tempdata[i*3+1]) >= 0) && ((tempdata[i*3+1] - tempdata[i*3]) >= 0) &&
						 (tempdata[i*3+2] >= Inf.MinR) && (tempdata[i*3+2] <= Inf.MaxR) &&
						 (tempdata[i*3+1] >= Inf.MinG) && (tempdata[i*3+1] <= Inf.MaxG) &&
						 (tempdata[i*3] >= Inf.MinB) && (tempdata[i*3] <= Inf.MaxB) &&
						 ((tempdata[i*3+2]-tempdata[i*3+1]) >= Inf.MinDifRG) && ((tempdata[i*3+2]-tempdata[i*3+1]) <= Inf.MaxDifRG) &&
						 ((tempdata[i*3+1]-tempdata[i*3]) >= Inf.MinDifGB) && ((tempdata[i*3+1]-tempdata[i*3]) <= Inf.MaxDifGB) &&
						 ((tempdata[i*3+2]-tempdata[i*3]) >= Inf.MinDifRB) && ((tempdata[i*3+2]-tempdata[i*3]) <= Inf.MaxDifRB) ) {
							
						if (i > tempPoint) {
							tempPoint = i;
						}

						d1[i*3] = 0;
						d1[i*3+1] = 0;
						d1[i*3+2] = 255;
					}
				}

				
			}
				
		}
	}

	delete tempdata;

	return tempPoint; // return Gray
}


void CPreProgramDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (nType == SIZE_MINIMIZED) {
		//== hide program
		ShowWindow(SW_HIDE);
		m_SystemTray.cbSize = sizeof(m_SystemTray);
		m_SystemTray.hWnd = GetSafeHwnd(); 
		m_SystemTray.uID = 0x0064;
		m_SystemTray.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
		m_SystemTray.hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
		m_SystemTray.uCallbackMessage = WM_USER;
		sprintf(m_SystemTray.szTip, "Touch-screen");
		Shell_NotifyIcon(NIM_ADD, &m_SystemTray);
	}
}

LRESULT CPreProgramDlg::OnIcon(WPARAM wParam, LPARAM lParam)
{
	switch (lParam) {
    case WM_LBUTTONDBLCLK:
        ChkWndHide();
        break;
    }
    return 0;
}

void CPreProgramDlg::ChkWndHide()
{
	if (check_hide){
		ShowWindow(SW_SHOW);
		ShowWindow(SW_SHOWNORMAL);
		check_hide = false;
		Shell_NotifyIcon(NIM_DELETE, &m_SystemTray);
	}
	else{
		ShowWindow(SW_HIDE);
		check_hide = true;
		Shell_NotifyIcon(NIM_ADD, &m_SystemTray);
	}
}


void CPreProgramDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	OnStop();
	CDialog::OnClose();
}

void CPreProgramDlg::Dilation(BYTE *data, int width, int height, int size)
{
	int n = 3; // 3*3
	int *tempdata = new int[width*height*3];
	int white = 255;
	int black = 0;

	for (int i = 0; i < size; i++){
		if (((i%width)>0) && ((i%width)<width-1) && ((i/width)>0) && ((i/width)<height-1)) {
			if ( (data[i*3] == 255) || (data[i*3+1] == 255) || (data[i*3+2] == 255) ) {
				tempdata[(i+width-1)*3] = white;
				tempdata[(i+width-1)*3+1] = white;
				tempdata[(i+width-1)*3+2] = white;
				tempdata[(i+width)*3] = white;
				tempdata[(i+width)*3+1] = white;
				tempdata[(i+width)*3+2] = white;
				tempdata[(i+width+1)*3] = white;
				tempdata[(i+width+1)*3+1] = white;
				tempdata[(i+width+1)*3+2] = white;
				tempdata[(i-1)*3] = white;
				tempdata[(i-1)*3+1] = white;
				tempdata[(i-1)*3+2] = white;
				tempdata[(i)*3] = white;
				tempdata[(i)*3+1] = white;
				tempdata[(i)*3+2] = white;
				tempdata[(i+1)*3] = white;
				tempdata[(i+1)*3+1] = white;
				tempdata[(i+1)*3+2] = white;
				tempdata[(i-width-1)*3] = white;
				tempdata[(i-width-1)*3+1] = white;
				tempdata[(i-width-1)*3+2] = white;
				tempdata[(i-width)*3] = white;
				tempdata[(i-width)*3+1] = white;
				tempdata[(i-width)*3+2] = white;
				tempdata[(i-width+1)*3] = white;
				tempdata[(i-width+1)*3+1] = white;
				tempdata[(i-width+1)*3+2] = white;
			}else {
				tempdata[i*3] = black;
				tempdata[i*3+1] = black;
				tempdata[i*3+2] = black;
			}
		}else {
			tempdata[i*3] = black;
			tempdata[i*3+1] = black;
			tempdata[i*3+2] = black;
		}
	}

	for (i = 0; i < size*3; i++){
		data[i] = tempdata[i];
	}

	delete tempdata;
}

int CPreProgramDlg::checkframe(BYTE* Cdata,int width,int height,BYTE* d2)
{
	int s = 12; 
	int size = 12;
	
	int *tempdata = new int[width*height*3];

	tempdata[Inf.Base1] = d2[Inf.Base1];
	tempdata[Inf.Base1+1] = d2[Inf.Base1+1];
	tempdata[Inf.Base1+2] = d2[Inf.Base1+2];

	long begin = TempClickPoint - (width*7) - 6;
	long end = TempClickPoint + (width*7) + 6;
	for (int i=begin; i<=end; i++) {
		if ( InScreen1(i,width,height)  ) {

			tempdata[i*3] = d2[i*3];
			tempdata[i*3+1] = d2[i*3+1];
			tempdata[i*3+2] = d2[i*3+2];
			// white balance
			int ref1 = Inf.BaseB1 - tempdata[Inf.Base1];
			int ref2 = Inf.BaseG1 - tempdata[Inf.Base1+1];
			int ref3 = Inf.BaseR1 - tempdata[Inf.Base1+2];
		
			int temp = tempdata[i*3] + ref1;
			if (temp < 0)
				tempdata[i*3] = 0;
			else if (temp > 255)
				tempdata[i*3] = 255;
			else
				tempdata[i*3] = temp;

			temp = tempdata[i*3+1] + ref2;
			if (temp < 0)
				tempdata[i*3+1] = 0;
			else if (temp > 255)
				tempdata[i*3+1] = 255;
			else
				tempdata[i*3+1] = temp;

			temp = tempdata[i*3+2] + ref3;
			if (temp < 0)
				tempdata[i*3+2] = 0;
			else if (temp > 255)
				tempdata[i*3+2] = 255;
			else
				tempdata[i*3+2] = temp;

			if ( (Cdata[i*3] == 255) || (Cdata[i*3+1] == 255) || (Cdata[i*3+2] == 255) ) {
				if ( ((tempdata[i*3+2] - tempdata[i*3+1]) >= 0) && ((tempdata[i*3+1] - tempdata[i*3]) >= 0) &&
					 (tempdata[i*3+2] >= Inf.MinR) && (tempdata[i*3+2] <= Inf.MaxR) &&
					 (tempdata[i*3+1] >= Inf.MinG) && (tempdata[i*3+1] <= Inf.MaxG) &&
					 (tempdata[i*3] >= Inf.MinB) && (tempdata[i*3] <= Inf.MaxB) &&
					 ((tempdata[i*3+2]-tempdata[i*3+1]) >= Inf.MinDifRG) && ((tempdata[i*3+2]-tempdata[i*3+1]) <= Inf.MaxDifRG) &&
					 ((tempdata[i*3+1]-tempdata[i*3]) >= Inf.MinDifGB) && ((tempdata[i*3+1]-tempdata[i*3]) <= Inf.MaxDifGB) &&
					 ((tempdata[i*3+2]-tempdata[i*3]) >= Inf.MinDifRB) && ((tempdata[i*3+2]-tempdata[i*3]) <= Inf.MaxDifRB) ) {
						
					delete tempdata;
					return 1;
						
				}
			}
			
								
		}
				
		s--;
		if (s == 0) {
			s = size;
			i = i+(width-size);
		}
			
	}

	delete tempdata;

	
	return 0;

}

int CPreProgramDlg::checkframe1(BYTE *Cdata, int width, int height, BYTE *d2)
{
	int s = 30; 
	int size = 30;
	
	int *tempdata = new int[width*height*3];

	tempdata[Inf.Base1] = d2[Inf.Base1];
	tempdata[Inf.Base1+1] = d2[Inf.Base1+1];
	tempdata[Inf.Base1+2] = d2[Inf.Base1+2];

	long begin = TempClickPoint - (width*7) - 15;
	long end = TempClickPoint + (width*7) + 15;
	for (int i=begin; i<=end; i++) {
		if ( InScreen1(i,width,height)  ) {

			tempdata[i*3] = d2[i*3];
			tempdata[i*3+1] = d2[i*3+1];
			tempdata[i*3+2] = d2[i*3+2];
			// white balance
			int ref1 = Inf.BaseB1 - tempdata[Inf.Base1];
			int ref2 = Inf.BaseG1 - tempdata[Inf.Base1+1];
			int ref3 = Inf.BaseR1 - tempdata[Inf.Base1+2];
		
			int temp = tempdata[i*3] + ref1;
			if (temp < 0)
				tempdata[i*3] = 0;
			else if (temp > 255)
				tempdata[i*3] = 255;
			else
				tempdata[i*3] = temp;

			temp = tempdata[i*3+1] + ref2;
			if (temp < 0)
				tempdata[i*3+1] = 0;
			else if (temp > 255)
				tempdata[i*3+1] = 255;
			else
				tempdata[i*3+1] = temp;

			temp = tempdata[i*3+2] + ref3;
			if (temp < 0)
				tempdata[i*3+2] = 0;
			else if (temp > 255)
				tempdata[i*3+2] = 255;
			else
				tempdata[i*3+2] = temp;

			if ( (Cdata[i*3] == 255) || (Cdata[i*3+1] == 255) || (Cdata[i*3+2] == 255) ) {
				if ( ((tempdata[i*3+2] - tempdata[i*3+1]) >= 0) && ((tempdata[i*3+1] - tempdata[i*3]) >= 0) &&
					 (tempdata[i*3+2] >= Inf.MinR) && (tempdata[i*3+2] <= Inf.MaxR) &&
					 (tempdata[i*3+1] >= Inf.MinG) && (tempdata[i*3+1] <= Inf.MaxG) &&
					 (tempdata[i*3] >= Inf.MinB) && (tempdata[i*3] <= Inf.MaxB) &&
					 ((tempdata[i*3+2]-tempdata[i*3+1]) >= Inf.MinDifRG) && ((tempdata[i*3+2]-tempdata[i*3+1]) <= Inf.MaxDifRG) &&
					 ((tempdata[i*3+1]-tempdata[i*3]) >= Inf.MinDifGB) && ((tempdata[i*3+1]-tempdata[i*3]) <= Inf.MaxDifGB) &&
					 ((tempdata[i*3+2]-tempdata[i*3]) >= Inf.MinDifRB) && ((tempdata[i*3+2]-tempdata[i*3]) <= Inf.MaxDifRB) ) {
						
					delete tempdata;
					return 0;
			
				}
			}
			
								
		}
				
		s--;
		if (s == 0) {
			s = size;
			i = i+(width-size);
		}
			
	}

	delete tempdata;

	if (outClick) {
		return 0;
	}else {
		return 1;
	}
	
}
