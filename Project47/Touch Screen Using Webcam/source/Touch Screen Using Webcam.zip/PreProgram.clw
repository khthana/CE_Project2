; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPreProgramDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "PreProgram.h"

ClassCount=3
Class1=CPreProgramApp
Class2=CPreProgramDlg

ResourceCount=5
Resource2=IDD_PREPROGRAM_DIALOG
Resource3=IDD_CONFIGSCREEN
Resource1=IDR_MAINFRAME
Resource4=IDD_DIALOGBAR (English (U.S.))
Class3=ProgramConfig
Resource5=IDD_PREPROGRAM_DIALOG (English (U.S.))

[CLS:CPreProgramApp]
Type=0
HeaderFile=PreProgram.h
ImplementationFile=PreProgram.cpp
Filter=N
LastObject=CPreProgramApp

[CLS:CPreProgramDlg]
Type=0
HeaderFile=PreProgramDlg.h
ImplementationFile=PreProgramDlg.cpp
Filter=D
LastObject=CPreProgramDlg
BaseClass=CDialog
VirtualFilter=dWC



[DLG:IDD_PREPROGRAM_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CPreProgramDlg

[DLG:IDD_PREPROGRAM_DIALOG (English (U.S.))]
Type=1
Class=CPreProgramDlg
ControlCount=7
Control1=IDC_VIDEOOCXCTRL1,{A91E1E79-6AE7-11D4-AD08-A8AB2E818B70},1342242816
Control2=IDC_VIDEOOCXTOOLSCTRL1,{523EF5C0-2E8B-44C0-94F4-C6981B3D0C07},1342242816
Control3=IDC_CONFIG,button,1342242816
Control4=IDC_INIT,button,1342242816
Control5=IDC_STOP,button,1342242816
Control6=IDC_CHECKVALUE,button,1342242816
Control7=IDC_TEST,button,1342242816

[DLG:IDD_DIALOGBAR (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC,static,1342308352

[DLG:IDD_CONFIGSCREEN]
Type=1
Class=ProgramConfig
ControlCount=0

[CLS:ProgramConfig]
Type=0
HeaderFile=ProgramConfig.h
ImplementationFile=ProgramConfig.cpp
BaseClass=CDialog
Filter=D
LastObject=ProgramConfig
VirtualFilter=dWC

