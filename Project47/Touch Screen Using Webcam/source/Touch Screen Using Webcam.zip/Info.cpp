// Info.cpp: implementation of the Info class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PreProgram.h"
#include "Info.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Info::Info()
{
	FrameRate = 0;
	Point1 = 0;
	Point2 = 0;
	Point3 = 0;
	Point4 = 0;
	Point5 = 0;
	Point6 = 0;
	Point7 = 0;
	Point8 = 0;
	FingerPoint1 = 0;
	FingerPoint2 = 0;
	FingerPoint3 = 0;
	FingerPoint4 = 0;
	FingerPoint5 = 0;
	FingerPoint6 = 0;
	FingerPoint7 = 0;
	FingerPoint8 = 0;
	LeftUpX = 0;
	LeftDownX = 0;
	RightUpX = 0;
	RightDownX = 0;
	LeftUpY = 0;
	LeftDownY = 0;
	RightUpY = 0;
	RightDownY = 0;
	m1 = 0;
	m2 = 0;
	m3 = 0;
	m4 = 0;
	MaxR = 0;
	MaxG = 0;
	MaxB = 0;
	MinR = 255;
	MinG = 255;
	MinB = 255;
	MaxDifRG = 0;
	MaxDifGB = 0;
	MaxDifRB = 0;
	MinDifRG = 255;
	MinDifGB = 255;
	MinDifRB = 255;
	Base1 = 0;
	BaseB1 = 0;
	BaseG1 = 0;
	BaseR1 = 0;
}

Info::~Info()
{

}
