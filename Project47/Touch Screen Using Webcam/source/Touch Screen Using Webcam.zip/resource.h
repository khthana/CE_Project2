//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PreProgram.rc
//
#define RUNNING                         10
#define CHECKVALUE                      11
#define TEST                            13
#define IDD_PREPROGRAM_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_CONFIGSCREEN                130
#define IDI_ICON1                       133
#define IDC_VIDEOOCXCTRL1               1000
#define IDC_VIDEOOCXTOOLSCTRL1          1001
#define IDC_CONFIG                      1002
#define IDC_INIT                        1003
#define IDC_STOP                        1004
#define IDC_START                       1005
#define IDC_CHECKVALUE                  1006
#define IDC_TEST                        1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
