// PreProgram.h : main header file for the PREPROGRAM application
//

#if !defined(AFX_PREPROGRAM_H__9EFA5495_7FA8_4F65_8D4A_746808BCFC9A__INCLUDED_)
#define AFX_PREPROGRAM_H__9EFA5495_7FA8_4F65_8D4A_746808BCFC9A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPreProgramApp:
// See PreProgram.cpp for the implementation of this class
//

class CPreProgramApp : public CWinApp
{
public:
	CPreProgramApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreProgramApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPreProgramApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREPROGRAM_H__9EFA5495_7FA8_4F65_8D4A_746808BCFC9A__INCLUDED_)
