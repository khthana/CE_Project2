// PreProgramDlg.h : header file
//
//{{AFX_INCLUDES()
#include "videoocx.h"
#include "videoocxtools.h"
#include "ProgramConfig.h"
#include "Info.h"
//}}AFX_INCLUDES

#if !defined(AFX_PREPROGRAMDLG_H__56222C87_AD78_4D93_A90B_99A8117F78BB__INCLUDED_)
#define AFX_PREPROGRAMDLG_H__56222C87_AD78_4D93_A90B_99A8117F78BB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <fstream.h>

/////////////////////////////////////////////////////////////////////////////
// CPreProgramDlg dialog

class CPreProgramDlg : public CDialog
{
// Construction
public:		
	int countOut;
	bool FlagIn;
	int IO;	
	NOTIFYICONDATA m_SystemTray;
	bool check_hide;
	long Capture1;
	long Capture2;
	long TempCap;
	bool checkFirst;
	int CountScreen;	
	Info Inf;
	ProgramConfig *m_config;
	long m_Image;
	long m_ResultImage;
	long m_HelperImage;
	long m_GrayImage;
	long m_GrayResultImage;
	long m_GrayHelperImage;
	BOOL m_Running;
	int m_Status;
	long FDPointFinger;
	long CPointFinger;
	long PointFinger;
	long TempClickPoint;
	int m_state;
	POINT pt;
	INPUT in;
	DEVMODE dmOld;
	int countBClick;
	int countClick;
	int countDBClick;
	int countOutScreen;
	bool DragDrop;
	bool outClick;


	long FindColorPoint(BYTE* Cdata,int size,int width,int height,BYTE* d1);
	bool InScreen(long point,int width,int height);
	bool InScreen1(long point, int width, int height);
	bool CheckPointClose(long Point1,long Point2,int width,int height,int size);
	void MouseSignal(int p,int width,int height);
	void CheckStateMouse(int width,int height);
	void CheckOutScreen(int width,int height);
	void ClearValue();
	void RemoveNoiseColor(BYTE* data,int x,int y,int size);	
	long FindFDiffPoint(BYTE *Cdata, int size, int width, int height, int Gsize,BYTE *Pic,BYTE* d1);
	void ChkWndHide();
	int checkframe1(BYTE* Cdata,int width,int height,BYTE* d2);
	int checkframe(BYTE* Cdata,int width,int height,BYTE* d2);
	void Dilation(BYTE* data,int width,int height,int size);
	CPreProgramDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPreProgramDlg)
	enum { IDD = IDD_PREPROGRAM_DIALOG };
	CButton	m_Test;
	CButton	m_Stop;
	CButton	m_Init;
	CButton	m_Config;
	CButton	m_CheckValue;
	CVideoOCX	m_video;
	CVideoOCXTools	m_videoTool;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreProgramDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPreProgramDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnConfig();
	afx_msg void OnInit();
	afx_msg void OnStop();
	afx_msg void OnCheckvalue();
	afx_msg void OnTest();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnIcon(WPARAM wParam,LPARAM lParam);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREPROGRAMDLG_H__56222C87_AD78_4D93_A90B_99A8117F78BB__INCLUDED_)
