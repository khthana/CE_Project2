// ProgramConfig.cpp : implementation file
//

#include "stdafx.h"
#include "PreProgram.h"
#include "ProgramConfig.h"
#include <stdlib.h>
#include <fstream.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ProgramConfig dialog


ProgramConfig::ProgramConfig(CWnd* pParent /*=NULL*/)
	: CDialog(ProgramConfig::IDD, pParent)
{
	// Constructor and Init Value
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;
	m_GrayImage = 0;
	m_GrayResultImage = 0;
	m_GrayHelperImage = 0;
	TempHandleGray1 = 0;
	TempHandleGray2 = 0;
	TempHandleColor1 = 0;
	TempHandleColor2 = 0;
	state = 0;
	setInterface = false;
	countSec = 0;

	Create(IDD_CONFIGSCREEN,pParent);
	
}

void ProgramConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

}

BEGIN_MESSAGE_MAP(ProgramConfig, CDialog)
	//{{AFX_MSG_MAP(ProgramConfig)
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ProgramConfig message handlers

BOOL ProgramConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	DlgWidth  = GetSystemMetrics(SM_CXSCREEN);
	DlgHeight = GetSystemMetrics(SM_CYSCREEN);
	SetWindowPos(&wndTopMost, 0, 0, DlgWidth, DlgHeight, SWP_SHOWWINDOW);

	// hide cursor
	ShowCursor(FALSE);

	// Show white screen
	CPaintDC dc(this);
	CRect ScreenRecto;
	GetClientRect(&ScreenRecto);
	CBrush BrushGray(RGB(192, 192, 192));
	CBrush *pOldBrush = dc.SelectObject(&BrushGray);
	dc.Rectangle(ScreenRecto);
	dc.SelectObject(pOldBrush);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void ProgramConfig::GetHandleVideo(CVideoOCX *video,CVideoOCXTools* videoTool)
{
	// get handle of video and videoTool
	m_video = video;
	m_videoTool = videoTool;
}

void ProgramConfig::GetInfo(Info *I)
{
	// get handle of information
	Inf = I;
}

void ProgramConfig::OnMouseMove(UINT nFlags, CPoint point)  
{
	// TODO: Add your message handler code here and/or call default

	// if move mouse, program will close
	static int MoveCounter = 0;
	if (MoveCounter >= 30){
		DestroyWindow();
		MoveCounter = 0;
		ShowCursor(TRUE);
		MessageBox("Out Configuration",NULL,MB_OK);
	}
 	MoveCounter++;

	CDialog::OnMouseMove(nFlags, point);
}

void ProgramConfig::StartInterface() // set interface of webcam
{
	if (m_Image != 0)
		return;	

	// disable internal error message display
	m_video->SetErrorMessages(0);

	if (!m_video->Init())
	{
		// Error while trying to init control
		MessageBox(m_video->GetLastErrorString(), "VideoOCX Error", MB_OK);
		return;		// exit
	}

	// allocate memory for all images that will be needed to demonstrate VideoOCXTools - features
	//   Make sure you free the resources later using VideoOCX::ReleaseImageHandle(long).
	m_Image = m_video->GetColorImageHandle();
	m_ResultImage = m_video->GetColorImageHandle();
	m_HelperImage = m_video->GetColorImageHandle();

	m_GrayImage = m_video->GetGrayImageHandle();
	m_GrayResultImage = m_video->GetGrayImageHandle();
	m_GrayHelperImage = m_video->GetGrayImageHandle();

	Sleep(100);		// make sure VideoOCX has time to be properly initialized
	m_video->Start();
}

void ProgramConfig::StopInterface() // stop interface of webcam
{
	Sleep(250);			// wait for thread to end

	// end capture mode
	if (!m_video->Stop())
	{
		// error
		MessageBox(m_video->GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
	
	// free memory
	m_video->ReleaseImageHandle(m_Image);
	m_video->ReleaseImageHandle(m_ResultImage);
	m_video->ReleaseImageHandle(m_HelperImage);
	m_video->ReleaseImageHandle(m_GrayImage);
	m_video->ReleaseImageHandle(m_GrayResultImage);
	m_video->ReleaseImageHandle(m_GrayHelperImage);

	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;
	m_GrayImage = 0;
	m_GrayResultImage = 0;
	m_GrayHelperImage = 0;

	//	close video connection and free memory

	if (!m_video->Close())
	{
		// error while closing video connection
		MessageBox(m_video->GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
}

UINT CThread(LPVOID pParam) // Thread ( Find frame rate )
{
	// get handle of object
	ProgramConfig *p;
	p = (ProgramConfig *)pParam;

	while (p->countSec == 0) {
		
	}
	while (p->countSec == 1) { // count frame rate
		if (p->m_video->Capture(p->m_Image)) {
			p->Inf->FrameRate++;
		}
	}
	p->countSec = 5;
	p->KillTimer(p->m_Timer); // stop timerS

	

	p->MessageBox("Press any key to continue", NULL, MB_OK);

	return(0);
}

void ProgramConfig::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	int X = 0;
	int Y = 0;
	int width;
	int height;

	if (!setInterface) {
		Inf->FrameRate = 0;
		StartInterface();
		Sleep(100);

		// Find frame rate //
		AfxBeginThread(CThread, this);
		m_Timer = SetTimer(1, 1000, 0);		
		/////////////////////

		setInterface = true;
	}else {
		CClientDC dc(this);
		CBrush BrushBlack(RGB(0, 0, 0));
		CPen   PenBlack(PS_SOLID, 1, RGB(0, 0, 0));
		CBrush *pOldBrush = dc.SelectObject(&BrushBlack);
		CPen   *pOldPen   = dc.SelectObject(&PenBlack);
		BYTE *d;

		switch (state) {
		case 0 :
			// Find All Point //
			if (!FindPoint()) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				MessageBox("Find Point Error",NULL,MB_OK);
				return;
			}

			// Find Constant
			width = m_video->GetWidth();
			height = m_video->GetHeight();
			FindConstant(width,height);

			// Find Screen
			Inf->LeftUpX = (Inf->Point1 % width);
			Inf->LeftUpY = (Inf->Point1 / width)+5;
			Inf->RightUpX = (Inf->Point3 % width);
			Inf->RightUpY = (Inf->Point3 / width)+5;
			Inf->LeftDownX = (Inf->Point6 % width);
			Inf->LeftDownY = (Inf->Point6 / width)-5;
			Inf->RightDownX = (Inf->Point8 % width);
			Inf->RightDownY = (Inf->Point8 / width)-5;

			// Find m for function InScreen
			Inf->m1 = (Inf->LeftUpY-Inf->RightUpY)/(Inf->LeftUpX-Inf->RightUpX);
			Inf->m2 = (Inf->LeftDownY-Inf->RightDownY)/(Inf->LeftDownX-Inf->RightDownX);
			Inf->m3 = (Inf->LeftUpY-Inf->LeftDownY)/(Inf->LeftUpX-Inf->LeftDownX);
			Inf->m4 = (Inf->RightUpY-Inf->RightDownY)/(Inf->RightUpX-Inf->RightDownX);

			MessageBox("Press any key to continue",NULL,MB_OK);

			// Get White Screen
			CreateGrayScreen();
			Sleep(1000);
			GetPicture2(2);  //TempHandleGray2

			d = (BYTE*)m_video->GetDataPointer(TempHandleColor2);
			// Find based point to white balance
			Inf->Base1 = (Inf->Point2+(width*20))*3;

			Inf->BaseB1 = d[(Inf->Point2+(width*20))*3];
			Inf->BaseG1 = d[(Inf->Point2+(width*20))*3+1];
			Inf->BaseR1 = d[(Inf->Point2+(width*20))*3+2];

			// Draw Point 1
			CreateGrayScreen();
			dc.Rectangle(20,20,30,30);
			Sleep(1000);
			GetPicture2(2);
			

			break;
		case 1 : // Find Finger Point 1 //	
			CreateGrayScreen();
			dc.Rectangle(20,20,30,30);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);

			Inf->FingerPoint1 = FindFingerPoint(1);
			
			if (Inf->FingerPoint1 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			// Draw Point 2
			CreateGrayScreen();
			dc.Rectangle((DlgWidth/2)-5,20,(DlgWidth/2)+5,20+10);
			Sleep(1000);
			GetPicture2(2);

			MessageBox("Press any key to continue",NULL,MB_OK);

			break;
		case 2 : // Find Finger Point 2 //	
			CreateGrayScreen();
			dc.Rectangle((DlgWidth/2)-5,20,(DlgWidth/2)+5,20+10);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);

			Inf->FingerPoint2 = FindFingerPoint(2);
			
			if (Inf->FingerPoint2 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			CreateGrayScreen();
			dc.Rectangle((DlgWidth)-30,25-5,(DlgWidth)-20,25+5);
			Sleep(1000);
			GetPicture2(2);

			MessageBox("Press any key to continue", NULL, MB_OK);

			break;
		case 3 : // Find Finger Point 3 //	
			CreateGrayScreen();
			dc.Rectangle((DlgWidth)-30,25-5,(DlgWidth)-20,25+5);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);
			
			Inf->FingerPoint3 = FindFingerPoint(3);
			
			if (Inf->FingerPoint3 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			CreateGrayScreen();
			dc.Rectangle((DlgWidth/3)-5,(DlgHeight/2)-5,(DlgWidth/3)+5,(DlgHeight/2)+5);
			Sleep(1000);
			GetPicture2(2);

			MessageBox("Press any key to continue", NULL, MB_OK);

			break;
		case 4 : // Find Finger Point 4 //	
			CreateGrayScreen();
			dc.Rectangle((DlgWidth/3)-5,(DlgHeight/2)-5,(DlgWidth/3)+5,(DlgHeight/2)+5);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);
			

			Inf->FingerPoint4 = FindFingerPoint(4);
			
			if (Inf->FingerPoint4 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			GetInfoFinger();

			CreateGrayScreen();
			dc.Rectangle(2*(DlgWidth/3)-5,(DlgHeight/2)-5,2*(DlgWidth/3)+5,(DlgHeight/2)+5);
			Sleep(1000);
			GetPicture2(2);

			MessageBox("Press any key to continue", NULL, MB_OK);

			break;
		case 5 : // Find Finger Point 5 //	
			CreateGrayScreen();
			dc.Rectangle(2*(DlgWidth/3)-5,(DlgHeight/2)-5,2*(DlgWidth/3)+5,(DlgHeight/2)+5);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);

			Inf->FingerPoint5 = FindFingerPoint(5);
			if (Inf->FingerPoint5 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			CreateGrayScreen();
			dc.Rectangle(20,(DlgHeight)-30,30,(DlgHeight)-20);
			Sleep(1000);
			GetPicture2(2);

			MessageBox("Press any key to continue", NULL, MB_OK);

			break;
		case 6 : // Find Finger Point 6 //	
			CreateGrayScreen();
			dc.Rectangle(20,(DlgHeight)-30,30,(DlgHeight)-20);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);

			Inf->FingerPoint6 = FindFingerPoint(6);
			if (Inf->FingerPoint6 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			CreateGrayScreen();
			dc.Rectangle((DlgWidth/2)-5,(DlgHeight)-30,(DlgWidth/2)+5,(DlgHeight)-20);
			Sleep(1000);
			GetPicture2(2);
			
			MessageBox("Press any key to continue", NULL, MB_OK);		
			
			break;
		case 7 : // Find Finger Point 7 //	
			CreateGrayScreen();
			dc.Rectangle((DlgWidth/2)-5,(DlgHeight)-30,(DlgWidth/2)+5,(DlgHeight)-20);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);

			Inf->FingerPoint7 = FindFingerPoint(7);
			if (Inf->FingerPoint7 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			CreateGrayScreen();
			dc.Rectangle((DlgWidth)-30,(DlgHeight)-30,(DlgWidth)-20,(DlgHeight)-20);
			Sleep(1000);
			GetPicture2(2);

			MessageBox("Press any key to continue", NULL, MB_OK);
			
			break;
		case 8 : // Find Finger Point 8 //	
			CreateGrayScreen();
			dc.Rectangle((DlgWidth)-30,(DlgHeight)-30,(DlgWidth)-20,(DlgHeight)-20);
			Sleep(1000);
			GetPicture1(2);
			Sleep(100);

			Inf->FingerPoint8 = FindFingerPoint(8);
			if (Inf->FingerPoint8 <= 0) {
				StopInterface();
				DestroyWindow();
				ShowCursor(TRUE);
				return;
			}

			MessageBox("Press any key to continue", NULL, MB_OK);

			break;
		default :
			width = m_video->GetWidth();
			height = m_video->GetHeight();

			FindConstant1(width,height);
			setInterface = false;
			DestroyWindow();
			StopInterface();
			ShowCursor(TRUE);
		}

		dc.SelectObject(pOldBrush);
		dc.SelectObject(pOldPen);

		state++;
	}

	CDialog::OnKeyDown(nChar, nRepCnt, nFlags);
}

void ProgramConfig::GetPicture1(int type) // 1->Color, 2->Gray
{
	int width = m_video->GetWidth();
	int height = m_video->GetHeight();

	switch (type) {
	case 1 :
		TempHandleColor1 = m_video->CreateColorImageHandle(width,height);

		if (!m_video->Capture(TempHandleColor1))
			MessageBox("GetPicture1 Capture Error",NULL,MB_OK);
		break;
	case 2 :
		TempHandleColor1 = m_video->CreateColorImageHandle(width,height);

		if (!m_video->Capture(TempHandleColor1))
			MessageBox("GetPicture1 Capture Error",NULL,MB_OK);

		TempHandleGray1 = m_video->CreateGrayImageHandle(width,height);

		if (!m_video->ToGray(TempHandleColor1,TempHandleGray1))
			MessageBox("Convert To Gray Error",NULL,MB_OK);
		break;
	}
}

void ProgramConfig::GetPicture2(int type) // 1->Color, 2->Gray
{
	int width = m_video->GetWidth();
	int height = m_video->GetHeight();

	switch (type) {
	case 1 :
		TempHandleColor2 = m_video->CreateColorImageHandle(width,height);

		if (!m_video->Capture(TempHandleColor2))
			MessageBox("GetPicture2 Capture Error",NULL,MB_OK);
		break;
	case 2 :
		TempHandleColor2 = m_video->CreateColorImageHandle(width,height);

		if (!m_video->Capture(TempHandleColor2))
			MessageBox("GetPicture2 Capture Error",NULL,MB_OK);
		
		TempHandleGray2 = m_video->CreateGrayImageHandle(width,height);

		if (!m_video->ToGray(TempHandleColor2,TempHandleGray2))
			MessageBox("Convert To Gray Error",NULL,MB_OK);
		break;
	}
}

void ProgramConfig::CreateGrayScreen()
{
	CClientDC dc(this);
	CRect ScreenRecto;

	GetClientRect(&ScreenRecto);
	CBrush BrushGray(RGB(192, 192, 192));

	CBrush *pOldBrush = dc.SelectObject(&BrushGray);

	dc.Rectangle(ScreenRecto);

	dc.SelectObject(pOldBrush);

	CBrush BrushBlue(RGB(0, 0, 0));
	CPen   PenBlue(PS_SOLID, 1, RGB(0, 0, 0));

	pOldBrush = dc.SelectObject(&BrushBlue);
	CPen   *pOldPen   = dc.SelectObject(&PenBlue);
}

void ProgramConfig::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	countSec++;

	CDialog::OnTimer(nIDEvent);
}

bool ProgramConfig::FindPoint()
{
	CClientDC dc(this);
	CBrush BrushBlack(RGB(0, 0, 0));
	CPen   PenBlack(PS_SOLID, 1, RGB(0, 0, 0));
	CBrush *pOldBrush = dc.SelectObject(&BrushBlack);
	CPen   *pOldPen   = dc.SelectObject(&PenBlack);

	int width = 0;
	int height = 0;

	// Get Point 1
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle(20,20,34,34);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point1 = GetPoint();	

	if (Inf->Point1 <= 0) {
		return false;
	}
		
	// Get Point 2
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle((DlgWidth/2)-7,20,(DlgWidth/2)+7,20+14);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point2 = GetPoint();

	if (Inf->Point2 <= 0) {
		return false;
	}


	// Get Point 3
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle((DlgWidth)-34,20,(DlgWidth)-20,20+14);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point3 = GetPoint();

	if (Inf->Point3 <= 0) {
		return false;
	}


	// Get Point 4
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle((DlgWidth/3)-7,(DlgHeight/2)-7,(DlgWidth/3)+7,(DlgHeight/2)+7);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point4 = GetPoint();

	if (Inf->Point4 <= 0) {
		return false;
	}


	// Get Point 5
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle(2*(DlgWidth/3)-7,(DlgHeight/2)-7,2*(DlgWidth/3)+7,(DlgHeight/2)+7);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point5 = GetPoint();

	if (Inf->Point5 <= 0) {
		return false;
	}


	// Get Point 6
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle(20,(DlgHeight)-34,34,(DlgHeight)-20);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point6 = GetPoint();

	if (Inf->Point6 <= 0) {
		return false;
	}

	
	// Get Point 7
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle((DlgWidth/2)-7,(DlgHeight)-34,(DlgWidth/2)+7,(DlgHeight)-20);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point7 = GetPoint();

	if (Inf->Point7 <= 0) {
		return false;
	}

		

	// Get Point 8
	// create point
	CreateGrayScreen();
	Sleep(1000);
	GetPicture1(2);
	Sleep(100);

	CreateGrayScreen();
	dc.Rectangle((DlgWidth)-34,(DlgHeight)-34,(DlgWidth)-20,(DlgHeight)-20);
	Sleep(1000);
	GetPicture2(2);
	Sleep(100);

	Inf->Point8 = GetPoint();

	if (Inf->Point8 <= 0) {
		return false;
	}

		

	dc.SelectObject(pOldBrush);
	dc.SelectObject(pOldPen);

	return true;
}

long ProgramConfig::GetPoint()
{
	BYTE *data1 = (BYTE*)m_video->GetDataPointer(TempHandleColor1);
	int size = m_video->GetImageDataSize(TempHandleColor1);
	BYTE *data2 = (BYTE*)m_video->GetDataPointer(TempHandleColor2);
	BYTE *data3 = (BYTE*)m_video->GetDataPointer(m_ResultImage);

	int countPixel = 0;
	long Temp[50];
	int ts = 50;

	while ( (ts>=20) && (countPixel==0) ) {

		for (int i=0; i<size; i++) {
			if ((i%3)==0) {
				if ( ((data1[i]-data2[i]) > ts) || ((data2[i]-data1[i]) > ts) ||
					 ((data1[i+1]-data2[i+1]) > ts) || ((data2[i+1]-data1[i+1]) > ts) ||
					 ((data1[i+1]-data2[i+2]) > ts) || ((data2[i+1]-data1[i+2]) > ts) ) {
					data3[i] = 255;
					data3[i+1] = 255;
					data3[i+2] = 255;
				}else{
					data3[i] = 0;
					data3[i+1] = 0;
					data3[i+2] = 0;
				}
			}
		}

		for (i=0; i<size; i++) {
			if ((i%3)==0) {
				if (data3[i] == 255) {
					Temp[countPixel] = i;
					countPixel++;
					if (countPixel >= 49) {
						MessageBox("Get Point Fail : Pixel more",NULL,MB_OK);
						return 0;
					}
				}
			}
		}

		ts = ts - 5;

	}

	if (countPixel == 0) {
		MessageBox("Get Point Fail : No Pixel",NULL,MB_OK);
		return 0;
	}

	countPixel = countPixel/2;

	return Temp[countPixel]/3;
}	

void ProgramConfig::FindConstant(int width, int height) // Convert from picture to screen
{
	int n = 8;

	EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &dmOld);
	int y = dmOld.dmPelsHeight;
	int x = dmOld.dmPelsWidth;

	double Point1X = Inf->Point1 % width;
	double Point1Y = height - (Inf->Point1 / width);
	double Point2X = Inf->Point2 % width;
	double Point2Y = height - (Inf->Point2 / width);
	double Point3X = Inf->Point3 % width;
	double Point3Y = height - (Inf->Point3 / width);
	double Point4X = Inf->Point4 % width;
	double Point4Y = height - (Inf->Point4 / width);
	double Point5X = Inf->Point5 % width;
	double Point5Y = height - (Inf->Point5 / width);
	double Point6X = Inf->Point6 % width;
	double Point6Y = height - (Inf->Point6 / width);
	double Point7X = Inf->Point7 % width;
	double Point7Y = height - (Inf->Point7 / width);
	double Point8X = Inf->Point8 % width;
	double Point8Y = height - (Inf->Point8 / width);

	double a1[8][8] = {	Point1X*Point1X*Point1X,Point1Y*Point1Y*Point1Y,Point1X*Point1X*Point1Y,Point1X*Point1Y*Point1Y,Point1X*Point1Y,Point1X,Point1Y,1,
						Point2X*Point2X*Point2X,Point2Y*Point2Y*Point2Y,Point2X*Point2X*Point2Y,Point2X*Point2Y*Point2Y,Point2X*Point2Y,Point2X,Point2Y,1,
						Point3X*Point3X*Point3X,Point3Y*Point3Y*Point3Y,Point3X*Point3X*Point3Y,Point3X*Point3Y*Point3Y,Point3X*Point3Y,Point3X,Point3Y,1,
						Point4X*Point4X*Point4X,Point4Y*Point4Y*Point4Y,Point4X*Point4X*Point4Y,Point4X*Point4Y*Point4Y,Point4X*Point4Y,Point4X,Point4Y,1, 
						Point5X*Point5X*Point5X,Point5Y*Point5Y*Point5Y,Point5X*Point5X*Point5Y,Point5X*Point5Y*Point5Y,Point5X*Point5Y,Point5X,Point5Y,1,
						Point6X*Point6X*Point6X,Point6Y*Point6Y*Point6Y,Point6X*Point6X*Point6Y,Point6X*Point6Y*Point6Y,Point6X*Point6Y,Point6X,Point6Y,1,
						Point7X*Point7X*Point7X,Point7Y*Point7Y*Point7Y,Point7X*Point7X*Point7Y,Point7X*Point7Y*Point7Y,Point7X*Point7Y,Point7X,Point7Y,1,
						Point8X*Point8X*Point8X,Point8Y*Point8Y*Point8Y,Point8X*Point8X*Point8Y,Point8X*Point8Y*Point8Y,Point8X*Point8Y,Point8X,Point8Y,1, };
	double b1[8] = { 0,x/2,x,x/3,(x*2)/3,0,x/2,x };
	double m = 0;

	for (int i=0; i<=(n-2); i++) {
		for (int j=i+1; j<=(n-1); j++) {
			m = a1[j][i] / a1[i][i];
			a1[j][i] = 0;
			b1[j] = b1[j] - m*b1[i];
			for (int k=i+1; k<=(n-1); k++) {
				a1[j][k] = a1[j][k] - m*a1[i][k];
			}
		}
	}

	Inf->XConstant[n-1] = b1[n-1] / a1[n-1][n-1];

	for (i=(n-2); i>=0; i--) {
		for (int j=i+1; j<=(n-1); j++) {
			b1[i] = b1[i] - a1[i][j]*Inf->XConstant[j];
			Inf->XConstant[i] = b1[i] / a1[i][i];
		}
	}

	double a2[8][8] = {	Point1X*Point1X*Point1X,Point1Y*Point1Y*Point1Y,Point1X*Point1X*Point1Y,Point1X*Point1Y*Point1Y,Point1X*Point1Y,Point1X,Point1Y,1,
						Point2X*Point2X*Point2X,Point2Y*Point2Y*Point2Y,Point2X*Point2X*Point2Y,Point2X*Point2Y*Point2Y,Point2X*Point2Y,Point2X,Point2Y,1,
						Point3X*Point3X*Point3X,Point3Y*Point3Y*Point3Y,Point3X*Point3X*Point3Y,Point3X*Point3Y*Point3Y,Point3X*Point3Y,Point3X,Point3Y,1,
						Point4X*Point4X*Point4X,Point4Y*Point4Y*Point4Y,Point4X*Point4X*Point4Y,Point4X*Point4Y*Point4Y,Point4X*Point4Y,Point4X,Point4Y,1, 
						Point5X*Point5X*Point5X,Point5Y*Point5Y*Point5Y,Point5X*Point5X*Point5Y,Point5X*Point5Y*Point5Y,Point5X*Point5Y,Point5X,Point5Y,1,
						Point6X*Point6X*Point6X,Point6Y*Point6Y*Point6Y,Point6X*Point6X*Point6Y,Point6X*Point6Y*Point6Y,Point6X*Point6Y,Point6X,Point6Y,1,
						Point7X*Point7X*Point7X,Point7Y*Point7Y*Point7Y,Point7X*Point7X*Point7Y,Point7X*Point7Y*Point7Y,Point7X*Point7Y,Point7X,Point7Y,1,
						Point8X*Point8X*Point8X,Point8Y*Point8Y*Point8Y,Point8X*Point8X*Point8Y,Point8X*Point8Y*Point8Y,Point8X*Point8Y,Point8X,Point8Y,1, };
	double b2[8] = { 0,0,0,y/2,y/2,y,y,y };
	m = 0;

	for (i=0; i<=(n-2); i++) {
		for (int j=i+1; j<=(n-1); j++) {
			m = a2[j][i] / a2[i][i];
			a2[j][i] = 0;
			b2[j] = b2[j] - m*b2[i];
			for (int k=i+1; k<=(n-1); k++) {
				a2[j][k] = a2[j][k] - m*a2[i][k];
			}
		}
	}

	Inf->YConstant[n-1] = b2[n-1] / a2[n-1][n-1];

	for (i=(n-2); i>=0; i--) {
		for (int j=i+1; j<=(n-1); j++) {
			b2[i] = b2[i] - a2[i][j]*Inf->YConstant[j];
			Inf->YConstant[i] = b2[i] / a2[i][i];
		}

	}
}

void ProgramConfig::FindConstant1(int width, int height) // convert from webcam view to user view
{
	int n = 8;

	double Point1X = Inf->FingerPoint1 % width;
	double Point1Y = height - (Inf->FingerPoint1 / width);
	double Point2X = Inf->FingerPoint2 % width;
	double Point2Y = height - (Inf->FingerPoint2 / width);
	double Point3X = Inf->FingerPoint3 % width;
	double Point3Y = height - (Inf->FingerPoint3 / width);
	double Point4X = Inf->FingerPoint4 % width;
	double Point4Y = height - (Inf->FingerPoint4 / width);
	double Point5X = Inf->FingerPoint5 % width;
	double Point5Y = height - (Inf->FingerPoint5 / width);
	double Point6X = Inf->FingerPoint6 % width;
	double Point6Y = height - (Inf->FingerPoint6 / width);
	double Point7X = Inf->FingerPoint7 % width;
	double Point7Y = height - (Inf->FingerPoint7 / width);
	double Point8X = Inf->FingerPoint8 % width;
	double Point8Y = height - (Inf->FingerPoint8 / width);

	double P1X = Inf->Point1 % width;
	double P1Y = height - (Inf->Point1 / width);
	double P2X = Inf->Point2 % width;
	double P2Y = height - (Inf->Point2 / width);
	double P3X = Inf->Point3 % width;
	double P3Y = height - (Inf->Point3 / width);
	double P4X = Inf->Point4 % width;
	double P4Y = height - (Inf->Point4 / width);
	double P5X = Inf->Point5 % width;
	double P5Y = height - (Inf->Point5 / width);
	double P6X = Inf->Point6 % width;
	double P6Y = height - (Inf->Point6 / width);
	double P7X = Inf->Point7 % width;
	double P7Y = height - (Inf->Point7 / width);
	double P8X = Inf->Point8 % width;
	double P8Y = height - (Inf->Point8 / width);

	double a1[8][8] = {	Point1X*Point1X*Point1X,Point1Y*Point1Y*Point1Y,Point1X*Point1X*Point1Y,Point1X*Point1Y*Point1Y,Point1X*Point1Y,Point1X,Point1Y,1,
						Point2X*Point2X*Point2X,Point2Y*Point2Y*Point2Y,Point2X*Point2X*Point2Y,Point2X*Point2Y*Point2Y,Point2X*Point2Y,Point2X,Point2Y,1,
						Point3X*Point3X*Point3X,Point3Y*Point3Y*Point3Y,Point3X*Point3X*Point3Y,Point3X*Point3Y*Point3Y,Point3X*Point3Y,Point3X,Point3Y,1,
						Point4X*Point4X*Point4X,Point4Y*Point4Y*Point4Y,Point4X*Point4X*Point4Y,Point4X*Point4Y*Point4Y,Point4X*Point4Y,Point4X,Point4Y,1, 
						Point5X*Point5X*Point5X,Point5Y*Point5Y*Point5Y,Point5X*Point5X*Point5Y,Point5X*Point5Y*Point5Y,Point5X*Point5Y,Point5X,Point5Y,1,
						Point6X*Point6X*Point6X,Point6Y*Point6Y*Point6Y,Point6X*Point6X*Point6Y,Point6X*Point6Y*Point6Y,Point6X*Point6Y,Point6X,Point6Y,1,
						Point7X*Point7X*Point7X,Point7Y*Point7Y*Point7Y,Point7X*Point7X*Point7Y,Point7X*Point7Y*Point7Y,Point7X*Point7Y,Point7X,Point7Y,1,
						Point8X*Point8X*Point8X,Point8Y*Point8Y*Point8Y,Point8X*Point8X*Point8Y,Point8X*Point8Y*Point8Y,Point8X*Point8Y,Point8X,Point8Y,1, };
	double b1[8] = { P1X,P2X,P3X,P4X,P5X,P6X,P7X,P8X };
	double m = 0;

	for (int i=0; i<=(n-2); i++) {
		for (int j=i+1; j<=(n-1); j++) {
			m = a1[j][i] / a1[i][i];
			a1[j][i] = 0;
			b1[j] = b1[j] - m*b1[i];
			for (int k=i+1; k<=(n-1); k++) {
				a1[j][k] = a1[j][k] - m*a1[i][k];
			}
		}
	}

	Inf->PointXConstant[n-1] = b1[n-1] / a1[n-1][n-1];

	for (i=(n-2); i>=0; i--) {
		for (int j=i+1; j<=(n-1); j++) {
			b1[i] = b1[i] - a1[i][j]*Inf->PointXConstant[j];
			Inf->PointXConstant[i] = b1[i] / a1[i][i];
		}
	}

	double a2[8][8] = {	Point1X*Point1X*Point1X,Point1Y*Point1Y*Point1Y,Point1X*Point1X*Point1Y,Point1X*Point1Y*Point1Y,Point1X*Point1Y,Point1X,Point1Y,1,
						Point2X*Point2X*Point2X,Point2Y*Point2Y*Point2Y,Point2X*Point2X*Point2Y,Point2X*Point2Y*Point2Y,Point2X*Point2Y,Point2X,Point2Y,1,
						Point3X*Point3X*Point3X,Point3Y*Point3Y*Point3Y,Point3X*Point3X*Point3Y,Point3X*Point3Y*Point3Y,Point3X*Point3Y,Point3X,Point3Y,1,
						Point4X*Point4X*Point4X,Point4Y*Point4Y*Point4Y,Point4X*Point4X*Point4Y,Point4X*Point4Y*Point4Y,Point4X*Point4Y,Point4X,Point4Y,1, 
						Point5X*Point5X*Point5X,Point5Y*Point5Y*Point5Y,Point5X*Point5X*Point5Y,Point5X*Point5Y*Point5Y,Point5X*Point5Y,Point5X,Point5Y,1,
						Point6X*Point6X*Point6X,Point6Y*Point6Y*Point6Y,Point6X*Point6X*Point6Y,Point6X*Point6Y*Point6Y,Point6X*Point6Y,Point6X,Point6Y,1,
						Point7X*Point7X*Point7X,Point7Y*Point7Y*Point7Y,Point7X*Point7X*Point7Y,Point7X*Point7Y*Point7Y,Point7X*Point7Y,Point7X,Point7Y,1,
						Point8X*Point8X*Point8X,Point8Y*Point8Y*Point8Y,Point8X*Point8X*Point8Y,Point8X*Point8Y*Point8Y,Point8X*Point8Y,Point8X,Point8Y,1, };
	double b2[8] = { P1Y,P2Y,P3Y,P4Y,P5Y,P6Y,P7Y,P8Y };
	m = 0;

	for (i=0; i<=(n-2); i++) {
		for (int j=i+1; j<=(n-1); j++) {
			m = a2[j][i] / a2[i][i];
			a2[j][i] = 0;
			b2[j] = b2[j] - m*b2[i];
			for (int k=i+1; k<=(n-1); k++) {
				a2[j][k] = a2[j][k] - m*a2[i][k];
			}
		}
	}

	Inf->PointYConstant[n-1] = b2[n-1] / a2[n-1][n-1];

	for (i=(n-2); i>=0; i--) {
		for (int j=i+1; j<=(n-1); j++) {
			b2[i] = b2[i] - a2[i][j]*Inf->PointYConstant[j];
			Inf->PointYConstant[i] = b2[i] / a2[i][i];
		}

	}
}

long ProgramConfig::FindFingerPoint(int point) // S = TempHandleGray2, D = TempHandleGray1
{
	BYTE *data1 = (BYTE*)m_video->GetDataPointer(TempHandleColor1);
	BYTE *data2 = (BYTE*)m_video->GetDataPointer(TempHandleColor2);
	BYTE *data3 = (BYTE*)m_video->GetDataPointer(m_ResultImage);

	int width = m_video->GetWidth();
	int height = m_video->GetHeight();
	int size = 20*3;
	int s = 20*3;
	int begin = 0;
	int end = 0;
	long tempPoint = 0;
	int pixel = 30;
	int ts = 70;
	int count = 0;
	
	switch (point) {
	case 1 :
		begin = (Inf->Point1 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point1 + ((size/6)*width) + (size/6))*3;
		break;
	case 2:
		begin = (Inf->Point2 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point2 + ((size/6)*width) + (size/6))*3;
		break;
	case 3:
		begin = (Inf->Point3 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point3 + ((size/6)*width) + (size/6))*3;
		break;
	case 4:
		begin = (Inf->Point4 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point4 + ((size/6)*width) + (size/6))*3;
		break;
	case 5:
		begin = (Inf->Point5 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point5 + ((size/6)*width) + (size/6))*3;
		break;
	case 6:
		begin = (Inf->Point6 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point6 + ((size/6)*width) + (size/6))*3;
		break;
	case 7:
		begin = (Inf->Point7 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point7 + ((size/6)*width) + (size/6))*3;
		break;
	case 8:
		begin = (Inf->Point8 - ((size/6)*width) - (size/6))*3;
		end = (Inf->Point8 + ((size/6)*width) + (size/6))*3;
		break;
	}

	while ( (ts>=25) && (count <= pixel) ) {
		count = 0;
		tempPoint = 0;
		for (int i=begin; i<=end; i++) {
			if ((i%3)==0) {
				if (InScreen(i/3,width,height)) {
					if ( ((data2[i] - data1[i]) >= ts) || ((data1[i] - data2[i]) >= ts) ||
						 ((data2[i+1] - data1[i+1]) >= ts) || ((data1[i+1] - data2[i+1]) >= ts) ||
						 ((data2[i+2] - data1[i+2]) >= ts) || ((data1[i+2] - data2[i+2]) >= ts) ) {

						if (i>tempPoint) {
							tempPoint = i;
						}
						count++;
						data3[i] = 255;
						data3[i+1] = 255;
						data3[i+2] = 255;
					}
				}
			}

			s--;
			if (s == 0) {
				s = size;
				i = i+(width-(size/3))*3;
			}
			

		}

		ts = ts - 5;
		pixel = pixel - 5;
		
	}

	if (tempPoint == 0) {
		MessageBox("Get Color Point Error",NULL,MB_OK);
		return 0;
	}


	return tempPoint/3;
}

bool ProgramConfig::InScreen(long point,int width,int height)
{
	int xxx = point % width;
	int yyy = point / width;
	int count = 0;

	if ( ((height/2)-Inf->LeftUpY-15) >= (Inf->m1*((width/2)-Inf->LeftUpX)) ) {
		if ((yyy-Inf->LeftUpY-15) >= (Inf->m1*(xxx-Inf->LeftUpX))) {
			count++;
		}
	}else {
		if ((yyy-Inf->LeftUpY-15) <= (Inf->m1*(xxx-Inf->LeftUpX))) {
			count++;
		}
	}

	if (((height/2)-Inf->LeftDownY+15) >= (Inf->m2*((width/2)-Inf->LeftDownX))) {
		if ((yyy-Inf->LeftDownY+15) >= (Inf->m2*(xxx-Inf->LeftDownX))) {
			count++;
		}
	}else {
		if ((yyy-Inf->LeftDownY+15) >= (Inf->m2*(xxx-Inf->LeftDownX))) {
			count++;
		}
	}

	if (((height/2)-Inf->LeftUpY) <= (Inf->m3*((width/2)-Inf->LeftUpX+15))) {
		if ((yyy-Inf->LeftUpY) <= (Inf->m3*(xxx-Inf->LeftUpX+15))) {
			count++;
		}
	}else {
		if ((yyy-Inf->LeftUpY) >= (Inf->m3*(xxx-Inf->LeftUpX+15))) {
			count++;
		}
	}

	if (((height/2)-Inf->RightUpY) >= (Inf->m4*((width/2)-Inf->RightUpX-15))) {
		if ((yyy-Inf->RightUpY) >= (Inf->m4*(xxx-Inf->RightUpX-15))) {
			count++;
		}
	}else {
		if ((yyy-Inf->RightUpY) <= (Inf->m4*(xxx-Inf->RightUpX-15))) {
			count++;
		}
	}

	if (count == 4) {
		return true;
	}

	return false;
}

void ProgramConfig::GetInfoFinger() // find color of finger
{
	Inf->MaxR = 0;
	Inf->MaxG = 0;
	Inf->MaxB = 0;
	Inf->MinR = 255;
	Inf->MinG = 255;
	Inf->MinB = 255;
	Inf->MaxDifRG = 0;
	Inf->MaxDifGB = 0;
	Inf->MaxDifRB = 0;
	Inf->MinDifRG = 255;
	Inf->MinDifGB = 255;
	Inf->MinDifRB = 255;

		BYTE *data = (BYTE*)m_video->GetDataPointer(TempHandleColor1);
		int size = m_video->GetImageDataSize(m_Image);
		int width = m_video->GetWidth();
		int height = m_video->GetHeight();
		int w = 0;
		int h = 0;
		int temp = 0;
		int PointX = Inf->Point4 % width;
		int PointY = Inf->Point4 / width;
		for (int i=0; i<size; i++) {
			temp = i/3;
			w = temp % width;
			h = temp / width;
			if ( (w >= (PointX-15)) && (w <= (PointX+20)) && (h >= (PointY-15)) && (h <= (PointY+15)) ) {
				if ((i%3) == 0){	// Blue
					if ( (data[i] < 128) ) {
						if (data[i] > Inf->MaxB) {
							Inf->MaxB = data[i];
						}
						if (data[i] < Inf->MinB) {
							Inf->MinB = data[i];
						}

						if (data[i+1] > Inf->MaxG) {
							Inf->MaxG = data[i+1];
						}
						if (data[i+1] < Inf->MinG) {
							Inf->MinG = data[i+1];
						}

						if (data[i+2] > Inf->MaxR) {
							Inf->MaxR = data[i+2];
						}
						if (data[i+2] < Inf->MinR) {
							Inf->MinR = data[i+2];
						}

						if ((data[i+2]-data[i+1]) > Inf->MaxDifRG) {
							Inf->MaxDifRG = data[i+2]-data[i+1];
						}
						if ((data[i+2]-data[i+1]) < Inf->MinDifRG) {
							Inf->MinDifRG = data[i+2]-data[i+1];
						}
						if ((data[i+1]-data[i]) > Inf->MaxDifGB) {
							Inf->MaxDifGB = data[i+1]-data[i];
						}
						if ((data[i+1]-data[i]) < Inf->MinDifGB) {
							Inf->MinDifGB = data[i+1]-data[i];
						}
						if ((data[i+2]-data[i]) > Inf->MaxDifRB) {
							Inf->MaxDifRB = data[i+2]-data[i];
						}
						if ((data[i+2]-data[i]) < Inf->MinDifRB) {
							Inf->MinDifRB = data[i+2]-data[i];
						}

						data[i] = 0;
						data[i+1] = 0;
						data[i+2] = 255;

					}else {
						data[i] = 255;
						data[i+1] = 255;
						data[i+2] = 255;
					}
				}
				if ((i%3) == 1){	// Green
				}
				if ((i%3) == 2){    // Red
				}
			}
			
		}
	
	
}


