// Info.h: interface for the Info class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INFO_H__874562AB_76C5_4B40_A7E7_960A711DE62E__INCLUDED_)
#define AFX_INFO_H__874562AB_76C5_4B40_A7E7_960A711DE62E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Info  
{
public:
	int FrameRate;
	long Point1;
	long Point2;
	long Point3;
	long Point4;
	long Point5;
	long Point6;
	long Point7;
	long Point8;
	long FingerPoint1;
	long FingerPoint2;
	long FingerPoint3;
	long FingerPoint4;
	long FingerPoint5;
	long FingerPoint6;
	long FingerPoint7;
	long FingerPoint8;
	double LeftUpX;
	double LeftDownX;
	double RightUpX;
	double RightDownX;
	double LeftUpY;
	double LeftDownY;
	double RightUpY;
	double RightDownY;
	double m1;
	double m2;
	double m3;
	double m4;
	double XConstant[8];
	double YConstant[8];
	double PointXConstant[8];
	double PointYConstant[8];
	int MaxR;
	int MaxG;
	int MaxB;
	int MinR;
	int MinG;
	int MinB;
	int MaxDifRG;
	int MaxDifGB;
	int MaxDifRB;
	int MinDifRG;
	int MinDifGB;
	int MinDifRB; 
	long Base1;
	int BaseB1;
	int BaseG1;
	int BaseR1;
	Info();
	virtual ~Info();

};

#endif // !defined(AFX_INFO_H__874562AB_76C5_4B40_A7E7_960A711DE62E__INCLUDED_)
