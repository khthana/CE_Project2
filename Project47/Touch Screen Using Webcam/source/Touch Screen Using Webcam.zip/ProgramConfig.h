#if !defined(AFX_PROGRAMCONFIG_H__A909C37A_683E_4C02_AE27_357495D5597E__INCLUDED_)
#define AFX_PROGRAMCONFIG_H__A909C37A_683E_4C02_AE27_357495D5597E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProgramConfig.h : header file
#include "videoocx.h"
#include "videoocxtools.h"
#include "Info.h"
//

/////////////////////////////////////////////////////////////////////////////
// ProgramConfig dialog

class ProgramConfig : public CDialog
{
// Construction
public:		
	int countSec;
	int m_Timer;
	int state;
	bool setInterface;
	Info *Inf;
	CVideoOCX* m_video;
	CVideoOCXTools*	m_videoTool;
	int DlgWidth;
	int DlgHeight;
	long m_Image;
	long m_ResultImage;
	long m_HelperImage;
	long m_GrayImage;
	long m_GrayResultImage;
	long m_GrayHelperImage;
	long TempHandleColor1;
	long TempHandleColor2;
	long TempHandleGray1;
	long TempHandleGray2;
	DEVMODE dmOld;
	void GetInfo(Info *I);
	void GetHandleVideo(CVideoOCX *video,CVideoOCXTools* videoTool);
	void StopInterface();
	void StartInterface();
	void GetPicture1(int type);
	void GetPicture2(int type);
	void CreateGrayScreen();
	bool FindPoint();
	long GetPoint();
	bool InScreen(long point,int width,int height);
	long FindFingerPoint(int point);
	void FindConstant(int width,int height);
	void FindConstant1(int width,int height);
	void GetInfoFinger();
	ProgramConfig(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ProgramConfig)
	enum { IDD = IDD_CONFIGSCREEN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ProgramConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ProgramConfig)
	virtual BOOL OnInitDialog();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGRAMCONFIG_H__A909C37A_683E_4C02_AE27_357495D5597E__INCLUDED_)
