#include <reg51.h>
#include <stdio.h>
sbit RF_Data_Recieve = P3^2;
sbit RF_Data_Send = P1^0;
unsigned char RF_CarSign = 0x08;
unsigned char RF_Recieve = 0x00;
unsigned char RF_Send = 0x0A;
unsigned char tempu = 0x00;
unsigned char checksum = 0x00;
int index,indexs;

// For delay baud rate 1200 baud
void delay_baud1200() {
	unsigned int x,a;
	for (x=0;x<1;x++) {
		//loop for delay 833 us
		for (a=0;a<365;a++);	
	}
}

// For get RF_Recieve value
unsigned char get_remote() {
	return(RF_Recieve);
}

// For clear RF_Recieve value
void clear_remote() {
	RF_Recieve = 0x00;
}


// For initialize value
void remote_init(void) {
	RF_Data_Recieve= 1;
	EX0 = 1;
	IT0 = 1;
	EA = 1;
}
// For recieve bus code from bus
void service_ex0(void) interrupt 0 {
	int i,parity = 0;
	unsigned char crc;
	// Recieve header
	for (i=0;i<8;i++) {
		delay_baud1200();
		tempu = tempu >> 1;
		if (RF_Data_Recieve) {
			tempu = tempu | 0x80;
		}
	}
	// Check header
	if (tempu == 'U') {
		// Recieve bus code
		for (i=0;i<8;i++) {
			delay_baud1200();
			RF_Recieve = RF_Recieve >> 1;
			if (RF_Data_Recieve) {
				RF_Recieve = RF_Recieve | 0x80;
			}
		}
		for (i=0;i<8;i++) {
			delay_baud1200();
			crc = crc >> 1;
			if (RF_Data_Recieve) {
				crc = crc | 0x80;
			}
		}
		delay_baud1200();
		crc = crc + RF_Recieve + tempu;
		if(crc != 0xFF) clear_remote();
	}
	EX0 = 0;
	ES = 1;
}

// For send bus code and sign bit to station
void service_send() {		// Send bit data station to Bus
	unsigned char a,tmp;// Checksum;
	int i,parity = 0;
	// Send sync header
	tmp = 'U';
	for (i=0;i<8;i++) {	
		a = tmp & 0x01;
		tmp = tmp >> 1;
		if (a) {
			RF_Data_Send = 1;
		}
		else RF_Data_Send = 0;
		delay_baud1200();
	}
	// Send data
	tmp = RF_Send;
	for (i=0;i<8;i++) {	
		a = tmp & 0x01;
		tmp = tmp >> 1;
		if (a) { 
			RF_Data_Send = 1;
		}
		else RF_Data_Send = 0;
		delay_baud1200();
	}
	checksum = 'U' + RF_Send;
	checksum = ~checksum;
	// Send Checksum
	tmp = checksum;
	for (i=0;i<8;i++) {	
		a = tmp & 0x01;
		tmp = tmp >> 1;
		if (a) { 
			RF_Data_Send = 1;
		}
		else RF_Data_Send = 0;
		delay_baud1200();
	}
	// Send Stop bit	
	RF_Data_Send = 0;
	delay_baud1200();
}

void main() {
	//----------------Enable interrupt serail port configuration 9600 bps
	SCON = 0x50;	//configuration for serial port Rx/Tx data
	TMOD = 0x21;	//Timer 1 mode 2
	TH1  = 0xFD;	//Reload value for serial baudrate(9600 bps)
	TL1  = 0xFD;
	EA   = 1;
	ES   = 1;
	TR1  = 1;
	remote_init();	// set initial RF
	while(1) {
		if (get_remote() != 0x00) {
			if (RF_Send == 0x00) {
				RF_Send = get_remote() | RF_CarSign;
				for (index=0;index<52;index++) service_send();
				for (indexs=0;indexs<2550;indexs++) delay_baud1200();
				clear_remote();
				EX0 = 1;
			}
			else {
				for (index=0;index<52;index++) service_send();
				for (indexs=0;indexs<2550;indexs++) delay_baud1200();
				clear_remote();
				EX0 = 1;
			}
		}
		else {
			RF_Send = 0;
			EX0 = 1;
		}
	}
}
