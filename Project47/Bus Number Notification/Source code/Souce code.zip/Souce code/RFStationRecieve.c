#include <reg51.h>
#include <stdio.h>
sbit RF_Data_Recieve = P3^2;
unsigned char RF_Recieve = 0x00;
unsigned char tempu = 0x00;
unsigned char busQ[10];
int countQ[10];
unsigned int i = 0;
unsigned int j,k,a;

// For delay baud rate 1200 baud
void delay_baud1200() {
	unsigned int x,a;
	for (x=0;x<1;x++) {
		//loop for delay 833 us
		for (a=0;a<365;a++);	
	}
}

// For clear RF_Recieve value
void clear_remote() {
	RF_Recieve = 0x00;
}

// For clear bus queue
void clearQ() {
	int i;
	for (i=0;i<10;i++) {
		busQ[i] = 0x00;
		countQ[i] = 0;
	}
}

// For get RF_Recieve value
unsigned char get_remote() {
	return RF_Recieve;
}

// Interrupt for serial communication
void service_serial() interrupt 4 {
	if (TI) {
		TI = 0;
	}
} 

// For recieve bus code from bus
void service_ex0(void) interrupt 0 {
	int i,parity = 0;
	unsigned char crc;
	// Recieve header
	for (i=0;i<8;i++) {
		delay_baud1200();
		tempu = tempu >> 1;
		if (RF_Data_Recieve) {
			tempu = tempu | 0x80;
		}
	}
	// Check header
	if (tempu == 'U') {
		// Recieve bus code
		for (i=0;i<8;i++) {
			delay_baud1200();
			RF_Recieve = RF_Recieve >> 1;
			if (RF_Data_Recieve) {
				RF_Recieve = RF_Recieve | 0x80;
			}
		}
		for (i=0;i<8;i++) {
			delay_baud1200();
			crc = crc >> 1;
			if (RF_Data_Recieve) {
				crc = crc | 0x80;
			}
		}
		delay_baud1200();
		crc = crc + RF_Recieve + tempu;
		if(crc != 0xFF) clear_remote();
	}
	EX0 = 0;
	ES = 1;
}

// For initialize value
void remote_init(void) {
	RF_Data_Recieve = 1;
	EX0 = 1;
	IT0 = 1;
	EA = 1;
}

void main() {
	//----------------Enable interrupt serail port configuration 9600 bps
	SCON = 0x50;	//configuration for serial port Rx/Tx data
	TMOD = 0x21;	//Timer 1 mode 2
	TH1  = 0xFD;	//Reload value for serial baudrate(9600 bps)
	TL1  = 0xFD;
	EA   = 1;
	ES   = 1;
	TR1  = 1;
	clearQ();
	remote_init();	// set initial RF
	while(1) {
		if (get_remote() != 0x00) {
			while (1) {
				if (busQ[i] == get_remote()) {
					countQ[i] = 0;
					i = 0;
					break;
				}
				if (busQ[i] == 0x00) {
					busQ[i] = get_remote();
					for (j=0;j<10;j++) 
						if ((busQ[j] != 0x00)&&(j!=i)) countQ[j]++;
					i = 0;
					break;
				}
				if (i > 9) {
					RF_Recieve = busQ[0] & 0x7F;
					for (j=0;j<9;j++) { 
						busQ[j] = busQ[j+1];
						countQ[j] = countQ[j+1];
					}
					busQ[9] = get_remote();
					i = 0;
					break;
				}
				if (countQ[i] > 1990) {
					for (j=i;j<9;j++) { 
						busQ[j] = busQ[j+1];
						countQ[j] = countQ[j+1];
					}
					busQ[9] = 0x00;
					RF_Recieve = busQ[i] & 0x7F; 
					i = 0;
					break;
				}
				i++;
			}
			SBUF = get_remote();
			clear_remote();	//clear data from RF_Recieve
			ES = 0;
			EX0 = 1;
		}
		else {
			for (j=0;j<10;j++) 
				if (busQ[j] != 0x00) countQ[j]++;
			for (j=0;j<10;j++) {
				if (countQ[j] > 1990) {
					SBUF = busQ[j] & 0x7F;
					for (k=j;k<10;k++) {
						busQ[k] = busQ[k+1];
						countQ[k] = countQ[k+1];
					}
					j--;
				}
			}
			ES = 0;
			EX0 = 1;
		}
	}
}