VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form Form1 
   Caption         =   "Bus Number Notification"
   ClientHeight    =   9975
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   14340
   LinkTopic       =   "Form1"
   ScaleHeight     =   9975
   ScaleMode       =   0  'User
   ScaleWidth      =   14340
   Begin VB.Frame Frame2 
      Caption         =   "Display Bus Number"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   26.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   11055
      Left            =   120
      TabIndex        =   32
      Top             =   0
      Visible         =   0   'False
      Width           =   15015
      Begin VB.TextBox Text17 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   99.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2880
         Left            =   560
         TabIndex        =   33
         Top             =   840
         Width           =   6800
      End
      Begin VB.TextBox Text18 
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "AngsanaUPC"
            Size            =   21.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2880
         Left            =   7710
         MultiLine       =   -1  'True
         TabIndex        =   42
         Top             =   840
         Width           =   6800
      End
      Begin VB.TextBox Text26 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   11060
         TabIndex        =   41
         Top             =   7340
         Width           =   3200
      End
      Begin VB.TextBox Text25 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   7560
         TabIndex        =   40
         Top             =   7340
         Width           =   3200
      End
      Begin VB.TextBox Text24 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   4060
         TabIndex        =   39
         Top             =   7340
         Width           =   3200
      End
      Begin VB.TextBox Text23 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   560
         TabIndex        =   38
         Top             =   7340
         Width           =   3200
      End
      Begin VB.TextBox Text22 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   11060
         TabIndex        =   37
         Top             =   4840
         Width           =   3200
      End
      Begin VB.TextBox Text21 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   7560
         TabIndex        =   36
         Top             =   4840
         Width           =   3200
      End
      Begin VB.TextBox Text20 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   4060
         TabIndex        =   35
         Top             =   4840
         Width           =   3200
      End
      Begin VB.TextBox Text19 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   72
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2115
         Left            =   560
         TabIndex        =   34
         Top             =   4840
         Width           =   3200
      End
      Begin VB.OLE OLE1 
         Height          =   30
         Left            =   5760
         TabIndex        =   43
         Top             =   3360
         Width           =   135
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Initialize Bus Numbers"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   27.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   8775
      Left            =   2400
      TabIndex        =   0
      Top             =   960
      Width           =   10815
      Begin VB.CommandButton Command2 
         Caption         =   "&Update"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   765
         Left            =   600
         TabIndex        =   47
         Top             =   7500
         Width           =   1965
      End
      Begin VB.CommandButton CmdOK 
         Caption         =   "&OK"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   765
         Left            =   5600
         Style           =   1  'Graphical
         TabIndex        =   46
         Top             =   7500
         Width           =   1965
      End
      Begin VB.CommandButton CmdLoad 
         Caption         =   "&Load"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   765
         Left            =   3100
         TabIndex        =   45
         Top             =   7500
         Width           =   1965
      End
      Begin VB.CommandButton CmdSave 
         Caption         =   "&Save"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   765
         Left            =   8100
         TabIndex        =   44
         Top             =   7480
         Width           =   1965
      End
      Begin MSCommLib.MSComm MSComm1 
         Left            =   8100
         Top             =   6900
         _ExtentX        =   1005
         _ExtentY        =   1005
         _Version        =   393216
         DTREnable       =   -1  'True
      End
      Begin MSComDlg.CommonDialog CommonDialog1 
         Left            =   7500
         Top             =   6900
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
         Flags           =   3
      End
      Begin VB.TextBox Text16 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   31
         Top             =   6440
         Width           =   1845
      End
      Begin VB.TextBox Text15 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   30
         Top             =   5640
         Width           =   1845
      End
      Begin VB.TextBox Text14 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   29
         Top             =   4840
         Width           =   1845
      End
      Begin VB.TextBox Text13 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   28
         Top             =   4040
         Width           =   1845
      End
      Begin VB.TextBox Text12 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   27
         Top             =   3240
         Width           =   1845
      End
      Begin VB.TextBox Text11 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   26
         Top             =   2440
         Width           =   1845
      End
      Begin VB.TextBox Text10 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   25
         Top             =   1640
         Width           =   1845
      End
      Begin VB.TextBox Text9 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   8760
         TabIndex        =   24
         Top             =   840
         Width           =   1845
      End
      Begin VB.TextBox Text8 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   23
         Top             =   6440
         Width           =   1845
      End
      Begin VB.TextBox Text7 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   22
         Top             =   5640
         Width           =   1845
      End
      Begin VB.TextBox Text6 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   21
         Top             =   4840
         Width           =   1845
      End
      Begin VB.TextBox Text5 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   20
         Top             =   4040
         Width           =   1845
      End
      Begin VB.TextBox Text4 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   19
         Top             =   3240
         Width           =   1845
      End
      Begin VB.TextBox Text3 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   18
         Top             =   2440
         Width           =   1845
      End
      Begin VB.TextBox Text2 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   17
         Top             =   1640
         Width           =   1845
      End
      Begin VB.TextBox Text1 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   20.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   3360
         TabIndex        =   16
         Top             =   840
         Visible         =   0   'False
         Width           =   1845
      End
      Begin VB.Label Label16 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1111"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   15
         Top             =   6440
         Width           =   1845
      End
      Begin VB.Label Label15 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1110"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   14
         Top             =   5640
         Width           =   1845
      End
      Begin VB.Label Label14 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1101"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   13
         Top             =   4840
         Width           =   1815
      End
      Begin VB.Label Label13 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1100"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   12
         Top             =   4040
         Width           =   1845
      End
      Begin VB.Label Label12 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1011"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   11
         Top             =   3240
         Width           =   1845
      End
      Begin VB.Label Label11 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1010"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   10
         Top             =   2440
         Width           =   1845
      End
      Begin VB.Label Label10 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1001"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   9
         Top             =   1640
         Width           =   1845
      End
      Begin VB.Label Label9 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 1000"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   5760
         TabIndex        =   8
         Top             =   840
         Width           =   1845
      End
      Begin VB.Line Line1 
         X1              =   5400
         X2              =   5400
         Y1              =   720
         Y2              =   7080
      End
      Begin VB.Label Label8 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0111"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   7
         Top             =   6440
         Width           =   1845
      End
      Begin VB.Label Label7 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0110"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   6
         Top             =   5640
         Width           =   1845
      End
      Begin VB.Label Label6 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0101"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   5
         Top             =   4840
         Width           =   1845
      End
      Begin VB.Label Label5 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0100"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   4
         Top             =   4040
         Width           =   1845
      End
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0011"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   3
         Top             =   3240
         Width           =   1845
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0010"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   2
         Top             =   2440
         Width           =   1845
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Code 0001"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   20.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   465
         Left            =   360
         TabIndex        =   1
         Top             =   1640
         Width           =   1845
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim connStr As String
Dim conn As New ADODB.Connection
Dim rs As New ADODB.Recordset
Dim Code2BusNum(16) As String
Dim DataBuffer(10) As Byte
Dim BusQue(10) As String
Dim flag As Boolean

Public Static Sub SetQues(j As Integer, StrData As Byte)
    i% = 1
    X = 1
    Dim temp As Byte
    Dim NumBus As Byte
    ' For check out bus code
    temp = StrData And 128
    Do While X
        If j <> 1 Then
            ' Enqueue bus queue
            If (BusQue(i) = Code2BusNum(j)) And (DataBuffer(i) = StrData) Then
                flag = False
                X = 0
            End If
            If BusQue(i) = "" Then
                BusQue(i) = Code2BusNum(j)
                DataBuffer(i) = StrData
                flag = True
                X = 0
            End If
            ' Out bus code dequeue bus queue
            If temp = 0 Then
                For l% = 1 To 10
                    If (DataBuffer(l) And 127) = StrData Then
                        Exit For
                    End If
                Next
                For k% = l To 8
                    BusQue(k) = BusQue(k + 1)
                    DataBuffer(k) = DataBuffer(k + 1)
                Next
                flag = True
                X = 0
            End If
            ' Bus queue overflow dequeue first queue
            If i > 9 Then
                For k% = 1 To 8
                    BusQue(k) = BusQue(k + 1)
                    DataBuffer(k) = DataBuffer(k + 1)
                Next
                BusQue(9) = Code2BusNum(j)
                flag = True
                X = 0
            End If
            i = i + 1
        End If
        If j = 1 Then
            X = 0
        End If
    Loop
End Sub
' For open file .bnn
Private Sub CmdLoad_Click()
    CommonDialog1.ShowOpen
    iFileNum% = FreeFile
    i% = 1
    Dim BusNum(16) As String
    pFile$ = CommonDialog1.FileName
    If pFile <> "" Then
        dfile$ = Right(pFile, 4)
        If LCase(dfile) <> ".bnn" Then
            MsgBox "�� File ����չ��ʡ�� .bnn ��ҹ��", 48, "�駢�ͼԴ��Ҵ"
        Else
            Open pFile For Input As #iFileNum
            Do While Not EOF(iFileNum)
                Line Input #iFileNum, DataVar
                BusNum(i) = DataVar
                i = i + 1
            Loop
            Close #iFileNum
            ' Show data in .bnn file
            Text1.Text = BusNum(1)
            Text2.Text = BusNum(2)
            Text3.Text = BusNum(3)
            Text4.Text = BusNum(4)
            Text5.Text = BusNum(5)
            Text6.Text = BusNum(6)
            Text7.Text = BusNum(7)
            Text8.Text = BusNum(8)
            Text9.Text = BusNum(9)
            Text10.Text = BusNum(10)
            Text11.Text = BusNum(11)
            Text12.Text = BusNum(12)
            Text13.Text = BusNum(13)
            Text14.Text = BusNum(14)
            Text15.Text = BusNum(15)
            Text16.Text = BusNum(16)
        End If
    End If
End Sub

Private Sub CmdOK_Click()
    ' Check correction of data
    If MsgBox("��ҷ������鹶١��ͧ�����������?", 68, "�ô�׹�ѹ�����١��ͧ") = 6 Then
        Frame2.Visible = True
    Else
        Frame2.Visible = False
    End If
End Sub
' For save file .bnn
Private Sub CmdSave_Click()
    CommonDialog1.ShowSave
    iFileNum% = FreeFile
    pFile$ = CommonDialog1.FileName
    If pFile <> "" Then
        pFile = pFile + ".bnn"
        BusNum$ = Text1.Text + vbCrLf + Text2.Text + vbCrLf + Text3.Text + vbCrLf + Text4.Text + vbCrLf + Text5.Text + vbCrLf + Text6.Text + vbCrLf + Text7.Text + vbCrLf + Text8.Text + vbCrLf + Text9.Text + vbCrLf + Text10.Text + vbCrLf + Text11.Text + vbCrLf + Text12.Text + vbCrLf + Text13.Text + vbCrLf + Text14.Text + vbCrLf + Text15.Text + vbCrLf + Text16.Text
        Open pFile For Output As #iFileNum
        Print #iFileNum, BusNum
        Close #iFileNum
    End If
End Sub

Private Sub Command2_Click()
    Load frmbus
    frmbus.Show
    Form1.Enabled = False
End Sub

' Have data from RF Station Recieve Board
Private Sub MSComm1_OnComm()
    Dim NumBus As Byte
    Dim StrData As String
'    Dim test As String
'    Dim testint As Integer
'    Dim teststr As Integer
    NumBus = 15
    ' Get input
    StrData = MSComm1.Input
    ' Cut first character
'    test = Mid$(StrData, 3, 1)
'    testint = Asc(test)
    StrData = Left$(StrData, 1)
'    teststr = Asc(StrData)
    If (StrData <> "") Then
        ' Divide signbit and bus code
        NumBus = NumBus And Asc(StrData)
        i% = NumBus + 1
        ' Set queue bus for display
        Call SetQues(i, Asc(StrData))
    End If
    ' If queue change, Change display
    If flag Then
        If BusQue(1) <> "" Then
            'Select detail from database bus
            sqlStm = "SELECT busdetail FROM bus WHERE busid = '" + BusQue(1) + "'"
            Set rs = conn.Execute(sqlStm, NumRowAuto, adCmdTxt)
            Text18.Text = rs("busdetail")
        End If
        ' For dequeue
        If BusQue(1) = "" Then
            Text18.Text = ""
        End If
        ' Set text follow by queue
        Text17.Text = BusQue(1)
        Text19.Text = BusQue(2)
        Text20.Text = BusQue(3)
        Text21.Text = BusQue(4)
        Text22.Text = BusQue(5)
        Text23.Text = BusQue(6)
        Text24.Text = BusQue(7)
        Text25.Text = BusQue(8)
        Text26.Text = BusQue(9)
    End If
End Sub

Private Sub Text1_Change()
    Code2BusNum(1) = Text1.Text
End Sub

Private Sub Text2_Change()
    Code2BusNum(2) = Text2.Text
End Sub

Private Sub Text3_Change()
    Code2BusNum(3) = Text3.Text
End Sub

Private Sub Text4_Change()
    Code2BusNum(4) = Text4.Text
End Sub

Private Sub Text5_Change()
    Code2BusNum(5) = Text5.Text
End Sub

Private Sub Text6_Change()
    Code2BusNum(6) = Text6.Text
End Sub

Private Sub Text7_Change()
    Code2BusNum(7) = Text7.Text
End Sub

Private Sub Text8_Change()
    Code2BusNum(8) = Text8.Text
End Sub

Private Sub Text9_Change()
    Code2BusNum(9) = Text9.Text
End Sub

Private Sub Text10_Change()
    Code2BusNum(10) = Text10.Text
End Sub

Private Sub Text11_Change()
    Code2BusNum(11) = Text11.Text
End Sub

Private Sub Text12_Change()
    Code2BusNum(12) = Text12.Text
End Sub

Private Sub Text13_Change()
    Code2BusNum(13) = Text13.Text
End Sub

Private Sub Text14_Change()
    Code2BusNum(14) = Text14.Text
End Sub

Private Sub Text15_Change()
    Code2BusNum(15) = Text15.Text
End Sub

Private Sub Text16_Change()
    Code2BusNum(16) = Text16.Text
End Sub

Private Sub Form_Load()
    Form1.WindowState = 2
    Form1.ScaleHeight = 11115
    Form1.ScaleWidth = 15240
    'connStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Documents and Settings\tongchai\Desktop\VB Interface\bus.mdb;"
    connStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + App.Path + "\bus.mdb;"
    Dim sqlStm As String
    ' Setup Database
    With conn
        If .State = adStateOpen Then
            .Close
        End If
        .ConnectionString = connStr
        .CursorLocation = adUseClient
        .Mode = adModeReadWrite
        .Open
    End With
    ' Clear buffer data
    For i% = 1 To 10
        DataBuffer(i) = 0
    Next
    ' Set que false
    flag = False
    ' Set up using comport
    MSComm1.CommPort = 1
    MSComm1.PortOpen = True
    MSComm1.RThreshold = 1
End Sub

