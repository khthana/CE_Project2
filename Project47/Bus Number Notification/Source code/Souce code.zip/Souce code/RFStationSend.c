#include <reg51.h>
#include <stdio.h>
sbit RF_Data_Send = P1^0;
unsigned char RF_SignBitCar = 0x80;
unsigned char RF_Send = 0x00;
unsigned char checksum = 0x00;

void delay_baud1200() {
	unsigned int x,a;
	for (x=0;x<1;x++) {
		for (a=0;a<365;a++);	//loop for delay 833 us
	}
}

void start_1200() {
	unsigned int x,a;
	for (x=0;x<1;x++) {
		for (a=0;a<183;a++);
	}
}

// For send bus code and sign bit to station
void service_send(unsigned char RF_Send) {		// Send bit data station to Bus
	unsigned char a,tmp;// Checksum;
	int i,parity = 0;
	// Send sync header
	tmp = 'U';
	for (i=0;i<8;i++) {	
		a = tmp & 0x01;
		tmp = tmp >> 1;
		if (a) {
			RF_Data_Send = 1;
		}
		else RF_Data_Send = 0;
		delay_baud1200();
	}
	// Send data
	tmp = RF_Send;
	for (i=0;i<8;i++) {	
		a = tmp & 0x01;
		tmp = tmp >> 1;
		if (a) { 
			RF_Data_Send = 1;
		}
		else RF_Data_Send = 0;
		delay_baud1200();
	}
	checksum = 'U' + RF_Send;
	checksum = ~checksum;
	// Send Checksum
	tmp = checksum;
	for (i=0;i<8;i++) {	
		a = tmp & 0x01;
		tmp = tmp >> 1;
		if (a) { 
			RF_Data_Send = 1;
		}
		else RF_Data_Send = 0;
		delay_baud1200();
	}
	// Send Stop bit	
	RF_Data_Send = 0;
	delay_baud1200();
}
void remote_init(void) {
	EX0 = 1;
	IT0 = 1;
	EA = 1;
}

char change_RF_SignBitCar(unsigned char sign) {
	if (sign == 0x80) return 0x90;
	if (sign == 0x90) return 0xA0;
	if (sign == 0xA0) return 0xB0;
	if (sign == 0xB0) return 0xC0;
	if (sign == 0xC0) return 0xD0;
	if (sign == 0xD0) return 0xE0;
	if (sign == 0xE0) return 0xF0;
	if (sign == 0xF0) return 0x80;
}

void service_timer0() interrupt 1 {
	
}

void main() {
	//----------------Enable interrupt serail port configuration 9600 bps
	SCON = 0x50;	//configuration for serial port Rx/Tx data
	TMOD = 0x21;	//Timer 1 mode 2
	TH1  = 0xFD;	//Reload value for serial baudrate(9600 bps)
	TL1  = 0xFD;
	EA   = 1;
	ES   = 1;
	TR1  = 1;
	remote_init();	// set initial RF
	while(1) {
		//---------------------Send RF data -----------------------------
		service_send(RF_SignBitCar);
		RF_SignBitCar = change_RF_SignBitCar(RF_SignBitCar);
	}
}