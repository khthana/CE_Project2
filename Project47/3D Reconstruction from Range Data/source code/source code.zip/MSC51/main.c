/*------------------------------------------------------------------------------
MAIN.C:  Interrupt Driver SIO Using printf.

Copyright 1995-2002 KEIL Software, Inc.
------------------------------------------------------------------------------*/
#include <reg51.h>
#include <stdio.h>
#include "sio.h"

/*------------------------------------------------------------------------------
_getkey waits until a character is received from the serial port.  This may not
be the exact desired operation (for example if the buffer is empty, this
function hangs waiting for a character to be received).
------------------------------------------------------------------------------*/
int counter;
unsigned char c;

step_delay()
{
	int i,j;
	for (i=0;i<1500;i++)
	{
	for (j=0;j<30;j++);
	}
}

step_right_to_left(int count)
{
	switch (count){
	case 0:
	P2 = 0x01;
	step_delay();
	break;
	case 1:
	P2 = 0x08;
	step_delay();
	break;
	case 2:
	P2 = 0x04;
	step_delay();
	break;
	case 3:
	P2 = 0x02;
	step_delay();
	break;
	}
}

step_left_to_right(int count)
{	
	switch (count){
	case 0:
	P2 = 0x08;
	step_delay();
	break;
	case 1:
	P2 = 0x01;
	step_delay();
	break;
	case 2:
	P2 = 0x02;
	step_delay();
	break;
	case 3:
	P2 = 0x04;
	step_delay();
	break;
	}	
}

light_on(){
	P1 = 0x00;
}

light_off(){
	P1 = 0xff;
}

char _getkey (void)
{
int k;

do
  {
  k = com_getchar ();
  }
while (k == -1);

return ((unsigned char) k);
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
char putchar (char c)
{
volatile unsigned int i;

while (com_putchar (c) != 0)
  {
  for (i=0; i<1000; i++)
    {
    /*** DO NOTHING ***/
    }
  }

return (c);
}

/*------------------------------------------------------------------------------
Note that the two function above, _getkey and putchar, replace the library
functions of the same name.  These functions use the interrupt-driven serial
I/O routines in SIO.C.
------------------------------------------------------------------------------*/
code char message [] =
  "This is a test to see if the interrupt driven serial I/O routines really work.";

void main (void)
{
com_initialize ();              /* initialize interrupt driven serial I/O */
com_baudrate (9600);            /* setup for 9600 baud */

EA = 1;                         /* Enable Interrupts */						// use for Rotate Motor
counter = 0;
P1 = 0xff;
while (1)
  {		
		c = getchar ();
	  	switch(c){
		case 'r':
			step_right_to_left(counter);
			counter++;
			if(counter==4){counter=0;}
		break;
		case 'l':
			step_left_to_right(counter);
			counter++;
			if(counter==4){counter=0;}
		break;
		case 'o':
			light_on();
		break;
		case 'f':
			light_off();
		break;
		}
  }
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/

