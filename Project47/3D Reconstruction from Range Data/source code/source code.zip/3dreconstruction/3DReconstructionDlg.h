// 3DReconstructionDlg.h : header file
//
//{{AFX_INCLUDES()
#include "videoocx.h"
#include "RF.h"
#include "videoocxtools.h"
//}}AFX_INCLUDES

#if !defined(AFX_3DRECONSTRUCTIONDLG_H__5692E8A4_534A_4A9C_B72A_35A20D523FE4__INCLUDED_)
#define AFX_3DRECONSTRUCTIONDLG_H__5692E8A4_534A_4A9C_B72A_35A20D523FE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMy3DReconstructionDlg dialog

class CMy3DReconstructionDlg : public CDialog
{
// Construction
public:
	CMy3DReconstructionDlg(CWnd* pParent = NULL);	// standard constructor
	CRF Serial;
// Dialog Data
	//{{AFX_DATA(CMy3DReconstructionDlg)
	enum { IDD = IDD_MY3DRECONSTRUCTION_DIALOG };
	CButton	m_UpdateStr;
	CButton	m_Format;
	CButton	m_Info;
	CButton	m_Preview;
	CButton	m_Start;
	CButton	m_Stop_Scan;
	CButton	m_Scan_Test;
	CButton	m_Rotate_L;
	CButton	m_Rotate_R;
	CButton	m_Threshold;
	CButton	m_Light;
	CButton	m_Capture;
	CButton	m_Driver;
	CButton	m_Close;
	CVideoOCX	m_Video;
	CVideoOCXTools	m_VideoOCXTool;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy3DReconstructionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

public:

	// Image handles to demonstrate VideoOCXTools - features
	long m_Image;
	long m_ResultImage;
	long m_HelperImage;
	long m_GrayImage;
	long Height,Width;
		
	// flag to determine if thread is running
	BOOL m_Running;
	BOOL next;
	BOOL light;
	int Default_Frame;
//	int frame;
	// indicates currently active radio button 
	//		(which again indicates active VideoOCXTools function)
	int	m_ToolNumber;

	// Threshold value (is used in Thread)
//	short m_Threshold;
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy3DReconstructionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnSelectDriver();
	afx_msg void OnCapture();
	afx_msg void OnLight();
	afx_msg void OnThreshold();
	afx_msg void OnRotateR();
	afx_msg void OnRotateL();
	afx_msg void OnScanTest();
	afx_msg void OnStopScan();
	afx_msg void OnStart();
	afx_msg void OnPreview();
	afx_msg void OnInfo();
	afx_msg void OnFormat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_3DRECONSTRUCTIONDLG_H__5692E8A4_534A_4A9C_B72A_35A20D523FE4__INCLUDED_)
