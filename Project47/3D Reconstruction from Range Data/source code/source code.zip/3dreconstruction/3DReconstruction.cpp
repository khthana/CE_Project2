//-----------------------------------------------------------------------------
// File: 3DReconstruction.cpp
//
// Desc: DirectX MFC dialog application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#define DIRECTINPUT_VERSION 0x0800
#include "stdafx.h"
#include "3DReconstruction.h"


//-----------------------------------------------------------------------------
// Application globals
//-----------------------------------------------------------------------------
TCHAR*          g_strAppTitle       = _T( "3DReconstruction" );
CApp            g_App;
HINSTANCE       g_hInst = NULL;
CAppForm*       g_AppFormView = NULL;

//****
	Object*			m_Object;		//		Class Of Object
	BOOL			m_HaveObject;	//		Variable that tell "Have Object Or Not"
//****


//-----------------------------------------------------------------------------
// The MFC macros are all listed here
//-----------------------------------------------------------------------------
IMPLEMENT_DYNCREATE( CAppDoc,      CDocument )
IMPLEMENT_DYNCREATE( CAppFrameWnd, CFrameWnd )
IMPLEMENT_DYNCREATE( CAppForm,     CFormView )



BEGIN_MESSAGE_MAP( CApp, CWinApp )
    //{{AFX_MSG_MAP(CApp)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()




BEGIN_MESSAGE_MAP( CAppForm, CFormView )
    //{{AFX_MSG_MAP(CAppForm)
    ON_COMMAND(    IDC_VIEWFULLSCREEN, OnToggleFullScreen )
    ON_BN_CLICKED(IDC_CHANGEDEVICE, OnChangeDevice)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_CAPTURE, OnCapture)
	ON_BN_CLICKED(IDC_CLOSE, OnCameraClose)
	ON_BN_CLICKED(IDC_FORMAT, OnFormat)
	ON_BN_CLICKED(IDC_FRAME1X, OnFrame1x)
	ON_BN_CLICKED(IDC_FRAME2X, OnFrame2x)
	ON_BN_CLICKED(IDC_FRAME4X, OnFrame4x)
	ON_BN_CLICKED(IDC_FRAME8X, OnFrame8x)
	ON_BN_CLICKED(IDC_INFO, OnInfo)
	ON_BN_CLICKED(IDC_LIGHT, OnLight)
	ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
	ON_BN_CLICKED(IDC_ROTATE_L, OnRotateL)
	ON_BN_CLICKED(IDC_ROTATE_R, OnRotateR)
	ON_BN_CLICKED(IDC_SCAN, OnScan)
	ON_BN_CLICKED(IDC_STOP_SCAN, OnStopScan)
	ON_BN_CLICKED(IDC_CHANGE, OnChange)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_ENHANCE, OnEnhance)
	ON_BN_CLICKED(IDC_POINT, OnPoint)
	ON_BN_CLICKED(IDC_WIRE, OnWire)
	ON_BN_CLICKED(IDC_Solid, OnSolid)
	ON_BN_CLICKED(IDC_DEBUG, OnDebug)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




BEGIN_MESSAGE_MAP(CAppDoc, CDocument)
    //{{AFX_MSG_MAP(CAppDoc)
            // NOTE - the ClassWizard will add and remove mapping macros here.
            //    DO NOT EDIT what you see in these blocks of generated code!
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()




BEGIN_MESSAGE_MAP(CAppFrameWnd, CFrameWnd)
    //{{AFX_MSG_MAP(CAppFrameWnd)
    ON_COMMAND(IDM_CHANGEDEVICE, OnChangeDevice)
    ON_COMMAND(IDM_CONFIGINPUT, OnConfigInput)
	ON_COMMAND(IDM_LOAD, On_IDM_Load)
	ON_COMMAND(IDM_NEW, On_IDM_New)
	ON_COMMAND(IDM_SAVE, On_IDM_Save)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




//-----------------------------------------------------------------------------
// Name: CAppForm()
// Desc: Constructor for the dialog resource form.  Paired with ~CAppForm()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//-----------------------------------------------------------------------------
CAppForm::CAppForm()
         :CFormView( IDD_FORMVIEW )
{
    //{{AFX_DATA_INIT(CAppForm)
	m_Intensity = 80;
	m_Removal = 5;
	m_Distance = 15;
	m_Angle = 72.52;
	Width = 0;
	Height = 0;
	m_Enhance = TRUE;
	Paint = 1;
	m_DebugMode = TRUE;
	//}}AFX_DATA_INIT

    g_AppFormView          = this;
    m_hwndRenderWindow     = NULL;
    m_hwndRenderFullScreen = NULL;
    m_hWndTopLevelParent   = NULL;

    // Override some CD3DApplication defaults:
    m_dwCreationWidth           = 500;
    m_dwCreationHeight          = 375;
    m_strWindowTitle            = TEXT( "3D Reconstruction from Range Data" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
    m_bStartFullscreen          = false;
    m_bShowCursorWhenFullscreen = false;

    // Create a D3D font using d3dfont.cpp
    m_pFont                     = new CD3DFont( _T("Arial"), 8, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;
    m_pD3DXMesh                 = NULL;
    m_pInputDeviceManager       = NULL;
    m_pDIConfigSurface          = NULL;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
    m_fWorldRotX                = 0.0f;
    m_fWorldRotY                = 0.0f;
	m_fZoom						= -30.0f;
	m_fSlideX					= 0.0f;
	m_fSlideY					= 0.0f;

	
	

	//UpdateData(FALSE);

    // Read settings from registry
    ReadSettings();
}




//-----------------------------------------------------------------------------
// Name: CAppForm::OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//-----------------------------------------------------------------------------
HRESULT CAppForm::OneTimeSceneInit()
{
    // TODO: perform one time initialization

    // Initialize DirectInput
    InitInput( m_hWndTopLevelParent );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ReadSettings()
// Desc: Read the app settings from the registry
//-----------------------------------------------------------------------------
VOID CAppForm::ReadSettings()
{
    HKEY hkey;
    if( ERROR_SUCCESS == RegCreateKeyEx( HKEY_CURRENT_USER, DXAPP_KEY, 
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkey, NULL ) )
    {
        // TODO: change as needed

        // Read the stored window width/height.  This is just an example,
        // of how to use DXUtil_Read*() functions.
        DXUtil_ReadIntRegKey( hkey, TEXT("Width"), &m_dwCreationWidth, m_dwCreationWidth );
        DXUtil_ReadIntRegKey( hkey, TEXT("Height"), &m_dwCreationHeight, m_dwCreationHeight );

        RegCloseKey( hkey );
    }
}




//-----------------------------------------------------------------------------
// Name: WriteSettings()
// Desc: Write the app settings to the registry
//-----------------------------------------------------------------------------
VOID CAppForm::WriteSettings()
{
    HKEY hkey;

    if( ERROR_SUCCESS == RegCreateKeyEx( HKEY_CURRENT_USER, DXAPP_KEY, 
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkey, NULL ) )
    {
        // TODO: change as needed

        // Write the window width/height.  This is just an example,
        // of how to use DXUtil_Write*() functions.
        DXUtil_WriteIntRegKey( hkey, TEXT("Width"), m_rcWindowClient.right );
        DXUtil_WriteIntRegKey( hkey, TEXT("Height"), m_rcWindowClient.bottom );

        RegCloseKey( hkey );
    }
}





//-----------------------------------------------------------------------------
// Name: StaticInputAddDeviceCB()
// Desc: Static callback helper to call into CAppForm class
//-----------------------------------------------------------------------------
HRESULT CALLBACK CAppForm::StaticInputAddDeviceCB( 
                                         CInputDeviceManager::DeviceInfo* pDeviceInfo, 
                                         const DIDEVICEINSTANCE* pdidi, 
                                         LPVOID pParam )
{
    CAppForm* pApp = (CAppForm*) pParam;
    return pApp->InputAddDeviceCB( pDeviceInfo, pdidi );
}




//-----------------------------------------------------------------------------
// Name: InputAddDeviceCB()
// Desc: Called from CInputDeviceManager whenever a device is added. 
//       Set the dead zone, and creates a new InputDeviceState for each device
//-----------------------------------------------------------------------------
HRESULT CAppForm::InputAddDeviceCB( CInputDeviceManager::DeviceInfo* pDeviceInfo, 
                                                   const DIDEVICEINSTANCE* pdidi )
{
    UNREFERENCED_PARAMETER( pdidi );
    
    // Setup the deadzone 
    DIPROPDWORD dipdw;
    dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
    dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    dipdw.diph.dwObj        = 0;
    dipdw.diph.dwHow        = DIPH_DEVICE;
    dipdw.dwData            = 500;
    pDeviceInfo->pdidDevice->SetProperty( DIPROP_DEADZONE, &dipdw.diph );

    // Create a new InputDeviceState for each device so the 
    // app can record its state 
    InputDeviceState* pNewInputDeviceState = new InputDeviceState;
    ZeroMemory( pNewInputDeviceState, sizeof(InputDeviceState) );
    pDeviceInfo->pParam = (LPVOID) pNewInputDeviceState;

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitInput()
// Desc: Initialize DirectInput objects
//-----------------------------------------------------------------------------
HRESULT CAppForm::InitInput( HWND hWnd )
{
    HRESULT hr;

    // Setup action format for the actual gameplay
    ZeroMemory( &m_diafGame, sizeof(DIACTIONFORMAT) );
    m_diafGame.dwSize          = sizeof(DIACTIONFORMAT);
    m_diafGame.dwActionSize    = sizeof(DIACTION);
    m_diafGame.dwDataSize      = NUMBER_OF_GAMEACTIONS * sizeof(DWORD);
    m_diafGame.guidActionMap   = g_guidApp;

    // TODO: change the genre as needed
    m_diafGame.dwGenre         = DIVIRTUAL_CAD_3DCONTROL; 

    m_diafGame.dwNumActions    = NUMBER_OF_GAMEACTIONS;
    m_diafGame.rgoAction       = g_rgGameAction;
    m_diafGame.lAxisMin        = -100;
    m_diafGame.lAxisMax        = 100;
    m_diafGame.dwBufferSize    = 16;
    _tcscpy( m_diafGame.tszActionMap, _T("3DReconstruction Game") );

    // Create a new input device manager
    m_pInputDeviceManager = new CInputDeviceManager();

    if( FAILED( hr = m_pInputDeviceManager->Create( hWnd, NULL, m_diafGame, 
                                                    StaticInputAddDeviceCB, this ) ) )
        return DXTRACE_ERR( "m_pInputDeviceManager->Create", hr );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the display device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CAppForm::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( pCaps );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( Format );
    BOOL bCapsAcceptable;

    // TODO: Perform checks to see if these display caps are acceptable.
    bCapsAcceptable = TRUE;

    if( bCapsAcceptable )         
        return S_OK;
    else
        return E_FAIL;
}




//-----------------------------------------------------------------------------
// Name: CAppForm::InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateOffScreenPlainSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//-----------------------------------------------------------------------------
HRESULT CAppForm::InitDeviceObjects()
{
    // TODO: create device objects
    HRESULT hr;

    // Init the font
    hr = m_pFont->InitDeviceObjects( m_pd3dDevice );
    if( FAILED( hr ) )
        return DXTRACE_ERR( "m_pFont->InitDeviceObjects", hr );
   
//**** 
	m_Object = new Object(m_pd3dDevice);		//Setup Device 
	//m_HaveObject = FALSE ;						//No Object
//****

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: CAppForm::RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//-----------------------------------------------------------------------------
HRESULT CAppForm::RestoreDeviceObjects()
{
    // TODO: setup render states
    HRESULT hr;

    // Setup a material
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

    // Set up the textures
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

    // Set miscellaneous render states
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,		D3DCULL_NONE);
    // Set the world matrix
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

    // Set up our view matrix. A view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. Here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
    D3DXMATRIX matView;
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -30.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &matView, &vFromPt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

    // Set the projection matrix
    D3DXMATRIX matProj;
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

    // Set up lighting states
    D3DLIGHT9 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
    m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // Restore the font
    m_pFont->RestoreDeviceObjects();

    if( !m_bWindowed )
    {
        // Create a surface for configuring DInput devices
        if( FAILED( hr = m_pd3dDevice->CreateOffscreenPlainSurface( 640, 480, 
                                        m_d3dsdBackBuffer.Format, D3DPOOL_DEFAULT, 
                                        &m_pDIConfigSurface, NULL ) ) ) 
            return DXTRACE_ERR( "CreateOffscreenPlainSurface", hr );
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: StaticConfigureInputDevicesCB()
// Desc: Static callback helper to call into CAppForm class
//-----------------------------------------------------------------------------
BOOL CALLBACK CAppForm::StaticConfigureInputDevicesCB( 
                                            IUnknown* pUnknown, VOID* pUserData )
{
    CAppForm* pApp = (CAppForm*) pUserData;
    return pApp->ConfigureInputDevicesCB( pUnknown );
}




//-----------------------------------------------------------------------------
// Name: ConfigureInputDevicesCB()
// Desc: Callback function for configuring input devices. This function is
//       called in fullscreen modes, so that the input device configuration
//       window can update the screen.
//-----------------------------------------------------------------------------
BOOL CAppForm::ConfigureInputDevicesCB( IUnknown* pUnknown )
{
    // Get access to the surface
    LPDIRECT3DSURFACE9 pConfigSurface = NULL;
    if( FAILED( pUnknown->QueryInterface( IID_IDirect3DSurface9,
                                          (VOID**)&pConfigSurface ) ) )
        return TRUE;

    // Render the scene, with the config surface blitted on top
    Render();

    RECT  rcSrc;
    SetRect( &rcSrc, 0, 0, 640, 480 );

    POINT ptDst;
    ptDst.x = (m_d3dsdBackBuffer.Width-640)/2;
    ptDst.y = (m_d3dsdBackBuffer.Height-480)/2;

    LPDIRECT3DSURFACE9 pBackBuffer;
    m_pd3dDevice->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer );
    m_pd3dDevice->UpdateSurface( pConfigSurface, &rcSrc, pBackBuffer, &ptDst );
    pBackBuffer->Release();

    // Present the backbuffer contents to the front buffer
    m_pd3dDevice->Present( 0, 0, 0, 0 );

    // Release the surface
    pConfigSurface->Release();

    return TRUE;
}




//-----------------------------------------------------------------------------
// Name: CAppForm::FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CAppForm::FrameMove()
{
    // TODO: update world

    // Update user input state
    UpdateInput( &m_UserInput );

    // Respond to input
    if( m_UserInput.bDoConfigureInput && m_bWindowed )  // full-screen configure disabled for now
    {
        // One-shot per keypress
        m_UserInput.bDoConfigureInput = FALSE;

        Pause( true );

        // Get access to the list of semantically-mapped input devices
        // to delete all InputDeviceState structs before calling ConfigureDevices()
        CInputDeviceManager::DeviceInfo* pDeviceInfos;
        DWORD dwNumDevices;
        m_pInputDeviceManager->GetDevices( &pDeviceInfos, &dwNumDevices );

        for( DWORD i=0; i<dwNumDevices; i++ )
        {
            InputDeviceState* pInputDeviceState = (InputDeviceState*) pDeviceInfos[i].pParam;
            SAFE_DELETE( pInputDeviceState );
            pDeviceInfos[i].pParam = NULL;
        }

        // Configure the devices (with edit capability)
        if( m_bWindowed )
            m_pInputDeviceManager->ConfigureDevices( m_hWndTopLevelParent, NULL, NULL, DICD_EDIT, NULL );
        else
            m_pInputDeviceManager->ConfigureDevices( m_hwndRenderFullScreen,
                                                     m_pDIConfigSurface,
                                                     (VOID*)StaticConfigureInputDevicesCB,
                                                     DICD_EDIT, (LPVOID) this );

        Pause( false );
    }

    if( m_UserInput.bDoConfigureDisplay )
    {
        // One-shot per keypress
        m_UserInput.bDoConfigureDisplay = FALSE;

        OnChangeDevice();
    }

    // Update the world state according to user input
    D3DXMATRIX matWorld;
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.fAxisRotateLR )
        m_fWorldRotY += m_fElapsedTime * m_UserInput.fAxisRotateLR;

    if( m_UserInput.fAxisRotateUD )
        m_fWorldRotX += m_fElapsedTime * m_UserInput.fAxisRotateUD;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &matWorld, &matRotX, &matRotY );
    m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

	if( m_UserInput.fAxisZoom )
		m_fZoom += m_fElapsedTime * m_UserInput.fAxisZoom;
	
	if( m_UserInput.fAxisSlideUD )
		m_fSlideX += m_fElapsedTime * m_UserInput.fAxisSlideUD;
	
	if( m_UserInput.fAxisSlideLR )
		m_fSlideY += m_fElapsedTime * m_UserInput.fAxisSlideLR;


	
	D3DXMATRIX matView;
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( m_fSlideY, m_fSlideX, m_fZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( m_fSlideY, m_fSlideX, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &matView, &vFromPt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//-----------------------------------------------------------------------------
void CAppForm::UpdateInput( UserInput* pUserInput )
{
    if( NULL == m_pInputDeviceManager )
        return;

    // Get access to the list of semantically-mapped input devices
    CInputDeviceManager::DeviceInfo* pDeviceInfos;
    DWORD dwNumDevices;
    m_pInputDeviceManager->GetDevices( &pDeviceInfos, &dwNumDevices );

    // Loop through all devices and check game input
    for( DWORD i=0; i<dwNumDevices; i++ )
    {
        DIDEVICEOBJECTDATA rgdod[10];
        DWORD   dwItems = 10;
        HRESULT hr;
        LPDIRECTINPUTDEVICE8 pdidDevice = pDeviceInfos[i].pdidDevice;
        InputDeviceState* pInputDeviceState = (InputDeviceState*) pDeviceInfos[i].pParam;

        hr = pdidDevice->Acquire();
        hr = pdidDevice->Poll();
        hr = pdidDevice->GetDeviceData( sizeof(DIDEVICEOBJECTDATA),
                                        rgdod, &dwItems, 0 );
        if( FAILED(hr) )
            continue;

        // Get the sematics codes for the game menu
        for( DWORD j=0; j<dwItems; j++ )
        {
            BOOL  bButtonState = (rgdod[j].dwData==0x80) ? TRUE : FALSE;
            FLOAT fButtonState = (rgdod[j].dwData==0x80) ? 1.0f : 0.0f;
            FLOAT fAxisState   = (FLOAT)((int)rgdod[j].dwData)/100.0f;
            UNREFERENCED_PARAMETER( fButtonState );

            switch( rgdod[j].uAppData )
            {
                // TODO: Handle semantics for the game 

                // Handle relative axis data
                case INPUT_ROTATE_AXIS_LR: 
                    pInputDeviceState->fAxisRotateLR = -fAxisState;
                    break;
                case INPUT_ROTATE_AXIS_UD:
                    pInputDeviceState->fAxisRotateUD = -fAxisState;
                    break;

                // Handle buttons separately so the button state data
                // doesn't overwrite the axis state data, and handle
                // each button separately so they don't overwrite each other
                case INPUT_ROTATE_LEFT:  pInputDeviceState->bButtonRotateLeft  = bButtonState; break;
                case INPUT_ROTATE_RIGHT: pInputDeviceState->bButtonRotateRight = bButtonState; break;
                case INPUT_ROTATE_UP:    pInputDeviceState->bButtonRotateUp    = bButtonState; break;
                case INPUT_ROTATE_DOWN:  pInputDeviceState->bButtonRotateDown  = bButtonState; break;
				case INPUT_ZOOM_IN:		 pInputDeviceState->bButtonZoomIn	   = bButtonState; break;
				case INPUT_ZOOM_OUT:	 pInputDeviceState->bButtonZoomOut	   = bButtonState; break;
				case INPUT_SLIDE_UP:	 pInputDeviceState->bButtonSlideUp	   = bButtonState; break;
				case INPUT_SLIDE_DOWN:	 pInputDeviceState->bButtonSlideDown   = bButtonState; break;
				case INPUT_SLIDE_LEFT:	 pInputDeviceState->bButtonSlideLeft   = bButtonState; break;
				case INPUT_SLIDE_RIGHT:	 pInputDeviceState->bButtonSlideRight  = bButtonState; break;


                // Handle one-shot buttons
                case INPUT_CONFIG_INPUT:   if( bButtonState ) pUserInput->bDoConfigureInput = TRUE; break;
                case INPUT_CONFIG_DISPLAY: if( bButtonState ) pUserInput->bDoConfigureDisplay = TRUE; break;
            }
        }
    }

    // TODO: change process code as needed

    // Process user input and store result into pUserInput struct
    pUserInput->fAxisRotateLR = 0.0f;
    pUserInput->fAxisRotateUD = 0.0f;
	pUserInput->fAxisZoom	  = 0.0f;
	pUserInput->fAxisZoom	  = 0.0f;
	pUserInput->fAxisSlideUD  = 0.0f;
	pUserInput->fAxisSlideLR  = 0.0f;	

    // Concatinate the data from all the DirectInput devices
    for( i=0; i<dwNumDevices; i++ )
    {
        InputDeviceState* pInputDeviceState = (InputDeviceState*) pDeviceInfos[i].pParam;

        // Use the axis data that is furthest from zero
        if( fabs(pInputDeviceState->fAxisRotateLR) > fabs(pUserInput->fAxisRotateLR) )
            pUserInput->fAxisRotateLR = pInputDeviceState->fAxisRotateLR;

        if( fabs(pInputDeviceState->fAxisRotateUD) > fabs(pUserInput->fAxisRotateUD) )
            pUserInput->fAxisRotateUD = pInputDeviceState->fAxisRotateUD;
		
		if( fabs(pInputDeviceState->fAxisSlideUD) > fabs(pUserInput->fAxisSlideUD) )
            pUserInput->fAxisSlideUD = pInputDeviceState->fAxisSlideUD;

        if( fabs(pInputDeviceState->fAxisSlideLR) > fabs(pUserInput->fAxisSlideLR) )
            pUserInput->fAxisSlideLR = pInputDeviceState->fAxisSlideLR;


        // Process the button data 
        if( pInputDeviceState->bButtonRotateLeft )
            pUserInput->fAxisRotateLR = 1.0f;
        else if( pInputDeviceState->bButtonRotateRight )
            pUserInput->fAxisRotateLR = -1.0f;

        if( pInputDeviceState->bButtonRotateUp )
            pUserInput->fAxisRotateUD = 1.0f;
        else if( pInputDeviceState->bButtonRotateDown )
            pUserInput->fAxisRotateUD = -1.0f;

		if( pInputDeviceState->bButtonZoomIn)
			pUserInput->fAxisZoom = 5.0f;
		else if ( pInputDeviceState->bButtonZoomOut )
			pUserInput->fAxisZoom = -5.0f;
		
		if( pInputDeviceState->bButtonSlideLeft )
            pUserInput->fAxisSlideLR = 5.0f;
        else if( pInputDeviceState->bButtonSlideRight )
            pUserInput->fAxisSlideLR = -5.0f;

        if( pInputDeviceState->bButtonSlideUp )
            pUserInput->fAxisSlideUD = -5.0f;
        else if( pInputDeviceState->bButtonSlideDown )
            pUserInput->fAxisSlideUD = 5.0f;


    } 
}




//-----------------------------------------------------------------------------
// Name: CAppForm::Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CAppForm::Render()
{
    // Clear the viewport
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         0x000000ff, 1.0f, 0L );

    // Begin the scene
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
        // TODO: render world
       
	
//****
		
		if(m_Object->HaveObject())m_Object->DrawObject();
//****


        // Render stats and help text  
       // RenderText();

        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: Renders stats and help text to the scene.
//-----------------------------------------------------------------------------
HRESULT CAppForm::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    // Output display stats
    FLOAT fNextLine = 40.0f; 

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    // Output statistics & help
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 

    sprintf( szMsg, TEXT("Left/Right Axis: %0.2f Up/Down Axis: %0.2f "), 
              m_UserInput.fAxisRotateLR, m_UserInput.fAxisRotateUD );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Use arrow keys or joystick to rotate object") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press 'F3' to configure input") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Pause()
// Desc: Called in to toggle the pause state of the app.
//-----------------------------------------------------------------------------
VOID CAppForm::Pause( bool bPause )
{
    // Get access to the list of semantically-mapped input devices
    // to zero the state of all InputDeviceState structs.  This is needed
    // because when using DISCL_FOREGROUND, the action mapper will not 
    // record actions when the focus switches, for example if a dialog appears.
    // This causes a problem when a button held down when loosing focus, and let
    // go when the focus is lost.  The app will not record that the button 
    // has been let go, so the state will be incorrect when focus returns.  
    // To fix this either use DISCL_BACKGROUND or zero the state when 
    // loosing focus.
    CInputDeviceManager::DeviceInfo* pDeviceInfos;
    DWORD dwNumDevices;
    m_pInputDeviceManager->GetDevices( &pDeviceInfos, &dwNumDevices );

    for( DWORD i=0; i<dwNumDevices; i++ )
    {
        InputDeviceState* pInputDeviceState = (InputDeviceState*) pDeviceInfos[i].pParam;
        ZeroMemory( pInputDeviceState, sizeof(InputDeviceState) );
    }

    CD3DApplication::Pause( bPause );
}




//-----------------------------------------------------------------------------
// Name: DoDataExchange()
// Desc: DDX/DDV support
//-----------------------------------------------------------------------------
void CAppForm::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAppForm)
	DDX_Control(pDX, IDC_DEBUG, m_LockQuick);
	DDX_Control(pDX, IDC_ENHANCE, m_LockEnhance);
	DDX_Control(pDX, IDC_CHANGE, m_Change);
	DDX_Control(pDX, IDC_STOP_SCAN, m_StopScan);
	DDX_Control(pDX, IDC_SCAN, m_Scan);
	DDX_Control(pDX, IDC_ROTATE_R, m_RotateR);
	DDX_Control(pDX, IDC_ROTATE_L, m_RotateL);
	DDX_Control(pDX, IDC_PREVIEW, m_Preview);
	DDX_Control(pDX, IDC_LIGHT, m_Light);
	DDX_Control(pDX, IDC_INFO, m_Info);
	DDX_Control(pDX, IDC_FORMAT, m_Format);
	DDX_Control(pDX, IDC_CLOSE, m_Close);
	DDX_Control(pDX, IDC_CAPTURE, m_Capture);
	DDX_Control(pDX, IDC_START, m_Start);
	DDX_Control(pDX, IDC_FRAME1X, m_Frame1x);
	DDX_Control(pDX, IDC_FRAME2X, m_Frame2x);
	DDX_Control(pDX, IDC_FRAME4X, m_Frame4x);
	DDX_Control(pDX, IDC_FRAME8X, m_Frame8x);
	DDX_Control(pDX, IDC_REMOVAL, m_LockRemoval);
	DDX_Control(pDX, IDC_INTENSITY, m_LockIntensity);
	DDX_Control(pDX, IDC_DISTANCE, m_LockDistance);
	DDX_Control(pDX, IDC_VIDEOOCXCTRL1, m_Video);
	DDX_Control(pDX, IDC_VIDEOOCXTOOLSCTRL1, m_VideoOCXTool);
	DDX_Text(pDX, IDC_INTENSITY, m_Intensity);
	DDV_MinMaxInt(pDX, m_Intensity, 0, 255);
	DDX_Text(pDX, IDC_REMOVAL, m_Removal);
	DDV_MinMaxInt(pDX, m_Removal, 0, 255);
	DDX_Text(pDX, IDC_DISTANCE, m_Distance);
	DDV_MinMaxInt(pDX, m_Distance, 5, 20);
	DDX_Text(pDX, IDC_WIDE, Width);
	DDX_Text(pDX, IDC_HIGH, Height);
	DDX_Check(pDX, IDC_ENHANCE, m_Enhance);
	DDX_Check(pDX, IDC_DEBUG, m_DebugMode);
	//}}AFX_DATA_MAP
}




//-----------------------------------------------------------------------------
// Name: WindowProc()
// Desc: 
//-----------------------------------------------------------------------------
LRESULT CAppForm::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
    switch( message )
    {
        case WM_COMMAND:
        {
            switch( LOWORD(wParam) )
            {
                case IDM_CONFIGINPUT:
                    m_UserInput.bDoConfigureInput = TRUE;
                    break;

                case IDC_CHANGEDEVICE:
                case IDM_CHANGEDEVICE:
                    m_UserInput.bDoConfigureDisplay = TRUE;
                    return 0; // Don't hand off to parent
            }
            break;
        }
    }
    
    return CFormView ::WindowProc(message, wParam, lParam);
}




//-----------------------------------------------------------------------------
// Name: OnChangeDevice()
// Desc: Needed to enable dlg menu item 
//-----------------------------------------------------------------------------
void CAppFrameWnd::OnChangeDevice() 
{
    g_AppFormView->m_UserInput.bDoConfigureDisplay = TRUE;
}




//-----------------------------------------------------------------------------
// Name: OnConfigInput()
// Desc: 
//-----------------------------------------------------------------------------
void CAppFrameWnd::OnConfigInput() 
{
    g_AppFormView->m_UserInput.bDoConfigureInput = TRUE;
}




//-----------------------------------------------------------------------------
// Name: CAppForm::InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//-----------------------------------------------------------------------------
HRESULT CAppForm::InvalidateDeviceObjects()
{
    // TODO: Cleanup any objects created in RestoreDeviceObjects()
    m_pFont->InvalidateDeviceObjects();
    SAFE_RELEASE( m_pDIConfigSurface );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: CAppForm::DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//-----------------------------------------------------------------------------
HRESULT CAppForm::DeleteDeviceObjects()
{
    // TODO: Cleanup any objects created in InitDeviceObjects()
   
	m_pFont->DeleteDeviceObjects();
    
	//SAFE_RELEASE( m_pD3DXMesh );

//****

	if(m_Object->HaveObject())m_Object->CleanObject();
//****

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: CAppForm::FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CAppForm::FinalCleanup()
{
    // TODO: Perform any final cleanup needed
    // Cleanup D3D font
    SAFE_DELETE( m_pFont );

    // Cleanup DirectInput
    CleanupDirectInput();

    // Write the settings to the registry
    WriteSettings();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: CleanupDirectInput()
// Desc: Cleanup DirectInput 
//-----------------------------------------------------------------------------
VOID CAppForm::CleanupDirectInput()
{
    if( NULL == m_pInputDeviceManager )
        return;

    // Get access to the list of semantically-mapped input devices
    // to delete all InputDeviceState structs
    CInputDeviceManager::DeviceInfo* pDeviceInfos;
    DWORD dwNumDevices;
    m_pInputDeviceManager->GetDevices( &pDeviceInfos, &dwNumDevices );

    for( DWORD i=0; i<dwNumDevices; i++ )
    {
        InputDeviceState* pInputDeviceState = (InputDeviceState*) pDeviceInfos[i].pParam;
        SAFE_DELETE( pInputDeviceState );
        pDeviceInfos[i].pParam = NULL;
    }

    // Cleanup DirectX input objects
    SAFE_DELETE( m_pInputDeviceManager );

}




//-----------------------------------------------------------------------------
// Name: InitInstance()
// Desc: This is the main entry point for the application. The MFC window stuff
//       is initialized here. See also the main initialization routine for the
//       CAppForm class, which is called indirectly from here.
//-----------------------------------------------------------------------------
BOOL CApp::InitInstance()
{
    // Asscociate the MFC app with the frame window and doc/view classes
    AddDocTemplate( new CSingleDocTemplate( IDR_MAINFRAME,
                                            RUNTIME_CLASS(CAppDoc),
                                            RUNTIME_CLASS(CAppFrameWnd),
                                            RUNTIME_CLASS(CAppForm) ) );

	AfxEnableControlContainer();

    // Dispatch commands specified on the command line (req'd by MFC). This
    // also initializes the the CAppDoc, CAppFrameWnd, and CAppForm classes.
    CCommandLineInfo cmdInfo;
    ParseCommandLine( cmdInfo );
    if( !ProcessShellCommand( cmdInfo ) )
        return FALSE;

    if( !g_AppFormView->IsReady() )
        return FALSE;

    g_AppFormView->GetParentFrame()->RecalcLayout();
    g_AppFormView->ResizeParentToFit( FALSE ); 
    
    m_pMainWnd->SetWindowText( g_strAppTitle );
    m_pMainWnd->UpdateWindow();

    return TRUE;
}




//-----------------------------------------------------------------------------
// Name: LoadFrame()
// Desc: Uses idle time to render the 3D scene.
//-----------------------------------------------------------------------------
BOOL CAppFrameWnd::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
    BOOL bResult = CFrameWnd::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext);
    
    LoadAccelTable( MAKEINTRESOURCE(IDR_MAIN_ACCEL) );

    return bResult;
}




//-----------------------------------------------------------------------------
// Name: OnIdle()
// Desc: Uses idle time to render the 3D scene.
//-----------------------------------------------------------------------------
BOOL CApp::OnIdle( LONG )
{
    // Do not render if the app is minimized
    if( m_pMainWnd->IsIconic() )
        return FALSE;

    TCHAR strStatsPrev[200];

    lstrcpy(strStatsPrev, g_AppFormView->PstrFrameStats());

    // Update and render a frame
    if( g_AppFormView->IsReady() )
    {
        g_AppFormView->CheckForLostFullscreen();
        g_AppFormView->RenderScene();
    }

    // Keep requesting more idle time
    return TRUE;
}




//-----------------------------------------------------------------------------
// Name: PreCreateWindow()
// Desc: Change the window style (so it cannot maximize or be sized) before
//       the main frame window is created.
//-----------------------------------------------------------------------------
BOOL CAppFrameWnd::PreCreateWindow( CREATESTRUCT& cs )
{
    cs.style = WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;

    return CFrameWnd::PreCreateWindow( cs );
}




//-----------------------------------------------------------------------------
// Name: ~CAppForm()
// Desc: Destructor for the dialog resource form. Shuts down the app
//-----------------------------------------------------------------------------
CAppForm::~CAppForm()
{
    Cleanup3DEnvironment();
    SAFE_RELEASE( m_pD3D );
    FinalCleanup();
}




//-----------------------------------------------------------------------------
// Name: OnToggleFullScreen()
// Desc: Called when user toggles the fullscreen mode
//-----------------------------------------------------------------------------
void CAppForm::OnToggleFullScreen()
{
    ToggleFullscreen();
	switch (Paint)
	{
	case 1: m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,		D3DFILL_SOLID); break;
	case 2: m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,		D3DFILL_WIREFRAME); break;
	case 3: m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,		D3DFILL_POINT); break;
	default :break;
	}
}




//-----------------------------------------------------------------------------
// Name: OnChangeDevice()
// Desc: Use hit the "Change Device.." button. Display the dialog for the user
//       to select a new device/mode, and call Change3DEnvironment to
//       use the new device/mode.
//-----------------------------------------------------------------------------
VOID CAppForm::OnChangeDevice()
{
    Pause(true);

    UserSelectNewDevice();

    // Update UI
    UpdateUIForDeviceCapabilites();

    Pause(false);
}




//-----------------------------------------------------------------------------
// Name: AdjustWindowForChange()
// Desc: Adjusts the window properties for windowed or fullscreen mode
//-----------------------------------------------------------------------------
HRESULT CAppForm::AdjustWindowForChange()
{
    if( m_bWindowed )
    {
        ::ShowWindow( m_hwndRenderFullScreen, SW_HIDE );
        CD3DApplication::m_hWnd = m_hwndRenderWindow;

        // Tell the action mapper that the focus wnd has changed
        m_pInputDeviceManager->SetFocus( m_hWndTopLevelParent );
    }
    else
    {
        if( ::IsIconic( m_hwndRenderFullScreen ) )
            ::ShowWindow( m_hwndRenderFullScreen, SW_RESTORE );
        ::ShowWindow( m_hwndRenderFullScreen, SW_SHOW );
        CD3DApplication::m_hWnd = m_hwndRenderFullScreen;

        // Tell the action mapper that the focus wnd has changed
        m_pInputDeviceManager->SetFocus( m_hwndRenderFullScreen );
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FullScreenWndProc()
// Desc: The WndProc funtion used when the app is in fullscreen mode. This is
//       needed simply to trap the ESC key.
//-----------------------------------------------------------------------------
LRESULT CALLBACK FullScreenWndProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    if( msg == WM_CLOSE )
    {
        // User wants to exit, so go back to windowed mode and exit for real
        g_AppFormView->OnToggleFullScreen();
        g_App.GetMainWnd()->PostMessage( WM_CLOSE, 0, 0 );
    }
    else if( msg == WM_SETCURSOR )
    {
        SetCursor( NULL );
    }
    else if( msg == WM_KEYUP && wParam == VK_ESCAPE )
    {
        // User wants to leave fullscreen mode
        g_AppFormView->OnToggleFullScreen();
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: CheckForLostFullscreen()
// Desc: If fullscreen and device was lost (probably due to alt-tab), 
//       automatically switch to windowed mode
//-----------------------------------------------------------------------------
HRESULT CAppForm::CheckForLostFullscreen()
{
    HRESULT hr;

    if( m_bWindowed )
        return S_OK;

    if( FAILED( hr = m_pd3dDevice->TestCooperativeLevel() ) )
        ForceWindowed();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateUIForDeviceCapabilites()
// Desc: Whenever we get a new device, call this function to enable/disable the
//       appropiate UI controls to match the device's capabilities.
//-----------------------------------------------------------------------------
VOID CAppForm::UpdateUIForDeviceCapabilites()
{
    // TODO: Check the capabilities of the device and update the UI as needed
    DWORD dwCaps = m_d3dCaps.RasterCaps;
    UNREFERENCED_PARAMETER( dwCaps );
}




//-----------------------------------------------------------------------------
// Name: OnInitialUpdate()
// Desc: When the AppForm object is created, this function is called to
//       initialize it. Here we getting access ptrs to some of the controls,
//       and setting the initial state of some of them as well.
//-----------------------------------------------------------------------------
VOID CAppForm::OnInitialUpdate()
{
    // Update the UI
    CFormView::OnInitialUpdate();

    // Get the top level parent hwnd
    m_hWndTopLevelParent = GetTopLevelParent()->GetSafeHwnd();

    // Save static reference to the render window
    m_hwndRenderWindow = GetDlgItem(IDC_RENDERVIEW)->GetSafeHwnd();

    // Register a class for a fullscreen window
    WNDCLASS wndClass = { CS_HREDRAW | CS_VREDRAW, FullScreenWndProc, 0, 0, NULL,
                          NULL, NULL, (HBRUSH)GetStockObject(WHITE_BRUSH), NULL,
                          _T("Fullscreen Window") };
    RegisterClass( &wndClass );

    // We create the fullscreen window (not visible) at startup, so it can
    // be the focus window.  The focus window can only be set at CreateDevice
    // time, not in a Reset, so ToggleFullscreen wouldn't work unless we have
    // already set up the fullscreen focus window.
    m_hwndRenderFullScreen = CreateWindow( _T("Fullscreen Window"), NULL,
                                           WS_POPUP, CW_USEDEFAULT,
                                           CW_USEDEFAULT, 100, 100,
                                           m_hWndTopLevelParent, 0L, NULL, 0L );

    // Note that for the MFC samples, the device window and focus window
    // are not the same.
    CD3DApplication::m_hWnd = m_hwndRenderWindow;
    CD3DApplication::m_hWndFocus = m_hwndRenderFullScreen;
    CD3DApplication::Create( AfxGetInstanceHandle() );

	/////////////////////////////////////////////////////////////////
	m_Running = FALSE;
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;
	m_ToolNumber = -1;	
	m_SetFrame = TRUE;
	light = FALSE;
	Count=1;
	Default_Frame = 200;
	Frame = Default_Frame;
	 
	UpdateData(FALSE);
}

void CAppForm::OnCameraClose() 
{
	// Stop capture thread

	m_Running = FALSE;	// tell thread to end
	Sleep(250);			// wait for thread to end

	// end capture mode
	if (!m_Video.Stop())
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}

	// free memory
	m_Video.ReleaseImageHandle(m_Image);
	m_Video.ReleaseImageHandle(m_ResultImage);
	m_Video.ReleaseImageHandle(m_HelperImage);
	m_Video.ReleaseImageHandle(m_GrayImage);
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;

	//	close video connection and free memory
	Sleep(5);
	if (!m_Video.Close())
	{
		// error while closing video connection
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
	else
	{
		m_Scan.EnableWindow(FALSE);
		m_Capture.EnableWindow(FALSE);
		m_Close.EnableWindow(FALSE);
		m_Format.EnableWindow(FALSE);
		m_Info.EnableWindow(FALSE);
		m_Preview.EnableWindow(FALSE);
		m_StopScan.EnableWindow(FALSE);
		m_Frame1x.EnableWindow(FALSE);
		m_Frame2x.EnableWindow(FALSE);
		m_Frame4x.EnableWindow(FALSE);
		m_Frame8x.EnableWindow(FALSE);
		m_Change.EnableWindow(FALSE);
		m_LockIntensity.EnableWindow(FALSE);
		m_LockDistance.EnableWindow(FALSE);
		m_LockRemoval.EnableWindow(FALSE);
		m_LockEnhance.EnableWindow(FALSE);
		m_LockQuick.EnableWindow(FALSE);
		m_Start.EnableWindow(TRUE);
	}
	if(Serial.Disconnect())
	{
		m_Light.EnableWindow(FALSE);
		m_RotateL.EnableWindow(FALSE);
		m_RotateR.EnableWindow(FALSE);
	}
}

UINT CaptureThread(LPVOID pParam)
{
	// Capture Thread 
	CAppForm *dlg;		// reference to parent dialog

	// Get pointer to parent dialog
	dlg = (CAppForm *)pParam;
	
	// capture loop
	while (dlg->m_Running)
	{
		while(dlg->next){}
		// try to capture, if Capture returns FALSE, no image was available
		// at this time. 
		// which VideoOCXTools function is currently acitve?	
		//////////////////////////Define useful Variable/////////////////
		int x,y,m,n = 0;
		int CountPoint,CountBlank,CountPointAfter = 0;
		int state=0;
		float Slope = 0;
		int Range,X1,X2,Y1,Y2,dx,dy=0;
		int i,j= 0;
		int SumX=0;
		float avgX;
		/*int NewX =0;*/
		int SumPixel=0;
		int CountPixel=0;
		int Quality [7]={0,0,0,0,0,0,0};
		float xPos,yPos,zPos =0;
		BYTE * DataImage ;
		char ShowFrame [3];
		D3DXMATRIX CPos;
		D3DXMATRIX MulMat;
		
		//////////////////////////Set new text//////////////////////////
		switch(dlg->m_ToolNumber)
			{

			 ////////////////////Capture one frame/////////////
				case 0:
				dlg->m_Video.Capture(dlg->m_Image);
				dlg->m_Video.Show(dlg->m_Image);
				dlg->next=TRUE;
				break;


			//////////////////////////Scan subtraction Image////////////////
				case 1:
				if(dlg->Default_Frame != 0)
				{
					dlg->Default_Frame--;
					////////////////////Get First Frame for Subtraction//////////
					if((dlg->Default_Frame+1)*dlg->Count==200)
					{
						dlg->Serial.sendCommand('f'); //**********************
						dlg->MessageBox("Please Remove Object for Capture Background","Scan Process",MB_OK);
						
						////////////////Capture Background Process//////////////
						dlg->m_Video.SetPreview(FALSE);
						dlg->m_Video.Capture(dlg->m_Image);
						DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
						dlg->Height=dlg->m_Video.GetHeight();
						dlg->Width=dlg->m_Video.GetWidth();
						
						/////////////////Initial Variable of XYZ Process///////////
						dlg->PixelLength= 0.65/dlg->Width;
						dlg->PixelLength_h = 0.24/dlg->Height;
						///////////////////////////////////////////////////////////
						for(y = 0; y < dlg->Height; y++)
						{
							for (x = 0; x < dlg->Width; x++)
							{
								dlg->Background[x*3+dlg->Width*y*3]=DataImage[x*3+dlg->Width*y*3];
								dlg->Background[x*3+dlg->Width*y*3+1]=DataImage[x*3+dlg->Width*y*3+1];
								dlg->Background[x*3+dlg->Width*y*3+2]=DataImage[x*3+dlg->Width*y*3+2];
							}
						}
						dlg->m_Video.SetPreview(TRUE);
						dlg->MessageBox("Please Insert Object for Continue Process","Scan Process",MB_OK);
						dlg->m_Video.SetPreview(FALSE);
						
					}

				////////////////////////////////////////////////////////////
				//////////////////Send Command to motor/////////////////////
					for(x=0;x<dlg->Count;x++)
					{
						dlg->Serial.sendCommand('l'); //***********************
						Sleep(500);	
					}

				//////////////////Capture First Pic and Copy to temp(object only)/////////////////
					dlg->m_Video.Capture(dlg->m_Image);
					dlg->m_Video.Show(dlg->m_Image);		//
					DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
					dlg->Height=dlg->m_Video.GetHeight();
					dlg->Width=dlg->m_Video.GetWidth();
					
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							dlg->TempImage[x*3+dlg->Width*y*3]=DataImage[x*3+dlg->Width*y*3];
							dlg->TempImage[x*3+dlg->Width*y*3+1]=DataImage[x*3+dlg->Width*y*3+1];
							dlg->TempImage[x*3+dlg->Width*y*3+2]=DataImage[x*3+dlg->Width*y*3+2];
						}
					}
					

				/////////////////////Light on/////////////////////////////////
					dlg->Serial.sendCommand('o');    //********************
					Sleep(250);
					
				///////////////////////Capture Next Pic(object + Line)//////////////
					dlg->m_Video.Capture(dlg->m_Image);
					DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
					dlg->m_Video.Show(dlg->m_Image);		//
		
				///////////////////////Subtraction Between two Pics(Background and object)/////////////
				///////////////////////Important at Value after Subtraction//////////////////////////// 
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if((dlg->TempImage[x*3+dlg->Width*y*3]-dlg->Background[x*3+dlg->Width*y*3]>(0-dlg->m_Removal)&&dlg->TempImage[x*3+dlg->Width*y*3]-dlg->Background[x*3+dlg->Width*y*3]<(dlg->m_Removal))
								||(dlg->TempImage[x*3+dlg->Width*y*3+1]-dlg->Background[x*3+dlg->Width*y*3+1]>(0-dlg->m_Removal)&&dlg->TempImage[x*3+dlg->Width*y*3+1]-dlg->Background[x*3+dlg->Width*y*3+1]<(dlg->m_Removal))
								||(dlg->TempImage[x*3+dlg->Width*y*3+2]-dlg->Background[x*3+dlg->Width*y*3+2]>(0-dlg->m_Removal)&&dlg->TempImage[x*3+dlg->Width*y*3+2]-dlg->Background[x*3+dlg->Width*y*3+2]<(dlg->m_Removal)))
							{
								dlg->ObjectImage[x*3+dlg->Width*y*3]=0;
								dlg->ObjectImage[x*3+dlg->Width*y*3+1]=0;
								dlg->ObjectImage[x*3+dlg->Width*y*3+2]=0;
							}
							else
							{
								dlg->ObjectImage[x*3+dlg->Width*y*3]=dlg->TempImage[x*3+dlg->Width*y*3];
								dlg->ObjectImage[x*3+dlg->Width*y*3+1]=dlg->TempImage[x*3+dlg->Width*y*3+1];
								dlg->ObjectImage[x*3+dlg->Width*y*3+2]=dlg->TempImage[x*3+dlg->Width*y*3+2];
							}
						}
					}
		
				////////////////////now we get only Object no background in ObjectImage//////////
				////////////////////Subtraction Between Object + line and Object only////////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(dlg->ObjectImage[x*3+dlg->Width*y*3]!=0 && dlg->ObjectImage[x*3+dlg->Width*y*3+1]!=0 && dlg->ObjectImage[x*3+dlg->Width*y*3+2]!=0)
							{
								if(DataImage[x*3+dlg->Width*y*3]>=dlg->ObjectImage[x*3+dlg->Width*y*3])
								{
									DataImage[x*3+dlg->Width*y*3]=DataImage[x*3+dlg->Width*y*3]-dlg->ObjectImage[x*3+dlg->Width*y*3];
								}
								else
								{
									DataImage[x*3+dlg->Width*y*3]=dlg->ObjectImage[x*3+dlg->Width*y*3]-DataImage[x*3+dlg->Width*y*3];
								}
							}
							else
							{
								DataImage[x*3+dlg->Width*y*3]=0;
							}

							if(dlg->ObjectImage[x*3+dlg->Width*y*3+1]!=0)
							{
								if(DataImage[x*3+dlg->Width*y*3+1]>=dlg->ObjectImage[x*3+dlg->Width*y*3+1])
								{
									DataImage[x*3+dlg->Width*y*3+1]=DataImage[x*3+dlg->Width*y*3+1]-dlg->ObjectImage[x*3+dlg->Width*y*3+1];
								}
								else
								{
									DataImage[x*3+dlg->Width*y*3+1]=dlg->ObjectImage[x*3+dlg->Width*y*3+1]-DataImage[x*3+dlg->Width*y*3+1];
								}
							}
							else
							{
								DataImage[x*3+dlg->Width*y*3+1]=0;
							}

							if(dlg->ObjectImage[x*3+dlg->Width*y*3+2]!=0)
							{
								if(DataImage[x*3+dlg->Width*y*3+2]>=dlg->ObjectImage[x*3+dlg->Width*y*3+2])
								{
									DataImage[x*3+dlg->Width*y*3+2]=DataImage[x*3+dlg->Width*y*3+2]-dlg->ObjectImage[x*3+dlg->Width*y*3+2];
								}
								else
								{
									DataImage[x*3+dlg->Width*y*3+2]=dlg->ObjectImage[x*3+dlg->Width*y*3+2]-DataImage[x*3+dlg->Width*y*3+2];
								}
							}
							else
							{
								DataImage[x*3+dlg->Width*y*3+2]=0;
							}
						}
					}
					if(dlg->m_DebugMode == TRUE)
					{
						Sleep(250);							//
						dlg->m_Video.Show(dlg->m_Image);		//
					}

				/////////////////////Threshold for reduce noise//////////////////////
				/////////////////////Remind in Value that use in threshold///////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]>=dlg->m_Intensity){DataImage[x*3+dlg->Width*y*3]=0;}
							if(DataImage[x*3+dlg->Width*y*3]<dlg->m_Intensity){DataImage[x*3+dlg->Width*y*3]=0;}
							if(DataImage[x*3+1+dlg->Width*y*3]>=dlg->m_Intensity){DataImage[x*3+1+dlg->Width*y*3]=0;}
							if(DataImage[x*3+1+dlg->Width*y*3]<dlg->m_Intensity){DataImage[x*3+1+dlg->Width*y*3]=0;}
							if(DataImage[x*3+2+dlg->Width*y*3]>=dlg->m_Intensity){DataImage[x*3+2+dlg->Width*y*3]=255;}
							if(DataImage[x*3+2+dlg->Width*y*3]<dlg->m_Intensity){DataImage[x*3+2+dlg->Width*y*3]=0;}
						}
					}
					if(dlg->m_DebugMode == TRUE)
					{
						Sleep(100);							//
						dlg->m_Video.Show(dlg->m_Image);
					}
				/////////////////////Save Line Image for imply noise reducing///////////
					for(y = 0; y < dlg->Height; y++)
						{
							for (x = 0; x < dlg->Width; x++)
							{
								dlg->ObjectImage[x*3+dlg->Width*y*3]=DataImage[x*3+dlg->Width*y*3];
								dlg->ObjectImage[x*3+dlg->Width*y*3+1]=DataImage[x*3+dlg->Width*y*3+1];
								dlg->ObjectImage[x*3+dlg->Width*y*3+2]=DataImage[x*3+dlg->Width*y*3+2];
							}
						}
				/////////////////////////////////////////////////////////////////////////
				/////////////////////Find Center of Line Laser//////////////////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]!=0||DataImage[x*3+dlg->Width*y*3+1]!=0||DataImage[x*3+dlg->Width*y*3+2]!=0)
							{
								SumPixel=SumPixel+x;
								CountPixel++;
							}
						}
						if(CountPixel!=0)
						{
							for (x = 0; x < dlg->Width; x++)
							{
								if(x!=(SumPixel/CountPixel))
								{
									DataImage[x*3+dlg->Width*y*3]=0;
									DataImage[x*3+dlg->Width*y*3+1]=0;
									DataImage[x*3+dlg->Width*y*3+2]=0;
								}
								else
								{
									DataImage[x*3+dlg->Width*y*3]=255;
									DataImage[x*3+dlg->Width*y*3+1]=255;
									DataImage[x*3+dlg->Width*y*3+2]=255;
								}
							}
						}
						SumPixel=0;
						CountPixel=0;
					}

				//////////////////Should have Function for make Quality of line better//////////
					//**********************************************
					/////////////////Remove noise////////////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]==255&&DataImage[x*3+dlg->Width*y*3+1]==255&&DataImage[x*3+dlg->Width*y*3+2]==255)
							{
								if(dlg->ObjectImage[x*3+dlg->Width*y*3+2]==0 && dlg->ObjectImage[x*3+dlg->Width*y*3+1]==0 && dlg->ObjectImage[x*3+dlg->Width*y*3]==0)
								{
									DataImage[x*3+dlg->Width*y*3]=0;
									DataImage[x*3+dlg->Width*y*3+1]=0;
									DataImage[x*3+dlg->Width*y*3+2]=0;
								}
								if(y<dlg->Height/6)
								{
									DataImage[x*3+dlg->Width*y*3]=0;
									DataImage[x*3+dlg->Width*y*3+1]=0;
									DataImage[x*3+dlg->Width*y*3+2]=0;
								}
							}
						}
					}
				
				if(dlg->m_Enhance==TRUE)
				{
					////////////////////////////Fill every pixel in line///////////////
					if(dlg->Height < 320)Range=1;
					if(dlg->Height == 320)Range=1;
					if(dlg->Height > 320)Range=1;
					state=0;
					CountPoint = 0;
					CountBlank = 0;
					CountPointAfter = 0;
					for(y = 0; y < dlg->Height; y++)
					{
						n=0;
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3] == 255 && DataImage[x*3+dlg->Width*y*3+1]==255 && DataImage[x*3+dlg->Width*y*3+2]==255)
							{
								n=1;
							}							
						}

						if((state==0||state==1)&&n==1)
						{
							CountPoint++;
							state=1;
						}
						if((state==2||state==1)&&n==0)
						{
							CountBlank++;
							state=2;
						}
						if((state==2||state==3)&&n==1)
						{
							CountPointAfter++;
							state=3;
						}
						if(state==3&&n==0)
						{
							if(CountPoint>=Range && CountPointAfter>=Range)
							{
								Y1=y-(CountPointAfter+CountBlank+1);
								Y2=y-CountPointAfter;
								for (x = 0; x < dlg->Width; x++)
								{	
									if(DataImage[(x*3)+(dlg->Width*Y1*3)]==255 && DataImage[(x*3)+(dlg->Width*Y1*3)+1]==255 && DataImage[(x*3)+(dlg->Width*Y1*3)+2]==255)
									{
										X1=x;
									}
									if(DataImage[(x*3)+(dlg->Width*Y2*3)]==255 && DataImage[(x*3)+(dlg->Width*Y2*3)+1]==255 && DataImage[(x*3)+(dlg->Width*Y2*3)+2]==255)
									{
										X2=x;
									}
								}
								if(X2!=X1)
								{
									dx=X2-X1;
									dy=Y2-Y1;
									for (m=Y1+1;m<Y2;m++)
									{
										Slope = (float) dy/ (float) dx;
										n=((m-Y2)/Slope)+X2;
										DataImage[(n*3)+(dlg->Width*m*3)]=255;
										DataImage[(n*3)+(dlg->Width*m*3+1)]=255;
										DataImage[(n*3)+(dlg->Width*m*3+2)]=255;
									}
								}
								else if(X1==X2)
								{
									for (m=Y1+1;m<Y2;m++)
									{
										DataImage[(X1*3)+(dlg->Width*m*3)]=255;
										DataImage[(X1*3)+(dlg->Width*m*3+1)]=255;
										DataImage[(X1*3)+(dlg->Width*m*3+2)]=255;
									}
								}
								CountPoint = CountPoint+CountBlank+CountPointAfter;
								CountBlank = 1;
								CountPointAfter=0;
								state=2;
							}							
							else if(CountPointAfter<=2)
							{
								CountBlank=CountBlank+CountPointAfter+1;
								for (x = 0; x < dlg->Width; x++)
								{	
									if(DataImage[x*3+dlg->Width*(y-2)*3]==255)
									{
										DataImage[x*3+dlg->Width*(y-2)*3+1]=0;
										DataImage[x*3+dlg->Width*(y-2)*3+2]=0;
										DataImage[x*3+dlg->Width*(y-2)*3]=0;
									}
									if(DataImage[x*3+dlg->Width*(y-1)*3]==255)
									{
										DataImage[x*3+dlg->Width*(y-1)*3+1]=0;
										DataImage[x*3+dlg->Width*(y-1)*3+2]=0;
										DataImage[x*3+dlg->Width*(y-1)*3]=0;
									}
								}
								CountPointAfter=0;
								state=2;
							}
							else 
							{
								CountPoint = CountPointAfter;
								CountBlank = 1;
								CountPointAfter = 0;
								state=2;
							}
						}
					}
				
				///////////////////////////Smooth line//////////////////
					i=0;
					for(y = 0; y < dlg->Height; y++)
					{						
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3] == 255 && DataImage[x*3+dlg->Width*y*3+1]==255 && DataImage[x*3+dlg->Width*y*3+2]==255)
							{
								if(i==0)
								{
									X1=x;
									X2=x;
									Y2=y;
								}
								if(i!=0)
								{
									dx=x-X1;
									SumX=SumX+dx;
									X1=x;
								}
								i++;
							}
						}
						if(i==4)
						{
							avgX=(float)SumX/4;
							if(avgX!=0)
							{
								Slope = 1/avgX;
								for(m=Y2;m<Y2+5;m++)
								{
									for (x = 0; x < dlg->Width; x++)
									{	
										if(DataImage[x*3+dlg->Width*m*3]==255)
										{
											DataImage[x*3+dlg->Width*m*3+1]=0;
											DataImage[x*3+dlg->Width*m*3+2]=0;
											DataImage[x*3+dlg->Width*m*3]=0;
										}
									}
								}
								for(m=Y2;m<Y2+5;m++)
								{
									n=X2+avgX;
									DataImage[(n*3)+(dlg->Width*m*3)]=255;
									DataImage[(n*3)+(dlg->Width*m*3+1)]=255;
									DataImage[(n*3)+(dlg->Width*m*3+2)]=255;
								}					
							}
							i=0;
							SumX=0;
							y=y-3;
						}
					}
				}
					//////////////////////////////////////////////
					//********************************************
				////////////////////////////////////////////////////////////////////////////////
				//////////////////Pass Line Laser to equation and get X Y Z position Keep in Array////////
					for(y = 0; y < dlg->Height; y++)
					{
						n=0;
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]==255&&DataImage[x*3+dlg->Width*y*3+1]==255&&DataImage[x*3+dlg->Width*y*3+2]==255)
							{	
								////////////////////////Stereo Opsis Equation//////////////////
								xPos= 31.75/((-(0.482/((x-(dlg->Width/2))*dlg->PixelLength)))-tan(dlg->m_Angle));
								zPos= (-(0.482/((x-(dlg->Width/2))*dlg->PixelLength)))*xPos;
								yPos=((y-(dlg->Height/2))*dlg->PixelLength_h*zPos)/0.482;
							 
								///////////////////////////////////////////////////////////////
								
								////////////////////////Rotate Position of Point///////////////
								
								zPos = zPos-31.75;
								
								D3DXMatrixIdentity(&MulMat);

								CPos._11 = xPos; CPos._12 = yPos; CPos._13 = zPos;CPos._14=1;
								CPos._21 = 0   ; CPos._22 = 0   ; CPos._23 = 0   ;CPos._24=0;
								CPos._31 = 0   ; CPos._32 = 0   ; CPos._33 = 0   ;CPos._34=0;
								CPos._41 = 0   ; CPos._42 = 0   ; CPos._43 = 0   ;CPos._44=0;

								D3DXMatrixRotationY(&MulMat,(D3DXToRadian((dlg->Frame-dlg->Default_Frame+1)*dlg->Count*(-1.8))));
								D3DXMatrixMultiply(&CPos,&CPos,&MulMat);
								
								zPos = CPos._13;
								xPos = CPos._11;

								////////////////////////////////////////////////////////////////

								dlg->Position[(dlg->Frame-(dlg->Default_Frame+1))*dlg->Height*3+y*3]=xPos;
								dlg->Position[(dlg->Frame-(dlg->Default_Frame+1))*dlg->Height*3+y*3+1]=yPos;
								dlg->Position[(dlg->Frame-(dlg->Default_Frame+1))*dlg->Height*3+y*3+2]=zPos;
							}
							else 
							{
								n++;
							}
							if(n==dlg->Width)
							{
								dlg->Position[(dlg->Frame-(dlg->Default_Frame+1))*dlg->Height*3+y*3]=65535;
								dlg->Position[(dlg->Frame-(dlg->Default_Frame+1))*dlg->Height*3+y*3+1]=65535;
								dlg->Position[(dlg->Frame-(dlg->Default_Frame+1))*dlg->Height*3+y*3+2]=65535;
							}
						}
					}
				//////////////////////////////////////////////////////////////////////////////////////////
					//****
		

				///////////////////Show Output, Frame number and Turn off the Light//////////////////
					
					if(dlg->m_DebugMode == TRUE)
					{
						Sleep(250);
						itoa(((dlg->Frame)-(dlg->Default_Frame)),ShowFrame,10);
						dlg->m_VideoOCXTool.DrawText(dlg->m_Image, ShowFrame, 10, 10);					
						dlg->m_Video.Show(dlg->m_Image);
					}
						dlg->Serial.sendCommand('f');		//************************
						dlg->next=FALSE;	
						Sleep(500);				
					dlg->Serial.Clear();
				}
				///////////////////////////Complete Scanning///////////////////////
				else
				{
					dlg->Serial.sendCommand('f');		//**********************
					dlg->m_Video.SetPreview(TRUE);
					
					//****
					
				
					if(m_Object->HaveObject())
					{
						m_Object->CleanObject();
						m_HaveObject=FALSE;
					}
					m_Object->CreateObject(dlg->Position,dlg->Frame,dlg->Height);
					m_HaveObject = TRUE;
					
					//****

					dlg->m_SetFrame=TRUE;		
					dlg->Default_Frame=dlg->Frame;
					dlg->m_StopScan.EnableWindow(FALSE);
					dlg->m_Capture.EnableWindow(TRUE);
					dlg->m_Preview.EnableWindow(TRUE);
					dlg->m_Close.EnableWindow(TRUE);
					dlg->m_Format.EnableWindow(TRUE);
					dlg->m_Light.EnableWindow(TRUE);
					dlg->m_RotateL.EnableWindow(TRUE);
					dlg->m_RotateR.EnableWindow(TRUE);
					dlg->m_Start.EnableWindow(TRUE);
					dlg->m_Scan.EnableWindow(TRUE);
					dlg->m_LockIntensity.EnableWindow(TRUE);
					dlg->m_LockRemoval.EnableWindow(TRUE);
					dlg->m_LockDistance.EnableWindow(TRUE);
					dlg->m_LockEnhance.EnableWindow(TRUE);
					dlg->m_LockQuick.EnableWindow(TRUE);
					dlg->m_Change.EnableWindow(TRUE);
					dlg->m_Frame1x.EnableWindow(TRUE);
					dlg->m_Frame2x.EnableWindow(TRUE);
					dlg->m_Frame4x.EnableWindow(TRUE);
					dlg->m_Frame8x.EnableWindow(TRUE);
					Sleep(1000);
					dlg->next=TRUE;
				}
				break;
			////////////////////////////////////////////////////////////////

				case 2:									//Close Test
				dlg->Default_Frame=dlg->Frame;
				dlg->m_Video.SetPreview(TRUE);
				dlg->m_StopScan.EnableWindow(FALSE);
				dlg->m_Capture.EnableWindow(TRUE);
				dlg->m_Preview.EnableWindow(TRUE);
				dlg->m_Close.EnableWindow(TRUE);
				dlg->m_Format.EnableWindow(TRUE);
				dlg->m_Light.EnableWindow(TRUE);
				dlg->m_RotateL.EnableWindow(TRUE);
				dlg->m_RotateR.EnableWindow(TRUE);
				dlg->m_Start.EnableWindow(TRUE);
				dlg->m_Scan.EnableWindow(TRUE);
				dlg->m_LockEnhance.EnableWindow(TRUE);
				dlg->m_LockQuick.EnableWindow(TRUE);
				dlg->m_Frame1x.EnableWindow(TRUE);
				dlg->m_Frame2x.EnableWindow(TRUE);
				dlg->m_Frame4x.EnableWindow(TRUE);
				dlg->m_Frame8x.EnableWindow(TRUE);
				dlg->m_LockIntensity.EnableWindow(TRUE);
				dlg->m_LockRemoval.EnableWindow(TRUE);
				dlg->m_LockDistance.EnableWindow(TRUE);
				dlg->m_Change.EnableWindow(TRUE);
				dlg->m_SetFrame = TRUE;
				dlg->Serial.sendCommand('f');
				Sleep(1000);
				dlg->next=TRUE;
				
				break;
			//////////////////////////serial port////////////////
				case 3:									//Rotate Right
				if(dlg->Default_Frame != 0){			
					dlg->Default_Frame--;
					dlg->Serial.sendCommand('r');
					Sleep(1000);
					dlg->next=FALSE;
				}
				if(dlg->Default_Frame == 0){
					dlg->Default_Frame = dlg->Frame;
					dlg->next=TRUE;
				}
				break;

				case 4:									//Rotate Left
				if(dlg->Default_Frame != 0){
					dlg->Default_Frame--;
					dlg->Serial.sendCommand('l');
					Sleep(1000);
					dlg->next=FALSE;
				}
				if(dlg->Default_Frame == 0){
					dlg->Default_Frame = dlg->Frame;
					dlg->next=TRUE;
				}
				break;
			
			}
	// leave time for other processes
		Sleep(5);		
	}

	// End Thread
	return(0);
}

void CAppForm::OnStart() 
{
	if(Serial.Connect(1))
	{
		m_Light.EnableWindow(TRUE);
		m_RotateL.EnableWindow(TRUE);
		m_RotateR.EnableWindow(TRUE);
		Serial.sendCommand('l');
		Serial.sendCommand('f');
	}
	if (m_Image != 0)
		return;
	
	m_Video.SetErrorMessages(0);

	if (!m_Video.Init())
	{
		// Error while trying to init control
		
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
		return;		// exit
	}
	m_Video.SetPreview(TRUE);

	// allocate memory for all images that will be needed to demonstrate VideoOCXTools - features
	//   Make sure you free the resources later using VideoOCX::ReleaseImageHandle(long).
	m_Image = m_Video.GetColorImageHandle();
	m_ResultImage = m_Video.GetColorImageHandle();
	m_HelperImage = m_Video.GetColorImageHandle();
	m_GrayImage = m_Video.GetGrayImageHandle();
	m_ToolNumber = -1;
	next = FALSE;
	Height=m_Video.GetHeight();
	Width=m_Video.GetWidth();
	int size;
	size = m_Video.GetImageDataSize(m_Image);
	Background = new BYTE[size];
	TempImage = new BYTE[size];
	ObjectImage = new BYTE[size];
	Position = new float[Height*(Default_Frame)*3];
	if(Height>352)
	{
		m_VideoOCXTool.SetTextStyle(m_Image, "arial", 24, 255, 255, 255);
	}
	else if(Height<320)
	{
		m_VideoOCXTool.SetTextStyle(m_Image, "arial", 8, 255, 255, 255);
	}
	else
	{
		m_VideoOCXTool.SetTextStyle(m_Image, "arial", 16, 255, 255, 255);
	}
	m_VideoOCXTool.SetTextBackground(m_Image,0, 0, 0, 0);
	UpdateData(FALSE);

	Sleep(100);		// make sure VideoOCX has time to be properly initialized
	// Start capture thread	

	if (m_Video.Start())						// start capture mode
	{		
		m_Running = TRUE;
		AfxBeginThread(CaptureThread, this);	// start capture thread
	/////////////////Enable Control Button///////////////
		m_Scan.EnableWindow(TRUE);
		m_Capture.EnableWindow(TRUE);
		m_Close.EnableWindow(TRUE);
		m_Format.EnableWindow(TRUE);
		m_Info.EnableWindow(TRUE);
		m_Preview.EnableWindow(TRUE);
		m_Frame1x.EnableWindow(TRUE);
		m_Frame2x.EnableWindow(TRUE);
		m_Frame4x.EnableWindow(TRUE);
		m_Frame8x.EnableWindow(TRUE);
		m_Change.EnableWindow(TRUE);
		m_LockIntensity.EnableWindow(TRUE);
		m_LockDistance.EnableWindow(TRUE);
		m_LockRemoval.EnableWindow(TRUE);
		m_LockEnhance.EnableWindow(TRUE);
		m_LockQuick.EnableWindow(TRUE);
		m_Start.EnableWindow(FALSE);
	}
	else
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
}

void CAppForm::OnCapture() 
{
	m_Video.SetPreview(FALSE);
	m_ToolNumber = 0;
	next=FALSE;
	m_Scan.EnableWindow(FALSE);
}

void CAppForm::OnLight() 
{
	if (light == FALSE){				// Show Light (True mean light on)
	Serial.sendCommand('o');
	light = TRUE;
	}
	else {
	Serial.sendCommand('f');
	light = FALSE;
	}
	next = FALSE;
}

void CAppForm::OnRotateR() 
{
	m_ToolNumber = 3;
	next=FALSE;
}
                                                                                                                                                                                                                                                                       
void CAppForm::OnRotateL() 
{
	m_ToolNumber = 4;
	next=FALSE;
}

void CAppForm::OnScan() 
{
	m_SetFrame=FALSE;
	m_ToolNumber = 1;
	next=FALSE;
	m_StopScan.EnableWindow(TRUE);
	m_Capture.EnableWindow(FALSE);
	m_Preview.EnableWindow(FALSE);
	m_Close.EnableWindow(FALSE);
	m_Format.EnableWindow(FALSE);
	m_Light.EnableWindow(FALSE);
	m_RotateL.EnableWindow(FALSE);
	m_RotateR.EnableWindow(FALSE);
	m_Start.EnableWindow(FALSE);
	m_Scan.EnableWindow(FALSE);
	m_Frame1x.EnableWindow(FALSE);
	m_Frame2x.EnableWindow(FALSE);
	m_Frame4x.EnableWindow(FALSE);
	m_Frame8x.EnableWindow(FALSE);
	m_LockIntensity.EnableWindow(FALSE);
	m_LockRemoval.EnableWindow(FALSE);
	m_LockDistance.EnableWindow(FALSE);
	m_LockEnhance.EnableWindow(FALSE);
	m_LockQuick.EnableWindow(FALSE);
	m_Change.EnableWindow(FALSE);

	//**
	
	if(m_Object->HaveObject())m_Object->CleanObject();

}

void CAppForm::OnStopScan() 
{
	
	m_ToolNumber = 2;
	next=FALSE;
}

void CAppForm::OnPreview() 
{
	m_Video.SetPreview(TRUE);
	m_Scan.EnableWindow(TRUE);
}

void CAppForm::OnInfo() 
{
	if (!m_Video.ShowInfoDlg())
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);		
	}
}

void CAppForm::OnFormat() 
{
	m_Video.Stop();
	if (!m_Video.ShowFormatDlg())
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);		
	}
	m_Video.ReleaseImageHandle(m_Image);
	m_Image = m_Video.GetColorImageHandle();
	m_Video.Start();
	Height=m_Video.GetHeight();
	Width=m_Video.GetWidth();
	delete Background;
	delete TempImage;
	delete ObjectImage;
	delete Position;
	int size;
	size = m_Video.GetImageDataSize(m_Image);
	Background = new BYTE[size];
	TempImage = new BYTE[size];
	ObjectImage = new BYTE[size];
	Position = new float[Height*(Default_Frame)*3];
	if(Height>352)
	{
		m_VideoOCXTool.SetTextStyle(m_Image, "arial", 24, 255, 255, 255);
	}
	else if(Height<320)
	{
		m_VideoOCXTool.SetTextStyle(m_Image, "arial", 8, 255, 255, 255);
	}
	else
	{
		m_VideoOCXTool.SetTextStyle(m_Image, "arial", 16, 255, 255, 255);
	}
	m_VideoOCXTool.SetTextBackground(m_Image,0, 0, 0, 0);
	UpdateData(FALSE);
}

void CAppForm::OnFrame1x() 
{
	if(m_SetFrame==TRUE)
	{
		if(IsDlgButtonChecked(IDC_FRAME1X))
		{
			Default_Frame=200;
			Frame=200;
			Count=(200)/Default_Frame;
			delete Position;
			Position = new float[Height*(Default_Frame)*3];
			UpdateData(FALSE);
		}
	}
	
}

void CAppForm::OnFrame2x() 
{
	if(m_SetFrame==TRUE)
	{
		if(IsDlgButtonChecked(IDC_FRAME2X))
		{
			Default_Frame=100;
			Frame=100;
			Count=(200)/Default_Frame;
			delete Position;
			Position = new float[Height*(Default_Frame)*3];
			UpdateData(FALSE);
		}
	}
	
}

void CAppForm::OnFrame4x() 
{
	if(m_SetFrame==TRUE)
	{
		if(IsDlgButtonChecked(IDC_FRAME4X))
		{
			Default_Frame=50;
			Frame=50;
			Count=(200)/Default_Frame;
			delete Position;
			Position = new float[Height*(Default_Frame)*3];
			UpdateData(FALSE);
		}
	}
	
}

void CAppForm::OnFrame8x() 
{
	if(m_SetFrame==TRUE)
	{
		if(IsDlgButtonChecked(IDC_FRAME8X))
		{
			Default_Frame=25;
			Frame=25;
			Count=(200)/Default_Frame;
			delete Position;
			Position = new float[Height*(Default_Frame)*3];
			UpdateData(FALSE);
		}
	}
	
}

void CAppFrameWnd::On_IDM_Load() 
{
	// TODO: Add your command handler code here
		
	//if (m_HaveObject) 	m_Object->CleanObject();					// Clean Object
	if(m_Object->HaveObject()) m_Object->CleanObject();
	
	TCHAR						szMesh[MAX_PATH];
	OPENFILENAME ofn;       // common dialog box structure
	char szFile[260];       // buffer for file name
	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;
	ofn.lpstrFile = szFile;
	//
	// Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
	// use the contents of szFile to initialize itself.
	//
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = _T("Mesh File (.X)\0*.x");
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;


	// Display the Open dialog box. 

	if (GetOpenFileName(&ofn) ==TRUE)								
	 {
		DXUtil_FindMediaFileCb( szMesh, sizeof(szMesh), szFile );	//Check Path of File
		m_Object->LoadObject(szMesh);								//Load Mesh
		//m_HaveObject = TRUE;										//Now Have Object
	  };

}



void CAppFrameWnd::On_IDM_New() 
{
	// TODO: Add your command handler code here
	//m_HaveObject = FALSE ;
	if(m_Object->HaveObject())m_Object->CleanObject();

}

void CAppFrameWnd::On_IDM_Save() 
{
	// TODO: Add your command handler code here

	TCHAR initdir[MAX_PATH];
	
	OPENFILENAME ofn;       // common dialog box structure
	char szFile[260];       // buffer for file name
	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;
	ofn.lpstrFile = szFile;
	//
	// Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
	// use the contents of szFile to initialize itself.
	//
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = _T("Mesh File (.X)\0*.x");
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = initdir;						//Keep Path Value
	
	// Display the Open dialog box. 

	if (GetSaveFileName(&ofn) ==TRUE) 
	{                    
		TCHAR* pLastSlash =  _tcsrchr( szFile, _T('.x') );
		if(pLastSlash == NULL)	_tcsncat(szFile,".x",2);	//Concat .x to name
		SetCurrentDirectory(initdir);						//Set Directory that Run Process
		m_Object->SaveObject(szFile);						//Save Object to File
	};

	
}

void CAppForm::OnChange() 
{
	UpdateData(TRUE);
	switch (m_Distance)
	{
		case  5 : m_Angle = 81.05;break;
		case 10 : m_Angle = 72.52;break;
		case 15 : m_Angle = 64.71;break;
		case 20 : m_Angle = 57.79;break;
		default : MessageBox("Please Insert Value Only 5, 10, 15 or 20","Change Distance",MB_OK);
	}
}

void CAppForm::OnClose() 
{
	CAppForm::OnCameraClose();
	Serial.sendCommand('f');
	Serial.Disconnect();
	Sleep(1000);
	CFormView ::OnClose();
}

void CAppForm::OnEnhance() 
{
	if(m_Enhance == TRUE) m_Enhance = FALSE;
	else m_Enhance = TRUE;
}

void CAppForm::OnPoint() 
{
	// TODO: Add your control notification handler code here
	m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,		D3DFILL_POINT);
	Paint = 3;	
}

void CAppForm::OnWire() 
{
	// TODO: Add your control notification handler code here
	m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,		D3DFILL_WIREFRAME);
	Paint = 2;	
}



void CAppForm::OnSolid() 
{
	// TODO: Add your control notification handler code here
	m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,		D3DFILL_SOLID);
	Paint = 1;	
}

void CAppForm::OnDebug() 
{
	if(m_DebugMode == TRUE) m_DebugMode = FALSE;
	else m_DebugMode = TRUE;	
}
