#pragma once//



class Object
{
public:
	
	Object(IDirect3DDevice9* device);
	~Object();
		
	void CleanObject();
	void DrawObject();
	void SaveObject(TCHAR* inputstr);
	void LoadObject(TCHAR* inputstr);
	void CreateObject(float* p,int frame,int r);
	
	BOOL HaveObject();
	
	
private :
	
	IDirect3DDevice9*       m_pDevice;
	ID3DXMesh*				m_Mesh;

};