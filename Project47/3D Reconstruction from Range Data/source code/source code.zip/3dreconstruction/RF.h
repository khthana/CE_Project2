// RF.h: interface for the CRF class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RF_H__5D84A46E_A6C3_41D6_9401_ED8D36DD22BC__INCLUDED_)
#define AFX_RF_H__5D84A46E_A6C3_41D6_9401_ED8D36DD22BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "SerialPort.h"

class CRF  
{
public:
	void ClearDTR();
	void SetDTR();
	BOOL Disconnect();
	void Clear();

	COMMCONFIG config;
    CSerialPort port;

	void sendCommand(char ch);
	BOOL Connect(int comPort);
	CRF();
	virtual ~CRF();

};

#endif
