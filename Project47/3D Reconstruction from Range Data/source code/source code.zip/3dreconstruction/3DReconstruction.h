//-----------------------------------------------------------------------------
// File: 3DReconstruction.h
//
// Desc: Header file 3DReconstruction sample app
//-----------------------------------------------------------------------------
//{{AFX_INCLUDES()
#include "videoocx.h"
#include "resource.h"
#include "RF.h"
#include "videoocxtools.h"
//}}AFX_INCLUDES
#pragma once
#ifndef __AFXWIN_H__
#error include 'stdafx.h' before including this file
#endif
//****
//#include "Object.h"
//****





//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
// TODO: change "DirectX AppWizard Apps" to your name or the company name
#define DXAPP_KEY        TEXT("Software\\DirectX AppWizard Apps\\3DReconstruction")

// This GUID must be unique for every game, and the same for 
// every instance of this app.  // {44290FBF-C1DC-4518-9909-67C2153F1271}
// The GUID allows DirectInput to remember input settings
GUID g_guidApp = { 0x44290fbf, 0xc1dc, 0x4518, { 0x99, 0x09, 0x67, 0xc2, 0x15, 0x3f, 0x12, 0x71 } };


// DirectInput action mapper reports events only when buttons/axis change
// so we need to remember the present state of relevant axis/buttons for 
// each DirectInput device.  The CInputDeviceManager will store a 
// pointer for each device that points to this struct
struct InputDeviceState
{
    // TODO: change as needed
    FLOAT fAxisRotateLR;
    BOOL  bButtonRotateLeft;
    BOOL  bButtonRotateRight;

    FLOAT fAxisRotateUD;
    BOOL  bButtonRotateUp;
    BOOL  bButtonRotateDown;
	
	BOOL bButtonZoomIn;
	BOOL bButtonZoomOut;

	
    FLOAT fAxisSlideUD;
	FLOAT fAxisSlideLR;
	BOOL bButtonSlideUp;
	BOOL bButtonSlideDown;
	BOOL bButtonSlideLeft;
	BOOL bButtonSlideRight;

};


// Struct to store the current input state
struct UserInput
{
    // TODO: change as needed
    FLOAT fAxisRotateUD;
    FLOAT fAxisRotateLR;
	FLOAT fAxisZoom;
    BOOL bDoConfigureInput;
    BOOL bDoConfigureDisplay;
	BOOL bButtonZoomIn;
	BOOL bButtonZoomOut;
	BOOL bButtonSlideUp;
	BOOL bButtonSlideDown;
	BOOL bButtonSlideLeft;
	BOOL bButtonSlideRight;
	FLOAT fAxisSlideUD;
	FLOAT fAxisSlideLR;
};


// Input semantics used by this app
enum INPUT_SEMANTICS
{
    // Gameplay semantics
    // TODO: change as needed
    INPUT_ROTATE_AXIS_LR=1, INPUT_ROTATE_AXIS_UD,       
    INPUT_ROTATE_LEFT,      INPUT_ROTATE_RIGHT,    
    INPUT_ROTATE_UP,        INPUT_ROTATE_DOWN,
    INPUT_CONFIG_INPUT,     INPUT_CONFIG_DISPLAY,
	INPUT_ZOOM_IN,			INPUT_ZOOM_OUT,
	INPUT_SLIDE_UP,			INPUT_SLIDE_DOWN,
	INPUT_SLIDE_LEFT,		INPUT_SLIDE_RIGHT,
};

// Actions used by this app
DIACTION g_rgGameAction[] =
{
    // TODO: change as needed.  Be sure to delete user map files 
    // (C:\Program Files\Common Files\DirectX\DirectInput\User Maps\*.ini)
    // after changing this, otherwise settings won't reset and will be read 
    // from the out of date ini files 

    // Device input (joystick, etc.) that is pre-defined by DInput, according
    // to genre type. The genre for this app is space simulators.
    { INPUT_ROTATE_AXIS_LR,  DIAXIS_3DCONTROL_LATERAL,      0, TEXT("Rotate left/right"), },
    { INPUT_ROTATE_AXIS_UD,  DIAXIS_3DCONTROL_MOVE,         0, TEXT("Rotate up/down"), },

    // Keyboard input mappings
    { INPUT_ROTATE_LEFT,     DIKEYBOARD_LEFT,               0, TEXT("Rotate left"), },
    { INPUT_ROTATE_RIGHT,    DIKEYBOARD_RIGHT,              0, TEXT("Rotate right"), },
    { INPUT_ROTATE_UP,       DIKEYBOARD_UP,                 0, TEXT("Rotate up"), },
    { INPUT_ROTATE_DOWN,     DIKEYBOARD_DOWN,               0, TEXT("Rotate down"), },
    { INPUT_CONFIG_DISPLAY,  DIKEYBOARD_F2,                 DIA_APPFIXED, TEXT("Configure Display"), },    
    { INPUT_CONFIG_INPUT,    DIKEYBOARD_F3,                 DIA_APPFIXED, TEXT("Configure Input"), }, 
	{ INPUT_ZOOM_IN	,		 DIKEYBOARD_F4,					0, TEXT("Zoom In"), },
	{ INPUT_ZOOM_OUT	,    DIKEYBOARD_F5,					0, TEXT("Zoom Out"), },
	{ INPUT_SLIDE_UP	,	 DIKEYBOARD_F6,					0, TEXT("Slide Up"), },
	{ INPUT_SLIDE_DOWN	,	 DIKEYBOARD_F7,					0, TEXT("Slide Down"),},
	{ INPUT_SLIDE_LEFT	,	 DIKEYBOARD_F8,					0, TEXT("Slide Left"),},
	{ INPUT_SLIDE_RIGHT	,	 DIKEYBOARD_F9,					0, TEXT("Slide Right"),},

};

#define NUMBER_OF_GAMEACTIONS    (sizeof(g_rgGameAction)/sizeof(DIACTION))




//-----------------------------------------------------------------------------
// Name: class CAppForm
// Desc: CFormView-based class which allows the UI to be created with a form
//       (dialog) resource. This class manages all the controls on the form.
//-----------------------------------------------------------------------------
class CAppForm : public CFormView, public CD3DApplication
{
public:
    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
    CD3DFont*               m_pFont;                // Font for drawing text
    ID3DXMesh*              m_pD3DXMesh;            // D3DX mesh to store teapot

    CInputDeviceManager*    m_pInputDeviceManager;  // DirectInput device manager
    DIACTIONFORMAT          m_diafGame;             // Action format for game play
    LPDIRECT3DSURFACE9      m_pDIConfigSurface;     // Surface for config'ing DInput devices
    UserInput               m_UserInput;            // Struct for storing user input 

    FLOAT                   m_fWorldRotX;           // World rotation state X-axis
    FLOAT                   m_fWorldRotY;           // World rotation state Y-axis
	
	FLOAT					m_fZoom;
	FLOAT					m_fSlideX;
	FLOAT					m_fSlideY;






private:
    HWND    m_hwndRenderWindow;
    HWND    m_hwndRenderFullScreen;
    HWND    m_hWndTopLevelParent;

    virtual HRESULT ConfirmDevice( D3DCAPS9*,DWORD,D3DFORMAT );
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT FrameMove();
    virtual HRESULT Render();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT FinalCleanup();
    virtual HRESULT AdjustWindowForChange();
    VOID    Pause( bool bPause );

    HRESULT RenderText();

    HRESULT InitInput( HWND hWnd );
    void    UpdateInput( UserInput* pUserInput );
    void    CleanupDirectInput();

    VOID    ReadSettings();
    VOID    WriteSettings();

    VOID    UpdateUIForDeviceCapabilites();

protected:
    DECLARE_DYNCREATE(CAppForm)

             CAppForm();
    virtual  ~CAppForm();

public:
    BOOL IsReady() { return m_bActive; }
    TCHAR* PstrFrameStats() { return m_strFrameStats; }
    VOID RenderScene() { Render3DEnvironment(); }
    HRESULT CheckForLostFullscreen();

    //{{AFX_DATA(CAppForm)
	enum { IDD = IDD_FORMVIEW };
	CButton	m_LockQuick;
	CButton	m_LockEnhance;
	CButton	m_Change;
	CButton	m_StopScan;
	CButton	m_Scan;
	CButton	m_RotateR;
	CButton	m_RotateL;
	CButton	m_Preview;
	CButton	m_Light;
	CButton	m_Info;
	CButton	m_Format;
	CButton	m_Close;
	CButton	m_Capture;
	CButton	m_Start;
	CButton m_Frame1x;
	CButton m_Frame2x;
	CButton m_Frame4x;
	CButton m_Frame8x;
	CButton m_LockRemoval;
	CButton m_LockIntensity;
	CButton m_LockDistance;
	CVideoOCX	m_Video;
	int		m_High;
	CVideoOCXTools	m_VideoOCXTool;
	int		m_Wide;
	int		m_Intensity;
	int		m_Removal;
	int		m_Distance;
	float   m_Angle;
	int		Width;
	int		Height;
	BOOL	m_Enhance;
	BOOL	m_DebugMode;
	//}}AFX_DATA

    //{{AFX_VIRTUAL(CAppForm)
    virtual void OnInitialUpdate();
    protected:
    virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

public:
    //{{AFX_MSG(CAppForm)
    afx_msg void OnToggleFullScreen();
    afx_msg void OnChangeDevice();
	afx_msg void OnStart();
	afx_msg void OnCapture();
	afx_msg void OnCameraClose();
	afx_msg void OnFormat();
	afx_msg void OnFrame1x();
	afx_msg void OnFrame2x();
	afx_msg void OnFrame4x();
	afx_msg void OnFrame8x();
	afx_msg void OnInfo();
	afx_msg void OnLight();
	afx_msg void OnPreview();
	afx_msg void OnRotateL();
	afx_msg void OnRotateR();
	afx_msg void OnScan();
	afx_msg void OnStopScan();
	afx_msg void OnChange();
	afx_msg void OnClose();
	afx_msg void OnEnhance();
	afx_msg void OnPoint();
	afx_msg void OnWire();
	afx_msg void OnSolid();
	afx_msg void OnQuick();
	afx_msg void OnDebug();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()

    HRESULT InputAddDeviceCB( CInputDeviceManager::DeviceInfo* pDeviceInfo, const DIDEVICEINSTANCE* pdidi );
    static HRESULT CALLBACK StaticInputAddDeviceCB( CInputDeviceManager::DeviceInfo* pDeviceInfo, const DIDEVICEINSTANCE* pdidi, LPVOID pParam );   
    BOOL    ConfigureInputDevicesCB( IUnknown* pUnknown );
    static BOOL CALLBACK StaticConfigureInputDevicesCB( IUnknown* pUnknown, VOID* pUserData );

public:		// Add on Variable
	CRF Serial;
	int	Default_Frame,Frame;
	long m_Image;
	long m_ResultImage;
	long m_HelperImage;
	long m_GrayImage;
	int  Count;
	BYTE * Background ;
	BOOL m_Running,m_SetFrame;
	BOOL next;
	BOOL light;
	int	 m_ToolNumber;
	float  * Position; 
	BYTE * TempImage ;
	BYTE * ObjectImage;
	float PixelLength;
	float PixelLength_h;
	int Paint;
};




//-----------------------------------------------------------------------------
// Name: class CAppDoc
// Desc: Overridden CDocument class needed for the CFormView
//-----------------------------------------------------------------------------
class CAppDoc : public CDocument
{
protected:
    DECLARE_DYNCREATE(CAppDoc)

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAppDoc)
    public:
    //}}AFX_VIRTUAL

// Implementation
    //{{AFX_MSG(CAppDoc)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};




//-----------------------------------------------------------------------------
// Name: class CAppFrameWnd
// Desc: CFrameWnd-based class needed to override the CFormView's window style
//-----------------------------------------------------------------------------
class CAppFrameWnd : public CFrameWnd
{
protected:
    DECLARE_DYNCREATE(CAppFrameWnd)
public:
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAppFrameWnd)
    public:
    virtual BOOL PreCreateWindow( CREATESTRUCT& cs );
    virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, CWnd* pParentWnd = NULL, CCreateContext* pContext = NULL);
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CAppFrameWnd)
    afx_msg void OnChangeDevice();
    afx_msg void OnConfigInput();
	afx_msg void On_IDM_Load();
	afx_msg void On_IDM_New();
	afx_msg void On_IDM_Save();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};




//-----------------------------------------------------------------------------
// Name: class CApp
// Desc: Main MFC application class derived from CWinApp.
//-----------------------------------------------------------------------------
class CApp : public CWinApp
{
public:

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CApp)
    public:
    virtual BOOL InitInstance();
    virtual BOOL OnIdle( LONG );
    //}}AFX_VIRTUAL

// Implementation
    //{{AFX_MSG(CApp)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};




