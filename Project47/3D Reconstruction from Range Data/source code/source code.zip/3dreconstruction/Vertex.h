#pragma once
#include "stdafx.h"

struct Vertex
{
	Vertex(){}
	Vertex(
		float x, float y, float z,
		float nx, float ny, float nz,
		D3DCOLOR color)
	{
		m_x  = x;  m_y  = y;  m_z  = z;
		m_nx = nx; m_ny = ny; m_nz = nz;
		m_color  = color;
	}
    float m_x, m_y, m_z;
    float m_nx, m_ny, m_nz;
    D3DCOLOR m_color;
	static const DWORD FVF;
	
};

const DWORD Vertex::FVF = D3DFVF_XYZ  | D3DFVF_NORMAL | D3DFVF_DIFFUSE ;
