//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 3DReconstruction.rc
//
#define IDR_MAINFRAME                   101
#define IDI_MAIN_ICON                   101
#define IDD_FORMVIEW                    102
#define IDC_NODROP                      106
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_SELECTDEVICE                144
#define IDC_DEVICE_COMBO                1000
#define IDC_ADAPTER_COMBO               1002
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RESOLUTION_COMBO            1004
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_MULTISAMPLE_QUALITY_COMBO   1011
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDC_RENDERVIEW                  2002
#define IDC_VIEWFULLSCREEN              2003
#define IDC_CHANGEDEVICE                2004
#define IDC_VIDEOOCXTOOLSCTRL1          2006
#define IDC_TEST                        2008
#define IDC_VIDEOOCXCTRL1               2010
#define IDC_START                       2011
#define IDC_FORMAT                      2012
#define IDC_LIGHT                       2013
#define IDC_ROTATE_L                    2014
#define IDC_ROTATE_R                    2015
#define IDC_CAPTURE                     2016
#define IDC_PREVIEW                     2017
#define IDC_CLOSE                       2018
#define IDC_INFO                        2019
#define IDC_FRAME1X                     2021
#define IDC_FRAME2X                     2022
#define IDC_FRAME4X                     2023
#define IDC_FRAME8X                     2024
#define IDC_SCAN                        2025
#define IDC_STOP_SCAN                   2026
#define IDC_WIDE                        2027
#define IDC_HIGH                        2028
#define IDC_REMOVAL                     2029
#define IDC_INTENSITY                   2031
#define IDC_DISTANCE                    2032
#define IDC_CHANGE                      2033
#define IDC_ENHANCE                     2034
#define IDC_BUTTON1                     2035
#define IDC_POINT                       2036
#define IDC_WIRE                        2037
#define IDC_Solid                       2038
#define IDC_BUTTON5                     2039
#define IDC_DEBUG                       2040
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_EXIT                        40006
#define IDM_CONFIGINPUT                 40011
#define IDM_SAVE                        40023
#define IDM_LOAD                        40024
#define IDM_NEW                         40025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         40026
#define _APS_NEXT_CONTROL_VALUE         2041
#define _APS_NEXT_SYMED_VALUE           300
#endif
#endif
