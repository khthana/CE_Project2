#include "stdafx.h"
//#include "Object.h"
//#include "Vertex.h"

//Set Device 
Object::Object(IDirect3DDevice9* device)
{
	m_pDevice = device;
	m_Mesh = NULL;
}

Object::~Object()
{

}

//Draw Object//
void Object::DrawObject()
{
	m_Mesh->DrawSubset(0);
}

//Load Object//
void Object::LoadObject(TCHAR* inputstr)
{
	HRESULT hr = 0;


	hr = D3DXLoadMeshFromX(  
		inputstr,
		D3DXMESH_MANAGED,
		m_pDevice,
		NULL,
		NULL,
		NULL,
		NULL,
		&m_Mesh);

	
}

//Save Object//
void Object::SaveObject(TCHAR* inputstr)
{
	HRESULT hr = 0;

		hr = D3DXSaveMeshToX( 
		inputstr, 
		m_Mesh, 
		NULL, 
        NULL, 
		NULL,  
		0,
		DXFILEFORMAT_TEXT );
}

//Clean Object//
void Object::CleanObject()
{
	
	m_Mesh->Release();
	m_Mesh = NULL;
	
}

void Object::CreateObject(float* p,int frame,int r)
{
	int j = 0;
	int numv = 0;
	int numvl = 0;
		

	for(j=0;j< frame*r*3 ;j=j+3)
		{
			if(p[j] != 65535)
			{
				numv = numv+1;
			} 
		}

	//numv=numv+2;

	float* tv = 0 ;
	tv = new float[numv*3];
	
	int k =0;

	int* line = 0;
	line = new int[frame];

	int tiv = 0;

	
	
	for( k=0;k<frame;k++)
	{
		numvl = 0 ;
	
		
		for( j = k*r*3;j<((k+1)*r*3);j=j+3)
		{
			if((p[j] != 65535 ))
			{
				tv[tiv] = p[j];
				tv[tiv+1] = p[j+1];
				tv[tiv+2] = p[j+2];

				tiv = tiv + 3;
				numvl = numvl + 1;


			}
		
		}
		line[k] = numvl;
		//SumL = SumL + TempSum;
	}
		

	



/////////***********************************************   find vertex complete

	int face = 0;
	int numi = 0;

	//******
	
	
	int p1 = 0;
	int p2 = 0;
	int p3 = 0;
	int p4 = 0;
	
	int EndL = 0;
	int EndNextL = 0;
	int StartL = 0;
	int StartNextL = 0;
	int temp = 0;



	EndNextL = line[0]-1;
	StartNextL = 0;
	for(k=0;k<frame;k++)
	{	

		if(k != frame-1)
		{	
			EndL = EndNextL;
			EndNextL = EndNextL + line[k+1];
			StartL = StartNextL;
			StartNextL = StartNextL + line[k]; 
		}
		else if (k == frame-1)
		{
			EndL = EndNextL;
			EndNextL = line[0]-1 ;
			StartL = StartNextL;
			StartNextL = 0;
		}
			
			temp = EndNextL;
			for(j = EndL ; j >= StartL ; j--)
			{
				p1 = j;
				p2 = j-1;
				p3 = temp;
				p4 = temp-1;

				if((p2 >= StartL) && (p3 > StartNextL) && (p4 >= StartNextL))
				{
					face = face + 2;
					numi = numi + 6;
				}
				else if ((p2 >= StartL) && (p3 >= StartNextL))
				{
					face = face + 1;
					numi = numi + 3;
				}
				else if ((p3 > StartNextL) && (p4 >= StartNextL))
				{
					face = face + 1;
					numi = numi + 3;
				}
				temp--;
			}

		
	}


	int tii=0 ;
	int* ti = 0;
	ti = new int[numi];



	EndNextL = line[0]-1;
	StartNextL = 0;
	for(k=0;k<frame;k++)
	{	

		if(k != frame-1)
		{	
			EndL = EndNextL;
			EndNextL = EndNextL + line[k+1];
			StartL = StartNextL;
			StartNextL = StartNextL + line[k]; 
		}
		else if (k == frame-1)
		{
			EndL = EndNextL;
			EndNextL = line[0]-1 ;
			StartL = StartNextL;
			StartNextL = 0;
		}
			



			temp = EndNextL;
			for(j = EndL ; j >= StartL ; j--)
			{

							
				p1 = j;
				p2 = j-1;
				p3 = temp;
				p4 = temp-1;
				
				
				if((p2 >= StartL) && (p3 > StartNextL) && (p4 >= StartNextL))
				{
					ti[tii] = p1; ti[tii+1] = p3; ti[tii+2] = p4;
					ti[tii+3] = p1; ti[tii+4] = p4; ti[tii+5] = p2;
					tii = tii + 6;
				}
				else if ((p2 >= StartL) && (p3 >= StartNextL))
				{
					ti[tii] = p1; ti[tii+1] = p3; ti[tii+2] = p2;
					tii = tii + 3 ;
				}
				else if ((p3 > StartNextL) && (p4 >= StartNextL))
				{
					ti[tii] = p1; ti[tii+1] = p3; ti[tii+2] = p4;
					tii = tii + 3 ;
				}
				temp--;
			}
		


	}


	HRESULT hr = 0 ;

	hr = D3DXCreateMeshFVF(
		face,
		numv,
		D3DXMESH_MANAGED,
		Vertex::FVF,
		m_pDevice,
		&m_Mesh);


	j=0;
	Vertex* v = 0;
	m_Mesh->LockVertexBuffer(0, (void**)&v);
	
	for(k=0;k<numv;k++)
	{	
		
		v[k] = Vertex( tv[j], tv[j+1],  tv[j+2], 0.0f, 0.0f, 0.0f, D3DCOLOR_XRGB(255,0,0));
		j=j+3;
	}

	
	m_Mesh->UnlockVertexBuffer();


	
	
	WORD* i = 0;
	m_Mesh->LockIndexBuffer(0, (void**)&i);


	for(k=0;k<numi;k++)(i[k]= (WORD)ti[k]);

	m_Mesh->UnlockIndexBuffer();

	D3DXComputeNormals(m_Mesh,0);




	delete ti;
	delete tv;
	delete line;

}


//**
//**


//**

//**

//**

//**

//**

BOOL Object::HaveObject()
{

	if(m_Mesh == NULL) return FALSE;
	else return TRUE;
}