#if !defined(AFX_TEST_H__0E9723C6_41B0_461B_8F15_D4ADF46A3518__INCLUDED_)
#define AFX_TEST_H__0E9723C6_41B0_461B_8F15_D4ADF46A3518__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Test.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Test dialog

class Test : public CFileDialog
{
	DECLARE_DYNAMIC(Test)

public:
	Test(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(Test)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST_H__0E9723C6_41B0_461B_8F15_D4ADF46A3518__INCLUDED_)
