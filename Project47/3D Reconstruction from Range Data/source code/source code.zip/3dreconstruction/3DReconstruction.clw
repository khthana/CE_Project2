; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CAppForm
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "3dreconstruction.h"
LastPage=0

ClassCount=4
Class1=CApp
Class2=CAppForm
Class3=CAppDoc
Class4=CAppFrameWnd

ResourceCount=4
Resource1=IDR_MAIN_ACCEL (English (U.S.))
Resource2=IDD_SELECTDEVICE (English (U.S.))
Resource3=IDD_FORMVIEW (English (U.S.))
Resource4=IDR_MAINFRAME (English (U.S.))

[CLS:CApp]
Type=0
BaseClass=CWinApp
HeaderFile=3DReconstruction.h
ImplementationFile=3DReconstruction.cpp
LastObject=CApp

[CLS:CAppForm]
Type=0
BaseClass=CFormView 
HeaderFile=3DReconstruction.h
ImplementationFile=3DReconstruction.cpp
Filter=D
VirtualFilter=VWC
LastObject=IDC_DISTANCE

[CLS:CAppDoc]
Type=0
BaseClass=CDocument
HeaderFile=3DReconstruction.h
ImplementationFile=3DReconstruction.cpp

[CLS:CAppFrameWnd]
Type=0
BaseClass=CFrameWnd
HeaderFile=3DReconstruction.h
ImplementationFile=3DReconstruction.cpp
Filter=T
VirtualFilter=fWC
LastObject=CAppFrameWnd

[DLG:IDD_FORMVIEW]
Type=1
Class=CAppForm

[DLG:IDD_SELECTDEVICE (English (U.S.))]
Type=1
Class=?
ControlCount=29
Control1=IDC_STATIC,button,1342177287
Control2=IDC_STATIC,static,1342308864
Control3=IDC_ADAPTER_COMBO,combobox,1344339971
Control4=IDC_STATIC,static,1342308864
Control5=IDC_DEVICE_COMBO,combobox,1344339971
Control6=IDC_STATIC,button,1342177287
Control7=IDC_WINDOW,button,1342373897
Control8=IDC_FULLSCREEN,button,1342177289
Control9=IDC_STATIC,static,1342308352
Control10=IDC_ADAPTERFORMAT_COMBO,combobox,1344471043
Control11=IDC_STATIC,static,1342308352
Control12=IDC_RESOLUTION_COMBO,combobox,1344471043
Control13=IDC_STATIC,static,1342308352
Control14=IDC_REFRESHRATE_COMBO,combobox,1344471043
Control15=IDC_STATIC,button,1342177287
Control16=IDC_STATIC,static,1342308352
Control17=IDC_BACKBUFFERFORMAT_COMBO,combobox,1344339971
Control18=IDC_STATIC,static,1342308352
Control19=IDC_DEPTHSTENCILBUFFERFORMAT_COMBO,combobox,1344339971
Control20=IDC_STATIC,static,1342308864
Control21=IDC_MULTISAMPLE_COMBO,combobox,1344339971
Control22=IDC_STATIC,static,1342308352
Control23=IDC_MULTISAMPLE_QUALITY_COMBO,combobox,1344339971
Control24=IDC_STATIC,static,1342308352
Control25=IDC_VERTEXPROCESSING_COMBO,combobox,1344339971
Control26=IDC_STATIC,static,1342308352
Control27=IDC_PRESENTINTERVAL_COMBO,combobox,1344339971
Control28=IDOK,button,1342242817
Control29=IDCANCEL,button,1342242816

[DLG:IDD_FORMVIEW (English (U.S.))]
Type=1
Class=CAppForm
ControlCount=44
Control1=IDC_VIEWFULLSCREEN,button,1342242816
Control2=IDC_RENDERVIEW,static,1342177287
Control3=IDC_VIDEOOCXTOOLSCTRL1,{523EF5C0-2E8B-44C0-94F4-C6981B3D0C07},1342242816
Control4=IDC_VIDEOOCXCTRL1,{A91E1E79-6AE7-11D4-AD08-A8AB2E818B70},1342242816
Control5=IDC_STATIC,button,1342177287
Control6=IDC_STATIC,button,1342177287
Control7=IDC_START,button,1342242816
Control8=IDC_FORMAT,button,1476460544
Control9=IDC_STATIC,button,1342177287
Control10=IDC_LIGHT,button,1476460544
Control11=IDC_ROTATE_L,button,1476460544
Control12=IDC_ROTATE_R,button,1476460544
Control13=IDC_STATIC,button,1342177287
Control14=IDC_CAPTURE,button,1476460544
Control15=IDC_PREVIEW,button,1476460544
Control16=IDC_CLOSE,button,1476460544
Control17=IDC_INFO,button,1476460544
Control18=IDC_STATIC,button,1342177287
Control19=IDC_FRAME1X,button,1476395017
Control20=IDC_FRAME2X,button,1476395017
Control21=IDC_FRAME4X,button,1476395017
Control22=IDC_FRAME8X,button,1476395017
Control23=IDC_STATIC,button,1342177287
Control24=IDC_SCAN,button,1476460544
Control25=IDC_STOP_SCAN,button,1476460544
Control26=IDC_STATIC,static,1342308352
Control27=IDC_WIDE,edit,1350633602
Control28=IDC_STATIC,static,1342308352
Control29=IDC_HIGH,edit,1350633602
Control30=IDC_STATIC,button,1342177287
Control31=IDC_STATIC,button,1342177287
Control32=IDC_STATIC,static,1342308352
Control33=IDC_STATIC,static,1342308352
Control34=IDC_REMOVAL,edit,1484849280
Control35=IDC_INTENSITY,edit,1484849280
Control36=IDC_STATIC,static,1342308352
Control37=IDC_DISTANCE,edit,1484849280
Control38=IDC_CHANGE,button,1476460544
Control39=IDC_ENHANCE,button,1476460547
Control40=IDC_POINT,button,1342242816
Control41=IDC_WIRE,button,1342242816
Control42=IDC_Solid,button,1342242816
Control43=IDC_STATIC,static,1342308352
Control44=IDC_DEBUG,button,1476460547

[ACL:IDR_MAIN_ACCEL (English (U.S.))]
Type=1
Class=?
Command1=IDC_VIEWFULLSCREEN
CommandCount=1

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=CAppFrameWnd
Command1=IDM_NEW
Command2=IDM_SAVE
Command3=IDM_LOAD
Command4=ID_APP_EXIT
Command5=IDM_CHANGEDEVICE
Command6=IDM_CONFIGINPUT
CommandCount=6

