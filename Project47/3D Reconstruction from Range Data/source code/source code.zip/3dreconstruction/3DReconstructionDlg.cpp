// 3DReconstructionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "3DReconstruction.h"
#include "3DReconstructionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy3DReconstructionDlg dialog

CMy3DReconstructionDlg::CMy3DReconstructionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy3DReconstructionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy3DReconstructionDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy3DReconstructionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy3DReconstructionDlg)
	DDX_Control(pDX, IDC_FORMAT, m_Format);
	DDX_Control(pDX, IDC_INFO, m_Info);
	DDX_Control(pDX, IDC_PREVIEW, m_Preview);
	DDX_Control(pDX, IDC_START, m_Start);
	DDX_Control(pDX, IDC_STOP_SCAN, m_Stop_Scan);
	DDX_Control(pDX, IDC_SCAN_TEST, m_Scan_Test);
	DDX_Control(pDX, IDC_ROTATE_L, m_Rotate_L);
	DDX_Control(pDX, IDC_ROTATE_R, m_Rotate_R);
	DDX_Control(pDX, IDC_THRESHOLD, m_Threshold);
	DDX_Control(pDX, IDC_LIGHT, m_Light);
	DDX_Control(pDX, IDC_CAPTURE, m_Capture);
	DDX_Control(pDX, IDDRIVER, m_Driver);
	DDX_Control(pDX, IDCLOSE, m_Close);
	DDX_Control(pDX, IDC_VIDEOOCXCTRL1, m_Video);
	DDX_Control(pDX, IDC_VIDEOOCXTOOLSCTRL1, m_VideoOCXTool);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy3DReconstructionDlg, CDialog)
	//{{AFX_MSG_MAP(CMy3DReconstructionDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDCLOSE, OnClose)
	ON_BN_CLICKED(IDDRIVER, OnSelectDriver)
	ON_BN_CLICKED(IDC_CAPTURE, OnCapture)
	ON_BN_CLICKED(IDC_LIGHT, OnLight)
	ON_BN_CLICKED(IDC_THRESHOLD, OnThreshold)
	ON_BN_CLICKED(IDC_ROTATE_R, OnRotateR)
	ON_BN_CLICKED(IDC_ROTATE_L, OnRotateL)
	ON_BN_CLICKED(IDC_SCAN_TEST, OnScanTest)
	ON_BN_CLICKED(IDC_STOP_SCAN, OnStopScan)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
	ON_BN_CLICKED(IDC_INFO, OnInfo)
	ON_BN_CLICKED(IDC_FORMAT, OnFormat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy3DReconstructionDlg message handlers

BOOL CMy3DReconstructionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	// init members
	m_Running = FALSE;
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;
	m_ToolNumber = -1;	
	light = FALSE;
	Default_Frame = 200;
//	m_Threshold = 100;
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy3DReconstructionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy3DReconstructionDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
void CMy3DReconstructionDlg::OnClose() 
{
	// Stop capture thread

	m_Running = FALSE;	// tell thread to end
	Sleep(250);			// wait for thread to end

	// end capture mode
	if (!m_Video.Stop())
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}

	// free memory
	m_Video.ReleaseImageHandle(m_Image);
	m_Video.ReleaseImageHandle(m_ResultImage);
	m_Video.ReleaseImageHandle(m_HelperImage);
	m_Video.ReleaseImageHandle(m_GrayImage);
	m_Image = 0;
	m_ResultImage = 0;
	m_HelperImage = 0;

	//	close video connection and free memory
	Sleep(5);
	if (!m_Video.Close())
	{
		// error while closing video connection
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
}

void CMy3DReconstructionDlg::OnSelectDriver() 
{
	if (!m_Video.ShowDriverDlg())			// Show Driver selection dialog
	{
		// Source dialog failed
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);				
	}		

	m_Video.SetMode(0);						// Use Video as video source
}

UINT CaptureThread(LPVOID pParam)
{
	// Capture Thread 
	CMy3DReconstructionDlg *dlg;		// reference to parent dialog

	// Get pointer to parent dialog
	dlg = (CMy3DReconstructionDlg *)pParam;

	// capture loop
	while (dlg->m_Running)
	{
		while(dlg->next){}
		// try to capture, if Capture returns FALSE, no image was available
		// at this time. 
		// which VideoOCXTools function is currently acitve?	
		//////////////////////////Get Array Of Image/////////////////
		int x,y= 0;
		int SumPixel=0;
		int CountPixel=0;
		BYTE * DataImage ;
		BYTE * TempImage ;
		switch(dlg->m_ToolNumber)
			{
			 ////////////////////Capture one frame/////////////
				case 0:
				dlg->m_Video.Capture(dlg->m_Image);
				dlg->m_Video.Show(dlg->m_Image);
				dlg->next=TRUE;
				break;
			//////////////////////////Scan subtraction Image////////////////
				case 1:
				if(dlg->Default_Frame != 0)
				{
					//////////////////Send Command to motor//////////////
					dlg->Default_Frame--;
					dlg->Serial.sendCommand('r');
					Sleep(1000);							//
					//////////////////Capture First Pic and Copy to temp//////////////////
					dlg->m_Video.Capture(dlg->m_Image);
					dlg->m_Video.Show(dlg->m_Image);		//
					DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
					dlg->Height=dlg->m_Video.GetHeight();
					dlg->Width=dlg->m_Video.GetWidth();
					
					int size;
					size = dlg->m_Video.GetImageDataSize(dlg->m_Image);
					TempImage = new BYTE[size];
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							TempImage[x*3+dlg->Width*y*3]=DataImage[x*3+dlg->Width*y*3];
							TempImage[x*3+dlg->Width*y*3+1]=DataImage[x*3+dlg->Width*y*3+1];
							TempImage[x*3+dlg->Width*y*3+2]=DataImage[x*3+dlg->Width*y*3+2];
						}
					}
					
					/////////////////////Light on/////////////////////////////////
					dlg->Serial.sendCommand('o');
					Sleep(1000);							//
					///////////////////////Capture Next Pic///////////////////////
					dlg->m_Video.Capture(dlg->m_Image);
					DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
					dlg->m_Video.Show(dlg->m_Image);		//
					///////////////////////Subtraction Between two Pics/////////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]>=TempImage[x*3+dlg->Width*y*3])
							{
								DataImage[x*3+dlg->Width*y*3]=DataImage[x*3+dlg->Width*y*3]-TempImage[x*3+dlg->Width*y*3];
							}
							else
							{
								DataImage[x*3+dlg->Width*y*3]=TempImage[x*3+dlg->Width*y*3]-DataImage[x*3+dlg->Width*y*3];
							}
							if(DataImage[x*3+dlg->Width*y*3+1]>=TempImage[x*3+dlg->Width*y*3+1])
							{
								DataImage[x*3+dlg->Width*y*3+1]=DataImage[x*3+dlg->Width*y*3+1]-TempImage[x*3+dlg->Width*y*3+1];
							}
							else
							{
								DataImage[x*3+dlg->Width*y*3+1]=TempImage[x*3+dlg->Width*y*3+1]-DataImage[x*3+dlg->Width*y*3+1];
							}
							if(DataImage[x*3+dlg->Width*y*3+2]>=TempImage[x*3+dlg->Width*y*3+2])
							{
								DataImage[x*3+dlg->Width*y*3+2]=DataImage[x*3+dlg->Width*y*3+2]-TempImage[x*3+dlg->Width*y*3+2];
							}
							else
							{
								DataImage[x*3+dlg->Width*y*3+2]=TempImage[x*3+dlg->Width*y*3+2]-DataImage[x*3+dlg->Width*y*3+2];
							}
						}
					}
					Sleep(1000);							//
					dlg->m_Video.Show(dlg->m_Image);		//
					/////////////////////Threshold for reduce noise//////////////////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]>=50){DataImage[x*3+dlg->Width*y*3]=255;}
							if(DataImage[x*3+dlg->Width*y*3]<50){DataImage[x*3+dlg->Width*y*3]=0;}
							if(DataImage[x*3+1+dlg->Width*y*3]>=50){DataImage[x*3+1+dlg->Width*y*3]=255;}
							if(DataImage[x*3+1+dlg->Width*y*3]<50){DataImage[x*3+1+dlg->Width*y*3]=0;}
							if(DataImage[x*3+2+dlg->Width*y*3]>=50){DataImage[x*3+2+dlg->Width*y*3]=255;}
							if(DataImage[x*3+2+dlg->Width*y*3]<50){DataImage[x*3+2+dlg->Width*y*3]=0;}
						}
					}
					Sleep(1000);							//
					dlg->m_Video.Show(dlg->m_Image);
					/////////////////////Find Center of Line Laser//////////////////////
					for(y = 0; y < dlg->Height; y++)
					{
						for (x = 0; x < dlg->Width; x++)
						{
							if(DataImage[x*3+dlg->Width*y*3]!=0||DataImage[x*3+dlg->Width*y*3+1]!=0||DataImage[x*3+dlg->Width*y*3+2]!=0)
							{
								SumPixel=SumPixel+x;
								CountPixel++;
							}
						}
						if(CountPixel!=0)
						{
							for (x = 0; x < dlg->Width; x++)
							{
								if(x!=(SumPixel/CountPixel))
								{
									DataImage[x*3+dlg->Width*y*3]=0;
									DataImage[x*3+dlg->Width*y*3+1]=0;
									DataImage[x*3+dlg->Width*y*3+2]=0;
								}
								else
								{
									DataImage[x*3+dlg->Width*y*3]=255;
									DataImage[x*3+dlg->Width*y*3+1]=255;
									DataImage[x*3+dlg->Width*y*3+2]=255;
								}
							}
						}
						SumPixel=0;
						CountPixel=0;
					}
					///////////////////Show Output and Turn off the Light//////////////////
					Sleep(1000);							//
					dlg->m_Video.Show(dlg->m_Image);		//
					dlg->next=FALSE;
					dlg->Serial.sendCommand('f');
					delete TempImage;
					Sleep(1000);							//
				}
				if(dlg->Default_Frame == 0){
					dlg->Default_Frame = 200;
					dlg->Serial.sendCommand('f');
					dlg->next=TRUE;
				}
				break;
			////////////////////////////////////////////////////////////////
			///////////////////////Scan Test///////////////////////
				/*case 2:									//Scan Test
				if(dlg->Default_Frame == 200){
					dlg->Serial.sendCommand('o');
				}
				if(dlg->Default_Frame != 0){
					dlg->Default_Frame--;
					dlg->Serial.sendCommand('r');
					Sleep(500);
					dlg->m_Video.Capture(dlg->m_Image);
						//////////////////////Find Red/////////////////////////////////
						DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
						dlg->Height=dlg->m_Video.GetHeight();
						dlg->Width=dlg->m_Video.GetWidth();
						for(y = 0; y < dlg->Height; y++)
						{
							for (x = 0; x < dlg->Width; x++)
							{
								if(DataImage[x*3+dlg->Width*y*3+2]>100 && DataImage[x*3+dlg->Width*y*3]<50 && DataImage[x*3+dlg->Width*y*3+1]<50)
								{	DataImage[x*3+dlg->Width*y*3+2]=255;}	
								else
								{
									DataImage[x*3+dlg->Width*y*3]=0;
									DataImage[x*3+dlg->Width*y*3+1]=0;
									DataImage[x*3+dlg->Width*y*3+2]=0;
								}
							}
						}
					dlg->m_Video.Show(dlg->m_Image);
					dlg->next=FALSE;
				}
				if(dlg->Default_Frame == 0){
					dlg->Default_Frame = 200;
					dlg->Serial.sendCommand('f');
					dlg->next=TRUE;
				}
				break;*/

				case 3:									//Close Test
				dlg->Default_Frame = 200;
				dlg->Serial.sendCommand('f');
				dlg->next=TRUE;
				break;
			//////////////////////////serial port////////////////
				case 4:									//Rotate Right
				if(dlg->Default_Frame != 0){			
					dlg->Default_Frame--;
					dlg->Serial.sendCommand('r');
					Sleep(500);
					dlg->next=FALSE;
				}
				if(dlg->Default_Frame == 0){
					dlg->Default_Frame = 200;
				}
				break;

				case 5:									//Rotate Left
				if(dlg->Default_Frame != 0){
					dlg->Default_Frame--;
					dlg->Serial.sendCommand('l');
					Sleep(500);
					dlg->next=FALSE;
				}
				if(dlg->Default_Frame == 0){
					dlg->Default_Frame = 200;
				}
				break;
			///////////////////////////Threshold/////////////////////
			//////////////////////Arrange from B . G . R ////////////	
				case 6:
				dlg->m_Video.Capture(dlg->m_Image);
				DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
				dlg->Height=dlg->m_Video.GetHeight();
				dlg->Width=dlg->m_Video.GetWidth();
				for(y = 0; y < dlg->Height; y++)
				{
					for (x = 0; x < dlg->Width; x++)
					{
						if(DataImage[x*3+dlg->Width*y*3]>=100){DataImage[x*3+dlg->Width*y*3]=255;}
						if(DataImage[x*3+dlg->Width*y*3]<100){DataImage[x*3+dlg->Width*y*3]=0;}
						if(DataImage[x*3+1+dlg->Width*y*3]>=100){DataImage[x*3+1+dlg->Width*y*3]=255;}
						if(DataImage[x*3+1+dlg->Width*y*3]<100){DataImage[x*3+1+dlg->Width*y*3]=0;}
						if(DataImage[x*3+2+dlg->Width*y*3]>=100){DataImage[x*3+2+dlg->Width*y*3]=255;}
						if(DataImage[x*3+2+dlg->Width*y*3]<100){DataImage[x*3+2+dlg->Width*y*3]=0;}
					}
					x=0;
				}
				dlg->m_Video.Show(dlg->m_Image);
				dlg->next=TRUE;
				break;
	
			/////////////////////Image Processing////////////////////
			///////////////////////Find Red//////////////////////////
			///////////////Want Color Space//////////////////////////
				case 7:
				dlg->m_Video.Capture(dlg->m_Image);
				DataImage = (BYTE *)dlg->m_Video.GetDataPointer(dlg->m_Image);
				dlg->Height=dlg->m_Video.GetHeight();
				dlg->Width=dlg->m_Video.GetWidth();
				for(y = 0; y < dlg->Height; y++)
				{
					for (x = 0; x < dlg->Width; x++)
					{
						if(DataImage[x*3+dlg->Width*y*3]==255 && DataImage[x*3+dlg->Width*y*3+1]==113 && DataImage[x*3+dlg->Width*y*3+2]==58)
						{	
							DataImage[x*3+dlg->Width*y*3]=255;
							DataImage[x*3+dlg->Width*y*3+1]=0;
							DataImage[x*3+dlg->Width*y*3+2]=0;
						}
						else
						{
							DataImage[x*3+dlg->Width*y*3]=0;
							DataImage[x*3+dlg->Width*y*3+1]=0;
							DataImage[x*3+dlg->Width*y*3+2]=0;
						}
					}
				}
				dlg->m_Video.Show(dlg->m_Image);
				dlg->next=TRUE;
				break;
			
			///////////////////////////////////////////////////
			}

			// show result from VideoOCXTools - function 
			//		(Only if VideoOCXTools was successful)
	// leave time for other processes
		Sleep(5);		
	}

	// End Thread
	return(0);
}

void CMy3DReconstructionDlg::OnCapture() 
{
	m_Video.SetPreview(FALSE);
	m_ToolNumber = 0;
	next=FALSE;
}

void CMy3DReconstructionDlg::OnStart()
{
	Serial.Connect(1);
	if (m_Image != 0)
		return;
	
	m_Video.SetErrorMessages(0);

	if (!m_Video.Init())
	{
		// Error while trying to init control
		
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
		return;		// exit
	}
	m_Video.SetPreview(TRUE);

	// allocate memory for all images that will be needed to demonstrate VideoOCXTools - features
	//   Make sure you free the resources later using VideoOCX::ReleaseImageHandle(long).
	m_Image = m_Video.GetColorImageHandle();
	m_ResultImage = m_Video.GetColorImageHandle();
	m_HelperImage = m_Video.GetColorImageHandle();
	m_GrayImage = m_Video.GetGrayImageHandle();
	m_ToolNumber = -1;
	next = FALSE;

	Sleep(100);		// make sure VideoOCX has time to be properly initialized

	// Start capture thread	

	if (m_Video.Start())						// start capture mode
	{		
		m_Running = TRUE;
		AfxBeginThread(CaptureThread, this);	// start capture thread
	}
	else
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);
	}
}

HICON CMy3DReconstructionDlg::OnQueryDragIcon(void)
{
	return (HCURSOR) m_hIcon;
}

void CMy3DReconstructionDlg::OnLight() 
{
	if (light == FALSE){				// Show Light (True mean light on)
	Serial.sendCommand('o');
	light = TRUE;
	}
	else {
	Serial.sendCommand('f');
	light = FALSE;
	}
}

void CMy3DReconstructionDlg::OnThreshold() 
{
	m_Video.SetPreview(FALSE);
	m_ToolNumber = 6;
	next=FALSE;
}

void CMy3DReconstructionDlg::OnRotateR() 
{
	m_ToolNumber = 4;
	next=FALSE;
}

void CMy3DReconstructionDlg::OnRotateL() 
{
	m_ToolNumber = 5;
	next=FALSE;
}

void CMy3DReconstructionDlg::OnScanTest() 
{
	m_Video.SetPreview(FALSE);
	m_ToolNumber = 1;
	next=FALSE;
}

void CMy3DReconstructionDlg::OnStopScan() 
{
	m_ToolNumber = 3;
	next=FALSE;
}

void CMy3DReconstructionDlg::OnPreview() 
{
	m_Video.SetPreview(TRUE);
}

void CMy3DReconstructionDlg::OnInfo() 
{
	if (!m_Video.ShowInfoDlg())
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);		
	}
}

void CMy3DReconstructionDlg::OnFormat() 
{
	m_Video.Stop();
	if (!m_Video.ShowFormatDlg())
	{
		// error
		MessageBox(m_Video.GetLastErrorString(), "VideoOCX Error", MB_OK);		
	}
	m_Video.ReleaseImageHandle(m_Image);
	m_Image = m_Video.GetColorImageHandle();
	m_Video.Start();
}

