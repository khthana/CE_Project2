// RF.cpp: implementation of the CRF class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RF.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

char five[] = {0x55,0x55,0x55,0x55,0x55};
char ff[] = {0xff};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRF::CRF()
{

}

CRF::~CRF()
{

}

BOOL CRF::Connect(int comPort)
{
  try
  {

    CSerialPort::GetDefaultConfig(1, config);

    port.Open(comPort, 9600, CSerialPort::NoParity, 8, CSerialPort::OneStopBit,CSerialPort::XonXoffFlowControl);

   HANDLE hPort = port.Detach();
    port.Attach(hPort);
	
    DWORD dwModemStatus;
    port.GetModemStatus(dwModemStatus);

    DCB dcb;
    port.GetState(dcb);

    dcb.BaudRate = 9600;
    port.SetState(dcb);    

    DWORD dwErrors;                      
    port.ClearError(dwErrors);

    port.SetBreak();
    port.ClearBreak();

    COMSTAT stat;
    port.GetStatus(stat);

    COMMTIMEOUTS timeouts;
    port.GetTimeouts(timeouts);

    port.Setup(10000, 10000);

    port.GetConfig(config);

    config.dcb.BaudRate = 9600;
    port.SetConfig(config);

    port.Set0WriteTimeout();
    port.Set0ReadTimeout();

	return TRUE;
  }
  catch (CSerialException* pEx)
  {
    TRACE(_T("Handle Exception, Message:%s\n"), pEx->GetErrorMessage());
    pEx->Delete();
	return FALSE;
  }
}

BOOL CRF::Disconnect()
{
	try
	{
		port.Close();
		return TRUE;
	}
	catch(CSerialException* pEx)
	{
		TRACE(_T("Handle Exception, Message:%s\n"), pEx->GetErrorMessage());
		pEx->Delete();
		return FALSE;
	}
}

void CRF::sendCommand(char ch)
{
	char com[1];
	com[0] = ch;
	port.Write(com,1);
}



void CRF::SetDTR()
{
	port.SetDTR();
}

void CRF::ClearDTR()
{
	port.ClearDTR();
}

void CRF::Clear()
{
	port.ClearWriteBuffer();
	port.ClearReadBuffer();
}