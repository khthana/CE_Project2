// VerifyStep.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "VerifyStep.h"
#include "SignAndVerify.h"
#include <olectl.h>
#include <ole2.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVerifyStep dialog


CVerifyStep::CVerifyStep(CWnd* pParent /*=NULL*/)
	: CDialog(CVerifyStep::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVerifyStep)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CVerifyStep::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVerifyStep)
	DDX_Control(pDX, IDC_VERIFYPIC, m_VerifyPic);
	DDX_Control(pDX, IDC_SUBJECT2, m_Subject);
	DDX_Control(pDX, IDC_ISSUER2, m_Issuer);
	DDX_Control(pDX, IDC_KEYFM2, m_KeyFm);
	DDX_Control(pDX, IDC_KEYTO2, m_KeyTo);
	DDX_Control(pDX, IDC_HASH2, m_Hash);
	DDX_Control(pDX, IDC_SIGN2, m_Sign);
	DDX_Control(pDX, IDC_SIGNFM2, m_SignFm);
	DDX_Control(pDX, IDC_SIGNTO2, m_SignTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CVerifyStep, CDialog)
	//{{AFX_MSG_MAP(CVerifyStep)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVerifyStep message handlers

void CVerifyStep::getDoc(CIsagsignv2Doc* pDocument)
{
	pDoc = pDocument;
}

BOOL CVerifyStep::OnInitDialog() 
{
	CDialog::OnInitDialog();
	// show detail of signing to dialog
	m_Subject.SetWindowText(pDoc->currentSigner.getSignerInfo().SignerName);
	m_Issuer.SetWindowText(pDoc->currentSigner.getSignerInfo().IssuerName);
	m_KeyFm.SetWindowText(pDoc->currentSigner.getSignerInfo().IssueDate.FormatGmt("%d %A %B %Y"));
	m_KeyTo.SetWindowText(pDoc->currentSigner.getSignerInfo().RevocationDate.FormatGmt("%d %A %B %Y"));
	m_Hash.SetWindowText(pDoc->currentSigner.getHashAlgorithm());
	m_Sign.SetWindowText(pDoc->currentSigner.getSignDate().FormatGmt("%d %A %B %Y"));
	m_SignFm.SetWindowText(pDoc->currentSigner.getCertFrom().FormatGmt("%d %A %B %Y"));
	m_SignTo.SetWindowText(pDoc->currentSigner.getCertTo().FormatGmt("%d %A %B %Y"));
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CVerifyStep::OnButton1() 
{
	exit(0);	
}

void CVerifyStep::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// check the result 
	if(result == 1){ // Unmodified
		bmLtOff.LoadBitmap(IDB_UNMODIFIED);
		m_VerifyPic.SetBitmap( bmLtOff);
	}
	else if(result == 2){ // Modified
		bmLtOff.LoadBitmap(IDB_MODIFIED);
		m_VerifyPic.SetBitmap( bmLtOff);
	}
	else if(result == 3){ // Expired Signature
		bmLtOff.LoadBitmap(IDB_EXPIRED);
		m_VerifyPic.SetBitmap( bmLtOff);
		m_Subject.SetWindowText("-");
		m_Issuer.SetWindowText("-");
		m_KeyFm.SetWindowText("-");
		m_KeyTo.SetWindowText("-");
		m_Hash.SetWindowText("-");
		m_Sign.SetWindowText("-");
	}
	else if(result == 4){ // Invalid Time(early)
		bmLtOff.LoadBitmap(IDB_EARLY);
		m_VerifyPic.SetBitmap( bmLtOff);
		m_Subject.SetWindowText("-");
		m_Issuer.SetWindowText("-");
		m_KeyFm.SetWindowText("-");
		m_KeyTo.SetWindowText("-");
		m_Hash.SetWindowText("-");
		m_Sign.SetWindowText("-");
	}
	else if(result == 5){// Expired Certificate
		bmLtOff.LoadBitmap(IDB_EXPIRED_CERT);
		m_VerifyPic.SetBitmap( bmLtOff);
		m_Subject.SetWindowText("-");
		m_Issuer.SetWindowText("-");
		m_Hash.SetWindowText("-");
		m_Sign.SetWindowText("-");
		m_SignFm.SetWindowText("--");
		m_SignTo.SetWindowText("--");
	}
	// Do not call CDialog::OnPaint() for painting messages
}

void CVerifyStep::setResult(int r)
{
	result = r;
}
