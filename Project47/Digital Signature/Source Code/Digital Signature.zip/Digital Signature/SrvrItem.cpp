// SrvrItem.cpp : implementation of the CIsagsignv2SrvrItem class
//

#include "stdafx.h"
#include "Isagsign v2.h"

#include "Isagsign v2Doc.h"
#include "SrvrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2SrvrItem implementation

IMPLEMENT_DYNAMIC(CIsagsignv2SrvrItem, COleServerItem)

CIsagsignv2SrvrItem::CIsagsignv2SrvrItem(CIsagsignv2Doc* pContainerDoc)
	: COleServerItem(pContainerDoc, TRUE)
{
	// TODO: add one-time construction code here
	//  (eg, adding additional clipboard formats to the item's data source)
}

CIsagsignv2SrvrItem::~CIsagsignv2SrvrItem()
{
	// TODO: add cleanup code here
}

void CIsagsignv2SrvrItem::Serialize(CArchive& ar)
{
	// CIsagsignv2SrvrItem::Serialize will be called by the framework if
	//  the item is copied to the clipboard.  This can happen automatically
	//  through the OLE callback OnGetClipboardData.  A good default for
	//  the embedded item is simply to delegate to the document's Serialize
	//  function.  If you support links, then you will want to serialize
	//  just a portion of the document.

	if (!IsLinkedItem())
	{
		CIsagsignv2Doc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		pDoc->Serialize(ar);
	}
}

BOOL CIsagsignv2SrvrItem::OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize)
{
	// Most applications, like this one, only handle drawing the content
	//  aspect of the item.  If you wish to support other aspects, such
	//  as DVASPECT_THUMBNAIL (by overriding OnDrawEx), then this
	//  implementation of OnGetExtent should be modified to handle the
	//  additional aspect(s).

	if (dwDrawAspect != DVASPECT_CONTENT)
		return COleServerItem::OnGetExtent(dwDrawAspect, rSize);

	// CIsagsignv2SrvrItem::OnGetExtent is called to get the extent in
	//  HIMETRIC units of the entire item.  The default implementation
	//  here simply returns a hard-coded number of units.

	CIsagsignv2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	rSize = CSize(6450, 1490);   // 3000 x 3000 HIMETRIC units

	return TRUE;
}

BOOL CIsagsignv2SrvrItem::OnDraw(CDC* pDC, CSize& rSize)
{
	// Remove this if you use rSize
//	UNREFERENCED_PARAMETER(rSize);

	CIsagsignv2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// check that signing completed
	if(pDoc->currentSigner.getSignStatus() == 1){
		BITMAP bmp;
		CBitmap pic;

		if(pDoc->currentSigner.getPictureNumber() == 1){
			pic.LoadBitmap(IDB_SIG1);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 2){
			pic.LoadBitmap(IDB_SIG2);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 3){
			pic.LoadBitmap(IDB_SIG3);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 4){
			pic.LoadBitmap(IDB_SIG4);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 5){
			pic.LoadBitmap(IDB_SIG5);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 6){
			pic.LoadBitmap(IDB_SIG6);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 7){
			pic.LoadBitmap(IDB_SIG7);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 8){
			pic.LoadBitmap(IDB_SIG8);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 9){
			pic.LoadBitmap(IDB_SIG9);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 10){
			pic.LoadBitmap(IDB_SIG10);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 11){
			pic.LoadBitmap(IDB_SIG11);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 12){
			pic.LoadBitmap(IDB_SIG12);
			pic.GetObject(sizeof(BITMAP) , &bmp);
			pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
		}

	}
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2SrvrItem diagnostics

#ifdef _DEBUG
void CIsagsignv2SrvrItem::AssertValid() const
{
	COleServerItem::AssertValid();
}

void CIsagsignv2SrvrItem::Dump(CDumpContext& dc) const
{
	COleServerItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
