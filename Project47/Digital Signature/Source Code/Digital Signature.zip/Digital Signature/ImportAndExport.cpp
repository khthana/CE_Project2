// ImportAndExport.cpp: implementation of the ImportAndExport class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Isagsign v2.h"
#include "ImportAndExport.h"
#include "FileDlg.h"

#define MY_ENCODING_TYPE  (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING)
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ImportAndExport::ImportAndExport()
{

}

ImportAndExport::~ImportAndExport()
{

}

void ImportAndExport::Export_Cert(CString userName)
{
	HCERTSTORE         hSystemStore;
	PCCERT_CONTEXT     pCertContext = NULL;
	BYTE*              pbElement;
	DWORD              cbElement;
	char systemProtocol[256] = "MY";

	//--------------------------------------------------------------------
	// Open a system certificate store.

	if(hSystemStore = CertOpenSystemStore(
		NULL,
		systemProtocol))
	{
//	  AfxMessageBox("The CA system store is open. Continue.\n");
	}
	else
	{
	  HandleError("The first system store did not open.");
	}
	//--------------------------------------------------------------------
	// Retrieve the first certificate from the Root store.
	// CertFindCertificateInStore could be used here to find
	// a certificate with a specific property.

	while(pCertContext = CertEnumCertificatesInStore(hSystemStore, pCertContext)){
		if(GetCertificateSubject(&(pCertContext->pCertInfo->Subject)) == userName) break;
	}

	//--------------------------------------------------------------------
	// Find out how much memory to allocate for the serialized element.

	if(CertSerializeCertificateStoreElement(
		pCertContext,      // The existing certificate.
		0,                 // Accept default for dwFlags, 
		NULL,              // NULL for the first function call.
		&cbElement))       // Address where the length of the 
						   // serialized element will be placed.
	{
//		 AfxMessageBox("The length of the serialized string is %d.\n",cbElement);
	}
	else
	{
		 HandleError("Finding the length of the serialized element failed.");
	}
	//--------------------------------------------------------------------
	// Allocate memory for the serialized element.

	if(pbElement = (BYTE*)malloc(cbElement))
	{
//		 AfxMessageBox("Memory has been allocated. Continue.\n");
	}
	else
	{
		 HandleError("The allocation of memory failed.");
	}
	//--------------------------------------------------------------------
	// Create the serialized element from a certificate context.

	if(CertSerializeCertificateStoreElement(
		pCertContext,        // The certificate context source for the 
							 // serialized element.
		0,                   // dwFlags. Accept the default.
		pbElement,           // A pointer to where the new element will
							 // be stored.
		&cbElement))         // The length of the serialized element,
	{
//		 AfxMessageBox("The encoded element has been serialized. \n");
	}
	else
	{
		 HandleError("The element could not be serialized.");
	}
	//--------------------------------------------------------------------
	//  pbElement could be written to a file or be sent by e-mail
	//  to another user. 
	//  The following process uses the serialized 
	//  pbElement and its length, cbElement, to 
	//  add a new certificate to a store.


	char filter[] = "Personal Information Exchange (*.pfx) |*.pfx||";
	FileDlg f1(FALSE, "pfx", NULL, NULL, filter);
	if(f1.DoModal() == IDOK){
		CStdioFile file(f1.GetPathName(),
			CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
		file.Write(pbElement, cbElement);
		file.Close();
	}
	
	//Free Memory
	free(pbElement);
	CertCloseStore(hSystemStore,0);
}

void ImportAndExport::Import_Cert()
{
	HCERTSTORE         hSystemStore;
	PCCERT_CONTEXT     pCertContext = NULL;
	BYTE*              pbElement = NULL;
	DWORD              cbElement;
	char systemProtocol[256] = "MY";
	BYTE buffer[4097];
	UINT size;


	//--------------------------------------------------------------------
	// Open a system certificate store.

	if(hSystemStore = CertOpenSystemStore(
		NULL,
		systemProtocol))
	{
//	  AfxMessageBox("The CA system store is open. Continue.\n");
	}
	else
	{
	  HandleError("The first system store did not open.");
	}
	
	// Choose file that u want to add in your system
	char filter[] = "Personal Information Exchange (*.pfx) |*.pfx | All File (*.*)|*.*||";
	FileDlg f1(TRUE, NULL, NULL, NULL, filter);
	if(f1.DoModal() == IDOK){
		CStdioFile file(f1.GetPathName(),
		CFile::modeRead | CFile::typeBinary);
		size=file.Read(buffer,4096);
		pbElement=buffer;
		cbElement=size;
		file.Close();
	}	


	if(CertAddSerializedElementToStore(
		hSystemStore,          // Store where certificate is to be added.
		pbElement,           // The serialized element for another
							 // certificate. 
		cbElement,           // The length of pbElement.  
		CERT_STORE_ADD_REPLACE_EXISTING,
		//CERT_STORE_ADD_NEW,
							 // Flag to indicate what to do if a matching
							 // certificate is already in the store.
		0,                   // dwFlags. Accept the default.
		CERT_STORE_CERTIFICATE_CONTEXT_FLAG, 
		NULL,
		NULL
		))
	{
		 AfxMessageBox("The new certificate is added to the second store.\n");
	}
	else
	{
		 HandleError("The new element was not added to a store.");
	}
	
	//Free Memory
	//free(pbElement);
	CertCloseStore(hSystemStore,0);
}

void ImportAndExport::HandleError(char *s)
{
    AfxMessageBox(s);
    exit(1);
} // End of HandleError

CString ImportAndExport::GetCertificateSubject(CERT_NAME_BLOB *nameBlob)
{
	// Declare and initialize local variable here.
	int				t1 = -1 , t2 = -1;		// String separater.
	LPSTR		    pszName;	
	DWORD			cbName;
	DWORD			dwStrType = CERT_OID_NAME_STR;
	
	// The function CertNameToStr returns the number of bytes needed for a string to hold the name.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 NULL,							// Pointer to buffer.
			 0);							// Size of buffer.
	// Allocate the needed buffer.
	pszName = new char[cbName];

	// Call the function again to get the string.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 pszName ,						// Pointer to buffer.
			 cbName);						// Size of buffer.

	// Declare and initialize local variable for tag finding.
	CString	tempStr1(pszName) , tempStr2 , tempStr3 , tempStr4 , tag;
	// If found issuer name in certificate information then certificate can be used.
	t1 = tempStr1.Find("2.5.4.3");								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');
	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx
	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx
	
	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

