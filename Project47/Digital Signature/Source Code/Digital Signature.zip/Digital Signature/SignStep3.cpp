// SignStep3.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SignStep3.h"
#include "Picture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep3 property page

IMPLEMENT_DYNCREATE(CSignStep3, CPropertyPage)

CSignStep3::CSignStep3() : CPropertyPage(CSignStep3::IDD)
{
	//{{AFX_DATA_INIT(CSignStep3)
	m_DateFm = 0;
	m_DateTo = 0;
	//}}AFX_DATA_INIT
}

CSignStep3::~CSignStep3()
{
}

void CSignStep3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep3)
	DDX_Control(pDX, IDC_PICTURE, m_Pic);
	DDX_Control(pDX, IDC_BUTTON1, m_pic);
	DDX_Control(pDX, IDC_DATETIMEPICKER3, m_toCtrl);
	DDX_Control(pDX, IDC_DATETIMEPICKER2, m_fmCtrl);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER2, m_DateFm);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER3, m_DateTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSignStep3, CPropertyPage)
	//{{AFX_MSG_MAP(CSignStep3)
	ON_BN_CLICKED(IDC_RADIO1, OnSha1)
	ON_BN_CLICKED(IDC_RADIO2, OnMd5)
	ON_BN_CLICKED(IDC_RADIO3, OnMd4)
	ON_BN_CLICKED(IDC_BUTTON1, OnChangePic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignStep3 message handlers

BOOL CSignStep3::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// set default value
	picNumber = 1;
	CButton *hashAlgo;
	hashAlgo = (CButton*)GetDlgItem(IDC_RADIO1);
	hashAlgo->SetCheck(TRUE);
	hashAlgo->SetFocus();
	m_hash = "SHA-1";	
	CTime t2 = CTime::GetCurrentTime()+CTimeSpan(1,0,0,0);
	m_fmCtrl.SetTime(&CTime::GetCurrentTime());
	m_toCtrl.SetTime(&t2);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSignStep3::OnSha1() 
{
	m_hash = "SHA-1";
	
}

void CSignStep3::OnMd5() 
{
	m_hash = "MD5";	
	
}

void CSignStep3::OnMd4() 
{
	m_hash = "MD4";	
	
}

BOOL CSignStep3::OnSetActive() 
{
	CPropertySheet* parent = (CPropertySheet*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);	
	return CPropertyPage::OnSetActive();
}

void CSignStep3::OnChangePic() 
{
	// TODO: Add your control notification handler code here
	CPicture picDlg;
	picDlg.setPicNumber(picNumber);
	if(IDOK == picDlg.DoModal())
	picNumber=picDlg.picNumber;
	if(picNumber == 1){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG1);
		m_Pic.SetBitmap( bmPic);
	}
	else if(picNumber == 2){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG2);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 3){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG3);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 4){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG4);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 5){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG5);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 6){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG6);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 7){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG7);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 8){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG8);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 9){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG9);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 10){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG10);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 11){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG11);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 12){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG12);
		m_Pic.SetBitmap( bmPic );
	}

}

void CSignStep3::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	if(picNumber == 1){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG1);
		m_Pic.SetBitmap( bmPic);
	}
	else if(picNumber == 2){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG2);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 3){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG3);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 4){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG4);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 5){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG5);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 6){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG6);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 7){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG7);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 8){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG8);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 9){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG9);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 10){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG10);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 11){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG11);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 12){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG12);
		m_Pic.SetBitmap( bmPic );
	}	// Do not call CPropertyPage::OnPaint() for painting messages
}


