// SignStep4.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SignStep4.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep4 property page

IMPLEMENT_DYNCREATE(CSignStep4, CPropertyPage)

CSignStep4::CSignStep4() : CPropertyPage(CSignStep4::IDD)
{
	//{{AFX_DATA_INIT(CSignStep4)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CSignStep4::~CSignStep4()
{
}

CSignStep4::CSignStep4(CSignStep2* m_p2,CSignStep3* m_p3)
{
	m_page2 = m_p2;
	m_page3 = m_p3;
}

void CSignStep4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep4)
	DDX_Control(pDX, IDC_SUBJECT, m_Subject);
	DDX_Control(pDX, IDC_ISSUER, m_Issuer);
	DDX_Control(pDX, IDC_KEYFM, m_KeyFm);
	DDX_Control(pDX, IDC_KEYTO, m_KeyTo);
	DDX_Control(pDX, IDC_HASH, m_Hash);
	DDX_Control(pDX, IDC_SIGN, m_Sign);
	DDX_Control(pDX, IDC_SIGNFM, m_SignFm);
	DDX_Control(pDX, IDC_SIGNTO, m_SignTo);
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSignStep4, CPropertyPage)
	//{{AFX_MSG_MAP(CSignStep4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignStep4 message handlers

BOOL CSignStep4::OnSetActive() 
{
	// show detail of signing to dialog
    CPropertySheet* parent = (CPropertySheet*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
	m_Subject.SetWindowText(m_page2->signer.SignerName);
	m_Issuer.SetWindowText(m_page2->signer.IssuerName);
	m_KeyFm.SetWindowText(m_page2->signer.IssueDate.FormatGmt("%d %A %B %Y"));
	m_KeyTo.SetWindowText(m_page2->signer.RevocationDate.FormatGmt("%d %A %B %Y"));
	m_Hash.SetWindowText(m_page3->m_hash);
	m_Sign.SetWindowText(CTime::GetCurrentTime().FormatGmt("%d %A %B %Y"));
	m_SignFm.SetWindowText(m_page3->m_DateFm.FormatGmt("%d %A %B %Y"));
	m_SignTo.SetWindowText(m_page3->m_DateTo.FormatGmt("%d %A %B %Y"));
	
	return CPropertyPage::OnSetActive();
}

void CSignStep4::SetPage(CSignStep2* m_p2,CSignStep3* m_p3)
{
	m_page2 = m_p2;
	m_page3 = m_p3;
}
