// SignatureInformation.cpp: implementation of the SignatureInformation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SignatureInformation.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL (SignatureInformation, CObject, 1);

SignatureInformation::SignatureInformation()
{
	signerInfo.SignerName = "NULL";
	signerInfo.IssuerName = "NULL";
	hashAlgo = "SHA-1";
	pbSignatureLen = 0;
	pbSignature = NULL;
	picNumber = 0; // default number of picture
	signStatus = 0; // new signature

}

SignatureInformation::SignatureInformation(const SignatureInformation& sourceInfo)
{
	signerInfo = sourceInfo.signerInfo;
	hashAlgo = sourceInfo.hashAlgo;
	certFrom = sourceInfo.certFrom;
	certTo = sourceInfo.certTo;
	hashAlgo = sourceInfo.hashAlgo;
	signDate = sourceInfo.signDate;
	pbSignatureLen = sourceInfo.pbSignatureLen;
	pbSignature = new BYTE[pbSignatureLen];
	CopyMemory(pbSignature, sourceInfo.pbSignature, pbSignatureLen);
}

SignatureInformation::~SignatureInformation()
{
	delete [] pbSignature;
}

void SignatureInformation::Serialize(CArchive &ar)
{
	CObject::Serialize(ar);
	if(ar.IsStoring())	{
		ar << signerInfo.SignerName;
		ar << signerInfo.IssuerName;
		ar << signerInfo.IssueDate;
		ar << signerInfo.RevocationDate;
		ar << signDate;
		ar << certFrom;
		ar << certTo;
		ar << hashAlgo;
		ar << pbSignatureLen;
		ar.Write(pbSignature, pbSignatureLen);
		ar << picNumber;
		ar << signStatus;
	}
	else {
		ar >> signerInfo.SignerName;
		ar >> signerInfo.IssuerName;
		ar >> signerInfo.IssueDate;
		ar >> signerInfo.RevocationDate;
		ar >> signDate;
		ar >> certFrom;
		ar >> certTo;
		ar >> hashAlgo;
		ar >> pbSignatureLen;
		pbSignature = new BYTE[pbSignatureLen];
		ar.Read(pbSignature, pbSignatureLen);
		ar >> picNumber;
		ar >> signStatus;
	}
}

void SignatureInformation::setSignerInfo(SignerInformation sourceInfo)
{
	this->signerInfo.SignerName = sourceInfo.SignerName;
	this->signerInfo.IssuerName = sourceInfo.IssuerName;
	this->signerInfo.IssueDate = sourceInfo.IssueDate;
	this->signerInfo.RevocationDate = sourceInfo.RevocationDate;
}

void SignatureInformation::setHashAlgorithm(CString hashAlgo)
{
	this->hashAlgo = hashAlgo;
}


void SignatureInformation::setSignDate(CTime signDate)
{
	this->signDate = signDate;
}

void SignatureInformation::setCertDuration(CTime fm, CTime to)
{
	this->certFrom = fm;
	this->certTo = to;
}

void SignatureInformation::setPbSignatureBlob(BYTE* pbSig, UINT pbSigLen)
{
	this->pbSignatureLen = pbSigLen;
	this->pbSignature = new BYTE[pbSigLen];
	CopyMemory(pbSignature, pbSig, pbSignatureLen);
}

void SignatureInformation::setPictureNumber(int i)
{
	picNumber = i;
}

void SignatureInformation::setPbSignatureLen(UINT pbSigLen)
{
	this->pbSignatureLen = pbSigLen;
}

void SignatureInformation::setSignStatus(int status)
{
	signStatus = status;
}

SignerInformation SignatureInformation::getSignerInfo()
{
	return this->signerInfo;
}

CString SignatureInformation::getHashAlgorithm()
{
	return this->hashAlgo;
}


CTime SignatureInformation::getSignDate()
{
	return this->signDate;
}

CTime SignatureInformation::getCertFrom()
{
	return this->certFrom;
}

CTime SignatureInformation::getCertTo()
{
	return this->certTo;
}

BYTE* SignatureInformation::getPbSignatureBlob()
{
	return this->pbSignature;
}

UINT SignatureInformation::getPbSignatureBlobLength()
{
	return this->pbSignatureLen;
}

int SignatureInformation::getPictureNumber()
{
	return picNumber;
}

int SignatureInformation::getSignStatus()
{
	return signStatus;
}