// SignSheet.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SignSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignSheet

IMPLEMENT_DYNAMIC(CSignSheet, CPropertySheet)

CSignSheet::CSignSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CSignSheet::CSignSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
}

CSignSheet::~CSignSheet()
{
}


BEGIN_MESSAGE_MAP(CSignSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CSignSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignSheet message handlers
