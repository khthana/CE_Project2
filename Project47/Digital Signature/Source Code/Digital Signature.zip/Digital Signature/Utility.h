struct SignerInformation 
{
	CString SignerName;
	CString IssuerName;
	CTime IssueDate;
	CTime RevocationDate;
};
