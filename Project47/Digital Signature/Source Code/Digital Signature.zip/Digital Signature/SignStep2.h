#if !defined(AFX_SIGNSTEP2_H__F628D924_33BF_46D9_8F05_FE7D08C42B0F__INCLUDED_)
#define AFX_SIGNSTEP2_H__F628D924_33BF_46D9_8F05_FE7D08C42B0F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SignStep2.h : header file
//


#include "CertStore.h"
/////////////////////////////////////////////////////////////////////////////
// CSignStep2 dialog

class CSignStep2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSignStep2)

// Construction
public:
	CSignStep2();
	~CSignStep2();
	SignerInformation* signerList;
	CCertStore* cert;
	SignerInformation signer;
	int count;

// Dialog Data
	//{{AFX_DATA(CSignStep2)
	enum { IDD = IDD_DIALOG2 };
	CListCtrl	m_Cstep2;
	CStatic m_Subject;
	CStatic m_Issuer;
	CStatic m_ValidFm;
	CStatic m_ValidTo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSignStep2)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSignStep2)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNSTEP2_H__F628D924_33BF_46D9_8F05_FE7D08C42B0F__INCLUDED_)
