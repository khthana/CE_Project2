#if !defined(AFX_EXPORTDLG_H__B16C3B00_9CD6_4FFE_BC6D_2763FB358219__INCLUDED_)
#define AFX_EXPORTDLG_H__B16C3B00_9CD6_4FFE_BC6D_2763FB358219__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExportDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ExportDlg dialog
#include "CertStore.h"

class ExportDlg : public CDialog
{
// Construction
public:
	ExportDlg(CWnd* pParent = NULL);   // standard constructor
	CCertStore* cert;
	SignerInformation* signerList;
	SignerInformation signer;

// Dialog Data
	//{{AFX_DATA(ExportDlg)
	enum { IDD = IDD_CERT_EXPORT };
	CComboBox	m_comboExport;
	int		m_Export;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ExportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ExportDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPORTDLG_H__B16C3B00_9CD6_4FFE_BC6D_2763FB358219__INCLUDED_)
