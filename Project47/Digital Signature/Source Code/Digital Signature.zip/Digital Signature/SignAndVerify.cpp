// SignAndVerify.cpp: implementation of the SignAndVerify class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SignAndVerify.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SignAndVerify::SignAndVerify()
{
	if(!CryptAcquireContext(
		&hProv,
		"ISAGSIGN",
		NULL,
		PROV_RSA_FULL,
		NULL
		))
	{
		CryptAcquireContext(
		&hProv,
		"ISAGSIGN",
		NULL,
		PROV_RSA_FULL,
		CRYPT_NEWKEYSET
		);
	}
	
	digitalSignature = NULL;
	
}

SignAndVerify::~SignAndVerify()
{
	CryptReleaseContext(hProv, 0);
	if(digitalSignature != NULL)
		delete [] digitalSignature;
}

void SignAndVerify::FindHashValue(BYTE* dataStream, UINT dataStreamLen, CString hashAlgo)
{
	//choose algorithm
	if(hashAlgo = "MD4")
		CryptCreateHash(hProv, CALG_MD4, 0, 0, &hHash);
	if(hashAlgo = "MD5")
		CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash);
	if(hashAlgo = "SHA-1")
		CryptCreateHash(hProv, CALG_SHA, 0, 0, &hHash);

	//create hash 
	CryptHashData(hHash, dataStream, dataStreamLen, 0);
}	

void SignAndVerify::ConvertToHashValue()
{
	BYTE	*pbHash = NULL;
	DWORD	dwHashLen = sizeof(DWORD);
	DWORD	index;
	CString hashDigit;

	CryptGetHashParam(hHash, HP_HASHVAL, pbHash, &dwHashLen, 0);

	pbHash = (BYTE*)malloc(dwHashLen);

	if(CryptGetHashParam(hHash, HP_HASHVAL, pbHash, &dwHashLen, 0)){
		for(index = 0; index < dwHashLen; index++)
		{
			hashDigit.Format("%2.2x ", pbHash[index]);
			//create hashValue from hHash
			hashValue = hashValue + hashDigit;
		}
	}
	else {
		/*error Handle*/
	}

	delete pbHash;
}

CString SignAndVerify::GetHashValue()
{
	return hashValue;
}

UINT SignAndVerify::GetDigitalSignatureLen()
{
	return digitalSignatureLen;
}

BYTE* SignAndVerify::GetDigitalSignature()
{
	return digitalSignature;
}

BOOL SignAndVerify::SignSignature(BYTE* hashStream, UINT hashStreamLen, CString userName)
{
	HCERTSTORE					hStoreHandle;
	PCCERT_CONTEXT				pSignerCert = NULL;
	CRYPT_SIGN_MESSAGE_PARA		SignParam;
	DWORD						cbSignedMessageBlob;
	BYTE						*pbSignedMessageBlob;
	char systemProtocol[256] = "MY";
	const BYTE *messageArray[] = {hashStream};
	DWORD messageSize[1] = {hashStreamLen};

	// Open Certificate Store
	hStoreHandle = CertOpenSystemStore(NULL, systemProtocol);
	// find Certificate that is chosen by user
	while(pSignerCert = CertEnumCertificatesInStore(hStoreHandle, pSignerCert)){
		if(GetCertificateSubject(&(pSignerCert->pCertInfo->Subject)) == userName) break;
	}
	// assign default value of SignParam  
	SignParam.cbSize = sizeof(CRYPT_SIGN_MESSAGE_PARA);
	SignParam.dwMsgEncodingType = MY_ENCODE_TYPE;
	SignParam.pSigningCert = pSignerCert;
	SignParam.HashAlgorithm.pszObjId = szOID_RSA_MD5;
	SignParam.HashAlgorithm.Parameters.cbData = NULL;
	SignParam.cMsgCert = 1;
	SignParam.rgpMsgCert = &pSignerCert;
	SignParam.cAuthAttr = 0;
	SignParam.dwInnerContentType = 0;
	SignParam.cMsgCrl = 0;
	SignParam.cUnauthAttr = 0;
	SignParam.dwFlags = 0;
	SignParam.pvHashAuxInfo = NULL;
	SignParam.rgAuthAttr = NULL;
	
	// find size of digital signature
	if(!CryptSignMessage(
		&SignParam,
		FALSE,
		1,
		messageArray,
		messageSize,
		NULL,
		&cbSignedMessageBlob)){return FALSE;}
	// allocate memory for pbSignedMessageBlob
	pbSignedMessageBlob = new BYTE[cbSignedMessageBlob];
	// assign value for pbSignedMessageBlob
	if(!CryptSignMessage(
		&SignParam,
		FALSE,
		1,
		messageArray,
		messageSize,
		pbSignedMessageBlob,
		&cbSignedMessageBlob)){return FALSE;}
	// create digital signature from pbSignedMessageBlob
	digitalSignatureLen = cbSignedMessageBlob;
	digitalSignature = new BYTE[digitalSignatureLen];
	CopyMemory(digitalSignature, pbSignedMessageBlob, digitalSignatureLen);
	// free memory
	delete [] pbSignedMessageBlob;
	return TRUE;
}

CString SignAndVerify::GetCertificateSubject(CERT_NAME_BLOB *nameBlob)
{
	// Declare and initialize local variable here.
	int				t1 = -1 , t2 = -1;		// String separater.
	LPSTR		    pszName;	
	DWORD			cbName;
	DWORD			dwStrType = CERT_OID_NAME_STR;
	
	// The function CertNameToStr returns the number of bytes needed for a string to hold the name.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 NULL,							// Pointer to buffer.
			 0);							// Size of buffer.
	// Allocate the needed buffer.
	pszName = new char[cbName];

	// Call the function again to get the string.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 pszName ,						// Pointer to buffer.
			 cbName);						// Size of buffer.

	// Declare and initialize local variable for tag finding.
	CString	tempStr1(pszName) , tempStr2 , tempStr3 , tempStr4 , tag;
	// If found issuer name in certificate information then certificate can be used.
	t1 = tempStr1.Find("2.5.4.3");								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');
	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx
	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx
	
	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

void SignAndVerify::HandleError(CString errorMsg)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Handle the error occured in running the program
	AfxMessageBox(errorMsg , MB_OK);
	exit(1);
}

int SignAndVerify::VerifySignature(BYTE* digitalSig, DWORD digitalSigLen, BYTE* hashMsg)
{
	CRYPT_VERIFY_MESSAGE_PARA	VerifyParam;
	DWORD						cbDecodedMessageBlob;
	BYTE						*pbDecodedMessageBlob;
	// assign default value for VerifyParam
	VerifyParam.cbSize = sizeof(CRYPT_VERIFY_MESSAGE_PARA);
	VerifyParam.dwMsgAndCertEncodingType = MY_ENCODE_TYPE;
	VerifyParam.hCryptProv = 0;
	VerifyParam.pfnGetSignerCertificate = NULL;
	VerifyParam.pvGetArg = NULL;
	// find size of digital signature
	CryptVerifyMessageSignature(
		&VerifyParam,
		0,
		digitalSig,
		digitalSigLen,
		NULL,
		&cbDecodedMessageBlob,
		NULL);
	// allocate memory for pbSignedMessageBlob
	pbDecodedMessageBlob = new BYTE[cbDecodedMessageBlob];
	// assign value for pbSignedMessageBlob
	CryptVerifyMessageSignature(
		&VerifyParam,
		0,
		digitalSig,
		digitalSigLen,
		pbDecodedMessageBlob,
		&cbDecodedMessageBlob,
		NULL);
	// compare hash_value with digital signature
	int result = 1;
	for(UINT i=0; i<cbDecodedMessageBlob; i++){
		if(pbDecodedMessageBlob[i] != hashMsg[i]){
			result = 0;
			break;
		}
	}
	// free memory
	delete [] pbDecodedMessageBlob;
	return result;
}
