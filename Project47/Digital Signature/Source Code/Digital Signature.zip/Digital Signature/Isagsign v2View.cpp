// Isagsign v2View.cpp : implementation of the CIsagsignv2View class
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SignDlg.h"
#include "SignAndVerify.h"
#include "msword8.h"
#include "ExportDlg.h"
#include "ImportAndExport.h"
#include "SignSheet.h"
#include "SignStep1.h"
#include "SignStep2.h"
#include "SignStep3.h"
#include "SignStep4.h"
#include "VerifyStep.h"
#include "SrvrItem.h"

#include "Isagsign v2Doc.h"
#include "Isagsign v2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2View

IMPLEMENT_DYNCREATE(CIsagsignv2View, CView)

BEGIN_MESSAGE_MAP(CIsagsignv2View, CView)
	//{{AFX_MSG_MAP(CIsagsignv2View)
	ON_COMMAND(ID_CANCEL_EDIT_SRVR, OnCancelEditSrvr)
	ON_COMMAND(ID_VERIFY, OnVerify)
	ON_COMMAND(ID_IMPORT, OnImport)
	ON_COMMAND(ID_EXPORT, OnExport)
	ON_COMMAND(ID_SIGN, OnSign)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2View construction/destruction

CIsagsignv2View::CIsagsignv2View()
{
	// TODO: add construction code here
}

CIsagsignv2View::~CIsagsignv2View()
{
}


/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2View drawing

void CIsagsignv2View::OnDraw(CDC* pDC)
{
	CIsagsignv2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	if(pDoc->currentSigner.getSignStatus() == 1){
		BITMAP bmp;
		CBitmap pic;
		if(pDoc->currentSigner.getPictureNumber() == 1){
			pic.LoadBitmap(IDB_SIG1);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 2){
			pic.LoadBitmap(IDB_SIG2);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 3){
			pic.LoadBitmap(IDB_SIG3);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 4){
			pic.LoadBitmap(IDB_SIG4);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 5){
			pic.LoadBitmap(IDB_SIG5);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 6){
			pic.LoadBitmap(IDB_SIG6);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 7){
			pic.LoadBitmap(IDB_SIG7);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 8){
			pic.LoadBitmap(IDB_SIG8);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 9){
			pic.LoadBitmap(IDB_SIG9);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 10){
			pic.LoadBitmap(IDB_SIG10);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 11){
			pic.LoadBitmap(IDB_SIG11);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}
		else if(pDoc->currentSigner.getPictureNumber() == 12){
			pic.LoadBitmap(IDB_SIG12);
			pic.GetObject(sizeof(BITMAP),&bmp);
			pDC->DrawState(CPoint(0,0),CSize(bmp.bmWidth,bmp.bmHeight),pic,DST_BITMAP,NULL);
		}

	}
}

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2View printing

BOOL CIsagsignv2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CIsagsignv2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CIsagsignv2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// OLE Server support

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the server (not the container) causes the deactivation.
void CIsagsignv2View::OnCancelEditSrvr()
{
	GetDocument()->OnDeactivateUI(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2View diagnostics

#ifdef _DEBUG
void CIsagsignv2View::AssertValid() const
{
	CView::AssertValid();
}

void CIsagsignv2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CIsagsignv2Doc* CIsagsignv2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CIsagsignv2Doc)));
	return (CIsagsignv2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2View message handlers

void CIsagsignv2View::OnVerify() 
{
	CIsagsignv2Doc *pDoc = GetDocument();

	if((pDoc->currentSigner.getSignStatus() == 0)|| 
		(pDoc->currentSigner.getSignStatus() == -1)){ // if the signature was signed or error, it can't sign again
			AfxMessageBox("Signing signature was not complete!!\nThis signature cannot be verified.", MB_OK);
		return;
	}

	CString signerName_Ver;
	CString issuerName_Ver;
	CTime issueDate_Ver;
	CTime revocationDate_Ver;
	CString hashAlgo_Ver;
	CTime signDate_Ver;
	CTime   certFrom_Ver;
	CTime   certTo_Ver;
	UINT	sigLen_Ver;
	BYTE*	sig_Ver;
	CTime	currentTime;
	// assign value 
	signerName_Ver = pDoc->currentSigner.getSignerInfo().SignerName;
	issuerName_Ver = pDoc->currentSigner.getSignerInfo().IssuerName;
	issueDate_Ver = pDoc->currentSigner.getSignerInfo().IssueDate;
	revocationDate_Ver = pDoc->currentSigner.getSignerInfo().RevocationDate;
	hashAlgo_Ver = pDoc->currentSigner.getHashAlgorithm();
	signDate_Ver = pDoc->currentSigner.getSignDate();
	certFrom_Ver = pDoc->currentSigner.getCertFrom();
	certTo_Ver = pDoc->currentSigner.getCertTo();
	sigLen_Ver = pDoc->currentSigner.getPbSignatureBlobLength();
	sig_Ver = pDoc->currentSigner.getPbSignatureBlob();

	CVerifyStep dlg;
	// check Expired Certificate
	currentTime = CTime::GetCurrentTime();
	if(revocationDate_Ver < currentTime){
		dlg.getDoc(pDoc);
		dlg.setResult(5);
		dlg.DoModal();
		return;
	}
	// check Expired Signature
	if((certFrom_Ver != NULL)&&(certTo_Ver != NULL))
		if(currentTime >= certTo_Ver){
			dlg.getDoc(pDoc);
			dlg.setResult(3);
			dlg.DoModal();
			return;
		}
		else if(currentTime <= certFrom_Ver){ 
			dlg.getDoc(pDoc);
			dlg.setResult(4);
			dlg.DoModal();
			return;
		}
	UINT dataLen;
	BYTE* data;
	// read data from document which will sign.
	data = GetDataBlock(dataLen);
	BYTE* temp = new BYTE[dataLen];
	int count=0;
	int num=0;
	int pos=0;
	pos=0;
	// ****************************** decode data *****************************************************************************
	for(int i=count;i<(int)dataLen;i++){
		if(((data[i]=='i')&&(data[i+1]=='n')&&(data[i+2]=='s')&&(data[i+3]=='r')&&
			(data[i+4]=='s')&&(data[i+5]=='i')&&(data[i+6]=='d')) ||
			((data[i]=='\\')&&(data[i+1]=='a')&&(data[i+2]=='f')&&(data[i+3]=='2')&&
			(data[i+5]==' ')&&(data[i+6]=='\\')))
		{
			if((data[i]=='i')&&(data[i+1]=='n')&&(data[i+2]=='s')&&(data[i+3]=='r')&&
			(data[i+4]=='s')&&(data[i+5]=='i')&&(data[i+6]=='d'))
			{
				for(int k=i-1;k>0;k--){
				if((data[k]>=48)&&(data[k]<=57)&&(data[k-1]>=48)&&(data[k-1]<=57)&&
					(data[k-2]>=48)&&(data[k-2]<=57)&&(data[k-3]=='f'))k=k-5;
				if((data[k]!=13)&&(data[k]!=10)) temp[pos++]=data[k];
				if(data[k]==' ') break;
				}
			}
			count=1;
			for(int j=i+7;j<(int)dataLen;j++){
				if((data[j]=='\\')||(data[j]==' ')){
					for(int k=j+1;k<(int)dataLen;k++)
					{
							if (((data[k]=='{')&&(data[k+1]=='\\')&&(data[k+2]=='s')&&(data[k+3]=='p')) ||
							((data[k]=='{')&&(data[k+1]=='\\')&&(data[k+2]=='s')&&(data[k+3]=='n')) ||
							((data[k]=='{')&&(data[k+1]=='\\')&&(data[k+2]=='s')&&(data[k+3]=='v')) ||
							((data[k]=='{') && (data[k+1]=='\\') && (data[k+2]=='s') && (data[k+3]=='h') &&
							(data[k+4]=='p') && (data[k+5]=='r')&& (data[k+6]=='s')&& (data[k+7]=='l')&& (data[k+8]=='t')))
							{		num=0;
									k++;
									for(int l=k;l<(int)dataLen;l++){
									if(data[l]=='{')  num++;
									if(data[l]=='}')  num--;
									if(num<0) {k=l;break;}
								}
							}	
							else if((data[k]=='{') && (data[k+1]=='\\') && (data[k+2]=='o') && (data[k+3]=='b') &&
									(data[k+4]=='j') && (data[k+5]=='e') && (data[k+6]=='c') && (data[k+7]=='t'))
							{		num=0;
									k++;
									for(int l=k;l<(int)dataLen;l++){
									if((data[l]=='{') && (data[l+1]=='\\') && (data[l+2]=='*') && (data[l+3]=='\\') &&
									(data[l+4]=='o') && (data[l+5]=='b') && (data[l+6]=='j') && (data[l+7]=='c') &&
									(data[l+8]=='l') && (data[l+9]=='a') && (data[l+10]=='s') && (data[l+11]=='s'))
									{
										for(int p=l;p<(int)dataLen;p++){
										if((data[p]!=13)&&(data[p]!=10))
										temp[pos++]=data[p];
										if(data[p]=='}') {l=p+1;break; }
										}
									}
									if(data[l]=='{')  num++;
									if(data[l]=='}')  num--;
									if(num<0) {k=l;break;}
								}
							}
							else if((data[k]==13)||(data[k]==10)) {}	
							else if((data[k]=='f')&&(data[k+1]=='c')&&(data[k+2]=='s')&&(data[k+3]=='0')&&
								   (data[k+4]==' ')) k=k+4;
							else if((data[k]=='l')&&(data[k+1]=='t')&&(data[k+2]=='r')&&(data[k+3]=='r')&&
								   (data[k+4]=='o')&&(data[k+5]=='w')) k=k+5;
							else if((data[k]=='\\')&&(data[k+1]=='h')&&(data[k+2]=='i')&&(data[k+3]=='c')&&(data[k+4]=='h')&&
									(data[k+5]=='\\')&&(data[k+6]=='a')&&(data[k+7]=='f')&&
									(data[k+10]=='\\')&&(data[k+11]=='d')&&(data[k+12]=='b')&&(data[k+13]=='c')&&(data[k+14]=='h')&&
									(data[k+15]=='\\')&&(data[k+16]=='a')&&(data[k+17]=='f')&&
									(data[k+20]=='\\')&&(data[k+21]=='l')&&(data[k+22]=='o')&&(data[k+23]=='c')&&(data[k+24]=='h')&&
									(data[k+25]=='\\')&&(data[k+26]=='f')){
									if((data[k+27]=='2')&&(data[k+28]=='3'))
										if(data[k+32]=='}') k=k+32;
										else k=k+29;							
									else if(data[k+28]==' ')k=k+28;else k=k+29;
							}
							else if((data[k]=='\\')&&(data[k+1]=='h')&&(data[k+2]=='i')&&(data[k+3]=='c')&&(data[k+4]=='h')&&
									(data[k+5]=='\\')&&(data[k+6]=='a')&&(data[k+7]=='f')&&
									(data[k+9]=='\\')&&(data[k+10]=='d')&&(data[k+11]=='b')&&(data[k+12]=='c')&&(data[k+13]=='h')&&
									(data[k+14]=='\\')&&(data[k+15]=='a')&&(data[k+16]=='f')&&
									(data[k+18]=='\\')&&(data[k+19]=='l')&&(data[k+20]=='o')&&(data[k+21]=='c')&&(data[k+22]=='h')&&
									(data[k+23]=='\\')&&(data[k+24]=='f')){
									if((data[k+25]=='2')&&(data[k+26]=='3'))
										if(data[k+30]=='}') k=k+30;
										else k=k+27;							
									else if(data[k+26]==' ')k=k+26;else k=k+27;
							}
							else if((data[k]=='\\')&&(data[k+1]=='h')&&(data[k+2]=='i')&&(data[k+3]=='c')&&(data[k+4]=='h')&&
									(data[k+5]=='\\')&&(data[k+6]=='a')&&(data[k+7]=='f')&&
									(data[k+10]=='\\')&&(data[k+11]=='d')&&(data[k+12]=='b')&&(data[k+13]=='c')&&(data[k+14]=='h')&&
									(data[k+15]=='\\')&&(data[k+16]=='a')&&(data[k+17]=='f')&&
									(data[k+19]=='\\')&&(data[k+20]=='l')&&(data[k+21]=='o')&&(data[k+22]=='c')&&(data[k+23]=='h')&&
									(data[k+24]=='\\')&&(data[k+25]=='f')){
									if((data[k+26]=='2')&&(data[k+27]=='3'))
										if(data[k+31]=='}') k=k+31;
										else k=k+28;							
									else if(data[k+27]==' ')k=k+27;else k=k+28;
							}
							else if((data[k]=='i') && (data[k+1]=='d')&&(data[k+2]>=48)&&(data[k+2]<=57) )
							{
								for(int p=k+2;p<(int)dataLen;p++){
								if((data[p]<48) || (data[p]>57)) {k=p;break;}
								}
							}
							else if((data[k]=='\\') && (data[k+1]=='a')&& (data[k+2]=='f')&&(data[k+3]>=48)&&(data[k+3]<=57))
							{
								for(int p=k+3;p<(int)dataLen;p++){
								if((data[p]<48) || (data[p]>57)) {k=p;break;}
								}
							}
							else if((data[k]=='f')&&(data[k+1])=='c'&&(data[k+2]=='s')&&
									(data[k+3]=='0')&&(data[k+4]==' ')&&(data[k+5]=='\\')&&
									(data[k+6]=='i')&&(data[k+7]=='n')&&(data[k+8]=='s')&&
									(data[k+9]=='r')&&(data[k+10]=='s')){k=k+10;}
							else if((data[k]>=48)&&(data[k]<=57)&&(pos>=6)&&(temp[pos-6]=='P')&&
								(temp[pos-5]=='A')&&(temp[pos-4]=='G')&&(temp[pos-3]=='E')){}
							else if((data[k]>=48)&&(data[k]<=57)&&(pos>=7)&&(temp[pos-7]=='P')&&
								(temp[pos-6]=='A')&&(temp[pos-5]=='G')&&(temp[pos-4]=='E')){}
							else if((data[k]>=48)&&(data[k]<=57)&&(pos>=23)&&(temp[pos-23]=='P')&&
								(temp[pos-22]=='A')&&(temp[pos-21]=='G')&&(temp[pos-20]=='E')){}
							else if((data[k]>=48)&&(data[k]<=57)&&(pos>=24)&&(temp[pos-24]=='P')&&
								(temp[pos-23]=='A')&&(temp[pos-22]=='G')&&(temp[pos-1]=='E')){}
							else if((data[k]=='\\')&&(data[k+1]=='s')&&(data[k+2]=='p')){k=k+2;}
							else if((data[k]=='\\')&&(data[k+1]=='i')&&(data[k+2]=='r')&&(data[k+3]=='o')&&(data[k+4]=='w')&&
								(data[k+5]=='0')){k=k+5;}
							else if((data[k]=='\\')&&(data[k+1]=='i')&&(data[k+2]=='r')&&(data[k+3]=='o')&&(data[k+4]=='w')&&
								(data[k+5]=='b')&&(data[k+6]=='a')&&(data[k+7]=='n')&&(data[k+8]=='d')&&(data[k+9]=='0')){k=k+9;}
							else if((data[k]=='i')&&(data[k+1]=='n')&&(data[k+2]=='s')&&(data[k+3]=='r')&&(data[k+4]=='s')){k=k+4;}
							else if(data[k]=='\\'){}
							else{
								if(data[k]=='{') count++;
								if(data[k]=='}') { count--; i=k;if(count==0) break;}
								temp[pos++]=data[k];
							}
					}
					break;
				}
			}
		}
	}
	//************************************* END : decode data  **********************************************************************
			CStdioFile file1("C:\\Program Files\\IsagSign2547\\data3.sig", CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
			file1.Write(data, dataLen);
			file1.Close();
			CStdioFile file2("C:\\Program Files\\IsagSign2547\\data4.sig", CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
			file2.Write(temp, pos);
			file2.Close();
			
	//********* Hash data from File **********
	SignAndVerify verify;
	verify.FindHashValue(temp, pos, hashAlgo_Ver);
	verify.ConvertToHashValue();
	BYTE* hashStream = (BYTE*)(LPCSTR)(verify.GetHashValue());
	
	//********* verify signature *************
	DWORD sigSize[1] = {sigLen_Ver};
	if(verify.VerifySignature(sig_Ver, sigSize[0] , hashStream)==1) 
		dlg.setResult(1); // 
	else if(verify.VerifySignature(sig_Ver, sigSize[0] , hashStream)==0)
		dlg.setResult(2); // 
	else if(verify.VerifySignature(sig_Ver, sigSize[0] , hashStream)==-1){
		AfxMessageBox("Signing signature was not complete!!\nThis signature cannot be verified.", MB_OK);
		dlg.setResult(3); // The signature was an error, it's can't be verify.
		return;
	}
	dlg.getDoc(pDoc);
	dlg.DoModal();
}


BYTE* CIsagsignv2View::GetDataBlock(UINT& dataBlockLen)
{
	IUnknown			*pUnk = NULL;
	IDispatch			*pDisp = NULL;
	IDataObject			*pDataOb = NULL;
	LPDISPATCH			 lDisp = NULL;
	CLSID				 classID;
	HRESULT				 hResult;	
	// OLE Automation variable.
	_Application		appObj;
	_Document			docObj;
	Documents			docsObj;
	// Clipboard data.
	FORMATETC etc;
	STGMEDIUM stg;

	UINT format = ::RegisterClipboardFormat (CF_RTF);
	etc.cfFormat = format;
	etc.ptd = NULL;
	etc.lindex = -1;
	etc.dwAspect = DVASPECT_CONTENT;
	etc.tymed = TYMED_HGLOBAL;
	
	CLSIDFromProgID(L"Word.Application" , &classID);
	// Find class id and IUnknown interface of MS-WORD Application.
	hResult = GetActiveObject((const CLSID&)classID , NULL , &pUnk);
	if (hResult != S_OK) 
		AfxMessageBox("Error during GetActiveObject !");
		
	// Query IDispatch interface.
	hResult = pUnk->QueryInterface(IID_IDispatch , (void**)&pDisp);
	if (hResult != S_OK)
		AfxMessageBox("Error during QueryInterface for IDispatch !");

	appObj.AttachDispatch(pDisp , TRUE);
	lDisp = appObj.GetDocuments();
	docObj.AttachDispatch(lDisp , TRUE);

	// Query IDataobject interface.
	lDisp = appObj.GetActiveDocument();
	docObj.AttachDispatch(lDisp,TRUE);
	hResult = lDisp->QueryInterface(IID_IDataObject,(void**)&pDataOb);
	if ( hResult != S_OK )
		AfxMessageBox("Error during QueryInterface for IDataObject !");

	// Get data object in CF_TEXT format from MS-WORD.
	hResult = pDataOb->GetData(&etc,&stg);
	if ( hResult != S_OK )
		AfxMessageBox("Error during GetData !");

	HGLOBAL hgData = stg.hGlobal;
	BYTE* dataBlock = (BYTE*)GlobalLock(hgData);
	dataBlockLen = GlobalSize(stg.hGlobal);

	return dataBlock;
	// Free the stg storage medium.
	ReleaseStgMedium(&stg);
}


void CIsagsignv2View::OnImport() 
{
	ImportAndExport import;
	import.Import_Cert();
}

void CIsagsignv2View::OnExport() 
{
	ExportDlg d1;
	int nResponse = d1.DoModal();
	if (nResponse == IDOK)
	{	
		ImportAndExport export;
		export.Export_Cert(d1.signer.SignerName);
	}
}

void CIsagsignv2View::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
}

void CIsagsignv2View::OnSign() 
{
	CIsagsignv2Doc *pDoc = GetDocument();
	
	// check that digital signature was signed or not.
	if(pDoc->currentSigner.getSignStatus() == 0){ // not yet , it's ok
		CSignSheet dlg(_T("benz&bee"),this,0);
		CSignStep1 m_page1;
		CSignStep2 m_page2;
		CSignStep3 m_page3;
		CSignStep4 m_page4;
		m_page4.SetPage(&m_page2,&m_page3);

		dlg.AddPage(&m_page1);
		dlg.AddPage(&m_page2);
		dlg.AddPage(&m_page3);
		dlg.AddPage(&m_page4);
		dlg.SetWizardMode();
		// call dialog that user fill information
		if(dlg.DoModal() == ID_WIZFINISH){

			BYTE* data;
			UINT  dataLen;
			// read data from document which will sign.
			data = GetDataBlock(dataLen);
			BYTE* temp = new BYTE[dataLen];
			int count=0;
			int num=0;
			int pos=0;
			pos=0;
			// ****************************** decode data *****************************************************************************
			for(int i=count;i<(int)dataLen;i++){
				if(((data[i]=='i')&&(data[i+1]=='n')&&(data[i+2]=='s')&&(data[i+3]=='r')&&
					(data[i+4]=='s')&&(data[i+5]=='i')&&(data[i+6]=='d')) ||
					((data[i]=='\\')&&(data[i+1]=='a')&&(data[i+2]=='f')&&(data[i+3]=='2')&&
					(data[i+5]==' ')&&(data[i+6]=='\\')))
				{
					if((data[i]=='i')&&(data[i+1]=='n')&&(data[i+2]=='s')&&(data[i+3]=='r')&&
					(data[i+4]=='s')&&(data[i+5]=='i')&&(data[i+6]=='d'))
					{
						for(int k=i-1;k>0;k--){
						if((data[k]>=48)&&(data[k]<=57)&&(data[k-1]>=48)&&(data[k-1]<=57)&&
							(data[k-2]>=48)&&(data[k-2]<=57)&&(data[k-3]=='f'))k=k-5;			
						if((data[k]!=13)&&(data[k]!=10)) temp[pos++]=data[k];
						if(data[k]==' ') break;
						}
					}
					count=1;
					for(int j=i+7;j<(int)dataLen;j++){
						if((data[j]=='\\')||(data[j]==' ')){
							for(int k=j+1;k<(int)dataLen;k++)
							{
								if (((data[k]=='{')&&(data[k+1]=='\\')&&(data[k+2]=='s')&&(data[k+3]=='p')) ||
									((data[k]=='{')&&(data[k+1]=='\\')&&(data[k+2]=='s')&&(data[k+3]=='n')) ||
									((data[k]=='{')&&(data[k+1]=='\\')&&(data[k+2]=='s')&&(data[k+3]=='v')) ||
									((data[k]=='{') && (data[k+1]=='\\') && (data[k+2]=='s') && (data[k+3]=='h') &&
									(data[k+4]=='p') && (data[k+5]=='r')&& (data[k+6]=='s')&& (data[k+7]=='l')&& (data[k+8]=='t')))
									{		num=0;
											k++;
											for(int l=k;l<(int)dataLen;l++){
											if(data[l]=='{')  num++;
											if(data[l]=='}')  num--;
											if(num<0) {k=l;break;}
										}
									}	
									else if((data[k]=='{') && (data[k+1]=='\\') && (data[k+2]=='o') && (data[k+3]=='b') &&
											(data[k+4]=='j') && (data[k+5]=='e') && (data[k+6]=='c') && (data[k+7]=='t'))
									{		num=0;
											k++;
											for(int l=k;l<(int)dataLen;l++){
											if((data[l]=='{') && (data[l+1]=='\\') && (data[l+2]=='*') && (data[l+3]=='\\') &&
											(data[l+4]=='o') && (data[l+5]=='b') && (data[l+6]=='j') && (data[l+7]=='c') &&
											(data[l+8]=='l') && (data[l+9]=='a') && (data[l+10]=='s') && (data[l+11]=='s'))
											{
												for(int p=l;p<(int)dataLen;p++){
												if((data[p]!=13)&&(data[p]!=10))
												temp[pos++]=data[p];
												if(data[p]=='}') {l=p+1;break; }
												}
											}
											if(data[l]=='{')  num++;
											if(data[l]=='}')  num--;
											if(num<0) {k=l;break;}
										}
									}
									else if((data[k]=='f')&&(data[k+1]=='c')&&(data[k+2]=='s')&&(data[k+3]=='0')&&
										(data[k+4]==' ')) k=k+4;
									else if((data[k]=='l')&&(data[k+1]=='t')&&(data[k+2]=='r')&&(data[k+3]=='r')&&
										(data[k+4]=='o')&&(data[k+5]=='w')) k=k+5;
									else if((data[k]==13)||(data[k]==10)) {}	
									else if((data[k]=='\\')&&(data[k+1]=='h')&&(data[k+2]=='i')&&(data[k+3]=='c')&&(data[k+4]=='h')&&
											(data[k+5]=='\\')&&(data[k+6]=='a')&&(data[k+7]=='f')&&
											(data[k+10]=='\\')&&(data[k+11]=='d')&&(data[k+12]=='b')&&(data[k+13]=='c')&&(data[k+14]=='h')&&
											(data[k+15]=='\\')&&(data[k+16]=='a')&&(data[k+17]=='f')&&
											(data[k+20]=='\\')&&(data[k+21]=='l')&&(data[k+22]=='o')&&(data[k+23]=='c')&&(data[k+24]=='h')&&
											(data[k+25]=='\\')&&(data[k+26]=='f')){
											if((data[k+27]=='2')&&(data[k+28]=='3'))
												if(data[k+32]=='}') k=k+32;
												else k=k+29;							
											else if(data[k+28]==' ')k=k+28;else k=k+29;

									}
									else if((data[k]=='\\')&&(data[k+1]=='h')&&(data[k+2]=='i')&&(data[k+3]=='c')&&(data[k+4]=='h')&&
											(data[k+5]=='\\')&&(data[k+6]=='a')&&(data[k+7]=='f')&&
											(data[k+9]=='\\')&&(data[k+10]=='d')&&(data[k+11]=='b')&&(data[k+12]=='c')&&(data[k+13]=='h')&&
											(data[k+14]=='\\')&&(data[k+15]=='a')&&(data[k+16]=='f')&&
											(data[k+18]=='\\')&&(data[k+19]=='l')&&(data[k+20]=='o')&&(data[k+21]=='c')&&(data[k+22]=='h')&&
											(data[k+23]=='\\')&&(data[k+24]=='f')){
											if((data[k+25]=='2')&&(data[k+26]=='3'))
												if(data[k+30]=='}') k=k+30;
												else k=k+27;							
											else if(data[k+26]==' ')k=k+26;else k=k+27;
									}
									else if((data[k]=='\\')&&(data[k+1]=='h')&&(data[k+2]=='i')&&(data[k+3]=='c')&&(data[k+4]=='h')&&
											(data[k+5]=='\\')&&(data[k+6]=='a')&&(data[k+7]=='f')&&
											(data[k+10]=='\\')&&(data[k+11]=='d')&&(data[k+12]=='b')&&(data[k+13]=='c')&&(data[k+14]=='h')&&
											(data[k+15]=='\\')&&(data[k+16]=='a')&&(data[k+17]=='f')&&
											(data[k+19]=='\\')&&(data[k+20]=='l')&&(data[k+21]=='o')&&(data[k+22]=='c')&&(data[k+23]=='h')&&
											(data[k+24]=='\\')&&(data[k+25]=='f')){
											if((data[k+26]=='2')&&(data[k+27]=='3'))
												if(data[k+31]=='}') k=k+31;
												else k=k+28;							
											else if(data[k+27]==' ')k=k+27;else k=k+28;
									}
									else if((data[k]=='i') && (data[k+1]=='d')&&(data[k+2]>=48)&&(data[k+2]<=57) )
									{
										for(int p=k+2;p<(int)dataLen;p++){
										if((data[p]<48) || (data[p]>57)) {k=p;break;}
										}
									}
									else if((data[k]=='\\') && (data[k+1]=='a')&& (data[k+2]=='f')&&(data[k+3]>=48)&&(data[k+3]<=57))
									{
										for(int p=k+3;p<(int)dataLen;p++){
										if((data[p]<48) || (data[p]>57)) {k=p;break;}
										}
									}
									else if((data[k]=='f')&&(data[k+1])=='c'&&(data[k+2]=='s')&&
											(data[k+3]=='0')&&(data[k+4]==' ')&&(data[k+5]=='\\')&&
											(data[k+6]=='i')&&(data[k+7]=='n')&&(data[k+8]=='s')&&
											(data[k+9]=='r')&&(data[k+10]=='s')){k=k+10;}
									else if((data[k]>=48)&&(data[k]<=57)&&(pos>=6)&&(temp[pos-6]=='P')&&
										(temp[pos-5]=='A')&&(temp[pos-4]=='G')&&(temp[pos-3]=='E')){}
									else if((data[k]>=48)&&(data[k]<=57)&&(pos>=7)&&(temp[pos-7]=='P')&&
										(temp[pos-6]=='A')&&(temp[pos-5]=='G')&&(temp[pos-4]=='E')){}
									else if((data[k]>=48)&&(data[k]<=57)&&(pos>=23)&&(temp[pos-23]=='P')&&
										(temp[pos-22]=='A')&&(temp[pos-21]=='G')&&(temp[pos-20]=='E')){}
									else if((data[k]>=48)&&(data[k]<=57)&&(pos>=24)&&(temp[pos-24]=='P')&&
										(temp[pos-23]=='A')&&(temp[pos-22]=='G')&&(temp[pos-1]=='E')){}
									else if((data[k]=='\\')&&(data[k+1]=='s')&&(data[k+2]=='p')){k=k+2;}
									else if((data[k]=='\\')&&(data[k+1]=='i')&&(data[k+2]=='r')&&(data[k+3]=='o')&&(data[k+4]=='w')&&
										(data[k+5]=='0')){k=k+5;}

									else if((data[k]=='\\')&&(data[k+1]=='i')&&(data[k+2]=='r')&&(data[k+3]=='o')&&(data[k+4]=='w')&&
										(data[k+5]=='b')&&(data[k+6]=='a')&&(data[k+7]=='n')&&(data[k+8]=='d')&&(data[k+9]=='0')){k=k+9;}
									else if((data[k]=='i')&&(data[k+1]=='n')&&(data[k+2]=='s')&&(data[k+3]=='r')&&(data[k+4]=='s')){k=k+4;}
									else if(data[k]=='\\'){}
									else{
										if(data[k]=='{') count++;
										if(data[k]=='}') { count--; i=k;if(count==0) break;}
										temp[pos++]=data[k];
									}
							}
							break;
						}
					}
				}
			}
			//************************************* END : decode data  **********************************************************************
			CStdioFile file1("C:\\Program Files\\IsagSign2547\\data1.sig", CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
			file1.Write(data, dataLen);
			file1.Close();
			CStdioFile file2("C:\\Program Files\\IsagSign2547\\data2.sig", CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
			file2.Write(temp, pos);
			file2.Close();

			// set SingerInfo	
			pDoc->currentSigner.setSignerInfo(m_page2.signer);
			pDoc->currentSigner.setHashAlgorithm(m_page3.m_hash);
			pDoc->currentSigner.setSignDate(CTime::GetCurrentTime());
			pDoc->currentSigner.setCertDuration(m_page3.m_DateFm,m_page3.m_DateTo);
			pDoc->currentSigner.setPictureNumber(m_page3.picNumber);

			// hash
			SignAndVerify sign;
			sign.FindHashValue(temp, pos, pDoc->currentSigner.getHashAlgorithm());
			sign.ConvertToHashValue();
			
			// sign
			BYTE* hashStream = (BYTE*)(LPCSTR)(sign.GetHashValue());
			UINT  hashStreamLen = strlen((LPCSTR)(sign.GetHashValue()));
			if(!sign.SignSignature(hashStream, hashStreamLen,pDoc->currentSigner.getSignerInfo().SignerName)){
				pDoc->currentSigner.setSignStatus(-1); 
				AfxMessageBox("Signing signature was not successful.", MB_OK);
				return;
			}
			
			// set digital signature to file
			BYTE* sig = sign.GetDigitalSignature();
			UINT  sigLen = sign.GetDigitalSignatureLen();			
			pDoc->currentSigner.setPbSignatureBlob(sig, sigLen);
			pDoc->currentSigner.setSignStatus(1); 
			AfxMessageBox("Signing signature was successful.", MB_OK | MB_ICONINFORMATION);
		}
		else { // if it has error , it won't sign again
			pDoc->currentSigner.setSignStatus(-1);
			AfxMessageBox("Signing signature was not successful.", MB_OK);
		}
	} // if error happen , the signature can't sign again  
	else if(pDoc->currentSigner.getSignStatus() == -1){ 
		AfxMessageBox("Signing signature was not complete!!\nThis signature cannot be signed again.", MB_OK);
	} // if the signature was signed, it can't sign again
	else if(pDoc->currentSigner.getSignStatus() == 1){
		AfxMessageBox("Cannot duplicate signature.");
	}

	Invalidate(TRUE);
	GetDocument()->GetEmbeddedItem()->NotifyChanged();
}

