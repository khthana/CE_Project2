// SignStep1.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SignStep1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep1 property page

IMPLEMENT_DYNCREATE(CSignStep1, CPropertyPage)

CSignStep1::CSignStep1() : CPropertyPage(CSignStep1::IDD)
{
	//{{AFX_DATA_INIT(CSignStep1)
	m_step1 = -1;
	//}}AFX_DATA_INIT
}

CSignStep1::~CSignStep1()
{
}

void CSignStep1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep1)
	DDX_Control(pDX, IDC_RADIO1, m_Cstep1);
	DDX_Radio(pDX, IDC_RADIO1, m_step1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSignStep1, CPropertyPage)
	//{{AFX_MSG_MAP(CSignStep1)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignStep1 message handlers

BOOL CSignStep1::OnSetActive() 
{
	CPropertySheet* parent = (CPropertySheet*)GetParent();
    parent->SetWizardButtons(PSWIZB_NEXT);
	
	return CPropertyPage::OnSetActive();
}

void CSignStep1::OnRadio1() 
{
	chkChoice = 1;
}

void CSignStep1::OnRadio2() 
{
	chkChoice = 2;
}

BOOL CSignStep1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	CButton *hashAlgo;
	hashAlgo = (CButton*)GetDlgItem(IDC_RADIO1);
	hashAlgo->SetCheck(TRUE);
	chkChoice = 1;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CSignStep1::OnWizardNext() 
{
	// Link to Certificates Menu at Internet Options
	if(chkChoice == 2){
		WinExec("CertMgr.exe" , SW_SHOW);
	}
	return CPropertyPage::OnWizardNext();
}

