// Picture.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "Picture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPicture dialog


CPicture::CPicture(CWnd* pParent /*=NULL*/)
	: CDialog(CPicture::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPicture)
	m_List = _T("");
	//}}AFX_DATA_INIT
}


void CPicture::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPicture)
	DDX_Control(pDX, IDC_PICTURE, m_Pic);
	DDX_Control(pDX, IDC_LIST2, m_CList);
	DDX_LBString(pDX, IDC_LIST2, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPicture, CDialog)
	//{{AFX_MSG_MAP(CPicture)
	ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicture message handlers

BOOL CPicture::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	char str[20];
	for(int i=1; i<=12; i++){
		sprintf(str,"Style %d",i);
		m_CList.AddString(str);
	}
	m_CList.SetCurSel(picNumber-1);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPicture::OnSelchangeList2() 
{
	picNumber = m_CList.GetCurSel()+1;	
	if(picNumber == 1){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_1);
		m_Pic.SetBitmap( bmPic);
	}
	else if(picNumber == 2){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_2);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 3){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_3);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 4){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_4);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 5){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_5);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 6){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_6);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 7){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_7);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 8){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_8);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 9){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_9);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 10){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_10);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 11){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_11);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 12){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_12);
		m_Pic.SetBitmap( bmPic );
	}

}


void CPicture::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	picNumber = m_CList.GetCurSel()+1;	
	if(picNumber == 1){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_1);
		m_Pic.SetBitmap( bmPic);
	}
	else if(picNumber == 2){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_2);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 3){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_3);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 4){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_4);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 5){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_5);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 6){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_6);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 7){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_7);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 8){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_8);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 9){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_9);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 10){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_10);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 11){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_11);
		m_Pic.SetBitmap( bmPic );
	}
	else if(picNumber == 12){
		CBitmap bmPic;
		bmPic.LoadBitmap(IDB_SIG_12);
		m_Pic.SetBitmap( bmPic );
	}
}
void CPicture::setPicNumber(int pic)
{
	picNumber = pic;
}