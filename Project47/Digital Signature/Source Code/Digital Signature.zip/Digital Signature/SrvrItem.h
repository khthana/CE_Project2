// SrvrItem.h : interface of the CIsagsignv2SrvrItem class
//

#if !defined(AFX_SRVRITEM_H__8E7034C7_685C_4B7D_A324_DBAE5C2F611D__INCLUDED_)
#define AFX_SRVRITEM_H__8E7034C7_685C_4B7D_A324_DBAE5C2F611D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CIsagsignv2SrvrItem : public COleServerItem
{
	DECLARE_DYNAMIC(CIsagsignv2SrvrItem)

// Constructors
public:
	CIsagsignv2SrvrItem(CIsagsignv2Doc* pContainerDoc);
//	SignatureInformation currentSigner;

// Attributes
	CIsagsignv2Doc* GetDocument() const
		{ return (CIsagsignv2Doc*)COleServerItem::GetDocument(); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIsagsignv2SrvrItem)
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);
	//}}AFX_VIRTUAL

// Implementation
public:
	~CIsagsignv2SrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRVRITEM_H__8E7034C7_685C_4B7D_A324_DBAE5C2F611D__INCLUDED_)
