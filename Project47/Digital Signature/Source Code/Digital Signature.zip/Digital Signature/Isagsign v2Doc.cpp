// Isagsign v2Doc.cpp : implementation of the CIsagsignv2Doc class
//

#include "stdafx.h"
#include "Isagsign v2.h"

#include "Isagsign v2Doc.h"
#include "SrvrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2Doc

IMPLEMENT_DYNCREATE(CIsagsignv2Doc, COleServerDoc)

BEGIN_MESSAGE_MAP(CIsagsignv2Doc, COleServerDoc)
	//{{AFX_MSG_MAP(CIsagsignv2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CIsagsignv2Doc, COleServerDoc)
	//{{AFX_DISPATCH_MAP(CIsagsignv2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IIsagsignv2 to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {57CBE8D7-5C34-4AD3-B5F9-4676502099B5}
static const IID IID_IIsagsignv2 =
{ 0x57cbe8d7, 0x5c34, 0x4ad3, { 0xb5, 0xf9, 0x46, 0x76, 0x50, 0x20, 0x99, 0xb5 } };

BEGIN_INTERFACE_MAP(CIsagsignv2Doc, COleServerDoc)
	INTERFACE_PART(CIsagsignv2Doc, IID_IIsagsignv2, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2Doc construction/destruction

CIsagsignv2Doc::CIsagsignv2Doc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
}

CIsagsignv2Doc::~CIsagsignv2Doc()
{
	AfxOleUnlockApp();
}

BOOL CIsagsignv2Doc::OnNewDocument()
{
	if (!COleServerDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2Doc server implementation

COleServerItem* CIsagsignv2Doc::OnGetEmbeddedItem()
{
	// OnGetEmbeddedItem is called by the framework to get the COleServerItem
	//  that is associated with the document.  It is only called when necessary.

	CIsagsignv2SrvrItem* pItem = new CIsagsignv2SrvrItem(this);
	ASSERT_VALID(pItem);
	return pItem;
}

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2Doc serialization

void CIsagsignv2Doc::Serialize(CArchive& ar)
{
	this->currentSigner.Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2Doc diagnostics

#ifdef _DEBUG
void CIsagsignv2Doc::AssertValid() const
{
	COleServerDoc::AssertValid();
}

void CIsagsignv2Doc::Dump(CDumpContext& dc) const
{
	COleServerDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2Doc commands
