// ExportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ExportDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ExportDlg dialog


ExportDlg::ExportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(ExportDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ExportDlg)
	m_Export = -1;
	//}}AFX_DATA_INIT
}


void ExportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ExportDlg)
	DDX_Control(pDX, IDC_COMBO2, m_comboExport);
	DDX_CBIndex(pDX, IDC_COMBO2, m_Export);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ExportDlg, CDialog)
	//{{AFX_MSG_MAP(ExportDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ExportDlg message handlers


BOOL ExportDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	cert = new CCertStore();
	cert->ReadCertificateInStore();
	CString Subject;
	signerList = cert->get_signerInfoList();
	for(int i=0; i<(int)cert->get_signerCount() ; i++){
		Subject = signerList[i].SignerName;
		m_comboExport.AddString(Subject);
	}	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void ExportDlg::OnOK() 
{
	// TODO: Add extra validation here
	CDialog::OnOK();
	signer = signerList[m_Export];
	delete cert;
}
