#if !defined(AFX_SIGNDLG_H__249B57B7_8BA2_4B32_B070_94B65A847ABF__INCLUDED_)
#define AFX_SIGNDLG_H__249B57B7_8BA2_4B32_B070_94B65A847ABF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SignDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSignDlg dialog

#include "CertStore.h"
//#include "Utility.h"

class CSignDlg : public CDialog
{
// Construction
public:
	CSignDlg(CWnd* pParent = NULL);   // standard constructor
	SignerInformation* signerList;
	CString m_hash;
	CCertStore* cert;
	SignerInformation signer;

// Dialog Data
	//{{AFX_DATA(CSignDlg)
	enum { IDD = IDD_CERT };
	CDateTimeCtrl	m_toCtrl;
	CDateTimeCtrl	m_fmCtrl;
	CComboBox	m_comboSigner;
	CTime	m_fm;
	CTime	m_to;
	int		m_Signer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSignDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSignDlg)
	virtual void OnOK();
	afx_msg void OnMd4();
	afx_msg void OnMd5();
	afx_msg void OnSha1();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNDLG_H__249B57B7_8BA2_4B32_B070_94B65A847ABF__INCLUDED_)
