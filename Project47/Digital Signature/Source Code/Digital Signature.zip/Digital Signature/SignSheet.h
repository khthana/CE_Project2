#if !defined(AFX_SIGNSHEET_H__B68FB4EF_5577_48C2_81A0_66EB49F0C8F3__INCLUDED_)
#define AFX_SIGNSHEET_H__B68FB4EF_5577_48C2_81A0_66EB49F0C8F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SignSheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSignSheet

class CSignSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CSignSheet)

// Construction
public:
	CSignSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CSignSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSignSheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSignSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CSignSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNSHEET_H__B68FB4EF_5577_48C2_81A0_66EB49F0C8F3__INCLUDED_)
