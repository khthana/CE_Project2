#if !defined(AFX_SIGNSTEP3_H__CAC23389_202E_417D_8DF0_0EA1E5F42E61__INCLUDED_)
#define AFX_SIGNSTEP3_H__CAC23389_202E_417D_8DF0_0EA1E5F42E61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SignStep3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSignStep3 dialog

class CSignStep3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSignStep3)

// Construction
public:
	CSignStep3();
	~CSignStep3();
	CString m_hash;
	int picNumber;

// Dialog Data
	//{{AFX_DATA(CSignStep3)
	enum { IDD = IDD_DIALOG3 };
	CStatic	m_Pic;
	CButton	m_pic;
	CDateTimeCtrl	m_toCtrl;
	CDateTimeCtrl	m_fmCtrl;
	CTime	m_DateFm;
	CTime	m_DateTo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSignStep3)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSignStep3)
	virtual BOOL OnInitDialog();
	afx_msg void OnSha1();
	afx_msg void OnMd5();
	afx_msg void OnMd4();
	afx_msg void OnChangePic();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNSTEP3_H__CAC23389_202E_417D_8DF0_0EA1E5F42E61__INCLUDED_)
