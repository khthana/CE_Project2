#if !defined(AFX_SIGNSTEP4_H__EAD02CF0_A56A_4CD4_BD30_A4813B6AA8F8__INCLUDED_)
#define AFX_SIGNSTEP4_H__EAD02CF0_A56A_4CD4_BD30_A4813B6AA8F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SignStep4.h : header file
//

#include "SignStep2.h"
#include "SignStep3.h"

/////////////////////////////////////////////////////////////////////////////
// CSignStep4 dialog

class CSignStep4 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSignStep4)

// Construction
public:
	CSignStep4();
	CSignStep4(CSignStep2*,CSignStep3*);
	~CSignStep4();
	CSignStep2* m_page2;
	CSignStep3* m_page3;
	void SetPage(CSignStep2*,CSignStep3*);

// Dialog Data
	//{{AFX_DATA(CSignStep4)
	enum { IDD = IDD_DIALOG4 };
	CStatic m_Subject;
	CStatic m_Issuer;
	CStatic m_KeyFm;
	CStatic m_KeyTo;
	CStatic m_Hash;
	CStatic m_Sign;
	CStatic m_SignFm;
	CStatic m_SignTo;
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSignStep4)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSignStep4)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNSTEP4_H__EAD02CF0_A56A_4CD4_BD30_A4813B6AA8F8__INCLUDED_)
