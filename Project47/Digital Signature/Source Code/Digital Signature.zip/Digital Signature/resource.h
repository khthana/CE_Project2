//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Isagsign v2.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_USE_INSERT_OBJECT           101
#define IDD_DIALOG1                     107
#define IDR_MAINFRAME                   128
#define IDR_ISAGSITYPE                  129
#define IDD_CERT                        130
#define IDD_CERT_EXPORT                 131
#define IDD_DIALOG2                     132
#define IDD_DIALOG3                     133
#define IDD_DIALOG4                     134
#define IDD_PICTURE                     135
#define IDD_VERIFY                      136
#define IDR_ICON1                       136
#define IDB_BITMAP3                     138
#define IDB_PIC1                        139
#define IDB_BITMAP1                     140
#define IDB_BITMAP2                     141
#define IDB_PIC2                        142
#define IDB_UNMODIFIED                  143
#define IDB_MODIFIED                    144
#define IDB_EXPIRED                     145
#define IDB_SIG1                        149
#define IDB_SIG10                       150
#define IDB_PIC11                       151
#define IDB_SIG11                       151
#define IDB_PIC22                       152
#define IDB_SIG12                       152
#define IDB_SIG2                        153
#define IDB_SIG3                        154
#define IDB_SIG4                        155
#define IDB_SIG5                        156
#define IDB_SIG6                        157
#define IDB_SIG7                        158
#define IDB_SIG8                        159
#define IDB_SIG9                        160
#define IDB_SIG_1                       161
#define IDB_SIG_10                      162
#define IDB_SIG_11                      163
#define IDB_SIG_12                      164
#define IDB_SIG_2                       165
#define IDB_SIG_3                       166
#define IDB_SIG_4                       167
#define IDB_SIG_5                       168
#define IDB_SIG_6                       169
#define IDB_SIG_7                       170
#define IDB_SIG_8                       171
#define IDB_SIG_9                       172
#define IDB_EARLY                       173
#define IDB_EXPIRED_CERT                174
#define IDC_RADIO1                      1000
#define IDC_SUBJECT                     1000
#define IDC_RADIO2                      1001
#define IDC_LIST1                       1001
#define IDC_RADIO3                      1002
#define IDC_ISSUER                      1002
#define IDC_VALIDFM                     1003
#define IDC_DATETIMEPICKER2             1004
#define IDC_VALIDTO                     1004
#define IDC_COMBO2                      1005
#define IDC_DATETIMEPICKER3             1005
#define IDC_LIST2                       1005
#define IDC_KEYFM                       1005
#define IDC_BUTTON1                     1006
#define IDC_KEYTO                       1006
#define IDC_HASH                        1007
#define IDC_KEYTO2                      1007
#define IDC_SIGN                        1008
#define IDC_HASH2                       1008
#define IDC_SIGNFM                      1009
#define IDC_SIGN2                       1009
#define IDC_MD4                         1010
#define IDC_SIGNTO                      1010
#define IDC_SIGNFM2                     1010
#define IDC_MD5                         1011
#define IDC_SIGNTO2                     1011
#define IDC_SHA1                        1012
#define IDC_SUBJECT2                    1012
#define IDC_ISSUER2                     1013
#define IDC_KEYFM2                      1014
#define IDC_DATETIME_FM                 1016
#define IDC_VERIFYPIC                   1016
#define IDC_DATETIME_TO                 1017
#define IDC_PICTURE                     1018
#define ID_CANCEL_EDIT_SRVR             32769
#define ID_SIGN                         32771
#define ID_VERIFY                       32772
#define ID_IMPORT                       32773
#define ID_EXPORT                       32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        175
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
