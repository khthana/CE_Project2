// SignAndVerify.h: interface for the SignAndVerify class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIGNANDVERIFY_H__47E76581_17C1_4169_A131_DC879A0D35BA__INCLUDED_)
#define AFX_SIGNANDVERIFY_H__47E76581_17C1_4169_A131_DC879A0D35BA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define CERT_STORE_NAME L"MY"
#include "Isagsign v2.h"

class SignAndVerify  
{
public:
	SignAndVerify();
	virtual ~SignAndVerify();
	void FindHashValue(BYTE*, UINT, CString);
	void ConvertToHashValue();
	CString GetCertificateSubject(CERT_NAME_BLOB*);
	BOOL SignSignature(BYTE*, UINT, CString);
	BOOL VerifySignature(BYTE*, DWORD, BYTE*);
	void HandleError(CString);
	BYTE*	GetDigitalSignature();
	CString GetHashValue();
	UINT	GetDigitalSignatureLen();	
private:
	BYTE		*digitalSignature;
	UINT		digitalSignatureLen;
	HCRYPTPROV	hProv;
	HCRYPTHASH	hHash;
	CString		hashValue;
};

#endif // !defined(AFX_SIGNANDVERIFY_H__47E76581_17C1_4169_A131_DC879A0D35BA__INCLUDED_)
