// ImportAndExport.h: interface for the ImportAndExport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORTANDEXPORT_H__A6071BB6_F5AE_44F3_934D_58A91CD5C0CF__INCLUDED_)
#define AFX_IMPORTANDEXPORT_H__A6071BB6_F5AE_44F3_934D_58A91CD5C0CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ImportAndExport  
{
public:
	ImportAndExport();
	virtual ~ImportAndExport();
	void Export_Cert(CString);
	void Import_Cert();
	void HandleError(char *);
	CString GetCertificateSubject(CERT_NAME_BLOB *);

};

#endif // !defined(AFX_IMPORTANDEXPORT_H__A6071BB6_F5AE_44F3_934D_58A91CD5C0CF__INCLUDED_)
