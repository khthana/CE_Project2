// Isagsign v2Doc.h : interface of the CIsagsignv2Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISAGSIGNV2DOC_H__B621A552_463F_4EE4_8F5F_32B4592773EC__INCLUDED_)
#define AFX_ISAGSIGNV2DOC_H__B621A552_463F_4EE4_8F5F_32B4592773EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CIsagsignv2SrvrItem;

class CIsagsignv2Doc : public COleServerDoc
{
protected: // create from serialization only
	CIsagsignv2Doc();
	DECLARE_DYNCREATE(CIsagsignv2Doc)

// Attributes
public:
	CIsagsignv2SrvrItem* GetEmbeddedItem()
		{ return (CIsagsignv2SrvrItem*)COleServerDoc::GetEmbeddedItem(); }
	SignatureInformation currentSigner;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIsagsignv2Doc)
	protected:
	virtual COleServerItem* OnGetEmbeddedItem();
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIsagsignv2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CIsagsignv2Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CIsagsignv2Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAGSIGNV2DOC_H__B621A552_463F_4EE4_8F5F_32B4592773EC__INCLUDED_)
