#if !defined(AFX_FILEDLG_H__E93B1606_6AF3_485A_AD79_36B52385315E__INCLUDED_)
#define AFX_FILEDLG_H__E93B1606_6AF3_485A_AD79_36B52385315E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FileDlg dialog

class FileDlg : public CFileDialog
{
	DECLARE_DYNAMIC(FileDlg)

public:
	FileDlg(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(FileDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEDLG_H__E93B1606_6AF3_485A_AD79_36B52385315E__INCLUDED_)
