// SigningDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SigningDlg.h"
#include "msword8.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSigningDlg dialog


CSigningDlg::CSigningDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSigningDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSigningDlg)
	//}}AFX_DATA_INIT
}

CSigningDlg::CSigningDlg(UINT& dataLen){
	dataBlockLen = dataLen;
}

void CSigningDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSigningDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSigningDlg, CDialog)
	//{{AFX_MSG_MAP(CSigningDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSigningDlg message handlers

BOOL CSigningDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
/*	m_progress.SetRange(0,100);
	m_progress.SetStep(10);
	m_progress.SetPos(0);*/
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BYTE* CSigningDlg::GetDataBlock()
{
	CProgressCtrl myCtrl;
	myCtrl.Create(WS_CHILD|WS_VISIBLE|WS_DLGFRAME, CRect(10,10,200,30), this, 1);
	myCtrl.SetRange(0,100);
	myCtrl.SetPos(0);

	IUnknown			*pUnk = NULL;
	IDispatch			*pDisp = NULL;
	IDataObject			*pDataOb = NULL;
	LPDISPATCH			 lDisp = NULL;
	CLSID				 classID;
	HRESULT				 hResult;	
	// OLE Automation variable.
	_Application		appObj;
	_Document			docObj;
	Documents			docsObj;
	// Clipboard data.
	FORMATETC etc;
	STGMEDIUM stg;

	myCtrl.SetPos(10);
	UINT format = ::RegisterClipboardFormat (CF_RTF);
	etc.cfFormat = format;
//	etc.cfFormat = CF_TEXT;
	etc.ptd = NULL;
	etc.lindex = -1;
	etc.dwAspect = DVASPECT_CONTENT;
	etc.tymed = TYMED_HGLOBAL;
	
	myCtrl.SetPos(20);
	CLSIDFromProgID(L"Word.Application" , &classID);
	// Find class id and IUnknown interface of MS-WORD Application.
	hResult = GetActiveObject((const CLSID&)classID , NULL , &pUnk);
	if (hResult != S_OK) 
		AfxMessageBox("Error during GetActiveObject !");

	myCtrl.SetPos(30);	
	// Query IDispatch interface.
	hResult = pUnk->QueryInterface(IID_IDispatch , (void**)&pDisp);
	if (hResult != S_OK)
		AfxMessageBox("Error during QueryInterface for IDispatch !");

	myCtrl.SetPos(40);
	appObj.AttachDispatch(pDisp , TRUE);
	lDisp = appObj.GetDocuments();
	docObj.AttachDispatch(lDisp , TRUE);

	myCtrl.SetPos(50);
	// Query IDataobject interface.
	lDisp = appObj.GetActiveDocument();
	docObj.AttachDispatch(lDisp,TRUE);
	hResult = lDisp->QueryInterface(IID_IDataObject,(void**)&pDataOb);
	if ( hResult != S_OK )
		AfxMessageBox("Error during QueryInterface for IDataObject !");

	myCtrl.SetPos(60);
	// Get data object in CF_TEXT format from MS-WORD.
	hResult = pDataOb->GetData(&etc,&stg);
	if ( hResult != S_OK )
		AfxMessageBox("Error during GetData !");

	myCtrl.SetPos(90);
	HGLOBAL hgData = stg.hGlobal;
	BYTE* dataBlock = (BYTE*)GlobalLock(hgData);
	dataBlockLen = GlobalSize(stg.hGlobal);

	myCtrl.SetPos(100);
	return dataBlock;
	// Free the stg storage medium.
	ReleaseStgMedium(&stg);
}

int CSigningDlg::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
//	AfxMessageBox("modal");
//	data = GetDataBlock();
	OnOK();
	return CDialog::DoModal();
}

void CSigningDlg::OnOK() 
{
	// TODO: Add extra validation here
//	m_progress.StepIt();
	data = GetDataBlock();
	
	CDialog::OnOK();
}

