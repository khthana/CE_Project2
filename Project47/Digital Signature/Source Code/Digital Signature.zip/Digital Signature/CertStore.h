// CertStore.h: interface for the CCertStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CERTSTORE_H__294BCAE5_6EFD_47F8_9B1A_7615BA32AA72__INCLUDED_)
#define AFX_CERTSTORE_H__294BCAE5_6EFD_47F8_9B1A_7615BA32AA72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Isagsign v2.h"

class CCertStore  
{
public:
	CCertStore();
	virtual				~CCertStore();
	void				ReadCertificateInStore();
	CString				DecodeCertificate(CERT_NAME_BLOB*);
	SignerInformation*	get_signerInfoList();
	UINT				get_signerCount();
	CString				RetrieveIssuer(CString);
	CString				RetrieveSubject(CString);
	BOOL				CheckRevocationDate(const CERT_CONTEXT*);
private:
	int signerCount;
	SignerInformation* signerInfoList;
	void HandleError(CString);

};

#endif // !defined(AFX_CERTSTORE_H__294BCAE5_6EFD_47F8_9B1A_7615BA32AA72__INCLUDED_)
