#if !defined(AFX_SIGNINGDLG_H__F1B66915_4465_4C66_B02C_E0E4488C3FC1__INCLUDED_)
#define AFX_SIGNINGDLG_H__F1B66915_4465_4C66_B02C_E0E4488C3FC1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SigningDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSigningDlg dialog

class CSigningDlg : public CDialog
{
// Construction
public:
	CSigningDlg(CWnd* pParent = NULL);   // standard constructor
	CSigningDlg(UINT&);
	BYTE* GetDataBlock();
	UINT dataBlockLen;
	BYTE* data;
// Dialog Data
	//{{AFX_DATA(CSigningDlg)
	enum { IDD = IDD_DIALOG5 };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSigningDlg)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSigningDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNINGDLG_H__F1B66915_4465_4C66_B02C_E0E4488C3FC1__INCLUDED_)
