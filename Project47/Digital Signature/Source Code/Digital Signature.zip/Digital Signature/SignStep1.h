#if !defined(AFX_SIGNSTEP1_H__9F6A324F_062D_47B8_B562_AAFCEC5AF894__INCLUDED_)
#define AFX_SIGNSTEP1_H__9F6A324F_062D_47B8_B562_AAFCEC5AF894__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SignStep1.h : header file
//

#include "CertStore.h"

/////////////////////////////////////////////////////////////////////////////
// CSignStep1 dialog

class CSignStep1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSignStep1)

// Construction
public:
	CSignStep1();
	~CSignStep1();
	int chkChoice;

// Dialog Data
	//{{AFX_DATA(CSignStep1)
	enum { IDD = IDD_DIALOG1 };
	CButton	m_Cstep1;
	int		m_step1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSignStep1)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSignStep1)
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIGNSTEP1_H__9F6A324F_062D_47B8_B562_AAFCEC5AF894__INCLUDED_)
