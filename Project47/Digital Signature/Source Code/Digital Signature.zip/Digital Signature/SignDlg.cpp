// SignDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SignDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CSignDlg dialog


CSignDlg::CSignDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSignDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSignDlg)
	m_fm = 0;
	m_to = 0;
	m_Signer = -1;
	//}}AFX_DATA_INIT
}

void CSignDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignDlg)
	DDX_Control(pDX, IDC_DATETIME_TO, m_toCtrl);
	DDX_Control(pDX, IDC_DATETIME_FM, m_fmCtrl);
	DDX_Control(pDX, IDC_COMBO2, m_comboSigner);
	DDX_DateTimeCtrl(pDX, IDC_DATETIME_FM, m_fm);
	DDX_DateTimeCtrl(pDX, IDC_DATETIME_TO, m_to);
	DDX_CBIndex(pDX, IDC_COMBO2, m_Signer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSignDlg, CDialog)
	//{{AFX_MSG_MAP(CSignDlg)
	ON_BN_CLICKED(IDC_MD4, OnMd4)
	ON_BN_CLICKED(IDC_MD5, OnMd5)
	ON_BN_CLICKED(IDC_SHA1, OnSha1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignDlg message handlers

void CSignDlg::OnOK() 
{

//	UpdateData(TRUE);
//	AfxMessageBox("a", MB_OK);
//	theApp.currentSigner->setSignerInfo(signerList[m_comboSigner.GetCurSel()]);
//	theApp.currentSigner->setHashAlgorithm(m_hash);
//	theApp.currentSigner->setSignDate(CTime::GetCurrentTime());
//	theApp.currentSigner->set
	CDialog::OnOK();
	signer = signerList[m_Signer];
	delete cert;
	//AfxMessageBox(signer.SignerName, MB_OK);
}

void CSignDlg::OnMd4() 
{
	m_hash = "MD4";	
}

void CSignDlg::OnMd5() 
{
	m_hash = "MD5";	
}

void CSignDlg::OnSha1() 
{
	m_hash = "SHA-1";
}

BOOL CSignDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	cert = new CCertStore();
	cert->ReadCertificateInStore();
	CString Subject;
	signerList = cert->get_signerInfoList();
	for(int i=0; i<(int)cert->get_signerCount() ; i++){
		Subject = signerList[i].SignerName;
		m_comboSigner.AddString(Subject);
	}	
	CButton *hashAlgo;
	hashAlgo = (CButton*)GetDlgItem(IDC_MD4);
	hashAlgo->SetCheck(TRUE);
	m_hash = "MD4";

	m_fmCtrl.SetTime(&CTime::GetCurrentTime());
	m_toCtrl.SetTime(&CTime::GetCurrentTime());
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
