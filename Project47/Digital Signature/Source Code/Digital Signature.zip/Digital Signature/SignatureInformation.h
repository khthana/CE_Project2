// SignatureInformation.h: interface for the SignatureInformation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIGNATUREINFORMATION_H__E2ED7ADC_2A88_4716_B612_B4740C5D9E5F__INCLUDED_)
#define AFX_SIGNATUREINFORMATION_H__E2ED7ADC_2A88_4716_B612_B4740C5D9E5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Utility.h"

class SignatureInformation:public CObject 
{
public:
	SignatureInformation();
	SignatureInformation(const SignatureInformation&);
	virtual ~SignatureInformation();

	void setSignerInfo(SignerInformation);
	void setHashAlgorithm(CString);
	void setSignDate(CTime);
	void setCertDuration(CTime, CTime);
	void setPbSignatureBlob(BYTE*, UINT);
	void setPictureNumber(int);
	void setPbSignatureLen(UINT);
	void setSignStatus(int);

	SignerInformation getSignerInfo();
	CString getHashAlgorithm();
	CTime getSignDate();
	CTime getCertFrom();
	CTime getCertTo();
	BYTE* getPbSignatureBlob();
	UINT getPbSignatureBlobLength();
	int getPictureNumber();
	int getSignStatus();

	void Serialize(CArchive&);
	//for ARCHIVE function
	DECLARE_SERIAL(SignatureInformation) 
private:
	SignerInformation signerInfo;
	CString hashAlgo;
	CTime signDate;
	CTime certFrom;
	CTime certTo;
	BYTE *pbSignature;
	UINT pbSignatureLen;
	int picNumber;
	int signStatus; // 0 = new signature , 1 = signature is signed , -1 = signature was not complete
};

#endif // !defined(AFX_SIGNATUREINFORMATION_H__E2ED7ADC_2A88_4716_B612_B4740C5D9E5F__INCLUDED_)
