#if !defined(AFX_PICTURE_H__48BA0FD3_DC43_48CC_A457_7854D0C2B075__INCLUDED_)
#define AFX_PICTURE_H__48BA0FD3_DC43_48CC_A457_7854D0C2B075__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Picture.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPicture dialog

class CPicture : public CDialog
{
// Construction
public:
	CPicture(CWnd* pParent = NULL);   // standard constructor
	int picNumber;
	void setPicNumber(int);
// Dialog Data
	//{{AFX_DATA(CPicture)
	enum { IDD = IDD_PICTURE };
	CStatic	m_Pic;
	CListBox	m_CList;
	CString	m_List;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicture)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPicture)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList2();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICTURE_H__48BA0FD3_DC43_48CC_A457_7854D0C2B075__INCLUDED_)
