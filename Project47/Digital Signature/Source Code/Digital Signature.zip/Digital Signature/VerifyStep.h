#if !defined(AFX_VERIFYSTEP_H__6433B7CE_7A0B_4775_8599_0C7DB2602D0F__INCLUDED_)
#define AFX_VERIFYSTEP_H__6433B7CE_7A0B_4775_8599_0C7DB2602D0F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VerifyStep.h : header file
//

#include "Isagsign v2Doc.h"
#include "FontCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CVerifyStep dialog

class CVerifyStep : public CDialog
{
// Construction
public:
	CVerifyStep(CWnd* pParent = NULL);   // standard constructor
	CIsagsignv2Doc *pDoc;
	void getDoc(CIsagsignv2Doc*);
	void setResult(int);
private:
	SignerInformation signerInfo;
	CString hashAlgo;
	CTime signDate;
	CTime certFrom;
	CTime certTo;
	int result;
	CBitmap bmLtOff;
// Dialog Data
	//{{AFX_DATA(CVerifyStep)
	enum { IDD = IDD_VERIFY };
	CStatic	m_VerifyPic;
	CStatic m_Subject;
	CStatic m_Issuer;
	CStatic m_KeyFm;
	CStatic m_KeyTo;
	CStatic m_Hash;
	CStatic m_Sign;
	CStatic m_SignFm;
	CStatic m_SignTo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVerifyStep)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CVerifyStep)
	virtual BOOL OnInitDialog();
	afx_msg void OnButton1();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VERIFYSTEP_H__6433B7CE_7A0B_4775_8599_0C7DB2602D0F__INCLUDED_)
