// Isagsign v2.h : main header file for the ISAGSIGN V2 application
//

#if !defined(AFX_ISAGSIGNV2_H__ECD011B5_F287_47A7_8523_9D9F5094AEA0__INCLUDED_)
#define AFX_ISAGSIGNV2_H__ECD011B5_F287_47A7_8523_9D9F5094AEA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "SignatureInformation.h"
#define MY_ENCODE_TYPE (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING)
#define _WIN32_WINNT 0X0500
#include <windows.h>
#include <wincrypt.h>
/////////////////////////////////////////////////////////////////////////////
// CIsagsignv2App:
// See Isagsign v2.cpp for the implementation of this class
//

class CIsagsignv2App : public CWinApp
{
public:
	CIsagsignv2App();
	BYTE* digitalTest;
	void GetDataBlock(BYTE*,UINT&);
	BYTE* GetDataBlock(UINT&);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIsagsignv2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	COleTemplateServer m_server;
		// Server object for document creation
	//{{AFX_MSG(CIsagsignv2App)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAGSIGNV2_H__ECD011B5_F287_47A7_8523_9D9F5094AEA0__INCLUDED_)
