// Isagsign v2View.h : interface of the CIsagsignv2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISAGSIGNV2VIEW_H__08911C23_464D_45F9_BFEE_F73456E23A33__INCLUDED_)
#define AFX_ISAGSIGNV2VIEW_H__08911C23_464D_45F9_BFEE_F73456E23A33__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CIsagsignv2View : public CView
{
protected: // create from serialization only
	CIsagsignv2View();
	DECLARE_DYNCREATE(CIsagsignv2View)

// Attributes
public:
	CIsagsignv2Doc* GetDocument();
	BYTE* GetDataBlock(UINT&);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIsagsignv2View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIsagsignv2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CIsagsignv2View)
	afx_msg void OnCancelEditSrvr();
	afx_msg void OnVerify();
	afx_msg void OnImport();
	afx_msg void OnExport();
	afx_msg void OnSign();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Isagsign v2View.cpp
inline CIsagsignv2Doc* CIsagsignv2View::GetDocument()
   { return (CIsagsignv2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAGSIGNV2VIEW_H__08911C23_464D_45F9_BFEE_F73456E23A33__INCLUDED_)
