// SignStep2.cpp : implementation file
//

#include "stdafx.h"
#include "Isagsign v2.h"
#include "SignStep2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep2 property page

IMPLEMENT_DYNCREATE(CSignStep2, CPropertyPage)

CSignStep2::CSignStep2() : CPropertyPage(CSignStep2::IDD)
{
	//{{AFX_DATA_INIT(CSignStep2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CSignStep2::~CSignStep2()
{
	delete cert;	
}

void CSignStep2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep2)
	DDX_Control(pDX, IDC_LIST1, m_Cstep2);
	DDX_Control(pDX, IDC_SUBJECT, m_Subject);
	DDX_Control(pDX, IDC_ISSUER, m_Issuer);
	DDX_Control(pDX, IDC_VALIDFM, m_ValidFm);
	DDX_Control(pDX, IDC_VALIDTO, m_ValidTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSignStep2, CPropertyPage)
	//{{AFX_MSG_MAP(CSignStep2)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, OnClickList1)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignStep2 message handlers

BOOL CSignStep2::OnSetActive() 
{
	CPropertySheet* parent = (CPropertySheet*)GetParent();
	if(count<0) parent->SetWizardButtons(PSWIZB_BACK);
	else parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	return CPropertyPage::OnSetActive();
}

BOOL CSignStep2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	CImageList *imgISAGSIGN;

	imgISAGSIGN = new CImageList();
	imgISAGSIGN->Create(32,32,ILC_COLOR16,2,0);
	imgISAGSIGN->Add(AfxGetApp()->LoadIcon(IDR_ICON1));
	m_Cstep2.SetImageList(imgISAGSIGN, LVSIL_NORMAL);

	cert = new CCertStore();
	count = -1;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSignStep2::OnClickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	count = m_Cstep2.GetSelectionMark();
	if(count<0) return; // if user have not choose certificate yet, progrem will reject 
	CPropertySheet* parent = (CPropertySheet*)GetParent();
    parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	// show output to dialog
	m_Subject.SetWindowText(signerList[count].SignerName);
	m_Issuer.SetWindowText(signerList[count].IssuerName);
	m_ValidFm.SetWindowText(signerList[count].IssueDate.FormatGmt("%H:%M , %d %A %B %Y"));
	m_ValidTo.SetWindowText(signerList[count].RevocationDate.FormatGmt("%H:%M , %d %A %B %Y"));
	*pResult = 0;
}

LRESULT CSignStep2::OnWizardNext() 
{
	if(count<0) return -1;
	signer = signerList[count];
	return CPropertyPage::OnWizardNext();
}

void CSignStep2::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	m_Cstep2.DeleteAllItems();
	cert->ReadCertificateInStore();
	signerList = cert->get_signerInfoList();
	LV_ITEM item;	
	int subItemNext;
	// show all certificates to dialog
	for(int i=0; i<(int)cert->get_signerCount() ; i++){
		item.mask = LVIF_TEXT | LVIF_IMAGE;
		item.iItem = i;
		item.iSubItem = 0;
		item.iImage = 0;
		item.pszText = signerList[i].SignerName.GetBuffer(0);
		subItemNext = m_Cstep2.InsertItem(&item);
	}		
	// Do not call CPropertyPage::OnPaint() for painting messages
}
