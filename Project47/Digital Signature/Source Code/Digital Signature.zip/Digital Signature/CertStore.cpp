// CertStore.cpp: implementation of the CCertStore class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CertStore.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCertStore::CCertStore()
{
	signerCount = 0;
}

CCertStore::~CCertStore()
{
	delete [] signerInfoList;
}

void CCertStore::HandleError(CString errorMsg)
{
	AfxMessageBox(errorMsg, MB_OK | MB_ICONINFORMATION);
	exit(1);
}

void CCertStore::ReadCertificateInStore()
{
	int				index = 0;
	HANDLE			hStoreHandle;
	char			systemProtocol[256] = "MY";
	PCCERT_CONTEXT	pCertContext = NULL;
	PCCERT_CONTEXT	pDupCertContext = NULL;
	FILETIME		t1, t2;
	CString			tempIssuerStr, tempSubjectStr;
	
	//open system certificate store.
	if(!(hStoreHandle = CertOpenSystemStore(NULL,systemProtocol)))
		HandleError("Error during CertOpenSystemStore !");

	//count number of Certificate in store
	while(pCertContext = CertEnumCertificatesInStore(hStoreHandle,pCertContext))
		signerCount++;

	//allocate memory for 'SignerInformation'
	signerInfoList = new SignerInformation[signerCount];

	while(pCertContext = CertEnumCertificatesInStore(hStoreHandle, pCertContext)){
		//get Issue date from certificate
		t1 = pCertContext->pCertInfo->NotAfter;
		//get expire date from certificate
		t2 = pCertContext->pCertInfo->NotBefore;
		//get Issuer&Subject form certificate
		tempIssuerStr = DecodeCertificate(&(pCertContext->pCertInfo->Issuer));
		tempSubjectStr = DecodeCertificate(&(pCertContext->pCertInfo->Subject));
		//retrieve Issuer&Subject
		tempIssuerStr = RetrieveIssuer(tempIssuerStr);
		tempSubjectStr = RetrieveSubject(tempSubjectStr);
		//assign value for signerInfoList
		if(CheckRevocationDate(pCertContext)){
			signerInfoList[index].IssuerName = tempIssuerStr;
			signerInfoList[index].SignerName = tempSubjectStr;
			signerInfoList[index].IssueDate = CTime(t2);
			signerInfoList[index].RevocationDate = CTime(t1);
			index++;
		}
	}
	signerCount = index;
	CertCloseStore(hStoreHandle, 0);
}

CString CCertStore::DecodeCertificate(CERT_NAME_BLOB *nameBlob)
{
	DWORD	cbName;
	DWORD	dwStrType = CERT_OID_NAME_STR;
	LPSTR	pszName;

	cbName = CertNameToStr(
			 MY_ENCODE_TYPE,
			 nameBlob,
			 dwStrType,
			 NULL,
			 0);

	if(!(pszName = new char[cbName]))
		HandleError("Error during in a allcation memory for CERT_NAME_BLOB !");

	cbName = CertNameToStr(
			 MY_ENCODE_TYPE,
			 nameBlob,
			 dwStrType,
			 pszName,
			 cbName);
	return pszName;
}

SignerInformation* CCertStore::get_signerInfoList()
{
	return this->signerInfoList;
}

UINT CCertStore::get_signerCount()
{
	return this->signerCount;
}

CString CCertStore::RetrieveIssuer(CString certStr)
{
	// Declare and initialize local variable here.
	int					t1 = -1 , t2 = -1;
	CString				tag;
	CString				tempStr1(certStr) , tempStr2 , tempStr3 , tempStr4;
	
	// Cut the issuer name of signer certificate from pszName string.
	tag = "2.5.4.10";
		
	t1 = tempStr1.Find(tag);								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	// If the certificate is not trust by Certificate Authority then return 'NONE ISSUER'.
	if (t1 == -1)
		return "NONE ISSUER";

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');

	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx

	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx

	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

CString CCertStore::RetrieveSubject(CString certStr)
{
	// Declare and initialize local variable here.
	int					t1 , t2;
	CString				tag;
	CString				tempStr1(certStr) , tempStr2 , tempStr3 , tempStr4;
	
	// Cut the issuer name of signer certificate from pszName string.
	tag = "2.5.4.3";
		
	t1 = tempStr1.Find(tag);								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');

	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx

	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx

	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

BOOL CCertStore::CheckRevocationDate(const CERT_CONTEXT *pCertContext)
{
	FILETIME t1 = pCertContext->pCertInfo->NotAfter;
	CTime currentTime = CTime::GetCurrentTime();
	CTime expiredTime(t1);

	if(!(currentTime <= expiredTime))
		return FALSE;
	else 
		return TRUE;
}
