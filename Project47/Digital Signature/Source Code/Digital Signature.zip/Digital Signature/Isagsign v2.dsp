# Microsoft Developer Studio Project File - Name="Isagsign v2" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=Isagsign v2 - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "Isagsign v2.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Isagsign v2.mak" CFG="Isagsign v2 - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Isagsign v2 - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Isagsign v2 - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Isagsign v2 - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 Crypt32.lib /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "Isagsign v2 - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 Crypt32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "Isagsign v2 - Win32 Release"
# Name "Isagsign v2 - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\CertStore.cpp
# End Source File
# Begin Source File

SOURCE=.\ExportDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\FileDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ImportAndExport.cpp
# End Source File
# Begin Source File

SOURCE=.\IpFrame.cpp
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2.cpp"
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2.odl"
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2.rc"
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2Doc.cpp"
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2View.cpp"
# End Source File
# Begin Source File

SOURCE=.\MainFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\msword8.cpp
# End Source File
# Begin Source File

SOURCE=.\Picture.cpp
# End Source File
# Begin Source File

SOURCE=.\SignAndVerify.cpp
# End Source File
# Begin Source File

SOURCE=.\SignatureInformation.cpp
# End Source File
# Begin Source File

SOURCE=.\SignSheet.cpp
# End Source File
# Begin Source File

SOURCE=.\SignStep1.cpp
# End Source File
# Begin Source File

SOURCE=.\SignStep2.cpp
# End Source File
# Begin Source File

SOURCE=.\SignStep3.cpp
# End Source File
# Begin Source File

SOURCE=.\SignStep4.cpp
# End Source File
# Begin Source File

SOURCE=.\SrvrItem.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\VerifyStep.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=D:\Program\VC98\MFC\Include\AFXWIN.H
# End Source File
# Begin Source File

SOURCE=.\CertStore.h
# End Source File
# Begin Source File

SOURCE=.\ExportDlg.h
# End Source File
# Begin Source File

SOURCE=.\FileDlg.h
# End Source File
# Begin Source File

SOURCE=.\FontCtrl.h
# End Source File
# Begin Source File

SOURCE=.\ImportAndExport.h
# End Source File
# Begin Source File

SOURCE=.\IpFrame.h
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2.h"
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2Doc.h"
# End Source File
# Begin Source File

SOURCE=".\Isagsign v2View.h"
# End Source File
# Begin Source File

SOURCE=.\MainFrm.h
# End Source File
# Begin Source File

SOURCE=.\msword8.h
# End Source File
# Begin Source File

SOURCE=.\Picture.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\SignAndVerify.h
# End Source File
# Begin Source File

SOURCE=.\SignatureInformation.h
# End Source File
# Begin Source File

SOURCE=.\SignSheet.h
# End Source File
# Begin Source File

SOURCE=.\SignStep1.h
# End Source File
# Begin Source File

SOURCE=.\SignStep2.h
# End Source File
# Begin Source File

SOURCE=.\SignStep3.h
# End Source File
# Begin Source File

SOURCE=.\SignStep4.h
# End Source File
# Begin Source File

SOURCE=.\SrvrItem.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\TemplDef.h
# End Source File
# Begin Source File

SOURCE=.\Utility.h
# End Source File
# Begin Source File

SOURCE=.\VerifyStep.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\res\bitmap1.bmp
# End Source File
# Begin Source File

SOURCE=.\res\bitmap3.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Early.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Expired.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Expired2.bmp
# End Source File
# Begin Source File

SOURCE=.\res\icon1.ico
# End Source File
# Begin Source File

SOURCE=".\res\Isagsign v2.ico"
# End Source File
# Begin Source File

SOURCE=".\res\Isagsign v2.rc2"
# End Source File
# Begin Source File

SOURCE=".\res\Isagsign v2Doc.ico"
# End Source File
# Begin Source File

SOURCE=.\res\IToolbar.bmp
# End Source File
# Begin Source File

SOURCE=.\res\modified.bmp
# End Source File
# Begin Source File

SOURCE=.\res\pen.bmp
# End Source File
# Begin Source File

SOURCE=.\res\PEN05.ICO
# End Source File
# Begin Source File

SOURCE=".\res\Pic1-1.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\pic1.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Pic10.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Pic11.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Pic12.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic2-2.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic2.bmp
# End Source File
# Begin Source File

SOURCE=.\res\pic22.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic3-3.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic3.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic4-4.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic4.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic5-5.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic5.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic6-6.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic6.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic7-7.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic7.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic8-8.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic8.bmp
# End Source File
# Begin Source File

SOURCE=".\res\Pic9-9.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\Pic9.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Pic_10_10.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Pic_11_11.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Pic_12_12.bmp
# End Source File
# Begin Source File

SOURCE=.\res\sig1.bmp
# End Source File
# Begin Source File

SOURCE=.\res\sig2.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Toolbar.bmp
# End Source File
# Begin Source File

SOURCE=.\res\unmodified.bmp
# End Source File
# End Group
# Begin Source File

SOURCE=".\Isagsign v2.reg"
# End Source File
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# End Target
# End Project
