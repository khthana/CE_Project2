% clear and close all
clear all
close all
clc

% get the path of all image
inputpath = input('Enter the path of the image \n','s');

% number of images on your training set.
%M=40;
M = input('Enter number of image \n','s');
M = str2num(M);

%============================ Get Trainning Image ====================
%Chosen std and mean. 
%It can be any number that it is close to the std and mean of most of the images.
um=100;
ustd=80;

%read and show images(bmp);
S=[];   %img matrix
figure(1);

for i=1:M
    str = strcat(inputpath,int2str(i),'.jpg');

    %str=strcat(int2str(i),'.jpg');   %concatenates two strings that form the name of the image
  
    img=imread(str);
    %img = SkinSegment(str);
    
    %strName=strcat('E:\project\Senior Project\Source Code\Image\1.0\TrainningImDB\trainIm',int2str(i),'.jpg');
    %imwrite(img,strName);   % store trainning Image in new file

    subplot(ceil(sqrt(M)),ceil(sqrt(M)),i)
    imshow(img)
    
    %if i==3
    %    title('Training set','fontsize',18)
    %end
    
    drawnow;
    
    img = rgb2gray(img);
    
    [irow icol]=size(img);    % get the number of rows (N1) and columns (N2)
    
    temp=reshape(img',irow*icol,1);     %creates a (N1*N2)x1 matrix                     img' = img transpose array
    
    S=[S temp];         %X is a N1*N2xM matrix after finishing the sequence
                        %this is our S
end
%============================ Image Normalization ====================

%Here we change the mean and std of all images. We normalize all images.
%This is done to reduce the error due to lighting conditions.
for i=1:size(S,2)
    temp=double(S(:,i));
    m=mean(temp);
    st=std(temp);
    S(:,i)=(temp-m)*ustd/st+um;
end

%show normalized images
figure(2);
for i=1:M
    %str=strcat('E:\project\Senior Project\Source Code\Image\1.0\TrainningImDB\normIm',int2str(i),'.jpg');
   
    img=reshape(S(:,i),icol,irow);
    
    img = img';
      
    subplot(ceil(sqrt(M)),ceil(sqrt(M)),i)

    imshow(img);
    drawnow;
    
    if i==3
        title('Normalized Training Set','fontsize',18)
    end
end

%============================ Get Mean Image ====================
%mean image;
m=mean(S,2);   %obtains the mean of each row instead of each column
tmimg=uint8(m);   %converts to unsigned 8-bit integer. Values range from 0 to 255
img=reshape(tmimg,icol,irow);    %takes the N1*N2x1 vector and creates a N2xN1 matrix

img=img';       %creates a N1xN2 matrix by transposing the image.

figure(3);
imshow(img);
title('Mean Image','fontsize',18)

% Change image for manipulation
dbx=[];   % A matrix
for i=1:M
    temp=double(S(:,i));
    dbx=[dbx temp];
end

%Covariance matrix C=A'A, L=AA'
A=dbx';

L=A*A';

% vv are the eigenvector for L
% dd are the eigenvalue for both L=dbx'*dbx and C=dbx*dbx';
[vv dd]=eig(L);
% Sort and Eliminate those whose eigenvalue is zero
v=[];
d=[];
for i=1:size(vv,2)
    if(dd(i,i)>1e-4)
        v=[v vv(:,i)];
        d=[d dd(i,i)];
    end
 end
 
 %sort,  will return an ascending sequence
 [B index]=sort(d);
 ind=zeros(size(index));
 dtemp=zeros(size(index));
 vtemp=zeros(size(v));
 len=length(index);
 for i=1:len
    dtemp(i)=B(len+1-i);
    ind(i)=len+1-index(i);
    vtemp(:,ind(i))=v(:,i);
 end
 d=dtemp;
 v=vtemp;


%Normalization of eigenvectors
 for i=1:size(v,2)       %access each column
   kk=v(:,i);
   temp=sqrt(sum(kk.^2));
   v(:,i)=v(:,i)./temp;
end

%Eigenvectors of C matrix
u=[];
for i=1:size(v,2)
    temp=sqrt(d(i));
    u=[u (dbx*v(:,i))./temp];
end

%Normalization of eigenvectors
for i=1:size(u,2)
   kk=u(:,i);
   temp=sqrt(sum(kk.^2));
	u(:,i)=u(:,i)./temp;
end


% show eigenfaces;
figure(4);
for i=1:size(u,2)
    img=reshape(u(:,i),icol,irow);

    img=img';
    
    img=histeq(img,255);
    
    subplot(ceil(sqrt(M)),ceil(sqrt(M)),i)
    imshow(img)
    drawnow;
    if i==3
        title('Eigenfaces','fontsize',18)
    end
end


% Find the weight of each face in the training set.
omega = [];

for h=1:size(dbx,2) 
    WW=[]; 
    
    for i=1:size(u,2)
        t = u(:,i)';    
        WeightOfImage = dot(t,dbx(:,h)');

        WW = [WW; WeightOfImage];
    end
    
    omega = [omega WW];
end


%=======================  Acquire new image ======================
% Note: the input image must have a bmp or jpg extension. 
%       It should have the same size as the ones in your training set. 
%       It should be placed on your desktop 
strInput = input('Enter the path and the filename of the image and its extension \n','s');
%InputImage = imread(strcat('D:\image\training24\',strInput));
InputImage = imread(strInput);

%InputImage = imread(InputImage);
%InputImage = SkinSegment(strInput);

figure(5)
subplot(1,2,1)

imshow(InputImage); 
colormap('gray');
title('Input image','fontsize',18)

InputImage = rgb2gray(InputImage);
InImage=reshape(double(InputImage)',irow*icol,1);  

temp=InImage;

me=mean(temp);

st=std(temp);

temp=(temp-me)*ustd/st+um;

NormImage = temp;

Difference = temp-m;

p = [];

aa=size(u,2);

for i = 1:aa
    pare = dot(NormImage,u(:,i));
    p = [p; pare];
end

ReshapedImage = m + u(:,1:aa)*p;    %m is the mean image, u is the eigenvector
ReshapedImage = reshape(ReshapedImage,icol,irow);
ReshapedImage = ReshapedImage';

%show the reconstructed image.
subplot(1,2,2)

imagesc(ReshapedImage); colormap('gray');
title('Reconstructed image','fontsize',18)

InImWeight = [];
for i=1:size(u,2)
    t = u(:,i)';
    WeightOfInputImage = dot(t,Difference');
    InImWeight = [InImWeight; WeightOfInputImage];
end

ll = 1:M;
figure(6)
subplot(1,2,1)
stem(ll,InImWeight)
title('Weight of Input Face','fontsize',14)

% Find Euclidean distance
e=[];
for i=1:size(omega,2)
    q = omega(:,i);
    DiffWeight = InImWeight-q;
    mag = norm(DiffWeight);
    e = [e mag];
end

kk = 1:size(e,2);
subplot(1,2,2)
stem(kk,e)
title('Eucledian distance of input image','fontsize',14)


MaximumValue=max(e);
[MinimumValue,index]=min(e);

disp('The found image =');
disp(index);
disp('The Eucledian Distance =');
disp(MinimumValue);

dispInputImg = imread(strInput);
figure(7);
subplot(1,2,1);
imshow(dispInputImg);
title('Input Image','fontsize',14);
subplot(1,2,2);
imshow(strcat(inputpath,int2str(index),'.jpg'));
title('Image Found','fontsize',14);