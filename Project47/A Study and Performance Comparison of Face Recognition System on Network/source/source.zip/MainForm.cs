/******************************************************
                  DirectShow .NET
		      netmaster@swissonline.ch
*******************************************************/
//				SampleGrabber MainForm

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;

using DShowNET;
using DShowNET.Device;


namespace FaceRecognition
{

	public class FaceDetect
	{
		private Bitmap pic1;
		private Bitmap pic2;
		private Bitmap pic3;
		private Bitmap pic4;
			
		private double[,] tempY;
		private double[,] tempCb;
		private double[,] tempCr;
		
		public FaceDetect()
		{
		}
		
		public Bitmap DetectFace(Bitmap original)
		{
			Bitmap outpic;
			Bitmap tmppic = new Bitmap(original);
			pic1 = resize(tmppic,320,240);
			pic1 = rgb2ycbcr(pic1);
			pic2 = detect(pic1);
			pic3 = rgb2gray(pic2);
			pic4 = gray2bw(pic3);
			outpic = crop(original,pic4);
			outpic = rgb2gray(outpic);
			outpic = resize(outpic,100,125);
			
			//return outpic;
			return outpic;
		}
		
		
		// convert rgb to ycbcr
		public Bitmap rgb2ycbcr(Bitmap inpic)
		{
			Bitmap outpic;
			byte y,cb,cr;
			double dy,dcb,dcr;
			Color c;
	
			outpic = new Bitmap(inpic.Width,inpic.Height);
			
			tempY  = new double[inpic.Width,inpic.Height];
			tempCb = new double[inpic.Width,inpic.Height];
			tempCr = new double[inpic.Width,inpic.Height];
			
			for(int xx=0; xx<inpic.Width; xx++)
			{
				for(int yy=0; yy<inpic.Height; yy++)
				{
					c = inpic.GetPixel(xx,yy);
					
					dy  = ((0.299)*(c.R) + (0.587)*(c.G) + (0.114)*(c.B));
					dcb = ((-0.169)*(c.R) + (-0.331)*(c.G) + (0.500)*(c.B));
					dcr = ((0.500)*(c.R) + (-0.419)*(c.G) + (-0.081)*(c.B));
					
					y = (byte)dy;
					cb = (byte)dcb;
					cr = (byte)dcr;
					
					this.tempY[xx,yy] = dy;
					this.tempCb[xx,yy] = dcb;
					this.tempCr[xx,yy] = dcr;
					
					outpic.SetPixel(xx,yy,Color.FromArgb(y,cb,cr));
					
				}
			}
			
			return outpic;
		}
		
		// convert ycbcr to rgb
		private Bitmap ycbcr2rgb(Bitmap inpic)
		{
			Bitmap outpic;
			byte y,cb,cr;
			byte r,g,b;
			Color c;
			outpic = new Bitmap(inpic);
			
			for(int xx=0; xx<outpic.Width; xx++)
			{
				for(int yy=0; yy<outpic.Height; yy++)
				{
					c = outpic.GetPixel(xx,yy);
					
					y  = c.R;
					cb = c.G;
					cr = c.B;
					
					r = (byte)((1.164)*(y - 16) + (1.596)*(cr - 128));
					g = (byte)((1.164)*(y - 16) - (0.391)*(cb - 128) - (0.813)*(cr - 128));
					b = (byte)((1.164)*(y - 16) + (2.018)*(cb - 128));
					
					outpic.SetPixel(xx,yy,Color.FromArgb(r,g,b));
					
				}
			}
			
			return outpic;
		}
		
		// skin color segmentation		
		private Bitmap detect(Bitmap inpic)
		{
			Bitmap outpic;
			double theta1, theta2, theta3, theta4;
			double dY, dCb, dCr;
			
			outpic = new Bitmap(inpic);
			for(Int32 xx = 0; xx < inpic.Width; xx++)
			{
				for(Int32 yy = 0; yy < inpic.Height; yy++)
				{
									
					dY = this.tempY[xx,yy];
					dCb = this.tempCb[xx,yy];
					dCr = this.tempCr[xx,yy];
					
					//dY = (dY * 255);
					//dCb = (dCb * 255) - 127;
					//dCr = (dCr * 255) - 127;
					
					//dY = c.R;
					//dCb = c.G;
					//dCr = c.B;
					
					
					// calculate skin equation variable
					if(dY > 128)
					{
						theta1 = (-2) + (256 - dY)/16;
						theta2 = 20 - (256 - dY)/16;
						theta3 = 6;
						theta4 = (-8);
					}
					else	// Y <= 128
					{
						theta1 = 6;
						theta2 = 12;
						theta3 = 2 + (dY/32);
						theta4 = (-16) + (dY/16);
					}
					
					if(dCr >= (-2)*(dCb + 24))
					{
						if(dCr >= (-1)*(dCb + 17))
						{
							if(dCr >= (-4)*(dCb + 32))
							{
								if(dCr >= (2.5)*(dCb + theta1))
								{
									if(dCr >= theta3)
									{
										if(dCr >= (0.5)*(theta4 - dCb))
										{
											if(dCr <= ((220 - dCb)/6))
											{
												if(dCr <= ( 4 / 3)*(theta2 - dCb))
												{
													//this.found++;
												}
												else
												{
													outpic.SetPixel(xx,yy,Color.Black);
												}
											}
											else
											{
												outpic.SetPixel(xx,yy,Color.Black);
											}
										}
										else
										{
											outpic.SetPixel(xx,yy,Color.Black);
										}
									}
									else
									{
										outpic.SetPixel(xx,yy,Color.Black);
									}
								}
								else
								{
									outpic.SetPixel(xx,yy,Color.Black);
								}
							}
							else
							{
								outpic.SetPixel(xx,yy,Color.Black);
							}
						}
						else
						{
							outpic.SetPixel(xx,yy,Color.Black);
						}
					}
					else
					{
						outpic.SetPixel(xx,yy,Color.Black);
					}

						
				}
			}


			return outpic;
		}
		
		// convert rgb to gray
		private Bitmap rgb2gray(Bitmap inpic)	
		{
			Bitmap outpic;
			Color c;
			byte gray;
			outpic = new Bitmap(inpic);
			for(int xx=0; xx<outpic.Width; xx++)
			{
				for(int yy=0; yy<outpic.Height; yy++)
				{
					c = outpic.GetPixel(xx,yy);
					gray = (byte)((0.257)*(c.R) + (0.504)*(c.G) + (0.098)*(c.B) + 16);
					//gray = (byte)((-0.148)*(c.R) - (0.291)*(c.G) + (0.439)*(c.B) + 128);
					//gray = (byte)((0.439)*(c.R) - (0.368)*(c.G) - (0.071)*(c.B) +128);
					outpic.SetPixel(xx,yy,Color.FromArgb(gray,gray,gray));
					
				}
			}
			return outpic;
		}
		
		// convert gray to black&white
		private Bitmap gray2bw(Bitmap inpic)
		{
			Bitmap outpic;
			Color c;
			byte gray;
			outpic = new Bitmap(inpic);
			for(int xx=0; xx<outpic.Width; xx++)
			{
				for(int yy=0; yy<outpic.Height; yy++)
				{
					c = outpic.GetPixel(xx,yy);
					gray = c.R;
					if (gray < 128)
						outpic.SetPixel(xx,yy,Color.Black);
					else
						outpic.SetPixel(xx,yy,Color.White);
					
				}
			}
			return outpic;
		}
		
		// crop image
		private Bitmap crop(Bitmap original, Bitmap inpic)	// inpic is bw pic
		{
			Bitmap tmppic,outpic;
			Color c;
			int xx,yy,width,height;
			int up,down,left,right;
			tmppic = new Bitmap(inpic);
				
			// left
			xx = 0;
			yy = 0;
			c = Color.Black;
			while(c.R == 0)	// while color is black
			{
				c = tmppic.GetPixel(xx,yy);
				if(yy == 239)
				{
					yy = 0;
					xx++;
				}
				else
					yy++;
			}
			left = xx;
			
			
			// right
			xx = 319;
			yy = 0;
			c = Color.Black;
			while(c.R == 0)	// while color is black
			{
				c = tmppic.GetPixel(xx,yy);
				if(yy == 239)
				{
					yy = 0;
					xx--;
				}
				else
					yy++;
			}
			right = xx;
			
			
			// up
			xx = 0;
			yy = 0;
			c = Color.Black;
			while(c.R == 0)	// while color is black
			{
				c = tmppic.GetPixel(xx,yy);
				if(xx == 319)
				{
					xx = 0;
					yy++;
				}
				else
					xx++;
			}
			up = yy;
			
			// down
			width = right - left + 1;
			height = (int)(1.25 * width);	// width:height = 1:1.25
			//height = (int)(1 * width);	// width:height = 1:1
			down = up + height - 1;
			if(down>239)
				down = 239;
			
			outpic = new Bitmap(width,height);
			
			
			for( int j=up; j<(down+1); j++ )
				for( int i=left; i<(right+1); i++ )
				{
					c = original.GetPixel(i,j);
					outpic.SetPixel( (i-left),(j-up),c );
				}
			
			return outpic;
		}
		
		// resize image **reduce resolution
		private Bitmap resize(Bitmap inpic,int width,int height)
		{
			Bitmap outpic;
			outpic = new Bitmap(width,height);
			
			double nXFactor = (double)inpic.Width/width;
			double nYFactor = (double)inpic.Height/height;

			for (int x = 0; x < outpic.Width; ++x)
				for (int y = 0; y < outpic.Height; ++y)
					outpic.SetPixel( x, y, inpic.GetPixel(
						(int)(Math.Floor(x * nXFactor)),(int)(Math.Floor(y * nYFactor)) ) );
			
			return outpic;
		}	
		
	}


	/// <summary> Summary description for MainForm. </summary>
	public class MainForm : System.Windows.Forms.Form, ISampleGrabberCB
	{
		// my varaible
		private string fileName;

		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.ToolBar toolBar;
		private System.Windows.Forms.Panel videoPanel;
		private System.Windows.Forms.PictureBox pictureBox;
		private System.Windows.Forms.ToolBarButton toolBarBtnTune;
		private System.Windows.Forms.ToolBarButton toolBarBtnGrab;
		private System.Windows.Forms.ToolBarButton toolBarBtnSave;
		private System.Windows.Forms.ToolBarButton toolBarBtnSep;
		private System.Windows.Forms.ImageList imgListToolBar;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Label lblTime;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnNSSearch;
		private System.Windows.Forms.Button btnNSClear;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtNSName;
		private System.Windows.Forms.TextBox txtNSSurname;
		private System.Windows.Forms.TextBox txtIndex;
		private System.Windows.Forms.Button btnISearch;
		private System.Windows.Forms.Button btnIClear;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button bnSvStart;
		private System.Windows.Forms.Button btnCPClear;
		private System.Windows.Forms.Button btnCPDetect;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Button button1;
		private System.ComponentModel.IContainer components;
		private SaveFileDialog saveDlg;
		private String strImgName;

		public MainForm()
		{
			// Required for Windows Form Designer support
			InitializeComponent();
		}

		/// <summary> Clean up any resources being used. </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				CloseInterfaces();
			
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.toolBar = new System.Windows.Forms.ToolBar();
			this.toolBarBtnTune = new System.Windows.Forms.ToolBarButton();
			this.toolBarBtnGrab = new System.Windows.Forms.ToolBarButton();
			this.toolBarBtnSep = new System.Windows.Forms.ToolBarButton();
			this.toolBarBtnSave = new System.Windows.Forms.ToolBarButton();
			this.imgListToolBar = new System.Windows.Forms.ImageList(this.components);
			this.videoPanel = new System.Windows.Forms.Panel();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.pictureBox = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.button1 = new System.Windows.Forms.Button();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.btnCPDetect = new System.Windows.Forms.Button();
			this.btnCPClear = new System.Windows.Forms.Button();
			this.lblStatus = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.btnExit = new System.Windows.Forms.Button();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lblTime = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.btnIClear = new System.Windows.Forms.Button();
			this.btnISearch = new System.Windows.Forms.Button();
			this.txtIndex = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.txtNSSurname = new System.Windows.Forms.TextBox();
			this.txtNSName = new System.Windows.Forms.TextBox();
			this.btnNSClear = new System.Windows.Forms.Button();
			this.btnNSSearch = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.bnSvStart = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.SuspendLayout();
			// 
			// toolBar
			// 
			this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.toolBarBtnTune,
																					   this.toolBarBtnGrab,
																					   this.toolBarBtnSep,
																					   this.toolBarBtnSave});
			this.toolBar.Cursor = System.Windows.Forms.Cursors.Hand;
			this.toolBar.Dock = System.Windows.Forms.DockStyle.None;
			this.toolBar.DropDownArrows = true;
			this.toolBar.ImageList = this.imgListToolBar;
			this.toolBar.Location = new System.Drawing.Point(16, 272);
			this.toolBar.Name = "toolBar";
			this.toolBar.ShowToolTips = true;
			this.toolBar.Size = new System.Drawing.Size(88, 39);
			this.toolBar.TabIndex = 0;
			this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
			// 
			// toolBarBtnTune
			// 
			this.toolBarBtnTune.Enabled = false;
			this.toolBarBtnTune.ImageIndex = 0;
			this.toolBarBtnTune.Text = "Tune";
			this.toolBarBtnTune.ToolTipText = "TV tuner dialog";
			this.toolBarBtnTune.Visible = false;
			// 
			// toolBarBtnGrab
			// 
			this.toolBarBtnGrab.ImageIndex = 1;
			this.toolBarBtnGrab.Text = "Grab";
			this.toolBarBtnGrab.ToolTipText = "Grab picture from stream";
			// 
			// toolBarBtnSep
			// 
			this.toolBarBtnSep.Enabled = false;
			this.toolBarBtnSep.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarBtnSave
			// 
			this.toolBarBtnSave.Enabled = false;
			this.toolBarBtnSave.ImageIndex = 2;
			this.toolBarBtnSave.Text = "Save";
			this.toolBarBtnSave.ToolTipText = "Save image to file";
			// 
			// imgListToolBar
			// 
			this.imgListToolBar.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imgListToolBar.ImageSize = new System.Drawing.Size(16, 16);
			this.imgListToolBar.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// videoPanel
			// 
			this.videoPanel.BackColor = System.Drawing.Color.Black;
			this.videoPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.videoPanel.Location = new System.Drawing.Point(8, 24);
			this.videoPanel.Name = "videoPanel";
			this.videoPanel.Size = new System.Drawing.Size(320, 240);
			this.videoPanel.TabIndex = 1;
			this.videoPanel.Resize += new System.EventHandler(this.videoPanel_Resize);
			// 
			// splitter1
			// 
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(8, 584);
			this.splitter1.TabIndex = 2;
			this.splitter1.TabStop = false;
			// 
			// pictureBox
			// 
			this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox.Location = new System.Drawing.Point(16, 24);
			this.pictureBox.Name = "pictureBox";
			this.pictureBox.Size = new System.Drawing.Size(320, 240);
			this.pictureBox.TabIndex = 0;
			this.pictureBox.TabStop = false;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.videoPanel,
																					this.toolBar});
			this.groupBox1.Location = new System.Drawing.Point(24, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(336, 320);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Camera";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.button1,
																					this.pictureBox2,
																					this.btnCPDetect,
																					this.btnCPClear,
																					this.pictureBox});
			this.groupBox2.Location = new System.Drawing.Point(368, 16);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(480, 320);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Result";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(376, 280);
			this.button1.Name = "button1";
			this.button1.TabIndex = 17;
			this.button1.Text = "Save";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// pictureBox2
			// 
			this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox2.Location = new System.Drawing.Point(360, 80);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(100, 125);
			this.pictureBox2.TabIndex = 16;
			this.pictureBox2.TabStop = false;
			// 
			// btnCPDetect
			// 
			this.btnCPDetect.Location = new System.Drawing.Point(184, 280);
			this.btnCPDetect.Name = "btnCPDetect";
			this.btnCPDetect.Size = new System.Drawing.Size(80, 23);
			this.btnCPDetect.TabIndex = 15;
			this.btnCPDetect.Text = "Detect";
			this.btnCPDetect.Click += new System.EventHandler(this.btnCPDetect_Click);
			// 
			// btnCPClear
			// 
			this.btnCPClear.Location = new System.Drawing.Point(32, 280);
			this.btnCPClear.Name = "btnCPClear";
			this.btnCPClear.Size = new System.Drawing.Size(80, 23);
			this.btnCPClear.TabIndex = 13;
			this.btnCPClear.Text = "Clear";
			this.btnCPClear.Click += new System.EventHandler(this.btnCPClear_Click);
			// 
			// lblStatus
			// 
			this.lblStatus.BackColor = System.Drawing.Color.White;
			this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(222)));
			this.lblStatus.ForeColor = System.Drawing.Color.Blue;
			this.lblStatus.Location = new System.Drawing.Point(8, 16);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(232, 48);
			this.lblStatus.TabIndex = 6;
			this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.lblStatus});
			this.groupBox3.Location = new System.Drawing.Point(368, 336);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(248, 72);
			this.groupBox3.TabIndex = 7;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Status";
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(720, 544);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(112, 23);
			this.btnExit.TabIndex = 8;
			this.btnExit.Text = "Exit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.label1,
																					this.lblTime});
			this.groupBox4.Location = new System.Drawing.Point(368, 416);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(248, 56);
			this.groupBox4.TabIndex = 9;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Total time";
			this.groupBox4.Visible = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(192, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Second";
			// 
			// lblTime
			// 
			this.lblTime.BackColor = System.Drawing.Color.White;
			this.lblTime.Location = new System.Drawing.Point(8, 24);
			this.lblTime.Name = "lblTime";
			this.lblTime.Size = new System.Drawing.Size(176, 23);
			this.lblTime.TabIndex = 0;
			this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.groupBox7,
																					this.groupBox6});
			this.groupBox5.Location = new System.Drawing.Point(24, 336);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(336, 232);
			this.groupBox5.TabIndex = 10;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Search in Databasae";
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.btnIClear,
																					this.btnISearch,
																					this.txtIndex,
																					this.label6});
			this.groupBox7.Location = new System.Drawing.Point(8, 144);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(296, 80);
			this.groupBox7.TabIndex = 1;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "by Index";
			// 
			// btnIClear
			// 
			this.btnIClear.Location = new System.Drawing.Point(80, 48);
			this.btnIClear.Name = "btnIClear";
			this.btnIClear.Size = new System.Drawing.Size(96, 23);
			this.btnIClear.TabIndex = 3;
			this.btnIClear.Text = "Clear";
			// 
			// btnISearch
			// 
			this.btnISearch.Location = new System.Drawing.Point(192, 48);
			this.btnISearch.Name = "btnISearch";
			this.btnISearch.Size = new System.Drawing.Size(96, 23);
			this.btnISearch.TabIndex = 2;
			this.btnISearch.Text = "Search";
			// 
			// txtIndex
			// 
			this.txtIndex.Location = new System.Drawing.Point(80, 24);
			this.txtIndex.Name = "txtIndex";
			this.txtIndex.Size = new System.Drawing.Size(208, 20);
			this.txtIndex.TabIndex = 1;
			this.txtIndex.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 24);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(40, 23);
			this.label6.TabIndex = 0;
			this.label6.Text = "Index";
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtNSSurname,
																					this.txtNSName,
																					this.btnNSClear,
																					this.btnNSSearch,
																					this.label4,
																					this.label2});
			this.groupBox6.Location = new System.Drawing.Point(8, 16);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(296, 120);
			this.groupBox6.TabIndex = 0;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "by Name and Surname";
			// 
			// txtNSSurname
			// 
			this.txtNSSurname.Location = new System.Drawing.Point(80, 56);
			this.txtNSSurname.Name = "txtNSSurname";
			this.txtNSSurname.Size = new System.Drawing.Size(208, 20);
			this.txtNSSurname.TabIndex = 7;
			this.txtNSSurname.Text = "";
			// 
			// txtNSName
			// 
			this.txtNSName.Location = new System.Drawing.Point(80, 24);
			this.txtNSName.Name = "txtNSName";
			this.txtNSName.Size = new System.Drawing.Size(208, 20);
			this.txtNSName.TabIndex = 6;
			this.txtNSName.Text = "";
			// 
			// btnNSClear
			// 
			this.btnNSClear.Location = new System.Drawing.Point(80, 88);
			this.btnNSClear.Name = "btnNSClear";
			this.btnNSClear.Size = new System.Drawing.Size(96, 23);
			this.btnNSClear.TabIndex = 5;
			this.btnNSClear.Text = "Clear";
			// 
			// btnNSSearch
			// 
			this.btnNSSearch.Location = new System.Drawing.Point(192, 88);
			this.btnNSSearch.Name = "btnNSSearch";
			this.btnNSSearch.Size = new System.Drawing.Size(96, 23);
			this.btnNSSearch.TabIndex = 4;
			this.btnNSSearch.Text = "Search";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 56);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(64, 23);
			this.label4.TabIndex = 2;
			this.label4.Text = "Surname";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 24);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 23);
			this.label2.TabIndex = 0;
			this.label2.Text = "Name";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.bnSvStart,
																					this.label5});
			this.groupBox8.Location = new System.Drawing.Point(368, 480);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(200, 88);
			this.groupBox8.TabIndex = 11;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Server Management";
			this.groupBox8.Visible = false;
			// 
			// bnSvStart
			// 
			this.bnSvStart.Location = new System.Drawing.Point(8, 56);
			this.bnSvStart.Name = "bnSvStart";
			this.bnSvStart.Size = new System.Drawing.Size(184, 23);
			this.bnSvStart.TabIndex = 2;
			this.bnSvStart.Text = "Start Server";
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.White;
			this.label5.ForeColor = System.Drawing.Color.Blue;
			this.label5.Location = new System.Drawing.Point(8, 24);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(184, 23);
			this.label5.TabIndex = 1;
			this.label5.Text = "Server not started";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(858, 584);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox8,
																		  this.groupBox5,
																		  this.btnExit,
																		  this.groupBox2,
																		  this.groupBox1,
																		  this.splitter1,
																		  this.groupBox4,
																		  this.groupBox3});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FaceRecognition";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.Activated += new System.EventHandler(this.MainForm_Activated);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.groupBox8.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			this.Hide();
			CloseInterfaces();
		}

		/// <summary> detect first form appearance, start grabber. </summary>
		private void MainForm_Activated(object sender, System.EventArgs e)
		{
			if( firstActive )
				return;
			firstActive = true;

			if( ! DsUtils.IsCorrectDirectXVersion() )
			{
				MessageBox.Show( this, "DirectX 8.1 NOT installed!", "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				this.Close(); return;
			}
// comment here for can run if not connect cam
// from this
			if( ! DsDev.GetDevicesOfCat( FilterCategory.VideoInputDevice, out capDevices ) )
			{
				MessageBox.Show( this, "No video capture devices found!", "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				this.Close(); return;
			}

			DsDevice dev = null;
			if( capDevices.Count == 1 )
				dev = capDevices[0] as DsDevice;
			else
			{
				//DeviceSelector selector = new DeviceSelector( capDevices );
				//selector.ShowDialog( this );
				//dev = selector.SelectedDevice;
			}

			if( dev == null )
			{
				this.Close(); return;
			}

			if( ! StartupVideo( dev.Mon ) )
				this.Close();
// to this
		}

		private void videoPanel_Resize(object sender, System.EventArgs e)
		{
			ResizeVideoWindow();
		}


		/// <summary> handler for toolbar button clicks. </summary>
		private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			Trace.WriteLine( "!!BTN: toolBar_ButtonClick" );
		
			int hr;
			if( sampGrabber == null )
				return;

			if( e.Button == toolBarBtnGrab )	// btnGrab
			{
				Trace.WriteLine( "!!BTN: toolBarBtnGrab" );

				if( savedArray == null )
				{
					int size = videoInfoHeader.BmiHeader.ImageSize;
					if( (size < 1000) || (size > 16000000) )
						return;
					savedArray = new byte[ size + 64000 ];
				}
				
				toolBarBtnSave.Enabled = false;

				btnCPDetect.Enabled = true;

				Image old = pictureBox.Image;
				
				pictureBox.Image = null;
				
				if( old != null )
					old.Dispose();

				toolBarBtnGrab.Enabled = false;
				captured = false;
				hr = sampGrabber.SetCallback( this, 1 );
				
				this.lblStatus.Text = "Picture captured completed";

			}
			else if( e.Button == toolBarBtnSave )	// btnSave
			{
				Trace.WriteLine( "!!BTN: toolBarBtnSave" );

				SaveFileDialog sd = new SaveFileDialog();
				sd.FileName = @"1.jpg";
				sd.Title = "Save Image to Database as...";
				sd.Filter = "JPEG File (*.jpg)|*.jpg";
				sd.FilterIndex = 1;
				
				if( sd.ShowDialog() != DialogResult.OK )
					return;
				// store to variable
				this.fileName = sd.FileName;
				this.lblStatus.Text = "Saved as : " + this.fileName;

				pictureBox.Image.Save( sd.FileName, ImageFormat.Bmp );		// save to new bmp file
			}
			else if( e.Button == toolBarBtnTune ) //btn Tune
			{
				if( capGraph != null )
					DsUtils.ShowTunerPinDialog( capGraph, capFilter, this.Handle );
			}

		}

		/// <summary> capture event, triggered by buffer callback. </summary>
		void OnCaptureDone()
		{
			Trace.WriteLine( "!!DLG: OnCaptureDone" );
			try 
			{
				toolBarBtnGrab.Enabled = true;
				int hr;
				if( sampGrabber == null )
					return;
				hr = sampGrabber.SetCallback( null, 0 );

				int w = videoInfoHeader.BmiHeader.Width;
				int h = videoInfoHeader.BmiHeader.Height;
				if( ((w & 0x03) != 0) || (w < 32) || (w > 4096) || (h < 32) || (h > 4096) )
					return;
				int stride = w * 3;

				GCHandle handle = GCHandle.Alloc( savedArray, GCHandleType.Pinned );
				int scan0 = (int) handle.AddrOfPinnedObject();
				scan0 += (h - 1) * stride;
				Bitmap b = new Bitmap( w, h, -stride, PixelFormat.Format24bppRgb, (IntPtr) scan0 );
				handle.Free();
				savedArray = null;
				Image old = pictureBox.Image;
				pictureBox.Image = b;
				if( old != null )
					old.Dispose();
				toolBarBtnSave.Enabled = true;
			}
			catch( Exception ee )
			{
				MessageBox.Show( this, "Could not grab picture\r\n" + ee.Message, "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
			}
		}



		/// <summary> start all the interfaces, graphs and preview window. </summary>
		bool StartupVideo( UCOMIMoniker mon )
		{
			int hr;
			try 
			{
				if( ! CreateCaptureDevice( mon ) )
					return false;

				if( ! GetInterfaces() )
					return false;

				if( ! SetupGraph() )
					return false;

				if( ! SetupVideoWindow() )
					return false;

			#if DEBUG
				DsROT.AddGraphToRot( graphBuilder, out rotCookie );		// graphBuilder capGraph
			#endif
			
				hr = mediaCtrl.Run();
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				bool hasTuner = DsUtils.ShowTunerPinDialog( capGraph, capFilter, this.Handle );
				toolBarBtnTune.Enabled = hasTuner;

				return true;
			}
			catch( Exception ee )
			{
				MessageBox.Show( this, "Could not start video stream\r\n" + ee.Message, "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				return false;
			}
		}

		/// <summary> make the video preview window to show in videoPanel. </summary>
		bool SetupVideoWindow()
		{
			int hr;
			try 
			{
				// Set the video window to be a child of the main window
				hr = videoWin.put_Owner( videoPanel.Handle );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				// Set video window style
				hr = videoWin.put_WindowStyle( WS_CHILD | WS_CLIPCHILDREN );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				// Use helper function to position video window in client rect of owner window
				ResizeVideoWindow();

				// Make the video window visible, now that it is properly positioned
				hr = videoWin.put_Visible( DsHlp.OATRUE );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				hr = mediaEvt.SetNotifyWindow( this.Handle, WM_GRAPHNOTIFY, IntPtr.Zero );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );
				return true;
			}
			catch( Exception ee )
			{
				MessageBox.Show( this, "Could not setup video window\r\n" + ee.Message, "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				return false;
			}
		}


		/// <summary> build the capture graph for grabber. </summary>
		bool SetupGraph()
		{
			int hr;
			try 
			{
				hr = capGraph.SetFiltergraph( graphBuilder );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				hr = graphBuilder.AddFilter( capFilter, "Ds.NET Video Capture Device" );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				DsUtils.ShowCapPinDialog( capGraph, capFilter, this.Handle );

				AMMediaType media = new AMMediaType();
				media.majorType	= MediaType.Video;
				media.subType	= MediaSubType.RGB24;
				media.formatType = FormatType.VideoInfo;		// ???
				hr = sampGrabber.SetMediaType( media );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				hr = graphBuilder.AddFilter( baseGrabFlt, "Ds.NET Grabber" );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				Guid cat = PinCategory.Preview;
				Guid med = MediaType.Video;
				hr = capGraph.RenderStream( ref cat, ref med, capFilter, null, null ); // baseGrabFlt 
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				cat = PinCategory.Capture;
				med = MediaType.Video;
				hr = capGraph.RenderStream( ref cat, ref med, capFilter, null, baseGrabFlt ); // baseGrabFlt 
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				media = new AMMediaType();
				hr = sampGrabber.GetConnectedMediaType( media );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );
				if( (media.formatType != FormatType.VideoInfo) || (media.formatPtr == IntPtr.Zero) )
					throw new NotSupportedException( "Unknown Grabber Media Format" );

				videoInfoHeader = (VideoInfoHeader) Marshal.PtrToStructure( media.formatPtr, typeof(VideoInfoHeader) );
				Marshal.FreeCoTaskMem( media.formatPtr ); media.formatPtr = IntPtr.Zero;

				hr = sampGrabber.SetBufferSamples( false );
				if( hr == 0 )
					hr = sampGrabber.SetOneShot( false );
				if( hr == 0 )
					hr = sampGrabber.SetCallback( null, 0 );
				if( hr < 0 )
					Marshal.ThrowExceptionForHR( hr );

				return true;
			}
			catch( Exception ee )
			{
				MessageBox.Show( this, "Could not setup graph\r\n" + ee.Message, "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				return false;
			}
		}


		/// <summary> create the used COM components and get the interfaces. </summary>
		bool GetInterfaces()
		{
			Type comType = null;
			object comObj = null;
			try 
			{
				comType = Type.GetTypeFromCLSID( Clsid.FilterGraph );
				if( comType == null )
					throw new NotImplementedException( @"DirectShow FilterGraph not installed/registered!" );
				comObj = Activator.CreateInstance( comType );
				graphBuilder = (IGraphBuilder) comObj; comObj = null;

				Guid clsid = Clsid.CaptureGraphBuilder2;
				Guid riid = typeof(ICaptureGraphBuilder2).GUID;
				comObj = DsBugWO.CreateDsInstance( ref clsid, ref riid );
				capGraph = (ICaptureGraphBuilder2) comObj; comObj = null;

				comType = Type.GetTypeFromCLSID( Clsid.SampleGrabber );
				if( comType == null )
					throw new NotImplementedException( @"DirectShow SampleGrabber not installed/registered!" );
				comObj = Activator.CreateInstance( comType );
				sampGrabber = (ISampleGrabber) comObj; comObj = null;

				mediaCtrl	= (IMediaControl)	graphBuilder;
				videoWin	= (IVideoWindow)	graphBuilder;
				mediaEvt	= (IMediaEventEx)	graphBuilder;
				baseGrabFlt	= (IBaseFilter)		sampGrabber;
				return true;
			}
			catch( Exception ee )
			{
				MessageBox.Show( this, "Could not get interfaces\r\n" + ee.Message, "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				return false;
			}
			finally
			{
				if( comObj != null )
					Marshal.ReleaseComObject( comObj ); comObj = null;
			}
		}

		/// <summary> create the user selected capture device. </summary>
		bool CreateCaptureDevice( UCOMIMoniker mon )
		{
			object capObj = null;
			try 
			{
				Guid gbf = typeof( IBaseFilter ).GUID;
				mon.BindToObject( null, null, ref gbf, out capObj );
				capFilter = (IBaseFilter) capObj; capObj = null;
				return true;
			}
			catch( Exception ee )
			{
				MessageBox.Show( this, "Could not create capture device\r\n" + ee.Message, "DirectShow.NET", MessageBoxButtons.OK, MessageBoxIcon.Stop );
				return false;
			}
			finally
			{
				if( capObj != null )
					Marshal.ReleaseComObject( capObj ); capObj = null;
			}

		}



		/// <summary> do cleanup and release DirectShow. </summary>
		void CloseInterfaces()
		{
			int hr;
			try 
			{
			#if DEBUG
				if( rotCookie != 0 )
					DsROT.RemoveGraphFromRot( ref rotCookie );
			#endif

				if( mediaCtrl != null )
				{
					hr = mediaCtrl.Stop();
					mediaCtrl = null;
				}

				if( mediaEvt != null )
				{
					hr = mediaEvt.SetNotifyWindow( IntPtr.Zero, WM_GRAPHNOTIFY, IntPtr.Zero );
					mediaEvt = null;
				}

				if( videoWin != null )
				{
					hr = videoWin.put_Visible( DsHlp.OAFALSE );
					hr = videoWin.put_Owner( IntPtr.Zero );
					videoWin = null;
				}

				baseGrabFlt = null;
				if( sampGrabber != null )
					Marshal.ReleaseComObject( sampGrabber ); sampGrabber = null;

				if( capGraph != null )
					Marshal.ReleaseComObject( capGraph ); capGraph = null;

				if( graphBuilder != null )
					Marshal.ReleaseComObject( graphBuilder ); graphBuilder = null;

				if( capFilter != null )
					Marshal.ReleaseComObject( capFilter ); capFilter = null;
			
				if( capDevices != null )
				{
					foreach( DsDevice d in capDevices )
						d.Dispose();
					capDevices = null;
				}
			}
			catch( Exception )
			{}
		}

		/// <summary> resize preview video window to fill client area. </summary>
		void ResizeVideoWindow()
		{
			if( videoWin != null )
			{
				Rectangle rc = videoPanel.ClientRectangle;
				videoWin.SetWindowPosition( 0, 0, rc.Right, rc.Bottom );
			}
		}

		/// <summary> override window fn to handle graph events. </summary>
		protected override void WndProc( ref Message m )
		{
			if( m.Msg == WM_GRAPHNOTIFY )
			{
				if( mediaEvt != null )
					OnGraphNotify();
				return;
			}
			base.WndProc( ref m );
		}

		/// <summary> graph event (WM_GRAPHNOTIFY) handler. </summary>
		void OnGraphNotify()
		{
			DsEvCode	code;
			int p1, p2, hr = 0;
			do
			{
				hr = mediaEvt.GetEvent( out code, out p1, out p2, 0 );
				if( hr < 0 )
					break;
				hr = mediaEvt.FreeEventParams( code, p1, p2 );
			}
			while( hr == 0 );
		}

		/// <summary> sample callback, NOT USED. </summary>
		int ISampleGrabberCB.SampleCB( double SampleTime, IMediaSample pSample )
		{
			Trace.WriteLine( "!!CB: ISampleGrabberCB.SampleCB" );
			return 0;
		}

		/// <summary> buffer callback, COULD BE FROM FOREIGN THREAD. </summary>
		int ISampleGrabberCB.BufferCB( double SampleTime, IntPtr pBuffer, int BufferLen )
		{
			if( captured || (savedArray == null) )
			{
				Trace.WriteLine( "!!CB: ISampleGrabberCB.BufferCB" );
				return 0;
			}

			captured = true;
			bufferedSize = BufferLen;
			Trace.WriteLine( "!!CB: ISampleGrabberCB.BufferCB  !GRAB! size = " + BufferLen.ToString() );
			if( (pBuffer != IntPtr.Zero) && (BufferLen > 1000) && (BufferLen <= savedArray.Length) )
				Marshal.Copy( pBuffer, savedArray, 0, BufferLen );
			else
				Trace.WriteLine( "    !!!GRAB! failed " );
			this.BeginInvoke( new CaptureDone( this.OnCaptureDone ) );
			return 0;
		}


		/// <summary> flag to detect first Form appearance </summary>
		private bool					firstActive;

		/// <summary> base filter of the actually used video devices. </summary>
		private IBaseFilter				capFilter;

		/// <summary> graph builder interface. </summary>
		private IGraphBuilder			graphBuilder;

		/// <summary> capture graph builder interface. </summary>
		private ICaptureGraphBuilder2	capGraph;
		private ISampleGrabber			sampGrabber;

		/// <summary> control interface. </summary>
		private IMediaControl			mediaCtrl;

		/// <summary> event interface. </summary>
		private IMediaEventEx			mediaEvt;

		/// <summary> video window interface. </summary>
		private IVideoWindow			videoWin;

		/// <summary> grabber filter interface. </summary>
		private IBaseFilter				baseGrabFlt;

		/// <summary> structure describing the bitmap to grab. </summary>
		private	VideoInfoHeader			videoInfoHeader;
		private	bool					captured = true;
		private	int						bufferedSize;

		/// <summary> buffer for bitmap data. </summary>
		private	byte[]					savedArray;

		/// <summary> list of installed video devices. </summary>
		private ArrayList				capDevices;

		private const int WM_GRAPHNOTIFY	= 0x00008001;	// message from graph

		private const int WS_CHILD			= 0x40000000;	// attributes for video window
		private const int WS_CLIPCHILDREN	= 0x02000000;
		private const int WS_CLIPSIBLINGS	= 0x04000000;

//		private void btnCPDetect_Click(object sender, System.EventArgs e)
//		{
//			Bitmap pic1 = new Bitmap(pictureBox.Image);
//			Bitmap pic2;
//			FaceDetect face = new FaceDetect();
//			pic2 = face.DetectFace(pic1);
//			pictureBox2.Image = pic2;
//		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			saveDlg = new SaveFileDialog();
			saveDlg.Filter="JPEG Images (*.jpg,*.jpeg)|*.jpg;*.jpeg|Gif Images (*.gif)|*.gif|Bitmaps (*.bmp)|*.bmp";
			if( saveDlg.ShowDialog() == DialogResult.OK)
			{
				strImgName = saveDlg.FileName;
				pictureBox2.Image.Save(strImgName,ImageFormat.Jpeg);
			}
		}

		

		/// <summary> event when callback has finished (ISampleGrabberCB.BufferCB). </summary>
		private delegate void CaptureDone();

	#if DEBUG
		private int		rotCookie = 0;

		private void videoPanel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void pictureBox_Click(object sender, System.EventArgs e)
		{
		
		}

	

		private void MainForm_Load(object sender, System.EventArgs e)
		{
		
		}

		
		private void btnCPSearch_Click(object sender, System.EventArgs e)
		{
		
		}

		private void btnCPDetect_Click(object sender, System.EventArgs e)
		{
			//Bitmap facepic = new Bitmap("D:/pic/chat/11.jpg");
			Bitmap pic1;
			
			Bitmap facepic = new Bitmap(pictureBox.Image);
			
			FaceDetect FD = new FaceDetect();
			
			pic1 = FD.DetectFace(facepic);

			pictureBox2.Image = pic1;

		}

		private void pictureBox1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void pictureBox2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void btnExit_Click_1(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void btnCPClear_Click(object sender, System.EventArgs e)
		{
			this.pictureBox.Image = null;
			this.lblStatus.Text = "Captured picture cleared";
		}

	



	#endif
	}

	internal enum PlayState
	{
		Init, Stopped, Paused, Running
	}

}
