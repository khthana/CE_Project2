// ListenSock.cpp : implementation file
//

#include "stdafx.h"
#include "MVBServer.h"
#include "MVBServerDlg.h"
#include "ListenSock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CListenSock

CListenSock::CListenSock()
{
}

CListenSock::~CListenSock()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CListenSock, CSocket)
	//{{AFX_MSG_MAP(CListenSock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CListenSock member functions

void CListenSock::OnAccept(int nErrorCode) 
{
	if ( nErrorCode == 0 )
		((CMVBServerDlg*)m_pDwnd)->AcceptClient();

	CAsyncSocket::OnAccept(nErrorCode);
}

void CListenSock::OnClose(int nErrorCode) 
{
	if ( nErrorCode == 0 )
		this->Close();

	CAsyncSocket::OnClose(nErrorCode);
}

void CListenSock::SetParent(CDialog *pDwnd)
{
	m_pDwnd = pDwnd;
}
