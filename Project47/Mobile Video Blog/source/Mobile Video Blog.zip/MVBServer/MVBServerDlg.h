// MVBServerDlg.h : header file
//

#if !defined(AFX_MVBSERVERDLG_H__73EF1101_2628_4E1D_80FE_077C049EE930__INCLUDED_)
#define AFX_MVBSERVERDLG_H__73EF1101_2628_4E1D_80FE_077C049EE930__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ListenSock.h"
#include "ASock.h"

#define KUserMax 20
/////////////////////////////////////////////////////////////////////////////
// CMVBServerDlg dialog

class CMVBServerDlg : public CDialog
{
// Construction
public:
	CMVBServerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMVBServerDlg)
	enum { IDD = IDD_MVBSERVER_DIALOG };
	CListBox	m_displayList;
	UINT	m_listenPort;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMVBServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMVBServerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnListen();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void AcceptClient();
	CListenSock m_ListenSock;
	CASock m_UserSocket[KUserMax];
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MVBSERVERDLG_H__73EF1101_2628_4E1D_80FE_077C049EE930__INCLUDED_)
