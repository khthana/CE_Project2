#if !defined(AFX_ASOCK_H__74A47A62_1918_4174_8767_A1A9878DBB93__INCLUDED_)
#define AFX_ASOCK_H__74A47A62_1918_4174_8767_A1A9878DBB93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ASock.h : header file
//

enum TSocketState
    {
    ENotConnected = 100,
    EConnected,
	ELogged,
	ERequestedCategory,		// Request and send category already
	EReceivedHeader,		//Receive category id and file size
	EReceiveData,	// Server received message notice have data to send from remote
	EReceivedData			// Server have already received data.
    };

/////////////////////////////////////////////////////////////////////////////
// CASock command target

class CASock : public CAsyncSocket
{
// Attributes
public:
	TSocketState iSocketState;

// Operations
public:
	CASock();
	virtual ~CASock();

// Overrides
public:
	void SetSockAcceptedInfo();
	CString m_sockIP;
	CString m_sockPort;
	CString m_peerIP;
	CString m_peerPort;
	void ClosedSocket();
	void SetParent(CDialog *pDwnd);
	// Mark add
	void OnPort(char *buffer);
	void VerifyUSerPasswd(char *buffer,CString &user);
	void ReceiveHeader(char *buffer,char *char_CategoryID,int &count_file,char char_file_name[4][20],int *file_size,CString &desc,char *topic);
	void ReceiveFile(char *buffer,CString &user,char *char_CategoryID,int &count_file,char char_file_name[4][20],int *file_size,CString &desc,char topic[20],int &first,int &file_Recv,int nRecv);
	void UpdateDatabase(CString filename,CString char_blogID,CString user);

	// ClassWizard generated virtual function overrides
	/// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CASock)
	public:
	virtual void OnAccept(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CASock)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	

// Implementation
protected:
	CDialog* m_pDwnd;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASOCK_H__74A47A62_1918_4174_8767_A1A9878DBB93__INCLUDED_)
