; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CMVBServerDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "MVBServer.h"

ClassCount=3
Class1=CMVBServerApp
Class2=CMVBServerDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_MVBSERVER_DIALOG (English (U.S.))
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_MVBSERVER_DIALOG

[CLS:CMVBServerApp]
Type=0
HeaderFile=MVBServer.h
ImplementationFile=MVBServer.cpp
Filter=N

[CLS:CMVBServerDlg]
Type=0
HeaderFile=MVBServerDlg.h
ImplementationFile=MVBServerDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CMVBServerDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=MVBServerDlg.h
ImplementationFile=MVBServerDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_MVBSERVER_DIALOG]
Type=1
Class=CMVBServerDlg
ControlCount=5
Control1=IDCBT_LISTEN,button,1342242817
Control2=IDCBT_CLOSE,button,1476460544
Control3=IDCEDIT_PORT,edit,1350631552
Control4=IDC_STATIC,static,1342308352
Control5=IDCLIST_DISPLAY,listbox,1353781505

[DLG:IDD_MVBSERVER_DIALOG (English (U.S.))]
Type=1
Class=CMVBServerDlg
ControlCount=5
Control1=IDCBT_LISTEN,button,1342242817
Control2=IDCBT_CLOSE,button,1476460544
Control3=IDCEDIT_PORT,edit,1350631552
Control4=IDC_STATIC,static,1342308352
Control5=IDCLIST_DISPLAY,listbox,1352728835

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

