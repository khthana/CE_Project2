// WinSockDlg.h : header file
//

#if !defined(AFX_WINSOCKDLG_H__4819DAA5_2482_11D5_A259_CE524709CD2A__INCLUDED_)
#define AFX_WINSOCKDLG_H__4819DAA5_2482_11D5_A259_CE524709CD2A__INCLUDED_

#include "ASock.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CWinSockDlg dialog

class CWinSockDlg : public CDialog
{
// Construction
public:
	void Closed();
	void Connected();

	CWinSockDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWinSockDlg)
	enum { IDD = IDD_WINSOCK_DIALOG };
	CListBox	m_listMessage;
	CString	m_strloAppIP;
	CString	m_strloPort;
	CString	m_strSendMessages;
	UINT	m_intPorts;
	CString	m_strSentTotalMessages;
	CString	m_strAddIP;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinSockDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int m_intCountSentByte;
	CASock m_connectSock;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CWinSockDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg void OnDisconnect();
	afx_msg void OnButtonSend();
	afx_msg void OnBottonConnect();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINSOCKDLG_H__4819DAA5_2482_11D5_A259_CE524709CD2A__INCLUDED_)
