// ASock.cpp : implementation file
//

#include "stdafx.h"
#include "MVBServer.h"
#include "MVBServerDlg.h"
#include "ASock.h"
/////////////////*********New by Mark
#include <stdio.h>
#include <mysql.h>
#include <time.h>

#include <afxdisp.h>
//********************************
#include <direct.h>

#include <fstream>
#include <iostream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CASock

CASock::CASock()
{
	iSocketState = ENotConnected;
}

CASock::~CASock()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CASock, CAsyncSocket)
	//{{AFX_MSG_MAP(CASock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CASock member functions

void CASock::OnAccept(int nErrorCode) 
{

}

void CASock::OnPort(char *buffer)
{
	CString strShowClosePeer;
	UINT tempPort;
	CString strTemp(buffer);
	// Set remote IP Address
	this->GetPeerName(m_peerIP, tempPort);
	m_peerPort.Format("%lu", tempPort);

	// Show information connected
	strShowClosePeer.Format("Data: %s From:%s Port:%s State:%d",strTemp,m_peerIP, m_peerPort, iSocketState);
	((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowClosePeer);
}



void CASock::OnReceive(int nErrorCode) 
{
	//-----declaration---------------
	int buffer_size=1024;
	char buffer[4096];

	static int count_file=0;
	static char char_file_name[4][20];
	static int file_size[4];
	static CString user;
	static char char_CategoryID[10];
	static CString desc;
	static char topic[20];
	static int first=1;
	static int file_Recv=0;
	int nRecv;

	nRecv = Receive(buffer,buffer_size);
	CString strShowClosePeer;
	buffer[nRecv] = 0; 

	//-----End declaration---------------
	
	//if(this->iSocketState==ENotConnected)//Change state to connected
	//	this->iSocketState = EConnected;
	
	OnPort(buffer);						//Display port connected
	
	//*********************************
	/*
//	static	bool quit = false;
//	time_t t = time(NULL);
//	while (!quit)
	{
		//h.Select(1,0);
		if (time(NULL) - t > 10)
		{
			t = time(NULL);
			strShowClosePeer.Format("Time out.");
			((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowClosePeer);
			quit = true;
			//h.Update();
			//h.Disconnect();
		}
	}
*/
	//*********************************
	//Receive file data
	if(this->iSocketState==EReceivedHeader)//EReceivedHeader
	{										//Write to file	
		ReceiveFile(buffer,user,char_CategoryID,count_file,char_file_name,file_size,desc,topic,first,file_Recv,nRecv);
	}

	//Receive file name,file size and text
	if(this->iSocketState==ELogged)
	{	
		ReceiveHeader(buffer,char_CategoryID,count_file,char_file_name,file_size,desc,topic);
	}

	//Receive all data from mobile complete
	if(this->iSocketState==EReceivedData)//EReceivedData
	{
		strShowClosePeer.Format("Complete.");
		((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowClosePeer);
		this->iSocketState=ELogged; //Reset state and value
		first=1;
		count_file=0;
		file_Recv=0;
	}


	//Display user and password
	if(this->iSocketState==EConnected)
	{	
		VerifyUSerPasswd(buffer,user);
	}
	

}


void CASock::OnClose(int nErrorCode) 
{
	if ( nErrorCode == 0 ) {
		this->Close();
		ClosedSocket();

	}

	CAsyncSocket::OnClose(nErrorCode);

	iSocketState = ENotConnected;
}

void CASock::SetParent(CDialog *pDwnd)
{
	m_pDwnd = pDwnd;
}


/*
==========================================================
	CASock::ClosedSocket()
		Run when remoteSocket have already closed.
==========================================================
*/
void CASock::ClosedSocket()
{
	CString strShowClosePeer;
	strShowClosePeer.Format("Closed remote IP:%s Port:%s", 
		m_peerIP, m_peerPort);
	((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowClosePeer);
	//mark add
	iSocketState = ENotConnected;
}

/*
==========================================================
	CASock::SetSockAcceptedInfo()
		Use for set information and run some command
		when remoteSocket have already accepted.
==========================================================
*/
void CASock::SetSockAcceptedInfo()
{
	CString strShowNewAccept;
	UINT tempPort;
	this->iSocketState = EConnected;

	// Set local IP Address
	this->GetSockName(m_sockIP, tempPort);
	m_sockPort.Format("%lu", tempPort);

	// Set remote IP Address
	this->GetPeerName(m_peerIP, tempPort);
	m_peerPort.Format("%lu", tempPort);

	// Show information connected
	strShowNewAccept.Format("Accepted remote IP:%s Port:%s", 
		m_peerIP, m_peerPort);
	((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNewAccept);
}


//*****************************************************************
void CASock::VerifyUSerPasswd(char *buffer,CString &user)
{
		int pt_buffer =0;
		char user_temp[10];
		char passwd_temp[10];
		CString strShowUser;
		while (buffer[pt_buffer]!=':')
		{
			user_temp[pt_buffer]=buffer[pt_buffer];
			pt_buffer++;
			
		}
		user_temp[pt_buffer]=0;
		pt_buffer++;
		int i=0;
		while (buffer[pt_buffer]!=':')
		{
			passwd_temp[i]=buffer[pt_buffer];
			i++;
			pt_buffer++;
			
		}
		passwd_temp[i]=0;

		strShowUser.Format("User = %s,Passwd = %s logging.",user_temp,passwd_temp);
		((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);

		user=user_temp;
		CString passwd(passwd_temp);
		if((user!=' ')&&(passwd!=' '))
		{
				MYSQL *link;
				MYSQL_RES *result;
				MYSQL_ROW row;
				unsigned __int64 numofrows;
				char strsql[1000];
    
		//	try{
				link = mysql_init(NULL);
 				mysql_real_connect(link,"localhost","root","","em",0,NULL,0);
				
				//-----------Command select user&password
				sprintf(strsql,"SELECT * FROM em_member where username='%s'",user);
				mysql_query(link,strsql);
				result = mysql_store_result(link);
				row = mysql_fetch_row(result);
				
				strShowUser.Format(strsql);
				((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);


				//**************************
				int nYear=0;
				int nMonth=0;
				int nDay=0;
				int nHour=0;
				int nMin=0;
				int nSec=0;

				COleDateTime time;
				time=COleDateTime::GetCurrentTime();

				nDay=time.GetDay();
				nMonth=time.GetMonth();
				nYear=time.GetYear();

				nHour=time.GetHour();
				nMin=time.GetMinute();
				nSec=time.GetSecond();
				
				//**************************
				//----------Check user and passwd
				if((user==row[0])&&(passwd==row[1]))
				{
					//write to log file
					char path[50];
					sprintf(path,"c:\\Appserv\\www\\MVB\\log\\userpass_%d_%d_%d.log",nDay, nMonth, nYear);
					FILE *fi_log;
								
					fi_log=fopen(path,"a+b");		
					char temp[100];
					
					sprintf(temp,"%d/%d/%d %d:%d:%d User = %s IP=%s\n", nYear, nMonth, nDay, nHour, nMin, nSec, row[0], m_peerIP);
					CString log(temp);
					fwrite(log,sizeof(char),log.GetLength(),fi_log);
					fclose(fi_log);
					//end write log file

					this->iSocketState=ELogged;
					strShowUser.Format("User = %s,Passwd = %s logged.",row[0],row[1]);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);
					
					sprintf(strsql,"SELECT * FROM em_memberhistory where ((username='%s') and (placeID<>'%s'))",user,user);
					mysql_query(link,strsql);
					result = mysql_store_result(link);
					numofrows = mysql_num_rows(result);

					strShowUser.Format(strsql);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);

					strShowUser.Format("Num of result = %d\n",numofrows);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);
					
				
					CString temp_buffer;
					temp_buffer.Insert(0,"Pass");
					temp_buffer.Insert(temp_buffer.GetLength(),":");
					while( row = mysql_fetch_row(result) ) 
					{						
						temp_buffer.Insert(temp_buffer.GetLength(),row[0]);
						temp_buffer.Insert(temp_buffer.GetLength(),row[4]);
						temp_buffer.Insert(temp_buffer.GetLength(),":");
						strShowUser.Format("Category = %s %s \n",row[0],row[4]);
						((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);
					 }
					temp_buffer.Insert(temp_buffer.GetLength(),";");
					
					this->Send(temp_buffer,temp_buffer.GetLength());
					strShowUser.Format("Sent to mobile=%s",temp_buffer);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);
				}
				else
				{
					//write to log file
					char path[50];
					sprintf(path,"c:\\Appserv\\www\\MVB\\log\\userNotpass_%d_%d_%d.log",nDay, nMonth, nYear);
					FILE *fi_log;
								
					fi_log=fopen(path,"a+b");		
					char temp[100];
					
					sprintf(temp,"%d/%d/%d %d:%d:%d User = %s IP=%s\n", nYear, nMonth, nDay, nHour, nMin, nSec, user_temp, m_peerIP);
					//sprintf(temp,"%d/%d/%d %d:%d:%d User = %s,Passwd = %s .\n",nDay, nMonth, nYear, nHour, nMin, nSec, user_temp,passwd_temp);
					CString log(temp);
					fwrite(log,sizeof(char),log.GetLength(),fi_log);
					fclose(fi_log);
					//end write log file
					this->Send("Not",3);
					strShowUser.Format("User = %s,Passwd = %s not correct.",user,passwd);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowUser);
				}
				mysql_close(link);
		//	}catch(BadQuenry er){
		//		er.error;
		//	}catch(BadConversion er){
		//		er.type_name;
		//	}
		}
}


void CASock::ReceiveHeader(char *buffer,char *char_CategoryID,int &count_file,char char_file_name[4][20],int *file_size,CString &desc,char *topic)
{		
		int pt_buffer=-1;
		int pointer = 0;
		char char_file_size[4][20];
		CString strShowFile;

		while (buffer[pt_buffer]!=':')
		{
			char_CategoryID[pt_buffer]=buffer[pt_buffer];
			pt_buffer++;	
		}
		char_CategoryID[pt_buffer]=0;
		pt_buffer++;
		pointer = 0;

		while (buffer[pt_buffer]!=':')
		{
			topic[pointer]=buffer[pt_buffer];
			pointer++;
			pt_buffer++;
		}
		topic[pointer]=0;
		pt_buffer++;
		pointer = 0;

		while ((buffer[pt_buffer]!=';')&&(count_file<4))
		{
			while (buffer[pt_buffer]!=':')
			{
				char_file_name[count_file][pointer]=buffer[pt_buffer];
				pointer++;
				pt_buffer++;
				
			}
			char_file_name[count_file][pointer]=0;
			pt_buffer++;
			pointer = 0;
			
			CString filename(char_file_name[count_file]);
			if(filename!=" ")
			{
					pointer=0;
					while (buffer[pt_buffer]!=':')
					{
						char_file_size[count_file][pointer]=buffer[pt_buffer];
						pointer++;
						pt_buffer++;
					}
					char_file_size[count_file][pointer]=0;
					file_size[count_file] = atoi(char_file_size[count_file]);
					pt_buffer++;
					pointer=0;
					count_file++;
			}
		
		}

		this->iSocketState=EReceivedHeader;
		for(int display=0;display<count_file;display++)
		{
			strShowFile.Format("Category ID=%s Topic=%s File name=%s File size= %d bytes", char_CategoryID, topic, char_file_name[display],file_size[display]);
			((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowFile);
		}
		this->Send("Continue:",9);
}


void CASock::ReceiveFile(char *buffer,CString &user,char *char_CategoryID,int &count_file,char char_file_name[4][20],int *file_size,CString &desc,char topic[20],int &first,int &file_Recv,int nRecv)
{
//***********stable********************
		char temp_blogID[16];
		static CString char_blogID;
		CString strShowNextID;
		char strsql[5000];
//*************************************
		static int count_file_size=0;
		MYSQL *link;
		MYSQL_RES *result;
		MYSQL_ROW row;
		if(first)
		{	
				link = mysql_init(NULL);
 				mysql_real_connect(link,"localhost","root","","em",0,NULL,0);
				sprintf(strsql,"SELECT MAX(blogID) from em_memberpicture where username LIKE '%s'",user);
				mysql_query(link,strsql);
				result = mysql_store_result(link);
				row = mysql_fetch_row(result);
				int blogID=atoi(row[0]);
				blogID++;
				
				sprintf(temp_blogID,"%d",blogID);
				char_blogID=temp_blogID;

				for(int zero=char_blogID.GetLength();zero<16;zero++)
				{
						char_blogID.Insert(0,'0');
				}
				mysql_close(link);
				strShowNextID.Format("category id= %s blog = %s",char_CategoryID, char_blogID);
				((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);
		}

		if(count_file!=file_Recv)
		{	

				CString filename(char_file_name[file_Recv]);
				int nYear=0;
				int nMonth=0;
				int nDay=0;
				int nHour=0;
				int nMin=0;
				int nSec=0;
				
				COleDateTime time;
				time=COleDateTime::GetCurrentTime();

				nDay=time.GetDay();
				nMonth=time.GetMonth();
				nYear=time.GetYear();

				nHour=time.GetHour();
				nMin=time.GetMinute();
				nSec=time.GetSecond();
				if(filename=="Text")
				{				 
					
					static int pt_buffer=0;
					while (file_size[file_Recv]!=pt_buffer)
					{
						desc.Insert(desc.GetLength(),buffer[pt_buffer]);
						pt_buffer++;
					}
					if(file_size[file_Recv]==pt_buffer)
						this->Send("Continue:",9);
					
					strShowNextID.Format("desc = %s",desc);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);

					strShowNextID.Format("Receive Text= %d bytes",desc.GetLength());
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);	
							sprintf(strsql,"INSERT INTO em_memberpicture(blogID, placeID, username, blogTopic, blogDescription, picturename, soundname, videoname, status, TimeStamp, AmonutPost, AmountView) VALUES ('%s', '%s', '%s', '%s', '%s', NULL, NULL, NULL, 2, '%d-%d-%d %d:%d:%d', 0, 0)", char_blogID, char_CategoryID, user, topic, desc, nYear, nMonth, nDay, nHour, nMin, nSec);
							first=0;
					
						link = mysql_init(NULL);
 						mysql_real_connect(link,"localhost","root","","em",0,NULL,0);
						mysql_query(link,strsql);
						result = mysql_store_result(link);
							sprintf(strsql,"SELECT AmountBlog from em_memberhistory where username LIKE '%s' AND placeID LIKE %s",user,char_CategoryID);
								mysql_query(link,strsql);
								result = mysql_store_result(link);
							int AmountBlog=atoi(row[0]);
							AmountBlog++;
							sprintf(strsql,"UPDATE em_memberhistory SET AmountBlog  = %d where username LIKE '%s' AND placeID LIKE %s",AmountBlog,user,char_CategoryID);
								mysql_query(link,strsql);
								result = mysql_store_result(link);
					

					strShowNextID.Format(strsql);
					((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);

					mysql_close(link);
				
				}
				/*else{
					sprintf(strsql,"INSERT INTO em_memberpicture(blogID, placeID, username, blogTopic, blogDescription, picturename, soundname, videoname, status, TimeStamp, AmonutPost, AmountView) VALUES ('%s', '%s', '%s', '%s', '%s', NULL, NULL, NULL, 2, '%d-%d-%d %d:%d:%d', 0, 0)", char_blogID, char_CategoryID, user, topic, desc, nYear, nMonth, nDay, nHour, nMin, nSec);
						first=0;
						link = mysql_init(NULL);
 						mysql_real_connect(link,"localhost","root","","em",0,NULL,0);
						mysql_query(link,strsql);
						result = mysql_store_result(link);
						mysql_close(link);

				}*/


				char path[1000];
				sprintf(path,"c:\\Appserv\\www\\MVB\\userData\\%s\\category\\%s\\%s", user, char_CategoryID, char_blogID);
				mkdir(path);
				sprintf(path,"c:\\Appserv\\www\\MVB\\userData\\%s\\category\\%s\\%s\\%s", user, char_CategoryID, char_blogID, char_file_name[file_Recv]);
				
				
				if(filename!="Text")
					filename=char_file_name[file_Recv];
				else
					file_Recv++;
				if((filename!="")&&(count_file>0)&&(filename!="Text"))
					{
							strShowNextID.Format("Save file:%s\n",path);
							((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);

							FILE *fi;
							
							fi=fopen(path,"a+b");		
							
									fwrite(buffer,sizeof(char),nRecv,fi);
									count_file_size+=nRecv;
									float percent=0;
									float u=count_file_size;
									float d=file_size[file_Recv];
									percent = (u/d)*100;
									strShowNextID.Format("Received %d bytes = %.2f Percent.",count_file_size,percent);
									((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);

									if((count_file_size%1024==0)||(file_size[file_Recv]<=count_file_size))
									{
										this->Send("Continue:",9);
										strShowNextID.Format("Send Continue to mobile");
										((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);
										if(file_size[file_Recv]<=count_file_size)
										{
											UpdateDatabase(filename,char_blogID,user);
											strShowNextID.Format("Save File:%s complete.",filename);
											((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowNextID);
											file_Recv++;
											count_file_size=0;
										}
									}
							fclose(fi);
							if(count_file==file_Recv)
								this->iSocketState=EReceivedData;
				}//end if((filename!="")&&(count_file>0))
		}//end if (count_file!=file_Recv)
			
		
}


void CASock::UpdateDatabase(CString filename,CString char_blogID,CString user)
{
	char strsql[1000];
	int pos=0;
	MYSQL *link;
	MYSQL_RES *result;
	CString strShowSql;

	link = mysql_init(NULL);
 	mysql_real_connect(link,"localhost","root","","em",0,NULL,0);
	//********Picture************
	pos = filename.Find(".jpg");
	if(pos>0)
	{
		sprintf(strsql,"UPDATE em_memberpicture SET picturename  = '%s' WHERE blogID LIKE '%s' AND username LIKE '%s'", filename, char_blogID, user);
		mysql_query(link,strsql);
		result = mysql_store_result(link);

		strShowSql.Format(strsql);
		((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowSql);
		
	}
	//********Sound************
	pos = filename.Find(".amr");
	if(pos>0)
	{
		sprintf(strsql,"UPDATE em_memberpicture SET soundname  = '%s' WHERE blogID LIKE '%s' AND username LIKE '%s'", filename, char_blogID, user);
		mysql_query(link,strsql);
		result = mysql_store_result(link);
		
		strShowSql.Format(strsql);
		((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowSql);
		
	}
	//********Video************
	pos = filename.Find(".3gp");
	if(pos>0)
	{
		sprintf(strsql,"UPDATE em_memberpicture SET videoname  = '%s' WHERE blogID LIKE '%s' AND username LIKE '%s'", filename, char_blogID, user);
		mysql_query(link,strsql);
		result = mysql_store_result(link);
		
		strShowSql.Format(strsql);
		((CMVBServerDlg*)m_pDwnd)->m_displayList.AddString(strShowSql);
		
	}
	mysql_close(link);
}
