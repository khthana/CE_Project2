// MVBServer.h : main header file for the MVBSERVER application
//

#if !defined(AFX_MVBSERVER_H__D0C490D2_BA01_48FB_9666_FA8D5A8482B1__INCLUDED_)
#define AFX_MVBSERVER_H__D0C490D2_BA01_48FB_9666_FA8D5A8482B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMVBServerApp:
// See MVBServer.cpp for the implementation of this class
//

class CMVBServerApp : public CWinApp
{
public:
	CMVBServerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMVBServerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMVBServerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MVBSERVER_H__D0C490D2_BA01_48FB_9666_FA8D5A8482B1__INCLUDED_)
