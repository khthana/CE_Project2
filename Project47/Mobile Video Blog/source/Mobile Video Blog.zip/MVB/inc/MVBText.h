/*
* ============================================================================
*  Name     : CMVBText from MVBText.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares view for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBTEXT_H
#define MVBTEXT_H

// INCLUDES
#include <aknview.h>


// CONSTANTS
// UID of view
const TUid KTextId = {2};

// FORWARD DECLARATIONS
class CMVBContainerText;

// CLASS DECLARATION

/**
*  CMVBText view class.
* 
*/
class CMVBText : public CAknView
    {
    public: // Constructors and destructor

        /**
        * EPOC default constructor.
        */
        void ConstructL();

        /**
        * Destructor.
        */
        ~CMVBText();

    public: // Functions from base classes
        
        /**
        * From CAknView returns Uid of View
        * @return TUid uid of the view
        */
        TUid Id() const;

        /**
        * From MEikMenuObserver delegate commands from the menu
        * @param aCommand a command emitted by the menu 
        * @return void
        */
        void HandleCommandL(TInt aCommand);

        /**
        * From CAknView reaction if size change
        * @return void
        */
        void HandleClientRectChange();

    private:

        /**
        * From CAknView activate the view
        * @param aPrevViewId 
        * @param aCustomMessageId 
        * @param aCustomMessage 
        * @return void
        */
        void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
            const TDesC8& aCustomMessage);

        /**
        * From CAknView deactivate the view (free resources)
        * @return void
        */
        void DoDeactivate();

    private: // Data
        CMVBContainerText* iContainer;

	public:
		TBuf<1024>	iData;
    };

#endif

// End of File
