/* Copyright (c) 2001, Nokia. All rights reserved */

#ifndef __SOCKETSWRITER_H__
#define __SOCKETSWRITER_H__

#include <in_sock.h>
#include "TimeOutNotifier.h"

class CTimeOutTimer;

/*! 
  @class CSocketsWriter
  
  @discussion This class handles writing data to the socket.
  Data to be written is accumulated in iTransferBuffer, and is then transferred
  to iWriteBuffer for the actual write to the socket.
  */
class CSocketEngine;
class CSocketsWriter : public CActive, public MTimeOutNotifier
    {
public:
/*!
  @function NewL
   
  @discussion Create a CSocketsWriter object
  @param aEngineNotifier An observer for status reporting
  @param aSocket socket to write to
  @result a pointer to the created instance of CSocketsWriter
  */
    static CSocketsWriter* NewL(RSocket& aSocket);

/*!
  @function NewLC
   
  @discussion Create a CSocketsWriter object
  @param aEngineNotifier An observer for status reporting
  @param aSocket socket to write to
  @result a pointer to the created instance of CSocketsWriter
  */
	static CSocketsWriter* NewLC(RSocket& aSocket);

/*!
  @function ~CSocketsWriter
  
  @discussion Destroy the object and release all memory objects
  */
	~CSocketsWriter();

/*!
  @function IssueWrite

  @discussion Write the data to the socket (buffered)
  @param aData the data to be written
  */
    void IssueWriteL(const TDesC8& aData, TRequestStatus* aResponse);

public: // From MTimeOutNotifier
	    void SetEngine(CSocketEngine& aEngine);
	    TBool IsWaitData();

/*!
  @function TimerExpired
  
  @discussion Handle a timeout event
  */
	void TimerExpired(); 

protected: // from CActive
/*!
  @function DoCancel
   
  @discussion cancel any outstanding operation
  */
	void DoCancel();

/*!
  @function RunL
   
  @discussion called when operation complete
  */
	void RunL();	

private:
/*!
  @function CSocketsWriter
  
  @discussion Perform the first phase of two phase construction 
  @param aEngineNotifier An observer for status reporting
  @param aSocket socket to read from
  */
	CSocketsWriter(RSocket& aSocket);

/*!
  @function ConstructL
  
  @discussion Perform the second phase construction of a CSocketsWriter 
  */
	void ConstructL();

/*!
  @function SendNextPacket

  @discussion Handle a 'write buffer empty' situation.
  */    
    void SendNextPacket();


private: // Member variables

    /*! @const The size of the write buffer in bytes */
    enum {KWriteBufferSize = 4096};

    /*! @const The maximum time allowed for a write to complete */
    static const TInt KTimeOut;
 
    /*!
      @enum TWriteState

      @discussion Records whether a write request is pending
      @value ESending A write request is pending with the socket server
      @value EWaiting The idle state for this object
      */
	enum TWriteState 
	    {
		ESending, 
        EWaiting
	    };

    /*! @var The socket to write to */
    RSocket&                iSocket;

    /*! @var Accumulate data to send in here */
	TBuf8<KWriteBufferSize> iTransferBuffer;

    /*! @var Holds data currently being sent to socket */
	TBuf8<KWriteBufferSize> iWriteBuffer;

    /*! @var A timer used to cancel an outstanding write after a predefined timeout */
	CTimeOutTimer*          iTimer;

    /*! @var The timeout to use */
	TInt                    iTimeOut;

    /*! @var The state of this active object */
	TWriteState             iWriteStatus;

	CSocketEngine*			iEngine;
    };

#endif // __SOCKETSWRITER_H__

