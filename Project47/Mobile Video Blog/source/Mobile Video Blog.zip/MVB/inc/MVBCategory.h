/*
* ============================================================================
*  Name     : CMVBCategory from MVBCategory.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares view for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBCATEGORY_H
#define MVBCATEGORY_H

// INCLUDES
#include <aknview.h>
#include "SocketEngine.h"

// CONSTANTS
// UID of view
const TUid KViewId = {1};

const TInt KSizeCategoryID = 10;
const TInt KSizeCategoryTopic = 50;
typedef struct TCategoryTag {
	TBuf8<KSizeCategoryID> iID;
	TBuf8<KSizeCategoryTopic> iTopic;
} TCategory;

// FORWARD DECLARATIONS
class CMVBContainerCategory;

// CLASS DECLARATION

/**
*  CMVBCategory view class.
* 
*/
class CMVBCategory : public CAknView
    {
    public: // Constructors and destructor

        /**
        * EPOC default constructor.
        */
        void ConstructL();

        /**
        * Destructor.
        */
        ~CMVBCategory();

    public: // Functions from base classes
        
        /**
        * From CAknView returns Uid of View
        * @return TUid uid of the view
        */
        TUid Id() const;

        /**
        * From MEikMenuObserver delegate commands from the menu
        * @param aCommand a command emitted by the menu 
        * @return void
        */
        void HandleCommandL(TInt aCommand);
		void DynInitMenuPaneL(TInt aResourceId,CEikMenuPane* aMenuPane);

        /**
        * From CAknView reaction if size change
        * @return void
        */
        void HandleClientRectChange();

    private:

        /**
        * From CAknView activate the view
        * @param aPrevViewId 
        * @param aCustomMessageId 
        * @param aCustomMessage 
        * @return void
        */
        void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
            const TDesC8& aCustomMessage);

        /**
        * From CAknView deactivate the view (free resources)
        * @return void
        */
        void DoDeactivate();

    private: // Data
        CMVBContainerCategory* iContainer;
	
	public:
		void Clear_Category();
		void SetSocketEngine(CSocketEngine& aSocket);
		TDesC8& GetCategoryID();
	    void AddCategoryData(TDesC8& aID, TDesC8& aTopic);

		CArrayFixSeg<TCategory>*	iCategoryTable;
		CSocketEngine*				iSocket;
    };

#endif

// End of File
