/*
* ============================================================================
*  Name     : CMVBAppUi from MVBAppUi.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares UI class for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBAPPUI_H
#define MVBAPPUI_H

// INCLUDES
#include <eikapp.h>
#include <eikdoc.h>
#include <e32std.h>
#include <coeccntx.h>
#include <aknviewappui.h>
#include <akntabgrp.h>
#include <aknnavide.h>
#include "SocketEngine.h"
#include <aknwaitnotewrapper.h> 
#include "mvb.hrh"

// FORWARD DECLARATIONS
class CMVBContainerCategory;
class CSocketsWriter;
class CProgressNoteGameSaverAO;

// CLASS DECLARATION

/**
* Application UI class.
* Provides support for the following features:
* - EIKON control architecture
* - view architecture
* - status pane
* 
*/
class CMVBAppUi : public CAknViewAppUi
    {
	friend class CSocketEngine;
    public: // // Constructors and destructor

        /**
        * EPOC default constructor.
        */      
        void ConstructL();

        /**
        * Destructor.
        */      
        ~CMVBAppUi();
        
    public: // New functions

    public: // Functions from base classes

    private:
        // From MEikMenuObserver
        void DynInitMenuPaneL(TInt aResourceId,CEikMenuPane* aMenuPane);

    private:
        /**
        * From CEikAppUi, takes care of command handling.
        * @param aCommand command to be handled
        */
        void HandleCommandL(TInt aCommand);

        /**
        * From CEikAppUi, handles key events.
        * @param aKeyEvent Event to handled.
        * @param aType Type of the key event. 
        * @return Response code (EKeyWasConsumed, EKeyWasNotConsumed). 
        */
        virtual TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);

    private: //Data
        CAknNavigationControlContainer* iNaviPane;
        CAknTabGroup*                   iTabGroup;
        CAknNavigationDecorator*        iDecoratedTabGroup;
		TBuf<KMaxUsernameLength>		username;
		TBuf8<1024>						iSocketData;
		TRequestStatus					iResponse;
		TFileName						iStrError;

    public:
	    void ShowErrorDialog(TInt aResponse, TDesC& aText);
	    void SendBlogData();
	    void ShowSocketError(TDesC& aStrError, TMVBDialogType aType=EMVBErrorNote);

		CSocketEngine*		iSocket;
		RFs					iFsFile;
		RFile				readFile;
		TBool				iIsFileOpen;

		TInt				iTextSize;
		CProgressNoteGameSaverAO*		iSaveProgress;
    };

#endif

// End of File
