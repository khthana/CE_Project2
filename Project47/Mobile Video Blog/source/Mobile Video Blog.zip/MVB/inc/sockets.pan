/* Copyright (c) 2001, Nokia. All rights reserved */

#ifndef __SOCKETS_PAN__
#define __SOCKETS_PAN__

#include <e32std.h>

_LIT(KPanicSocket, "Sockets");
_LIT(KPanicSocketEngine, "SocketsEngine");
_LIT(KPanicSocketEngineWrite, "SocketsEngineWrite");
_LIT(KPanicSocketEngineRead, "SocketsEngineRead");

/** Sockets application panic codes */
enum TSocketsPanics 
    {
    ESocketBasicUi = 1,
    ESocketBadStatus,
    ESocketAppView,
    ESocketBadState
    };

#endif // __SOCKETS_PAN__
