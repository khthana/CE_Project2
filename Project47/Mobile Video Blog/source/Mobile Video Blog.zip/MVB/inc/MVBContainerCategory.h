/*
* ============================================================================
*  Name     : CMVBContainerCategory from MVBContainerCategory.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares container control for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBContainerCategory_H
#define MVBContainerCategory_H

// INCLUDES
#include <coecntrl.h>
#include <aknlists.h>
#include "eiklbx.h"         // For Listbox
#include "MVBCategory.h"
   
// FORWARD DECLARATIONS
class CEikLabel;        // for example labels

// CLASS DECLARATION

/**
*  CMVBContainerCategory  container control class.
*  
*/
class CMVBContainerCategory : public CCoeControl, MCoeControlObserver
    {
    public: // Constructors and destructor
        
        /**
        * EPOC default constructor.
        * @param aRect Frame rectangle for Container.
        */
        void ConstructL(const TRect& aRect);

        /**
        * Destructor.
        */
        ~CMVBContainerCategory();

    public: // New functions
		void ShowCategoryList(CArrayFixSeg<TCategory>& aCategoryList);

    public: // Functions from base classes
	    void SetParent(CMVBCategory& aParent);
	    TInt GetSelectCategoryIndex();

    private: // Functions from base classes

       /**
        * From CoeControl,SizeChanged.
        */
        void SizeChanged();
		TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType );

       /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

       /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;

       /**
        * From CCoeControl,Draw.
        */
        void Draw(const TRect& aRect) const;

       	
		/**
		* From MCoeControlObserver
		* Acts upon changes in the hosted control's state. 
		*
		* @param	aControl	The control changing its state
		* @param	aEventType	The type of control event 
		*/
        void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
        
    private: //data
        
		CAknSingleNumberStyleListBox* iListBox;
		CMVBCategory	*iParent;

    };

#endif

// End of File
