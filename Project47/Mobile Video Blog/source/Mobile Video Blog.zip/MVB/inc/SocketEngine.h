// SocketEngine.h: interface for the CSocketEngine class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __SOCKETENGINE_H__
#define __SOCKETENGINE_H__

#include <es_sock.h>
#include <in_sock.h>
#include <e32base.h>
#include <SecureSocket.h>
#include "mvb.hrh"
#include "TimeOutNotifier.h"
#include "MVBAppUi.h"

class CSocketsReader;
class CSocketsWriter;
class CTimeOutTimer;
class CSocketEngine : public CActive, public MTimeOutNotifier
{
	friend class CMVBAppUi;
public:
	TSocketState GetState();
	void StateProcess();
	void ReadedProcess(TDesC8& aData);
	void WritedProcess(TInt aResult);
	void Disconnect();
	void ChangeState(TSocketState aState);
	void SetUi(CMVBAppUi& aUi);
	static CSocketEngine* NewLC();
	static CSocketEngine* NewL();
	void ConnectL(TDesC8& aUsername, TDesC8& aPassword);
	void ConstructL();
	CSocketEngine();
	virtual ~CSocketEngine();
	void TimerExpired();
	void ReadL();
	void WriteL(const TDesC8& aData, TRequestStatus* aResponse);

private:
	enum {KReadBufferSize = 512};

	RSocket						iSocket;
	RSocketServ					iSocketServer;
	TInetAddr					iSockAddr;
	TSocketState				iState;
	CSocketsReader*             iSocketsReader;
	CSocketsWriter*             iSocketsWriter;

	CMVBAppUi*					iUi;
	CTimeOutTimer*				iTimer;
	static const TInt			KTimeOut;
	TSockXfrLength				iDummyLength;
	TFileName					iStrError;
	TBuf8<50>					iUsername;
	TBuf8<50>					iPassword;
	TBuf8<KReadBufferSize*2>	iReadData;
	TInt						iColonPos;

protected:
	void RunL();
	void DoCancel();

public:
	void EncryptData(TDes8& aOut, TDesC8& aIn);
	void SecureConnect();
	TBuf<15>					KServerIP;
	TInt						KPortNumber;
	TInt						iCount;
};

#endif // !defined(AFX_SOCKETENGINE_H__7F8851C7_7B54_45D7_9C0D_670E737ABA09__INCLUDED_)
