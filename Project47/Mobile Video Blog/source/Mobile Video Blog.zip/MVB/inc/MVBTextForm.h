#ifndef MVBTEXTFORM_H
#define MVBTEXTFORM_H

// INCLUDES

// System includes
#include <aknform.h> // CAknForm

// User includes
#include "NumericEditorEmployee.h" // TNumericEditorEmployee


// CLASS DECLARATION

/**
*
* @class	CNumericEditorForm NumericEditorForm.h
* @brief	This is the Form class for the NumericEditor form example based on the
* standard Symbian OS architecture.
*
* Copyright (c) EMCC Software Ltd 2003
* @version	1.0
*
*/
class CNumericEditorForm : public CAknForm
	{
public: // Constructor

	static CNumericEditorForm* NewL(TNumericEditorEmployee& aEmployee, TBool& aSaveState);

private: // from CAknForm

	void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane);

	TBool SaveFormDataL();

	void DoNotSaveFormDataL();

	void PostLayoutDynInitL();

private: // Constructor

	CNumericEditorForm (TNumericEditorEmployee& aEmployee, TBool& aSaveState);

private: // members

	void LoadFormValuesFromDataL();

private: //data
	TNumericEditorEmployee& iEmployee;
	TBool& iSaveState;
	};

#endif	// #ifndef NUMERICEDITORFORM_H

// End of File
