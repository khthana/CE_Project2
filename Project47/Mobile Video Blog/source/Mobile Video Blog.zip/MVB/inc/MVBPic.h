/*
* ============================================================================
*  Name     : CMVBPic from MVBPic.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares view for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBPIC_H
#define MVBPIC_H

// INCLUDES
#include <aknview.h>
#include <mmgfetchverifier.h> 
#include <MGFetch.h>

// CONSTANTS
// UID of view
const TUid KPicId = {3};

// FORWARD DECLARATIONS
class CMVBContainerPic;

// CLASS DECLARATION

typedef struct TFileInfoTag {
	TFileName	iFileName;
	TFileName	iFilePath;
	TInt		iFileSize;
} TFileInfo;
/**
*  CMVBPic view class.
* 
*/
class CMVBPic : public CAknView, MMGFetchVerifier
    {
    public: // Constructors and destructor
		
        /**
        * EPOC default constructor.
        */
        void ConstructL();

        /**
        * Destructor.
        */
        ~CMVBPic();

    public: // Functions from base classes
        
        /**
        * From CAknView returns Uid of View
        * @return TUid uid of the view
        */
        TUid Id() const;

        /**
        * From MEikMenuObserver delegate commands from the menu
        * @param aCommand a command emitted by the menu 
        * @return void
        */
        void HandleCommandL(TInt aCommand);

        /**
        * From CAknView reaction if size change
        * @return void
        */
        void HandleClientRectChange();

    private:

        /**
        * From CAknView activate the view
        * @param aPrevViewId 
        * @param aCustomMessageId 
        * @param aCustomMessage 
        * @return void
        */
        void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
            const TDesC8& aCustomMessage);

        /**
        * From CAknView deactivate the view (free resources)
        * @return void
        */
        void DoDeactivate();
		//=== Virtual function for MMGFetchVerifier inherit
		TBool VerifySelectionL (const MDesCArray *aSelectedFiles); 

    private: // Data
        CMVBContainerPic* iContainer;

    public:
	    void CancelSelectFile(TInt aType);
	    void ShowFileExtent();
		void BrowseUsingMGFetchL(TMediaFileType aMediaType);
		TFileInfo iFileExtent[3];

		TInt		iResponse;
		RFs			iFsFile;
		RFile		readFile;
    };

#endif

// End of File
