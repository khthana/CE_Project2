/*
* ============================================================================
*  Name     : CMVBContainerPic from MVBContainerPic.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares container control for application.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBContainerPic_H
#define MVBContainerPic_H

// INCLUDES
#include <coecntrl.h>
#include "eiklbx.h"         // For Listbox
   
// FORWARD DECLARATIONS
class CEikLabel;        // for example labels

// CLASS DECLARATION

/**
*  CMVBContainerPic  container control class.
*  
*/
class CMVBContainerPic : public CCoeControl, MCoeControlObserver
    {
    public: // Constructors and destructor

        /**
        * EPOC default constructor.
        * @param aRect Frame rectangle for Container.
        */
        void ConstructL(const TRect& aRect);

        /**
        * Destructor.
        */
        ~CMVBContainerPic();

    public: // New functions

    public: // Functions from base classes

    private: // Functions from base classes

       /**
        * From CoeControl,SizeChanged.
        */
        void SizeChanged();
		TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType );

       /**
        * From CoeControl,CountComponentControls.
        */
        TInt CountComponentControls() const;

       /**
        * From CCoeControl,ComponentControl.
        */
        CCoeControl* ComponentControl(TInt aIndex) const;

       /**
        * From CCoeControl,Draw.
        */
        void Draw(const TRect& aRect) const;

       	
		/**
		* From MCoeControlObserver
		* Acts upon changes in the hosted control's state. 
		*
		* @param	aControl	The control changing its state
		* @param	aEventType	The type of control event 
		*/
        void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
        
    public: //data
        
        CEikLabel* iLabel;          // example label
    };

#endif

// End of File
