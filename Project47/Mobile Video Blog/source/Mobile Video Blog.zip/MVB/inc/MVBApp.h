/*
* ============================================================================
*  Name     : CMVBApp from MVBApp.h
*  Part of  : MVB
*  Created  : 12/15/2004 by 
*  Description:
*     Declares main application class.
*  Version  :
*  Copyright: 
* ============================================================================
*/

#ifndef MVBAPP_H
#define MVBAPP_H

// INCLUDES
#include <aknapp.h>

// CONSTANTS
// UID of the application
const TUid KUidMVB = { 0x0DDC6845 };

// CLASS DECLARATION

/**
* CMVBApp application class.
* Provides factory to create concrete document object.
* 
*/
class CMVBApp : public CAknApplication
    {
    
    public: // Functions from base classes
    private:

        /**
        * From CApaApplication, creates CMVBDocument document object.
        * @return A pointer to the created document object.
        */
        CApaDocument* CreateDocumentL();
        
        /**
        * From CApaApplication, returns application's UID (KUidMVB).
        * @return The value of KUidMVB.
        */
        TUid AppDllUid() const;
    };

#endif

// End of File

