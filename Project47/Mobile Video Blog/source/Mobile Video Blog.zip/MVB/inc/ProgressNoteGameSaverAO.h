#ifndef PROGRESSNOTEGAMESAVERAO_H
#define PROGRESSNOTEGAMESAVERAO_H

// INCLUDES

// System Includes
#include <AknWaitNoteWrapper.h> // MProgressDialogCallback
#include <e32base.h>  // CActive

// FORWARD DECLARATIONS
class CAknProgressDialog;

// CLASS DECLARATION

/**
*
* @class	CProgressNoteGameSaverAO ProgressNoteGameSaverAO.h 
* @brief	This is the Active object class for a progress note example based on the
* standard Symbian OS architecture.  
*
* Copyright (c) EMCC Software Ltd 2003
* @version	1.0
* 
*/
class CProgressNoteGameSaverAO : public CActive, MProgressDialogCallback
	{
public: // Constructors and Destructors
	
	~CProgressNoteGameSaverAO();
	static CProgressNoteGameSaverAO* NewL();
	static CProgressNoteGameSaverAO* NewLC();
	
public: // members
	
	void SaveGameL(TInt aFinalValue);
	void ToSetActive();
	
private: // members
	
	TBool IsProcessDone() const;
	void SaveGamePartToFile ();
	void CancelGameSave();
	void CompleteGameSave();
	
private: // constructor
	
	CProgressNoteGameSaverAO() : CActive (EPriorityStandard){};
	void ConstructL();
	
private: // from CActive
	
	void RunL();
	void DoCancel();
	
private: // from MProgressDialogCallback
	
	void DialogDismissedL(TInt /*aButtonId*/); 
	
private: //data
	
	RTimer iTimeWaster;
	CAknProgressDialog* iProgressDialog;
	TInt iStepsCompleted;
	TInt iFinalValue;
	};
#endif //PROGRESSNOTEGAMESAVERAO_H
