// SocketEngine.cpp: implementation of the CSocketEngine class.
//
//////////////////////////////////////////////////////////////////////

#include <SecureSocket.h>
#include "SocketEngine.h"
#include "TimeOutTimer.h"
#include "Sockets.pan"
#include "MVBAppUi.h"
#include "SocketsReader.h"
#include "SocketsWriter.h"
#include "mvb.hrh"
#include "MVBCategory.h"
#include "ProgressNoteGameSaverAO.h"

const TInt CSocketEngine::KTimeOut = 30000000; // 30 seconds time-out
_LIT(KTLS1,"SSL2.0");
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSocketEngine::CSocketEngine()
: CActive(EPriorityHigh),
  iState(ENotConnected),
  iCount(0)
{
}

CSocketEngine::~CSocketEngine()
{
	if (IsActive())
		Cancel();

	delete iTimer;
	iTimer = NULL;

	iSocketServer.Close();
}

void CSocketEngine::ConstructL()
{
    // Start a timer
	iTimer = CTimeOutTimer::NewL(EPriorityHigh, *this);
	CActiveScheduler::Add(this);

	TInt err = iSocketServer.Connect();
	if (err != KErrNone && err != KErrAlreadyExists)
		{
		iStrError = _L("Cannot Connected\n Server.");
		iUi->ShowSocketError(iStrError);
		User::Leave(err);
		}
    // Create socket read and write active objects
	iSocketsReader = CSocketsReader::NewL(iSocket);
	iSocketsWriter = CSocketsWriter::NewL(iSocket);
	iSocketsReader->SetEngine(*this);
	iSocketsWriter->SetEngine(*this);

	// Define Socket address and port
	KServerIP = _L("161.246.5.206");
	KPortNumber = 2548;
}

void CSocketEngine::ConnectL(TDesC8& aUsername, TDesC8& aPassword)
{
	if (iState == ENotConnected)
		{
		iUsername.Copy(aUsername);
		iPassword.Copy(aPassword);
		// Open a TCP socket
		iSockAddr.SetPort(KPortNumber);
		iSockAddr.Input(KServerIP);
		User::LeaveIfError(iSocket.Open(iSocketServer, KAfInet, KSockStream, KProtocolInetTcp));

		// Initiate socket connection
	    iSocket.Connect(iSockAddr, iStatus);
		iState = EConnecting;

		// Start a timeout
	    iTimer->After(KTimeOut);

		SetActive();
		}
}

CSocketEngine* CSocketEngine::NewL()
{
	CSocketEngine* self = CSocketEngine::NewLC();
	CleanupStack::Pop(self);
	return self;
}

CSocketEngine* CSocketEngine::NewLC()
{
	CSocketEngine* self = new (ELeave) CSocketEngine();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

void CSocketEngine::DoCancel()
{
    iTimer->Cancel();

    // Cancel appropriate request to socket
    switch (iState)
        {
        case EConnecting:
            iSocket.CancelConnect();
            iSocket.Close();
			iState = ENotConnected;
            break;
	    default:
            User::Panic(KPanicSocketEngine, ESocketBadStatus);
            break;
	    }
}

void CSocketEngine::RunL()
{
    // Active object request complete handler.
    // iEngineStatus flags what request was made, so its
    // completion can be handled appropriately
	iTimer->Cancel(); // Cancel TimeOut timer before completion

	switch(iState)
	    {
		case EConnecting:
		    // IP connection request
		    if (iStatus == KErrNone)
		        // Connection completed successfully
		        {
				iStrError = _L("Connection Pass");
//				iUi->ShowSocketError(iStrError, EMVBInfoNote);
				
				iState = EAuthorize;
				StateProcess();
		        }
		    else
		        {
			    iSocket.Close();
				iStrError = _L("Connection Fail");
				iUi->ShowSocketError(iStrError);
                iState = ENotConnected;
                }
		    break;
		case EAuthorize:
			{

			}
			break;
	    default:
			{
			iStrError = _L("Panic RunL");
			iUi->ShowSocketError(iStrError);
            User::Panic(KPanicSocketEngine, ESocketBadStatus);
            break;
			}

	    };
}

void CSocketEngine::TimerExpired()
    {
	Cancel();
	switch(iState)
		{
		case EConnecting:
			{
			iStrError = _L("Timed Out");
			iUi->ShowSocketError(iStrError);
			}
			break;
		case EAuthorize:
			{
			iStrError = _L("No data receive");
			iUi->ShowSocketError(iStrError);
			}
			break;
		case ESendTextData:
		case ESendPicData:
		case ESendSoundData:
		case ESendVideoData:
			WritedProcess(KErrNone);
			break;

		default:
			break;
		}
    }

void CSocketEngine::SetUi(CMVBAppUi &aUi)
{
	iUi = &aUi;
}

void CSocketEngine::ReadL()
    {
    // Initiate read of data from socket
	if ((iState != ENotConnected) && (!iSocketsReader->IsActive())) 
        {
        iSocketsReader->Start();
        }
    }

void CSocketEngine::WriteL(const TDesC8& aData, TRequestStatus* aResponse)
    {
	if (iState != ENotConnected)
		{
		iSocketsWriter->IssueWriteL(aData, aResponse);
		}	
	else
		{
		*aResponse = KErrCancel;
		}
    }

void CSocketEngine::ChangeState(TSocketState aState)
{
	iState = aState;
}

void CSocketEngine::Disconnect()
{
	if (IsActive())
		Cancel();
	if (iSocketsWriter->IsActive())
		iSocketsWriter->Cancel();
	if (iSocketsReader->IsActive())
		iSocketsReader->Cancel();

	iSocket.Close();
	static_cast<CMVBCategory*>(iUi->View(KViewId))->Clear_Category();
	ChangeState(ENotConnected);
}


void CSocketEngine::WritedProcess(TInt aResult)
{
	switch(iState)
	    {
	    case EAuthorize:
			{
			iStrError = _L("Send authorize data completed");
//			iUi->ShowSocketError(iStrError, EMVBInfoNote);
			ReadL();
			}
			break;
		case ESendTextData:
		case ESendPicData:
		case ESendSoundData:
		case ESendVideoData:
			{
			if (iCount > 1)
				iCount = 0;
			iCount++;

			if (iCount <=1)
				{
				if (aResult != KErrNone)
					iState = ESendTimeOut;
				iUi->SendBlogData();
				if (iState != EConnected)
					{
/*					iStrError = _L("Continued Send Data.");
					iUi->ShowSocketError(iStrError, EMVBInfoNote);
*/					iUi->iSaveProgress->ToSetActive();
					}
				}
			else
				ReadL();
//				iTimer->After(1000000);

			}
			break;
		default:
			break;
		}
}

void CSocketEngine::ReadedProcess(TDesC8& aData)
{
	if (aData.Length() > 0)
		iReadData.Append(aData);
	TBuf8<KReadBufferSize*2> iTempData;
	switch(iState)
		{
		case EAuthorize:
			{
			iColonPos = iReadData.Locate(':');
			if (iColonPos == KErrNotFound)
				{
				iStrError = _L("Continue receive data.");
//				iUi->ShowSocketError(iStrError, EMVBInfoNote);
				}
			else
				{
				iTempData.Copy(iReadData);
				iReadData.Delete(0, iColonPos+1);
				iTempData.SetLength(iColonPos);

				if (iTempData.Compare(_L8("Pass")) == 0)
					{
					iStrError = _L("Password correct.");
					iUi->ShowSocketError(iStrError, EMVBConfirmNote);
					iState = EReceiveCategory;
					}
				else if (iTempData.Compare(_L8("Limit Over")) == 0)
					{
					iStrError = _L("Over connection.\nPlease try again.");
					iUi->ShowSocketError(iStrError);
					Disconnect();
					}
				else
					{
					iStrError = _L("Password incorrect.");
					iUi->ShowSocketError(iStrError);
					Disconnect();
					}
				}
			}

		case EReceiveCategory:
			{
			TBuf8<KSizeCategoryID+KSizeCategoryTopic> iCategoryData;
			TBuf8<KSizeCategoryID+KSizeCategoryTopic> iCategoryID;
			iColonPos = iReadData.Locate(':');
			while (iColonPos != KErrNotFound)
				{
				iTempData.Copy(iReadData);
				iReadData.Delete(0, iColonPos+1);
				iTempData.SetLength(iColonPos);

				iCategoryData.Copy(iTempData);
				iCategoryData.SetLength(iColonPos);

				iCategoryID.Copy(iCategoryData);
				iCategoryID.SetLength(KSizeCategoryID);
				iCategoryData.Delete(0, KSizeCategoryID);
				static_cast<CMVBCategory*>(iUi->View(KViewId))->AddCategoryData(iCategoryID, iCategoryData);

				iColonPos = iReadData.Locate(':');
				}

			// Check end of category
			iColonPos = iReadData.Locate(';');
			if (iColonPos != KErrNotFound)
				{
				iState = EConnected;
				iReadData.Delete(0, iColonPos+1);
				iStrError = _L("Prompt for send blog data.");
				iUi->ShowSocketError(iStrError, EMVBInfoNote);
				iSocketsReader->Cancel();
				}

			//Continue Read category data
			if (iState == EReceiveCategory)
				{
				iStrError = _L("Continue receive category.");
//				iUi->ShowSocketError(iStrError, EMVBInfoNote);
				}
			}
			break;
		case ESendTextData:
		case ESendPicData:
		case ESendSoundData:
		case ESendVideoData:
			{
			iColonPos = iReadData.Locate(':');
			if (iColonPos != KErrNotFound)
				{
				TBuf8<10> iServerResponse;
				iServerResponse.Copy(iReadData);
				iReadData.Delete(0, iColonPos+1);
				iServerResponse.SetLength(iColonPos);

				if (iServerResponse.Compare(_L8("Continue")) == 0)
					{
//					iStrError = _L("Continued Send Data.");
//					iUi->ShowSocketError(iStrError, EMVBInfoNote);
					iSocketsReader->Cancel();
					iCount = 0;
					WritedProcess(KErrNone);
					}
				}
			}
			break;
		default:
			break;
		}
}

void CSocketEngine::StateProcess()
{
	switch(iState)
	    {
	    case EAuthorize:
			{
			// Send data to give server authorisation
			TBuf8<150> iAuthorizeData;
			iAuthorizeData.Copy(iUsername);
			iAuthorizeData.Append(_L8(":"));
			iAuthorizeData.Append(iPassword);
			iAuthorizeData.Append(_L8(":"));

			//Send Authorize Message
			iStrError = _L("Check Authorize");
			iUi->ShowSocketError(iStrError, EMVBInfoNote);

			TRequestStatus iResponse = KErrNone;
			WriteL(iAuthorizeData, &iResponse);
			if (iResponse != KErrNone)
				{
				iStrError = _L("Connect send authorize data error.");
				iUi->ShowSocketError(iStrError);
				Disconnect();
				User::Leave(KErrCorrupt);
				}
			}
			break;

		default:
			break;
		}
}

TSocketState CSocketEngine::GetState()
{
	return iState;
}
