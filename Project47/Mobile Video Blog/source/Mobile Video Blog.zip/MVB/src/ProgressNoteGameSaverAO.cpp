/**
*
* @brief Definition of CProgressNoteGameSaverAO
*
* Copyright (c) EMCC Software Ltd 2003
* @version 1.0
*/

//	Class include
#include "ProgressNoteGameSaverAO.h"

// System includes
#include <eikprogi.h> // CEikProgressInfo
#include <MVB.rsg>

#include <eikenv.h>

// CONSTANTS
const TInt KTimerInterval(250000);
const TInt KIncrement(1);

// ================= MEMBER FUNCTIONS =======================

/**
* Destructor.
* Cancels the active object and closes the timer.
*/
CProgressNoteGameSaverAO::~CProgressNoteGameSaverAO()
	{
	Cancel();
	iTimeWaster.Close();
	delete iProgressDialog;
	}

/**
* Symbian OS 2nd phase constructor.  Creates a timer and adds the active object to the scheduler.
*/
void CProgressNoteGameSaverAO::ConstructL()
	{
	iTimeWaster.CreateLocal();
	CActiveScheduler::Add(this);
	}

/**
* Symbian OS 2 phase constructor.
* Constructs the CProgressNoteGameSaverAO using the constructor and ConstructL
* method, leaving the constructed object on the CleanupStack before returning it.
*
* @param aRect The rectangle for this window
* @return The newly constructed CProgressNoteGameSaverAO
*/
CProgressNoteGameSaverAO* CProgressNoteGameSaverAO::NewLC()
	{
	CProgressNoteGameSaverAO* self = new (ELeave) CProgressNoteGameSaverAO();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

/**
* Symbian OS 2 phase constructor.
* Constructs the CProgressNoteGameSaverAO using the NewLC method, popping
* the constructed object from the CleanupStack before returning it.
*
* @param aRect The rectangle for this window
* @return The newly constructed CProgressNoteGameSaverAO
*/
CProgressNoteGameSaverAO* CProgressNoteGameSaverAO::NewL()
	{
	CProgressNoteGameSaverAO* self = CProgressNoteGameSaverAO::NewLC();
	CleanupStack::Pop(self);
	return self;
	}

/**
* Called whenever the active object is cancelled. Cancels the timer.
*/
void CProgressNoteGameSaverAO::DoCancel()
	{
	iTimeWaster.Cancel();
	}

/**
* Saves a game, by starting the active object and executing a progress dialog
*/
void CProgressNoteGameSaverAO::SaveGameL(TInt aFinalValue)
	{
	iFinalValue = aFinalValue;
	iProgressDialog = new (ELeave) CAknProgressDialog (reinterpret_cast<CEikDialog**>(&iProgressDialog));
	iProgressDialog->PrepareLC(R_PROGRESSNOTE_SAVING_GAME_NOTE);
	iProgressDialog->SetCallback (this); // calls DialogDismissL on completion
	CEikProgressInfo* progressBar = iProgressDialog->GetProgressInfoL(); // not taking ownership
	progressBar->SetFinalValue(iFinalValue);  // Set final value of progress bar
	iProgressDialog->RunLD(); // this doesn't actually delete the dialog despite the 'D' suffix
	SaveGamePartToFile(); // make a synchronous request
	progressBar->IncrementAndDraw(KIncrement); // increment the progress bar
	//SetActive(); // set the active object to be active
	}
/**
* Performs the work of the active object.
* If there is still processing to complete, saves one part of the game to file and makes the object active again.
*/
void CProgressNoteGameSaverAO::RunL()
	{
	if (!IsProcessDone())
		{
		//SaveGamePartToFile();
		iProgressDialog->GetProgressInfoL()->IncrementAndDraw(KIncrement);
		//SetActive();
		}
	else
		{
		iProgressDialog->ProcessFinishedL();
		}
	}

/**
* Called by the progress note when it is dismissed.
* This is as a result of either the user cancelling the note,
* or the process finishing.
*/
void CProgressNoteGameSaverAO::DialogDismissedL(TInt /*aButtonId*/)
	{
	if (!IsProcessDone())
		{
		CancelGameSave();
		}
	else
		{
		CompleteGameSave();
		}
	iStepsCompleted = 0;
	}

/**
* Called by RunL to check whether to continue processing.
* @return ETrue if processing is complete, EFalse otherwise
*/
TBool CProgressNoteGameSaverAO::IsProcessDone() const
	{
	return (iStepsCompleted == iFinalValue);
	}

/**
* Dummy method which could be used to cancel a partially saved game, e.g.
* by resetting values and deleting the partially created file.
* In this example it stops the timer used to simulate a game save and cancels any outstanding requests
* for this active object
*/
void CProgressNoteGameSaverAO::CancelGameSave()
	{
	Cancel();
	}

/**
* Dummy method which could be used to save part of a game to a file
* In this example, it runs a timer for an arbitrary period of time
* to simulate saving part of the game.
* This is an asynchronous method
*/
void CProgressNoteGameSaverAO::SaveGamePartToFile ()
	{
	// Use an arbitrary delay to simulate saving part of the game
	//TInt delay = KTimerInterval;
	//iTimeWaster.After(iStatus, delay);
	// Note that we have completed a step
	iStepsCompleted++;
	}

/**
* Dummy method which could be used to complete the game saving process, e.g. by closing
* the saved game file.
* In this example it stops the timer used to simulate a game save and cancels any outstanding requests
* for this active object
*/
void CProgressNoteGameSaverAO::CompleteGameSave()
	{
	Cancel();
	}

void CProgressNoteGameSaverAO::ToSetActive()
{
	SaveGamePartToFile();
	iProgressDialog->GetProgressInfoL()->SetAndDraw(iStepsCompleted);
	if (IsProcessDone())
		iProgressDialog->ProcessFinishedL();
	//iStepsCompleted++;
	//SetActive();
}
