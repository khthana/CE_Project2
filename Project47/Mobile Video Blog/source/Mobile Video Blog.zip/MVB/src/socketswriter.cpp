/* Copyright (c) 2001, Nokia. All rights reserved */

#include "SocketsWriter.h"
#include "TimeOutTimer.h"
#include "Sockets.pan"
#include "mvb.hrh"
#include "SocketEngine.h"

const TInt CSocketsWriter::KTimeOut = 30000000; // 30 seconds time-out

CSocketsWriter* CSocketsWriter::NewL(RSocket& aSocket)
    {
	CSocketsWriter* self = CSocketsWriter::NewLC(aSocket);
	CleanupStack::Pop(self);
	return self;
    }

	
CSocketsWriter* CSocketsWriter::NewLC(RSocket& aSocket)
    {
	CSocketsWriter* self = new (ELeave) CSocketsWriter(aSocket);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
    }


CSocketsWriter::CSocketsWriter(RSocket& aSocket)
: CActive(EPriorityHigh),
  iSocket(aSocket)
    {
    }


CSocketsWriter::~CSocketsWriter()
    {
    Cancel();
    delete iTimer;
    iTimer = NULL;
    }

void CSocketsWriter::DoCancel()
    {	
    // Cancel asychronous write request
	iSocket.CancelWrite();
    iTimer->Cancel();
	iWriteStatus = EWaiting;
    }

void CSocketsWriter::ConstructL()
    {
	CActiveScheduler::Add(this);

	iTimeOut = KTimeOut; 
	iTimer = CTimeOutTimer::NewL(CActive::EPriorityHigh, *this);
	iWriteStatus = EWaiting;
    }

void CSocketsWriter::TimerExpired()
    {
	Cancel();
	iWriteStatus = EWaiting;
	iEngine->WritedProcess(KErrTimedOut);
    }

void CSocketsWriter::RunL()
    {
    iTimer->Cancel();
    // Active object request complete handler
	if (iStatus == KErrNone)
	    {
		switch(iWriteStatus)
		    {
		    // Character has been written to socket
		    case ESending:
                SendNextPacket();
			    break;
		    default:
                User::Panic(KPanicSocketEngineWrite, ESocketBadStatus);
                break;
		    };
	    }
    else 
	    {
		// Error: pass it up to user interface
//        iEngineNotifier.ReportError(MEngineNotifier::EGeneralWriteError, iStatus.Int());
        iWriteStatus = EWaiting;
	    }
    }

void CSocketsWriter::IssueWriteL(const TDesC8& aData, TRequestStatus* aResponse)
    {
    if (iWriteStatus != EWaiting)
        {
		*aResponse = KErrNotReady;
//		User::Leave(KErrNotReady);
        }

    else if ((aData.Length() + iTransferBuffer.Length()) > iTransferBuffer.MaxLength())
        {
        // Not enough space in buffer
		*aResponse = KErrOverflow;
//		User::Leave(KErrOverflow);
        }

    else if (!IsActive())
        {
		// Add new data to buffer
		iTransferBuffer.Append(aData);
        SendNextPacket();
		*aResponse = KErrNone;
        }
	else
		{
		*aResponse = KErrCancel;
		}
    }

void CSocketsWriter::SendNextPacket()
    {
    if (iTransferBuffer.Length() > 0)
        {
        // Move data from transfer buffer to actual write buffer
        iWriteBuffer = iTransferBuffer;
        iTransferBuffer.Zero();
	    iSocket.Write(iWriteBuffer, iStatus); // Initiate actual write
	
        // Request timeout
	    iTimer->After(iTimeOut);
	    SetActive();
	    iWriteStatus = ESending;
        }
    else
        {
	    iWriteStatus = EWaiting;
		iEngine->WritedProcess(KErrNone);
        }
    }

TBool CSocketsWriter::IsWaitData()
{
	if (iWriteStatus == ESending)
		return EFalse;
	else
		return ETrue;
}

void CSocketsWriter::SetEngine(CSocketEngine &aEngine)
{
	iEngine = &aEngine;
}
