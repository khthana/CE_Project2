/* Copyright (c) 2001, Nokia. All rights reserved */

#include "Sockets.pan"
#include "SocketsReader.h"
#include "SocketEngine.h"

CSocketsReader* CSocketsReader::NewL(RSocket& aSocket)
    {
	CSocketsReader* self = CSocketsReader::NewLC(aSocket);
	CleanupStack::Pop(self);
	return self;
    }

	
CSocketsReader* CSocketsReader::NewLC(RSocket& aSocket)
    {
	CSocketsReader* self = new (ELeave) CSocketsReader(aSocket);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
    }


CSocketsReader::CSocketsReader(RSocket& aSocket)
: CActive(EPriorityHigh),
  iSocket(aSocket)
    {
    }


CSocketsReader::~CSocketsReader()
    {
    Cancel();
    }


void CSocketsReader::ConstructL()
    {
	CActiveScheduler::Add(this);
    }

void CSocketsReader::DoCancel()
    {
    // Cancel asychronous read request
	iSocket.CancelRead();
    }

void CSocketsReader::RunL()
    {
    // Active object request complete handler
    switch (iStatus.Int())
        {
        case KErrNone:
			{
            // Character has been read from socket
			iEngine->ReadedProcess(iBuffer);
			if (iBuffer.Length() > 0)
				iBuffer.Zero();
		    IssueRead(); // Immediately start another read
			}
            break;
        case KErrDisconnected:
			iEngine->Disconnect();
            break;
        default:
            break;
        }	
    }

void CSocketsReader::IssueRead()
    {
    // Initiate a new read from socket into iBuffer
    __ASSERT_ALWAYS(!IsActive(), User::Panic(KPanicSocketEngineRead, ESocketBadState));
    iSocket.RecvOneOrMore(iBuffer, 0, iStatus, iDummyLength);
    SetActive();
    }

void CSocketsReader::Start()
    {
    // Initiate a new read from socket into iBuffer
    if (!IsActive())
        {
        IssueRead();
        }
    }

void CSocketsReader::SetEngine(CSocketEngine &aEngine)
{
	iEngine = &aEngine;
}
