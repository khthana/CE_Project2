#!/bin/sh

echo "anubisadd has been installed."
cp ./src/anubisadd /usr/sbin/
echo "anubisdel has been installed."
cp ./src/anubisdel /usr/sbin/
echo "pam_anubis.so has been installed."
cp ./src/pam_anubis.so /lib/security/
echo "anubistty has been installed."
cp ./src/anubistty /sbin/
echo "anubislogin has been installed."
cp ./src/anubislogin /bin/
chmod 4755 /bin/anubislogin
echo "aksusbd has been installed."
cp ./option/aksusbd /usr/bin/
cp ./conf/init/anubis /etc/init.d/
cp ./conf/pam.d/anubislogin /etc/pam.d/
cp ./conf/etc/inittab /etc/

update-rc.d anubis defaults 99
echo "Verifinger 4.2 Linux SDK header files have been installed."
cp -r ./include/* /usr/include/
echo "PAM and USB libraries have been installed."
cp -d ./lib/* /usr/lib

mkdir /etc/anubis


