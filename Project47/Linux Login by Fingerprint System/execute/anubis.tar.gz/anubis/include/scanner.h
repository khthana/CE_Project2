#ifndef __SCANNER_H__
#define __SCANNER_H__

struct scanner_info
{
	int		dpi;
	char		*name;
	int		version;		/* driver version */
	void		(*close) (void);
	int		(*init) (void);
	unsigned char *	(*read) (int *width, int *height);
	int		timeout;		/* wait for getting immage */
	int             max_bad_area;           /*   default max bad area   */
};

extern struct scanner_info	scanner_AFS4000;
extern struct scanner_info	scanner_af_s2;
extern struct scanner_info	scanner_fx2k;
extern struct scanner_info	scanner_shimizu;

#endif
