/********************************************************\
|*                                                      *|
|*                  VeriFinger 4.2 SDK                  *|
|*                                                      *|
|*  VFinger.h                                           *|
|*    Header file for VeriFinger library                *|
|*                                                      *|
|*  Copyright (C) 1998-2004 Neurotechnologija Ltd.      *|
|*                                                      *|
\********************************************************/

// Avoid multiple includes
#ifndef __VFINGER_INCLUDED__
#define __VFINGER_INCLUDED__

// Force C (not C++) names for VeriFinger API functions
#ifdef __cplusplus
extern "C"
{
#endif

///////////
//       //
// Types //
//       //
///////////

typedef unsigned char BYTE;
typedef signed char SBYTE;
typedef char CHAR;
typedef unsigned short WORD;
typedef unsigned short USHORT;
typedef short SHORT;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef int INT;
typedef long LONG;
typedef float FLOAT;
typedef double DOUBLE;
typedef int BOOL;

typedef void * HVFCONTEXT;

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#else
#define NULL ((void *)0)
#endif
#endif

///////////////
//           //
// Constants //
//           //
///////////////

#define VF_IMAGE_RESOLUTION 500
#define VF_FEATURES_RESOLUTION 500
#define VF_MAX_FEATURES_DIMENSION 2048
#define VF_MAX_MINUTIA_COUNT 1024
#define VF_MAX_SINGULAR_POINT_COUNT 64
#define VF_BLOCK_SIZE 16
#define VF_MAX_BLOCKED_ORIENTS_DIMENSION (VF_MAX_FEATURES_DIMENSION / VF_BLOCK_SIZE)
#define VF_MAX_FEATURES_SIZE 10000

#define VF_GENERALIZE_COUNT 3

#ifndef PI
#define PI 3.1415926535897932384626433832795
#endif

//////////////
//          //
// Features //
//          //
//////////////

typedef enum _VFSingularPointType
{
	vfsptUnknown = 0,
	vfsptCore = 1,
	vfsptDoubleCore = 2,
	vfsptDelta = 3
} VFSingularPointType;

typedef struct _VFSingularPoint
{
	INT X;
	INT Y;
	VFSingularPointType T;
	BYTE D;
} VFSingularPoint;

typedef enum _VFMinutiaType
{
	vfmtUnknown = 0,
	vfmtEnd = 1,
	vfmtBifurcation = 2
} VFMinutiaType;

typedef struct _VFMinutia
{
	INT X;
	INT Y;
	VFMinutiaType T;
	BYTE D;
	BYTE C;
	BYTE G;
} VFMinutia;

///////////////////
//               //
// Match details //
//               //
///////////////////

typedef struct _VFMatchDetails
{
	DWORD Size;

	INT Similarity;
	INT Rotation;
	INT TranslationX;
	INT TranslationY;
} VFMatchDetails;

typedef struct _VFMatchedMinutiae
{
	INT Count;
	SHORT Test[VF_MAX_MINUTIA_COUNT];
	SHORT Sample[VF_MAX_MINUTIA_COUNT];
} VFMatchedMinutiae;

typedef struct _VFMatchDetailsEx
{
	DWORD Size;

	INT Similarity;
	INT Rotation;
	INT TranslationX;
	INT TranslationY;

	VFMatchedMinutiae MM;
} VFMatchDetailsEx;

////////////////
//            //
// Directions //
//            //
////////////////

#define VFDIR_0    0
#define VFDIR_45  30
#define VFDIR_90  (VFDIR_45 * 2)
#define VFDIR_135 (VFDIR_45 * 3)
#define VFDIR_180 (VFDIR_45 * 4)
#define VFDIR_225 (VFDIR_45 * 5)
#define VFDIR_270 (VFDIR_45 * 6)
#define VFDIR_315 (VFDIR_45 * 7)
#define VFDIR_360 (VFDIR_45 * 8)
#define VFDIR_UNKNOWN 127
#define VFDIR_BACKGROUND 255
// Conversion from VFDIR_XXX to degrees and vice a versa
#define VFDirToDeg(dir) ((INT)(((dir) * 180 + ((dir) < 0 ? -VFDIR_90 : VFDIR_90)) / VFDIR_180))
#define VFDirToDegF(dir) ((dir) * 180.0 / VFDIR_180)
#define VFDegToDir(deg) ((BYTE)(((deg) * VFDIR_180 + ((deg) < 0 ? -90 : 90)) / 180))
// Conversion from VFDIR_XXX to radians and vice a versa
#define VFDirToRad(dir) ((dir) * PI / VFDIR_180)
#define VFRadToDir(a) ((BYTE)(INT)(a * VFDIR_180 / PI + (a < 0 ? -0.5 : 0.5)))
// Orientation stuff
#define VFIsBadArea(orient) ((BYTE)(orient) & 128)
#define VFIsGoodArea(orient) (!((BYTE)(orient) & 128))
#define VFTheOrient(orient) ((BYTE)(orient) & 127)
#define VFIsUnknown(orient) (VFTheOrient(orient) == VFDIR_UNKNOWN)
#define VFIsOrient(orient) (VFTheOrient(orient) < VFDIR_180)

////////////////////////
//                    //
// Registration types //
//                    //
////////////////////////

#define VF_RT_NOT_PROTECTED 0
#define VF_RT_UNREGISTERED  6
#define VF_RT_HASP          1
#define VF_RT_PC            2
#define VF_RT_UAREU         4
#define VF_RT_LAN           8

/////////////////////
//                 //
// Parameter types //
//                 //
/////////////////////

#define VF_TYPE_VOID     0
#define VF_TYPE_BYTE     1
#define VF_TYPE_SBYTE    2
#define VF_TYPE_WORD     3
#define VF_TYPE_SHORT    4
#define VF_TYPE_DWORD    5
#define VF_TYPE_INT      6
#define VF_TYPE_BOOL    10
#define VF_TYPE_CHAR    20
#define VF_TYPE_STRING 100

//////////////////////////////////////
//                                  //
// FAR and matching threshold ratio //
//                                  //
//////////////////////////////////////

#define VF_FARMT_COUNT 4
#ifndef VF_WE_DONT_NEED_CONSTS
const DOUBLE VF_FARMT_FAR[VF_FARMT_COUNT] = {0.0, 1.0, 2.0, 3.0}; // FAR 10^-X %
const INT VF_FARMT_MT[VF_FARMT_COUNT] = {22, 34, 47, 63}; // Matching threshold
#else
extern const DOUBLE VF_FARMT_FAR[VF_FARMT_COUNT];
extern const INT VF_FARMT_MT[VF_FARMT_COUNT];
#endif

/////////////////
//             //
// Error codes //
//             //
/////////////////

// Pass VFXxx() function result to this macro to determine if the execution of that function failed
#define VFFailed(result) ((result) < 0)

// Pass VFXxx() function result to this macro to determine if the execution of that function succeeded
#define VFSucceeded(result) ((result) >= 0)

// General
#define VFE_OK                0
#define VFE_FAILED           -1
#define VFE_OUT_OF_MEMORY    -2
#define VFE_NOT_INITIALIZED  -3
#define VFE_ARGUMENT_NULL    -4
#define VFE_INVALID_ARGUMENT -5
#define VFE_NOT_IMPLEMENTED  -9
// Registration
#define VFE_NOT_REGISTERED           -2000
#define VFE_INVALID_SERIAL_NUMBER    -2001
#define VFE_INVALID_REGISTRATION_KEY -2002
#define VFE_SCANNER_DRIVER_ERROR     -2003
#define VFE_REGISTRATION_NOT_NEEDED  -2004
#define VFE_NO_SCANNER               -2005
#define VFE_MORE_THAN_ONE_SCANNER    -2006
#define VFE_LM_CONNECTION_ERROR      -2007
#define VFE_LM_NO_MORE_LICENSES      -2008
// Parameters
#define VFE_INVALID_PARAMETER   -10
#define VFE_PARAMETER_READ_ONLY -11
// Features extraction
#define VFE_ILLEGAL_IMAGE_RESOLUTION -101
#define VFE_ILLEGAL_IMAGE_SIZE       -102
#define VFE_LOW_QUALITY_IMAGE        -103
// VeriFinger specific
#define VFE_INVALID_MODE -1000
// Features
#define VFE_INVALID_FEATURES_FORMAT -3000

///////////////
//           //
// Functions //
//           //
///////////////

#if defined(linux) || defined (__LINUX__)
#define VFINGER_API
#else
#define VFINGER_API __stdcall
#endif

// Registration
INT VFINGER_API VFRegistrationType();
INT VFINGER_API VFGenerateId(CHAR * serial, CHAR * id);
INT VFINGER_API VFRegister(CHAR * serial, CHAR * key);

// Initialization
INT VFINGER_API VFInitialize();
INT VFINGER_API VFFinalize();

// Contexts
HVFCONTEXT VFINGER_API VFCreateContext();
INT VFINGER_API VFFreeContext(HVFCONTEXT context);

// Parameters
INT VFINGER_API VFGetParameter(INT parameter, void * value, HVFCONTEXT context);
INT VFINGER_API VFSetParameter(INT parameter, DWORD value, HVFCONTEXT context);

// Features extraction
INT VFINGER_API VFExtract(INT width, INT height, BYTE * image, INT resolution, BYTE * features, DWORD * size, HVFCONTEXT context);

// Features generalization
INT VFINGER_API VFGeneralize(INT count, const BYTE * const * gen_features, BYTE * features, DWORD * size, HVFCONTEXT context);

// Verification
INT VFINGER_API VFVerify(const BYTE * features1, const BYTE * features2, VFMatchDetails * md, HVFCONTEXT context);

// Identification
INT VFINGER_API VFIdentifyStart(const BYTE * test_features, HVFCONTEXT context);
INT VFINGER_API VFIdentifyNext(const BYTE * sample_features, VFMatchDetails * md, HVFCONTEXT context);
INT VFINGER_API VFIdentifyEnd(HVFCONTEXT context);

// Features compression
INT VFINGER_API VFFeatSet(BYTE g, INT mCount, const VFMinutia * m,
	INT spCount, const VFSingularPoint * sp, INT boWidth, INT boHeight, const BYTE * bo,
	BYTE * features);

// Features decompression
INT VFINGER_API VFFeatGetG(const BYTE * features);
INT VFINGER_API VFFeatGetMinutiaCount(const BYTE * features);
INT VFINGER_API VFFeatGetMinutiae(const BYTE * features, VFMinutia * m);
INT VFINGER_API VFFeatGetSPCount(const BYTE * features);
INT VFINGER_API VFFeatGetSP(const BYTE * features, VFSingularPoint * sp);
INT VFINGER_API VFFeatGetBOSize(const BYTE * features, INT * pWidth, INT * pHeight);
INT VFINGER_API VFFeatGetBO(const BYTE * features, BYTE * bo);

////////////////
//            //
// Parameters //
//            //
////////////////

/**************************************************************************************\

Parameters can be of the following types:
	byte (VF_TYPE_BYTE)
	signed byte (VF_TYPE_SBYTE)
	word (VF_TYPE_WORD)
	short integer (VF_TYPE_SHORT)
	double word (VF_TYPE_DWORD)
	integer (VF_TYPE_INT)
	boolean (VF_TYPE_BOOL)
	char (VF_TYPE_CHAR);
	string (VF_TYPE_STRING)
For VFGetParameters "void * value" have to be:
	BYTE* for byte
	SBYTE* for signed byte
	WORD* for word
	SHORT* for short integer
	DWORD* for double word
	INT* for integer
	BOOL* for boolean
	CHAR* for char
	CHAR* for string (must point to array of at least string length + 1 CHARs; if NULL string length is returned)
For VFSetParameters "DWORD value" have to be:
	(DWORD)(BYTE) for byte;
	(DWORD)(SBYTE) for signed byte
	(DWORD)(WORD) for word
	(DWORD)(SHORT) for short integer
	(DWORD) for double word
	(DWORD)(INT) for integer
	(DWORD)(BOOL) for boolean
	(DWORD)(CHAR) for char
	(DWORD)(CHAR*) for string
Some parameters are read only

\**************************************************************************************/

// General parameters
#define VFP_TYPE          0 // Get | Returns one of VF_TYPE_XXX constants - type of the parameter which id is passed as value
#define VFP_NAME         10 // Get | String | Returns name of the library
#define VFP_VERSION_HIGH 11 // Get | DWord  | Returns high part of the library version
#define VFP_VERSION_LOW  12 // Get | DWord  | Returns low part of the library version
#define VFP_COPYRIGHT    13 // Get | String | Returns copyright of the library

// Extraction parameters
#define VFP_EXTRACT_FEATURES 110 // Get/Set | Int | Obsolete. Can be one of the following
	#define	VF_ALL_FEATURES                             0
	#define	VF_OMIT_BLOCKED_ORIENTATIONS                1
	#define VF_OMIT_BLOCKED_ORIENTATIONS_AND_CURVATURES 2

#define VFP_RETURNED_IMAGE 10002 // Get/Set | Int | Can be one of the following
	#define VF_RETURNED_IMAGE_NONE         0
	#define VF_RETURNED_IMAGE_BINARIZED    1
	#define VF_RETURNED_IMAGE_SKELETONIZED 2

// Matching parameters
#define VFP_MATCHING_THRESHOLD 200 // Get/Set | Int | >= 0
#define VFP_MAXIMAL_ROTATION   201 // Get/Set | Int | DIR_0..DIR_180
#define VFP_MATCH_FEATURES     210 // Get/Set | Int | Obsolete. The values are the same as for the VFP_EXTRACT_FEATURES

#define VFP_MATCHING_SPEED 220 // Get/Set | Int | Can be one of the following
	#define VF_MATCHING_SPEED_LOW    0
	#define VF_MATCHING_SPEED_HIGH 256

// Generalization parameters
#define VFP_GENERALIZATION_THRESHOLD 300 // Get/Set | Int | >= 0
#define VFP_GEN_MAXIMAL_ROTATION     301 // Get/Set | Int | DIR_0..DIR_180

// VeriFinger parameters
#define VFP_MODE 1000 // Get/Set | Int | Can be one of the following
	#define VF_MODE_GENERAL                           0
	#define VF_MODE_DIGITALPERSONA_UAREU            100
	#define VF_MODE_DIGITALPERSONA_URU              VF_MODE_DIGITALPERSONA_UAREU
	#define VF_MODE_BIOMETRIKA_FX2000               200
	#define VF_MODE_KEYTRONIC_SECUREDESKTOP         300
	#define VF_MODE_IDENTIX_TOUCHVIEW               400
	#define VF_MODE_PRECISEBIOMETRICS_100CS         500
	#define VF_MODE_STMICROELECTRONICS_TOUCHCHIP    600
	#define VF_MODE_IDENTICATORTECHNOLOGY_DF90      700
	#define VF_MODE_AUTHENTEC_AFS2                  800
	#define VF_MODE_AUTHENTEC_AES4000               810
	#define VF_MODE_ATMEL_FINGERCHIP                900
	#define VF_MODE_BMF_BLP100                     1000
	#define VF_MODE_SECUGEN_HAMSTER                1100
	#define VF_MODE_ETHENTICA                      1200
	#define VF_MODE_CROSSMATCH_VERIFIER300         1300

#ifdef __cplusplus
}
#endif

#endif //!__VFINGER_INCLUDED__
