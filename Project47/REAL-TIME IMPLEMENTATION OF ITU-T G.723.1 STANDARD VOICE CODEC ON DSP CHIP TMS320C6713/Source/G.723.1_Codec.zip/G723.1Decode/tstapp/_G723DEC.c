/*
//============================================================================
//
//    FILE NAME : _G723DEC.c
//
//    BLOCK NAME: G723DEC
//
//    GROUP NAME: Default Group
//
//    PURPOSE   : Provides the real-time block's DSP C source code.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Fri - 18 February 2005
//    Creation Time: 09:25 PM
//
//============================================================================
*/

#include "_g723dec.h"

#pragma DATA_SECTION(Params, ".hyper:ignore")
PARAMS Params;

/*----------------------------------------------------------------------------*/
/*               Optional real-time block interrupt routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called in response to a selected  */
/* DSP interrupt.  If this routine in not activated, the main block routine   */
/* will be called in response to a selected DSP interrupt.                    */
/*----------------------------------------------------------------------------*/
/*
void G723DEC_INT(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*               Optional real-time block initialization routine              */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called one time before the main   */
/* application begins.  This allows for any required software or hardware     */
/* initialization to be performed before the block executes.                  */
/*----------------------------------------------------------------------------*/

static IG723DEC_Fxns   fxns;
static G723DEC_Params  params;

void G723DEC_INIT(PARAMS *pPtr)
{
    fxns = G723DEC_NECTEC_IG723DEC;
    params = G723DEC_PARAMS;

    params.framesizeIn0 = pPtr->FramesizeIn0;
    params.framesizeOut0 = pPtr->FramesizeOut0;
    params.usePf = pPtr->_usePf;
    params.rate63 = pPtr->_rate63;

    pPtr->handle = G723DEC_create(&fxns, &params);
}


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block stop routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever the block diagram */
/* worksheet's execution is stopped.  Blocks that deal with hardware may need */
/* this routine to stop the hardware's execution.                             */
/*----------------------------------------------------------------------------*/
/*
void G723DEC_STOP(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block restart routine                */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever a block diagram   */
/* worksheet is executed after being stopped.  Blocks that deal with hardware */
/* may need this routine to restart the hardware's execution.                 */
/*----------------------------------------------------------------------------*/
/*
void G723DEC_RESTART(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                           Real-time block routine                          */
/*----------------------------------------------------------------------------*/
/* This is the main block routine.  It is called during each loop of the main */
/* application.  If an interrupt is selected, and the interrupt routine above */
/* is not activated, this routine will be called in response to the selected  */
/* interrupt instead of during the main application loop.                     */
/* Custom fields of the pPtr structure may be accessed as follows:            */
/*     pPtr->FramesizeIn0 = ...;                                              */
/*     pPtr->FramesizeOut0 = ...;                                             */
/*     pPtr->_usePf = ...;                                                    */
/*     pPtr->_wrkRate = ...;                                                  */
/*----------------------------------------------------------------------------*/
void G723DEC(PARAMS *pPtr)
{
    if(pPtr->handle){
        if(pPtr->Changed){
            G723DEC_Status	status;

            pPtr->Changed = FALSE;
            status.usePf = pPtr->_usePf;
            status.rate63 = pPtr->_rate63;
            G723DEC_control(pPtr->handle, G723DEC_SETSTATUS, &status);
        }

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        //G723DEC_decode(pPtr->handle, (XDAS_Int8 *)pPtr->PtrIn0, (XDAS_Int16 *)pPtr->PtrOut0);
        //G723DEC_inframesize(pPtr->handle, (XDAS_Int8 *)pPtr->PtrIn0, (XDAS_UInt32 *)pPtr->PtrOut0);
    }
}
