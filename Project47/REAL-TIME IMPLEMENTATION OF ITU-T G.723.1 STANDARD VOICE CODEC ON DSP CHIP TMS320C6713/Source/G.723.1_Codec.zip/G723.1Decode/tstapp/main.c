#include <std.h>
#include <log.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <time.h>
#include <clk.h>
#include <sts.h>
#include <trc.h>
//#include <swi.h>
//#include <hwi.h>
#include "G723DECcfg.h"




#include "g723dec.h"
#include "g723dec_nectec.h"
//#include "cst2.h"

extern int INTERNALHEAP;
extern int EXTERNALHEAP;

float PtrIn0[24];
float PtrOut0[256];
FILE  *Ifp, *Ofp; 
XDAS_Int16 Databuff[240];
XDAS_Int8 Line[24];
XDAS_UInt32 size;
G723DEC_Handle  handle;
IG723DEC_Fxns   fxns;
G723DEC_Params  params;
//int count;


void main(){
    /*G723DEC_Handle  handle;
    IG723DEC_Fxns   fxns;
    G723DEC_Params  params;*/

    fxns = G723DEC_NECTEC_IG723DEC;
    params = G723DEC_PARAMS;

    params.framesizeIn0 = 24;
    params.framesizeOut0 = 240;
    params.usePf = TRUE;
    params.rate63 = TRUE;
    Ifp = fopen("d:/tosend/xdasout53.out","rb");
	Ofp = fopen("d:/tosend/output53.pcm","wb");

    G723DEC_init();
    ALGRF_setup(INTERNALHEAP,EXTERNALHEAP);
   
    //if((handle = G723DEC_create(&fxns, &params)) != NULL){
        /* Call the control function to modify parameters as the algorithm runs 
        G723DEC_Status  status;

        // get current status
        G723DEC_control(pPtr->handle, G723DEC_GETSTATUS, &status);

        // modify/check status parameters before setting the new status information
        G723DEC_control(pPtr->handle, G723DEC_SETSTATUS, &status);
        */

        /* Call XDAIS algorithm specific routine(s) */
        // For example: */
       /* while( fread((void *)Line, 1, 1, Ifp) == 1){
        
        G723DEC_inframesize(handle, Line,&size );
        
        fread((void *)&Line[1], 1, size-1, Ifp);
        
        
        G723DEC_decode(handle, Line, Databuff);
        
        
        fwrite(Databuff, sizeof(Word16), 240, Ofp);
        
        }
        
        G723DEC_delete(handle);
    }
    G723DEC_exit();
    fclose(Ifp);
    fclose(Ofp);*/
}

void algorithm() {
	if((handle = G723DEC_create(&fxns, &params)) != NULL){
        /* Call the control function to modify parameters as the algorithm runs 
        G723DEC_Status  status;

        // get current status
        G723DEC_control(pPtr->handle, G723DEC_GETSTATUS, &status);

        // modify/check status parameters before setting the new status information
        G723DEC_control(pPtr->handle, G723DEC_SETSTATUS, &status);
        */

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        while( fread((void *)&Line[0], 1, 1, Ifp) == 1){
       // count++;
        
        G723DEC_inframesize(handle, Line,&size );
        
        fread((void *)&Line[1], size-1, 1, Ifp);
        if (TRC_query(TRC_USER0) == 0) 
                STS_set(&DEC,CLK_gethtime());
        
        
        G723DEC_decode(handle, Line, Databuff);
        
        if (TRC_query(TRC_USER0) == 0) 
                STS_delta(&DEC,CLK_gethtime());    
        
        
        fwrite(Databuff, sizeof(short), 240, Ofp);
        
        }
        
        G723DEC_delete(handle);
    }
    G723DEC_exit();
    fclose(Ifp);
    fclose(Ofp);







}

