/*
**
** File:        "lbccode2.c"
**
** Description:     Top-level source code for G.723.1 dual-rate codec
**
** Functions:       main
**                  Process_files()
**
**
*/

/*
    ITU-T G.723.1 Floating Point Speech Coder ANSI C Source Code.  Version 5.1F

    Original fixed-point code copyright (c) 1995,
    AudioCodes, DSP Group, France Telecom, Universite de Sherbrooke.
    All rights reserved.

    Floating-point code copyright (c) 1995,
    Intel Corporation and France Telecom (CNET).
    All rights reserved.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "typedef2.h"
#include "cst2.h"
#include "tab2.h"
#include "lbccode2.h"
#include "coder2.h"
#include "decod2.h"
#include "exc2.h"
#include "util2.h"
#include "codcng2.h"
#include "deccng2.h"
#include "vad2.h"

/* Global variables */
//enum  Wmode   WrkMode = Both;
//enum  Crate   wrkRate = Rate63;

//short  useHp = True;
//short  usePf = True;
//short  useVx = False;
//short  UsePr = True;
int   ReinitSize = 10;

void initCodData(CODCNTXTDEF *CodData) {
	CodData->wrkRate = Rate53;
	CodData->useHp =True;
	CodData->useVx = True;
	
	}
void initDecData(DECCNTXTDEF *DecData) {
	
	DecData->usePf = True;
	DecData->wrkRate = Rate63;

	}







	
	


char  SignOn[] = "ACL/USH/FT/DSPG ANSI C FLOATING POINT CODEC ITU LBC Ver 5.1F\n";

main(int argc, char *argv[])
{
    FILE  *Ifp, *Ofp;       /* I/O File pointers */
    FILE  *Fep  = NULL;     /* Frame erasures file pointer */
    FILE  *Ratp = NULL;     /* Rate file pointer */

	//int x=8;

    long  FrCnt = 0;
    long  FlLen = 246;
	
	

	ENCODE_HANDLE CodData;// = (CODCNTXTDEF *)malloc(sizeof(CODCNTXTDEF));
	
	DECODE_HANDLE DecData;// = (DECCNTXTDEF *)malloc(sizeof(DECCNTXTDEF));

	

	
	
	
	
	

	

    FLOAT  DataBuff[Frame];
 //   Word16 Crc;
//    char   Rate_Rd;

    char   Line[24];

    printf("%s", SignOn);

/* Process arguments and open I/O files */

    //FlLen = Process_Files(&Ifp, &Ofp, &Fep, &Ratp, argc, argv);

    /*
     * Init coder and the decoder
     */


	Ifp = fopen("d:/tosend/input.pcm","rb");
	Ofp = fopen("d:/tosend/reentout63.pcm","wb");
	init_table();

	CodData = ENCODE_HANDLE_new();
	DecData = DECODE_HANDLE_new();
	
	initCodData(CodData);
	initDecData(DecData);
	CodData->extra = 1;
    Init_Coder(CodData);
    Init_Decod(DecData);

    /* Init Comfort Noise Functions */
    //if (useVx) {
        Init_Vad(CodData);
        Init_Cod_Cng(CodData);
   // }
    Init_Dec_Cng(DecData);
	

/* Process all the input files */
    do {
       // switch (WrkMode) {

           // case Both:
             //   if (Ratp != NULL) {
              //      fread((char *)&Rate_Rd, sizeof(char), 1, Ratp);
              //      wrkRate = (enum Crate)Rate_Rd;
               // }
               // if (wrkRate == Rate53) reset_max_time();
                Read_lbc(DataBuff, Frame, Ifp);
                Coder(DataBuff, Line,
					&(CodData->wrkRate),
					CodData->useHp,
					CodData->useVx,
					CodData->CodCng ,
					CodData->CodStat,
					CodData->VadStat,
					&(CodData->extra) );
                Decod(DataBuff, Line, (Word16) 0,
					&(DecData->wrkRate),
					DecData->usePf,
					DecData->DecStat,
					DecData->DecCng);
                Write_lbc(DataBuff, Frame, Ofp);



				//Line_Wr(Line, Ofp);
              //  break;
/*
            case Cod :
                if (Ratp != NULL) {
                    fread((char *)&Rate_Rd, sizeof(char), 1, Ratp);
                    wrkRate = (enum Crate)Rate_Rd;
                }
                if (wrkRate == Rate53) reset_max_time();
                Read_lbc(DataBuff, Frame, Ifp);
                Coder(DataBuff, Line);
                Line_Wr(Line, Ofp);
                break;

            case Dec :
                if (Line_Rd(Line, Ifp) == (-1)) {
                    FlLen = FrCnt;
                    break;
                }
                if (Fep == NULL)
                    Crc = (Word16) 0;
                else
                    fread((char*)&Crc, sizeof(Word16), 1, Fep);
                Decod(DataBuff, Line, Crc);
                Write_lbc(DataBuff, Frame, Ofp);
                break;
        }*/

        FrCnt ++;

        if (ReinitSize > 0 && (FrCnt % ReinitSize) == 0) {
            Init_Coder(CodData);
            Init_Decod(DecData);
            if (CodData->useVx) {
                Init_Vad(CodData);
                Init_Cod_Cng(CodData);
            }
            Init_Dec_Cng(DecData);
			}

       /* if( 0) {
            if (WrkMode == Dec) {
                if (FrCnt < FlLen) {
                    fprintf( stdout, "Done : %6ld\r", FrCnt) ;
                }
            }
            else {
                fprintf(stdout, "Done : %6ld %3ld\r", FrCnt,
                                  FlLen ? FrCnt*100/FlLen : 0);
            }
            fflush(stdout);
			}*/
    }
    while (FrCnt < FlLen);

ENCODE_HANDLE_free(CodData);
DECODE_HANDLE_free(DecData);
/*    if (UsePr)
        fprintf(stdout,"\n");*/

    if(Ifp) { (void) fclose(Ifp); }
    if(Ofp) { (void) fclose(Ofp); }
 //   if(Fep) { (void) fclose(Fep); }
 //   if(Ratp) { (void) fclose(Ratp); }
    return 0;
}


/*
    This function processes the argument parameters. The function
      opens the IO files, and sets the global arguments accordingly
      to the command line parameters.
*/

/*
long  Process_Files(FILE **Ifp, FILE **Ofp,  FILE **Fep, FILE **Ratp,
                    int Argc, char *Argv[])
{
    int   i;
    long  Flen;
    char  *FerFileName = NULL;
    char  *RateFileName = NULL;

/* Process the argument list, if any */

  /*  if (Argc < 3) {
        printf("Usage: %s [options] inputfile outputfile\n", Argv[0]);
        exit(1);
    }

    for (i=1; i < Argc-2; i++) {

        /* Check the coder rate *//*
        if ( ! strncmp( "-r", Argv[i], 2) ) {
            if ( ! strcmp("63", Argv[i]+2) ) {
                wrkRate = Rate63 ;
                continue ;
            }

            else if ( ! strcmp("53", Argv[i]+2) ) {
                wrkRate = Rate53 ;
                continue ;
            }

            else {
                RateFileName = &Argv[i][2] ;
                continue ;
            }
        }

        if (!strcmp("-b", Argv[i])) {
            WrkMode = Both;
            continue;
        }

        if (!strcmp("-c", Argv[i])) {
            WrkMode = Cod;
            continue;
        }

        if (!strcmp("-d", Argv[i])) {
            WrkMode = Dec;
            continue;
        }

        if ( ! strcmp("-v", Argv[i]) ) {
            useVx = True ;
            continue ;
        }

        if (!strcmp("-Noh", Argv[i])) {
            useHp = False;
            continue;
        }

        if (!strcmp("-Nop", Argv[i])) {
            usePf = False;
            continue;
        }

        if ( ! strncmp( "-f", Argv[i], 2) ) {
            FerFileName = &Argv[i][2] ;
            continue ;
        }

        if ( ! strcmp("-n", Argv[i]) ) {
            UsePr = False;
            continue ;
        }

        if ( ! strncmp( "-R", Argv[i], 2) ) {
            ReinitSize = (int) strtol(&Argv[i][2], NULL, 0);
            continue ;
        }

        fprintf(stderr, "Illegal argument, %s\n", Argv[i]);
        exit(1);
    }

/*  Open I/O files  *//*

    *Ifp = fopen(Argv[Argc-2], "rb");
    if (*Ifp == NULL) {
        fprintf(stderr, "Invalid input file name: %s\n", Argv[Argc-2]);
        exit(1);
    }
    if ( UsePr )
        printf("Input file:    %s\n", Argv[Argc-2]);

    *Ofp = fopen(Argv[Argc-1], "wb");
    if (*Ofp == NULL) {
        fprintf(stderr, "Can't open output file: %s\n", Argv[Argc-1]);
        exit(1);
    }
    if ( UsePr )
        printf("Output file:    %s\n", Argv[Argc-1]);

    /* Open Fer file if requiered */
  /*  if ( WrkMode == Dec ) {

        if ( FerFileName != NULL ) {
            *Fep = fopen( FerFileName, "rb" ) ;
            if ( *Fep == NULL ) {
                fprintf(stderr, "Can't open FER file: %s\n", FerFileName ) ;
                exit(1) ;
            }
            if ( UsePr )
                printf("FER    file:     %s\n", FerFileName ) ;
        }
    }
    else {
        if ( RateFileName != NULL ) {
            *Ratp = fopen( RateFileName, "rb" ) ;
            if ( *Ratp == NULL ) {
                fprintf(stderr, "Can't open Rate file: %s\n", RateFileName ) ;
                exit(1) ;
            }
            if ( UsePr )
                printf("Rate   file:     %s\n", RateFileName ) ;
        }
    }

    /* Options report */
  /*  if ( UsePr ) {

        printf("Options:\n");
        if (WrkMode == Both)
            printf("Encoder/Decoder\n");
        else if (WrkMode == Cod)
            printf("Encoder\n");
        else
            printf("Decoder\n");

        if( WrkMode != Cod) {
            if(DecData->usePf == 0)
                printf("Postfilter disabled\n");
            else
                printf("Postfilter enabled\n");
        }

        if (WrkMode <= Cod) {
            if (*Ratp == NULL) {
                if (wrkRate == Rate63)
                    printf("Rate 6.3 kb/s\n");
                else
                    printf("Rate 5.3 kb/s\n");
            }
            if (useHp == 0)
                printf("Highpassfilter disabled\n");
            else
                printf("Highpassfilter enabled\n");
            if (useVx == 0)
                printf("VAD/CNG disabled\n");
            else
                printf("VAD/CNG enabled\n");
        }
    }

    /*  Compute the file length  */

 /*   fseek(*Ifp, 0L, SEEK_END);
    Flen = ftell(*Ifp);
    rewind(*Ifp);
    if (WrkMode == Dec)
        Flen = 0x7fffffffL ;
    else
        Flen /= sizeof(Word16)*Frame ;

    return Flen;
}*/
