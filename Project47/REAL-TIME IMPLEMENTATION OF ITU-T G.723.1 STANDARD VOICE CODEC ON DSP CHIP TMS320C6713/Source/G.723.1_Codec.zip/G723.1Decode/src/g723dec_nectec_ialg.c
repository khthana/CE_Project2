/*
//============================================================================
//
//    FILE NAME : G723DEC_NECTEC_ialg.c
//
//    ALGORITHM : G723DEC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the G723DEC_NECTEC.h interface; NECTEC's
//                implementation of the IG723DEC interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Fri - 18 February 2005
//    Creation Time: 09:25 PM
//
//============================================================================
*/

#pragma CODE_SECTION(G723DEC_NECTEC_alloc,      ".text:algrfAlloc")
#pragma CODE_SECTION(G723DEC_NECTEC_free,       ".text:algrfFree")
#pragma CODE_SECTION(G723DEC_NECTEC_initObj,    ".text:algrfInit")
#pragma CODE_SECTION(G723DEC_NECTEC_control,    ".text:algrfControl")
#pragma CODE_SECTION(G723DEC_NECTEC_init,       ".text:init")
#pragma CODE_SECTION(G723DEC_NECTEC_exit,       ".text:exit")
#pragma CODE_SECTION(G723DEC_NECTEC_numAlloc,   ".text:algrfNumAlloc")
#pragma CODE_SECTION(G723DEC_NECTEC_moved,      ".text:algrfMoved")
#pragma CODE_SECTION(G723DEC_NECTEC_activate,   ".text:algrfActivate")
#pragma CODE_SECTION(G723DEC_NECTEC_deactivate, ".text:algrfDeactivate")

#include <std.h>
#include <limits.h>
#include "ig723dec.h"
#include "g723dec_nectec.h"
#include "cst2.h"
#include "tab2.h"
#include "decod2.h"

#define W_DECSTAT 1
#define W_DECCNG 2
#define H_DECSTAT 3
#define H_DECCNG 4
#define MTAB_NRECS 5
#define W_DECSTAT_SIZE 1
#define W_DECCNG_SIZE 1
#define H_DECSTAT_SIZE 1
#define H_DECCNG_SIZE 1

/*
//============================================================================
// G723DEC_NECTEC_Obj
*/
typedef struct G723DEC_NECTEC_Obj {
    IALG_Obj        alg;   /* MUST be first field of all G723DEC objs */
    XDAS_UInt32     framesizeIn0;
    XDAS_UInt32     framesizeOut0;
    XDAS_Bool       usePf;
    XDAS_Bool       rate63;
    DECSTATDEF      *w_DecStat;
    DECCNGDEF      *w_DecCng;
    DECSTATDEF      *h_DecStat;
    DECCNGDEF      *h_DecCng;

    /* TODO: add custom fields here */
} G723DEC_NECTEC_Obj;

/*
//============================================================================
// G723DEC_NECTEC_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the G723DEC_NECTEC processing methods.
*/
Void G723DEC_NECTEC_activate(IALG_Handle handle)
{
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;
    
    // TODO: implement algActivate
    // TODO: Initialize any important scratch memory values to G723DEC->w_DecStat.
    memcpy((Void *)G723DEC->w_DecStat  , (Void *)G723DEC->h_DecStat  ,
	sizeof(DECSTATDEF));
    // TODO: Initialize any important scratch memory values to G723DEC->w_DecCng.
    memcpy((Void *)G723DEC->w_DecCng  , (Void *)G723DEC->h_DecCng  ,
	sizeof(DECCNGDEF));
}

/*
//============================================================================
// G723DEC_NECTEC_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a G723DEC_NECTEC_Obj structure.
*/
Int G723DEC_NECTEC_alloc(const IALG_Params *G723DECParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IG723DEC_Params *params = (Void *)G723DECParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IG723DEC_PARAMS;  /* set default parameters */
    }

    /* Request memory for G723DEC object */
    memTab[0].size = sizeof(G723DEC_NECTEC_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;

    // NOTE: Some algorithms may be better suited to use an equation to define memtab
    //       size(s). User may want to modify the size field as required by his algorithm.

    /* Request memory for w_DecStat array */
    memTab[W_DECSTAT].size = (W_DECSTAT_SIZE) * sizeof(DECSTATDEF);
    memTab[W_DECSTAT].alignment = (0 * 8) / CHAR_BIT;
    memTab[W_DECSTAT].space = IALG_DARAM0;
    memTab[W_DECSTAT].attrs = IALG_SCRATCH;

    /* Request memory for w_DecCng array */
    memTab[W_DECCNG].size = (W_DECCNG_SIZE) * sizeof(DECCNGDEF);
    memTab[W_DECCNG].alignment = (0 * 8) / CHAR_BIT;
    memTab[W_DECCNG].space = IALG_DARAM0;
    memTab[W_DECCNG].attrs = IALG_SCRATCH;

    /* Request memory for h_DecStat array */
    memTab[H_DECSTAT].size = (H_DECSTAT_SIZE) * sizeof(DECSTATDEF);
    memTab[H_DECSTAT].alignment = (0 * 8) / CHAR_BIT;
    memTab[H_DECSTAT].space = IALG_EXTERNAL;
    memTab[H_DECSTAT].attrs = IALG_PERSIST;

    /* Request memory for h_DecCng array */
    memTab[H_DECCNG].size = (H_DECCNG_SIZE) * sizeof(DECCNGDEF);
    memTab[H_DECCNG].alignment = (0 * 8) / CHAR_BIT;
    memTab[H_DECCNG].space = IALG_EXTERNAL;
    memTab[H_DECCNG].attrs = IALG_PERSIST;

    return (MTAB_NRECS);
}

/*
//============================================================================
// G723DEC_NECTEC_control
//
// Control our object's parameters while the algorithm is running
*/
Int G723DEC_NECTEC_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    IG723DEC_Status *sPtr = (IG723DEC_Status *)status;	
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;

    switch ((IG723DEC_Cmd)cmd) {

       case IG723DEC_GETSTATUS:
            sPtr->usePf = G723DEC->usePf;
            sPtr->rate63 = G723DEC->rate63;

            return(IALG_EOK);

       case IG723DEC_SETSTATUS:
            G723DEC->usePf = sPtr->usePf;
            G723DEC->rate63 = sPtr->rate63;

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// G723DEC_NECTEC_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the G723DEC_NECTEC processing methods to persistent memory.
*/
Void G723DEC_NECTEC_deactivate(IALG_Handle handle)
{
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;
    
    // TODO: implement algDeactivate
    // TODO: Save any important scratch memory values from G723DEC->w_DecStat 
    //       to persistant memory.
    memcpy((Void *)G723DEC->h_DecStat  , (Void *)G723DEC->w_DecStat  ,
	sizeof(DECSTATDEF));
    // TODO: Save any important scratch memory values from G723DEC->w_DecCng 
    //       to persistant memory.
    memcpy((Void *)G723DEC->h_DecCng  , (Void *)G723DEC->w_DecCng  ,
	sizeof(DECCNGDEF));
}

/*
//============================================================================
// G723DEC_NECTEC_exit
//
// Exit the G723DEC_NECTEC module as a whole.
 */
Void G723DEC_NECTEC_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// G723DEC_NECTEC_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// G723DEC_NECTEC_alloc operation above.
*/
Int G723DEC_NECTEC_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;

    n = G723DEC_NECTEC_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[W_DECSTAT].base = G723DEC->w_DecStat;
    memTab[W_DECCNG].base = G723DEC->w_DecCng;
    memTab[H_DECSTAT].base = G723DEC->h_DecStat;
    memTab[H_DECCNG].base = G723DEC->h_DecCng;

    return (n);
}

/*
//============================================================================
// G723DEC_NECTEC_init
//
// Initialize the G723DEC_NECTEC module as a whole.
*/
Void G723DEC_NECTEC_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// G723DEC_NECTEC_initObj
//
// Initialize the memory allocated for our instance.
*/
Int G723DEC_NECTEC_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *G723DECParams)
{
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;
    const IG723DEC_Params *params = (Void *)G723DECParams;

    if(params == NULL){
        params = &IG723DEC_PARAMS; /* set default parameters */
    }

    G723DEC->framesizeIn0 = params->framesizeIn0;
    G723DEC->framesizeOut0 = params->framesizeOut0;
    G723DEC->usePf = params->usePf;
    G723DEC->rate63 = params->rate63;
    G723DEC->w_DecStat = memTab[W_DECSTAT].base;
    G723DEC->w_DecCng = memTab[W_DECCNG].base;
    G723DEC->h_DecStat = memTab[H_DECSTAT].base;
    G723DEC->h_DecCng = memTab[H_DECCNG].base;

    /* TODO: Implement any additional algInit desired */
    
    Table_ptr = &table;
    Init_Decod(G723DEC->w_DecStat);
    Init_Decod(G723DEC->h_DecStat);
    Init_Dec_Cng(G723DEC->w_DecCng);
    Init_Dec_Cng(G723DEC->h_DecCng);
    
    
    return (IALG_EOK);
}

/*
//============================================================================
// G723DEC_NECTEC_moved
//
// Adjust any data pointers that has been moved by the client.
*/
Void G723DEC_NECTEC_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *G723DECParams)
{
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;
    const IG723DEC_Params *params = (Void *)G723DECParams;

    G723DEC->w_DecStat = memTab[W_DECSTAT].base;
    G723DEC->w_DecCng = memTab[W_DECCNG].base;
    G723DEC->h_DecStat = memTab[H_DECSTAT].base;
    G723DEC->h_DecCng = memTab[H_DECCNG].base;
}

/*
//============================================================================
// G723DEC_NECTEC_numAlloc
//
// Returns the maximum number of memory allocation requests that the 
// G723DEC_NECTEC_alloc method requires.
*/
Int G723DEC_NECTEC_numAlloc(Void)
{
    return(MTAB_NRECS);
}

/*
//============================================================================
// G723DEC_NECTEC_decode
// NECTEC's implementation of the decode operation.
// Custom fields of the G723DEC_NECTEC_Obj may be accessed as follows:
//     G723DEC->framesizeIn0 = ...;
//     G723DEC->framesizeOut0 = ...;
//     G723DEC->usePf = ...;
//     G723DEC->wrkRate = ...;
//     G723DEC->w_DecStat = ...;
//     G723DEC->w_DecCng = ...;
//     G723DEC->h_DecStat = ...;
//     G723DEC->h_DecCng = ...;
*/
XDAS_Void G723DEC_NECTEC_decode(IG723DEC_Handle handle, XDAS_Int8 * ptrIn, XDAS_Int16 * ptrOut)
{
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;

    /* TODO: implement decode */
    enum Crate wrkRate;
    int i;
    FLOAT DataBuff[240];
    if (G723DEC->rate63)
    	wrkRate = Rate63;
    else
    	wrkRate = Rate53;
    for (i = 0; i<24;i++ ) G723DEC->w_DecStat->Line[i] = (char)ptrIn[i];
    
    
    
    Decod(DataBuff, 
    	  G723DEC->w_DecStat->Line, 
    	  0,
    	  &(wrkRate),
    	  G723DEC->usePf,
    	  G723DEC->w_DecStat,
    	  G723DEC->w_DecCng);
    	  
   	Write_lbc(DataBuff, 240, ptrOut);

    /*
    int index;
    for(index=0; index<G723DEC->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

/*
//============================================================================
// G723DEC_NECTEC_inframesize
// NECTEC's implementation of the inframesize operation.
// Custom fields of the G723DEC_NECTEC_Obj may be accessed as follows:
//     G723DEC->framesizeIn0 = ...;
//     G723DEC->framesizeOut0 = ...;
//     G723DEC->usePf = ...;
//     G723DEC->wrkRate = ...;
//     G723DEC->w_DecStat = ...;
//     G723DEC->w_DecCng = ...;
//     G723DEC->h_DecStat = ...;
//     G723DEC->h_DecCng = ...;
*/
XDAS_Void G723DEC_NECTEC_inframesize(IG723DEC_Handle handle, XDAS_Int8 * ptrIn, XDAS_UInt32 * size)
{
    G723DEC_NECTEC_Obj *G723DEC = (Void *)handle;

    /* TODO: implement inframesize */
    
    Line_Rd(ptrIn, size);
    
    

    /*
    int index;
    for(index=0; index<G723DEC->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}
