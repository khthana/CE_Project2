#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "cst2.h"
#include "typedef2.h"

CODSTATDEF_HANDLE CODSTATDEF_HANDLE_new() {
	return (CODSTATDEF *)malloc(sizeof(CODSTATDEF));
	}
void CODSTATDEF_HANDLE_free(CODSTATDEF_HANDLE CODSTATDEF_handle) {
	free(CODSTATDEF_handle);
	}

DECSTATDEF_HANDLE DECSTATDEF_HANDLE_new(){
	return (DECSTATDEF *)malloc(sizeof(DECSTATDEF));
	}
void DECSTATDEF_HANDLE_free(DECSTATDEF_HANDLE DECSTATDEF_handle){
	free(DECSTATDEF_handle);
	}


SFSDEF_HANDLE SFSDEF_HANDLE_new(){
	return (SFSDEF *)malloc(sizeof(SFSDEF));
	}
void SFSDEF_HANDLE_free(SFSDEF_HANDLE SFSDEF_handle){
	free(SFSDEF_handle);
	}
	
/*
LINEDEF_HANDLE LINEDEF_HANDLE_new(){
	int i=0;
	LINEDEF_HANDLE LINEDEF_handle;
	LINEDEF_handle = (LINEDEF *)malloc(sizeof(LINEDEF));
	for (i=0;i<SubFrames;i++)
		LINEDEF_handle->Sfs[1] = SFSDEF_HANDLE_new();
	return LINEDEF_handle;
	}
void LINEDEF_HANDLE_free(LINEDEF_HANDLE LINEDEF_handle){
	int i=0;
		for (i=0;i<SubFrames;i++)
			free(LINEDEF_handle->Sfs[i]);
	free(LINEDEF_handle);
	}*/

PWDEF_HANDLE PWDEF_HANDLE_new(){
	return (PWDEF *)malloc(sizeof(PWDEF));
	}
void PWDEF_HANDLE_free(PWDEF_HANDLE PWDEF_handle){
	free(PWDEF_handle);
	}

PFDEF_HANDLE PFDEF_HANDLE_new(){
	return (PFDEF *)malloc(sizeof(PFDEF));
	}
void PFDEF_HANDLE_free(PFDEF_HANDLE PFDEF_handle){
	free(PFDEF_handle);
	}

BESTDEF_HANDLE BESTDEF_HANDLE_new(){
	return (BESTDEF *)malloc(sizeof(BESTDEF));
	}
void BESTDEF_HANDLE_free(BESTDEF_HANDLE BESTDEF_handle){
	free(BESTDEF_handle);
	}

VADSTATDEF_HANDLE VADSTATDEF_HANDLE_new(){
	return (VADSTATDEF *)malloc(sizeof(VADSTATDEF));
	}
void VADSTATDEF_HANDLE_free(VADSTATDEF_HANDLE VADSTATDEF_handle){
	free(VADSTATDEF_handle);
	}



CODCNGDEF_HANDLE CODCNGDEF_HANDLE_new(){
	return (CODCNGDEF *)malloc(sizeof(CODCNGDEF));
	}
void CODCNGDEF_HANDLE_free(CODCNGDEF_HANDLE CODCNGDEF_handle){
	free(CODCNGDEF_handle);
	}

DECCNGDEF_HANDLE DECCNGDEF_HANDLE_new(){
	return (DECCNGDEF *)malloc(sizeof(DECCNGDEF));
	}
void DECCNGDEF_HANDLE_free(DECCNGDEF_HANDLE DECCNGDEF_handle){
	free(DECCNGDEF_handle);
	}



ENCODE_HANDLE ENCODE_HANDLE_new(){
	ENCODE_HANDLE hmem;
	hmem = (CODCNTXTDEF *)malloc(sizeof(CODCNTXTDEF));

	hmem->CodStat = CODSTATDEF_HANDLE_new();
	hmem->VadStat = VADSTATDEF_HANDLE_new();
	hmem->CodCng = CODCNGDEF_HANDLE_new();
	
	return hmem;
	}
void ENCODE_HANDLE_free(ENCODE_HANDLE ENCODE_handle){
	
	CODSTATDEF_HANDLE_free(ENCODE_handle->CodStat );
	VADSTATDEF_HANDLE_free(ENCODE_handle->VadStat );
	CODCNGDEF_HANDLE_free(ENCODE_handle->CodCng );
	free(ENCODE_handle);
	}

DECODE_HANDLE DECODE_HANDLE_new(){
	DECODE_HANDLE hmem;
	hmem = (DECCNTXTDEF *)malloc(sizeof(DECCNTXTDEF));
	hmem->DecStat = DECSTATDEF_HANDLE_new();
	hmem->DecCng = DECCNGDEF_HANDLE_new();

	return hmem;
	}

void DECODE_HANDLE_free(DECODE_HANDLE DECODE_handle){
	DECSTATDEF_HANDLE_new(DECODE_handle->DecStat );
	DECCNGDEF_HANDLE_new(DECODE_handle->DecCng );
	free(DECODE_handle);
	}


	

