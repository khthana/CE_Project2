/*
//============================================================================
//
//    FILE NAME : G723DEC_NECTEC_ialgvt.c
//
//    ALGORITHM : G723DEC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the G723DEC_NECTEC module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Fri - 18 February 2005
//    Creation Time: 09:25 PM
//
//============================================================================
*/

#include <std.h>
#include "ig723dec.h"

#include "g723dec_nectec.h"

extern Int  G723DEC_NECTEC_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  G723DEC_NECTEC_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  G723DEC_NECTEC_free(IALG_Handle, IALG_MemRec *);
extern Int  G723DEC_NECTEC_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  G723DEC_NECTEC_numAlloc(Void);
extern Void G723DEC_NECTEC_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Void G723DEC_NECTEC_activate(IALG_Handle);
extern Void G723DEC_NECTEC_deactivate(IALG_Handle);
extern XDAS_Void G723DEC_NECTEC_decode(IG723DEC_Handle handle, XDAS_Int8 * ptrIn, XDAS_Int16 * ptrOut);
extern XDAS_Void G723DEC_NECTEC_inframesize(IG723DEC_Handle handle, XDAS_Int8 * ptrIn, XDAS_UInt32 * size);

#define IALGFXNS \
    &G723DEC_NECTEC_IALG,       /* module ID                            */ \
    G723DEC_NECTEC_activate,       /* activate   (NULL => not suported)    */ \
    G723DEC_NECTEC_alloc,       /* algAlloc                             */ \
    G723DEC_NECTEC_control,     /* control    (NULL => not suported)    */ \
    G723DEC_NECTEC_deactivate,  /* deactivate (NULL => not suported)    */ \
    G723DEC_NECTEC_free,        /* free                                 */ \
    G723DEC_NECTEC_initObj,     /* init                                 */ \
    G723DEC_NECTEC_moved,       /* moved      (NULL => not suported)    */ \
    G723DEC_NECTEC_numAlloc     /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// G723DEC_NECTEC_IG723DEC
//
// This structure defines NECTEC's implementation of the IG723DEC interface
// for the G723DEC_NECTEC module.
*/
IG723DEC_Fxns G723DEC_NECTEC_IG723DEC = {	/* module_vendor_interface */
    IALGFXNS,
    G723DEC_NECTEC_decode,
    G723DEC_NECTEC_inframesize,
};

/*
//============================================================================
// G723DEC_NECTEC_IALG
//
// This structure defines NECTEC's implementation of the IALG interface
// for the G723DEC_NECTEC module.
*/
#ifdef _TI_
asm("_G723DEC_NECTEC_IALG .set _G723DEC_NECTEC_IG723DEC");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns G723DEC_NECTEC_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
