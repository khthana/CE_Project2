/*
//============================================================================
//
//    FILE NAME : IG723DEC.c
//
//    ALGORITHM : G723DEC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iG723DEC.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Fri - 18 February 2005
//    Creation Time: 09:25 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "ig723dec.h"
#include "cst2.h"

/*
// ===========================================================================
// G723DEC_PARAMS
//
// This constant structure defines the default parameters for G723DEC objects
*/
IG723DEC_Params IG723DEC_PARAMS = {
    sizeof(IG723DEC_Params),
    24, /* unsigned int  framesizeIn0 */
    240, /* unsigned int  framesizeOut0 */
    1, /* usePf */
    Rate63, /* wrkRate */
};
