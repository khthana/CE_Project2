/*
//============================================================================
//
//    FILE NAME : G723DEC.c
//
//    ALGORITHM : G723DEC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in G723DEC.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Fri - 18 February 2005
//    Creation Time: 09:25 PM
//
//============================================================================
*/

#pragma CODE_SECTION(G723DEC_create,  ".text:create")
#pragma CODE_SECTION(G723DEC_control, ".text:control")
#pragma CODE_SECTION(G723DEC_delete,  ".text:delete")
#pragma CODE_SECTION(G723DEC_init,    ".text:init")
#pragma CODE_SECTION(G723DEC_exit,    ".text:exit")

#include <std.h>
#include <algrf.h>
#include <xdas.h>
#include "g723dec.h"

/*
// ===========================================================================
// G723DEC_create
//
//  Create an G723DEC instance object (using parameters specified by prms)
*/
G723DEC_Handle G723DEC_create(const IG723DEC_Fxns *fxns, const G723DEC_Params *prms)
{
    return ((G723DEC_Handle)ALGRF_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// G723DEC_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int G723DEC_control(G723DEC_Handle handle, G723DEC_Cmd cmd, G723DEC_Status *status)
{
    return (ALGRF_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// G723DEC_delete
//
// Delete the G723DEC instance object specified by handle
*/
Void G723DEC_delete(G723DEC_Handle handle)
{
    ALGRF_delete((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// G723DEC_init
//
// G723DEC module initialization
*/
Void  G723DEC_init(Void)
{
}

/*
// ===========================================================================
// G723DEC_exit
//
// G723DEC module finalization
*/
Void  G723DEC_exit(Void)
{
}

/*
// ===========================================================================
// G723DEC_decode
*/
XDAS_Void G723DEC_decode(G723DEC_Handle handle, XDAS_Int8 * ptrIn, XDAS_Int16 * ptrOut)
{
    ALGRF_activate((ALGRF_Handle)handle);

    handle->fxns->decode(handle, ptrIn, ptrOut);

    ALGRF_deactivate((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// G723DEC_inframesize
*/
XDAS_Void G723DEC_inframesize(G723DEC_Handle handle, XDAS_Int8 * ptrIn, XDAS_UInt32 * size)
{
    ALGRF_activate((ALGRF_Handle)handle);

    handle->fxns->inframesize(handle, ptrIn, size);

    ALGRF_deactivate((ALGRF_Handle)handle);
}
