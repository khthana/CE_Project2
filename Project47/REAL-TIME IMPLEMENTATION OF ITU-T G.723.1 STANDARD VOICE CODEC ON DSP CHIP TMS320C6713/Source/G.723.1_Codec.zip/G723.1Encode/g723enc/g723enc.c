/*
//============================================================================
//
//    FILE NAME : G723ENC.c
//
//    ALGORITHM : G723ENC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file implements all methods defined in G723ENC.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Tue - 11 January 2005
//    Creation Time: 03:42 PM
//
//============================================================================
*/

#pragma CODE_SECTION(G723ENC_create,  ".text:create")
#pragma CODE_SECTION(G723ENC_control, ".text:control")
#pragma CODE_SECTION(G723ENC_delete,  ".text:delete")
#pragma CODE_SECTION(G723ENC_init,    ".text:init")
#pragma CODE_SECTION(G723ENC_exit,    ".text:exit")



/*
#include <log.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <clk.h>
#include <sts.h>
#include <trc.h>
#include <swi.h>
#include <hwi.h>
#include "G723ENCcfg.h"*/

#include <std.h>
#include <algrf.h>
#include <xdas.h>
#include "g723enc.h"

/*
// ===========================================================================
// G723ENC_create
//
//  Create an G723ENC instance object (using parameters specified by prms)
*/
G723ENC_Handle G723ENC_create(const IG723ENC_Fxns *fxns, const G723ENC_Params *prms)
{
    return ((G723ENC_Handle)ALGRF_create((IALG_Fxns *)fxns, NULL, (IALG_Params *)prms));
}

/*
// ===========================================================================
// G723ENC_control
//
// Function to either write to the read/write parameters in the status
// structure or to read all the parameters in the status structure.
*/
Int G723ENC_control(G723ENC_Handle handle, G723ENC_Cmd cmd, G723ENC_Status *status)
{
    return (ALGRF_control((IALG_Handle)handle, cmd, (IALG_Status *)status));
}

/*
// ===========================================================================
// G723ENC_delete
//
// Delete the G723ENC instance object specified by handle
*/
Void G723ENC_delete(G723ENC_Handle handle)
{
    ALGRF_delete((ALGRF_Handle)handle);
}

/*
// ===========================================================================
// G723ENC_init
//
// G723ENC module initialization
*/
Void  G723ENC_init(Void)
{
}

/*
// ===========================================================================
// G723ENC_exit
//
// G723ENC module finalization
*/
Void  G723ENC_exit(Void)
{
}

/*
// ===========================================================================
// G723ENC_encode
*/
XDAS_Void G723ENC_encode(G723ENC_Handle handle, XDAS_Int16 * ptrIn, XDAS_Int8 * ptrOut)
{
	//if (TRC_query(TRC_USER0) == 0) 
    //STS_set(&CODEC,CLK_gethtime());

    ALGRF_activate((ALGRF_Handle)handle);

    handle->fxns->encode(handle, ptrIn, ptrOut);

    ALGRF_deactivate((ALGRF_Handle)handle);
    
   // if (TRC_query(TRC_USER0) == 0) 
   // STS_delta(&CODEC,CLK_gethtime());
}

Void G723ENC_outframesize(G723ENC_Handle handle, XDAS_Int8 * ptrIn, XDAS_UInt32 *size)
{
	
	handle->fxns->outframesize(handle,ptrIn,size);
	
}
