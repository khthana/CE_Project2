/*
//============================================================================
//
//    FILE NAME : _G723ENC.c
//
//    BLOCK NAME: G723ENC
//
//    GROUP NAME: Default Group
//
//    PURPOSE   : Provides the real-time block's DSP C source code.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Block
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Tue - 11 January 2005
//    Creation Time: 03:42 PM
//
//============================================================================
*/

#include "_g723enc.h"

#pragma DATA_SECTION(Params, ".hyper:ignore")
PARAMS Params;

/*----------------------------------------------------------------------------*/
/*               Optional real-time block interrupt routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called in response to a selected  */
/* DSP interrupt.  If this routine in not activated, the main block routine   */
/* will be called in response to a selected DSP interrupt.                    */
/*----------------------------------------------------------------------------*/
/*
void G723ENC_INT(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*               Optional real-time block initialization routine              */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called one time before the main   */
/* application begins.  This allows for any required software or hardware     */
/* initialization to be performed before the block executes.                  */
/*----------------------------------------------------------------------------*/

static IG723ENC_Fxns   fxns;
static G723ENC_Params  params;

void G723ENC_INIT(PARAMS *pPtr)
{
    fxns = G723ENC_NECTEC_IG723ENC;
    params = G723ENC_PARAMS;

    params.framesizeIn0 = pPtr->FramesizeIn0;
    params.framesizeOut0 = pPtr->FramesizeOut0;
    params.useHp = pPtr->_useHp;
    params.useVx = pPtr->_useVx;
    params.rate63 = pPtr->_rate63;

    pPtr->handle = G723ENC_create(&fxns, &params);
}


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block stop routine                   */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever the block diagram */
/* worksheet's execution is stopped.  Blocks that deal with hardware may need */
/* this routine to stop the hardware's execution.                             */
/*----------------------------------------------------------------------------*/
/*
void G723ENC_STOP(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                    Optional real-time block restart routine                */
/*----------------------------------------------------------------------------*/
/* If this routine is activated, it will be called whenever a block diagram   */
/* worksheet is executed after being stopped.  Blocks that deal with hardware */
/* may need this routine to restart the hardware's execution.                 */
/*----------------------------------------------------------------------------*/
/*
void G723ENC_RESTART(PARAMS *pPtr)
{

}
*/


/*----------------------------------------------------------------------------*/
/*                           Real-time block routine                          */
/*----------------------------------------------------------------------------*/
/* This is the main block routine.  It is called during each loop of the main */
/* application.  If an interrupt is selected, and the interrupt routine above */
/* is not activated, this routine will be called in response to the selected  */
/* interrupt instead of during the main application loop.                     */
/* Custom fields of the pPtr structure may be accessed as follows:            */
/*     pPtr->FramesizeIn0 = ...;                                              */
/*     pPtr->FramesizeOut0 = ...;                                             */
/*     pPtr->_useHp = ...;                                                    */
/*     pPtr->_useVx = ...;                                                    */
/*     pPtr->_wrkRate = ...;                                                  */
/*----------------------------------------------------------------------------*/
void G723ENC(PARAMS *pPtr)
{
    if(pPtr->handle){
        if(pPtr->Changed){
            G723ENC_Status	status;

            pPtr->Changed = FALSE;
            status.useHp = pPtr->_useHp;
            status.useVx = pPtr->_useVx;
            status.rate63 = pPtr->_rate63;
            G723ENC_control(pPtr->handle, G723ENC_SETSTATUS, &status);
        }

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        //G723ENC_encode(pPtr->handle, (XDAS_Int16 *)pPtr->PtrIn0, (XDAS_Int8 *)pPtr->PtrOut0);
    }
}
