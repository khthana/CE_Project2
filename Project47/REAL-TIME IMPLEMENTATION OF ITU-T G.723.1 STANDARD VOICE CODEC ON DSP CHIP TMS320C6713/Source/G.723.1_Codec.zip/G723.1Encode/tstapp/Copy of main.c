



#include <std.h>
#include <stdio.h>
#include <stdlib.h>
#include "g723enc.h"
#include "g723enc_nectec.h"
//#include "cst2.h"
//#include "tab2.h"
#include "xdas.h"
#include "util2.h"
#include "tab2.h"
#include "cst2.h"



float PtrIn0[256];
float PtrOut0[256];

void main(){
    G723ENC_Handle  handle;
    IG723ENC_Fxns   fxns;
    G723ENC_Params  params;
    FILE  *Ifp, *Ofp; 
    XDAS_Int16 DataBuff[240];
    XDAS_Int8 Line[24];
    XDAS_UInt32 size;

    fxns = G723ENC_NECTEC_IG723ENC;
    params = G723ENC_PARAMS;

    params.framesizeIn0 = 240;
    params.framesizeOut0 = 256;
    params.table_ptr = &table;
    params.useHp = True;
    params.useVx = True;
    params.wrkRate = Rate53;
    
    Ifp = fopen("d:/tosend/input.pcm","rb");
	Ofp = fopen("d:/tosend/xdasout.out","wb");
    

    G723ENC_init();
    if((handle = G723ENC_create(&fxns, &params)) != NULL){
        /* Call the control function to modify parameters as the algorithm runs 
        G723ENC_Status  status;

        // get current status
        G723ENC_control(pPtr->handle, G723ENC_GETSTATUS, &status);

        // modify/check status parameters before setting the new status information
        G723ENC_control(pPtr->handle, G723ENC_SETSTATUS, &status);
        */

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        //G723ENC_encode(handle, (XDAS_Int16 *)PtrIn0, (XDAS_Int8 *)PtrOut0);
        
        while( fread((void *)DataBuff, sizeof(XDAS_Int16), 240, Ifp) == 240){
        	
        	G723ENC_encode( handle, DataBuff ,Line );
        	Line_Wr(Line,&size);
        	

        	
        	fwrite( (void *)Line, size, 1,  Ofp);
	    }
        
        
        
        
        G723ENC_delete(handle);
    }
    G723ENC_exit();
    
    fclose(Ifp);
    fclose(Ofp);
}

