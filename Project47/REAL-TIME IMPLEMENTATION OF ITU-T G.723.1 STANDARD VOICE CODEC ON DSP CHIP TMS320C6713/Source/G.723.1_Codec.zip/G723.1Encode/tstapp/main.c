#include <log.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <clk.h>
#include <sts.h>
#include <trc.h>
#include <swi.h>
#include <hwi.h>
#include "G723ENCcfg.h"





#include <std.h>
#include <stdio.h>
#include <stdlib.h>
#include "g723enc.h"
#include "g723enc_nectec.h"
//#include "cst2.h"
//#include "tab2.h"
#include "xdas.h"
//#include "util2.h"
//#include "tab2.h"
//#include "cst2.h"



float PtrIn0[256];
float PtrOut0[256];
extern int INTERNALHEAP;
extern int EXTERNALHEAP;


G723ENC_Handle  handle;
    IG723ENC_Fxns   fxns;
    G723ENC_Params  params;
    FILE  *Ifp, *Ofp; 
    XDAS_Int16 DataBuff[240];
    XDAS_Int8 Line[24];
    XDAS_UInt32 size;
    FILE  *Ifp, *Ofp; 

void main(){
    /*
    G723ENC_Handle  handle;
    IG723ENC_Fxns   fxns;
    G723ENC_Params  params;
    FILE  *Ifp, *Ofp; 
    XDAS_Int16 DataBuff[240];
    XDAS_Int8 Line[24];
    XDAS_UInt32 size;*/

    fxns = G723ENC_NECTEC_IG723ENC;
    params = G723ENC_PARAMS;

    params.framesizeIn0 = 240;
    params.framesizeOut0 = 256;
 //   params.table_ptr = &table;
    params.useHp = TRUE;
    params.useVx = TRUE;
    params.rate63 = FALSE;
    
    Ifp = fopen("d:/tosend/doyin.pcm","rb");
	Ofp = fopen("d:/tosend/dsptest.out","wb");
    

    G723ENC_init();
    ALGRF_setup(INTERNALHEAP,EXTERNALHEAP);
    
    
    //if((handle = G723ENC_create(&fxns, &params)) != NULL){
        /* Call the control function to modify parameters as the algorithm runs 
        G723ENC_Status  status;

        // get current status
        G723ENC_control(pPtr->handle, G723ENC_GETSTATUS, &status);

        // modify/check status parameters before setting the new status information
        G723ENC_control(pPtr->handle, G723ENC_SETSTATUS, &status);
        */

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        //G723ENC_encode(handle, (XDAS_Int16 *)PtrIn0, (XDAS_Int8 *)PtrOut0);
        
    /*    while( fread((void *)DataBuff, sizeof(XDAS_Int16), 240, Ifp) == 240){
        	
        	G723ENC_encode( handle, DataBuff ,Line );
        	Line_Wr(Line,&size);
        	

        	
        	fwrite( (void *)Line, size, 1,  Ofp);
	    }
        
        
        
        
        G723ENC_delete(handle);
    }
    G723ENC_exit();
    
    fclose(Ifp);
    fclose(Ofp);*/
}

void algorithm() {

	if((handle = G723ENC_create(&fxns, &params)) != NULL){
        /* Call the control function to modify parameters as the algorithm runs 
        G723ENC_Status  status;

        // get current status
        G723ENC_control(pPtr->handle, G723ENC_GETSTATUS, &status);

        // modify/check status parameters before setting the new status information
        G723ENC_control(pPtr->handle, G723ENC_SETSTATUS, &status);
        */

        /* Call XDAIS algorithm specific routine(s) */
        /* For example: */
        //G723ENC_encode(handle, (XDAS_Int16 *)PtrIn0, (XDAS_Int8 *)PtrOut0);
        
        while( fread((void *)DataBuff, sizeof(XDAS_Int16), 240, Ifp) == 240){
        
        	if (TRC_query(TRC_USER0) == 0) 
                STS_set(&CODEC,CLK_gethtime());
        	
        	G723ENC_encode( handle, DataBuff ,Line );
        	//Line_Wr(Line,&size);
        	
        	if (TRC_query(TRC_USER0) == 0) 
                STS_delta(&CODEC,CLK_gethtime());    
                
                
                if (TRC_query(TRC_USER0) == 0) 
                STS_set(&STS0,CLK_gethtime());
        	
                
            G723ENC_outframesize( handle,Line,&size);           
            
            if (TRC_query(TRC_USER0) == 0) 
                STS_delta(&STS0,CLK_gethtime());    
                

   
        	fwrite( (void *)Line, size, 1,  Ofp);
	    }
        
        
        
        
        G723ENC_delete(handle);
    }
    G723ENC_exit();
    
    fclose(Ifp);
    fclose(Ofp);









}

