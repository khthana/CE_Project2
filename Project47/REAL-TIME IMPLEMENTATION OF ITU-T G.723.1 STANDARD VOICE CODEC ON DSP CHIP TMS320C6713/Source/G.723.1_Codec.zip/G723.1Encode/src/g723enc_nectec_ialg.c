/*
//============================================================================
//
//    FILE NAME : G723ENC_NECTEC_ialg.c
//
//    ALGORITHM : G723ENC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : Implementation of the G723ENC_NECTEC.h interface; NECTEC's
//                implementation of the IG723ENC interface.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Tue - 11 January 2005
//    Creation Time: 03:42 PM
//
//============================================================================
*/

#pragma CODE_SECTION(G723ENC_NECTEC_alloc,      ".text:algrfAlloc")
#pragma CODE_SECTION(G723ENC_NECTEC_free,       ".text:algrfFree")
#pragma CODE_SECTION(G723ENC_NECTEC_initObj,    ".text:algrfInit")
#pragma CODE_SECTION(G723ENC_NECTEC_control,    ".text:algrfControl")
#pragma CODE_SECTION(G723ENC_NECTEC_init,       ".text:init")
#pragma CODE_SECTION(G723ENC_NECTEC_exit,       ".text:exit")
#pragma CODE_SECTION(G723ENC_NECTEC_numAlloc,   ".text:algrfNumAlloc")
#pragma CODE_SECTION(G723ENC_NECTEC_moved,      ".text:algrfMoved")
#pragma CODE_SECTION(G723ENC_NECTEC_activate,   ".text:algrfActivate")
#pragma CODE_SECTION(G723ENC_NECTEC_deactivate, ".text:algrfDeactivate")

#include <std.h>
#include <limits.h>
#include "ig723enc.h"
#include "g723enc_nectec.h"
#include "cst2.h"
#include "coder2.h"
#include "tab2.h"
#include "util2.h"

#define W_CODSTAT 1
#define W_VADSTAT 2
#define W_CODCNG 3
#define H_CODSTAT 4
#define H_VADSTAT 5
#define H_CODCNG 6
#define MTAB_NRECS 7
#define W_CODSTAT_SIZE 1
#define W_VADSTAT_SIZE 1
#define W_CODCNG_SIZE 1
#define H_CODSTAT_SIZE 1
#define H_VADSTAT_SIZE 1
#define H_CODCNG_SIZE 1

/*
//============================================================================
// G723ENC_NECTEC_Obj
*/
typedef struct G723ENC_NECTEC_Obj {
    IALG_Obj        alg;   /* MUST be first field of all G723ENC objs */
    XDAS_UInt32     framesizeIn0;
    XDAS_UInt32     framesizeOut0;
    XDAS_Bool       useHp;
    XDAS_Bool       useVx;
    XDAS_Bool       rate63;
    CODSTATDEF      *w_codstat;
    VADSTATDEF      *w_vadstat;
    CODCNGDEF       *w_codcng;
    CODSTATDEF      *h_codstat;
    VADSTATDEF      *h_vadstat;
    CODCNGDEF       *h_codcng;

    /* TODO: add custom fields here */
    int				extra;
} G723ENC_NECTEC_Obj;

/*
//============================================================================
// G723ENC_NECTEC_activate
//
// Activate our object; e.g., initialize any scratch memory required
// by the G723ENC_NECTEC processing methods.
*/
Void G723ENC_NECTEC_activate(IALG_Handle handle)
{
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;
    
    // TODO: implement algActivate
    // TODO: Initialize any important scratch memory values to G723ENC->w_codstat.
    memcpy((Void *)G723ENC->w_codstat  , (Void *)G723ENC->h_codstat  ,
	sizeof(CODSTATDEF));
    // TODO: Initialize any important scratch memory values to G723ENC->w_vadstat.
    memcpy((Void *)G723ENC->w_vadstat  , (Void *)G723ENC->h_vadstat  ,
	sizeof(VADSTATDEF));
    // TODO: Initialize any important scratch memory values to G723ENC->w_codcng.
    memcpy((Void *)G723ENC->w_codcng  , (Void *)G723ENC->h_codcng  ,
	sizeof(CODCNGDEF));
}

/*
//============================================================================
// G723ENC_NECTEC_alloc
//
// Return a table of memory descriptors that describe the memory needed 
// to construct a G723ENC_NECTEC_Obj structure.
*/
Int G723ENC_NECTEC_alloc(const IALG_Params *G723ENCParams, IALG_Fxns **fxns, IALG_MemRec memTab[])
{
    const IG723ENC_Params *params = (Void *)G723ENCParams;

    /* TODO: implement algAlloc */
    
    if (params == NULL) {
        params = &IG723ENC_PARAMS;  /* set default parameters */
    }

    /* Request memory for G723ENC object */
    memTab[0].size = sizeof(G723ENC_NECTEC_Obj);
    memTab[0].alignment = (0 * 8) / CHAR_BIT;
    memTab[0].space = IALG_DARAM0;
    memTab[0].attrs = IALG_PERSIST;

    // NOTE: Some algorithms may be better suited to use an equation to define memtab
    //       size(s). User may want to modify the size field as required by his algorithm.

    /* Request memory for w_codstat array */
    memTab[W_CODSTAT].size = (W_CODSTAT_SIZE) * sizeof(CODSTATDEF);
    memTab[W_CODSTAT].alignment = (0 * 8) / CHAR_BIT;
    memTab[W_CODSTAT].space = IALG_DARAM0;
    memTab[W_CODSTAT].attrs = IALG_SCRATCH;

    /* Request memory for w_vadstat array */
    memTab[W_VADSTAT].size = (W_VADSTAT_SIZE) * sizeof(VADSTATDEF);
    memTab[W_VADSTAT].alignment = (0 * 8) / CHAR_BIT;
    memTab[W_VADSTAT].space = IALG_DARAM0;
    memTab[W_VADSTAT].attrs = IALG_SCRATCH;

    /* Request memory for w_codcng array */
    memTab[W_CODCNG].size = (W_CODCNG_SIZE) * sizeof(CODCNGDEF);
    memTab[W_CODCNG].alignment = (0 * 8) / CHAR_BIT;
    memTab[W_CODCNG].space = IALG_DARAM0;
    memTab[W_CODCNG].attrs = IALG_SCRATCH;

    /* Request memory for h_codstat array */
    memTab[H_CODSTAT].size = (H_CODSTAT_SIZE) * sizeof(CODSTATDEF);
    memTab[H_CODSTAT].alignment = (0 * 8) / CHAR_BIT;
    memTab[H_CODSTAT].space = IALG_EXTERNAL;
    memTab[H_CODSTAT].attrs = IALG_PERSIST;

    /* Request memory for h_vadstat array */
    memTab[H_VADSTAT].size = (H_VADSTAT_SIZE) * sizeof(VADSTATDEF);
    memTab[H_VADSTAT].alignment = (0 * 8) / CHAR_BIT;
    memTab[H_VADSTAT].space = IALG_EXTERNAL;
    memTab[H_VADSTAT].attrs = IALG_PERSIST;

    /* Request memory for h_codcng array */
    memTab[H_CODCNG].size = (H_CODCNG_SIZE) * sizeof(CODCNGDEF);
    memTab[H_CODCNG].alignment = (0 * 8) / CHAR_BIT;
    memTab[H_CODCNG].space = IALG_EXTERNAL;
    memTab[H_CODCNG].attrs = IALG_PERSIST;

    return (MTAB_NRECS);
}

/*
//============================================================================
// G723ENC_NECTEC_control
//
// Control our object's parameters while the algorithm is running
*/
Int G723ENC_NECTEC_control(IALG_Handle handle, IALG_Cmd cmd, IALG_Status * status)
{
    IG723ENC_Status *sPtr = (IG723ENC_Status *)status;	
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;

    switch ((IG723ENC_Cmd)cmd) {

       case IG723ENC_GETSTATUS:
            sPtr->useHp = G723ENC->useHp;
            sPtr->useVx = G723ENC->useVx;
            sPtr->rate63 = G723ENC->rate63;

            return(IALG_EOK);

       case IG723ENC_SETSTATUS:
            G723ENC->useHp = sPtr->useHp;
            G723ENC->useVx = sPtr->useVx;
            G723ENC->rate63 = sPtr->rate63;

            return(IALG_EOK);

       default:  break;
    }
                       
    return(IALG_EFAIL);
}

/*
//============================================================================
// G723ENC_NECTEC_deactivate
//
// Deactivate our object; e.g., save any scratch memory requred
// by the G723ENC_NECTEC processing methods to persistent memory.
*/
Void G723ENC_NECTEC_deactivate(IALG_Handle handle)
{
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;
    
    // TODO: implement algDeactivate
    // TODO: Save any important scratch memory values from G723ENC->w_codstat 
    //       to persistant memory.
    memcpy((Void *)G723ENC->h_codstat , (Void *)G723ENC->w_codstat  ,
	sizeof(CODSTATDEF));
    // TODO: Save any important scratch memory values from G723ENC->w_vadstat 
    //       to persistant memory.
    memcpy((Void *)G723ENC->h_vadstat , (Void *)G723ENC->w_vadstat  ,
	sizeof(VADSTATDEF));
    // TODO: Save any important scratch memory values from G723ENC->w_codcng 
    //       to persistant memory.
    memcpy((Void *)G723ENC->h_codcng , (Void *)G723ENC->w_codcng  ,
	sizeof(CODCNGDEF));
}

/*
//============================================================================
// G723ENC_NECTEC_exit
//
// Exit the G723ENC_NECTEC module as a whole.
 */
Void G723ENC_NECTEC_exit(Void)
{
    /* TODO: implement module exit */
}

/*
//============================================================================
// G723ENC_NECTEC_free
//
// Return a table of memory pointers that should be freed.  Note
// that this should include *all* memory requested in the 
// G723ENC_NECTEC_alloc operation above.
*/
Int G723ENC_NECTEC_free(IALG_Handle handle, IALG_MemRec memTab[])
{
    Int n;
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;

    n = G723ENC_NECTEC_alloc(NULL, NULL, memTab);

    memTab[0].base = handle;
    memTab[W_CODSTAT].base = G723ENC->w_codstat;
    memTab[W_VADSTAT].base = G723ENC->w_vadstat;
    memTab[W_CODCNG].base = G723ENC->w_codcng;
    memTab[H_CODSTAT].base = G723ENC->h_codstat;
    memTab[H_VADSTAT].base = G723ENC->h_vadstat;
    memTab[H_CODCNG].base = G723ENC->h_codcng;

    return (n);
}

/*
//============================================================================
// G723ENC_NECTEC_init
//
// Initialize the G723ENC_NECTEC module as a whole.
*/
Void G723ENC_NECTEC_init(Void)
{
    /* TODO: implement module init */
}

/*
//============================================================================
// G723ENC_NECTEC_initObj
//
// Initialize the memory allocated for our instance.
*/
Int G723ENC_NECTEC_initObj(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *G723ENCParams)
{
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;
    const IG723ENC_Params *params = (Void *)G723ENCParams;

    if(params == NULL){
        params = &IG723ENC_PARAMS; /* set default parameters */
    }
    
    G723ENC->framesizeIn0 = params->framesizeIn0;
    G723ENC->framesizeOut0 = params->framesizeOut0;
    G723ENC->useHp = params->useHp;
    G723ENC->useVx = params->useVx;
    G723ENC->rate63 = params->rate63;
    G723ENC->w_codstat = memTab[W_CODSTAT].base;
    G723ENC->w_vadstat = memTab[W_VADSTAT].base;
    G723ENC->w_codcng = memTab[W_CODCNG].base;
    G723ENC->h_codstat = memTab[H_CODSTAT].base;
    G723ENC->h_vadstat = memTab[H_VADSTAT].base;
    G723ENC->h_codcng = memTab[H_CODCNG].base;

    /* TODO: Implement any additional algInit desired */
    
    Table_ptr = &table;
    
    G723ENC->extra = 1;
    Init_Coder(G723ENC->w_codstat);
    Init_Vad(G723ENC->w_vadstat);
    Init_Cod_Cng(G723ENC->w_codcng);
    Init_Coder(G723ENC->h_codstat);
    Init_Vad(G723ENC->h_vadstat);
    Init_Cod_Cng(G723ENC->h_codcng);
    
    return (IALG_EOK);
}

/*
//============================================================================
// G723ENC_NECTEC_moved
//
// Adjust any data pointers that has been moved by the client.
*/
Void G723ENC_NECTEC_moved(IALG_Handle handle,
		const IALG_MemRec memTab[], IALG_Handle p, const IALG_Params *G723ENCParams)
{
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;
    const IG723ENC_Params *params = (Void *)G723ENCParams;

    G723ENC->w_codstat = memTab[W_CODSTAT].base;
    G723ENC->w_vadstat = memTab[W_VADSTAT].base;
    G723ENC->w_codcng = memTab[W_CODCNG].base;
    G723ENC->h_codstat = memTab[H_CODSTAT].base;
    G723ENC->h_vadstat = memTab[H_VADSTAT].base;
    G723ENC->h_codcng = memTab[H_CODCNG].base;
}

/*
//============================================================================
// G723ENC_NECTEC_numAlloc
//
// Returns the maximum number of memory allocation requests that the 
// G723ENC_NECTEC_alloc method requires.
*/
Int G723ENC_NECTEC_numAlloc(Void)
{
    return(MTAB_NRECS);
}

/*
//============================================================================
// G723ENC_NECTEC_encode
// NECTEC's implementation of the encode operation.
// Custom fields of the G723ENC_NECTEC_Obj may be accessed as follows:
//     G723ENC->framesizeIn0 = ...;
//     G723ENC->framesizeOut0 = ...;
//     G723ENC->useHp = ...;
//     G723ENC->useVx = ...;
//     G723ENC->wrkRate = ...;
//     G723ENC->w_codstat = ...;
//     G723ENC->w_vadstat = ...;
//     G723ENC->w_codcng = ...;
//     G723ENC->h_codstat = ...;
//     G723ENC->h_vadstat = ...;
//     G723ENC->h_codcng = ...;
*/
XDAS_Void G723ENC_NECTEC_encode(IG723ENC_Handle handle, XDAS_Int16 * ptrIn, XDAS_Int8 * ptrOut)
{
    G723ENC_NECTEC_Obj *G723ENC = (Void *)handle;

    /* TODO: implement encode */
    
    
	 //float DataBuff[240];
    int i;
    enum Crate wrkRate;
    if (G723ENC->rate63)
    	wrkRate = Rate63;
    else
    	wrkRate = Rate53;

    /* TODO: implement encode */
    for (i = 0; i < Frame; i++ ) G723ENC->w_codstat->DataBuff[i] = (float)ptrIn[i];
    
    Coder(G723ENC->w_codstat->DataBuff, 
			ptrOut,
			&(wrkRate),
			G723ENC->useHp,
			G723ENC->useVx,
			G723ENC->w_codcng,
			G723ENC->w_codstat,
			G723ENC->w_vadstat,
			&(G723ENC->extra));
			
//	Line_Wr(ptrOut,&(G723ENC->framesizeOut0));
    /*
    int index;
    for(index=0; index<G723ENC->framesizeOut0; index++){
      *(ptrOut0+index) = *(ptrIn0+index);
    }
    */
}

XDAS_Void G723ENC_NECTEC_outframesize(IG723ENC_Handle handle, XDAS_Int8 * ptrIn, XDAS_UInt32 *size)
{
	Line_Wr(ptrIn,size);
}
