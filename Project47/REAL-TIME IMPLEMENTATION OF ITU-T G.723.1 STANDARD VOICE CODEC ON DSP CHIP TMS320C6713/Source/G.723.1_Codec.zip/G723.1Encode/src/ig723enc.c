/*
//============================================================================
//
//    FILE NAME : IG723ENC.c
//
//    ALGORITHM : G723ENC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file defines the default parameter structure for iG723ENC.h
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Tue - 11 January 2005
//    Creation Time: 03:42 PM
//
//============================================================================
*/

#include <std.h>
#include <xdas.h>
#include "ig723enc.h"
//#include "cst2.h"
//#include "tab2.h"

/*
// ===========================================================================
// G723ENC_PARAMS
//
// This constant structure defines the default parameters for G723ENC objects
*/
IG723ENC_Params IG723ENC_PARAMS = {
    sizeof(IG723ENC_Params),
    240, /* unsigned int  framesizeIn0 */
    24, /* unsigned int  framesizeOut0 */
    TRUE, /* useHp */
    TRUE, /* useVx */
    TRUE, /* rate63 */
//    &table,
};
