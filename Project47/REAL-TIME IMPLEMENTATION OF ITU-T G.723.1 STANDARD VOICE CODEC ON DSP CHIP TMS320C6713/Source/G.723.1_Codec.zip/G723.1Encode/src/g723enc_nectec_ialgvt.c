/*
//============================================================================
//
//    FILE NAME : G723ENC_NECTEC_ialgvt.c
//
//    ALGORITHM : G723ENC
//
//    VENDOR    : NECTEC
//
//    TARGET DSP: C67x
//
//    PURPOSE   : This file contains the function table definitions for
//                all interfaces implemented by the G723ENC_NECTEC module
//                that derive from IALG
//
//                You are free to replace these tables with different
//                definitions.  For example, one may want to build a
//                system where the algorithm is activated once and never
//                deactivated, moved, or freed.
//
//    Component Wizard for eXpressDSP Version 1.31.00 Auto-Generated Component
//
//    Number of Inputs : 1
//    Number of Outputs: 1
//
//    Creation Date: Tue - 11 January 2005
//    Creation Time: 03:42 PM
//
//============================================================================
*/

#include <std.h>
#include "ig723enc.h"

#include "g723enc_nectec.h"

extern Int  G723ENC_NECTEC_alloc(const IALG_Params *, struct IALG_Fxns **, IALG_MemRec *);
extern Int  G723ENC_NECTEC_control(IALG_Handle, IALG_Cmd, IALG_Status *);
extern Int  G723ENC_NECTEC_free(IALG_Handle, IALG_MemRec *);
extern Int  G723ENC_NECTEC_initObj(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Int  G723ENC_NECTEC_numAlloc(Void);
extern Void G723ENC_NECTEC_moved(IALG_Handle, const IALG_MemRec *, IALG_Handle, const IALG_Params *);
extern Void G723ENC_NECTEC_activate(IALG_Handle);
extern Void G723ENC_NECTEC_deactivate(IALG_Handle);
extern XDAS_Void G723ENC_NECTEC_encode(IG723ENC_Handle handle, XDAS_Int16 * ptrIn, XDAS_Int8 * ptrOut);
extern XDAS_Void G723ENC_NECTEC_outframesize(IG723ENC_Handle handle, XDAS_Int8 *ptrIn, XDAS_UInt32 *size);

#define IALGFXNS \
    &G723ENC_NECTEC_IALG,       /* module ID                            */ \
    G723ENC_NECTEC_activate,       /* activate   (NULL => not suported)    */ \
    G723ENC_NECTEC_alloc,       /* algAlloc                             */ \
    G723ENC_NECTEC_control,     /* control    (NULL => not suported)    */ \
    G723ENC_NECTEC_deactivate,  /* deactivate (NULL => not suported)    */ \
    G723ENC_NECTEC_free,        /* free                                 */ \
    G723ENC_NECTEC_initObj,     /* init                                 */ \
    G723ENC_NECTEC_moved,       /* moved      (NULL => not suported)    */ \
    G723ENC_NECTEC_numAlloc     /* numAlloc   (NULL => IALG_DEFMEMRECS) */ \

/*
//============================================================================
// G723ENC_NECTEC_IG723ENC
//
// This structure defines NECTEC's implementation of the IG723ENC interface
// for the G723ENC_NECTEC module.
*/
IG723ENC_Fxns G723ENC_NECTEC_IG723ENC = {	/* module_vendor_interface */
    IALGFXNS,
    G723ENC_NECTEC_encode,
    G723ENC_NECTEC_outframesize,
};


/*
//============================================================================
// G723ENC_NECTEC_IALG
//
// This structure defines NECTEC's implementation of the IALG interface
// for the G723ENC_NECTEC module.
*/
#ifdef _TI_
asm("_G723ENC_NECTEC_IALG .set _G723ENC_NECTEC_IG723ENC");
#else
/*
//============================================================================
// The structure is duplicated here to allow this code to be compiled
// and run on non-DSP platforms at the expense of unnecessary data space
// consumed by the definition below.
*/
IALG_Fxns G723ENC_NECTEC_IALG = {	/* module_vendor_interface */
    IALGFXNS
};
#endif
