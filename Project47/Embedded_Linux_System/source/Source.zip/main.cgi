#!/usr/bin/perl 

####################################################
# crane web interface script\
#
# created by embedded linux system
# 10/10/47	rev.2
####################################################
# read data from user request
read(STDIN, $dat, $ENV{'CONTENT_LENGTH'});
if(length($dat)==0)
{
	$xpos=" ";
	$ypos=" ";
}
else
{
	($temp1,$temp2) = split(/&/,$dat);
	($temp11,$temp12) = split(/=/,$temp1);
	($xpos,$ypos) = split(/\%2C/,$temp12);
	`echo $xpos$ypos > /proc/crane_controller/move_only`;
}
# set base color
$white="FFFFFF";
$red="FF0000";
@color = [];
# reset all cells color to white
$color[11]=$white;
$color[12]=$white;
$color[13]=$white;
$color[14]=$white;
$color[15]=$white;

$color[21]=$white;
$color[22]=$white;
$color[23]=$white;
$color[24]=$white;
$color[25]=$white;

$color[31]=$white;
$color[32]=$white;
$color[33]=$white;
$color[34]=$white;
$color[35]=$white;

$color[41]=$white;
$color[42]=$white;
$color[43]=$white;
$color[44]=$white;
$color[45]=$white;

$color[51]=$white;
$color[52]=$white;
$color[53]=$white;
$color[54]=$white;
$color[55]=$white;

#################################################
# read condition and set display here
#################################################
$status = `cat /proc/crane_controller/crane_status`;
($status_no,$status_text)=split(/\,/,$status);
$xypos = `cat /proc/crane_controller/crane_position`;
$color[$xypos] = $red;


#################################################
# display html page script
#################################################
print "Content-type: text/html\n\n";
print "<html>\n";
print "<title>Crane controller project\n";
print "</title>\n";
print "<body ><table align=\"center\"><tr><td>Rack Display</td></tr></table><br>\n";
print "<table align=\"center\" border=\"1\" width=\"25\%\">\n";
print "<tr>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[15]\">15</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[25]\">25</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[35]\">35</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[45]\">45</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[55]\">55</td>\n";
print "</tr>\n";
print "<tr>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[14]\">14</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[24]\">24</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[34]\">34</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[44]\">44</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[54]\">54</td>\n";
print "</tr>\n";
print "<tr>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[13]\">13</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[23]\">23</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[33]\">33</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[43]\">43</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[53]\">53</td>\n";
print "</tr>\n";
print "<tr>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[12]\">12</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[22]\">22</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[32]\">32</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[42]\">42</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[52]\">52</td>\n";
print "</tr>\n";
print "<tr>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[11]\">11</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[21]\">21</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[31]\">31</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[41]\">41</td>\n";
print "<td width=\"20\%\" align=\"center\" bgcolor=\"$color[51]\">51</td>\n";
print "</tr>\n";
print "</table>\n";
print "<br>$status_text\n";
print "<br><table align=\"center\"><tr><td><form method=\"POST\" action=\"./main.cgi\">\n";
print "<br>Please fill X and Y position in format X,Y<br>\n";
print "<br><table align=\"center\"><tr><td><input type=\"text\" name=\"xyposition\"></td></tr></table><br>\n";
print "<br><table align=\"center\"><tr><td><input type=\"submit\" value=\"Start move\" name=\"moveb\">\n";
print "<input type=\"reset\" value=\"Clear\" name=\"resetb\"></td></tr></table>\n";
print "</td></tr></table></form>\n";
print "</body>\n";
print "</html>\n";

