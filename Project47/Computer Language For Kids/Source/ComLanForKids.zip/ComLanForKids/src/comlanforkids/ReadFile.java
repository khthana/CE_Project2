package comlanforkids;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ReadFile {

  File convertfile = null;

  int nloopp = 0;
  int nfile = 0;
  int ia[] = new int[0];
  int ja[] = new int[0];
  String tmpFile[] = new String[0];
  int i=0,j=0,index0=0,index1=0,flag=0,nnloop=0;

  int[][] tmp = new int[0][0];
  int[][] orang = new int[0][0];
  String[][] tmpbb = new String[0][0];
  int[][] loopp = new int[0][4];
  File[] file;

  int qualityofpic[][];
  private int typeofpic[];

  public boolean IsTopLeft[][];
  public int tabl[][];
  public int orange[][];
  public int nloop = 0;
  public File CFile[][];
  public int n = 0;
  public int h = 0;
  public int w = 0;


  private File[][] ChangeFile(){
    File[][] CFile2 = new File[h*2][w*2];

    for (int p = 0 ; p < h*2 ; p++){
      for (int o = 0 ; o < w*2 ; o++)
      {
        if(tabl[p][o] != 27){
          CFile2[p][o] = null;
        }
        else
        {
          CFile2[p][o] = file[qualityofpic[p][o]-1];
        }
      }
    }
    return CFile2;
  }

  private void Convert(){

    try {
       FileReader fin = new FileReader(convertfile);
       BufferedReader bin = new BufferedReader(fin);

       String s;
       while ((s = bin.readLine()) != null)
       {
         if (s.equals("Size"))
         {
           flag=1;
           continue;
         }
         else if (flag==0)
         {
           flag=5;
           break;
         }
         else if (flag==1)
         {
           index1 = s.indexOf(' ',index0);
           h = Integer.parseInt((s.substring(index0,index1).trim()));
           index0 = index1+1;
           index1 = s.indexOf(' ',index0);
           w = Integer.parseInt((s.substring(index0,s.length()).trim()));
           break;
         }
       }
       if (flag==5){
         //JOptionPane.showMessageDialog(this,"Error opening this file","Error",JOptionPane.ERROR_MESSAGE);
       }
       else
       {
       tmp = new int[h*2][w*2];
       orang = new int[h*2][w*2];
       tmpbb = new String[h*2][w*2];
       flag = 0;
       while ((s = bin.readLine()) != null)
       {
         j=0;
         index0=0;
         index1=0;

         if (s.equals("Table"))
         {
           flag=2;
           continue;
         }
         else if (s.equals("Orange"))
         {
           flag=3;
           i=0;
           continue;
         }
         else if (s.equals("BlackBox")){
           flag=6;
           i=0;
           break;
         }
         else if (flag==2)
         {
           while (index0 < s.length())
           {
             index1 = s.indexOf(' ',index0);
             tmp[i][j] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             j++;
           }
           i++;
           continue;
         }
         else if (flag==3)
         {
           while (index0 < s.length())
           {
             index1 = s.indexOf(' ',index0);
             orang[i][j] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             j++;
           }
           i++;
           continue;
         }
       }
       if(flag!=6){//JOptionPane.showMessageDialog(this,"Error opening this file","Error",JOptionPane.ERROR_MESSAGE);
       }
       else{
           index0=0;
           s = bin.readLine();
           nfile = Integer.parseInt((s.substring(index0,s.length()).trim()));
           ia = new int[nfile];
           ja = new int[nfile];
           tmpFile = new String[nfile];
           for (int tt = 0 ; tt < nfile ; tt++){
             s = bin.readLine();
             index0=0;
             index1=0;
             index1 = s.indexOf(' ',index0);
             ia[tt] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             index1 = s.indexOf(' ',index0);
             ja[tt] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             tmpFile[tt] = s.substring(index0,s.length()).trim();
           }
           s = bin.readLine();
           if (s.equals("Loop")) flag=8;
       }
       }
       if(flag!=8){//JOptionPane.showMessageDialog(this,"Error opening this file","Error",JOptionPane.ERROR_MESSAGE);

       }
       else{
         int tmpi = 0;
         while ((s = bin.readLine()) != null){
           index0=0;
           index1=0;
           if(flag == 8){
             nloopp = Integer.parseInt((s.substring(index0,s.length()).trim()));
             flag = 9;
             loopp = new int[nloopp][4];
             continue;
           }
           else if(flag==9){
             int tmpj = 0;
             while (index0 < s.length())
             {
               index1 = s.indexOf(' ',index0);
               loopp[tmpi][tmpj] = Integer.parseInt((s.substring(index0,index1).trim()));
               index0 = index1+1;
               tmpj++;
             }
             tmpi++;
             continue;
           }
         }

       bin.close();

       Loop tmploop[] = new Loop[nloopp];

       qualityofpic = new int[h*2][w*2];
       IsTopLeft = new boolean[h*2][w*2];
       tabl = new int[h*2][w*2];
       orange = new int[h*2][w*2];

       for(int p = 0 ; p < h*2 ; p++ ){
         for(int q = 0 ; q < w*2 ; q++ ){
           qualityofpic[p][q] = 0;
           IsTopLeft[p][q] = false;
           tabl[p][q] = tmp[p][q];
           orange[p][q] = orang[p][q];
         }
       }


       for(int p = 0 ; p < h*2 ; p++){
         for(int q = 0 ; q < w*2 ; q++){
           if(tmp[p][q]!=0 && tmp[p][q]!=14){
             n++;

             if(tmp[p][q]==4){
               IsTopLeft[p][q] = true;
               qualityofpic[p][q] = n;
               tmp[p][q] = 0;
               LoadBlock(p,q);
             }
             else if(tmp[p][q]==13){
               IsTopLeft[p][q] = true;
               qualityofpic[p+1][q+1] = n;
               qualityofpic[p][q+1] = n;
               qualityofpic[p+1][q] = n;
               qualityofpic[p][q] = n;
               tmp[p+1][q+1] = 0;
               tmp[p+1][q] = 0;
               tmp[p][q+1] = 0;
               tmp[p][q] = 0;
               LoadBlock(p,q);
               n++;
               int u=0;
               int v=0;
               for(int l = 0 ; l < nloopp ; l++){

                 if(loopp[l][0]==q && loopp[l][1]==p){
                   IsTopLeft[loopp[l][3]][loopp[l][2]] = true;
                   qualityofpic[loopp[l][3]+1][loopp[l][2]+1] = n;
                   qualityofpic[loopp[l][3]+1][loopp[l][2]] = n;
                   qualityofpic[loopp[l][3]][loopp[l][2]+1] = n;
                   qualityofpic[loopp[l][3]][loopp[l][2]] = n;
                   tmp[loopp[l][3]+1][loopp[l][2]+1] = 0;
                   tmp[loopp[l][3]][loopp[l][2]+1] = 0;
                   tmp[loopp[l][3]+1][loopp[l][2]] = 0;
                   tmp[loopp[l][3]][loopp[l][2]] = 0;
                   LoadBlock(loopp[l][3],loopp[l][2]);
                   u = loopp[l][2];
                   v = loopp[l][3];
                 }
               }

               tmploop[nloop] = new Loop(p,q,u,v,n-1,n);
               nloop++;

             }
             else{
               IsTopLeft[p][q] = true;
               qualityofpic[p+1][q+1] = n;
               qualityofpic[p][q+1] = n;
               qualityofpic[p+1][q] = n;
               qualityofpic[p][q] = n;
               tmp[p+1][q+1] = 0;
               tmp[p+1][q] = 0;
               tmp[p][q+1] = 0;
               tmp[p][q] = 0;
               LoadBlock(p,q);
             }
           }
         }
       }

       file = new File[n];
       int kk = 0;
       int ll = 0;
       for(int ii=0;ii<n;ii++){
         kk = 0;
         ll = 0;
         if(typeofpic[ii]==27){
           boolean tmpboolean=false;
           for(kk=0;kk<h*2;kk++){
             for(ll=0;ll<w*2;ll++){
               if(qualityofpic[kk][ll]==ii+1){
                 for(int jj=0;jj<nfile;jj++){
                   if(ia[jj]==ll&&ja[jj]==kk){
                     file[ii] = new File(tmpFile[jj]);
                     tmpboolean=true;
                     break;
                   }
                 }
               }
               if(tmpboolean)break;
             }
             if(tmpboolean)break;
           }
         }else{
           file[ii]=null;
         }
       }

       }
    }
    catch (EOFException endOfFileException) {
      //JOptionPane.showMessageDialog(this,"No more records in file","End of File",JOptionPane.ERROR_MESSAGE);
    }
    //catch (ClassNotFoundException classNotFoundException) {
    //  JOptionPane.showMessageDialog(this,"Unable to create object","Class Not Found",JOptionPane.ERROR_MESSAGE);
    //}
    catch (IOException ioException) {
      //JOptionPane.showMessageDialog(this,"Error during read from file","Read Error",JOptionPane.ERROR_MESSAGE);
    }

  }


  private void LoadBlock(int p,int q){
    int tmp5[] = new int[n-1];
    for (int r = 0 ; r < n-1 ; r++){
      tmp5[r] = typeofpic[r];
    }
    typeofpic = new int[n];

    for (int r = 0 ; r < n-1 ; r++){
      typeofpic[r] = tmp5[r];
    }
    typeofpic[n-1]=tabl[p][q];
  }


  public ReadFile(File file) {

    convertfile = file;
    Convert();
    this.CFile = ChangeFile();

  }
}