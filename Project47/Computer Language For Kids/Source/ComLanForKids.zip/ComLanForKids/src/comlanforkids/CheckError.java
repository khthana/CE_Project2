package comlanforkids;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CheckError {

  private int height;
  private int wide;
  private int tab[][];
  private boolean tl[][];
  private int orange[][];
  private boolean m[][];
  private File file[][];
  private File ThisFile;

  int n;
  int[] a;
  int x;
  int y;
  public boolean havebox;
  boolean[] foundloop;
  int nloop;
  int percent=32768;
  int ratio=1;
  int IsRecursion = 0; //if equals 32768 == infinite loop

  public CheckError(int height, int wide,int[][] tab,boolean[][] tl,int orange[][],File[][] file,boolean havebox,File ThisFile) {

    this.height = height;
    this.wide = wide;
    this.tab = new int[height][wide];
    this.tl = new boolean[height][wide];
    this.orange = new int[height][wide];
    this.file = new File[height][wide];
    this.havebox = havebox;
    this.ThisFile = ThisFile;
    m = new boolean[height][wide];
    for(int i = 0; i<height ; i++){
      for(int j = 0; j<wide ; j++){
        this.tab[i][j] = tab[i][j];
        this.orange[i][j] = orange[i][j];
        this.file[i][j] = file[i][j];
        if((tab[i][j] == 5 || tab[i][j] == 9)&&tl[i][j]){
          this.tl[i][j] = false;
          j++;
          this.tab[i][j] = tab[i][j];
          this.orange[i][j] = orange[i][j];
          this.file[i][j] = file[i][j];
          this.tl[i][j] = true;
        }else if((tab[i][j] == 8)&&tl[i][j]){
          this.tl[i][j] = true;
          j++;
          this.tab[i][j] = tab[i][j];
          this.orange[i][j] = orange[i][j];
          this.file[i][j] = file[i][j];
          this.tl[i][j] = true;
          j++;
          this.tab[i][j] = tab[i][j];
          this.orange[i][j] = orange[i][j];
          this.file[i][j] = file[i][j];
        }
        else this.tl[i][j] = tl[i][j];
        m[i][j] = false;
      }
    }

  }

  public int[] Check(int h ,int w ,int style){
    if(style == 0){
      for(int i = h; i<height; i++){
        for(int j = w; j<wide; j++){
          if(tl[i][j]){

            if(tab[i][j] != 1 && tab[i][j] != 0){
              a[0] = i;
              a[1] = j;
              return a;
            }else if (tab[i][j] == 1){
              x = i;
              y = j;
              m[x][y] = true;
              if(h+2<height){return Check(x+2,y,1);}
              else {
                a[0] = h;
                a[1] = w;
                return a;
              }
            }

          }
        }
      }
      a[0] = -2;
      a[1] = -2;
      return a;
    }
    else if(style == 1){
        if(tl[h][w]){
          if(tab[h][w] == 2 || tab[h][w] == 27){
            if(tab[h][w] == 27){

              if(file[h][w]!=null && ThisFile !=null){
                String tmp1 = file[h][w].getPath();
                String tmp2 = ThisFile.getPath();

                if(tmp1.equals(tmp2)){
                  IsRecursion = IsRecursion + percent;
                  percent = 0;
                  if(IsRecursion >= 32768){
                    a[0] = h;
                    a[1] = w;
                    return a;
                  }
                  else{
                    m[h][w] = true;
                    return Check(h+2,w,1);
                  }
                }
              }
              ReadFile fileread = new ReadFile(file[h][w]);
              CheckError error = new CheckError(fileread.h*2,fileread.w*2,fileread.tabl,fileread.IsTopLeft,fileread.orange,fileread.CFile,havebox,file[h][w]);
              int[] WrongBlock = error.CheckAll(n+1);

              int x = WrongBlock[0];
              int y = WrongBlock[1];
              havebox = error.havebox;

              if(x == -2 && y == -2 ){ x = 0; y = 0;}
              if(x == -1 && y == -1 ){
                m[h][w] = true;
                return Check(h+2,w,1);
              }
              else if(x < -1 || y < -1 ) {System.err.println("error");}
              else{
                a[0] = h;
                a[1] = w;
                return a;
              }

            }
            m[h][w] = true;
            return Check(h+2,w,1);
          }
          else if(tab[h][w] == 11){
            m[h][w] = true;
            return Check(h+2,w+1,2);
          }
          else if(tab[h][w] == 12){
            m[h][w] = true;
            return Check(h+2,w,2);
          }

          else if(tab[h][w] == 26 && havebox
                  ){
            m[h][w] = true;
            return Check(h-1,w+2,3);
          }
          else if(tab[h][w] == 15 && havebox
                  ){
            m[h][w] = true;
            return Check(h+1,w-2,4);
          }

          else if(tab[h][w] == 3){
            havebox = true;
            m[h][w] = true;
            return Check(h+2,w,1);
          }
          else if(tab[h][w] == 13){
            foundloop[nloop] = false;
            nloop++;
            int i[] = new int[2];
            i = Check(h+2,w,1);
            m[h][w] = true;
            if(foundloop[nloop])return Check(i[0]+2,i[1],1);
            else{return Check(i[0]+2,i[1],1);}
          }
          else if(tab[h][w] == 14){
            nloop--;
            if(nloop >= 0)foundloop[nloop] = true;
            a[0] = h;
            a[1] = w;
            m[h][w] = true;
            return a;
          }
          else if(tab[h][w] == 7 && havebox
                  ){
            if(w-1 >= 0){
               int i[] = new int[2];
               int j[] = new int[2];
               ratio = ratio * 2;
               int tmppercent = percent;
               percent = 32768 / ratio ;

               i = Check(h+2,w,2);

               percent = 32768 / ratio ;
               j = Check(h+2,w+1,2);
               ratio = ratio / 2;
               percent = tmppercent;
               //IsRecursion;

               if(i[0]>=0 &&i[1]>=0 &&j[0]>=0 &&j[1]>=0){
                 if(i[0] == j[0] && i[1] == j[1] && tab[i[0]][i[1]] == 8){

                   if(i[0]+2 < height){
                     m[h][w] = true;
                     return Check(i[0]+2,i[1],1);
                   }
                   else{
                     a[0] = i[0]+2;
                     a[1] = i[1];
                     return a;
                   }
                 }

                 else{
                   if(i[0]<j[0]){
                     a[0] = i[0]-2;
                     a[1] = i[1];
                     return a;
                   }else {
                     a[0] = j[0]-2;
                     a[1] = j[1];
                     return a;
                   }
                 }

               }else{
                 if(i[0]<0){
                   a[0] = i[0];
                   a[1] = i[1];
                   return a;
                 }else {
                   a[0] = j[0];
                   a[1] = j[1];
                   return a;
                 }
               }
            }
            else {
              a[0] = h;
              a[1] = w;
              return a;
            }
          }
          else if(tab[h][w] == 20){
            boolean tmp = true;
            for(int i = 0 ; i <1000 ; i++){
              if(!foundloop[i])tmp = false;
            }
            if (tmp){
              m[h][w] = true;
              a[0] = -1;
              a[1] = -1;
              return a;
            }
            else{
              a[0] = h;
              a[1] = w;
              return a;
            }
          }
          else{
            a[0] = h;
            a[1] = w;
            return a;
          }
        }else {
          a[0] = h;
          a[1] = w;
          return a;
        }
    }
    else if(style == 2){
      if(tl[h][w]){
        if(tab[h][w] == 5){
          m[h][w] = true;
          return Check(h+2,w-1,2);
        }
        else if(tab[h][w] == 6){
          m[h][w] = true;
          return Check(h+2,w+1,2);
        }
        else if(tab[h][w] == 9){
          m[h][w] = true;
          return Check(h+2,w-1,1);
        }
        else if(tab[h][w] == 10){
          m[h][w] = true;
          return Check(h+2,w,1);
        }
        else if(tab[h][w] == 8){
          if(w==0){
            a[0] = h;
            a[1] = w;
            return a;
          }
          else if(tl[h][w-1]){
            a[0] = h;
            a[1] = w-1;
            m[h][w] = true;
            return a;
          }
          a[0] = h;
          a[1] = w;
          m[h][w] = true;
          return a;
        }
        else {
          a[0] = h;
          a[1] = w;
          return a;
        }
      }
      else {
        a[0] = h;
        a[1] = w;
        return a;
      }
    }
    else if(style == 3){
      if(tab[h][w] == 16 || tab[h][w] == 18){
        m[h][w] = true;
        return Check(h+3,w-2,1);
      }
      else{
        a[0] = h+1;
        a[1] = w-2;
        return a;
      }
    }
    else {
      if(tab[h][w] == 17){
        m[h][w] = true;
        return Check(h+1,w+2,1);
      }
      else if(tab[h][w] == 19 && orange[h][w] != 0){
        m[h][w] = true;
        return Check(h+1,w+2,1);
      }
      else{
        a[0] = h-1;
        a[1] = w+2;
        return a;
      }
    }
  }

  public int[] CheckAll(int n){
    this.n = n;
    a = new int[2];
    if(n >100){
      a[0] = 1;
      a[1] = 1;
      return a;
    }
    x = 0;
    y = 0;
    nloop = 0;
    foundloop = new boolean[1000];
    for(int i = 0 ; i <1000 ; i++)
      foundloop[i] = true;
    int b[] = new int[2];
    b = Check(x,y,0);
    if(b[0] == -1 && b[1] == -1){
      for(int i = 0; i<height ; i++){
        for(int j = 0; j<wide ; j++){
          if(tl[i][j] != m [i][j]){
            a[0] = i;
            a[1] = j;
            return a;
          }
        }
      }
    }
    return b;
  }

}