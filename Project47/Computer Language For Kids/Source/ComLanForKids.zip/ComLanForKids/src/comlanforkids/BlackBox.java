package comlanforkids;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class BlackBox {
  protected File filename;
  protected boolean havebox;
  protected int norange;

  int l = 0;
  int lx[] = new int[15];
  int ly[] = new int[15];
  int lz[] = new int[15];
  int lxx[] = new int[15];
  int lyy[] = new int[15];
  boolean lb[] = new boolean [15];
  boolean lbb[] = new boolean [15];
  int xx = 0;
  int yy = 0;
  int xxx = 0;
  int yyy = 0;
  boolean animetionfinish = true;
  boolean operator = false;


  private int h = 0;
  private int w = 0;
  private int n = 0;


  private int qualityofpic[][];
  private boolean IsTopLeft[][];
  private int tabl[][];
  private int orange[][];
  private int nloop = 0;
  private File CFile[][];

  boolean qwq = true;

  private void FindTotal(){

  if(yy!=0){
    if(IsTopLeft[xx][yy]){

    }else if(IsTopLeft[xx][yy-1]){
      yy--;
    }else if(IsTopLeft[xx][yy+1]){
      yy++;
    }
  }else{
    if(IsTopLeft[xx][yy]){

    }else if(IsTopLeft[xx][yy+1]){
      yy++;
    }
  }


  if(havebox || tabl[xx][yy] == 3){

    switch (tabl[xx][yy]){
    case 3:
      norange = orange[xx][yy];
      break;
    case 16:
      norange = norange + orange[xx][yy];
      operator = true;
      break;
    case 17:
      norange = norange - orange[xx][yy];
      operator = true;
      break;
    case 18:
      norange = norange * orange[xx][yy];
      operator = true;
      break;
    case 19:
      int nn;
      nn = norange % orange[xx][yy];
      nn = norange - nn;
      norange = nn / orange[xx][yy];
      operator = true;
      break;
    case 27:
      BlackBox BB = new BlackBox(CFile[xx][yy],havebox,norange);
      norange = BB.Total();
      break;
    }

  }else norange = -32764;


  if(!havebox && (tabl[xx][yy]==16 || tabl[xx][yy]==17 || tabl[xx][yy]==18 || tabl[xx][yy]==19)){
  operator = true;
  }


  if(!qwq){
    qwq = true;
    animetionfinish = true;
      /*if(havebox){
        jPanel2.remove(Box);
        jPanel2.remove(TextBox);
      }*/
      havebox = false;
      operator = false;
  }else{


  switch (tabl[xx][yy]){
    case 1:
    case 2:
    case 9:
    case 10:
    case 27:
      xx=xx+2;
      break;
    case 3:
      havebox = true;
      xx=xx+2;
      break;

    case 5:
    case 12:
      if(tabl[xx+2][yy] == 5 || tabl[xx+2][yy] == 8 || tabl[xx+2][yy] == 9)yy--;
      xx = xx + 2;
      break;

    case 6:
    case 11:
      if(tabl[xx+2][yy+1] != 5 && tabl[xx+2][yy+1] != 8)yy++;
      xx = xx + 2;
      break;

    case 7:
      if(norange>=orange[xx][yy])yy--;
      else yy++;
    case 8:
      xx = xx + 2;
      break;
    case 13:
      boolean tmp = true;
      int tmp2 = 0;
      boolean tmp3 = true;
      for(int i = 0; i< 15 ; i++){
        if(lxx[i] == xx && lyy[i] == yy){
          tmp = false;
          tmp2 = i;
        }
      }
      if(tmp){
        for(int i = 0; i< 15 ; i++){
          if(lxx[i] == 0 && lyy[i] == 0 && tmp3){
            tmp2 = i;
            tmp3 = false;
          }
        }
        lxx[tmp2] = xx;
        lyy[tmp2] = yy;
      }
      l = tmp2;
      if(lz[l] == orange[xx][yy]){
        int s = 0;
        int xxx = 0;
        int yyy = 0;
        int xxxx= xx+2;
        int yyyy= yy;
        while(xxx == 0 && yyy ==0){
          if(yyyy!=0){
            if(IsTopLeft[xxxx][yyyy]){

            }else if(IsTopLeft[xxxx][yyyy-1]){
              yyyy--;
            }else if(IsTopLeft[xxxx][yyyy+1]){
              yyyy++;
            }
          }else{
            if(IsTopLeft[xxxx][yyyy]){

            }else if(IsTopLeft[xxxx][yyyy+1]){
              yyyy++;
            }
          }
          switch (tabl[xxxx][yyyy]){
            case 13:
              s++;
              xxxx = xxxx + 2;
              break;
            case 14:
              if(s==0){
                xxx = xxxx;
                yyy = yyyy;
              }
              else {
                s--;
                xxxx = xxxx + 2;
              }
              break;
            default:
              xxxx = xxxx + 2;
          }
        }
        xx = xxx;
        yy = yyy;
        lb[l] = true;
        }
      else{
        lx[l] = xx;
        ly[l] = yy;
        xx = xx +2;
      }
      break;
    case 14:
      if(!lb[l]){
        xx = lx[l];
        yy = ly[l];
        lz[l] = lz[l] + 1;
      }else{
        lb[l]=false;
        lz[l]=0;
        lxx[l]=0;
        lyy[l]=0;
        l--;
        xx = xx +2;
      }
      break;
    case 16:
    case 18:
      xx++;
      yy = yy-2;
      break;
    case 17:
    case 19:
      xx--;
      yy = yy+2;
      break;
    case 15:
      if(operator){
        xx = xx + 2;
        operator = false;
      }
      else{
        xx++;
        yy = yy-2;
      }
      break;
    case 26:
      if(operator){
        xx = xx + 2;
        operator = false;
      }
      else{
        xx--;
        yy = yy+2;
      }
      break;
    case 20:
      qwq = false;
  }
  }

  }

  public int Total(){

    ReadFile fileread = new ReadFile(filename);

    n = fileread.n;
    h = fileread.h;
    w = fileread.w;
    qualityofpic = fileread.qualityofpic;
    IsTopLeft = fileread.IsTopLeft;
    tabl = fileread.tabl;
    orange = fileread.orange;
    nloop = fileread.nloop;
    CFile = fileread.CFile;

    animetionfinish=false;
    l = 0;
    lx = new int[15];
    ly = new int[15];
    lz = new int[15];
    lxx = new int[15];
    lyy = new int[15];
    lb = new boolean[15];
    lbb = new boolean[15];
    for(int i = 0 ; i< 15 ; i++){
      lx[i]=0;
      ly[i]=0;
      lz[i]=0;
      lxx[i]=0;
      lyy[i]=0;
      lb[i]=false;
      lbb[i]=false;
    }
    xx = 0;
    yy = 0;
    xxx = 0;
    yyy = 0;
    operator = false;
    for(int i = 0 ; i< h*2 ; i++){
      for( int j = 0 ; j < w*2 ; j++){
        if(tabl[i][j]==1){
          xx = i-1;
          yy = j-1;
        }
      }
    }

    int bobb = 0;
    while(!animetionfinish){

      bobb++;
      FindTotal();
      if(bobb>300)return -300;
    }

    return norange;
  }

  public BlackBox(File file,boolean havebox,int norange) {
    this.filename = file;
    this.havebox = havebox;
    this.norange = norange;
  }
}