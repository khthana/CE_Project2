package comlanforkids;

import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Loop {
  public JLabel[] labelloop;
  public int nlabelloop;
  public int loopx;
  public int loopy;
  public int endloopx;
  public int endloopy;
  public int pressx;
  public int pressy;

  public int findrange(){
    nlabelloop = (endloopy-loopy)/2-1;
    if(loopx>=endloopx) nlabelloop = nlabelloop + (loopx-endloopx)/2;
    else nlabelloop = nlabelloop + (endloopx-loopx)/2;
    nlabelloop = nlabelloop + 2;
    return nlabelloop;
  }

  public Loop(int l1,int l2 ,int el1,int el2,int px,int py) {
    nlabelloop=0;
    pressx = px;
    pressy = py;
    loopx = l1;
    loopy = l2;
    endloopx = el1;
    endloopy = el2;
    nlabelloop = (el2-l2)/2-1;
    if(l1>=el1) nlabelloop = nlabelloop + (l1-el1)/2;
    else nlabelloop = nlabelloop + (el1-l1)/2;
    nlabelloop = nlabelloop + 2;
  }
}