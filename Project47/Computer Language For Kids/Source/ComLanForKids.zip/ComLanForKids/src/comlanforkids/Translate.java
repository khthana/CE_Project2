package comlanforkids;
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Translate {
  int i=0,j=0;
  boolean flag = false;
  int countif;
  File fileblack[][];
  boolean box;
  int hh = 0;
  int ww = 0;
  String ss;
  Vector vBlack = new Vector();
  String[] FileAlready = new String[10];
  int CountFile=0;
  boolean ok = true;

  //=============================== Translate ===================================
  public void Translate(int h,int w,int tabl[][],int orange[][],int type,Vector v,File Name,File file[][]) throws IOException
  {
    hh = h;
    ww = w;
    fileblack = file;
    //------------------------------ Find First Block --------------------------
    for (int y=0 ; y<h*2 ; y++)
     for (int x=0 ; x<w*2 ; x++)
       if (tabl[y][x] == 1)
       {
        i = x;
        j = y;
        flag = true;
       }
    i--;
    j--;
    if (flag)
    {
      Tran(i,j,tabl,orange,v);
    //----------------- Write to File -----------------
    FileWriter fout = new FileWriter(Name+".c");
    BufferedWriter bout = new BufferedWriter(fout);
    PrintWriter pout = new PrintWriter(bout);

    for (int k=0 ; k<v.size() ; k++)
      pout.println(v.elementAt(k));
    //pout.println("");
    for (int k=0 ; k<vBlack.size() ; k++)
      pout.println(vBlack.elementAt(k));
    //bin.close();
    pout.close();
    }
  }

  public void Tran(int x,int y,int tabl[][],int orange[][],Vector v) throws IOException
  {
    //-------------------------------- Begin -----------------------------------
    if (tabl[y][x] == 1)
    {
      v.addElement(new String("#include <stdio.h>"));
      v.addElement(new String("#include <conio.h>"));
      v.addElement(new String(""));
      v.addElement(new String("void main()"));
      v.addElement(new String("{"));
      v.addElement(new String("     clrscr();"));
      Tran(x,y+2,tabl,orange,v);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 2)
    {
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //---------------------------------- Box -----------------------------------
    else if (tabl[y][x] == 3)
    {
      box = true;
      for (int k=0 ; k<v.size() ; k++)
      if (v.elementAt(k).equals("void main()"))
      {
        v.insertElementAt(new String("int box;"),k-1);
        k = v.size();
      }
      v.addElement(new String ("     box = "+orange[y][x]+";"));
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 5)
    {
      if (tabl[y][x-1] == 5) x--;
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 6)
    {
      if (tabl[y][x-1]!=6) x++;
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //----------------------------------- If -----------------------------------
    else if (tabl[y][x] == 7)
    {
      //---------------------------- Left Side ----------------------------
      v.addElement(new String("     if (box >= "+orange[y][x]+")"));
      v.addElement(new String("     {"));
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      //---------------------------- Right Side ----------------------------
      v.addElement(new String("     else"));
      v.addElement(new String("     {"));
      x++;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //--------------------------------- End If ---------------------------------
    else if (tabl[y][x] == 8)
    {
      v.addElement(new String("     }"));
      //---------------------------- Left Side ----------------------------
      if (tabl[y][x-1] != 8)
        return;
      //--------------------------- Right Side ----------------------------
      else if (tabl[y][x+1] != 8)
      {
        x = x - 1;
        y = y + 2;
        Tran(x,y,tabl,orange,v);
      }
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 9)
    {
      if (tabl[y][x-1]==9) x--;
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 10)
    {
      if (tabl[y][x-1] == 10) x--;
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 11)
    {
      x++;
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 12)
    {
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //---------------------------------- Loop ----------------------------------
    else if (tabl[y][x] == 13)
    {
      v.addElement(new String("     for (i=1 ; i<="+orange[y][x]+" ; i++"+")"));
      v.addElement(new String("     {"));
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //-------------------------------- End Loop --------------------------------
    else if (tabl[y][x] == 14)
    {
      v.addElement(new String("     }"));
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //-------------------- Co-Factor of Substract & Divide ---------------------
    else if (tabl[y][x] == 15)
    {
      x--;
      y++;
      Tran(x,y,tabl,orange,v);
      x++;
      y++;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //---------------------------------- Add -----------------------------------
    else if (tabl[y][x] == 16)
    {
      v.addElement(new String("     box = box + "+orange[y][x]+";"));
      return;
    }
    //-------------------------------- Subtract --------------------------------
    else if (tabl[y][x] == 17)
    {
      v.addElement(new String("     box = box - "+orange[y][x]+";"));
      return;
    }
    //-------------------------------- Multiply --------------------------------
    else if (tabl[y][x] == 18)
    {
      v.addElement(new String("     box = box * "+orange[y][x]+";"));
      return;
    }
    //--------------------------------- Divide ---------------------------------
    else if (tabl[y][x] == 19)
    {
      v.addElement(new String("     box = box / "+orange[y][x]+";"));
      return;
    }
    //------------------------------ End Program -------------------------------
    else if (tabl[y][x] == 20)
    {
      v.addElement(new String("}"));
      return;
    }
    //---------------------- Co-Factor of Add & Multiply -----------------------
    else if (tabl[y][x] == 26)
    {
      x = x + 2;
      Tran(x,y,tabl,orange,v);
      x = x - 2;
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
    //-------------------------------- Black Box -------------------------------
    else if (tabl[y][x] == 27)
    {
      int[] tempK = new int[1];
      String s = fileblack[y][x].getName();
      ss = s + "()";
      s = s + "();";
      for (int a=0 ; a <= 9 ; a++)
        if (s.equals(FileAlready[a])) ok = false;
      if (ok)
      {
        FileAlready[CountFile] = s;
        CountFile ++;
        for (int k=0 ; k<v.size() ; k++)
          if (v.elementAt(k).equals("void main()"))
          {
            v.insertElementAt(new String("void ")+s,k);
            k = v.size();
          }
        tempK[0] = vBlack.size();
        vBlack.addElement(new String(""));
        ReadFile fileread = new ReadFile(fileblack[y][x]);
        Black(fileread.tabl,fileread.orange,fileread.CFile,v,tempK,fileread.h,fileread.w);
      }
      ok = true;
      v.addElement(new String("     ")+s);
      y = y + 2;
      Tran(x,y,tabl,orange,v);
      return;
    }
  }

//----------------------- Find First Block of Black Box ------------------------
  public void Black(int tabl[][],int orange[][],File file[][],Vector v,int kk[],int h,int w)
  {
    //------------------------------ Find First Block --------------------------
    for (int y=0 ; y<h*2 ; y++)
      for (int x=0 ; x<w*2 ; x++){
    if (tabl[y][x] == 1)
       {
        i = x;
        j = y;
        flag = true;
       }
     }
    i--;
    j--;
    if (flag)
    {
      TranBlack(i,j,tabl,orange,file,v,kk);
    }
  }

//-------------------------- Translate for Black Box ---------------------------
  public void TranBlack(int x,int y,int tabl[][],int orange[][],File file[][],Vector v,int kk[])
  {
    if (tabl[y][x] ==1)
    {
      vBlack.insertElementAt(new String("void ")+ss,kk[0]+1);
      vBlack.insertElementAt(new String("{"),kk[0]+2);
      y = y + 2;
      kk[0] = kk[0]+2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 2)
    {
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //---------------------------------- Box -----------------------------------
    else if (tabl[y][x] == 3)
    {
      if (!box)
      {
        for (int k=0 ; k<v.size() ; k++)
          if (v.elementAt(k).equals("void main()"))
          {
            v.insertElementAt(new String("int box;"),k-1);
            k = v.size();
          }
      }
      vBlack.insertElementAt(new String ("     box = "+orange[y][x]+";"),kk[0]+1);
      kk[0]++;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 5)
    {
      if (tabl[y][x-1] == 5) x--;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 6)
    {
      if (tabl[y][x-1]!=6) x++;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //----------------------------------- If -----------------------------------
    else if (tabl[y][x] == 7)
    {
      //---------------------------- Left Side ----------------------------
      vBlack.insertElementAt(new String("     if (box >= "+orange[y][x]+")"),kk[0]+1);
      vBlack.insertElementAt(new String("     {"),kk[0]+2);
      y = y + 2;
      kk[0] = kk[0] + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      //---------------------------- Right Side ----------------------------
      vBlack.insertElementAt(new String("     else"),kk[0]+1);
      vBlack.insertElementAt(new String("     {"),kk[0]+2);
      x++;
      kk[0] = kk[0] + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //--------------------------------- End If ---------------------------------
    else if (tabl[y][x] == 8)
    {
      vBlack.insertElementAt(new String("     }"),kk[0]+1);
      kk[0]++;
      //---------------------------- Left Side ----------------------------
      if (tabl[y][x-1] != 8)
        return;
      //--------------------------- Right Side ----------------------------
      else if (tabl[y][x+1] != 8)
      {
        x = x - 1;
        y = y + 2;
        TranBlack(x,y,tabl,orange,file,v,kk);
      }
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 9)
    {
      if (tabl[y][x-1]==9) x--;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 10)
    {
      if (tabl[y][x-1] == 10) x--;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 11)
    {
      x++;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //------------------------------ Normal Path -------------------------------
    else if (tabl[y][x] == 12)
    {
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //---------------------------------- Loop ----------------------------------
    else if (tabl[y][x] == 13)
    {
      vBlack.insertElementAt(new String("     for (i=1 ; i<="+orange[y][x]+" ; i++"+")"),kk[0]+1);
      vBlack.insertElementAt(new String("     {"),kk[0]+2);
      kk[0] = kk[0] + 2;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //-------------------------------- End Loop --------------------------------
    else if (tabl[y][x] == 14)
    {
      vBlack.insertElementAt(new String("     }"),kk[0]+1);
      kk[0]++;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //-------------------- Co-Factor of Substract & Divide ---------------------
    else if (tabl[y][x] == 15)
    {
      x--;
      y++;
      TranBlack(x,y,tabl,orange,file,v,kk);
      x++;
      y++;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //---------------------------------- Add -----------------------------------
    else if (tabl[y][x] == 16)
    {
      vBlack.insertElementAt(new String("     box = box + "+orange[y][x]+";"),kk[0]+1);
      kk[0]++;
      return;
    }
    //-------------------------------- Subtract --------------------------------
    else if (tabl[y][x] == 17)
    {
      vBlack.insertElementAt(new String("     box = box - "+orange[y][x]+";"),kk[0]+1);
      kk[0]++;
      return;
    }
    //-------------------------------- Multiply --------------------------------
    else if (tabl[y][x] == 18)
    {
      vBlack.insertElementAt(new String("     box = box * "+orange[y][x]+";"),kk[0]+1);
      kk[0]++;
      return;
    }
    //--------------------------------- Divide ---------------------------------
    else if (tabl[y][x] == 19)
    {
      vBlack.insertElementAt(new String("     box = box / "+orange[y][x]+";"),kk[0]+1);
      kk[0]++;
      return;
    }
    //------------------------------ End Program -------------------------------
    else if (tabl[y][x] == 20)
    {
      vBlack.insertElementAt(new String("}"),kk[0]+1);
      vBlack.insertElementAt(new String(""),kk[0]+2);
      kk[0] = kk[0] + 2;
      return;
    }
    //---------------------- Co-Factor of Add & Multiply -----------------------
    else if (tabl[y][x] == 26)
    {
      x = x + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      x = x - 2;
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
    //-------------------------------- Black Box -------------------------------
    else if (tabl[y][x] == 27)
    {
      int[] tempK = new int[1];
      String s = file[y][x].getName();
      ss = s + "()";
      s = s + "();";
      for (int a=0 ; a <= 9 ; a++)
        if (s.equals(FileAlready[a])) ok = false;
      if (ok)
      {
        FileAlready[CountFile] = s;
        CountFile ++;
        for (int k=0 ; k<v.size() ; k++)
          if (v.elementAt(k).equals("void main()"))
          {
            v.insertElementAt(new String("void ")+s,k);
            k = v.size();
          }
        vBlack.insertElementAt(new String("     ")+s,kk[0]+1);
        kk[0]++;
        tempK[0] = vBlack.size();
        vBlack.addElement(new String(""));
        ReadFile fileread = new ReadFile(file[y][x]);
        Black(fileread.tabl,fileread.orange,fileread.CFile,v,tempK,fileread.h,fileread.w);
      }
      else
      {
        vBlack.insertElementAt(new String("     ")+s,kk[0]+1);
        kk[0]++;
        ok = true;
      }
      y = y + 2;
      TranBlack(x,y,tabl,orange,file,v,kk);
      return;
    }
  }
}
