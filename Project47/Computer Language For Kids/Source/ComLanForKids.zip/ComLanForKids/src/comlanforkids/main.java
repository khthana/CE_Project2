package comlanforkids;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class main extends JFrame {
  private JPanel contentPane = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  ImageIcon leftButtonIcon = createImageIcon("images/left.gif");
  private JButton jButton2 = new JButton(leftButtonIcon);
  //private JButton jButton2 = new JButton("images/left.gif");
  private JButton jButton1 = new JButton();
  private TitledBorder titledBorder1;
  private JPanel EditPane = new JPanel();
  private XYLayout xYLayout2 = new XYLayout();
  ImageIcon i = createImageIcon("images/right.gif");
  ImageIcon j = createImageIcon("images/left.gif");
  private JLabel jLabel1 = new JLabel();


  public main() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  protected static ImageIcon createImageIcon(String path) {
    java.net.URL imgURL = main.class.getResource(path);
    if (imgURL != null) {
        return new ImageIcon(imgURL);
    } else {
        System.err.println("Couldn't find file: " + path);
        return null;
    }
    }


  private void jbInit() throws Exception {
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    contentPane.setLayout(xYLayout1);
    this.setSize(new Dimension(600, 600));
    this.setTitle("Computer Languages for Kids");
    contentPane.setBackground(SystemColor.controlHighlight);
    contentPane.setMinimumSize(new Dimension(200, 200));
    contentPane.setPreferredSize(new Dimension(320, 219));
    contentPane.setToolTipText("");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
  public void actionPerformed(ActionEvent e) {
    jButton2_actionPerformed(e);
  }
    });

//    this.getContentPane().add(contentPane, BorderLayout.CENTER);
    jScrollPane1.getViewport().setBackground(Color.white);
    jScrollPane1.setAutoscrolls(true);
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder());
    jScrollPane1.setToolTipText("");

    EditPane.setLayout(xYLayout2);
    EditPane.setBackground(Color.white);

    contentPane.add(jButton2,   new XYConstraints(497, 20, 81, 74));
    contentPane.add(jButton1,    new XYConstraints(20, 22, 81, 74));
    contentPane.add(jScrollPane1, new XYConstraints(115, 110, 364, 369));
    jScrollPane1.getViewport().add(EditPane, null);
    //EditPane.add(jLabel1,       new XYConstraints(0, 0, 60, 60));



    Image A;
    Toolkit tk = getToolkit();
    A = tk.getImage("images/left.gif");

    //A = getImage( getDocumentBase(),"images/left.gif");

    //label.setIcon( createImageIcon("images/bug1.gif") );

    //EditPane.imageUpdate(A,100,100,100,200,200);
    //contentPane.imageUpdate(A,1,10,10,100,100);


   // Icon middleButtonIcon = new SquareIcon();

    //EditPane.add(new JLabel(j));
    //EditPane.add(new JLabel(i));
    //EditPane.


  }


  void jButton2_actionPerformed(ActionEvent e) {
    EditPane.add(jLabel1,       new XYConstraints(0, 0, 60, 60));
    jLabel1.add(new JLabel(j));


  }

}