package comlanforkids;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;

/*
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class GUI extends JFrame
    implements MouseListener, MouseMotionListener, KeyListener{
  private JPanel jPanel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private XYLayout xYLayout2 = new XYLayout();

  ImageIcon Start = createImageIcon("images/start.gif");
  ImageIcon Stop = createImageIcon("images/stop.gif");
  ImageIcon Assign = createImageIcon("images/assign.gif");
  ImageIcon Endif = createImageIcon("images/endif.gif");
  ImageIcon Endleft = createImageIcon("images/endleft.gif");
  ImageIcon Endright = createImageIcon("images/endright.gif");
  ImageIcon Ifmore = createImageIcon("images/ifmore.gif");
  ImageIcon Ifleft = createImageIcon("images/ifleft.gif");
  ImageIcon Ifright = createImageIcon("images/ifright.gif");
  ImageIcon Minus = createImageIcon("images/minus.gif");
  ImageIcon Plus = createImageIcon("images/plus.gif");
  ImageIcon Way = createImageIcon("images/way.gif");
  ImageIcon Slash = createImageIcon("images/slash.gif");
  ImageIcon BackSlash = createImageIcon("images/backslash.gif");

  ImageIcon Loops = createImageIcon("images/loop.gif");
  ImageIcon Endloop = createImageIcon("images/endloop.gif");
  ImageIcon Mul = createImageIcon("images/koon.gif");
  ImageIcon Div = createImageIcon("images/haan.gif");

  ImageIcon Orange = createImageIcon("images/orange.gif");
  ImageIcon background = createImageIcon("images/background.gif");

  ImageIcon Minushaan = createImageIcon("images/minushaan.gif");
  ImageIcon Pluskoon = createImageIcon("images/pluskoon.gif");

  ImageIcon Wayg1 = createImageIcon("images/wayg1.gif");
  ImageIcon Wayg2 = createImageIcon("images/wayg2.gif");
  ImageIcon Wayg3 = createImageIcon("images/wayg3.gif");
  ImageIcon Wayg4 = createImageIcon("images/wayg4.gif");

  ImageIcon BlackBox = createImageIcon("images/blackbox.gif");

  private JButton jButton1 = new JButton(Start);
  private JButton jButton2 = new JButton(Way);
  private JButton jButton3 = new JButton(Assign);
  private JButton jButton4 = new JButton(Orange);
  private JButton jButton5 = new JButton(Slash);
  private JButton jButton6 = new JButton(BackSlash);
  private JButton jButton7 = new JButton(Ifmore);
  private JButton jButton8 = new JButton(Endif);
  private JButton jButton9 = new JButton(Ifleft);
  private JButton jButton10 = new JButton(Ifright);
  private JButton jButton11 = new JButton(Endleft);
  private JButton jButton12 = new JButton(Endright);
  private JButton jButton13 = new JButton(Loops);
  private JButton jButton14 = new JButton(BlackBox);
  private JButton jButton15 = new JButton(Minushaan);
  private JButton jButton16 = new JButton(Plus);
  private JButton jButton17 = new JButton(Minus);
  private JButton jButton18 = new JButton(Mul);
  private JButton jButton19 = new JButton(Div);
  private JButton jButton20 = new JButton(Stop);
  private JButton jButton26 = new JButton(Pluskoon);

  private JPanel jPanel2 = new JPanel();
  private XYLayout xYLayout3 = new XYLayout();

  private JLabel orangepic = new JLabel(Orange);

  private JLabel statusBar;
  static int h = 7;
  static int w = 7;
  private JLabel Background[][];
  private int n = 0;
  private JLabel Block[];
  private boolean IsSetBackground = false;
  private int qualityofpic[][];
  private int typeofpic[];  //0 = no pic
  private int qualityoforange[];

  private JLabel looplabel[];
  //private JLabel arrowlabel[];

  //private int loop[];
  //private int endloop[];
  private int nloop = 0;


  private boolean IsTopLeft[][];

  int Pressnumber = 0;
  int clickX,clickY;
  int Clicknumber = 0;

  private int tabl[][];
  private int table[][];
  private int orange[][];
  private int haveloop[][];
  private JLabel textlabel[];
  private File file[];
  private JLabel filelabel[];
  private JLabel Error;
  boolean err = false;

  //int position[];

  //int time;

  boolean showorange = false;
  //boolean tmporange = true;
  int clickorange = 0;
  private JButton jButton21 = new JButton();
  private JButton jButton22 = new JButton();
  private JButton jButton23 = new JButton();
  private JButton jButton24 = new JButton();
  private JButton jButton25 = new JButton();

  int[] WrongBlock = new int[2];


  private File Name,Nam;

  int norange = 0;
  int l = 0;
  int lx[] = new int[15];
  int ly[] = new int[15];
  int lz[] = new int[15];
  int lxx[] = new int[15];
  int lyy[] = new int[15];
  boolean lb[] = new boolean [15];
  boolean lbb[] = new boolean [15];

  boolean havebox = false;
  int xx = 0;
  int yy = 0;
  int xxx = 0;
  int yyy = 0;
  boolean animetionfinish = true;
  boolean operator = false;


  private JLabel Box;
  private JLabel TextBox;

  int LastX = 0;
  int LastY = 0;

  public GUI() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }


  protected static ImageIcon createImageIcon(String path) {
    java.net.URL imgURL = GUI.class.getResource(path);
    if (imgURL != null) {
      return new ImageIcon(imgURL);
    } else {
      System.err.println("Couldn't find file: " + path);
      return null;
    }
  }

  protected ImageIcon CheckPictures(int i){
    if(i==1)return Start;
    else if (i==2)return Way;
    else if (i==3)return Assign;
    else if (i==4)return Orange;
    else if (i==5)return Slash;
    else if (i==6)return BackSlash;
    else if (i==7)return Ifmore;
    else if (i==8)return Endif;
    else if (i==9)return Ifleft;
    else if (i==10)return Ifright;
    else if (i==11)return Endleft;
    else if (i==12)return Endright;
    else if (i==13)return Loops;
    else if (i==14)return Endloop;
    else if (i==15)return Minushaan;
    else if (i==16)return Plus;
    else if (i==17)return Minus;
    else if (i==18)return Mul;
    else if (i==19)return Div;
    else if (i==20)return Stop;
    else if (i==26)return Pluskoon;
    else if (i==31)return Wayg1;
    else if (i==32)return Wayg2;
    else if (i==33)return Wayg3;
    else if (i==34)return Wayg4;
    else if (i==27)return BlackBox;
    else return background;

  }

  private boolean IsCanPutOrange(int Pic){
    switch (Pic){
      case 3:
      case 4:
      case 7:
      case 13:
      case 16:
      case 17:
      case 18:
      case 19:
        return true;
      default:
        return false;
    }
  }

  private void SetTextPosition(int n,int w, int h,int type,int orange){
    int tmp=0;

    if(IsCanPutOrange(type)&&type!=4){
      textlabel[n].setText(Integer.toString(qualityoforange[qualityofpic[w][h]-1]));
      if(type==3)jPanel2.add( textlabel[n], new XYConstraints(w*30+20, h*30+4, 60, 60) );
      else if(type==7)jPanel2.add( textlabel[n], new XYConstraints(w*30+39, h*30-1, 60, 60) );
      else if(type==13)jPanel2.add( textlabel[n], new XYConstraints(w*30+47, h*30-1, 60, 60) );
      else if(type==16)jPanel2.add( textlabel[n], new XYConstraints(w*30+32, h*30-17, 60, 60) );
      else if(type==17)jPanel2.add( textlabel[n], new XYConstraints(w*30+25, h*30-15, 60, 60) );
      else if(type==18)jPanel2.add( textlabel[n], new XYConstraints(w*30+32, h*30-17, 60, 60) );
      else if(type==19)jPanel2.add( textlabel[n], new XYConstraints(w*30+25, h*30-16, 60, 60) );
    }
    else if(type==4){
      textlabel[n].setText(Integer.toString(qualityoforange[qualityofpic[w][h]-1]));
      jPanel2.add( textlabel[n], new XYConstraints(w*30+10, h*30-15, 60, 60) );
    }
    else{
      textlabel[n].setText("");
      jPanel2.add( textlabel[n], new XYConstraints(w*30+10, h*30, 60, 60) );
    }

  }

  private void SetFilePosition(int n,int w, int h){
    if(typeofpic[n]==27){
      filelabel[n].setText(file[n].getName());
    }
    else{
      filelabel[n].setText("");
    }
    jPanel2.add( filelabel[n], new XYConstraints(w*30+16, h*30-13, 60, 60) );
  }

  private void DeletePic(boolean b){
    n = n - 1;
    int del;
    if(b){
      del = Clicknumber-1;
    }
    else {
      Clicknumber = Pressnumber;
      del = Pressnumber-1;
      Pressnumber = 0;

    }
    jPanel2.remove(Block[del]);
    jPanel2.remove(textlabel[del]);
    jPanel2.remove(filelabel[del]);

    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < del ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }

    for (int i = del ; i < n ; i++){
      tmp[i] = Block[i+1];
      tmp5[i] = typeofpic[i+1];
      tmp6[i] = qualityoforange[i+1];
      tmp2[i] = textlabel[i+1];
      tmp0[i] = file[i+1];
      tmp9[i] = filelabel[i+1];
    }

    Block = new JLabel[n];
    typeofpic = new int[n];
    qualityoforange = new int[n];
    textlabel = new JLabel[n];
    file = new File[n];
    filelabel = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i] ;
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }

    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
      {
        if(Clicknumber == qualityofpic[i][j]){
          qualityofpic[i][j] = 0;
          IsTopLeft[i][j] = false;
        }
        else if(Clicknumber < qualityofpic[i][j]){
          qualityofpic[i][j]--;
        }
      }
      for (int i = 0 ; i < nloop ; i++){
        if(del+1<tmploop[i].pressx){
          tmploop[i].pressx--;
          tmploop[i].pressy--;
        }
      }

      jPanel2.revalidate();
      SetLoop(true);
      SetBackground(w,h);
      Clicknumber = 0;
      Save();
  }
  public void Deleteloop()
  {
    int tmp=-1;
          if(typeofpic[Clicknumber-1]==13){
            tmp = Clicknumber;
            DeletePic(true);
            Clicknumber = tmp;
            DeletePic(true);
          }
          else if(typeofpic[Clicknumber-1]==14){
            tmp = Clicknumber;
            DeletePic(true);
            Clicknumber = tmp-1;
            DeletePic(true);
          }

          int ii=-1;
          for (int i = 0 ; i < nloop ; i++){
            if(tmp == tmploop[i].pressx || tmp == tmploop[i].pressy){
              ii = i;
              break;
            }
          }

          for(int j = 0 ; j < tmploop[ii].nlabelloop ; j ++){
            jPanel2.remove( tmploop[ii].labelloop[j]);

          }


          nloop--;
          Loop tmp7[] = new Loop[nloop];

          for (int i = 0 ; i < ii ; i++){
            tmp7[i] = tmploop[i];
          }
          for (int i = ii ; i < nloop ; i++){
            tmp7[i] = tmploop[i+1];
          }

          tmploop = new Loop[nloop];
          for (int i = 0 ; i < nloop ; i++){
            tmploop[i] = tmp7[i];
          }
          Pressnumber = 0;
  }
  public void keyPressed( KeyEvent event ){
    if(event.getKeyCode() == 127){
      if(Clicknumber!=0){
        if(typeofpic[Clicknumber-1]==13 || typeofpic[Clicknumber-1]==14){
          Deleteloop();
        }
        else DeletePic(true);
      }
    }
    Save();
  }

  public void keyReleased( KeyEvent event ){
  }
  public void keyTyped( KeyEvent event ){
  }


public void FindReleasedBlock(int tmpx,int tmpy){
  boolean bool = true;

  if(tmpx > w*2-1+4 || tmpy > h*2-1+4 || tmpx < -4 || tmpy < -4){
    if(typeofpic[Pressnumber-1]!=13 && typeofpic[Pressnumber-1]!=14){
      DeletePic(false);
    }
    else{
      Clicknumber=Pressnumber;
      Deleteloop();
    }
    bool = false;
  }
  else{

    if(typeofpic[Pressnumber-1]==13){
      int ii = -1;

        for (int i = 0 ; i < nloop ; i++){
          if(Pressnumber == tmploop[i].pressx){
            ii = i;
          }
        }
        if(ii!=-1){
          if(tmpx+tmploop[ii].endloopx-tmploop[ii].loopx > w*2-1+4
             || tmpy+tmploop[ii].endloopy-tmploop[ii].loopy > h*2-1+4
             || tmpx+tmploop[ii].endloopx-tmploop[ii].loopx <0
             || tmpy+tmploop[ii].endloopy-tmploop[ii].loopy <-4
             ){
            Clicknumber=Pressnumber+1;
            Deleteloop();
            bool = false;
          }
        }
    }


if(bool){

    LastX=tmpx;
    LastY=tmpy;
  while(tmpx<0){
    tmpx+=2;
    IncreaseWideX();
  }
  while(tmpy<0){
    tmpy+=2;
    IncreaseHeightX();
  }
  while(tmpx>w*2-1)IncreaseWide();
  while(tmpy>h*2-1)IncreaseHeight();

  if(clickX < 30 && clickY < 30){}
  else if(clickX < 30 && clickY >= 30){
    if(tmpy != 0){
      if(typeofpic[Pressnumber-1] != 14)tmpy--;
      clickY = clickY-30;
    }
  }
  else if(clickX >= 30 && clickY < 30){
    if(tmpx != 0){
      if(typeofpic[Pressnumber-1] != 14)tmpx--;
      clickX = clickX-30;
    }
  }
  else if(clickX >= 30 && clickY >= 30){
    if(tmpx != 0){
      if(typeofpic[Pressnumber-1] != 14)tmpx--;
      clickX = clickX-30;
    }
    if(tmpy != 0){
      if(typeofpic[Pressnumber-1] != 14)tmpy--;
      clickY = clickY-30;
    }
  }


  int ii=-1;
  if(typeofpic[Pressnumber-1] == 14){
    for (int i = 0 ; i < nloop ; i++){
      if(Pressnumber == tmploop[i].pressy){
        ii = i;
      }
    }
    int[] xyloop = new int [2];
    xyloop[0] = tmploop[ii].loopx;
    xyloop[1] = tmploop[ii].loopy;
    if(xyloop[0]%2==0 && xyloop[1]%2==0){
      if(tmpx%2!=0)tmpx--;
      if(tmpy%2!=0)tmpy--;
    }
    else if(xyloop[0]%2==0 && xyloop[1]%2==1){
      if(tmpx%2!=0)tmpx--;
      if(tmpy%2!=1)tmpy--;
    }
    else if(xyloop[0]%2==1 && xyloop[1]%2==0){
      if(tmpx%2!=1)tmpx--;
      if(tmpy%2!=0)tmpy--;
    }
    else if(xyloop[0]%2==1 && xyloop[1]%2==1){
      if(tmpx%2!=1)tmpx--;
      if(tmpy%2!=1)tmpy--;
    }
    while(tmpy <= xyloop[1])tmpy = tmpy + 2;
  }

  if(typeofpic[Pressnumber-1] == 13){
      for (int i = 0 ; i < nloop ; i++){
        if(Pressnumber == tmploop[i].pressx){
          ii = i;
        }
    }
  }
  if((tmpx==w*2-1 || tmpx==w*2-2) && (tmpy==h*2-1 || tmpy==h*2-2)){ IncreaseHeight(); IncreaseWide(); }
  else if((tmpx==w*2-1 || tmpx==w*2-2) && qualityofpic[tmpx][tmpy+1] == 0)IncreaseWide();
  else if((tmpy==h*2-1 || tmpy==h*2-2) && qualityofpic[tmpx+1][tmpy] == 0)IncreaseHeight();

  boolean q = false;
  if(tmpx<0){
    IncreaseWideX();
    tmpx = tmpx + 2;
  }
  if(tmpy<0){
    IncreaseHeightX();
    tmpy = tmpy + 2;
  }

  if(typeofpic[Pressnumber-1]==14 || typeofpic[Pressnumber-1]==13){
    if(tmpx == 0 || tmpx == 1){
        IncreaseWideX();
        tmpx = tmpx+2;
    }
  }

  if(qualityofpic[tmpx][tmpy] != 0){
    if(typeofpic[Pressnumber-1]==4 && (IsCanPutOrange(typeofpic[qualityofpic[tmpx][tmpy]-1])) ){
      qualityoforange[qualityofpic[tmpx][tmpy]-1]
          = qualityoforange[qualityofpic[tmpx][tmpy]-1] + qualityoforange[Pressnumber-1];
      SetTextPosition(qualityofpic[tmpx][tmpy]-1,tmpx,tmpy,typeofpic[qualityofpic[tmpx][tmpy]-1],qualityoforange[qualityofpic[tmpx][tmpy]-1]);
      SetFilePosition(qualityofpic[tmpx][tmpy]-1,tmpx,tmpy);
      Clicknumber = Pressnumber;
      DeletePic(true);
      Pressnumber = 0;

    }
    else q= true;
  }
  else q= true;
  if(q==true){
    if((qualityofpic[tmpx][tmpy] == 0 && qualityofpic[tmpx][tmpy+1] == 0 &&
        qualityofpic[tmpx+1][tmpy] == 0 && qualityofpic[tmpx+1][tmpy+1] == 0 ) ||
        (qualityofpic[tmpx][tmpy] == 0 && typeofpic[Pressnumber-1]==4)){

      if(typeofpic[Pressnumber-1]!=4){

        qualityofpic[tmpx][tmpy]=Pressnumber;
        qualityofpic[tmpx+1][tmpy]=Pressnumber;
        qualityofpic[tmpx][tmpy+1]=Pressnumber;
        qualityofpic[tmpx+1][tmpy+1]=Pressnumber;
        IsTopLeft[tmpx][tmpy]=true;

        if(typeofpic[Pressnumber-1]==13){
            for (int i = 0 ; i < nloop ; i++){
              if(Pressnumber == tmploop[i].pressx){
                ii = i;
              }
            }
            int t=0;
            while(tmploop[ii].loopx>tmploop[ii].endloopx+t){
              t=t+2;
              IncreaseWideX();
              tmpx = tmpx+2;
            }

          int tmpxx = tmploop[ii].loopx;
          int tmpyy = tmploop[ii].loopy;
          tmploop[ii].loopx = tmpx;
          tmploop[ii].loopy = tmpy;

          Pressnumber++;

          FindReleasedBlock(tmpx+tmploop[ii].endloopx-tmpxx,tmpy+tmploop[ii].endloopy-tmpyy);
          Pressnumber--;
        }
        else
          if(typeofpic[Pressnumber-1]==14){
          tmploop[ii].endloopx = tmpx;
          tmploop[ii].endloopy = tmpy;
        }
      }

      else {
        qualityofpic[tmpx][tmpy]=Pressnumber;
        IsTopLeft[tmpx][tmpy]=true;
      }

      jPanel2.remove(Block[Pressnumber-1]);
      jPanel2.remove(textlabel[Pressnumber-1]);
      jPanel2.remove(filelabel[Pressnumber-1]);
      SetTextPosition(Pressnumber-1,tmpx,tmpy,typeofpic[Pressnumber-1],qualityoforange[qualityofpic[tmpx][tmpy]-1]);
      SetFilePosition(Pressnumber-1,tmpx,tmpy);
      Block[Pressnumber-1] = new JLabel(CheckPictures(typeofpic[Pressnumber-1]));
      if(typeofpic[Pressnumber-1]!=4){
        jPanel2.add( Block[Pressnumber-1], new XYConstraints(tmpx*30, tmpy*30, 60, 60) );
      }
      else {
        jPanel2.add( Block[Pressnumber-1], new XYConstraints(tmpx*30, tmpy*30, 30, 30) );
      }

    }
    else{
      if(typeofpic[Pressnumber-1] != 14){
      if(qualityofpic[tmpx+1][tmpy] == 0 && qualityofpic[tmpx+1][tmpy+1] == 0 )
        FindReleasedBlock(tmpx+1,tmpy);
      else if(qualityofpic[tmpx][tmpy+1] == 0 && qualityofpic[tmpx+1][tmpy+1] == 0 )
        FindReleasedBlock(tmpx,tmpy+1);
      else if(qualityofpic[tmpx+1][tmpy+1] == 0 )
        FindReleasedBlock(tmpx+1,tmpy+1);
      else FindReleasedBlock(tmpx+1,tmpy);
      }else{
        FindReleasedBlock(tmpx+2,tmpy);
      }
    }

}
  }
}
  deletenotuse();

}
private void deletenotuse(){
  if(w>7){
    boolean u = true;
    for(int i = w*2 -2;i>10&&u;i-=2){
      for(int j = 0;j<h*2;j++){
        if(qualityofpic[i][j]!=0)u = false;
        if(qualityofpic[i+1][j]!=0)u = false;
      }
      if(u){
        DecreaseWide();
      }
    }
  }

  if(h>7){
    boolean u = true;
    for(int i = h*2 -2;i>10&&u;i-=2){
      for(int j = 0;j<w*2;j++){
        if(qualityofpic[j][i]!=0)u = false;
        if(qualityofpic[j][i+1]!=0)u = false;
      }
      if(u){
        DecreaseHeight();
      }
    }
  }
}


  // MouseListener event handlers
   // handle event when mouse released immediately after press
   public void mouseClicked( MouseEvent event )
   {
      if(animetionfinish){
      int x = event.getX();
      int y = event.getY();
      int tmpx = 0;
      int tmpy = 0;

      //int tmpz;
      while(x>=30){
        tmpx++;
        x=x-30;
      }

      while(y>=30){
        tmpy++;
        y=y-30;
      }
      LastX=tmpx;
      LastY=tmpy;
      if(tmpx < w*2 && tmpy < h*2)
      if(qualityofpic[tmpx][tmpy]!=0){
        Clicknumber = qualityofpic[tmpx][tmpy];
      }

      if(Clicknumber != 0 )
        if((qualityoforange[Clicknumber-1] != 0 && typeofpic[Clicknumber-1] != 19) ||
           (qualityoforange[Clicknumber-1] != 1 && typeofpic[Clicknumber-1] == 19))
      if(IsCanPutOrange(typeofpic[Clicknumber-1]) && typeofpic[Clicknumber-1] != 4){
        if(!showorange
           ){

          jPanel2.add( orangepic, new XYConstraints(tmpx*30, tmpy*30, 30, 30) );
          showorange = true;
          if(typeofpic[Clicknumber-1] == 19){
            if( clickorange < qualityoforange[Clicknumber-1]-1){clickorange++;}}
          else if(clickorange < qualityoforange[Clicknumber-1])clickorange++;

          jPanel2.revalidate();
          SetOther(w,h,0);
          SetLoop(true);
          SetBackground(w,h);
          orangepic.show();

        }

      }

   }

   }

   // handle event when mouse pressed
   public void mousePressed( MouseEvent event )
   {

      if(animetionfinish){
      int x = event.getX();
      int y = event.getY();

      int tmpx = 0;
      int tmpy = 0;

      while(x>=30){
        tmpx++;
        x=x-30;
      }

      while(y>=30){
        tmpy++;
        y=y-30;
      }
      if(tmpx < w*2 && tmpy < h*2)
      if(qualityofpic[tmpx][tmpy]!=0){
        if(!showorange){

          Pressnumber = qualityofpic[tmpx][tmpy];

          if(typeofpic[Pressnumber-1]!=4){
            if(tmpx == w*2-1)clickX = x+30;
            else if(qualityofpic[tmpx][tmpy] == qualityofpic[tmpx+1][tmpy])clickX = x;
            else clickX = x+30;
            if(tmpy == h*2-1)clickY = y+30;
            else if(qualityofpic[tmpx][tmpy] == qualityofpic[tmpx][tmpy+1])clickY = y;
            else clickY = y+30;
            }else {clickX = x; clickY = y;}

            if(typeofpic[Pressnumber-1]!=4){
              int type;
              if(tmpx == w*2-1 && tmpy == h*2-1)type = 4;
              else if(tmpx == w*2-1){
                if (qualityofpic[tmpx][tmpy] == qualityofpic[tmpx][tmpy+1])type = 3;
                else type = 4;
              }
              else if(tmpy == h*2-1){
                if (qualityofpic[tmpx][tmpy] == qualityofpic[tmpx+1][tmpy])type = 2;
                else type = 4;
              }else{
                if(qualityofpic[tmpx][tmpy] == qualityofpic[tmpx+1][tmpy] &&
                   qualityofpic[tmpx][tmpy] == qualityofpic[tmpx][tmpy+1])type = 1;
                else if(qualityofpic[tmpx][tmpy] == qualityofpic[tmpx+1][tmpy] &&
                        qualityofpic[tmpx][tmpy] != qualityofpic[tmpx][tmpy+1])type = 2;
                else if(qualityofpic[tmpx][tmpy] != qualityofpic[tmpx+1][tmpy] &&
                        qualityofpic[tmpx][tmpy] == qualityofpic[tmpx][tmpy+1])type = 3;
                else type = 4;
              }

              if (type == 1){
                qualityofpic[tmpx][tmpy] = 0;
                qualityofpic[tmpx+1][tmpy] = 0;
                qualityofpic[tmpx][tmpy+1] = 0;
                qualityofpic[tmpx+1][tmpy+1] = 0;
                IsTopLeft[tmpx][tmpy]=false;
              }
              else if (type == 2){
                qualityofpic[tmpx][tmpy] = 0;
                qualityofpic[tmpx+1][tmpy] = 0;
                qualityofpic[tmpx][tmpy-1] = 0;
                qualityofpic[tmpx+1][tmpy-1] = 0;
                IsTopLeft[tmpx][tmpy-1]=false;
              }
              else if (type == 3){
                qualityofpic[tmpx][tmpy] = 0;
                qualityofpic[tmpx-1][tmpy] = 0;
                qualityofpic[tmpx][tmpy+1] = 0;
                qualityofpic[tmpx-1][tmpy+1] = 0;
                IsTopLeft[tmpx-1][tmpy]=false;
              }
              else{
                qualityofpic[tmpx][tmpy] = 0;
                qualityofpic[tmpx-1][tmpy] = 0;
                qualityofpic[tmpx][tmpy-1] = 0;
                qualityofpic[tmpx-1][tmpy-1] = 0;
                IsTopLeft[tmpx-1][tmpy-1]=false;
              }
              int ii = -1;
              if(typeofpic[Pressnumber-1] == 13){
                for (int i = 0 ; i < nloop ; i++){
                  if(Pressnumber == tmploop[i].pressx){
                    ii = i;
                  }
                }
                if(ii!=-1){
                qualityofpic[tmploop[ii].endloopx][tmploop[ii].endloopy] = 0;
                qualityofpic[tmploop[ii].endloopx+1][tmploop[ii].endloopy] = 0;
                qualityofpic[tmploop[ii].endloopx][tmploop[ii].endloopy+1] = 0;
                qualityofpic[tmploop[ii].endloopx+1][tmploop[ii].endloopy+1] = 0;
                IsTopLeft[tmploop[ii].endloopx][tmploop[ii].endloopy]=false;
                }
              }
            }
            else{
              qualityofpic[tmpx][tmpy] = 0;
              IsTopLeft[tmpx][tmpy]=false;
            }

        }
        else{

          showorange = false;
          jPanel2.remove(orangepic);
          jPanel2.revalidate();
          SetOther(w,h,0);
          SetLoop(true);
          SetBackground(w,h);
          JLabel tmp[] = new JLabel[n];
          int tmp5[] = new int[n];
          int tmp6[] = new int[n];
          JLabel tmp2[] = new JLabel[n];
          File tmp0[] = new File[n];
          JLabel tmp9[] = new JLabel[n];

          for (int i = 0 ; i < n ; i++){
            tmp[i] = Block[i];
            tmp5[i] = typeofpic[i];
            tmp6[i] = qualityoforange[i];
            tmp2[i] = textlabel[i];
            tmp0[i] = file[i];
            tmp9[i] = filelabel[i];
          }
          Block = new JLabel[n+1];
          typeofpic = new int[n+1];
          qualityoforange = new int[n+1];
          textlabel = new JLabel[n+1];
          file = new File[n+1];
          filelabel = new JLabel[n+1];

          for (int i = 0 ; i < n ; i++){
            Block[i] = tmp[i];
            typeofpic[i] = tmp5[i];
            qualityoforange[i] = tmp6[i];
            textlabel[i] = tmp2[i];
            file[i] = tmp0[i];
            filelabel[i] = tmp9[i];
          }
          typeofpic[n]=4;
          qualityoforange[n]=clickorange;
          Block[n] = new JLabel(Orange);
          textlabel[n] = new JLabel("");
          filelabel[n] = new JLabel("");

          Pressnumber = n+1;


          qualityoforange[qualityofpic[tmpx][tmpy]-1] = qualityoforange[qualityofpic[tmpx][tmpy]-1]-clickorange;

          jPanel2.add( Block[Pressnumber-1], new XYConstraints(tmpx*30, tmpy*30, 30, 30) );

          n = n + 1;
          jPanel2.revalidate();
          SetOther(w,h,n);
          SetLoop(true);
          SetBackground(w,h);
          filelabel[n-1].show();
          textlabel[n-1].show();
          Block[n-1].show();

        }

      }

      }
      Save();
   }

   // handle event when mouse released after dragging
   public void mouseReleased( MouseEvent event )
   {
      //mouseAfterReleased(event.getX(),event.getY());

    if(Pressnumber!=0){

      int x=event.getX();
      int y=event.getY();
      int tmpxx = x;
      int tmpyy = y;
      int tmpx = 0;
      int tmpy = 0;

        if(x>0){
          while(x>=30){
            tmpx++;
            x=x-30;
          }
        }else{
          while(x<=-30){
            tmpx--;
            x=x+30;
          }
        }
        if(y>0){
          while(y>=30){
            tmpy++;
            y=y-30;
          }
        }else{
          while(y<=30){
            tmpy--;
            y=y+30;
          }
        }

        if( typeofpic[Pressnumber-1] != 14){
          FindReleasedBlock(tmpx,tmpy);
        }else if(typeofpic[Pressnumber-1] != 13){
          FindReleasedBlock(tmpx,tmpy);
        }else{
        }

        jPanel2.revalidate();
        SetOther(w,h,Pressnumber);
        SetLoop(true);
        SetBackground(w,h);

        if (Pressnumber != 0) {
          filelabel[Pressnumber-1].show();
          textlabel[Pressnumber-1].show();
          Block[Pressnumber-1].show();
        }
      }

      Clicknumber = Pressnumber;
      Pressnumber = 0;

      Save();



      jPanel2.revalidate();
      SetOther(w,h,0);
      SetLoop(true);
      SetBackground(w,h);
   }

   // handle event when mouse enters area
   public void mouseEntered( MouseEvent event )
   {
   }

   // handle event when mouse exits area
   public void mouseExited( MouseEvent event )
   {
      //statusBar.setText( "Mouse outside window" );
      //getContentPane().setBackground( Color.white );
   }

   // MouseMotionListener event handlers
   // handle event when user drags mouse with button pressed
   public void mouseDragged( MouseEvent event )
   {
      if(Pressnumber!=0){
          int x = event.getX();
          int y = event.getY();

          jPanel2.remove(Block[Pressnumber-1]);
          jPanel2.remove(textlabel[Pressnumber-1]);
          jPanel2.remove(filelabel[Pressnumber-1]);
          Block[Pressnumber-1] = new JLabel(CheckPictures(typeofpic[Pressnumber-1]));

          if(typeofpic[Pressnumber-1] == 27)
            filelabel[Pressnumber-1].setText(file[Pressnumber-1].getName());
          else filelabel[Pressnumber-1].setText("");

          if(IsCanPutOrange(typeofpic[Pressnumber-1]))
            textlabel[Pressnumber-1].setText(Integer.toString(qualityoforange[Pressnumber-1]));
          else textlabel[Pressnumber-1].setText("");

          if(typeofpic[Pressnumber-1] != 13 && typeofpic[Pressnumber-1] != 14){

            if(typeofpic[Pressnumber-1] != 4 ){
              jPanel2.add( filelabel[Pressnumber-1], new XYConstraints((x-clickX)+16, (y-clickY)-13, 60, 60) );
              switch (typeofpic[Pressnumber-1]){
                case 3:
                  jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+20, (y-clickY)+19, 30, 30) );
                  break;
                case 7:
                  jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+39, (y-clickY)+14, 30, 30) );
                  break;
                case 16:
                case 18:
                  jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+32, (y-clickY)-2, 30, 30) );
                  break;
                case 17:
                  jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+25, (y-clickY), 30, 30) );
                  break;
                case 19:
                  jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+25, (y-clickY)-1, 30, 30) );
                  break;
                default:
                  jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+10, (y-clickY), 60, 60) );
              }

              jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-clickX, y-clickY, 60, 60) );
            }
            else{
              jPanel2.add( filelabel[Pressnumber-1], new XYConstraints((x-clickX)+10, (y-clickY), 60, 60) );
              jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+10, (y-clickY), 30, 30) );
              jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-clickX, y-clickY, 30, 30) );
            }

          }
          else{
            if(typeofpic[Pressnumber-1] == 14){
              int ii=-1;
              for (int i = 0 ; i < nloop ; i++){
                if(Pressnumber == tmploop[i].pressy){
                  ii = i;
                }
              }
              int[] xyloop = new int [2];
              xyloop[0] = tmploop[ii].loopx;
              xyloop[1] = tmploop[ii].loopy;
              if(xyloop[0]%2==0 && xyloop[1]%2==0){
                if((y-(y%60)) <= xyloop[1]*30+60){
                  jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-(x%60), xyloop[1]*30+60, 60, 60) );
                }
                else jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-(x%60), y-(y%60), 60, 60) );
              }
              else if(xyloop[0]%2==0 && xyloop[1]%2==1){
                if((y-((y+30)%60)) <= xyloop[1]*30+60){
                  jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-(x%60), xyloop[1]*30+60, 60, 60) );
                }
                else jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-(x%60), y-((y+30)%60), 60, 60) );
              }
              else if(xyloop[0]%2==1 && xyloop[1]%2==0){
                if((y-(y%60)) <= xyloop[1]*30+60){
                  jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-((x+30)%60), xyloop[1]*30+60, 60, 60) );
                }
                else jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-((x+30)%60), y-(y%60), 60, 60) );
              }
              else if(xyloop[0]%2==1 && xyloop[1]%2==1){
                if((y-((y+30)%60)) <= xyloop[1]*30+60){
                  jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-((x+30)%60), xyloop[1]*30+60, 60, 60) );
                }
                else jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-((x+30)%60), y-((y+30)%60), 60, 60) );
              }
            }
            else{


              int ii=-1;
              for (int i = 0 ; i < nloop ; i++){
                if(Pressnumber == tmploop[i].pressx){
                  ii = i;
                }
              }

              int[] xyloop = new int [2];
              xyloop[0] = tmploop[ii].loopx;
              xyloop[1] = tmploop[ii].loopy;

              int[] xyendloop = new int [2];
              xyendloop[0] = tmploop[ii].endloopx;
              xyendloop[1] = tmploop[ii].endloopy;

              jPanel2.remove(Block[Pressnumber]);
              Block[Pressnumber] = new JLabel(Endloop);

              jPanel2.add( filelabel[Pressnumber-1], new XYConstraints((x-clickX)+10, (y-clickY), 60, 60) );
              jPanel2.add( textlabel[Pressnumber-1], new XYConstraints((x-clickX)+47, (y-clickY)-1, 60, 60) );
              jPanel2.add( Block[Pressnumber-1], new XYConstraints(x-clickX, y-clickY, 60, 60) );

              jPanel2.add( Block[Pressnumber], new XYConstraints(x-clickX+(xyendloop[0]-xyloop[0])*30, y-clickY+(xyendloop[1]-xyloop[1])*30, 60, 60) );
            }
          }
          jPanel2.revalidate();
          SetOther(w,h,Pressnumber);
          SetLoop(true);
          SetBackground(w,h);
          filelabel[Pressnumber-1].show();
          textlabel[Pressnumber-1].show();
          Block[Pressnumber-1].show();

      }
   }

   // handle event when user moves mouse
   public void mouseMoved( MouseEvent event )
   {
      //statusBar.setText( "Moved at [" + event.getX() + ", " + event.getY() + "]" );
      if(showorange){
        showorange = false;
        clickorange = 0;
        jPanel2.remove(orangepic);
        jPanel2.revalidate();
        SetOther(w,h,0);
        SetLoop(true);
        SetBackground(w,h);
      }
      clickorange = 0;
   }

//================================= Main =======================================
  public static void main(String[] args) throws IOException {
    GUI GUI1 = new GUI();
    GUI1.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }

  private void jbInit() throws Exception {

    this.setResizable(false);
    this.setSize(new Dimension(820, 700));

    this.getContentPane().setLayout(xYLayout2);
    this.setTitle("Computer Languages for Kids");
    jButton21.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton21.setText("New");
    jButton22.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton22.setText("Open");
    jButton23.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton23.setText("Save");
    jButton24.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton24.setActionCommand("Run by Step");
    jButton24.setText("Run by Step");
    jButton25.setEnabled(false);
    jButton25.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton25.setText("Next");
    jButton26.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton26.setMaximumSize(new Dimension(5, 5));
    jButton26.setMinimumSize(new Dimension(5, 5));
    jButton26.setToolTipText("Use with \"Plus\" or \"Multiplication\"");
    jButton1.setToolTipText("Begin");
    jButton3.setToolTipText("Assign the value");
    jButton4.setToolTipText("Orange for add value");
    jButton7.setToolTipText("If");
    jButton8.setToolTipText("End if");
    jButton20.setToolTipText("End");
    jButton13.setToolTipText("Loop");
    jButton16.setToolTipText("\"+\" Plus");
    jButton17.setToolTipText("\"-\" Substract");
    jButton18.setToolTipText("\"x\" Multiplication");
    jButton19.setToolTipText("\"/\" Division");
    jButton15.setToolTipText("Use with \"Substract\" or \"Division\"");
    jButton14.setToolTipText("End loop");
    jButton2.setToolTipText("Path");
    jButton5.setToolTipText("Path");
    jButton6.setToolTipText("Path");
    jButton9.setToolTipText("Path");
    jButton10.setToolTipText("Path");
    jButton11.setToolTipText("Path");
    jButton12.setToolTipText("Path");
    jButton27.setText("Stop");
    jButton27.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton27.setActionCommand("Stop");
    jButton27.setEnabled(false);
    jButton28.setText("Run by Result");
    jButton28.setActionCommand("Run by Result");
    jButton28.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton29.setText("Convert to C");
    jButton29.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton29.setActionCommand("Convert to C");

    jPanel1.setLayout(xYLayout1);
    xYLayout2.setWidth(810);
    xYLayout2.setHeight(700);
    jPanel1.add(jScrollPane1,  new XYConstraints(110, 110, 450, 450));
    jPanel1.add(jButton1, new XYConstraints(20, 20, 70, 70));
    jPanel1.add(jButton2, new XYConstraints(132, 20, 70, 70));
    jPanel1.add(jButton3, new XYConstraints(240, 20, 70, 70));
    jPanel1.add(jButton4, new XYConstraints(319, 40, 32, 32));
    jPanel1.add(jButton5, new XYConstraints(20, 132, 70, 70));
    jPanel1.add(jButton6, new XYConstraints(580, 132, 70, 70));
    jPanel1.add(jButton7, new XYConstraints(360, 20, 70, 70));
    jPanel1.add(jButton9, new XYConstraints(20, 244, 70, 70));
    jPanel1.add(jButton10, new XYConstraints(580, 244, 70, 70));
    jPanel1.add(jButton11, new XYConstraints(20, 356, 70, 70));
    jPanel1.add(jButton12, new XYConstraints(580, 356, 70, 70));
    jPanel1.add(jButton13, new XYConstraints(20, 468, 70, 70));
    jPanel1.add(jButton14, new XYConstraints(580, 468, 70, 70));
    jPanel1.add(jButton15, new XYConstraints(580, 580, 70, 70));
    jPanel1.add(jButton16, new XYConstraints(132, 580, 70, 70));
    jPanel1.add(jButton17, new XYConstraints(244, 580, 70, 70));
    jPanel1.add(jButton18, new XYConstraints(356, 580, 70, 70));
    jPanel1.add(jButton19, new XYConstraints(468, 580, 70, 70));
    jPanel1.add(jButton20, new XYConstraints(580, 20, 70, 70));
    jPanel1.add(jButton23, new XYConstraints(680, 104, 115, 28));
    jPanel1.add(jButton26, new XYConstraints(20, 580, 70, 70));
    jPanel1.add(jButton8, new XYConstraints(468, 20, 70, 70));
    jPanel1.add(jButton21, new XYConstraints(680, 24, 115, 28));
    jPanel1.add(jButton22, new XYConstraints(680, 64, 115, 28));
    jPanel1.add(jButton27,  new XYConstraints(683, 340, 106, 19));
    jPanel1.add(jButton25, new XYConstraints(683, 306, 106, 19));
    jPanel1.add(jButton24,  new XYConstraints(681, 251, 115, 28));
    jPanel1.add(jButton28,   new XYConstraints(681, 190, 115, 28));
    jPanel1.add(jButton29,   new XYConstraints(682, 149, 115, 28));
    jScrollPane1.getViewport().add(jPanel2, null);

    jButton1.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton2.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton3.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton4.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton5.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton6.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton7.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton8.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton9.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton10.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton11.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton12.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton13.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton14.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton15.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton16.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton17.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton18.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton19.setBorder(BorderFactory.createRaisedBevelBorder());
    jButton20.setBorder(BorderFactory.createRaisedBevelBorder());

    jScrollPane1.setBorder(BorderFactory.createLineBorder(Color.black));
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    jPanel2.setLayout(xYLayout3);
    jPanel2.setBackground(Color.white);


    statusBar = new JLabel();

    this.getContentPane().add(jPanel1, new XYConstraints(2, 0, -1, -1));
    jPanel2.addMouseListener( this );        // listens for own mouse and
    jPanel2.addMouseMotionListener( this );  // mouse-motion events
    addKeyListener( this );
    setVisible( true );

    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });

    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });


    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });

    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });

    jButton5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton5_actionPerformed(e);
      }
    });

    jButton6.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton6_actionPerformed(e);
      }
    });

    jButton7.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton7_actionPerformed(e);
      }
    });

    jButton8.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton8_actionPerformed(e);
      }
    });

    jButton9.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton9_actionPerformed(e);
      }
    });

    jButton10.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton10_actionPerformed(e);
      }
    });

    jButton11.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton11_actionPerformed(e);
      }
    });

    jButton12.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton12_actionPerformed(e);
      }
    });

    jButton13.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton13_actionPerformed(e);
      }
    });

    jButton14.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton14_actionPerformed(e);
      }
    });

    jButton15.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton15_actionPerformed(e);
      }
    });

    jButton16.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton16_actionPerformed(e);
      }
    });

    jButton17.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton17_actionPerformed(e);
      }
    });

    jButton18.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton18_actionPerformed(e);
      }
    });

    jButton19.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton19_actionPerformed(e);
      }
    });

    jButton20.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton20_actionPerformed(e);
      }
    });

    jButton21.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton21_actionPerformed(e);
      }
    });

    jButton22.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton22_actionPerformed(e);
      }
    });

    jButton23.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try {
          jButton23_actionPerformed(e);
        }
        catch(IOException E) {
          E.printStackTrace();
        }
      }
    });

    jButton24.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton24_actionPerformed(e);
      }
    });


    jButton25.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton25_actionPerformed(e);
      }
    });

    jButton26.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton26_actionPerformed(e);
      }
    });
    jButton27.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton27_actionPerformed(e);
      }
    });
    jButton28.addActionListener(new java.awt.event.ActionListener() {
  public void actionPerformed(ActionEvent e) {
    jButton28_actionPerformed(e);
  }
    });
    jButton29.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try {
          jButton29_actionPerformed(e);
        }
        catch(IOException E) {
          E.printStackTrace();
        }
      }
    });

    qualityofpic = new int[w*2][h*2];
    IsTopLeft = new boolean[w*2][h*2];
    tabl = new int[h*2][w*2];
    orange = new int[h*2][w*2];
    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
           qualityofpic[i][j] = 0;
           IsTopLeft[i][j] = false;
           tabl[j][i] = 0;
           orange[j][i] = 0;
        }

    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    jPanel2.revalidate();
  }

  void WhenAddNewPic(int x,int y){
    if(typeofpic[n]==4){
      if(qualityofpic[x][y] == 0){
        qualityofpic[x][y]=n+1;
        IsTopLeft[x][y]=true;
        SetTextPosition(n,x,y,typeofpic[n],qualityoforange[n]);
        SetFilePosition(n,x,y);
      }else {
        while(x+2 > w*2-1){
            IncreaseWide();
        }
        if(qualityofpic[x+1][y] == 0){
          qualityofpic[x+1][y]=n+1;
          IsTopLeft[x+1][y]=true;
          SetTextPosition(n,x+1,y,typeofpic[n],qualityoforange[n]);
          SetFilePosition(n,x+1,y);
        }
        else if(qualityofpic[x+2][y] == 0){
          qualityofpic[x+2][y]=n+1;
          IsTopLeft[x+2][y]=true;
          SetTextPosition(n,x+2,y,typeofpic[n],qualityoforange[n]);
          SetFilePosition(n,x+2,y);
        }
        else{
          while(y+2 > h*2-1){
            IncreaseHeight();
          }
          if(qualityofpic[x][y+1] == 0){
            qualityofpic[x][y+1]=n+1;
            IsTopLeft[x][y+1]=true;
            SetTextPosition(n,x,y+1,typeofpic[n],qualityoforange[n]);
            SetFilePosition(n,x,y+1);
          }
          else if(qualityofpic[x][y+2] == 0){
            qualityofpic[x][y+2]=n+1;
            IsTopLeft[x][y+2]=true;
            SetTextPosition(n,x,y+2,typeofpic[n],qualityoforange[n]);
            SetFilePosition(n,x,y+2);
          }
          else{
            if(x-1<0){
              IncreaseWideX();
              x = x+2;
            }
            if(qualityofpic[x-1][y] == 0){
              qualityofpic[x-1][y]=n+1;
              IsTopLeft[x-1][y]=true;
              SetTextPosition(n,x-1,y,typeofpic[n],qualityoforange[n]);
              SetFilePosition(n,x-1,y);
            }
            else {
              if(y-1<0){
                IncreaseHeightX();
                y = y+2;
              }
              if(qualityofpic[x][y-1] == 0){
                qualityofpic[x][y-1]=n+1;
                IsTopLeft[x][y-1]=true;
                SetTextPosition(n,x,y-1,typeofpic[n],qualityoforange[n]);
                SetFilePosition(n,x,y-1);
              }
              else WhenAddNewPic(x,y+1);
            }
          }
        }
      }
    }
    else{
      while(x+1 > w*2-1){
        IncreaseWide();
      }
      while(y+2 >= h*2-1){
        IncreaseHeight();
      }
      while(x < 0){
        IncreaseWideX();
        x = x+2;
      }
      while(y < 0){
        IncreaseHeightX();
        y = y+2;
      }

      if(typeofpic[n]==14 || typeofpic[n]==13){
        if(x == 0 || x == 1){
          IncreaseWideX();
          x = x+2;
        }
      }

      if(qualityofpic[x][y] == 0 && qualityofpic[x+1][y] == 0 && qualityofpic[x][y+1] == 0
         && qualityofpic[x+1][y+1] == 0){
             qualityofpic[x+1][y]=n+1;
             qualityofpic[x][y+1]=n+1;
             qualityofpic[x+1][y+1]=n+1;
             qualityofpic[x][y]=n+1;
             IsTopLeft[x][y]=true;
             SetTextPosition(n,x,y,typeofpic[n],qualityoforange[n]);
             SetFilePosition(n,x,y);
      }else{
        if(x+2 > w*2-1 && !(x+1 > w*2-1)){
        IncreaseWide();
        }
        if(typeofpic[n]==14){
          if(x+3 >= w*2-1){
            IncreaseWide();
          }
          if(qualityofpic[x+2][y] == 0 && qualityofpic[x+3][y] == 0 && qualityofpic[x+2][y+1] == 0
             && qualityofpic[x+3][y+1] == 0){
            qualityofpic[x+2][y]=n+1;
            qualityofpic[x+3][y+1]=n+1;
            qualityofpic[x+2][y+1]=n+1;
            qualityofpic[x+3][y]=n+1;
            IsTopLeft[x+2][y]=true;
          }
          else WhenAddNewPic(x,y+2);
        }
        else{
          if(qualityofpic[x+1][y] == 0 && qualityofpic[x+2][y] == 0 && qualityofpic[x+1][y+1] == 0
             && qualityofpic[x+2][y+1] == 0){
            qualityofpic[x+1][y]=n+1;
            qualityofpic[x+2][y+1]=n+1;
            qualityofpic[x+1][y+1]=n+1;
            qualityofpic[x+2][y]=n+1;
            IsTopLeft[x+1][y]=true;
            SetTextPosition(n,x+1,y,typeofpic[n],qualityoforange[n]);
            SetFilePosition(n,x+1,y);
          }
          else{
            if(x+2 >= w*2-1 && !(x+2 > w*2-1 && !(x+1 > w*2-1)) && !(x+1 > w*2-1)){
              IncreaseWide();
          }
            if(qualityofpic[x+2][y] == 0 && qualityofpic[x+3][y] == 0 && qualityofpic[x+2][y+1] == 0
               && qualityofpic[x+3][y+1] == 0){
              qualityofpic[x+3][y]=n+1;
              qualityofpic[x+2][y+1]=n+1;
              qualityofpic[x+3][y+1]=n+1;
              qualityofpic[x+2][y]=n+1;
              IsTopLeft[x+2][y]=true;
              SetTextPosition(n,x+2,y,typeofpic[n],qualityoforange[n]);
              SetFilePosition(n,x+2,y);
            }
            else{
              if(y+2 > h*2-1 && !(y+1 > h*2-1)){
                IncreaseHeight();
              }
              if(qualityofpic[x][y+1] == 0 && qualityofpic[x][y+2] == 0 && qualityofpic[x+1][y+1] == 0
               && qualityofpic[x+1][y+2] == 0){
              qualityofpic[x][y+1]=n+1;
              qualityofpic[x+1][y+2]=n+1;
              qualityofpic[x+1][y+1]=n+1;
              qualityofpic[x][y+2]=n+1;
              IsTopLeft[x][y+1]=true;
              SetTextPosition(n,x,y+1,typeofpic[n],qualityoforange[n]);
              SetFilePosition(n,x,y+1);
            }
            else{
              if(y+2 >= h*2-1 && !(y+2 > h*2-1 && !(y+1 > h*2-1)) && !(y+1 > h*2-1)){
                IncreaseHeight();
              }
              if(qualityofpic[x][y+2] == 0 && qualityofpic[x][y+3] == 0 && qualityofpic[x+1][y+2] == 0
                 && qualityofpic[x+1][y+3] == 0){
                qualityofpic[x][y+3]=n+1;
                qualityofpic[x+1][y+2]=n+1;
                qualityofpic[x+1][y+3]=n+1;
                qualityofpic[x][y+2]=n+1;
                IsTopLeft[x][y+2]=true;
                SetTextPosition(n,x,y+2,typeofpic[n],qualityoforange[n]);
                SetFilePosition(n,x,y+2);
              }
              else{
                if(x-1<0){
                  IncreaseWideX();
                  x = x+2;
                }
                if(qualityofpic[x][y] == 0 && qualityofpic[x][y+1] == 0 && qualityofpic[x-1][y+1] == 0
                   && qualityofpic[x-1][y] == 0){
                  qualityofpic[x-1][y]=n+1;
                  qualityofpic[x-1][y+1]=n+1;
                  qualityofpic[x][y+1]=n+1;
                  qualityofpic[x][y]=n+1;
                  IsTopLeft[x-1][y]=true;
                  SetTextPosition(n,x-1,y,typeofpic[n],qualityoforange[n]);
                  SetFilePosition(n,x-1,y);
                }
                else{
                  if(x-1<=0 && !(x-1<0)){
                    IncreaseWideX();
                    x = x+2;
                  }
                  if(qualityofpic[x-2][y] == 0 && qualityofpic[x-2][y+1] == 0 && qualityofpic[x-1][y+1] == 0
                     && qualityofpic[x-1][y] == 0){
                    qualityofpic[x-2][y]=n+1;
                    qualityofpic[x-2][y+1]=n+1;
                    qualityofpic[x-1][y+1]=n+1;
                    qualityofpic[x-1][y]=n+1;
                    IsTopLeft[x-2][y]=true;
                    SetTextPosition(n,x-2,y,typeofpic[n],qualityoforange[n]);
                    SetFilePosition(n,x-2,y);
                  }
                  else{
                    if(y-1<0){
                      IncreaseHeightX();
                      y = y+2;
                    }
                    if(qualityofpic[x][y] == 0 && qualityofpic[x+1][y] == 0 && qualityofpic[x+1][y-1] == 0
                       && qualityofpic[x][y-1] == 0){
                      qualityofpic[x][y-1]=n+1;
                      qualityofpic[x+1][y-1]=n+1;
                      qualityofpic[x+1][y]=n+1;
                      qualityofpic[x][y]=n+1;
                      IsTopLeft[x][y-1]=true;
                      SetTextPosition(n,x,y-1,typeofpic[n],qualityoforange[n]);
                      SetFilePosition(n,x,y-1);
                    }
                    else{
                      if(y-1<=0 && !(y-1<0)){
                        IncreaseHeightX();
                        y = y+2;
                      }
                      if(qualityofpic[x][y-2] == 0 && qualityofpic[x+1][y-2] == 0 && qualityofpic[x+1][y-1] == 0
                         && qualityofpic[x][y-1] == 0){
                        qualityofpic[x][y-2]=n+1;
                        qualityofpic[x+1][y-2]=n+1;
                        qualityofpic[x+1][y-1]=n+1;
                        qualityofpic[x][y-1]=n+1;
                        IsTopLeft[x][y-2]=true;
                        SetTextPosition(n,x,y-2,typeofpic[n],qualityoforange[n]);
                        SetFilePosition(n,x,y-2);
                      }
                      else WhenAddNewPic(x,y+1);
                    }
                  }
                }
              }
            }

          }
           }
        }
      }



    }
    deletenotuse();
  }

  void jButton1_actionPerformed(ActionEvent e) {

    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=1;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Start);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=2;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Way);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();

  }

  void jButton3_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=3;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Assign);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();

  }

  void jButton4_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=4;
    qualityoforange[n]=1;
    Block[n] = new JLabel(Orange);
    textlabel[n] = new JLabel("1");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();

  }


  void jButton5_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=5;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Slash);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }

  void jButton6_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=6;
    qualityoforange[n]=0;
    Block[n] = new JLabel(BackSlash);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton7_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=7;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Ifmore);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton8_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=8;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Endif);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton9_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=9;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Ifleft);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton10_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=10;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Ifright);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton11_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=11;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Endleft);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton12_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=12;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Endright);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton13_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=13;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Loops);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");
    WhenAddNewPic(LastX,LastY);
    int tmpx = 0;
    int tmpy = 0;
    for (tmpx = 0 ;tmpx < w*2; tmpx++){
      boolean tmpt = true;
      for (tmpy = 0 ;tmpy < h*2; tmpy++){
        if(qualityofpic[tmpx][tmpy]==n+1){
          tmpt = false;
          break;
        }
      }
      if(!tmpt)break;
    }
    tmpx = tmpx - LastX;
    tmpy = tmpy - LastY;

    n = n + 1;


    tmp = new JLabel[n];
    tmp5 = new int[n];
    tmp6 = new int[n];
    tmp2 = new JLabel[n];
    tmp0 = new File[n];
    tmp9 = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=14;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Endloop);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");
    WhenAddNewPic(LastX+tmpx,LastY+4+tmpy);

    Loop tmp7[] = new Loop[nloop];

    for (int i = 0 ; i < nloop ; i++){
      tmp7[i] = tmploop[i];
    }
    tmploop = new Loop[nloop+1];
    for (int i = 0 ; i < nloop ; i++){
      tmploop[i] = tmp7[i];
    }
    int loopi = -1;
    int loopj = -1;
    int endloopi = -1;
    int endloopj = -1;
    for (int i = w*2-1 ; i >=0 ; i--){
      for (int j = h*2-1 ; j >=0 ; j--){
        if(n == qualityofpic[i][j]){
          loopi = i;
          loopj = j;
        }
        else if(n+1 == qualityofpic[i][j]){
          endloopi = i;
          endloopj = j;
        }
      }
    }

    tmploop[nloop] = new Loop(loopi,loopj,endloopi,endloopj,n,n+1);
    nloop++;

    n = n + 1;

    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(false);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();

  }


  void jButton14_actionPerformed(ActionEvent e) {

    OpenFile();
    File namae = Nam;
    if(Nam == null || Nam.getName().equals("")){}
    else{
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=27;
    qualityoforange[n]=0;
    file[n]=Nam;
    Block[n] = new JLabel(BlackBox);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel(file[n].getName());

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
    }
  }


  void jButton15_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=15;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Minushaan);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }

  void jButton26_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=26;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Pluskoon);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton16_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=16;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Plus);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton17_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=17;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Minus);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton18_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=18;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Mul);
    textlabel[n] = new JLabel("0");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton19_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=19;
    qualityoforange[n]=1;
    Block[n] = new JLabel(Div);
    textlabel[n] = new JLabel("1");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }


  void jButton20_actionPerformed(ActionEvent e) {
    JLabel tmp[] = new JLabel[n];
    int tmp5[] = new int[n];
    int tmp6[] = new int[n];
    JLabel tmp2[] = new JLabel[n];
    File tmp0[] = new File[n];
    JLabel tmp9[] = new JLabel[n];

    for (int i = 0 ; i < n ; i++){
      tmp[i] = Block[i];
      tmp5[i] = typeofpic[i];
      tmp6[i] = qualityoforange[i];
      tmp2[i] = textlabel[i];
      tmp0[i] = file[i];
      tmp9[i] = filelabel[i];
    }
    Block = new JLabel[n+1];
    typeofpic = new int[n+1];
    qualityoforange = new int[n+1];
    textlabel = new JLabel[n+1];
    file = new File[n+1];
    filelabel = new JLabel[n+1];
    for (int i = 0 ; i < n ; i++){
      Block[i] = tmp[i];
      typeofpic[i] = tmp5[i];
      qualityoforange[i] = tmp6[i];
      textlabel[i] = tmp2[i];
      file[i] = tmp0[i];
      filelabel[i] = tmp9[i];
    }
    typeofpic[n]=20;
    qualityoforange[n]=0;
    Block[n] = new JLabel(Stop);
    textlabel[n] = new JLabel("");
    filelabel[n] = new JLabel("");

    WhenAddNewPic(LastX,LastY);
    n = n + 1;
    jPanel2.revalidate();
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    filelabel[n-1].show();
    textlabel[n-1].show();
    Block[n-1].show();
    Save();
  }

  void jButton21_actionPerformed(ActionEvent e) {
    Clear();
  }


  //-------------------------------- Open File -----------------------------------
  void jButton22_actionPerformed(ActionEvent e) {
    //statusBar.setText( "Clicked Open" );

    OpenFile();
    if (Nam != null)
    {
      readRecord();
    }
  }

//-------------------------------- Save File -----------------------------------
  void jButton23_actionPerformed(ActionEvent e) throws IOException{

    int[][] tmp = new int[h*2][w*2];
    boolean[][] t = new boolean[h*2][w*2];
    for(int i = 0; i<h*2 ; i++){
      for(int j = 0; j<w*2 ; j++){
        t[i][j]=IsTopLeft[j][i];
        tmp[i][j]=tabl[i][j];
      }
    }

    SaveFile();
    if (Name != null)
    {
      addRecord();
      CloseOutputFile();
    }
  }

  private File[][] ChangeFile(){
    File[][] CFile = new File[h*2][w*2];

      for (int p = 0 ; p < h*2 ; p++){
            for (int o = 0 ; o < w*2 ; o++)
            {
              if(qualityofpic[o][p] == 0){
                CFile[p][o] = null;
              }
              else if(file[qualityofpic[o][p]-1]==null)
              {
                CFile[p][o] = null;
              }
              else
              {
                CFile[p][o] = file[qualityofpic[o][p]-1];
              }
            }
        }
    return CFile;
  }

void jButton24_actionPerformed(ActionEvent e) {
  boolean[][] t = new boolean[h*2][w*2];
  haveloop = new int[h*2][w*2];
  for(int i = 0; i<h*2 ; i++){
    for(int j = 0; j<w*2 ; j++){
      t[i][j]=IsTopLeft[j][i];
    }
  }

  godown= false;
  goup= false;
  CheckError error = new CheckError(h*2,w*2,tabl,t,orange,ChangeFile(),false,null);
  WrongBlock = error.CheckAll(0);
  int x = WrongBlock[0];
  int y = WrongBlock[1];
  if(x == -2 && y == -2 ){ x = 0; y = 0;}
  if((x == -1 && y == -1) || (x == -3 && y == -3)){
    animetion();
  }
  else if(x < -1 || y < -1 )System.err.println("error");
  else{
    showerror(x,y);
  }
}

void showerror(int x,int y){

    if(x<=1){}else
    if(tabl[x][y]==0){
      x = x - 2;
    }
    if(x!=0||y!=0){
      if(IsTopLeft[y][x]){

      }else if(IsTopLeft[y-1][x]){
        y--;
      }else if(IsTopLeft[y][x-1]){
        x--;
      }else if(IsTopLeft[y-1][x-1]){
        x--;
        y--;
      }
    }
    ImageIcon Err = new ImageIcon();
    switch (tabl[x][y]){
      case 0:Err = createImageIcon("images/backgroundx.gif");
        break;
      case 1:Err = createImageIcon("images/startx.gif");
        break;
      case 2:Err = createImageIcon("images/wayx.gif");
        break;
      case 3:Err = createImageIcon("images/assignx.gif");
        break;
      case 4:Err = createImageIcon("images/orangex.gif");
        break;
      case 5:Err = createImageIcon("images/slashx.gif");
        break;
      case 6:Err = createImageIcon("images/backslashx.gif");
        break;
      case 7:Err = createImageIcon("images/ifmorex.gif");
        break;
      case 8:Err = createImageIcon("images/endifx.gif");
        break;
      case 9:Err = createImageIcon("images/ifleftx.gif");
        break;
      case 10:Err = createImageIcon("images/ifrightx.gif");
        break;
      case 11:Err = createImageIcon("images/endleftx.gif");
        break;
      case 12:Err = createImageIcon("images/endrightx.gif");
        break;
      case 13:Err = createImageIcon("images/loopx.gif");
        break;
      case 14:Err = createImageIcon("images/endloopx.gif");
        break;
      case 15:Err = createImageIcon("images/minushaanx.gif");
        break;
      case 16:Err = createImageIcon("images/plusx.gif");
        break;
      case 17:Err = createImageIcon("images/minusx.gif");
        break;
      case 18:Err = createImageIcon("images/koonx.gif");
        break;
      case 19:Err = createImageIcon("images/haanx.gif");
        break;
      case 20:Err = createImageIcon("images/stopx.gif");
        break;
      case 26:Err = createImageIcon("images/pluskoonx.gif");
        break;
      case 27:Err = createImageIcon("images/BlackBoxx.gif");
        break;
      case 31:Err = createImageIcon("images/wayg1.gif");
        break;
      case 32:Err = createImageIcon("images/wayg2.gif");
        break;
      case 33:Err = createImageIcon("images/wayg3.gif");
        break;
      case 34:Err = createImageIcon("images/wayg4.gif");
        break;
    }


    SetOther(w,h,-1);
    err = false;
    Error = new JLabel(Err);
    if (tabl[x][y] != 4)
      jPanel2.add( Error, new XYConstraints(y*30, x*30, 60, 60) );
    else jPanel2.add( Error, new XYConstraints(y*30, x*30, 30, 30) );

    jPanel2.revalidate();
    SetOther(w,h,-1);
    SetLoop(true);
    SetBackground(w,h);
    err = true;
}

boolean qwq = true;
boolean godown = false;
boolean goup = false;
boolean arrowdown[][];
boolean firstupdown = true;
int oldxx = 0;
int oldyy = 0;
int Case = 0;

void LoopDown(){
  if(oldyy>yy){
    Case = 4;
    oldyy = oldyy-2;
  }
  else if(oldyy==yy && oldxx!=xx){
    Case = 1;
    oldyy = oldyy-2;
  }
  else if(oldxx<xx-2){
    if(firstupdown){
      Case = 1;
      oldyy = oldyy-2;
    }else{
      Case = 2;
      oldxx = oldxx+2;
    }
  }
  else if(oldxx==xx-2 && oldyy!=yy){
    Case = 3;
    oldxx = oldxx+2;
    if(oldyy+2 == yy){
      godown = false;
    }
  }
  else if(oldxx==xx && oldyy != yy){
    Case = 4;
    oldyy = oldyy+2;
    if(oldyy+2 == yy){
      godown = false;
    }
  }
  else{
    godown = false;
  }
  if(!godown){
    int[] temp = findpartner(xx,yy);
    if(temp[0]>=0&&temp[1]>=0){
      haveloop[temp[0]][temp[1]]=orange[temp[0]][temp[1]];
    }
    else System.err.println("Error");
  }

  if(havebox){
    jPanel2.remove(Box);
    jPanel2.remove(TextBox);
    TextBox = new JLabel("");
    TextBox.setText(Integer.toString(norange));
    jPanel2.add( TextBox, new XYConstraints(oldyy*30+21, oldxx*30+18, 42, 35) );

    ImageIcon BoxPic = new ImageIcon();
    BoxPic = createImageIcon("images/box.gif");
    Box = new JLabel(BoxPic);
    jPanel2.add( Box, new XYConstraints(oldyy*30+9, oldxx*30+12, 42, 35) );

  }

  ImageIcon Err = new ImageIcon();
  switch(Case){
  case 1:Err = createImageIcon("images/wayg1y.gif");
  break;
  case 2:Err = createImageIcon("images/wayg2y.gif");
  break;
  case 3:Err = createImageIcon("images/wayg3y.gif");
  break;
  case 4:Err = createImageIcon("images/wayg4y.gif");
  break;
  }
  SetOther(w,h,-1);

  Error = new JLabel(Err);
  jPanel2.add( Error, new XYConstraints(oldyy*30, oldxx*30, 60, 60) );

  jPanel2.revalidate();
  SetOther(w,h,0);
  SetLoop(true);
  SetBackground(w,h);
  err = true;
  firstupdown = false;
}

void LoopUp(){
  if(oldyy>yy){
    Case = 4;
    oldyy = oldyy-2;
  }
  else if(oldyy==yy && oldxx!=xx){
    Case = 3;
    oldyy = oldyy-2;
  }
  else if(oldxx>xx+2){
    if(firstupdown){
      Case = 3;
      oldyy = oldyy-2;
    }else{
    Case = 2;
    oldxx = oldxx-2;
    }
  }
  else if(oldxx==xx+2 && oldyy!=yy){
    Case = 1;
    oldxx = oldxx-2;
    if(oldyy+2 == yy){
      goup = false;
    }
  }
  else if(oldxx==xx && oldyy != yy){
    Case = 4;
    oldyy = oldyy+2;
    if(oldyy+2 == yy){
      goup = false;
    }
  }
  else{
    goup = false;
  }

  if(havebox){
    jPanel2.remove(Box);
    jPanel2.remove(TextBox);
    TextBox = new JLabel("");
    TextBox.setText(Integer.toString(norange));
    jPanel2.add( TextBox, new XYConstraints(oldyy*30+21, oldxx*30+18, 42, 35) );

    ImageIcon BoxPic = new ImageIcon();
    BoxPic = createImageIcon("images/box.gif");
    Box = new JLabel(BoxPic);
    jPanel2.add( Box, new XYConstraints(oldyy*30+9, oldxx*30+12, 42, 35) );

  }

  ImageIcon Err = new ImageIcon();
  switch(Case){
  case 1:Err = createImageIcon("images/wayg1y.gif");
  break;
  case 2:Err = createImageIcon("images/wayg2y.gif");
  break;
  case 3:Err = createImageIcon("images/wayg3y.gif");
  break;
  case 4:Err = createImageIcon("images/wayg4y.gif");
  break;
  }
  SetOther(w,h,-1);

  Error = new JLabel(Err);
  jPanel2.add( Error, new XYConstraints(oldyy*30, oldxx*30, 60, 60) );

  jPanel2.revalidate();
  SetOther(w,h,0);
  SetLoop(true);
  SetBackground(w,h);
  err = true;
  firstupdown = false;
}


void jButton27_actionPerformed(ActionEvent e) {
  qwq = true;
  animetionfinish = true;
  if(havebox){
    jPanel2.remove(Box);
    jPanel2.remove(TextBox);
  }
  for(int i = 0 ; i<nop ; i++){
    jPanel2.remove(looplabel[i]);
  }
  nop = 0;
  havebox = false;
  operator = false;
  firstupdown = true;
  jButton27.setEnabled(false);
  jButton25.setEnabled(false);
  jButton1.setEnabled(true);
  jButton2.setEnabled(true);
  jButton3.setEnabled(true);
  jButton4.setEnabled(true);
  jButton5.setEnabled(true);
  jButton6.setEnabled(true);
  jButton7.setEnabled(true);
  jButton8.setEnabled(true);
  jButton9.setEnabled(true);
  jButton10.setEnabled(true);
  jButton11.setEnabled(true);
  jButton12.setEnabled(true);
  jButton13.setEnabled(true);
  jButton14.setEnabled(true);
  jButton15.setEnabled(true);
  jButton16.setEnabled(true);
  jButton17.setEnabled(true);
  jButton18.setEnabled(true);
  jButton19.setEnabled(true);
  jButton20.setEnabled(true);
  jButton21.setEnabled(true);
  jButton22.setEnabled(true);
  jButton23.setEnabled(true);
  jButton24.setEnabled(true);
  jButton26.setEnabled(true);
  jButton28.setEnabled(true);
  jButton29.setEnabled(true);
  jPanel2.revalidate();
  SetOther(w,h,0);
  SetLoop(true);
  SetBackground(w,h);
}
boolean ttmp = false;

void showresult(){
  if(ttmp){
    jPanel2.remove(Box);
    jPanel2.remove(TextBox);
    ttmp = false;
  }
  norange = 0;
  l = 0;
  lx = new int[15];
  ly = new int[15];
  lz = new int[15];
  lxx = new int[15];
  lyy = new int[15];
  lb = new boolean[15];
  lbb = new boolean[15];
  haveloop = new int[h*2][w*2];
  arrowdown = new boolean[h*2][w*2];
  for(int i = 0 ; i< 15 ; i++){
    lx[i]=0;
    ly[i]=0;
    lz[i]=0;
    lxx[i]=0;
    lyy[i]=0;
    lb[i]=false;
    lbb[i]=false;
  }
  havebox = false;
  xx = 0;
  yy = 0;
  xxx = 0;
  yyy = 0;
  operator = false;
  for(int i = 0 ; i< h*2 ; i++){
    for( int j = 0 ; j < w*2 ; j++){
      if(tabl[i][j]==1){
        xx = i-1;
        yy = j-1;
      }
      haveloop[i][j]=0;
      arrowdown[i][j]=false;
    }
  }
  animetionfinish = false;
  while(!animetionfinish){
    if(!qwq){
      qwq=true;

      if(havebox){

        TextBox = new JLabel("");
        TextBox.setText(Integer.toString(norange));
        jPanel2.add( TextBox, new XYConstraints(yy*30+21, xx*30+18, 42, 35) );

        ImageIcon BoxPic = new ImageIcon();
        BoxPic = createImageIcon("images/box.gif");
        Box = new JLabel(BoxPic);
        jPanel2.add( Box, new XYConstraints(yy*30+9, xx*30+12, 42, 35) );

        SetOther(w,h,-1);

        Error = new JLabel(createImageIcon("images/stopy.gif"));
        jPanel2.add( Error, new XYConstraints(yy*30, xx*30, 60, 60) );

        jPanel2.revalidate();
        SetOther(w,h,0);
        SetLoop(true);
        SetBackground(w,h);
        err = true;
        ttmp = true;

      }
      havebox = false;
      operator = false;
      animetionfinish=true;
      tmpbooo=false;

    }
    if(yy!=0){
      if(IsTopLeft[yy][xx]){

      }else if(IsTopLeft[yy-1][xx]){
        yy--;
      }else if(IsTopLeft[yy+1][xx]){
        yy++;
      }
    }else{
      if(IsTopLeft[yy][xx]){

      }else if(IsTopLeft[yy+1][xx]){
        yy++;
      }
    }

    if(havebox || tabl[xx][yy] == 3 || tabl[xx][yy] == 27 ){

      switch (tabl[xx][yy]){
      case 3:
        norange = orange[xx][yy];
        break;
      case 16:
        norange = norange + orange[xx][yy];
        operator = true;
        break;
      case 17:
        norange = norange - orange[xx][yy];
        operator = true;
        break;
      case 18:
        norange = norange * orange[xx][yy];
        operator = true;
        break;
      case 19:
        int nn;
        nn = norange % orange[xx][yy];
        nn = norange - nn;
        norange = nn / orange[xx][yy];
        operator = true;
        break;
      case 27:
        BlackBox BB = new BlackBox(file[qualityofpic[yy][xx]-1],havebox,norange);
        norange = BB.Total();
        break;
      }

    }

    if(!havebox && (tabl[xx][yy]==16 || tabl[xx][yy]==17 || tabl[xx][yy]==18 || tabl[xx][yy]==19)){
      operator = true;
    }

    switch (tabl[xx][yy]){
      case 27:
        if(norange!=-32764){havebox = true;}
        case 1:
        case 2:
        case 9:
        case 10:
          xx=xx+2;
          break;
        case 3:
          havebox = true;
          xx=xx+2;
          break;

        case 5:
        case 12:
          if(tabl[xx+2][yy] == 5 || tabl[xx+2][yy] == 8 || tabl[xx+2][yy] == 9)yy--;
          xx = xx + 2;
          break;

        case 6:
        case 11:
          if(tabl[xx+2][yy+1] != 5 && tabl[xx+2][yy+1] != 8)yy++;
          xx = xx + 2;
          break;

        case 7:
          if(norange>=orange[xx][yy])yy--;
          else yy++;
        case 8:
          xx = xx + 2;
          break;
        case 13:
          boolean tmp = true;
          int tmp2 = 0;

          boolean tmp3 = true;
          for(int i = 0; i< 15 ; i++){
            if(lxx[i] == xx && lyy[i] == yy){
              tmp = false;
              tmp2 = i;
            }
          }
          if(tmp){
            for(int i = 0; i< 15 ; i++){
              if(lxx[i] == 0 && lyy[i] == 0 && tmp3){
              tmp2 = i;
              tmp3 = false;
            }
            }
            lxx[tmp2] = xx;
            lyy[tmp2] = yy;
          }
          l = tmp2;
          if(lz[l] == orange[xx][yy]){
            int s = 0;
            int xxx = 0;
            int yyy = 0;
            int xxxx= xx+2;
            int yyyy= yy;
            while(xxx == 0 && yyy ==0){
              if(yyyy!=0){
                if(IsTopLeft[yyyy][xxxx]){

                }else if(IsTopLeft[yyyy-1][xxxx]){
                  yyyy--;
                }else if(IsTopLeft[yyyy+1][xxxx]){
                  yyyy++;
                }
              }else{
                if(IsTopLeft[yyyy][xxxx]){

                }else if(IsTopLeft[yyyy+1][xxxx]){
                  yyyy++;
                }
              }
              switch (tabl[xxxx][yyyy]){
                case 13:
                  s++;
                  xxxx = xxxx + 2;
                  break;
                case 14:
                  if(s==0){
                    xxx = xxxx;
                    yyy = yyyy;
                  }
                  else {
                    s--;
                    xxxx = xxxx + 2;
                  }
                  break;
                default:
                  xxxx = xxxx + 2;
              }
            }
            godown = true;
            oldxx = xx;
            oldyy = yy;
            xx = xxx;
            yy = yyy;
            lb[l] = true;
          }
          else{
            lx[l] = xx;
            ly[l] = yy;
            xx = xx +2;
          }
          break;
        case 14:
          if(!lb[l]){
            goup = true;
            oldxx = xx;
            oldyy = yy;
            xx = lx[l];
            yy = ly[l];
            lz[l] = lz[l] + 1;
          }else{
            lb[l]=false;
            lz[l]=0;
            lxx[l]=0;
            lyy[l]=0;
            l--;
            xx = xx +2;
          }
          break;
        case 16:
        case 18:
          xx++;
          yy = yy-2;
          break;
        case 17:
        case 19:
          xx--;
          yy = yy+2;
          break;
        case 15:
          if(operator){
            xx = xx + 2;
            operator = false;
          }
          else{
            xx++;
            yy = yy-2;
          }
          break;
        case 26:
          if(operator){
            xx = xx + 2;
            operator = false;
          }
          else{
            xx--;
            yy = yy+2;
          }
          break;
        case 20:
          qwq = false;
    }
  }
}

void jButton28_actionPerformed(ActionEvent e) {

  boolean[][] t = new boolean[h*2][w*2];
  for(int i = 0; i<h*2 ; i++){
    for(int j = 0; j<w*2 ; j++){
      t[i][j]=IsTopLeft[j][i];
    }
  }

  CheckError error = new CheckError(h*2,w*2,tabl,t,orange,ChangeFile(),false,null);
  WrongBlock = error.CheckAll(0);
  int x = WrongBlock[0];
  int y = WrongBlock[1];
  if(x == -2 && y == -2 ){ x = 0; y = 0;}
  if((x == -1 && y == -1) || (x == -3 && y == -3)){
    showresult();
  }
  else if(x < -1 || y < -1 )System.err.println("error");
  else{
    showerror(x,y);
  }


}

void jButton25_actionPerformed(ActionEvent e) {
  tmpbooo=true;
  nop=0;
  for (int i =0;i<h*2;i++){
    for (int j =0;j<w*2;j++){
      if(qualityofpic[j][i]!=0){
        if(typeofpic[qualityofpic[j][i]-1]==13 && IsTopLeft[j][i]){
          jPanel2.remove(looplabel[nop]);
          looplabel[nop] = new JLabel(Integer.toString(orange[i][j]-haveloop[i][j]));
          jPanel2.add( looplabel[nop], new XYConstraints(j*30+47, i*30-15, 60, 60));
          nop++;
        }
      }
    }
  }

  if(godown){
    LoopDown();
  }
  else if(goup){
    LoopUp();
  }
  else{


  if(yy!=0){
    if(IsTopLeft[yy][xx]){

    }else if(IsTopLeft[yy-1][xx]){
      yy--;
    }else if(IsTopLeft[yy+1][xx]){
      yy++;
    }
  }else{
    if(IsTopLeft[yy][xx]){

    }else if(IsTopLeft[yy+1][xx]){
      yy++;
    }
  }
  if(havebox){
    jPanel2.remove(Box);
    jPanel2.remove(TextBox);
  }


  if(havebox || tabl[xx][yy] == 3 || tabl[xx][yy] == 27 ){

    switch (tabl[xx][yy]){
    case 3:
      norange = orange[xx][yy];
      break;
    case 16:
      norange = norange + orange[xx][yy];
      operator = true;
      break;
    case 17:
      norange = norange - orange[xx][yy];
      operator = true;
      break;
    case 18:
      norange = norange * orange[xx][yy];
      operator = true;
      break;
    case 19:
      int nn;
      nn = norange % orange[xx][yy];
      nn = norange - nn;
      norange = nn / orange[xx][yy];
      operator = true;
      break;
    case 27:
      BlackBox BB = new BlackBox(file[qualityofpic[yy][xx]-1],havebox,norange);
      norange = BB.Total();
      break;
    }
    if(tabl[xx][yy]!=27 || norange != -32764){
      TextBox = new JLabel("");
      TextBox.setText(Integer.toString(norange));
      jPanel2.add( TextBox, new XYConstraints(yy*30+21, xx*30+18, 42, 35) );

      ImageIcon BoxPic = new ImageIcon();
      BoxPic = createImageIcon("images/box.gif");
      Box = new JLabel(BoxPic);
      jPanel2.add( Box, new XYConstraints(yy*30+9, xx*30+12, 42, 35) );
    }

  }

  if(!havebox && (tabl[xx][yy]==16 || tabl[xx][yy]==17 || tabl[xx][yy]==18 || tabl[xx][yy]==19)){
    operator = true;
  }

  ImageIcon Err = new ImageIcon();
  switch (tabl[xx][yy]){
    case 1:Err = createImageIcon("images/starty.gif");
      break;
    case 2:Err = createImageIcon("images/wayy.gif");
      break;
    case 3:Err = createImageIcon("images/assigny.gif");
      break;
    case 5:Err = createImageIcon("images/slashy.gif");
      break;
    case 6:Err = createImageIcon("images/backslashy.gif");
      break;
    case 7:Err = createImageIcon("images/ifmorey.gif");
      break;
    case 8:Err = createImageIcon("images/endify.gif");
      break;
    case 9:Err = createImageIcon("images/iflefty.gif");
      break;
    case 10:Err = createImageIcon("images/ifrighty.gif");
      break;
    case 11:Err = createImageIcon("images/endlefty.gif");
      break;
    case 12:Err = createImageIcon("images/endrighty.gif");
      break;
    case 13:
      if(haveloop[xx][yy]==0)Err = createImageIcon("images/loop2y.gif");
      else Err = createImageIcon("images/loopy.gif");
      break;
    case 14:
      if(arrowdown[xx][yy]) Err = createImageIcon("images/endloop2y.gif");
      else Err = createImageIcon("images/endloopy.gif");
      break;
    case 15:Err = createImageIcon("images/minushaany.gif");
      break;
    case 16:Err = createImageIcon("images/plusy.gif");
      break;
    case 17:Err = createImageIcon("images/minusy.gif");
      break;
    case 18:Err = createImageIcon("images/koony.gif");
      break;
    case 19:Err = createImageIcon("images/haany.gif");
      break;
    case 20:Err = createImageIcon("images/stopy.gif");
      break;
    case 26:Err = createImageIcon("images/pluskoony.gif");
      break;
    case 27:Err = createImageIcon("images/BlackBoxy.gif");
      break;
    case 31:Err = createImageIcon("images/wayg1.gif");
      break;
    case 32:Err = createImageIcon("images/wayg2.gif");
      break;
    case 33:Err = createImageIcon("images/wayg3.gif");
      break;
    case 34:Err = createImageIcon("images/wayg4.gif");
      break;
  }

  SetOther(w,h,-1);

  Error = new JLabel(Err);
  jPanel2.add(Error, new XYConstraints(yy*30, xx*30, 60, 60));

  jPanel2.revalidate();
  SetOther(w,h,-1);
  SetLoop(true);
  SetBackground(w,h);
  err = true;

  if(!qwq){
    qwq = true;
    animetionfinish = true;
      if(havebox){
        jPanel2.remove(Box);
        jPanel2.remove(TextBox);
      }
      havebox = false;
      operator = false;
      jButton27.setEnabled(false);
      jButton25.setEnabled(false);
      jButton1.setEnabled(true);
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(true);
      jButton6.setEnabled(true);
      jButton7.setEnabled(true);
      jButton8.setEnabled(true);
      jButton9.setEnabled(true);
      jButton10.setEnabled(true);
      jButton11.setEnabled(true);
      jButton12.setEnabled(true);
      jButton13.setEnabled(true);
      jButton14.setEnabled(true);
      jButton15.setEnabled(true);
      jButton16.setEnabled(true);
      jButton17.setEnabled(true);
      jButton18.setEnabled(true);
      jButton19.setEnabled(true);
      jButton20.setEnabled(true);
      jButton21.setEnabled(true);
      jButton22.setEnabled(true);
      jButton23.setEnabled(true);
      jButton24.setEnabled(true);
      jButton26.setEnabled(true);
      jButton28.setEnabled(true);
      jButton29.setEnabled(true);

      for(int i =0 ; i<nloop ; i++){
        jPanel2.remove(looplabel[i]);
      }
      tmpbooo=false;
  }else{


  switch (tabl[xx][yy]){
    case 27:
      if(norange!=-32764){havebox = true;}
    case 1:
    case 2:
    case 9:
    case 10:
      xx=xx+2;
      break;
    case 3:
      havebox = true;
      xx=xx+2;
      break;

    case 5:
    case 12:
      if(tabl[xx+2][yy] == 5 || tabl[xx+2][yy] == 8 || tabl[xx+2][yy] == 9)yy--;
      xx = xx + 2;
      break;

    case 6:
    case 11:
      if(tabl[xx+2][yy+1] != 5 && tabl[xx+2][yy+1] != 8)yy++;
      xx = xx + 2;
      break;

    case 7:
      if(norange>=orange[xx][yy])yy--;
      else yy++;
    case 8:
      xx = xx + 2;
      break;
    case 13:
      firstupdown = true;
      if(haveloop[xx][yy]!=0)haveloop[xx][yy]--;
      boolean tmp = true;
      int tmp2 = 0;

      boolean tmp3 = true;
      for(int i = 0; i< 15 ; i++){
        if(lxx[i] == xx && lyy[i] == yy){
          tmp = false;
          tmp2 = i;
        }
      }
      if(tmp){
        for(int i = 0; i< 15 ; i++){
          if(lxx[i] == 0 && lyy[i] == 0 && tmp3
             ){
            tmp2 = i;
            tmp3 = false;
          }
        }
        lxx[tmp2] = xx;
        lyy[tmp2] = yy;
      }
      l = tmp2;
      if(lz[l] == orange[xx][yy]){
        int s = 0;
        int xxx = 0;
        int yyy = 0;
        int xxxx= xx+2;
        int yyyy= yy;
        while(xxx == 0 && yyy ==0){
          if(yyyy!=0){
            if(IsTopLeft[yyyy][xxxx]){

            }else if(IsTopLeft[yyyy-1][xxxx]){
              yyyy--;
            }else if(IsTopLeft[yyyy+1][xxxx]){
              yyyy++;
            }
          }else{
            if(IsTopLeft[yyyy][xxxx]){

            }else if(IsTopLeft[yyyy+1][xxxx]){
              yyyy++;
            }
          }
          switch (tabl[xxxx][yyyy]){
            case 13:
              s++;
              xxxx = xxxx + 2;
              break;
            case 14:
              if(s==0){
                xxx = xxxx;
                yyy = yyyy;
              }
              else {
                s--;
                xxxx = xxxx + 2;
              }
              break;
            default:
              xxxx = xxxx + 2;
          }
        }
        godown = true;
        arrowdown[findpartner(xx,yy)[0]][findpartner(xx,yy)[1]] = true;
        oldxx = xx;
        oldyy = yy;
        xx = xxx;
        yy = yyy;
        lb[l] = true;
        }
      else{
        lx[l] = xx;
        ly[l] = yy;
        xx = xx +2;
      }
      break;
    case 14:
      firstupdown = true;
      if(!lb[l]){
        goup = true;
        oldxx = xx;
        oldyy = yy;
        xx = lx[l];
        yy = ly[l];
        lz[l] = lz[l] + 1;
      }else{
        arrowdown[xx][yy]=false;
        lb[l]=false;
        lz[l]=0;
        lxx[l]=0;
        lyy[l]=0;
        l--;
        xx = xx +2;
      }
      break;
    case 16:
    case 18:
      xx++;
      yy = yy-2;
      break;
    case 17:
    case 19:
      xx--;
      yy = yy+2;
      break;
    case 15:
      if(operator){
        xx = xx + 2;
        operator = false;
      }
      else{
        xx++;
        yy = yy-2;
      }
      break;
    case 26:
      if(operator){
        xx = xx + 2;
        operator = false;
      }
      else{
        xx--;
        yy = yy+2;
      }
      break;
    case 20:
      qwq = false;

      tmpbooo=false;
  }
  }
  }
}
  void jButton29_actionPerformed(ActionEvent e) throws IOException{

    int[][] tmp = new int[h*2][w*2];
    boolean[][] t = new boolean[h*2][w*2];
    for(int i = 0; i<h*2 ; i++){
      for(int j = 0; j<w*2 ; j++){
        t[i][j]=IsTopLeft[j][i];
        tmp[i][j]=tabl[i][j];
      }
    }

    SaveCFile();

    if (Name != null)
    {
      CloseOutputFile();
    }


    CheckError error = new CheckError(h*2,w*2,tabl,t,orange,ChangeFile(),false,null);
    WrongBlock = error.CheckAll(0);
    int x = WrongBlock[0];
    int y = WrongBlock[1];
    if(x == -2 && y == -2 ){ x = 0; y = 0;}
    if((x == -1 && y == -1) || (x == -3 && y == -3)){
      Vector v = new Vector();
      Translate Tran = new Translate();

      //------ Call Class Translate to Translate from Picture code to C code -----
      try {
        Tran.Translate(h,w,tmp,orange,0,v,Name,ChangeFile());
      }
      catch(IOException E) {
        E.printStackTrace();
      }
    }
  }


  void Clear(){
    for (int i = 0 ; i < w ; i++)
        for (int j = 0 ; j < h ; j++) jPanel2.remove( Background[i][j] );

    for(int i = 0 ; i<n ; i++){
      jPanel2.remove(Block[i]);
      jPanel2.remove(textlabel[i]);
      jPanel2.remove(filelabel[i]);
    }
    n = 0;
    w = 7;
    h = 7;
    Block = new JLabel[n];
    typeofpic = new int[n];
    qualityoforange = new int[n];
    textlabel = new JLabel[n];
    filelabel = new JLabel[n];
    file = new File[n];

    qualityofpic = new int[w*2][h*2];
    IsTopLeft = new boolean[w*2][h*2];
    tabl = new int[h*2][w*2];
    orange = new int[h*2][w*2];

    for(int i = 0 ; i<nloop ; i++){
      for(int j = 0 ; j < tmploop[i].nlabelloop ; j ++){
        jPanel2.remove( tmploop[i].labelloop[j]);
      }

    }
    nloop = 0;
    tmploop = new Loop[nloop];

    SetOther(w,h,-1);
    SetLoop(true);
    IsSetBackground = false;
    SetBackground(w,h);
  }

  private ObjectInputStream input;
   private void OpenFile()
   {
     //---------- Disply file dialog, so user can choose file to open -----------
     JFileChooser fileChooser = new JFileChooser();
     fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

     int result = fileChooser.showOpenDialog(this);

     //------------ If user clicked Cancel button on dialog, return -------------
     if (result == JFileChooser.CANCEL_OPTION)
       return;

     //-------------------------- Get selected file -----------------------------
     File fileNam = fileChooser.getSelectedFile();
     Nam = fileNam;

     //---------------------- Display error if invalid --------------------------
     if (fileNam == null || fileNam.getName().equals(""))
       JOptionPane.showMessageDialog(this,"Invalid File Name","Invalid File Name", JOptionPane.ERROR_MESSAGE);
   }


   private ObjectOutputStream output;
   private void SaveFile()
   {
     //---------- Disply file dialog, so user can choose file to open -----------
     JFileChooser fileChooser = new JFileChooser();
     fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

     int result = fileChooser.showSaveDialog(this);

     //------------ If user clicked Cancel button on dialog, return -------------
     if (result == JFileChooser.CANCEL_OPTION)
       return;

     //-------------------------- Get selected file -----------------------------
     File fileName = fileChooser.getSelectedFile();
     Name = fileName;

     //---------------------- Display error if invalid --------------------------
     if (fileName == null || fileName.getName().equals(""))
       JOptionPane.showMessageDialog(this,"Invalid File Name","Invalid File Name", JOptionPane.ERROR_MESSAGE);
     else
     {
       try
       {
         output = new ObjectOutputStream(new FileOutputStream(fileName));//+".bb"));
       }
       // Process exceptions from saving file
       catch (IOException ioException)
       {
         JOptionPane.showMessageDialog(this,"Error Saving File","Error",JOptionPane.ERROR_MESSAGE);
       }
     }
   }

   private void SaveCFile()
   {
     //---------- Disply file dialog, so user can choose file to open -----------
     JFileChooser fileChooser = new JFileChooser();
     fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

     int result = fileChooser.showSaveDialog(this);

     //------------ If user clicked Cancel button on dialog, return -------------
     if (result == JFileChooser.CANCEL_OPTION)
       return;

     //-------------------------- Get selected file -----------------------------
     File fileName = fileChooser.getSelectedFile();
     Name = fileName;

     //---------------------- Display error if invalid --------------------------
     if (fileName == null || fileName.getName().equals(""))
       JOptionPane.showMessageDialog(this,"Invalid File Name","Invalid File Name", JOptionPane.ERROR_MESSAGE);
     else
     {
       try
       {
         output = new ObjectOutputStream(new FileOutputStream(fileName+".c"));
       }
       // Process exceptions from saving file
       catch (IOException ioException)
       {
         JOptionPane.showMessageDialog(this,"Error Saving File","Error",JOptionPane.ERROR_MESSAGE);
       }
     }
   }
   private void CloseOutputFile()
   {
     //----------------------------- Close File ---------------------------------
     try
     {
       output.close();
       //System.exit(0);
     }
     //----------------- Process exceptions from closing file -------------------
     catch(IOException ioException)
     {
       JOptionPane.showMessageDialog(this,"Error closing file","Error",JOptionPane.ERROR_MESSAGE);
       System.exit(1);
     }
   }

   private void CloseInputFile()
   {
    //----------------------------- Close File ---------------------------------
    try
    {
      input.close();
      //System.exit(0);
    }
    //----------------- Process exceptions from closing file -------------------
    catch(IOException ioException)
    {
      JOptionPane.showMessageDialog(this,"Error closing file","Error",JOptionPane.ERROR_MESSAGE);
      System.exit(1);
    }
   }

   private void readRecord()
   {
     int hhh = h;
     int www = w;
     int nloopp = 0;
     int nfile = 0;
     int ia[] = new int[0];
     int ja[] = new int[0];
     String tmpFile[] = new String[0];
     Clear();

     int i=0,j=0,index0=0,index1=0,flag=0,nnloop=0;
     int[][] tmp = new int[0][0];
     int[][] orang = new int[0][0];
     String[][] tmpbb = new String[0][0];
     int[][] loopp = new int[0][4];
     try {
       FileReader fin = new FileReader(Nam);
       BufferedReader bin = new BufferedReader(fin);

       String s;
       while ((s = bin.readLine()) != null)
       {
         if (s.equals("Size"))
         {
           flag=1;
           continue;
         }
         else if (flag==0)
         {
           flag=5;
           break;
         }
         else if (flag==1)
         {
           index1 = s.indexOf(' ',index0);
           hhh = Integer.parseInt((s.substring(index0,index1).trim()));
           index0 = index1+1;
           index1 = s.indexOf(' ',index0);
           www = Integer.parseInt((s.substring(index0,s.length()).trim()));
           break;
         }
       }
       if (flag==5)
         JOptionPane.showMessageDialog(this,"Error opening this file","Error",JOptionPane.ERROR_MESSAGE);
       else
       {
       tmp = new int[hhh*2][www*2];
       orang = new int[hhh*2][www*2];
       tmpbb = new String[hhh*2][www*2];
       flag = 0;
       while ((s = bin.readLine()) != null)
       {
         j=0;
         index0=0;
         index1=0;

         if (s.equals("Table"))
         {
           flag=2;
           continue;
         }
         else if (s.equals("Orange"))
         {
           flag=3;
           i=0;
           continue;
         }
         else if (s.equals("BlackBox")){
           flag=6;
           i=0;
           break;
         }
         else if (flag==2)
         {
           while (index0 < s.length())
           {
             index1 = s.indexOf(' ',index0);
             tmp[i][j] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             j++;
           }
           i++;
           continue;
         }
         else if (flag==3)
         {
           while (index0 < s.length())
           {
             index1 = s.indexOf(' ',index0);
             orang[i][j] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             j++;
           }
           i++;
           continue;
         }
       }
       if(flag!=6)JOptionPane.showMessageDialog(this,"Error opening this file","Error",JOptionPane.ERROR_MESSAGE);
       else{
           index0=0;
           s = bin.readLine();
           nfile = Integer.parseInt((s.substring(index0,s.length()).trim()));
           ia = new int[nfile];
           ja = new int[nfile];
           tmpFile = new String[nfile];
           for (int tt = 0 ; tt < nfile ; tt++){
             s = bin.readLine();
             index0=0;
             index1=0;
             index1 = s.indexOf(' ',index0);
             ia[tt] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             index1 = s.indexOf(' ',index0);
             ja[tt] = Integer.parseInt((s.substring(index0,index1).trim()));
             index0 = index1+1;
             tmpFile[tt] = s.substring(index0,s.length()).trim();
           }
           s = bin.readLine();
           if (s.equals("Loop")) flag=8;
       }
       }
       if(flag!=8)JOptionPane.showMessageDialog(this,"Error opening this file","Error",JOptionPane.ERROR_MESSAGE);
       else{
         int tmpi = 0;
         while ((s = bin.readLine()) != null){
           index0=0;
           index1=0;
           if(flag == 8){
             nloopp = Integer.parseInt((s.substring(index0,s.length()).trim()));
             flag = 9;
             loopp = new int[nloopp][4];
             continue;
           }
           else if(flag==9){
             int tmpj = 0;
             while (index0 < s.length())
             {
               index1 = s.indexOf(' ',index0);
               loopp[tmpi][tmpj] = Integer.parseInt((s.substring(index0,index1).trim()));
               index0 = index1+1;
               tmpj++;
             }
             tmpi++;
             continue;
           }
         }

       bin.close();

       tmploop = new Loop[nloopp];

       n = 0;

       while(hhh>h){IncreaseHeight();}
       while(www>w){IncreaseWide();}
       while(hhh<h){DecreaseHeight();}
       while(www<w){DecreaseWide();}

       qualityofpic = new int[w*2][h*2];
       IsTopLeft = new boolean[w*2][h*2];
       tabl = new int[h*2][w*2];
       orange = new int[h*2][w*2];

       for(int p = 0 ; p < w*2 ; p++ ){
         for(int q = 0 ; q < h*2 ; q++ ){
           qualityofpic[p][q] = 0;
           IsTopLeft[p][q] = false;
           tabl[q][p] = tmp[q][p];
           orange[q][p] = orang[q][p];
         }
       }

       for(int p = 0 ; p < w*2 ; p++){
         for(int q = 0 ; q < h*2 ; q++){
           int hh,ww;
               ww = p;
               hh = q;
           if(tmp[q][p]!=0 && tmp[q][p]!=14){
             n++;

             if(tmp[q][p]==4){
               IsTopLeft[p][q] = true;
               qualityofpic[p][q] = n;
               tmp[q][p] = 0;
               LoadBlock(p,q,ww,hh);
             }
             else if(tmp[q][p]==13){
               IsTopLeft[p][q] = true;
               qualityofpic[p+1][q+1] = n;
               qualityofpic[p][q+1] = n;
               qualityofpic[p+1][q] = n;
               qualityofpic[p][q] = n;
               tmp[q+1][p+1] = 0;
               tmp[q][p+1] = 0;
               tmp[q+1][p] = 0;
               tmp[q][p] = 0;
               LoadBlock(p,q,ww,hh);
               n++;
               int u=0;
               int v=0;
               for(int l = 0 ; l < nloopp ; l++){
                 if(loopp[l][0]==p && loopp[l][1]==q){
                   IsTopLeft[loopp[l][2]][loopp[l][3]] = true;
                   qualityofpic[loopp[l][2]+1][loopp[l][3]+1] = n;
                   qualityofpic[loopp[l][2]][loopp[l][3]+1] = n;
                   qualityofpic[loopp[l][2]+1][loopp[l][3]] = n;
                   qualityofpic[loopp[l][2]][loopp[l][3]] = n;
                   tmp[loopp[l][3]+1][loopp[l][2]+1] = 0;
                   tmp[loopp[l][3]][loopp[l][2]+1] = 0;
                   tmp[loopp[l][3]+1][loopp[l][2]] = 0;
                   tmp[loopp[l][3]][loopp[l][2]] = 0;
                   LoadBlock(loopp[l][2],loopp[l][3],ww,hh);
                   u = loopp[l][2];
                   v = loopp[l][3];
                 }
               }

               tmploop[nloop] = new Loop(p,q,u,v,n-1,n);
               nloop++;

             }
             else{
               IsTopLeft[p][q] = true;
               qualityofpic[p+1][q+1] = n;
               qualityofpic[p][q+1] = n;
               qualityofpic[p+1][q] = n;
               qualityofpic[p][q] = n;
               tmp[q+1][p+1] = 0;
               tmp[q][p+1] = 0;
               tmp[q+1][p] = 0;
               tmp[q][p] = 0;
               LoadBlock(p,q,ww,hh);

             }
           }
         }
       }
       file = new File[n];
       filelabel = new JLabel[n];
       int kk = 0;
       int ll = 0;
       for(int ii=0;ii<n;ii++){
         kk = 0;
         ll = 0;
         if(typeofpic[ii]==27){
             boolean tmpboolean=false;
             for(kk=0;kk<w*2;kk++){
               for(ll=0;ll<h*2;ll++){

                 if(qualityofpic[kk][ll]==ii+1){

                   for(int jj=0;jj<nfile;jj++){
                     if(ia[jj]==kk&&ja[jj]==ll){
                       file[ii] = new File(tmpFile[jj]);
                       filelabel[ii] = new JLabel(file[ii].getName());
                       tmpboolean=true;
                       break;
                     }
                   }
                 }
                 if(tmpboolean)break;
               }
               if(tmpboolean)break;
             }
         }else{
           file[ii]=null;
           filelabel[ii] = new JLabel("");
         }
         SetFilePosition(ii,kk,ll);
       }

       SetOther(w,h,-1);
       ShowLoop();
       SetBackground(w,h);

       while(h<7){IncreaseHeight();}
       while(w<7){IncreaseWide();}
       }
     }
     catch (EOFException endOfFileException) {
       JOptionPane.showMessageDialog(this,"No more records in file","End of File",JOptionPane.ERROR_MESSAGE);
     }
     catch (IOException ioException) {
       JOptionPane.showMessageDialog(this,"Error during read from file","Read Error",JOptionPane.ERROR_MESSAGE);
     }
   }

   private void LoadBlock(int p,int q,int ww,int hh){
     JLabel tmp3[] = new JLabel[n-1];
     int tmp5[] = new int[n-1];
     int tmp6[] = new int[n-1];
     JLabel tmp2[] = new JLabel[n-1];

     for (int r = 0 ; r < n-1 ; r++){
       tmp3[r] = Block[r];
       tmp5[r] = typeofpic[r];
       tmp6[r] = qualityoforange[r];
       tmp2[r] = textlabel[r];
     }
     Block = new JLabel[n];
     typeofpic = new int[n];
     qualityoforange = new int[n];
     textlabel = new JLabel[n];

     for (int r = 0 ; r < n-1 ; r++){
       Block[r] = tmp3[r];
       typeofpic[r] = tmp5[r];
       qualityoforange[r] = tmp6[r];
       textlabel[r] = tmp2[r];
     }
     typeofpic[n-1]=tabl[q][p];
     qualityoforange[n-1]=orange[q][p];
     textlabel[n-1] = new JLabel("");
     SetTextPosition(n-1,ww,hh,typeofpic[n-1],qualityoforange[n-1]);
     Block[n-1] = new JLabel(CheckPictures(typeofpic[n-1]));
     jPanel2.add( Block[n-1], new XYConstraints(ww*30, hh*30, 60, 60) );
   }

   private void addRecord()
   {
     int[][] tmp = new int[h*2][w*2];
     boolean[][] t = new boolean[h*2][w*2];
     for(int i = 0; i<h*2 ; i++){
       for(int j = 0; j<w*2 ; j++){
         t[i][j]=IsTopLeft[j][i];
         tmp[i][j]=tabl[i][j];
       }
     }

     //----------------- Write to File -----------------
     try {
       FileWriter fout = new FileWriter(Name);
       BufferedWriter bout = new BufferedWriter(fout);
       PrintWriter pout = new PrintWriter(bout);

       pout.println("Size");
       pout.println(h+" "+w);

       pout.println("Table");
       for(int i = 0; i<h*2 ; i++){
         for(int j = 0; j<w*2 ; j++){
           pout.print(tmp[i][j]+" ");
         }
         pout.println();
       }
       pout.println("Orange");
       for(int i = 0; i<h*2 ; i++){
         for(int j = 0; j<w*2 ; j++){
           pout.print(orange[i][j]+" ");
         }
         pout.println();
       }


       pout.println("BlackBox");
       int tmpn = 0;
       for(int i = 0;i < n;i++){
         if(typeofpic[i] == 27)
           tmpn++;
       }
       pout.println(tmpn);
       tmpn = 0;
       for(int i = 0;i < n;i++){
         if(typeofpic[i] == 27){
           for(int ia = 0; ia<w*2 ; ia++){
             boolean tmpboo = false;
             for(int ja = 0; ja<h*2 ; ja++){
               if (qualityofpic[ia][ja] == i+1){
                 pout.println(ia+" "+ja+" "+file[i]);
                 tmpboo=true;
                 break;
               }
             }
             if(tmpboo)break;
           }
         }
       }

       pout.println("Loop");
       pout.println(nloop);


       for(int k = 0;k<nloop;k++){
         pout.println(tmploop[k].loopx+ " "+tmploop[k].loopy+ " "+tmploop[k].endloopx+ " "+tmploop[k].endloopy +" ");
       }


         pout.println();
       for(int i = 0; i<nloop ; i++){

         pout.println();
       }
       pout.close();
       output.flush();
     }
     catch(NumberFormatException formatException)
     {
       JOptionPane.showMessageDialog(this,"Bad account number or balance","Invalid Number Format",JOptionPane.ERROR_MESSAGE);
     }
     catch(IOException ioException)
     {
       JOptionPane.showMessageDialog(this,"Error writing to file","IO Exception",JOptionPane.ERROR_MESSAGE);
       CloseInputFile();
     }
  }
boolean tmpbooo = false;
  private void animetion(){
    jButton27.setEnabled(true);
    jButton25.setEnabled(true);
    jButton1.setEnabled(false);
    jButton2.setEnabled(false);
    jButton3.setEnabled(false);
    jButton4.setEnabled(false);
    jButton5.setEnabled(false);
    jButton6.setEnabled(false);
    jButton7.setEnabled(false);
    jButton8.setEnabled(false);
    jButton9.setEnabled(false);
    jButton10.setEnabled(false);
    jButton11.setEnabled(false);
    jButton12.setEnabled(false);
    jButton13.setEnabled(false);
    jButton14.setEnabled(false);
    jButton15.setEnabled(false);
    jButton16.setEnabled(false);
    jButton17.setEnabled(false);
    jButton18.setEnabled(false);
    jButton19.setEnabled(false);
    jButton20.setEnabled(false);
    jButton21.setEnabled(false);
    jButton22.setEnabled(false);
    jButton23.setEnabled(false);
    jButton24.setEnabled(false);
    jButton26.setEnabled(false);
    jButton28.setEnabled(false);
    jButton29.setEnabled(false);
    animetionfinish = false;

    firstupdown = true;
    norange = 0;
    l = 0;
    lx = new int[15];
    ly = new int[15];
    lz = new int[15];
    lxx = new int[15];
    lyy = new int[15];
    lb = new boolean[15];
    lbb = new boolean[15];
    tmpbooo = false;
    for(int i = 0 ; i< 15 ; i++){
      lx[i]=0;
      ly[i]=0;
      lz[i]=0;
      lxx[i]=0;
      lyy[i]=0;
      lb[i]=false;
      lbb[i]=false;
    }
    qwq=true;
    havebox = false;
    xx = 0;
    yy = 0;
    xxx = 0;
    yyy = 0;
    operator = false;
    looplabel = new JLabel[nloop];
    int tmp[][] = new int[h*2][w*2];
    for(int i = 0 ; i< h*2 ; i++){
      for( int j = 0 ; j < w*2 ; j++){
        tmp[i][j]=orange[i][j];
      }
    }

    arrowdown = new boolean[h*2][w*2];

    nop=0;
    for(int i = 0 ; i< h*2 ; i++){
      for( int j = 0 ; j < w*2 ; j++){
        arrowdown[i][j]=false;
        if(tabl[i][j]==1){
          xx = i-1;
          yy = j-1;
        }
        if(qualityofpic[j][i]!=0){
        if(typeofpic[qualityofpic[j][i]-1]==13&&tmp[i][j]!=0){
          haveloop[i][j]=tmp[i][j];
          tmp[i+1][j+1]=0;
          tmp[i+1][j]=0;
          tmp[i][j+1]=0;
        }
        else haveloop[i][j]=0;

        if(typeofpic[qualityofpic[j][i]-1]==13 && IsTopLeft[j][i]){
          looplabel[nop] = new JLabel(Integer.toString(orange[i][j]-haveloop[i][j]));
          jPanel2.add( looplabel[nop], new XYConstraints(j*30+47, i*30-15, 60, 60));
          nop++;
        }
        }
      }
    }

    jPanel2.revalidate();
    SetOther(w,h,-1);
    SetLoop(true);
    SetBackground(w,h);
  }
  int nop;
//------------------------------------------------------------------------------
  private void IncreaseHeightX(){
    IncreaseHeight();
    for(int j = h*2 -3;j>=0;j--){

      for (int i = 0; i<w*2 ; i++ )
      {
        qualityofpic[i][j+2] = qualityofpic[i][j];
        IsTopLeft[i][j+2] = IsTopLeft[i][j];
        tabl[j+2][i] = tabl[j][i];
        orange[j+2][i] = orange[j][i];
        qualityofpic[i][j] = 0;
        IsTopLeft[i][j] = false;
        tabl[j][i] = 0;
        orange[j][i] = 0;
      }



    }
    for(int i = 0 ; i < nloop ; i++){
      tmploop[i].loopy = tmploop[i].loopy + 2;
      tmploop[i].endloopy = tmploop[i].endloopy + 2;
    }
  }

  private void IncreaseWideX(){
    IncreaseWide();
    for(int i = w*2 -3;i>=0;i--){

    for (int j = 0; j<h*2 ; j++ )
    {
      qualityofpic[i+2][j] = qualityofpic[i][j];
      IsTopLeft[i+2][j] = IsTopLeft[i][j];
      tabl[j][i+2] = tabl[j][i];
      orange[j][i+2] = orange[j][i];
      qualityofpic[i][j] = 0;
      IsTopLeft[i][j] = false;
      tabl[j][i] = 0;
      orange[j][i] = 0;
    }

  }
  for(int i = 0 ; i < nloop ; i++){
    tmploop[i].loopx = tmploop[i].loopx + 2;
    tmploop[i].endloopx = tmploop[i].endloopx + 2;
  }
  }

  private void DecreaseHeight(){

    int tmp[][] = new int[w*2][h*2];
    boolean tmp2[][] = new boolean[w*2][h*2];
    int tmp3[][] = new int[w*2][h*2];
    int tmp4[][] = new int[w*2][h*2];

    for (int j = 0; j<h*2-2 ; j++ )
      for (int i = 0; i<w*2 ; i++ )
        {
          tmp[i][j] = qualityofpic[i][j];
          tmp2[i][j] = IsTopLeft[i][j];
          tmp3[i][j] = tabl[j][i];
          tmp4[i][j] = orange[j][i];
        }
        for (int i = 0 ; i < w ; i++) jPanel2.remove( Background[i][h-1] );
    h--;
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    qualityofpic = new int[w*2][h*2];
    IsTopLeft = new boolean[w*2][h*2];
    tabl = new int[h*2][w*2];
    orange = new int[h*2][w*2];
    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
          qualityofpic[i][j] = tmp[i][j];
          IsTopLeft[i][j] = tmp2[i][j];
          tabl[j][i] = tmp3[i][j];
          orange[j][i] = tmp4[i][j];
        }
  }

  private void IncreaseHeight(){

    int tmp[][] = new int[w*2][h*2];
    boolean tmp2[][] = new boolean[w*2][h*2];
    int tmp3[][] = new int[w*2][h*2];
    int tmp4[][] = new int[w*2][h*2];
    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
          tmp[i][j] = qualityofpic[i][j];
          tmp2[i][j] = IsTopLeft[i][j];
          tmp3[i][j] = tabl[j][i];
          tmp4[i][j] = orange[j][i];
        }
    SetOther(w,h,Pressnumber);
    SetBackground(w,h+1);
    qualityofpic = new int[w*2][h*2];
    IsTopLeft = new boolean[w*2][h*2];
    tabl = new int[h*2][w*2];
    orange = new int[h*2][w*2];

    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2-2 ; j++ )
        {
          qualityofpic[i][j] = tmp[i][j];
          IsTopLeft[i][j] = tmp2[i][j];
          tabl[j][i] = tmp3[i][j];
          orange[j][i] = tmp4[i][j];
        }

    for (int i = 0; i<w*2 ; i++ )
      {
        qualityofpic[i][h*2-2] = 0;
        qualityofpic[i][h*2-1] = 0;
        IsTopLeft[i][h*2-2] = false;
        IsTopLeft[i][h*2-1] = false;
        tabl[h*2-2][i] = 0;
        tabl[h*2-1][i] = 0;
        orange[h*2-2][i] = 0;
        orange[h*2-1][i] = 0;
      }

  }

  private void DecreaseWide(){

    int tmp[][] = new int[w*2][h*2];
    boolean tmp2[][] = new boolean[w*2][h*2];
    int tmp3[][] = new int[w*2][h*2];
    int tmp4[][] = new int[w*2][h*2];

    for (int i = 0; i<w*2-2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
          tmp[i][j] = qualityofpic[i][j];
          tmp2[i][j] = IsTopLeft[i][j];
          tmp3[i][j] = tabl[j][i];
          tmp4[i][j] = orange[j][i];
        }
        for (int j = 0 ; j < h ; j++) jPanel2.remove( Background[w-1][j] );
    w--;
    SetOther(w,h,Pressnumber);
    SetLoop(true);
    SetBackground(w,h);
    qualityofpic = new int[w*2][h*2];
    IsTopLeft = new boolean[w*2][h*2];
    tabl = new int[h*2][w*2];
    orange = new int[h*2][w*2];

    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
          qualityofpic[i][j] = tmp[i][j];
          IsTopLeft[i][j] = tmp2[i][j];
          tabl[j][i] = tmp3[i][j];
          orange[j][i] = tmp4[i][j];
        }
  }

  private void IncreaseWide(){

    int tmp[][] = new int[w*2][h*2];
    boolean tmp2[][] = new boolean[w*2][h*2];
    int tmp3[][] = new int[w*2][h*2];
    int tmp4[][] = new int[w*2][h*2];

    for (int i = 0; i<w*2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
          tmp[i][j] = qualityofpic[i][j];
          tmp2[i][j] = IsTopLeft[i][j];
          tmp3[i][j] = tabl[j][i];
          tmp4[i][j] = orange[j][i];
        }

    SetOther(w,h,Pressnumber);
    SetBackground(w+1,h);
    qualityofpic = new int[w*2][h*2];
    IsTopLeft = new boolean[w*2][h*2];
    tabl = new int[h*2][w*2];
    orange = new int[h*2][w*2];

    for (int i = 0; i<w*2-2 ; i++ )
      for (int j = 0; j<h*2 ; j++ )
        {
          qualityofpic[i][j] = tmp[i][j];
          IsTopLeft[i][j] = tmp2[i][j];
          tabl[j][i] = tmp3[i][j];
          orange[j][i] = tmp4[i][j];
        }
    for (int j = 0; j<h*2 ; j++ )
      {
        qualityofpic[w*2-2][j] = 0;
        qualityofpic[w*2-1][j] = 0;
        IsTopLeft[w*2-2][j] = false;
        IsTopLeft[w*2-1][j] = false;
        tabl[j][w*2-2] = 0;
        tabl[j][w*2-1] = 0;
        orange[j][w*2-2] = 0;
        orange[j][w*2-1] = 0;
      }
  }

  private Loop tmploop[] = new Loop [nloop];
  private JButton jButton27 = new JButton();
  private JButton jButton28 = new JButton();
  private JButton jButton29 = new JButton();

  private void ShowLoop(){
    for(int i = 0 ; i < nloop ; i++){
  tmploop[i].findrange();
  int xloop = tmploop[i].loopx;
  int yloop = tmploop[i].loopy;
  int xendloop = tmploop[i].endloopx;
  int yendloop = tmploop[i].endloopy;
  int nlabel = 0;

  tmploop[i].labelloop = new JLabel[tmploop[i].nlabelloop];

  while(xloop>xendloop){
    xloop = xloop - 2;
    tmploop[i].labelloop[nlabel] = new JLabel(Wayg4);
    jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

    nlabel++;
  }

  xloop = xloop - 2;

  tmploop[i].labelloop[nlabel] = new JLabel(Wayg1);
  jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

  nlabel++;
  while(yloop<yendloop-2){
    yloop = yloop + 2;

    tmploop[i].labelloop[nlabel] = new JLabel(Wayg2);
    jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

    nlabel++;
  }
  yloop = yloop + 2;

  tmploop[i].labelloop[nlabel] = new JLabel(Wayg3);
  jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

  nlabel++;

  while(xloop<xendloop-2){
    xloop = xloop + 2;

    tmploop[i].labelloop[nlabel] = new JLabel(Wayg4);
    jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

    nlabel++;
  }
  xloop = xloop + 2;

    }
  }

  public int[] findpartner(int x,int y){
    int a[] = new int[2];
    for(int i=0;i<nloop;i++){
      if(y==tmploop[i].loopx && x==tmploop[i].loopy){
        a[0] = tmploop[i].endloopy;
        a[1] = tmploop[i].endloopx;
        return a;
      }
      else if(y==tmploop[i].endloopx && x==tmploop[i].endloopy){
        a[0] = tmploop[i].loopy;
        a[1] = tmploop[i].loopx;
        return a;
      }
    }
    a[0]=-1;
    a[1]=-1;
    return a;
  }

  private void SetLoop(boolean t){

    for(int i = 0 ; i < nloop ; i++){


      for(int j = 0 ; j < tmploop[i].nlabelloop ; j ++){
        if(t){
          jPanel2.remove( tmploop[i].labelloop[j]);
        }
        else if(i != nloop-1){
          jPanel2.remove( tmploop[i].labelloop[j]);
        }
      }
      tmploop[i].findrange();
      int xloop = tmploop[i].loopx;
      int yloop = tmploop[i].loopy;
      int xendloop = tmploop[i].endloopx;
      int yendloop = tmploop[i].endloopy;
      int nlabel = 0;
      tmploop[i].labelloop = new JLabel[tmploop[i].nlabelloop];

      while(xloop>xendloop){
        xloop = xloop - 2;
        tmploop[i].labelloop[nlabel] = new JLabel(Wayg4);
        jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

        nlabel++;
      }

      xloop = xloop - 2;

      tmploop[i].labelloop[nlabel] = new JLabel(Wayg1);
      jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

      nlabel++;
      while(yloop<yendloop-2){
        yloop = yloop + 2;

        tmploop[i].labelloop[nlabel] = new JLabel(Wayg2);
        jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

        nlabel++;
      }
      yloop = yloop + 2;

      tmploop[i].labelloop[nlabel] = new JLabel(Wayg3);
      jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

      nlabel++;

      while(xloop<xendloop-2){
        xloop = xloop + 2;

        tmploop[i].labelloop[nlabel] = new JLabel(Wayg4);
        jPanel2.add( tmploop[i].labelloop[nlabel], new XYConstraints(xloop*30, yloop*30, 60, 60) );

        nlabel++;
      }
      xloop = xloop + 2;

    }

  }

  private void SetBackground(int x,int y){
    if(ttmp){
      jPanel2.remove(Box);
      jPanel2.remove(TextBox);
      ttmp = false;
    }

    if(IsSetBackground){
      for (int i = 0 ; i < w ; i++)
        for (int j = 0 ; j < h ; j++) jPanel2.remove( Background[i][j] );

    }

    if(x!=w)w=w+1;
    if(y!=h)h=h+1;

    Background = new JLabel[x][y];

    for (int i = 0 ; i < x ; i++)
      for (int j = 0 ; j < y ; j++){
    Background[i][j] = new JLabel(background);

    jPanel2.add( Background[i][j], new XYConstraints(i*60, j*60, 60, 60) );

    jPanel2.revalidate();
    IsSetBackground = true;
      }

  }


  private void SetOther(int x,int y,int z){
    boolean temp;
    if(err)jPanel2.remove(Error);
    err = false;
    for (int k = 0 ; k < n ; k++){
      temp = false;
      if(k!=z-1){
        temp = true;
      }
      if(z>0){
        if(typeofpic[z-1]==13 && k==z)temp = false;
      }
        if(temp){
        jPanel2.remove(Block[k]);

        if(z != -1){
          jPanel2.remove(filelabel[k]);
          jPanel2.remove(textlabel[k]);
        }
        for (int o = 0 ; o < w*2 ; o++){
          for (int p = 0 ; p < h*2 ; p++)
            {
              if(qualityofpic[o][p] == k+1 && IsTopLeft[o][p] == true){
                if(qualityoforange[qualityofpic[o][p]-1]>=0 && IsCanPutOrange(typeofpic[qualityofpic[o][p]-1])){
                }
                  if(z != -1){
                    SetTextPosition(qualityofpic[o][p]-1,o,p,typeofpic[qualityofpic[o][p]-1],qualityoforange[qualityofpic[o][p]-1]);
                    SetFilePosition(qualityofpic[o][p]-1,o,p);
                  }
                if(typeofpic[k]!=4){
                  if(typeofpic[k]==13 && !animetionfinish){
                    if(haveloop[p][o]==0){
                      Block[k] = new JLabel(createImageIcon("images/loop2.gif"));
                    }
                    else{
                      Block[k] = new JLabel(createImageIcon("images/loop.gif"));
                    }
                  }

                  if(typeofpic[k]==14 && !animetionfinish){
                    if(arrowdown[p][o]){
                      Block[k] = new JLabel(createImageIcon("images/endloop2.gif"));
                    }
                    else{
                      Block[k] = new JLabel(createImageIcon("images/endloop.gif"));
                    }
                  }

                  jPanel2.add( Block[k], new XYConstraints(o*30, p*30, 60, 60) );
                }
                else{
                  jPanel2.add( Block[k], new XYConstraints(o*30, p*30, 30, 30) );
                }
              }
            }
        }
      //}


      }
    }
  }


  private void Save(){

      for (int p = 0 ; p < h*2 ; p++){
          for (int o = 0 ; o < w*2 ; o++)
            {
              if(qualityofpic[o][p]>=10)System.err.print(qualityofpic[o][p]+" ");
              else System.err.print(" "+qualityofpic[o][p]+" ");
            }
            System.err.print("   ");
            for (int o = 0 ; o < w*2 ; o++)
            {
              if(IsTopLeft[o][p]==true)System.err.print("T ");
              else System.err.print("F ");
            }
            System.err.print("   ");
            for (int o = 0 ; o < w*2 ; o++)
            {
              if(qualityofpic[o][p] == 0)
              {
                System.err.print(" 0 ");
                tabl[p][o] = 0;
              }
              else if(typeofpic[qualityofpic[o][p]-1]>=10)
              {
                System.err.print(typeofpic[qualityofpic[o][p]-1]+" ");
                tabl[p][o] = typeofpic[qualityofpic[o][p]-1];
              }
              else
              {
                System.err.print(" "+typeofpic[qualityofpic[o][p]-1]+" ");
                tabl[p][o] = typeofpic[qualityofpic[o][p]-1];
              }
            }
            System.err.print("   ");
            for (int o = 0 ; o < w*2 ; o++)
            {
              if(qualityofpic[o][p] == 0)
              {
                System.err.print(" 0 ");
                orange[p][o] = 0;
              }
              else if(qualityoforange[qualityofpic[o][p]-1]>=10)
              {
                System.err.print(qualityoforange[qualityofpic[o][p]-1]+" ");
                orange[p][o] = qualityoforange[qualityofpic[o][p]-1];
              }
              else
              {
                System.err.print(" "+qualityoforange[qualityofpic[o][p]-1]+" ");
                orange[p][o] = qualityoforange[qualityofpic[o][p]-1];
              }
            }
            System.err.print("   ");

            for (int o = 0 ; o < w*2 ; o++)
            {
              if(qualityofpic[o][p] == 0){
                System.err.print(" 0 ");
                //filetable[p][o] = null;
              }
              else if(file[qualityofpic[o][p]-1]==null)
              {
                System.err.print(" 1 ");
              }
              else
              {
                System.err.print(file[qualityofpic[o][p]-1]+ " ");
              }
            }
            System.err.println("");
        }
        System.err.println("-------------------------------------------");
  }

}