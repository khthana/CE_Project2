#include <stdio.h>
#include <conio.h>

int box;
int box;
void a();
void r();
int box;
int box;
int box;
void f();
void main()
{
     clrscr();
     a();
}

void a()
{
     box = 0;
     if (box >= 0)
     {
     box = 0;
     box = box - 2;
     r();
     box = 1;
     a();
     }
     else
     {
     if (box >= 1)
     {
     }
     else
     {
     box = box + 2;
     }
     box = box + 2;
     }
}


void r()
{
     f();
     box = 0;
}


void f()
{
     box = 0;
}

