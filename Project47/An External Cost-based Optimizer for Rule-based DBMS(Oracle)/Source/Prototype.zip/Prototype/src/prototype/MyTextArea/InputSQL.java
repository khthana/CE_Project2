package prototype.MyTextArea;

import javax.swing.JTextArea;
import java.awt.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class InputSQL
    extends JTextArea {

  private String Massage;
  boolean type;
  public InputSQL(boolean temp) {
    type = temp;
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

  }

  public String getMassage() {
    return Massage;
  }

  public void setMassage(String Massage) {
    this.Massage = Massage;
  }

  private void jbInit() throws Exception {
    if (type) {
      this.setBackground(new Color(235, 235, 255));
      this.setFont(new java.awt.Font("Dialog", 1, 14));
      this.setForeground(new Color(255, 100, 100));
    }
    else {
      this.setBackground(new Color(255, 235, 235));
      this.setFont(new java.awt.Font("Dialog", 1, 14));
      this.setForeground(new Color(100, 100, 255));
    }
  }

}
