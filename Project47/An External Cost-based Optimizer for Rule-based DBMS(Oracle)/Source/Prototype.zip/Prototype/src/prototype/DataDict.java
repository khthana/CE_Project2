package prototype;

import java.sql.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class DataDict {

  String driver = new String("com.borland.datastore.jdbc.DataStoreDriver");
  String url = new String("jdbc:borland:dslocal:DataStore\\DataStore.jds");
  String oracledriver = new String("oracle.jdbc.driver.OracleDriver");
  String oracleurl = new String("jdbc:oracle:thin:@localhost:1521:");

  private Connection connection, oraConnection;
  private Statement statement, oraStatement, oraStatement2, oraStatement3;
  private PreparedStatement psTablerowInsert, psColumnInsert;
  private PreparedStatement psTableCount, psColumnCount, psDeleteTable,
      psDeleteColumn;
  private ResultSet resultSet, oraTableset, oraRowset, oraColumnset,
      tempresultSet;
  private ResultSetMetaData metaData, metaData2;
  private String user;
  private String password;
  private String sid;
  private int numOftable;
  private int numOfcolumn;
  private int rowOftable;
  private int distinctValue, nullValue;
  private String maxValue, minValue;
  private boolean isIndex = false;
  private String columnType;


  public DataDict() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    try {
      Class.forName(driver);
      connection = DriverManager.getConnection(url, "null", "null");
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (ClassNotFoundException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }

  }

  /**
   * Analyze
   *
   * @param user String
   * @param passwd String
   */
  public void Analyze() {
    try {

      statement = oraConnection.createStatement(
          ResultSet.TYPE_SCROLL_INSENSITIVE,
          ResultSet.CONCUR_READ_ONLY);

      oraStatement = oraConnection.createStatement(
          ResultSet.TYPE_SCROLL_INSENSITIVE,
          ResultSet.CONCUR_READ_ONLY);

      oraStatement2 = oraConnection.createStatement(
          ResultSet.TYPE_SCROLL_INSENSITIVE,
          ResultSet.CONCUR_READ_ONLY);

      oraStatement3 = oraConnection.createStatement(
          ResultSet.TYPE_SCROLL_INSENSITIVE,
          ResultSet.CONCUR_READ_ONLY);

      oraTableset = oraStatement.executeQuery(
          "select TABLE_NAME from USER_ALL_TABLES");
      oraTableset.last();
      numOftable = oraTableset.getRow();
      oraTableset.first();

      psTableCount = connection.prepareStatement(
          "select count(*) from TABLEROW where USERNAME=? AND PASSWORD=? AND TABLENAME=?");
      psColumnCount = connection.prepareStatement("select count(*)  from COLUMNSTATE where USERNAME=? AND PASSWORD=? AND TABLENAME=? AND COLUMNNAME=?");

      psDeleteTable = connection.prepareStatement(
          "delete from tablerow where USERNAME=? AND PASSWORD=?");
      psDeleteColumn = connection.prepareStatement(
          "delete from columnstate where USERNAME=? AND PASSWORD=?");

      psTablerowInsert = connection.prepareStatement(
          "insert into TABLEROW values( ? , ? , ? , ?  )");

      psColumnInsert = connection.prepareStatement(
          "INSERT INTO COLUMNSTATE VALUES( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )");

      psColumnCount.setString(1, user);
      psColumnCount.setString(2, password);

      psTableCount.setString(1, user);
      psTableCount.setString(2, password);
      psTablerowInsert.setString(1, user);
      psTablerowInsert.setString(2, password);

      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);

      psDeleteTable.setString(1, user);
      psDeleteTable.setString(2, password);

      psDeleteColumn.setString(1, user);
      psDeleteColumn.setString(2, password);
      psDeleteTable.executeUpdate();
      psDeleteColumn.executeUpdate();

      // loop for each table

      for (int loop = 1; loop <= numOftable; loop++) {
        if (oraTableset.getString(1).equalsIgnoreCase("PLAN_TABLE")) {
          oraTableset.next();
          continue;
        }
        psTablerowInsert.setString(3, oraTableset.getString(1));
        psColumnInsert.setString(3, oraTableset.getString(1));
        psTableCount.setString(3, oraTableset.getString(1));
        psColumnCount.setString(3, oraTableset.getString(1));
        oraRowset = oraStatement2.executeQuery("select count(*) from " +
                                               oraTableset.getString(1));
        metaData = oraStatement3.executeQuery("select * from " +
                                              oraTableset.getString(1)).
            getMetaData();                                                     // metaDat for now table
        numOfcolumn = metaData.getColumnCount();
        oraRowset.next();
        rowOftable = oraRowset.getInt(1);
        psTablerowInsert.setInt(4, rowOftable);
        tempresultSet = psTableCount.executeQuery();
        tempresultSet.next();

        psTablerowInsert.execute();

        //loop for each column

        for (int loop2 = 1; loop2 <= numOfcolumn; loop2++) {
          psColumnInsert.setString(4, metaData.getColumnName(loop2));
          psColumnCount.setString(4, metaData.getColumnName(loop2));
          distinctValue = 0;
          nullValue = 0;
          oraColumnset = statement.executeQuery("select count(distinct " +
                                                metaData.getColumnName(loop2) +
                                                ") from " +
                                                oraTableset.getString(1));
          oraColumnset.next();
          distinctValue = oraColumnset.getInt(1);                                 // get distincValue
          oraColumnset = statement.executeQuery("select count(*) from " +
                                                oraTableset.getString(1) +
                                                " where " +
                                                metaData.getColumnName(loop2) +
                                                " is  null");
          oraColumnset.next();
          nullValue = oraColumnset.getInt(1);                                       // get nullValue
          if (nullValue == rowOftable) {
            maxValue = "null";
            minValue = "null";
          }
          else if (rowOftable > 0) {
            oraColumnset = statement.executeQuery("select max(" +
                                                  metaData.getColumnName(loop2) +
                                                  ") from " +
                                                  oraTableset.getString(1) + "");
            oraColumnset.next();
            maxValue = oraColumnset.getObject(1).toString();
            oraColumnset = statement.executeQuery("select min(" +
                                                  metaData.getColumnName(loop2) +
                                                  ") from " +
                                                  oraTableset.getString(1) + "");
            oraColumnset.next();
            minValue = oraColumnset.getObject(1).toString();
          }
          else {
            maxValue = "null";
            minValue = "null";
          }                                                          // get min,max value
          oraColumnset = statement.executeQuery("select " +
                                                metaData.getColumnName(loop2) +
                                                " from " +
                                                oraTableset.getString(1));
          metaData2 = oraColumnset.getMetaData();
          columnType = metaData2.getColumnTypeName(1);
          oraColumnset = statement.executeQuery(
              "select count(*) from user_ind_columns where column_name = '" +
              metaData.getColumnName(loop2) + "'  and  table_name = '" +
              oraTableset.getString(1) + "'  ");
          oraColumnset.next();
          if (oraColumnset.getInt(1) > 0)
            isIndex = true;
          else
            isIndex = false;

            //end one column
            //thisline for save value
          tempresultSet = psColumnCount.executeQuery();
          tempresultSet.next();

          psColumnInsert.setInt(5, distinctValue);
          psColumnInsert.setInt(6, nullValue);
          psColumnInsert.setString(7, minValue);
          psColumnInsert.setString(8, maxValue);
          psColumnInsert.setString(9, columnType);
          psColumnInsert.setBoolean(10, isIndex);
          psColumnInsert.execute();
        }

        oraTableset.next(); //  complete each table
      }

      psTablerowInsert.close();
      psColumnInsert.close();
      connection.commit();

    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(10), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }

  }

  /**
   * CheckFirst
   *
   * @param User String
   * @param Passwd String
   */
  public void CheckFirst(String User, String Passwd, String Sid) {
    try {
      user = User;
      password = Passwd;
      sid = Sid;
      Class.forName(oracledriver);
      oraConnection = DriverManager.getConnection(oracleurl + sid, user, Passwd);
      psTablerowInsert = connection.prepareStatement(
          "select count(*)  from TABLEROW where USERNAME  = ? and PASSWORD = ?");
      psTablerowInsert.setString(1, User);
      psTablerowInsert.setString(2, Passwd);
      resultSet = psTablerowInsert.executeQuery();

      resultSet.next();
      if (resultSet.getInt(1) == 0) {
        Analyze();
      }
      //  init driver oracle

    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (ClassNotFoundException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }

  }

  /**
   * GetNumOfRow
   *
   * @param TableName String
   */
  public int GetNumOfRow(String TableName) {
    int s = 0;
    try {
      psTablerowInsert = connection.prepareStatement(
          "SELECT ROW FROM TABLEROW WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =?");
      psTablerowInsert.setString(1, user);
      psTablerowInsert.setString(2, password);
      psTablerowInsert.setString(3, TableName);
      resultSet = psTablerowInsert.executeQuery();
      resultSet.next();
      s = resultSet.getInt(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getSid() {
    return sid;
  }

  public void setSid(String sid) {
    this.sid = sid;
  }

  /**
   * GetDistinctValue
   *
   * @param TableName String
   * @param ColumnName String
   * @return int
   */
  public int GetDistinctValue(String TableName, String ColumnName) {
    int s = 0;
    try {
      psColumnInsert = connection.prepareStatement("SELECT DISTINCTVALUE  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, TableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      s = resultSet.getInt(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;

  }

  /**
   * GetNumOfNull
   *
   * @param TableName String
   * @param ColumnName String
   * @return int
   */
  public int GetNumOfNull(String TableName, String ColumnName) {
    int s = 0;
    try {
      psColumnInsert = connection.prepareStatement("SELECT NULLVALUE  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, TableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      s = resultSet.getInt(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;
  }

  /**
   * GetMinValue
   *
   * @param TableName String
   * @param ColumnName String
   * @return String
   */
  public String GetMinValue(String TableName, String ColumnName) {
    String s = "";
    try {
      psColumnInsert = connection.prepareStatement("SELECT MINVALUE  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, TableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      s = resultSet.getString(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;

  }

  /**
   * GetMaxValue
   *
   * @param TableName String
   * @param ColumnName String
   * @return String
   */
  public String GetMaxValue(String TableName, String ColumnName) {
    String s = "";
    try {
      psColumnInsert = connection.prepareStatement("SELECT MAXVALUE  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, TableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      s = resultSet.getString(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;

  }

  /**
   * GetDataType
   *
   * @param TableName String
   * @param ColumnName String
   * @return String
   */
  public String GetDataType(String TableName, String ColumnName) {
    String s = "";
    try {
      psColumnInsert = connection.prepareStatement("SELECT DATATYPE  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, TableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      s = resultSet.getString(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;

  }

  /**
   * IsIndex
   *
   * @param TableName String
   * @param ColumnName String
   * @return boolean
   */
  public boolean IsIndex(String TableName, String ColumnName) {
    boolean s = false;
    try {
      psColumnInsert = connection.prepareStatement("SELECT ISINDEX  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, TableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      s = resultSet.getBoolean(1);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    return s;
  }

  /**
   * GetExistTable
   *
   * @param tableName String
   * @return boolean
   */
  public boolean GetExistTable(String tableName) {
    boolean output = false;
    try {
      psTablerowInsert = connection.prepareStatement("SELECT COUNT(*)  FROM TABLEROW WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =?");
      psTablerowInsert.setString(1, user);
      psTablerowInsert.setString(2, password);
      psTablerowInsert.setString(3, tableName);
      resultSet = psTablerowInsert.executeQuery();
      resultSet.next();
      if (resultSet.getInt(1) >= 1)
        output = true;
      else
        output = false;

    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }

    return output;
  }

  /**
   * GetExistColumn
   *
   * @param tableName String
   * @param ColumnName String
   * @return boolean
   */
  public boolean GetExistColumn(String tableName, String ColumnName) {
    boolean output = false;
    try {
      psColumnInsert = connection.prepareStatement("SELECT COUNT(*)  FROM COLUMNSTATE  WHERE USERNAME = ? AND PASSWORD = ? AND TABLENAME =? AND COLUMNNAME =?");
      psColumnInsert.setString(1, user);
      psColumnInsert.setString(2, password);
      psColumnInsert.setString(3, tableName);
      psColumnInsert.setString(4, ColumnName);
      resultSet = psColumnInsert.executeQuery();
      resultSet.next();
      if (resultSet.getInt(1) >= 1)
        output = true;
      else
        output = false;
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }

    return output;
  }

}
