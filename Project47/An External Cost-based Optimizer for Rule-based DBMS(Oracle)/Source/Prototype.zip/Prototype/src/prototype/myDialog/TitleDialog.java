package prototype.myDialog;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class TitleDialog
    extends JDialog {

  JButton Ok = new JButton();
 // JLabel TitlePicture = new JLabel();
 Icon image1 = new ImageIcon("test.gif");
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();



  public TitleDialog() throws HeadlessException {

    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

  }

  private void jbInit() throws Exception {

    setSize(new Dimension(312, 279));
    setModal(true);
    setTitle("LogOn");
    this.getContentPane().setLayout(null);

    Ok.setText("��");
    Ok.setBounds(new Rectangle(103, 207, 107, 31));
    Ok.addActionListener(new TigleDialog_jButton1_actionAdapter(this));

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation( (screenSize.width - frameSize.width) / 2,
                     ( (screenSize.height - frameSize.height) / 2) - 20);
    jLabel1.setToolTipText("");
    jLabel1.setText("�ù���                      �ӹҭ����");
    jLabel1.setBounds(new Rectangle(77, 57, 176, 30));
    jLabel2.setBounds(new Rectangle(83, 81, 161, 30));
    jLabel2.setToolTipText("");
    jLabel2.setText("����ѡ���                       �Թ���");
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 17));
    jLabel3.setText("An External Cost-Base Optimizer");
    jLabel3.setBounds(new Rectangle(36, 16, 245, 53));
    jLabel4.setToolTipText("");
    jLabel4.setText("ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ");
    jLabel4.setBounds(new Rectangle(21, 148, 271, 27));
    jLabel5.setText("�ա���֡�� 2547");
    jLabel5.setBounds(new Rectangle(117, 167, 85, 31));
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(Ok, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jLabel5, null);
    this.getContentPane().add(jLabel4, null);


  }

  void jButton1_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }

  /**
   * paint
   *
   * @param g Graphics
   */


}

class TigleDialog_jButton1_actionAdapter
    implements java.awt.event.ActionListener {
  TitleDialog adaptee;

  TigleDialog_jButton1_actionAdapter(TitleDialog adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}
