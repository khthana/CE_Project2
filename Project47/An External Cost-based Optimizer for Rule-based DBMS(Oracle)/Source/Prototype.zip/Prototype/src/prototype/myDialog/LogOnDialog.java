package prototype.myDialog;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class LogOnDialog
    extends JDialog {

  JPanel panel1                                     = new JPanel();
  JLabel jLabel1                                   = new JLabel();
  JLabel jLabel2                                   = new JLabel();
  JLabel jLabel3                                   = new JLabel();
  JButton Ok                                          = new JButton();
  JButton Cancle                                  = new JButton();

  public JTextField UserName           = new JTextField();
  public JPasswordField Password = new JPasswordField();
  public JTextField Sid                         = new JTextField();


  private String inputName;
  private String inputPassword;
  private String inputSid;
  private boolean ok;

  public LogOnDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public LogOnDialog() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1 = (JPanel)this.getContentPane();
    panel1.setLayout(null);
    setSize(new Dimension(300, 262));
    setModal(true);
    setTitle("LogOn");



    jLabel1.setFont(new java.awt.Font("Dialog", 1, 15));
    jLabel1.setText("UserName");
    jLabel1.setBounds(new Rectangle(5, 42, 80, 25));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 15));
    jLabel2.setText("Password");
    jLabel2.setBounds(new Rectangle(5, 82, 80, 25));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 15));
    jLabel3.setText("Sid");
    jLabel3.setBounds(new Rectangle(5, 122, 80, 25));
    panel1.setBackground(new Color(245, 245, 245));
    panel1.setNextFocusableComponent(Ok);
    Ok.setBounds(new Rectangle(30, 186, 100, 35));
    Ok.setFont(new java.awt.Font("Dialog", 1, 15));
    Ok.setText("\u0E15\u0E01\u0E25\u0E07");
    Ok.addActionListener(new LogOnDialog_Ok_actionAdapter(this));
    Cancle.setBounds(new Rectangle(160, 186, 100, 35));
    Cancle.setFont(new java.awt.Font("Dialog", 1, 15));
    Cancle.setText("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
    Cancle.addActionListener(new LogOnDialog_Cancle_actionAdapter(this));

    UserName.setBounds(new Rectangle(100, 40, 170, 30));
    Password.setBounds(new Rectangle(100, 80, 170, 30));
    Sid.setBounds(new Rectangle(100, 120, 170, 30));
    Sid.addKeyListener(new LogOnDialog_Sid_keyAdapter(this));

    panel1.add(UserName);
    panel1.add(Password);
    panel1.add(jLabel1, null);
    panel1.add(jLabel2, null);
    panel1.add(Cancle, null);
    panel1.add(Ok, null);
    panel1.add(Sid, null);
    panel1.add(jLabel3, null);

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation( (screenSize.width - frameSize.width) / 2,
                     ( (screenSize.height - frameSize.height) / 2) - 20);

  }

  void Ok_actionPerformed(ActionEvent e) {
    this.inputName = this.UserName.getText();
    this.inputPassword = this.Password.getText();
    this.inputSid = this.Sid.getText();
    ok = true;
    dispose();
  }

  void Cancle_actionPerformed(ActionEvent e) {
    ok = false;
    dispose();
  }

  public String getInputName() {
    return inputName;
  }

  public void setInputName(String inputName) {
    this.inputName = inputName;
  }

  public String getInputPassword() {
    return inputPassword;
  }

  public void setInputPassword(String inputPassword) {
    this.inputPassword = inputPassword;
  }

  public boolean isOk() {
    return ok;
  }

  public void setOk(boolean ok) {
    this.ok = ok;
  }

  public void setInputSid(String inputSid) {
    this.inputSid = inputSid;
  }

  /**
   * getinputSid
   *
   * @return String
   */
  public String getinputSid() {
    return inputSid;
  }

  void Sid_keyPressed(KeyEvent e) {
     if (e.getKeyCode() == e.VK_ENTER) {
       ActionEvent e1=null;
       this.Ok_actionPerformed(e1);
     }
  }
}

class LogOnDialog_Ok_actionAdapter
    implements java.awt.event.ActionListener {
  LogOnDialog adaptee;

  LogOnDialog_Ok_actionAdapter(LogOnDialog adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.Ok_actionPerformed(e);
  }
}

class LogOnDialog_Cancle_actionAdapter
    implements java.awt.event.ActionListener {
  LogOnDialog adaptee;

  LogOnDialog_Cancle_actionAdapter(LogOnDialog adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.Cancle_actionPerformed(e);
  }
}

class LogOnDialog_Sid_keyAdapter extends java.awt.event.KeyAdapter {
  LogOnDialog adaptee;

  LogOnDialog_Sid_keyAdapter(LogOnDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.Sid_keyPressed(e);
  }
}
