package prototype;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;

import prototype.myDialog.*;

public class DButil
    extends AbstractTableModel {

  private Connection connection, DatastoreConnection;
  private Statement statement, DatastoreStatement;
  private ResultSet resultSet;
  private ResultSetMetaData metaData;
  private int numberOfRows;
  JFrame parent = new JFrame();
  long firstTime, lastTime, elapseTime;
  JProgressBar progressBar = new JProgressBar();

  LogOnDialog myLogonDialog = new LogOnDialog();
  String driver = new String("oracle.jdbc.driver.OracleDriver");
  String url = new String("jdbc:oracle:thin:@localhost:1521:");
  String query = new String("select TABLE_NAME,TABLE_LOCK,PARTITIONED,NESTED,TABLESPACE_NAME,PCT_FREE,PCT_USED from USER_ALL_TABLES");

  String Datastore_Driver = new String(
      "com.borland.datastore.jdbc.DataStoreDriver");
  String Datastore_Url = new String(
      "jdbc:borland:dslocal:DataStore\\DataStore.jds");

  // keep track of database connection status
  private boolean connectedToDatabase = false;
  private String user;
  private String passWord;
  private String sid;

  // initialize resultSet and obtain its meta data object;
  // determine number of rows
  public DButil(JFrame temp1, JProgressBar temp2) {
    parent = temp1;
    progressBar = temp2;
  }

  // get class that represents column type
  public Class getColumnClass(int column) throws IllegalStateException {
    // ensure database connection is available
    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to Database");

    // determine Java class of column
    try {
      String className = metaData.getColumnClassName(column + 1);

      // return Class object that represents className
      return Class.forName(className);
    }

    // catch SQLExceptions and ClassNotFoundExceptions
    catch (Exception exception) {
      exception.printStackTrace();
    }

    // if problems occur above, assume type Object
    return Object.class;
  }

  // get number of columns in ResultSet
  public int getColumnCount() throws IllegalStateException {
    // ensure database connection is available
    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to Database");

    // determine number of columns
    try {
      return metaData.getColumnCount();
    }

    // catch SQLExceptions and print error message
    catch (SQLException sqlException) {
      sqlException.printStackTrace();
    }

    // if problems occur above, return 0 for number of columns
    return 0;
  }

  // get name of a particular column in ResultSet
  public String getColumnName(int column) throws IllegalStateException {
    // ensure database connection is available
    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to Database");

    // determine column name
    try {
      return metaData.getColumnName(column + 1);
    }

    // catch SQLExceptions and print error message
    catch (SQLException sqlException) {
      sqlException.printStackTrace();
    }

    // if problems, return empty string for column name
    return "";
  }

  // return number of rows in ResultSet
  public int getRowCount() throws IllegalStateException {
    // ensure database connection is available
    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to Database");

    return numberOfRows;
  }

  // obtain value in particular row and column
  public Object getValueAt(int row, int column) throws IllegalStateException {
    // ensure database connection is available

    if (!connectedToDatabase)
      throw new IllegalStateException("Not Connected to Database");

    // obtain a value at specified ResultSet row and column
    try {
      resultSet.absolute(row + 1);
      progressBar.setValue(row + 1);
      return resultSet.getObject(column + 1);
    }

    // catch SQLExceptions and print error message
    catch (SQLException sqlException) {
      sqlException.printStackTrace();
    }

    // if problems, return empty string object
    return "";
  }

  // set new database query string
  public void setQuery(String query) {
    try {
      // ensure database connection is available
      if (!connectedToDatabase)
        throw new IllegalStateException("Not Connected to Database");
      // specify query and execute it
      firstTime = System.currentTimeMillis();

      resultSet = statement.executeQuery(query);
      lastTime = System.currentTimeMillis();
      elapseTime = lastTime - firstTime;

      // obtain meta data for ResultSet
      metaData = resultSet.getMetaData();

      // determine number of rows in ResultSet
      resultSet.last(); // move to last row
      numberOfRows = resultSet.getRow(); // get row number
      progressBar.setMaximum(numberOfRows);
      // notify JTable that model has changed
      fireTableStructureChanged();
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(parent, e.toString().substring(32), "Error",
                                    JOptionPane.DEFAULT_OPTION);

    }
  }

  // close Statement and Connection
  public void disconnectFromDatabase() {
    // close Statement and Connection
    try {
      statement.close();
      connection.close();
    }

    // catch SQLExceptions and print error message
    catch (SQLException sqlException) {
      sqlException.printStackTrace();
    }

    // update database connection status
    finally {
      connectedToDatabase = false;
    }
  }

  /**
   * Connect
   */
  public void Connect() {
    try {
      Class.forName(driver);
      // connect to database
      myLogonDialog.UserName.setText("");
      myLogonDialog.Password.setText("");

      myLogonDialog.show();
      user = myLogonDialog.getInputName();
      passWord = myLogonDialog.getInputPassword();
      sid = myLogonDialog.getinputSid();



      connection = DriverManager.getConnection(url + sid, user, passWord);
      DatastoreConnection = DriverManager.getConnection(Datastore_Url, "null",
          "null");

      myLogonDialog.Password.setText("");
      myLogonDialog.UserName.setText("");
      myLogonDialog.Sid.setText("");

      // create Statement to query database
      statement = connection.createStatement(
          ResultSet.TYPE_SCROLL_INSENSITIVE,
          ResultSet.CONCUR_READ_ONLY);

      DatastoreStatement = DatastoreConnection.createStatement(
          ResultSet.TYPE_SCROLL_INSENSITIVE,
          ResultSet.CONCUR_READ_ONLY);

      // update database connection status
      connectedToDatabase = true;

      // set query and execute it
      if (connectedToDatabase) {
        setQuery(query);
        /*data dict.analyze(result)                                         */
      }
    }
    catch (SQLException e) {
      connectedToDatabase = false;
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }
    catch (ClassNotFoundException e) {
      connectedToDatabase = false;
      JOptionPane.showMessageDialog(null, e.toString().substring(27), "Error",
                                    JOptionPane.ERROR_MESSAGE);
    }

  }

  public boolean isConnectedToDatabase() {
    return connectedToDatabase;
  }

  public long getElapseTime() {
    return elapseTime;
  }

  public int getNumberOfRows() {
    return numberOfRows;
  }

  public void setNumberOfRows(int numberOfRows) {
    this.numberOfRows = numberOfRows;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getPassWord() {
    return passWord;
  }

  public void setPassWord(String passWord) {
    this.passWord = passWord;
  }

  public String getSid() {
    return sid;
  }

  public void setSid(String sid) {
    this.sid = sid;
  }

  public void DataStoresetQuery(String query) {
    try {
      // ensure database connection is available

      firstTime = System.currentTimeMillis();
      resultSet = DatastoreStatement.executeQuery(query);
      lastTime = System.currentTimeMillis();
      elapseTime = lastTime - firstTime;

      // obtain meta data for ResultSet
      metaData = resultSet.getMetaData();

      // determine number of rows in ResultSet
      resultSet.last(); // move to last row
      numberOfRows = resultSet.getRow(); // get row number
      progressBar.setMaximum(numberOfRows);
      // notify JTable that model has changed
      fireTableStructureChanged();
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(parent, e.toString().substring(32), "Error",
                                    JOptionPane.DEFAULT_OPTION);

    }

  }

} // end class ResultSetTableModel
