package prototype;

import javax.swing.*;

public class Optimizer {
  private String input;
  private String output;
  private DataDict myDict;
  private MySqlStatement mysqlstmt = new MySqlStatement();
  public Optimizer() {

  }

  public String getInput() {
    return input;
  }

  public void setInput(String input) {
    this.input = input;
  }

  public String getOutput() {
    return output;
  }

  public double EstimateRowReturn(String table, String expr) { // return in % of rows return per all rows
    if (myDict.GetExistTable(table)) {
      boolean left_column = false;
      int nrows = myDict.GetNumOfRow(table), compare_index;
      int ndistinct = 0;
      String column = "";
      double min = 0, max = 0;
      double value = 0;
      String comparater = "";
      String left, right;
      if (expr.indexOf("!=") != -1) {
        compare_index = expr.indexOf("!=");
        comparater = "!=";
        left = expr.substring(0, compare_index);
        right = expr.substring(compare_index + 2);
      }
      else if (expr.indexOf("<=") != -1) {
        compare_index = expr.indexOf("<=");
        comparater = "<=";
        left = expr.substring(0, compare_index);
        right = expr.substring(compare_index + 2);
      }
      else if (expr.indexOf(">=") != -1) {
        compare_index = expr.indexOf(">=");
        comparater = ">=";
        left = expr.substring(0, compare_index);
        right = expr.substring(compare_index + 2);
      }
      else if (expr.indexOf("=") != -1) {
        compare_index = expr.indexOf("=");
        comparater = "=";
        left = expr.substring(0, compare_index);
        right = expr.substring(compare_index + 1);
      }
      else if (expr.indexOf("<") != -1) {
        compare_index = expr.indexOf("<");
        comparater = "<";
        left = expr.substring(0, compare_index);
        right = expr.substring(compare_index + 1);
      }
      else if (expr.indexOf(">") != -1) {
        compare_index = expr.indexOf(">");
        comparater = ">";
        left = expr.substring(0, compare_index);
        right = expr.substring(compare_index + 1);
      }
      else
        return 0.0; //not contain comparator in where clause ;return 0.0

      try {
        if (left.indexOf("'") == -1) {
          value = (double) Double.parseDouble(left);
        }
        else
          return 0.0;
      }
      catch (NumberFormatException ne) {
        column = left.toUpperCase();
        left_column = true;
      }
      try {
        if (right.indexOf("'") == -1) {
          value = (double) Double.parseDouble(right);
          if (!left_column) { // if two side is constants check boolean
            double vl = Double.parseDouble(left);
            double vr = Double.parseDouble(right);
            /*check return 100% or 0%*/
            if (comparater.equals("=")) {
              if (vl == vr) {
                return 100.00;
              }
              else
                return 0.0;
            }
            else if (comparater.equals("<")) {
              if (vl < vr) {
                return 100.00;
              }
              else
                return 0.0;
            }
            else if (comparater.equals(">")) {
              if (vl > vr) {
                return 100.00;
              }
              else
                return 0.0;
            }
            else if (comparater.equals("!=")) {
              if (vl != vr) {
                return 100.00;
              }
              else
                return 0.0;
            }
            else if (comparater.equals("<=")) {
              if (vl <= vr) {
                return 100.00;
              }
              else
                return 0.0;
            }
            else if (comparater.equals(">=")) {
              if (vl >= vr) {
                return 100.00;
              }
              else
                return 0.0;
            }

          }
          else { //left is column and right is constants
            if (comparater.equals("<=")) { // value <= 50 ---- value < 51
              comparater = "<";
              value++;
            }
            else if (comparater.equals(">=")) { // value >=50 ---- value > 49
              comparater = ">";
              value--;
            }
          }
        }
        else
          return 0.0;
      }
      catch (NumberFormatException ne) {
        column = right.toUpperCase();
        if (!left_column) { //if constant on left side ; 50 <= value -----  value >= 50
          if (comparater.equals("<"))
            comparater = ">";
          else if (comparater.equals(">")) //50 > value ---- value < 50
            comparater = "<";
          else if (comparater.equals("<=")) { //50 <= value ---- value > 49
            comparater = ">";
            value--;
          }
          else if (comparater.equals(">=")) { //50 >= value ---- value < 51
            comparater = "<";
            value++;
          }
        }
      }

      /******/
      if (myDict.GetExistColumn(table, column)) {
        if (myDict.GetDataType(table, column).equals("NUMBER")) {
          ndistinct = myDict.GetDistinctValue(table, column);
          min = Double.parseDouble(myDict.GetMinValue(table, column));
          max = Double.parseDouble(myDict.GetMaxValue(table, column));
        }
        else //if not type number return 0.0
          return 0.0;
      }
      else
        return 0.0;
      /*****/
      if ( ( (ndistinct * 1.0 / nrows) * 100) < 30) {
        return 0.0;
      }
      else {
        if (comparater.equals("=")) {
          if (min <= value && value <= max) {
            return ( (nrows * 1.0 / ndistinct) / nrows) * 100;
          }
          else
            return 0.0;
        }
        else if (comparater.equals("!=")) {
          if (min <= value && value <= max) {
            return 100.00 - ( (nrows * 1.0 / ndistinct) / nrows) * 100;
          }
          else
            return 100.0;
        }
        else if (comparater.equals("<")) {
          if (value < min) { // c< 50 < min=100 // c < min=100 --- 0.0%
            return 0.0;
          }
          if (value > max) {
            return 100.0;
          }
          else
            return (value - min) / (max - min) * 100.0;
        }
        else if (comparater.equals(">")) {
          if (value < min) { // c< 50 < min=100 // c < min=100 --- 0.0%
            return 100.0;
          }
          if (value > max) {
            return 0.0;
          }
          else
            return (max - value) / (max - min) * 100.0;
        }
      }
    }

    return 0.0;
  }

  private void OptimizeCatesian() {
    int rows[] = new int[mysqlstmt.getNumberOfTable()];
    String tb;
    for (int i = 0; i < mysqlstmt.getNumberOfTable(); i++) {
      if (mysqlstmt.getTable(i).indexOf(" ") != -1)
        tb = mysqlstmt.getTable(i).substring(0,
                                             mysqlstmt.getTable(i).indexOf(" ")).
            toUpperCase();
      else
        tb = mysqlstmt.getTable(i).toUpperCase();
      if (!myDict.GetExistTable(tb))
        rows[i] = 0;
      else
        rows[i] = myDict.GetNumOfRow(tb);
    }
    output = "SELECT /*+ rule */\n" + mysqlstmt.getSelectString() + "\nFROM ";
    int tempi;
    for (int i = 0; i < rows.length - 1; i++) {
      for (int j = 0; j < rows.length - 1 - i; j++) {
        if (rows[j + 1] > rows[j]) { // compare the two neighbors
          //swap
          tempi = rows[j];
          rows[j] = rows[j + 1];
          rows[j + 1] = tempi;
          mysqlstmt.swapTable(j, j + 1);
        }
      }
    }
    String from = mysqlstmt.getTable(0);
    for (int i = 1; i < mysqlstmt.getNumberOfTable(); i++) {
      from += "," + mysqlstmt.getTable(i);
    }
    output += from + "\n" + mysqlstmt.getWhere() + "\n" + mysqlstmt.getGroup_by() +
        "\n" + mysqlstmt.getHaving() + "\n" + mysqlstmt.getOrder_by();
  }

  private void OptimizeMultipleOr() { //Optimize when have multiple OR in where stmt and from same table
    output = "SELECT /*+ rule use_concat */\n" + mysqlstmt.getSelectString() +
        "\nFROM " + mysqlstmt.getFrom() + "\n" + mysqlstmt.getWhere() + "\n" +
        mysqlstmt.getGroup_by() + "\n" + mysqlstmt.getHaving() + "\n" +
        mysqlstmt.getOrder_by();
  }

  private void OptimizeMultipleJoin() { //Optimize when have multiple joins in multiple tables
    int rows[] = new int[mysqlstmt.getNumberOfTable()];
    String tb;
    for (int i = 0; i < mysqlstmt.getNumberOfTable(); i++) {
      if (mysqlstmt.getTable(i).indexOf(" ") != -1)
        tb = mysqlstmt.getTable(i).substring(0,
                                             mysqlstmt.getTable(i).indexOf(
            " ")).toUpperCase();
      else
        tb = mysqlstmt.getTable(i).toUpperCase();
      if (!myDict.GetExistTable(tb))
        rows[i] = 0;
      else
        rows[i] = myDict.GetNumOfRow(tb);
    }

    int tempi;
    for (int i = 0; i < rows.length - 1; i++) {
      for (int j = 0; j < rows.length - 1 - i; j++) {
        if (rows[j + 1] < rows[j]) { // compare the two neighbors
          //swap
          tempi = rows[j];
          rows[j] = rows[j + 1];
          rows[j + 1] = tempi;
          mysqlstmt.swapTable(j, j + 1);
        }
      }
    }
    String from = mysqlstmt.getTable(0);
    for (int i = 1; i < mysqlstmt.getNumberOfTable(); i++) {
      from += "," + mysqlstmt.getTable(i);
    }

    output = "SELECT /*+ ordered */\n" + mysqlstmt.getSelectString() +
        "\nFROM " + from + "\n" + mysqlstmt.getWhere() + "\n" +
        mysqlstmt.getGroup_by() + "\n" + mysqlstmt.getHaving() + "\n" +
        mysqlstmt.getOrder_by();

  }

  private void OptimizeFullScan(String table) { //Optimize when have multiple OR in where stmt and from same table
    output = "SELECT /*+ full(" + table + ") */" +
        mysqlstmt.getSelectString() +
        "\nFROM " + mysqlstmt.getFrom() + "\n" + mysqlstmt.getWhere() +
        "\n" + mysqlstmt.getGroup_by() + "\n" + mysqlstmt.getHaving() + "\n" +
        mysqlstmt.getOrder_by();
  }

  public String Optimize(String temp, DataDict DtDict) {
    myDict = DtDict;
    input = temp;
    mysqlstmt.setSql(input);
    if (mysqlstmt.getSelectString().indexOf("/*+") != -1) {
      return input;
    }

    if (mysqlstmt.IsCatesian()) { // pure catesian product
      OptimizeCatesian();
    }
    else if (mysqlstmt.getNumberOfTable() == 1 && mysqlstmt.IsMultipleOR() &&
             mysqlstmt.getWhere().indexOf(" like ") == -1 &&
             mysqlstmt.IsAllWhereIndexes(myDict)) { //use_concat
      OptimizeMultipleOr();
    }
    else if (mysqlstmt.IsAllJoin() && mysqlstmt.getNumberOfTable() >= 2) { // use ordered hint if multiple join
      OptimizeMultipleJoin();
    }
    else if (mysqlstmt.getNumberOfTable() == 1 &&
             mysqlstmt.getNumberOfExpression() == 1 &&
             mysqlstmt.IsAllWhereIndexes(myDict)) {
      double percent = EstimateRowReturn(mysqlstmt.getTable(0).toUpperCase(),
                                         mysqlstmt.getWhere().replaceFirst(
          "WHERE ", ""));
      if (percent > 7) {
        OptimizeFullScan(mysqlstmt.getTable(0));
      }
      else {
        output = "SELECT " + mysqlstmt.getSelectString() +
            "\nFROM " + mysqlstmt.getFrom() + "\n" + mysqlstmt.getWhere() +
            "\n" + mysqlstmt.getGroup_by() + "\n" + mysqlstmt.getHaving() +
            "\n" + mysqlstmt.getOrder_by();
      }

    }
    else {
      output = "SELECT " + mysqlstmt.getSelectString() +
          "\nFROM " + mysqlstmt.getFrom() + "\n" + mysqlstmt.getWhere() + "\n" +
          mysqlstmt.getGroup_by() + "\n" + mysqlstmt.getHaving() + "\n" +
          mysqlstmt.getOrder_by();
    }
    return output;
  }
}
