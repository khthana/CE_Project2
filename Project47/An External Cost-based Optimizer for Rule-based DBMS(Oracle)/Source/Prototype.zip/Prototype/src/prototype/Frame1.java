package prototype;

import java.io.*;
import java.text.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;

import prototype.MyTextArea.*;
import prototype.myDialog.TitleDialog;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Frame1
    extends JFrame
    implements KeyListener {
  JProgressBar progressBar = new JProgressBar();
  DButil myDB = new DButil(this, progressBar);
  DataDict myDataDict = new DataDict();
  Optimizer Optimizer   = new Optimizer();
  public int status;
  JPanel contentPane;
  JButton ConnectButton     = new JButton();
  JButton StaticButton          = new JButton();
  JButton AnalyzeButton      = new JButton();
  JButton DinamicButton     = new JButton();
  JButton ExitButton              = new JButton();
  InputSQL InputSQL            = new InputSQL(true);
  InputSQL OutputSQL         = new InputSQL(false);
  JScrollPane scroll              = new JScrollPane(InputSQL);
  JScrollPane scroll2            = new JScrollPane(OutputSQL);
  JSplitPane splitPane         = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scroll,
                                                 scroll2);
  String Date;
  DateFormat Format;
  java.util.Date now                   = new java.util.Date();
  JTextField DateField              = new JTextField();
  JTextField LoginNameField = new JTextField("Login Name:");

  JTable resultTable                 = new JTable(15, 8);
  JScrollPane resultPane        = new JScrollPane(resultTable);
  status st                                   = new status();
  JFileChooser chooser          = new JFileChooser();
  JLabel TimeLabel                  = new JLabel("Elapse Time:");
  JLabel RowLabel                   = new JLabel("Number of Rowreturn:");
  JCheckBox OptimizeCheckBox = new JCheckBox();
  private String user;
  private String password;


  public Frame1() {

    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();

    }
    catch (Exception e) {
      e.printStackTrace();
    }

  }

  public void keyPressed(KeyEvent event) {

    if (event.getKeyCode() == event.VK_F5) {
      String query = "";
      if (OptimizeCheckBox.isSelected()) {
        query = Optimizer.Optimize(InputSQL.getText(), myDataDict);
      }
      else {
        query = InputSQL.getText();

      }
      OutputSQL.setText(query);
      myDB.setQuery(query);
      TimeLabel.setText("Elapse Time: " + myDB.getElapseTime() + " ms");
      RowLabel.setText("Number of Rowreturn: " + myDB.getRowCount());
    }
    else if (event.getKeyCode() == event.VK_ESCAPE) {
      if (JOptionPane.showConfirmDialog(this, "Are you sure to exit", "Confirm",
                                        JOptionPane.DEFAULT_OPTION) == 0) {
        System.exit(0);
      }
    }
  }

  public void keyReleased(KeyEvent event) {

  }

  public void keyTyped(KeyEvent event) {
  }

  //Component initialization
  private void jbInit() throws Exception {
    setSize(new Dimension(915, 664));
    setTitle("An External CostBase Optimizer");

    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    contentPane.setBackground(new Color(255, 255, 190));

    Format = DateFormat.getDateInstance(DateFormat.FULL);
    Date = Format.format(now);

    DateField.setBackground(new Color(255, 255, 216));
    DateField.setEnabled(true);
    DateField.setFont(new java.awt.Font("Dialog", 1, 15));
    DateField.setBorder(BorderFactory.createRaisedBevelBorder());
    DateField.setEditable(false);
    DateField.setText(Date);
    DateField.setHorizontalAlignment(SwingConstants.CENTER);
    DateField.setBounds(13, 6, 300, 25);

    LoginNameField.setBackground(new Color(255, 255, 216));
    LoginNameField.setEnabled(true);
    LoginNameField.setFont(new java.awt.Font("Dialog", 1, 15));
    LoginNameField.setBorder(BorderFactory.createRaisedBevelBorder());
    LoginNameField.setEditable(false);
    LoginNameField.setText("Login Name:");
    LoginNameField.setHorizontalAlignment(SwingConstants.CENTER);
    LoginNameField.setBounds(new Rectangle(368, 6, 250, 25));

    splitPane.setDividerLocation(374);
    splitPane.setOneTouchExpandable(true);
    splitPane.setBounds(new Rectangle(14, 34, 748, 301));

    ConnectButton.setText("Connect");
    ConnectButton.addActionListener(new Frame1_ConnectButton_actionAdapter(this));
    ConnectButton.setBounds(new Rectangle(770, 40, 130, 50));

    StaticButton.setText("Static Optimizer");
    StaticButton.addActionListener(new Frame1_StaticButton_actionAdapter(this));
    StaticButton.setBounds(new Rectangle(770, 100, 130, 50));
    StaticButton.setEnabled(false);

    AnalyzeButton.setText("Analyze");
    AnalyzeButton.addActionListener(new Frame1_AnalyzeButton_actionAdapter(this));
    AnalyzeButton.setBounds(new Rectangle(770, 160, 130, 50));
    AnalyzeButton.setEnabled(false);

    DinamicButton.setText("Dinamic Optimizer");
    DinamicButton.addActionListener(new Frame1_DinamicButton_actionAdapter(this));
    DinamicButton.setBounds(new Rectangle(770, 220, 130, 50));
    DinamicButton.setEnabled(false);

    ExitButton.setText("Exit");
    ExitButton.addActionListener(new Frame1_ExitButton_actionAdapter(this));
    ExitButton.setBounds(new Rectangle(770, 280, 130, 50));

    TimeLabel.setFont(new java.awt.Font("Dialog", 1, 14));
    TimeLabel.setForeground(new Color(26, 10, 177));
    TimeLabel.setBounds(new Rectangle(669, 593, 189, 24));

    RowLabel.setFont(new java.awt.Font("Dialog", 1, 14));
    RowLabel.setForeground(new Color(26, 10, 177));
    RowLabel.setBounds(new Rectangle(420, 593, 250, 24));

    resultTable.setBackground(new Color(230, 255, 230));
    resultTable.setGridColor(new Color(140, 140, 230));
    resultTable.setRowSelectionAllowed(false);
    resultTable.setForeground(new Color(4, 4, 4));
    //resultTable.ed
    resultPane.setBounds(new Rectangle(13, 340, 884, 257));

    InputSQL.addKeyListener(this);
    InputSQL.setEnabled(false);

    OutputSQL.setEditable(false);

    st.setBounds(new Rectangle(769, 6, 130, 30));

    progressBar.setBounds(13, 599, 330, 16);
    progressBar.setMaximum(myDB.getNumberOfRows());

    // Note: source for ExampleFileFilter can be found in FileChooserDemo,
    // under the demo/jfc directory in the Java 2 SDK, Standard Edition.

    OptimizeCheckBox.setBackground(new Color(255, 255, 216));
    OptimizeCheckBox.setSelected(true);
    OptimizeCheckBox.setText("Optimize");
    OptimizeCheckBox.setBounds(new Rectangle(640, 8, 83, 23));

    contentPane.add(resultPane, null);
    contentPane.add(DateField, null);
    contentPane.add(LoginNameField, null);
    contentPane.add(TimeLabel, null);
    contentPane.add(RowLabel, null);
    contentPane.add(progressBar, null);
    contentPane.add(OptimizeCheckBox, null);
    contentPane.add(ConnectButton, BorderLayout.EAST);
    contentPane.add(StaticButton, BorderLayout.EAST);
    contentPane.add(AnalyzeButton, BorderLayout.EAST);
    contentPane.add(DinamicButton, BorderLayout.EAST);
    contentPane.add(ExitButton, BorderLayout.EAST);
    contentPane.add(st, BorderLayout.EAST);
    contentPane.add(splitPane);

  }

  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  void ConnectButton_actionPerformed(ActionEvent e) {
    myDB.Connect();
    myDataDict.CheckFirst(myDB.getUser(), myDB.getPassWord(), myDB.getSid());
    st.DrawStatus(myDB.isConnectedToDatabase());
    this.repaint();
    if (myDB.isConnectedToDatabase()) {
      LoginNameField.setText("Login Name:" + myDB.getUser());
      resultTable.setModel(myDB);
      StaticButton.setEnabled(true);
      AnalyzeButton.setEnabled(true);
      DinamicButton.setEnabled(true);
      InputSQL.setText("");
      OutputSQL.setText("");
    }
    else {
      StaticButton.setEnabled(false);
      AnalyzeButton.setEnabled(false);
      DinamicButton.setEnabled(false);
    }

    this.repaint();
  }

  void DinamicButton_actionPerformed(ActionEvent e) {
    scroll.setEnabled(true);
    InputSQL.setEnabled(true);
    InputSQL.setEditable(true);
    InputSQL.setText("");
    OutputSQL.setText("");
    InputSQL.requestFocus();
  }

  void StaticButton_actionPerformed(ActionEvent e) {

    chooser.setFileFilter(new myFilter());
    InputSQL.setEditable(false);

    String InputLine;
    String OutputLine = "";
    String OutSQL;

    int returnVal = chooser.showOpenDialog(this);

    if (returnVal != JFileChooser.CANCEL_OPTION) {

      class myFillter
          extends FileFilter {
        public myFillter() {
        }

        private Hashtable h = new Hashtable();
        public boolean accept(File f) {
          if (f.isDirectory()) {
            return true;
          }
          String n = f.getName();
          int i = n.lastIndexOf('.');
          if (i > 0 && i < n.length() - 1) {
            String e = n.substring(i + 1);
            if (e != null && h.get(e) != null) {
              return true;
            }
          }
          return false;
        }

        public String getDescription() {
          return "Image File (*.java or *.txt)";
        }

        public void addExtension(String e) {
          h.put(e, this);
        }

      }

      File file = chooser.getSelectedFile();
      myFillter filter = new myFillter();

      filter.addExtension("java");
      filter.addExtension("cpp");
      filter.addExtension("c");
      filter.addExtension("php");
      filter.addExtension("jsp");
      filter.addExtension("asp");
      filter.addExtension("asm");
      filter.addExtension("frm");
      filter.addExtension("txt");
      chooser.setFileFilter(filter);

      try {
        BufferedReader input = new BufferedReader(new FileReader(file));

        StringBuffer Inputbuffer = new StringBuffer();
        StringBuffer Tempbuffer = new StringBuffer();
        StringBuffer Outputbuffer = new StringBuffer();
        int Start, Stop;
        int loop = 0;

        PrintStream MyTempFile = null;

        MyTempFile = new PrintStream(new FileOutputStream(file.getParent() +
            "\\temp.java"));

        while ( (InputLine = input.readLine()) != null) {
          loop++;
          /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          Start = FindFirstStringSQL(InputLine);
          Stop = FindLastStringSQL(InputLine, Start + 12);

          if ( (Start != -1) && (Stop != -1)) {
            OutSQL = InputLine.substring(Start, Stop);
            if ( (OutSQL.substring(0, 6).equalsIgnoreCase("select")) &&
                (Start != -1)) {
              OutSQL = Optimizer.Optimize(OutSQL, myDataDict);
              OutSQL = OutSQL.replaceAll("\n", " ");
              OutputLine = InputLine.substring(0, Start) + OutSQL +
                  InputLine.substring(Stop, InputLine.length());
            }
          }
          else
            OutputLine = InputLine;

          Inputbuffer.append(InputLine + "\n");
          Tempbuffer.append(OutputLine + "\n");
          MyTempFile.println(OutputLine);

        }
        MyTempFile.close();
        PrintStream MyOutputFile = new PrintStream(new FileOutputStream(file.
            getPath()));
        File Tempfile = new File(file.getParent() + "\\temp.java");

        BufferedReader Tempinput = new BufferedReader(new FileReader(Tempfile));
        while ( (InputLine = Tempinput.readLine()) != null) {
          MyOutputFile.println(InputLine);
        }
        Tempinput.close();

        MyOutputFile.close();
        Tempfile.delete();
        InputLine = Inputbuffer.toString();
        OutputLine = Tempbuffer.toString();
        InputSQL.setText("");
        InputSQL.append(InputLine);
        OutputSQL.setText("");
        OutputSQL.append(OutputLine);

      }
      catch (IOException et) {
        et.toString();
      }
      //This is where a real application would open the file.

    }

  }

  void ExitButton_actionPerformed(ActionEvent e) {
    if (myDB.isConnectedToDatabase()) {
      myDB.disconnectFromDatabase();
    }
    TitleDialog AboutMe = new TitleDialog();
    AboutMe.setTitle("About");
    AboutMe.show();
    System.exit(0);
  }

  void AnalyzeButton_actionPerformed(ActionEvent e) {
    myDataDict.Analyze();
    myDB.DataStoresetQuery(" SELECT  TABLENAME,COLUMNNAME,DISTINCTVALUE,NULLVALUE,MINVALUE,MAXVALUE,DATATYPE,ISINDEX  FROM COLUMNSTATE ");
    TimeLabel.setText("Elapse Time: " + myDB.getElapseTime() + " ms");
    RowLabel.setText("Number of Rowreturn: " + myDB.getRowCount());
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * FindStringSQL
   *
   * @param InputLine String
   * @return String
   */
  public int FindFirstStringSQL(String InputLine) {
    int s1, s2, lenght = 0;
    boolean temp = false;
    lenght = InputLine.length();
    s1 = InputLine.indexOf("\"");
    if (s1 != -1) {
      while (!temp && ! (s1 >= (lenght - 7))) {
        if (InputLine.startsWith(" ", s1) || InputLine.startsWith("\"", s1)) {
          s1++;
        }
        else if (InputLine.substring(s1).substring(0,
            6).equalsIgnoreCase("select")) {
          temp = true;
        }
        else
          s1++;
      }
      s2 = s1 + 7;
      while (temp && ! (s2 >= lenght)) {
        if (InputLine.substring(0, 6).equalsIgnoreCase("from")) {
          temp = false;
          return s1;
        }
        else {
          s2++;
        }
      }
    }
    return s1;

  }

  public int FindLastStringSQL(String InputLine, int start) {
    return InputLine.indexOf("\"", start);
  }

  /**
   * paintComponent
   *
   * @param g Graphics
   */

}

class Frame1_ConnectButton_actionAdapter
    implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_ConnectButton_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.ConnectButton_actionPerformed(e);
  }
}

class Frame1_DinamicButton_actionAdapter
    implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_DinamicButton_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.DinamicButton_actionPerformed(e);
  }
}

class Frame1_StaticButton_actionAdapter
    implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_StaticButton_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.StaticButton_actionPerformed(e);
  }
}

class Frame1_ExitButton_actionAdapter
    implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_ExitButton_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.ExitButton_actionPerformed(e);
  }

}

class Frame1_AnalyzeButton_actionAdapter
    implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_AnalyzeButton_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.AnalyzeButton_actionPerformed(e);
  }
}
