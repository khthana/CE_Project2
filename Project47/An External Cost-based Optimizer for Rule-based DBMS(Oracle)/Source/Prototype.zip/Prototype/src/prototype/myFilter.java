package prototype;

import javax.swing.filechooser.*;
import java.io.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class myFilter extends javax.swing.filechooser.FileFilter {
  public myFilter() {
  }
  public boolean accept(File f) {
    boolean accept = f.isDirectory();
    if( ! accept) {
      String suffix = getSuffix(f);
      if(suffix != null)
        accept = suffix.equals("java");
    }
    return accept;
 }
 public String getDescription() {
    return "Text Files(*.java)";
 }
 private String getSuffix(File f) {
    String s = f.getPath(), suffix = null;
    int i = s.lastIndexOf('.');
    if(i > 0 && i < s.length() - 1)
      suffix = s.substring(i+1).toLowerCase();
    return suffix;
 }

}
