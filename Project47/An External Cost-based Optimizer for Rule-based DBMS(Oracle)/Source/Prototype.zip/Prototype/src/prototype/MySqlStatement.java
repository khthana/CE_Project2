package prototype;

import javax.swing.*;
import java.util.*;

public class MySqlStatement {
  private String sql;
  private String select;
  private String table[] = new String[255];
  private String from;
  private String where;
  private String where_expr[] = new String[255];
  private String boolean_connector[] = new String[255];
  private String order_by;
  private String having;
  private String group_by;
  private int ifrom;
  private int iwhere;
  private int igroup_by;
  private int ihaving;
  private int iorder_by;
  private int ntable;
  private int nwhere_expr;
  private boolean mul_or;
  private boolean mul_and;
  private Vector v;
  private Vector vt;

  public MySqlStatement() {
    sql = "";
    select = "";
    from = "";
    where = "";
    order_by = "";
    having = "";
    group_by = "";
    ntable = 0;
    nwhere_expr = 0;
    v = new Vector();
    vt = new Vector();
    mul_or = mul_and = false;
    ifrom = iwhere = igroup_by = ihaving = iorder_by = -1;
  }

  public MySqlStatement(String sql) {
    setSql(sql);
  }

  public String getSql() { //return sql
    return this.sql;
  }

  public int getNumberOfTable() {
    return ntable;
  }

  public String getSelectString() { // return string select to string before "from"
    return select;
  }

  public String getTable(int i) { // return table string
    return table[i];
  }

  public int getNumberOfExpression() {
    return nwhere_expr;
  }

  public String getFrom() {
    return from;
  }

  public String getWhere() {
    return where.replaceFirst(" where", "WHERE");
  }

  public String getGroup_by() {
    return group_by;
  }

  public String getHaving() {
    return having;
  }

  public String getOrder_by() {
    return order_by;
  }

  public void setSql(String sql) { //set sql
    this.sql = sql.replaceAll("\n", " ");
    this.sql = this.sql.replaceAll("\t", " ");
    while (this.sql.indexOf("  ") != -1) {
      this.sql = this.sql.replaceAll("  ", " "); //replace two whitespace with one whitespace
    }
    this.sql = this.sql.toLowerCase();
    select = "";
    from = "";
    ntable = 0;
    nwhere_expr = 0;
    mul_or = mul_and = false;
    set_index();
    set_string(sql);
    set_where_expr();
    SplitFrom();
  }

  private void set_index() {
    ifrom = this.sql.indexOf(" from ");
    iwhere = this.sql.indexOf(" where ");
    igroup_by = this.sql.indexOf(" group by ");
    ihaving = this.sql.indexOf(" having ");
    iorder_by = this.sql.indexOf(" order by ");
  }

  private void set_string(String oldsql) { //set  all string
    int end;
    //set select string
    select = sql.substring(0, ifrom).toLowerCase();
    select = select.replaceFirst("select", "");
    //set where string
    if (iwhere == -1) {
      this.where = "";
    }
    else {
      if (igroup_by != -1)
        end = igroup_by;
      else if (ihaving != -1)
        end = ihaving;
      else if (iorder_by != -1)
        end = iorder_by;
      else
        end = this.sql.length();
      this.where = sql.substring(iwhere, end);
      StringBuffer buf = new StringBuffer(oldsql.substring(iwhere, end));
      int is, ie;
      while (buf.indexOf("'") != -1) {
        is = buf.indexOf("'");
        ie = buf.indexOf("'", is + 1);
        this.where = this.where.replaceFirst(buf.substring(is, ie).toLowerCase(),
                                             buf.substring(is, ie));
        buf.delete(is, ie + 1);
      }
    }
    //set group by string
    if (igroup_by == -1) {
      this.group_by = "";
    }
    else {
      if (ihaving != -1)
        end = ihaving;
      else if (iorder_by != -1)
        end = iorder_by;
      else
        end = this.sql.length();
      this.group_by = sql.substring(igroup_by, end);
    }
    //set having string
    if (ihaving == -1) {
      this.having = "";
    }
    else {
      if (iorder_by != -1)
        end = iorder_by;
      else
        end = this.sql.length();
      this.having = sql.substring(ihaving, end);
    }
    //set order by string
    if (iorder_by == -1) {
      this.order_by = "";
    }
    else {
      this.order_by = sql.substring(iorder_by, sql.length());
    }
  }

  public boolean IsCatesian() {
    if (iwhere == -1 && ntable >= 2)
      return true;
    else if (ntable >= 2 && !IsAllJoin())
      return true;
    return false;
  }

  public boolean IsAllJoin() {
    if (ntable - 1 > nwhere_expr) //number of join expression in WHERE must equal or more than number of table in FROM -1
      return false;

    int compare_index;
    String s, left, right;
    v.clear();
    v.ensureCapacity(ntable);
    for (int i = 0; i < nwhere_expr; i++) {
      s = where_expr[i];
      if (s.indexOf("!=") != -1)
        compare_index = s.indexOf("!=");
      else if (s.indexOf("<=") != -1)
        compare_index = s.indexOf("<=");
      else if (s.indexOf(">=") != -1)
        compare_index = s.indexOf(">=");
      else if (s.indexOf("=") != -1)
        compare_index = s.indexOf("=");
      else if (s.indexOf("<") != -1)
        compare_index = s.indexOf("<");
      else if (s.indexOf(">") != -1)
        compare_index = s.indexOf(">");
      else
        continue; //not contain comparator in where clause ;do next loop

      left = s.substring(0, compare_index);
      right = s.substring(compare_index + 1).replaceFirst("=", "");

      if (left.indexOf("'") != -1 || right.indexOf("'") != -1) {
        continue;
      }
      if (left.indexOf(".") == -1 || right.indexOf(".") == -1) {
        continue;
      }
      if (left.indexOf(".") != -1 && right.indexOf(".") != -1) { //has . in left and right
        if (vt.contains(left.substring(0, left.indexOf("."))) &&
            vt.contains(right.substring(0, right.indexOf(".")))) { // check - Is it synonym or table in both left and right?
          if (!v.contains(left.substring(0, left.indexOf(".")))) { //if not contain in v ; do add into v
            v.add(left.substring(0, left.indexOf(".")));
          }
          if (!v.contains(right.substring(0, right.indexOf(".")))) { //if not contain in v ; do add into v
            v.add(right.substring(0, right.indexOf(".")));
          }
        }
        else {
          continue;

        }
      }

    }
    if (v.size() == ntable) { //all table used to join
      return true;
    }
    return false;
  }

  public boolean IsMultipleOR() {
    return mul_or;
  }

  public boolean IsAllWhereIndexes(DataDict dict) { //use only with 1 table in from clause

    int compare_index;
    String s, left, right;
    v.clear();
    v.ensureCapacity(nwhere_expr);
    for (int i = 0; i < nwhere_expr; i++) {
      s = where_expr[i];
      if (s.indexOf("!=") != -1)
        compare_index = s.indexOf("!=");
      else if (s.indexOf("<=") != -1)
        compare_index = s.indexOf("<=");
      else if (s.indexOf(">=") != -1)
        compare_index = s.indexOf(">=");
      else if (s.indexOf("=") != -1)
        compare_index = s.indexOf("=");
      else if (s.indexOf("<") != -1)
        compare_index = s.indexOf("<");
      else if (s.indexOf(">") != -1)
        compare_index = s.indexOf(">");
      else
        continue; //not contain comparator in where clause ;do next loop

      left = s.substring(0, compare_index);
      right = s.substring(compare_index + 1).replaceFirst("=", "");
      try {
        if (left.indexOf("'") == -1)
          Double.parseDouble(left);
      }
      catch (NumberFormatException ne) {
        v.add(left);
      }
      catch (Exception e) {
      }
      /****/
      try {
        if (right.indexOf("'") == -1)
          Double.parseDouble(right);
      }
      catch (NumberFormatException ne) {
        v.add(right);
      }
      catch (Exception e) {
      }
    }

    String tb = table[0];
    if (!dict.GetExistTable(tb.toUpperCase()))
      return false;

    int count = 0;
    for (int l = 0; l < v.size(); l++) {
      if (dict.GetExistColumn(tb.toUpperCase(),
                              v.elementAt(l).toString().toUpperCase())) {
        if (dict.IsIndex(tb.toUpperCase(),
                         v.elementAt(l).toString().toUpperCase())) {
          count++;
        }
      }
    }
    if (count == v.size()) {
      return true;
    }
    return false;
  }

  public boolean IsMultipleAND() {
    return mul_and;
  }

  private void set_where_expr() {
    if (iwhere == -1) {
      return;
    }
    StringBuffer sbuf = new StringBuffer(where.replaceFirst(" where ", ""));
    int ior = sbuf.indexOf(" or ");
    int iand = sbuf.indexOf(" and ");

    if (ior == iand && iand == -1) { //have 1 expression
      nwhere_expr = 1;
      where_expr[0] = sbuf.toString();
      /**/
      mul_or = mul_and = false;
    }
    //All expression connected by both AND and OR; cut only OR
    else if (ior != -1 && iand != -1) {
      int start = 0;
      int ibtwn = sbuf.indexOf(" between ");
      int count_and = 0, count_btwn = 0;
      while (ibtwn != -1) {
        count_btwn++;
        ibtwn = sbuf.indexOf(" between ", ibtwn + 1);
      }
      while (iand != -1 && ibtwn != 0) {
        count_and++;
        iand = sbuf.indexOf(" and ", iand + 1);
      }

      while (ior != -1) {
        nwhere_expr++;
        where_expr[nwhere_expr - 1] = sbuf.substring(start, ior);
        boolean_connector[nwhere_expr - 1] = "OR";
        start = ior + 4; //ignored " or "
        ior = sbuf.indexOf(" or ", start);
      }
      where_expr[nwhere_expr] = sbuf.substring(start);
      nwhere_expr++;

      if (count_and == count_btwn && count_btwn > 0 &&
          count_btwn <= nwhere_expr) { //all and is own by between ; then all expr connect by or
        mul_or = true;
        mul_and = false;
      }
      else {
        mul_or = mul_and = false;
      }
    }
    //all expression connected by OR
    else if (ior != -1) {
      int start = 0;
      while (ior != -1) {
        nwhere_expr++;
        where_expr[nwhere_expr - 1] = sbuf.substring(start, ior);
        boolean_connector[nwhere_expr - 1] = "OR";
        start = ior + 4; //ignored " or "
        ior = sbuf.indexOf(" or ", start);
      }
      where_expr[nwhere_expr] = sbuf.substring(start);
      nwhere_expr++;
      mul_or = true;
    }
    //all expression connected by AND
    else if (iand != -1) {
      int start = 0;
      int ibtwn = -1;
      while (iand != -1 && iand != sbuf.length()) {
        nwhere_expr++;
        ibtwn = sbuf.indexOf(" between ");
        if (ibtwn != -1 && ibtwn < iand) { //if between-and expr
          iand = sbuf.indexOf(" and ", iand + 1);
          if (iand == -1)
            iand = sbuf.length();
          where_expr[nwhere_expr - 1] = sbuf.substring(start, iand);
          if (iand != sbuf.length()) { //if not end where
            boolean_connector[nwhere_expr - 1] = "AND";
            start = iand + 5; //ignored " and "
            iand = sbuf.indexOf(" and ", start);
          }
        }
        else { ///else if not between-and expr
          where_expr[nwhere_expr - 1] = sbuf.substring(start, iand);
          boolean_connector[nwhere_expr - 1] = "AND";
          start = iand + 5; //ignored " and "
          iand = sbuf.indexOf(" and ", start);
        }
      }
      if (iand == -1) {
        where_expr[nwhere_expr] = sbuf.substring(start);
        nwhere_expr++;
      }
      mul_and = true;
    }
    where = new String("WHERE ");
    for (int t = 0; t < nwhere_expr - 1; t++) {
      where += where_expr[t] + "\n" + boolean_connector[t] + " ";
    }
    where += where_expr[nwhere_expr - 1];
  }

  private void SplitFrom() {
    try {
      int begin = ifrom + 6;
      int end;
      if (iwhere != -1)
        end = iwhere;
      else if (igroup_by != -1)
        end = igroup_by;
      else if (ihaving != -1)
        end = ihaving;
      else if (iorder_by != -1)
        end = iorder_by;
      else
        end = this.sql.length();

      StringTokenizer tokens = new StringTokenizer(this.sql.substring(begin,
          end).replaceAll(",", " , "));
      from = this.sql.substring(begin, end);
      while (tokens.hasMoreElements()) {
        table[ntable] = tokens.nextToken();
        while (table[ntable].indexOf(",") == -1 && tokens.hasMoreElements()) {
          table[ntable] += " " + tokens.nextToken();
        }
        table[ntable] = table[ntable].replaceAll(",", "");
        ntable++;
      }

      //set vector table
      vt.clear();
      vt.ensureCapacity(ntable);
      for (int i = 0; i < ntable; i++) {
        if (table[i].indexOf(" ") != -1) { //have   synonym
          vt.add(table[i].substring(table[i].indexOf(" ") + 1).replaceAll(" ",
              ""));
        }
        else
          vt.add(table[i].replaceAll(" ", ""));
      }
    }
    catch (Exception e) {
      JOptionPane.showMessageDialog(null, e.toString());
    }
  }

  //swap table
  public void swapTable(int first, int second) {
    String tmp = table[first];
    table[first] = table[second];
    table[second] = tmp;
  }

}
