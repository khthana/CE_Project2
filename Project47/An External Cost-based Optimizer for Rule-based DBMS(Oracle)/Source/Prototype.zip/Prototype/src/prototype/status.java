package prototype;

import java.awt.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class status
    extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();

  boolean st = false;

  public status() {
    try {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    this.repaint();
    this.setLayout(borderLayout1);
    this.setVisible(true);
  }

  /**
   * draw
   *
   * @param status int
   */
  public void DrawStatus(boolean status) {
    st = status;
    repaint();
  }

  public void paintComponent(Graphics g) {
    super.paintComponents(g);

    if (!st) {
      g.setColor(new Color(255, 0, 0));
      g.fillOval(20, 0, 35, 30);
      g.setColor(new Color(170, 170, 170));
      g.fillOval(80, 0, 35, 30);
    }
    else if (st) {
      g.setColor(new Color(170, 170, 170));
      g.fillOval(20, 0, 35, 30);
      g.setColor(new Color(0, 255, 0));
      g.fillOval(80, 0, 35, 30);
    }

  }

}
