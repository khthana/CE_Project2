-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 20 เม.ย. 2005  น.
-- รุ่นของเซิร์ฟเวอร์: 4.1.9
-- รุ่นของ PHP: 4.3.10
-- 
-- ฐานข้อมูล: `conference`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `joinmeet`
-- 

CREATE TABLE `joinmeet` (
  `UserID` int(11) NOT NULL default '0',
  `MeetID` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `joinmeet`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `member`
-- 

CREATE TABLE `member` (
  `MemberID` int(10) NOT NULL auto_increment,
  `Rank` varchar(20) NOT NULL default '',
  `MemberName` varchar(40) NOT NULL default '',
  `MemberSurname` varchar(40) NOT NULL default '',
  `Dean` varchar(20) NOT NULL default '',
  `MemberEmail` varchar(40) NOT NULL default '',
  `MemberMobile` varchar(9) NOT NULL default '',
  `MemberTel` varchar(9) NOT NULL default '',
  `UserName` varchar(12) NOT NULL default '',
  `PassWord` varchar(12) NOT NULL default '',
  `Granted` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`MemberID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `member`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `memberjam`
-- 

CREATE TABLE `memberjam` (
  `JamID` int(10) NOT NULL auto_increment,
  `MeetID` int(10) NOT NULL default '0',
  `Name` varchar(30) NOT NULL default '',
  `SName` varchar(30) NOT NULL default '',
  `Dean` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`JamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `memberjam`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `pathmeeting`
-- 

CREATE TABLE `pathmeeting` (
  `MeetID` int(10) NOT NULL default '0',
  `Session` char(2) NOT NULL default '',
  `Num` char(2) NOT NULL default '',
  `hTopic` varchar(100) NOT NULL default '',
  `Subject1` varchar(255) NOT NULL default '',
  `Subject2` varchar(255) NOT NULL default '',
  `Message` text NOT NULL,
  `numFile` int(3) NOT NULL default '0',
  `PathFile` varchar(255) NOT NULL default '',
  `Poster` varchar(255) NOT NULL default '0',
  PRIMARY KEY  (`MeetID`,`Session`,`Num`,`numFile`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- dump ตาราง `pathmeeting`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `preparemeeting`
-- 

CREATE TABLE `preparemeeting` (
  `MeetID` int(10) NOT NULL auto_increment,
  `Subject` varchar(255) NOT NULL default '',
  `Num` varchar(10) NOT NULL default '0',
  `D` char(2) NOT NULL default '',
  `M` char(2) NOT NULL default '',
  `Y` varchar(4) NOT NULL default '',
  `MeetSentPaper` varchar(10) NOT NULL default '',
  `MeetStart` varchar(6) NOT NULL default '',
  `MeetEnd` varchar(6) NOT NULL default '',
  `MeetPlace` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`MeetID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `preparemeeting`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `report`
-- 

CREATE TABLE `report` (
  `ReportID` int(10) NOT NULL auto_increment,
  `MeetID` int(10) NOT NULL default '0',
  `ReportFile` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ReportID`,`MeetID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `report`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tempfile`
-- 

CREATE TABLE `tempfile` (
  `Num` int(10) NOT NULL auto_increment,
  `MeetID` int(10) NOT NULL default '0',
  `Session` char(3) NOT NULL default '',
  `Digest` char(3) NOT NULL default '',
  `FileUpload` varchar(255) NOT NULL default '',
  `Member` varchar(255) NOT NULL default '0',
  PRIMARY KEY  (`Num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `tempfile`
-- 

