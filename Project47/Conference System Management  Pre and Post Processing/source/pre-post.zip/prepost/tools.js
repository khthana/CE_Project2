/*
GenDate('divDOB_Date', 'DOB_Date', '', '')
GenMonth('divDOB_Month', 'DOB_Month', '', '')
GenYear('divDOB_Year', 'DOB_Year', 65, -10, '', '')
*/
function GenDate(divName, fieldName, selectedValue) {
	//onChangeContent = 'onChange="' + onChangeContent + '"';
	var dayScript='<select name='+fieldName+' class=formor><option value=\"\">�ѹ���'
	for (var i=1; i<=31; i++) {
		if (i<10) Zero='0'
		else Zero=''
		dayScript += '<option value=\"'+Zero+i+'\"'
		if (i==selectedValue)
			dayScript += ' selected'
		dayScript += '>'+i+'</option>'
	}
	dayScript += '</select>'
	document.all[divName].innerHTML=dayScript
}
function GenMonth(divName, fieldName, selectedValue) {
	//empty MonthArray[0]; MonthArray starts at 1. 
	//1 = Jan, 2 = Feb, 3 = Mar...
	
	var MonthArray=new Array("","���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��ɨԡ�¹","�ѹ�Ҥ�") 
	//onChangeContent = 'onChange="' + onChangeContent + '"';
	var monthScript='<select name='+fieldName+' class=formor><option value=\"\">��͹'
	var Zero
	for (var i=1; i<MonthArray.length; i++) {
		if (i<10) Zero='0'
		else Zero=''
		monthScript += '<option value=\"'+Zero+i+'\"'
		if (i==selectedValue)
			monthScript += ' selected'
		monthScript += '>'+MonthArray[i]+'</option>'
	}
	monthScript=monthScript+'</select>'
	document.all[divName].innerHTML=monthScript
}
function GenYear(divName, fieldName, minusYears, plusYears, selectedValue) {
	var nowY = new Date();
	var thisYear=nowY.getYear();
	if (thisYear<1900)	thisYear=thisYear+1900+543;
	else thisYear=thisYear+543;
	var beginYear=thisYear-minusYears;
	var endYear=thisYear+plusYears;
	//onChangeContent = 'onChange="' + onChangeContent + '"';
	var yearScript='<select name='+fieldName+' class=formor><option value=\"\">�� �.�.'
	beginYear--
	do {
		beginYear++
		yearScript=yearScript+'<option value=\"'+beginYear+'\"'
		if (beginYear==eval(selectedValue))
			yearScript += ' selected'
		yearScript += '>'+beginYear+'</option>'
	}
	while (beginYear<endYear)
	yearScript += '</select>'
	document.all[divName].innerHTML=yearScript
}

// ÊèÇ¹¢Í§¡ÒÃ à¾ÔèÁ¡ÒÃ»ÃÐªØÁ
var Num = 0;
var subNum = 1;
var Total = 0;
var SH = 1;
var TM = 0;
var chkSH = false;
var SessionHeader = new Array("","����ͧ�����ͷ�Һ","�Ѻ�ͧ��§ҹ��û�Ъ��","����ͧ�׺���ͧ","����ͧ�ʹ����;Ԩ�ó�");
var strTemp = '';
//GenText('gend', 'Text', '','Num++')
function ObjEnable(objName) {
	document.all[objName].disabled=false;
}
function ObjDisable(objName) {
	document.all[objName].disabled=true;
}
function ChkBox(fieldAction,fieldVisible) {
	if (document.all[fieldAction].checked)	{
		document.all[fieldVisible].style.visibility='visible';
		ObjEnable('Digest');
	}else {document.all[fieldVisible].style.visibility='hidden';	ObjDisable('Digest');}
}

function GenSession(divName, fieldName1, fieldName2, fieldName3, inValue1, inValue2, inValue3) {
	//var GenScript = '<input name=' +fieldName+ ' type=text class=formor id=Meet size=5 maxlength=5><br>'
	subNum = 1;
	Num++;	
	Total ++;
	if (SH==TM) StrHead = '';	else StrHead = SessionHeader[SH];
	GenScript = '<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">'
	GenScript += '<tr><td colspan="2" align="center"><b><u>' +StrHead+ '</u></b></td></tr>'
	GenScript += '<tr><td colspan="2"><b>����º���з�� ' +Num+ '</b></td></tr>'
	GenScript += '<tr><td width="29%" height="8" align="right"></td><td width="71%" height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">����ͧ&nbsp;&nbsp;</td><td>'
	GenScript += '<input name="' +fieldName1+ +Total+ '" type="text" class="formor" size="50" id="' +fieldName1+ +Total+ '"></td></tr>'
	//GenScript += '<tr><td height="8" align="right"></td><td height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">��Ǣ������&nbsp;&nbsp;</td><td>'
	GenScript += '<input type="checkbox" name="checkbox' +Total+ '" value="true"  onClick="ChkBox(\'checkbox' +Total+ '\',\'Subject2' +Total+ '\');">&nbsp;&nbsp;'
	GenScript += '<input name="Subject2' +Total+ '"  type="text" class="formor" id="Subject2' +Total+ '" value="-" size="40" style="visibility:hidden"></td></tr>'
	//GenScript += '<tr><td height="8" align="right"></td><td height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">��������´&nbsp;&nbsp;</td><td>'
	GenScript += '<input type="hidden" name="nSession' +Total+ '" value="' +Num+ '">'
	GenScript += '<input type="hidden" name="nNum' +Total+ '" value="' +subNum+ '">'
	GenScript += '<input type="hidden" name="hTopic' +Total+ '" value="' +SessionHeader[SH]+ '">'
	GenScript += '<textarea name="' +fieldName2+ +Total+ '" cols="40" rows="3" class="formor" id="' +fieldName2+ +Total+ '"></textarea></td></tr>'
	//GenScript += '<tr><td height="8" align="right"></td><td height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">Ṻ���&nbsp;&nbsp;</td><td>'
	GenScript += '<input name="' +fieldName3+ +Total+ '" type="file" class="formor" size="40" id="' +fieldName3+ +Total+ '"></td></tr>'
	
	GenScript += '<tr><td align="right">&nbsp;</td><td>&nbsp;</td></tr><tr><td colspan="2"><span ID=GenMeet' +Total+ '></span></td></tr></table>'
	
	document.all[divName].innerHTML = GenScript
	TM = SH;
}

function GenSessionDigest(divName, fieldName1, fieldName2, fieldName3, inValue1, inValue2, inValue3) {
	//var GenScript = '<input name=' +fieldName+ ' type=text class=formor id=Meet size=5 maxlength=5><br>'
	Total++;
	subNum++;
	GenScript = '<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">'
	GenScript += '<tr><td width="29%" height="8" align="right"></td><td width="71%" height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">��Ǣ������' +Num+  '.' +subNum+ '&nbsp;&nbsp;</td><td>'
	GenScript += '<input name="Subject2' +Total+ '"  type="text" class="formor" id="Subject2' +Total+ '" size="40"></td></tr>'
	//GenScript += '<tr><td height="8" align="right"></td><td height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">��������´&nbsp;&nbsp;</td><td>'

	GenScript += '<input type="hidden" name="nSession' +Total+ '" value="' +Num+ '">'
	GenScript += '<input type="hidden" name="nNum' +Total+ '" value="' +subNum+ '">'
	GenScript += '<input type="hidden" name="hTopic' +Total+ '" value="' +SessionHeader[SH]+ '">'
	GenScript += '<input type="hidden" name="Subject1' +Total+ '" value="' +document.all["Subject1"+(Total-1)].value+ '">'
	GenScript += '<textarea name="' +fieldName2+ +Total+ '" cols="40" rows="3" class="formor" id="' +fieldName2+ +Total+ '"></textarea></td></tr>'
	//GenScript += '<tr><td height="8" align="right"></td><td height="8"></td></tr>'
	
	GenScript += '<tr><td align="right">Ṻ���&nbsp;&nbsp;</td><td>'
	GenScript += '<input name="' +fieldName3+ +Total+ '" type="file" class="formor" size="40" id="' +fieldName3+ +Total+ '"></td></tr>'
	
	GenScript += '<tr><td align="right">&nbsp;</td><td>&nbsp;</td></tr><tr><td colspan="2"><span ID=GenMeet' +Total+ '></span></td></tr></table>'
	
	document.all[divName].innerHTML = GenScript
	TM = SH;
}
function addDataHide(divName,formName,sendName) {
	GenScript = '<form name="' +formName+ '" method="post" action="' +sendName+ '">'
	
	GenScript += '\n<input type="hidden" name="fieldSubject" value="' +document.all["Subject"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldNumMeet" value="' +document.all["NumMeet"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldMeetDay" value="' +document.all["MeetDay"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldMeetMonth" value="' +document.all["MeetMonth"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldMeetYear" value="' +document.all["MeetYear"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldSendPaper" value="' +document.all["SentDay"].value+'/'+document.all["SentMonth"].value+'/'+document.all["SentYear"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldMeetStart" value="' +document.all["MeetStart"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldMeetEnd" value="' +document.all["MeetEnd"].value+ '">'
	GenScript += '\n<input type="hidden" name="fieldMeetPlace" value="' +document.all["MeetPlace"].value+ '">'
	
	GenScript += '<input type="hidden" name="Total" value=' +Total+ '>'
	
	for(i=1; i<=Total; i++) {
		GenScript += '\n\n<input type="hidden" name="fieldSession' +i+ '" value="' +document.all["nSession"+i].value+ '">'
		GenScript += '\n<input type="hidden" name="fieldNum' +i+ '" value="' +document.all["nNum"+i].value+ '">'
		GenScript += '\n<input type="hidden" name="fieldhTopic' +i+ '" value="' +document.all["hTopic"+i].value+ '">'
		GenScript += '\n<input type="hidden" name="fieldSubject1' +i+ '" value="' +document.all["Subject1"+i].value+ '">'
		GenScript += '\n<input type="hidden" name="fieldSubject2' +i+ '" value="' +document.all["Subject2"+i].value+ '">'
		GenScript += '\n<input type="hidden" name="fieldMessage' +i+ '" value="' +document.all["Message"+i].value+ '">'
		GenScript += '\n<input type="hidden" name="fieldPathFile' +i+ '" value="' +document.all["PathFile"+i].value+ '">'
	}
	
	GenScript += '\n</form>'
	//alert(GenScript);
//document.all[divName].innerHTML = GenScript;
document.all[formName].submit();
/*	for(i=1; i<=Total; i++) {
		alert ( document.all["fieldSession"+i].value + "\n" 
		+ document.all["fieldhTopic"+i].value + "\n" 
		+ document.all["fieldNum"+i].value + "\n" 
		+ document.all["fieldSubject1"+i].value + "\n" 
		+ document.all["fieldSubject2"+i].value + "\n" 
		+ document.all["fieldMessage"+i].value + "\n" 
		+ document.all["fieldPathFile"+i].value + "\n" );
		//+ document.all["MeetEnd"].value
	}*/
}
function ShowData() {
	//alert (document.all["Subject"].value + "\n" + document.all["NumMeet"].value + "\n" + document.all["MeetPlace"].value + "\n" + document.all["MeetDay"].value 
	//+ "\n" + document.all["MeetMonth"].value + "\n" /* + document.all["SentPaper"].value+ "\n" */  + document.all["MeetStart"].value + "\n" + document.all["MeetEnd"].value);
	for(i=1; i<=Total; i++) {
		alert ( document.all["nSession"+i].value + "\n" 
		+ document.all["hTopic"+i].value + "\n" 
		+ document.all["nNum"+i].value + "\n" 
		+ document.all["Subject1"+i].value + "\n" 
		+ document.all["Subject2"+i].value + "\n" 
		+ document.all["Message"+i].value + "\n" 
		+ document.all["PathFile"+i].value + "\n" );
		//+ document.all["MeetEnd"].value
	}
}