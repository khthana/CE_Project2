<link rel="stylesheet" href="../css/prepost.css" type="text/css">
<?php
// �纤���ѹ����ա�û�Ъ��㹤��駷���ҹ���
if (isset($_REQUEST["JdDate"]))
{
	$StartDay = $_REQUEST["JdDate"];
}else {
	$jd = GregorianToJD(date("m"),1,date("Y"));
	$StartDay = JDtoGregorian($jd);
}

$m = substr($StartDay,0,strpos($StartDay,"/"));	// �Ѵ�����͹�͡��
$d = substr(substr(strchr($StartDay,"/"),1),0,strpos($StartDay,"/"));	// �Ѵ����ѹ�͡��
$y = substr(strrchr($StartDay,"/"),1);	// �Ѵ��һ��͡��
$MakeTime = mktime(0,0,0,$m,1,$y);
if (isset($_REQUEST["JdDate"]))	{	$jd = GregorianToJD($m,1,$y); }
/*$month = date("m")+0;	// +0 ���ͷ��� ������� integer
$year  = date("Y")+543;*/
if ($m<10) $m='0'.$m;
/*echo "<script>alert('".$m."');</script>";*/

$sql = "SELECT MeetID,D FROM preparemeeting WHERE m = '".$m ."' AND y = '" . $y . "' ORDER BY MeetID DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't run SQL command List Day Meetting");

//$Day[0] = 0;
while ($row = mysql_fetch_array ($table)){
	$MID[] = $row["MeetID"];
	$Day[] = $row["D"];
}
if (mysql_num_rows($table) == 0)	{ $Day[0] = 0;}		// ������͹���� ����ա�û�Ъ�� �С�˹���� $Day[0] ���ͻ�ͧ�ѹ Error
$c = 0;	// ��Ѻ����繵�Ƿ����������� �ͧ�ѹ����ա�û�Ъ��

	$StartWeek = date("w", $MakeTime);
	// Check lastday in month
	if (($m == 1) || ($m == 3) || ($m ==5) || ($m == 7) || ($m ==8) || ($m == 10) || ($m ==12))	{	$EndCount = 31; }
	elseif 	(($m == 4) || ($m == 6) || ($m ==9) || ($m == 11))	{	$EndCount = 30; }
	elseif 	(!checkdate($m,$d+29,$y))	{	$EndCount = 28; }
	else	$EndCount = 29;

	/*echo "<tr align=middle bgcolor=FFFFFF height=16><td colspan=7 width=25>";
	echo "/JDday " . $jd . "<br>/Day " . $StartDay;
	echo "<br><br>GetWeek> " . $StartWeek . "</td></tr>";*/
	$StartCount = $StartWeek;
	$NumDay = 1;
?>
<table width="180" border="0">
            <tr>
              <td bgcolor="#000000"><table width=100% border=0 cellpadding=0 cellspacing=0 bgcolor=#FF9900 class="thai">
                  <tbody>
                    <tr bgcolor="#FFFF99">
                      <td colspan=7 class="thaibold"><font size="1">&nbsp;<img src="../images/icon/arrow_down.gif" width="10" height="10">&nbsp;<font color="#000000">��ԷԹ���ǡ�û�Ъ��</font></font></td>
                    </tr>
                    <tr align=middle bgcolor="#000000">
                      <td height="1" colspan=7></td>
                    </tr>
					<tr>
                       <td height="5" colspan="7"></td>
                     </tr>
                    <tr align="center">
                      <td colspan=7>��Ш���͹ <strong><?php echo date("F",$MakeTime)?></strong></td>
                    </tr>
					 <tr align="center">
                      <td colspan=7>�.�. <strong><?php echo date("Y",$MakeTime)+543?></strong></td>
                    </tr>
                     <tr>
                       <td height="5" colspan="7"></td>
                     </tr>
                    <tr>
                      <td height="1" colspan="7" bgcolor="#000000"></td>
                    </tr>
					<tr align=middle bgcolor=FFCC66 height=16>
                      <td width=25><strong>��</strong></td>
                      <td width=24><strong>�.</strong></td>
                      <td width=24><strong>�.</strong></td>
                      <td width=24><strong>�.</strong></td>
                      <td width=24><strong>��</strong></td>
                      <td width=23><strong>�.</strong></td>
                      <td width=30><strong>�.</strong></td>
                    </tr>
					<tr>
                      <td height="1" colspan="7" bgcolor="#000000"></td>
                    </tr>
<?php
	for ($NumDay; $NumDay<$EndCount; $NumDay+0)
	{
		echo "<tr align=middle height=16>";
		for($i=0; $i<7; $i++)
		{
			if ($NumDay > $EndCount)	{ $StartCount = 1; }
			
			if (($i == $StartCount) || ($StartCount == -1))	{
				$StartCount = -1;
				// Check �ѹ��������ѹ�Ѩ�غѹ  ���������
				if (($NumDay == date("d")) && ($m == date("m")) && ($y == date("Y")))	{	echo "<td bgcolor=#FFFF00 width=25>" . $NumDay++ . "</td>";
				}elseif ($NumDay == $Day[$c])	{	echo "<td bgcolor=#CCCCCC width=25><a href=preview.php?tid=" . $MID[$c] . ">" . $NumDay++ . "</a></td>";	// �ѹ����ա�û�Ъ��
				}else	echo "<td bgcolor=#FF9900 width=25>" . $NumDay++ . "</td>";
			}else echo "<td bgcolor=FFCC66 width=25>-</td>";
		}
		echo "</tr>";
	}
	
if (isset($_REQUEST["tid"])) $andID = "&tid=".$_REQUEST["tid"];
else $andID = "";
?>
					<tr>
                      <td height="1" colspan="7" bgcolor="#000000"></td>
                    </tr>
                    <tr align=middle height=16>
                      <td colspan=2><a href="<?php echo $FileIndex . "?JdDate=" . JDtoGregorian($jd-1) . $andID; ?>"><font color=#ffffff>��͹��ѧ</font></a></td>
                      <td colspan=3><a href="#">�ա���Ѿഷ</a></td>
                      <td colspan=2><a href="<?php echo $FileIndex . "?JdDate=" . JDtoGregorian($jd+$EndCount) . $andID; ?>"><font color=#ffffff>�Ѵ�</font></a></td>
                    </tr>
                  </tbody>
              </table></td>
            </tr>
        </table>