<?php 
/*echo $_FILES["file"]['type'];
echo $_FILES["file"]['size'];
echo $_FILES["file"]['name'];*/

class Upload {

	function GetFileType($file_type)
	{
		switch($file_type)  //  ���͡��״�ͧ�Ҿ ����繨Ф׹��ҡ�Ѻ�͡���ʡ�Ţͧ�Ҿ �������繨Ф׹��ҡ�Ѻ�͡��� false
		{
			case "application/pdf"; return "pdf"; break;
			case "application/octet-stream"; return "rar"; break;
			case "application/x-zip-compressed"; return "zip"; break;
			case "image/jpg"; return "jpg"; break;
			case "image/jpeg"; return "jpg"; break;
			case "image/pjpeg"; return "jpg"; break;
			case "image/gif"; return "gif"; break;
			default; return "false";
		}
	}
	
	function do_upload($name1, $name2, $name3, $userfile) {
		$site_name = $_SERVER['HTTP_HOST'];
		$url_dir = "http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
		$url_this =  "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];

		$upload_dir = "upload/";
		$upload_url = $url_dir . "/upload/";
	
		$temp_name = $userfile['tmp_name'];
		$file_name = $userfile['name']; 
		$result    = $userfile['error'];
		$file_url  = $upload_url.$file_name;
		$idfile = $name1."_".$name2."_".$name3."_".trim($file_name);
		$file_path = $upload_dir.$idfile;
	
		$result  =  move_uploaded_file($temp_name, $file_path);
		$message = ($result)? $file_path :
				  "Somthing is wrong with uploading a file.";
	
		return $message;
	}
}
?>