<?php 
session_start();
?>
<html>
<head>
<title>Pre-Post Conference System</title>
<?php 
include("../config.php");
include("upload.php");

if (isset($_FILES["fileUp"])){
	$up = new Upload();
	if ($up->GetFileType($_FILES["fileUp"]['type']) == 'pdf') {
		$msgFile = $up->do_upload($_REQUEST["tid"], $_REQUEST["nSession"], $_REQUEST["nNum"], $_FILES["fileUp"]);
		$sql = "INSERT INTO tempfile VALUES('','".$_REQUEST["tid"]."','".$_REQUEST["nSession"]."','".$_REQUEST["nNum"]."','".$msgFile."','".$_SESSION["Name"]."')";
		//echo "<br><br><br>".$sql;
		$table = mysql_db_query ($dbname, $sql) or die("Can't INSERT to DB");
	}else echo "<script>alert('��س�Ṻ�����ʡ�� PDF ��ҹ�鹤�Ѻ');</script>";
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../css/prepost.css" type="text/css">
<script LANGUAGE="JavaScript">
<!-- Hide JavaScript From Java-Impaired Browsers-->
function FileUpload(tid, nSession, nNum)
{
	//alert(nSession+'  '+nNum);
	if (document.all["fileUp"].value == '')	alert('��سҷӡ��Ṻ����͹��Ѻ');
	else {
		document.all["formUp"].action = "user_upload.php?tid="+tid+"&nSession="+nSession+"&nNum="+nNum;
		document.all["formUp"].submit();
	}
}
//-->
</script>
</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"><center>
  <table width="780" border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td height="16">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="16" align="right"><strong>Content&nbsp;Site&nbsp;->>>&nbsp;</strong></td>
      <td width="474"><table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC" class="thai">
        <tr>
          <td width="25%" align="center"><strong><a href="index.php"><font color="#0000CC">Home</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="editProfile.php"><font color="#0000CC">Profile</font></a></strong></td>
          <td width="25%" align="center">&nbsp;</td>
          <td width="25%" align="center"><strong><font color="#000000" size="-2">[<a href="../logout.php">LogOut</a>]</font></strong></td>
        </tr>
      </table></td>
      <td width="126">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">
        <?php $FileIndex = "user_upload.php";		include($_SESSION['useFile']);	include("calendar.php");?></td>
      <td align="center" valign="top"><br>
        <table width="95%"  border="0" cellpadding="1" cellspacing="0" bgcolor="#000000" class="thai">
          <tr>
            <td colspan="2" bgcolor="#000000">
<table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="thai">
                <tr>
                  <td colspan="2" align="center" valign="top">&nbsp;</td>
                </tr>
				
<?php
$sql = "SELECT * FROM tempfile WHERE Member='".$_SESSION["Name"]."' AND MeetID='".$_REQUEST["tid"]."' ORDER BY Num DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
while ($rowFile = mysql_fetch_array ($table)){
	echo '<tr>
			  <td colspan="2" align="center" valign="top">�س��Ṻ���&nbsp;<font color="#0000FF">'.substr(strrchr($rowFile["FileUpload"], "/"),1,strlen(strrchr($rowFile["FileUpload"], "/"))).'</font>&nbsp;�������º���з�� '.$rowFile["Session"].'&nbsp;</td>
			</tr>';
}
?>
                <tr>
                  <td colspan="2" align="center" valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="2" align="center" valign="top">
                    <form name="formUp" method="post" enctype="multipart/form-data" action="user_upload.php">
                      <input name="fileUp" type="file" class="formor" size="50">
                    </form>
                  </td>
                </tr>
                <tr>
                  <td height="8" colspan="2" align="center"></td>
                </tr>
                <tr>
                  <td width="84%" valign="top"><font color="#FF0000">&nbsp;**㹡��&nbsp;Ṻ������������������ҹ��**<br>
					**�������������ժ�ͧ��ҧ**</font></td>
                  <td width="16%">&nbsp;</td>
                </tr>
            </table>
<?php
$sql = "SELECT * FROM preparemeeting WHERE MeetID='".$_REQUEST["tid"]."' ORDER BY meetid DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
$row = mysql_fetch_array ($table);

echo '<table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="thai">';
/*echo '<tr><td width="25%">&nbsp;</td><td width="60%">&nbsp;</td><td width="15%">&nbsp;</td></tr>';
echo '<tr><td colspan=3 align=center><img src="../images/logo/logo-kmitl-eng_resize.gif" width="102" height="99"></td></tr>';
echo '<tr><td colspan=3 align=center><br>
            <b>����º���С�û�Ъ����Ш�'.$row["Subject"].'</b><br>
            <strong>���駷��&nbsp;&nbsp;'.$row["Num"].'</strong><br>
            <b>�ѹxx���&nbsp;'.$row["D"].'&nbsp;'.$row["M"].'&nbsp;�.�.&nbsp;'.$row["Y"].'</b><br>
            <b>'.$row["MeetPlace"].'&nbsp;&nbsp;<br>����&nbsp;'.$row["MeetStart"].'�. - '.$row["MeetEnd"].'�.&nbsp;</b><br>
            <b>..................................</b><br></td></tr>';*/
echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';

$sql = "SELECT * FROM pathmeeting WHERE MeetID='".$row["MeetID"]."'";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
$tempTopic = '';
$tempSubTopic = '';
$tempSubNumTopic = '';
$LinkFile = 'upload/'.$row["MeetID"].'.pdf';
$TbColor = "#FFFFCC";
while ($row = mysql_fetch_array ($table)){
if (($tempSubTopic==$row["Session"])&&($tempSubNumTopic==$row["Num"])) {
	if ($row["PathFile"]!='-') {
		echo '<tr>
				  <td colspan=2 align="center"><font color="#FF0000">�����Ṻ�����</font>&nbsp;&nbsp;
				  <a href="'.$row["PathFile"].'" target="_blank"><font color="#000000"><u>'.substr(strrchr($row["PathFile"], "/"),1,strlen(strrchr($row["PathFile"], "/"))).'</u></font></a></td>
				</tr>';
	}
}else {
	if($tempTopic!=$row["hTopic"]) {
		$tempTopic=$row["hTopic"];
		echo '<tr>
			  <td valign="top">&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td colspan=2 valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>'.$tempTopic.'</strong></td>
			  <td>&nbsp;</td>
			</tr>';
	}else $tempTopic='';
	if (($tempSubTopic!=$row["Session"])&&($tempTopic!=$row["hTopic"])) {
		echo '<tr>
				  <td valign="top" height="8"></td>
				  <td height="8"></td>
				  <td>&nbsp;</td>
				</tr>';
	}
	if ($tempSubTopic!=$row["Session"]) {
		if ($TbColor == "#FFFFCC") { $TbColor = "#FFCC66"; } else $TbColor = "#FFFFCC";
		echo '<tr>
				  <td valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����º���з��&nbsp;'.$row["Session"].'&nbsp;&nbsp;</td>
				  <td>����ͧ&nbsp;&nbsp;<font color="#0000FF">'.$row["Subject1"].'</font></td>
				  <td align="center">&gt;<a href="#" onClick="javascript:FileUpload('.$row["MeetID"].','.$row["Session"].','.$row["Num"].');">Ṻ���</a>&lt;</td>
				</tr>';
		if ($row["PathFile"]!='-') {
		echo '<tr>
				  <td colspan=2 align="center"><font color="#FF0000">�����Ṻ�����</font>&nbsp;&nbsp;
				  <a href="'.$row["PathFile"].'" target="_blank"><font color="#000000"><u>'.substr(strrchr($row["PathFile"], "/"),1,strlen(strrchr($row["PathFile"], "/"))).'</u></font></a></td>
				</tr>';
		}
	}else { echo '<tr>
				  <td valign="top" align="right">'.$row["Session"].".".$row["Num"].'&nbsp;&nbsp;</td>
				  <td>����ͧ&nbsp;&nbsp;<font color="#0000FF">'.$row["Subject2"].'</font></td>
				  <td align="center">&gt;<a href="#" onClick="javascript:FileUpload('.$row["MeetID"].','.$row["Session"].','.$row["Num"].');">Ṻ���</a>&lt;</td>
				</tr>';
				if ($row["PathFile"]!='-') {
					echo '<tr>
							  <td colspan=2 align="center"><font color="#FF0000">�����Ṻ�����</font>&nbsp;&nbsp;
							  <a href="'.$row["PathFile"].'" target="_blank"><font color="#000000"><u>'.substr(strrchr($row["PathFile"], "/"),1,strlen(strrchr($row["PathFile"], "/"))).'</u></font></a></td>
							</tr>';
					}
			}
	$tempTopic = $row["hTopic"];
	$tempSubTopic = $row["Session"];
	$tempSubNumTopic = $row["Num"];
	
}
}
echo '<tr><td valign="top">&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
		<tr>
		  <td colspan="3" align="center" valign="top"><b>..................................</b></td>
		</tr>
		<tr><td valign="top">&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
		</table>';
mysql_close();
/*
<tr>
  <td align="center" colspan=3><b><a href="'.$LinkFile.'" target="_blank">��������������</a></b></td>
</tr>
<tr><td valign="top">&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
*/
?></td>
          </tr>
        </table>
        <br>
      </td>
      <td valign="top">

<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr>
          <td align="center"><font color="#000000">�Թ�յ�͹�Ѻ</font><br><a href="mailto:<?php echo $_SESSION["Mail"];?>"><u><font color="#990000"><?php echo "�س" . $_SESSION['Name'];?></font></u></a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><FONT class=font color=#000000>Copyright &copy;2003-2005 ce.kmitl.ac.th. All rights reserved.</FONT></td>
      <td>&nbsp;</td>
    </tr>
  </table>

</center></body>
</html>