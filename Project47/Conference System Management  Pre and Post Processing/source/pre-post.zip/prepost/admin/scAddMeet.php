<?php
session_start();
include("../config.php");
include("upload.php");
$up = new Upload();

//$_SESSION["file"] = $_FILES["file"];
// Assign value
if (!isset($_REQUEST["action"])) $action='start';
else $action = $_REQUEST["action"];
$_SESSION["Topic"] = Array("","����ͧ�����ͷ�Һ","�Ѻ�ͧ��§ҹ��û�Ъ��","����ͧ�׺���ͧ","����ͧ�ʹ����;Ԩ�ó�","����");

// Check file type
if ((isset($_FILES["PathFile"]))&&($_FILES["PathFile"]['name']!="")) {
	if (($up->GetFileType($_FILES["PathFile"]['type']) != 'pdf')&&($action!='start')) {
			$MSGerror = '��س�Ṻ��� PDF ��ҹ�鹤�Ѻ';
			header("Location: add_meeting2.php?action=".$action."&MSGerror=".$MSGerror); 
			exit();
	}else $filePath = $up->do_upload($_SESSION["NumMeet"], $_POST["nSession"],$_POST["nNum"], $_FILES["PathFile"]);
}else $filePath = '-';

switch ($action) {
	case 'start' :
		$_SESSION["NumMeet"] 	= $_POST["NumMeet"];
		$_SESSION["tSubject"] 	= $_POST["Subject"];
		$_SESSION["tNum"] 		= $_POST["NumMeet"]."/".$_POST["MeetYear"];
		$_SESSION["tD"] 		= $_POST["MeetDay"];
		$_SESSION["tM"] 		= $_POST["MeetMonth"];
		$_SESSION["tY"] 		= $_POST["MeetYear"]-543;
		$_SESSION["tSendPaper"] = $_POST["SentMonth"]."/".$_POST["SentDay"]."/".($_POST["SentYear"]-543);
		$_SESSION["tStart"] 	= $_POST["MeetStart"];
		$_SESSION["tEnd"] 		= $_POST["MeetEnd"];
		$_SESSION["tPlace"] 	= $_POST["MeetPlace"];

		$_SESSION["TP"] = 1;
		$_SESSION["Total"] = 1;
		$_SESSION["NumSub"] = 1;
		$_SESSION["Sess"] = 1;
		$action = 'addSession';
		break;
		
	case 'addSession' :
		$_SESSION["NumSub"] = 1;
		if (isset($_REQUEST["TP"])) $_SESSION["TP"]++;
		
		$_SESSION["sSession".$_SESSION["Total"]] 		= $_POST["nSession"];
		$_SESSION["sNum".$_SESSION["Total"]] 			= $_POST["nNum"];
		$_SESSION["sTopic".$_SESSION["Total"]] 			= $_POST["hTopic"];
		$_SESSION["sSubject1".$_SESSION["Total"]] 		= $_POST["Subject1"];
		$_SESSION["sSubject2".$_SESSION["Total"]] 		= $_POST["Subject2"];
		$_SESSION["sMessage".$_SESSION["Total"]] 		= $_POST["Message"];
		$_SESSION["numFile".$_SESSION["Total"]]			= 1;
		$_SESSION["File".$_SESSION["Total"]]			= $filePath;
		
		//$FileName = $up->do_upload($_SESSION["sSession".$_SESSION["Total"]],$_SESSION["sNum".$_SESSION["Total"]], $_FILES["PathFile"]);
		
		$_SESSION["Sess"]++;
		$_SESSION["Total"]++;
		break;
		
	case 'addSubSession' :
		//$_SESSION["NumSub"]++;
		$_SESSION["sSession".$_SESSION["Total"]] 		= $_POST["nSession"];
		$_SESSION["sNum".$_SESSION["Total"]] 			= $_SESSION["NumSub"];
		$_SESSION["sTopic".$_SESSION["Total"]] 			= $_POST["hTopic"];
		$_SESSION["sSubject1".$_SESSION["Total"]] 		= $_POST["Subject1"];
		$_SESSION["sSubject2".$_SESSION["Total"]] 		= $_POST["Subject2"];
		$_SESSION["sMessage".$_SESSION["Total"]] 		= $_POST["Message"];
		$_SESSION["numFile".$_SESSION["Total"]]			= 1;
		$_SESSION["File".$_SESSION["Total"]]			= $filePath;
		
		//$FileName = $up->do_upload($_SESSION["sSession".$_SESSION["Total"]],$_SESSION["sNum".$_SESSION["Total"]], $_FILES["PathFile"]);
		
		$_SESSION["NumSub"]++;
		$_SESSION["Total"]++;
		break;
		
	case 'Finish' :
		$_SESSION["sSession".$_SESSION["Total"]] 		= $_POST["nSession"];
		$_SESSION["sNum".$_SESSION["Total"]] 			= $_SESSION["NumSub"];
		$_SESSION["sTopic".$_SESSION["Total"]] 			= $_POST["hTopic"];
		$_SESSION["sSubject1".$_SESSION["Total"]] 		= $_POST["Subject1"];
		$_SESSION["sSubject2".$_SESSION["Total"]] 		= $_POST["Subject2"];
		$_SESSION["sMessage".$_SESSION["Total"]] 		= $_POST["Message"];
		$_SESSION["numFile".$_SESSION["Total"]]			= 1;
		$_SESSION["File".$_SESSION["Total"]]			= $filePath;
		
		//$FileName = $up->do_upload($_SESSION["sSession".$_SESSION["Total"]],$_SESSION["sNum".$_SESSION["Total"]], $_FILES["PathFile"]);
		header("Location: incMeeting.php");
		/*echo "<script>window.open(' incMeeting.php','createPDF','height=700,width=700,status=0,menubar=0')</script>";*/
		exit();
		break;
			
	default :
		if (isset($_REQUEST["TP"])) $_SESSION["TP"]++;
		header("Location: add_meeting2.php?action=addSession");
		exit();
		break;
}

header("Location: add_meeting2.php?action=".$action);

?>