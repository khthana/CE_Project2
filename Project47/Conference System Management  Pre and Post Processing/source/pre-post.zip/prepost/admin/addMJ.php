<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>ŧ����¹��Ҫԡ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="css/prepost.css" type="text/css">

<?php

include("../config.php");
include("admin.php");
$adm = new Admin();

if (isset($_REQUEST["addMJ"]))
	$adm->AddMemberJam(1,$_REQUEST["name"],$_REQUEST["sname"],$_REQUEST['dean']);

?>
</head>

<body bgcolor="#FFCC66">
<form name="form1" method="post" action="addMJ.php?addMJ=true" style="visibility:hidden ">
  <p>&nbsp;</p>
   <table width="39%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="42%"><div align="left"><strong>���;�����ӹ�˹��:</strong></div></td>
      <td width="58%"><input type="text" name="name"></td>
    </tr>
    <tr>
      <td><div align="left"><strong>���ʡ��:</strong></div></td>
      <td><input type="text" name="sname"></td>
    </tr>
    <tr>
      <td><div align="left"><strong>���˹�:</strong></div></td>
      <td><input type="text" name="dean"></td>
    </tr>
    <tr>
      <td>&nbsp; </td>
      <td><input name="Submit" type="submit" onClick="" value="�ѹ�֡������"></td>
    </tr>
  </table>
  <p>&nbsp;  </p>
</form>
</body>
</html>
