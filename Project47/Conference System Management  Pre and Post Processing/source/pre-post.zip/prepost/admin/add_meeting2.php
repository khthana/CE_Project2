<?php
session_start();
include("../config.php");

if (!isset($_SESSION["step"])) $step=0;
else $step = $_SESSION["step"];
if (!isset($_REQUEST["action"])) {
	$action='start';
	session_unregister("Total");
	session_unregister("NumMeet");
	session_unregister("tSubject");
	session_unregister("tNum");
	session_unregister("tD");
	session_unregister("tM");
	session_unregister("tY");
	session_unregister("tSendPaper");
	session_unregister("tStart");
	session_unregister("tEnd");
	session_unregister("tPlace");
}
else $action = $_REQUEST["action"];
if (isset($_REQUEST["MSGerror"])) echo "<script>alert('".$_REQUEST["MSGerror"]."');</script>";

function GetLongDateThai($date)
{
	$van = array("�ѹ�ҷԵ��"	,"�ѹ�ѹ���","�ѹ�ѧ���","�ѹ�ظ","�ѹ����ʺ��","�ѹ�ء��","�ѹ�����");
	$dean = array("","���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��ɨԡ�¹","�ѹ�Ҥ�");
	$timestamp = strtotime($date);
	return '&nbsp;&nbsp;'.$van[date('w',$timestamp)].'��� '.date('d',$timestamp).'&nbsp;'.$dean[date('m',$timestamp)+0].'&nbsp;&nbsp;�.�.'.(date('Y',$timestamp)+543);
}
?>
<html>
<head>
<title>Pre-Post Conference System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../css/prepost.css" type="text/css">
<script LANGUAGE="JavaScript" src="../tools.js"></script>
<script LANGUAGE="JavaScript">
<!-- Hide JavaScript From Java-Impaired Browsers-->
function CheckText(action,TP){
	//document.all["SentPaper"].value = document.all["SentDay"].value + "/" + document.all["SentMonth"].value + "/" + document.all["SentYear"].value;
	switch(action) {
		case 'start' :
			if ( (document.all['Subject'].value =='') || (document.all['NumMeet'].value =='') || (document.all['MeetPlace'].value =='') || 
			(document.all['MeetDay'].value =='') || (document.all['MeetMonth'].value =='') || (document.all['MeetYear'].value =='') || 
			(document.all['SentDay'].value =='') || (document.all['SentMonth'].value =='') || (document.all['SentYear'].value =='') || 
			(document.all['MeetStart'].value =='') || (document.all['MeetEnd'].value =='')  ) 
				alert ("��سҵ�Ǩ�ͺ�����ŷ���͡�����ա����\n���ͷ�ҹ�ѧ������͡�����źҧ���˹�");
			else {	
					document.all['AddMeeting'].action = "scAddMeet.php?action="+action;
					document.all['AddMeeting'].submit();
			}
			break;
			
		case 'addSession' :
			if ( (document.all['Subject1'].value =='') && (document.all['Message'].value =='') )//|| (document.all['PathFile'].value =='') )//|| (document.all['Poster'].value =='')  ) 
				if (confirm ("�س��ͧ��â�����Ǣ�͹��������?")) {
					document.all['AddMeeting'].action = "scAddMeet.php?action=none&TP=1";
					document.all['AddMeeting'].submit();
				}else ;
			else if ( (document.all['nSession'].value =='') || (document.all['nNum'].value =='') || (document.all['hTopic'].value =='') || 
			(document.all['Subject1'].value =='') || (document.all['Subject2'].value =='') || 
			(document.all['Message'].value =='') )//|| (document.all['PathFile'].value =='') )//|| (document.all['Poster'].value =='')  ) 
				alert ("��سҵ�Ǩ�ͺ�����ŷ���͡�����ա����\n���ͷ�ҹ�ѧ������͡�����źҧ���˹�");
			else {	
					if (TP==1) document.all['AddMeeting'].action = "scAddMeet.php?action="+action+"&TP=1";
					else {	document.all['AddMeeting'].action = "scAddMeet.php?action="+action;	}
					document.all['AddMeeting'].submit();
			}
			break;
			
		case 'addSubSession' :
			if ( (document.all['Subject1'].value =='') && (document.all['Message'].value =='') )//|| (document.all['PathFile'].value =='') )//|| (document.all['Poster'].value =='')  ) 
				if (confirm ("�س��ͧ��â�����Ǣ�͹��������?")) {
					document.all['AddMeeting'].action = "scAddMeet.php?action=none&TP=1";
					document.all['AddMeeting'].submit();
				}else ;
			else if ( (document.all['nSession'].value =='') || (document.all['nNum'].value =='') || (document.all['hTopic'].value =='') || 
			(document.all['Subject1'].value =='') || (document.all['Subject2'].value =='') || 
			(document.all['Message'].value =='') )//|| (document.all['PathFile'].value =='') )//|| (document.all['Poster'].value =='')  ) 
				alert ("��سҵ�Ǩ�ͺ�����ŷ���͡�����ա����\n���ͷ�ҹ�ѧ������͡�����źҧ���˹�");
			else {	
					document.all['AddMeeting'].action = "scAddMeet.php?action="+action;
					document.all['AddMeeting'].submit();
			}
			break;
			
		case 'Finish' :
			if ( (document.all['nSession'].value =='') || (document.all['nNum'].value =='') || (document.all['hTopic'].value =='') || 
			(document.all['Subject1'].value =='') || (document.all['Subject2'].value =='') || 
			(document.all['Message'].value =='') )//|| (document.all['PathFile'].value =='') )//|| (document.all['Poster'].value =='')  ) 
				alert ("��سҵ�Ǩ�ͺ�����ŷ���͡�����ա����\n���ͷ�ҹ�ѧ������͡�����źҧ���˹�");
			else {	
					document.all['AddMeeting'].action = "scAddMeet.php?action="+action;
					//document.all['AddMeeting'].target = "_blank";
					document.all['AddMeeting'].submit();
			}
			break;
			
		default :
			break;
	}
	//this.AddMeeting.submit();
}
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
  <table width="780" border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td height="16">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="16" align="right"><strong>Content&nbsp;Site&nbsp;->>>&nbsp;</strong></td>
      <td width="474"><table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC" class="thai">
          <tr>
            <td width="25%" align="center"><strong><a href="index.php"><font color="#0000CC">Home</font></a></strong></td>
            <td width="25%" align="center"><strong><a href="editProfile.php"><font color="#0000CC">Profile</font></a></strong></td>
            <td width="25%" align="center">&nbsp;</td>
            <td width="25%" align="center"><strong><a href="../index.html"><font color="#000000" size="-2">[LogOut]</font></a></strong></td>
          </tr>
      </table></td>
      <td width="126">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">
	  <?php $FileIndex = "add_meeting2.php";		include($_SESSION['useFile']);	include("calendar.php");?>
	  </td>
      <td align="center" valign="top">
	  
<?php 
if (isset($_SESSION["tSubject"]) && isset($_SESSION["tNum"]) && isset($_SESSION["tD"]) && isset($_SESSION["tM"]) && isset($_SESSION["tY"]) 
	&& isset($_SESSION["tSendPaper"]) && isset($_SESSION["tStart"]) && isset($_SESSION["tEnd"]) && isset($_SESSION["tPlace"]))
{	  
	echo "<table width=90% border=0 cellspacing=0 cellpadding=0 class=thai>";
	echo "<tr><td colspan=3 align=center><br>";
	echo "<b>" .$_SESSION["tSubject"]. "</b><br>";
	echo "<b>���駷��&nbsp;&nbsp;" .$_SESSION["tNum"]. "</b><br>";
	echo "<b>". GetLongDateThai($_SESSION["tM"].'/'.$_SESSION["tD"].'/'.$_SESSION["tY"]) ."</b><br>";
	echo "<b>�&nbsp;" .$_SESSION["tPlace"]. "&nbsp;&nbsp;����&nbsp;" .$_SESSION["tStart"]. "-" .$_SESSION["tEnd"]. "&nbsp;�.</b><br>";
	echo "<b>..................................</b><br>";
	echo "</td></tr>";
	echo "<tr><td height=8 width=30%></td><td height=8 width=55%></td><td height=8 width=15%></td></tr>";
}
// +++++++++++++++++++++++++++++++++++++End Head
//<img src=\"../images/icon/arrow_down.gif\" width=\"10\" height=\"10\">&nbsp;<img src=\"../images/icon/delete.gif\" width=\"11\" height=\"12\">
if (isset($_SESSION["Total"])) {
for($i=1; $i< $_SESSION["Total"]; $i++) {
	/*echo "<script>alert('".($i-1) .". ".$_SESSION["sTopic".($i)]."    ".($i-2) ."." .$_SESSION["sTopic".($i-1)]."');</script>";*/
	
	if ($i==1) { echo "<tr align=center><td colspan=3><strong><u><br>".$_SESSION["sTopic".($i)]. "</u></strong></td><td></td></tr>"; }
	else if ($_SESSION["sTopic".($i)]!=$_SESSION["sTopic".($i-1)]) { echo "<tr align=center><td colspan=3><strong><u><br>".$_SESSION["sTopic".($i)]. "</u></strong></td><td></td></tr>"; }

	if ($i==1) { echo "<tr><td height=8></td><td height=8></td><td height=8></td></tr>  <tr><td width=29%><strong>����º���з��&nbsp;".$_SESSION["sSession".($i)]."</strong></td><td width=71%>"; }
	else if ($_SESSION["sSession".($i)]!=$_SESSION["sSession".($i-1)]) { echo "<tr><td height=8></td><td height=8></td><td height=8></td></tr>  <tr><td width=29%><strong>����º���з��&nbsp;".$_SESSION["sSession".($i)]."</strong></td><td width=71%>"; }
	
	if ($i==1) { echo "����ͧ&nbsp;" .$_SESSION["sSubject1".($i)] ."</td><td><img src=\"../images/icon/arrow_down.gif\" width=\"10\" height=\"10\">&nbsp;<img src=\"../images/icon/delete.gif\" width=\"11\" height=\"12\"></td></tr>"; }
	else if (($i==($_SESSION["Total"]-1))&&($_SESSION["sSession".($i)]!=$_SESSION["sSession".($i-1)])) { echo "����ͧ&nbsp;" .$_SESSION["sSubject1".($i)] ."</td><td><img src=\"../images/icon/arrow_down.gif\" width=\"10\" height=\"10\">&nbsp;<img src=\"../images/icon/delete.gif\" width=\"11\" height=\"12\"></td></tr>"; }
	else if (($i!=$_SESSION["Total"])&&($_SESSION["sSession".($i)]!=$_SESSION["sSession".($i-1)])) { echo "����ͧ&nbsp;" .$_SESSION["sSubject1".($i)] ."</td><td><img src=\"../images/icon/arrow_down.gif\" width=\"10\" height=\"10\">&nbsp;<img src=\"../images/icon/delete.gif\" width=\"11\" height=\"12\"></td></tr>"; }
	else { 
		if ($_SESSION["sNum".($i)]=='1') echo "����ͧ&nbsp;" .$_SESSION["sSubject1".($i)] ."</td><td><img src=\"../images/icon/arrow_down.gif\" width=\"10\" height=\"10\">&nbsp;<img src=\"../images/icon/delete.gif\" width=\"11\" height=\"12\"></td></tr> <tr><td height=8></td><td height=8></td><td height=8></td></tr>"; 
		echo "<tr><td align=right><b>" .$_SESSION["sSession".($i)]. "." .$_SESSION["sNum".($i)]. "</b>&nbsp;&nbsp;</td><td>����ͧ&nbsp;" .$_SESSION["sSubject2".($i)]. "</td><td><img src=\"../images/icon/arrow_down.gif\" width=\"10\" height=\"10\">&nbsp;<img src=\"../images/icon/delete.gif\" width=\"11\" height=\"12\"></td></tr></tr>";
	}
	echo "<tr><td height=8></td><td height=8></td><td height=8></td></tr>";
	
	/*echo "<tr><td>&nbsp;</td><td bgcolor=#FFFFCC>���ͧ�ҡ����ҹ����������Ҥ� ���ʺ�ѭ�Ҥ����ẹ���Դ�������§�� �� ������Ӿǡ IM ���ҧ MMSG ICQ �ѡ��ش�ҡ����������ͺ��¤��� ��ô�ǹ���Ŵ��ҹ FTP/RSYNC ������ҧ�ҡ �繵� </td></tr>";
	echo "<tr><td height=8></td><td height=8></td></tr>";
	echo "<tr><td align=right><strong>Ṻ���&nbsp;:&nbsp;</strong></td><td>F:\Software\slsk152.exe </td></tr>";
	echo "<tr align=center><td colspan=2>";
	if (($i==1)||($i==$_SESSION["Total"])) { echo "<hr width=90% size=2 color=#FFFFCC>"; }
	else if ($_SESSION["sSession".($i)]!=$_SESSION["sSession"][$i]) { echo "<hr width=90% size=2 color=#FFFFCC>"; }
	echo "</td></tr>";*/
}}
if (isset($_SESSION["tSubject"]) && isset($_SESSION["tNum"]) && isset($_SESSION["tD"]) && isset($_SESSION["tM"]) && isset($_SESSION["tY"]) 
	&& isset($_SESSION["tSendPaper"]) && isset($_SESSION["tStart"]) && isset($_SESSION["tEnd"]) && isset($_SESSION["tPlace"]))
{	  echo "</table>"; }

?>
	  
	  <br>
	
	  <form action="addMeet.php" method="post" enctype="multipart/form-data" name="AddMeeting">
		<table width="95%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>
			
<?php
$sql = "SELECT Num FROM preparemeeting ORDER BY meetid DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't run SQL command");
$row = mysql_fetch_array ($table);

if ($action=='start') include("step1.inc");
else if ($action=='addSession') include("step2.inc");
else include("step3.inc");
?>

<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
          <tr align="right">
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr align="right">
            <td colspan="2">
				<input name="Session" type="button" class="button" id="Session" onClick="javascript:CheckText('<?php if(($action!='addSubSession')||($action=='start')) echo $action; 
				else echo 'addSession';?>','');" value="��˹�����">
				&nbsp;&nbsp;
				<input name="Digest" type="button" class="button" id="Digest" value="����ͧ����" onClick="javascript:CheckText('addSubSession','');" disabled>
				&nbsp;&nbsp;
				<input name="NextHead" type="button" class="button" id="NextHead" value="��Ǣ�ͶѴ�" onClick="javascript:CheckText('addSession','1');" disabled>
				&nbsp;&nbsp;
				<input name="Save" type="button" class="button" id="Save" value="�ѹ�֡" onClick="javascript:CheckText('Finish','');" disabled>
				&nbsp;&nbsp;
              	<input name="Cancel" type="reset" class="button" id="Cancel" value="¡��ԡ">			</td>
            </tr>
</table>			
<?php 
if ($action=='addSubSession') 
	echo "<script>ObjEnable('Digest')</script>";
if ($action!='start')
	echo "<script>ObjEnable('NextHead')</script>";
else echo "<script>ObjDisable('NextHead')</script>";
if ((isset($_SESSION["TP"]))&&($_SESSION["TP"]==5)) echo "<script>ObjDisable('NextHead'); ObjEnable('Save');</script>";
?>
			</td>
          </tr>
        </table>
        </form>
</td>
      <td valign="top">
        <table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
<?php
// �ʴ�����-���ʡ�� �������ҹ����
$sql = "SELECT MemberName, MemberSurname, MemberEmail FROM Member WHERE MemberID = '1'";
$table = mysql_db_query ($dbname, $sql) or die("Can't run SQL command");
$row = mysql_fetch_array ($table)
?>
          <tr>
            <td align="center"><font color="#000000">�Թ�յ�͹�Ѻ</font><br>
                <a href="mailto:<?php echo $row["MemberEmail"];?>"><u><font color="#990000"><?php echo "�س" . $row["MemberName"] . "&nbsp;&nbsp;" . $row["MemberSurname"];?></font></u></a></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
<?php mysql_close();?>
        </table>

      </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"> <span ID=GenFormSend></span></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><font class=font color=#000000>Copyright &copy;2003-2005 ce.kmitl.ac.th. All rights reserved.</font></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</center></body>
</html>