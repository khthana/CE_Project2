<?php
session_start();
?>
<html>
<head>
<title>Pre-Post Conference System</title>
<?php 
include("../config.php");

function GetLongDateThai($date)
{
	$van = array("�ѹ�ҷԵ��"	,"�ѹ�ѹ���","�ѹ�ѧ���","�ѹ�ظ","�ѹ����ʺ��","�ѹ�ء��","�ѹ�����");
	$dean = array("","���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��ɨԡ�¹","�ѹ�Ҥ�");
	$timestamp = strtotime($date);
	return '&nbsp;&nbsp;'.$van[date('w',$timestamp)].'��� '.(date('d',$timestamp)+0).'&nbsp;'.$dean[date('m',$timestamp)+0].'&nbsp;&nbsp;�.�.'.(date('Y',$timestamp)+543);
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../css/prepost.css" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
  <table width="780" border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td height="16">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="16" align="right"><strong><a href="#" onClick="document.all['formAddMem'].style.visibility = 'visible'">Content</a>&nbsp;Site&nbsp;->>>&nbsp;</strong></td>
      <td width="474"><table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC" class="thai">
        <tr>
          <td width="25%" align="center"><strong><a href="index.php"><font color="#0000CC">Home</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="editProfile.php"><font color="#0000CC">Profile</font></a></strong></td>
          <td width="25%" align="center">&nbsp;</td>
          <td width="25%" align="center"><strong><a href="../index.html"><font color="#000000" size="-2">[LogOut]</font></a></strong></td>
        </tr>
      </table></td>
      <td width="126">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">
        <?php $FileIndex = "preview.php";		include($_SESSION['useFile']);	include("calendar.php");?>      </td>
      <td align="center" valign="top"><br>
        <table width="95%"  border="0" cellpadding="1" cellspacing="0" bgcolor="#000000" class="thai">
          <tr>
            <td colspan="2" bgcolor="#000000">
			
<?php
$tid = $_REQUEST["tid"];
/*echo "<script>alert('".$tid."');</script>";*/
$sql = "SELECT * FROM preparemeeting WHERE MeetID='".$_REQUEST["tid"]."'";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
$row = mysql_fetch_array ($table);

echo '<table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="thai">';
echo '<tr><td width="36%">&nbsp;</td><td width="64%">&nbsp;</td></tr>';
echo '<tr><td colspan=3 align=center><img src="../images/logo/logo-kmitl-eng_resize.gif" width="102" height="99"></td></tr>';
echo '<tr><td colspan=3 align=center><br>
            <b>����º���С�û�Ъ����Ш�'.$row["Subject"].'</b><br>
            <strong>���駷��&nbsp;&nbsp;'.$row["Num"].'</strong><br>
			<b>'. GetLongDateThai($row["M"].'/'.$row["D"].'/'.$row["Y"]) .'</b><br>
            <b>'.$row["MeetPlace"].'&nbsp;&nbsp;<br>����&nbsp;'.$row["MeetStart"].'�. - '.$row["MeetEnd"].'�.&nbsp;</b><br>
            <b>..................................</b><br></td></tr>';
echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';
$sendPaper = $row["MeetSentPaper"];

$sql = "SELECT * FROM pathmeeting WHERE MeetID='".$_REQUEST["tid"]."'";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
$tempTopic = '';
$tempSubTopic = '';
while ($row = mysql_fetch_array ($table)){
	if($tempTopic!=$row["hTopic"]) {
		$tempTopic=$row["hTopic"];
		echo '<tr>
			  <td valign="top">&nbsp;</td>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>'.$tempTopic.'</strong></td>
			  <td>&nbsp;</td>
			</tr>';
	}else $tempTopic='';
	if (($tempSubTopic!=$row["Session"])&&($tempTopic!=$row["hTopic"])) {
		echo '<tr>
				  <td valign="top" height="8"></td>
				  <td height="8"></td>
				</tr>';
	}
	if ($tempSubTopic!=$row["Session"]) {
		echo '<tr>
				  <td valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����º���з��&nbsp;'.$row["Session"].'&nbsp;&nbsp;</td>
				  <td>����ͧ&nbsp;&nbsp;<font color="#0000FF">'.$row["Subject1"].'</font></td>
				</tr>';
	}else {
		if ($row["Subject2"]!='-') {
			echo '<tr>
					  <td valign="top" align="right">'.$row["Session"].".".$row["Num"].'&nbsp;&nbsp;</td>
					  <td>����ͧ&nbsp;&nbsp;<font color="#0000FF">'.$row["Subject2"].'</font></td>
					</tr>';
		}
	}
	$tempTopic = $row["hTopic"];
	$tempSubTopic = $row["Session"];
}
// List Member
include("admin.php");
$adm = new Admin();

$namelst=$adm->ListJoin($_REQUEST["tid"]);
if (count($namelst)!=0) {
echo '<script>
		var chk = \'1\';
		GenScript = \'\';
		function GenList(divName) {
			GenScript += \'<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">\'
			GenScript += \'<tr>\'
			GenScript += \'<td valign="top" align="right"><b>��ª��ͼ�������������Ъ��</b></td>\'
			GenScript += \'<td>&nbsp;</td>\'
			GenScript += \'</tr>\'';
for($n=0;$n<count($namelst);$n=$n+3) {
	echo '
			GenScript += \'<tr>\'
			GenScript += \'<td valign="top" align="right">'.$namelst[$n+2].'&nbsp;&nbsp;</td>\'
			GenScript += \'<td>'.$namelst[$n].'&nbsp;&nbsp;'.$namelst[$n+1].'</td>\'
			GenScript += \'</tr>\'
			';
}
echo '	
			GenScript += \'</table>\';
			if (chk==\'1\') {
				document.all[divName].innerHTML = GenScript;
				chk=\'0\';
			}
		}
		</script>';
}
// End List Member

echo '<tr>
		  <td valign="top">&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
		<tr>
		  <td colspan="2" align="center"><b>..................................</b></td>
		</tr>
		<tr>
		  <td valign="top">&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
		<tr>
		  <td colspan="2" align="center" valign="top">��˹����͡��� '.GetLongDateThai($sendPaper).'</td>
		</tr>
		<tr>
		  <td valign="top">&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
		<tr>
		  <td valign="top">&nbsp;</td>
		  <td align="right">
		  	<a href="#" onClick="GenList(\'ListMember\')"><font color="#FF0000"><b>������������Ъ��</b></font></a>&nbsp;&nbsp;&nbsp;
		  	<a href="user_upload.php?tid='.$tid.'"><font color="#FF0000"><b>��ͧ��������͡���</b></font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		</tr>
		<tr>
		  <td valign="top">&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
		<tr>
		  <td colspan=2 valign="top"><span ID=ListMember></span></td>
		</tr>';
echo '<tr>
		  <td valign="top">&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
	</table>';
?>
		    </td>
          </tr>
        </table>
      </td>
      <td valign="top">

<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr>
          <td align="center"><font color="#000000">�Թ�յ�͹�Ѻ</font><br><a href="mailto:<?php echo $_SESSION["Mail"];?>"><u><font color="#990000"><?php echo "�س" . $_SESSION['Name'];?></font></u></a></td>
        </tr>
        <tr>
          <td><br>
<br>
<br>
<br>
<br>
<form name="formAddMem" method="post" action="addMJ.php?addMJ=true" style="visibility:hidden">
   <table width="100%"  border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td colspan="2"><div align="left">���;�����ӹ�˹��:</div>              </td>
      </tr>
    <tr align="center">
      <td colspan="2"><input name="name" type="text" class="formgray" size="15"></td>
      </tr>
    <tr>
      <td width="35%"><div align="left">���ʡ��:</div></td>
      <td width="65%"><input name="sname" type="text" class="formgray" size="13"></td>
    </tr>
    
    <tr>
      <td><div align="left">���˹�:</div></td>
      <td><input name="dean" type="text" class="formgray" size="13"></td>
    </tr>
    <tr align="center">
      <td colspan="2" height="8"></td>
    </tr>
    <tr align="center">
      <td colspan="2">        <input name="Submit" type="submit" class="button" onClick="" value="�ѹ�֡������">      </td>
      </tr>
  </table>
</form></td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td></td>
      <td align="center"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><FONT class=font color=#000000>Copyright &copy;2003-2005 ce.kmitl.ac.th. All rights reserved.</FONT></td>
      <td>&nbsp;</td>
    </tr>
  </table>
<?php mysql_close();?>
</center></body>
</html>