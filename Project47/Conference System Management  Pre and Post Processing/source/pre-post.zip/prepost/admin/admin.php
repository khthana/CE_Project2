<?php
include("../config.php");
include("../member.php");

class Admin
{

	function ListJoin($mid,$retas=0)
	{
		if($retas!=0)
			$sql = "SELECT UserName FROM Member,joinmeet WHERE Member.Granted = 'committee' AND Member.MemberID = joinmeet.UserID AND joinmeet.MeetID = '$mid'";
		else
			$sql = "SELECT Rank,MemberName,MemberSurname,Dean FROM Member,joinmeet WHERE Member.Granted = 'committee' AND Member.MemberID = joinmeet.UserID AND joinmeet.MeetID = '$mid'";

		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$ret=array();
		$i = 0;
		while ($row = mysql_fetch_array ($table))
		{
			if($retas!=0)
				$ret[$i] = $row["UserName"];
			else
			{
				$ret[$i] = $row['Rank'].$row["MemberName"];
				$i++;
				$ret[$i] = $row['MemberSurname'];
				$i++;
				$ret[$i] = $row['Dean'];
			}
			$i++;
		}
		return $ret;
	}
	function GetPratan()
	{
		$sql = "SELECT Rank,MemberName,MemberSurname,Dean FROM Member WHERE Granted = 'chairman' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$row = mysql_fetch_array ($table);
		$ret=array();
		$i = 0;
		$ret[$i++] = $row['Rank'].$row["MemberName"];
		$ret[$i++] = $row['MemberSurname'];
		$ret[$i++] = $row['Dean'];
		return $ret;
	}
	function GetLayka()
	{
		$sql = "SELECT Rank,MemberName,MemberSurname,Dean FROM Member WHERE Member.Granted = 'secretary' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$ret=array();
		$i = 0;
		while ($row = mysql_fetch_array ($table))
		{
			$ret[$i++] = $row['Rank'].$row["MemberName"];
			$ret[$i++] = $row['MemberSurname'];
			$ret[$i++] = $row['Dean'];
		}
		return $ret;
	}
	function ListNotJoin($mid)
	{
		$usr=$this->ListJoin($mid,1);
		if(count($usr)>0)
			{
			$ecp="UserName <> '$usr[0]'";
		for($n=1;$n<count($usr);$n++)
			$ecp .= " AND UserName <> '$usr[$n]'";
		$sql = "SELECT Rank,MemberName,MemberSurname,Dean FROM Member WHERE Member.Granted = 'committee' AND $ecp ";
		}
		else
		$sql = "SELECT Rank,MemberName,MemberSurname,Dean FROM Member WHERE Member.Granted = 'committee'";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$ret=array();
		$i = 0;
		while ($row = mysql_fetch_array ($table))
		{
			$ret[$i++] = $row['Rank'].$row["MemberName"];
			$ret[$i++] = $row['MemberSurname'];
			$ret[$i++] = $row['Dean'];
		}
		return $ret;
	}
	function AddMemberJam($mid,$name,$sname,$dean)
	{
		$sql = "INSERT INTO memberjam VALUES('0','$mid','$name','$sname','$dean')";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
	}
	function ListMJ($mid)
	{
		$sql = "SELECT Name,SName,Dean FROM Memberjam WHERE MeetID = '$mid' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$ret=array();
		$i = 0;
		while ($row = mysql_fetch_array ($table))
		{
			$ret[$i++] = $row['Name'];
			$ret[$i++] = $row['SName'];
			$ret[$i++] = $row['Dean'];
		}
		return $ret;
	}
	function SendMail($url,$mid,$message)
	{
		// subject
		$subject = '���ԭ���������Ъ��';
		// message
		$msg1 = '
		<html>
		<head>
		<title>Untitled Document</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
		</head>
		
		<body>
		<p>'.$message.'</p>
		<p><a href="http://';
			$mbr = new Member();
			$mail = $mbr->ListField('MemberEmail');
			$uid = $mbr->ListField('MemberID');
			for($n=0;$n<count($mail);$n++)
			{
				$msg = $msg1.$url.'/prepost/admin/join.php?MeetID='.$mid.'&UserID='.$uid[$n].'">��Ҿ�������ö���������Ъ����</a> </p>
				</body>
				</html>
				';
				/*
				// To send HTML mail, the Content-type header must be set
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				
				// Additional headers
				$headers .= 'To: Mary <mary@example.com>, Kelly <kelly@example.com>' . "\r\n";
				$headers .= 'From: Birthday Reminder <birthday@example.com>' . "\r\n";
				$headers .= 'Cc: birthdayarchive@example.com' . "\r\n";
				$headers .= 'Bcc: birthdaycheck@example.com' . "\r\n";
				*/
				// Mail it
				//mail($mail[$n], $subject, $msg/*, $headers*/);
		
				echo 'Mail to:'.$mail[$n].'<br>'.'Subject :'.$subject.'<br>'.$msg;
			}
	}
}
?>