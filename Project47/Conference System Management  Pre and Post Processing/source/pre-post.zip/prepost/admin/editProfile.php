<?php
session_start();
?>
<html>
<head>
<title>Pre-Post Conference System</title>
<?php 
include("../config.php");
include("../member.php");
$mbr = new Member();

if (isset($_REQUEST["edit"]))
	$mbr->Edit($_SESSION['user'],$_REQUEST['pwd'],$_REQUEST["email"],$_REQUEST["name"],$_REQUEST["sname"],$_REQUEST["tel1"],$_REQUEST["tel2"],$_REQUEST['rank'],$_REQUEST['dean']);
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../css/prepost.css" type="text/css">

</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"><center>
  <table width="780" border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td height="16">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="16" align="right"><strong>Content&nbsp;Site&nbsp;->>>&nbsp;</strong></td>
      <td width="474"><table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC" class="thai">
        <tr>
          <td width="25%" align="center"><strong><a href="index.php"><font color="#0000CC">Home</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="editProfile.php"><font color="#0000CC">Profile</font></a></strong></td>
          <td width="25%" align="center">&nbsp;</td>
          <td width="25%" align="center"><strong><font color="#000000" size="-2">[<a href="../logout.php">LogOut</a>]</font></strong></td>
        </tr>
      </table></td>
      <td width="126">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">
        <?php $FileIndex = "editProfile.php";		include($_SESSION['useFile']);	include("calendar.php");?>      </td>
      <td align="center" valign="top"><br>
        <form name="form1" method="post" action="editProfile.php?edit=true">
          <p><strong>��䢻���ѵ���ǹ���</strong></p>
          <table width="80%"  border="0" cellspacing="3" cellpadding="0" class="thai">
            <tr>
              <td width="38%"><div align="left"><strong>������͡�Թ:</strong></div></td>
              <td width="62%"><?php echo $_SESSION["user"];?></td>
            </tr>
            <tr>
              <td><div align="left"><strong>���ʼ�ҹ:</strong></div></td>
              <td><input name="pwd" type="password" class="formor" size="10" maxlength="10"></td>
            </tr>
            <tr>
              <td><strong>���ʼ�ҹ:</strong>&nbsp;(�ա����)</td>
              <td><input name="pwd2" type="password" class="formor" size="10" maxlength="10"></td>
            </tr>
            <tr>
              <td><div align="left"><strong>������:</strong></div></td>
              <td><input name="email" type="text" class="formor" value="<?php echo $mbr->GetSome('5',$_SESSION['user']);?>"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td><strong>�ӹ�˹�Ҫ���:</strong></td>
              <td><input name="rank" type="text" class="formor" value="<?php echo $mbr->GetSome('1',$_SESSION['user']);?>" size="10"></td>
            </tr>
            <tr>
              <td><div align="left"><strong>����:</strong></div></td>
              <td><input name="name" type="text" class="formor" size="15" value="<?php echo $mbr->GetSome('2',$_SESSION['user']);?>">
              &nbsp;</td>
            </tr>
            <tr>
              <td><div align="left"><strong>���ʡ��:</strong></div></td>
              <td><input name="sname" type="text" class="formor" size="15" value="<?php echo $mbr->GetSome('3',$_SESSION['user']);?>"></td>
            </tr>
            <tr>
              <td><div align="left"><strong>�������Ѿ����Ͷ��:</strong></div></td>
              <td><input name="tel1" type="text" class="formor" size="9" maxlength="9" value="<?php echo $mbr->GetSome('6',$_SESSION['user']);?>"></td>
            </tr>
            <tr>
              <td><div align="left"><strong>�������Ѿ���ҹ:</strong></div></td>
              <td><input name="tel2" type="text" class="formor" size="9" maxlength="9" value="<?php echo $mbr->GetSome('7',$_SESSION['user']);?>"></td>
            </tr>
            <tr>
              <td><div align="left"><strong>���˹�:</strong></div></td>
              <td><input name="dean" type="text" class="formor" value="<?php echo $mbr->GetSome('4',$_SESSION['user']);?>">
              &nbsp;<font color="#FF0000">*����ç����</font></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input name="Submit" type="submit" onClick="" value="�ѹ�֡������"></td>
            </tr>
          </table>
        </form>
        </td>
      <td valign="top">

<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr>
          <td align="center"><font color="#000000">�Թ�յ�͹�Ѻ</font><br><a href="mailto:<?php echo $_SESSION["Mail"];?>"><u><font color="#990000"><?php echo "�س" . $_SESSION['Name'];?></font></u></a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><FONT class=font color=#000000>Copyright &copy;2003-2005 ce.kmitl.ac.th. All rights reserved.</FONT></td>
      <td>&nbsp;</td>
    </tr>
  </table>

</center></body>
</html>