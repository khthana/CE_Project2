<?php
session_start();
?>
<html>
<head>
<title>Pre-Post Conference System</title>
<?php 
include("../config.php");

if (isset($_REQUEST["add"])) {
	if ($_REQUEST["add"]=='Y') {
		$sql = "SELECT * FROM pathmeeting WHERE MeetID='".$_REQUEST["mID"]."' AND Session='".$_REQUEST["nSession"]."' AND Num='".$_REQUEST["Digest"]."' ORDER BY MeetID,Session,Num,numFile DESC";
		//$sql = $sql + "";
		$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
		$rowPathMeet = mysql_fetch_array ($table);
			/*echo "<script>alert('".$rowPathMeet["numFile"]."');</script>";*/
			$numFile = $rowPathMeet["numFile"]+1;
		$sql = "INSERT INTO pathmeeting VALUES('".$_REQUEST["mID"]."','".$_REQUEST["nSession"]."','".$_REQUEST["Digest"]."','".$rowPathMeet["hTopic"]."','".$rowPathMeet["Subject1"]."','".$rowPathMeet["Subject2"]."','".$rowPathMeet["Message"]."','".$numFile."','".$_REQUEST["nameFile"]."','".$_SESSION["Name"]."')";
		$table = mysql_db_query ($dbname, $sql) or die("Can't INSERT to DB");
		
		$sql = "DELETE FROM tempfile WHERE Num='" . $_REQUEST["idNum"] . "'";
		$table = mysql_db_query ($dbname, $sql) or die("can't Delete");
	}else {
		$sql = "DELETE FROM tempfile WHERE Num='" . $_REQUEST["idNum"] . "'";
		$table = mysql_db_query ($dbname, $sql) or die("can't Delete");
	}
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../css/prepost.css" type="text/css">

</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"><center>
  <table width="780" border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td height="16">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="16" align="right"><strong>Content&nbsp;Site&nbsp;->>>&nbsp;</strong></td>
      <td width="474"><table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC" class="thai">
        <tr>
          <td width="25%" align="center"><strong><a href="index.php"><font color="#0000CC">Home</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="editProfile.php"><font color="#0000CC">Profile</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="#"></a></strong></td>
          <td width="25%" align="center"><strong><font color="#000000" size="-2">[<a href="../logout.php">LogOut</a>]</font></strong></td>
        </tr>
      </table></td>
      <td width="126">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">
        <?php $FileIndex = "index.php";		include($_SESSION['useFile']);	include("calendar.php");?>      </td>
      <td align="center" valign="top"><br>
        <table width="90%"  border="0" cellpadding="0" cellspacing="0" class="thai">
          <tr>
            <td width="60%"><strong>�͡��÷���������</strong></td>
            <td width="36%">&nbsp;</td>
            <td width="4%"><strong>OK</strong></td>
          </tr>
          <tr>
            <td height="8"></td>
            <td height="8"></td>
            <td height="8"></td>
          </tr>
		  
<?php 
$sql = "SELECT * FROM tempfile ORDER BY Num DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
$TbColor = "#FFFFCC";
while ($rowFile = mysql_fetch_array ($table)){
	if ($TbColor == "#FFFFCC") { $TbColor = "#FFCC66"; } else $TbColor = "#FFFFCC";
	echo '<tr bgcolor='.$TbColor.'><td height="5"></td><td height="5"></td><td height="5"></td></tr>
		  <tr bgcolor='.$TbColor.'>
            <td><a href="'.$rowFile["FileUpload"].'" target="_blank">&nbsp;<img src="../images/icon/icon_message.gif" width="12" height="13" border="0">&nbsp;&nbsp;<b>'.substr(strrchr($rowFile["FileUpload"], "/"),1,strlen(strrchr($rowFile["FileUpload"], "/"))).'</b></a></td>
            <td>��&nbsp;&nbsp;<font color="#0000FF">�س'.$rowFile["Member"].'</font></td>
            <td align="center"><a href="checkfile.php?add=Y&idNum='.$rowFile["Num"].'&mID='.$rowFile["MeetID"].'&nSession='.$rowFile["Session"].'&Digest='.$rowFile["Digest"].'&nameFile='.$rowFile["FileUpload"].'"><img src="../images/icon/arrow_down.gif" alt="�����͡��ù��" width="10" height="10" border="0"></a></td>
          </tr>
          <tr bgcolor='.$TbColor.'>
            <td colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��û�Ъ����С�����û�ШӤ�����ǡ�����ʵ��  ���駷�� 5/2549</td>
            <td align="center"><a href="checkfile.php?add=N&idNum='.$rowFile["Num"].'"><img src="../images/icon/delete.gif" alt="ź���" width="11" height="12" border="0"></a></td>
          </tr>
		  <tr bgcolor='.$TbColor.'>
            <td colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#0000FF">����º���з��&nbsp;'.$rowFile["Session"].'&nbsp;&nbsp;��Ǣ�����·��&nbsp;'.$rowFile["Digest"].'</font></td>
            <td align="center"></td>
          </tr>
		  <tr bgcolor='.$TbColor.'><td height="5"></td><td height="5"></td><td height="5"></td></tr>
		  ';
	//<tr><td height="8"></td><td height="8"></td><td height="8"></td></tr>
}
?>
		  
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td align="center">&nbsp;</td>
          </tr>
        </table>
        <br>
      </td>
      <td valign="top">

<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr>
          <td align="center"><font color="#000000">�Թ�յ�͹�Ѻ</font><br><a href="mailto:<?php echo $_SESSION["Mail"];?>"><u><font color="#990000"><?php echo "�س" . $_SESSION['Name'];?></font></u></a></td>
        </tr>
        <tr>
          <td></td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><FONT class=font color=#000000>Copyright &copy;2003-2005 ce.kmitl.ac.th. All rights reserved.</FONT></td>
      <td>&nbsp;</td>
    </tr>
  </table>

</center></body>
</html>