<?php
include("../config.php");

$mid = $_GET['MeetID'];
$uid = $_GET['UserID'];

$sql = "INSERT INTO joinmeet VALUES('$uid','$mid')";
$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
?>
