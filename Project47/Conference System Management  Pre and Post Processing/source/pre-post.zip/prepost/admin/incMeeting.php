<?php
session_start();
include("../config.php");
include("upload.php");
function GetLongDateThai($date)
{
	$van = array("�ѹ�ҷԵ��"	,"�ѹ�ѹ���","�ѹ�ѧ���","�ѹ�ظ","�ѹ����ʺ��","�ѹ�ء��","�ѹ�����");
	$dean = array("���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��ɨԡ�¹","�ѹ�Ҥ�");
	$timestamp = strtotime($date);
	return '  '.$van[date('w',$timestamp)].'��� '.(date('d',$timestamp)+0).' '.$dean[date('m',$timestamp)+0].'  �.�.'.(date('Y',$timestamp)+543);
}
$up = new Upload();

$sql = "INSERT INTO preparemeeting VALUES('','".$_SESSION["tSubject"]."','".$_SESSION["tNum"]."','".$_SESSION["tD"]."','".$_SESSION["tM"]."','".$_SESSION["tY"]."','".$_SESSION["tSendPaper"]."','".$_SESSION["tStart"]."','".$_SESSION["tEnd"]."','".$_SESSION["tPlace"]."')";
//echo $sql."<br>";
//$table = mysql_db_query ($dbname, $sql) or die("Can't INSERT to DB");
$sql = "SELECT MeetID,D FROM preparemeeting ORDER BY MeetID DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't Open DB");
$row = mysql_fetch_array ($table);

for($i=1; $i<= $_SESSION["Total"]; $i++) {
	//$sql = "INSERT INTO pathmeeting VALUES('".$row["MeetID"]."','".$_SESSION["sSession".$i]."','".$_SESSION["sNum".$i]."','".$_SESSION["sTopic".$i]."','".$_SESSION["sSubject1".$i]."','".$_SESSION["sSubject2".$i]."','".$_SESSION["sMessage".$i]."','".$_SESSION["numFile".$i]."','".$_SESSION["File".$i]."','".$_SESSION["Granted"]."')";
	//echo "<br><br><br>".$sql;
	$table = mysql_db_query ($dbname, $sql) or die("Can't INSERT to DB");
}

/*echo "<script>window.open('crePDF.php','createPDF','height=700,width=700,status=0,menubar=1')</script>";*/
include("scPDF.php");
include("admin.php");

$pdf=new PDF();
$pdf->AliasNbPages();
$pdf->AddFristPage($_SESSION["tSubject"],'',$_SESSION["tNum"],GetLongDateThai($_SESSION["tM"].'/'.$_SESSION["tD"].'/'.$_SESSION["tY"]),$_SESSION["tPlace"],GetLongDateThai($_SESSION["tSendPaper"]));
$pdf->AddSecPage($_SESSION["tSubject"],$_SESSION["tNum"],GetLongDateThai($_SESSION["tM"].'/'.$_SESSION["tD"].'/'.$_SESSION["tY"]));
for($i=1; $i<= $_SESSION["Total"]; $i++) {
	//$_SESSION["sMessage".$i] 
	if ($i==1) { $pdf->AddTopicVara($_SESSION["sTopic".$i]); }
	else if ($_SESSION["sTopic".$i]!=$_SESSION["sTopic".($i-1)]) { $pdf->AddTopicVara($_SESSION["sTopic".$i]); }
	if ($i==1) { $pdf->AddVara($_SESSION["sSession".$i],$_SESSION["sSubject1".$i] ); }
	else if ($_SESSION["sSession".$i]!=$_SESSION["sSession".($i-1)]) { $pdf->AddVara($_SESSION["sSession".$i],$_SESSION["sSubject1".$i]); }
}

$adm=new Admin();
$data1=$adm->ListJoin(1);
$data2=$adm->ListNotJoin(1);
$data3=$adm->ListMJ(1);

$date=GetLongDateThai($_SESSION["tM"].'/'.$_SESSION["tD"].'/'.$_SESSION["tY"]);
$pdf->AddJoinPage($_SESSION["tNum"],$date,$adm->GetPratan(),$data1,$data2,$data3,$adm->GetLayKa());

for($i=1; $i<= $_SESSION["Total"]; $i++) {
	$pdf->AddVaraPage($_SESSION["sSession".$i].'.'.$_SESSION["sNum".$i],$_SESSION["sSubject2".$i],$_SESSION["sTopic".$i],$_SESSION["sSubject1".$i]);
	$pdf->AddPara($_SESSION["sMessage".$i]);
	$pdf->PstPac();
	//$pdf->AddJoinPage($_SESSION["File".$i]);
	//$pdf->Output();
	//$pdf->AddVaraPage('1.2','MSg');		?????????? ???????????????????
}
$pdf->Output('temp.pdf','F');
$pdf->Output('upload/'.$row["MeetID"].'.pdf','F');
/*$pdf->Output();*/

echo "<script>win2 = window.open('temp.pdf','createPDF','height=600,width=800,status=0,menubar=1')</script>";
/*echo "<script>window.location.replace('index.php');</script>";*/

echo '<a href="index.php">��Ѻ�˹���á</a><br><br><br><br>';
$adm = new Admin();
$msg = '���ԭ���������Ъ����ѹ���'. GetLongDateThai($_SESSION["tM"].'/'.$_SESSION["tD"].'/'.$_SESSION["tY"]) .'<br>��ҹ����ö����������´��<a href="index.php">�����</a>';
$adm->SendMail('127.0.0.1',$row['MeetID'],$msg);

mysql_close();
?>
