<?php
session_start();
?>
<html>
<head>
<title>Pre-Post Conference System</title>
<?php 
include("../config.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../css/prepost.css" type="text/css">

</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"><center>
  <table width="780" border="0" cellpadding="0" cellspacing="0" class="thai">
    <tr>
      <td height="16">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="16" align="right"><strong>Content&nbsp;Site&nbsp;->>>&nbsp;</strong></td>
      <td width="474"><table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC" class="thai">
        <tr>
          <td width="25%" align="center"><strong><a href="index.php"><font color="#0000CC">Home</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="editProfile.php"><font color="#0000CC">Profile</font></a></strong></td>
          <td width="25%" align="center"><strong><a href="#"></a></strong></td>
          <td width="25%" align="center"><strong><font color="#000000" size="-2">[<a href="../logout.php">LogOut</a>]</font></strong></td>
        </tr>
      </table></td>
      <td width="126">&nbsp;</td>
    </tr>
    <tr>
      <td valign="top">
        <?php $FileIndex = "index.php";		include($_SESSION['useFile']);	include("calendar.php");?>      </td>
      <td align="center" valign="top"><br>
        <table width="95%"  border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr>
          <td><strong>��ػ�š�û�Ъ��</strong></td>
        </tr>
        <tr>
          <td>
		  
<?php
// �ʴ���¡�÷���ա�û�Ъ��㹤��駷���ҹ���
$sql = "SELECT * FROM report ORDER BY meetid DESC";
$table = mysql_db_query ($dbname, $sql) or die("Can't run SQL command");

echo "<table width=100% border=0 cellpadding=0 cellspacing=0 class=thai>";
$TbColor = "#FFFFCC";
while ($row = mysql_fetch_array ($table)){
	if ($TbColor == "#FFFFCC") { $TbColor = "#FFCC66"; } else $TbColor = "#FFFFCC";
	echo "<tr bgcolor=$TbColor><td width=5% align=center><img src=\"../images/icon/icon_message.gif\" width=\"12\" height=\"13\"></td>";
	echo "<td width=75%><a href=preview.php?tid=" . $row["meetid"] . ">��û�Ъ����С�����û�Ш�" . $row["subject"] . "&nbsp;&nbsp;���駷�� " . $row["num"] . "</a></td>";
	echo "<td width=20%>" . $row["D"] . "/" . $row["M"] . "/" . $row["Y"] . "</td></tr>";
}
echo "</table>";
mysql_close();
?></td>
        </tr>
      </table>
      <br>
      </td>
      <td valign="top">

<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr>
          <td align="center"><font color="#000000">�Թ�յ�͹�Ѻ</font><br><a href="mailto:<?php echo $_SESSION["Mail"];?>"><u><font color="#990000"><?php echo "�س" . $_SESSION['Name'];?></font></u></a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><FONT class=font color=#000000>Copyright &copy;2003-2005 ce.kmitl.ac.th. All rights reserved.</FONT></td>
      <td>&nbsp;</td>
    </tr>
  </table>

</center></body>
</html>