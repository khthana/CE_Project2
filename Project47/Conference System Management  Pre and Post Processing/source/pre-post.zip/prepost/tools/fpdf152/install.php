<?
include(".\font\makefont\makefont.php");

`create_pfb.bat`;

MakeFont('AngsanaUPCB.pfb', 'AngsanaUPCB.afm', 'windows874');
MakeFont('AngsanaUPCBI.pfb', 'AngsanaUPCBI.afm', 'windows874');
MakeFont('AngsanaUPCI.pfb', 'AngsanaUPCI.afm', 'windows874');
MakeFont('AngsanaUPC.pfb', 'AngsanaUPC.afm', 'windows874');
MakeFont('BrowalliaUPCB.pfb', 'BrowalliaUPCB.afm', 'windows874');
MakeFont('BrowalliaUPCBI.pfb', 'BrowalliaUPCBI.afm', 'windows874');
MakeFont('BrowalliaUPCI.pfb', 'BrowalliaUPCI.afm', 'windows874');
MakeFont('BrowalliaUPC.pfb', 'BrowalliaUPC.afm', 'windows874');
MakeFont('CordiaUPCB.pfb', 'CordiaUPCB.afm', 'windows874');
MakeFont('CordiaUPCBI.pfb', 'CordiaUPCBI.afm', 'windows874');
MakeFont('CordiaUPCI.pfb', 'CordiaUPCI.afm', 'windows874');
MakeFont('CordiaUPC.pfb', 'CordiaUPC.afm', 'windows874');
MakeFont('DilleniaUPCB.pfb', 'DilleniaUPCB.afm', 'windows874');
MakeFont('DilleniaUPCBI.pfb', 'DilleniaUPCBI.afm', 'windows874');
MakeFont('DilleniaUPCI.pfb', 'DilleniaUPCI.afm', 'windows874');
MakeFont('DilleniaUPC.pfb', 'DilleniaUPC.afm', 'windows874');
MakeFont('EucrosiaUPCB.pfb', 'EucrosiaUPCB.afm', 'windows874');
MakeFont('EucrosiaUPCBI.pfb', 'EucrosiaUPCBI.afm', 'windows874');
MakeFont('EucrosiaUPCI.pfb', 'EucrosiaUPCI.afm', 'windows874');
MakeFont('EucrosiaUPC.pfb', 'EucrosiaUPC.afm', 'windows874');
MakeFont('FreesiaUPCB.pfb', 'FreesiaUPCB.afm', 'windows874');
MakeFont('FreesiaUPCBI.pfb', 'FreesiaUPCBI.afm', 'windows874');
MakeFont('FreesiaUPCI.pfb', 'FreesiaUPCI.afm', 'windows874');
MakeFont('FreesiaUPC.pfb', 'FreesiaUPC.afm', 'windows874');
MakeFont('IrisUPCB.pfb', 'IrisUPCB.afm', 'windows874');
MakeFont('IrisUPCBI.pfb', 'IrisUPCBI.afm', 'windows874');
MakeFont('IrisUPCI.pfb', 'IrisUPCI.afm', 'windows874');
MakeFont('IrisUPC.pfb', 'IrisUPC.afm', 'windows874');
MakeFont('JasmineUPCB.pfb', 'JasmineUPCB.afm', 'windows874');
MakeFont('JasmineUPCBI.pfb', 'JasmineUPCBI.afm', 'windows874');
MakeFont('JasmineUPCI.pfb', 'JasmineUPCI.afm', 'windows874');
MakeFont('JasmineUPC.pfb', 'JasmineUPC.afm', 'windows874');
MakeFont('KodchiangUPCB.pfb', 'KodchiangUPCB.afm', 'windows874');
MakeFont('KodchiangUPCBI.pfb', 'KodchiangUPCBI.afm', 'windows874');
MakeFont('KodchiangUPCI.pfb', 'KodchiangUPCI.afm', 'windows874');
MakeFont('KodchiangUPC.pfb', 'KodchiangUPC.afm', 'windows874');
MakeFont('LilyUPCB.pfb', 'LilyUPCB.afm', 'windows874');
MakeFont('LilyUPCBI.pfb', 'LilyUPCBI.afm', 'windows874');
MakeFont('LilyUPCI.pfb', 'LilyUPCI.afm', 'windows874');
MakeFont('LilyUPC.pfb', 'LilyUPC.afm', 'windows874');

`cleaner.bat`;

?>