<?php
define('FPDF_FONTPATH','../font/');
require('../fpdf.php');

$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('AngsanaUPC','B',16);
$pdf->Cell(40,10,'�ѹ����');
$pdf->Output();
?>
