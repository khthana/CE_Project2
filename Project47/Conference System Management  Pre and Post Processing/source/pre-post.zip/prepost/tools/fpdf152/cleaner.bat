del *upc*.afm *upc*.pfb
move *upc*.* .\font\