<?php session_start();?>
<html>
<head>
<title>Pre-Post Conference System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<?php 
$thday = array("�ѹ�ҷԵ��","�ѹ�ѹ���","�ѹ�ѧ���","�ѹ�ظ","�ѹ����ʺ��","�ѹ�ء��","�ѹ�����");
$thmonth = array("���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��Ȩԡ�¹","�ѹ�Ҥ�");
//echo $thday[date("w")] . " " . date("j") . " " . $thmonth[date("m")-1] . " " . (date("Y")+543); 

if(isset($_SESSION['user']) && !($_SESSION['user']<0))
	header("Location: admin/index.php");
?>
<link rel="stylesheet" href="css/prepost.css" type="text/css">

<script language="JavaScript">
<!--
function MM_opWindow(theURL,winName,attibuteWin) { //v2.0
  window.open(theURL,winName,attibuteWin);
}
//-->
</script>

</head>
<body bgcolor="#FFCC66" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"><br>
<center>
<table width="700" border="0" cellspacing="0" cellpadding="0" class="thai">
  <tr>
    <td width="18" valign="top">&nbsp;</td>
    <td width="682" height="16" valign="top">&nbsp; </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td height="398" valign="top"><table width="662" border="0" cellspacing="0" cellpadding="0" class="thai">
        <tr> 
          <td width="15" height="14"><img src="images/border/left_top.gif"></td>
          <td width="170" background="images/border/top.gif"></td>
          <td width="15" background="images/border/top.gif"></td>
          <td height="14" width="470" background="images/border/top.gif"></td>
          <td width="15" height="14"><img src="images/border/right_top.gif"></td>
        </tr>
        <tr> 
          <td rowspan="3" background="images/border/left.gif">&nbsp;</td>
          <td colspan="3" valign="top" background="images/border/bg.gif"><img src="images/border/title_head.gif" width="632" height="125"></td>
          <td rowspan="2" background="images/border/right.gif">&nbsp;</td>
        </tr>
        <tr> 
          <td colspan="3" valign="top" background="images/border/bg.gif">&nbsp;</td>
        </tr>
        <tr> 
          <td align="center" valign="top" background="images/border/bg.gif"> <form name="formLogin" method="post" action="login.php">
              <table width="160" border="0" cellspacing="0" cellpadding="0" class="thai">
                <tr> 
                  <td height="8" align="center"></td>
                </tr>
                <tr> 
                  <td height="30" align="center" background="images/border/title.gif"><font size="2" face="Tahoma, Arial"><strong>::&nbsp;User&nbsp;Login&nbsp;::</strong></font></td>
                </tr>
                <tr> 
                  <td height="8" align="center"></td>
                </tr>
                <tr> 
                  <td align="center"><font size="1" face="Tahoma, Arial"><strong>UserName</strong></font>&nbsp; 
                    <input name="user" type="text" class="text" size="10"> 
                  </td>
                </tr>
                <tr> 
                  <td align="center"><font size="1" face="Tahoma, Arial"><strong>PassWord</strong></font>&nbsp; 
                    <input name="pass" type="password" class="text" size="10"></td>
                </tr>
                <tr> 
                  <td height="8" align="center"></td>
                </tr>
                <tr> 
                  <td align="center"><img onClick="document.formLogin.submit();" src="images/icon/power.gif" alt="�������к�" width="32" height="32" border="0" class="menu"> 
                  </td>
                </tr>
                <tr> 
                  <td height="8" align="center"></td>
                </tr>
                <tr> 
<?php 
	if(isset($_SESSION['user']) && $_SESSION['user']<0)
		echo "<script> alert('�Դ��ͼԴ��Ҵ㹡���͡�Թ��س��ͧ����');</script>";
//echo $_SESSION['user'];
//echo(isset($_SESSION['user'])?'SET':'UNSET');
?>
                  <td align="center"><font color="#FF6600">�س��ͧ�ӡ��&nbsp;<a href="#">Login</a>&nbsp;<br>
                    �Ѻ�к���͹&nbsp;&nbsp;�֧������ö��ҹ<br>
                    ���ǹ��ҧ����Ѻ</font></td>
                </tr>
                <tr> 
                  <td align="center">&nbsp;</td>
                </tr>
              </table>
            </form></td>
          <td valign="top" background="images/border/inner_left.gif"><img src="images/border/inner_left_top.gif" width="15" height="15"></td>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="thai">
              <tr>
                <td width="37%" background="images/border/inner_top.gif"></td> 
                <td width="63%" height="14" background="images/border/inner_top.gif"></td>
              </tr>
              <tr>
                <td align="center"><img src="images/logo_pb.PNG" width="139" height="139"></td> 
                <td><br>
                  <br>
                  <br>
                  <strong>�����˵�</strong><br> <br>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#8226;&nbsp;�ҡ�բ��ʧ���㹡����ҹ�к� 
                  ��е�ͧ����ͺ���<br>
                  ��سҵԴ��� oasnaw@ce.kmitl.ac.th<br> </td>
              </tr>
            </table></td>
          <td valign="top" background="images/border/inner_right.gif"><img src="images/border/inner_right_top.gif" width="15" height="15"></td>
        </tr>
        <tr> 
          <td height="16"><img src="images/border/left_buttom.gif" width="15" height="15"></td>
          <td height="16" background="images/border/buttom.gif">&nbsp;</td>
          <td height="16" colspan="2" background="images/border/inner_buttom_w.gif"><img src="images/border/inner_buttom.gif" width="15" height="15"></td>
          <td height="16"><img src="images/border/right_buttom.gif" width="15" height="15"></td>
        </tr>
        <tr>
          <td height="16">&nbsp;</td>
          <td height="16">&nbsp;</td>
          <td height="16" colspan="2" align="right"><font size="1" face="Tahoma, Arial"><strong>Copyright 
            &reg; 2004 CE KMIT'L. All rights Reserved. Credits</strong></font></td>
          <td height="16">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
</table>
</center>
</body>
</html>