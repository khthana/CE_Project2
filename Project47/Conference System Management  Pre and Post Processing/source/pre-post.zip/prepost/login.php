<?php 
include("config.php");
include("member.php");
$mbr = new Member();

session_start();
//global $_SESSION;
//$_SESSION['msg'] = '�Դ��ͼԾ�Ҵ㹡���͡�Թ';
//echo(isset($_SESSION['user'])?"SET":"UNSET");
//echo($_REQUEST["user"]);

if(!isset($_SESSION['user']) || $_SESSION['user']==-1)
{
	if($mbr->Login($_POST['user'],$_POST['pass']))
	{
		$_SESSION['user'] =  $mbr->GetSome('8',$_POST['user']);
		$_SESSION['MemberID'] = $mbr->GetSome('0',$_SESSION['user']);
		$_SESSION['Granted'] = $mbr->GetSome('10',$_SESSION['user']);
		$_SESSION['name'] = $mbr->GetName($_SESSION['user']);
		$_SESSION['sname'] = $mbr->GetSurName($_SESSION['user']);
		$_SESSION['Name']= $mbr->GetName($_SESSION['user'])."&nbsp;&nbsp;".$mbr->GetSurName($_SESSION['user']);
		$_SESSION['Mail']= $mbr->GetSome('5',$_SESSION['user']);
		if ($mbr->GetSome('10',$_SESSION['user'])=='secretary')
			$_SESSION['useFile'] = "admin.inc";
		else $_SESSION['useFile'] = "user.inc";
		header("Location: admin/index.php");
	}
	else
	{
		$_SESSION['user']=-1;	//Invalid User & Pass
		header("Location: index.php");
	}
}
else if(isset($_POST['user']))
	if($_POST['user'] != $_SESSION['user'])
		$_SESSION=-2;	//exist login
?>