<?php
$hostname = "localhost";
$username = "eight";
$password = "";
$dbname = "conference";

$connect=mysql_connect($hostname, $username, $password) OR die("Unable to connect to database");
mysql_select_db($dbname,$connect) or die("Can't open DB  ^^ Can't open DB");

?>