<?php
include("config.php");
class Member
{
var $sql;
var $table;
var $row;
	function Login($usr,$pass)
	{
		$sql = "SELECT * FROM member WHERE UserName = '$usr' AND PassWord = '$pass' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$row = mysql_fetch_array($table);
		//echo (count($row));
		if(count($row)!=1)
			return true;
		else
			return false;
	}
	function GetName($usr)
	{
		$sql = "SELECT MemberName FROM Member WHERE UserName = '$usr' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$row = mysql_fetch_array($table);
		return $row["MemberName"];
	}
	function GetSurName($usr)
	{
		$sql = "SELECT MemberSurname FROM Member WHERE UserName = '$usr' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$row = mysql_fetch_array($table);
		return $row["MemberSurname"];
	}
	function GetSome($field,$usr)
	{
		$sql = "SELECT * FROM Member WHERE UserName = '$usr' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$row = mysql_fetch_array($table);
		return $row[$field];
	}
	function Edit($usr,$pwd,$email,$name,$sname,$tel1,$tel2,$rank,$dean)
	{
		if($pwd!="")
			$sql = "UPDATE Member SET PassWord='$pwd',MemberName='$name',MemberSurname='$sname',MemberEmail='$email',MemberMobile='$tel1',MemberTel='$tel2',Rank='$rank',Dean='$dean' WHERE UserName = '$usr' ";
		else
			$sql = "UPDATE Member SET MemberName='$name',MemberSurname='$sname',MemberEmail='$email',MemberMobile='$tel1',MemberTel='$tel2',Rank='$rank',Dean='$dean' WHERE UserName = '$usr' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
	}
	function Regis($usr,$pwd,$email,$name,$sname,$tel1,$tel2,$rank,$dean)
	{
		$sql = "INSERT INTO member VALUES('0','$rank','$name','$sname','$dean','$email','$tel1','$tel2','$usr','$pwd','admin')";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
	}
	function ListJoin($mid,$retas=0)
	{
		if($retas!=0)
			$sql = "SELECT UserName FROM Member,joinmeet WHERE Member.MemberID = joinmeet.UserID AND joinmeet.MeetID = '$mid'";
		else
			$sql = "SELECT MemberName,MemberSurname FROM Member,joinmeet WHERE Member.MemberID = joinmeet.UserID AND joinmeet.MeetID = '$mid'";

		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		$ret=array();
		$i = 0;
		while ($row = mysql_fetch_array ($table))
		{
			if($retas!=0)
				$ret[$i] = $row["UserName"];
			else
				$ret[$i] = $row["MemberName"]."  ".$row['MemberSurname'];
			$i++;
		}
		return $ret;
	}
	function ListField($field)
	{
		$sql = "SELECT $field FROM Member";// WHERE Granted <> 'admin' ";
		$table = mysql_db_query ("conference", $sql) or die("Can't run SQL command");
		
		$ret=array();
		$i = 0;
		while ($row = mysql_fetch_array ($table))
		{
			$ret[$i] = $row[$field];
			$i++;
		}

		return $ret;
	}
	function Close()
	{
		mysql_close();
	}
}//SELECT MemberName,MemberSurname FROM Member WHERE MemberID = (SELECT UserID FROM joinmeet WHERE MeetID = '$mid')
?>