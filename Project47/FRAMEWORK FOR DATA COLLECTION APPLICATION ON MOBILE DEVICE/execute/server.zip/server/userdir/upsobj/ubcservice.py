from sqlobj import ubcservice as sqlobj

class UserPasswordStore(object):
	def __init__(self):
		self.userList = sqlobj.Worker.select()
		
	def getPassword(self, username):
		for user in self.userList:
			if user.username == username:
				return user.password