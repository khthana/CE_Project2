from sqlobj import supply as sqlobj

class UserPasswordStore(object):
	def __init__(self):
		self.userList = sqlobj.Staff.select()
		
	def getPassword(self, username):
		for user in self.userList:
			if user.username == username:
				return user.password