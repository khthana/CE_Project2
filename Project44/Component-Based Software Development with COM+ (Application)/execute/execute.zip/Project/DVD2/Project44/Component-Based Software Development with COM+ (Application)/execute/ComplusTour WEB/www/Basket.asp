<HTML>
<HEAD>
<TITLE> Summary Basket OlalaTour.com </TITLE>
	    <META http-equiv=Content-Type content="text/htm; charset=windows-874">	    
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>

<BODY BGCOLOR="#FFFFFF">
<script language="JavaScript">
<!--
function openPopupPackageDetail(PackageID,DepartDate) {
  popupInformWin = window.open('PopupPackageDetail.asp?PackageID=' + PackageID + '&Departdate=' + DepartDate,'remote','scrollbars,resizable,width=360,height=270');
  //popupInformWin = window.open('PopupPackageDetail.asp?packageID=21&Departdate=20/5/2545','remote','scrollbars,resizable,width=360,height=270');  
}
function openPopupBasketTraveller(BasketID,PackageBasketItemID) {
	popupInformWin = window.open('PopupBasketTraveller.asp?BasketID=' + BasketID + '&PackageBasketItemID=' + PackageBasketItemID,'remote','scrollbars,resizable,width=360,height=270');
	//popupInformWin = window.open('index.asp','remote',
}
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}
-->
</script>


<!--form name="confirm_reserve" action="thankyou.htm" method="post"-->
      <%
'	on error resume next
		Response.Cookies("NumT") = Request.Form("seats")
	for i =1 to Request.Form("seats")
		Response.Cookies("T" & i) = Request.Form("T" & i)
		Response.Cookies("L" & i) = Request.Form("L" & i)
	next

	cmd	= Request("cmd")	
	set  objBasket = Server.CreateObject("TourBookingService.IBasket")

	BasketID = Request.Cookies("BasketID") 

	if  BasketID = "" and (cmd = "addPackage" or cmd="addHotel" or cmd="addBus" or cmd="addAirline" or cmd="addHotelAir" or cmd="addHotelBus") then
'Response.Write "before->" & basketID
		basketID = objBasket.CreateBasket
'Response.Write "  after->" & basketID
		Response.Cookies("BasketID") = BasketID
		Response.Cookies("BasketID").Expires = date+1
		'response.write "No cookies ,now add.. Cookies No " & BasketID   			
	end if
'Response.Write "bas=>"  & basketID	
'	Response.Write "BasketID=" & basketid
	set util = server.CreateObject("ComplusUtil.IUtility")
'add package

	if cmd = "addPackage" then
		AmountOfTraveller = Request("AmountOfTraveller")
		DepartDate = cdate(Request("DepartDate"))
		PackageID  = Request("PackageID")
		set objReservePackageDetailFac = Server.CreateObject("DALDB.CReservePackageDetailFactory")
		set objReservePackageDetail	   = Server.CreateObject("DALDB.CReservePackageDetail")
	    Set objReservePackageDetail = objReservePackageDetailFac.AddNew
	    objReservePackageDetail.PackageID = PackageID
	    objReservePackageDetail.DepartDate = DepartDate 
	'    add Traveller 
	    Response.Cookies("NumT") = AmountOfTraveller
	    for i =1 to AmountOfTraveller
			Set objTraveller = objReservePackageDetail.AddTraveller
			Response.Cookies("T" & i) = Request.Form("T" & i)
			Response.Cookies("L" & i) = Request.Form("L" & i)
			Response.Cookies("B" & i) = Request.Form("B" & i)
			TravName =  Request("T" & i ) & " " & Request("L" & i )
			objTraveller.TravellerName = TravName
			objTraveller.BirthDate = cdate(Request("B" & i ))
			
			'Response.Write "objTraveller.BirthDate=" & objTraveller.BirthDate
			'Response.Write "Request=" & Request("B" & i )
		next 
		set util = server.CreateObject("ComplusUtil.IUtility")

		objbasket.AddPackageBasketItem cint(BasketID),util.ConvertToOBj(objReservePackageDetail)
	end if ' cmd add package

'add hotel
	if cmd = "addHotel" then
		HotelID =  Request("HotelID")
		RoomModelID = cint(Request("RoomModelID"))
		BookCheckIn = cdate(request("BookCheckIn"))
		BookCheckOut =  cdate(Request("BookCheckOut"))
		AmountOfRoom =  cint(Request("AmountOfRoom"))
		BookingPrice =  cint(Request("BookingPrice"))
		set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
		set objReserveHotel = objReserveHotels.AddNew
		with objReserveHotel
				.HotelID = HotelID
				.RoomModelID = RoomModelID
				.BookCheckIn = BookCheckIn
				.BookCheckOut = BookCheckOut
				.AmountOfRoom = AmountOfRoom
				.BookingPrice = BookingPrice
		end with
		objbasket.AddHotelBasketItem cint(BasketID),util.ConvertToOBj(objReserveHotel)
	end if 'add hotel

'add Bus
	if cmd = "addBus" then
	'Response.Write "NOW Add bus"
	RouteID =	Request("RouteID")
	seats	=	Request("seats")
	srcidx	=	Request("srcidx")
	desidx	=	Request("desidx")
	unitprice = Request("unitprice")
	toilet		= Request("Toilet")
	smoking	=	Request("smoking")
	window	=	Request("window")
	departdate =Request("departdate")
	departureStationID = Request("departureStationID")
	destinationStationid = Request("destinationStationID")
	departuretime	= Request("departuretime")
	arrivetime		= Request("arrivetime")

	'Response.Write "filght=" & filghtid
	
				set objViewBusBookInfoFac = Server.CreateObject("DALDB.CViewBusBookInfoFactory")
				set objViewBusBookInfo    = Server.CreateObject("DALDB.CViewBusBookInfo")
			    Set objViewBusBookInfo = objViewBusBookInfoFac.AddNew
			    objViewBusBookInfo.StationdesName = cstr(destinationStationid)
			    objViewBusBookInfo.StationsrcName = cstr(departureStationID)
			    objViewBusBookInfo.ArriveDateTime = cdate(departdate & " " & arrivetime)
			    'objViewBusBookInfo.ClassID = cint(classid)
			    objViewBusBookInfo.DepartDate	= cdate(departdate)
			    objViewBusBookInfo.DepartDateTime = cdate(departdate & " " & departuretime)
			    objViewBusBookInfo.desIdx = cint(desidx)
			    objViewBusBookInfo.routeID = cstr(Routeid)
			    objViewBusBookInfo.Price = ccur(unitprice)
			    objViewBusBookInfo.toilet = cbool(Toilet)
			    objViewBusBookInfo.Smoking = cbool(smoking)
			    objViewBusBookInfo.Window = cbool(window)
			    objViewBusBookInfo.srcIdx = cint(srcidx)
			    objViewBusBookInfo.TotalSeat = cint(seats)
			'    add Traveller 
'		Response.Write objViewAirlineBookInfo.DepartDateTime
'		Response.Write "<br>"
'		Response.Write  objViewAirlineBookInfo.ArriveDateTime
			    for i =1 to seats
					Set objEJBTraveller = objViewBusBookInfo.AddTraveller
					objEJBTraveller.firstname = (Request("T" & i ))
					objEJBTraveller.lastname =  cstr(Request("L" & i ))
				next 

				set util = server.CreateObject("ComplusUtil.IUtility")
				objbasket.AddBusBasketItem  cint(BasketID), util.ConvertToOBj(objViewBusBookInfo)
	end if 'add Bus

'add Airline
	if cmd = "addAirline" then
	flightid=	Request("FlightID")
	classid	=	Request("ClassID")
	seats	=	Request("seats")
	srcidx	=	Request("srcidx")
	desidx	=	Request("desidx")
	unitprice = Request("unitprice")
	smoking	=	Request("smoking")
	window	=	Request("window")
	departdate =Request("departdate")
	departureairportID = Request("departureAirportID")
	destinationairportid = Request("destinationAirportID")
	departuretime	= Request("departuretime")
	arrivetime		= Request("arrivetime")

	'Response.Write "filght=" & filghtid
	
				set objViewAirlineBookInfoFac = Server.CreateObject("DALDB.CViewAirlineBookInfoFactory")
				set objViewAirlineBookInfo    = Server.CreateObject("DALDB.CViewAirlineBookInfo")
			    Set objViewAirlineBookInfo = objViewAirlineBookInfoFac.AddNew
			    objViewAirlineBookInfo.AirportdesName = cstr(destinationairportid)
			    objViewAirlineBookInfo.AirportsrcName = cstr(departureairportID)
			    objViewAirlineBookInfo.ArriveDateTime = cdate(departdate & " " & arrivetime)
			    objViewAirlineBookInfo.ClassID = cstr(classid)
			    objViewAirlineBookInfo.DepartDate	= cdate(departdate)
			    objViewAirlineBookInfo.DepartDateTime = cdate(departdate & " " & departuretime)
			    objViewAirlineBookInfo.desIdx = cint(desidx)
			    objViewAirlineBookInfo.FlightID = cstr(flightid)
			    objViewAirlineBookInfo.Price = ccur(unitprice)
			    objViewAirlineBookInfo.Smoking = cbool(smoking)
			    objViewAirlineBookInfo.Window = cbool(window)
			    objViewAirlineBookInfo.srcIdx = cint(srcidx)
			    objViewAirlineBookInfo.TotalSeat = cint(seats)
			'    add Traveller 
'		Response.Write objViewAirlineBookInfo.DepartDateTime
'		Response.Write "<br>"
'		Response.Write  objViewAirlineBookInfo.ArriveDateTime
			    for i =1 to seats
					Set objEJBTraveller = objViewAirlineBookInfo.AddTraveller
					objEJBTraveller.firstname = (Request("T" & i ))
					objEJBTraveller.lastname =  cstr(Request("L" & i ))
				next 

				set util = server.CreateObject("ComplusUtil.IUtility")
				objbasket.AddAirlineBasketItem  cint(BasketID), util.ConvertToOBj(objViewAirlineBookInfo)

	end if 'add Airline
	
'add Hotel and Airline
	if cmd = "addHotelAir" then
	flightid=	Request("FlightID")
	classid	=	Request("ClassID")
	seats	=	Request("seats")
	srcidx	=	Request("srcidx")
	desidx	=	Request("desidx")
	unitprice = Request("unitprice")
	smoking	=	Request("smoking")
	window	=	Request("window")
	departdate =Request("departdate")
	departureairportID = Request("departureAirportID")
	destinationairportid = Request("destinationAirportID")
	departuretime	= Request("departuretime")
	arrivetime		= Request("arrivetime")
				set objViewAirlineBookInfoFac = Server.CreateObject("DALDB.CViewAirlineBookInfoFactory")
				set objViewAirlineBookInfo    = Server.CreateObject("DALDB.CViewAirlineBookInfo")
			    Set objViewAirlineBookInfo = objViewAirlineBookInfoFac.AddNew
			    objViewAirlineBookInfo.AirportdesName = cstr(destinationairportid)
			    objViewAirlineBookInfo.AirportsrcName = cstr(departureairportID)
			    objViewAirlineBookInfo.ArriveDateTime = cdate(departdate & " " & arrivetime)
			    objViewAirlineBookInfo.ClassID = cstr(classid)
			    objViewAirlineBookInfo.DepartDate	= cdate(departdate)
			    objViewAirlineBookInfo.DepartDateTime = cdate(departdate & " " & departuretime)
			    objViewAirlineBookInfo.desIdx = cint(desidx)
			    objViewAirlineBookInfo.FlightID = cstr(flightid)
			    objViewAirlineBookInfo.Price = ccur(unitprice)
			    objViewAirlineBookInfo.Smoking = cbool(smoking)
			    objViewAirlineBookInfo.Window = cbool(window)
			    objViewAirlineBookInfo.srcIdx = cint(srcidx)
			    objViewAirlineBookInfo.TotalSeat = cint(seats)
			    for i =1 to seats
					Set objEJBTraveller = objViewAirlineBookInfo.AddTraveller
					objEJBTraveller.firstname = (Request("T" & i ))
					objEJBTraveller.lastname =  cstr(Request("L" & i ))
				next 

				set util = server.CreateObject("ComplusUtil.IUtility")
				objbasket.AddAirlineBasketItem  cint(BasketID), util.ConvertToOBj(objViewAirlineBookInfo)
' add roundtrip
	flightid2=	Request("FlightID2")
	classid2	=	Request("ClassID2")
	srcidx2	=	Request("srcidx2")
	desidx2	=	Request("desidx2")
	unitprice2 = Request("unitprice2")
	smoking2	=	Request("smoking2")
	window2	=	Request("window2")
	departdate2 =Request("departdate2")
	departureairportID2 = Request("departureAirportID2")
	destinationairportid2 = Request("destinationAirportID2")
	departuretime2	= Request("departuretime2")
	arrivetime2		= Request("arrivetime2")
				set objViewAirlineBookInfoFac = Server.CreateObject("DALDB.CViewAirlineBookInfoFactory")
				set objViewAirlineBookInfo    = Server.CreateObject("DALDB.CViewAirlineBookInfo")
			    Set objViewAirlineBookInfo = objViewAirlineBookInfoFac.AddNew
			    objViewAirlineBookInfo.AirportdesName = cstr(destinationairportid2)
			    objViewAirlineBookInfo.AirportsrcName = cstr(departureairportID2)
			    objViewAirlineBookInfo.ArriveDateTime = cdate(departdate2 & " " & arrivetime2)
			    objViewAirlineBookInfo.ClassID = cstr(classid2)
			    objViewAirlineBookInfo.DepartDate	= cdate(departdate2)
			    objViewAirlineBookInfo.DepartDateTime = cdate(departdate2 & " " & departuretime2)
			    objViewAirlineBookInfo.desIdx = cint(desidx2)
			    objViewAirlineBookInfo.FlightID = cstr(flightid2)
			    objViewAirlineBookInfo.Price = ccur(unitprice2)
			    objViewAirlineBookInfo.Smoking = cbool(smoking2)
			    objViewAirlineBookInfo.Window = cbool(window2)
			    objViewAirlineBookInfo.srcIdx = cint(srcidx2)
			    objViewAirlineBookInfo.TotalSeat = cint(seats)
			    for i =1 to seats
					Set objEJBTraveller = objViewAirlineBookInfo.AddTraveller
					objEJBTraveller.firstname = (Request("T" & i ))
					objEJBTraveller.lastname =  cstr(Request("L" & i ))
				next 

				set util = server.CreateObject("ComplusUtil.IUtility")
				objbasket.AddAirlineBasketItem  cint(BasketID), util.ConvertToOBj(objViewAirlineBookInfo)
'add hotel for trip
		HotelID =  Request("HotelID")
		RoomModelID = cint(Request("RoomModelID"))
		BookCheckIn = cdate(request("BookCheckIn"))
		BookCheckOut =  cdate(Request("BookCheckOut"))
		AmountOfRoom =  cint(Request("AmountOfRoom"))
		BookingPrice =  cint(Request("BookingPrice"))
		set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
		set objReserveHotel = objReserveHotels.AddNew
		with objReserveHotel
				.HotelID = HotelID
				.RoomModelID = RoomModelID
				.BookCheckIn = BookCheckIn
				.BookCheckOut = BookCheckOut
				.AmountOfRoom = AmountOfRoom
				.BookingPrice = BookingPrice
		end with
		objbasket.AddHotelBasketItem cint(BasketID),util.ConvertToOBj(objReserveHotel)


	end if 'add Airline and Hotel

'add Hotel and bus
	if cmd = "addHotelBus" then
	RouteID =	Request("RouteID")
	seats	=	Request("seats")
	srcidx	=	Request("srcidx")
	desidx	=	Request("desidx")
	unitprice = Request("unitprice")
	toilet		= Request("Toilet")
	smoking	=	Request("smoking")
	window	=	Request("window")
	departdate =Request("departdate")
	departureStationID = Request("departureStationID")
	destinationStationid = Request("destinationStationID")
	departuretime	= Request("departuretime")
	arrivetime		= Request("arrivetime")
				set objViewBusBookInfoFac = Server.CreateObject("DALDB.CViewBusBookInfoFactory")
				set objViewBusBookInfo    = Server.CreateObject("DALDB.CViewBusBookInfo")
			    Set objViewBusBookInfo = objViewBusBookInfoFac.AddNew
			    objViewBusBookInfo.StationdesName = cstr(destinationStationid)
			    objViewBusBookInfo.StationsrcName = cstr(departureStationID)
			    objViewBusBookInfo.ArriveDateTime = cdate(departdate & " " & arrivetime)
			    objViewBusBookInfo.DepartDate	= cdate(departdate)
			    objViewBusBookInfo.DepartDateTime = cdate(departdate & " " & departuretime)
			    objViewBusBookInfo.desIdx = cint(desidx)
			    objViewBusBookInfo.routeID = cstr(Routeid)
			    objViewBusBookInfo.Price = ccur(unitprice)
			    objViewBusBookInfo.toilet = cbool(Toilet)
			    objViewBusBookInfo.Smoking = cbool(smoking)
			    objViewBusBookInfo.Window = cbool(window)
			    objViewBusBookInfo.srcIdx = cint(srcidx)
			    objViewBusBookInfo.TotalSeat = cint(seats)
			    for i =1 to seats
					Set objEJBTraveller = objViewBusBookInfo.AddTraveller
					objEJBTraveller.firstname = (Request("T" & i ))
					objEJBTraveller.lastname =  cstr(Request("L" & i ))
				next 

				set util = server.CreateObject("ComplusUtil.IUtility")
				objbasket.AddBusBasketItem  cint(BasketID), util.ConvertToOBj(objViewBusBookInfo)

' add roundtrip
	RouteID2 =	Request("RouteID2")
	seats	=	Request("seats")
	srcidx2	=	Request("srcidx2")
	desidx2	=	Request("desidx2")
	unitprice2 = Request("unitprice2")
	toilet2		= Request("Toilet2")
	smoking2	=	Request("smoking2")
	window2	=	Request("window2")
	departdate2 =Request("departdate2")
	departureStationID2 = Request("departureStationID2")
	destinationStationid2 = Request("destinationStationID2")
	departuretime2	= Request("departuretime2")
	arrivetime2		= Request("arrivetime2")
				set objViewBusBookInfoFac = Server.CreateObject("DALDB.CViewBusBookInfoFactory")
				set objViewBusBookInfo    = Server.CreateObject("DALDB.CViewBusBookInfo")
			    Set objViewBusBookInfo = objViewBusBookInfoFac.AddNew
			    objViewBusBookInfo.StationdesName = cstr(destinationStationid2)
			    objViewBusBookInfo.StationsrcName = cstr(departureStationID2)
			    objViewBusBookInfo.ArriveDateTime = cdate(departdate2 & " " & arrivetime2)
			    objViewBusBookInfo.DepartDate	= cdate(departdate2)
			    objViewBusBookInfo.DepartDateTime = cdate(departdate2 & " " & departuretime2)
			    objViewBusBookInfo.desIdx = cint(desidx2)
			    objViewBusBookInfo.routeID = cstr(Routeid2)
			    objViewBusBookInfo.Price = ccur(unitprice2)
			    objViewBusBookInfo.toilet = cbool(Toilet2)
			    objViewBusBookInfo.Smoking = cbool(smoking2)
			    objViewBusBookInfo.Window = cbool(window2)
			    objViewBusBookInfo.srcIdx = cint(srcidx2)
			    objViewBusBookInfo.TotalSeat = cint(seats)
			    for i =1 to seats
					Set objEJBTraveller = objViewBusBookInfo.AddTraveller
					objEJBTraveller.firstname = (Request("T" & i ))
					objEJBTraveller.lastname =  cstr(Request("L" & i ))
				next 

				set util = server.CreateObject("ComplusUtil.IUtility")
				objbasket.AddBusBasketItem  cint(BasketID), util.ConvertToOBj(objViewBusBookInfo)

'add hotel for trip
		HotelID =  Request("HotelID")
		RoomModelID = cint(Request("RoomModelID"))
		BookCheckIn = cdate(request("BookCheckIn"))
		BookCheckOut =  cdate(Request("BookCheckOut"))
		AmountOfRoom =  cint(Request("AmountOfRoom"))
		BookingPrice =  cint(Request("BookingPrice"))
		set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
		set objReserveHotel = objReserveHotels.AddNew
		with objReserveHotel
				.HotelID = HotelID
				.RoomModelID = RoomModelID
				.BookCheckIn = BookCheckIn
				.BookCheckOut = BookCheckOut
				.AmountOfRoom = AmountOfRoom
				.BookingPrice = BookingPrice
		end with
		objbasket.AddHotelBasketItem cint(BasketID),util.ConvertToOBj(objReserveHotel)


	end if 'add Bus and Hotel


%>

<%
	if BasketID = "" then
		Response.Write "<br><div align=center><font color=#FF0000 	><b> �������¡��㹵С��Ңͧ�س</b></font></div><br><br>"
		Response.Write  "<p class='head5'><a href='index.asp' target='_parent'><pre>                     back</pre></a></p>"
	else
	'Response.Write "BASketID=" & BasketId
	set objReserveHotels	= Server.CreateObject("DALDB.CReserveHotelDetailFactory")
	set objReservePackages	= Server.CreateObject("DALDB.CReservePackageDetailFactory")
	set objBusBookInfos		= Server.CreateObject("DALDB.CViewBusBookInfoFactory")
	set objAirlineBookInfos	= Server.CreateObject("DALDB.CViewAirlineBookInfoFactory")
	set colBasket = objbasket.ViewBasket(Cint(BasketID))', util.ConvertToOBj(objReserveHotels) , util.ConvertToOBj(objReservePackages) , 1 ,  1

if colbasket.item(1) is nothing and colbasket.item(2) is nothing and colbasket.item(3) is nothing and colbasket.item(4) is nothing  then
	Response.Write "<br><div class='head_2' align=center> �������¡��㹵С��Ңͧ�س</div><br><br>"
else


%>
<form name="Confirm_Del_TourBooking" action="ConfirmDelTourBasket.asp" method="post">
<!--
<TABLE width="90%" border="1" align=center>
TBODY
	<TR>
		  <TH colspan=2 align=middle bgColor=#8080b0 class="head2" height="23"><b>�С��Ңͧ�س</b></TH>
	</TR>
	<tr><td colspan=2>&nbsp; </td></tr>-->
<TABLE width="95%" Border="0" align=center>
<TBODY>
	<TR>
		<TD>
			 
		</TD>
	</TR>
	<tr> 
            <td colspan=7> 
              <div align="center"><font color="#FF0000"><b>��¡��㹵�С���</b></font></div>
            </td>
     </tr>
<%
' render basket

'========================================================
'	render hotel basket
	if not colbasket.item(1) is nothing then
		' render Hotelbasket
	set objReserveHotels = colbasket.item(1)
	
	cnt = objReserveHotels.internalCRecocdset.RowCount
'	Response.Write "Hotelcnt=" & cnt
	if basketID <> "" and cnt > 0  then
%>
      
	<TR>
	    <TD>
        <table width="100%" border="0" cellspacing="1" cellpadding="0" align="center">
          <!--<tr>
		  	<td colspan=7><div align="center"><b><font size="+1" color="#FF9933">��¡�èͧ�ç���</font></b></div>
       		</td>
          </tr>-->
          
          <tr bgcolor="#DFDFDF" > 
            <td colspan=7 > <font color="#006699" size="-1">��¡�èͧ�ç���</font> 
            </td>
          </tr>
          <!--<tr>  
		  	<td width="5%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">ź</font></b></font></div>
            </td>
            <td width="8%" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��¡�� 
                </font></b></font></div>
            </td>
            <td width="23%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ѹ�ѡ</font></b></font></div>
            </td>
            <td width="26%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ç���</font></b></font></div>
            </td>
            <td width="17%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="8%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ӹǹ 
                ��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="13%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�Ҥ���� 
                (�ҷ)</font></b></font></div>
            </td>
          </tr>-->
          <!--<tr>
		      <td colspan=2> 
				<table width="100%" Border="0" cellspacing="1" cellpadding="0" align="center">-->
          <tr align=center bgcolor="#006699" height="20"> 
            <th width="5%"  ><font color="#FFFFFF" size="-1"> ź </font></th>
            <th width="8%"   ><font color="#FFFFFF" size="-1"> ��¡�� </font></th>
            <th width="24%" ><font color="#FFFFFF" size="-1"> �ѹ�ѡ </font></th>
            <th width="20%" ><font color="#FFFFFF" size="-1"> �ç���</font></th>
            <th width="18%" ><font color="#FFFFFF" size="-1"> ��ͧ�ѡ </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-1"> �ӹǹ </font></th>
            <th width="15%" ><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ) </font></th>
          </tr>
          <%
		dim i
		dim HotelTotalPrice
		HotelTotalPrice = 0
    	For i = 1 To objReserveHotels.internalCRecocdset.RowCount
		HotelToTalPrice = HotelTotalprice + objReserveHotels.Item(i).BookingPrice
		set HotelService = Server.CreateObject("TourService.IHotelViewer")
		set OBjHotels = Server.CreateObject("DALDB.CHotelFactory")
			'Response.Write "HotelID=" & objReserveHotels.Item(i).HotelID
			'Response.Write "type=" & VarType(HotelService)
'			call HotelService.GetHotel(clng(1))
		set OBjHotels =	HotelService.GetHotel(clng(objReserveHotels.Item(i).HotelID))
		set ObjRoomModels =Server.CreateObject("DALDB.CRoomModelFactory")
		set objRoomModels = Hotelservice.GetRoomModel(objReserveHotels.Item(i).RoomModelID)
		HotelName= objHotels.Item(1).HotelName
		RoomModelName=objRoomModels.Item(1).RoomModelName
 %>
          <tr  align=center  class="text1"  <%  if i mod 2 = 0 then Response.Write "bgcolor=#DFDFDF" %>> 
            <td width="5%"> <font size="-2"> 
              <input type="checkbox" name="HoteldelItem" value="<%=  objReserveHotels.Item(i).BasketItemID %>">
              </font></td>
            <td width="8%"> <font size="-2"><%= i %> </font></td>
            <td width="24%"><font size="-2"><%=  objReserveHotels.Item(i).BookCheckIn %> 
              - <%= objReserveHotels.Item(i).BookCheckOut %></font></td>
            <td width="20%"><a href="javascript:openViewHotelWindow('<%=objReserveHotels.Item(i).HotelID%>')"><font size="-2"><%=HOTELNAME%></font></a></td>
            <td width="18%"><a href="javascript:openViewRoomModelWindow('<%=objReserveHotels.Item(i).RoomModelID%>')"><font size="-2"><%=ROOMMODELNAME%></font></a></td>
            <td width="10%"> <font size="-2"><%=  objReserveHotels.Item(i).AmountOfRoom %> 
              </font></td>
            <td width="15%"> <font size="-2"><%=  objReserveHotels.Item(i).BookingPrice %> 
              </font></td>
          </tr>
          <%    Next	   %>
          <tr  height="25" valign=bottom> 
            <td colspan="6" align=right ><b><font size="-1" color="#006699">�Ҥ����������</font></b> 
            </td>
            <th width="15%"> <font size="-1" color="#FF0000"><%=HotelTotalPrice%></font> 
            </th>
          </tr>
          <!--
          <tr> 
            <td colspan="6"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><b><font color="#0D549B"><%=HotelTotalPrice%></font></b></font></div>
            </td>
          </tr>-->
        </table>
	</td></tr>
      <% else ' if basket ��ҧ      %>
	  	<tr><td class="head9" align=center>			<br>
        <b><font color="#FF0000" size="-1">�������¡�èͧ�ç���㹵С��Ңͧ�س</font></b> 
      </td>
    </tr>
      <% end if %>
      
  <!--
  <tr>
    <td bgcolor="#D7DCE8">&nbsp;</td>
     </tr>-->
<!--/table-->		
<%		
	end if
'========================================================
'	render Airline basket
'	Response.Write "airtyype=" & VarType(colbasket.item(4))
'		Response.Write "�ըӹǹ��¡��==" & colbasket.item(4).count
	if not colbasket.item(4) is nothing then

		set objAirlineBookInfos = colbasket.item(4)
'	Response.Write "airtyype=" & VarType(objReserveAirlines)	
	cnt = objAirlineBookInfos.Count
'	Response.Write "�ըӹǹ��¡��==" & cnt
	if basketID <> "" and cnt > 0  then
%>

	<tr>
		<td>
			
        <table width="100%" Border="0" cellspacing="1">
          <tr> 
            <td colspan=9>&nbsp;</td>
          </tr>
          <tr bgcolor="#DFDFDF" > 
            <td colspan=9 class="head11"> <font color="#006699" size="-1">��¡�èͧ��������ͧ�Թ</font> 
            </td>
          </tr>
          <tr align=center bgcolor="#006699"  height="20"> 
            <th width="5%" ><font color="#FFFFFF" size="-1"> ź </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-1"> ����ǺԹ </font></th>
            <th width="12%" ><font color="#FFFFFF" size="-1"> �鹷ҧ </font></th>
            <th width="12%" ><font color="#FFFFFF" size="-1"> ���·ҧ </font></th>
            <th width="14%" ><font color="#FFFFFF" size="-1"> �ѹ�Թ�ҧ </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-1"> �����͡ </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-1"> ���Ҷ֧ </font></th>
            <th width="13%" ><font color="#FFFFFF" size="-1"> �ӹǹ(��) </font></th>
            <th width="14%" ><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ) </font></th>
          </tr>
          <!--
<tr><td>
	<table width="100%" border="0" align=center>
   <tr>
 	<td colspan=9><div align="center"><b><font size="+1" color="#ff9933">��¡�èͧ��������ͧ�Թ</font></b></div>
	</td>
   </tr>

  <tr bgcolor="#003366"> 
    <td width="3%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>ź</b></font></div>
    </td>
    <td width="10%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>����ǺԹ</b></font></div>
    </td>
    <td width="8%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�鹷ҧ</b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>���·ҧ</b></font></div>
    </td>
    <td width="10%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�ѹ�Թ�ҧ</b></font></div>
    </td>
    <td width="6%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�����͡</b></font></div>
    </td>
    <td width="25%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>���Ҷ֧</b></font></div>
    </td>
    <td> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�ӹǹ<br>
        ����Թ�ҧ</b></font></div>
    </td>
    <td> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�Ҥ����<br>
        (�ҷ)</b></font></div>
    </td>
  </tr> -->
          <%
		dim AirlineTotalPrice
		AirlineTotalPrice = 0
    	For i = 1 To cnt'objReserveAirlines.Count
		
		AirlineTotalPrice = AirlineTotalPrice + (objAirlineBookInfos.Item(i).Price * objAirlineBookInfos.Item(i).TotalSeat )
		
%>
          <tr  align=center  class="text1" <%  if i mod 2 = 0 then Response.Write "bgcolor=#DFDFDF" %> > 
            <td width="5%" > 
              <input type="checkbox" name="AirlineDelItem" value="<%=objAirlineBookInfos.Item(i).AirlineBasketItemID%>">
            </td>
            <td width="10%" ><%=objAirlineBookInfos.Item(i).FlightID%></td>
            <td width="12%" ><%=objAirlineBookInfos.Item(i).AirportsrcName%></td>
            <td width="12%" ><%=objAirlineBookInfos.Item(i).AirportdesName%></td>
            <td width="14%" ><%=objAirlineBookInfos.Item(i).DepartDate%></td>
            <td width="10%" ><%=TimeValue(objAirlineBookInfos.Item(i).DepartDateTime)%></td>
            <td width="10%" ><%=TimeValue(objAirlineBookInfos.Item(i).ArriveDateTime)%></td>
            <td width="13%" ><%=objAirlineBookInfos.Item(i).TotalSeat%></td>
            <td width="14%" ><%=objAirlineBookInfos.Item(i).Price * objAirlineBookInfos.Item(i).TotalSeat %></td>
          </tr>
          <% next  %>
          <!-- <tr> 
            <td colspan="8"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><b><font color="#0D549B"><%=AirlineTotalPrice%></font></b></font></div>
            </td>
          </tr>
-->
          <tr  height="25" valign=bottom> 
            <td colspan="8" align=right ><b><font size="-1" color="#006699">�Ҥ����������</font></b> 
            </td>
            <th width="14%"> <font size="-1" color="#FF0000"><%=AirlineTotalPrice %></font> 
            </th>
          </tr>
        </table>
	</td></tr>
      <% else ' if basket ��ҧ      %>
	  		<tr><td class="head9" align=center>			<br>
        <font size="-1"><b><font color="#FF0000">�������¡�èͧ��������ͧ�Թ㹵С��Ңͧ�س</font></b></font>	
      </td>
    </tr>
      <% end if %>

<%
	end if
'========================================================
'	render Bus basket
	if not colbasket.item(3) is nothing then

		set objBusBookInfos = colbasket.item(3)
'	Response.Write "airtyype=" & VarType(objReserveAirlines)	
	cnt = objBusBookInfos.Count
'	Response.Write "�ըӹǹ��¡��==" & cnt
	if basketID <> "" and cnt > 0  then
%>

<tr>
	<td>
	      
        <table width="100%" Border="0" cellspacing="1">
          <tr> 
            <td colspan=9>&nbsp;</td>
          </tr>
          <tr bgcolor="#DFDFDF" > 
            <td colspan=9 > <font color="#006699" size="-1">��¡�èͧö�����</font></td>
          </tr>
          <tr align=center bgcolor="#006699"  height="20"> 
            <th width="5%" ><font color="#FFFFFF" size="-2"> ź </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-2"> �����ö </font></th>
            <th width="12%" ><font color="#FFFFFF" size="-2"> �鹷ҧ </font></th>
            <th width="12%" ><font color="#FFFFFF" size="-2"> ���·ҧ </font></th>
            <th width="14%" ><font color="#FFFFFF" size="-2"> �ѹ�Թ�ҧ </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-2"> �����͡ </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-2"> ���Ҷ֧ </font></th>
            <th width="13%" ><font color="#FFFFFF" size="-2"> �ӹǹ(��) </font></th>
            <th width="14%" ><font color="#FFFFFF" size="-2"> �Ҥ�(�ҷ) </font></th>
          </tr>
          <!--<table width="100%" border="0">
   <tr>
 	<td colspan=9><div align="center"><b><font size="+1" color="#ff9933">��¡�èͧö���</font></b></div>
	</td>
   </tr>

  <tr bgcolor="#003300"> 
    <td width="3%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>ź</b></font></div>
    </td>
    <td width="10%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�����ö</b></font></div>
    </td>
    <td width="8%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�鹷ҧ</b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>���·ҧ</b></font></div>
    </td>
    <td width="10%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�ѹ�Թ�ҧ</b></font></div>
    </td>
    <td width="6%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�����͡</b></font></div>
    </td>
    <td width="25%"> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>���Ҷ֧</b></font></div>
    </td>
    <td> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�ӹǹ<br>
        ����Թ�ҧ</b></font></div>
    </td>
    <td> 
      <div align="center"><font color="#FFFFFF" size="-1"><b>�Ҥ����<br>
        (�ҷ)</b></font></div>
    </td>
  </tr>-->
          <%
		dim BusTotalPrice
		BusTotalPrice = 0
    	For i = 1 To cnt'objReserveAirlines.Count
		
		BusTotalPrice = BusTotalPrice + ( objBusBookInfos.Item(i).Price * objBusBookInfos.Item(i).TotalSeat)
		
%>
          <tr  class="text1"  align="center" <%  if i mod 2 = 0 then Response.Write "bgcolor=#DFDFDF" %> > 
            <td width="5%"> 
              <input type="checkbox" name="BusDelItem" value="<%=objBusBookInfos.Item(i).BusBasketItemID%>">
            </td>
            <td width="10%" ><%=objBusBookInfos.Item(i).routeID%></td>
            <td width="12%" ><%=objBusBookInfos.Item(i).StationsrcName%></td>
            <td width="12%" ><%=objBusBookInfos.Item(i).StationdesName%></td>
            <td width="14%" ><%=objBusBookInfos.Item(i).DepartDate%></td>
            <td width="10%" ><%=TimeValue(objBusBookInfos.Item(i).DepartDateTime)%></td>
            <td width="10%" ><%=TimeValue(objBusBookInfos.Item(i).ArriveDateTime)%></td>
            <td width="13%" ><%=objBusBookInfos.Item(i).TotalSeat%></td>
            <td width="14%" ><%=objBusBookInfos.Item(i).Price * objBusBookInfos.Item(i).TotalSeat %></td>
          </tr>
          <% next  %>
          <!--<tr> 
            <td colspan="8"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><b><font color="#0D549B"><%=BusTotalPrice%></font></b></font></div>
            </td>
          </tr>-->
          <tr  height="25" valign=bottom> 
            <td colspan="8" align=right ><b><font size="-1" color="#006699">�Ҥ����������</font></b> 
            </td>
            <th width="14%"> <font  size="-1" color="#FF0000"><%=BusTotalPrice %></font> 
            </th>
          </tr>
        </table>
	</td></tr>
      <% else ' if basket ��ҧ      %>
	  		<!--<tr><td>
	      <font size="+1" color="#FF9933">You Bus basket is empty</font> 
		 </td></tr>-->
			 <tr><td class="head9" align=center>			<br>
        <font size="-1" color="#FF0000"><b>�������¡�èͧö�����㹵С��Ңͧ�س</b></font> 
      </td>
    </tr>
      <% end if %>

<%
	end if
'========================================================
%>

<%
'========================================================
	'render package basket
	if not colbasket.item(2) is nothing then
	set objReservePackages = colbasket.item(2)
'	Response.Write "Package have "		
	PackageCnt = objReservePackages.Count
'	Response.Write packageCnt & " item in basket"
%>
	<tr><td>
      <!-- <table width="100%" border="1" cellspacing="3" cellpadding="0">
           <tr>
		  	<td colspan=6><div align="center"><b><font size="+1" color="#FF9933">��¡�èͧ Package �����</font></b></div>
       		</td>
          </tr>

        <tr bgcolor=#e6e6fa class="head3" align=center> 
          <td>ź</td>
          <td>��¡�÷��</td>
          <td>��¡����ࡨ�����</td>
          <td>�ѹ�͡�Թ�ҧ</td>
          <td>�ӹǹ����Թ�ҧ</td>
          <td>�Ҥ���� (�ҷ)</td>
        </tr>
-->
		<table width="100%" Border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td colspan=9>&nbsp;</td>
          </tr>
          <tr bgcolor="#DFDFDF" > 
            <td colspan=9 > <font color="#006699" size="-1">��¡�èͧ���稷����</font></td>
          </tr>
          <tr align=center bgcolor="#006699"  height="20"> 
            <th width="5%" ><font color="#FFFFFF" size="-1"> ź </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-1"> ��¡�÷�� </font></th>
            <th width="25%" ><font color="#FFFFFF" size="-1"> ��¡�����稷���� 
              </font></th>
            <th width="25%" ><font color="#FFFFFF" size="-1"> �ѹ�͡�Թ�ҧ </font></th>
            <th width="20%" ><font color="#FFFFFF" size="-1"> �ӹǹ����Թ�ҧ 
              </font></th>
            <th width="15%" ><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ)</font></th>
          </tr>
          <% for j=1 to packagecnt %>
          <%
	PackageID	=	objReservePackages.Item(j).PackageID
	DepartDate	=	objReservePackages.Item(j).DepartDate
	PackageName	=	objReservePackages.Item(j).PackageName
	NumOfTraveller=	objReservePackages.Item(j).colTraveller.Count
	
'find price	
	set objPackageDepartures = Server.CreateObject("DALDB.CPackageDepartureFactory")
	set TourService	= Server.CreateObject("TourService.IPackageViewer")
	set bookingservice = Server.CreateObject("TourBookingService.IBookManager")
	objPackageDepartures.Serialize = tourservice.GetPackageDeparture(cint(packageID)).Serialize
	childprice = 0
	adultprice = 0
	for i = 1 to objPackageDepartures.internalCRecocdset.Rowcount
		if Departdate = objPackageDepartures.Item(i).DepartDate then
			childprice = objPackageDepartures.Item(i).ChildPrice
			AdultPrice = objPackageDepartures.Item(i).AdultPrice
	bookingprice = 0
		'Response.Write objreservepackages.Item(j).colTraveller.Item(1).travellername
		'Response.Write "t_cnt=" & numofTraveller
		for k = 1 to numofTraveller
			age = bookingservice.CalculateAge(objReservePackages.Item(j).colTraveller.Item(k).Birthdate,CDate(DepartDate))
		'	Response.Write age
			if age < 15 then
			 bookingprice = bookingprice + childprice
			 else
			 bookingprice = bookingprice + adultprice
			end if
		next 'k 
		end if
	next ' i
	
'	BookingPrice=	objReservePackages.Item(j).colTraveller
	Packagetotalprice = Packagetotalprice + bookingprice
%>
          <tr class="text1" align=center  <%  if i mod 2 = 0 then Response.Write "bgcolor=#DFDFDF" %> > 
            <td> 
              <input type="checkbox" name="PackageDelItem" value=<%=objReservePackages.Item(j).PackageBasketItemID%>>
            </td>
            <td><%=j%></td>
            <td><a href="javascript:openPopupPackageDetail('<%=PackageID%>','<%=DepartDate%>')"><%=PackageName%></a></td>
            <td><a href="javascript:openPopupPackageDetail('<%=PackageID%>','<%=DepartDate%>')"><%=DepartDate%></a></td>
            <td><a href="javascript:openPopupBasketTraveller('<%=BasketID%>','<%=objReservePackages.Item(j).PackageBasketItemID%>')"><%=NumOfTraveller%></a></td>
            <!--          <td><a href="javascript:openPopupTraveller('<%=BookingID%>','<%=ItemNo%>')"><%=NumOfTraveller%></a></td>  -->
            <td><%=BookingPrice%></td>
          </tr>
          <%		next  ' j--> packagecnt %>
          <!--
        <tr> 
          <td colspan="5" align="right" class="head4">���������&nbsp;&nbsp;&nbsp;</td>
          <td align="center" class="text"><b><u><%=PackageTotalPrice%></u></b></td>
        </tr> -->
          <tr  height="25" valign=bottom> 
            <td colspan="5" align=right height="15" ><b><font size="-1" color="#006699">�Ҥ����������</font></b> 
            </td>
            <th height="15"> <font  size="-1" color="#FF0000"><%=PackageTotalPrice%></font> 
            </th>
          </tr>
        </table> 
		
			</td>
		</tr>
		<!--
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td colspan=5>�Ҥ���������� 4 �к�</td>
		<td><%=HotelTotalPrice + PackageTotalPrice + BusTotalPrice + AirlineTotalPrice %></td>
	</tr>-->
		<tr><td height=20 valign=bottom>&nbsp; </td></tr>
	    <tr>
			<td>
				
        <table width="100%">
          <tr bgcolor="#DFDFDF"> 
            <td align=right width="85%"><b><font color="#006699">�Ҥ�����ء��¡��</font></b></td>
						
            <th align=center  width="15%"><font  color="#FF0000"><%=HotelTotalPrice + BusTotalPrice + AirlineTotalPrice + PackageTotalPrice%></font></th>
					</tr>
				</table>
			</td>
	   </tr>
			
				<tr><td  height=20 valign=bottom>&nbsp; </td></tr>
      <!--</table>-->

	
  <% end if ' render package%>
  <!--/td-->
  <!--/tr-->
<!--
    <tr> 
          
      <td colspan=2 align=center> 
        <input type="hidden" name="BasketID" value=<%=basketID%>>
        <input type=submit name="TourBasket" value="�ӹǳ�Ҥ�����" class="buttonbox">
       &nbsp;&nbsp; 
        <input type=submit name="TourBasket" value="�ͧ" class="buttonbox">
          </td>
	</tr>
		-->
		 <tr> 
			  <td  align=center> 
			  	        <input type="hidden" name="BasketID" value=<%=basketID%>>
						<input type=submit name="TourBasket" value="�ӹǳ�Ҥ�����" class="button1">
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type=submit name="TourBasket" value="�ͧ" class="button1">
					  </td>
					</tr>
     <tr> 
          <td colspan=2>&nbsp;</td>
        </tr>
	
<!--/TBODY-->
<!--/TABLE-->
</table>
</form>
<% end if %>
<% end if ' has a basket but no item %>
<!--/form-->
</BODY>
</HTML>
