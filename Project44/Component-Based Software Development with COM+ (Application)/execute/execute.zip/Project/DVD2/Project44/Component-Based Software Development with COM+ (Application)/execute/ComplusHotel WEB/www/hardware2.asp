<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<OBJECT runat="server" ID="x"  PROGID="Hwproject.HwClass">
</OBJECT>
<html>
<body>
<% 
	if x.isOn(3) then
		response.write("On")
	else
		response.write("off")
	end if
%>
</body>
</html>