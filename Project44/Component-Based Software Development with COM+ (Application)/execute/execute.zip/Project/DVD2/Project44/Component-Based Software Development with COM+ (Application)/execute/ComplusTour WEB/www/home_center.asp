<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD><TITLE> OLALA Tour -> ��ԡ���Ѻ�ͧ�ç��� ������ ����� ���ö</TITLE>
	    <META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>

<BODY BGCOLOR="#FFFFFF"> 
<BR>
  <!--  Special Package  -->
  <TABLE cellSpacing=0 cellPadding=1 width=350 border=0>
    <TBODY> 
    <TR>
      <TD colSpan=2 height=13><IMG height=24 src="images/specials.gif"  width=420></TD>
    </TR>
    </TBODY> 
  </TABLE>
  <BR>
<TABLE>		
<%
	'on error resume next

	'Response.Cookies("InDate") = Request.Form("MinDepartDate")
	'Response.Cookies("OutDate") = Request.Form("MaxDepartDate")
	'Response.Cookies("Amt") = Request.Form("NumTraveller")

	'dim objSearchPackage
	'dim objSearchPackageResultFactory
		
		'set  objSearchPackage = Server.CreateObject("TourService.ISearch")
		'set objSearchPackageResultFactory = server.CreateObject("DALDB.CPackageSearchResultFactory")
		'Response.Write "PlaceName=" & Request.Form("PlaceName") & "-<BR>"
		'Response.Write "Country=" & Request.Form("Country") & "-<BR>"
		'Response.Write "State=" & Request.Form("State") & "-<BR>"
		'Response.Write "City=" & Request.Form("City") & "-<BR>"
		'Response.Write "MinDepartDate=" & Request.form("MinDepartDate") & "-<BR>"
		'Response.Write "MaxDepartDate" & Request.form("MaxDepartDate") & "-<BR>"
		'Response.Write "NumOfDays" & Request.Form("NumOfDays")& "-<BR>"
		'Response.Write "NumTraveller" & Request.Form("NumTraveller") & "-<BR>"
		'set objSearchResultFactory = objSearchPackage.SearchPackage(CStr( Request.Form("PlaceName") ),CStr( Request.Form("Country") ),CStr( Request.Form("State") ),CStr( Request.Form("City") ),CDate( Request.form("MinDepartDate") ),CDate(Request.form("MaxDepartDate")),CInt( Request.Form("NumOfDays") ),CInt( Request.Form("NumTraveller") ) )
		'objSearchPackageResultFactory.Serialize = objSearchResultFactory.Serialize
		'set objSearchPackage = nothing
		'if objSearchPackageResultFactory.Count = 0 then 
	'	else
		
		dim IPackageViewer 
		dim objPackageFac
		dim objPackage
			set IPackageViewer = server.CreateObject("TourService.IPackageViewer")
			set objPackageFac = server.CreateObject("DALDB.CPackageFactory")
			set objPackage = IPackageViewer.GetPackage(cint(0))
			objPackageFac.Serialize = objPackage.Serialize
			'===========Package1========================
			for i = 4 to 6 
			PackageID = objPackageFac.Item(i).PackageID
			PackageName = objPackageFac.Item(i).PackageName
			NumOfDays = objPackageFac.Item(i).NumOfDays
			Description = objPackageFac.Item(i).Description
			
			dim objPackageDepartureFac
			set objPackageDepartureFac = server.CreateObject("DALDB.CPackageDepartureFactory")
			set objPackageDeparture = IPackageViewer.GetPackageDeparture(cint(PackageID))
			objPackageDepartureFac.Serialize = objPackageDeparture.Serialize
			DepartDate = objPackageDepartureFac.Item(1).DepartDate
			AdultPrice = objPackageDepartureFac.Item(1).AdultPrice
			ChildPrice = objPackageDepartureFac.Item(1).ChildPrice
			
			dim objPackageDetailFac
			set objPackageDetailFac = server.CreateObject("DALDB.CPackageDetailFactory")
			set objPackageDetail = IPackageViewer.GetPackageDetail(cint(PackageID))
			objPackageDetailFac.Serialize = objPackageDetail.Serialize
			PlaceID = objPackageDetailFac.Item(1).PlaceID
			
			dim objPlaceFac
			set objPlaceFac = server.CreateObject("DALDB.CPlaceFactory")
			set objPlace = IPackageViewer.GetPlace(cint(PlaceID))
			objPlaceFac.Serialize = objPlace.Serialize
			ImagePath = objPlaceFac.Item(1).ImagePath
%>
	
	
	<TR>
		<TD vAlign=center width=115> 
		<DIV align=center class"text">
		<A  href="ShowPackageDetail.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=0">
		<IMG height=63 src="<%=ImagePath%>" width=82 border=0></a>
		</DIV>
		</TD>
		
		
      <TD width=384 class="text"> <font color="#006699"> 
        <!--A  href="package.htm"-->
		<BR>
        <a href="ShowPackageDetail.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=0">
        <FONT face=Verdana><u><b><%=PackageName%>&nbsp;&nbsp;</b> 
        <%=NumOfDays%> �ѹ <%=NumOfDays - 1%> 
        �׹ �͡�Թ�ҧ <%=DepartDate%></u></FONT></a><BR>
        
        
        <!--/A-->
        ����˭��Ҥ� <%=AdultPrice%> 
        �ҷ/��ҹ �� <%=ChildPrice%> 
        �ҷ/��ҹ</font> <BR>
        <%=Description%>
		
		<A href="addTraveller.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=0&cmd=addPackage"><FONT face=Verdana color=RED>��Ժ����С���</font></a>
		</TD>
	</TR>
<%			
			
			
			next 'i objPackageFac
		
		
		'for i = 1 to objSearchPackageResultFactory.Count
		'	PackageID = objSearchPackageResultFactory.Item(i).objCPackageDeparture.PackageID
		'	DepartDate = objSearchPackageResultFactory.Item(i).objCPackageDeparture.DepartDate
			
		'	set IPackageViewer = server.CreateObject("TourService.IPackageViewer")
		'	set PackageDetailFac = server.CreateObject("DALDB.CPackageDetailFactory")
		
		'	set PackageDetail = IPackageViewer.GetPackageDetail(cint(PackageID))	
		'	PackageDetailFac.Serialize = PackageDetail.Serialize
		'	PlaceID = PackageDetailFac.Item(1).PlaceID			
			
		'	set PlaceFac = server.CreateObject("DALDB.CPlaceFactory")
		'	PlaceFac.Serialize = IPackageViewer.GetPlace(cint(PlaceID)).Serialize
'		'	PlaceFac.Serialize = objPlace.serialize 
		'	ImagePath = PlaceFac.Item(1).ImagePath
			'Response.Write objSearchPackageResultFactory.Item(i).objCPackage.PackageName + "<br>"
			 'objSearchPackageResultFactory.Item(1).objCPackage.PackageName
	
'		next 
		'PlaceName = Request.QueryString("")
'	end if
%>
		
	</TBODY>
	</TABLE>	
</DIV>
</BODY>
</HTML>