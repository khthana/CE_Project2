<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<OBJECT runat="server" ID="x"  PROGID="Remote.Hw">
</OBJECT>
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<%
'set x = server.createobject("Remote.Hw")
response.write x.fnx()
%>
</BODY>
</HTML>
