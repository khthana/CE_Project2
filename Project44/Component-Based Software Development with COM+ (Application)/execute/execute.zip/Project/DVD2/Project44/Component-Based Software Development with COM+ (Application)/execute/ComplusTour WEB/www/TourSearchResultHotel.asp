<html>
<head>

<title> OLALA TOUR :: Result of Hotel Searching </title>

<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="homestyle.css" >
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>


</head>

<body bgcolor="#FFFFFF" >
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>

<table width="95%" border="0" cellspacing="0" cellpadding="5" align=center>
  <!--  <tr> 
    <td width="148" bgcolor="#D7DCE8" height="249" valign="top"> -->
  <%
	on error resume next
		Response.Cookies("InDate") = Request.Form("CheckInDate")
		Response.Cookies("OutDate") = Request.Form("CheckOutDate")
		Response.Cookies("Amt") = Request.Form("AmountOfRoom")
'			cmd = Request.Form("cmd")
'			Email = Request.Form("Email")
'			Password = Request.Form("Password")
			
'			if cmd = "login" then
'			set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
'			CustomerID = objCustomer.Login(Cstr(Email),Cstr(Password))
'					if err.number = 0 and CustomerID > 0 then
'						Response.Cookies("CustomerID") = CustomerID
'						Response.Cookies("CustomerID").expires = date+1

'					else
'							select case err.number 
'								case vbObjectError+1 err_txt = "notfound"
'								case vbObjectError+5 err_txt = "wrongpassword"
'							end select
'						err_txt = "loginerror.asp?err="  & err_txt  
'							pagename=request.servervariables("script_name")
'						response.redirect(err_txt & "&frompage=" & pagename)
'					end if  
'			end if		    	
		
'			if cmd="logout" then
'						Response.Cookies("BasketID").expires = now
'						Response.Cookies("CustomerID").expires = now
'						Response.Cookies("BasketID") =""
'						Response.Cookies("CustomerID") = ""

'			end if
	
			
'			CustomerID = Request.Cookies("CustomerID")

'			if CustomerID = "" then
			'' render login box
%>
  <!--
      <form name="form1" method="post" action="">
        <table width="130" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td bgcolor="#6B8EC6" width="130"> 
              <div align="center"><font size="-1">Login</font></div>
            </td>
          </tr>
          <tr> 
            <td width="130"><font size="-1">E-mail address</font></td>
          </tr>
          <tr> 
            <td height="15" width="130"> <font size="-1"> 
              <input type="text" name="Email">
              </font></td>
          </tr>
          <tr> 
            <td width="130"><font size="-1">Password</font></td>
          </tr>
          <tr> 
            <td width="130"> <font size="-1"> 
              <input type="password" name="Password">
              </font></td>
          </tr>
          <tr> 
            <td height="10" width="130"> 
              <div align="center"><font size="-1"> 
			   
				<input type="hidden" name="cmd" value="login">
			  	<input type="hidden" name="country" value="<%=Request.Form.Item("Country")%>">
			  	<input type="hidden" name="state" value="<%=Request.Form.Item("State")%>">
			  	<input type="hidden" name="city" value="<%=Request.Form.Item("City")%>">
			  	<input type="hidden" name="star" value="<%=Request.Form.Item("star")%>">
			  	<input type="hidden" name="HotelName" value="<%=Request.Form.Item("HotelName")%>">
			  	<input type="hidden" name="RoomModelName" value="<%=Request.Form.Item("RoomModelName")%>">
			  	<input type="hidden" name="PriceRate" value="<%=Request.Form.Item("PriceRate")%>">
			  	<input type="hidden" name="CheckInDate" value="<%=Request.Form.Item("CheckInDate")%>">
			  	<input type="hidden" name="CheckOutDate" value="<%=Request.Form.Item("CheckOutDate")%>">
			  	<input type="hidden" name="AmountOfRoom" value="<%=Request.Form.Item("AmountOfRoom")%>">
			
							<input type="submit" name="Submit" value="Login">
                <input type="reset" name="Submit2" value="Reset">
                <br>
                <a href="lostpassword.asp">Lost Password</a><br>
                <a href="register.asp">New User</a></font></div>
            </td>
          </tr>
        </table>
      </form> 
	  -->
  <%
'			else
			 'show customer name and render customer menu 
'				set Customers = Server.CreateObject("DALDB.CCustomerFactory")
'				set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
'				customers.Serialize  = objCustomer.GetCustomer(clng(CustomerID)).Serializer
'				CustomerName = Customers.item(1).CustomerName
%>
  <!--
      <table width="130" border="0" cellspacing="1" cellpadding="0" align="center" dwcopytype="CopyTableRow">
        <tr> 
          <td bgcolor="#6B8EC6" width="116" height="17"><font size="-1" color="#FFFFFF"><b>���ʴդ�Ѻ 
            �س <%=CustomerName%> </b></font></td>
        </tr>
        <tr> 
          <td bgcolor="#6B8EC6" width="116" height="17"> 
            <div align="center"><font size="-1"><a href="MyProfile.asp">My 
              Profile</a></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#6B8EC6" width="116"> 
            <div align="center"><font size="-1"><a href="MyReservation.asp">My 
              Reservation</a></font></div>
          </td>
        </tr>
        <tr> 
          <td height="15" bgcolor="#6B8EC6" width="116">
<div align="center">
              <form name="formx" method="post" action="index.asp">
                <input type="hidden" name="cmd" value="logout">
                <input type="image" name="Submit" value="logout" src="images/viewonmap.gif" width="70" height="13">
			  </form>
              </div>
          </td>
        </tr>
      </table>
-->
  <%
'			end if ' render login box OR menu
%>
  <td rowspan="2" height="277" valign="top"> 
    <%
'on error resume next
dim a, b ,c  ,i ,j ,k,L
dim BookingPrice 
dim Country,State,City,HotelName,MinStar,MaxStar,RoomModelName,MinPrice,MaxPrice,CheckIndate,CheckOutDate,AmountOfRoom
set objHotelSearchResults = server.CreateObject("DALDB.CHotelSearchResultFactory")
set objSearch = server.CreateObject("TourService.ISearch")
dim id,star,priceRate
dim tmp1,tmp2,tmp3
dim HotelCnt
dim RoomModelPriceObj
dim notfound
' Check an reformat Input 
Country = Request.Form.Item("Country")
State =  Request.Form.Item("State")
	if State = "any" then State ="" end if
City =  Request.Form.Item("City")
	if City = "any" then City ="" end if
HotelName =  Request.Form.Item("HotelName")
Star =  Request.Form.Item("Star")
RoomModelName = Request.Form.Item("RoomModelName") 
	if RoomModelName = "any" then RoomModelName ="" end if
PriceRate =  Request.Form.Item("PriceRate")
CheckInDate = request.Form.Item("CheckInDate")
CheckOutDate =  Request.Form.Item("CheckOutDate")
AmountOfRoom =  Request.Form.Item("AmountOfRoom")
	if AmountOfRoom = "" then AmountOfRoom = 1 end if

select case star
	case "1-2"	Minstar = 1
				maxstar = 2
	case "2-3"	Minstar = 2
				maxstar = 3
	case "3-4"	Minstar = 3
				maxstar = 4
	case "4-5"	Minstar = 4
				maxstar = 5
	case "1-5"	Minstar = 1
				maxstar = 5
	case ELSE 	Minstar = 1
				maxstar = 5				
end select

SELECT case Pricerate
	case "0-1000"		MinPrice = 0
						MaxPrice = 1000
	case "1001-2000"	MinPrice = 1001
						MaxPrice = 2000
	case "2001-3000"	MinPrice = 2001
						MaxPrice = 3000
	case "3001-4000"	MinPrice = 3001
						MaxPrice = 4000
	case "4001-5000"	MinPrice = 4001
						MaxPrice = 5000
	case "5001-1000000"	MinPrice = 5001
						MaxPrice = 1000000
	case else			MinPrice = 0
						MaxPrice = 1000000
end select
' call method Search and Deserialize
	notfound = false
	set tmp1 = objSearch.SearchHotel(Cstr(Country),cstr(State),cstr(City),cstr(HotelName),cint(MinStar),cint(MaxStar),Cstr(RoomModelName),ccur(MinPrice),ccur(MaxPrice),cdate(CheckIndate),cdate(CheckOutDate),Cint(AmountOfroom))
	if Err.number = vbObjectError+1 then 
		notfound = true
	end if
	
	tmp1.Serialize a,b,c
	objHotelSearchResults.DeSerialize a,b,c

	HotelCnt = objHotelSearchResults.Count
%>
      <div align="left"><font color="#FF9900"><b><font face="MS Sans Serif" size="-1" color="#FF0000">���Ѿ���ä����ç��� 
        </font></b></font> <br>
         
        <%		if notfound then %>
        <font size="-1" color="#006699"><b>��辺�ç������س��ͧ���</b> </font>
        <%	else %>
        <font size="-1" color="#006699">��������</font> <font size="-1" color="#006699"><b> 
        <%=Hotelcnt%> </b>�ç��� 
        <%	end if%>
        </font><font size="-1"><br>
      <br>
        <font color="#006699">Check-in date : <b><%=CheckInDate%></b><br>
        Check-out date : <b><%=CheckOutDate%></b></font></font><font color="#006699"><br>
        <font size="-1">�ӹǹ��ͧ�ѡ����ͧ��� : </font><b><%=AmountOfRoom%></b></font><font size="-1" color="#006699">��ͧ</font><br>
    </div>
    <%for i = 1 to Hotelcnt%>
      <table width="100%" border="0" cellspacing="2" cellpadding="0">
        <tr> 
          <td colspan="7" height="9" bgcolor="#006699"><b><font color="#FFFFFF" size="-1"><%=ObjHotelSearchResults.Item(i).HotelObj.HotelName%></font></b></td>
        </tr>
        <tr> 
          <td width="62%"><font size="-1"> <%=ObjHotelSearchResults.Item(i).HotelObj.City%> 
            , <%=ObjHotelSearchResults.Item(i).HotelObj.Country%> </font></td>
          <td colspan="4"><font size="-1"></font> 
            <div align="right"><font size="-1"><b><font color="#006699">stars</font></b> 
              <%	for z = 1 to ObjHotelSearchResults.Item(i).HotelObj.Star %>
              <img src="images/star1.gif"> 
              <%			next	  %>
              </font></div>
          </td>
        </tr>
        <tr> 
          <td colspan="5"> 
            <div align="left"><font size="-1"><img src= <%= ObjHotelSearchResults.Item(i).HotelObj.ImageMapPath %> align="left">&nbsp; 
              <%=ObjHotelSearchResults.Item(i).HotelObj.Description%> <a href="javascript:openViewHotelWindow('<%=ObjHotelSearchResults.Item(i).HotelObj.HotelID%>')"><b>�������������</b></a> 
              </font></div>
          </td>
        </tr>
        <tr> 
          <td width="62%"> 
            <div align="center"><font size="-1"><font color="#FF0000">��Դ��ͧ�ѡ</font></font></div>
          </td>
          <%
    Set RoomModelPriceObj = ObjHotelSearchResults.Item(i).RoomModelPriceObj.Item(1)
	dim dcnt 
	dcnt = RoomModelPriceObj.colCPricePerDay.Count
    For j = 1 To dcnt
%>
          <td width="21%"> 
            <div align="center"><font size="-2"><font color="#FF0000"><%=RoomModelPriceObj.colCPricePerDay(j).Day%></font></font></div>
          </td>
          <%next%>
        </tr>
        <%    For k = 1 To ObjHotelSearchResults.Item(i).colCRoomModelPrice.Count 
        Dim cnt 
        Set RoomModelPriceObj = ObjHotelSearchResults.Item(i).colCRoomModelPrice.Item(k)
%>
        <tr> 
          <td width="62%" bgcolor="#D3D3D3"><font size="-1"><a href="javascript:openViewRoomModelWindow('<%=trim(RoomModelPriceObj.RoomModelID)%>')"><b><%=RoomModelPriceObj.RoomModelName%></b></a></font></td>
          <% cnt = RoomModelPriceObj.colCPricePerDay.Count%>
          <%   BookingPrice = 0
For L = 1 To cnt
%>
          <td width="21%" bgcolor="#D3D3D3"> 
            <div align="center"><font size="-1"><b><font color="#006699" size="-2"><%= RoomModelPriceObj.colCPricePerDay.Item(L).Price %> 
              </font></b><font color="#006699" size="-2">�ҷ</font></font></div>
          </td>
          <%		BookingPrice =BookingPrice + RoomModelPriceObj.colCPricePerDay.Item(L).Price
 next   '   L 
 %>
          <form name="form3" method="post" action="basket.asp">
            <td width="17%" bgcolor="#006699"> 
              <input type="hidden" name="cmd" value="addHotel">
              <input type="hidden" name="HotelID" value="<%=trim(ObjHotelSearchResults.Item(i).HotelObj.HotelID)%>">
              <input type="hidden" name="RoomModelID" value="<%=trim(RoomModelPriceObj.RoomModelID)%>">
              <input type="hidden" name="BookCheckIn" value="<%=trim(RoomModelPriceObj.colCPricePerDay(1).Day)%>">
              <input type="hidden" name="BookCheckOut" value="<%=trim(RoomModelPriceObj.colCPricePerDay(dcnt).Day)%>">
              <input type="hidden" name="AmountOfRoom" value="<%=AmountOfRoom%>">
              <input type="hidden" name="BookingPrice" value="<%= BookingPrice*AmountOfRoom %>">
              <input type="image" name="Submit3" value="��Ժ����С���" src="images/viewonmap1.gif" width="73" height="13">
            </td>
          </form>
        </tr>
        <% next  ' i   %>
      </table>
    <br>
    <%next %>
  </td>
  </tr>
  
</table>
</body>
</html>
