<OBJECT runat="Server" ID="object1"  PROGID="MyCom.MyGrid">
</OBJECT>
<%
'object1.showtable2 "Provider=Microsoft.Jet.OLEDB.4.0; Data 'Source=C:\ComplusHotel\Hotel.mdb;","Customer" 
object1.showtable2 "Provider=SQLOLEDB;Data Source=localhost;User ID=testcom;                               Password=testcom;Initial Catalog=Hotel","Customer" 
%>