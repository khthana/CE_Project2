<%
	'private final String TARGET_PAGE = "index.jsp";

    'private AirlineServiceHome airlineServiceHome = null;
    '/* ======================= lookup component ======================= */
    'public void jspInit() {
    '        //look up jndi name
    '        Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

    '        //cast to Home interface
    '        airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
    '  }
%>

<%

'    String departureAirportID = request.getParameter("departureAirport").toUpperCase();
'    String destinationAirportID = request.getParameter("destinationAirport").toUpperCase();
'    if (departureAirportID.equals("") || destinationAirportID.equals("")
'		|| departureAirportID == null || destinationAirportID == null)
'	{
'        response.sendRedirect(response.encodeURL(TARGET_PAGE+"?errCode=0"));
'    }

	Response.Cookies("InDate") = Request.Form("InDate")
	Response.Cookies("OutDate") = Request.Form("OutDate")
	Response.Cookies("Amt") = Request.Form("seats")

	
	departureAirportID = request.form("departureAirport")
	destinationAirportID = request.form("destinationAirport")
	 if departureAirportID ="" or destinationAirportID ="" then
		response.redirect("Error.htm") 
		end if
		
%>


<%
'	on error resume next
	set airlineService = Server.CreateObject("TourService.ISearch")
	'departureAirportVO = airlineService.GetAirport(departureAirportID)
	'destinationAirportVO = airlineService.GetAirport(destinationAirportID)

'    AirlineService airlineService = airlineServiceHome.create();
'	AirportVO departureAirportVO = null;
'	AirportVO destinationAirportVO = null;
'	try {
'	   	departureAirportVO = airlineService.GetAirport(departureAirportID);
'		destinationAirportVO = airlineService.GetAirport(destinationAirportID);
'    }
'    catch (Exception e) {
'        response.sendRedirect(response.encodeURL(TARGET_PAGE+"?errCode=1"));
'    }
%>


<%
'    /* ================== �ѹ�Թ�ҧ� / ��Ѻ ================== */
'	String departureDay = request.getParameter("departureDay");
'	String departureMonth = request.getParameter("departureMonth");
'	String departureYear = request.getParameter("departureYear");
'	String departureDateString = departureYear+"-"+departureMonth+"-"+departureDay;
'	java.sql.Date departureDate = java.sql.Date.valueOf(departureDateString);
'	String returnDay = request.getParameter("returnDay");
'	String returnMonth = request.getParameter("returnMonth");
'	String returnYear = request.getParameter("returnYear");
'	String returnDateString = returnYear+"-"+returnMonth+"-"+returnDay;
'	java.sql.Date returnDate = java.sql.Date.valueOf(returnDateString);

	departureDate = request.form("Indate")
	returnDate = 	request.form("Outdate")
'	departureDateString = departureYear+"-"+departureMonth+"-"+departureDay
'	returnMonth = request.form("returnMonth")
'	returnYear = request.form("returnYear")
'	returnDateString = returnYear+"-"+returnMonth+"-"+returnDay
'	returnDate = CDate(returnDateString)

'    /* ================== ���˹觷�����ٺ������������˹�ҵ�ҧ ================== */
'    boolean window = true;
'    boolean smoking = true;
'    boolean directFlight = true;
'    if (request.getParameter("window") == null)    { window = false; }
'    if (request.getParameter("smoking") == null)    { smoking = false; }
'    if (request.getParameter("directFlight") == null)    { directFlight = false; }
    window_ = true
    smoking = true
    directFlight = true
    if (request.form("window") = "")    then window_ = false
    if (request.form("smoking") = "")    then smoking = false
    if (request.form("directFlight") = "")    then directFlight = false



'    /* ================== �����Թ�ҧ� / ��Ѻ================== */
'	java.sql.Time departureTime = null;
'	java.sql.Time returnTime = null;
'	String departureTimeString = request.getParameter("departureTime");
'	String returnTimeString = request.getParameter("returnTime");
'	if (!departureTimeString.equals("0")) {
'		departureTime = java.sql.Time.valueOf(departureTimeString);
'	}
'	if (!returnTimeString.equals("0")) {
'		returnTime = java.sql.Time.valueOf(returnTimeString);
'	}
'	departureTime = NULL
'	returnTime = NULL
	departureTimeString = request.form("departureTime")
	returnTimeString = request.form("returnTime")
	if ( departureTimeString <> "0" ) then 
		departureTime = CDate(departureTimeString)
	end if
	if ( returnTimeString <> "0" ) then
		returnTime = CDate(returnTimeString)
	end if

'	String tripType = request.getParameter("tripType");
'    int seats = Integer.parseInt(request.getParameter("seats"));
'    String aircraftClass = request.getParameter("class");
'    String airline = request.getParameter("airline");
'    if (airline.equals("")) { airline = null; }
	 tripType = request.form("tripType")
     seats = CInt( request.form("seats") )
     aircraftClass = request.form("class")
     airline = request.form("airline")
'????      if (airline = "" ) then  airline = null
	'if airline = "" then airline = NULL 
    
'    Collection searchResultCollection = null;
'	searchResultCollection = airlineService.Search(
'        departureAirportID,
'        destinationAirportID,
'        seats,
'        departureDate,
'        departureTime,
'        aircraftClass,
'        airline,
'        smoking,
'        window,
'        directFlight);

'    Collection searchResultCollection = null;
' Date, Departtime As Date, airclass As String, airline As String, smoking As Boolean, Window As Boolean, NonStopOnly As Boolean) As CAirlineSearchResultFactory
		set searchResultCollection = airlineService.SearchAirline( _
	    cstr(departureAirportID), _
        cstr(destinationAirportID), _
        cint(seats), _
        cdate(departureDate), _
        cdate(departureTime), _
        cstr(aircraftClass), _
        cstr(airline), _
        cbool(smoking), _
        cbool(window_) , _
        cbool(directFlight))
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
'	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
'	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
'	if(shoppingCart == null) {
'		shoppingCart = new ShoppingCart();
'	}
%>

<head>
<!-- #BeginEditable "doctitle" --> 
<title>:: OLALA AIR :: ���Ѿ���ä���</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="homestyle.css" >

<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>


<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="3" cellpadding="0">

    <td height="5" width="663" rowspan="2"> <!-- #BeginEditable "Center" --> 
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
            <p>&nbsp;</p>
            <table cellspacing=0 cellpadding=0 width="100%" border=0>
              <tbody> 
              <tr> 
                <td bgcolor=#34208b><img height=20 
            src="images/lt_blue_corner.gif" width=18 border=0></td> <!-- rateheader -->
                <td class=head3 align=left width=440 
          background=images/dk_blue_bg.gif><font color=#fefefe><b>���Ѿ���ä�������ǺԹ - ������</b></font></td>
                <td align=right bgcolor=#34208b><img height=20 
            src="images/rt_blue_corner.gif" width=18 
        border=0></td>
              </tr>
              </tbody> 
            </table>
<%
    if (searchResultCollection is nothing) then 
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="100"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%" height="100%">
                    <tr> 
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                      <td bgcolor="#F0F0F0" height="1"></td>
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td class="text"></td> <!--  airFieldTitleGray-->
                      <td class="text">��辺����ǺԹ���ç�Ѻ������ͧ��âͧ�س 
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
        <%
    else 
    itemNo = 0

    'Iterator i = searchResultCollection.iterator();
	counts = searchResultCollection.count
	i = 1
    do while (i  <=  counts ) 
'        itemNo++;
		 itemNo = itemNo + 1
        'AirSeatSearchResult assr = (AirSeatSearchResult) i.next();
		set assr = searchResultCollection.item(i)
		i = i + 1
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="131"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" bgcolor="#F0F0F0" height="1"></td>
                      <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td></td><!-- airFieldTitleGray -->
                      <td width="230" color="#FEFEFE" class="text"><font color="#888888"><b>��¡�÷�� <%= itemNo %></b></font></td>
                      <td width="230" bgcolor="#FEFEFE"></td>
                      <td></td>
                    </tr>
                  </table>
                  <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                    <!-- begin date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap class="airsearchexample"><b><font color=#34208B><%=departureDate%></font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3"><font color="#888888"><b>CLASS</b></font></td>
                      <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                      <td NOWRAP class="airsearchexample2"><b> <font color=#888888 >ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="airsearchexample2"><b> <font color=#888888>DEPART</font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample2"><b> <font color="#888888">����ǺԹ 
                        #</font></b><font color="#888888"></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <!-- end  date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= departureAirportID %></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= assr.ClassID %></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> <b><%= TimeValue(assr.DepartTime)  %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= assr.FlightID %></td>
                      <td width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="infocopy"><%= destinationAirportID %></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"></td>
                      <td nowrap class="infocopy"> <b><%=timevalue(assr.ArriveTime)%></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                    </tr>
                  </table>
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <table width="230" border="0" cellspacing="0" cellpadding="1">
                          <tr> 
                            <td bgcolor="#34208B"> 
                              <table width="230" border="0" cellspacing="0" cellpadding="2">
                                <tr> 
                                  <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���� 
                                    <%= assr.Price * seats %> �ҷ ����Ѻ <%= seats %> �����</font></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td colspan="2"><img height=7 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <form method="POST" name="RezRequester" action="addEJBtraveller.asp">
                          <input class=airBookitButton type="submit" name="Submit3" value="Add to cart" style="border-bottom:thin solid #000000
      ;border-right:thin solid #000000;border-top:thin solid
      #D7D7D7;border-left:thin solid #D7D7D7;background-color:#34208B;color:#FFFFFF">
                        <input type="hidden" name="cmd" value="addAirline">
                        <input type="hidden" name="flightID" value="<%= trim(assr.FlightID) %>">
                        <input type="hidden" name="classID" value="<%= trim(assr.ClassID) %>">
                        <input type="hidden" name="seats" value="<%= seats %>">
                        <input type="hidden" name="srcidx" value="<%= assr.SrcIdx %>">
                        <input type="hidden" name="desidx" value="<%= assr.DesIdx %>">
                        <input type="hidden" name="unitPrice" value="<%= assr.Price %>">
                        <input type="hidden" name="smoking" value="<%= smoking %>">
                        <input type="hidden" name="window" value="<%= window_ %>">
                        <input type="hidden" name="departDate" value="<%= departureDate %>">
						<input type="hidden" name="departureAirportID" value="<%= departureAirportID %>">
						<input type="hidden" name="destinationAirportID" value="<%= destinationAirportID %>">
						<input type="hidden" name="departureTime" value="<%= TimeValue(assr.DepartTime) %>">
						<input type="hidden" name="arriveTime" value="<%= TimeValue(assr.ArriveTime) %>">
                        </form>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10 height="2"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" height="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2" height="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <br>
        <%
    	loop'} // while
    end if'} // else



	if (tripType = "R" ) then
	set searchResultCollection = airlineService.SearchAirline(_
	    cstr(destinationAirportID), _
        cstr(departureAirportID), _
        cint(seats), _
        cdate(returnDate), _
        cdate(returnTime), _
        cstr(aircraftClass), _
        cstr(airline), _
        cbool(smoking), _
        cbool(window_) , _
        cbool(directFlight))

%>

            <table cellspacing=0 cellpadding=0 width="100%" border=0>
              <tbody> 
              <tr> 
                <td bgcolor=#34208b><img height=20 
            src="images/lt_blue_corner.gif" width=18 border=0></td>
                <td class=rateheader align=left width=440 
          background=images/dk_blue_bg.gif><font color=#fefefe><b> ���Ѿ���ä�������ǺԹ - ����ǡ�Ѻ </b></font></td>
                <td align=right bgcolor=#34208b><img height=20 
            src="images/rt_blue_corner.gif" width=18 
        border=0></td>
              </tr>
              </tbody> 
            </table>
<%
    if (searchResultCollection is nothing ) then
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="100"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%" height="100%">
                    <tr> 
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                      <td bgcolor="#F0F0F0" height="1"></td>
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td class="airFieldTitleGray"></td>
                      <td class="airFieldTitleGray">��辺����ǺԹ���ç�Ѻ������ͧ��âͧ�س 
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
        <%
    '}
    else '{
    itemNo = 0
    'Iterator i = searchResultCollection.iterator();
	counts  = searchResultCollection.count
	i=1
    do while(i <= counts) 
        itemNo = itemNo+1
'        AirSeatSearchResult assr = (AirSeatSearchResult) i.next();
		set assr = searchResultCollection.item(i)
		i = i +1 
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="131"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" bgcolor="#F0F0F0" height="1"></td>
                      <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td></td>
                      <td width="230" color="#FEFEFE" class="airFieldTitleGray"><font color="#888888"><b>��¡�÷��<%= itemNo %></b></font></td>
                      <td width="230" bgcolor="#FEFEFE"></td>
                      <td></td>
                    </tr>
                  </table>
                  <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                    <!-- begin date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap class="airsearchexample"><b><font color=#34208B><%= returnDate %></font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3"><font color="#888888"><b>CLASS</b></font></td>
                      <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                      <td NOWRAP class="airsearchexample2"><b> <font color=#888888>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="airsearchexample2"><b> <font color=#888888>DEPART</font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample2"><b> <font color="#888888">����ǺԹ 
                        #</font></b><font color="#888888"></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <!-- end  date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= destinationAirportID %></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= assr.ClassID %></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> <b><%=TimeValue(assr.DepartTime)%></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= assr.FlightID %></td>
                      <td width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="infocopy"><%= departureAirportID %></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"></td>
                      <td nowrap class="infocopy"> <b><%= Timevalue(assr.ArriveTime) %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                    </tr>
                  </table>
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <table width="230" border="0" cellspacing="0" cellpadding="1">
                          <tr> 
                            <td bgcolor="#34208B"> 
                              <table width="230" border="0" cellspacing="0" cellpadding="2">
                                <tr> 
                                  <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���� 
                                    <%= assr.Price * seats %> �ҷ ����Ѻ <%= seats %> �����</font></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td colspan="2"><img height=7 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <form method="POST" name="RezRequester" action="addEJBtraveller.asp">
                          <input class=airBookitButton type="submit" name="Submit3" value="Add to cart" style="border-bottom:thin solid #000000
      ;border-right:thin solid #000000;border-top:thin solid
      #D7D7D7;border-left:thin solid #D7D7D7;background-color:#34208B;color:#FFFFFF">
                        <input type="hidden" name="cmd" value="addAirline">
                        <input type="hidden" name="flightID" value="<%= trim(assr.FlightID) %>">
                        <input type="hidden" name="classID" value="<%= trim(assr.ClassID) %>">
                        <input type="hidden" name="seats" value="<%= seats %>">
                        <input type="hidden" name="srcidx" value="<%= assr.SrcIdx %>">
                        <input type="hidden" name="desidx" value="<%= assr.DesIdx %>">
                        <input type="hidden" name="unitPrice" value="<%= assr.Price %>">
                        <input type="hidden" name="smoking" value="<%= smoking %>">
                        <input type="hidden" name="window" value="<%= window_ %>">
                        <input type="hidden" name="departDate" value="<%= returndate %>">
						<input type="hidden" name="departureAirportID" value="<%= destinationAirportID %>">
						<input type="hidden" name="destinationAirportID" value="<%= departureAirportID %>">
						<input type="hidden" name="departureTime" value="<%= TimeValue(assr.DepartTime) %>">
						<input type="hidden" name="arriveTime" value="<%= TimeValue(assr.ArriveTime) %>">
                        </form>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10 height="2"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" height="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2" height="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <br>
<%
	loop
	end if
	end if
			'}
		'}
	'}
%>

          </td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>