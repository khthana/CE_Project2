gacutil /u BusProxy
regasm /u busproxy.dll /tlb:busproxy.tlb