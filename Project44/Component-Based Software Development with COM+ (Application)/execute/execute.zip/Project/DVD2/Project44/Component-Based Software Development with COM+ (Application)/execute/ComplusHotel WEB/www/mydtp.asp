<%@ Language=VBScript %>
<%
'---------------------------------------------------------------------------------------------------------------------------------------------------
'Date picker for Textbox
'Author's Comment:
'---------------------------------------------------------------------------------------------------------------------------------------------------
'(1)	Include these lines in your code:
'		<SCRIPT language=javascript src=calendar.js></SCRIPT>
'		<SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>

'(2)	Not to forget the IFRAME as well.
'		<IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm"></IFRAME>

'(3)	The textbox that store the date need to have this event:
'		onchange="javascript:cbfloadmefirst('form2', 'CheckInDate');"

'(4)	The button/image to trigger the calander must have ID and the following event:
'		onclick="javascript:cbfshowcalendar('form2', 'CheckInDate', 'btn1');event.cancelBubble=true;"

'There are not much error handling placed in the codes, so you need to add it yourself if possible.

'Enjoy

'Regards,
'Ngan C.S. 2002-01-17
'---------------------------------------------------------------------------------------------------------------------------------------------------
%>
<HTML>
<HEAD><TITLE></TITLE>
</HEAD>

<BODY>
<SCRIPT language=javascript src=calendar.js></SCRIPT>
<SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
<IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm"></IFRAME>
<FORM name=form2 action="index.asp" >
  <TABLE>
<TR>
<TD>
<INPUT type=text name=CheckInDate value='<%=Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543%>' onchange="javascript:cbfloadmefirst('form2', 'CheckInDate');">
<INPUT id=btn1 type=button value='Calendar' onclick="javascript:cbfshowcalendar('form2', 'CheckInDate', 'btn1');event.cancelBubble=true;">
</TD>
</TR>
</TABLE>
<INPUT type=text name=date2 value='<%=Day(Date()) & "/" & Month(Date()) & "/" &  Year(Date())+543%>' onchange="javascript:cbfloadmefirst('form2', 'date2');">
<INPUT id=btn2 type=button value='Calendar' onclick="javascript:cbfshowcalendar('form2', 'date2', 'btn2');event.cancelBubble=true;">
</FORM>


</BODY>
</HTML>
