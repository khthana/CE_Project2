<OBJECT runat="Server" ID="p"  PROGID="TestDaldb.CFunction">
</OBJECT>
Hello
<%
a=now
p.fnx
b=now

%>
<%=a-b%>