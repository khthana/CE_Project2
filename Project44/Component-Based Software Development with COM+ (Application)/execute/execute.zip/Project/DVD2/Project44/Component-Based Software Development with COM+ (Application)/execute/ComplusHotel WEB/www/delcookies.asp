<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<%
	response.cookies("BasketID").expires = now
	response.cookies("CustomerID").expires = now
	Response.Write "NowCookies-basket=" & Request.Cookies("BasketID") & "<br>"
	Response.Write "NowCookies-cusID =" & Request.Cookies("CustomerID") & "<br>"
	
	if Request.Cookies("BasketID") = "" and Request.Cookies("CustomerID") = "" then
	Response.Write "Delete Cookies success"
	else Response.Write "Cookies exist, BasketID=" & Request.Cookies("BasketID") & "CustomerID=" & Request.Cookies("CustomerID")
	end if
%>




</BODY>
</HTML>
