161.246.6.240
<br>
<%
response.write "count =   " & request.form.count & "<br>"
response.write "user = " & request.form.item("user") 
response.write "<br>password = " & request.form.item("password")

response.write "<br><br><br><br><br>" & request.form.item("sw")
%>