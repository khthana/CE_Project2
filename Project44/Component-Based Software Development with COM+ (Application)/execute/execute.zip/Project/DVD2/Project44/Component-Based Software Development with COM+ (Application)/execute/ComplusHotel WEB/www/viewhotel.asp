<html>
<head>
<title>OLALA HOTEL :: View Hotel </title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css" >
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<p align="center"> 
  <%
	dim HotelID
	dim HotelService
	dim ObjHotels
	dim HotelName,Star,Address,Telephone,Description,Image
	
	HotelID = Request.QueryString("HotelID")
	set ObjHotels = Server.CreateObject("DALDB.CHotelFactory")
	set HotelService = Server.CreateObject("HotelService.IHotelViewer")

	ObjHotels.Serialize = HotelService.GetHotel(Clng(HotelID)).Serialize
	with ObjHotels.Item(1)
		HotelName	= .HotelName
		Image		= .ImageMapPath
		Star		= .Star
		Address		= .Road + ", " + .SubDistrict +", "+ .District +", "+ .City +", "+ .State +", "+ .Country+"."
		Telephone	= .Telephone		
		Description = .Description
	end with
	


%>

<br>
  <b><font color="#FF9900" class=head11><%=HotelName%></font></b><br><BR>

  <img src="<%=image%>"><br>
</p>


<!--
<table width="100%" border="0">
  <tr> 
    <td width="50%"> 
      <div align="right">Star</div>
    </td>
    <td><%=star%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Address</div>
    </td>
    <td><%=address%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Telephone</div>
    </td>
    <td><%=telephone%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Description</div>
    </td>
    <td><%=description%></td>
  </tr>
  <tr> 
    <td colspan="2"> 
      <div align="center"><a href="javascript:window.close();">Close windows</a></div>
    </td>
  </tr>
</table>
-->
<table width="95%" border="0" cellspacing=1  align=center  cellpadding=0>
  <tr bgcolor="#F0F0F0" > 
    <td class="head_1" width="232"> 
      <div align="right">Star : &nbsp; &nbsp;</div>
    </td>
    <td width="501" class="text1"><%=star%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1" width="232"> 
      <div align="right">Address : &nbsp;&nbsp;</div>
    </td>
    <td width="501"  class="text1"><%=address%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1" width="232"> 
      <div align="right">Telephone : &nbsp;&nbsp;</div>
    </td>
    <td width="501"  class="text1"><%=telephone%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1" width="232"> 
      <div align="right">Description : &nbsp;&nbsp;</div>
    </td>
    <td width="501"  class="text1"><%=description%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td colspan=2>&nbsp;</td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td colspan="2"> 
      <div align="center"><a href="javascript:window.close();" class="z1">Close 
        windows</a></div>
    </td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>
