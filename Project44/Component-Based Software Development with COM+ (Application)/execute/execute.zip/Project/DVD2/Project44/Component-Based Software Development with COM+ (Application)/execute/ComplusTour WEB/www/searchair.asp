
<HTML>
<HEAD>
<TITLE> Search AirLine </TITLE>

   <!--<script language="JavaScript" SRC="js_code.js"></Script>-->
   <link rel="stylesheet" type="text/css" href="homestyle.css" >

      <SCRIPT language=javascript src="calendar.js"></SCRIPT>
      <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
<IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1; left: 66px; top: 260px" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm"></IFRAME> 

</HEAD>


<BODY>

  	 <form method="post" action="TourSearchResultAir.asp" name='form2'>
     
  <table cellspacing=0 cellpadding=0 width="95%" border=0 align=center>
    <tr>
	 <td>
		<TABLE cellSpacing=0 cellPadding=1 width="100%" border=1 bordercolor=#F9F9F9  align="center">
		<TBODY>
		<TR>
		    <TD bgColor=#FFFFFF height=24 width="100%" align=center> 
              <div align="left"><img src="images/SearchAirline.gif" width="420" height="24"></div>
            </TD>
			<!--<TD background="images/tab.gif" align=center>
				��������ǺԹ
			</TD>-->
		</TR></TBODY>
		</TABLE>

<!--
              <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#34208b><img height=20 src="images/lt_blue_corner.gif" width=18 border=0></td>
                  <td class=rateheader align=left width=440 background="images/dk_blue_bg.gif">
				  <font color=#fefefe><b>��������ǺԹ</b></font></td>
                  <td align=right bgcolor=#34208b>
				  <img height=20 src="images/rt_blue_corner.gif" width=18 border=0></td>
                </tr>
                </tbody>
              </table>
-->
			  <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td><img height=6 src="images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor=#34208b><img height=1 src="images/1x1.gif"  width=1></td>
                </tr>
                <tr>
                  <td class=head3  bgcolor=#f0f0f0><b>&nbsp;ʶҹ����Թ�ҧ</b></td> <!--searchinstruct-->
                </tr>
                </tbody>
              </table>

         <table cellspacing=0 cellpadding=1 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#f0f0f0>

                    <table cellspacing=0 cellpadding=0 width="100%" bgcolor=#fefefe  border=0>
                      <tbody> 
                      <tr bgcolor=#fefefe width="100%"> 
                        <td width=20><img height=8 src="/images/1x1.gif" width=20></td>
                        <td width="141"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=33><img height=3 src="images\1x1(1).gif" width=1></td>
                        <td width="136"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=26><img height=3 src="images/1x1.gif" width=1></td>
                        <td class=airsearchexample3 width="132"> 
                          <p><font color="#888888"> </font></p>
                        </td>
                        <td width=1 rowspan=5><img height=3 src="images/1x1.gif" width=1></td>
                      </tr>
                      <tr> 
                        <td width=20>&nbsp;</td>
                        <td nowrap width="160" class="head5"><b>ʹ���Թ�鹷ҧ:</b></td><!-- "airFieldTitle" <font color="#34208b" >-->
                        <td colspan="4"> 
                          <div align="left"> 
                            <select name="departureAirport" class="smallform">
							<option value="YVR" selected>Vancuver(YVR)</option>
							<option value="DFW" >Dallas Fort Worth(DFW)</option>
							<option value="BKK" >Bangkok(BKK)</option>							
							<option value="CNX" >Cheng Mai(CNX)</option>							
<!--                         
'    Collection airlineCollection = airlineService.GetAllAirport();
'    Iterator iterator = airlineCollection.iterator();

-->
                            </select>
                          </div>
                        </td>
                      </tr>
                      <tr> 
                        <td width=20><img height=3 src="images/1x1.gif"  width=1></td>
                        <td width="141"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=33><img height=3 src="images/1x1.gif"  width=1></td>
                        <td width="136"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=26><img height=3 src="images/1x1.gif"   width=1></td>
                        <td width="132"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=3><img height=3 src="images/1x1.gif"  width=1></td>
                      </tr>
                      <tr> 
                        <td width=20>&nbsp;</td>
                        <td nowrap width="141" class="head5"><b>ʹ���Թ���·ҧ:</b></td>
                        <td colspan="4"> 
                          <div align="left"> 
                            <select name="destinationAirport" class="smallform">
							<option value=YVR>Vancuver(YVR)</option>
							<option value=DFW selected>Dallas Fort Worth(DFW)</option>
							<option value="BKK" >Bangkok(BKK)</option>							
							<option value="CNX" >Cheng Mai(CNX)</option>							
							
						<!--
                              
'    iterator = airlineCollection.iterator();

-->
                            </select>
                          </div>
                        </td>
                      </tr>
                      <tr> 
                        <td width=20><img height=3 src="images/1x1.gif" width=1></td>
                        <td width="141"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=33><img height=3 src="images/1x1.gif"  width=1></td>
                        <td width="136"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=26><img height=3 src="images/1x1.gif" width=1></td>
                        <td width="132"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=3><img height=3 src="images/1x1.gif" width=1></td>
                      </tr>
                      <tr bgcolor=#fefefe> 
                        <td width="20">&nbsp;</td>
                        <td class=airsearchexample3 noWrap colspan=4>&nbsp; 
					 </td><!-- "listAirport.jsp" -->
                      </tr>
                      <tr> 
                        <td width=20><img height=7 src="images/1x1.gif" width=1></td>
                        <td width="141"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=33><img height=3 src="images/1x1.gif" width=1></td>
                        <td width="136"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=26><img height=3 src="images/1x1.gif" width=1></td>
                        <td width="132"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=1><img height=3 src="images/1x1.gif" width=1></td>
                      </tr>
                      </tbody> 
                    </table>



		  </td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td><img height=6 src="images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor=#34208b><img height=1 src="images/1x1.gif"
          width=1></td>
                </tr>
                <tr>
                  <td class=head3 bgcolor=#f0f0f0><b>&nbsp;�ѹ���
                    ��������Թ�ҧ</b></td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=1 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#f0f0f0>
                    <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                      <tr>
                        <td width=20><img height=8 src="/images/1x1.gif" width=20></td>
                        <td noWrap><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=5><img height=3 src="/images/1x1.gif" width=1></td>
                        <td colspan="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td noWrap class="head5"><b>�͡�ҡʹ���Թ�鹷ҧ:</b></td>
                        <td width=5>&nbsp;</td>
                        <td noWrap colspan="7" valign="middle" class="airField"> 
				<%
					InDate = Request.Cookies("InDate")
					If Indate = "" then
					Indate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
					OutDate = Request.Cookies("OutDate")
					If OutDate = "" then
					OutDate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
				%>


				<INPUT ID=txtbox1 class="textbox" type="text" name="InDate" value='<%=InDate%>' onchange="javascript:cbfloadmefirst('form2', 'InDate');" size="13" maxlength="10">
              <a href="javascript:cbfshowcalendar('form2', 'InDate', 'txtbox1')"><img src="images/calendar.gif" width="34" height="21" border="0"></a>
						<!--
                          <select name="departureDay"  class="smallform">
							<option value=1>test1</option>
							<option value=2>test2</option>
						  
    String dateOption = null;

                          </select>
                          <select name="departureMonth"  class="smallform">
                            <option value="01" >���Ҥ�</option>
                            <option value="02" >����Ҿѹ��</option>
                            <option value="03" >�չҤ�</option>
                            <option value="04" >����¹</option>
                            <option value="05" >����Ҥ�</option>
                            <option value="06" >�Զع�¹</option>
                            <option value="07" >�á�Ҥ�</option>
                            <option value="08" >�ԧ�Ҥ�</option>
                            <option value="09" >�ѹ��¹</option>
                            <option value="10" >���Ҥ�</option>
                            <option value="11" >��Ȩԡ�¹</option>
                            <option value="12" >�ѹ�Ҥ�</option>
                          </select>
                          <select name="departureYear"  class="smallform">
                            <option value="2002" selected>2002
                            <option value="2003">2003
                          </select>
-->                          
                          <select name="departureTime" class="smallform">
						  	<option value="0" selected>����к�</option>
							<option value="00:00:00">00:00:00</option>
                            <option value="01:00:00">01:00:00</option>
                            <option value="02:00:00">02:00:00</option>
                            <option value="03:00:00">03:00:00</option>
                            <option value="04:00:00">04:00:00</option>
                            <option value="05:00:00">05:00:00</option>
                            <option value="06:00:00">06:00:00</option>
		                    <option value="07:00:00">07:00:00</option>
                            <option value="08:00:00">08:00:00</option>
                            <option value="09:00:00">09:00:00</option>
                            <option value="10:00:00">10:00:00</option>
                            <option value="11:00:00">11:00:00</option>
                            <option value="12:00:00">12:00:00</option>
                            <option value="13:00:00">13:00:00</option>
                            <option value="14:00:00">14:00:00</option>
                            <option value="15:00:00">15:00:00</option>
                            <option value="16:00:00">16:00:00</option>
                            <option value="17:00:00">17:00:00</option>
                            <option value="18:00:00">18:00:00</option>
                            <option value="19:00:00">19:00:00</option>
                            <option value="20:00:00">20:00:00</option>
                            <option value="21:00:00">21:00:00</option>
                            <option value="22:00:00">22:00:00</option>
                            <option value="23:00:00">23:00:00</option>
                          </select>   
                          </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=5 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=5><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="117"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=22><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="22"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="22"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="65"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td noWrap class="head5"><b>�͡�ҡʹ���Թ���·ҧ:</b></td>
                        <td width=5>&nbsp;</td>
                        <td colspan="7" class="airField">

				<INPUT ID="txtbox2" class="textbox" type="text" name="OutDate" value='<%=OutDate%>' onchange="javascript:cbfloadmefirst('form2', 'OutDate');" size="13" maxlength="10">
              <a href="javascript:cbfshowcalendar('form2', 'OutDate', 'txtbox2')"><img src="images/calendar.gif" width="34" height="21" border="0"></a>

<!--
						  <select name="returnDay"  class="smallform">
							<option value=1>test1</option>
							<option value=2>test2</option>
						
    dateOption = null;

                          </select>
                          <select name="returnMonth"  class="smallform">
						    <option value="01" >���Ҥ�</option>
                            <option value="02" >����Ҿѹ��</option>
                            <option value="03" >�չҤ�</option>
                            <option value="04" >����¹</option>
                            <option value="05" >����Ҥ�</option>
                            <option value="06" >�Զع�¹</option>
                            <option value="07" >�á�Ҥ�</option>
                            <option value="08" >�ԧ�Ҥ�</option>
                            <option value="09" >�ѹ��¹</option>
                            <option value="10" >���Ҥ�</option>
                            <option value="11" >��Ȩԡ�¹</option>
                            <option value="12" >�ѹ�Ҥ�</option>
                          </select>
                          <select name="returnYear"  class="smallform">
                            <option value="2002" selected>2002
                            <option value="2003">2003
                          </select>
-->
                          <select name="returnTime" class="smallform">
						  	<option value="0" selected>����к�</option>
							<option value="00:00:00">00:00:00</option>
                            <option value="01:00:00">01:00:00</option>
                            <option value="02:00:00">02:00:00</option>
                            <option value="03:00:00">03:00:00</option>
                            <option value="04:00:00">04:00:00</option>
                            <option value="05:00:00">05:00:00</option>
                            <option value="06:00:00">06:00:00</option>
		                    <option value="07:00:00">07:00:00</option>
                            <option value="08:00:00">08:00:00</option>
                            <option value="09:00:00">09:00:00</option>
                            <option value="10:00:00">10:00:00</option>
                            <option value="11:00:00">11:00:00</option>
                            <option value="12:00:00">12:00:00</option>
                            <option value="13:00:00">13:00:00</option>
                            <option value="14:00:00">14:00:00</option>
                            <option value="15:00:00">15:00:00</option>
                            <option value="16:00:00">16:00:00</option>
                            <option value="17:00:00">17:00:00</option>
                            <option value="18:00:00">18:00:00</option>
                            <option value="19:00:00">19:00:00</option>
                            <option value="20:00:00">20:00:00</option>
                            <option value="21:00:00">21:00:00</option>
                            <option value="22:00:00">22:00:00</option>
                            <option value="23:00:00">23:00:00</option>
                          </select>   
                        </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=8 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=5><img height=3 src="/images/1x1.gif" width=1></td>
                        <td colspan="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td colspan="9" class="text"><font
                  color=#888888><b>�����˵�: ��Ҥس��ͧ��õ����Թ�ҧ��������� 
                          ����ͧ�к��ѹ��� ��������Թ�ҧ�ҡʹ���Թ���·ҧ��Ѻ</b></font></td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=5 src="/images/1x1.gif" width=1></td>
                        <td colspan="9" class="searchexample"> <img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                </tbody>
              </table>
              <table border=0 cellpadding=0 cellspacing=0 width="100%">
                <tr>
                  <td><img height=6 src="/images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor="#34208B"><img height=1 src="/images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor="#F0F0F0"class=head3> <font color="#000000"><b>&nbsp;�������ͧ����ǺԹ
                    �����¡�úԹ</b> </font></td>
                </tr>
              </table>
              
        <table border=0 cellpadding=1 cellspacing=0 width=100%>
          <tr>
                  <td bgcolor="#F0F0F0">
                    <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                      <tr>
                        <td width=14><img height=8 src="/images/1x1.gif" width=20></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=20></td>
                      </tr>
                      <tr>
                        <td width=14>&nbsp;</td>
                        <td class="airFieldTitle" align="right">
                          <p><font class="head5"> ���������</font> 
                            <input type="radio" value="O" name="tripType" CHECKED>
                            <br>
                            <font class="head5"> �-��Ѻ</font> 
                            <input type="radio" value="R" name="tripType" >
                          </p>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="airFieldTitle" align="right"> <img height=3 src="/images/1x1.gif" width=50>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="head5" align="center"> 
							<b> �ӹǹ�������� </b>
						<%
								Amt = Request.Cookies("Amt")
								If Amt = "" then
								Amt = 1
								end if
						%>
                          <select name="seats" class="smallform">
                            <option value="1" <%if amt =1 then Response.Write "selected"%>>1
                            <option value="2" <%if amt =2 then Response.Write "selected"%>>2
                            <option value="3" <%if amt =3 then Response.Write "selected"%>>3
                            <option value="4" <%if amt =4 then Response.Write "selected"%>>4
                            <option value="5" <%if amt =5 then Response.Write "selected"%>>5
                            <option value="6" <%if amt =6 then Response.Write "selected"%>>6
                          </select>
                          <b>�� </b></td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td colspan=7><img height=5 src="/images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                    <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                      <tr> 
                        
                  <td width=1><img height=1 src="images/1x1.gif" width=1></td>
                        
                  <td width="116"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        
                  <td width="51"><img height=3 src="/images/1x1.gif" width=1></td>
                        
                  <td width=228><img height=3 src="/images/1x1.gif" width=1></td>
                        
                  <td width="52"><img height=3 src="/images/1x1.gif" width=1></td>
                        
                  <td width=20><img height=3 src="/images/1x1.gif" width=20></td>
                      </tr>
                      <tr> 
                        
                  <td width=1>&nbsp;</td>
                        
                  <td class="airFieldTitle" align="right" width="116"> 
                    <p><font class="head5">��¡�úԹ����ͧ���</font></p>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="airField" align="left" colspan="3"> 
                          <select name="airline" size="0" class="smallform">
                            <option value="">����к�</option>
                            <!--

    Collection allAirlineCollection = airlineService.GetAllAirline();
-->
                          </select>
                        </td>
                        
                  <td width=20>&nbsp;</td>
                      </tr>
                      <tr> 
                        
                  <td width=1>&nbsp;</td>
                        
                  <td align="right" width="116" class="head5"><b>�����������</b></td>
                        <td width=10>&nbsp;</td>
                        <td align="left" colspan="3"> 
                          <select name="class" class="smallform">
                            <option value="E" selected>Economy Class</option>
                            <option value="B">Business Class</option>
                            <option value="F">First Class</option>
                          </select>
                        </td>
                        
                  <td width=20>&nbsp;</td>
                      </tr>
                      <tr> 
                        
                  <td width=1><img height=1 src="images/1x1.gif" width=1></td>
                        
                  <td align="right" width="116"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td align="left" colspan="3"><img height=3 src="/images/1x1.gif" width=1></td>
                        
                  <td width=20><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr> 
                        
                  <td width=1>&nbsp;</td>
                        
                  <td align="right" width="116"> 
                    <input type="checkbox" name="window" value="true">
                        </td>
                       <td width=10>&nbsp;</td>
                        <td class="text" align="left" colspan="3">��������˹�ҵ�ҧ</td>
                        
                  <td width=20>&nbsp;</td>
                      </tr>
                      <tr> 
                        
                  <td width=1>&nbsp;</td>
                        
                  <td align="right" width="116"> 
                    <input type="checkbox" name="smoking" value="true">
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="text" align="left" colspan="3">������ٺ������</td>
                        
                  <td width=20>&nbsp;</td>
                      </tr>
                      <tr> 
                        
                  <td width=1>&nbsp;</td>
                        
                  <td align="right" width="116"> 
                    <input type="checkbox" name="directFlight" value="true">
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="text" align="left" colspan="3">����ͧ��õ������ǺԹ</td>
                        
                  <td width=20>&nbsp;</td>
                      </tr>
                      <tr> 
                        
                  <td width=1>&nbsp;</td>
                        
                  <td width="116">&nbsp;</td>
                        <td width=10>&nbsp;</td>
                        <td class="text" align="left" colspan="3"> <font color="#888888"> 
                          <b> ������͡������͡��� �Ҩ�����ӹǹ������͡Ŵ����ŧ</b> 
                          </font> </td>
                        
                  <td width=20>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td colspan=7><img height=5 src="/images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr bgcolor="#FEFEFE">
                        <td align="right"><img height=1 src="/images/1x1.gif" width=450></td>
                        <td><img height=1 src="images/1x1.gif" width=1></td>
                      </tr>
					  
                      <tr bgcolor="#FEFEFE">
                        <td align="right">
                          <input type="submit" name="submitted" value="��������ǺԹ" class="button" >
                          &nbsp; </td> <!--style="border-bottom:thin solid #000000
      ;border-right:thin solid #000000;border-top:thin solid
      #D7D7D7;border-left:thin solid #D7D7D7;background-color:#34208B;color:#FFFFFF"-->
                        <td><img height=1 src="images/1x1.gif" width=1></td>
                      </tr>
                      <tr bgcolor="#FEFEFE">
                        <td align="right"><img height=5 src="/images/1x1.gif" width=3></td>
                        <td><img height=1 src="images/1x1.gif" width=1></td>
                      </tr>
                    </table>
	</td></tr></table>
     </td>
	 </tr>
	</table>
	</form>
</BODY>
</HTML>
