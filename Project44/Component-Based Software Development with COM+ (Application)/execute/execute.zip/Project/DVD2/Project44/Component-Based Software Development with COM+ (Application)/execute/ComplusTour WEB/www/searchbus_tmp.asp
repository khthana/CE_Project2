<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Search Bus </TITLE>
	    <META http-equiv=Content-Type content="text/htm; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
</HEAD>

<BODY>

<br><br>
<h2 class=head1 align=center>�ѧ������ </h2>


</BODY>
</HTML>
