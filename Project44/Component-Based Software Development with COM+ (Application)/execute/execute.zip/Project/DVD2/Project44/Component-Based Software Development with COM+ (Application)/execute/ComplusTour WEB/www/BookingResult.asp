<HTML>
<HEAD>
<TITLE> Summary Reserve OlalaTour.com </TITLE>
	    <META http-equiv=Content-Type content="text/htm; charset=windows-874">
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>

<BODY BGCOLOR="#FFFFFF">
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=350,height=350');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=350,height=350');
}

function openPopupPackageDetail(PackageID,DepartDate) {
  popupInformWin = window.open('PopupPackageDetail.asp?PackageID=' + PackageID + '&Departdate=' + DepartDate,'remote','scrollbars,resizable,width=360,height=350');
  //popupInformWin = window.open('PopupPackageDetail.asp?packageID=21&Departdate=20/5/2545','remote','scrollbars,resizable,width=360,height=270');  
}
function openPopupTraveller(BookingID,ItemNo) {
	popupInformWin = window.open('PopupTraveller.asp?BookingID=' + BookingID + '&ItemNo=' + ItemNo,'remote','scrollbars,resizable,width=360,height=270');
	//popupInformWin = window.open('index.asp','remote',
}
-->
</script>


<!--form name="confirm_reserve" action="thankyou.htm" method="post"-->
<TABLE width="95%" Border="0" align=center>
  <TBODY> 
  
	 
      <%
	'on error resume next
'	dim objBookingService
	
	
	
	'==========================================
		'set objBookingFac = server.CreateObject("DALDB.CBookingFactory")
		'set IBookViewer = server.CreateObject("TourBookingService.IBookViewer")
		'set objBooking = IBookViewer.GetBooking(cint(CustomerID))
		'set IBookViewer = nothing
		'objBookingFac.Serialize = objBooking.Serialize
		
		'for i =1 to objBookingFac.Count
		'	if objBookingFac.Item(i).TotalPrice = 0 then
		'		set IBookManager = server.CreateObject("TourBookingService.IBookManager")
		'			Boo = IBookManager.CancelAllBooking(cint(objBookingFac.Item(i).BookingID))
		'		set IBookManager = nothing
		'		Response.Write "CalcelAllBooking " & i & " = " & Boo & "<br>"
 		'	end if
		'next
	
	'==========================================
	
	dim IBookViewer
	dim objBookingFactory
	dim objBooking
	dim i,j
		
		CustomerID = Request.Cookies("TourCustomerID")
		
		set objBookingFactory = server.CreateObject("DALDB.CBookingFactory")
		set IBookViewer = Server.CreateObject("TourBookingService.IBookViewer")
on error resume next		
		set objBooking = IBookViewer.GetBooking(Clng(CustomerID))
		'set IBookViewer = nothing
		objBookingFactory.Serialize = objBooking.Serialize
	
	
	'======================Begin test========================
		'set objBookingFac = server.CreateObject("DALDB.CBookingFactory")
		'set IBookViewer = server.CreateObject("TourBookingService.IBookViewer")
		'set objBooking = IBookViewer.GetBooking(cint(CustomerID))
		' Response.Write objbooking.item(1).HotelBookingID
		'objBookingFactory.Serialize = objBooking.Serialize
'		for i = 1 to objBookingFactory.Count
			'if BookingID = objBookingFactory.Item(i).BookingID then 
'				HasPackage = false
'				HasHotel = false
'				HasAir = false
'				HasBus = false
				
				
				'======================Hotel===========================
				
'				if objBookingFactory.Item(i).HotelBookingID = 0 then
'					HasHotel = true
'				else	
'					Response.Write "HotelBookingID=" & objBookingFactory.Item(i).HotelBookingID & "<br>"
'					err.number = 0
'					set objHotelBooking.serialize = IBookViewer.GetHotelBookingDetail(cint(objBookingFac.Item(i).HotelBookingID)).Serialize
'					if err.number <> 0 or objHotelBooking is nothing or objHotelBooking.count = 0 then
'						HasHotel = true
'					end if
'				end if
				'=====================Bus========================
'				if objBookingFactory.Item(i).BusBookingID = "0" then
'					HasBus = true
'				else
'					err.number = 0
'					'set objBusBookingFac = server.CreateObject("DALDB.C")
'					set objBusBooking = IBookViewer.ViewBusBookinginfo(cstr(objBookingFac.Item(i).BusBookingID))
'					
'					if err.number <> 0 or objBusBooking is nothing then
'						HasBus = true
'					end if
'				end if
				'=====================Air=======================
'				if objBookingFactory.Item(i).AirLineBookingID = "0" then
'					HasAir = true
'				else
'					err.number = 0
'					set objAirBooking = IBookViewer.ViewAirlineBookinginfo(cstr(objBookingFac.Item(i).AirLineBookingID))
'					if err.number <> 0 or objAirBooking is nothing then
'						HasAir = true
'					end if
'				end if
'			
			'=====================Package================================
'				on error resume next
'				err.number = 0
'				set objPackageBooking = IBookViewer.GetPackageBooking(cint(BookingID))
'				'on error goto 0
'				Response.Write "err.number=" & err.number & "<br>"
'				if err.number <> 0  then 'or objPackageBooking is nothing or objPackageBooking.count = 0 then
'					HasPackage = true
'				end if
			
'			set IBookViewer = nothing
			
			'set IBookManager = nothing
			'set IBookManager = server.CreateObject("TourBookingService.IBookManager")
'				boo = false
				'if HasPackage and HasHotel and HasBus and HasAir then
					'Response.Write "CancelAllBooking<BR>"
					'Response.Write "BookingID=" & BookingID & "<BR>"
					'on error goto 0
					'boo = IBookManager.CancelAllBooking(cint(BookingID))
				'end if
			'set IBookManager = nothing
			'end if 'BookingID
'		next 'i
		
		'Response.Write "HasPackage=" & HasPackage & "<br>"
		'Response.Write "HasHotel=" & HasHotel & "<br>"
		'Response.Write "HasBus=" & HasBus & "<br>"
		'Response.Write "HasAir=" & HasAir & "<BR>"
		'Response.Write "CancelBooking=" & boo
		
'		Response.Redirect("BookingResult.asp")
		'Response.Write ItemArr		
	
	'=====================end test==========================
	
	if not ( VarType(objBooking) = 0 ) then
		
%>

     
     <TR>
		
    <TD colspan=2 height="54"> 
      <div align="center"><b><font color="#FF0000">��������´��èͧ</font></b> 
      </div>
    </TD>
	</TR>
     
     
     
     
     
     
<%	k = 0
	for i = 1 to objBookingFactory.Count
		
'===========================begin test==============
'		Response.Write "----------------------------------------------"
'		HasPackage = false
'		HasHotel = false
'		HasAir = false
'		HasBus = false
				
				
		'======================Hotel===========================
'		Response.Write "HotelBookingID=" & objBookingFactory.Item(i).HotelBookingID & "<br>"
'		if objBookingFactory.Item(i).HotelBookingID <> 0 then
'			HasHotel = true
'		else	
			'Response.Write "HotelBookingID=" & objBookingFactory.Item(i).HotelBookingID & "<br>"
'			on error resume next
'			err.number = 0
'			set objHotelBooking.serialize = IBookViewer.GetHotelBookingDetail(cint(objBookingFactory.Item(i).HotelBookingID)).Serialize
'			if err.number = 0 then 'or not(objHotelBooking is nothing) or objHotelBooking.count > 0 then
'				HasHotel = true
'			end if
'			on error goto 0
'		end if
		'=====================Bus========================
'		if trim(objBookingFactory.Item(i).BusBookingID) = "0" then
'			Response.Write "BusBookingID not equal 0<BR>"
'			HasBus = true
'		else
'			on error resume next
'			err.number = 0
'			'set objBusBookingFac = server.CreateObject("DALDB.C")
'			set objBusBooking = IBookViewer.ViewBusBookinginfo(cstr(objBookingFactory.Item(i).BusBookingID))
'					
'			if err.number = 0 then 'or not(objBusBooking is nothing) then
'				Response.Write "BusErr.number=0<BR>"
'				Response.Write "objBusBooking" & vartype(objBusBooking)
'				HasBus = true
'			end if
'			on error goto 0
'		end if
'		'=====================Air=======================
'		if trim(objBookingFactory.Item(i).AirLineBookingID) <> "0" then
'			HasAir = true
'		else
'			on error resume next
'			err.number = 0
'			set objAirBooking = IBookViewer.ViewAirlineBookinginfo(cstr(objBookingFactory.Item(i).AirLineBookingID))
'			if err.number = 0 then 'or not(objAirBooking is nothing) then
'				HasAir = true
'			end if
'			on error goto 0
'		end if
'			
'		'=====================Package================================
'		on error resume next
'		err.number = 0
'		
'		set objPackageBooking = IBookViewer.GetPackageBooking(cint(BookingID))
'		'on error goto 0
'		'Response.Write "err.number=" & err.number & "<br>"
'		if err.number = 0  then 'or objPackageBooking is nothing or objPackageBooking.count = 0 then
'			HasPackage = true
'		end if
'		on error goto 0
'		set IBookViewer = nothing
'			
'			'set IBookManager = nothing
'			'set IBookManager = server.CreateObject("TourBookingService.IBookManager")
'		'boo = false
'	
'		Response.Write "HasPackage" & i & "=" & HasPackage & "<br>"
'		Response.Write "HasHotel" & i & "=" & HasHotel & "<br>"
'		Response.Write "HasBus" & i & "=" & HasBus & "<br>"
'		Response.Write "HasAir" & i & "=" & HasAir & "<BR>"
'		Response.Write "<BR>"
'		
'	if HasPackage or HasHotel or HasBus or HasAir then	
'		
'
'		
'===============================end test=======================		


'=============================================================		
if objBookingFactory.Item(i).TotalPrice > 0 then		
		
		k = k+1
		
		
		
'=============================================================		
		HotelTotalPrice = 0
		BusTotalPrice = 0
		AirlineTotalPrice = 0
		PackageTotalPrice = 0
		IsConfirm = objBookingFactory.Item(i).Confirmation
%>	
<form name="Confirm_Del_TourBooking" action="ConfirmDelTourBooking.asp" method="POST">

	<tr align=center> 
      <td colspan=2 ><b> <font color="#006699">��¡�÷�� <%=k%></font></b></td> 
	</tr>	  
	<tr> 
      <td colspan=2 class="text" height="21"> <font color="#006699">
        <%if IsConfirm = True then%>
        ��¡�õ��仹���׹�ѹ��Ъ����Թ���º�������� 
        <%else%>
        ��س��׹�ѹ��Ъ����Թ��¡�õ��仹�������ѹ���&nbsp; <%=objBookingFactory.Item(i).ConfirmDeadline%> 
        <%end if%>
        </font> </td>
    </tr>
        <%	'======================Hotel====================================
		HotelBookingID = 0
		HotelBookingID = cint(objBookingFactory.Item(i).HotelBookingID)	
		HotelDetailCount = 0
		'Response.Write "HotelBookingID" & HotelBookingID & "<br>"
		if HotelBookingID <> 0 then
			dim TourBookingService
			'dim objHotelBookingFac
			dim objHotelBookingDetailFac	
			

			set objHotelBookingDetailFac = server.CreateObject("DALDB.CHotelBookingDetailFactory")
			'Response.Write "HotelBookingID = " & HotelBookingID
		set TourBookingService = server.CreateObject("TourBookingService.IBookViewer")
			set tmp = TourBookingService.GetHotelBookingDetail(cint(HotelBookingID))
		set TourBookingService = nothing
			objHotelBookingDetailFac.Serialize = tmp.serialize
			'set objHotelBookingDetailFac = tmp
			'set objHotelBookingFac = server.CreateObject("DALDB.CHotelBookingFac")
			'set objHotelBookingFac = TourBookingService.GetHotelBooking(

		
		HotelDetailCount = objHotelBookingDetailFac.Count
		'Response.Write "HotelCount=" & HotelDetailCount & "<br>"
		'Response.Write "HotelDetailCount=" & HotelDetailCount
		if HotelDetailCount > 0 then
		
%>
		

	<tr > 
      <td colspan=2  bgcolor="#DFDFDF"> <font color="#006699" size="-1">��¡�èͧ�ç���</font> 
      </td> 
    </tr>	
	
    <tr>
      <td colspan=2> 
        <table width="100%" Border="0" cellspacing="1" cellpadding="0" align="center">
          <tr align=center bgcolor="#006699" height="20"> 
            <th width="5%"  ><b><font color="#FFFFFF" size="-1"> ź </font></b></th>
            <th width="8%"   ><b><font color="#FFFFFF" size="-1"> ��¡�� </font></b></th>
            <th width="22%" ><b><font color="#FFFFFF" size="-1"> �ѹ�ѡ </font></b></th>
            <th width="25%" ><b><font color="#FFFFFF" size="-1"> �ç���</font></b></th>
            <th width="25%" ><b><font color="#FFFFFF" size="-1"> ��ͧ�ѡ </font></b></th>
            <th width="15%" ><b><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ) </font></b></th>
          </tr>
          <input type="hidden" name="HotelBookingID" value=<%=HotelBookingID%> >
          <%			
			 
			'HotelTotalPrice = 0
			'Response.Write "HotelCnt=" & objHotelBookingDetailFac.Count
			for j = 1 to objHotelBookingDetailFac.Count
				HotelTotalPrice = HotelTotalPrice + objHotelBookingDetailFac.Item(j).BookingPrice
%>
          <tr align=center  <%  if J mod 2 = 0 then Response.Write "bgcolor=#EEEEEE" %>> 
            <td algin=center class="text1"> 
              <%
			if IsConfirm = false then
%>
              <input type="checkbox" name="HotelDelItem" value="<%=objHotelBookingDetailFac.Item(j).ItemNo%>">
              <%			end if
%>
            </td>
            <td algin=center class="text1"> <%=j%> </td>
            <td  algin=center class="text1"><%=objHotelBookingDetailFac.Item(j).BookCheckIn %> 
              - <%=objHotelBookingDetailFac.Item(j).BookCheckOut%></td>
            <td  algin=center class="text1"><a href="javascript:openViewHotelWindow('<%=objHotelBookingDetailFac.Item(j).HotelID%>')"><%=objHotelBookingDetailFac.Item(j).HotelName%></a> 
            </td>
            <td algin=center class="text1"> <a href="javascript:openViewRoomModelWindow('<%=objHotelBookingDetailFac.Item(j).RoomModelID%>')"><%=objHotelBookingDetailFac.Item(j).RoomModelName%></a> 
            </td>
            <td algin=center class="text1"> <%=objHotelBookingDetailFac.Item(j).BookingPrice%> 
            </td>
          </tr>
          <%		
			next 'j
%>
          <tr  height="25" valign=bottom> 
            <td colspan="5" align=right ><b><font size="-1" color="#0D549B">�Ҥ����������</font></b> 
            </td>
            <th> <font  size="-1" color="#FF0000"><%=HotelTotalPrice%></font> 
            </th>
          </tr>
        </table>
		</td>
		</tr>
<%		end if 'HotelDetailCount > 0
		end if 'HotelBookingID <> 0
	
'=============================Airline================================		
	AirBookingID = "0"
	AirBookingID = trim(cstr(objBookingFactory.Item(i).AirLineBookingID))


	if AirBookingID <> "0" then
		err.number = 0 
		set TourBookingService = server.CreateObject("TourBookingService.IBookViewer")
		set objAirlineBookInfos = TourBookingService.ViewAirlineBookinginfo(cstr(AirBookingID))
		set TourBookingService = nothing	
	'	Response.Write "airtyype=" & VarType(objReserveAirlines)	
		'Response.Write err.Description
		if err.number = 0 and objAirlineBookInfos.count <> 0 then
			AirCnt = objAirlineBookInfos.Count
	'		Response.Write "Count=" & objAirlineBookInfos.Count & "<br>"
		else
			AirCnt = 0
		end if
'		Response.Write "�ըӹǹ��¡��==" & cnt
		
		'Response.Write "AirCnt=" & AirCnt & "<br>"
		if AirCnt > 0 then
%>
	<tr>
		<td colspan=2">

        <table width="100%" Border="0" cellspacing="1">
          
          <tr bgcolor="#DFDFDF" > 
            <td colspan=8 > <font color="#006699" size="-1">��¡�èͧ��������ͧ�Թ</font> 
            </td>
          </tr>
          <tr align=center bgcolor="#006699"  height="20"> 
            <th width="5%" ><font color="#FFFFFF" size="-1"> ź </font></th>
            <th width="10%"><font color="#FFFFFF" size="-1"> ����ǺԹ </font></th>
            <th width="14%"> <font color="#FFFFFF" size="-1"> 
              <!--"12%"-->
              �鹷ҧ </font></th>
            <th width="14%" > <font color="#FFFFFF" size="-1"> 
              <!--"12%"-->
              ���·ҧ </font></th>
            <!--th width="14%" > �ѹ�Թ�ҧ </th-->
            <th width="15%" > <font color="#FFFFFF" size="-1"> 
              <!--10%-->
              �����͡ </font></th>
            <th width="15%" > <font color="#FFFFFF" size="-1"> 
              <!--10%-->
              ���Ҷ֧ </font></th>
            <th width="12%" ><font color="#FFFFFF" size="-1"> �ӹǹ(��) </font></th>
            <th width="15%" ><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ) </font></th>
          </tr>
          <input type="hidden" name="AirBookingID" value=<%=AirBookingID%>>
          <%
		'dim AirlineTotalPrice
		'AirlineTotalPrice = 0
    	For j = 1 To AirCnt'objReserveAirlines.Count
		
		AirlineTotalPrice = AirlineTotalPrice + (objAirlineBookInfos.Item(j).Price * objAirlineBookInfos.Item(j).TotalSeat)
		
%>
          <tr  class="text1" align=center <%  if j mod 2 = 0 then Response.Write "bgcolor=#EEEEEE" %> > 
            <td  class="text1"> 
              <% if IsConfirm = false then    
	 %>
              <input type="checkbox" name="AirlineDelItem" value="<%=objAirlineBookInfos.Item(j).ItemNo%>">
              <% end if %>
            </td>
            
            <td > <%=objAirlineBookInfos.Item(j).FlightID%></td>
            <td><%=objAirlineBookInfos.Item(j).AirportsrcName%></td>
            <td ><%=objAirlineBookInfos.Item(j).AirportdesName%></td>
            <!--<td ><%=objAirlineBookInfos.Item(j).DepartDate%></td>-->
            <td ><%=objAirlineBookInfos.Item(j).DepartDateTime%></td>
            <td ><%=objAirlineBookInfos.Item(j).ArriveDateTime%></td>
            <td ><%=objAirlineBookInfos.Item(j).TotalSeat%></td>
            <td ><%=objAirlineBookInfos.Item(j).Price * objAirlineBookInfos.item(j).TotalSeat%></td>
          </tr>
          <% next 'j  %>
          <tr  height="25" valign=bottom> 
            <td colspan="7" align=right ><b><font size="-1" color="#0D549B">�Ҥ����������</font></b> 
            </td>
            <th> <font  size="-1" color="#FF0000"><%=AirlineTotalPrice %></font> 
            </th>
          </tr>
        </table>
  </td></tr>
        <% end if %>
        <%
	end if

'=============================BUS================================		
'on error goto 0
	BusBookingID = "0"
	BusBookingID = trim(cstr(objBookingFactory.Item(i).BusBookingID))
	
	if BusBookingID <> "0" then
		err.number	= 0
		set TourBookingService = server.CreateObject("TourBookingService.IBookViewer")
		set objBusBookInfos = TourBookingService.ViewBusBookinginfo(cstr(BusBookingID))
		set TourBookingService = nothing	
	'	Response.Write "airtyype=" & VarType(objReserveAirlines)	
		if err.number = 0 and not(objBusBookInfos is nothing) then
			BusCnt = objBusBookInfos.Count
		else
			BusCnt = 0
		end if
'		Response.Write "�ըӹǹ��¡��==" & cnt
		if BusCnt > 0 then
%>
  <tr>
      <td colspan=2>
	  
	    <table width="100%" border="0" cellspacing="1">
          
          <tr bgcolor="#DFDFDF" > 
            <td colspan=8 > <font color="#006699" size="-1">��¡��ö�����</font></td>
          </tr>
          <tr align=center bgcolor="#006699" height="20"> 
            <th width="5%" height="16" ><font color="#FFFFFF" size="-1"> ź </font></th>
            <th width="10%" height="16" ><font color="#FFFFFF" size="-1"> �����ö 
              </font></th>
            <th width="14%" height="16" ><font color="#FFFFFF" size="-1"> �鹷ҧ 
              </font></th>
            <th width="14%" height="16" ><font color="#FFFFFF" size="-1"> ���·ҧ 
              </font></th>
            <!--<th width="14%" > �ѹ�Թ�ҧ </th>-->
            <th width="15%" height="16" ><font color="#FFFFFF" size="-1"> �����͡ 
              </font></th>
            <th width="15%" height="16" ><font color="#FFFFFF" size="-1"> ���Ҷ֧ 
              </font></th>
            <th width="12%" height="16" ><font color="#FFFFFF" size="-1"> �ӹǹ(��) 
              </font></th>
            <th width="15%" height="16" ><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ) 
              </font></th>
          </tr>
          <input type="hidden" name="BusBookingID" value=<%=BusBookingID%>>
          <%
		'dim BusTotalPrice
		'BusTotalPrice = 0
    	For j = 1 To BusCnt'objReserveAirlines.Count
		
		BusTotalPrice = BusTotalPrice + (objBusBookInfos.Item(j).Price * objBusBookInfos.Item(j).TotalSeat)
		
%>
          <tr  class="text1"  align=center <%  if j mod 2 = 0 then Response.Write "bgcolor=#EEEEEE" %> > 
            <td  > 
              <% if IsConfirm = false then    
	 %>
              <input type="checkbox" name="BusDelItem" value="<%=objBusBookInfos.Item(j).ItemNo%>">
              <% end if %>
            </td>
            <td ><%=objBusBookInfos.Item(j).RouteID%></td>
            <td ><%=objBusBookInfos.Item(j).StationsrcName%></td>
            <td ><%=objBusBookInfos.Item(j).StationdesName%></td>
            
            <td ><%=objBusBookInfos.Item(j).DepartDateTime%></td>
            <td ><%=objBusBookInfos.Item(j).ArriveDateTime%></td>
            <td ><%=objBusBookInfos.Item(j).TotalSeat%></td>
            <td ><%=objBusBookInfos.Item(j).Price * objBusBookInfos.Item(j).TotalSeat%></td>
          </tr>
          <% next 'j  %>
          <tr  height="25" valign=bottom> 
            <td colspan="7" align=right ><b><font size="-1" color="#0D549B">�Ҥ����������</font></b> 
            </td>
            <th> <font  size="-1" color="#FF0000"><%=BusTotalPrice %></font> </th>
          </tr>
        </table>
	  
	   </td>
	</tr>
      <% end if %>

<%
	end if
	

%>




<%	'=====================PackageTour================================		
 'on error resume next
	dim objPackageBookingFactory
	dim objPackageBooking
		set objPackageBookingFactory = Server.CreateObject("DALDB.CPackageBookingFactory")
		
		err.number = 0
		
		set objBookingService = server.CreateObject("TourBookingService.IBookViewer")
		on error resume next
		set objPackageBooking = objBookingService.GetPackageBooking(cint(objBookingFactory.Item(i).BookingID))	
		set objBookingService = nothing
		
		if err.number = 0 then
			objPackageBookingFactory.Serialize = objPackageBooking.Serialize
			PackageCount = objPackageBookingFactory.Count
		else
			PackageCount = 0
		end if
		
		'Response.Write "BookingID=" & objBookingFactory.Item(i).BookingID & "<br>"
		'Response.Write "PackageCount=" & PackageCount & "<br><br>"
		
		on error goto 0
		'Response.Write " PackageBookingFactory=" & objPackageBookingFactory.Count
	'if not objPackageBookingFactory is nothing then
	'Response.Write "PackageCount=" & objPackageBookingFactory.Count
	if PackageCount > 0 then	
		'Response.Write "   PackageBookingFactory   " 
		dim objTourService
		'find PackageName from PackageID
		dim objPackageFactory
		dim objPackage
		'find number of traveller from packageid and itemno
		dim objPackageBookingDetailFactory
		dim objPackageBookingDetail
		set objPackageFactory = Server.CreateObject("DALDB.CPackageFactory")
		set objPackageBookingDetailFactory = server.CreateObject("DALDB.CPackageBookingDetailFactory")
		'for PackageName of each PackageID (j loop)
		'PackagetotalPrice = 0
		'on error resume next
'		Response.Write "Count=" & objPackageBookingFactory.Count
		
%>		
	
	<tr>
	<td colspan=2>
<%	if PackageCount > o then
%>			
        <table width="100%" Border="0" cellspacing="1" cellpadding="0">
          
          <tr bgcolor="#DFDFDF" > 
            <td colspan=9 > <font color="#006699" size="-1">��¡�èͧ���稷����</font></td>
          </tr>
          <!--	
					<tr bgcolor=#e6e6fa class="head3" align=center> 
						<td width="3%">ź</td>
						<td width="7%">��¡�÷��</td>
						<td width="12%">��¡����ࡨ�����</td>
						<td width="21%">�ѹ�͡�Թ�ҧ</td>
						<td width="44%">�ӹǹ����Թ�ҧ</td>
						<td width="13%">�Ҥ���� (�ҷ)</td>
					</tr>-->
          <tr align=center bgcolor="#006699" height="20"> 
            <th width="5%" ><font color="#FFFFFF" size="-1"> ź </font></th>
            <th width="10%" ><font color="#FFFFFF" size="-1"> ��¡�÷�� </font></th>
            <th width="25%" ><font color="#FFFFFF" size="-1"> ��¡�����稷���� 
              </font></th>
            <th width="25%" ><font color="#FFFFFF" size="-1"> �ѹ�͡�Թ�ҧ </font></th>
            <th width="20%" ><font color="#FFFFFF" size="-1"> �ӹǹ����Թ�ҧ 
              </font></th>
            <th width="15%" ><font color="#FFFFFF" size="-1"> �Ҥ�(�ҷ)</font></th>
          </tr>
          <%		for j = 1 to objPackageBookingFactory.Count
						
						set objTourService = Server.CreateObject("TourService.IPackageViewer")	
						set objPackage = objTourService.GetPackage(objPackageBookingFactory.Item(j).PackageID)
						set objTourService = nothing
						
						set objPackageFactory = Server.CreateObject("DALDB.CPackageFactory")
						objPackageFactory.Serialize = objPackage.Serialize	
						'PackageName from Package
						PackageName = objPackageFactory.Item(1).PackageName
						PackageID = objPackageFactory.item(1).PackageID
						'BookingPrice from PackageBooking
						BookingPrice = objPackageBookingFactory.Item(j).BookingPrice
						DepartDate = objPackageBookingFactory.Item(j).DepartDate
						BookingID = objPackageBookingFactory.Item(j).BookingID
						ItemNo = objPackageBookingFactory.Item(j).ItemNo
						PackageTotalPrice = PackageTotalPrice + BookingPrice
						'for NumOfTraveller of each packageBooking 
'==================================objBookingService
						set objBookingService = server.CreateObject("TourBookingService.IBookViewer")
						set objPackageBookingDetail = objBookingService.GetPackageBookingDetail(objPackageBookingFactory.Item(j).BookingID,objPackageBookingFactory.Item(j).ItemNo)
						set objBookingService = nothing
						
						set objPackageBookingDetailFactory = server.CreateObject("DALDB.CPackageBookingDetailFactory")
						
						objPackageBookingDetailFactory.Serialize = objPackageBookingDetail.serialize
						'NumOfTraveller
						
						NumOfTraveller = objPackageBookingDetailFactory.Count
						
						
					
			%>
          <tr class="text1" align=center  <%  if J mod 2 = 0 then Response.Write "bgcolor=#EEEEEE" %>> 
            <td> 
              <%
					if IsConfirm = false then
						'Response.Write "PackageBookingFactory=" & objPackageBookingFactory.Item(j).ItemNo
			%>
              <input type="checkbox" name="DelPackageBooking" value=<%=objPackageBookingFactory.Item(j).ItemNo%>>
              <%		end if
			%>
            </td>
            <td><%=j%></td>
            <td><a href="javascript:openPopupPackageDetail('<%=PackageID%>','<%=DepartDate%>')"><%=PackageName%></a></td>
            <td><a href="javascript:openPopupPackageDetail('<%=PackageID%>','<%=DepartDate%>')"><%=DepartDate%></a></td>
            <td><a href="javascript:openPopupTraveller('<%=BookingID%>','<%=ItemNo%>')"><%=NumOfTraveller%></a></td>
            <td><%=BookingPrice%></td>
          </tr>
          <%		next 'j
				
				
			%>
          <tr  height="25" valign=bottom> 
            <td colspan="5" align=right ><b><font size="-1" color="#0D549B">�Ҥ����������</font></b> 
            </td>
            <th> <font  size="-1" color="#FF0000"><%=PackageTotalPrice%></font> 
            </th>
          </tr>
        </Table>
			<%	end if 'if objPackageBookingFactory.count <> 0
				end if 'if not ( VarType(objBooking) = 0 ) then
				TotalPrice = HotelTotalPrice + BusTotalPrice + AirlineTotalPrice + PackageTotalPrice 
			%>	
			
						
			<!--   END ALL LOOP J   -->
			</td></tr>


				
			   <tr>
					
      <td align=right bgcolor="#CCCCCC" width="85%"><b><font color="#006699">�Ҥ�����ء��¡��</font></b></td>
					
      <th align=center  bgcolor="#CCCCCC"  width="15%"><font  color="#FF0000"><%=TotalPrice%></font></th>
			   </tr>
			
				<tr><td colspan=2 height=20 valign=bottom>&nbsp; </td></tr>
			
			<%		If IsConfirm = false then
			%>      <tr> 
					  <td  align=center colspan="6"> 
						<input type=submit name="TourBooking" value="�ӹǳ�Ҥ�����" class="buttonbox">
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type=submit name="TourBooking" value="�׹�ѹ��èͧ" class="buttonbox">
						<input type="hidden" name="BookingID" value="<%=objBookingFactory.Item(i).BookingID%>">
						<input type="hidden" name="Price" value="<%=TotalPrice%>" >
					  </td>
					</tr>
			<%      end if
			%>      

		   <tr>		
      <td colspan=2>&nbsp; </td>
    </tr>
   </form>
<%
	'end if 'if HasPackage and HasHotel and HasBus and HasAir then
	end if 'objBookingFactory.Item(i).TotalPrice = 0
	next 'i
	else 'if not objBookingFactory is nothing 
		Response.Write "<BR><div class='head21' align=center> ��й�� �س�ѧ��������¡�èͧ </div>"
	end if
%>
 <!--  </td>
  </tr>
 --> 	
	
</TBODY>

</TABLE>
<!--/form-->
</BODY>
</HTML>
