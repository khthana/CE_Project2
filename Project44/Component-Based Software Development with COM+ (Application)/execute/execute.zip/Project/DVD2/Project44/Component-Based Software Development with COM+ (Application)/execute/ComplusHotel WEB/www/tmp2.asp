<%@ Language=VBScript %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>

<BODY>

<P>&nbsp;</P>
<%
	dim HotelID,RoomModelID,BookCheckIn,BookCheckOut,AmountOfRoom
	dim basketID
	DIM OBJECTBASKET
	set objBasket = server.CreateObject("BookingService.IBasket")
	set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
	set objReserveHotel = Server.CreateObject("DALDB.CReserveHotelDetail")
	set util = server.CreateObject("ComplusUtil.IUtility")
	
	'get Input 
	HotelID =  Request.QueryString.Item("HotelID")
	RoomModelID = Request.QueryString.Item("RoomModelID") 
	BookCheckIn = request.QueryString.Item("BookCheckIn")
	BookCheckOut =  Request.QueryString.Item("BookCheckOut")
	AmountOfRoom =  Request.QueryString.Item("AmountOfRoom")

	Response.Write Request.Cookies("BasketID")
	
	' call method
	'basketID = objBasket.CreateBasket

	set objReserveHotel = objReserveHotels.AddNew
	with objReserveHotel
		.HotelID = HotelID
		.RoomModelID = RoomModelID
		.BookCheckIn = BookCheckIn
		.BookCheckOut = BookCheckOut
		.AmountOfRoom = AmountOfRoom
		.BookingPrice = 
	end with

	basketid =1
	'objbasket.AddBasketItem cint(basketid),util.ConvertToOBj(objReserveHotel)
	set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")	
	objReserveHotels.Serialize = objbasket.ViewBasket(1).Serialize
	dim i
    For i = 1 To objReserveHotels.internalCRecocdset.RowCount
        With objReserveHotels.Item(i)
			Response.Write "HotelID=" & .HotelID & "RoomModel=" &  .RoomModelID & .BookCheckIn & .BookCheckOut & "<br>"
        End With
    Next



%>

Country : <%=Country%> <BR>
state :<%=state%> <BR>
city :<%=city%> <BR>
HotelName :<%=HotelName%> <BR>
star : <%=star%> <br>
MinStar :<%=MinStar%> <BR>
MaxStar :<%=MaxStar%> <BR>
RoomType :<%=RoomModelName%> <BR>
PriceRate : <%=Pricerate%> <br>
MinPrice :<%=MinPrice%> <BR>
MaxPrice :<%=MaxPrice%> <BR>
In :<%=CheckInDate%> <BR>
Out :<%=CheckOutDate%> <BR>
Amount :<%=AmountOfRoom%> <BR>

</BODY>
</HTML>
