<%

x = instr( 0, "b", "abcd")

response.write x
%>