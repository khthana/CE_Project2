<HTML>
<HEAD>
<TITLE> Summary Basket OlalaTour.com </TITLE>
	    <META http-equiv=Content-Type content="text/htm; charset=windows-874">	    
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>

<BODY BGCOLOR="#FFFFFF">
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>
<%
'	on error resume next
	Response.Cookies("InDate") = Request.Form("InDate")
	Response.Cookies("OutDate") = Request.Form("OutDate")
	Response.Cookies("Amt") = Request.Form("seats")


'========================search Air RoundTrip=============================
	
	'departureAirportID 
	tmpA= request.form("departureAirport")
	'destinationAirportID 
	tmpB= request.form("destinationAirport")
'Response.Write tmpA & "<br>"
'Response.Write tmpb & "<br>"
	tmpX =	Split(tmpA,",")
	tmpY = 	Split(tmpB,",")

	departureAirportID = tmpX(0)
	destinationAirportID  = tmpY(0)
	FromCountry = tmpX(1)
	FromCity	= tmpX(2)
	ToCountry	= tmpY(1)
	ToCity		= tmpY(2)
'Response.Write "-" & departureAirportID & "-" & destinationAirportID & "-<br>"
'Response.Write "-" & FromCountry & "-" & ToCountry & "-<br>"
'Response.Write "-" & FromCity & "-" & ToCity & "-<br>"
			
 if departureAirportID ="" or destinationAirportID ="" then
'		response.redirect("Error.htm") 
		end if
	
	set airlineService = Server.CreateObject("TourService.ISearch")

	departureDate = request.form("Indate")
	returnDate = 	request.form("Outdate")

    window_ = true
    smoking = true
    directFlight = true
    if (request.form("window") = "")    then window_ = false
    if (request.form("smoking") = "")    then smoking = false
    if (request.form("directFlight") = "")    then directFlight = false


	departureTimeString = request.form("departureTime")
	returnTimeString = request.form("returnTime")
	if ( departureTimeString <> "0" ) then 
		departureTime = CDate(departureTimeString)
	end if
	if ( returnTimeString <> "0" ) then
		returnTime = CDate(returnTimeString)
	end if

	 tripType = request.form("tripType")
     seats = ( request.form("Amount") )
		if seats = "" then 
			seats = 1 
		end if
     aircraftClass = request.form("class")
     airline = request.form("airline")

		set searchResultCollection = airlineService.SearchAirline( _
	    cstr(departureAirportID), _
        cstr(destinationAirportID), _
        cint(seats), _
        cdate(departureDate), _
        cdate(departureTime), _
        cstr("E"), _
        "", _
        cbool(smoking), _
        cbool(window_) , _
        cbool(directFlight))

	set searchResultCollection2 = airlineService.SearchAirline(_
	    cstr(destinationAirportID), _
        cstr(departureAirportID), _
        cint(seats), _
        cdate(returnDate), _
        cdate(returnTime), _
        cstr("E"), _
        "", _
        cbool(smoking), _
        cbool(window_) , _
        cbool(directFlight))
'==============================
'==============================search Hotel =============================
dim a, b ,c  ,i ,j ,k,L
dim BookingPrice 
dim Country,State,City,HotelName,MinStar,MaxStar,RoomModelName,MinPrice,MaxPrice,CheckIndate,CheckOutDate,AmountOfRoom
set objHotelSearchResults = server.CreateObject("DALDB.CHotelSearchResultFactory")
set objSearch = server.CreateObject("TourService.ISearch")
dim id,star,priceRate
dim tmp1,tmp2,tmp3
dim HotelCnt
dim RoomModelPriceObj
dim notfound
' Check an reformat Input 
Country = ToCountry
State =  Request.Form.Item("State")
	if State = "any" then State ="" end if
City =  ToCity
HotelName =  Request.Form.Item("HotelName")
Star =  Request.Form.Item("Star")
RoomModelName = Request.Form.Item("RoomModelName") 
	if RoomModelName = "any" then RoomModelName ="" end if
PriceRate =  Request.Form.Item("PriceRate")
CheckInDate = request.Form.Item("InDate")
CheckOutDate =  Request.Form.Item("OutDate")
AmountOfRoom =  Request.Form.Item("Amount")
	if AmountOfRoom = "" then AmountOfRoom = 1 end if
if (amountofroom mod 2 = 1) then
	amountofroom = (amountofroom \ 2) + 1
else
amountofroom = (amountofroom \ 2)
end if

select case star
	case "1-2"	Minstar = 1
				maxstar = 2
	case "2-3"	Minstar = 2
				maxstar = 3
	case "3-4"	Minstar = 3
				maxstar = 4
	case "4-5"	Minstar = 4
				maxstar = 5
	case "1-5"	Minstar = 1
				maxstar = 5
	case ELSE 	Minstar = 1
				maxstar = 5				
end select

SELECT case Pricerate
	case "0-1000"		MinPrice = 0
						MaxPrice = 1000
	case "1001-2000"	MinPrice = 1001
						MaxPrice = 2000
	case "2001-3000"	MinPrice = 2001
						MaxPrice = 3000
	case "3001-4000"	MinPrice = 3001
						MaxPrice = 4000
	case "4001-5000"	MinPrice = 4001
						MaxPrice = 5000
	case "5001-1000000"	MinPrice = 5001
						MaxPrice = 1000000
	case else			MinPrice = 0
						MaxPrice = 1000000
end select
' call method Search and Deserialize
	notfound = false
	set tmp1 = objSearch.SearchHotel(Cstr(Country),cstr(State),cstr(City),cstr(HotelName),cint(MinStar),cint(MaxStar),Cstr(RoomModelName),ccur(MinPrice),ccur(MaxPrice),cdate(CheckIndate),cdate(CheckOutDate),Cint(AmountOfroom))
	if Err.number = vbObjectError+1 then 
		notfound = true
	end if
	
	tmp1.Serialize a,b,c
	objHotelSearchResults.DeSerialize a,b,c

	HotelCnt = objHotelSearchResults.Count
	'Response.Write "==>"& notfound & searchResultCollection.count & searchResultCollection2.count &  Hotelcnt
	
%>
<b> <font size="+1"> 
<%'if notfound or (searchResultCollection.count = 0) or (searchResultCollection2.count = 0) then
	if notfound or (searchResultCollection is nothing) or (searchResultCollection2 is nothing) then
%>
<font color="#006699">&nbsp;&nbsp;��辺����ǺԹ ��� �ç���������س��ͧ���</font></font></b> 
<%else %>
<%
		set assr = searchResultCollection.item(1)
		set assr2 = searchResultCollection2.item(1)

%>
<table width="100%" border="0">
  <tr bgcolor="#F8F8F8" > 
    <td colspan=9 class="head11"> <font color="#006699"><b><font size="-1" color="#FF0000">�š�ä�������ǺԹ�-��Ѻ</font></b></font></td>
  </tr>
  <tr align=center bgcolor="#E6E6FA" class="head10" height="20"> 
    <th width="10%" bgcolor="#006699" ><font color="#FFFFFF"> ����ǺԹ </font></th>
    <th width="12%" bgcolor="#006699" ><font color="#FFFFFF"> �鹷ҧ </font></th>
    <th width="12%" bgcolor="#006699" ><font color="#FFFFFF"> ���·ҧ </font></th>
    <th width="14%" bgcolor="#006699" ><font color="#FFFFFF"> �ѹ�Թ�ҧ </font></th>
    <th width="10%" bgcolor="#006699" ><font color="#FFFFFF"> �����͡ </font></th>
    <th width="10%" bgcolor="#006699" ><font color="#FFFFFF"> ���Ҷ֧ </font></th>
    <th width="12%" bgcolor="#006699" ><font color="#FFFFFF"> �ӹǹ(��) </font></th>
    <th width="15%" bgcolor="#006699" ><font color="#FFFFFF"> �Ҥ�(�ҷ) </font></th>
  </tr>
  <%
		
%>
  <tr  align=center  class="text1" > 
    <td ><font color="#006699"><%=assr.FlightID%></font></td>
    <td ><font color="#006699"><%=departureAirportID%></font></td>
    <td ><font color="#006699"><%=destinationAirportID%></font></td>
    <td ><font color="#006699"><%=DepartureDate%></font></td>
    <td ><font color="#006699"><%=Timevalue(assr.DepartTime)%></font></td>
    <td ><font color="#006699"><%=Timevalue(assr.ArriveTime)%></font></td>
    <td ><font color="#006699"><%=seats%></font></td>
    <td ><font color="#006699"><%=assr.Price * seats %></font></td>
  </tr>
  <tr  align=center  class="text1" > 
    <td ><font color="#006699"><%=assr2.FlightID%></font></td>
    <td ><font color="#006699"><%=destinationAirportID%></font></td>
    <td ><font color="#006699"><%=departureAirportID%></font></td>
    <td ><font color="#006699"><%=returnDate%></font></td>
    <td ><font color="#006699"><%=Timevalue(assr2.DepartTime)%></font></td>
    <td ><font color="#006699"><%=Timevalue(assr2.ArriveTime)%></font></td>
    <td ><font color="#006699"><%=seats%></font></td>
    <td ><font color="#006699"><%=assr2.Price * seats %></font></td>
  </tr>
  <tr  height="25" valign=bottom> 
    <td colspan="7" align=right height="25" ><font size="-1" color="#0D549B">�Ҥ����</font> </td>
    <th height="25"> <font size="-1" color="#FF0000"><%=(assr.Price * seats)+(assr2.Price * seats)%></font> 
    </th>
    <%FlightPrice = (assr.Price * seats)+(assr2.Price * seats)%>
  </tr>
</table>
  <BR>
<div align="left"><font size="-1"><font color="#FF0000" face="MS Sans Serif"><b>���Ѿ���ä����ç���</b></font><font color="#006699" face="MS Sans Serif"> 
  <br>
  <%		if notfound then %>
  ��辺�ç������س��ͧ��� 
  <%	else %>
  ��������&nbsp;<%=Hotelcnt%>&nbsp;�ç��� 
  <%	end if%>
  <br>
  </font><font color="#006699" face="MS Sans Serif">Check-in date</font><b><font color="#006699" face="MS Sans Serif"> 
  : &nbsp;<%=CheckInDate%><br>
  </font></b><font color="#006699" face="MS Sans Serif">Check-out date</font><b><font color="#006699" face="MS Sans Serif"> 
  :&nbsp;<%=CheckOutDate%><br>
  </font></b><font color="#006699" face="MS Sans Serif">�ӹǹ��ͧ�ѡ����ͧ��� 
  :</font><b><font color="#006699" face="MS Sans Serif">&nbsp;<%=AmountOfRoom%>&nbsp;</font></b><font color="#006699" face="MS Sans Serif">��ͧ</font><b><font color="#006699" face="MS Sans Serif"><br>
  </font></b></font></div>
    <%for i = 1 to Hotelcnt%>
      <table width="100%" border="0" cellspacing="2" cellpadding="0">
        <tr> 
          <td colspan="8" height="9" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">&nbsp;&nbsp;<%=ObjHotelSearchResults.Item(i).HotelObj.HotelName%></font></b></td>
        </tr>
        <tr> 
          
    <td width="62%"><font size="-1"> <b><%=ObjHotelSearchResults.Item(i).HotelObj.City%> 
      , <%=ObjHotelSearchResults.Item(i).HotelObj.Country%></b> </font></td>
          <td colspan="4"><font size="-1"></font> 
            <div align="right"><font size="-1"><b><font color="#006699">stars</font></b> 
              <%	for z = 1 to ObjHotelSearchResults.Item(i).HotelObj.Star %>
              <img src="images/star1.gif"> 
              <%			next	  %>
              </font></div>
          </td>
        </tr>
        <tr> 
          <td colspan="5"> 
            <div align="left"><font size="-1"><img src= <%= ObjHotelSearchResults.Item(i).HotelObj.ImageMapPath %> align="left">&nbsp; 
              <%=ObjHotelSearchResults.Item(i).HotelObj.Description%> <a href="javascript:openViewHotelWindow('<%=ObjHotelSearchResults.Item(i).HotelObj.HotelID%>')"><b>�������������</b></a> 
              </font></div>
          </td>
        </tr>
        <tr> 
          
    <td width="62%"> 
      <div align="center"><font size="-1"><font color="#FF0000" size="-2">��Դ��ͧ�ѡ</font></font></div>
          </td>
          <%
    Set RoomModelPriceObj = ObjHotelSearchResults.Item(i).RoomModelPriceObj.Item(1)
	dim dcnt 
	dcnt = RoomModelPriceObj.colCPricePerDay.Count
    For j = 1 To dcnt
%>
          
    <td width="21%"> 
      <div align="center"><font size="-1"><font color="#FF0000" size="-2"><%=RoomModelPriceObj.colCPricePerDay(j).Day%></font></font></div>
          </td>
          <%next%>
        </tr>
        <%    For k = 1 To ObjHotelSearchResults.Item(i).colCRoomModelPrice.Count 
        Dim cnt 
        Set RoomModelPriceObj = ObjHotelSearchResults.Item(i).colCRoomModelPrice.Item(k)
%>
        <tr> 
          
    <td width="62%" bgcolor="#D3D3D3"><font size="-1"><a href="javascript:openViewRoomModelWindow('<%=trim(RoomModelPriceObj.RoomModelID)%>')"><b><%=RoomModelPriceObj.RoomModelName%></b></a></font></td>
          <% cnt = RoomModelPriceObj.colCPricePerDay.Count%>
          <%   BookingPrice = 0
For L = 1 To cnt
%>
          
    <td width="21%" bgcolor="#D3D3D3"> 
      <div align="center"><font size="-2"><b><font color="#006699"><%= RoomModelPriceObj.colCPricePerDay.Item(L).Price %> 
              </font></b><font color="#006699">�ҷ</font></font></div>
          </td>
          <%		BookingPrice =BookingPrice + RoomModelPriceObj.colCPricePerDay.Item(L).Price
 next   '   L 
 %>
          <form name="form3" method="post" action="addEJBTraveller.asp">
            
      <td width="17%" bgcolor="#006699"> 
        <input type="hidden" name="cmd" value="addHotelAir">
              <input type="hidden" name="HotelID" value="<%=trim(ObjHotelSearchResults.Item(i).HotelObj.HotelID)%>">
              <input type="hidden" name="RoomModelID" value="<%=trim(RoomModelPriceObj.RoomModelID)%>">
              <input type="hidden" name="BookCheckIn" value="<%=trim(RoomModelPriceObj.colCPricePerDay(1).Day)%>">
              <input type="hidden" name="BookCheckOut" value="<%=trim(RoomModelPriceObj.colCPricePerDay(dcnt).Day)%>">
              <input type="hidden" name="AmountOfRoom" value="<%=AmountOfRoom%>">
              <input type="hidden" name="BookingPrice" value="<%= BookingPrice*AmountOfRoom %>">
		                <input type="hidden" name="flightID" value="<%= trim(assr.FlightID) %>">
                        <input type="hidden" name="classID" value="<%= trim(assr.ClassID) %>">
                        <input type="hidden" name="seats" value="<%= seats %>">
                        <input type="hidden" name="srcidx" value="<%= assr.SrcIdx %>">
                        <input type="hidden" name="desidx" value="<%= assr.DesIdx %>">
                        <input type="hidden" name="unitPrice" value="<%= assr.Price %>">
                        <input type="hidden" name="smoking" value="<%= smoking %>">
                        <input type="hidden" name="window" value="<%= window_ %>">
                        <input type="hidden" name="departDate" value="<%= departureDate %>">
						<input type="hidden" name="departureAirportID" value="<%= departureAirportID %>">
						<input type="hidden" name="destinationAirportID" value="<%= destinationAirportID %>">
						<input type="hidden" name="departureTime" value="<%= TimeValue(assr.DepartTime) %>">
						<input type="hidden" name="arriveTime" value="<%= TimeValue(assr.ArriveTime) %>">
 
		                <input type="hidden" name="flightID2" value="<%= trim(assr2.FlightID) %>">
                        <input type="hidden" name="classID2" value="<%= trim(assr2.ClassID) %>">
                       
                        <input type="hidden" name="srcidx2" value="<%= assr2.SrcIdx %>">
                        <input type="hidden" name="desidx2" value="<%= assr2.DesIdx %>">
                        <input type="hidden" name="unitPrice2" value="<%= assr2.Price %>">
                        <input type="hidden" name="smoking2" value="<%= smoking %>">
                        <input type="hidden" name="window2" value="<%= window_ %>">
                        <input type="hidden" name="departDate2" value="<%= returndate %>">
						<input type="hidden" name="departureAirportID2" value="<%=destinationAirportID %>">
						<input type="hidden" name="destinationAirportID2" value="<%=departureAirportID  %>">
						<input type="hidden" name="departureTime2" value="<%= TimeValue(assr.DepartTime) %>">
						<input type="hidden" name="arriveTime2" value="<%= TimeValue(assr.ArriveTime) %>">
               
              
              <input type="image" name="Submit3" value="��Ժ����С���" src="images/viewonmap1.gif" width="73" height="13">
            </td>
          </form>
        </tr>
        <% next  ' i   %>
      </table>
    <br>
    <%next %>




<%end if%>
</BODY>
</HTML>
