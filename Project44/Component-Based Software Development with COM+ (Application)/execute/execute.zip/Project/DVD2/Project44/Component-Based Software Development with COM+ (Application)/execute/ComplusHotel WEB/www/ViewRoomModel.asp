<html>
<head>
<title> OLALA HOTEL :: View Room Model </title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css" >
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<p align="center"> 
  <%
	dim RoomModelID
	dim HotelService
	dim ObjRoomModels
	dim HotelName,Star,Address,Telephone,Description,Image
	
	RoomModelID = Request.QueryString("RoomModelID")
	set ObjRoomModels = Server.CreateObject("DALDB.CRoomModelFactory")
	set HotelService = Server.CreateObject("HotelService.IHotelViewer")

	ObjRoomModels.Serialize = HotelService.GetRoomModel(Clng(RoomModelID)).Serialize	
	


%>
  <b><font color="#FF9900" class="head11"><%=ObjRoomModels.Item(1).RoomModelName%></font></b><br>
  <br>
</p>
<!--
<table width="100%" border="0">
  <tr> 
    <td width="50%"> 
      <div align="right">Number Of Toilet</div>
    </td>
    <td><%=ObjRoomModels.Item(1).NumOfToilet%></td>
  </tr>
  <tr> 
    <td width="50%" height="23"> 
      <div align="right">Number Of Bedroom</div>
    </td>
    <td height="23"><%=ObjRoomModels.Item(1).NumOfBedroom%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Number Of Livingroom</div>
    </td>
    <td><%=ObjRoomModels.Item(1).NumOflivingroom%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Number Of Single Bed</div>
    </td>
    <td><%=ObjRoomModels.Item(1).NumOfSingleBed%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Number Of Couple Bed</div>
    </td>
    <td><%=ObjRoomModels.Item(1).NumOfCoupleBed%></td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="right">Max Guest</div>
    </td>
    <td><%=ObjRoomModels.Item(1).MaxGuest%></td>
  </tr>
  <tr> 
    <td> 
      <div align="right">Has Air Condition</div>
    </td>
    <td>
    <%if ObjRoomModels.Item(1).Aircondition  then%>
		yes
    <%else%>
		no
    <%end if%>
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="right">Has Terrace</div>
    </td>
    <td>
    <%if ObjRoomModels.Item(1).Terrace then%>
		yes
    <%else%>
		no
    <%end if%>
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="right">Has Telephone</div>
    </td>
    <td>
    <%if ObjRoomModels.Item(1).Telephone  then%>
		yes
    <%else%>
		no
    <%end if%>
    </td>
  </tr>
  <tr> 
    <td colspan="2"> 
      <div align="center"><a href="javascript:window.close();">Close windows</a></div>
    </td>
  </tr>
</table>-->

<table width="95%" border="0" cellspacing=1 align=center  cellpadding=0 >
  <tr bgcolor="#F0F0F0" > 
    <td class="head_1"> 
      <div align="right">Number Of Toilet : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"><%=ObjRoomModels.Item(1).NumOfToilet%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td height="23"  class="head_1"> 
      <div align="right">Number Of Bedroom : &nbsp;&nbsp;</div>
    </td>
    <td height="23" width="48%" class="text1"><%=ObjRoomModels.Item(1).NumOfBedroom%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Number Of Livingroom : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"><%=ObjRoomModels.Item(1).NumOflivingroom%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Number Of Single Bed : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"><%=ObjRoomModels.Item(1).NumOfSingleBed%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Number Of Couple Bed : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"><%=ObjRoomModels.Item(1).NumOfCoupleBed%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Max Guest :&nbsp;&nbsp; </div>
    </td>
    <td width="48%" class="text1"><%=ObjRoomModels.Item(1).MaxGuest%></td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Has Air Condition : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"> 
      <%if ObjRoomModels.Item(1).Aircondition  then%>
      yes 
      <%else%>
      no 
      <%end if%>
    </td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Has Terrace : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"> 
      <%if ObjRoomModels.Item(1).Terrace then%>
      yes 
      <%else%>
      no 
      <%end if%>
    </td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td  class="head_1"> 
      <div align="right">Has Telephone : &nbsp;&nbsp;</div>
    </td>
    <td width="48%" class="text1"> 
      <%if ObjRoomModels.Item(1).Telephone  then%>
      yes 
      <%else%>
      no 
      <%end if%>
    </td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td colspan="2">&nbsp; </td>
  </tr>
  <tr bgcolor="#F0F0F0" > 
    <td colspan="2"> 
      <div align="center"><a href="javascript:window.close();" class="z1">Close 
        windows</a></div>
    </td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>  
