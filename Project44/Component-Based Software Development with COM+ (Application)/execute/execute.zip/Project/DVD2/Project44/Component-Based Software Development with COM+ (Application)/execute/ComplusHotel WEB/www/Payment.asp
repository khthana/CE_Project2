<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title> OLALA HOTEL :: Payment</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css">

  <link rel="stylesheet" type="text/css" href="Templates/style.css">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" topMargin= 0>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>
<table width="98%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="52" colspan="2" > <!--
      <p><b><font face="Arial, Helvetica, sans-serif" size="+2" color="6B8EC6"><font color="#FFFFFF">OLALA 
        HOTEL</font> </font></b></p>-->
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td width="5%">&nbsp;</td>
			<td align="center" valign="bottom"> 
				<img src="images/hd_hotel_pic1.gif" height="60"> </td>
			<td align="center" valign="top"> 
				<img src="images/hd_hotel_pic.gif" height="60"> </td>
			<td align="center" valign="middle"> 
				<img src="images/hd_hotel_pic2.gif"  height="60"> </td>

			<td align="right"> <img src="images/hd_olalahotel.gif"> </td>
		</tr>
		</table>

    </td>
  </tr>
 <!-- <tr> 
    <td bgcolor="#006699" width="36%">&nbsp;&nbsp;&nbsp;
		<a href="../index.asp" class=z1>Main</a>|
		<a href="#" class=z1> Search </a>|
		<a href="../basket.asp" class=z1>View Basket</a>| 
		<a href="../basket.asp" class=z1>Checkout  </a>|</td>
    <td bgcolor="#006699" width="64%"> 
      <div align="right"><font color="#FFFFFF" size="-1">Disclimer | Policies 
        | Feedback | FAQ | Help | About | Coutact Us</font></div>
    </td>
  </tr>-->
  <tr>
  <td>
  <table width="99%" border="0" cellspacing="1" cellpadding="0" align="center" bgcolor="black">
  <tr bgcolor="#FF6666"> 
    <td bgcolor="#FFCC99" width="17%" align="center" class="head5">
      <a href="index.asp" class="link1"><b>Main</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp"  class="link1"><b>Search</b></a>
    </td>

    <td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="basket.asp" class="link1"><b>View Basket</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp" class="link1"><b>About Us</b></a>
    </td>

  </tr>
	<tr>
          <td align="right" colspan="4" bgcolor="#76CCFF" height=4><img src="images/1x1b.gif" border="0" /></td>
    </tr>

</table>
</td>
</tr>

</table>


<table width="99%" border="0" cellspacing="0" cellpadding="5" align="center" height="600">
  <tr> 
    <td width="17%" bgcolor="#D7DCE8" height="330" valign="top" align="center"> 
      <%
	on error resume next
			cmd = Request.Form("cmd")
			Email = Request.Form("Email")
			Password = Request.Form("Password")
			'frompage = request("frompage")		
			'pagename=request.servervariables("script_name")
	
			if cmd = "login" then
			set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
			CustomerID = objCustomer.Login(Cstr(Email),Cstr(Password))
					if err.number = 0 and CustomerID > 0 then
						Response.Cookies("CustomerID") = CustomerID
						Response.Cookies("CustomerID").expires = date+1
'						Response.Cookies("BasketID").expires = now
						
							
							if request.servervariables("script_name") = "/complushotel/www/loginerror.asp" then
								response.redirect("myreservation.asp")
							end if

					else
							select case err.number 
								case vbObjectError+1 err_txt = "notfound"
								case vbObjectError+5 err_txt = "wrongpassword"
							end select
						err_txt = "loginerror.asp?err="  & err_txt 
						response.redirect(err_txt)
					end if  
			end if		    	
		'	cmd  = request.querystring("cmd")
			if cmd="logout" then
						Response.Cookies("BasketID").expires = now
						Response.Cookies("CustomerID").expires = now
						Response.Cookies("BasketID") =""
						Response.Cookies("CustomerID") = ""

			end if
	
			
			CustomerID = Request.Cookies("CustomerID")
			'response.write CustomerID
			if CustomerID = "" then
			'' render login box
%>
      <form name="form1" method="post" action="">
        <table width="130" border="0" cellspacing="0" cellpadding="0" align="center" >
          <tr align="center" > 
            <td  width="130" height=25 >
				<div align="center"><img src="images/login.gif" ></div>
            </td>
          </tr>
          <tr> 
            <td width="130" class="head7"><br><b>   E-mail address </b></td>
          </tr>
          <tr> 
            <td height="15" width="130"> <font size="-1"> 
              <input type="text" name="Email" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td width="130" class="head7" height=20 valign="bottom"><b>Password</b></td>
          </tr>
          <tr> 
            <td width="130"> <font size="-1"> 
              <input type="password" name="Password" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td height="10" width="130"> 
              <div align="center"><font size="-1"> 
			   
				<input type="hidden" name="cmd" value="login">
			  	<input type="hidden" name="country" value="<%=Request.Form.Item("Country")%>">
			  	<input type="hidden" name="state" value="<%=Request.Form.Item("State")%>">
			  	<input type="hidden" name="city" value="<%=Request.Form.Item("City")%>">
			  	<input type="hidden" name="star" value="<%=Request.Form.Item("star")%>">
			  	<input type="hidden" name="HotelName" value="<%=Request.Form.Item("HotelName")%>">
			  	<input type="hidden" name="RoomModelName" value="<%=Request.Form.Item("RoomModelName")%>">
			  	<input type="hidden" name="PriceRate" value="<%=Request.Form.Item("PriceRate")%>">
			  	<input type="hidden" name="CheckInDate" value="<%=Request.Form.Item("CheckInDate")%>">
			  	<input type="hidden" name="CheckOutDate" value="<%=Request.Form.Item("CheckOutDate")%>">
			  	<input type="hidden" name="AmountOfRoom" value="<%=Request.Form.Item("AmountOfRoom")%>">
			<br><br>
							<input type="submit" name="Submit" value="Login" class="smbutton">
                <input type="reset" name="Submit2" value="Reset" class="smbutton">
                <br><br>
                <a href="lostpassword.asp"> ������ʼ�ҹ </a><br>
                <a href="register.asp"> ��Ѥ���Ҫԡ���� </a></font></div>
            </td>
          </tr>
        </table>
      </form>
<%
			else
			 'show customer name and render customer menu 
				set Customers = Server.CreateObject("DALDB.CCustomerFactory")
				set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
				customers.Serialize  = objCustomer.GetCustomer(clng(CustomerID)).Serializer
				CustomerName = Customers.item(1).CustomerName
%>

      <table width="130" border="0" cellspacing="1" cellpadding="0" align="center" dwcopytype="CopyTableRow">
        <tr > 
          <td bgcolor="#3B8EC6" height="38" align=center><font size="-1" color="#FFFFFF"><b>���ʴդ�Ѻ 
            <br>
            �س <%=CustomerName%> </b></font></td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26"> 
            <div align="center"><font size="-1"><a href="MyProfile.asp" class="z2"> ��䢢�����</a></font></div> 
          </td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26" > 
            <div align="center"><font size="-1"><a href="MyReservation.asp" class="z2"> ��¡�èͧ</a></font></div>
          </td>
        </tr>
        <tr> 
          <td height="15" bgcolor="#6B8EC6" width="116"><br>
<div align="center">
              <form name="formx" method="post" action="index.asp">
                <input type="hidden" name="cmd" value="logout">
                <!--<input type="image" name="Submit" value="logout" src="../images/viewonmap.gif" width="70" height="13">-->
				<input type="submit" name="Submit" value="logout" class="button">
				
			  </form>
              </div>
          </td>
        </tr>
      </table>
<%
			end if ' render login box OR menu
%>
    </td>
    <td width="625" height="249" valign="top"> 
		<table width="95%" align="center">
			<tr>
				<td>
					<!-- #BeginEditable "Center_Content" -->
	<%
		dim HotelBookingID,TotalPrice
		HotelBookingID = Request.QueryString("HotelBookingID").Item 
		TotalPrice = Request.QueryString("TotalPrice").Item
	'	Response.Write "Booking=" & HotelBookingID & "Total=" & TotalPrice

	%><br><b>
		<div align=center><font color="#FF3399" size="+1" face="MS Sans Serif">�ʹ�Թ����ͧ����</font> 
      <font color="#FF9966" size="+1" face="MS Sans Serif"><%=TotalPrice%></font> <font color="#FF3399" size="+1" face="MS Sans Serif">�ҷ</font></div></b><font face="MS Sans Serif"><br>
      
      </font> 
      <form name="form2" method="post" action="paymentComplete.asp">
              <table width="90%" border="0" cellspacing="0" cellpadding="2" align="center">
                <tr> 
                  <td colspan="4"><font face="MS Sans Serif"><font  color="#0D549B"><b>�����źѵ��ôԵ</b></font></font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">��Դ�ѵ�&nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <select name="select">
                      <option value="AMEX" selected>Amarican Express</option>
                      <option>Discover</option>
                      <option>MasterCard</option>
                      <option>VISA</option>
                      <option>Diner's Club</option>
                    </select>
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1"> �ѹ�������&nbsp;&nbsp; 
                      </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif" size="-1" > ��͹ </font>
                    <select name="select2">
                      <option value="Jan"><font size="-1" face="MS Sans Serif"> 
                      ���Ҥ� </font></option>
                      <option value="Feb"><font size="-1" face="MS Sans Serif"> 
                      ����Ҿѹ��</font></option>
                      <option value="Mar"><font size="-1" face="MS Sans Serif"> 
                      �չҤ�</font></option>
                      <option value="Apr"><font size="-1" face="MS Sans Serif"> 
                      ����¹</font></option>
                      <option value="May"><font size="-1" face="MS Sans Serif"> 
                      ����Ҥ� </font></option>
                      <option value="Jun"><font size="-1" face="MS Sans Serif"> 
                      �Զع�¹</font></option>
                      <option value="Jul"><font size="-1" face="MS Sans Serif"> 
                      �á�Ҥ� </font></option>
                      <option value="Aug"><font size="-1" face="MS Sans Serif"> 
                      �ԧ�Ҥ� </font></option>
                      <option value="Sep"><font size="-1" face="MS Sans Serif"> 
                      �ѹ��¹ </font></option>
                      <option value="Oct> ���Ҥ� </option>
				<option value="Nov"><font size="-1" face="MS Sans Serif"> ��Ȩԡ�¹ 
                      </font></option>
                      <option value="Dec"><font size="-1" face="MS Sans Serif"> 
                      ��չ�Ҥ� </font></option>
                    </select>
                    </td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">�Ţ���ѵ�&nbsp;&nbsp; 
                      </font></div>
                  </td>
                  <td colspan="2"> <font face="MS Sans Serif"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield3" maxlength="16" class="textbox" >
                    </font></font></td>
					
                  <td width="29%"><font face="MS Sans Serif" size="-1">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </font> 
                    <select name="select3">
                      <option value="2545"><font size="-1" face="MS Sans Serif">2545 
                      </font></option>
                      <option value="2546"><font size="-1" face="MS Sans Serif">2546 
                      </font></option>
                      <option value="2547"><font size="-1" face="MS Sans Serif">2547 
                      </font></option>
                      <option value="2548"><font size="-1" face="MS Sans Serif">2548 
                      </font></option>
                      <option value="2549"><font size="-1" face="MS Sans Serif">2549 
                      </font></option>
                      <option value="2550"><font size="-1" face="MS Sans Serif">2550 
                      </font></option>
                      <option value="2551"><font size="-1" face="MS Sans Serif">2551 
                      </font></option>
                    </select>
                    </td>
                </tr>
                <tr> 
                  <td colspan="4" height="35" valign=bottom><font  color="#0D549B" face="MS Sans Serif"><b>�����ż���ͺѵ�</b></font> 
                  </td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">���� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield6" size="20"  class="textbox">
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">���ʡ�� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield62" size="20"  class="textbox">
                    </font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">��ҹ�Ţ��� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield63" size="20"  class="textbox">
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">��� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield64" size="20"  class="textbox">
                    </font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">�ѧ��Ѵ &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield67" size="20"  class="textbox">
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">������ɳ��� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield68" size="20"  class="textbox">
                    </font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">����� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield69" size="20"  class="textbox">
                    </font></td>
                  <td width="21%">&nbsp;</td>
                  <td width="29%">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <div align="center"> 
                      <input type="submit" name="Submit3" value="Submit" class="button">
                      <input type="hidden" name="HotelBookingID" value="<%=HotelBookingID%>">
                      <input type="reset" name="Submit4" value="Reset" class="button">
                    </div>
                  </td>
                </tr>
              </table>
      </form>
      <!-- #EndEditable -->
				</td>
			</tr>
		</table>				
	</td>
  </tr>
 <!-- <tr>
    <td width="148" bgcolor="#D7DCE8" height="28" valign="top">&nbsp; </td>
    <td width="631" height="28" valign="top">&nbsp;</td>
  </tr>-->
</table>
</body>
<!-- #EndTemplate --></html>
