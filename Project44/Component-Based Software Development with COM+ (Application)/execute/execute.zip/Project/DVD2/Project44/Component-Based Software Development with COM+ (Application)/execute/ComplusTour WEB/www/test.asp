<%@ Language=VBScript %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>
<BODY>

<P>&nbsp;</P>
<%
set IBookViewer = server.CreateObject("TourBookingService.IBookViewer")
		set objBookingFac = server.CreateObject("DALDB.CBookingFactory")
		set objBooking = IBookViewer.GetBooking(Cint(14))
		objBookingFac.Serialize = objbooking.Serialize
		
		
%>
<%=  objbookingfac.Item(1).ConfirmDeadline  %>
<br>
jiu9ouhnuiopj,iojp
</BODY>
</HTML>
