<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<OBJECT runat="Server" ID="test1"  PROGID="test2.test1">
</OBJECT>

<%
'	dim x 
'	x = CStr(test1.a)
	response.write(test1.a(152.6))

%>



</BODY>
</HTML>
