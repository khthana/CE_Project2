<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD><TITLE> OLALA Tour -> ��ԡ���Ѻ�ͧ�ç��� ������ ����� ���ö</TITLE>
	    <META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>

<BODY BGCOLOR="#FFFFFF"> 
<DIV align=center>
	<table width="100%" border=0>
	<tbody>
		<tr>
			
      <TH align=middle class="head2"><b><font color="#FF0000">��¡�����稷����</font></b></TH>
		</tr>
		
		
		
		<tr>
			<td colspan=2>&nbsp; </td>
		</tr>
	</table>
	
	<TABLE cellSpacing=0 cellPadding=2 width=507 border=0>
	<TBODY> 
		
<%
	on error resume next

	Response.Cookies("InDate") = Request.Form("MinDepartDate")
	Response.Cookies("OutDate") = Request.Form("MaxDepartDate")
	Response.Cookies("Amt") = Request.Form("NumTraveller")

	dim objSearchPackage
	dim objSearchPackageResultFactory
		
		set  objSearchPackage = Server.CreateObject("TourService.ISearch")
		set objSearchPackageResultFactory = server.CreateObject("DALDB.CPackageSearchResultFactory")
		'Response.Write "PlaceName=" & Request.Form("PlaceName") & "-<BR>"
		'Response.Write "Country=" & Request.Form("Country") & "-<BR>"
		'Response.Write "State=" & Request.Form("State") & "-<BR>"
		'Response.Write "City=" & Request.Form("City") & "-<BR>"
		'Response.Write "MinDepartDate=" & Request.form("MinDepartDate") & "-<BR>"
		'Response.Write "MaxDepartDate" & Request.form("MaxDepartDate") & "-<BR>"
		'Response.Write "NumOfDays" & Request.Form("NumOfDays")& "-<BR>"
		'Response.Write "NumTraveller" & Request.Form("NumTraveller") & "-<BR>"
		set objSearchResultFactory = objSearchPackage.SearchPackage(CStr( Request.Form("PlaceName") ),CStr( Request.Form("Country") ),CStr( Request.Form("State") ),CStr( Request.Form("City") ),CDate( Request.form("MinDepartDate") ),CDate(Request.form("MaxDepartDate")),CInt( Request.Form("NumOfDays") ),CInt( Request.Form("NumTraveller") ) )
		objSearchPackageResultFactory.Serialize = objSearchResultFactory.Serialize
		set objSearchPackage = nothing
		if objSearchPackageResultFactory.Count = 0 then 
%>			<P><font class="text"> ��辺���稷���� </font><a href="search.asp"><u> Search Again </u></a> </P>
<%		else
		
		for i = 1 to objSearchPackageResultFactory.Count
			PackageID = objSearchPackageResultFactory.Item(i).objCPackageDeparture.PackageID
			DepartDate = objSearchPackageResultFactory.Item(i).objCPackageDeparture.DepartDate
			
			set IPackageViewer = server.CreateObject("TourService.IPackageViewer")
			set PackageDetailFac = server.CreateObject("DALDB.CPackageDetailFactory")
		
			set PackageDetail = IPackageViewer.GetPackageDetail(cint(PackageID))	
			PackageDetailFac.Serialize = PackageDetail.Serialize
			PlaceID = PackageDetailFac.Item(1).PlaceID			
			
			set PlaceFac = server.CreateObject("DALDB.CPlaceFactory")
			PlaceFac.Serialize = IPackageViewer.GetPlace(cint(PlaceID)).Serialize
'			PlaceFac.Serialize = objPlace.serialize 
			ImagePath = PlaceFac.Item(1).ImagePath
%>
	<TR>
		<TD vAlign=center width=115> 
		<DIV align=center class"text">
		<A  href="ShowPackageDetail.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=<%=Request("NumTraveller")%>">
		<IMG height=63 src="<%=ImagePath%>" width=82 border=0></A>
		</DIV>
		</TD>
		
		
      <TD width=384 class="text"> <font color="#006699"> 
        <!--A  href="package.htm"-->
        <a href="ShowPackageDetail.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=<%=Request("NumTraveller")%>"><FONT face=Verdana><u><b><%=objSearchPackageResultFactory.Item(i).objCPackage.PackageName %>&nbsp;&nbsp;</b> 
        <%=objSearchPackageResultFactory.Item(i).objCPackage.NumOfDays%> �ѹ <%=objSearchPackageResultFactory.Item(i).objCPackage.NumOfDays - 1%> 
        �׹ �Թ�ҧ <%=DepartDate%></FONT></u></a> <BR>
        <!--/A-->
        ����˭��Ҥ� <%=objSearchPackageResultFactory.Item(i).objCPackageDeparture.AdultPrice%> 
        �ҷ/��ҹ �� <%=objSearchPackageResultFactory.Item(i).objCPackageDeparture.ChildPrice%> 
        �ҷ/��ҹ</font> <BR>
        <%=objSearchPackageResultFactory.Item(i).objCPackage.Description%>
		
		<A href="addTraveller.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=<%=request("NumTraveller")%>&cmd=addPackage"><FONT face=Verdana color=RED>��Ժ����С���</font></a>
		</TD>
	</TR>
<%			'Response.Write objSearchPackageResultFactory.Item(i).objCPackage.PackageName + "<br>"
			 'objSearchPackageResultFactory.Item(1).objCPackage.PackageName
	
		next 
		'PlaceName = Request.QueryString("")
	end if
%>
		
	</TBODY>
	</TABLE>	
</DIV>
</BODY>
</HTML>