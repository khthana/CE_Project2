<HTML>
<HEAD>
<TITLE> Summary Reserve OlalaTour.com </TITLE>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>
</HEAD>
<BODY BGCOLOR="#FFFFFF">

<%
	on error resume next
	dim CustormerService
	
	set CustomerService = Server.CreateObject("TourCustomerService.ICustomer")
	Address = Request.Form("Address1") & Request.Form("Address2")
	
	CustomerName = Request.Form("CustomerName")
	Telephone = Request.Form("Telephone")
	Email = Request.Form("Email")
	Gender = Request.Form("Gender")
	Password = Request.Form("Passwordd")
	'ConfirmPassword = Request.Form("ConfirmPassword")
	
	CustomerID = CustomerService.Register(CStr(CustomerName),CStr(Address),CStr(Telephone),CStr(Email),CStr(Gender),CStr(Password))
	if err.number = 0 then
		Response.Cookies("TourCustomerID") = CustomerID
		Response.Cookies("TourCustomerID").expires = date + 1
		
		'Response.Cookies("TourCustomerID") = CustomerID
		'Response.Cookies("TourCustomerID").expires = date + 1
		'Response.Write "CustomerID=" & CustomerID
		'Response.Redirect("index.asp")
		'Response.Redirect("GetCustomer.asp")
%>		


<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <TH align=left bgColor=#e6e6fa class="head3" colspan=2>&nbsp;&nbsp;&nbsp;��������ǹ��� 
            </TH>
          </tr>
          <tr> 
            <td width="28%" class="head4"> 
              <div align="right" class="text">���� - ���ʡ�� :&nbsp;&nbsp;</div>
            </td>
            <td width="72%" class="text"> 
              <LABEL><%=CustomerName%></LABEL>
              </td>
          </tr>
          <tr> 
            
    <td width="28%" class="head4" height="19"> 
      <div align="right" class="text"> �� :&nbsp;&nbsp;</div>
            </td>
            
    <td class="text" width="72%" height="19"> 
      <%
			if Gender = "M" then
%>
      <input type="radio" name="Gender" value="M"  checked> ���
<%            else
%>              <input type="radio" name="Gender" value="F" checked> ˭ԧ
<%            end if
%>    
			</td>
          </tr>
          <tr> 
            <td width="28%"> 
              <div align="right" class="text">�������:&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif" 
                        size=2>
              <LABEL><%=Address%></LABEL>
              </font></td>
          </tr>
		  <tr> 
            <td width="28%"> 
              <div align="right" class="text">���Ѿ�� :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"    size=2> 
              <LABEL><%=Telephone%><LABEL>
              </font></td>
          </tr>
		  
		  <tr> 
            <td width="28%"> 
              <div align="right" class="text">������ :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"    size=2> 
              <LABEL><%=Email%><LABEL>
              </font></td>
          </tr>
        
          <tr> 
            <td colspan=2>&nbsp;</td>
          </tr>
        
		  <tr>
			<!--td align="right"><a href="EditCustomer.asp"><font class="text"><u>��䢢����� | </u></font></a></td-->
			
    <td align="center" colspan=2><a href="index.asp" target="_parent" class="text"><u>&nbsp;HOME&nbsp;</u></a></td>
		  </tr> 	
        
        
        </table>
		











<%	else
%>		<table width="95%">
			<tr>
				<td><%=err.Description%> &nbsp; <a href="regisform.htm" class="text"><u> Try again </u></a></td>
			</tr>
		</table> 

<%	end if
	'Response.Write "CustomerID = " & CustomerID & "<BR>"
%>

</BODY>
</HTML>
