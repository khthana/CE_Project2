<HTML>
	<HEAD><TITLE> OLALA TOUR </TITLE>
	<META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>
	
<BODY bgColor=#ffffff>
<DIV align=center> <b><font color="#FF0000">��ª��ͼ���Թ�ҧ</font></b> 
  <%
	'on error resume next

	routeID	=	Request("RouteID")
	toilet	=	Request("Toilet")
	departureStationID = Request("departureStationID")
	destinationStationid = Request("destinationstationID")

	routeID2	=	Request("RouteID2")
	toilet2	=	Request("Toilet2")
	departureStationID2 = Request("departureStationID2")
	destinationStationid2 = Request("destinationstationID2")

	flightid=	Request("FlightID")
	classid	=	Request("ClassID")
	seats	=	Request("seats")
	srcidx	=	Request("srcidx")
	desidx	=	Request("desidx")
	unitprice = Request("unitprice")
	smoking	=	Request("smoking")
	window	=	Request("window")
	departdate =Request("departdate")
	departureairportID = Request("departureAirportID")
	destinationairportid = Request("destinationAirportID")
	departuretime	= Request("departuretime")
	arrivetime		= Request("arrivetime")
	
	flightid2=	Request("FlightID2")
	classid2	=	Request("ClassID2")	
	srcidx2	=	Request("srcidx2")
	desidx2	=	Request("desidx2")
	unitprice2 = Request("unitprice2")
	smoking2	=	Request("smoking2")
	window2	=	Request("window2")
	departdate2 =Request("departdate2")
	departureairportID2 = Request("departureAirportID2")
	destinationairportid2 = Request("destinationAirportID2")
	departuretime2	= Request("departuretime2")
	arrivetime2		= Request("arrivetime2")
	
	HotelID			= Request("HotelID")
	RoomModelID		= Request("RoomModelID")
	BookCheckIn		= Request("BookCheckIn")
	BookCheckOut	= Request("BookCheckOut")
	AmountOfRoom	= Request("AmountOfRoom")
	BookingPrice	= Request("BookingPrice")
%>
  <form name="AddTravellerForm" action="Basket.asp" method="post">
    <table width="80%" border="0" cellspacing="1" cellpadding="0">
      <tr  align=center> 
        <td height="17" width="32%" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">�ӴѺ���</font></b></td>
        <td width="34%" height="17" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">���ͼ���Թ�ҧ</font></b></td>
        <td width="34%" height="17" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">���ʡ��</font></b></td>
      </tr>
      <% 	for i = 1 to seats %>
      <tr class="text" align=center  bgcolor="#EEEEEE"> 
        <td width="32%"><%=i%></td>
        <td width="34%"> 
          <%
				T = Request.Cookies("T" &  i)
				L = Request.Cookies("L" &  i)
			%>
          <input type="text" class = "textbox" name="T<%=i%>" size="30" value="<%=T%>">
        </td>
        <td width="34%"> 
          <div align="center"> 
            <input type="text" class=textbox name="L<%=i%>" size="30" value="<%=L%>">
          </div>
        </td>
      </tr>
      <%	next %>
      <tr class="text" align=center> 
        <td colspan="3"> <br>
          <input type="hidden" name="cmd" value="<%=Request("cmd")%>">
          <input type="hidden" name="flightID" value="<%= FlightID %>">
          <input type="hidden" name="classID" value="<%= ClassID %>">
          <input type="hidden" name="seats" value="<%= seats %>">
          <input type="hidden" name="srcidx" value="<%= SrcIdx %>">
          <input type="hidden" name="desidx" value="<%= DesIdx %>">
          <input type="hidden" name="unitPrice" value="<%= UnitPrice %>">
          <input type="hidden" name="smoking" value="<%= smoking %>">
          <input type="hidden" name="window" value="<%= window %>">
          <input type="hidden" name="departDate" value="<%= departDate %>">
          <input type="hidden" name="departureAirportID" value="<%= departureAirportID %>">
          <input type="hidden" name="destinationAirportID" value="<%= destinationAirportID %>">
          <input type="hidden" name="departureTime" value="<%= DepartureTime %>">
          <input type="hidden" name="arriveTime" value="<%= ArriveTime %>">
          <input type="hidden" name="flightID2" value="<%= FlightID2 %>">
          <input type="hidden" name="classID2" value="<%= ClassID2 %>">
          <input type="hidden" name="srcidx2" value="<%= SrcIdx2 %>">
          <input type="hidden" name="desidx2" value="<%= DesIdx2 %>">
          <input type="hidden" name="unitPrice2" value="<%= UnitPrice2 %>">
          <input type="hidden" name="smoking2" value="<%= smoking2 %>">
          <input type="hidden" name="window2" value="<%= window2 %>">
          <input type="hidden" name="departDate2" value="<%= departDate2 %>">
          <input type="hidden" name="departureAirportID2" value="<%= departureAirportID2 %>">
          <input type="hidden" name="destinationAirportID2" value="<%= destinationAirportID2 %>">
          <input type="hidden" name="departureTime2" value="<%= DepartureTime2 %>">
          <input type="hidden" name="arriveTime2" value="<%= ArriveTime2 %>">
          <input type="hidden" name="Toilet" value="<%= Toilet %>">
          <input type="hidden" name="RouteID" value="<%= RouteID %>">
          <input type="hidden" name="departureStationID" value="<%= departureStationID %>">
          <input type="hidden" name="destinationStationID" value="<%= destinationStationID %>">
          <input type="hidden" name="Toilet2" value="<%= Toilet2 %>">
          <input type="hidden" name="RouteID2" value="<%= RouteID2 %>">
          <input type="hidden" name="departureStationID2" value="<%= departureStationID2 %>">
          <input type="hidden" name="destinationStationID2" value="<%= destinationStationID2 %>">
          <input type="hidden" name="HotelID" value="<%= HotelID %>">
          <input type="hidden" name="RoomModelID" value="<%= RoomModelID %>">
          <input type="hidden" name="BookCheckIn" value="<%= BookCheckIn %>">
          <input type="hidden" name="BookCheckOut" value="<%= BookCheckOut %>">
          <input type="hidden" name="BookingPrice" value="<%= BookingPrice %>">
          <input type="hidden" name="AmountOfRoom" value="<%= AmountOfRoom %>">
          <input type="submit" name="Submit" value="Submit" class="button">
          <input type="reset" name="Submit2" value="Reset" class="button">
        </td>
      </tr>
    </table>
</form>

</DIV>
</BODY>
</HTML>