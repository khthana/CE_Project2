<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<Form action="tsCheckBox.asp" method="post">
<INPUT TYPE="checkbox" NAME="a"  value="aa">aaa
<INPUT TYPE="checkbox" NAME="b"  value="bb"">bbb
<INPUT TYPE="submit" >
</Form>
<%

	response.write request.form("a") + "<br>"
	response.write request.form("b")+ "<br><br><br>"
	
	if request.form("a")="" then Response.write "A is Empty"
		if request.form("b")="" then Response.write "B is Empty"
%>

</BODY>
</HTML>
