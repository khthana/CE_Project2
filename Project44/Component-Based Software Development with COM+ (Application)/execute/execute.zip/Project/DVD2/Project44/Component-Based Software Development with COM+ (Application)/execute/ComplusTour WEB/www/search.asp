<HTML>
<HEAD>
<TITLE> Search Form </TITLE>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>
</Head>


<BODY BGCOLOR="#ffffff">
<SCRIPT LANGUAGE="JavaScript">
<!--
function checkform(form)
{
    // see http://www.thesitewizard.com/archive/validation.shtml
    // for an explanation of this script and how to use it on your
    // own website

    // ** START **
    if (form.Country.value == "") {
        alert( "��س������ͻ����" );
        //form.Country.focus();
        return false ;
    }
    if (form.NumTraveller.value == "") {
		alert("��س����ӹǹ��");
		//form.Country.focus();
		return false;
	}
	else if (parseInt(form.NumTraveller.value).toString() == "NaN") {
		alert("��س����ӹǹ���繵���Ţ");
		return false;
	}
	else if (parseInt(form.NumTraveller.value) < 0) {
		alert("��س����ӹǹ������")
		return false;
	}
	else {
		form.NumTraveller.value = parseInt(form.NumTraveller.value)
	}

	if (form.MinDepartDate.value == "" && form.MaxDepartDate.value == "" ) {
		form.MinDepartDate.value = 0;
		form.MaxDepartDate.value = 0;
	} 
	else if (form.MinDepartDate.value != "" && form.MaxDepartDate.value == "") {
			form.MaxDepartDate.value = form.MinDepartDate.value
	}
	else if (form.MinDepartDate.value == "" && form.MaxDepartDate.value != "") {
			form.MinDepartDate.value = form.MaxDepartDate.value
	}
	
    if (form.NumOfDays.value == "") {
		form.NumOfDays.value = 0
	} 
	else if (parseInt(form.NumOfDays.value).toString() == "NaN") {
		alert("��س����ӹǹ�ѹ�繵���Ţ");
		return false;
	} 
	else if (parseInt(form.NumOfDays.value) < 0){
		alert("��س����ӹǹ�ѹ����")
		return false;
	}
	else {
		form.NumOfDays.value = parseInt(form.NumOfDays.value)
	}
    // ** END **
	return true ;
}
-->
</SCRIPT>

<SCRIPT language=javascript src="calendar.js"></SCRIPT>
      <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
<IFRAME STYLE="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; DISPLAY: none; Z-INDEX: 100; LEFT: 66px; BORDER-LEFT: 1px solid; WIDTH: 167px; BORDER-BOTTOM: 1px solid; POSITION: absolute; TOP: 260px; HEIGHT: 200px" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=no SRC="datev2.htm"></IFRAME> 



<FORM name="SearchForm"  action="SearchPackage.asp" method="post" onsubmit="return checkform(this)">
	
  <TABLE width="95%" border=0 align="center" cellpadding="0" cellspacing="0">
    <TBODY> 
    <tr>
      <td colspan=2 height="42"><img src="images/SearchPackage.gif" width="420" height="24"> 
      </td>
    </tr>
    <TR> 
      <TD> 
        <table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td width="22%" height="33"  > 
              <div align="right"   
            class="text"><font color="#003399"><b> ʶҹ��������:&nbsp;&nbsp;</b></font></div>
            </td>
            <td width="24%" height="33"> <font color="#003399"><b> 
              <input size=15 name="PlaceName" class="textbox" align="right"  >
              </b></font></td>
            <td width="18%" height="33"  > 
              <div align="right"  class="text" ><font color="#003399"><b>�ѧ��Ѵ 
                :&nbsp;&nbsp;</b></font></div>
            </td>
            <td width="36%" height="33"> <font color="#003399"><b> 
              <input size=15 name="City" class="textbox" align="right"  >
              </b></font></td>
          </tr>
          <tr> 
            <td width="22%" height="37"  > 
              <div align="right"  class="text" ><font color="#003399"><b>�Ѱ :&nbsp;&nbsp;</b></font></div>
            </td>
            <td width="24%" height="37"> <font color="#003399"><b> 
              <input size=15 name="State" class="textbox" align="right"  >
              </b></font></td>
            <td width="18%" height="37"  > 
              <div align="right"  class="text" ><font color="#003399"><b><font size="1" color="#FF0000">***</font><font color="#FF0000"> 
                </font>����� :&nbsp;&nbsp;</b></font></div>
            </td>
            <td width="36%" height="37"> <font color="#003399"><b> 
              <SELECT id=select1 name=Country align="left">
				<OPTION value="��">�������</OPTION>
			  </SELECT>
              
              </b></font></td>
          </tr>
          <tr> 
            <!--td width="21%"  > 
              <div align="right" class="text" >�ѹ/��͹/�� &nbsp;&nbsp;&nbsp;<br> ����͡�Թ�ҧ :&nbsp;&nbsp;</div>
            </td>
            <td width="27%" class="text"> 
              <input id=txtbox1 type="text" class="textbox" name="MinDepartDate" value='<%=Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543%>' onChange="javascript:cbfloadmefirst('SearchForm', 'MinDepartDate');" size="13" maxlength="10">
              <font face="MS Sans Serif" size=2> 
                <a href="javascript:cbfshowcalendar('SearchForm', 'MinDepartDate', 'txtbox1')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font>
                 
            </td>
            <td width="23%">
				<div align="left" class="text"> �֧�ѹ��� : </div>
			</td>
			<td width="29%">
				<input id=txtbox2  class="textbox" name="MaxDepartDate" value='<%=Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543%>' onChange="javascript:cbfloadmefirst('SearchForm', 'MaxDepartDate');" size="13" maxlength="10">
				<font face="MS Sans Serif" size=2>
				   <a href="javascript:cbfshowcalendar('SearchForm', 'MaxDepartDate', 'txtbox2')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font>
                
			</td-->
            <td colspan=4 align="left" class="text" height="40"><b><font color="#003399"> 
              �͡�Թ�ҧ�����:&nbsp;&nbsp; 
              <%
					InDate = Request.Cookies("InDate")
					If Indate = "" then
					Indate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
					OutDate = Request.Cookies("OutDate")
					If OutDate = "" then
					OutDate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
				%>
              <input id=txtbox1 class="textbox" name="MinDepartDate" value='<%=InDate%>' onChange="javascript:cbfloadmefirst('SearchForm', 'MinDepartDate');" size="13" maxlength="10">
              <font face="MS Sans Serif" size=2> <A href="javascript:cbfshowcalendar('SearchForm', 'MinDepartDate', 'txtbox1')"><IMG height=21 src="images/calendar.gif" width=34 border=0></A></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�֧�ѹ��� 
              : 
              <input id=txtbox2  class="textbox" name="MaxDepartDate" value='<%=OutDate%>' onChange="javascript:cbfloadmefirst('SearchForm', 'MaxDepartDate');" size="13" 
            maxlength="10" 
           >
              <font face="MS Sans Serif" size=2> <A href="javascript:cbfshowcalendar('SearchForm', 'MaxDepartDate', 'txtbox2')"><IMG height=21 src="images/calendar.gif" width=34 border=0></A></font></font> 
              </b></td>
          </tr>
          <tr> 
            <td width="22%" class="head4" height="34"> 
              <div align="right" class="text"><font color="#003399"><b>�ӹǹ�ѹ�Թ�ҧ 
                :&nbsp;&nbsp;</b></font></div>
            </td>
            <td width="24%" class="text" height="34"> <font color="#003399"><b> 
              <input size=5  name="NumOfDays" class="textbox" >
              �ѹ </b></font></td>
            <td width="18%" class=text  align=right height="34"> <font color="#003399"><b><font size="1" color="#FF0000">***</font><font size="1"> 
              </font>�ӹǹ�� :&nbsp; </b></font></td>
            <td width="36%" class='text' height="34"> <font color="#003399"><b> 
              <%
					Amt = Request.Cookies("Amt")
					If Amt = "" then
					Amt = 1
					end if
			%>
              <input size=7 name="NumTraveller"  class="textbox"  
            align="right" value="<%=Amt%>">
              &nbsp;�� </b></font></td>
          </tr>
          <tr> 
            <td colspan=3 align=right class="text"> 
              <div align="right"><b></b><font color="#003399"> </font></div>
            </td>
            <td align=right class="text">
              <div align="left"><font color="#003399"><font color="#FF0000">*** 
                is (require)</font></font><b><font color="#003399"> </font></b> 
              </div>
            </td>
          </tr>
          <tr> 
            <td colspan=4 align=right height=30> 
              <div align="center"> 
                <input type="submit" name="SearchPackage" value="Search" class="button" >
              </div>
            </td>
          </tr>
        </table>
      </TD>
    <tr>
      <td colspan=2>&nbsp;</td>
    </tr>
    </TBODY> 
  </TABLE>

	

</FORM>

</BODY>
</HTML>
