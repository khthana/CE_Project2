<OBJECT ID="MSFlexGrid1" WIDTH="500" HEIGHT="300" CLASSID="CLSID:6262D3A0-531B-11CF-91F6-C2863C385E30" >
	<param name="Rows" value="15">
	<param name="Cols" value="2">
	<param name="allowuserresizing" value="1">
	<param name="fixedcols" value="0">
</OBJECT>


<%
'MSFlexGrid1.ColWidth(0) = 50'(MSFlexGrid1.Width / MSFlexGrid1.Cols) - 105
'MSFlexGrid1.ColWidth(1) = MSFlexGrid1.Width / MSFlexGrid1.Cols
%>
<SCRIPT LANGUAGE="VBScript">
function hello
'alert ("hello there!  We've just loaded!")
MSFlexGrid1.ColWidth(0) = ( 15 *   (MSFlexGrid1.Width / MSFlexGrid1.Cols) ) -400
MSFlexGrid1.ColWidth(1) = 15 * (MSFlexGrid1.Width / MSFlexGrid1.Cols)
alert ("hello there!  We've just loaded!  " &  MSFlexGrid1.Width / MSFlexGrid1.Cols)
end function
function list1_Click
	alert ("hello there!  ")
end function
</SCRIPT>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY onLoad="hello()">
<br>
Hello
<br>
<OBJECT ID="list1" WIDTH="50" HEIGHT="50" CLASSID="CLSID:8BD21D20-EC42-11CE-9E0D-00AA006002F3">
</OBJECT>
&nbsp;&nbsp;&nbsp;&nbsp;
<OBJECT ID="Microsoft Forms 2.0 ListBox" WIDTH="50" HEIGHT="50" CLASSID="CLSID:8BD21D20-EC42-11CE-9E0D-00AA006002F3">
</OBJECT>
<br>
<OBJECT ID="Microsoft Forms 2.0 Label" WIDTH="400" HEIGHT="20" CLASSID="CLSID:978C9E23-D4B0-11CE-BF2D-00AA003F40D0">
	<param name="caption" value="Hello Label">
</OBJECT>
<BR>
<OBJECT ID="Microsoft DataGrid Control, Version 6.0 (OLEDB)" WIDTH="400" HEIGHT="200" CLASSID="CLSID:CDE57A43-8B86-11D0-B3C6-00A0C90AEA82">
</OBJECT>
</BODY>
</HTML>
