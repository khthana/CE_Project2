<%@ Language=VBScript %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>
<BODY>

<P>&nbsp;</P>
<%
set d  =server.CreateObject("BusProxy.BusProxy")
set w  =server.CreateObject("DALDB.CReserveBusDetailFactory")
dim p 'As CReserveBusDetail
Set p = w.AddNew
p.routeID = "AA330"
p.totalseat = 1
p.desIdx = 1
p.srcIdx = 1
p.Smoking = False
p.Window = False
p.DepartDate = "9/11/2002"
Dim t 'As CEJBTraveller

Set t = p.AddTraveller
t.firstname = "fds"
t.lastname = "fdsfds"
t.travellerID = "0"

Response.Write  d.Reserve ("1", w)


%>
</BODY>
</HTML>
<%
set objCParams =server.CreateObject("DALDB.CParams")
set objCDAL =server.CreateObject("DALDB.CDAL")
set objCRecordset ==server.CreateObject("(DALDB.CRecordset")
'=====Bigin var of Package=====
set objCReservePackageDetailFac ==server.CreateObject("CReservePackageDetailFactory")
Dim DepartDateStr 'As String
Dim BirthDateStr 'As String
Dim query 'As String
Dim mBookingID 'As Long
Dim i 'As Integer
Dim j 'As Integer
Dim PackageBookingPrice 'As Currency
Dim age 'As Integer
Dim MinPackageDepartDate 'As Date
Dim MaxPackageDepartDate 'As Date
'=====Begin var of Hotel=====
set HotelBookingService =server.CreateObject("BookingService.IBookManager")
Dim HotelBookingID 'As Long
Dim objCReserveHotelDetailFac =server.CreateObject("DALDB.CReserveHotelDetailFactory")
Dim objHotelBookingDetailFac =server.CreateObject("DALDB.CHotelBookingDetailFactory")
Dim MinCheckinDate 'As Date
Dim MaxCheckoutDate 'As Date
Dim HotelBookingPrice 'As Currency
'=====Bigin var of Bus=======
Dim BusbookingID 'As String
Dim MinBusDepartDate 'As Date
Dim MaxBusDepartDate 'As Date
Dim BusBookingInfoFac 'As BusProxy.ViewBusBookinfoFactory 'New DALDB.CViewBusBookinfoFactory
Dim BusBookingPrice 'As Currency
Dim bus =server.CreateObject("BusProxy.BusProxy")
'=====Begin var of Airline===
Dim AirlineBookingID As String
Dim MinAirlineDepartDate As Date
Dim MaxAirlineDepartDate As Date
Dim TourService 'As TourBookingService.IBookViewer


Dim AirlineBookingInfoFac=server.CreateObject("DALDB.CViewAirlineBookinfoFactory")
Dim AirlineBookingPrice 'As Currency
Dim air =server.CreateObject("AirlineProxy.AirlineProxy")
'===========================
Dim TotalPrice 'As Currency
Dim ObsoleteDate 'As Date
Dim ObsoleteDateStr 'As String
Dim ConfirmDeadline 'As Date
Dim ConfirmDeadlineStr 'As String

Dim fso 'As New FileSystemObject

Dim objFile 'As File
Dim objTS 'As TextStream
Dim IsReserveHotel 'As Boolean
Dim IsReserveBus 'As Boolean
Dim IsReserveAir 'As Boolean
Dim IsReservePackage 'As Boolean

'Dim objObjectContext As COMSVCSLib.ObjectContext
'Set objObjectContext = GetObjectContext

    IsReserveHotel = False
    IsReserveAir = False
    IsReserveBus = False
    IsReservePackage = False

'On Error GoTo handler
    objCDAL.OpenDb (2)
    objCParams.Add "SQL", ""
    ' add customerID to Booking and query ID back
    objCRecordset.internalResordset.Open "Booking", objCDAL.internalConnection, adOpenKeyset, adLockOptimistic
    objCRecordset.internalResordset.AddNew
    objCRecordset.internalResordset.Fields("CustomerID") = CustomerID
    objCRecordset.internalResordset.Update
    
    mBookingID = objCRecordset.internalResordset.Fields("BookingID")
    objCRecordset.internalResordset.Close
    
    '-----keng edit
    objCDAL.CloseDb
    Set objCDAL = Nothing
    Set objCParams = Nothing
    Set objCRecordset = Nothing
    '-------------
    
    Reserve = mBookingID

    MinCheckinDate = "12/12/2600"
    MinBusDepartDate = "12/12/2600"
    MinAirlineDepartDate = "12/12/2600"
    MinPackageDepartDate = "12/12/2600"
    MaxCheckoutDate = "1/1/2500"
    MaxBusDepartDate = "1/1/2500"
    MaxAirlineDepartDate = "1/1/2500"
    MaxPackageDepartDate = "1/1/2500"
'=====================Begin Reserve Hotel========
    HotelBookingPrice = 0
    If Not ReserveHotelDetailFactory Is Nothing Then
    objCReserveHotelDetailFac.Serialize = ReserveHotelDetailFactory.Serialize
    If objCReserveHotelDetailFac.Count <> 0 Then
    'If HotelBookingService Is Nothing Then MsgBox "nn"
        'Set HotelBookingService = New BookingService.IBookManager
'        On Error Resume Next
        HotelBookingID = 0
        HotelBookingID = HotelBookingService.Reserve(10, ReserveHotelDetailFactory)
        If HotelBookingID > 0 Or Err.Number = 0 Then
            IsReserveHotel = True
            'MinCheckinDate = objCReserveHotelDetailFac.Item(1).BookCheckIn
            'MaxCheckoutDate = objCReserveHotelDetailFac.Item(1).BookCheckOut
            For i = 1 To objCReserveHotelDetailFac.Count
                MinCheckinDate = FindMinDate(MinCheckinDate, objCReserveHotelDetailFac.Item(i).BookCheckIn)
                MaxCheckoutDate = FindMaxDate(MaxCheckoutDate, objCReserveHotelDetailFac.Item(i).BookCheckOut)
            Next i
    Set TourService = CreateObject("TourBookingService.IBookViewer")
            'keng edit
            Set objHotelBookingDetailFac = TourService.GetHotelBookingDetail(HotelBookingID)
            '---------
    Set TourService = Nothing
            For i = 1 To objHotelBookingDetailFac.Count
                HotelBookingPrice = HotelBookingPrice + objHotelBookingDetailFac.Item(i).BookingPrice
            Next i
   
        Else
'            IsReserveHotel = False
            HotelBookingID = 0
        End If
        On Error GoTo handler
    End If
    End If
    'msgbox "MinCheckinDate = " & MinCheckinDate

'=====================End Reserve Hotel==========




'=====================Begin Reserve Bus=================
 BusBookingPrice = 0
 If Not ReserveBusDetailFactory Is Nothing Then
'   Call function ReserveBus
    'BusbookingID = 0
'    On Error Resume Next
        BusbookingID = "0"
        BusbookingID = SOAPReserveBUS(10, ReserveBusDetailFactory)
        IsReserveBus = True
'    On Error GoTo handler
       'MinBusDepartDate = ReserveBusDetailFactory.Item(1).DepartDate
       'MaxBusDepartDate = ReserveBusDetailFactory.Item(1).DepartDate
       
       For i = 1 To ReserveBusDetailFactory.Count
            MinBusDepartDate = FindMinDate(MinBusDepartDate, ReserveBusDetailFactory.Item(i).DepartDate)
            MaxBusDepartDate = FindMaxDate(MaxBusDepartDate, ReserveBusDetailFactory.Item(i).DepartDate)
       Next i
 Set TourService = CreateObject("TourBookingService.IBookViewer")
        'keng edit
       'Set BusBookingInfoFac = TourService.ViewBusBookinginfo(BusbookingID)
       
       Set BusBookingInfoFac = TourService.ViewBusBookinginfo2(BusbookingID)
       '------------
 Set TourService = Nothing
       For i = 1 To BusBookingInfoFac.Count
            BusBookingPrice = BusBookingPrice + (BusBookingInfoFac.Item(i).Price * BusBookingInfoFac.Item(i).totalseat)
       Next i
        '--------------------------
        Set ReserveAirlineDetailFactory = Nothing
        Set BusBookingInfoFac = Nothing
        '--------------------------
        
            
Else
    BusbookingID = "0"
End If

'======================Begin Reserve Airline==================
AirlineBookingPrice = 0
If Not ReserveAirlineDetailFactory Is Nothing Then
'   Call function ReserveAirline
    'AirlinebookingID = 0
'    On Error Resume Next
    AirlineBookingID = "0"
    AirlineBookingID = SOAPReserveAirline(10, ReserveAirlineDetailFactory)
    IsReserveAir = True
       'MinAirlineDepartDate = ReserveAirlineDetailFactory.Item(1).DepartDate
       'MaxAirlineDepartDate = ReserveAirlineDetailFactory.Item(1).DepartDate
       For i = 1 To ReserveAirlineDetailFactory.Count
            MinAirlineDepartDate = FindMinDate(MinAirlineDepartDate, ReserveAirlineDetailFactory.Item(i).DepartDate)
            MaxAirlineDepartDate = FindMaxDate(MaxAirlineDepartDate, ReserveAirlineDetailFactory.Item(i).DepartDate)
       Next i
  Set TourService = CreateObject("TourBookingService.IBookViewer")
       Set AirlineBookingInfoFac = TourService.ViewAirlineBookinginfo(AirlineBookingID)
  Set TourService = Nothing
       For i = 1 To AirlineBookingInfoFac.Count
            AirlineBookingPrice = AirlineBookingPrice + (AirlineBookingInfoFac.Item(i).Price * AirlineBookingInfoFac.Item(i).totalseat)
       Next i
Else
    AirlineBookingID = "0"
End If

    'clean---------------
    Set TourService = Nothing
    '-------------------
'=====================Begin Reserve Package====================
    PackageBookingPrice = 0
    If Not ReservePackageDetailFactory Is Nothing Then
    Set objCReservePackageDetailFac = ReservePackageDetailFactory
    'objCReservePackageDetailFac.Serialize = ReservePackageDetailFactory.Serialize
'If ReservePackageDetailFactory <> nothing then
    'If objCReservePackageDetailFac.internalCRecocdset.RowCount <> 0 Then
    '==========Begin Reserve Package=======
        'objCParams.Add "SQL", ""
        For i = 1 To objCReservePackageDetailFac.Count
             With objCReservePackageDetailFac
                MinPackageDepartDate = FindMinDate(MinPackageDepartDate, .Item(i).DepartDate)
                MaxPackageDepartDate = FindMaxDate(MaxPackageDepartDate, .Item(i).DepartDate)
                DepartDateStr = Month(.Item(i).DepartDate) & "/" & Day(.Item(i).DepartDate) & "/" & Year(.Item(i).DepartDate)
                'check that PackageDeparture is not full
                query = "select AdultPrice,ChildPrice,MaxTraveller - NumOfTraveller as DifTraveller from PackageDeparture where PackageID = " & .Item(i).PackageID & " and DepartDate ='" & DepartDateStr & "'"
                objCParams.Item("SQL") = query
                Set objCRecordset = objCDAL.ExecuteCommand(objCParams)
                'if PackageDeparture is not full then reserve
                If .Item(i).colTraveller.Count <= objCRecordset.Fields("DifTraveller").Value Then
                    'BookingPrice = 0
                    For j = 1 To .Item(i).colTraveller.Count
                        age = CalculateAge(.Item(i).colTraveller.Item(j).BirthDate, .Item(i).DepartDate)
                        If age >= 15 Then
                            PackageBookingPrice = PackageBookingPrice + objCRecordset.Fields("AdultPrice").Value
                        Else
                            PackageBookingPrice = PackageBookingPrice + objCRecordset.Fields("ChildPrice").Value
                        End If
                    Next j
                    ' add booking to packagebooking
                    query = "insert into PackageBooking(BookingID,ItemNo,PackageID,DepartDate,BookingPrice) values(" & mBookingID & "," & i & "," & .Item(i).PackageID & ",'" & DepartDateStr & "'," & PackageBookingPrice & ")"
                    objCParams.Item("SQL") = query
                    objCDAL.ExecuteCommand objCParams
 
                    
                    
                    For j = 1 To .Item(i).colTraveller.Count
                        BirthDateStr = .Item(i).colTraveller.Item(j).BirthDate
                        BirthDateStr = Month(.Item(i).colTraveller.Item(j).BirthDate) & "/" & Day(.Item(i).colTraveller.Item(j).BirthDate) & "/" & Year(.Item(i).colTraveller.Item(j).BirthDate)
                        query = "insert into PackageBookingDetail(BookingID,ItemNo,TravellerNo,TravellerName,BirthDate) values(" & mBookingID & "," & i & "," & j & ",'" & .Item(i).colTraveller.Item(j).TravellerName & "','" & BirthDateStr & "')"
                        Debug.Print query
                        objCParams.Item("SQL") = query
                        objCDAL.ExecuteCommand objCParams
                        
                    Next j
                    'update NumOfTraveller
                    query = "update PackageDeparture set NumOfTraveller = NumOfTraveller + " & .Item(i).colTraveller.Count & " where PackageID =" & .Item(i).PackageID & " and DepartDate ='" & DepartDateStr & "'"
                    objCParams.Item("SQL") = query
                    objCDAL.ExecuteCommand objCParams
                    'DepartDateStr = Day(.Item(i).DepartDate) & "/" & Month(.Item(i).DepartDate) & "/" & Year(.Item(i).DepartDate)
                    '.internalCRecocdset.MoveNext
                End If
             
             End With
        Next i 'end loop i
    '==========End Reserve Package=========
    End If 'If objCReservePackageDetailFac <> Nothing

    'keng-------
    Set objCDAL = New DALDB.CDAL
    Set objCParams = New DALDB.CParams
    objCDAL.OpenDb (2)
    objCParams.Add "SQL", ""
    '------------


'Calculate TotalPrice in Booking (Hotel.TotalPrice + Bus.TotalPrice + Airline.TatalPrice + Package.TotalPrice)
    TotalPrice = HotelBookingPrice + BusBookingPrice + AirlineBookingPrice + PackageBookingPrice
'Calculate ConfirmDeadline = The first date in all booking - 7
    ConfirmDeadline = FindMinDate(MinPackageDepartDate, FindMinDate(MinAirlineDepartDate, FindMinDate(MinCheckinDate, MinBusDepartDate))) - 7
    ConfirmDeadlineStr = Month(ConfirmDeadline) & "/" & Day(ConfirmDeadline) & "/" & Year(ConfirmDeadline)
'Calculate ObsoletedDate = The Last date in all Booking
    ObsoleteDate = FindMaxDate(MaxPackageDepartDate, FindMaxDate(MaxAirlineDepartDate, FindMaxDate(MaxCheckoutDate, MaxBusDepartDate)))
    ObsoleteDateStr = Month(ObsoleteDate) & "/" & Day(ObsoleteDate) & "/" & Year(ObsoleteDate)
'Update Hotel,Bus,AirlineBookingID,TotalPrice,ConfirmDeadline and ObsolateDate where BookingID = mBookingID
    query = "update Booking set HotelBookingID=" & HotelBookingID & ", BusBookingID='" & BusbookingID & "', AirlineBookingID='" & AirlineBookingID & "', TotalPrice=" & TotalPrice & ", ConfirmDeadline='" & ConfirmDeadlineStr & "', ObsoleteDate='" & ObsoleteDateStr & "' where BookingID=" & mBookingID
'    Debug.Print query
    objCParams.Item("SQL") = query
    '-----------------
    objCDAL.ExecuteCommand objCParams
    IsReservePackage = True
    
    objCDAL.CloseDb
    'objObjectContext.SetComplete
    Set objObjectContext = Nothing
Exit Function

handler:
    'objObjectContext.SetAbort
'---------------------
' Hotel error ->do nothing
' Bus error -->rollback hotel
' airError --> rollback hotel , bus
    If Not (ReserveAirlineDetailFactory Is Nothing) And IsReserveAir = False And Not (ReserveBusDetailFactory Is Nothing) Then
        On Error Resume Next
         bus.CancelBooking BusbookingID
         If Err.Number <> 0 Then
             fso.OpenTextFile "UnReserveLog.txt", ForAppending, True
             Set objFile = fso.GetFile("UnReserveLog.txt")
             Set objTS = objFile.OpenAsTextStream(ForAppending)
             objTS.WriteLine "BusBookingID = " & BusbookingID
             objTS.Close
         End If
    End If
'package error --> rollback hotel ,bus ,air
   ' rollback bus
    If Not (ReservePackageDetailFactory Is Nothing) And IsReservePackage = False And Not (ReserveBusDetailFactory Is Nothing) Then
       On Error Resume Next
        bus.CancelBooking BusbookingID
            If Err.Number <> 0 Then
                fso.OpenTextFile "UnReserveLog.txt", ForAppending, True
                Set objFile = fso.GetFile("UnReserveLog.txt")
                Set objTS = objFile.OpenAsTextStream(ForAppending)
                objTS.WriteLine "BusBookingID = " & BusbookingID
                objTS.Close
            End If

    End If
   ' rollback air
    If Not (ReservePackageDetailFactory Is Nothing) And IsReservePackage = False And Not (ReserveAirlineDetailFactory Is Nothing) Then
       On Error Resume Next
        air.CancelBooking AirlineBookingID
        If Err.Number <> 0 Then
            fso.OpenTextFile "UnReserveLog.txt", ForAppending, True
            Set objFile = fso.GetFile("UnReserveLog.txt")
            Set objTS = objFile.OpenAsTextStream(ForAppending)
            objTS.WriteLine "AirlineBookingID = " & AirlineBookingID
            objTS.Close
        End If
    End If
'---------------------
    Reserve = -1
    Err.Raise Err.Number, Err.Source, Err.Description
End Function

%>