<%@ Language=VBScript %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>

<BODY>

<P>&nbsp;</P>
<%
'on error resume next
dim a, b ,c  
dim Country,State,City,HotelName,MinStar,MaxStar,RoomModelName,MinPrice,MaxPrice,CheckIndate,CheckOutDate,AmountOfRoom
set objHotelSearchResults = server.CreateObject("DALDB.CHotelSearchResultFactory")
set objSearch = server.CreateObject("HotelService.IHotelSearcher")
dim id,star,priceRate
dim tmp1,tmp2,tmp3
dim HotelCnt
' Check an reformat Input 
Country = Request.Form.Item("Country")
State =  Request.Form.Item("State")
	if State = "any" then State ="" end if
City =  Request.Form.Item("City")
	if City = "any" then City ="" end if
HotelName =  Request.Form.Item("HotelName")
Star =  Request.Form.Item("Star")
RoomModelName = Request.Form.Item("RoomModelName") 
	if RoomModelName = "any" then RoomModelName ="" end if
PriceRate =  Request.Form.Item("PriceRate")
CheckInDate = request.Form.Item("CheckInDate")
CheckOutDate =  Request.Form.Item("CheckOutDate")
AmountOfRoom =  Request.Form.Item("AmountOfRoom")
	if AmountOfRoom = "" then AmountOfRoom = 1 end if

select case star
	case "1-2"	Minstar = 1
				maxstar = 2
	case "2-3"	Minstar = 2
				maxstar = 3
	case "3-4"	Minstar = 3
				maxstar = 4
	case "4-5"	Minstar = 4
				maxstar = 5
	case "1-5"	Minstar = 1
				maxstar = 5
	case ELSE 	Minstar = 1
				maxstar = 5				
end select

SELECT case Pricerate
	case "0-1000"		MinPrice = 0
						MaxPrice = 1000
	case "1001-2000"	MinPrice = 1001
						MaxPrice = 2000
	case "2001-3000"	MinPrice = 2001
						MaxPrice = 3000
	case "3001-4000"	MinPrice = 3001
						MaxPrice = 4000
	case "4001-5000"	MinPrice = 4001
						MaxPrice = 5000
	case "5001-1000000"	MinPrice = 5001
						MaxPrice = 1000000
	case else			MinPrice = 0
						MaxPrice = 1000000
end select

	
' call method Search and Deserialize
	set tmp1 = objSearch.SearchHotel(Cstr(Country),cstr(State),cstr(City),cstr(HotelName),cint(MinStar),cint(MaxStar),Cstr(RoomModelName),ccur(MinPrice),ccur(MaxPrice),cdate(CheckIndate),cdate(CheckOutDate),Cint(AmountOfroom))
	if Err.number = vbObjectError+1 then
		Response.Write "Can't find Hotel that you want"
	end if
	tmp1.Serialize a,b,c
	objHotelSearchResults.DeSerialize a,b,c

	HotelCnt = objHotelSearchResults.Count

%>

Country : <%=Country%> <BR>
state :<%=state%> <BR>
city :<%=city%> <BR>
HotelName :<%=HotelName%> <BR>
star : <%=star%> <br>
MinStar :<%=MinStar%> <BR>
MaxStar :<%=MaxStar%> <BR>
RoomType :<%=RoomModelName%> <BR>
PriceRate : <%=Pricerate%> <br>
MinPrice :<%=MinPrice%> <BR>
MaxPrice :<%=MaxPrice%> <BR>
In :<%=CheckInDate%> <BR>
Out :<%=CheckOutDate%> <BR>
Amount :<%=AmountOfRoom%> <BR>

</BODY>
</HTML>
