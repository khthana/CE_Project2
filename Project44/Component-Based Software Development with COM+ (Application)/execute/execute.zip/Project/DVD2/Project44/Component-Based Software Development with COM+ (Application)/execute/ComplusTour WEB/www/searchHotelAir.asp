<html>
<head>
<title> Reserve Hotel</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
   <link rel="stylesheet" type="text/css" href="homestyle.css" >
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" >
<table width="90%" align=center>
	  <tr>
	  	<td>
	  	  
      <SCRIPT language=javascript src="calendar.js"></SCRIPT>
      <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
<IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1; left: 66px; top: 260px" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm"></IFRAME> 
      <form name="form2" method="post" action="TourSearchResultHotelAir.asp">
        <table width="85%" border="0" cellspacing="0" cellpadding="0" align="left">
          <tr> 
            <td colspan="4" height="42"> 
              <div align="left"><font face="MS Sans Serif" size="-1"><img src="images/SearchHotelAir.gif" width="420" height="24"></font></div>
            </td>
          </tr>
          <tr> 
            <td colspan="2"><font size="-1" color="#6B8EC6"><b><font color="#003399">�͡�Թ�ҧ�ҡ</font></b></font></td>
            <td colspan="2"><font size="-1" color="#6B8EC6"><b><font color="#003399">�ç�������ͧ���</font></b></font></td>
          </tr>
          <tr> 
            <td colspan="2"><font size="-1"> 
              <select name="departureAirport" class="smallform">
                <option value="YVR,᤹�Ҵ�,�ǹ�������">Vancuver(YVR)</option>
                <option value="DFW,����ԡ�,������">Dallas Fort Worth(DFW)</option>
                <option value="BKK,��,��ا෾" selected>Bangkok</option>
                <option value="CNX,��,��§����">Chiang Mai</option>
              </select>
              </font></td>
            <td colspan="2"><font size="-1"> 
              <input type="text" name="HotelName" class="textbox" size="20">
              </font></td>
          </tr>
          <tr> 
            <td width="38%" height="25" valign="bottom"><font size="-1" color="#003399"><b>�ѹ�͡ 
              </b></font></td>
            <td width="23%" height="25" valign="bottom"><font size="-1" color="#003399"><b>�����͡</b></font></td>
            <td colspan="2" height="25" valign="bottom"><b><font size="-1" color="#003399">��Դ��ͧ</font></b></td>
          </tr>
          <tr> 
            <td width="38%"><font size="-1"> 
              <%
					InDate = Request.Cookies("InDate")
					If Indate = "" then
					Indate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
					OutDate = Request.Cookies("OutDate")
					If OutDate = "" then
					OutDate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
				%>
              <input id=txtbox1 class="textbox" type="text" name="InDate" value='<%=InDate%>' onChange="javascript:cbfloadmefirst('form2', 'InDate');" size="13" maxlength="10">
              &nbsp;<a href="javascript:cbfshowcalendar('form2', 'InDate', 'txtbox1')"><img src="images/calendar.gif" width="34" height="21" border="0"></a> 
              </font></td>
            <td width="23%"><font size="-1"> 
              <select name="departureTime" class="smallform">
                <option value="0" selected>����к�</option>
                <option value="00:00:00">00:00:00</option>
                <option value="01:00:00">01:00:00</option>
                <option value="02:00:00">02:00:00</option>
                <option value="03:00:00">03:00:00</option>
                <option value="04:00:00">04:00:00</option>
                <option value="05:00:00">05:00:00</option>
                <option value="06:00:00">06:00:00</option>
                <option value="07:00:00">07:00:00</option>
                <option value="08:00:00">08:00:00</option>
                <option value="09:00:00">09:00:00</option>
                <option value="10:00:00">10:00:00</option>
                <option value="11:00:00">11:00:00</option>
                <option value="12:00:00">12:00:00</option>
                <option value="13:00:00">13:00:00</option>
                <option value="14:00:00">14:00:00</option>
                <option value="15:00:00">15:00:00</option>
                <option value="16:00:00">16:00:00</option>
                <option value="17:00:00">17:00:00</option>
                <option value="18:00:00">18:00:00</option>
                <option value="19:00:00">19:00:00</option>
                <option value="20:00:00">20:00:00</option>
                <option value="21:00:00">21:00:00</option>
                <option value="22:00:00">22:00:00</option>
                <option value="23:00:00">23:00:00</option>
              </select>
              </font></td>
            <td colspan="2"><font size="-1"> 
              <select name="RoomModelName">
                <option value="any" selected><font size="-1">����к�</font></option>
                <option value="Superior-single"><font size="-1">Superior-single</font></option>
                <option value="Superior-twin"><font size="-1">Superior-twin</font></option>
                <option value="Deluxe-single"><font size="-1">Deluxe-single</font></option>
                <option value="Deluxe-twin"><font size="-1">Deluxe-twin</font></option>
                <option value="Executive-single"><font size="-1">Executive-single</font></option>
                <option value="Executive-twin"><font size="-1">Executive-twin</font></option>
                <option value="Carnation suit"><font size="-1">Carnation suit</font></option>
              </select>
              </font></td>
          </tr>
          <tr valign="bottom"> 
            <td height="26" colspan="2"><font size="-1" color="#003399"><b>���·ҧ���</b></font></td>
            <td colspan="2" height="26"><b></b><b><font size="-1" color="#003399">��ǧ�Ҥ�(�ҷ)</font></b></td>
          </tr>
          <tr> 
            <td colspan="2"><font size="-1"> 
              <select name="destinationAirport" class="smallform">
                <option value="YVR,᤹�Ҵ�,�ǹ�������">Vancuver(YVR)</option>
                <option value="DFW,����ԡ�,������" >Dallas Fort Worth(DFW)</option>
                <option value="BKK,��,��ا෾">Bangkok</option>
                <option value="CNX,��,��§����" selected>Cheng Mai</option>
              </select>
              </font></td>
            <td colspan="2"><font size="-1"> 
              <select name="PriceRate">
                <option value="0-1000000" selected><font size="-1">����к�</font></option>
                <option value="0-1000"><font size="-1">��ӡ��� 1,000</font></option>
                <option value="1001-2000"><font size="-1">1,000 - 2,000</font></option>
                <option value="2001-3000"><font size="-1">2,000 - 3,000</font></option>
                <option value="3001-4000"><font size="-1">3,000 - 4,000</font></option>
                <option value="4001-5000"><font size="-1">4,000 - 5,000</font></option>
                <option value="5001-1000000"><font size="-1">5,000 ����</font></option>
              </select>
              </font></td>
          </tr>
          <tr valign="bottom"> 
            <td height="27" width="38%"><font size="-1" color="#003399"><b>�ѹ��Ѻ</b></font></td>
            <td height="27" width="23%"><font size="-1" color="#003399"><b>���ҡ�Ѻ</b></font><font size="-1" color="#003399"></font></td>
            <td width="17%" height="27"><b><font size="-1" color="#003399">�дѺ(���)</font></b></td>
            <td width="22%" height="27"><b><font size="-1" color="#003399"><b>�ӹǹ��</b></font><font size="-1"></font></b></td>
          </tr>
          <tr> 
            <td height="31" width="38%"><font size="-1"> 
              <input id="txtbox2" class="textbox" type="text" name="OutDate" value='<%=OutDate%>' onChange="javascript:cbfloadmefirst('form2', 'OutDate');" size="13" maxlength="10">
              &nbsp;&nbsp;&nbsp;&nbsp; <a href="javascript:cbfshowcalendar('form2', 'OutDate', 'txtbox2')"><img src="images/calendar.gif" width="34" height="21" border="0"></a> 
              </font></td>
            <td height="31" width="23%"><font size="-1"> 
              <select name="returnTime" class="smallform">
                <option value="0" selected>����к�</option>
                <option value="00:00:00">00:00:00</option>
                <option value="01:00:00">01:00:00</option>
                <option value="02:00:00">02:00:00</option>
                <option value="03:00:00">03:00:00</option>
                <option value="04:00:00">04:00:00</option>
                <option value="05:00:00">05:00:00</option>
                <option value="06:00:00">06:00:00</option>
                <option value="07:00:00">07:00:00</option>
                <option value="08:00:00">08:00:00</option>
                <option value="09:00:00">09:00:00</option>
                <option value="10:00:00">10:00:00</option>
                <option value="11:00:00">11:00:00</option>
                <option value="12:00:00">12:00:00</option>
                <option value="13:00:00">13:00:00</option>
                <option value="14:00:00">14:00:00</option>
                <option value="15:00:00">15:00:00</option>
                <option value="16:00:00">16:00:00</option>
                <option value="17:00:00">17:00:00</option>
                <option value="18:00:00">18:00:00</option>
                <option value="19:00:00">19:00:00</option>
                <option value="20:00:00">20:00:00</option>
                <option value="21:00:00">21:00:00</option>
                <option value="22:00:00">22:00:00</option>
                <option value="23:00:00">23:00:00</option>
              </select>
              </font></td>
            <td width="17%" height="31"><font size="-1"> 
              <select name="Star">
                <option value="1-5" selected><font size="-1">����к�</font></option>
                <option value="1-2"><font size="-1">1 - 2</font></option>
                <option value="2-3"><font size="-1">2 - 3</font></option>
                <option value="3-4"><font size="-1">3 - 4</font></option>
                <option value="4-5"><font size="-1">4 - 5</font></option>
              </select>
              </font></td>
            <td width="22%" height="31"><b><font size="-1"> 
              <%
					Amt = Request.Cookies("Amt")
					If Amt = "" then
					Amt = 1
					end if
						
					%>
              <input type="text" name="Amount" value="<%=Amt%>" class=textbox size="5">
              </font></b></td>
          </tr>
          <tr valign="bottom"> 
            <td colspan="4" height="44"> 
              <div align="center"> 
                <input type="submit" name="Search" value="Search !!" class="button">
                <b><font size="-1"> 
                <input type="reset" name="Submit4" value="Reset" class="button">
                </font></b> </div>
            </td>
          </tr>
        </table>
        
              </form>
			  </td>
		  </tr>
	  </table>
</body>
</html>