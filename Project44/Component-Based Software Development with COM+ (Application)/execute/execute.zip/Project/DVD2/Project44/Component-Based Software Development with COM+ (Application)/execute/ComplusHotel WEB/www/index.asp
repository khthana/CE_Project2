<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title> OLALA HOTEL :: MAIN </title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css">

  <link rel="stylesheet" type="text/css" href="Templates/style.css">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" topMargin= 0>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>
<table width="98%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="52" colspan="2" > <!--
      <p><b><font face="Arial, Helvetica, sans-serif" size="+2" color="6B8EC6"><font color="#FFFFFF">OLALA 
        HOTEL</font> </font></b></p>-->
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td width="5%">&nbsp;</td>
			<td align="center" valign="bottom"> 
				<img src="images/hd_hotel_pic1.gif" height="60"> </td>
			<td align="center" valign="top"> 
				<img src="images/hd_hotel_pic.gif" height="60"> </td>
			<td align="center" valign="middle"> 
				<img src="images/hd_hotel_pic2.gif"  height="60"> </td>

			<td align="right"> <img src="images/hd_olalahotel.gif"> </td>
		</tr>
		</table>

    </td>
  </tr>
 <!-- <tr> 
    <td bgcolor="#006699" width="36%">&nbsp;&nbsp;&nbsp;
		<a href="../index.asp" class=z1>Main</a>|
		<a href="#" class=z1> Search </a>|
		<a href="../basket.asp" class=z1>View Basket</a>| 
		<a href="../index.asp" class=z1>About Us  </a>|</td>
    <td bgcolor="#006699" width="64%"> 
      <div align="right"><font color="#FFFFFF" size="-1">Disclimer | Policies 
        | Feedback | FAQ | Help | About | Coutact Us</font></div>
    </td>
  </tr>-->
  <tr>
  <td>
  <table width="99%" border="0" cellspacing="1" cellpadding="0" align="center" bgcolor="black">
  <tr bgcolor="#FF6666"> 
    <td bgcolor="#FFCC99" width="17%" align="center" class="head5">
      <a href="index.asp" class="link1"><b>Main</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp"  class="link1"><b>Search</b></a>
    </td>

    <td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="basket.asp" class="link1"><b>View Basket</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp" class="link1"><b>About Us</b></a>
    </td>

  </tr>
	<tr>
          <td align="right" colspan="4" bgcolor="#76CCFF" height=4><img src="images/1x1b.gif" border="0" /></td>
    </tr>

</table>
</td>
</tr>

</table>


<table width="99%" border="0" cellspacing="0" cellpadding="5" align="center" height="600">
  <tr> 
    <td width="17%" bgcolor="#D7DCE8" height="330" valign="top" align="center"> 
      <%
	on error resume next
			cmd = Request.Form("cmd")
			Email = Request.Form("Email")
			Password = Request.Form("Password")
			'frompage = request("frompage")		
			'pagename=request.servervariables("script_name")
	
			if cmd = "login" then
			set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
			CustomerID = objCustomer.Login(Cstr(Email),Cstr(Password))
					if err.number = 0 and CustomerID > 0 then
						Response.Cookies("CustomerID") = CustomerID
						Response.Cookies("CustomerID").expires = date+1
'						Response.Cookies("BasketID").expires = now
						
							
							if request.servervariables("script_name") = "/complushotel/www/loginerror.asp" then
								response.redirect("myreservation.asp")
							end if

					else
							select case err.number 
								case vbObjectError+1 err_txt = "notfound"
								case vbObjectError+5 err_txt = "wrongpassword"
							end select
						err_txt = "loginerror.asp?err="  & err_txt 
						response.redirect(err_txt)
					end if  
			end if		    	
		'	cmd  = request.querystring("cmd")
			if cmd="logout" then
						Response.Cookies("BasketID").expires = now
						Response.Cookies("CustomerID").expires = now
						Response.Cookies("BasketID") =""
						Response.Cookies("CustomerID") = ""

			end if
	
			
			CustomerID = Request.Cookies("CustomerID")
			'response.write CustomerID
			if CustomerID = "" then
			'' render login box
%>
      <form name="form1" method="post" action="">
        <table width="130" border="0" cellspacing="0" cellpadding="0" align="center" >
          <tr align="center" > 
            <td  width="130" height=25 >
				<div align="center"><img src="images/login.gif" ></div>
            </td>
          </tr>
          <tr> 
            <td width="130" class="head7"><br><b>   E-mail address </b></td>
          </tr>
          <tr> 
            <td height="15" width="130"> <font size="-1"> 
              <input type="text" name="Email" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td width="130" class="head7" height=20 valign="bottom"><b>Password</b></td>
          </tr>
          <tr> 
            <td width="130"> <font size="-1"> 
              <input type="password" name="Password" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td height="10" width="130"> 
              <div align="center"><font size="-1"> 
			   
				<input type="hidden" name="cmd" value="login">
			  	<input type="hidden" name="country" value="<%=Request.Form.Item("Country")%>">
			  	<input type="hidden" name="state" value="<%=Request.Form.Item("State")%>">
			  	<input type="hidden" name="city" value="<%=Request.Form.Item("City")%>">
			  	<input type="hidden" name="star" value="<%=Request.Form.Item("star")%>">
			  	<input type="hidden" name="HotelName" value="<%=Request.Form.Item("HotelName")%>">
			  	<input type="hidden" name="RoomModelName" value="<%=Request.Form.Item("RoomModelName")%>">
			  	<input type="hidden" name="PriceRate" value="<%=Request.Form.Item("PriceRate")%>">
			  	<input type="hidden" name="CheckInDate" value="<%=Request.Form.Item("CheckInDate")%>">
			  	<input type="hidden" name="CheckOutDate" value="<%=Request.Form.Item("CheckOutDate")%>">
			  	<input type="hidden" name="AmountOfRoom" value="<%=Request.Form.Item("AmountOfRoom")%>">
			<br><br>
							<input type="submit" name="Submit" value="Login" class="smbutton">
                <input type="reset" name="Submit2" value="Reset" class="smbutton">
                <br><br>
                <a href="lostpassword.asp"> ������ʼ�ҹ </a><br>
                <a href="register.asp"> ��Ѥ���Ҫԡ���� </a></font></div>
            </td>
          </tr>
        </table>
      </form>
<%
			else
			 'show customer name and render customer menu 
				set Customers = Server.CreateObject("DALDB.CCustomerFactory")
				set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
				customers.Serialize  = objCustomer.GetCustomer(clng(CustomerID)).Serializer
				CustomerName = Customers.item(1).CustomerName
%>

      <table width="130" border="0" cellspacing="1" cellpadding="0" align="center" dwcopytype="CopyTableRow">
        <tr > 
          <td bgcolor="#3B8EC6" height="38" align=center><font size="-1" color="#FFFFFF"><b>���ʴդ�Ѻ 
            <br>
            �س <%=CustomerName%> </b></font></td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26"> 
            <div align="center"><font size="-1"><a href="MyProfile.asp" class="z2"> ��䢢�����</a></font></div> 
          </td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26" > 
            <div align="center"><font size="-1"><a href="MyReservation.asp" class="z2"> ��¡�èͧ</a></font></div>
          </td>
        </tr>
        <tr> 
          <td height="15" bgcolor="#6B8EC6" width="116"><br>
<div align="center">
              <form name="formx" method="post" action="index.asp">
                <input type="hidden" name="cmd" value="logout">
                <!--<input type="image" name="Submit" value="logout" src="../images/viewonmap.gif" width="70" height="13">-->
				<input type="submit" name="Submit" value="logout" class="button">
				
			  </form>
              </div>
          </td>
        </tr>
      </table>
<%
			end if ' render login box OR menu
%>
    </td>
    <td width="625" height="249" valign="top"> 
		<table width="95%" align="center">
			<tr>
				<td>
					<!-- #BeginEditable "Center_Content" --><br>
	  <table border='0'  bgcolor='FFFFFF' width='95%' height="10"  align='center'><!-- bgcolor='#C0C0C0' -->
	 <tr>

	  <TD bgColor='#D99B91' height=12 width="100%" ><!--   #F5B836 -->
			<!-- <DIV align=center> --><FONT face="MS Sans Serif" color=#F8F8F8 size="-8"><B>�����ç���</B></FONT><!-- </DIV> -->
			<IMG SRC="images/Icon_hotels.gif" WIDTH="33" HEIGHT="24" BORDER=0 ALT="">
		</TD>

	  </tr>
	  </table> 
      <SCRIPT language=javascript src=calendar.js></SCRIPT>
      <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
            <IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1; left: 5px; top: 350px" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm"></IFRAME> 
            <form name="form2" method="post" action="SearchResulttmp.asp">
       <!-- <table border="0" cellspacing="0" cellpadding="0" align="center" width="85%" bgcolor='#E8E8E8'>
          <tr> 
		  	<td width="22">&nbsp;</td>
            <td colspan="2"><font size="-1" color="#6B8EC6">�����</font></td>
                  <td width="107"><font size="-1" color="#6B8EC6">�дѺ(���)</font></td>
            <td width="170"><font size="-1" color="#6B8EC6">�ѹ��Ҿѡ</font></td>
          </tr>
          <tr> 
		  	<td width="22">&nbsp;</td>
            <td colspan="2"> <font size="-1"> 
              <select name="Country">
                <option value="Canada">Canada</option>
                <option value="England">England</option>
                <option value="U.S.A.">U.S.A.</option>
                <option value="Thailand" selected>Thailand</option>
                <option value="China">China</option>
                <option value="Singapore">Singapore</option>
                <option>Hongkong</option>
                <option>Australia</option>
                <option>Malaysia</option>
                <option>Indonesia</option>
              </select>
              </font></td>
            <td width="107"> <font size="-1"> 
              <select name="Star">
                <option value="1-5" selected>����к�</option>
                <option value="1-2">1 - 2</option>
                <option value="2-3">2 - 3</option>
                <option value="3-4">3 - 4</option>
                <option value="4-5">4 - 5</option>
              </select>
              </font></td>
            <td width="170"><font size="-1"> 
             
              <INPUT ID=txtbox1 class="textbox" type="text" name="CheckInDate" value='<%=Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543%>' onchange="javascript:cbfloadmefirst('form2', 'CheckInDate');" size="13" maxlength="10">
              <a href="javascript:cbfshowcalendar('form2', 'CheckInDate', 'txtbox1')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font></td>
          </tr>
          <tr> 
		  	<td width="22">&nbsp;</td>
            <td width="119"><font size="-1" color="#6B8EC6">�Ѱ</font></td>
            <td width="96"><font size="-1" color="#6B8EC6">���ͧ</font></td>
            <td width="107"><font size="-1" color="#6B8EC6">��Դ��ͧ</font></td>
            <td width="170"><font size="-1" color="#6B8EC6">�ѹ�͡</font></td>
          </tr>
          <tr> 
		  	<td width="22">&nbsp;</td>
            <td width="119"> <font size="-1"> 
              <select name="State">
                <option value="any" selected>����к�</option>
                <option>California</option>
                <option value="Bangkok"><font size="-1">Bangkok</font></option>
                <option><font size="-1">Chaingmai</font></option>
                <option><font size="-1">Chaingrai</font></option>
                <option><font size="-1">Khonkan</font></option>
                <option><font size="-1">Ubonratchatanee</font></option>
                <option><font size="-1">Chonburi</font></option>
                <option><font size="-1">Trad</font></option>
                <option><font size="-1">Kanjanaburi</font></option>
                <option><font size="-1">Petchaburi</font></option>
                <option><font size="-1">Yala</font></option>
                <option><font size="-1">Narathivas</font></option>
                <option>Ohio</option>
              </select>
              </font></td>
            <td width="96"><font size="-1"> 
              <select name="City">
                <option value="any" selected>����к�</option>
                <option value="Bangkok">Bangkok</option>
                <option value="Denver">Denver</option>
                <option value="Atlanta">Atlanta</option>
              </select>
              </font></td>
            <td width="107"> <font size="-1"> 
              <select name="RoomModelName">
                <option value="any" selected>����к�</option>
                <option value="Standard">Standard</option>
                <option value="Deluxe">Deluxe</option>
                <option value="Premium">Premium</option>
              </select>
              </font></td>
            <td width="170"><font size="-1"> 
             
              <INPUT id=txtbox2  class=textbox type=text name="CheckOutDate" value='<%=Day(Date()) & "/" & Month(Date()) & "/" &  Year(Date())+543%>' onchange="javascript:cbfloadmefirst('form2', 'CheckOutDate');" size="13" maxlength="10">
              <a href="javascript:cbfshowcalendar('form2', 'CheckOutDate', 'txtbox2')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font></td>
          </tr>
          <tr> 
		  	<td width="22">&nbsp;</td>
            <td colspan="2"><font size="-1" color="#6B8EC6">�����ç���</font></td>
            <td width="107"><font size="-1" color="#6B8EC6">��ǧ�Ҥ�(�ҷ) </font></td>
            <td width="170"><font size="-1" color="#6B8EC6">�ӹǹ��ͧ</font></td>
          </tr>
          <tr> 
			  
                  <td width="22" height="30">&nbsp;</td>
                  <td colspan="2" height="30"> <font size="-1"> 
                    <input type="text" name="HotelName" class="textbox">
              </font></td>
                  <td width="107" height="30"> <font size="-1"> 
                    <select name="PriceRate">
                <option value="0-1000000" selected>����к�</option>
                <option value="0-1000">��ӡ��� 1,000</option>
                <option value="1001-2000">1,000 - 2,000</option>
                <option value="2001-3000">2,000 - 3,000</option>
                <option value="3001-4000">3,000 - 4,000</option>
                <option value="4001-5000">4,000 - 5,000</option>
                <option value="5001-1000000">5,000 ����</option>
              </select>
              </font></td>
                  <td width="170" height="30"><font size="-1"> 
                    <input type="text" name="AmountOfRoom" value="1" class=textbox size="5">
              </font><font size="-1" color="#6B8EC6"> </font></td>
          </tr>
          <tr> 
            <td colspan="5">&nbsp;</td>
          </tr>
          <tr> 
            <td colspan="5"> 
              <div align="center"> 
                <input type="submit" name="Search" value="Search !!" class="button">
                <input type="reset" name="Submit4" value="Reset" class="button">
              </div><br>
            </td>
          </tr>
        </table>   -->
              <table width="95%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="FFFBEA"><!--F5F8F5  -->

				<tr bordercolor="#FFFFFF" bgcolor="FFEFC0"> <!-- F8DA94 -->
                  <td width="34%" height="10" valign="bottom"><font size="-1" > <!-- color="#6B8EC6" -->
                    &nbsp;�����</font></td>
                  <td width="32%" height="10" valign="bottom"><font size="-1" >�����ç���</font></td><!-- height=''31 -->
                  <td width="17%" height="10" valign="bottom"><font size="-1" >�дѺ(���)</font></td>
                  <td width="14%" height="10" valign="bottom"><font size="-1" >�ӹǹ��ͧ</font></td>
                </tr>

				<tr bordercolor="#FFFFFF" height='12'>
				<td colspan='4'></td>
				</tr>

                <tr bordercolor="#FFFFFF"> 
                  <td width="34%"><font size="-1"> &nbsp;&nbsp;&nbsp;&nbsp; 
                    <select name="Country">
                      <!--option value="Canada">Canada</option>
                      <option value="England">England</option>
                      <option value="U.S.A.">U.S.A.</option>
                      --><option value="��" selected>��</option>
                      <!--<option value="China">China</option>
                      <option value="Singapore">Singapore</option>
                      <option>Hongkong</option>
                      <option>Australia</option>
                      <option>Malaysia</option>
                      <option>Indonesia</option>
                    --></select>
                    </font></td>
                  <td width="32%"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <input type="text" name="HotelName" class="textbox" size="20">
                    </font></td>
                  <td width="17%"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <select name="Star">
                      <option value="1-5" selected>����к�</option>
                      <option value="1-2">1 - 2</option>
                      <option value="2-3">2 - 3</option>
                      <option value="3-4">3 - 4</option>
                      <option value="4-5">4 - 5</option>
                    </select>
                    </font></td>
                  <td width="14%"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <input type="text" name="AmountOfRoom" value="1" class=textbox size="5">
                    </font></td>
                </tr>

				<tr bordercolor="#FFFFFF" height='12'>
				<td colspan='4'></td>
				</tr>

                <tr bordercolor="#FFFFFF" bgcolor="FFEFC0"> 
                  <td width="34%" height="10" valign="bottom"><font size="-1" >&nbsp;�Ѱ</font></td>
                  <td width="32%" height="10" valign="bottom"><font size="-1" >��Դ��ͧ</font></td>
                  <td height="10" valign="bottom" colspan="2"><font size="-1" >�ѹ��Ҿѡ</font></td>
                </tr>

				<tr bordercolor="#FFFFFF" height='12'>
				<td colspan='4'></td>
				</tr>

                <tr bordercolor="#FFFFFF"> 
                  <td width="34%"><font size="-1"> &nbsp;&nbsp;&nbsp;&nbsp; 
                    <select name="State">
                      <option value="any" selected>����к�</option>
                      <!--<option>California</option>
                      <option value="��ا෾"><font size="-1">��ا෾</font></option>
                      <option value="��§����"><font size="-1">��§����</font></option>
                      <option value="���ͧ"><font size="-1">���ͧ</font></option>
                      <option><font size="-1">�͹��</font></option>
                      <option><font size="-1">�غ��Ҫ�ҹ�</font></option>
                      <option><font size="-1">�ź���</font></option>
                      <option><font size="-1">��Ҵ</font></option>
                      <option><font size="-1">Kanjanaburi</font></option>
                      <option><font size="-1">Petchaburi</font></option>
                      <option><font size="-1">Yala</font></option>
                      <option><font size="-1">Narathivas</font></option>
                      <option>Ohio</option>
                    --></select>
                    </font></td>
                  <td width="32%"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <select name="RoomModelName">
                      <option value="any" selected>����к�</option>
                      <option value="Superior-single">Superior-single</option>
                      <option value="Superior-twin">Superior-twin</option>
                      <option value="Deluxe-single">Deluxe-single</option>
                      <option value="Deluxe-twin">Deluxe-twin</option>
                      <option value="Executive-single">Executive-single</option>
                      <option value="Executive-twin">Executive-twin</option>
                      <option value="Carnation suit">Carnation suit</option>
                    </select>
                    </font></td>
                  <td colspan="2"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <!--<input type="text" name="CheckInDate" maxlength="10" size="13" value="1/10/2544">  -->
                    <input id=txtbox1 class="textbox" type="text" name="CheckInDate" value='<%=Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543%>' onChange="javascript:cbfloadmefirst('form2', 'CheckInDate');" size="13" maxlength="10">
                    <a href="javascript:cbfshowcalendar('form2', 'CheckInDate', 'txtbox1')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font></td>
                </tr>

				<tr bordercolor="#FFFFFF" height='12'>
				<td colspan='4'></td>
				</tr>

                <tr bordercolor="#FFFFFF" bgcolor='FFEFC0'> 
                  <td width="34%" height="10" valign="bottom"><font size="-1" >&nbsp;���ͧ</font></td>
                  <td width="32%" height="10" valign="bottom"><font size="-1" >��ǧ�Ҥ�(�ҷ) 
                    </font></td>
                  <td height="10" colspan="2"><font size="-1" >�ѹ�͡</font><font size="-1"> 
                    </font></td>
                </tr>

				<tr bordercolor="#FFFFFF" height='12'>
				<td colspan='4'></td>
				</tr>

                <tr bordercolor="#FFFFFF"> 
                  <td width="34%"><font size="-1"> &nbsp;&nbsp;&nbsp;&nbsp; 
                    <select name="City">
                      <option value="any" selected>����к�</option>
                      <option value="��ا෾">��ا෾</option>
                      <option value="��§����">��§����</option>
                      <option value="���ͧ">���ͧ</option>
                    </select>
                    </font></td>
                  <td width="32%"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <select name="PriceRate">
                      <option value="0-1000000" selected>����к�</option>
                      <option value="0-1000">��ӡ��� 1,000</option>
                      <option value="1001-2000">1,000 - 2,000</option>
                      <option value="2001-3000">2,000 - 3,000</option>
                      <option value="3001-4000">3,000 - 4,000</option>
                      <option value="4001-5000">4,000 - 5,000</option>
                      <option value="5001-1000000">5,000 ����</option>
                    </select>
                    </font></td>
                  <td colspan="2"><font size="-1"> &nbsp;&nbsp;&nbsp; 
                    <!-- <input type="text" name="CheckOutDate" maxlength="10" size="13" value="1/10/2544"> -->
                    <input id=txtbox2  class=textbox type=text name="CheckOutDate" value='<%=Day(Date()) & "/" & Month(Date()) & "/" &  Year(Date())+543%>' onChange="javascript:cbfloadmefirst('form2', 'CheckOutDate');" size="13" maxlength="10">
                    <a href="javascript:cbfshowcalendar('form2', 'CheckOutDate', 'txtbox2')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font></td>
                </tr>
                <tr bordercolor="#FFFFFF"> 
                  <td width="34%" height="31">&nbsp;</td>
                  <td width="32%" height="31">&nbsp;</td>
                  <td height="31" colspan="2">&nbsp;</td>
                </tr>
                <tr bordercolor="#FFFFFF"> 
                  <td colspan="4"> 
                    <div align="center"> 
                <input type="submit" name="Search" value="Search !!" class="button">
                <input type="reset" name="Submit4" value="Reset" class="button">
              </div><br></td>
                </tr>
              </table>
              <p>&nbsp;</p>
            </form>
      <!-- #EndEditable -->
				</td>
			</tr>
		</table>				
	</td>
  </tr>
 <!-- <tr>
    <td width="148" bgcolor="#D7DCE8" height="28" valign="top">&nbsp; </td>
    <td width="631" height="28" valign="top">&nbsp;</td>
  </tr>-->
</table>
</body>
<!-- #EndTemplate --></html>
