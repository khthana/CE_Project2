<HTML>
	<HEAD><TITLE> OLALA Tour -> ��ԡ���Ѻ�ͧ�ç��� ������ ����� ���ö</TITLE>
	    <META http-equiv=Content-Type content="text/htm; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >

		<SCRIPT LANGUAGE="JavaScript">
		<!--
		function newImage(arg) {
			if (document.images) {
				rslt = new Image();
				rslt.src = arg;
				return rslt;
			}
		}

		function changeImages() {
			if (document.images && (preloadFlag == true)) {
				for (var i=0; i<changeImages.arguments.length; i+=2) {
					document[changeImages.arguments[i]].src = changeImages.arguments[i+1];
				}
			}
		}

		var preloadFlag = false;
		function preloadImages() {
			if (document.images) {
				home_01_over = newImage("images/home_01-over.gif");
				reshotel_01_over = newImage("images/reshotel_01-over.gif");
				respack_01_over = newImage("images/respack_01-over.gif");
				resbus_01_over = newImage("images/resbus_01-over.gif");
				resair_01_over = newImage("images/resair_01-over.gif");
				basket_01_over = newImage("images/basket_01-over.gif");
				preloadFlag = true;
			}
		}

		// -->
		</SCRIPT>

	</Head>


																	<!--  Begin BODY -->
								
<body ONLOAD="preloadImages();" bgColor=#ffffff topMargin=0 >
<TABLE cellSpacing=0 cellPadding=0 width=600 align=center border=0>
  <TR><td>
	<IMG height=86 src="images/title_index2.jpg"  width=749 align="center">
</td></tr>
<tr>
    <td> 
      <div align="center"><font size=-3>&nbsp;<a href="index.asp"><img src="images/top_Home.gif" width="90" height="20" border="0" align="absbottom"></a><a href="searchhotel.asp" target="home_center"><img src="images/top_Hotel.gif" width="90" height="20" border="0" align="absbottom"></a><a href="search.asp" target="home_center"><img src="images/top_package.gif" width="90" height="20" border="0" align="absbottom"></a><a href="searchair.asp" target="home_center"><img src="images/top_Airs.gif" width="90" height="20" border="0" align="absbottom"></a><a href="searchbus.asp" target="home_center"><img src="images/top_bus.gif" width="90" height="20" border="0" align="absbottom"></a><a href="searchHotelAir.asp" target="home_center"><img src="images/top_HotelAir.gif" width="90" height="20" border="0" align="absbottom"></a><a href="searchHotelBus.asp" target="home_center"><img src="images/top_Hotelbus.gif" width="90" height="20" border="0" align="absbottom"></a><a href="basket.asp" target="home_center"><img src="images/top_Basket.gif" width="90" height="20" border="0" align="absbottom"></a></font></div>
    </td>
  </tr>

<tr>
    <td bgcolor="#006699" height="2"> 
      <!--<table cellSpacing=0 cellPadding=0 width=650 align=center border=0  bgcolor="#1464C8" >
<tr><td>
<A HREF="index.asp"
	ONMOUSEOVER="changeImages('home_01', 'images/home_01-over.gif'); return true;"
	ONMOUSEOUT="changeImages('home_01', 'images/home_01.gif'); return true;">
	<IMG NAME="home_01" SRC="images/home_01.gif" WIDTH=100 HEIGHT=30 border=0></A>
<A HREF="searchhotel.asp" target="home_center"
	ONMOUSEOVER="changeImages('reshotel_01', 'images/reshotel_01-over.gif'); return true;"
	ONMOUSEOUT="changeImages('reshotel_01', 'images/reshotel_01.gif'); return true;">
	<IMG NAME="reshotel_01" SRC="images/reshotel_01.gif" WIDTH=100 HEIGHT=30 border=0></A>
<A HREF="search.asp" target="home_center"
	ONMOUSEOVER="changeImages('respack_01', 'images/respack_01-over.gif'); return true;"
	ONMOUSEOUT="changeImages('respack_01', 'images/respack_01.gif'); return true;">
	<IMG NAME="respack_01" SRC="images/respack_01.gif" WIDTH=100 HEIGHT=30 border=0></A>
<A HREF="searchbus.asp" target="home_center"
	ONMOUSEOVER="changeImages('resbus_01', 'images/resbus_01-over.gif'); return true;"
	ONMOUSEOUT="changeImages('resbus_01', 'images/resbus_01.gif'); return true;">
	<IMG NAME="resbus_01" SRC="images/resbus_01.gif" WIDTH=100 HEIGHT=30 border=0></A>
<A HREF="searchair.asp" target="home_center"
	ONMOUSEOVER="changeImages('resair_01', 'images/resair_01-over.gif'); return true;"
	ONMOUSEOUT="changeImages('resair_01', 'images/resair_01.gif'); return true;">
	<IMG NAME="resair_01" SRC="images/resair_01.gif" WIDTH=100 HEIGHT=30 border=0></A>
<A HREF="basket.asp"  target="home_center"
	ONMOUSEOVER="changeImages('basket_01', 'images/basket_01-over.gif'); return true;"
	ONMOUSEOUT="changeImages('basket_01', 'images/basket_01.gif'); return true;">
	<IMG NAME="basket_01" SRC="images/basket_01.gif" WIDTH=100 HEIGHT=30 border=0></A>
</td></tr>
</table>
-->
      <!--<tr><td bgcolor="#2474D8" height=0><font size=-3>&nbsp;</font></td></tr>-->
    </td>
  </tr>

</table>

<!--
<BODY bgColor=#ffffff topMargin=0 onload="MM_preloadImages('images/t1_on.gif','images/t2_on.gif','images/t3_on.gif','images/t4_on.gif','images/t5_on.gif','images/t6_on.gif','images/nn_in.jpg','images/ss_in.jpg','images/cc_in.jpg','images/aa_in.jpg','images/ee_in.jpg','images/t10_on.gif')" marginheight="0" marginwidth="0">

<TABLE cellSpacing=0 cellPadding=0 width=600 align=center border=0>
  <TBODY>
  <TR>
    <TD colSpan=2><IMG height=86 src="images/title_index2.jpg" 
    width=749></TD></TR>
  <TR>
    <TD vAlign=top colSpan=2>
      <DIV align=left><A 
      onmouseover="MM_swapImage('Image7','','images/t1_on.gif',1)" 
      onmouseout=MM_swapImgRestore() 
      href="#"><IMG height=20 
      src="images/t1.gif" width=95 border=0 name=Image7></A><A 
      onmouseover="MM_swapImage('Image2','','images/t2_on.gif',1)" 
      onmouseout=MM_swapImgRestore() 
      href="packagetour.htm" target="home_center"><IMG height=20 
      src="images/t2.gif" width=98 border=0 name=Image2></A><A 
      onmouseover="MM_swapImage('Image3','','images/t3_on.gif',1)" 
      onmouseout=MM_swapImgRestore() 
      href="searchhotel.asp" target="home_center"><IMG height=20 
      src="images/t3.gif" width=80 border=0 name=Image3></A><A 
      onmouseover="MM_swapImage('Image4','','images/t4_on.gif',1)" 
      onmouseout=MM_swapImgRestore() 
      href="#" ><IMG height=20 
      src="images/t4.gif" width=89 border=0 name=Image4></A><A 
      onmouseover="MM_swapImage('Image5','','images/t5_on.gif',1)" 
      onmouseout=MM_swapImgRestore() 
      href="reserveair.asp" target="home_center"><IMG 
      height=20 src="images/t5.gif" width=101 border=0 name=Image5></A><A 
      onmouseover="MM_swapImage('Image6','','images/t6_on.gif',1)" 
      onmouseout=MM_swapImgRestore() 
      href="#"><IMG height=20 
      src="images/t6.gif" width=113 border=0 name=Image6></A><A href="index.html"><IMG height=20 
      src="images/t9.gif" width=67 border=0 name=Image1></A></DIV></TD></TR>
  <TR>
    <TD colSpan=2><IMG height=5 src="images/line.gif" 
  width=749></TD></TR></TBODY></TABLE><BR>
  ->
  
  <!-- ���ҧ 2 -->
   <br>
<TABLE cellSpacing=0 cellPadding=0 width=751 align=center border=0 height="100%">
  <TBODY> 
  <TR vAlign=top>
		
    <TD colSpan=2 height="100%"> 
      <DIV align=left ><IMG height=44 src="images/What_new2.gif"  width=154><BR>
      </DIV>
			
			
      <TABLE cellSpacing=0 cellPadding=1 width=154 bgColor=#8ca6ce border=0  valign="top" hspace="0" vspace="0">
        <TBODY> 
        <TR> 
          <TD> 
            <TABLE cellSpacing=0 cellPadding=2 width="100%" bgColor=#ffffff  border=0 valign="top">
              <TBODY> 
              <TR> 
                <TD align=middle> 
                  <DIV align=left class="text"> <b>&nbsp;&nbsp; <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <A href="regisform.htm" target="home_center">��Ѥ���Ҫԡ����</A><BR>
                    &nbsp;&nbsp; <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <A href="lostpassword.asp" target="home_center"> 
                    <!--FONT onclick="MM_openBrWindow('member.htm','member','width=595,height=425')"�Է�Ի���ª����Ҫԡ-->
                    <!--/FONT-->
                    ������ʼ�ҹ</A><BR>
                    &nbsp;&nbsp; <IMG height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp; 
                    <A href="aboutus.htm" target="home_center">���ѡ���</A><BR>
                    &nbsp;&nbsp; 
                    <!--<BR>&nbsp;&nbsp;
										<IMG  height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp;
										<A href="#">�Ըա�èͧ�ç���</A> -->
                    
                    </b></DIV>
                </TD>
              </TR>
              </TBODY> 
            </TABLE>
            <b> 
            <!--  ��͡�Թ  -->
            </b> 
            <TABLE cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff  border=0 vspace="0">
              <TBODY> 
              <TR> 
                <TD> 
                  <DIV align=right><b><IMG height=25 src="images/login.gif" width=150 border=0></b></DIV>
                </TD>
              </TR>
              </TBODY> 
            </TABLE>
            <TABLE cellSpacing=0 cellPadding=2 width="100%" bgColor=#ffffff  border=0 vspace="0">
              <TBODY> 
              <TR align=top> 
                <TD align=middle class=text> <b> 
                  <%
			on error resume next
			'if Request.Cookies("CustomerID") <> "" then
				
					command = Request.Form("cmd")
					CustomerIDCookies = Request.Cookies("TourCustomerID")
				
					
					err.number = 0
					if command = "login" then
						dim TourCustomerService
						set TourCustomerService = server.CreateObject("TourCustomerService.ICustomer")
						CustomerID = TourCustomerService.Login(CStr(Request.Form("Email")),CStr(Request.Form("Password")))
						'Response.Write "CustomerID = " & CustomerID & "<BR>"
						'Response.Write "Command = " & Request.Form("cmd") & "<BR>"
					
						if err.number = 0 then
							Response.Cookies("TourCustomerID") = CustomerID
							Response.Cookies("TourCustomerID").expires = date + 1
							'Response.Write "ErrNum = " & err.number & "<BR>"
							'Response.Write "CustomerID = " & CustomerID & "<BR>"
							dim objCustomerFactory
							dim objCustomer
							set objCustomerFactory = server.CreateObject("DALDB.CCustomerFactory")
							set objCustomer = TourCustomerService.GetCustomer(CInt(CustomerID))
							objCustomerFactory.Serialize = objCustomer.Serializer
							'Response.Write  "&nbsp;&nbsp;&nbsp;<IMG height=7 src='images/icon3.gif' width='7' align='bottom'>&nbsp;&nbsp;"
							Response.Write "<font class='head11'>"
							Response.Write objCustomerFactory.Item(1).CustomerName & " ���ѧ��͡�Թ����" & "</font><br><br>"
%>
                  <!--============================View My Reservation===================-->
                  </b> 
                  <DIV align=left class="text"> <b>&nbsp;&nbsp; <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <a href="BookingResult.asp" target="home_center">����¡�èͧ</a><br>
                    &nbsp;&nbsp; 
                    <!--============================View My Information==================-->
                    <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <a href="GetCustomer.asp" target="home_center">�٢����Ţͧ�س</a><br>
                    &nbsp;&nbsp; 
                    <!--==============================Edit Customer Info==================-->
                    <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <a href="EditCustomer.asp" target="home_center">��䢢����Ţͧ�س</a>&nbsp;&nbsp; 
                    </b></div>
                  <b> 
                  <!--==============================Logout==============================-->
                  </b> 
                  <form name="Logout" action="index.asp" method="post">
                    <b> 
                    <INPUT type="submit" name="LogoutButton" value="Logout" class="button">
                    <input type="hidden" name="cmd" value="logout" class="button">
                    </b> 
                  </form>
                  <b> 
                  <%						else
							Response.Write err.Description
						end if
					elseif command = "logout" then
						response.cookies("TourCustomerID").expires = now
						Response.Cookies("TourCustomerID") = ""
						response.cookies("BasketID").expires = now
						Response.Cookies("BasketID") = ""
						Response.Cookies("InDate") = ""
						Response.Cookies("OutDate") = ""
						for i =1 to Request.Cookies("NumT")
							Response.Cookies("T" & i) = ""
							Response.Cookies("L" & i) = ""
							Response.Cookies("B" & i) = ""
						next
						'Response.Write "now logout"
					'�Դ IE ������� Logout �����Դ������������ login �ѧ��ҧ����
					elseif CustomerIDCookies <> "" then
						'Response.Write CustomerIDCookies
						set TourCustomerService = server.CreateObject("TourCustomerService.ICustomer")
						set objCustomerFactory = server.CreateObject("DALDB.CCustomerFactory")
						set objCustomer = TourCustomerService.GetCustomer(CInt(CustomerIDCookies))
						objCustomerFactory.Serialize = objCustomer.Serializer
						'Response.Write  "&nbsp;&nbsp;&nbsp;<IMG height=7 src='images/icon3.gif' width='7' align='bottom'>&nbsp;&nbsp;"
						Response.Write "<font class='head11'>"
						Response.Write objCustomerFactory.Item(1).CustomerName & " ���ѧ��͡�Թ����" & "</font><br><br>"
							
%>
                  <!--============================View My Reservation===================-->
                  </b> 
                  <DIV align=left class="text"> <b>&nbsp;&nbsp; <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <a href="BookingResult.asp" target="home_center">����¡�èͧ</a><br>
                    &nbsp;&nbsp; 
                    <!--============================View My Information==================-->
                    <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <a href="GetCustomer.asp" target="home_center">�٢����Ţͧ�س</a><br>
                    &nbsp;&nbsp; 
                    <!--==============================Edit Customer Info==================-->
                    <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp; 
                    <a href="EditCustomer.asp" target="home_center">��䢢����Ţͧ�س</a>&nbsp;&nbsp; 
                    </b></div>
                  <b> 
                  <!--==============================Logout==============================-->
                  </b> 
                  <form name="Logout" action="index.asp" method="post">
                    <b> 
                    <INPUT type="submit" name="LogoutButton" value="Logout"  class="button">
                    <input type="hidden" name="cmd" value="logout">
                    </b> 
                  </form>
                  <b> 
                  <%					end if
			
			
					ResCustomerID = Request.Cookies("TourCustomerID")
					'Response.Write "RescustomerID = " & ResCustomerID & "<br>"
					'Response.Write "Err.number = " & err.number & "<BR>"
					if ResCustomerID = "" or err.number <> 0 then 
%>
                  </b> 
                  <form name="LoginForm" method="post" action="index.asp">
                    <table align=center>
                      <tr> 
                        <td class="head4"><b> Email : </b></td>
                        <td> <b> 
                          <input class="textbox" size=10 name="Email">
                          </b></td>
                      </tr>
                      <tr> 
                        <td class="head4"><b> Password : </b></td>
                        <td> <b> 
                          <input type=password class="textbox" size=10 name="Password">
                          </b></td>
                      </tr>
                      <tr> 
                        <td class="head4" colspan=2 align=center height=50> <b> 
                          <input type="submit" class="button" size=10 name="submit" value="��͡�Թ" onMouseOver="pviiClassNew(this,'buttonover')" onMouseOut="pviiClassNew(this,'button')">
                          </b></td>
                      </tr>
                    </table>
                    <b> 
                    <input type="hidden" name="cmd" value="login">
                    </b> 
                  </form>
                  <b> 
                  <%					end if
%>
                  </b></TD>
              </TR>
              </TBODY> 
            </TABLE>
            <b> 
            <!-- ��ͧ����� -->
            <!--
						<TABLE cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff  border=0 vspace="0">
						<TBODY>
							<TR>
								<TD>
									<DIV align=right><IMG height=25 src="images/travel3.gif" width=150 border=0></DIV>
								</TD>
							</TR>
						</TBODY></TABLE>
						<TABLE cellSpacing=0 cellPadding=2 width="100%" bgColor=#ffffff  border=0 vspace="0">
						<TBODY>
							<TR align=top>
									<TD align=middle>
										<DIV align=left class="text">	&nbsp;&nbsp;
											<IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp;
											<A href="#">���� / ��ӵ�</A><BR>&nbsp;&nbsp;
											<IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp;
											<A href="#">����</A><BR>&nbsp;&nbsp;
											<IMG height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp;
											<A href="#">�ѡ��ҹ��������</A><BR>&nbsp;&nbsp;
											<IMG  height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp;
											<A href="#">�Ѻö��ͧ����� </A> <BR>&nbsp;&nbsp;
											<IMG  height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp;
											<A href="#">����� / �չ��</A> <BR>&nbsp;&nbsp;
											<IMG  height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp;
											<A href="#">��ͧ��</A> 
										<BR><BR></DIV>
										<DIV align=center>
											<a href="search.asp" class="head3" style="COLOR: #FF6666;" target="home_center">
													�����ͧ</a></DIV><br>
									</TD>
								</TR>
							</TBODY>
						</TABLE>
						-->
            <!-- �Դ������ -->
            </b> 
            <TABLE cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff  border=0 vspace="0">
              <TBODY> 
              <TR> 
                <TD> 
                  <DIV align=right><b><IMG height=25 src="images/us2.gif" width=150 border=0></b></DIV>
                </TD>
              </TR>
              </TBODY> 
            </TABLE>
            <TABLE cellSpacing=0 cellPadding=2 width="100%" bgColor=#ffffff  border=0 vspace="0">
              <TBODY> 
              <TR align=top> 
                <TD align=middle> 
                  <DIV align=left class="text"> <b><font size="-1">&nbsp;&nbsp; 
                    <!--<IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;&nbsp;
											<A href="#">�Դ�������ͧ�ҧ��ҹ෤�Ԥ</A><BR>&nbsp;&nbsp;-->
                    <IMG height=7 src="images/icon3.gif" width=7 align=bottom>&nbsp;</font></b><font size="-1"><A href="lostpassword.asp" target="home_center">�ç������ʹ�����Ҫԡ</A><BR>
                    &nbsp;&nbsp; <IMG height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp; 
                    <A href="aboutus.htm" target="home_center">��ԡ�â���������Ҫԡ 
                    </A><BR>
                    &nbsp;&nbsp; <IMG  height=7 src="images/icon3.gif" width=7  align=bottom>&nbsp;&nbsp; 
                    <A href="searchhotel.asp" target="home_center"> �Դ������ͧ��ͧ�ѡ</A> 
                    <BR>
                    &nbsp;&nbsp; <b><BR>
                    </b></font><b><font size="-1"><BR>
                    </font> </b></DIV>
                </TD>
              </TR>
              </TBODY> 
            </TABLE>
          </TD>
        </TR>
        </TBODY> 
      </TABLE>		
			
											<!--***************************  CENTER COLUMN      ***********************-->					
		
		
	<TD width="100%" height="100%">
			<Table align="center" width="95%" cellspacing=0 cellpadding=0 border=0>
			<tr><td>
			<IFRAME Src="home_center.asp" name="home_center" frameborder=0 
				width="100%" height="750" marginwidth=0 scrolling=auto>			
			</IFrame>
			</td></tr></table>
			
	</TD>

	
	<!-- column �����ش
			<TD width=26> 
 				<DIV align=center></DIV>		
			
			</TD>-->
		</TR>
	</TBODY>
	</TABLE>

<DIV align=center></DIV><BR>
<TABLE cellSpacing=0 cellPadding=1 width=740 align=center bgColor=#cccccc border=0>
<TBODY>
	<TR>
 		<TD>
			<TABLE cellSpacing=0 cellPadding=5 width="100%" bgColor=#ffffff  border=0>
			<TBODY>
				<TR vAlign=top>
					<TD colSpan=5>
						<DIV align=center class="text">Powered by OLALA Tour Corporation.</DIV><br>
						<!--<DIV align=center ><font size=3 color="FF66FF">�س��Ң��繤����</Font></DIV>-->
          				</TD>
				</TR>
			</TBODY>
			</TABLE>
		</TD>
	</TR>
</TBODY>
</TABLE>
<DIV>&nbsp;</DIV>
<DIV>&nbsp;</DIV>
<DIV>&nbsp;</DIV>
</BODY>
</HTML>