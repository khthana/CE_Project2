<HTML>
<HEAD>
<TITLE>Edit Customer Form</TITLE>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>
</head>
<Script language="JavaScript">
<!--	
	function validate(){
		window.alert("Registration is Complete");
	}
-->
</Script>
<BODY BGCOLOR="#FFFFFF">



<%
	dim TourCustomerService
	dim objCustomerFactory
	dim objCustomer
		CustomerID = Request.Cookies("TourCustomerID")
		'Response.Write "CustomerID = " & CustomerID
		set TourCustomerService = Server.CreateObject("TourCustomerService.ICustomer")
		set objCustomerFactory = Server.CreateObject("DALDB.CCustomerFactory")
		set objCustomer = TourCustomerService.GetCustomer(Cint(CustomerID))
		objCustomerFactory.serialize = objCustomer.Serializer
%>		
<script language="javascript">
<!--
function checkpwd(form) {
	if ((form.ConfirmPassword.value != form.Passwordd.value) && (form.ConfirmPassword.value != "") && (form.Passwordd.value != "")) {
		alert("Password does not match");
		return false;
	}
	//alert("Password match");
	return true;
}
-->
</script>	
	
	<form name="EditCustomerForm" method="POST" action="" onSubmit="return checkpwd(this)">
	
  <Table align="center" border=0 width="90%">
    <tr><td>	
		<TABLE width="100%" border=0>
		<TBODY>
			<TR>
				<TH align=middle bgColor=#8080b0 class="head2"><b>Personal Data</b></TH>
			</TR>
			<tr><td colspan=2>&nbsp; </td></tr>
			<TR>
				<TD>

        
      <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <TH align=left bgColor=#e6e6fa class="head3" colspan=2>&nbsp;&nbsp;&nbsp;��������ǹ��� 
          </TH>
        </tr>
        <tr> 
          <td width="28%" class="head4"> 
            <div align="right" class="text">���� - ���ʡ�� :&nbsp;&nbsp;</div>
          </td>
          <td width="72%" class="text">  
            <input type="hidden" name="CustomerID" value=<%=CustomerID%>>
            <input name="CustomerName" class="textbox" value=<%=objCustomerFactory.Item(1).CustomerName%> >
          </td>
        </tr>
        <tr> 
          <td width="28%" class="head4"> 
            <div align="right" class="text"> �� :&nbsp;&nbsp;</div>
          </td>
          <td class="text" width="72%"> 
          <%if objCustomerFactory.Item(1).Gender = "M" then %>
            <input type="radio" name="Gender" value="M"  checked> ���
            <input type="radio" name="Gender" value="F"> ˭ԧ 
          <%else%>
			<input type="radio" name="Gender" value="M"> ���
            <input type="radio" name="Gender" value="F" checked> ˭ԧ 
          <%end if%>
          </td>
        </tr>
        <tr> 
          <td width="28%"> 
            <div align="right" class="text">�������:&nbsp;&nbsp;</div>
          </td>
          <td width="72%"><font face="MS Sans Serif" 
                        size=2> 
            <input name="Address" class="textbox" value=<%=objCustomerFactory.Item(1).Address%>>
            </font></td>
        </tr>
        <tr> 
          <td width="28%"> 
            <div align="right" class="text">���Ѿ�� :&nbsp;&nbsp;</div>
          </td>
          <td width="72%"><font face="MS Sans Serif"    size=2>
            <input name="Telephone" class="textbox" value=<%=objCustomerFactory.Item(1).Telephone%> >
            </font></td>
        </tr>
        
        
        
<tr> 
            <td colspan=2>&nbsp;</td>
          </tr>
        </table>
		</TR>
		
		
		
		
		
		<TR>
			<TD>
			
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
            <TH align=left bgColor=#e6e6fa class="head3" colspan=2>&nbsp;&nbsp;&nbsp;����������Ѻ��͡�Թ�
              OlalaTour.com</TH>
  </tr>


          <tr> 
            <td width="28%"> 
              <div align="right"  class="text">������ :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"  size=2><b> 
              <input size=30 name="Email" class="textbox" value=<%=objCustomerFactory.Item(1).Email%> >
              </b></font></td>
          </tr>
          <tr> 
            <td width="28%"> 
              <div align="right"  class="text">Password :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"  size=2><b> 
              <input type=password size=30 name="Passwordd" class="textbox">
              </b></font></td>
          </tr>
          <tr> 
            <td width="28%"> 
              <div align="right"  class="text">Comfirm password :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"  size=2><b> 
              <input type=password size=30 name="ConfirmPassword" class="textbox">
              </b></font></td>
          </tr>
			


<tr><td colspan=2>&nbsp;</td></tr>  
  
</table>
			</TD>
		</TR>
		

<tr><td>
<table align=center border=0 width="100%">
	<tr>
		<td colspan=2 align=center>
			<input type="submit" class="buttonbox" Value="         ��Ẻ�����         ">			
		</td>
		
	</tr>
</table>
</td></tr>        
 	
	</TBODY>
	</TABLE>
<input type="hidden" name="cmd" value="EditCustomer">
	</td></tr>
	</table>
</form>
<%
	on error resume next
	if Request.Form("cmd") = "EditCustomer" then
		'Response.Write Request.Form.Count 
		'for	each a in Request.Form 
		'Response.Write Request.Form(a) & "<br>"
		'next
		'Response.Write "CustomerID = " & Request.Form("CustomerID")
		with objCustomerFactory.Item(1)
			.CustomerID = trim(Request.Form("CustomerID"))
			.CustomerName = trim(Request.Form("CustomerName"))
			.Address = trim(Request.Form("Address"))
			.Telephone = trim(Request.Form("Telephone"))
			.Gender = trim(Request.Form("Gender"))
			.Email = trim(Request.Form("Email"))
			if trim(Request.Form("Passwordd")) <> "" then
				.Password = trim(Request.Form("Passwordd"))
			else
				.Password = .Password
			end if
		end with
	dim util
		set util = server.CreateObject("ComplusUtil.IUtility")	
	boo = TourCustomerService.EditCustomer(util.ConvertToOBj(objCustomerFactory.Item(1)))
	if boo = True then
		Response.Redirect("GetCustomer.asp")
	end if
	'dim customer
		'set util = server.CreateObject("ComplusUtil.IUtility")
		'set Customer = server.CreateObject("DALDB.CCustomer")
		'set Customer = util.ConvertToOBj(objCustomer)
		'===============Call Edit Customer====================
		'TourCustomerService.EditCustomer(Util.ConvertToOBj(ObjCustomer))
		'Response.Write boo
		'==============Show Customer data====================
		'set objCustomerFactory = server.CreateObject("DALDB.CCustomerFactory")
		'set objCustomer = TourCustomerService.GetCustomer(cint(Request.Form("CustomerID")))
		'objCustomerFactory.Serialize = objCustomer.Serializer
	end if
%>		
	
</BODY>
</HTML>
