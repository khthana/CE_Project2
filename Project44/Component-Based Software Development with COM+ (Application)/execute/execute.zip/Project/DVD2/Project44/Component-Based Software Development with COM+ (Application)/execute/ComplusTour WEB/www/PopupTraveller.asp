<HTML>
<HEAD>
<HTML>
	<HEAD><TITLE> OLALA TOUR  :: Traveller Detail </TITLE>
	<META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>
	
<BODY bgColor=#ffffff>
<DIV align=center> 
  <p>&nbsp;</p>
  <p><b><font color="#FF0000">��ª��ͼ���Թ�ҧ</font></b> </p>
  <table width="100%" border="0" cellspacing="3" cellpadding="0">
    <tr class="head3" align=center> 
      <td width="20%" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">�ӴѺ���</font></b></td>
      <td colspan="2" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">���ͼ���Թ�ҧ</font></b></td>
    </tr>
    <form name="CancelTravellerForm" action="javascript:window.close();">
      <%
	on error resume next
	BookingID = Request("BookingID")
	ItemNo = Request("ItemNo")
	'Response.Write "PackageID = " & PackageID & "<BR>"
	'Response.Write "DepartDate = " & DepartDAte & "<br>"
	'cmd = Request.Form("cmd")
	TravellerNo = Request("TravellerNo")
	dim TourBookingService
	dim objPackageBookingDetailFac
	dim objPackageBookingDetail
	
	if TravellerNo <> "" then
		
		'Response.Write "loop if"
		'Response.Write "BookingID = " & BookingID & "<BR>"
		'Response.Write "ItemNo = " & ItemNo & "<BR>"
		'Response.Write "TravellerNo = " & TravellerNo & "<BR>"
		
		set TourBookingService = server.CreateObject("TourBookingService.IBookManager")
		TourBookingService.CancelPackageBookingDetail clng(BookingID),cint(ItemNo),cint(TravellerNo)
	end if
	
		set TourBookingService = server.CreateObject("TourBookingService.IBookViewer")
		set objPackageBookingDetailFac = server.CreateObject("DALDB.CPackageBookingDetailFactory")
		set objPackageBookingDetail = TourBookingService.GetPackageBookingDetail(clng(BookingID),cint(ItemNo))
		objPackageBookingDetailFac.Serialize = objPackageBookingDetail.Serialize
		if objPackageBookingDetail is nothing then
%>
      <tr class="text" align="center"> 
        <td colspan=3> <b><font color="#FF0000" size="-1">����ռ���Թ�ҧ</font></b> 
        </td>
      </tr>
      <%		else
		for i = 1 to objPackageBookingDetailFac.Count
	
		
%>
      <tr class="text" align=center> 
        <td width="20%" bgcolor="#EEEEEE"><%=i%></td>
        <td width="58%" bgcolor="#EEEEEE"><%=objPackageBookingDetailFac.Item(i).TravellerName%></td>
        <!--input type="hidden" name="BookingID" value="<%=BookingID%>">
		<input type="hidden" name="ItemNo" value="<%=ItemNo%>">
		<input type="hidden" name="TravellerNo" value="<%=objPackageBookingDetailFac.Item(i).TravellerNo%>">
		<td width="20%"><input type="submit" name="cmd" value="Cancel"></td-->
        <td width="22%" bgcolor="#EEEEEE"><a href="PopupTraveller.asp?BookingID=+<%=BookingID%>+&ItemNo=<%=ItemNo%>&TravellerNo=+<%=objPackageBookingDetailFac.Item(i).TravellerNo%>">Cancel</a></td>
      </tr>
      <%	
		'Response.Write "BookingID = " & BookingID & "<BR>"
		'Response.Write "ItemNo = " & ItemNo & "<BR>"
		'Response.Write "TravellerNo = " & TravellerNo & "<BR>"
		
	next
	end if	
%>
      <tr> 
        <td colspan=2>&nbsp;</td>
        <td width="22%"> 
          <div align=center> 
            <input type="submit" class="buttonbox" name="OK" value="      OK      ">
          </div>
        </td>
      </tr>
    </form>
  </table>
</DIV>
</BODY>
</HTML>