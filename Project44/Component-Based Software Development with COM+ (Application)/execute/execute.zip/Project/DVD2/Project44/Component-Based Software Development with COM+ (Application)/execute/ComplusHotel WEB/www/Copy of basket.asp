<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title>Untitled Page</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css">

  <link rel="stylesheet" type="text/css" href="Templates/style.css">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" topMargin= 0>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>
<table width="98%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="52" colspan="2" > <!--
      <p><b><font face="Arial, Helvetica, sans-serif" size="+2" color="6B8EC6"><font color="#FFFFFF">OLALA 
        HOTEL</font> </font></b></p>-->
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td width="5%">&nbsp;</td>
			<td align="center" valign="bottom"> 
				<img src="images/hd_hotel_pic1.gif" height="60"> </td>
			<td align="center" valign="top"> 
				<img src="images/hd_hotel_pic.gif" height="60"> </td>
			<td align="center" valign="middle"> 
				<img src="images/hd_hotel_pic2.gif"  height="60"> </td>

			<td align="right"> <img src="images/hd_olalahotel.gif"> </td>
		</tr>
		</table>

    </td>
  </tr>
 <!-- <tr> 
    <td bgcolor="#006699" width="36%">&nbsp;&nbsp;&nbsp;
		<a href="../index.asp" class=z1>Main</a>|
		<a href="#" class=z1> Search </a>|
		<a href="../basket.asp" class=z1>View Basket</a>| 
		<a href="../basket.asp" class=z1>Checkout  </a>|</td>
    <td bgcolor="#006699" width="64%"> 
      <div align="right"><font color="#FFFFFF" size="-1">Disclimer | Policies 
        | Feedback | FAQ | Help | About | Coutact Us</font></div>
    </td>
  </tr>-->
  <tr>
  <td>
  <table width="99%" border="0" cellspacing="1" cellpadding="0" align="center" bgcolor="black">
  <tr bgcolor="#FF6666"> 
    <td bgcolor="#FFCC99" width="17%" align="center" class="head5">
      <a href="index.asp" class="link1"><b>Main</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp"  class="link1"><b>Search</b></a>
    </td>

    <td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="basket.asp" class="link1"><b>View Basket</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp" class="link1"><b>About Us</b></a>
    </td>

  </tr>
	<tr>
          <td align="right" colspan="4" bgcolor="#76CCFF" height=4><img src="images/1x1b.gif" border="0" /></td>
    </tr>

</table>
</td>
</tr>

</table>


<table width="99%" border="0" cellspacing="0" cellpadding="5" align="center" height="600">
  <tr> 
    <td width="17%" bgcolor="#D7DCE8" height="330" valign="top" align="center"> 
      <%
	on error resume next
			cmd = Request.Form("cmd")
			Email = Request.Form("Email")
			Password = Request.Form("Password")
			'frompage = request("frompage")		
			'pagename=request.servervariables("script_name")
	
			if cmd = "login" then
			set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
			CustomerID = objCustomer.Login(Cstr(Email),Cstr(Password))
					if err.number = 0 and CustomerID > 0 then
						Response.Cookies("CustomerID") = CustomerID
						Response.Cookies("CustomerID").expires = date+1
'						Response.Cookies("BasketID").expires = now
						
							
							if request.servervariables("script_name") = "/complushotel/www/loginerror.asp" then
								response.redirect("myreservation.asp")
							end if

					else
							select case err.number 
								case vbObjectError+1 err_txt = "notfound"
								case vbObjectError+5 err_txt = "wrongpassword"
							end select
						err_txt = "loginerror.asp?err="  & err_txt 
						response.redirect(err_txt)
					end if  
			end if		    	
		'	cmd  = request.querystring("cmd")
			if cmd="logout" then
						Response.Cookies("BasketID").expires = now
						Response.Cookies("CustomerID").expires = now
						Response.Cookies("BasketID") =""
						Response.Cookies("CustomerID") = ""

			end if
	
			
			CustomerID = Request.Cookies("CustomerID")
			'response.write CustomerID
			if CustomerID = "" then
			'' render login box
%>
      <form name="form1" method="post" action="">
        <table width="130" border="0" cellspacing="0" cellpadding="0" align="center" >
          <tr align="center" > 
            <td  width="130" height=25 >
				<div align="center"><img src="images/login.gif" ></div>
            </td>
          </tr>
          <tr> 
            <td width="130" class="head7"><br><b>   E-mail address </b></td>
          </tr>
          <tr> 
            <td height="15" width="130"> <font size="-1"> 
              <input type="text" name="Email" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td width="130" class="head7" height=20 valign="bottom"><b>Password</b></td>
          </tr>
          <tr> 
            <td width="130"> <font size="-1"> 
              <input type="password" name="Password" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td height="10" width="130"> 
              <div align="center"><font size="-1"> 
			   
				<input type="hidden" name="cmd" value="login">
			  	<input type="hidden" name="country" value="<%=Request.Form.Item("Country")%>">
			  	<input type="hidden" name="state" value="<%=Request.Form.Item("State")%>">
			  	<input type="hidden" name="city" value="<%=Request.Form.Item("City")%>">
			  	<input type="hidden" name="star" value="<%=Request.Form.Item("star")%>">
			  	<input type="hidden" name="HotelName" value="<%=Request.Form.Item("HotelName")%>">
			  	<input type="hidden" name="RoomModelName" value="<%=Request.Form.Item("RoomModelName")%>">
			  	<input type="hidden" name="PriceRate" value="<%=Request.Form.Item("PriceRate")%>">
			  	<input type="hidden" name="CheckInDate" value="<%=Request.Form.Item("CheckInDate")%>">
			  	<input type="hidden" name="CheckOutDate" value="<%=Request.Form.Item("CheckOutDate")%>">
			  	<input type="hidden" name="AmountOfRoom" value="<%=Request.Form.Item("AmountOfRoom")%>">
			<br><br>
							<input type="submit" name="Submit" value="Login" class="smbutton">
                <input type="reset" name="Submit2" value="Reset" class="smbutton">
                <br><br>
                <a href="lostpassword.asp"> ������ʼ�ҹ </a><br>
                <a href="register.asp"> ��Ѥ���Ҫԡ���� </a></font></div>
            </td>
          </tr>
        </table>
      </form>
<%
			else
			 'show customer name and render customer menu 
				set Customers = Server.CreateObject("DALDB.CCustomerFactory")
				set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
				customers.Serialize  = objCustomer.GetCustomer(clng(CustomerID)).Serializer
				CustomerName = Customers.item(1).CustomerName
%>

      <table width="130" border="0" cellspacing="1" cellpadding="0" align="center" dwcopytype="CopyTableRow">
        <tr > 
          <td bgcolor="#3B8EC6" height="38" align=center><font size="-1" color="#FFFFFF"><b>���ʴդ�Ѻ 
            <br>
            �س <%=CustomerName%> </b></font></td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26"> 
            <div align="center"><font size="-1"><a href="MyProfile.asp" class="z2"> ��䢢�����</a></font></div> 
          </td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26" > 
            <div align="center"><font size="-1"><a href="MyReservation.asp" class="z2"> ��¡�èͧ</a></font></div>
          </td>
        </tr>
        <tr> 
          <td height="15" bgcolor="#6B8EC6" width="116"><br>
<div align="center">
              <form name="formx" method="post" action="index.asp">
                <input type="hidden" name="cmd" value="logout">
                <!--<input type="image" name="Submit" value="logout" src="../images/viewonmap.gif" width="70" height="13">-->
				<input type="submit" name="Submit" value="logout" class="button">
				
			  </form>
              </div>
          </td>
        </tr>
      </table>
<%
			end if ' render login box OR menu
%>
    </td>
    <td width="625" height="249" valign="top"> 
		<table width="95%" align="center">
			<tr>
				<td>
					<!-- #BeginEditable "Center_Content" --> 
<%
'on error resume next
	dim HotelID,RoomModelID,BookCheckIn,BookCheckOut,AmountOfRoom,BookingPrice
	dim basketID
	DIM OBJECTBASKET
	set objBasket = server.CreateObject("BookingService.IBasket")
	set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
	set objReserveHotel = Server.CreateObject("DALDB.CReserveHotelDetail")
	set util = server.CreateObject("ComplusUtil.IUtility")
	
	BasketID = Request.Cookies("BasketID") 
		if  BasketID = "" and Request.QueryString.Item("cmd") = "add" then
			basketID = objBasket.CreateBasket
			Response.Cookies("BasketID") = BasketID
			Response.Cookies("BasketID").Expires = date+1
			response.write "No cookies ,now add.."  			
		end if
	response.write "Get cookies ������ " & basketID
'get Input 
	response.write	"cmd =" & Request.QueryString.Item("cmd") 

	if Request.QueryString.Item("cmd") = "add" then
		HotelID =  Request.QueryString.Item("HotelID")
		RoomModelID = Request.QueryString.Item("RoomModelID") 
		BookCheckIn = request.QueryString.Item("BookCheckIn")
		BookCheckOut =  Request.QueryString.Item("BookCheckOut")
		AmountOfRoom =  Request.QueryString.Item("AmountOfRoom")
		BookingPrice =  Request.QueryString.Item("BookingPrice")
		
		set objReserveHotel = objReserveHotels.AddNew
		with objReserveHotel
				.HotelID = HotelID
				.RoomModelID = RoomModelID
				.BookCheckIn = BookCheckIn
				.BookCheckOut = BookCheckOut
				.AmountOfRoom = AmountOfRoom
				.BookingPrice = BookingPrice
		end with

		objbasket.AddBasketItem cint(basketid),util.ConvertToOBj(objReserveHotel)	
		
	end if ' cmd add

%>	

<% if basketID <> "" then %>
      <div align="center"><b><font size="+1" color="#FF9933">Your Basket</font></b></div>
      <br>
      <form name="form2" method="post" action="reserve.asp">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td width="5%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">ź</font></b></font></div>
            </td>
            <td width="8%" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��¡�� 
                </font></b></font></div>
            </td>
            <td width="23%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ѹ�ѡ</font></b></font></div>
            </td>
            <td width="26%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ç���</font></b></font></div>
            </td>
            <td width="17%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="8%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ӹǹ 
                ��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="13%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�Ҥ���� 
                (�ҷ)</font></b></font></div>
            </td>
          </tr>
     <%
		set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")	
		objReserveHotels.Serialize = objbasket.ViewBasket(Cint(BasketID)).Serialize
		dim i
		dim TotalPrice
		TotalPrice = 0
    	For i = 1 To objReserveHotels.internalCRecocdset.RowCount
		ToTalPrice = Totalprice + objReserveHotels.Item(i).BookingPrice
 %>
	      <tr <%  if i mod 2 = 0 then Response.Write "bgcolor=#D7DCE8" %>> 
            <td width="5%"> <font size="-1"> 
              <input type="checkbox" name="checkbox" value="checkbox">
              </font></td>
            <td width="8%"> 
              <div align="center"><font size="-1"><%= i %></font></div>
            </td>
            <td width="23%"><font size="-1"><%=  objReserveHotels.Item(i).BookCheckIn %> - <%= objReserveHotels.Item(i).BookCheckOut %></font></td>
            <td width="26%"><font size="-1"><%=  objReserveHotels.Item(i).HotelName %></font></td>
            <td width="17%"><font size="-1"><%=  objReserveHotels.Item(i).RoomModelName %></font></td>
            <td width="8%"> 
              <div align="center"><font size="-1"><%=  objReserveHotels.Item(i).AmountOfRoom %></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><%=  objReserveHotels.Item(i).BookingPrice %></font></div>
            </td>
          </tr>
       
<%    Next	   %>
	   
	   
	      <tr> 
            <td colspan="6"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><b><font color="#0D549B"><%=TotalPrice%></font></b></font></div>
            </td>
          </tr>
        </table>
		<div align="right"> 
          <p> 
            <input type="submit" name="Submit4" value="�ӹǹ����">
	        <input type="hidden" name="BasketID" value="<%= BasketID %>">
            <input type="submit" name="reserve" value="�ͧ">

          </p>
          </div>
      </form>

      
    <% else ' if basket ��ҧ      %>
      <font size="+1" color="#FF9933">You basket is empty</font> 
      <% end if %>
      <!-- #EndEditable -->
				</td>
			</tr>
		</table>				
	</td>
  </tr>
 <!-- <tr>
    <td width="148" bgcolor="#D7DCE8" height="28" valign="top">&nbsp; </td>
    <td width="631" height="28" valign="top">&nbsp;</td>
  </tr>-->
</table>
</body>
<!-- #EndTemplate --></html>
