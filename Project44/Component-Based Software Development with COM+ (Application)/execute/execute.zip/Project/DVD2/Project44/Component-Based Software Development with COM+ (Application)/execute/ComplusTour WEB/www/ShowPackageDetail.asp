<HTML>
<HEAD>

	<HEAD><TITLE> OLALA TOUR </TITLE>
	<META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>
	
<BODY bgColor=#ffffff>

<%
	PackageID = Request.QueryString("PackageID")
	DepartDate = Request.QueryString("DepartDate")
	'Response.Write "PackageID = " & PackageID & "<BR>"
	'Response.Write "DepartDate = " & DepartDAte & "<br>"
	dim TourService
	dim objPackageDepartureFac
	dim objPackageDeparture
		set TourService = server.CreateObject("TourService.IPackageViewer")
		set objPackageDepartureFac = server.CreateObject("DALDB.CPackageDepartureFactory")
		set objPackageDeparture = TourService.GetPackageDeparture(Cint(PackageID))
		objPackageDepartureFac.Serialize = objPackageDeparture.Serialize
		for i = 1 to objPackageDepartureFac.Count
			'Response.Write objPackageDepartureFac.Count & "<BR>"
			'Response.Write objPackageDepartureFac.Item(i).DepartDate & "<br>"
			'Response.Write DepartDate & "<br>"
			'Response.Write objPackageDepartureFac.Item(i).PackageCloseDate & "<BR>"
			'Response.Write " kk " & objPackageDepartureFac.Item(i).DepartDate & "<BR>"
			'Response.Write " rr " & DepartDate & "<BR>"
			if objPackageDepartureFac.Item(i).DepartDate = Cdate(DepartDate) then
				with objPackageDepartureFac.Item(i) 
					NumOfTraveller = .NumOfTraveller
					MaxTraveller = .MaxTraveller 
					ChildPrice = .ChildPrice
					AdultPrice = .AdultPrice
					PackageCloseDate = .PackageCloseDate
					'Response.Write "PackageCloseDate = " & objPackageDepartureFac.Item(i).PackageCloseDate & "<br>"
				End with
			end if
		next
	'Response.Write "PackageCloseDate = " & PackageCloseDate & "<br>"
	dim objPackageFac
	dim objPackage
		set objPackageFac = server.CreateObject("DALDB.CPackageFactory")
		set objPackage = TourService.GetPackage(cint(PackageID))
		objPackageFac.Serialize = objPackage.Serialize
		with objPackageFac.Item(1)
			PackageName = .PackageName
			Description = .Description
			NumOfDays = .NumOfDays
		end with

%>
	
<DIV align=center> <b><font color="#FF0000"><%=PackageName%></font></b> 
  <P><FONT face="MS Sans Serif" color=#000000 size=2><B><font color="#006699">�ͧ�������ѹ���֧<%=PackageCloseDate%></font></B></FONT></P>
	

	
  <table cellspacing=0 cellpadding=1 width="70%" border=0>
    <tbody> 
    <tr> 
      <td height=103 colspan=2> 
        <div align=center> 
          <p align=center><b><font face="MS Sans Serif" size=3 color=#ff0000>�Ҥ�����Ѻ����˭� 
            <font color="#006699"><%=AdultPrice%></font> �ҷ/��ҹ <br>
            �Ҥ�����Ѻ�� <font color="#006699"><%=ChildPrice%></font> �ҷ/��ҹ</font></b></p>
        </div>
      </td>
    </tr>
    <!--TD width="8%" >&nbsp;</TD-->
    <td>
        <div align=center class="text"><b><font color="#006699">�͡�Թ�ҧ�ѹ��� 
          <%=DepartDate%> ������ <%=NumOfDays%> �ѹ <%=NumOfDays - 1%> �׹</font></b></div>
    </td>
    </tr>
    <tr>
      <td>
        <div align="center"><font color="#006699" size="-1"><%=Description%></font></div>
        <br>
      </td>
    </tr>
    </tbody> 
  </table>
  <table width="70%" border="0">
    <tr bgcolor="#006699"> 
      <td width="30%"> 
        <DIV align="center" class="text"><font size="-1"><b><font color="#FFFFFF">�ѹ���</font></b></font></DIV>
      </td>
      <td width="30%"> 
        <DIV align="center" class="text"><font size="-1"><b><font color="#FFFFFF">����</font></b></font></DIV>
      </td>
      <td width="40%"> 
        <DIV align="center" class="text"><font size="-1"><b><font color="#FFFFFF">ʶҹ���</font></b></font></DIV>
      </td>
    </tr>
    <%
	dim objPackageDetailFac
	dim objPackageDetail
		set objPackageDetailFac = server.CreateObject("DALDB.CPackageDetailFactory")
		set objPackageDetail = TourService.GetPackageDetail(Cint(PackageID))
		objPackageDetailFac.Serialize = objPackageDetail.Serialize 
		for i = 1 to objPackageDetailFac.Count
			Days = objPackageDetailFac.Item(i).Days
			TimeOfDay = Timevalue(objPackageDetailFac.Item(i).TimeOfDay)
			PlaceID = objPackageDetailFac.Item(i).PlaceID
			dim objPlaceFac
			dim objPlace
			set objPlaceFac = server.CreateObject("DALDB.CPlaceFactory") 
			set objPlace = TourService.GetPlace(Cint(PlaceID))
			objPlaceFac.Serialize = objPlace.Serialize
			PlaceName = objPlaceFac.Item(1).PlaceName	  
			
%>
    <tr bgcolor="#eeeeee"> 
      <td width="30%" height="2"> 
        <DIV align="center" class="text"><%=Days%></DIV>
        
      </td>
      <td width="30%" height="2"> 
        <DIV align="center" class="text"><%=TimeOfDay%></DIV>
        
      </td>
      <td width="40%" height="2"> 
        <DIV align="center" class="text"><%=PlaceName%></DIV>
        
      </td>
    </tr>
    <%		next
%>
  </table>
	
	
	
	
	<P class="text"><A  href="addTraveller.asp?PackageID=<%=PackageID%>&DepartDate=<%=DepartDate%>&AmountOfTraveller=<%=request("AmountOfTraveller")%>&cmd=addPackage"> ��Ժ���С���</A>&nbsp; | <A  href="index.asp" target="_parent">��Ѻ�˹���á</A> </P>
<HR align=center width="90%" SIZE=1>
</DIV>
</BODY>
</HTML>