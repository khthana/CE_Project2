<html>
<head>
<title> Reserve Hotel</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
   <link rel="stylesheet" type="text/css" href="homestyle.css" >
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" >

<script language="javascript">
<!--
function checkform(form){
	if (form.CheckInDate.value == "") {
		alert("��س��к��ѹ�����Ҿѡ");
		return false;	
	}
	
	if (form.CheckOutDate.value == "") {
		alert("��س��к��ѹ�͡");
		return false;
	}
	return true;
}
-->
</script>
      
      <SCRIPT language=javascript src="calendar.js"></SCRIPT>
      <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
<IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1; left: 66px; top: 260px" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm"></IFRAME> 
<form name="form2" method="post" action="TourSearchResultHotel.asp" onsubmit="return checkform(this)">
        <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            
      <td colspan="4" height="42" valign="bottom"><b><font color="#009999" size="-1"><img src="images/SearchHotel.gif" width="420" height="24"></font></b></td>
          </tr>
          <tr> 
            
      <td width="23%" height="30" valign="bottom"><b><font size="-1" color="#003399"> 
        &nbsp;�����</font></b></td>
            
      <td width="36%" height="30" valign="bottom"><b><font size="-1" color="#003399">�����ç���</font></b></td>
            
      <td width="15%" height="30" valign="bottom"><b><font size="-1" color="#003399">�дѺ(���)</font></b></td>
            
      <td width="26%" height="30" valign="bottom"><b><font size="-1" color="#003399">�ӹǹ��ͧ</font></b></td>
          </tr>
          <tr> 
            
      <td width="23%"><b><font size="-1" color="#003399"> 
        <select name="Country">
                <!--<option value="᤹Ҵ�">᤹Ҵ�</option>
                      <option value="�ѧ���">�ѧ���</option>
                      <option value="���Ѱ����ԡ�">���Ѱ����ԡ�</option>
                      -->
                <option value="��" selected>��</option>
                <!--<option value="�չ">�չ</option>
                      <option value="�ԧ����">�ԧ����</option>
                      <option>��ͧ��</option>
                      <option>���������</option>
                      <option>�������</option>
                      <option>�Թ⹹����</option>
                    -->
              </select>
              </font></b></td>
            
      <td width="36%"><b><font size="-1" color="#003399"> 
        <input type="text" name="HotelName" class="textbox" size="20">
              </font></b></td>
            
      <td width="15%"><b><font size="-1" color="#003399"> 
        <select name="Star">
                <option value="1-5" selected>����к�</option>
                <option value="1-2">1 - 2</option>
                <option value="2-3">2 - 3</option>
                <option value="3-4">3 - 4</option>
                <option value="4-5">4 - 5</option>
              </select>
              </font></b></td>
            
      <td width="26%"><b><font size="-1" color="#003399"> 
        <%
					Amt = Request.Cookies("Amt")
					If Amt = "" then
					Amt = 1
					end if
						
					%>
        <input type="text" name="AmountOfRoom" value="<%=Amt%>" class=textbox size="5">
              </font></b></td>
          </tr>
          <tr> 
            
      <td width="23%" height="31" valign="bottom"><b><font size="-1" color="#003399">&nbsp;�Ѱ</font></b></td>
            
      <td width="36%" height="31" valign="bottom"><b><font size="-1" color="#003399">��Դ��ͧ</font></b></td>
            <td height="31" valign="bottom" colspan="2"><b><font size="-1" color="#003399">�ѹ��Ҿѡ</font></b></td>
          </tr>
          <tr> 
            
      <td width="23%"><b><font size="-1" color="#003399"> 
        <select name="State">
                <option value="any" selected>����к�</option>
              </select>
              </font></b></td>
            
      <td width="36%"><b><font size="-1" color="#003399"> 
        <select name="RoomModelName">
                <option value="any" selected>����к�</option>
                <option value="Superior-single">Superior-single</option>
                <option value="Superior-twin">Superior-twin</option>
                <option value="Deluxe-single">Deluxe-single</option>
                <option value="Deluxe-twin">Deluxe-twin</option>
                <option value="Executive-single">Executive-single</option>
                <option value="Executive-twin">Executive-twin</option>
                <option value="Carnation suit">Carnation suit</option>
              </select>
              </font></b></td>
            <td colspan="2"><b><font size="-1" color="#003399"> 
              <!--<input type="text" name="CheckInDate" maxlength="10" size="13" value="1/10/2544">  -->
              <%
					InDate = Request.Cookies("InDate")
					If Indate = "" then
					Indate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
					OutDate = Request.Cookies("OutDate")
					If OutDate = "" then
					OutDate = Day(Date()) &    "/" & Month(Date()) & "/" &  Year(Date())+543
					end if
				%>
              <input id=txtbox1 class="textbox" type="text" name="CheckInDate" value='<%=InDate%>' onChange="javascript:cbfloadmefirst('form2', 'CheckInDate');" size="13" maxlength="10">
              <a href="javascript:cbfshowcalendar('form2', 'CheckInDate', 'txtbox1')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font></b></td>
          </tr>
          <tr> 
            
      <td width="23%" height="30" valign="bottom"><b><font size="-1" color="#003399">&nbsp;���ͧ</font></b></td>
            
      <td width="36%" height="30" valign="bottom"><b><font size="-1" color="#003399">��ǧ�Ҥ�(�ҷ) 
        </font></b></td>
            <td height="30" colspan="2"><b><font size="-1" color="#003399">�ѹ�͡ 
              </font></b></td>
          </tr>
          <tr> 
            
      <td width="23%"><b><font size="-1" color="#003399"> 
        <select name="City">
                <option value="any" selected>����к�</option>
                <option value="��ا෾">��ا෾</option>
                <option value="��§����">��§����</option>
                <option value="���ͧ">���ͧ</option>
                <!--<option value="�͹��"><font size="-1">�͹��</font></option>
                      <option value="�غ��Ҫ�ҹ�"><font size="-1">�غ��Ҫ�ҹ�</font></option>
                      <option value="�ź���"><font size="-1">�ź���</font></option>
                      <option value="��Ҵ"><font size="-1">��Ҵ</font></option>
                      <option value="�ҭ������"><font size="-1">�ҭ������</font></option>
                      <option value="ྪú���"><font size="-1">ྪú���</font></option>
                      <option value="����"><font size="-1">����</font></option>
                      <option value="��Ҹ����"><font size="-1">��Ҹ����</font></option>
                     -->
              </select>
              </font></b></td>
            
      <td width="36%"><b><font size="-1" color="#003399"> 
        <select name="PriceRate">
                <option value="0-1000000" selected>����к�</option>
                <option value="0-1000">��ӡ��� 1,000</option>
                <option value="1001-2000">1,000 - 2,000</option>
                <option value="2001-3000">2,000 - 3,000</option>
                <option value="3001-4000">3,000 - 4,000</option>
                <option value="4001-5000">4,000 - 5,000</option>
                <option value="5001-1000000">5,000 ����</option>
              </select>
              </font></b></td>
            <td colspan="2"><b><font size="-1" color="#003399"> 
              <!-- <input type="text" name="CheckOutDate" maxlength="10" size="13" value="1/10/2544"> -->
              <input id=txtbox2  class=textbox type=text name="CheckOutDate" value='<%=OutDate%>' onChange="javascript:cbfloadmefirst('form2', 'CheckOutDate');" size="13" maxlength="10">
              <a href="javascript:cbfshowcalendar('form2', 'CheckOutDate', 'txtbox2')"><img src="images/calendar.gif" width="34" height="21" border="0"></a></font></b></td>
          </tr>
          <tr> 
            
      <td width="23%" height="31"><font color="#003399"></font></td>
            
      <td width="36%" height="31"><font color="#003399"></font></td>
            <td height="31" colspan="2"><font color="#003399"></font></td>
          </tr>
          <tr> 
            <td colspan="4"> 
              <div align="center"> 
                <input type="submit" name="Search" value="Search !!" class="button">
                <input type="reset" name="Submit4" value="Reset" class="button">
              </div>
              <br>
            </td>
          </tr>
        </table>
			   <p>&nbsp;</p>
      </form>
</body>
</html>