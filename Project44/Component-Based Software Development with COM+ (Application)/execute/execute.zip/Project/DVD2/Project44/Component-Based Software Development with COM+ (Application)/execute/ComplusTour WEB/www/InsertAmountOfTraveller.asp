<%@ Language=VBScript %>
<HTML>
<HEAD>
<title> OLALA TOUR </title>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
</HEAD>
<BODY>
<div align="center">
  <p>&nbsp;</p>
  <p><font color="#FF0000"><b>��س����ӹǹ����Թ�ҧ</b></font> <BR>
  </p>
</div>
<form name="AddAmountOfTraveller" action="AddTraveller.asp" method="post">
  <div align="center">
    <input type="text" class ="textbox" name="AmountOfTraveller" >
    <input type="hidden" name="PackageID" value=<%=Request("PackageID")%>>
    <input type="hidden" name="DepartDate" value=<%=Request("DepartDate")%>>
    <input type="hidden" name="cmd" value="addPackage">
    <input type="submit"  name="submit" value="Submit" class="button">
  </div>
</form>
</BODY>