
<HTML>
<HEAD>
	<TITLE>OLALA TOUR</TITLE>
</HEAD>
<BODY>
<%
	dim TourCustomerService
		set TourCustomerService = server.CreateObject("TourCustomerService.ICustomer")
		CustomerID = TourCustomerService.Login(Cstr(Request.Form("Email")),Cstr(Request.Form("Password")))
		Response.Cookies("CustomerID") = CustomerID
		Response.Cookies("CustomerID").expires = Date + 1
%>
</BODY>
</HTML>
