<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title> OLALA TOUR </title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css">

  <link rel="stylesheet" type="text/css" href="Templates/style.css">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" topMargin= 0>
	
<%	BookingID = Request.Form("BookingID")
	dim TourBookingServece
	set TourbookingService = server.CreateObject("TourBookingService.IBookManager")
	TourBookingService.ConfirmBooking(Clng(BookingID))
%>
	<P align="center"><font size="+2" class="text" color="#FF9933">�ͺ�س������ԡ��</font><P>
	<br>
	<br>
	<P align="center"><font class="text">�Ţ�����ҧ�ԧ�����㹡�õԴ��ͤ�� &nbsp;  <B><FONT color=#0d549b><%=BookingID%></FONT></B></p> 




</body>
</html>
