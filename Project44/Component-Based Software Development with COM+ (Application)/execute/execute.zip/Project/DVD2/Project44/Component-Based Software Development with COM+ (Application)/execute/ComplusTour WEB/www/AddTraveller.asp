<HTML>
	<HEAD><TITLE> OLALA TOUR </TITLE>
	<META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>
	
<BODY bgColor=#ffffff>
  <%
	'on error resume next
	AmountOfTraveller = Request("AmountOfTraveller")
	PackageID = Request("PackageID")
	DepartDate = Request("DepartDate")
	
	
	if AmountOfTraveller = 0 then
		'Response.Write "AmountOfTraveller=" & AmountOfTraveller & "-<BR>"
		
		Response.Redirect("InsertAmountOfTraveller.asp?PackageID=" & PackageID & "&DepartDate=" & DepartDate)
%>
		
		 
<%	else
%>
  <DIV align=center> <b><font color="#FF0000">��ª��ͼ���Թ�ҧ</font></b> 

  <form name="AddTravellerForm" action="Basket.asp" method="post">
    <table width="80%" border="0" cellspacing="3" cellpadding="0">
      <tr  align=center> 
        <td height="17" width="29%" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">�ӴѺ���</font></b></td>
        <td width="23%" height="17" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">���ͼ���Թ�ҧ</font></b></td>
        <td width="31%" height="17" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">���ʡ��</font></b></td>
        <td width="17%" height="17" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">�ѹ�Դ</font></b></td>
      </tr>
      <% 	for i = 1 to AmountOfTraveller %>
      <tr class="text" align=center  bgcolor="#EEEEEE"> 
        <td width="29%"><%=i%></td>
        <td width="23%"> 
          <%
				T = Request.Cookies("T" &  i)
				L = Request.Cookies("L" &  i)
				B = Request.Cookies("B" &  i)
			%>
          <input type="text" class = "textbox" name="T<%=i%>" size="22" value="<%=T%>">
        </td>
        <td width="31%"> 
          <input type="text" class = "textbox" name="L<%=i%>" size="27" value="<%=L%>">
        </td>
        <td width="17%"> 
          <div align="center"> 
            <input type="text" class=textbox name="B<%=i%>" size="10" value="<%=B%>">
          </div>
        </td>
      </tr>
      <%	next %>
      <tr class="text" align=center> 
        <td colspan="4"> <br>
          <input type="hidden" name="cmd" value="<%=Request("cmd")%>">
          <input type="hidden" name="PackageID" value="<%=PackageID%>">
          <input type="hidden" name="DepartDate" value="<%=DepartDate%>">
          <input type="hidden" name="AmountOfTraveller" value="<%=AmountOfTraveller%>">
          <input type="submit" name="Submit" value="Submit" class="button">
          <input type="reset" name="Submit2" value="Reset" class="button">
        </td>
      </tr>
    </table>
</form>
</DIV>
<%end if%>

</BODY>
</HTML>