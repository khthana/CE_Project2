
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>
<BODY>
<script language="JavaScript">
<!--
	function checkform(form){
		alert(date.parse(form.text.value));
		return false	
	}
-->
</script>
<form name="test" action="test.asp" method="post" onsubmit="return checkform(this)">
<INPUT type="text" id=text1 name=text>
<INPUT type="submit" value="Submit" id=submit1 name=submit1>
</form>

</BODY>
</HTML>
