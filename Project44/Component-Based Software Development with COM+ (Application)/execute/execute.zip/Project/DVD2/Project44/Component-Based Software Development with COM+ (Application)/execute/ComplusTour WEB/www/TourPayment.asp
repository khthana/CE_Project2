<HTML>
<HEAD>
<title> OLALA TOUR </Title>
<link rel="stylesheet" type="text/css" href="homestyle.css">
</HEAD>
<BODY>

<% BookingID = Request("BookingID")
   TotalPrice = Request("Price")
   'for each aaaa in Request.ServerVariables 
   'Response.Write "<br>dsadsa" & aaaa 
   'next
   'Response.Write Request.Form.Count 
   'Response.Write "BookingID=" & BookingID
   'Response.Write "TotalPrice=" & TotalPrice	%>
<form name="payment" method="post" action="TourpaymentComplete.asp">
<table width="90%" border="0" cellspacing="0" cellpadding="2" align="center">
	<tr>
		<td colspan="4" align="center"><font face="MS Sans Serif" color="#FF9933">�ʹ�Թ����ͧ���� &nbsp; <%=TotalPrice%> &nbsp; �ҷ</font>	
    </tr>
    <tr> 
		<td colspan="4"><font face="MS Sans Serif"><font  color="#0D549B"><b>�����źѵ��ôԵ</b></font></font></td>
    </tr>
    <tr> 
        <td width="20%"> 
	      <div align="right"><font face="MS Sans Serif" size="-1">��Դ�ѵ�&nbsp;&nbsp; </font></div>
        </td>
        <td width="30%"> <font face="MS Sans Serif"> 
			<select name="select">
				<option value="AMEX" selected>Amarican Express</option>
                <option>Discover</option>
                <option>MasterCard</option>
                <option>VISA</option>
                <option>Diner's Club</option>
            </select>
		</font></td>
        <td width="21%"> 
			<div align="right"><font face="MS Sans Serif" size="-1"> �ѹ�������&nbsp;&nbsp; 
        </font></div>
        </td>
        <td width="29%"><font face="MS Sans Serif" size="-1" > ��͹ </font>
			<select name="select2">
				<option value="Jan"><font size="-1" face="MS Sans Serif"> ���Ҥ� </font></option>
                <option value="Feb"><font size="-1" face="MS Sans Serif"> ����Ҿѹ��</font></option>
                <option value="Mar"><font size="-1" face="MS Sans Serif"> �չҤ�</font></option>
                <option value="Apr"><font size="-1" face="MS Sans Serif"> ����¹</font></option>
                <option value="May"><font size="-1" face="MS Sans Serif"> ����Ҥ� </font></option>
                <option value="Jun"><font size="-1" face="MS Sans Serif"> �Զع�¹</font></option>
                <option value="Jul"><font size="-1" face="MS Sans Serif"> �á�Ҥ� </font></option>
                <option value="Aug"><font size="-1" face="MS Sans Serif"> �ԧ�Ҥ� </font></option>
                <option value="Sep"><font size="-1" face="MS Sans Serif"> �ѹ��¹ </font></option>
                <option value="Oct"><font size="-1" face="MS Sans Serif"> ���Ҥ� </font></option>
				<option value="Nov"><font size="-1" face="MS Sans Serif"> ��Ȩԡ�¹ </font></option>
                <option value="Dec"><font size="-1" face="MS Sans Serif"> �ѹ�Ҥ� </font></option>
            </select>
        </td>
    </tr>
    <tr> 
        <td width="20%"> 
           <div align="right"><font face="MS Sans Serif" size="-1">�Ţ���ѵ�&nbsp;&nbsp; 
            </font></div>
        </td>
        <td colspan="2"> <font face="MS Sans Serif"><font face="MS Sans Serif"> 
            <input type="text" name="textfield3" maxlength="16" class="textbox" >
        </font></font></td>
				
        <td width="29%"><font face="MS Sans Serif" size="-1">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             </font> 
                    <select name="select3">
                      <option value="2545"><font size="-1" face="MS Sans Serif">2545 
                      </font></option>
                      <option value="2546"><font size="-1" face="MS Sans Serif">2546 
                      </font></option>
                      <option value="2547"><font size="-1" face="MS Sans Serif">2547 
                      </font></option>
                      <option value="2548"><font size="-1" face="MS Sans Serif">2548 
                      </font></option>
                      <option value="2549"><font size="-1" face="MS Sans Serif">2549 
                      </font></option>
                      <option value="2550"><font size="-1" face="MS Sans Serif">2550 
                      </font></option>
                      <option value="2551"><font size="-1" face="MS Sans Serif">2551 
                      </font></option>
                    </select>
                    </td>
                </tr>
                <tr> 
                  <td colspan="4" height="35" valign=bottom><font  color="#0D549B" face="MS Sans Serif"><b>�����ż���ͺѵ�</b></font> 
                  </td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">���� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield6" size="20"  class="textbox">
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">���ʡ�� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield62" size="20"  class="textbox">
                    </font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">��ҹ�Ţ��� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield63" size="20"  class="textbox">
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">��� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield64" size="20"  class="textbox">
                    </font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">�ѧ��Ѵ &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield67" size="20"  class="textbox">
                    </font></td>
                  <td width="21%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">������ɳ��� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="29%"><font face="MS Sans Serif"> 
                    <input type="text" name="textfield68" size="20"  class="textbox">
                    </font></td>
                </tr>
                <tr> 
                  <td width="20%"> 
                    <div align="right"><font face="MS Sans Serif" size="-1">����� &nbsp;&nbsp; </font></div>
                  </td>
                  <td width="30%"> <font face="MS Sans Serif"> 
                    <input type="text" name="textfield69" size="20"  class="textbox">
                    </font></td>
                  <td width="21%">&nbsp;</td>
                  <td width="29%">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"> 
                    <div align="center"> 
                      <input type="submit" name="Payment" value="Submit" class="button">
                      <input type="hidden" name="BookingID" value="<%=BookingID%>">
                      <input type="reset" name="Submit4" value="Reset" class="button">
                    </div>
                  </td>
                </tr>
              </table>
      </form>
      

</BODY>
</HTML>
