<HTML>
<HEAD>
<TITLE> OLALA TOUR </TITLE>
</HEAD>
<BODY>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}

-->
</script>
<%
	'on error resume next
	
	
	'Response.Write "<br>fdsfsdfds ==== " & objbooking.item(1).BookingID
	
	
	
	
	CustomerID = Request.Cookies("TourCustomerID")
	
	'set objBookingFac = server.CreateObject("DALDB.CBookingFactory")
	'set IBookViewer = server.CreateObject("TourBookingService.IBookViewer")
	'set objBooking = IBookViewer.GetBooking(cint(CustomerID))
	'objBookingFac.Serialize = objBooking.Serialize
	
	'set IBookViewer = nothing
	'set objBooking = nothing
	'set objBookingFac = nothing
	
	
	cmd = Request.Form("TourBooking")
	BookingID = Request.Form("BookingID")
	TotalPrice = Request.Form("Price")
	Response.Write "BookingID="  & BookingID & "VS" & Request.Form("BookingID")
	dim TourBookingService
	set TourBookingService = server.CreateObject("TourBookingService.IBookManager")
	
	if cmd = "�ӹǳ�Ҥ�����" then
		HotelItemArr = Request.Form("HotelDelItem")
		AirlineItemArr = Request.Form("AirlineDelItem")
		BusItemArr = Request.Form("BusDelItem")
		PackageItemArr = Request.Form("DelPackageBooking")
		
		'================CancelHotelBookingDetail====================	
		if HotelItemArr <> "" then
			HotelBookingID = Request.Form("HotelBookingID")
			HotelItemArr = split(HotelItemArr,", ")
			
			'Response.Write "HotelBookingID=" & HotelBookingID & "<br>"
			for i = 0 to ubound(HotelItemArr)
				'Response.Write "HotelItemArr(i)=" & HotelItemArr(i) & "<br>"
				
				DelHotelBoo = TourBookingService.CancelHotelBookingDetail(cint(HotelBookingID),cint(HotelItemArr(i)))
				'Response.Write "DelHotelBoo=" & DelHotelBoo & "<BR>"
			next
		end if
		
		'================CancelAirlineBookingDetail====================
		if AirlineItemArr <> "" then
			AirlineBookingID = Request.Form("AirBookingID")
			AirlineItemArr = split(AirlineItemArr,", ")
			for i = 0 to ubound(AirlineItemArr)
				TourBookingService.CancelAirlineBookingDetail cstr(AirlineBookingID),clng(AirlineItemArr(i))
			next
		end if
		
		'================CancelBusBookingDetail====================
		if BusItemArr <> "" then
			BusBookingID = Request.Form("BusBookingID")
			BusItemArr = split(BusItemArr,", ")
			for i = 0 to ubound(BusItemArr)
				TourBookingService.CancelBusBookingDetail cstr(BusBookingID),clng(BusItemArr(i))
				'Response.Write "ItemArr(i)=" & BusItemArr(i) & "<BR>"
			next
		end if
		
		'================CancelPackageBookingDetail====================
		if PackageItemArr <> "" then
			PackageItemArr = split(PackageItemArr,", ")
			for i = 0 to ubound(PackageItemArr)
				TourBookingService.CancelPackageBooking Cint(BookingID),Cint(PackageItemArr(i))
				'Response.Write "ItemArr(i)=" & ItemArr(i) & "<BR>" 
			next
		end if
		
		
		set TourBookingService = nothing
		

'		set objBookingFac = server.CreateObject("DALDB.CBookingFactory")
'		set IBookViewer = server.CreateObject("TourBookingService.IBookViewer")
'		set objBooking = IBookViewer.GetBooking(cint(CustomerID))
'		set IBookViewer = nothing
'		objBookingFac.Serialize = objBooking.Serialize
'		
'		for i =1 to objBookingFac.Count
'			if objBookingFac.Item(i).TotalPrice = 0 then
'				set IBookManager = server.CreateObject("TourBookingService.IBookManager")
'					Boo = IBookManager.CancelAllBooking(cint(objBookingFac.Item(i).BookingID))
'				set IBookManager = nothing
'				Response.Write "CalcelAllBooking " & i & " = " & Boo & "<br>"
 '			end if
'		next
'===========================================================================		
'		set objBookingFac = server.CreateObject("DALDB.CBookingFactory")
'		set IBookViewer = server.CreateObject("TourBookingService.IBookViewer")
'		set objBooking = IBookViewer.GetBooking(cint(CustomerID))
'		' Response.Write objbooking.item(1).HotelBookingID
'		objBookingFac.Serialize = objBooking.Serialize
'		for i = 1 to objBookingFac.Count
'			if BookingID = objBookingFac.Item(i).BookingID then 
'				HasPackage = false
'				HasHotel = false
'				HasAir = false
'				HasBus = false
'				
'				
'				'======================Hotel===========================
'				
'				if objBookingFac.Item(i).HotelBookingID = 0 then
'					HasHotel = true
'				else	
'					Response.Write "HotelBookingID=" & objBookingFac.Item(i).HotelBookingID & "<br>"
'					err.number = 0
'					
'					set objHotelBooking.serialize = IBookViewer.GetHotelBookingDetail(cint(objBookingFac.Item(i).HotelBookingID)).Serialize
'					if err.number <> 0 or objHotelBooking is nothing or objHotelBooking.count = 0 then
'						HasHotel = true
'					end if
'				end if
'				'=====================Bus========================
'				if objBookingFac.Item(i).BusBookingID = "0" then
'					HasBus = true
'				else
'					err.number = 0
'					'set objBusBookingFac = server.CreateObject("DALDB.C")
'					set objBusBooking = IBookViewer.ViewBusBookinginfo(cstr(objBookingFac.Item(i).BusBookingID))
'					
'					if err.number <> 0 or objBusBooking is nothing then
'						HasBus = true
'					end if
'				end if
'				'=====================Air=======================
'				if objBookingFac.Item(i).AirLineBookingID = "0" then
'					HasAir = true
'				else
'					err.number = 0
'					set objAirBooking = IBookViewer.ViewAirlineBookinginfo(cstr(objBookingFac.Item(i).AirLineBookingID))
'					if err.number <> 0 or objAirBooking is nothing then
'						HasAir = true
'					end if
'				end if
'			
'			'=====================Package================================
'				on error resume next
'				err.number = 0
'				set objPackageBooking = IBookViewer.GetPackageBooking(cint(BookingID))
'				'on error goto 0
'				Response.Write "err.number=" & err.number & "<br>"
'				if err.number <> 0  then 'or objPackageBooking is nothing or objPackageBooking.count = 0 then
'					HasPackage = true
'				end if
'			
'			
'			set IBookViewer = nothing
'			set IBookManager = nothing
'			set IBookManager = server.CreateObject("TourBookingService.IBookManager")
'				boo = false
'				if HasPackage and HasHotel and HasBus and HasAir then
'					Response.Write "CancelAllBooking<BR>"
'					Response.Write "BookingID=" & BookingID & "<BR>"
'					on error goto 0
'					'boo = IBookManager.CancelAllBooking(cint(BookingID))
'				end if
'			set IBookManager = nothing
'			end if 'BookingID
'		next 'i
		
'		Response.Write "HasPackage=" & HasPackage & "<br>"
'		Response.Write "HasHotel=" & HasHotel & "<br>"
'		Response.Write "HasBus=" & HasBus & "<br>"
'		Response.Write "HasAir=" & HasAir & "<BR>"
'		Response.Write "CancelBooking=" & boo
'		
		Response.Redirect("BookingResult.asp")
'		'Response.Write ItemArr		
'	
	
	
	
	elseif cmd = "�׹�ѹ��èͧ" then
'		Response.Write bookingid
		err.number = 0
		boo = TourBookingService.ConfirmBooking(Clng(BookingID))
		if err.number <> 0 then
			 Response.Write "ERROR : Can't Confirm This Booking <BR>" & err.Description
		else
		'Response.Write "BookingID=" & BookingID & "boo=" & boo 
			Response.Redirect("TourPayment.asp?BookingID=" & BookingID & "&Price=" & TotalPrice)	
		end if
	end if


%>

</BODY>
</HTML>
