gacutil /u AirlineProxy
regasm /u airlineproxy.dll /tlb:airlineproxy.tlb