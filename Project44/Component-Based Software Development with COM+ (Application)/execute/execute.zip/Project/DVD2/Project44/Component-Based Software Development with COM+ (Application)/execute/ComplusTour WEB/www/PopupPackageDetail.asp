<HTML>
<HEAD>

	<HEAD><TITLE> OLALA TOUR  :: Package Detail </TITLE>
	<META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>
	
<BODY bgColor=#ffffff>

<%
	'on error resume next
	PackageID = Request.QueryString("PackageID")
	DepartDate = Request.QueryString("DepartDate")
	'Response.Write "PackageID = " & PackageID & "<BR>"
	'Response.Write "DepartDate = " & DepartDAte & "<br>"
	dim TourService
	dim objPackageDepartureFac
	dim objPackageDeparture
		set TourService = server.CreateObject("TourService.IPackageViewer")
		set objPackageDepartureFac = server.CreateObject("DALDB.CPackageDepartureFactory")
		set objPackageDeparture = TourService.GetPackageDeparture(Cint(PackageID))
		objPackageDepartureFac.Serialize = objPackageDeparture.Serialize
		for i = 1 to objPackageDepartureFac.Count
			'Response.Write objPackageDepartureFac.Count & "<BR>"
			'Response.Write objPackageDepartureFac.Item(i).DepartDate & "<br>"
			'Response.Write DepartDate & "<br>"
			'Response.Write objPackageDepartureFac.Item(i).PackageCloseDate & "<BR>"
			'Response.Write " kk " & objPackageDepartureFac.Item(i).DepartDate & "<BR>"
			'Response.Write " rr " & DepartDate & "<BR>"
			if objPackageDepartureFac.Item(i).DepartDate = Cdate(DepartDate) then
				with objPackageDepartureFac.Item(i) 
					NumOfTraveller = .NumOfTraveller
					MaxTraveller = .MaxTraveller 
					ChildPrice = .ChildPrice
					AdultPrice = .AdultPrice
					PackageCloseDate = .PackageCloseDate
					'Response.Write "PackageCloseDate = " & objPackageDepartureFac.Item(i).PackageCloseDate & "<br>"
				End with
			end if
		next
	'Response.Write "PackageCloseDate = " & PackageCloseDate & "<br>"
	dim objPackageFac
	dim objPackage
		set objPackageFac = server.CreateObject("DALDB.CPackageFactory")
		set objPackage = TourService.GetPackage(cint(PackageID))
		objPackageFac.Serialize = objPackage.Serialize
		with objPackageFac.Item(1)
			PackageName = .PackageName
			Description = .Description
			NumOfDays = .NumOfDays
		end with

%>
	
<DIV align=center>
  <p>&nbsp;</p>
  <p><font color="#FF0000"><b><%=PackageName%> </b></font> </p>
  <TABLE cellSpacing=0 cellPadding=1 width="70%" border=0>
	<TBODY>
		<TR>
			<TD  colspan=2 class=head12 align=center>
			
			<BR>
        <font size="-1"><b><font color="#006699">�Ҥ�����Ѻ����˭� <%=AdultPrice%> 
        �ҷ/��ҹ <BR>
        �Ҥ�����Ѻ�� <%=ChildPrice%> �ҷ/��ҹ </font></b></font> </TD>
		</TR>
		<TR>			<TD>&nbsp;					</TD>	</TR>
		
		<!--TD width="8%" >&nbsp;</TD-->
		<!--TD><DIV align=center class="text"><B>�͡�Թ�ҧ�ѹ��� <%=DepartDate%> ������ <%=NumOfDays%> �ѹ <%=NumOfDays - 1%> �׹</B></DIV>
		</TD
		</TR>-->
		<TR>
      <TD align=center class="head9"><font color="#006699" size="-1"><%=Description%></font></TD>
		</TR>		
	
	</TBODY>
	</TABLE>

	
  <table width="70%" border="3" cellspacing=0  cellpadding=0 bordercolor="#FFFFFF" bgcolor="#F5F5F5">
    <tr bgcolor="#006699"> 
      <td width="30%"> 
        <DIV align="center" class="text"><font color="#FFFFFF" size="-1"><b>�ѹ���</b></font></DIV>
      </td>
      <td width="30%"> 
        <DIV align="center" class="text"><font color="#FFFFFF" size="-1"><b>����</b></font></DIV>
      </td>
      <td width="40%"> 
        <DIV align="center" class="text"><font color="#FFFFFF" size="-1"><b>ʶҹ���</b></font></DIV>
      </td>
    </tr>
    <%
	dim objPackageDetailFac
	dim objPackageDetail
		set objPackageDetailFac = server.CreateObject("DALDB.CPackageDetailFactory")
		set objPackageDetail = TourService.GetPackageDetail(Cint(PackageID))
		objPackageDetailFac.Serialize = objPackageDetail.Serialize 
		for i = 1 to objPackageDetailFac.Count
			Days = objPackageDetailFac.Item(i).Days
			TimeOfDay = Timevalue(objPackageDetailFac.Item(i).TimeOfDay)
			PlaceID = objPackageDetailFac.Item(i).PlaceID
			dim objPlaceFac
			dim objPlace
			set objPlaceFac = server.CreateObject("DALDB.CPlaceFactory") 
			set objPlace = TourService.GetPlace(Cint(PlaceID))
			objPlaceFac.Serialize = objPlace.Serialize
			PlaceName = objPlaceFac.Item(1).PlaceName	  
			
%>
    <tr class="text" align="center" bgcolor="#EEEEEE"> 
      <td width="30%"><%=Days%></td>
      <td width="30%"><%=TimeOfDay%></td>
      <td width="40%"><%=PlaceName%></td>
    </tr>
    <%		next
%>
  </table>
	
<form action="javascript:window.close();">
	<input type="submit" name="OK" value="     OK     " class="buttonbox">	
</form>
	
	<P></P>
</DIV>
</BODY>
</HTML>