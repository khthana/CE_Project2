<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title> OLALA TOUR </title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>


</head>

<body bgcolor="#FFFFFF" >
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>

<table width="779" border="0" cellspacing="0" cellpadding="5">
  <tr> 
    <td width="148" bgcolor="#D7DCE8" height="249" valign="top"> 
<%
	on error resume next
			CustomerID = Request.Cookies("TourCustomerID")
			'response.write CustomerID
%>
    </td>
    <td width="631" height="249" valign="top"> <!-- #BeginEditable "Center_Content" --> 
<%

	'on error resume next
	set objMyReserve = server.CreateObject("TourBookingService.IBookViewer")
	set objHotelBookings = Server.CreateObject("DALDB.cHotelBookingFactory")
	set objHotelBookingDetails = Server.CreateObject("DALDB.cHotelBookingDetailFactory")
	'set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
	set util = server.CreateObject("ComplusUtil.IUtility")
	dim i

	HotelBookingID = 'Request.Form("HotelBookingID")
	TotalPrice = Request.Form("Totalprice")
	
	if Request.Form("InBooking") = "�����Թ" then
		Response.Redirect("Payment.asp?HotelBookingID=" & HotelBookingID & "&TotalPrice=" & Totalprice)
	elseif Request.Form("InBooking") = "�ӹǳ����" then
	'	Response.Write "del_ItemNO-->" & Request.Form("delItem") & "<BR>"
		delitem = Request.Form("delItem")		
		arr_delitem = split(delitem,", ")
		set ManageReserve = server.CreateObject("BookingService.IBookManager")
		
		for k = 0 to ubound(arr_delitem)
			manageReserve.CancelBookingDetail clng(HotelBookingID), Clng(arr_delItem(k))
		next
	end if


	'get booking from cusID
	objHotelBookings.Serialize = objMyreserve.GetHotelBooking(Clng(CustomerID)).Serialize
	'Response.Write "HotelBookingID =" & objHotelBookings.Item(1).HotelBookingID
%>

<div align="center"><b><font size="+1" color="#FF9933" face="MS Sans Serif">

<%	if err.number <>0 then	%>
����բ����š�èͧ�ͧ�س
<%else%> 
     �����š�èͧ�ͧ�س</font></b></div>
      <br>

<%
	showitem = 1
	for  i = 1 to objHotelBookings.Count
	dim HotelBookingID
	editable = true
	HotelBookingID = 	objHotelBookings.Item(i).HotelBookingID
'	Response.Write "HotelBookingID=" & HotelBookingID
'	set objReserveHotels = Server.CreateObject("DALDB.CReserveHotelDetailFactory")
	set objHotelBookingDetails = Server.CreateObject("DALDB.cHotelBookingDetailFactory")
	objHotelBookingDetails.Serialize = objMyreserve.GetHotelBookingDetail(Clng(HotelBookingID)).Serialize

	ee=0
'	Response.Write "������ " & objHotelBookingDetails.count  & "��¡��" & "<br>"
	ee=objHotelBookingDetails.count
'	Response.Write "TYPE" & ee & "<br>"
'	Response.Write "CNT=" & objHotelBookingDetails.count & "<br>"

	if ee > 0 then 
	
'	Response.Write "CusID=" &  CustomerID & " has Booking=" & objHotelBookings.Count &" Item"
'	Response.Write "<br>"
'	Response.Write "In Booking Item " & i & " has Detail=" & objHotelBookingDetails.Count & "Item"
%>	  
      <form name="form <% =i %> " method="post" action="">
	��¡�÷�� <%=showitem%>  
	<%showitem = showitem + 1%>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <td colspan="6"> 
            <% if objHotelBookings.Item(i).Confirmation = False then %>
            ��س��׹�ѹ��Ъ����Թ��¡�õ��仹�������ѹ��� <%= objHotelBookings.Item(i).ConfirmDeadline %> 
            <% else %>
            ��¡�õ��仹�� �׹�ѹ��Ъ����Թ���º�������� 
            
            <%	editable = false
				end if 
			%>
          </td>
          </tr>
          <tr> 
            <td width="5%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">ź</font></b></font></div>
            </td>
            <td width="8%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��¡�� 
                </font></b></font></div>
            </td>
            <td width="21%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ѹ�ѡ</font></b></font></div>
            </td>
            <td width="28%" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ç���</font></b></font></div>
            </td>
            <td height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="13%" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�Ҥ� 
                (�ҷ)</font></b></font></div>
            </td>
          </tr>
          <%
			dim j 
			for j = 1 to objHotelBookingDetails.Count
			
		  %>
          <tr <%  if J mod 2 = 0 then Response.Write "bgcolor=#D7DCE8" %>> 
            <td width="5%"> 
              <div align="center"><font size="-1"> 
                <%if editable then%>
                <input type="checkbox" name="delItem" value="<%=objHotelBookingDetails.Item(j).ItemNo %>">
                <%else%>
                <b>-</b> 
                <%end if%>
                </font></div>
            </td>
            <td width="8%"> 
              <div align="center"><font size="-1"><%=j%></font></div>
            </td>
            <td width="21%"><font size="-1"><%=objHotelBookingDetails.Item(j).BookCheckIn %> 
              - <%=objHotelBookingDetails.Item(j).BookCheckOut%></font></td>
            <td width="28%"><font size="-1">	<a href="javascript:openViewHotelWindow('<%=objHotelBookingDetails.Item(j).HotelID%>')"><%=objHotelBookingDetails.Item(j).HotelName%></a>
			</font></td>
            <td> 
              <div align="center"><font size="-1"><a href="javascript:openViewRoomModelWindow('<%=objHotelBookingDetails.Item(j).RoomModelID%>')"><%=objHotelBookingDetails.Item(j).RoomModelName%></a></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><%=objHotelBookingDetails.Item(j).BookingPrice%> 
                </font></div>
            </td>
          </tr>
          <%
			next 'j
		%>
          <tr> 
            <td colspan="5"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><b><font color="#0D549B"><%=objHotelBookings.Item(i).TotalPrice %></font></b></font></div>
            </td>
          </tr>
        </table>
          <% if editable then %>
		<div align="right"> 
          <p> 
			<input type="submit" name="InBooking" value="�ӹǳ����">
            <input type="hidden" name="HotelBookingID" value="<%= HotelBookingID %>">
            <input type="hidden" name="TotalPrice" value="<%=objHotelBookings.Item(i).TotalPrice %>">
            <input type="submit" name="InBooking" value="�����Թ">
          </p>
          </div>
<%end if %>
      </form>
	 <BR>
      <% 
		end if ' bookingdetail.count >0
      next 'i
	
		
	end if ' no reserve
		
		
		end if ' no customerID
	%>
      <!-- #EndEditable --></td>
  </tr>
  <tr>
    <td width="148" bgcolor="#D7DCE8" height="28" valign="top">&nbsp;</td>
    <td width="631" height="28" valign="top">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
