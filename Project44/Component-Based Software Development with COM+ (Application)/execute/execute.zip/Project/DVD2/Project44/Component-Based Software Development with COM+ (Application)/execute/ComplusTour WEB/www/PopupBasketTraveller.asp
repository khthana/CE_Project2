<HTML>
<HEAD>
<HTML>
	<HEAD><TITLE> OLALA TOUR </TITLE>
	<META http-equiv=Content-Type content="text/html; charset=windows-874">
	    <script language="JavaScript" SRC="js_code.js"></Script>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	</Head>
	
<BODY bgColor=#ffffff>

<DIV align=center> 
  <p>&nbsp;</p>
  <p><b><font color="#FF0000">��ª��ͼ���Թ�ҧ</font></b> </p>
  <table width="100%" border="0" cellspacing="3" cellpadding="0">
    <tr class="head3" align=center> 
      <td width="20%" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">�ӴѺ���</font></b></td>
      <td colspan="2" bgcolor="#006699"><b><font color="#FFFFFF" size="-1">���ͼ���Թ�ҧ</font></b></td>
    </tr>
    <form name="CancelTravellerForm" action="javascript:window.close();">
      <%
'	on error resume next
	BasketID = Request("BasketID")
	PackageBasketItemID = Request("PackageBasketItemID")
	TravellerItemID = Request("TravellerItemID")
	
'	Response.Write "PackageBasID = " & PackageBasketItemID & "<BR>"
'	Response.Write "BasketID = " & BasketID & "<br>"
'	Response.Write "delTr=" & TravellerItemID
	'cmd = Request.Form("cmd")
	

	dim TourBookingService
	dim objPackageBookingDetailFac
	dim objPackageBookingDetail
	
	if TravellerItemID <> "" then
		
		'Response.Write "loop if"
		'Response.Write "BookingID = " & BookingID & "<BR>"
		'Response.Write "ItemNo = " & ItemNo & "<BR>"
		'Response.Write "TravellerNo = " & TravellerNo & "<BR>"		

		set TourBasketService = server.CreateObject("TourBookingService.IBasket")
		TourBasketService.RemoveBasketTravellerItem clng(TravellerItemID) 
	
	end if

		set objBasket = server.CreateObject("TourBookingService.IBasket")
		set objPackageBaskets =Server.CreateObject("DALDB.CReservePackageDetailFactory")
		set objPackageBaskets = objBasket.ViewBasket(Clng(BasketID)).Item(2)
'		set objTravellers = Server.CreateObject("DALDB.CTraveller")
	
'	Response.Write VarType(objPackageBaskets)
if not objPackageBaskets is nothing then
		for i =1 to objPackageBaskets.Count
			if objPackageBaskets.Item(i).packageBasketitemid = clng(packageBasketitemid) then
					
		if objPackageBaskets.Item(i).colTraveller.count = 0 then
%>
      <tr class="text" align="center"> 
        <td colspan=3> <b><font color="#FF0000" size="-1">����ռ���Թ�ҧ</font></b> 
        </td>
      </tr>
      <%		else %>
      <% for j = 1 to objPackageBaskets.Item(i).colTraveller.count %>
      <tr class="text" align=center> 
        <td width="20%" bgcolor="#EEEEEE"><%=j%></td>
        <td width="60%" bgcolor="#EEEEEE"><%=objPackageBaskets.Item(i).colTraveller.Item(j).TravellerName%></td>
        <td bgcolor="#EEEEEE" width="20%"><a href="PopupBasketTraveller.asp?BasketID=<%=BasketID%>&TravellerItemID=<%=objPackageBaskets.Item(i).colTraveller.Item(j).TravellerItemID%>&PackageBasketItemID=<%=PackageBasketItemID%>">Cancel</a></td>
      </tr>
      <%next 'j%>
      <%	
		'Response.Write "BookingID = " & BookingID & "<BR>"
		'Response.Write "ItemNo = " & ItemNo & "<BR>"
		'Response.Write "TravellerNo = " & TravellerNo & "<BR>"
			end if
	end if	
next

else 
%>
      <tr class="text" align="center"> 
        <td colspan=3> <b><font color="#FF0000" size="-1">����ռ���Թ�ҧ</font></b> 
        </td>
      </tr>
      <%end if%>
      <tr> 
        <td colspan=2>&nbsp;</td>
        <td width="20%"> 
          <div align=center> 
            <input type="submit" class="buttonbox" name="OK" value="      OK      ">
          </div>
        </td>
      </tr>
    </form>
  </table>
</DIV>
</BODY>
</HTML>