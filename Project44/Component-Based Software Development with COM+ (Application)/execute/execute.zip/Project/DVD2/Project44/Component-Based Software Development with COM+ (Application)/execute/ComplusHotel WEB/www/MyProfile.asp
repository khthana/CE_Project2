<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title>OLALA HOTEL :: My Profile </title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css">

  <link rel="stylesheet" type="text/css" href="Templates/style.css">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" topMargin= 0>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>
<table width="98%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="52" colspan="2" > <!--
      <p><b><font face="Arial, Helvetica, sans-serif" size="+2" color="6B8EC6"><font color="#FFFFFF">OLALA 
        HOTEL</font> </font></b></p>-->
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td width="5%">&nbsp;</td>
			<td align="center" valign="bottom"> 
				<img src="images/hd_hotel_pic1.gif" height="60"> </td>
			<td align="center" valign="top"> 
				<img src="images/hd_hotel_pic.gif" height="60"> </td>
			<td align="center" valign="middle"> 
				<img src="images/hd_hotel_pic2.gif"  height="60"> </td>

			<td align="right"> <img src="images/hd_olalahotel.gif"> </td>
		</tr>
		</table>

    </td>
  </tr>
 <!-- <tr> 
    <td bgcolor="#006699" width="36%">&nbsp;&nbsp;&nbsp;
		<a href="../index.asp" class=z1>Main</a>|
		<a href="#" class=z1> Search </a>|
		<a href="../basket.asp" class=z1>View Basket</a>| 
		<a href="../basket.asp" class=z1>Checkout  </a>|</td>
    <td bgcolor="#006699" width="64%"> 
      <div align="right"><font color="#FFFFFF" size="-1">Disclimer | Policies 
        | Feedback | FAQ | Help | About | Coutact Us</font></div>
    </td>
  </tr>-->
  <tr>
  <td>
  <table width="99%" border="0" cellspacing="1" cellpadding="0" align="center" bgcolor="black">
  <tr bgcolor="#FF6666"> 
    <td bgcolor="#FFCC99" width="17%" align="center" class="head5">
      <a href="index.asp" class="link1"><b>Main</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp"  class="link1"><b>Search</b></a>
    </td>

    <td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="basket.asp" class="link1"><b>View Basket</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp" class="link1"><b>About Us</b></a>
    </td>

  </tr>
	<tr>
          <td align="right" colspan="4" bgcolor="#76CCFF" height=4><img src="images/1x1b.gif" border="0" /></td>
    </tr>

</table>
</td>
</tr>

</table>


<table width="99%" border="0" cellspacing="0" cellpadding="5" align="center" height="600">
  <tr> 
    <td width="17%" bgcolor="#D7DCE8" height="330" valign="top" align="center"> 
      <%
	on error resume next
			cmd = Request.Form("cmd")
			Email = Request.Form("Email")
			Password = Request.Form("Password")
			'frompage = request("frompage")		
			'pagename=request.servervariables("script_name")
	
			if cmd = "login" then
			set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
			CustomerID = objCustomer.Login(Cstr(Email),Cstr(Password))
					if err.number = 0 and CustomerID > 0 then
						Response.Cookies("CustomerID") = CustomerID
						Response.Cookies("CustomerID").expires = date+1
'						Response.Cookies("BasketID").expires = now
						
							
							if request.servervariables("script_name") = "/complushotel/www/loginerror.asp" then
								response.redirect("myreservation.asp")
							end if

					else
							select case err.number 
								case vbObjectError+1 err_txt = "notfound"
								case vbObjectError+5 err_txt = "wrongpassword"
							end select
						err_txt = "loginerror.asp?err="  & err_txt 
						response.redirect(err_txt)
					end if  
			end if		    	
		'	cmd  = request.querystring("cmd")
			if cmd="logout" then
						Response.Cookies("BasketID").expires = now
						Response.Cookies("CustomerID").expires = now
						Response.Cookies("BasketID") =""
						Response.Cookies("CustomerID") = ""

			end if
	
			
			CustomerID = Request.Cookies("CustomerID")
			'response.write CustomerID
			if CustomerID = "" then
			'' render login box
%>
      <form name="form1" method="post" action="">
        <table width="130" border="0" cellspacing="0" cellpadding="0" align="center" >
          <tr align="center" > 
            <td  width="130" height=25 >
				<div align="center"><img src="images/login.gif" ></div>
            </td>
          </tr>
          <tr> 
            <td width="130" class="head7"><br><b>   E-mail address </b></td>
          </tr>
          <tr> 
            <td height="15" width="130"> <font size="-1"> 
              <input type="text" name="Email" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td width="130" class="head7" height=20 valign="bottom"><b>Password</b></td>
          </tr>
          <tr> 
            <td width="130"> <font size="-1"> 
              <input type="password" name="Password" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td height="10" width="130"> 
              <div align="center"><font size="-1"> 
			   
				<input type="hidden" name="cmd" value="login">
			  	<input type="hidden" name="country" value="<%=Request.Form.Item("Country")%>">
			  	<input type="hidden" name="state" value="<%=Request.Form.Item("State")%>">
			  	<input type="hidden" name="city" value="<%=Request.Form.Item("City")%>">
			  	<input type="hidden" name="star" value="<%=Request.Form.Item("star")%>">
			  	<input type="hidden" name="HotelName" value="<%=Request.Form.Item("HotelName")%>">
			  	<input type="hidden" name="RoomModelName" value="<%=Request.Form.Item("RoomModelName")%>">
			  	<input type="hidden" name="PriceRate" value="<%=Request.Form.Item("PriceRate")%>">
			  	<input type="hidden" name="CheckInDate" value="<%=Request.Form.Item("CheckInDate")%>">
			  	<input type="hidden" name="CheckOutDate" value="<%=Request.Form.Item("CheckOutDate")%>">
			  	<input type="hidden" name="AmountOfRoom" value="<%=Request.Form.Item("AmountOfRoom")%>">
			<br><br>
							<input type="submit" name="Submit" value="Login" class="smbutton">
                <input type="reset" name="Submit2" value="Reset" class="smbutton">
                <br><br>
                <a href="lostpassword.asp"> ������ʼ�ҹ </a><br>
                <a href="register.asp"> ��Ѥ���Ҫԡ���� </a></font></div>
            </td>
          </tr>
        </table>
      </form>
<%
			else
			 'show customer name and render customer menu 
				set Customers = Server.CreateObject("DALDB.CCustomerFactory")
				set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
				customers.Serialize  = objCustomer.GetCustomer(clng(CustomerID)).Serializer
				CustomerName = Customers.item(1).CustomerName
%>

      <table width="130" border="0" cellspacing="1" cellpadding="0" align="center" dwcopytype="CopyTableRow">
        <tr > 
          <td bgcolor="#3B8EC6" height="38" align=center><font size="-1" color="#FFFFFF"><b>���ʴդ�Ѻ 
            <br>
            �س <%=CustomerName%> </b></font></td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26"> 
            <div align="center"><font size="-1"><a href="MyProfile.asp" class="z2"> ��䢢�����</a></font></div> 
          </td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26" > 
            <div align="center"><font size="-1"><a href="MyReservation.asp" class="z2"> ��¡�èͧ</a></font></div>
          </td>
        </tr>
        <tr> 
          <td height="15" bgcolor="#6B8EC6" width="116"><br>
<div align="center">
              <form name="formx" method="post" action="index.asp">
                <input type="hidden" name="cmd" value="logout">
                <!--<input type="image" name="Submit" value="logout" src="../images/viewonmap.gif" width="70" height="13">-->
				<input type="submit" name="Submit" value="logout" class="button">
				
			  </form>
              </div>
          </td>
        </tr>
      </table>
<%
			end if ' render login box OR menu
%>
    </td>
    <td width="625" height="249" valign="top"> 
		<table width="95%" align="center">
			<tr>
				<td>
					<!-- #BeginEditable "Center_Content" -->
<%
'	on error resume next

	set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")	
	error = false
	if Request.Form("cmd").Item	= "regist"  OR Request.Form("cmd").Item	= "Edit" then
		CustomerName = Request.Form("CustomerName")
		Address = Request.Form("Address")
		Gender = Request.Form("Gender")
		Telephone = Request.Form("Telephone")
		Email = Request.Form("Email")
		Password = Request.Form("Password")
		ConfirmPassword = Request.Form("ConfirmPassword")
	passwordnotmatch	= false
		if confirmpassword <> password then
			passwordnotmatch = true
		end if
		if cmd = "regist" then
					if passwordnotmatch then 
						response.redirect("register.asp?registerr=passwordnotmatch")
					end if
				CustomerID =  objCustomer.Register(Cstr(CustomerName),CStr(Address),CStr(Telephone),cstr(Email),cstr(Gender),cstr(Password),"general")
				if (CustomerID = -1) or err.number <> 0 then
					error = true
					Response.Write  "<BR><font color=#ff9900><B>" & err.Description & "</B></font><BR>"
					Response.Write  "<A href=index.asp >back</a>"
					err.Clear
				else 
					Response.Cookies("CustomerID") = CustomerID
					Response.Cookies("CustomerID").Expires = date+1
				end if 'customerID
		end if
	
	
	end if 'cmd 

	if not error then 
		CustomerID = Request.Cookies("CustomerID")		
		if CustomerID= "" then 
			Response.Redirect("LoginError.asp") 
		else 
	
		set ObjMyProfiles = Server.CreateObject("DALDB.CCustomerFactory")
		ObjMyProfiles.Serialize = objCustomer.GetCustomer(Clng(CustomerID)).Serializer		
		
		if cmd = "Edit" then
					if passwordnotmatch then 
						response.redirect("editprofile.asp?registerr=passwordnotmatch")
					end if

			objMyprofiles.Item(1).CustomerName = CustomerName
			objMyprofiles.Item(1).Address = Address
			objMyprofiles.Item(1).Gender = Gender
			objMyprofiles.Item(1).Telephone = Telephone
			objMyprofiles.Item(1).Password = Password
			dim util			
			set util = server.CreateObject("ComplusUtil.IUtility")
				
			rs = objCustomer.EditCustomer(util.ConvertToOBj(objMyprofiles.Item(1)))
			if not rs then 
				Response.Write err.description
			end if
			
		end if
		
		
%>
      <div align="center">
        <p><font color="#ff9900" size="+1"><b><font face="MS Sans Serif">�����Ţͧ�س</font></b></font><font color="#ff9900" size="+1"><b><font face="MS Sans Serif"><br>
          </font></b></font> </p>
        </div>
      <table width="90%" border="0" cellspacing="2" cellpadding="0" align="center" 
      id=TABLE1 height="131">
        <tr> 
                <td width="29%" height="10"> 
                  <div align="right"><font color="#0d549b" size="-1">Your Name : &nbsp;&nbsp;</font></div>
          </td>
                <td width="71%" height="10"> 
                  <div align="left"><font size="-1"><%= ObjMyProfiles.Item(1).CustomerName %></font></div>
          </td>
        </tr>
        <tr> 
                <td width="29%" height="9"> 
                  <div align="right"><font color="#0d549b" size="-1">Address : &nbsp;&nbsp; </font></div>
          </td>
                <td width="71%" height="9"><font size="-1"><%= ObjMyProfiles.Item(1).Address %> 
                  </font></td>
        </tr>
        <tr> 
                <td width="29%" height="17"> 
                  <div align="right"><font color="#0d549b" size="-1">Telephone No.  : &nbsp;&nbsp; </font><font size="-1"> 
              </font></div>
          </td>
                <td width="71%" height="17"> 
                  <div align="left"><font size="-1"><%= ObjMyProfiles.Item(1).Telephone %></font></div>
          </td>
        </tr>
        <tr> 
                <td width="29%" height="9"> 
                  <div align="right"><font size="-1"> </font><font color="#0d549b" size="-1">Gender  : &nbsp;&nbsp; </font></div>
          </td>
                <td width="71%" height="9"> <font size="-1"> <%= ObjMyProfiles.Item(1).Gender %></font></td>
        </tr>
        <tr> 
                <td width="29%" height="14"> 
                  <div align="right"><font color="#0d549b" size="-1">E-mail  : &nbsp;&nbsp; </font><font size="-1"> 
              </font></div>
          </td>
                <td width="71%" height="14"><font size="-1"><%= ObjMyProfiles.Item(1).Email %></font></td>
        </tr>
        <tr> 
                <td width="29%" height="7"> 
                  <div align="right"><font color="#0d549b" size="-1">Password  : &nbsp;&nbsp; </font><font size="-1"></font><font size="-1"> 
              </font></div>
          </td>
                <td width="71%" height="7"><font size="-1"><%= ObjMyProfiles.Item(1).Password %></font></td>
        </tr>
        <tr> 
          <td colspan="2"> <BR>
            <div align="center"><a href="index.asp"><font size="-1">Home</font></a> &nbsp;&nbsp;&nbsp;&nbsp;
              <font size="-1"><a href="EditProfile.asp">Edit Profile</a></font></div>
          </td>
        </tr>
      </table>
<% 
		end if ' no customerID

	end if   ' error 
%>
	  
	  <!-- #EndEditable -->
				</td>
			</tr>
		</table>				
	</td>
  </tr>
 <!-- <tr>
    <td width="148" bgcolor="#D7DCE8" height="28" valign="top">&nbsp; </td>
    <td width="631" height="28" valign="top">&nbsp;</td>
  </tr>-->
</table>
</body>
<!-- #EndTemplate --></html>
