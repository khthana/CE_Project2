<html><!-- #BeginTemplate "/Templates/Hotel_template_home.dwt" -->
<head>
<!-- #BeginEditable "doctitle" --> 
<title>Untitled Page</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
 <link rel="stylesheet" type="text/css" href="Templates/homestyle.css">

  <link rel="stylesheet" type="text/css" href="Templates/style.css">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" topMargin= 0>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}


//-->
</script>
<table width="98%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="52" colspan="2" > <!--
      <p><b><font face="Arial, Helvetica, sans-serif" size="+2" color="6B8EC6"><font color="#FFFFFF">OLALA 
        HOTEL</font> </font></b></p>-->
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td width="5%">&nbsp;</td>
			<td align="center" valign="bottom"> 
				<img src="images/hd_hotel_pic1.gif" height="60"> </td>
			<td align="center" valign="top"> 
				<img src="images/hd_hotel_pic.gif" height="60"> </td>
			<td align="center" valign="middle"> 
				<img src="images/hd_hotel_pic2.gif"  height="60"> </td>

			<td align="right"> <img src="images/hd_olalahotel.gif"> </td>
		</tr>
		</table>

    </td>
  </tr>
 <!-- <tr> 
    <td bgcolor="#006699" width="36%">&nbsp;&nbsp;&nbsp;
		<a href="../index.asp" class=z1>Main</a>|
		<a href="#" class=z1> Search </a>|
		<a href="../basket.asp" class=z1>View Basket</a>| 
		<a href="../basket.asp" class=z1>Checkout  </a>|</td>
    <td bgcolor="#006699" width="64%"> 
      <div align="right"><font color="#FFFFFF" size="-1">Disclimer | Policies 
        | Feedback | FAQ | Help | About | Coutact Us</font></div>
    </td>
  </tr>-->
  <tr>
  <td>
  <table width="99%" border="0" cellspacing="1" cellpadding="0" align="center" bgcolor="black">
  <tr bgcolor="#FF6666"> 
    <td bgcolor="#FFCC99" width="17%" align="center" class="head5">
      <a href="index.asp" class="link1"><b>Main</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp"  class="link1"><b>Search</b></a>
    </td>

    <td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="basket.asp" class="link1"><b>View Basket</b></a>
    </td>

	<td bgcolor="#FFCC99" width="17%" align="center" class="head6">
      <a href="index.asp" class="link1"><b>About Us</b></a>
    </td>

  </tr>
	<tr>
          <td align="right" colspan="4" bgcolor="#76CCFF" height=4><img src="images/1x1b.gif" border="0" /></td>
    </tr>

</table>
</td>
</tr>

</table>


<table width="99%" border="0" cellspacing="0" cellpadding="5" align="center" height="600">
  <tr> 
    <td width="17%" bgcolor="#D7DCE8" height="330" valign="top" align="center"> 
      <%
	on error resume next
			cmd = Request.Form("cmd")
			Email = Request.Form("Email")
			Password = Request.Form("Password")
			'frompage = request("frompage")		
			'pagename=request.servervariables("script_name")
	
			if cmd = "login" then
			set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
			CustomerID = objCustomer.Login(Cstr(Email),Cstr(Password))
					if err.number = 0 and CustomerID > 0 then
						Response.Cookies("CustomerID") = CustomerID
						Response.Cookies("CustomerID").expires = date+1
'						Response.Cookies("BasketID").expires = now
						
							
							if request.servervariables("script_name") = "/complushotel/www/loginerror.asp" then
								response.redirect("myreservation.asp")
							end if

					else
							select case err.number 
								case vbObjectError+1 err_txt = "notfound"
								case vbObjectError+5 err_txt = "wrongpassword"
							end select
						err_txt = "loginerror.asp?err="  & err_txt 
						response.redirect(err_txt)
					end if  
			end if		    	
		'	cmd  = request.querystring("cmd")
			if cmd="logout" then
						Response.Cookies("BasketID").expires = now
						Response.Cookies("CustomerID").expires = now
						Response.Cookies("BasketID") =""
						Response.Cookies("CustomerID") = ""

			end if
	
			
			CustomerID = Request.Cookies("CustomerID")
			'response.write CustomerID
			if CustomerID = "" then
			'' render login box
%>
      <form name="form1" method="post" action="">
        <table width="130" border="0" cellspacing="0" cellpadding="0" align="center" >
          <tr align="center" > 
            <td  width="130" height=25 >
				<div align="center"><img src="images/login.gif" ></div>
            </td>
          </tr>
          <tr> 
            <td width="130" class="head7"><br><b>   E-mail address </b></td>
          </tr>
          <tr> 
            <td height="15" width="130"> <font size="-1"> 
              <input type="text" name="Email" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td width="130" class="head7" height=20 valign="bottom"><b>Password</b></td>
          </tr>
          <tr> 
            <td width="130"> <font size="-1"> 
              <input type="password" name="Password" class="textbox">
              </font></td>
          </tr>
          <tr> 
            <td height="10" width="130"> 
              <div align="center"><font size="-1"> 
			   
				<input type="hidden" name="cmd" value="login">
			  	<input type="hidden" name="country" value="<%=Request.Form.Item("Country")%>">
			  	<input type="hidden" name="state" value="<%=Request.Form.Item("State")%>">
			  	<input type="hidden" name="city" value="<%=Request.Form.Item("City")%>">
			  	<input type="hidden" name="star" value="<%=Request.Form.Item("star")%>">
			  	<input type="hidden" name="HotelName" value="<%=Request.Form.Item("HotelName")%>">
			  	<input type="hidden" name="RoomModelName" value="<%=Request.Form.Item("RoomModelName")%>">
			  	<input type="hidden" name="PriceRate" value="<%=Request.Form.Item("PriceRate")%>">
			  	<input type="hidden" name="CheckInDate" value="<%=Request.Form.Item("CheckInDate")%>">
			  	<input type="hidden" name="CheckOutDate" value="<%=Request.Form.Item("CheckOutDate")%>">
			  	<input type="hidden" name="AmountOfRoom" value="<%=Request.Form.Item("AmountOfRoom")%>">
			<br><br>
							<input type="submit" name="Submit" value="Login" class="smbutton">
                <input type="reset" name="Submit2" value="Reset" class="smbutton">
                <br><br>
                <a href="lostpassword.asp"> ������ʼ�ҹ </a><br>
                <a href="register.asp"> ��Ѥ���Ҫԡ���� </a></font></div>
            </td>
          </tr>
        </table>
      </form>
<%
			else
			 'show customer name and render customer menu 
				set Customers = Server.CreateObject("DALDB.CCustomerFactory")
				set ObjCustomer = Server.CreateObject("CustomerService.ICustomer")
				customers.Serialize  = objCustomer.GetCustomer(clng(CustomerID)).Serializer
				CustomerName = Customers.item(1).CustomerName
%>

      <table width="130" border="0" cellspacing="1" cellpadding="0" align="center" dwcopytype="CopyTableRow">
        <tr > 
          <td bgcolor="#3B8EC6" height="38" align=center><font size="-1" color="#FFFFFF"><b>���ʴդ�Ѻ 
            <br>
            �س <%=CustomerName%> </b></font></td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26"> 
            <div align="center"><font size="-1"><a href="MyProfile.asp" class="z2"> ��䢢�����</a></font></div> 
          </td>
        </tr>
        <tr align=center> 
          <td bgcolor="#6B8EC6" height="26" > 
            <div align="center"><font size="-1"><a href="MyReservation.asp" class="z2"> ��¡�èͧ</a></font></div>
          </td>
        </tr>
        <tr> 
          <td height="15" bgcolor="#6B8EC6" width="116"><br>
<div align="center">
              <form name="formx" method="post" action="index.asp">
                <input type="hidden" name="cmd" value="logout">
                <!--<input type="image" name="Submit" value="logout" src="../images/viewonmap.gif" width="70" height="13">-->
				<input type="submit" name="Submit" value="logout" class="button">
				
			  </form>
              </div>
          </td>
        </tr>
      </table>
<%
			end if ' render login box OR menu
%>
    </td>
    <td width="625" height="249" valign="top"> 
		<table width="95%" align="center">
			<tr>
				<td>
					<!-- #BeginEditable "Center_Content" --> 
      <p align="left"><b><font size="+2" color="#6B8EC6">HOTEL SEARCH</font></b></p>
      <form name="form2" method="post" action="SearchResulttmp.asp">
        <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td colspan="2"><font size="-1" color="#6B8EC6">Country</font></td>
            <td width="20%"><font size="-1">Star</font></td>
            <td width="41%"><font size="-1" color="#6B8EC6">Check-in Date</font></td>
          </tr>
          <tr> 
            <td height="10" colspan="2"> <font size="-1"> 
              <select name="Country">
                <option value="Canada">Canada</option>
                <option value="England">England</option>
                <option value="U.S.A.">U.S.A.</option>
                <option value="Thailand" selected>Thailand</option>
                <option value="China">China</option>
                <option value="Singapore">Singapore</option>
                <option>Hongkong</option>
                <option>Australia</option>
                <option>Malaysia</option>
                <option>Indonesia</option>
              </select>
              </font></td>
            <td height="10" width="20%"> <font size="-1"> 
              <select name="Star">
                <option value="1-5">any</option>
                <option value="1-2"><font size="-1">1 - 2 </font></option>
                <option value="2-3"><font size="-1">2 - 3 </font></option>
                <option value="3-4"><font size="-1">3 - 4</font></option>
                <option value="4-5"><font size="-1">4 - 5</font></option>
              </select>
              </font></td>
            <td height="10" width="41%"><font size="-1"> 
              <input type="text" name="CheckInDate" maxlength="10" size="13" value="1/10/2544">
              <select name="select2">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
                <option>13</option>
                <option>14</option>
                <option>15</option>
                <option>16</option>
                <option>17</option>
                <option>18</option>
                <option>19</option>
                <option>20</option>
                <option>21</option>
                <option>22</option>
                <option>23</option>
                <option>24</option>
                <option>25</option>
                <option>26</option>
                <option>27</option>
                <option>28</option>
                <option>29</option>
                <option>30</option>
                <option>31</option>
              </select>
              <select name="select3">
                <option selected>Jan</option>
                <option>Feb</option>
                <option>Mar</option>
                <option>Apr</option>
                <option>May</option>
                <option>Jun</option>
                <option>Jul</option>
                <option>Aug</option>
                <option>Sep</option>
                <option>Oct</option>
                <option>Nov</option>
                <option>Dec</option>
              </select>
              <select name="select4">
                <option selected>2001</option>
                <option>2002</option>
                <option>2003</option>
                <option>2004</option>
              </select>
              </font></td>
          </tr>
          <tr> 
            <td height="18" width="21%"><font size="-1" color="#6B8EC6">State</font></td>
            <td height="18" width="18%">City</td>
            <td height="18" width="20%">RoomType</td>
            <td height="18" width="41%">Check-Out Date</td>
          </tr>
          <tr> 
            <td width="21%"> <font size="-1"> 
              <select name="State">
                <option value="any" selected>any</option>
                <option>California</option>
                <option value="Bangkok"><font size="-1">Bangkok</font></option>
                <option><font size="-1">Chaingmai</font></option>
                <option><font size="-1">Chaingrai</font></option>
                <option><font size="-1">Khonkan</font></option>
                <option><font size="-1">Ubonratchatanee</font></option>
                <option><font size="-1">Chonburi</font></option>
                <option><font size="-1">Trad</font></option>
                <option><font size="-1">Kanjanaburi</font></option>
                <option><font size="-1">Petchaburi</font></option>
                <option><font size="-1">Yala</font></option>
                <option><font size="-1">Narathivas</font></option>
                <option>Ohio</option>
              </select>
              </font></td>
            <td width="18%"><font size="-1"> 
              <select name="City">
                <option selected>Any</option>
                <option>Bangkok</option>
                <option>Denver</option>
                <option>Atlanta</option>
                <option value="-">-</option>
              </select>
              </font></td>
            <td width="20%"> <font size="-1"> 
              <select name="RoomModelName">
                <option selected><font size="-1">any</font></option>
                <option value="Standard"><font size="-1">Standard</font></option>
                <option value="Deluxe"><font size="-1">Deluxe</font></option>
                <option value="Premium"><font size="-1">Premium</font></option>
                <option value="standard_1">Standard_1</option>
              </select>
              </font></td>
            <td width="41%"><font size="-1"> 
              <input type="text" name="CheckOutDate" maxlength="10" size="13" value="1/10/2544">
              <select name="select10">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
                <option>13</option>
                <option>14</option>
                <option>15</option>
                <option>16</option>
                <option>17</option>
                <option>18</option>
                <option>19</option>
                <option>20</option>
                <option>21</option>
                <option>22</option>
                <option>23</option>
                <option>24</option>
                <option>25</option>
                <option>26</option>
                <option>27</option>
                <option>28</option>
                <option>29</option>
                <option>30</option>
                <option>31</option>
              </select>
              <select name="select10">
                <option selected>Jan</option>
                <option>Feb</option>
                <option>Mar</option>
                <option>Apr</option>
                <option>May</option>
                <option>Jun</option>
                <option>Jul</option>
                <option>Aug</option>
                <option>Sep</option>
                <option>Oct</option>
                <option>Nov</option>
                <option>Dec</option>
              </select>
              <select name="select10">
                <option selected>2001</option>
                <option>2002</option>
                <option>2003</option>
                <option>2004</option>
              </select>
              </font></td>
          </tr>
          <tr> 
            <td colspan="2">HotelName</td>
            <td width="20%"><font size="-1" color="#6B8EC6">Prices Rate(Bath) 
              </font></td>
            <td width="41%">Amount Of Rooms</td>
          </tr>
          <tr> 
            <td colspan="2"> <font size="-1"> 
              <input type="text" name="HotelName">
              </font></td>
            <td width="20%"> <font size="-1"> 
              <select name="PriceRate">
                <option value="0-1000" selected><font size="-1" color="#6B8EC6">below 
                1,000</font></option>
                <option value="1001-2000"><font size="-1" color="#6B8EC6">1,001-2,000</font></option>
                <option value="2001-3000"><font size="-1" color="#6B8EC6">2,001-3,000</font></option>
                <option value="3001-4000"><font size="-1" color="#6B8EC6">3,001-4,000</font></option>
                <option value="4001-5000"><font size="-1" color="#6B8EC6">4,001-5,000</font></option>
                <option value="5001-1000000"><font size="-1" color="#6B8EC6">5,000 
                up</font></option>
                <option value="0-1000000">any</option>
              </select>
              </font></td>
            <td width="41%"><font size="-1"> 
              <input type="text" name="AmountOfRoom">
              </font><font size="-1" color="#6B8EC6"> </font></td>
          </tr>
          <tr> 
            <td colspan="4"> 
              <div align="center"> 
                <input type="submit" name="Search" value="Submit">
                <input type="reset" name="Submit4" value="Reset">
              </div>
            </td>
          </tr>
        </table>
      </form><!-- #EndEditable -->
				</td>
			</tr>
		</table>				
	</td>
  </tr>
 <!-- <tr>
    <td width="148" bgcolor="#D7DCE8" height="28" valign="top">&nbsp; </td>
    <td width="631" height="28" valign="top">&nbsp;</td>
  </tr>-->
</table>
</body>
<!-- #EndTemplate --></html>
