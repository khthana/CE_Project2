<%@ Language=VBScript %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>
<BODY>

<P>&nbsp;</P>

<%
set objBooking = server.CreateObject("BookingService.IBookManager")
set objHotels = server.CreateObject("DALDB.CReserveHotelDetailFactory")
set objHotelDetail = server.CreateObject("DALDB.CReserveHotelDetail")
set util = server.CreateObject("ComplusUtil.Utility")
Set objHotelDetail = objHotels.AddNew
With objHotelDetail
        .HotelID = 1
        .RoomModelID = 1
        .AmountOfRoom = 7
        .BookCheckIn = "8/6/2544"
        .BookCheckOut = "8/6/2544"
End With
dim id 
id = 55
id = objBooking.Reserve(cint(55), util.ConverttoObj(objHotels))
%>
bookingID is
<%=  id %>
<br>
</BODY>
</HTML>
