<html>
<head>
<title> Lost Password </title>

<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="homestyle.css" >

<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>


<body bgcolor="#FFFFFF" >

<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
function openViewRoomModelWindow(RoomModelid) {
  popupInformWin = window.open('viewRoomModel.asp?RoomModelID='+RoomModelid,'remote2','scrollbars,resizable,width=360,height=270');
}

//-->
</script>

<Table cellspacing=0 cellpadding=0 border=0 width="80%" align=center> 
<tr>
    <td width="631" height="249" valign="top"> <!-- #BeginEditable "Center_Content" -->
      <%
	  
		Email = Request.Form("Email")
		if Email <> "" then
		%>
		
		<br><div class="head_2" align=center>��ӡ�������ʼ�ҹ��ѧ E-Mail �ͧ�س���º��������</div><br><br>
	<%	else %>
	  
	  
	  
	  <form name="form2" method="post" action="lostpassword.asp">
        <div class=head1> ��س��к� E-mail Address �ͧ�س </div>
        <table width="95%" border="0" align="center" cellpadding=30>
          <tr> 
            <td height="7" class=head4 align=right><b>E-mail Address : </b></td>
            <td align=left> <input type="text" name="email" size="30" class="textbox">       </td>
          </tr>
          <tr> 
            <td align=right width="50%"> 
                <input type="submit" name="Submit" value="Submit" class="button">
			</td>
			<td align=left width="50%"> 
                <input type="reset" name="Submit3" value="Reset" class="button">
            </td>
          </tr>
        </table>
        
    <% end if %>
        <p class=head5><a href="index.asp" target="_parent">back</a></p>
      </form>

	  </td>
  </tr>
</table>
</body>
</html>
