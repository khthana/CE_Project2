
<HTML>
<HEAD>
<TITLE> OLALA TOUR </TITLE>
</HEAD>
<BODY>
<script language="JavaScript">
<!--
function openViewHotelWindow(hotelid) {
  popupInformWin = window.open('viewhotel.asp?HotelID='+hotelid,'remote','scrollbars,resizable,width=360,height=270');
}
-->
</script>
<%
'----------------------------------------------
	'on error resume next
	
	cmd = Request.Form("TourBasket")
	BasketID = Request.Form("BasketID")
	set TourBasket = server.CreateObject("TourBookingService.IBasket")
	
	if cmd = "�ӹǳ�Ҥ�����" then
		ItemArr = Request.Form("PackageDelItem")
			PackageItemArr = split(ItemArr,", ")
		ItemArr = Request.Form("HotelDelItem")
			HotelItemArr = split(ItemArr,", ")
		ItemArr = Request.Form("BusDelItem")
			BusItemArr = split(ItemArr,", ")
		ItemArr = Request.Form("AirlineDelItem")
			AirItemArr = split(ItemArr,", ")

'		Response.Write "delair" & itemarr

		for i = 0 to ubound(PackageItemArr)
			TourBasket.RemovePackageBasketItem cint(PackageItemArr(i))
			'Response.Write ItemArr(i) & " " & boo
		next
		
		for i = 0 to ubound(HotelItemArr)
			TourBasket.RemoveHotelBasketItem cint(HotelItemArr(i))
			'Response.Write ItemArr(i) & " " & boo
		next
		for i = 0 to ubound(BusItemArr)
			TourBasket.RemoveBusBasketItem cint(BusItemArr(i))
			'Response.Write ItemArr(i) & " " & boo
		next
		for i = 0 to ubound(AirItemArr)
			TourBasket.RemoveAirlineBasketItem cint(AirItemArr(i))
			'Response.Write ItemArr(i) & " " & boo
		next
		
		Response.Redirect("Basket.asp")

	
	elseif cmd = "�ͧ" then
		TourCustomerID = Request.Cookies("TourCustomerID")
		'Response.Write "CusID=" & TourCustomerID
		if TourCustomerID = "" then 
			Response.Write "NOTLogin"
			Response.Redirect("loginerror.asp")
		else	
			'set objBusBookInfos '=Server.CreateObject("DALDB.CViewBusBookInfoFactory")
			'set objAirlineBookInfos '=Server.CreateObject("DALDB.CViewAirlineBookInfoFactory")
						
			set colBasket = TourBasket.ViewBasket(Cint(BasketID))
	set TourBasket = nothing
			set objReserveHotelDetails = colBasket.item(1) 
			set objReservePackageDetails = colBasket.item(2) 
			set objBusBookInfos = colBasket.item(3) 
			set objAirlineBookInfos = colBasket.item(4) 
	set colBasket = nothing
				'set objReserveBusDetails = colBasket.item(3) 
				'set objReserveAirlineDetails = colBasket.item(4) 

			'Response.Write "ClassID=" & objBusBookInfos.Item(1).ClassID
			'Response.Write 
			if not objBusBookInfos is nothing then
			set objReserveBusDetails = Server.CreateObject("DALDB.CReserveBusDetailFactory")
			for i = 1 to objBusBookInfos.Count
				set objReserveBusDetail =  objReserveBusDetails.AddNew
								
				'objReserveBusDetails.Item(i).ClassID = objBusBookInfos.Item(i).ClassID
				set objReserveBusDetails.Item(i).colCEJBTraveller = objBusBookInfos.Item(i).colCEJBTraveller
				objReserveBusDetails.Item(i).DepartDate = objBusBookInfos.Item(i).DepartDate
				objReserveBusDetails.Item(i).desIdx = objBusBookInfos.Item(i).desIdx
				objReserveBusDetails.Item(i).routeID = objBusBookInfos.Item(i).routeID
				objReserveBusDetails.Item(i).Smoking = objBusBookInfos.Item(i).Smoking
				objReserveBusDetails.Item(i).srcIdx = objBusBookInfos.Item(i).srcIdx
				objReserveBusDetails.Item(i).TotalSeat = objBusBookInfos.Item(i).TotalSeat
				objReserveBusDetails.Item(i).Window = objBusBookInfos.Item(i).Window
			next
			else
				set objReserveBusDetails = nothing
			end if
	set	objBusBookInfos = nothing
			
			if not objAirlineBookInfos is nothing then
			set objReserveAirlineDetails = Server.CreateObject("DALDB.CReserveAirlineDetailFactory")
			for i = 1 to objAirlineBookInfos.Count
				set objReserveAirlineDetail =  objReserveAirlineDetails.AddNew
				objReserveAirlineDetails.Item(i).ClassID = objAirlineBookInfos.Item(i).ClassID
				set objReserveAirlineDetails.Item(i).colCEJBTraveller = objAirlineBookInfos.Item(i).colCEJBTraveller
				objReserveAirlineDetails.Item(i).DepartDate = objAirlineBookInfos.Item(i).DepartDate
				objReserveAirlineDetails.Item(i).desIdx = objAirlineBookInfos.Item(i).desIdx
				objReserveAirlineDetails.Item(i).FlightID = objAirlineBookInfos.Item(i).FlightID
				objReserveAirlineDetails.Item(i).Smoking = objAirlineBookInfos.Item(i).Smoking
				objReserveAirlineDetails.Item(i).srcIdx = objAirlineBookInfos.Item(i).srcIdx
				objReserveAirlineDetails.Item(i).TotalSeat = objAirlineBookInfos.Item(i).TotalSeat
				objReserveAirlineDetails.Item(i).Window = objAirlineBookInfos.Item(i).Window
			next
			else
				set objReserveAirlineDetails = nothing
			end if
	set objAirlineBookInfos = nothing
			
			set TourBookingService = Server.CreateObject("TourBookingService.IBookManager")
			set util = Server.CreateObject("ComplusUtil.IUtility")
			err.number = 0
			
			rs = TourBookingService.Reserve(Clng(TourCustomerID) ,util.ConvertToOBj(objReserveHotelDetails),util.ConvertToOBj(objReserveBusDetails),util.ConvertToOBj(objReserveAirlineDetails),util.ConvertToOBj(objReservePackageDetails))
			'----------------------*********************** keng

			'----------------------**************************keng
				set TourBookingService = nothing
				if err.number = 0 then
					response.cookies("BasketID").expires = now
					Response.Cookies("BasketID") = ""
'Response.Write "<a href=ReserveComplete.asp?BookingID=" & rs & ">dd</a>"  
					response.Redirect("ReserveComplete.asp?BookingID=" & rs)
				else 
					Response.Write err.Description
				end if
		end if
	end if


%>

</BODY>
</HTML>
