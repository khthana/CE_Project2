<HTML>
<HEAD>
<TITLE>Edit Customer Form</TITLE>
	    <link rel="stylesheet" type="text/css" href="homestyle.css" >
	    <script language="JavaScript" SRC="js_code.js"></Script>
</head>

<Script language="JavaScript">
	function validate(){
		window.alert("Registration is Complete");
	}

</Script>

<BODY BGCOLOR="#FFFFFF">


<TABLE width="90%" border=0 align=center>
<TBODY>
	<TR>
			
      <TH align=middle bgColor=#8080b0 class="head2"><b>Personal Data</b></TH>
	</TR>
	<tr><td colspan=2>&nbsp; </td></tr>
	<TR>
		<TD>
<%
	on error resume next
	dim TourCustomerService
	dim objCustomerFactory
	dim objCustomer
		set TourCustomerService = server.CreateObject("TourCustomerService.ICustomer")
		set objCustomerFactory = server.CreateObject("DALDB.CCustomerFactory")
		'Response.Write Request.Cookies("TourCustomerID")
		CustomerID = Request.Cookies("TourCustomerID")
		'Response.Write "CustomerID = " & CustomerID & "<BR>"
		set objCustomer = TourCustomerService.GetCustomer(cint(CustomerID))
		objCustomerFactory.Serialize = objCustomer.Serializer
%>				
      
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <TH align=left bgColor=#e6e6fa class="head3" colspan=2>&nbsp;&nbsp;&nbsp;��������ǹ��� 
            </TH>
          </tr>
          <tr> 
            <td width="28%" class="head4"> 
              <div align="right" class="text">���� - ���ʡ�� :&nbsp;&nbsp;</div>
            </td>
            <td width="72%" class="text"> 
              <LABEL><%=objCustomerFactory.Item(1).CustomerName%></LABEL>
              </td>
          </tr>
          <tr> 
            <td width="28%" class="head4"> 
              <div align="right" class="text"> �� :&nbsp;&nbsp;</div>
            </td>
            <td class="text" width="72%"> 
<%
			if objCustomerFactory.Item(1).Gender = "M" then
%>              <input type="radio" name="Gender" value="M"  checked> ���
<%            else
%>              <input type="radio" name="Gender" value="F" checked> ˭ԧ
<%            end if
%>    
              </td>
          </tr>
          <tr> 
            <td width="28%"> 
              <div align="right" class="text">�������:&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif" 
                        size=2>
              <LABEL><%=objCustomerFactory.Item(1).Address%></LABEL>
              </font></td>
          </tr>
		  <tr> 
            <td width="28%"> 
              <div align="right" class="text">���Ѿ�� :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"    size=2> 
              <LABEL><%=objCustomerFactory.Item(1).Telephone%><LABEL>
              </font></td>
          </tr>
		  
		  <tr> 
            <td width="28%"> 
              <div align="right" class="text">������ :&nbsp;&nbsp;</div>
            </td>
            <td width="72%"><font face="MS Sans Serif"    size=2> 
              <LABEL><%=objCustomerFactory.Item(1).Email%><LABEL>
              </font></td>
          </tr>
        
		  
          <tr> 
            <td colspan=2>&nbsp;</td>
          </tr>
        </table>
		</TR>
	</TBODY>
	</TABLE>

</BODY>
</HTML>
