gacutil /i busproxy.dll
regasm busproxy.dll /tlb:busproxy.tlb