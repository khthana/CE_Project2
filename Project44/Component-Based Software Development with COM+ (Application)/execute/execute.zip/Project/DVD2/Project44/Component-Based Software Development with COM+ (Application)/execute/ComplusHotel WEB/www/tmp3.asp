<%@ Language=VBScript %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>

<BODY>

<P>&nbsp;</P>
     <%
     set objBookings = server.CreateObject("DALDB.CHotelBookingFactory")
set objBookViewer = server.CreateObject("BookingService.IBookViewer")
set objHotelViewer = server.CreateObject("HotelService.IHotelViewer")


'set util = server.CreateObject("ComplusUtil.Utility")
'Set objHotelDetail = objHotels.AddNew
dim CustomerID
dim HotelBookingID
dim i,j
	
	CustomerID = Request.QueryString("ID")
    ' get hotel booking from customerID
    ObjBookings.Serialize = ObjBookViewer.GetHotelBooking(clng(CustomerID)).Serialize
    For i = 1 To ObjBookings.Count
        HotelBookingID = ObjBookings.Item(i).HotelBookingID
        'get hotel bookingdetail from hotelbookingID
		set objBookingDetails = server.CreateObject("DALDB.CHotelBookingDetailFactory")
        ObjBookingDetails.Serialize = ObjBookViewer.GetHotelBookingDetail(CLng(HotelBookingID)).Serialize
        For j = 1 To ObjBookingDetails.Count
			
						
            
            Response.Write (j & " " & ObjBookingDetails.Item(j).BookCheckIn & "-" & ObjBookingDetails.Item(j).BookCheckOut & " "  & objBookingDetails.Item(j).HotelName)
            Response.Write(" " & objBookingDetails.Item(j).RoomModelName)
            Response.Write(" " & objBookingDetails.Item(j).RoomNo)
            Response.Write("<BR>")
            
        Next
    
Next
 	
%>      <div align="center"><b><font size="+1" color="#FF9933" face="MS Sans Serif">�����š�èͧ�ͧ�س</font></b></div>
      <br>
      <form name="form2" method="post" action="">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td width="5%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">ź</font></b></font></div>
            </td>
            <td width="8%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��¡�� 
                </font></b></font></div>
            </td>
            <td width="21%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ѹ�ѡ</font></b></font></div>
            </td>
            <td width="32%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ç���</font></b></font></div>
            </td>
            <td width="13%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="8%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�ӹǹ 
                ��ͧ�ѡ</font></b></font></div>
            </td>
            <td width="13%" height="20" bgcolor="#0D549B"> 
              <div align="center"><font size="-1"><b><font color="#FFFFFF">�Ҥ���� 
                (�ҷ)</font></b></font></div>
            </td>
          </tr>
          <tr> 
            <td width="5%"> <font size="-1"> 
              <input type="checkbox" name="checkbox" value="checkbox">
              </font></td>
            <td width="8%"> 
              <div align="center"><font size="-1">1</font></div>
            </td>
            <td width="21%"><font size="-1">20/12/44 - 21/12/44</font></td>
            <td width="32%"><font size="-1">�ç��������</font></td>
            <td width="13%"><font size="-1">Standard</font></td>
            <td width="8%"> 
              <div align="center"><font size="-1">2</font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1">5,000 </font></div>
            </td>
          </tr>
          <tr> 
            <td width="5%" bgcolor="#D7DCE8"> <font size="-1"> 
              <input type="checkbox" name="checkbox2" value="checkbox">
              </font></td>
            <td width="8%" bgcolor="#D7DCE8"> 
              <div align="center"><font size="-1">2</font></div>
            </td>
            <td width="21%" bgcolor="#D7DCE8"><font size="-1">20/12/44 - 21/12/44</font></td>
            <td width="32%" bgcolor="#D7DCE8"><font size="-1">�ç������Ե�ҹ�</font></td>
            <td width="13%" bgcolor="#D7DCE8"><font size="-1">Standard</font></td>
            <td width="8%" bgcolor="#D7DCE8"> 
              <div align="center"><font size="-1">2</font></div>
            </td>
            <td width="13%" bgcolor="#D7DCE8"> 
              <div align="right"><font size="-1">10,000</font></div>
            </td>
          </tr>
          <tr> 
            <td width="5%"> <font size="-1"> 
              <input type="checkbox" name="checkbox2" value="checkbox">
              </font></td>
            <td width="8%"> 
              <div align="center"><font size="-1">3</font></div>
            </td>
            <td width="21%"><font size="-1">20/12/44 - 21/12/44</font></td>
            <td width="32%"><font size="-1">�ç������Ե�ҹ�</font></td>
            <td width="13%"><font size="-1">Premium</font></td>
            <td width="8%"> 
              <div align="center"><font size="-1">1</font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1">10,000</font></div>
            </td>
          </tr>
          <tr> 
            <td width="5%" bgcolor="#D7DCE8"> <font size="-1"> 
              <input type="checkbox" name="checkbox2" value="checkbox">
              </font></td>
            <td width="8%" bgcolor="#D7DCE8"> 
              <div align="center"><font size="-1">4</font></div>
            </td>
            <td width="21%" bgcolor="#D7DCE8"><font size="-1">20/12/44 - 21/12/44</font></td>
            <td width="32%" bgcolor="#D7DCE8"><font size="-1">�ç������Ե�ҹ�</font></td>
            <td width="13%" bgcolor="#D7DCE8"><font size="-1">Deluxe</font></td>
            <td width="8%" bgcolor="#D7DCE8"> 
              <div align="center"><font size="-1">1</font></div>
            </td>
            <td width="13%" bgcolor="#D7DCE8"> 
              <div align="right"><font size="-1">10,000</font></div>
            </td>
          </tr>
          <tr> 
            <td colspan="6"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
            </td>
            <td width="13%"> 
              <div align="right"><font size="-1"><b><font color="#0D549B">35,000</font></b></font></div>
            </td>
          </tr>
        </table>
		<div align="right"> 
          <p> 
            <input type="submit" name="Submit4" value="�ӹǹ����">
            <input type="submit" name="Submit3" value="�����Թ">
          </p>
          </div>
      </form>
</BODY>
</HTML>
