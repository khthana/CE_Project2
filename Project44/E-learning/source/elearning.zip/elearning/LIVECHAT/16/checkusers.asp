<HTML>
<HEAD>
	<TITLE>PortaChat 1.3:  Current Users</TITLE>
</HEAD>
<!--#include file="style.asp"-->
<BODY BGCOLOR="<%=strFrameColor%>" onLoad="window.focus()">
<TABLE BORDER=0><TR><TD>
<%
' PortaChat 1.3 
' Author: Peter Brunone
' Release Date: December 12, 2000
' Contact: peterbrunone@aspalliance.com

'  This page provides a list of currently logged-on users.  Since there is no timeout feature yet, you can
'  check for "dead" users and log them out with one click.

Dim strUsers,arrUsers, strKill, strPageName
Dim i

strKill =  Request.QueryString("kill")
strUsers = Application("strUsers")
strPageName = Request.ServerVariables("SCRIPT_NAME")

If Request.QueryString("kill") <> "" Then
	strKill = "|" & strKill
	strUsers = Replace(strUsers,strKill,"")
'	strUsers = Replace(strUsers,"||","|")
	Application.Lock
	Application("strUsers") = strUsers
	Application.UnLock
End If

arrUsers = Split(strUsers,"|")

Response.Write "<B>Currently Logged In (click to flush):</B><BR><BR>"

For i=0 To UBound(arrUsers)
	If arrUsers(i) <> strKill Then
		Response.Write "<A HREF=""" & strPageName & "?kill=" & Server.URLEncode(arrUsers(i)) & """>" & arrUsers(i) & "</A><BR>" & vbCRLF
	End If
Next

Response.Write(strUsers)  ' Debugging

%>
</TD></TR></TABLE>
</BODY>
</HTML>
