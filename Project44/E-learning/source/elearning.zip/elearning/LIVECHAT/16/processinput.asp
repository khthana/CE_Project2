<%
' PortaChat 1.3 
' Author: Peter Brunone
' Release Date: December 12, 2000
' Contact: peterbrunone@aspalliance.com

Dim strChatLine,strStyle

strChatLine = "<B>" & strChatName & ":</B> " & strChatInput 

If Len(strLogin) > 0 Then
	If InStr(strUsers,App(strChatName)) < 1 Then
		strChatBody = strChatBody & "<BR><FONT COLOR=""#BB0000""><B>" & strChatName & " " & strChatInput & "</B></FONT>" & vbCRLF
		strUsers = strUsers & App(strChatName)
		Response.Cookies("ChatName") = Trim(strChatName)
		Response.Cookies("ChatName").Expires = Date + 365
	Else
		strUserConflict = "true"
	End If
ElseIf LCase(Request.Form("chatSubmit")) = "log out" Then
	If Len(Trim(strChatName)) = 0 Then strChatName = Request.Cookies("ChatName")
	strChatBody = strChatBody & "<BR><FONT COLOR=""#000000""><B>" & strChatName & " has left the room</B></FONT>" & vbCRLF
	strUsers = Replace(strUsers,App(strChatName),"")
	strLogout = "true"
Else
'	Check for commands
	If Left(strChatInput,1) = "/" Then
		Select Case True
			Case InStr(LCase(strChatInput),"clear") > 0
				strChatBody = ""
				strChatLine = "<B>" & strChatName & " wiped the screen</B>"
			Case InStr(LCase(strChatInput),"/nick") = 1
				strNewChatName = Trim(Replace(strChatInput,"/nick",""))

				If InStr(strUsers,App(strNewChatName)) < 1 Then
					If Len(Trim(strNewChatName)) > 0 Then
						strChatLine = "<B>" & strChatName & " is now known as " & strNewChatName & "</B>"
						strUsers = Replace(strUsers,App(strChatName),App(strNewChatName))
						strChatName = strNewChatName
						Response.Cookies("ChatName") = Trim(strChatName)
					Else
						strChatLine = "<B>" & strChatName & " is screwing with the application</B>"
					End If
					strNewNick = "true"
				Else
					strUserConflict = "true"
				End If
			Case InStr(LCase(strChatInput),"/me") = 1
				strChatLine = Replace(strChatInput,"/me",strChatName)
			Case (InStr(LCase(strChatInput),"/logout") = 1 Or InStr(LCase(strChatInput),"/lo") = 1)
				strChatBody = strChatBody & "<BR><FONT COLOR=""#000000""><B>" & strChatName & " has left the room</B></FONT>" & vbCRLF
				strUsers = Replace(strUsers,App(strChatName),"")
				strLogout = "true"
		End Select
	End If
'	Check for stylistic preferences
	If strFont <> "Default" And Len(strFont) <> 0 Then
		strStyle = "font-family:" & strFont & ";"
		Response.Cookies("Font") = strFont
	End If
	If strSize <> "Default" And Len(strSize) <> 0 Then
		strStyle = strStyle & "font-size:" & strSize & "pt;"
		Response.Cookies("Size") = strSize
	End If
	If strColor <> "Default" And Len(strColor) <> 0 Then
		strStyle = strStyle & "color:" & strColor & ";"
		Response.Cookies("Style") = strStyle
	End If
'	Aaand slap it all together.
	If strLogout <> "true" And strUserConflict <> "true" Then
		strChatLine = "<BR><A STYLE=""" & strStyle & """>" & strChatLine & "</A>"
		strChatBody = strChatBody & strChatLine & vbCRLF
	End If
End If

Function App(strUserName)
	App = "|" & strUserName
End Function
%>