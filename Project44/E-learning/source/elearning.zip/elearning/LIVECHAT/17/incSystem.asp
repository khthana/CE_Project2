<%
'//// Modify the following variables to configure your shoutbox /////

'//// The URL to your ShoutBox ////
shoutboxurl="http://localhost/shoutbox/xlashoutbox"


'//// Messages Refresh Rate (In seconds)  ////
refreshrate=8	

'//// Number of simultaneous messages in the box /////
maxmessages=5

'//// The Color of your ShoutBox! ////
sboxcolor="#00CCFF"

'//// The Color of your ShoutBox! Text Labels (Pick a Nick, Shout,...) ////
sboxtextcolor="#000000"

'//// Your ShoutBox! Border Color ////
sboxbordercolor="#000099"

'//// The ShoutBox! message area background ////
sboxmessagesbkg="#FFFFFF"

'//// The ShoutBox! message's text color ////
sboxmessagetextcolor="#000000"
%>