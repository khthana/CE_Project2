<!-- #include file="incSystem.asp" -->
<%
redim nomessages(maxmessages)
if not(isarray(application("shoutbox"))) then
	application.lock
		application("shoutbox")=nomessages
	application.unlock
end if

shoutbox=application("shoutbox")

sboxtext=request("sboxtext")
if sboxtext<>"" then

	'/// Trap URL's ///
	start=instr(sboxtext,"http://")
	if start=0 then start=instr(sboxtext,"www.")
	if start<>0 then 
		stripurl=right(sboxtext,len(sboxtext)-start+1)
		spaces=instr(striprurl," ")-1 	'//// Where the URL Ends
		if spaces<=0 then spaces=len(stripurl)
		theurl=left(stripurl,spaces)
		sboxtext=replace(sboxtext,theurl,"<a href=http://"&theurl&" target='_blank'>"&theurl&"</a>")
		sboxtext=replace(sboxtext,"http://http://","http://")
	end if	


	'//// Insert text ////
	for x=maxmessages-1 to 1 step -1
		shoutbox(x+1)=shoutbox(x)
	next
	shoutbox(1)="<font face=Verdana size=1><b>"&session("sboxnick")&"&gt;</b>"&sboxtext&"</font><br>"
	application.lock
		application("shoutbox")=shoutbox
	application.unlock
end if
%>
<html>
<head>
<title>ShoutBox! Messages</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="REFRESH" content="<%=refreshrate%>; URL=sboxmessages.asp">
</head>

<body bgcolor="<%=sboxmessagesbkg%>" text="<%=sboxmessagetextcolor%>">
<%
for x=1 to maxmessages
if shoutbox(x)<>"" then response.write shoutbox(x)&"<br>" else exit for
next
%>
</body>
</html>
