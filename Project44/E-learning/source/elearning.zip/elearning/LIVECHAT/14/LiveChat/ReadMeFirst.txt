-------------------------------------------
]   LiveChat v2.61 RC1 by Ken Wincel      [
]   All Rights Reserved                   [
]   http://www.happytech.net              [
-------------------------------------------

***********************************************
         RELEASE NOTES FOR 2.61 RC1 - BEGIN
***********************************************

Since there has been such a great demand for v2.61 I rushed to create this packaged ZIP.
I'm calling this release candidate 1, has it is lacking documentation. In additition, I need to remove unused files.

LiveChat is completely self-contained. Simply unzip it to its own folder and your ready to go. StartHere.asp is a sample on launching LiveChat.