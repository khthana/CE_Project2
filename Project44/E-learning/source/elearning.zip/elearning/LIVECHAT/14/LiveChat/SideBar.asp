<html>

<head><%
'*** Change the 5 to effect the refresh rate ***
%>

<meta HTTP-EQUIV="REFRESH" CONTENT="5;display.asp">
<title>Side Bar</title>
<meta name="GENERATOR" content="Microsoft FrontPage 3.0">
<meta name="Microsoft Border" content="none">
</head>
<%
'****************************************
'   Get Settings for Sidebar Skins
'****************************************
%>
<!-- #include file="sideskin.inc" -->

<body background="<%=imgSide%>" bgcolor="#FFFFBE" topmargin="0" leftmargin="0">

<table border="0" cellpadding="2" cellspacing="4" width="100%" height="100%"
style="border-left: 1px solid rgb(0,0,0)">
  <tr>
    <td width="100%" valign="top" height="100%"><p align="center"><font face="Arial"
    color="<%=colWho%>"><small><small>Who's Online <%=Application("sessCount")%></small></small></font><br>
    <font face="Arial" color="<%=colNick%>"><small><small><br>
<%=Application("slot10")%>    <br>
<%=Application("slot9")%>    <br>
<%=Application("slot8")%>    <br>
<%=Application("slot7")%>    <br>
<%=Application("slot6")%>    <br>
<%=Application("slot5")%>    <br>
<%=Application("slot4")%>    <br>
<%=Application("slot3")%>    <br>
<%=Application("slot2")%>    <br>
<%=Application("slot1")%>    <br>
    </small></small></font></td>
  </tr>
</table>
</body>
</html>
