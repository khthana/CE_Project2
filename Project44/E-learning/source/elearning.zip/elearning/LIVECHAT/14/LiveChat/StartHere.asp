<!-- Do not remove this line * Please * -->
<!-- LiveChat v2.5 by Ken Wincel @ http://www.happytech.net -->
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Live Chat Start Page</title>
</head>

<body topmargin="0" leftmargin="0">

<table border="0" cellpadding="2" cellspacing="0" width="100%">
  <tr>
    <td width="100%" bgcolor="#800000"><font color="#FFFF80" face="Arial"><small>LiveChat 2.61
    &nbsp; - Getting Started</small></font></td>
  </tr>
</table>

<p>&nbsp;</p>

<form name="frmMain" align="center">
  <div align="center"><center><table border="0" cellpadding="2" cellspacing="0" width="90%">
    <tr>
      <td width="90%"><small><font face="Arial">This page demonstrates the best way to
      open/activate LiveChat2.61, as it was designed to run in a 600x350 window. Of course you
      may change the deminsions or graphics as you see fit. For an example of how happytech.net
      uses LiveChat, visit <a href="http://www.happytech.net">www.happytech.net</a></font></small><table
      border="0" cellpadding="2" cellspacing="0" width="100%">
        <tr>
          <td width="100%">&nbsp;<div align="center"><center><p><font face="Arial"><small>Button Example</small><br>
          <input type="button" value="Press to Chat" name="btnPress"></font></p>
          </center></div><div align="center"><center><p><font face="Arial"><small><br>
          Graphic Example </small></font><br>
          <img src="back.jpg" name="imgPress" alt="Press to Chat" width="282" height="47"></td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
  </center></div>
</form>

<p align="center">&nbsp;</p>
<div align="center"><center>

<table border="0" cellpadding="2" cellspacing="0" width="90%">
  <tr>
    <td width="100%"><strong><small><font face="Arial">Other LiveChat2.61 Tools</font></small></strong><p><small><font
    face="Arial"><a href="clear.asp">clear.asp</a> - Use this link anytime you want to reset
    the ChatRoom Application variables. This is handy when users don't close the window
    properly, and the App still displays the user's nickname. Is also handy for clearing all
    messages.</font></small></p>
    <p><small><font face="Arial"><a href="snooper.asp">snooper.asp</a> - This can also be
    activated by clicking on the </font></small><img src="bullet.gif"
    alt="bullet.gif (338 bytes)" WIDTH="13" HEIGHT="13"> which shows on the login screen. It
    acts as a snooper, which tells you how many people are in the chatroom, and the last 4
    lines typed. On your site you may want to move this &amp; the clear.asp to another secured
    area. I have on my site, because I'm still developing this application.</td>
  </tr>
</table>
</center></div>

<p align="center">&nbsp;</p>
<div align="center"><center>

<table border="0" cellpadding="2" cellspacing="0" width="90%">
  <tr>
    <td width="100%"></td>
  </tr>
</table>
</center></div>

<p align="center">&nbsp;</p>

<hr align="center">

<p align="center"><small><small><font face="Arial">happytech.net - All Rights Reserved</font></small></small></p>
</body>
<script Language="VBScript">
sub btnPress_OnClick
	Window.Open "default.asp", "wdwLiveChat2", "width=600, height=350, top=0, left=0"
end sub

sub imgPress_OnClick
	Window.Open "default.asp", "wdwLiveChat2", "width=600, height=350, top=0, left=0"
end sub
</script>

</html>
