<!--#include file="AppConfig.inc"-->
<%
Dim bc
Dim MyBrow
Dim NewRoom
Dim OldRoom
Dim Chat_List
Dim Chat_Rooms
Dim i
Dim x

Session("NewRoom")="True"

Set bc = Server.CreateObject("MSWC.BrowserType")
MyBrow= bc.browser
set bc=nothing

OldRoom = Session("Room")
NewRoom = Request.QueryString("Rm")

Session("Room")=Request.QueryString("Rm")
Session("Catagory")=Request.QueryString("Cat")

If MyBrow="Netscape" Then
	Session("Room")=Replace(Session("Room"),"+"," ")
	Session("Catagory")=Replace(Session("Catagory"),"+"," ")
End If

ReDim Chat_List(Ubound(Application("Chat_List")),4)
for i = 0 to Ubound(Application("Chat_List"))
  	Chat_List (i,0) = Application("Chat_List")(i,0)
	Chat_List (i,1) = Application("Chat_List")(i,1)
	Chat_List (i,2) = Application("Chat_List")(i,2)
	If Trim(Application("Chat_List")(i,0)) = Trim(Session("User")) Then
		Chat_List (i,3) = NewRoom
		Chat_List (i,4) = Now()
	Else
		Chat_List (i,3) = Application("Chat_List")(i,3)
		Chat_List (i,4) = Application("Chat_List")(i,4)
	End If
next
Application.Lock
Application("Chat_List")=Chat_List
Application.UnLock

ReDim Chat_Rooms(Ubound(Application("Chat_Rooms")),3)
for x = 0 to Ubound(Application("Chat_Rooms"))
	Chat_Rooms(x,0) = Application("Chat_Rooms")(x,0)
	Chat_Rooms(x,1) = Application("Chat_Rooms")(x,1)
	Chat_Rooms(x,2) = Application("Chat_Rooms")(x,2)

   If Application("Chat_Rooms")(x,0) = OldRoom Then
		Chat_Rooms(x,3)= (Application("Chat_Rooms")(x,3)-1)
	ElseIf Application("Chat_Rooms")(x,0) = NewRoom Then
		Chat_Rooms(x,3)= (Application("Chat_Rooms")(x,3)+1)
	Else
		Chat_Rooms(x,3) = Application("Chat_Rooms")(x,3)
	End If
next

Application.Lock
Application("Chat_Rooms")=Chat_Rooms
Application.UnLock
Session("Room")=NewRoom
%>

<html>
<Head>
<title>Change Rooms</title>
<SCRIPT LANGUAGE="JavaScript"><!--
window.resizeTo(300,120);
setTimeout('self.close()',3000);
//--></SCRIPT>
</head>
<body>
<Center><FONT face="<%=FF%>" color="<%=PgFntClr%>">Please wait while you are sent to<br><B>! <%=Session("Room")%> !</B></font></center>
</body>
</html>




