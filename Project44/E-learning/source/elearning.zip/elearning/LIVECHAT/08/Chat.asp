<%
Dim bc
Dim MyBrow
Set bc = Server.CreateObject("MSWC.BrowserType")
Session("MyBrow")= bc.browser
%>
<HTML>
<HEAD>
<SCRIPT LANGUAGE="JavaScript">
  <!--
   function unload() { 
   var jumpToHere;
	var winOptions;
	var popUpWindow;
	
	jumpToHere = "Logoff2.asp";
	
	winOptions = "top=100,left=200,width=300,height=100,scrollbars=no";
	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
   }
//-->
</SCRIPT>
<TITLE>NVE-Chat V2.0</TITLE>
</HEAD>
<% If Session("MyBrow")<> "IE" Then %>
<FRAMESET onUnload="unload()" ROWS="1%,15%,53%,31%" Border="0" frameborder="0">
<% Else %>
<FRAMESET onUnload="unload()" ROWS="*%,12%,61%,27%"  Border="0">
<% End If %>
  <FRAME SRC="validatechat.asp" NAME="ValidateChat" SCROLLING="No" NORESIZE>
  <FRAME SRC="header.asp" NAME="Header" SCROLLING="No" NORESIZE>
  <FRAMESET COLS="85%,15%">
    <FRAME SRC="body.asp" NAME="Body">
    <FRAME SRC="user.asp" NAME="Users">
    </FRAMESET>
  <FRAME SRC="functions.asp" NAME="Functions" SCROLLING="No" >
</FRAMESET>

<NOFRAMES>
<BODY>
<P>
</BODY></NOFRAMES></HTML>

