This application is completely free to do with what you want 
but it would be appriciated if you leave the
link to http://www.nvecs.com in the chat area page.

This application was designed to work within a popup window, 
when you leave the chatroom it closes the window 

To open your chatroom in a popup window paste the code below between 
the <head> </head> tags of your webpage

<SCRIPT language="JavaScript"><!---------
function OpenChat() 
{
var popup = window.open('./Put your chat directory name here/','windowName','width=630,height=450');
if (!popup.opener) popup.opener = self;
}
//------></SCRIPT>

Then Add the link below to your page

<A HREF="javascript:OpenChat()">Chatrooms</A>

Chat Room Over view

AppConfig.inc

Lets you set 
database path (currently set to ../cgi-bin/Chatv2.mdb)
Page Font Color
Page Font Face
Logo image path (currently set to chatlogo.gif)
LogOff image Path (currently set to ../images/home.gif)
Chatroom Page Background Color
Header-Footer/form Color
Header-Footer/form Font Color
Link Colors
Your Email address for chatroom manager requests
Set Language Filter
Show Face button in chatroom (allows users to select a face for the room)
Show Guest Speaker button on the lonon form (allows users to submit a request to be notified of any guest speakers)
for this function you will need to update the GuestSpeakerReq.asp page with you email component information 


ControlPanel.asp

Monitor rooms
Remove guests from a rooms
Add/Edit Rooms
Delete Rooms

Logon help page included 
room help page included

Maintenance pages
MaintPages.zip


Basic User Functions 

Help page at logon screen 
Help page in chat room 
Set maximum number of line entries to view 
Set number of seconds chat room should refresh the screen 
Remove their personal line entries by clicking the entry link 
Change rooms 
Select a face for your room name
Remove face for your room name
 

It is recommended that you unzip the MaintPages.zip into a seperate folder from the chat room pages and set the password on the MaintConfig.inc file so that no one can access the maintenance pages of your application

after you setup your maintenance pages and set the password on the MaintConfig.inc file complete the site address below and book mark it in your browser

