<!--#include file="AppConfig.inc"-->
<%

if Len(session("RefreshRate"))=0 Then
	session("RefreshRate")=5
End if

If Len(Session(Session("Room") & "_LastModified")) = 0 Then
	Session(Session("Room") & "_LastModified") = Now()
End If

Session("User")=Session("User")

ElapesTime=DateDiff("s", Session(Session("Room") & "_LastModified"), Application(Session("Room") & "_LastModified"))

Response.write "<HTML>" & vbcrlf
Response.write "<HEAD>" & vbcrlf
Response.write "<meta HTTP-EQUIV='REFRESH' CONTENT='" & session("RefreshRate") & "'>" & vbcrlf
If Int(ElapesTime) > 0 Or Session("NewRoom")="True" Then
	Session("NewRoom")="False"
	Session(Session("Room") & "_LastModified") = Application(Session("Room") & "_LastModified") 
		
	Response.write "<Script Language=""Javascript"">{" & vbcrlf
	Response.write "parent.Body.location.href='body.asp'" & vbcrlf
	Response.write "}" & vbcrlf
	Response.write "</Script>" & vbcrlf
End If
Response.write "</HEAD>" & vbcrlf
Response.write "<BODY BGCOLOR='" & HdrClr & "' topmargin='0'>" & vbcrlf
'Response.write "<Center>" & Int(ElapesTime) & "  " & Session("NewRoom") &  "</Center>" & vbcrlf
Response.write "</BODY>" & vbcrlf
Response.write "</HTML>" & vbcrlf
%>
