<% 
Option Explicit
Response.buffer=True

Dim bc
Dim MyBrow
Dim Views
Dim RefreshRate
Dim WhisperTo
Dim WhisperOptions
Dim i
Dim rOrder

If Len(Session("rOrder")) = 0 Then
	rOrder = "Desc"
Else
	rOrder = Session("rOrder")
End If

Set bc = Server.CreateObject("MSWC.BrowserType")
MyBrow= bc.browser
Set bc=Nothing
%>
<!--#include file="AppConfig.inc"-->
<%
If Len(session("User"))=0 Then
	Response.write"<P><Center><font face='" & FF & "'>"
	Response.write "! Your chat session has expired ! Click <a href=""Default.asp"">here</a> to go to the logon screen</font></Center>" 
	Response.end
End If
%> 
<HTML>
<HEAD>
 <SCRIPT language="JavaScript">

function SelectFace() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "SelectFace.asp";
 	winOptions = "top=200, left=200, width=115, height=150,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }

function help() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "help.asp";
 	winOptions = "top=5, left=100, width=450, height=350,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }

 function RoomMaint() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   
	jumpToHere = "ManagerMaint.asp";
 	winOptions = "top=250, left=250, width=250, height=180,scrollbars=no";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }
 function PrintIt() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   
	jumpToHere = "print.asp";
 	winOptions = "top=5, left=100,height=500,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }

function ActiveRooms() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   
	jumpToHere = "ActiveRooms.asp";
 	winOptions = "top=50, left=250,height=200,width=300,scrollbars=no";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }

 function RemoveGuest() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   
	jumpToHere = "RemoveGuest.asp";
 	winOptions = "top=100, left=250,height=200,width=300,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }

 function ValEntry()
 {
 if (document.Chat.Chat.value=='')
        return false;  
    else {
        return true;  
    }
}

function Whisper(s)
{
var Item = (s.options[s.selectedIndex].value);

document.Chat.whisper.value=Item;
document.Update.submit();
} 

 </Script>
  <TITLE>Please title this page. (Page 2)</TITLE>

</HEAD>
<BODY marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" BGCOLOR="<%=HdrClr%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
<% If MyBrow <> "Netscape" Then %>
<script language="JavaScript" for="window" event="onLoad()">
<!--
Chat.Chat.focus()
//-->
</script>
<% End If %>
<Center>
<Table border="0" width="100%">
<TR><form Action="LogOff.asp" Method="Post">
<TD valign="middle" align="Center" width=20%>
<INPUT type="submit" value="Exit">
</TD>
</Form>
<FORM Name="Chat" Action="SaveChat.asp" Method="Post"" onSubmit="return ValEntry()">
			<TD valign="middle" width=60%>
				<Center>
	  			<INPUT type="hidden" Name="User" value="<%=Session("User")%>">
	  			<% If MyBrow="Netscape" Then %>
				<TextArea Name="Chat" Rows=2 Cols="55" selected></TextArea>
				<% Else %>
				<TextArea Name="Chat" Rows=2 Cols="55" selected></TextArea>
 				<% End If %>
				</Center>
			</TD>
   		<TD valign="middle" width=20%>
			   <Center>
	  			<INPUT type="submit" value=" Send ">
				<input type="hidden" Name="whisper" value="<%=Session("Whisper")%>">
				</center>
			</TD></FORM>
   	</TR>
	  <tr>
	  <td colspan="3"><Center>
<% If Len(Session("User"))>0 Then %>
<form Name="Update" Action="SetSession.asp" Method="Post">
<table border="0">
<tr>
<td valign="middle">
<FONT face="<%=FF%>" color="<%=FntClr%>"><Small>View </Small></font>
<Select Name="Views" OnChange="Update.submit()">
<% If Session("Views")=25 Then %>
<option Value="25" Selected>All
<%Else%>
<option value="25">All
<%End If%>
<% If Session("Views")=10 Or Len(Session("Views"))=0 Then %>
<option value="10" Selected>10
<%Else%>
<option value="10">10
<%End If%>
<% If Session("Views")=15 Then %>
<option value="15" Selected>15
<%Else%>
<option value="15">15
<%End If%>
<% If Session("Views")=20 Then %>
<option value="20" Selected>20
<%Else%>
<option value="20">20
<%End If%>
</Select> <FONT face="<%=FF%>" color="<%=FntClr%>"><Small>rows</Small></Font>
</td>
<td valign="middle">
<FONT face="<%=FF%>" color="<%=FntClr%>"><Small>Refresh</Small></font>
<Select Name="RefreshRate" OnChange="Update.submit()">
<% If Session("RefreshRate")=2 Then %>
<option Selected>2
<%Else%>
<option>2
<%End If%>
<% If Session("RefreshRate")=3 Then %>
<option Selected>3
<%Else%>
<option>3
<%End If%>
<% If Session("RefreshRate")=4 Then %>
<option Selected>4
<%Else%>
<option>4
<%End If%>
<% If Session("RefreshRate")=5 Or Len(Session("RefreshRate"))=0 Then %>
<option Selected>5
<%Else%>
<option>5
<%End If%>
<% If Session("RefreshRate")=6 Then %>
<option Selected>6
<%Else%>
<option>6
<%End If%>
<% If Session("RefreshRate")=7 Then %>
<option Selected>7
<%Else%>
<option>7
<%End If%>
<% If Session("RefreshRate")=8 Then %>
<option Selected>8
<%Else%>
<option>8
<%End If%>
<% If Session("RefreshRate")=9 Then %>
<option Selected>9
<%Else%>
<option>9
<%End If%>
<% If Session("RefreshRate")=10 Then %>
<option Selected>10
<%Else%>
<option>10
<%End If%>
<% If Session("RefreshRate")=11 Then %>
<option Selected>11
<%Else%>
<option>11
<%End If%>
<% If Session("RefreshRate")=12 Then %>
<option Selected>12
<%Else%>
<option>12
<%End If%>
<% If Session("RefreshRate")=13 Then %>
<option Selected>13
<%Else%>
<option>13
<%End If%>
<% If Session("RefreshRate")=14 Then %>
<option Selected>14
<%Else%>
<option>14
<%End If%>
<% If Session("RefreshRate")=15 Then %>
<option Selected>15
<%Else%>
<option>15
<%End If%>
<% If Session("RefreshRate")=16 Then %>
<option Selected>16
<%Else%>
<option>16
<%End If%>
<% If Session("RefreshRate")=17 Then %>
<option Selected>17
<%Else%>
<option>17
<%End If%>
<% If Session("RefreshRate")=18 Then %>
<option Selected>18
<%Else%>
<option>18
<%End If%>
<% If Session("RefreshRate")=19 Then %>
<option Selected>19
<%Else%>
<option>19
<%End If%>
<% If Session("RefreshRate")=20 Then %>
<option Selected>20
<%Else%>
<option>20
<%End If%>
</Select> <FONT face="<%=FF%>" color="<%=FntClr%>"><Small>sec.</Small></Font>
</td>
<td><FONT face="<%=FF%>" color="<%=FntClr%>"><Small>View </Small></Font>
<Select name="rOrder" OnChange="Update.submit()">
<option <%If rOrder="Asc" Then Response.write "Selected"%>>Asc
<option <%If rOrder="Desc" Then Response.write "Selected"%>>Desc
</Select>&nbsp;
</td>
<td valign="middle">
<% If sPrinter="on" then %>
<INPUT type="button" value="Print" OnClick="PrintIt()">&nbsp;&nbsp;
<% 
End If 
If Ubound(Application("Chat_Rooms"))> 0 Then %>
<INPUT type="Button" value="Rooms" Onclick="ActiveRooms()">&nbsp;
<% End If %>
<INPUT type="Button" value="Help" Onclick="help()">&nbsp;
<% If facebtn=True Then %>
<INPUT type="Button" value="Face" Onclick="SelectFace()">&nbsp;
<% 
WhisperOptions = Session("WhisperList")
WhisperOptions = Split(WhisperOptions,",")

End If 
%>
</td>
</tr>
<tr>
<td colspan=4><input type=checkbox name="Notify" value="Yes" <%=Session("Checked")%> OnClick="Update.submit()"> <FONT face="<%=FF%>" color="<%=FntClr%>"><Small>Notify me when new guests enter the room &nbsp; Whisper to:</Small></font>
<Select name="WhisperTo" OnChange="Whisper(this)">
<option>none
<%
for i = 0 to ubound(Application("Chat_List"))
If Application("Chat_List")(i,0) <> Session("User") And Application("Chat_List")(i,3)=Session("Room") Then
%>
<option value="<%=Application("Chat_List")(i,0)%>" <% If Session("Whisper") = Application("Chat_List")(i,0) Then Response.write " Selected"%>><%=Application("Chat_List")(i,0)%> 
<%
End If
Next
%>
</Select></td>
</tr>
</table>
</Center>
</td>
</tr>
</table>
</Form>
<% End If %>
</Center>
</BODY></HTML>
