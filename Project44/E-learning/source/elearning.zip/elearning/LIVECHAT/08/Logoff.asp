<%Option Explicit%>
<!--#include file="AppConfig.inc"-->
<%
Response.buffer=True

Dim GoodBye
Dim t
Dim n
Dim NewArraySize
Dim i
Dim y
Dim Chat_Rooms()
n=-1
NewArraySize=-1

Session("GoodBye")=Session("User")

For t = 0 to Ubound(Application("Chat_List"))
	If Trim(Application("Chat_List")(t,0)) <> Trim(Session("User")) Then	
		 	NewArraySize=NewArraySize + 1
	End If
Next

ReDim Chat_List(NewArraySize,4)

For i = 0 to Ubound(Application("Chat_List"))
	
	If Trim(Application("Chat_List")(i,0)) <> Trim(Session("User")) Then  
		n = n + 1
		Chat_List(n,0) = Application("Chat_List")(i,0)
		Chat_List(n,1) = Application("Chat_List")(i,1)
		Chat_List(n,2) = Application("Chat_List")(i,2)
		Chat_List(n,3) = Application("Chat_List")(i,3)
		Chat_List(n,4) = Application("Chat_List")(i,4)		
	Else
		Application.Lock
		Application("User_Cnt") = Application("User_Cnt") - 1
		Application.UnLock
	End If
	
Next

Application.Lock
Application("Chat_List")=""
Application("Chat_List")=Chat_List
If Application("User_Cnt") < 0 Then
	Application("User_Cnt") = 0
End If
Application.UnLock

ReDim Chat_Rooms(Ubound(Application("Chat_Rooms")),3)
for y = 0 to Ubound(Application("Chat_Rooms"))
	Chat_Rooms(y,0) = Application("Chat_Rooms")(y,0)
	Chat_Rooms(y,1) = Application("Chat_Rooms")(y,1)
	Chat_Rooms(y,2) = Application("Chat_Rooms")(y,2)

   If Application("Chat_Rooms")(y,0) = Session("Room") Then
		Chat_Rooms(y,3)= (Application("Chat_Rooms")(y,3)-1)
	Else
		Chat_Rooms(y,3) = Application("Chat_Rooms")(y,3)
	End If
next

Application.Lock
Application("Chat_Rooms")=""
Application("Chat_Rooms")=Chat_Rooms
Application.UnLock

Session("Loggout")= True

%>

<html>
<head>
<title>Log Off</title>
<SCRIPT LANGUAGE="JavaScript"><!--
setTimeout('top.close()',2000);
//--></SCRIPT>
</head>
<BODY topmargin="0" bottommargin="0" leftmarin="1" rightmargin="1" BGCOLOR="<%=HdrClr%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
</body>
</html>
