<!--#include file="AppConfig.inc"-->
<html>
<head>
<title>Faces</title>
</head>
<body topmargin="0">
<Center>
<font face="arial" size="1"><B>Click on a face</B></font>
<hr>
<a href="SessionFace.asp?face="><font face="arial" size="1">Remove Face</font></a><br>
<hr>
<Table>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face1.gif"><img src="face1.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face2.gif"><img src="face2.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face3.gif"><img src="face3.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face4.gif"><img src="face4.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face5.gif"><img src="face5.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face6.gif"><img src="face6.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face7.gif"><img src="face7.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face8.gif"><img src="face8.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face9.gif"><img src="face9.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face13.gif"><img src="face13.gif" border="0"></a></td>
</tr>
<tr>
<td align="Center"><a href="SessionFace.asp?face=face21.gif"><img src="face21.gif" border="0"></a></td>
</tr>
</table>
</Center>
<P>
</body>
</html>

