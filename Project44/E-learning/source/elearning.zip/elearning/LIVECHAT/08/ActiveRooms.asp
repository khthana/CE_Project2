<%Option Explicit%>
<!--#include file="AppConfig.inc"-->
<%
Dim Ucnt
Dim CurRoom
Dim gRS
Dim Gcnt
Dim MaxCnt
Dim StrCat
Dim StrRm
Dim bc
Dim MyBrow
Dim i
Dim Chat_Rooms

%>

<html>
<head>
<SCRIPT Language="vbscript">
<!---------
Function CloseIt()
Window.Close
End Function
---------------->
</SCRIPT>

<title>Active Rooms</title>
</head>
<BODY topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginheight="0" marginwidth="0" BGCOLOR="<%=PgBGColor%>">
<P>
<center>
<table>
<tr>
<td bgcolor="<%=HdrClr%>" valign="top" align="center">&nbsp;<Small><FONT face="<%=FF%>" color="<%=FntClr%>">Room</font></Small>&nbsp;</td>
<td bgcolor="<%=HdrClr%>" valign="top" align="center">&nbsp;<Small><FONT face="<%=FF%>" color="<%=FntClr%>">No of users</font></Small>&nbsp;</td>
<td bgcolor="<%=HdrClr%>" valign="top" align="center">&nbsp;<Small><FONT face="<%=FF%>" color="<%=FntClr%>">Max. users</font></Small>&nbsp;</td>
</tr>
<%
'ReDim Chat_Rooms(Ubound(Application("Chat_Rooms")),3) 
Chat_Rooms = Application("Chat_Rooms")
for i = 0 to Ubound(Chat_Rooms)
If Session("Room")<> Chat_Rooms(i,0) Then %>
<tr>
<td><Small><FONT face="<%=FF%>" color="<%=PgFntClr%>"><A href="ChangeRoom.asp?Rm=<%=Server.URLEncode(Chat_Rooms(i,0))%>&Cat=<%=Server.URLEncode(Chat_Rooms(i,2))%>"><%=Chat_Rooms(i,0)%></A></font></Small></td>
<td align="center"><Small><FONT face="<%=FF%>" color="<%=PgFntClr%>"><%If Trim(Chat_Rooms(i,3))="" Then Response.write "0" Else Response.write Chat_Rooms(i,3) %></font></Small></td>
<td><Small><FONT face="<%=FF%>" color="<%=PgFntClr%>"><%=Chat_Rooms(i,1)%></font></Small></td>
</tr>
<%
End If
Next
%>
<tr>
<td bgcolor="<%=HdrClr%>" colspan=3>&nbsp;</td>
</tr>
</Table>
</Center>
<P>
<CENTER>
  <INPUT type="Button" Value="Close" OnClick="CloseIt()">
</CENTER>
<P>
</body>
</html>


