<%
Dim Face

	Session("Face")=Request.QueryString("Face")
%>
<html>
<head>
<title>Select Face</Title>
<SCRIPT LANGUAGE="JavaScript"><!--
setTimeout('self.close()',0000);
//--></SCRIPT>
</head>
<body>
</body
</html>
