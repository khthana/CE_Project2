<!--#include file="AppConfig.inc"-->
<%
Dim StrUser
Dim StrPWD
Dim StrEmail
Dim VarCookie

'Test for cookies enabled
	response.cookies("testcookie") ("User") = "Test"
	
	VarCookie=request.cookies("testcookie") ("user")

If Len(VarCookie)=0 Then
	response.redirect"nocookies.html"
End If

StrUser = Request.Cookies("Chat")("User")
StrPwd = Request.Cookies("Chat")("PWD")
StrEmail = Request.Cookies("Chat")("Email")
 
Dim bc
Dim MyBrow
 
Set bc = Server.CreateObject("MSWC.BrowserType")
MyBrow= bc.browser

%>
<HTML>
<HEAD>
<TITLE>Logon Screen</TITLE>

<SCRIPT language="JavaScript">

function LogonReq() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "Rooms.asp";
 	winOptions = "top=100, left=100, width=450, height=350,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "Rooms", winOptions);
 }

function Logonhelp() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "LogonHelp.asp";
 	winOptions = "top=100, left=100, width=450, height=250,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "Logon_Help", winOptions);
 }

 function Features() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "features.html";
 	winOptions = "top=100, left=100, width=600, height=400,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "Features", winOptions);
 }
</Script>

</HEAD>
<BODY BGCOLOR="<%=PgBGColor%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
<CENTER>
<P>
<CENTER>
<IMG BORDER="0" SRC="<%=Mlogo%>">
<P>
  <FONT face="<%=FF%>" color="<%=PgFntClr%>"><B>Logon to Rooms</B></FONT>
  <P>
  <FONT face="<%=FF%>" color="<%=PgFntClr%>">Guests enter a prefered Name and Password</font>
  <P>
  <FONT face="<%=FF%>" color="<%=PgFntClr%>">Email is optional</font>

  <P>
   <FORM Name="Chat" Action="rooms.asp" Method="post">
    <TABLE border=1 BGCOLOR="<%=HdrClr%>">
      <TR>
	<TD><TABLE CELLPADDING="2" ALIGN="Center">
	    <TR>
	      <TD align="right"><FONT face="<%=FF%>" color="<%=FntClr%>">Name :</FONT></TD>
	      <TD>
		<INPUT type ="text" Name="User" STYLE="font: normal 10pt Arial" value="<%=StrUser%>"></TD>
	    </TR>
		 <TR>
	      <TD align="right"><FONT face="<%=FF%>" color="<%=FntClr%>">Password :</FONT></TD>
	      <TD>
		<INPUT type ="password" Name="PWD" STYLE="font: normal 10pt Arial" value="<%=StrPwd%>"></TD>
	    </TR>
		 <TR>
	      <TD align="right"><FONT face="<%=FF%>" color="<%=FntClr%>">Email :</FONT></TD>
	      <TD>
		<INPUT type ="text" Name="Email" STYLE="font: normal 10pt arial" value="<%=StrEmail%>"></TD>
	    </TR>
		 <TR>
	      <TD align="right"><FONT face="<%=FF%>" color="<%=FntClr%>">Remember Logon Info :</FONT></TD>
	      <TD>
		<INPUT type ="CheckBox" Name="Remember" value="yes" Checked></TD>
	    </TR> 
	    <TR>
	      <TD COLSPAN=2><Center>
		<INPUT type ="Submit" value="Logon"> 
		<INPUT type ="Reset" value="Clear">
		<input type ="button" value="Help" OnClick="Logonhelp()">
		<!-----
		<input type ="button" value="Get your own ASP Chat" OnClick="DownLoadIt()">
		------>
		</Center>
		</TD>
	    </TR>
		 <% If gspkrbtn = True Then %>
		 <TR>
		 <TD colspan=2><Center><input type ="button" value="Guest Speaker Notification" OnClick="GuestSpeaker()"></TD>
		 </TR>
		 <% End If %>
	  </TABLE>
	</TD>
      </TR>
    </TABLE>
  </FORM>
<% If MyBrow <> "Netscape" Then %>
<script language="JavaScript" for="window" event="onLoad()">
<!--
Chat.User.focus()
//-->
</script>
<% End If %>
  </CENTER>
<P>
</BODY></HTML>
