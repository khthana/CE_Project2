<%
Option Explicit
%>
<!--#include file="AppConfig.inc"-->
<%
Dim sChat
Dim Chat
Dim Whisp
Dim Chat_List
Dim CheckFor
Dim NewWord
Dim i
Dim SplitVar
Dim n
Dim x
Dim Img
Dim ThisDate
Dim StrImgPath
Dim LinkArray
Dim LinkArray_2
Dim EmailArray
Dim sPos
Dim StartVar
Dim EndVar
Dim ePos
Dim lPos
Dim text1
Dim text1a
Dim StrExit 
Dim eStart
Dim eMid
Dim eEnd
Dim eLeft
Dim eRight
Dim NewString
Dim nStart

StrImgPath = "http://" & Request.Servervariables("Server_Name") & Left(Request.Servervariables("URL"),InstrRev(Request.Servervariables("URL"),"/"))

Session("WhisperTo")= Server.htmlEnCode(Request.form("whisper"))

if Session("WhisperTo")="" Then
	Session("WhisperTo")="none"
End If

If Len(request.form("Chat"))=0 Then
	Response.Redirect"ChatReq.asp"
	Response.end
End if

sChat=request.form("Chat")
sChat=Replace((sChat),"<a href="""," ")
sChat=Replace((sChat),"<a href='"," ")
sChat=Replace((sChat),"'>"," ")
sChat=Replace((sChat),""">"," ")
sChat=Replace((sChat),"</a>"," ")
sChat=Replace((sChat),"HTTP://"," ")
sChat=Replace((sChat),"http://"," ")

sChat=Server.htmlEnCode(sChat)

If StrMonitor="all" Or StrMonitor=Session("Catagory") Then
	
	'///////////////////////////////
	'// Filter out unwanted words //
	'///////////////////////////////
		
	CheckFor=Split(Trim(LangMon), ",")
	
	For i=0 to ubound(CheckFor)
	
		'//////////////////////////////////////////////////////
		'// we will do a split on the filter string and make //
		'// the first letter of each word uppercase ////////////
		'////////////////////////////////////////////
		
		SplitVar=CheckFor(i) 
		
		SplitVar=Split(SplitVar," ")
		
		For n=0 to ubound(SplitVar)
			NewWord=NewWord & " " & UCase(Left(Trim(SplitVar(n)),1)) & Mid(Trim(SplitVar(n)),2)
			NewWord=Trim(NewWord)
		next
	
		' Replace Phrases or words with first letter upper case
		sChat = Replace(sChat,NewWord, blreplace)
		sChat = Replace(sChat,NewWord & " ", blreplace)
		sChat = Replace(sChat," " & NewWord, blreplace)
		' Replace lower case words
		sChat = Replace(sChat,Lcase(CheckFor(i)),blreplace)
		sChat = Replace(sChat,Lcase(CheckFor(i)) & " ",blreplace)
		sChat = Replace(sChat," " & Lcase(CheckFor(i)),blreplace)
		'Replace upper case words
		sChat = Replace(sChat,Ucase(CheckFor(i)),blreplace)
		sChat = Replace(sChat,Ucase(CheckFor(i) & " "),blreplace)
		sChat = Replace(sChat," " & Ucase(CheckFor(i)),blreplace)
	
		NewWord=""
	Next

End If

If Len(Trim(Session("WhisperTo"))) > 0 And Trim(Session("WhisperTo"))<> "none" Then
	sChat=sChat & " wt=" & Session("WhisperTo") 
End If

'//////////////////////////////////////////////////////////////////////////////
'// Get the value of the text area in lower case to use as the search string //
'// so we do not have to worry about upper and lower case text				     //
'//////////////////////////////////////////////////////////////////////////////

text1 = Replace(Lcase(sChat),"http://","")
text1 = Replace(text1,chr(13),space(1) & chr(13))


'////////////////////////////////////////////////////////////////////////////////
'// Get the value of the text area without changing the case, this will be the //
'// String we add the hyperlinks to at the end of the process			          //
'////////////////////////////////////////////////////////////////////////////////

text1a = Replace(sChat,"http://","")
text1a = Replace(text1a,chr(13),space(1) & chr(13))

sPos=1 ' Set the starting position to begin the search

If Len(Text1) > 0 Then 

	Do Until StrExit="True"
	
	StartVar=InStr(sPos, text1,"www")

	If StartVar > 0 Then
	   EndVar=Instr(Mid(text1,StartVar,Len(text1)),",")
		
		If EndVar = 0 Then
			EndVar=Instr(Mid(text1,StartVar,Len(text1))," ")
		End If

		If EndVar = 0 Then
			EndVar=Len(text1)
			sPos = Len(text1)
			StrExit="True"
		End If

		If LinkArray = "" Then
			LinkArray = Mid(text1a,StartVar,EndVar)
		Else
			LinkArray=LinkArray & "," & Mid(text1a,StartVar,EndVar)
		End If
	Else

		sPos = Len(text1)
		StrExit="True"
	
	End If

	sPos=(StartVar + EndVar) ' Set the next postition in the string to start the search

	Loop
	
End If

LinkArray_2 = Split(LinkArray,",")

for i=0 to UBound(LinkArray_2)

text1a=Replace(text1a,LinkArray_2(i),"<a href='http://" & Trim(LCase(LinkArray_2(i))) & "' Target='_Blank'>" & Trim(LCase(LinkArray_2(i))) & "</a> &nbsp;")

next

text1a=Replace(text1a,"&nbsp;,",",&nbsp;")

sChat=text1a

if Chat_I_Date ="on" Then	
	ThisDate = Date()
	ThisDate = "<Small><font color=""red"">" & FormatDateTime(ThisDate,vblongDate) & "</font></Small>"
	sChat = sChat  & " - " & ThisDate
End If

Trim(sChat)

If Len(Session("Face"))>0 Then
	Img= "<img src='" & StrImgPath & session("Face") & "' border='0' align='top'>"
	sChat= Img & "&nbsp;&nbsp;" & sChat 
End If

'////////////////////////////////
'// Add moods to the chat text //
'////////////////////////////////

sChat = Replace (sChat,":)","&nbsp;<img src='" & StrImgPath & "mood1.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,":-)","&nbsp;<img src='" & StrImgPath & "mood1.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,":(","&nbsp;<img src='" & StrImgPath & "mood2.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,":-(","&nbsp;<img src='" & StrImgPath & "mood2.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,";)","&nbsp;<img src='" & StrImgPath & "mood3.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,";-)","&nbsp;<img src='" & StrImgPath & "mood3.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,"lol","&nbsp;<img src='" & StrImgPath & "mood4.gif' width='15' height='15'>&nbsp;")
sChat = Replace (sChat,"LOL","&nbsp;<img src='" & StrImgPath & "mood4.gif' width='15' height='15'>&nbsp;")

Application.Lock
Application(Session("Room") & "_1") = Application(Session("Room") & "_2")
Application(Session("Room") & "_2") = Application(Session("Room") & "_3")
Application(Session("Room") & "_3") = Application(Session("Room") & "_4")
Application(Session("Room") & "_4") = Application(Session("Room") & "_5")
Application(Session("Room") & "_5") = Application(Session("Room") & "_6")
Application(Session("Room") & "_6") = Application(Session("Room") & "_7")
Application(Session("Room") & "_7") = Application(Session("Room") & "_8")
Application(Session("Room") & "_8") = Application(Session("Room") & "_9")
Application(Session("Room") & "_9") = Application(Session("Room") & "_10")
Application(Session("Room") & "_10") = Application(Session("Room") & "_11")
Application(Session("Room") & "_11") = Application(Session("Room") & "_12")
Application(Session("Room") & "_12") = Application(Session("Room") & "_13")
Application(Session("Room") & "_13") = Application(Session("Room") & "_14")
Application(Session("Room") & "_14") = Application(Session("Room") & "_15")
Application(Session("Room") & "_15") = Application(Session("Room") & "_16")
Application(Session("Room") & "_16") = Application(Session("Room") & "_17")
Application(Session("Room") & "_17") = Application(Session("Room") & "_18")
Application(Session("Room") & "_18") = Application(Session("Room") & "_19")
Application(Session("Room") & "_19") = Application(Session("Room") & "_20")
Application(Session("Room") & "_20") = Application(Session("Room") & "_21")
Application(Session("Room") & "_21") = Application(Session("Room") & "_22")
Application(Session("Room") & "_22") = Application(Session("Room") & "_23")
Application(Session("Room") & "_23") = Application(Session("Room") & "_24")
Application(Session("Room") & "_24") = Application(Session("Room") & "_25")
Application(Session("Room") & "_25") = Session("User") & " -" & sChat 
Application(Session("Room") & "_LastModified") = Now()
Application.UnLock

Chat_List = Application("Chat_List")

For x = 0 to Ubound(Chat_List)
	If Chat_List(x,0)= Session("User") Then
		Chat_List(x,4)=Now()
		Application.Lock
		Application("Chat_List")= Chat_List
		Application.Unlock
		exit For
	End If
Next

Response.Redirect "functions.asp" '"ChatReq.asp"
%>
