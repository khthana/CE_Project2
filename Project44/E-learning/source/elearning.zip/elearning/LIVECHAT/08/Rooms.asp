<%Option Explicit%>
<!--#include file="AppConfig.inc"-->
<%
Response.buffer=True

Dim MyPWD
Dim Conn
Dim connStr
Dim Sql
Dim RS
Dim Rows
Dim sRoom
Dim gName
Dim gCnt
Dim PWD
Dim Views
Dim RefreshRate
Dim RoomArray()
Dim SetCnt
Dim Chat_List()
Dim Chat_Rooms()
Dim i
Dim x
Dim Loggout
Dim ChatCnt
Dim Ncnt
Dim Notify()
Dim StrDontAdd

Ncnt = 0

Session("Loggout")= False

If Len(Application("User_Cnt")) = 0 Then
	Application("User_Cnt") = 0
End If

'// Check the Application("Notify") array for null entries
If IsArray(Application("Notify")) Then
	For i = 0 to Ubound(Application("Notify"))
		If Len(Trim(Application("Notify")(i))) > 0 Then
			Ncnt=Ncnt + 1
		End If
	next

	If Ncnt > 0 Then
		ReDim Notify(Ncnt-1)
		For i = 0 to Ubound(Application("Notify"))
			If Len(Trim(Application("Notify")(i))) > 0 Then
				Notify(i) = Application("Notify")(i)
			End If
		next
	Else
		Redim Notify(-1)
	End If
	Application.Lock
	Application("Notify")=Notify
	Application.UnLock

End If

'/////////////////////////////////////////////////////////////
'// use these to clear the appliation variables for testing //
'/////////////////////////////////////////////////////////////
'Application("Rooms_Cnt")=""
'Application("Chat_List")=""
'Application("User_Cnt") = 0
'Application("Notify")=""

If Len(Application("Rooms_Cnt"))= 0 Then
	Application("Rooms_Cnt") = 0
End If	

If Request.form("Remember")="yes" Then
	response.cookies("Chat") ("User") = Request.form("User")
	response.cookies("Chat") ("PWD")  = Request.form("PWD")
	response.cookies("Chat") ("Email")= Request.form("Email")
	Response.Cookies("Chat").Expires = Date + 365
End If

gName=LCase(Request.form("User"))

If gName="guest"  Then
 	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<Center>" & vbcrlf
	Response.write"Please select a new name" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<A href=""javascript:history.back(1)"">Back</A>" & vbcrlf
   Response.write"</Center>" & vbcrlf
	Response.end
End If

If len(gName)=0 Then
 	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<Center>" & vbcrlf
	Response.write"A user name is required" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<A href=""javascript:history.back(1)"">Back</A>" & vbcrlf
   Response.write"</Center>" & vbcrlf
	Response.end
End If

MyPWD=LCase(Request.form("PWD"))
 
If len(MyPWD)=0 Then
 	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<Center>" & vbcrlf
	Response.write"A password is required" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<A href=""javascript:history.back(1)"">Back</A>" & vbcrlf
   Response.write"</Center>" & vbcrlf
	Response.end
End If

If Application("Rooms_Cnt") = 0 Then
'//////////////////////////////////////////////
'// Update Application("Chat_Rooms") Variable //
'// from the database.                        //
'//////////////////////////////////////////////
Set conn = Server.CreateObject("ADODB.Connection")
connStr = "DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=" & Server.MapPath(MyCon)
Conn.Open connStr
	 
Sql="SELECT * From Rooms Order By Room;"

Set RS=Server.CreateObject("ADODB.Recordset")

RS.Open Sql, Conn, 3, 3

Rows=RS.RecordCount
Application("Rooms_Cnt")= Rows

ReDim  RoomArray((Rows-1),3)

SetCnt = 0

Do While Not RS.EOF
	RoomArray((SetCnt),(0)) = RS("Room")
	RoomArray((SetCnt),(1)) = RS("MaxUser")
	RoomArray((SetCnt),(2)) = RS("Catagory")
	RoomArray((SetCnt),(3)) = "0"
	SetCnt=SetCnt + 1
RS.MoveNext
Loop
Application.Lock
Application("Chat_Rooms")= RoomArray
Application.UnLock

RS.Close
Conn.Close
Set RS=Nothing
Set Conn=Nothing

Else

'///////////////////////////////////////////////
'// Check for error in chatroom user count    //
'// of the application("Chat_Rooms") variable //
'// This function is just incase there was a  //
'// problem when a user left the room         //  
'///////////////////////////////////////////////
ReDim	Chat_Rooms(Ubound(Application("Chat_Rooms")),3)

for i = 0 to Ubound(Chat_Rooms)
	ChatCnt = 0 
	Chat_Rooms(i,0) = Application("Chat_Rooms")(i,0)
	Chat_Rooms(i,1) = Application("Chat_Rooms")(i,1)
	Chat_Rooms(i,2) = Application("Chat_Rooms")(i,2)

	If Len(Application("User_Cnt")) > 0 And Application("User_Cnt") > 0 Then
		for x = 0 to Ubound(application("Chat_List"))
			If Trim(Application("Chat_List")(x,3)) = Trim(Application("Chat_Rooms")(i,0)) Then
				If DateValue(Application("Chat_List")(x,4)) = Date() Then 
					ChatCnt = ChatCnt + 1
				End If
			End If
		next
	End If

	 Chat_Rooms(i,3) = ChatCnt
Next

Application.Lock
Application("Chat_Rooms")=""
Application("Chat_Rooms")=Chat_Rooms
Application.UnLock
End If

'/////////////////////////////////////////////////////////
'// If there is no chat rooms available show ths message//
'/////////////////////////////////////////////////////////
If Application("Rooms_Cnt")=0 Then
 	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"&nbsp;" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<Center>" & vbcrlf
	Response.write"No Chat rooms in session, please check back" & vbcrlf
	Response.write"<P>" & vbcrlf
	Response.write"<A href=""../"">Back</A>" & vbcrlf
   Response.write"</Center>" & vbcrlf
	Response.end
 End If


'///////////////////////////////////////////////////////////
'// If there is only 1 chat room send user directly there //
'// and update the Application("Chat_List") and the		 //
'// Application("Chat_Rooms") variables.                   //
'///////////////////////////////////////////////////////////
If Application("Rooms_Cnt") = 1 Then
 	Application.Lock
	Session("User")=gName
	Session("PWD")=MyPWD
	Session("Email")=Request.form("Email")
	Session("Room")=Application("Chat_Rooms")(0,0)
	ReDim Chat_Rooms(UBound(Application("Chat_Rooms")),3)
	
	for x = 0 to UBound(Chat_Rooms)
			Chat_Rooms(x,0) = Application("Chat_Rooms")(x,0)
			Chat_Rooms(x,1) = Application("Chat_Rooms")(x,1)
			Chat_Rooms(x,2) = Application("Chat_Rooms")(x,2)
			If Application("Chat_Rooms")(x,0)=Session("Room") Then
				Chat_rooms(x,3)= Application("Chat_Rooms")(x,3) + 1
			Else
				Chat_rooms(x,3)= Application("Chat_Rooms")(x,3)
			End If
	Next
	
	Application("Chat_Rooms")= Chat_Rooms
	
	Session("Catagory")=Application("Chat_Rooms")(0,2)
	Session("Views")= 10
	Session("RefreshRate")=5

	'// Check to see if the user is currently in the Application("Chat_List") Array
	'// If so don't add them again
StrDontAdd = False
If IsArray(Application("Chat_List")) Then
	For i = 0 to Ubound(Application("Chat_List"))
 		If (Trim(Application("Chat_List")(i,0)) = Trim(gName)) And (Trim(Application("Chat_List")(i,1)) = Trim(MyPWD)) Then
			StrDontAdd = True
			Exit For
		Else
			StrDontAdd = False
		End If
	next
End If
If StrDontAdd = False Then

	If Not IsArray(Application("Chat_List")) Then
		Redim Chat_List(0,4)
		Chat_List(0,0)= gName
		Chat_List(0,1)= MyPWD
		Chat_List(0,2)= Request.form("Email")
		Chat_List(0,3)= Application("Chat_Rooms")(0,0)
		Chat_List(0,4)= Now()
	Else
		ReDim Chat_List((Ubound(Application("Chat_List"))+1),4)
		For i = 0 to Ubound(Application("Chat_List"))
			Chat_List (i,0) = Application("Chat_List")(i,0)
			Chat_List (i,1) = Application("Chat_List")(i,1)
			Chat_List (i,2) = Application("Chat_List")(i,2)
			Chat_List (i,3) = Application("Chat_List")(i,3)
			Chat_List (i,4) = Application("Chat_List")(i,4)
		Next
		Chat_List (i,0) = gName
		Chat_List (i,1) = MyPWD
		Chat_List (i,2) = Request.form("Email")
		Chat_List (i,3) = Application("Chat_Rooms")(0,0)
		Chat_List (i,4) = Now()
	End If
	Application("Chat_List") = Chat_List
	Application("User_Cnt")  = Application("User_Cnt") + 1
	Application.UnLock

End If
	Response.Redirect"chat.asp"
	Response.end
End If


'/////////////////////////////////////////////////////////
'// If there are multple chat rooms show the logon form //
'/////////////////////////////////////////////////////////
	
%>

<html>
<head>
<title>Select a Room</title>

  <SCRIPT language="JavaScript">

function LogonReq() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "LogonReq.asp";
 	winOptions = "top=100, left=100, width=450, height=350,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }
</script>
</head>
<BODY BGCOLOR="<%=PgBGColor%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
<CENTER>
<IMG BORDER="0" SRC="<%=Mlogo%>">
<P>
<FONT face="<%=FF%>" color="<%=PgFntClr%>"><B>Logon to Room</B></FONT>
<P>
<FORM Action="LogonReq.asp" Method="post">
<table border=1 BGCOLOR="<%=HdrClr%>">
<tr>
<td><input type = "hidden" Name="User" Value="<%=gName%>">
	 <input type = "hidden" Name="PWD" Value="<%=MyPWD%>">
	 <input type = "hidden" Name="Email" Value="<%=Request.form("Email")%>">
    <table>
    <tr>
  	   <td><center><FONT face="<%=FF%>" color="<%=FntClr%>">Join a Room</font></center></td>
	 </tr>
	 <tr>
		<td><center>
		<%
			  Response.write "<Select Name=""Room"">" & vbcrlf
			  Response.write "<Option Selected>" & vbcrlf
			  for i = 0 to UBound(Application("Chat_Rooms"))
			  Response.write "<Option value='" & Application("Chat_Rooms")(i,0) & "-" & Application("Chat_Rooms")(i,2) & "'>" & Application("Chat_Rooms")(i,0) & " (" & Application("Chat_Rooms")(i,2) & ") Guests " 
			  If Trim(Application("Chat_Rooms")(i,3))="" Then
			  	Response.write "(0)"
			  Else
			  	Response.write "(" & Application("Chat_Rooms")(i,3) & ")"
			  End If
		     Next
 			  Response.write "</Select>"
		%>
				</center>
			</td>
		</tr>
		<tr>
			<td colspan=2>&nbsp;</td>
		</tr>
		<tr>
			<td colspan=2><center>
			<input type = "submit" value="Go">
			<input type="button" value="Back" OnClick="javascript:history.back(1)">
			</center></td>
		</tr>
	</table>
</td>
</tr>
</table>
</form>
<P>
</center>
</body>
</html>



