<%Option Explicit%>
<!--#include file="AppConfig.inc"-->
<%
Response.buffer=True

Dim bc
Dim MyBrow
Dim Guest
Dim Rcnt
Dim Acnt
Dim rUsers
Dim CurRoom
Dim PWD
Dim sPWD
Dim sUser
Dim mSize
Dim v
Dim ipos
Dim Length
Dim Catagory
Dim Room
Dim Views
Dim RefreshRate
Dim i
Dim x
Dim Chat_list
Dim Chat_Rooms
Dim StrDontAdd

Guest=LCase(request.form("PWD"))

'///////////////////////////////////////////////
'// Split the Room name and the Room Category //
'///////////////////////////////////////////////
	v = Request.form("Room")
	ipos = instr(v,"-")
	length=len(v)
	Session("Room") = left(v,ipos-1)
	Session("Catagory") = right(v,length-ipos)

	for i = 0 to Ubound(Application("Chat_Rooms"))
		If Application("Chat_Rooms")(i,0) = Session("Room") Then
			rUsers = Application("Chat_Rooms")(i,3)
			Rcnt   = Application("Chat_Rooms")(i,1)
			exit for
		End If
	next
	 
	If CInt(rUsers) > CInt(Rcnt) Then
		CurRoom=Request.form("Room")
		CurRoom=Replace(CurRoom,"~","'")

		Response.write"<P>" & vbcrlf
		Response.write"&nbsp;" & vbcrlf
		Response.write"<P>" & vbcrlf
		Response.write"&nbsp;" & vbcrlf
		Response.write"<P>" & vbcrlf
		Response.write"<Center>" & vbcrlf
		Response.write "( " & CurRoom &  " ) is full" & vbcrlf
		Response.write"<P>" & vbcrlf
		Response.write"<A href=""javascript:history.back(1)"">Select a new room</A><P>" & vbcrlf
		Response.write"<A href=""../"">Back to home page</A>" & vbcrlf
	   Response.write"</Center>" & vbcrlf
		Response.end
	end if

if len(Request.form("PWD"))=0 then
	Response.write "<P>&nbsp;<P>&nbsp;<P><Center>Password is required<P>Click the <A href=""javascript:history.back(1)""><img src=""../images/smiley.gif"" Align=""Middle"" border=""0""></A> to go back</Center>"
	Response.end
End If
	
	Session("User")=Server.htmlEnCode(Request.form("User"))
	Session("PWD")=request.form("PWD")
	Session("Email")=Request.form("Email")
	Session("Views")= 10
	Session("RefreshRate")=5

	Application.Lock
	Redim Chat_Rooms(Ubound(Application("Chat_Rooms")),3)
	Chat_Rooms = Application("Chat_Rooms")
	for x = 0 to UBound(Application("Chat_Rooms"))
		Chat_Rooms(i,0) = Application("Chat_Rooms")(i,0)
		Chat_Rooms(i,1) = Application("Chat_Rooms")(i,1)
		Chat_Rooms(i,2) = Application("Chat_Rooms")(i,2)
		If Application("Chat_Rooms")(i,0)=Session("Room") Then
			Chat_rooms(i,3)= Application("Chat_Rooms")(i,3) + 1
		Else
			Chat_rooms(i,3)= Application("Chat_Rooms")(i,3)
		End If
	Next
	 Application("Chat_Rooms")= Chat_Rooms
	 '// Check to see if the user is currently in the Application("Chat_List") Array
	 '// If so don't add them again
StrDontAdd = False
If IsArray(Application("Chat_List")) Then
	 For i = 0 to Ubound(Application("Chat_List"))
	 	If (Trim(Application("Chat_List")(i,0)) = Trim(Session("User"))) And (Trim(Application("Chat_List")(i,1)) = Trim(Session("PWD"))) Then
			StrDontAdd = True
			Exit For
		Else
			StrDontAdd = False
		End If
	 next
End If

If StrDontAdd = False Then

	If Application("User_Cnt")= 0 Then
		Redim Chat_List(0,4)
		Chat_List(0,0)= Session("User")
		Chat_List(0,1)= Session("PWD")
		Chat_List(0,2)= Session("Email")
		Chat_List(0,3)= Session("Room")
		Chat_List(0,4)= Now()

	Else
		
		ReDim Chat_List(Ubound(Application("Chat_List"))+1,4)
		For i = 0 to Ubound(Application("Chat_List"))
			Chat_List (i,0) = Application("Chat_List")(i,0)
			Chat_List (i,1) = Application("Chat_List")(i,1)
			Chat_List (i,2) = Application("Chat_List")(i,2)
			Chat_List (i,3) = Application("Chat_List")(i,3)
			Chat_List (i,4) = Application("Chat_List")(i,4)
		Next
		
		Chat_List (i,0) = Session("User")
		Chat_List (i,1) = Session("PWD")
		Chat_List (i,2) = Session("Email")
		Chat_List (i,3) = Session("Room")
		Chat_List (i,4) = Now()

	End If

	Application("Chat_List") = Chat_List
	Application("User_Cnt")  = Application("User_Cnt") + 1
	
	Application.UnLock
	
End If

	Response.Redirect "Chat.asp"
	Response.end

%>
<script language="javascript">
function LogonReq() 
{
	var jumpToHere;
	var winOptions;
	var popUpWindow;
   	
	jumpToHere = "Rooms.asp";
 	winOptions = "top=100, left=100, width=450, height=350,scrollbars=yes";
 	popUpWindow = open(jumpToHere, "MyWindow", winOptions);
 }
</script>
<%
Response.Redirect"Chat.asp"
%>
