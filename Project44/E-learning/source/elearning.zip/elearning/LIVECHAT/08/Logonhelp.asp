<!--#include file="AppConfig.inc"-->
<HTML>
<HEAD>
<SCRIPT Language="vbscript">
<!---------
Function CloseIt()
Window.Close
End Function
---------------->
</SCRIPT>
  <TITLE>Help</TITLE>
</HEAD>
<BODY Topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" BGCOLOR="<%=PgBGColor%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
<TABLE BORDER="0" CELLPADDING="2">
<tr>
<td colspan="2" width=85% BGCOLOR="<%=HdrClr%>"><font face="<%=FF%>" color="<%=FntClr%>">Logon Help</font></td>
  </TR>
  <TR>
    <TD><B><SMALL><FONT face="<%=FF%>" color="<%=PgFntClr%>">Guests</FONT></SMALL></B></TD>
    <TD></TD>
  </TR>
  <TR>
    <TD>
	   <FONT face="<%=FF%>" color="<%=PgFntClr%>"><B><SMALL>1.</SMALL></B></FONT>
		<FONT face="<%=FF%>" color="<%=PgFntClr%>"><SMALL>Enter your desired screen name in the name field.<BR>
      <B>2.</B> Enter your desired password in the password field.<BR>
      <B>3.</B> If you want other guests to be able to send you email during your visit to a room enter your email address in the email field.</SMALL></FONT><BR>
		</TD>
    <TD></TD>
  </TR>
  <TR>
    <TD colspan=2><SMALL><FONT face="<%=FF%>" color="<%=PgFntClr%>">After logging on you will be prompted to select an active room<br>
	 unless there is only 1 room available then you will be taken to that room. </FONT></SMALL></TD>
    </TR>
  <TR>
    <TD>&nbsp;</TD>
    <TD>&nbsp;</TD>
  </TR>
</TABLE>
<P>
<CENTER>
  <INPUT type="Button" Value="Close" OnClick="CloseIt()">
</CENTER>
<P>
</BODY></HTML>
