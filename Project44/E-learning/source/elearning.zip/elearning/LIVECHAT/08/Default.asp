<html>
<head><title>Chat Test</title>
<script language="JavaScript"><!--
if (document.images)
    window.location.href=("logscreen.asp");
else
    window.location.href = "nojava.html";
//--></SCRIPT>
</head>
<body>
</body>
</html>
