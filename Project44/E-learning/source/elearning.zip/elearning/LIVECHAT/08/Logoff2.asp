<%Option Explicit%>
<!--#include file="AppConfig.inc"-->
<%
Response.buffer=True
On error resume Next
Dim bc
Dim MyBrow
Dim lg
Dim NewArraySize
Dim i
Dim x
Dim y
Dim t
Dim n
Dim Chat_Rooms()
Dim TmpArray
n=-1
NewArraySize=-1

If IsArray(Application("Notify")) Then
	'// Clear user from the application variable
	'response.write Ubound(Application("Notify"))
	'Response.end
	If Ubound(Application("Notify"))< 1 Then
		ReDim TmpArray(-1)
		Application.Lock
		Application("Notify")= TmpArray
		Application.UnLock
	Else
		ReDim TmpArray(Ubound(application("Notify"))-1)
		
		for i = 0 to Ubound(Application("Notify"))
			If Trim(Application("Notify")(i)) <> Trim(Session("User")) Then
				TmpArray(i)= Application("Notify")(i)
			end If
		next
		Application.Lock
		Application("Notify")=TmpArray
		Application.UnLock
	End If		
End If		

If len(Session("GoodBye"))=0 Then
Session("GoodBye")= Session("User")
End If
lg=Session("GoodBye")

Set bc = Server.CreateObject("MSWC.BrowserType")
MyBrow= bc.browser

If Session("Loggout") <> True Then

For t = 0 to Ubound(Application("Chat_List"))
	If Trim(Application("Chat_List")(t,0)) <> Trim(Session("User")) Then	
		 	NewArraySize=NewArraySize + 1
	End If
Next

ReDim Chat_List(NewArraySize,4)

For i = 0 to Ubound(Application("Chat_List"))
	
	If Trim(Application("Chat_List")(i,0)) <> Trim(Session("User")) Then  
		n = n + 1
		Chat_List(n,0) = Application("Chat_List")(i,0)
		Chat_List(n,1) = Application("Chat_List")(i,1)
		Chat_List(n,2) = Application("Chat_List")(i,2)
		Chat_List(n,3) = Application("Chat_List")(i,3)
		Chat_List(n,4) = Application("Chat_List")(i,4)		
	Else
		Application.Lock
		Application("User_Cnt") = Application("User_Cnt") - 1
		Application.UnLock
	End If
	
Next

Application.Lock
Application("Chat_List")=""
Application("Chat_List")=Chat_List
If Application("User_Cnt") < 0 Then
	Application("User_Cnt") = 0
End If
Application.UnLock

ReDim Chat_Rooms(Ubound(Application("Chat_Rooms")),3)
for y = 0 to Ubound(Application("Chat_Rooms"))
	Chat_Rooms(y,0) = Application("Chat_Rooms")(y,0)
	Chat_Rooms(y,1) = Application("Chat_Rooms")(y,1)
	Chat_Rooms(y,2) = Application("Chat_Rooms")(y,2)

   If Application("Chat_Rooms")(y,0) = Session("Room") Then
		If Application("Chat_Rooms")(y,3) > 0 Then 
			Chat_Rooms(y,3)= (Application("Chat_Rooms")(y,3)-1)
		End If
	Else
		Chat_Rooms(y,3) = Application("Chat_Rooms")(y,3)
	End If
next

Application.Lock
Application("Chat_Rooms")=""
Application("Chat_Rooms")=Chat_Rooms
Application.UnLock

Session("Loggout")= True
End If
Session("GoodBye") = ""
Session("Room") = ""
Session("User") = ""
Session("Email") = ""
Session("Pwd") = ""
session("RefreshRate") = ""
session("Views") = ""
Session("CurCount") = ""
Session("Checked") = ""

%>

<html>
<head>
<title>Log Off</title>
<SCRIPT LANGUAGE="JavaScript"><!--
setTimeout('self.close()',2000);
//--></SCRIPT>
</head>
<% If MyBrow="Netscape" Then %>
<BODY topmargin="0" bottommargin="0" leftmargin="1" rightmargin="1" BGCOLOR="<%=HdrClr%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
<P>
&nbsp;
<Center>
<font face="<%=FF%>" color="<%=FntClr%>">See You Next Time <%=lg%></Center></font>
<% Else %>
<BODY topmargin="0" bottommargin="0" leftmargin="1" rightmargin="1" BGCOLOR="<%=HdrClr%>" link="<%=PgLink%>" vlink="<%=Pgvlink%>" alink="<%=Pgalink%>">
<P>
&nbsp;
<Center>
<font face="<%=FF%>" color="<%=FntClr%>">See You Next Time <%=lg%></Center></font>
<%End If%>
</body>
</html>

