<%
Option Explicit
Response.Buffer=True
Dim Views
Dim RefreshRate
Dim Checked
Dim TmpArray()
Dim i
%>
<!--#include file="AppConfig.inc"-->
<%
Session("Views")= Request.form("Views")
Session("RefreshRate")= Request.form("RefreshRate")
Session("rOrder")= Request.form("rOrder")

If Request.form("Notify")="Yes" Then
	Session("Checked")= "Checked"
	If IsArray(Application("Notify")) Then
		ReDim TmpArray(Ubound(Application("Notify"))+1)
		for i = 0 to Ubound(Application("Notify"))
			TmpArray(i)= Application("Notify")(i)
		next
		TmpArray(i)=Trim(Session("User"))
		Application.Lock
		Application("Notify")=TmpArray
		Application.UnLock
	Else
		ReDim TmpArray(0)
		TmpArray(0)=Trim(Session("User"))
		Application.Lock
		Application("Notify")=TmpArray
		Application.UnLock
	End If
Else
	Session("Checked")= ""
	If IsArray(Application("Notify")) Then
		If Ubound(Application("Notify"))< 1 Then
			ReDim TmpArray(-1)
			Application.Lock
			Application("Notify")= TmpArray
			Application.UnLock
		Else
			ReDim TmpArray(Ubound(application("Notify"))-1)

			for i = 0 to Ubound(Application("Notify"))
				If Trim(Application("Notify")(i)) <> Trim(Session("User")) Then
					TmpArray(i)= Application("Notify")(i)
				end If
			next
			Application.Lock
			Application("Notify")=TmpArray
			Application.UnLock
		End If		
	End If		
End If

Session("Whisper") = Request.form("WhisperTo")
%>
<html>
<head>
<Script Language="Javascript">
{
parent.Functions.location.href="functions.asp"
parent.Body.location.href="body.asp"

}
</Script>
</head>
<body BGCOLOR="<%=HdrClr%>">
</body>
</html>

