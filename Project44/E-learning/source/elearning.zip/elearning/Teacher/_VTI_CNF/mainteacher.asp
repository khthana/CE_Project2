vti_encoding:SR|utf8-nl
vti_author:SR|ELEARNING\\Administrator
vti_modifiedby:SR|ELEARNING\\Administrator
vti_timelastmodified:TR|20 Mar 2002 01:49:09 -0000
vti_timecreated:TR|20 Mar 2002 01:13:07 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{F4D7949B-D1E6-42C6-943E-99B48523BF2B}
vti_backlinkinfo:VX|main1.asp
vti_nexttolasttimemodified:TW|20 Mar 2002 01:45:42 -0000
vti_title:SR|Teacher
vti_cacheddtm:TX|20 Mar 2002 01:49:10 -0000
vti_filesize:IR|1947
vti_cachedtitle:SR|Teacher
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|../font.css S|../Image/ARRO42E1.gif H|../Course/Uploads/addsubject.asp S|../Image/ARRO42E1.gif H|../Course/Uploads/Technical/editsub4teacher.asp S|../Image/ARRO42E1.gif H|../Member/coursemember.asp S|../Image/ARRO42E1.gif H|../home/News/Upload/updatenews.asp S|../Image/ARRO42E1.gif H|../Course/Uploads/Technical/course4student.asp
vti_cachedsvcrellinks:VX|FQUS|font.css FSUS|Image/ARRO42E1.gif FHUS|Course/Uploads/addsubject.asp FSUS|Image/ARRO42E1.gif FHUS|Course/Uploads/Technical/editsub4teacher.asp FSUS|Image/ARRO42E1.gif FHUS|Member/coursemember.asp FSUS|Image/ARRO42E1.gif FHUS|home/News/Upload/updatenews.asp FSUS|Image/ARRO42E1.gif FHUS|Course/Uploads/Technical/course4student.asp
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language th
vti_charset:SR|windows-874
vti_language:SR|th
