<link rel="stylesheet" type="text/css" href="../font.css" >
<head>
<meta http-equiv="Content-Language" content="th">
<title>Teacher</title>
</head>
<body>
<center><br>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="550" bgcolor="#F9F9F9">
  <tr>
    <td width=250>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="250" height="194">
      <tr>
        <td width="20">
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>
        <td width="230"><b><a href="../Course/Uploads/addsubject.asp">�����Ԫ�㹡���͹</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Course/Uploads/Technical/editsub4teacher.asp">�����������Ԫҷ���͹</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Member/coursemember.asp">�ѡ���¹��ԪҢͧ�س</a></b></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../home/News/Upload/updatenews.asp">��С�Ȣ�����������Ҫԡ��Һ���ǡѹ</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Course/Uploads/Technical/course4student.asp">�Ԫҷ��ŧ����¹���¹</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../loadprogram/Upload/updatedownload.asp">��ǹ�ͧ��� Download �����</a></b></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
    </td>
    <td width=300 background="../Image/teacher04.gif" height="200" valign="bottom">&nbsp;</td>
  </tr>
</table>
</center>
</body>