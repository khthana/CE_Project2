<!--#include virtual="/../conn.asp"-->
<%
if request.form("action")="dele" then
id=Cint(request.cookies("member_id"))
set	rs=server.createobject("adodb.recordset")
	sql="select subject_id from etemp where member_id='"&id&"'"
	rs.open sql,con,1,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
			if request.form("del"&rs("subject_id"))="on" then
			rs.delete
			end if
		rs.movenext
		loop
	end if
	rs.close
end if
con.close
response.redirect "tempitem.asp"
%>