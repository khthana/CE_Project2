<html>
<link href="../../Style.css" rel="stylesheet" type="text/css">
<link href="../../font.css" rel="stylesheet" type="text/css">
<body>
 <center>
<table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="550" id="AutoNumber1" height="100%">
  <tr>
    <td width="11%" valign="top">
    <br>
    <!------------------------------------------------------------------------------------->
<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="red" width="100%" bgcolor="#D6E7EF">
  <tr>
    <td width="100%">&nbsp;<b>��������Ԫ�</b></td>
  </tr>
</table>
<br>
 <hr color="#3399FF" width="550" size="1">
    <table border="1" cellspacing="2" style="border-collapse: collapse"  id="AutoNumber2" cellpadding="2" width="100%">
      <tr>
        <td width="250">
    <form METHOD="POST" ACTION="chksubject.asp">
        <table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#3399FF" width="100%" id="AutoNumber3" cellpadding="0">
          <tr>
            <td width="100%">&nbsp;<b><span lang="th">��Ǵ���� �ͧ </span>Course</b></td>
          </tr>
          <tr>
            <td width="100%">&nbsp;<select class="textbox" size="1" name="kind">
		<!--#include virtual="/../../conn.asp"-->
		<%
		set	rs=server.createobject("adodb.recordset")
		sql="select * from egroup_sub "
		rs.open sql,con,1,3
		if rs.eof then
            response.write "<option value=''>�������Ǵ����</option>"
		else
		rs.movefirst
		do while not rs.eof
            response.write "<option value='"&rs("sgroup")&"'>"&rs("sgroup")&"</option>"
		rs.movenext
		loop		
		end if
		rs.close
		con.close	
		%>
            </select></td>
          </tr>
          <tr>
            <td width="100%">&nbsp;<b><span lang="th">��駪��� </span>Course
            <span lang="th">�����ʹ�</span></b></td>
          </tr>
          <tr>
            <td width="100%">&nbsp;<input class="textbox" maxLength="50" name="namesubject" size="35"></td>
          </tr>
          <tr>
            <td width="100%">&nbsp;<b><span lang="th">��͸Ժ��</span></b></td>
          </tr>
          <tr>
            <td width="100%">&nbsp;<textarea class="textbox" rows="4" name="sdetail" cols="35"></textarea></td>
          </tr>
          <tr>
            <td width="100%">&nbsp;<input class="sbttn" type="submit" value="Submit">
            <input class="sbttn" type="reset" value="Reset"></td>
          </tr>
        </table>
        </form>
        </td>
        <td valign="top">
        <table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#3399FF" width="100%" height=100% id="AutoNumber4" cellpadding="0">
          <tr>
            <td width="100%" bgcolor="#D6E7EF"><span lang="th">&nbsp;���й�</span></td>
          </tr>
          <tr>
            <td width="100%">
            <ul>
              <li>
              <p align="justify"><span lang="th">���͡��Ǵ����ͧ����ͧ����ͧ��ù��ʹ� ���ͤ����дǡ㹤���</span></li>
              <li>
              <p align="justify"><span lang="th">��駪�������ͧ����ͧ��ù��ʹ�</span></li>
              <li>
              <p align="justify"><span lang="th">����͸Ժ�ª�������ͧ �����ʴ���������´��ҧ�������ǡѺ�Ԫҷ���͹</span>(<span lang="th">���������������������������������ͧ��ҹ</span>)</li>
            </ul>
            </td>
          </tr>
        </table>
        </td>
      </tr>
    </table><br>
     <hr color="#3399FF" width="550" size="1">
     <!------------------------------------------------------------------------------------->
    </td>
  </tr>
</table>
</center>
</body>

</html>