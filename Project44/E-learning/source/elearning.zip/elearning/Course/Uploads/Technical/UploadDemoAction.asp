<%@ENABLESESSIONSTATE=FALSE%>
<!--#include file="..\DSUpload.inc"-->
<%
'*********************************************************************************
'Copyright Dundas Software Ltd. 2000. All Rights Reserved.
'
'PURPOSE:           Processes the information POSTED by main.asp, and
'					 display the content of the Files & Form collection of the
'                    Dundas Upload control.
'
'CONTROLS USED:		Dundas Upload control.
'
'Dundas Software Contact Information:
'	Email:	sales@dundas.com
'   Phone:	(800) 463-1492
'			(416) 467-5100
'	Fax:	(416) 422-4801
'*********************************************************************************
server.scripttimeout=3600%>
<HTML>
<HEAD>
<LINK href="../../../board.css" rel=stylesheet type=text/css>
<LINK href="../../../font.css" rel=stylesheet type=text/css>
</HEAD>

<BODY>
<%
on error resume next

'check if there is an error, if so then inform user of error. 
private sub CheckErr
	if Err <> 0 then
		' Display error message
		Response.Write "<P style='BACKGROUND-COLOR: #a52a2a'><FONT color=#ffffff>"
		Response.Write "&nbsp;&nbsp;" & "ERROR:  " & Err.description & "</FONT></P>"
		' Clear error
		Err.Clear
	end if
end sub

'create upload component instance
set objUpload = Server.CreateObject("Dundas.Upload")

objUpload.ProgressID = Request.QueryString("ProgressID")
'if the state server was on a different machine then this is where you would need to 
'  set the IP address of the machine where the state server is located
'objUpload.StateServer = "127.0.0.1"

'initialize the root & temp folders names
RootFolderName = Server.MapPath(".") & "\TempData\"
TempFolderName = RootFolderName & objUpload.GetUniqueName

'don't use unique file names in the beginning
objUpload.UseUniqueNames = false

'upload data till first uploaded file is encountered
set NextFile = objUpload.GetNextFile
call CheckErr

'set the various properties specified by the user
if IsEmpty(objUpload.Form("UniqueNames")) then
	objUpload.UseUniqueNames = false
else
	'if "unique file names" are selected set the flag
	objUpload.UseUniqueNames = true

	'change the NextFile object's name to be unique 
	if not(NextFile is nothing) then	
		NextFile.FileName = objUpload.GetUniqueName & "_" &	NextFile.FileName
	end if
end if 

'set the temp. folder name
if not(IsEmpty(objUpload.Form("FolderName"))) then
	TempFolderName = RootFolderName & objUpload.Form.Item("FolderName")
end if 

'set maximum upload size
if not(IsEmpty(objUpload.Form.Item("MaxUpload"))) then
	objUpload.MaxUploadSize = objUpload.Form.Item("MaxUpload")
	if objUpload.MaxUploadSize <> -1 then
		objUpload.MaxUploadSize = objUpload.MaxUploadSize * 1024
	end if
end if

'set the maximum number of files which can be uploaded at one time
if not(IsEmpty(objUpload.Form.Item("MaxFiles"))) then
	objUpload.MaxFileCount = objUpload.Form.Item("MaxFiles")
end if
'set the maximum file size allowed
if not(IsEmpty(objUpload.Form.Item("MaxSize"))) then
	objUpload.MaxFileSize = objUpload.Form.Item("MaxSize")
	if objUpload.MaxFileSize <> -1 then
		objUpload.MaxFileSize = objUpload.MaxFileSize * 1024
	end if
end if	

'create temp folder
objUpload.DirectoryCreate TempFolderName
call CheckErr

'upload the rest of the files one by one
do until NextFile is nothing
	'save file into the temp. folder
	NextFile.Save TempFolderName
	
	'get Nextfile object
	set NextFile = nothing
	set NextFile = objUpload.GetNextFile

	'exit the loop in case of error	
	if Err <> 0 then
		call CheckErr
		exit do
	end if
loop

'show file items collection
Response.Write "<P style='BACKGROUND-COLOR: #6495ed'><FONT color=#ffffff>"
Response.Write "&nbsp;Number of files uploaded: " & CStr(objUpload.Files.Count) & "</FONT></P>"
it = 0
for each item in objUpload.Files
	Response.Write "<TABLE border=1 cellPadding=0 cellSpacing=1 width='100%'"
	if cint(it/2.)*2 = it then
		Response.Write " style='BACKGROUND-COLOR: #ffffe0'>" 
	else
		Response.Write " style='BACKGROUND-COLOR: #ffffff'>" 
	end if 
	Response.Write "<TR><TD width='18%' class=tsize8>Input Tag name:</TD>"
	Response.Write "<TD class=tsize8>" & item.TagName & "</TD></TR>"
	Response.Write "<TR><TD class=tsize8>Content type:</TD>"
	Response.Write "<TD class=tsize8>" & item.ContentType & "</TD></TR>"
	Response.Write "<TR><TD class=tsize8>Size:</TD>"
	Response.Write "<TD class=tsize8>" & CStr(item.Size) & "</TD></TR>"
	Response.Write "<TR><TD class=tsize8>Original path:</TD>"
	Response.Write "<TD class=tsize8>" & item.OriginalPath & "</TD></TR>"
	Response.Write "<TR><TD class=tsize8>Server path:</TD>"
	Response.Write "<TD class=tsize8>" & item.Path & "</TD></TR>"
	Response.Write "</TABLE>"


	if objUpload.Form.Item("type")="" or objUpload.Form.Item("bname")="" then
	item.Delete		' Delete uploaded file
	end if
	
	it = it + 1
	svp=item.Path
	bsize=item.Size
next

'show form items collection
%><!--
Response.Write "<BR>"
Response.Write "<P style='BACKGROUND-COLOR: #6495ed'><FONT color=#ffffff>"
Response.Write "&nbsp;Number of form items: " & CStr(objUpload.Form.Count) & "</FONT></P>"
Response.Write "<TABLE border=0 cellPadding=0 cellSpacing=1>"
Response.Write "<TR><TD width='18%'><STRONG>Input Tag Name:</STRONG></TD>"
Response.Write "<TD width='18%'><STRONG>Value:</STRONG></TD></TR>"
it = 0
for each item in objUpload.Form
	if cint(it/2.)*2 = it then
		Response.Write "<TR width='18%' style='BACKGROUND-COLOR: #ffffe0'>" 
	else
		Response.Write "<TR width='18%' style='BACKGROUND-COLOR: #ffffff'>" 
	end if 
	Response.Write "<TD>" & item & "</TD>"
	Response.Write "<TD>" & item.Value & "</TD></TR>"
	it = it + 1
next
Response.Write "</TABLE>"
-->
<!--#include virtual="/../../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")	
'--------------------------------------------------------------------------------------------------------------------------
sname=objUpload.Form.Item("FolderName")
a=len(svp)
b=InstRrev(svp,"{")
c=(a+1)-b
bfile=Right(svp,c)
bpath=sname&"/"&bfile


	if objUpload.Form.Item("type")="" then
		response.write "<table><tr><td><b>"
		response.write "Not Complete!!!         UPLOAD FILES TO DATABASE	You must Select &quot;Type&quot;"
		response.write "</b></td></tr></table>"
		
		datacomplete="false"
		
	elseif objUpload.Form.Item("bname")="" then
		response.write "<table><tr><td><b>"
		response.write "Not Complete!!!         UPLOAD FILES TO DATABASE	Because &quot;It Not Topic&quot;"
		response.write "</b></td></tr></table>"
		
		datacomplete="false"
	else
		sql="select subject_id from esub_topics where sname='"&sname&"'"
		rs.open sql,con,0,3
		subject_id=rs("subject_id")
		rs.close
		rs.open "esub_detail",con,0,3,512
		rs.addnew
			rs("subject_id")=Cint(subject_id)
			rs("btype")	=objUpload.Form.Item("type")
			rs("btopic")	=objUpload.Form.Item("bname")
			rs("bfile")		=bfile
			rs("bsize")		=bsize
			rs("bpath")	=bpath
			rs("bdate")	=now
		rs.update
		rs.close
		
		sql="select supdate from esub_topics where subject_id='"&subject_id&"'"
		rs.open sql,con,0,3
		rs("supdate")=now
		rs.update
		rs.close
		datacomplete="true"	
	end if
sql="select subject_id from esub_topics where sname='"&sname&"'"
	rs.open sql,con,0,3
	subject_id=rs("subject_id")
	rs.close
con.close
set objUpload = nothing
if datacomplete="false" then	
	response.redirect "detail4update.asp?subject_id="&Cstr(subject_id)
elseif datacomplete="true" then	
	response.redirect "detail4update.asp?subject_id="&Cstr(subject_id)
end if
%>
</BODY>
</HTML>