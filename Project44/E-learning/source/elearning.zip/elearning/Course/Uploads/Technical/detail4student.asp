<html>
<head>
<meta http-equiv="REFRSH">
<link href="../../../board.css" rel="stylesheet" type="text/css">
<link href="../../../Style.css" rel="stylesheet" type="text/css">
<link href="../../../select.css" rel="stylesheet" type="text/css">
<link href="../../../font.css" rel="stylesheet" type="text/css">
<link href="../../../link.css" rel="stylesheet" type="text/css">
<title>��������´�ͧ�Ԫ�</title>
</head>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<body>
<center>
<br>
<table border="0" cellspacing="0" style="border-collapse: collapse" width="550">
  <tr>
    <td>
<!--#include virtual="/../../../conn.asp"-->
<%
if request.querystring("subject_id")<>"" then
subject_id=Cint(request.querystring("subject_id"))
set	rs=server.createobject("adodb.recordset")
	sql="select * from esub_topics where subject_id='"&subject_id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
	response.write "<table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='100%' >"
	response.write "<tr><td colspan='2' class=tsize12><b> <img src='../../CLSS13B1.GIF'>&nbsp;"&rs("sname")&"</b></td></tr>"
	response.write "<tr bgcolor='#F5F5F5'><td class=tsize8 width='50' align=right valign=top>Detail :</td>"
	response.write "<td class=tsize8 width='450'>"&rs("sdetail")&"<hr size='1'>"
	response.write "<font color='#666666'>Create </font>"&rs("sdate")&"<font color='#666666'> Last Update </font>"&rs("supdate")&"</td></tr><tr>"
	response.write "</tr></table>"	

	set ra=con.execute ("select count(subject_id) as 'total' from etest1 where subject_id='"&rs("subject_id")&"'")
	set rb=con.execute ("select result_1 from eresult_1 where subject_id='"&rs("subject_id")&"'")
	if not rb.eof then result1=rb("result_1") else result1="�ѧ������Ẻ���ͺ" end if
	
	set ra1=con.execute ("select count(subject_id) as 'total' from etest2 where subject_id='"&rs("subject_id")&"'")
	set rb2=con.execute ("select result_2 from eresult_2 where subject_id='"&rs("subject_id")&"'")
	if not rb2.eof then result2=rb2("result_2") else result2="�ѧ������Ẻ���ͺ" end if

		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%'>"
		response.write "<tr><td width=60><td  class=tsize8 bgcolor='#F0F0F0' width='90' >&nbsp;<font color='#cc0066'><b>"&rs("sgroup")&"</b></font></td>"
	response.write "<td colspan=2></td></tr>"
	response.write "<tr  bgcolor='#ECF9FF'>"
	response.write "<td width=150 colspan='2' class=tsize8 >&nbsp;"
	response.write "<img border='0' src='../../../Image/CLSS13L1.GIF' width='5' height='5'>&nbsp;"	
	response.write "<a title='�ù��' href='../../Test/Test1/test14student.asp?subject_id="&rs("subject_id")&"'>Ẻ���ͺ��� 1</a>"	
	response.write "</td>"
	response.write "<td width=100>&nbsp;</td>"
	response.write "<td class=tsize8><font color=red>"&result1& "</font> / "&ra("total")&" ���</td>"
	response.write "<tr  bgcolor='#ECF9FF'>"
	response.write "<td width=150 colspan='2' class=tsize8 >&nbsp;"
	response.write "<img border='0' src='../../../Image/CLSS13L1.GIF' width='5' height='5'>&nbsp;"	
	response.write "<a title='�ѵ���' href='../../Test/Test2/test24student.asp?subject_id="&rs("subject_id")&"'>Ẻ���ͺ��� 2</a>"	
	response.write "</td>"
	response.write "<td width=100>&nbsp;</td>"
	response.write "<td class=tsize8><font color=red>"&result2& "</font> / "&ra1("total")&" ���</td>"
	response.write "</table>"
	response.write "<br>"
	rs.close
	sql="select * from esub_detail where subject_id='"&subject_id&"'"
	rs.open sql,con,3,3
	if rs.eof then 
		response.write "<table border='0'><tr><td class=tsize8>����բ�����</td></tr></table>"
	else
		response.write "<table border='1' width='100%' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#EFEFEF' >"
		rs.movefirst
		do while not rs.eof 
		response.write "<tr><td>"
		bfile=rs("bfile")
		a=len(bfile)
		b=InstRrev(bfile,"}")
		c=a-b
		bfile=Right(bfile,c)
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse'><tr>"
		response.write "<td width='20'>"
		response.write "<img src='../../../Image/NOTEBK01.gif' width='15' height='15'>"
		response.write "</td>"		
		response.write "<td><font color='#006699'><b>"
		if rs("btype")="Vedio" then		%>
<a class=al  href="javascript:%20void%20window.open('vedio.asp?detail_id=<%=rs("detail_id")%>',null,'toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=yes,width=780,height=540 ' ); ">
<%=rs("btopic")%></a>
		<%else%>
<a class=al  href="javascript:%20void%20window.open('TempData/<%=rs("bpath")%>',null,'toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=yes,width=780,height=540 ' ); ">
<%=rs("btopic")%></a>			
			
			
		<%
		end if
		response.write "&nbsp;</b></font></td>"
		response.write "<td class=tsize8>Type : <font color='#996633'>"&rs("btype")&"</font>&nbsp;"
		response.write "File : "&bfile&"<font color='#666666'> size </font>"&rs("bsize")&"<font color='#666666'> byte </font>&nbsp;"
		response.write "</td></tr>"
		response.write "<tr><td colspan=2></td>"
		response.write "<td class=tsize8>"
		response.write "</td></tr></table>"
		response.write "</td></tr>"
		rs.movenext
		m=m+1
		loop
		response.write "</table>"
	end if	
	end if	
else
response.write "����բ�����"
end if
con.close
%>
</td></tr></table>
</center>
</body>
</html>