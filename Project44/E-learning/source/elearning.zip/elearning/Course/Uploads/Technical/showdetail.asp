<html>
<head>
<link href="../../../board.css" rel="stylesheet" type="text/css">
<link href="../../../Style.css" rel="stylesheet" type="text/css">
<link href="../../../select.css" rel="stylesheet" type="text/css">
<link href="../../../font.css" rel="stylesheet" type="text/css">
<link href="../../../link.css" rel="stylesheet" type="text/css">
<title>��������´�ͧ�Ԫ�</title>
</head>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<body>
<center>
<br>
<form method="POST" action="del_file.asp">
<table border="0" cellspacing="0" style="border-collapse: collapse" width="550" id="AutoNumber1">
  <tr>
    <td>
<!--#include virtual="/../../../conn.asp"-->
<%
if request.querystring("subject_id")<>"" then
subject_id=request.querystring("subject_id")
set	rs=server.createobject("adodb.recordset")
	sql="select * from esub_topics where subject_id='"&subject_id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
	response.write "<table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='100%' >"
	response.write "<tr><td colspan='2' class=tsize12><b> <img src='../../CLSS13B1.GIF'>&nbsp;"&rs("sname")&"</b></td></tr>"
	response.write "<tr bgcolor='#F5F5F5'><td class=tsize8 width='50' align=right valign=top>Detail :</td>"
	response.write "<td class=tsize8 width='450'>"&rs("sdetail")&"<hr size='1'>"
	response.write "<font color='#666666'>Create </font>"&rs("sdate")&"<font color='#666666'> Last Update </font>"&rs("supdate")&"</td></tr><tr>"
	response.write "<td></td>"
	response.write "<td>"
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%'>"
		response.write "<tr><td  class=tsize8 bgcolor='#F0F0F0' width='70' >&nbsp;<font color='#cc0066'><b>"&rs("sgroup")&"</b></font></td>"
		response.write "<td width='150' align=right class=tsize8 >"
		if mode="2" or mode="3" then
		response.write "<a title='�ù��' href='../../Test/Test1/test14teacher.asp?subject_id="&rs("subject_id")&"'>Test 1</a>"
		else
		response.write "<a title='�ù��' href='../../Test/Test1/test14student.asp?subject_id="&rs("subject_id")&"'>Test 1</a>"
		end if
		response.write "&nbsp;&nbsp;(17/20)</td>"
		response.write "<td width='150' align=right class=tsize8><a title='�ѵ���' href=''>Test 2</a>&nbsp;&nbsp;(5/20)</td>"
		response.write "<td width='100' align=right class=tsize8>"
		response.write "</td><td align=right class=tsize8 >"
		response.write "</td></tr></table>"
	response.write "</td>"
	response.write "</tr></table>"	
	if mode="1" then
		response.write "<br>"
	else
		response.write "<table border='0' width='100%'  style='border-collapse: collapse' bordercolor='#111111' cellpadding='0' cellspacing='0'><tr>"
		response.write "<td class=tsize8>"
		response.write "����͡"
		response.write "</td><td class=tsize8 align=right><a href='main.asp?idxt="&gidx&" '>����������</a></td></tr></table>"
	end if
	end if
	rs.close
	sql="select * from esub_detail where subject_id='"&gidx&"'"
	rs.open sql,con,3,3
	if rs.eof then 
		response.write "<table border='0'><tr><td class=tsize8>����բ�����</td></tr></table>"
	else
		response.write "<table border='0' width='100%' cellpadding='0' cellspacing='0' style='border-collapse: collapse' >"
		rs.movefirst
		do while not rs.eof 
		response.write "<tr><td>"
		bfile=rs("bfile")
		a=len(bfile)
		b=InstRrev(bfile,"}")
		c=a-b
		bfile=Right(bfile,c)
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse'><tr>"
		response.write "<td width='20'>"
		if mode="1" then
			response.write "<img src='../../../Image/NOTEBK01.gif' width='15' height='15'>"
		else%>
			<input type=checkbox name='del<%=rs("detail_id")%>' value='on'>
		<%end if
		response.write "</td>"		
		response.write "<td><font color='#006699'><b>"
		response.write "<a class=al target=_blank href='TempData/"&rs("bpath")&"'>"&rs("btopic")&"</a>"
		response.write "&nbsp;</b></font></td>"
		response.write "<td class=tsize8>Type : <font color='#996633'>"&rs("btype")&"</font>&nbsp;"
		response.write "File : "&bfile&"<font color='#666666'> size </font>"&rs("bsize")&"<font color='#666666'> byte </font>&nbsp;"
		response.write "</td></tr>"
		response.write "<tr><td colspan=2></td>"
		response.write "<td class=tsize8>"
		response.write "</td></tr></table>"
		response.write "</td></tr>"
		rs.movenext
		m=m+1
		loop
		response.write "</table>"
		
		if mode<>"1" then
			response.write "<table border='0' cellpadding='0' cellspacing='0' width='550'>"
			response.write "<tr><td></TD></TR>"
			response.write "<tr><td>"
			response.write "<input  type=hidden name=topic value='"&gidx&"'>"
			response.write "<input  type=hidden name=action value=dele>"
			response.write "<input style='HEIGHT: 20px; WIDTH: 50px' class=tsize8 type='submit' name=del value=����͡ onclick='return conf(this)'>"
			response.write "</td></tr></table>"
		end if
	end if	
else
response.write "����բ�����"
end if
con.close
%>
</td></tr></table>
</form>
</center>
</body>
</html>