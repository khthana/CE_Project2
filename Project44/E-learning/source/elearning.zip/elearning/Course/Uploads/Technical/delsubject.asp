
<head>
<meta HTTP-EQUIV="REFRESH">
<link href="../Style.css" rel="stylesheet" type="text/css">
<link href="../../../select.css" rel="stylesheet" type="text/css">
<link href="../../../font.css" rel="stylesheet" type="text/css">
<title>New Document</title>
</head>

<!--#include virtual="/../../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
if request.cookies("member_id")<>"" then
id=request.cookies("member_id")
if request.form("action")="del4teacher" or request.form("action")="del4admin" then
if request.form("action")="del4teacher" then
	sql="select subject_id,sname from esub_topics where member_id='"&id&"'"
elseif request.form("action")="del4admin" then
	sql="select subject_id,sname from esub_topics"
end if
	rs.open sql,con,3,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
		if request.form("del"&rs("subject_id"))="on" then
			RootFolderName = Server.MapPath(".") & "/TempData/"&rs("sname")
			'ź Folder
			file_folder = RootFolderName
			set fso=CreateObject("Scripting.FileSystemObject")
			set a=fso.GetFolder(file_folder)
			a.delete		'ź Folder
				con.execute("delete esub_detail where subject_id='"&rs("subject_id")&"' ")
				con.execute("delete ecourse_list where subject_id='"&rs("subject_id")&"' ")	
			rs.delete																
		end if
		rs.movenext
		loop
	end if
	rs.close
elseif request.form("action")="del4student" then
	sql="select subject_id from ecourse_list"
	rs.open sql,con,3,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
		if request.form("del"&rs("subject_id"))="on" then
			rs.delete																
		end if
		rs.movenext
		loop
	end if
	rs.close
end if			'�����͹� action
end if			'�����͹���Ҫԡ
con.close
if request.form("action")="del4teacher" then
	response.redirect "editsub4teacher.asp"
elseif request.form("action")="del4admin" then
	response.redirect "editsub4admin.asp"
elseif request.form("action")="del4student" then
	response.redirect "course4student.asp"
end if
%>