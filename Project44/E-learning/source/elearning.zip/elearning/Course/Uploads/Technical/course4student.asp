<html>

<head>
<link href="../../../board.css" rel="stylesheet" type="text/css">
<link href="../../../Style.css" rel="stylesheet" type="text/css">
<link href="../../../select.css" rel="stylesheet" type="text/css">
<link href="../../../font.css" rel="stylesheet" type="text/css">
<link href="../../../link.css" rel="stylesheet" type="text/css">
<title>New Document</title>
<base target="_self">
</head>

<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}

function toPage(select) {
		location='sublist.asp?Page=' + select.options[select.selectedIndex].value  }

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
<body>
<center>
<form method="POST" action="delsubject.asp">
<table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="550" id="AutoNumber1" height="100%">
  <tr>
    <td valign="top">
    <br>
<%
psize=10		'��˹�����ʴ��� 10 ����ͧ��� 1 ˹��

if request.cookies("member_id")<>"" then
id=request.cookies("member_id")
texttop="Course ���سŧ����¹����"
%>
<!--#include virtual="/../../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
	sql="select count(*) as 'total' from ecourse_list where member_id='"&id&"'"
	rs.open sql,con,3,3
	totalrecord=rs("total")		'�ӹǹ record ������
	rs.close
	sql="select *  from ecourse_list,esub_topics where ecourse_list.member_id='"&id&"' and ecourse_list.subject_id=esub_topics.subject_id"
	rs.open sql,con,3,3
	If Request.QueryString("Page")="" Then
   		Page=1
	Else
   		Page=CInt(Request.QueryString("Page"))   ' ����ŧ�����º��º��������
	End If
	if (totalrecord Mod psize)<>0 then
		totalpage=(totalrecord\psize)+1  	'page
	else
		totalpage=(totalrecord\psize)
	end if
response.write "<table border='0' cellpadding='0' cellspacing='0' width='100%' bordercolor=red style='border-collapse: collapse' >"
response.write "<tr><td class=tsize12><img border='0' src='../../CLSS13B1.GIF'>&nbsp;<b>"&texttop&"</b></td></tr></table>"
response.write "<table border='0' width='100%'><tr><td align='right' class=tsize8>"&psize&" Course : 1 Page&nbsp;"
response.write "<select class=tsize8 size=1 onChange='toPage(this)'>"
 	For i=1 To totalpage
response.write "<option value=" & i  
	If i=Page Then 
     	response.Write " selected" 
     End If
      	response.Write ">" & i
   	Next
response.write "</select>"
response.write " �ҡ�ӹǹ <font color='RED'><b>"&totalpage&"</b></font> ˹��</td></tr></table>"
	if rs.eof then 
		response.write "<table border='0' cellspacing='0' cellpadding='0' width='100%' bordercolor=red style='border-collapse: collapse'><tr><td>����բ�����</td></tr></table>"
	else
	rs.movefirst
	if Page<>1 then
		rs.move ((psize*page)-psize)
	end if
	response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='550'>"
	response.write "<tr><td class=tsize8  align=right>ź&nbsp;</td>"
	response.write "</tr></table>"
	response.write "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='550' id='AutoNumber1' bgcolor='#F5F5F5'>"
	response.write "<tr><td>"
	m=1
	do while not rs.eof and m<=psize
%>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='550' id='AutoNumber1'>
<tr>
    <td width='30' align=center>
    <img border='0' src='../../../Image/bookclose.gif' name='number<%=rs("subject_id")%>'> </td>
    <td>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='500'>
<tr><td width='230'>
	<a class=al  title="����������´" <a href=detail4student.asp?subject_id=<%=rs("subject_id")%> 	onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('number<%=rs("subject_id")%>','','../../../Image/bookopen.gif',1)">
    <b><%=rs("sname")%></b></a> &nbsp;
	</td>
	<td class=tsize8 width='160'><font color='#666666'>Update :&nbsp;</font><%=rs("supdate")%></td>
	<td class=tsize8 width='110' >ŧ����¹���� :&nbsp;
	<%
	set	rc=con.execute("select count(*) as 'total' from ecourse_list where subject_id='"&rs("subject_id")&"' ")
		response.write rc("total")
	%>
	</td>
	</tr></table>
    	</td>
    	<td width='20' align=center>
		<input type=checkbox name='del<%=rs("subject_id")%>' value='on' >
    </td>
    </tr>
    <tr>
    <td colspan=3 bgcolor='#FFFFFF'></td>
    </tr>
    </table>
<%	rs.movenext
		m=m+1
		loop
		response.write "</td></tr></table><br>"
			response.write "<table border='0' cellpadding='0' cellspacing='0' width='100%'>"
			response.write "<tr><td align=right>"
			response.write "<input  type=hidden name=action value=del4student>"
			response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value=����͡ onclick='return conf(this)'>"
			response.write "</td></tr></table>"
	end if
%>
    </td>
  </tr>
</table>
</form>
</center>
</body>
</html>
<%
rs.close
con.close
end if
%>