<%@ENABLESESSIONSTATE=FALSE%> <%
'******************************************************************************
'Copyright Dundas Software Ltd. 2000. All Rights Reserved.
'
'PURPOSE:           The user can try uploading files to the server using 
'                    different settings for the Dundas Upload control.
'
'POST DESTINATION:  UplLimitAction.asp.           
'
'Dundas Software Contact Information:
'	Email:	sales@dundas.com
'   Phone:	(800) 463-1492
'			(416) 467-5100
'	Fax:	(416) 422-4801
'******************************************************************************
Response.Expires = -10000
%>
<html>

<head>
<script Language="javascript">
<!--
function CheckForCookiesOn()
{
//checks to see if browser has cookie support enabled,
//	if not an alert box is displayed, letting user know we need cookies
//also returns true if cookies disabled, otherwise false is returned	
	var blnCookiesSupported = false;
	
	//set the cookie
	document.cookie = 'testit' + "=" + escape('hi') + ";"
	
	//now attempt to retrieve the cookie
	var aCookie = document.cookie.split(";");
	for (var i=0; i < aCookie.length; i++)
	{ 
		var aCrumb = aCookie[i].split("=");
		if ('testit' == aCrumb[0])
		{
			blnCookiesSupported=true; 
			return false; 
		}	
		if (blnCookiesSupported==false){
			alert('For the progress bar to function correctly (for this particular demo) your browser must be set up so that it utilizes cookies.\nPlease note that cookie support is not required for the Progress Bar itself.');
			return true;
		}
	}
}
//-->
</script>
<link href="../Style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../../../font.css">
</head>

<body>

<%
on error resume next

'create UploadProgress object
set UplProg = Server.CreateObject("Dundas.UploadProgress")
'set the StateServer IP address
'UplProg.StateServer = "127.0.0.1"
'retrieve a new progress ID
NewProgressID = UplProg.GetNewProgressID
set UplProg = nothing

if Err <> 0 then
	NewProgressID = -1
	'display an error message
	'Response.Write "<P style='BACKGROUND-COLOR: #a52a2a'><FONT color=#ffffff>"
	'Response.Write "&nbsp;&nbsp;" & "State Server Error:  " & Err.description & "&nbsp;&nbsp;Progress bar will be disabled!</FONT></P>"
end if
%>
<script>
NewID = <%=NewProgressID%>;
function dorefresh()
{
	var CookiesOff;
	
	//if cookies are not enabled let user know that browser must be supporting cookies for this demo to run ok
	CookiesOff = CheckForCookiesOn();	
		
		
	if( NewID != -1 && String(window.document.cookie).indexOf("RefreshProgressID=TRUE") != -1 )
		window.location.reload(1);
	window.document.cookie = "RefreshProgressID=FALSE";


	if (CookiesOff == true){
	//by setting the ProgressID to -1 we make sure progress bar will not be displayed by the Upload function below	
		NewID = -1;
	}	
}
	
function upload()
{ 
	if (NewID != -1){	
	//only open progressbar.asp window if cookies are enabled, since we are using cookies
	//   to store a boolean (RefreshProgressID) to store the ProgressID (identifies this particular upload operation)
		window.document.cookie = "RefreshProgressID=TRUE";
		Param = "SCROLLBARS=no,RESIZABLE=no, TOOLBAR=no,STATUS=no,MENUBAR=no,WIDTH=400,HEIGHT=100";
		Param += ",TOP=" + String(window.screen.Height/2 - 50);
		Param += ",LEFT=" + String(window.screen.Width/2 - 200);
		window.open("ProgressBar.asp?ProgressID=<%=NewProgressID%>" , null, Param);
	}	
	
	document.UploadForm.action = "UploadDemoAction.asp?ProgressID=<%=NewProgressID%>"
	document.UploadForm.submit();
}

//make sure irregardless of how user gets here (e.g. Back button) that a new id is generated
//  every time the page is loaded. 
window.onload = dorefresh;
</script>
<!--#include virtual="/../../../conn.asp"--><%
subject_id=request.querystring("subject_id")
	set	rs=server.createobject("adodb.recordset")
	sql="select * from esub_topics where subject_id=('"&subject_id&"') "
	rs.open sql,con,0,3
	subject_id=rs("subject_id")
	skind=rs("sgroup")
	sname=rs("sname")
	sdate=rs("sdate")
	supdate=rs("supdate")
	rs.close
	sql="select sum(bsize) as 'usesize' from esub_detail where subject_id='"&subject_id&"'"	
	rs.open sql,con,0,3
		used=rs("usesize")
	rs.close
	con.close
%>
<center><br>
<table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#FF0000" width="550" id="AutoNumber1">
  <tr>
    <td>
    <table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FF3300" width="100%" bgcolor="#D6E7EF">
      <tr>
        <td width="100%" >&nbsp;<b>���� �����¹</b></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td width="100%" valign="top">
    <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
      <tr>
        <td width="100%">
        <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber3">
          <tr>
            <td width="150" class="tsize8">
            <p align="right"><font color="#0000FF"><b>SUBJECT NAME :</b></font></p>
            </td>
            <td>&nbsp;<b><%=sname%></b></td>
          </tr>
          <tr>
            <td width="150" class="tsize8">
            <p align="right"><font color="#0000FF"><b>Create <span lang="en-us">
            :</span></b></font></p>
            </td>
            <td class="tsize8">&nbsp;<%=sdate%></td>
          </tr>
          <tr>
            <td width="150" class="tsize8">
            <p align="right"><font color="#0000FF"><b>Last Update<span lang="en-us"> 
            :</span></b></font></p>
            </td>
            <td class="tsize8">&nbsp;<%=supdate%></td>
          </tr>
          <tr>
            <td width="150" class="tsize8">
            <p align="right"><font color="#0000FF"><b>Use Size<span lang="en-us"> 
            :</span></b></font></p>
            </td>
            <td class="tsize8">&nbsp;<%=used%> Byte</td>
          </tr>
        </table>
        <hr color="#3399FF" size="1"></td>
      </tr>
      <tr>
        <td width="100%">
        <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5">
          <tr>
            <td width="300">
            <!------------------------------------------------------------------------------------->
            <form name="UploadForm" action="UploadDemoAction.asp" encType="multipart/form-data" method="post" style="BORDER-BOTTOM: thin; BORDER-RIGHT-STYLE: none">
              <input ID="UniqueNames" NAME="UniqueNames" TYPE="hidden" value="ON">
              <input NAME="FolderName" TYPE="hidden" value="<%=sname%>" style="WIDTH: 94px" size="20">
              <input NAME="MaxUpload" TYPE="hidden" VALUE="50000" style="WIDTH: 94px" size="20">
              <input NAME="MaxFiles" TYPE="hidden" VALUE="1" style="WIDTH: 94px" size="20">
              <input NAME="MaxSize" TYPE="hidden" VALUE="50000" style="WIDTH: 94px" size="20">
              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="26%" id="AutoNumber2" height="124">
                <tr>
                  <td width="33%" height="19"><b><font color="#0000FF">&nbsp;���͡�������ͧ
                  <span lang="en-us">file </span>��� <span lang="en-us">Upload</span></font></b></td>
                </tr>
                <tr>
                  <td width="33%" height="14">
                  <p><select class="textbox" size="1" name="type">
                  <option value="">Select Type</option>
                  <option value="Vedio">Vedio *.asf</option>
                  <option value="Acrobat">Acrobat File *.pdf</option>
                  <option value="Powerpoint">Powerpoint *.ppt</option>
                  </select></p>
                  </td>
                </tr>
                <tr>
                  <td width="33%" height="18"><b><font color="#0000FF">&nbsp;��駪����������ͧ</font></b></td>
                </tr>
                <tr>
                  <td width="33%" height="13">
                  <p><input class="textbox" type="text" name="bname" size="43"></p>
                  </td>
                </tr>
                <tr>
                  <td width="33%" height="19"><b>&nbsp;<font color="#0000FF">���͡
                  </font></b><span lang="en-us"><b><font color="#0000FF">file</font></b>
                  </span></td>
                </tr>
                <tr>
                  <td width="33%" height="17">
                  <input class="textbox" type="file" name="file1" size="29"></td>
                </tr>
                <tr>
                  <td width="33%" height="24">
                  <p align="center">
                  <input class="sbttn" TYPE="button" VALUE="Upload File(s)" ONCLICK="upload()">
                  </p>
                  </td>
                </tr>
              </table>
            </form>
            <!------------------------------------------------------------------------------------->
            </td>
            <td valign="top">
            <!------------------------------------------------------------------------------------->
            <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%"  height=100% id="AutoNumber4">
              <tr>
                <td width="100%" bgcolor="#D6E7EF">&nbsp;<span lang="th">���й�</span></td>
              </tr>
              <tr>
                <td width="100%" class="tsize8">
                <ul>
                  <li><span lang="th">���͡ </span>Type <span lang="th">�����������Ѻ
                  </span>File <span lang="th">���</span> Upload</li>
                  <li><span lang="th">��駪����������ͧ㹡�ù��ʹ�</span></li>
                  <li><span lang="th">�ӡ�� </span>Browse File <span lang="th">���зӡ��
                  </span>Upload</li>
                </ul>
                </td>
              </tr>
            </table>
            <!------------------------------------------------------------------------------------->
            </td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center>

</body>

</html>