<body>
<%
skind=request.form("kind")
sname=request.form("namesubject")
sdetail=request.form("sdetail")
sdetail=replace(sdetail,chr(13),"<br>")
stime=Cint(request.form("stime"))
if skind="" then
	response.write"<script language='javascript'>"
	response.write"alert('Select Type Present');"
	response.write"history.back(1);"
	response.write"</script>"
elseif sname="" then
	response.write"<script language='javascript'>"
	response.write"alert('Insert Subject Present');"
	response.write"history.back(1);"
	response.write"</script>"
else%>
<!--#include virtual="/../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
	sql="select * from esub_topics where sname='"&sname&"'"
	rs.open sql,con,1,3
	if rs.eof then
		'���ҧ Directory
		RootFolderName = Server.MapPath(".") & "\technical\TempData\"
		call addnewfolder(RootFolderName,sname)
		sub addnewfolder(path,foldername)
		dim fso, f, fc, nf
		set fso = CreateObject("Scripting.filesystemObject")
		set f = fso.GetFolder(path)
		set fc = f.Subfolders
		if foldername<>"" then
			set nf = fc.Add(foldername)
		end if
		end sub

		rs.addnew
			rs("sgroup")=skind
			rs("sname")=sname
			rs("sdetail")=sdetail
			rs("sdate")	=now
			rs("supdate")=now
			rs("member_id")=Cint(request.cookies("member_id"))
		rs.update
	else
		response.write"<script language='javascript'>"
		response.write"alert('Name to Use');"
		response.write"history.back(1);"
		response.write"</script>"
	end if
	rs.close
	sql="select subject_id from esub_topics where sname='"&sname&"'"
	rs.open sql,con,1,3
	subject_id=rs("subject_id")
	rs.close
con.close
response.redirect "technical/detail4update.asp?subject_id="&subject_id
end if
%>
</body>