<html>
<head>
<meta http-equiv="REFRESH">
<link rel="stylesheet" type="text/css" href="../font.css" >
<title>Detail Course</title>
<base target="_self">
</head>
<body>
<br>
<center>
<table border="0" cellspacing="0" style="border-collapse: collapse" width="550" id="AutoNumber1" bordercolor="#FF0000" cellpadding="0">
<tr><td>
<!--#include virtual="/../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")

If Request.QueryString("subject_id")<>"" Then
subject_id=Request.QueryString("subject_id")
	sql="select * from esub_topics where subject_id='"&subject_id&"'"
	rs.open sql,con,3,3
	if not rs.eof then
	response.write "<table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='100%' >"
	response.write "<tr><td colspan='2'  class=tsize12><b> <img src='CLSS13B1.GIF'> "&rs("sname")&"</b></td></tr>"
	response.write "<tr bgcolor='#F5F5F5'><td class=tsize8 width='50' align=right valign=top>Detail :</td>"
	response.write "<td class=tsize8 width='450'>"&rs("sdetail")&"<hr size='1'>"
	response.write "<font color='#666666'>Create </font>"&rs("sdate")&"<font color='#666666'> Last Update </font>"&rs("supdate")&"</td></tr><tr>"
	response.write "<td></td>"
	response.write "<td>"
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%'>"
		response.write "<tr><td  class=tsize8 bgcolor='#F0F0F0' width='70' >&nbsp;<font color='#cc0066'><b>"&rs("sgroup")&"</b></font></td>"
		response.write "<td  align=right class=tsize8 >&nbsp;</td>"
		response.write "<td width='80' align=right class=tsize8></td>"
		response.write "<td width='50' align=right class=tsize8>"
		response.write "</td><td width='120' align=right class=tsize8>"
		response.write "</td></tr></table>"
	response.write "</td>" 
	response.write "</tr></table><br>"	
	end if
	rs.close
	sql="select * from esub_detail where subject_id='"&subject_id&"'"
	rs.open sql,con,3,3
	if not rs.eof then
		rs.movefirst
		response.write "<table border='1' width='100%' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#EFEFEF' >"
		do while not rs.eof
		bfile=rs("bfile")
		a=len(bfile)
		b=InstRrev(bfile,"}")
		c=a-b
		bfile=Right(bfile,c)
		response.write "<tr><td>"
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse'>"
		response.write "<tr><td><img src='../Image/NOTEBK01.gif' width='15' height='15'></td>"
		response.write "<td>&nbsp;<font color='#006699'><b>"&rs("btopic")&"&nbsp;</b></font></td>"
		response.write "<td class=tsize8>Type : <font color='#993399'>"&rs("btype")&"</font>&nbsp;</td>"
		response.write "<td class=tsize8>File : "&bfile&"<font color='#666666'> size </font>"&rs("bsize")&"<font color='#666666'> byte </font>&nbsp;</td>"
		response.write "</tr></table>"
		response.write "</td></tr>"		
		rs.movenext
		loop
		response.write "</table>"
	end if
	rs.close
End If

%>
</td></tr></table>
<br><input class=tsize8 style='HEIGHT: 20px; WIDTH: 70px' type='button'  value=Back onclick='javascript:history.back();'>
</center>
</body></html>
<%
con.close
%>