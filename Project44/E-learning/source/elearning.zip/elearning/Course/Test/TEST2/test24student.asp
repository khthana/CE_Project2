<link rel='stylesheet' type='text/css' href='../../../board.css'>
<link rel='stylesheet' type='text/css' href='../../../font.css'>
<link rel='stylesheet' type='text/css' href='../../../link.css'>
<script language="JavaScript">
function conf(object){
	if (confirm("Are you Sure!!")==true){
	return true;
	}
return false;
}
</script>
<br>
<center>
<!--#include virtual="/../../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
ID=request.cookies("member_id")
subject_id=request.querystring("subject_id")
	sql="select * from esub_topics where subject_id='"&subject_id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		response.write "<center><table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='550' >"
	response.write "<tr><td colspan='2' class=tsize12><b> <img src='../../CLSS13B1.GIF'>&nbsp;"&rs("sname")&"</b></td></tr>"
	response.write "<tr bgcolor='#F5F5F5'><td class=tsize8 width='50' align=right valign=top>Detail :</td>"
	response.write "<td class=tsize8 width='450'>"&rs("sdetail")&"<hr size='1'>"
		response.write "<font color='#666666'>Create </font>"&rs("sdate")&"<font color='#666666'> Last Update </font>"&rs("supdate")&"</td></tr><tr>"
	response.write "</tr></table></center>"	
	end if
	rs.close
	
if ID<>"" then
	sql="select status from emember where member_id='"&ID&"'"
	rs.open sql,con,0,3
		permit=rs("status")
	rs.close
else	
	permit=""
end if
	sql="select * from etest2 where subject_id='"&subject_id&"'"
	rs.open sql,con,0,3
if not rs.eof then
	response.write "<form method='POST' action='resulttest2.asp'>"
	response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='500'>"
	response.write "<tr>"
	response.write "<td width='25' align=center><b><font color='#0000FF'>�١</font></b></td>"
	response.write "<td width='25' align=center><font color='#FF0000'><b>�Դ</b></font></td>"
	response.write "<td >&nbsp;<font color='#009933'><b>�Ӷ��?</b></font></td></tr>"		
	response.write "<tr><td colspan='4' height='1' bgcolor='#FF0000'></td></tr>"
	rs.movefirst
	do while not rs.eof
%>
<tr>
<td width='25' align=center><input type='radio' name='ans<%=rs("test2_id")%>' value='1'></td>
<td width='25' align=center ><input type='radio'name='ans<%=rs("test2_id")%>' value='2'></td>
<td ><%=rs("ask")%></td></tr>
<tr><td colspan='4' height='1' bgcolor='#0099FF'></td></tr>
<%
	rs.movenext
	loop
	response.write "</table>"
	response.write "<table border='0' cellpadding='0' cellspacing='0' width='500'>"
	response.write "<tr><td></TD></TR>"
	response.write "<tr><td>"
	response.write "<input  type=hidden name='id_sub' value='"&subject_id&"'>"
		response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value=��ŧ onclick='return conf(this)'>"
	response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='reset' name=del value=¡��ԡ>"
		response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='Button' value='��͹��Ѻ' onclick='javascript:history.back();'>"
	response.write "</td></tr></table>"
	response.write "</form>"
else
response.write "<table border='0' cellpadding='2' style='border-collapse: collapse' width='400' >"
response.write "<tr><td align=center>"
response.write "<font color=RED><b>*Ẻ���ͺ�ѧ�������    Test not ready!!!!</b></font>"
response.write "</td></tr></table>"
response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='Button' value='��͹��Ѻ' onclick='javascript:history.back();'>"
end if
%>
</form>
</center>
<%
con.close
%>