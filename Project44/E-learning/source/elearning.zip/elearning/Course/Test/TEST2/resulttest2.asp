<!--#include virtual="/../../../conn.asp"-->
<%
ID=request.cookies("member_id")
id_sub=request.form("id_sub")
set	rs=server.createobject("adodb.recordset")
	sql="select * from etest2 where subject_id='"&id_sub&"' "
	rs.open sql,con,1,3
	if not rs.eof then
		rs.movefirst
		totalans=0
		do while not rs.eof
			result=request.form("ans"&rs("test2_id"))
			if Strcomp(result,rs("ans"))=0 then
				totalans=totalans+1	
			end if
		rs.movenext
		loop
	end if
	rs.close
	sql="select * from eresult_2 where subject_id='"&id_sub&"' and member_id='"&ID&"'"
	rs.open sql,con,1,3
	if not rs.eof then
		rs("result_2")=totalans		
		rs.update
	else
		con.execute "Insert into eresult_2(member_id,subject_id,result_2) values('"&ID&"','"&id_sub&"','"&totalans&"')"			
	end if
	rs.close
con.close
response.write totalans
response.redirect "../../Uploads/Technical/detail4student.asp?subject_id="&id_sub
%>