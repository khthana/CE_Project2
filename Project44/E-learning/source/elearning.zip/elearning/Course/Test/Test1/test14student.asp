<link rel='stylesheet' type='text/css' href='../../../board.css'>
<link rel='stylesheet' type='text/css' href='../../../font.css'>
<link rel='stylesheet' type='text/css' href='../../../link.css'>
<script language="JavaScript">
function conf(object){
	if (confirm("Are you Sure!!")==true){
	return true;
	}
return false;
}
</script>
<br>
<center>
<form Action='resulttest1.asp' Method='Post'>
<!--#include virtual="/../../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
ID=request.cookies("member_id")
subject_id=request.querystring("subject_id")
	sql="select * from esub_topics where subject_id='"&subject_id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		response.write "<center><table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='550' >"
	response.write "<tr><td colspan='2' class=tsize12><b> <img src='../../CLSS13B1.GIF'>&nbsp;"&rs("sname")&"</b></td></tr>"
	response.write "<tr bgcolor='#F5F5F5'><td class=tsize8 width='50' align=right valign=top>Detail :</td>"
	response.write "<td class=tsize8 width='450'>"&rs("sdetail")&"<hr size='1'>"
		response.write "<font color='#666666'>Create </font>"&rs("sdate")&"<font color='#666666'> Last Update </font>"&rs("supdate")&"</td></tr><tr>"
	response.write "</tr></table><br></center>"	
	end if
	rs.close

if ID<>"" then
	sql="select status from emember where member_id='"&ID&"'"
	rs.open sql,con,0,3
		permit=rs("status")
	rs.close
else	
	permit=""
end if
	sql="select * from etest1 where subject_id='"&subject_id&"'"
	rs.open sql,con,0,3
	if not rs.eof then
	rs.movefirst
	do while not rs.eof
%>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="400" >
  <tr>
    <td colspan='2' class='tsize12'>&nbsp;<b><font color='#0000CC'><%=rs("ask")%></font></b></td>
  </tr>
  <tr>
    <td width="20" align='right'><input type='radio' name='ans<%=rs("test1_id")%>' value='1' ></td>
    <td width="380" class=tsize8>&nbsp;<%=rs("choice1")%></td>
  </tr>
  <tr>
    <td width="20" align='right'><input type='radio'name='ans<%=rs("test1_id")%>' value='2' ></td>
    <td width="380" class=tsize8>&nbsp;<%=rs("choice2")%></td>
  </tr>
    <tr>
    <td width="20" align='right'><input type='radio' name='ans<%=rs("test1_id")%>' value='3'></td>
    <td width="380" class=tsize8>&nbsp;<%=rs("choice3")%></td>
  </tr>
    <tr>
    <td width="20" align='right'><input type='radio' name='ans<%=rs("test1_id")%>' value='4'></td>
    <td width="380" class=tsize8>&nbsp;<%=rs("choice4")%></td>
  </tr>
</table>
<%
	rs.movenext
	loop
%>	
<table border='0' cellpadding='2' style='border-collapse: collapse' width='400' >
  <tr>
    <td >
    <input type='hidden' name='id_sub' value=<%=subject_id%>>
    <input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value=��ŧ onclick='return conf(this)'>
    <input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='reset' name=del value=¡��ԡ>    
	<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='Button' value='��͹��Ѻ' onclick='javascript:history.back();'>

    </td>
  </tr>
</table>
<%
else
response.write "<table border='0' cellpadding='2' style='border-collapse: collapse' width='400' >"
response.write "<tr><td align=center>"
response.write "<font color=RED><b>*Ẻ���ͺ�ѧ�������    Test not ready!!!!</b></font>"
response.write "</td></tr></table>"
response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='Button' value='��͹��Ѻ' onclick='javascript:history.back();'>"
end if
%>
</form>
</center>

<%
con.close
%>