
<head>
<meta HTTP-EQUIV="REFRESH">
<link href="../../../Style.css" rel="stylesheet" type="text/css">
<link href="../../../select.css" rel="stylesheet" type="text/css">
<link href="../../../font.css" rel="stylesheet" type="text/css">

<title>New Document</title>
</head>

<!--#include virtual="/../../../conn.asp"-->
<%
if request.form("action")="dele" then
subject_id=Cint(request.form("subject_id"))
set	rs=server.createobject("adodb.recordset")
	sql="select test1_id from etest1 where subject_id='"&subject_id&"' "
	rs.open sql,con,1,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
			if request.form("del"&rs("test1_id"))="on" then
				rs.delete
			end if
		rs.movenext
		loop
	end if
	rs.close
end if
con.close
response.redirect "test14teacher.asp?subject_id="&subject_id
%>