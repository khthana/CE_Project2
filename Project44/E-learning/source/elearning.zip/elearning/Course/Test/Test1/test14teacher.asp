<link rel='stylesheet' type='text/css' href='../../../board.css'>
<link rel='stylesheet' type='text/css' href='../../../font.css'>
<link rel='stylesheet' type='text/css' href='../../../link.css'>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<br>
<center>
<!--#include virtual="/../../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
ID=request.cookies("member_id")
subject_id=request.querystring("subject_id")
	sql="select * from esub_topics where subject_id='"&subject_id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		response.write "<center><table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='550' >"
	response.write "<tr><td colspan='2' class=tsize12><b> <img src='../../CLSS13B1.GIF'>&nbsp;"&rs("sname")&"</b></td></tr>"
	response.write "<tr bgcolor='#F5F5F5'><td class=tsize8 width='50' align=right valign=top>Detail :</td>"
	response.write "<td class=tsize8 width='450'>"&rs("sdetail")&"<hr size='1'>"
		response.write "<font color='#666666'>Create </font>"&rs("sdate")&"<font color='#666666'> Last Update </font>"&rs("supdate")&"</td></tr><tr>"
	response.write "</tr></table></center>"	
	end if
	rs.close
if ID<>"" then
	sql="select status from emember where member_id='"&ID&"'"
	rs.open sql,con,0,3
		permit=rs("status")
	rs.close
else	
	permit=""
end if
	sql="select * from etest1 where subject_id='"&subject_id&"'"
	rs.open sql,con,0,3
	if not rs.eof then
	response.write "<form method='POST' action='del_test1.asp'>"
	rs.movefirst
	do while not rs.eof
%>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="400" id="AutoNumber1">
  <tr>
  	<td width="20"><input type=checkbox name='del<%=rs("test1_id")%>' value='on'></td>
    <td colspan='2' class='tsize12'>&nbsp;<b><%=rs("ask")%></b></td>
  </tr>
  <tr>
	<td width="20"></td>
    <td width="20" align='right'><input type='radio' name='ans<%=rs("test1_id")%>' value='1' <%if Cint(rs("ans"))=1 then response.write "checked" end if%>></td>
    <td width="380" class=tsize8>&nbsp;<%=rs("choice1")%></td>
  </tr>
  <tr>
  	<td width="20"></td>
    <td width="20" align='right'><input type='radio'name='ans<%=rs("test1_id")%>' value='2' <%if Cint(rs("ans"))=2 then response.write "checked" end if%>></td>
    <td width="360" class=tsize8>&nbsp;<%=rs("choice2")%></td>
  </tr>
    <tr>
  	<td width="20"></td>
    <td width="20" align='right'><input type='radio' name='ans<%=rs("test1_id")%>' value='3' <%if Cint(rs("ans"))=3 then response.write "checked" end if%>></td>
    <td width="360" class=tsize8>&nbsp;<%=rs("choice3")%></td>
  </tr>
    <tr>
  	<td width="20"></td>
    <td width="20" align='right'><input type='radio' name='ans<%=rs("test1_id")%>' value='4' <%if Cint(rs("ans"))=4 then response.write "checked" end if%>></td>
    <td width="360" class=tsize8>&nbsp;<%=rs("choice4")%></td>
  </tr>
</table>
<%
	rs.movenext
	loop
	response.write "<table border='0' cellpadding='0' cellspacing='0' width='400'>"
	response.write "<tr><td></TD></TR>"
	response.write "<tr><td>"
	response.write "<input  type=hidden name=subject_id value='"&subject_id&"'>"
	response.write "<input  type=hidden name=action value=dele>"
	response.write "<input style='HEIGHT: 20px; WIDTH: 50px' class=tsize8 type='submit' name=del value=����͡ onclick='return conf(this)'>"
	response.write "</td></tr></table>"
	response.write "</form>"
	end if
%>	
<form Action='addtest1.asp' Method='Post'>
<table border='0' cellpadding='2' style='border-collapse: collapse' width='400' bgcolor='#DEBCBC'>
  <tr>
    <td colspan="2" bgcolor="#6699CC">&nbsp;<b>����Ẻ���ͺ</b></td>
  </tr>
  <tr>
    <td align=right width=60><b>�Ӷ�� :</b></td>
    <td ><input class='tsize8' type='text' name='ask' size='60'></td>
  </tr>
  <tr>
    <td align=right><input type='radio' name='ans' value='1'></td>
    <td ><input class=tsize8 type='text' name='choice1' size='40'> </td>
  </tr>
  <tr>
    <td align=right><input type='radio' name='ans' value='2'></td>
    <td ><input class=tsize8 type='text' name='choice2' size='40'></td>
  </tr>
  <tr>
    <td align=right>
    <input type='radio' name='ans' value='3'></td>
    <td ><input class=tsize8 type='text' name='choice3' size='40'></td>
  </tr>
  <tr>
    <td align=right><input type='radio' name='ans' value='4'>
    </td>
        <td ><input class=tsize8 type='text' name='choice4' size='40'></td>
  </tr>
  <tr>
    <td align=right></td>
    <td >
    <input type='hidden' name='id_sub' value=<%=subject_id%>>
    <input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value=��ŧ>
    <input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='reset' name=del value=¡��ԡ>
	<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='Button' value='��͹��Ѻ' onclick='javascript:history.back();'>

    </td>
  </tr>
</table>
</form>
</center>
<%
con.close
%>