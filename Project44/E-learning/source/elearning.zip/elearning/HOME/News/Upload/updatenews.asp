<html>

<link rel="stylesheet" type="text/css" href="../../../board.css">
<link rel="stylesheet" type="text/css" href="../../../font.css">
<link rel="stylesheet" type="text/css" href="../../../link.css">
<head>
<title>News for Admin</title>
</head>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>

<body>
<br>
<center>
<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' width='550'>
<tr><td>
<form method="Post" action="del_news.asp">

<!--#include virtual="/../../../conn.asp"--><%
set	rs=server.createobject("adodb.recordset")
if request.cookies("member_id")<>"" then
id=request.cookies("member_id")
	sql="select status from emember where member_id='"&id&"' "
	rs.open sql,con,0,3
		status=Cint( rs("status") )
	rs.close
else
	status=1
end if
'----------------------------------------------------------------------------------------------
'�������Ţ��Ƿ�����
	if status=2 then
		sql="select * from enews where member_id='"&id&"' "
	elseif status=3 then
		sql="select * from enews order by ndate desc"
	else
		sql="select * from enews order by ndate desc"
	end if
	rs.open sql,con,3,3
		response.write "<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' width='100%'>"
		response.write "<tr><td width=350>"
		if status=2 then
				response.write "<input style='HEIGHT: 22px; WIDTH: 140px' class=input_button4 type='submit' name=del value='Delete For Me..' onclick='return conf(this)'>"
		elseif status=3 then
				response.write "<input style='HEIGHT: 22px; WIDTH: 180px' class=input_button4 type='submit' name=del value='Delete For Administrator' onclick='return conf(this)'>"
		end if
		response.write "</td><td align=right>"
		if id<>"" then
			response.write "<a href='main.asp'><font color='red'>��С�Ȣ���</font></a> "
		end if
		response.write "</td></tr></table><hr size=1>"

	if rs.eof then 
		response.write "<table border='0'><tr><td>����բ�����</td></tr></table>"
	else
		do while not rs.eof 
		response.write "<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' bordercolor='#C0C0C0' ><tr><td width=20 >"%>
		<input type=checkbox name='del<%=rs("news_id")%>' value='on' <%if id="" then response.write "disabled" end if%>>
<%
		response.write "</td><td>"
		response.write "<a class=al href=edit4news.asp?ID=" & rs("news_id") & ">" & rs("ntopic") & "</a>"
		response.write "</td>"
		response.write "<td class=tsize8>&nbsp;�¤س <font color='#993333'>"&rs("nuser")&"</font></td>"
		response.write "<td class=tsize8>&nbsp;"&rs("ndate")&"</td>"
		if rs("nfile")<>"" then
			response.write "<td>&nbsp;&nbsp;<img src='../../../Image/file.gif' title='file ���Ṻ��'></td>"	
		end if
		timetemp=Datediff("d" ,Cdate(rs("ndate")),now())
	  	if timetemp<3 then 
  			response.write "<td>&nbsp;<img border='0' src='../../../Image/new02.gif'></td>"
	  	end if
		response.write "</tr></table>"	
		rs.movenext
		loop
		response.write "<hr size=1><table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' width='100%'>"
		response.write "<tr><td width=350>"
		if id<>"" then
		response.write "<input  type=hidden name=action value=dele>"
		response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value='Delete' onclick='return conf(this)'>"
		end if
		response.write "</td><td align=right>"
		if id<>"" then
			response.write "<a href='main.asp'><font color='red'>��С�Ȣ���</font></a> "
		end if
		response.write "</td></tr></table><hr size=1>"
	end if
	rs.close
	Set rs=Nothing	
con.close
set con=Nothing
%>
</form>
</td></tr></table>
</center>
</body>
</html>