<html>
<link rel="stylesheet" type="text/css" href="../../../board.css">
<link rel="stylesheet" type="text/css" href="../../../font.css">
<head>
<meta http-equiv="Content-Language" content="en-us">
<title>NEWS</title>
</head>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<br>
<center>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='550' >
<tr><td>
<!--#include virtual="/../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
if request.cookies("member_id")<>"" then
	member_id=request.cookies("member_id")
	sql="select status from emember where member_id='"&member_id&"' "
	rs.open sql,con,0,3
		status=Cint( rs("status") )
	rs.close
else
	status=1
end if
if request.querystring("ID")<>"" then
	ID=Cint(request.querystring("ID"))
	sql="select * from enews where news_id='"&ID&"'"
else
	sql="select * from enews order by ndate desc"
end if
	rs.open sql,con,3,3
	if not rs.eof then
	rs.movefirst
	do while not rs.eof 
	With Response
	.write "<table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='550' >"
	.write "<tr><td colspan='2' bgcolor='#006699'>"
	.write "<b><font color=yellow>"&rs("ntopic")&"</font></b>"
	.write "</td></tr>"
	.write "<tr bgcolor='#F5F5F5'><td width='80' align=right valign=top><b>��������´ :</b></td>"
	.write "<td width='450'>"&rs("ndata")&"<hr size='1'>"
	.write "����С�� <font color=BLUE>"&rs("nuser")&"</font> ��С������� "&rs("ndate")&"</td></tr>"
	.write "<TR><td align=right  bgcolor='#F5F5F5'>File ���Ṻ��</td><td>"
	
	.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%' >"
	.write "<tr><td width='370'>	"	
	if StrComp(rs("nfile"),"")<>0 then
		.write "<a href=Upload/db/"&rs("nfile")&"><img border='0' src='../../../Image/file.gif' title='file ���Ṻ��'>&nbsp;"&rs("nfile")&"</a>"
	else
		.write "No File"
	end if
	if StrComp(member_id,rs("member_id"))=0 or status=3 then
		.write "<td align=right bgcolor='yellow' width='80'>"
		.write "<a href='del_news.asp?del="&rs("news_id")&" ' onclick='return conf(this)'><font color='#FF0000'>ź��С�ȹ��</font></a>&nbsp;"
	else
		.write "<td align=right width='80'>"
	end if
	.write "</td></tr></table>"	
	.write "</td></tr></table>"
	.write "<center><input type='button' class=tsize8 style='HEIGHT: 20px; WIDTH: 70px' value='GO BACK' onclick='javascript:history.back();'></center>"
	End With
	rs.movenext
	loop
	end if
rs.close
con.close
%>
</td></tr></table>
</center>