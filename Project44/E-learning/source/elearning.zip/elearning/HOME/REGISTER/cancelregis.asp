<!--#include virtual="/../../conn.asp"-->
<%
if request.cookies("member_id")<>"" then
id=request.cookies("member_id")
set	rs=server.createobject("adodb.recordset")
	sql="select member_id from emember where member_id='"&id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		rs.delete
	end if	 
	rs.close
	sql="select member_id from emember_01 where member_id='"&id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		rs.delete
	end if	 
	rs.close
	sql="select member_id from ecourse_list where member_id='"&id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		rs.delete
	end if	 
	rs.close
	sql="select member_id from etemp where member_id='"&id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		rs.delete
	end if	 
	rs.close
	sql="select member_id from eresult_1 where member_id='"&id&"' "
	rs.open sql,con,0,3
	if not rs.eof then
		rs.delete
	end if	 
	rs.close
	response.cookies("member_id")=""
	response.write "<script language='javascript'>"
	response.write "alert('�������Ҫԡ�ͧ�س��١¡��ԡ���º��������');"
	response.write "parent.location.href='../../index.htm'; "
	response.write "</script>"
end if
con.close
%>