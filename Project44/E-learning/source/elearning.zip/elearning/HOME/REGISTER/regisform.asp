<link rel="stylesheet" type="text/css" href="../../board.css">
<link rel="stylesheet" type="text/css" href="../../font.css">
<body>

<center>
<form Action="register.asp" Method="Post">
  <%'������Ѻ������ %>
  <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="550" id="AutoNumber1">
    <tr>
      <td><br>
      <table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FF0000" width="100%" bgcolor="#D6E7EF">
        <tr>
          <td>&nbsp;<b>��������������´����ǡѺ����ѵ���ǹ���</b></td>
        </tr>
      </table>
      <!-------------------------------------------------------->
      <table border="1" style="border-collapse: collapse" width="546" id="AutoNumber2" bgcolor="#F5F5F5" bordercolor="#FFFFFF" cellpadding="2">
        <tr>
          <td width="102" align="right">&nbsp;</td>
          <td width="433">
          &nbsp;</td>
        </tr>
        <tr>
          <td width="102" align="right">���� :</td>
          <td width="433">
          <input type="text" class="input_post" size="30" name="name" value="<%=request.form("name")%>">
          <b>#</b></td>
        </tr>
        <tr>
          <td width="102" align="right">���ʡ�� :</td>
          <td width="433">
          <input type="text" class="input_post" size="30" name="surname" value="<%=request.form("surname")%>">
          <b>#</b></td>
        </tr>
        <tr>
          <td width="102" align="right">�� :</td>
          <td width="433"><input type="radio" name="gender" value="M">���
          <input type="radio" name="gender" value="F">˭ԧ</td>
        </tr>
        <tr>
          <td width="102" align="right">�ѹ�Դ :</td>
          <td width="433">
          <select  name="date">
          <option value="">�ѹ</option>
          <%for i=1 to 31%>
          <option value="<%=i%>"><%=i%></option>
          <%next%>
          </select >,&nbsp;
          <select  name="month" >
          <option value="">��͹</option>
          <option value="1" >���Ҥ�<br></option>
          <option value="2" >����Ҿѹ��<br></option>
          <option value="3" >�չҤ�<br></option>
          <option value="4" >����¹<br></option>
          <option value="5" >����Ҥ�<br></option>
          <option value="6" >�Զع�¹<br></option>
          <option value="7" >�á�Ҥ�<br></option>
          <option value="8" >�ԧ�Ҥ�<br></option>
          <option value="9" >�ѹ��¹<br></option>
          <option value="10" >���Ҥ�<br></option>
          <option value="11" >��Ȩԡ�¹<br></option>
          <option value="12" >�ѹ�Ҥ�<br></option>
          </select>,&nbsp;
          <select  name="year">
          <option value="">��</option>
          <%
          syear=(year(date)+443)
          for i=syear to (year(date)+543)%>
          <option value="<%=i%>"><%=i%></option>
          <%next%>
          </select></td>
        </tr>
        <tr>
          <td width="102" align="right" valign="top">������� :</td>
          <td width="433">
          <textarea class="input_post" name="address" cols="50" rows='2' ></textarea></td>
        </tr>
        <tr>
          <td width="102" align="right">���Ѿ�� :</td>
          <td width="433">
          <input type="text" class="input_post" name="phone" size="30" value="<%=request.form("phone")%>"></td>
        </tr>
        <tr>
          <td width="102" align="right">ICQ :</td>
          <td width="433">
          <input type="text" class="input_post" size="30" name="icq" value="<%=request.form("icq")%>"></td>
        </tr>
        <tr>
          <td width="102" align="right" valign="top"><span lang="th">����֡��</span> :</td>
          <td valign="top" width="433">
          <select class="input_post" size="1" name="edu">
          <option value="">����֡��</option>
          <option value="͹غ��">͹غ��</option>
          <option value="��ж��֡��">��ж��֡��</option>
          <option value="�Ѹ����">�Ѹ����</option>
          <option value="�Ѹ������">�Ѹ������</option>
          <option value="�Ǫ.">�Ǫ.</option>
          <option value="���.">���.</option>
          <option value="��ԭ�ҵ��">��ԭ�ҵ��</option>
          <option value="��ԭ���">��ԭ���</option>
          <option value="��ԭ���͡">��ԭ���͡</option>
          <option value="�֡�ҵ�ҧ�����">�֡�ҵ�ҧ�����</option>
          <option value="����">����</option>
          </select> </td>
        </tr>
        <tr>
          <td width="102" align="right" valign="top"><span lang="th">��÷ӧҹ
          </span>:</td>
          <td valign="top" width="433">
          <textarea class="input_post" name="work" cols="50" rows='2' ></textarea></td>
        </tr>
        <tr>
          <td width="102" align="right"><span lang="th">��������ö&nbsp;&nbsp;<br>����� </span>:</td>
          <td width="433">
          <textarea class="input_post" name="able" cols="50" rows='2' ></textarea></td>
        </tr>
        <tr>
          <td width="102" align="right">&nbsp;</td>
          <td width="433">&nbsp;</td>
        </tr>
      </table>
      <!-------------------------------------------------------->
      </td>
    </tr>
    <tr>
      <td>
	    

      </td>
    </tr>
    <tr>
      <td>
      <!--------------------------------------------------------><br>
      <table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FF0000" width="100%" bgcolor="#FF9933">
        <tr>
          <td>&nbsp;<b>������<span lang="th">�ͧ�к�</span></b></td>
        </tr>
      </table>
      <table border="1" style="border-collapse: collapse" width="100%" id="AutoNumber2" bgcolor="#FFEEDD" bordercolor="#FFFFFF" cellpadding="2">
        <tr>
          <td width="100" align="right">&nbsp;</td>
          <td>
          &nbsp;</td>
      <td>
      </td>
        </tr>
        <tr>
          <td width="100" align="right">Status :</td>
          <td>
          <select class="input_post" size="1" name="etype" value=" 1" &gt; &lt;option selected value=" 1">
          <option value="1">Student</option>
          <option value="2">Teacher</option>
          <option value="3">Administrator</option>
          </select> </td>
          <td rowspan=2>
        <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" bgcolor="#FFCC99">
          <tr>
            <td><b>E-mail Address</b> <span lang="th">��᷹����㹡��
            </span><b>Log-in</b> <span lang="th">�ͧ��ҹ�����㹡�õԴ�����ѧ��Ҫԡ</span></td>
          </tr>
        </table>

		</td>
        </tr>
        <tr>
          <td width="100" align="right">���ͷ����&nbsp;&nbsp; <br>
          �ʴ���к� :</td>
          <td>
          <input type="text" class="input_post" name="usename" size="30" value="<%=request.form("usename")%>"></td>
        </tr>
        <tr>
          <td width="100" align="right"><span lang="en-us">E-mail Address</span> 
          :</td>
          <td>
          <input type="text" class="input_post" name="email" size="30" value="<%=request.form("email")%>"></td>
              	
    	          <td rowspan=3>
                <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber6" bgcolor="#FFCC99">
          <tr>
            <td><span lang="th">�س�е�ͧ�׹�ѹ </span><b>Password</b>
            <span lang="th">�ա����������������� </span>Password
            <span lang="th">�ͧ�س��͡�١��ͧ ��С�á�͡ </span>Password
            <span lang="th">��鹤���շ�駵���ѡ����е���Ţ����ѹ<font color="#FF0000"><b>�����¡��� 6 
            ���</b></font> </span>&nbsp;<span lang="th">���������ժ�ͧ��ҧ�����ҧ�Ӵ���</span></td>
          </tr>
        </table>
          
          
          </td>
        </tr>
        <tr>
          <td width="100" align="right"><span lang="en-us">Password :</span></td>
          <td>
          <input class="input_post" type="password" name="pwd" size="20" value="<%=request.form("pwd")%>"></td>
        </tr>
        <tr>
          <td width="100" align="right"><span lang="en-us">Re-Enter&nbsp;&nbsp;&nbsp; 
          Password :</span></td>
          <td><b>
          <input class="input_post" type="password" name="pwd2" size="20" value="<%=request.form("pwd2")%>"></b></td>
        </tr>
        <tr>
          <td width="100" align="right">&nbsp;</td>
          <td><input Type="Submit" class="input_button2" Value="ŧ����¹">
          <input Type="Reset" class="input_button2" Value="¡��ԡ"></td>
          </td>
          <td>
          </td>
        </tr>
      </table>
      <!--------------------------------------------------------></td>
    </tr>
  </table>
</form>
</center>
</form>

</body>