<meta http-equiv="Content-Language" content="en-us">
<link href="../../board.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../../font.css">
<script language="JavaScript">
function conf(object){
	if (confirm("Are you Sure?")==true){
	return true;
	}
return false;
}
</script>

<body>
<form Action="login.asp" Method="Post">
  <table border="0" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber1">
    <tr>
      <td valign=top>
      <table border="2" cellspacing="1" style="border-collapse: collapse" bordercolor="#FF0000" width="100%" id="AutoNumber4">
        <tr>
          <td width="100%"><b>&nbsp;<font face="Impact" size="6" color="#009933">Log-In</font><font face="Tahoma" color="#009933">
          </font><font face="Tahoma" color="#006699">TOOLS (<span lang="th">����ͧ������������к�</span>)</font></b></td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td align="center" valign="top">
      <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="550" id="AutoNumber2" height="94">
        <tr>
          <td width="150" height="16" bgcolor="#E1E1E1">&nbsp;</td>
          <td width="200" height="16" bgcolor="#E1E1E1">&nbsp;</td>
          <td width="200" height="16">&nbsp;</td>
        </tr>
        <tr>
          <td height="71" valign="bottom" align="right">
          <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="150" id="AutoNumber5">
            <tr>
              <td width="100%" bgcolor="#FFCC99">More information</td>
            </tr>
            <tr>
              <td width="100%">
              <ul>
                <li><span lang="th"><%if request.cookies("member_id")<>"" then%>
                <a href="../../Member/profile4student.asp">��䢢�������ǹ���</a> <%else%> 
                ��䢢�������ǹ��� <%end if%> </span></li>
                <li><span lang="th"><a href="../register/accept.asp">��Ѥ���Ҫԡ</a></span></li>
                <li><a href="../forget/fgform.asp"><span lang="th">��� </span>Password</a></li>
                <li><span lang="th"><a href="../register/cancelregis.asp" onclick='return conf(this)'>¡��ԡ �������Ҫԡ</a></span></li>
              </ul>
              </td>
            </tr>
          </table>
          </td>
          <td height="71" align=center>
		<!--#include file="logfrm.asp"-->
          </td>
          <td height="71">
          <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="200" id="AutoNumber3">
            <tr>
              <td width="100%" bgcolor="#FFCC99"><span lang="th">���й�</span></td>
            </tr>
            <tr>
              <td width="100%">
              <ul>
                <li><span lang="th">��� </span><b>E-mail</b><span lang="th"> ���
                </span><b>Password</b> <span lang="th">�����������к�</span></li>
                <li><span lang="th">��ҹ����ѧ�����ŧ����¹�������ö���ԡ����к��� 
                �е�ͧ�ӡ�� ��Ѥ���Ҫԡ ���¡�͹</span></li>
                <li><span lang="th">��Ҩ� </span>Password <span lang="th">�������� 
                ���顷�� <b><font color="#0000FF">��� </font></b></span><b>
                <font color="#0000FF">Password</font></b></li>
              </ul>
              </td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td height="16"></td>
          <td height="16" colspan="2" bgcolor="#E1E1E1"><b>Log-In :</b> 
          Enter E-mail Address &amp; Password</td>
        </tr>
      </table>
      <br>
      <hr color="#FF9933" size="1"></td>
    </tr>
  </table>
</form>
</body>