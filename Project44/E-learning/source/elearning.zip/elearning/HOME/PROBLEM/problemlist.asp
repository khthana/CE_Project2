<html>

<link rel="stylesheet" type="text/css" href="../../font.css">

<head>
<meta http-equiv="Content-Language" content="en-us">
<title>NEWS</title>
</head>
<script language="javascript">
function conf(object){
	if (confirm("Do you Want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<body>
<br>
<!--#include virtual="/../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
if request.cookies("member_id")<>"" then
id=request.cookies("member_id")
	sql="select status from emember where member_id='"&id&"'"
	rs.open sql,con,0,3,1
		status=Cstr(rs("status"))
	rs.close
else
status=""
end if
	sql="select * from eproblem order by pgroup desc"
	rs.open sql,con,3,3,1
	if not rs.eof then
rs.movefirst
do while not rs.eof
%>
<center>
 	<%if strcomp(rs("problem_id"),rs("pgroup")) then %>
<table border="1" cellpadding="2" style="border-collapse: collapse" bordercolor="white" width="550" bgcolor="#DDF4FF">
  <tr>
   <td width="70" valign=top align=right><b>�ͺ :</b></td>
    <td width="480" class=tsize8><%=rs("pdata")%><hr color="#009999" size="1">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td class=tsize8>�ͺ�� �س<%=rs("puser")%> ���������&nbsp;<%=rs("pdate")%></td>
		<td width="80" class=tsize8 align='center'></td>
		<td width="60" class=tsize8 align='right' >
		<%if status="3"  then%>	
		<a class=al href="del_ans.asp?del=<%=rs("problem_id")%>" onclick='return conf(this)'><font color=red>ź�ӵͺ���</font></a>
		<%end if%>		
		</td>
      </tr>
    </table>
     </td>
  </tr>
</table>
<%else%>
<table border="1" cellpadding="2" style="border-collapse: collapse" bordercolor="white" width="550" bgcolor="#006699">
  <tr>
    <td width="70" valign=top align=right><b><font color=white>�Ӷ�� :</font></b></td>
	
    <td width="480" class=tsize8><font color=white><%=rs("pdata")%></font><hr color="#DDF4FF" size="1">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td class=tsize8><font color=white>����� �س<%=rs("puser")%> ���������&nbsp;<%=rs("pdate")%></font></td>
	<td width="80" class=tsize8 align=center>
	
<%if status="3"  then%>	
     <a class=al href="ansproblem.asp?reply=<%=rs("problem_id")%>"><font color=yellow>�ͺ�Ӷ��</font></a>
	</td><td width="60" class=tsize8 align=right >&nbsp;
	<a class=al href="del_prob.asp?del=<%=rs("problem_id")%>" onclick='return conf(this)'><font color=red>ź�Ӷ�����</font></a>
<%else%>
	</td><td width="60" class=tsize8 align=right>
<%end if%>
      </td></tr>
    </table>
     </td>
  </tr>
</table>
	<%end if%>
	
</center>
<%
rs.movenext
loop
	end if
rs.close
set rs=Nothing
con.close
set con=Nothing
%>
</body>
</html>