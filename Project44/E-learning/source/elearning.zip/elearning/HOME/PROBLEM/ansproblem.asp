<html>

<link rel="stylesheet" type="text/css" href="../../font.css">

<head>
<meta http-equiv="Content-Language" content="en-us">
<title>NEWS</title>
</head>
<center>
<br>
<!--#include virtual="/../../conn.asp"-->
<%
reply=request.querystring("reply")
set	rs=server.createobject("adodb.recordset")
	sql="select * from eproblem where pgroup='"&reply&"' order by pdate asc "
	rs.open sql,con,3,3,1
	if not rs.eof then
rs.movefirst
do while not rs.eof
%>

 	<%if strcomp(rs("problem_id"),rs("pgroup")) then %>
<table border="1" cellpadding="2" style="border-collapse: collapse" bordercolor="white" width="550" bgcolor="#DDF4FF">
  <tr>
   <td width="70" valign=top align=right><b>�ͺ :</b></td>
    <td width="480" class=tsize8><%=rs("pdata")%><hr color="#009999" size="1">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td class=tsize8>����� �س<%=rs("puser")%> ���������&nbsp;<%=rs("pdate")%></td>
        <td width="70" class=tsize8 align=right></td>
      </tr>
    </table>
     </td>
  </tr>
</table>
<%else%>
<table border="1" cellpadding="2" style="border-collapse: collapse" bordercolor="white" width="550" bgcolor="#006699">
  <tr>
    <td width="70" valign=top align=right><b><font color=white>�Ӷ�� :</font></b></td>
	
    <td width="480" class=tsize8><font color=white><%=rs("pdata")%></font><hr color="#DDF4FF" size="1">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td class=tsize8><font color=white>����� �س<%=rs("puser")%> ���������&nbsp;<%=rs("pdate")%></font></td>
        <td width="70" class=tsize8 align=right>
      </td></tr>
    </table>
     </td>
  </tr>
</table>
	<%end if%>
<%
rs.movenext
loop
	end if
rs.close
set rs=Nothing
con.close
set con=Nothing
%>
<!--#include file="npform.asp"-->
</center>
</html>