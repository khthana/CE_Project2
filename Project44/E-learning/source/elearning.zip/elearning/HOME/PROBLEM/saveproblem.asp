<body>
<%
if request.form("problem")="" then
%>
<script language="JavaScript">
	alert("���Ӷ����͹");
	history.back();
</script>
<%
elseif request.form("user")="" then
%>
<script language="JavaScript">
	alert("�����ͼ��������");
	history.back();
</script>
<%
else
group=request.form("group")
user=request.form("user")
mail=request.form("email")
prob=request.form("problem")
data=replace(prob,chr(13),"<br>")
	if request.cookies("member_id")<>"" then
		id=Cint( request.cookies("member_id") )
	else
		id=0
	end if
%>
<!--#include virtual="/../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
	sql="select * from eproblem"
	rs.open sql,con,1,3
	rs.addnew
	rs("pgroup")=group
	rs("member_id")=id
	rs("puser")=user
	rs("pmail")=mail
	rs("pdata")=data
	rs("pdate")=now
	rs.update
	rs.close
	if group="0" then
		sql="select problem_id,pgroup from eproblem where pgroup='"&group&"' "
		rs.open sql,con,1,3
			rs("pgroup")=Cint(rs("problem_id"))
		rs.update
		rs.close
	end if
	
con.close
end if
response.redirect "indexprob.asp"

%>
</body>