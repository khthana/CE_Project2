<html>

<link rel="stylesheet" type="text/css" href="../board.css">
<link rel="stylesheet" type="text/css" href="../font.css">
<link rel="stylesheet" type="text/css" href="../link.css">
<head>
<title>Member</title>
</head>
<body>
<center>
<br>
<!--#include virtual="/../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")

if request.cookies("member_id")<>"" then
	gid=request.cookies("member_id")
	sql="select * from esub_topics where member_id='"&gid&"'"
	rs.open sql,con,0,3
	if not rs.eof then
	rs.movefirst
	do while not rs.eof
%>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='550' >
<tr bgcolor="#66CCFF" >
    <td width='30' align=center>
    <img border='0' src='../../../Image/bookclose.gif' name='number<%=rs("subject_id")%>'> </td>
    <td>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='500'>
<tr><td width='230'>
	<a class=al  title="����������´">
    <b><%=rs("sname")%></b></a> &nbsp;
	</td>
	<td class=tsize8 width='160'><font color='#666666'>Update :&nbsp;</font><%=rs("supdate")%></td>
	<td class=tsize8 width='110' >ŧ����¹���� :&nbsp;
	<%
	set	rc=con.execute("select count(*) as 'total' from ecourse_list where subject_id='"&rs("subject_id")&"' ")
		response.write rc("total")
	%>
	</td>
	</tr></table>
    	</td>
    </tr>
    <tr>
    <td colspan=3 height='3'></td>
    </tr>
    </table>
    <%
	set	 rc=con.execute("select * from ecourse_list,emember where ecourse_list.member_id=emember.member_id and ecourse_list.subject_id='"&rs("subject_id")&"' ")
	if not rc.eof then
	response.write "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='550' id='AutoNumber1' bgcolor='#F5F5F5'>"
	response.write "<tr><td width='100%'>"
	rc.movefirst
	do while not rc.eof
			select case rc("status")
			case "1" : status ="Student"
			case "2" : status ="Teacher"
			case "3" : status ="Administrator"
			case "0" : status ="�� Confrim"
		end select
	   	response.write "<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse'><tr>"
		'response.write "<td align='center' width='20'></td>"
		response.write "<td align='center' width='30'>"
		response.write "<a href=mailto:" & rc("email") & "><img  src='../Image/mail.gif' border='0' title='������'></a>"
		response.write "</td><td>"
		response.write "<a class=al title='�������ʹ٢�����' href=profile4update.asp?mode="&mode&"&ID=" & rc("member_id") & ">" & rc("email") & "</a>"
		response.write "</td>"
		response.write "<td class=tsize8 width='150'>&nbsp;ʶҹ� <font color='#993333'>"&status&"</font></td>"
		response.write "</tr></table>"	
	rc.movenext
	loop
	response.write "</td></tr></table>"
	end if
	response.write "<br>"	
	rs.movenext
	loop
	else
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='550'>"
		response.write "<tr><td width='100%'>&nbsp;����բ�����</td></tr></table>"
	end if
	rs.close
end if	
con.close
%>
</body>
</html>