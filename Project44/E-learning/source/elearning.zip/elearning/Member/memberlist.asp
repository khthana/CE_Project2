<html>

<link rel="stylesheet" type="text/css" href="../board.css">
<link rel="stylesheet" type="text/css" href="../font.css">
<link rel="stylesheet" type="text/css" href="../link.css">
<head>
<title>Member</title>
</head>
<body>
<center>
<form Action='delmember.asp' Method='Post'>
<br>
<!--#include virtual="/../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
if request.cookies("member_id")<>"" then
	gid=request.cookies("member_id")
	sql="select status from emember where member_id='"&gid&"'"
	rs.open sql,con,0,3
		permit=rs("status")
	rs.close
else	
	permit=""
end if
if request.querystring("mode")<>"" then
	mode=request.querystring("mode")
else
	mode=""
end if
if mode="Student" then
	sql="select * from emember where status='1' order by member_id desc"
elseif mode="Teacher" then
	sql="select * from emember where status='2' or status='0' order by status asc"
elseif mode="Administrator" then
	sql="select * from emember where status='3' order by member_id desc"
elseif mode="" then
	sql="select * from emember order by status desc"
end if
	rs.open sql,con,0,3
	response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='550'>"
	response.write "<tr><td width='30' class=tsize12 height='40' align='center'><img border='0' src='../Image/Acadmy02.gif'></td>"
	response.write "<td class=tsize12>&nbsp;<b>"&mode&"</b></td></tr>"
	response.write "<tr><td colspan=2 class=tsize8>Delete</td></tr></table>"	
	response.write "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='550' id='AutoNumber1' bgcolor='#F5F5F5'>"
	response.write "<tr><td width='100%'>"
	if not rs.eof then
	rs.movefirst
	do while not rs.eof
		select case rs("status")
			case "1" : status ="Student"
			case "2" : status ="Teacher"
			case "3" : status ="Administrator"
			case "0" : status ="�� Confrim"
		end select
		if permit="3" then 
		response.write "<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' bordercolor='#C0C0C0' ><tr><td width=20 >"
		%>
		<input type=checkbox name='del<%=rs("member_id")%>' value='on' <%if StrComp(rs("member_id"),request.cookies("member_id"))=0 then response.write "Disabled" end if%>>
<%	response.write "</td><td width='30' align='center'>"
		response.write "<a href=mailto:" & rs("email") & "><img  src='../Image/mail.gif' border='0' title='������'></a>"
		response.write "</td><td>"
		response.write "<a class=al title='�������ʹ٢�����' href=profile4update.asp?mode="&mode&"&ID=" & rs("member_id") & ">" & rs("email") & "</a>"
		response.write "</td>"
		response.write "<td class=tsize8>&nbsp;ʶҹ� <font color='#993333'>"&status&"</font></td>"
		response.write "<td>&nbsp;</td>"
		response.write "</tr></table>"	
		else
		response.write "<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' bordercolor='#C0C0C0' ><tr><td width=20 >"
		%>
		<input type=checkbox name='del<%=rs("member_id")%>' value='on' Disabled>
<%	response.write "</td><td width='30' align='center'>"
		response.write "<a href=mailto:" & rs("email") & "><img  src='../Image/mail.gif' border='0' title='������'></a>"
		response.write "</td><td>"
		response.write rs("email")
		response.write "</td>"
		response.write "<td class=tsize8>&nbsp;ʶҹ� <font color='#993333'>"&status&"</font></td>"
		response.write "<td>&nbsp;</td>"
		response.write "</tr></table>"	
		end if
	rs.movenext
	loop
	else
		response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%'>"
		response.write "<tr><td width='100%'>&nbsp;����բ�����</td></tr></table>"
	end if
	response.write "</td></tr></table>"
	rs.close
con.close
if permit="3" then 
	response.write "<table border='0' cellpadding='0' cellspacing='0' width='550'>"
	response.write "<tr><td></TD></TR>"
	response.write "<tr><td>"
	response.write "<input  type=hidden name=mode value='"&mode&"'>"			
	response.write "<input  type=hidden name=action value=dele>"
	response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value=����͡>"
	response.write "</td></tr></table>"
end if
%>
</form>
</center>
</body>
</html>