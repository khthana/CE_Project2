<!--#include virtual="/../conn.asp"-->
<%
if request.form("action")="dele" then
if request.form("mode")<>"" then
	mode=request.form("mode")
else
	mode=""
end if
if mode="Student" then
	sql="select * from emember where status='1' "
elseif mode="Teacher" then
	sql="select * from emember where status='2' "
elseif mode="Administrator" then
	sql="select * from emember where status='3' "
elseif mode="" then
	sql="select * from emember "
end if
set	rs=server.createobject("adodb.recordset")
	rs.open sql,con,1,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
			if request.form("del"&rs("member_id"))="on" then
				con.execute "delete emember_01 where member_id='"&rs("member_id")&"' "
				con.execute "delete ecourse_list where member_id='"&rs("member_id")&"' "
			rs.delete
			end if
		rs.movenext
		loop
	end if
	rs.close
end if
con.close
response.redirect "memberlist.asp?mode="&mode		
%>