<link rel="stylesheet" type="text/css" href="../board.css">
<link rel="stylesheet" type="text/css" href="../font.css">
<link rel="stylesheet" type="text/css" href="../link.css">
<link href="../Style.css" rel="stylesheet" type="text/css">

<center>
<br>
<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="550" bordercolor="#FF0000">
  <tr><td>
<!--#include virtual="/../conn.asp"-->
<%

set	rs=server.createobject("adodb.recordset")
if request.querystring("mode")<>"" then
	mode=request.querystring("mode")
else
	mode=""
end if	
if request.querystring("ID")<>"" then
	ID=request.querystring("ID")
else
	ID=request.cookies("member_id")
end if	
if ID<>"" then
	sql="select * from emember,emember_01 	where 	(emember.member_id=emember_01.member_id) and emember.member_id='"&ID&"' "
	rs.open sql,con,0,3
	if not rs.eof then
%>
<form Action="update.asp" Method="Post">
<table border="0" cellpadding="2" style="border-collapse: collapse" width="100%" id="AutoNumber5">
    <tr>
    <td colspan='2' ><font color="#800000"><b>:: ��������ǹ���</b></font></td>
  </tr>
	<tr>
      <td align='right' width='100'><b>���� :</b> </td>
      <td width='450'><input type="text" class="input_post" size="20" name="name" value="<%=rs("name")%>">&nbsp; 
      ���ʡ�� :<input type="text" class="input_post" size="20" name="surname" value="<%=rs("surname")%>"></td>
	</tr>
  <tr>
    <td align='right' width='100'><b>�ѹ�Դ :</b> </td>
    <td width='450'>
         <%
        	bday=rs("birth_d")
          bmonth=rs("birth_m")
          byear=rs("birth_y")
        %>
     �ѹ :<input type="text" class="input_post" size="2" maxlength="2" name="date" value="<%=rs("birth_d")%>"> 
     ��͹ :<input type="text" class="input_post" size="2" maxlength="2" name="month" value="<%=rs("birth_m")%>"> 
	�� :<input type="text" class="input_post" size="5" maxlength="4" name="year" value="<%=rs("birth_y")%>"> 
  <b>�� :</b>
		<%if Strcomp(rs("gender"),"M")=0 then  
				response.write "<input type='radio' name='gender' value='M' checked > ���" 
				response.write "<input type='radio' name='gender' value='F'> ˭ԧ"
		elseif Strcomp(rs("gender"),"F")=0 then
				response.write "<input type='radio' name='gender' value='M' > ���" 
				response.write "<input type='radio' name='gender' value='F' checked> ˭ԧ"
		end if%>
    </td>
  </tr>
  <tr>
    <td align='right' width='100' valign='top'><b>������� :</b></td>
    <td width='450'>
    <textarea class="input_post" name="address" cols="55" rows='2'><%=rs("address")%>
    </textarea>
    </td>
  </tr>
  <tr>
    <td align='right' width='100'><b>���Ѿ�� :</b> </td>
    <td width='450'>
    <input type="text" class="input_post" name="phone" size="20" value="<%=rs("phone")%>">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; 
      ICQ :<input type="text" class="input_post" size="20" name="icq" value="<%=rs("icq")%>">
    </td>
  </tr>
  <tr>
    <td align='right' width='100'><b>����֡�� :</b></td>
    <td width='450'>
      <select class="input_post" size="1" name="edu">
          <option selected>����֡��</option>
          <option value="͹غ��" <%if Strcomp(rs("edu"),"͹غ��")=0 then response.write "selected" end if%>>͹غ��</option>
          <option value="��ж��֡��" <%if Strcomp(rs("edu"),"��ж��֡��")=0 then response.write "selected" end if%>>��ж��֡��</option>
          <option value="�Ѹ����" <%if Strcomp(rs("edu"),"�Ѹ����")=0 then response.write "selected" end if%>>�Ѹ����</option>
          <option value="�Ѹ������" <%if Strcomp(rs("edu"),"�Ѹ������")=0 then response.write "selected" end if%>>�Ѹ������</option>
          <option value="�Ǫ." <%if Strcomp(rs("edu"),"�Ǫ.")=0 then response.write "selected" end if%>>�Ǫ.</option>
          <option value="���." <%if Strcomp(rs("edu"),"���.")=0 then response.write "selected" end if%>>���.</option>
          <option value="��ԭ�ҵ��" <%if Strcomp(rs("edu"),"��ԭ�ҵ��")=0 then response.write "selected" end if%>>��ԭ�ҵ��</option>
          <option value="��ԭ���" <%if Strcomp(rs("edu"),"��ԭ���")=0 then response.write "selected" end if%>>��ԭ���</option>
          <option value="��ԭ���͡" <%if Strcomp(rs("edu"),"��ԭ���͡")=0 then response.write "selected" end if%>>��ԭ���͡</option>
          <option value="�֡�ҵ�ҧ�����" <%if Strcomp(rs("edu"),"�֡�ҵ�ҧ�����")=0 then response.write "selected" end if%>>�֡�ҵ�ҧ�����</option>
          <option value="����" <%if Strcomp(rs("edu"),"����")=0 then response.write "selected" end if%>>����</option>
     </select>
    </td>
  </tr>
    <tr>
	<td align=right valign=top width='100'><b>��÷ӧҹ :</b></td>
    		<td width='450'><textarea class="input_post" name="work" cols="55" rows='2'><%=rs("working")%>
   	</textarea>
   	</td>
   </tr>
       <tr>
        <td align=right valign=top width='100'><b>��������ö<br>�����  :</b></td>
    <td width='450'><textarea class="input_post" name="able" cols="55" rows='2' ><%=rs("able")%>
    </textarea></td>
      </tr>
     <tr>
    <td align='right' width='100'>&nbsp;</td>
    <td width='450'>&nbsp;</td>
  </tr>
  </table>
<br>
<table border="0" cellpadding="2" style="border-collapse: collapse" width="100%" id="AutoNumber5">
  <tr>
    <td colspan=2><font color="#800000"><b>:: �������к�</b></font></td>
  </tr>
    <tr>
    <td align='right' width='100'><b>Status :</b></td>
    <td width='450'>
      <select class="input_post" size="1" name="tempstatus" <%if mode="" then response.write "disabled" end if%>>
          <option value="1" <%if Strcomp(rs("status"),1)=0 then response.write "selected" end if%>>Student</option>
          <option value="2" <%if Strcomp(rs("status"),2)=0 then response.write "selected" end if%>>Teacher</option>
          <option value="3" <%if Strcomp(rs("status"),3)=0 then response.write "selected" end if%>>Administrator</option>
          <option value="0" <%if Strcomp(rs("status"),0)=0 then response.write "selected" end if%>>�� Confirm</option>
     </select>
   </tr>
    <tr>
    <td align='right' width='100'><b><span lang="th">������к� </span>:</b></td>
    <td width='450'>
          <input type="text" class="input_post" name="usename" size="30" value="<%=rs("usename")%>"></td>
  </tr>
    <tr>
    <td align='right' width='100'><b>E-mail : </b> </td>
    <td width='450'>
          <input type="text" class="input_post" name="email" size="30" value="<%=rs("email")%>" disabled></td>
  </tr>
   <tr>
    <td align='right' width='100'><b>Password :</b></td>
    <td width='450'>
<input class="input_post" type="<%if mode="" or request.cookies("member_id")="" then response.write "password" else response.write "text" end if%>" name="pwd" size="20" value="<%=rs("pwd")%>" disabled>
  </td>
  </tr> 
  <tr>
    <td align='right' width='100'>&nbsp;</td>
    <td width='450'>
	<%if request.cookies("member_id")<>"" and mode<>"" then%>    
	    	<input type =hidden name="mode" value="<%=mode%>">    
	    	<input type =hidden name="idmember" value="<%=ID%>">    
		<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' Type="Submit" Value="���">
		<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' Type="button" Value="��Ѻ�" onclick='history.back()'>
    <%end if%>
    </td>
  </tr>
  <tr>
    <td align='right' width='100'>&nbsp;</td>
    <td width='450'>&nbsp;</td>
  </tr>
  <tr>
    <td colspan=2><font color="#800000"><b>:: �����š���֡��</b></font></td>
  </tr>
	</table>
</form>
<%end if
	rs.close
	sql="select * from ecourse_list,esub_topics where ecourse_list.subject_id=esub_topics.subject_id and ecourse_list.member_id='"&ID&"' "
	rs.open sql,con,1,3
	if not rs.eof then
	response.write "<center><table border='1' width='450' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bgcolor='#D6E7EF' >"
	response.write "<tr><td>"
	rs.movefirst
	do while not rs.eof
		set ra=con.execute ("select count(subject_id) as 'total' from etest1 where subject_id='"&rs("subject_id")&"'")
		set rb=con.execute ("select result_1 from eresult_1 where subject_id='"&rs("subject_id")&"'")
		if not rb.eof then result1=rb("result_1") else result1="�ѧ������Ẻ���ͺ" end if

		set ra1=con.execute ("select count(subject_id) as 'total' from etest2 where subject_id='"&rs("subject_id")&"'")
		set rb1=con.execute ("select result_2 from eresult_2 where subject_id='"&rs("subject_id")&"'")
		if not rb1.eof then result2=rb1("result_2") else result2="�ѧ������Ẻ���ͺ" end if
%>
<table border='0' cellpadding='0' style='border-collapse: collapse' width='450'  >
  <tr>
    <td align='center' width='30'><img src='../Image/bookclose.gif'></td>
    <td width='220'><b>&nbsp;<%=rs("sname")%></b></td>
    <td width='200' class=tsize8></td>
  </tr>
  <tr>
    <td align='center'></td>
    <td class=tsize8 align='center'>&nbsp;Ẻ���ͺ��� 1</td>
    <td class=tsize8><font color=red><%=result1%></font>&nbsp;/&nbsp;<%=ra("total")%> ���</td>
  </tr>
    <tr>
    <td align='center'></td>
    <td class=tsize8 align='center'>&nbsp;Ẻ���ͺ��� 2</td>
    <td class=tsize8><font color=red><%=result2%></font>&nbsp;/&nbsp;<%=ra1("total")%> ���</td>
  </tr>
</table>

<%
	rs.movenext
	loop	
	response.write "</td></tr></table></center>"
	end if

	
	
else
response.write "����բ�����"
end if
con.close
%>
<br>    
</td></tr></table>
</center>