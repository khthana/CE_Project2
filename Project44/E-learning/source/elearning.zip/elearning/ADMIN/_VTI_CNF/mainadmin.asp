vti_encoding:SR|utf8-nl
vti_author:SR|ELEARNING\\Administrator
vti_modifiedby:SR|ELEARNING\\Administrator
vti_timelastmodified:TR|19 Mar 2002 11:28:34 -0000
vti_timecreated:TR|20 Mar 2002 01:59:18 -0000
vti_title:SR|Teacher
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{0CF5FB8E-C09A-4AE6-B5EF-AE8F5BFB7CFC}
vti_backlinkinfo:VX|main1.asp
vti_nexttolasttimemodified:TW|20 Mar 2002 02:27:49 -0000
vti_cacheddtm:TX|19 Mar 2002 11:28:34 -0000
vti_filesize:IR|3291
vti_cachedtitle:SR|Teacher
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|../font.css S|../Image/ARRO42E1.gif H|addsgroup/listsgroup.asp S|../Image/ARRO42E1.gif H|../Course/Uploads/addsubject.asp S|../Image/ARRO42E1.gif H|../Course/Uploads/Technical/editsub4admin.asp S|../Image/ARRO42E1.gif H|../home/News/Upload/updatenews.asp S|../Image/ARRO42E1.gif H|../eboard/wblist.asp S|../Image/ARRO42E1.gif H|../Member/memberlist.asp S|../Image/ARRO42E1.gif H|../Member/memberlist.asp S|../Image/ARRO42E1.gif H|../Member/memberlist.asp S|../Image/ARRO42E1.gif H|../home/problem/indexprob.asp
vti_cachedsvcrellinks:VX|FQUS|font.css FSUS|Image/ARRO42E1.gif FHUS|admin/addsgroup/listsgroup.asp FSUS|Image/ARRO42E1.gif FHUS|Course/Uploads/addsubject.asp FSUS|Image/ARRO42E1.gif FHUS|Course/Uploads/Technical/editsub4admin.asp FSUS|Image/ARRO42E1.gif FHUS|home/News/Upload/updatenews.asp FSUS|Image/ARRO42E1.gif FHUS|eboard/wblist.asp FSUS|Image/ARRO42E1.gif FHUS|Member/memberlist.asp FSUS|Image/ARRO42E1.gif FHUS|Member/memberlist.asp FSUS|Image/ARRO42E1.gif FHUS|Member/memberlist.asp FSUS|Image/ARRO42E1.gif FHUS|home/problem/indexprob.asp
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language th
vti_charset:SR|windows-874
vti_language:SR|th
