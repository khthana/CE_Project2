<link rel="stylesheet" type="text/css" href="../font.css" >
<head>
<meta http-equiv="Content-Language" content="th">
<title>Teacher</title>
</head>
<body>
<center><br>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="550" bgcolor="#F9F9F9">
  <tr>
    <td width=250>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="250" height="194">
      <tr>
        <td width="20">
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>
        <td width="230"><b><a href="addsgroup/listsgroup.asp">
        ������Ǵ����ͧ����Ԫҷ����ʹ�</a></b></td>
      </tr>
      <tr>
        <td width="20">
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>
        <td width="230"><b><a href="../Course/Uploads/addsubject.asp">�����Ԫ�㹡���͹</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Course/Uploads/Technical/editsub4admin.asp">�����������Ԫҷ���͹</a></b></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../home/News/Upload/updatenews.asp">��С�Ȣ�����������Ҫԡ��Һ���ǡѹ</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><span lang="en-us"><b><a href="../eboard/wblist.asp">Learning board</a></b></span></td>
      </tr>
      <tr>
        <td >
        &nbsp;</td>        
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2" bgcolor="#FF9933" >
        <p align="center"><font color="#FFFFFF"><b>��Ҫԡ�ͧ <span lang="en-us">
        Web Site</span></b></font></td>        
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Member/memberlist.asp?mode=Student">��Ҫԡ����繹ѡ���¹</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Member/memberlist.asp?mode=Teacher">��Ҫԡ������Ҩ����</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../Member/memberlist.asp?mode=Administrator">��Ҫԡ����繼������к�</a></b></td>
      </tr>
      <tr>
        <td >
        &nbsp;</td>        
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../home/problem/indexprob.asp">�ѭ�Ңͧ��Ҫԡ</a></b></td>
      </tr>
      <tr>
        <td >
        <img border="0" src="../Image/ARRO42E1.gif" align="right"></td>        
        <td ><b><a href="../loadprogram/Upload/updatedownload.asp">��ǹ�ͧ��� Download �����</a></b></td>
      </tr>
    </table>
    </td>
    <td width=300 background="../Image/teacher02.gif" height="200" valign="bottom">&nbsp;</td>
  </tr>
</table>
</center>
</body>