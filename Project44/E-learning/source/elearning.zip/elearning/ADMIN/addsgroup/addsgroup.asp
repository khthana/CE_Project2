<!--#include virtual="/../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
if request.form("action")="add" then
if request.form("sgroup")="" then
	response.write "<script language='javascript'>"
	response.write "alert('Insert Group Subject');"
	response.write "history.back(1);"
	response.write "</script>"
else
sgroup=request.form("sgroup")
	sql="select * from egroup_sub where sgroup='"&sgroup&"' "	
	rs.open sql,con,1,3
	if rs.eof then
		con.execute "insert into egroup_sub(sgroup) values('"&sgroup&"')"
		response.write "<script language='javascript'>"
		response.write "alert('Successfull');"
		response.write "</script>"
		response.redirect "listsgroup.asp"
	else
		response.write "<script language='javascript'>"
		response.write "alert('���� Group �������������');"
		response.write "history.back(1);"
		response.write "</script>"
	end if
	rs.close
end if
elseif request.form("action")="del" then
	sql="select * from egroup_sub "
	rs.open sql,con,1,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
			if request.form("del"&rs("sgroup_id"))="on" then
				rs.delete		'ź RECORD
			end if
		rs.movenext
		loop
	end if
	rs.close
	response.redirect "listsgroup.asp"
end if
con.close
%>