<!--#include virtual="/../../conn.asp"-->
<%
choice=request.form("choice")
if choice<>"" then
set	rs=server.createobject("adodb.recordset")
	sql="select subject_id,sgroup from esub_topics  where sgroup='"&choice&"'"
	rs.open sql,con,3,3
	if rs.eof then 
		response.write "<table border='0' cellspacing='0' cellpadding='0' width='100%' bordercolor=red style='border-collapse: collapse'><tr><td>����բ�����</td></tr></table>"
	else
	rs.movefirst
	do while not rs.eof
		if request.form("group"&rs("subject_id"))<>"choice" then
			rs("sgroup")=request.form("group"&rs("subject_id"))
			rs.update
		end if	
	rs.movenext
	loop
	end if
	rs.close
end if
con.close
response.redirect "listsgroup.asp"
%>