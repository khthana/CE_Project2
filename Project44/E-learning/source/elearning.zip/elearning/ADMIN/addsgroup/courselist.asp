<html>
<link rel="stylesheet" type="text/css" href="../../font.css" >
<link rel="stylesheet" type="text/css" href="../../link.css" >
<link rel="stylesheet" type="text/css" href="../../board.css" >
<link rel="stylesheet" type="text/css" href="../../select.css" >
<head>
<title>�Ԫ����Ǵ��ҧ�</title>
<base target="_self">
</head>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<body>
<br>
<center>
<form method="POST" action="editgroup.asp">
<table border="0" cellspacing="0" style="border-collapse: collapse" width="550" id="AutoNumber1" bordercolor="#FF0000" cellpadding="0">
<tr><td>
<!--#include virtual="/../../conn.asp"-->
<%
if request.querystring("choice")<>"" then
choice=request.querystring("choice")

response.write "<table border='0' cellspacing='0' style='border-collapse: collapse' width='100%' id='AutoNumber1' bordercolor='#FF0000' cellpadding='0'>"
response.write "<tr><td height='10' class=tsize12><img src='../../Image/CLSS13B2.GIF'>&nbsp;<b>��Ǵ����&nbsp;"&choice&"</b></td></tr></table><br>"

set	rs=server.createobject("adodb.recordset")
	sql="select count(*) as 'total' from esub_topics  where sgroup='"&choice&"'"
	rs.open sql,con,3,3
	totalrecord=rs("total")		'�ӹǹ record ������
	rs.close
	sql="select * from esub_topics where sgroup='"&choice&"'"
	rs.open sql,con,3,3

	if rs.eof then 
		response.write "<table border='0' cellspacing='0' cellpadding='0' width='100%' bordercolor=red style='border-collapse: collapse'><tr><td>����բ�����</td></tr></table>"
	else
	response.write "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='550' ><tr><td>"
	response.write "<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='100%'>"
	rs.movefirst
	do while not rs.eof
%>

	<tr>
    	<td width='30' align=center><img border='0' src='../../Image/bookclose.gif'> </td>
    	<td width='170'>
    	<a class=al title='�����Ǵ����ͧ�Ԫҹ��'><b><%=rs("sname")%></b>&nbsp;</a></td>
	<td class=tsize8 width='100' >ŧ����¹���� :&nbsp;
	<%
	set	rc=con.execute("select count(*) as 'total' from ecourse_list where subject_id='"&rs("subject_id")&"' ")
		response.write rc("total")
	%>
	</td>
	<td class=tsize8 width='160' ><font color='#666666'>Update :&nbsp;</font><%=rs("supdate")%>
	</td>
	<td class=tsize8 width='90' align='right'>
	<select class=tsize8 name='group<%=rs("subject_id")%>'>
		<%set	rc=con.execute("select distinct sgroup from esub_topics")
		if not rc.eof then
		rc.movefirst
		do while not rc.eof
		temp=rc("sgroup")
		%><option value='<%=temp%>' <%if temp=choice then response.write "selected" end if %>><%=temp%></option><%
		rc.movenext
		loop
		end if
		%>
</select>
	</td>

	</tr>
 <%
	rs.movenext
	loop
	
	response.write "</table></td></tr></table>"
	response.write "<table width='550' border='0'><tr><td class=tsize8 align='right'>"
	response.write "<input type='hidden' name='choice' value='"&choice&"'>"
	response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 80px' type='submit' name='edit' value=����¹��Ǵ���� onclick='return conf(this)'>"
	response.write "</td></tr>"
	response.write "</table>"
	end if
	rs.close
end if
con.close
%>
</td></tr></table>
</form>
</center>
</body></html>