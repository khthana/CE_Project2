<link href="../../font.css" rel="stylesheet" type="text/css">
<link href="../../link.css" rel="stylesheet" type="text/css">
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>
<center><br>
<form method='Post' action='addsgroup.asp'>        
<!--#include virtual="/../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
	sql="select * from egroup_sub "	
	rs.open sql,con,1,3
	if rs.eof then
		response.write "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='300'>"
		response.write "<tr><td>����բ�����</td></tr>"
		response.write "</table>"		
	else
	response.write "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' width='300' >"
	rs.movefirst
	do while not rs.eof
		response.write "<tr bgcolor='#66CCFF'><td width='20'>"
		%>
		<input type=checkbox name='del<%=rs("sgroup_id")%>' value='on'>
		<%
		response.write "</td><td width='280'>&nbsp;<a class=al title='������Ԫ����Ǵ������' href='courselist.asp?Choice="&rs("sgroup")&"'><b>"&rs("sgroup")&"</b></a></td></tr>"
	rs.movenext
	loop
	response.write "<tr><td colspan='2'></td></tr>"
	response.write "</table>"		
	response.write "<table border='0' cellpadding='1' cellspacing='1' style='border-collapse: collapse' width='300'>"
	response.write "<tr><td>"
	response.write "<input type='hidden' name='action' value='del'>"
	response.write "<input class=tsize8 type='submit' style='HEIGHT: 20px; WIDTH: 40px' value='Delete'  onclick='return conf(this)'>"
	response.write "</td></tr>"
	response.write "<tr><td>"	
	response.write "<font color='red'><b>��͹ź��������Ԫ����Ǵ�������������Ǵ���������������͹���ͻ�ͧ�ѹ�ѭ���Ԫ��������Ǵ����</b></font>"
	response.write "</td></tr>"          
	response.write "</table>"		
	end if
	rs.close
con.close
%>
</form>
<!--#include file="addfrm.asp"-->
</table>
</center>