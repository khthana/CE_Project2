<%@ENABLESESSIONSTATE=FALSE%>
<%
'******************************************************************************
'Copyright Dundas Software Ltd. 2000. All Rights Reserved.
'
'PURPOSE:           The user can try uploading files to the server using 
'                    different settings for the Dundas Upload control.
'
'POST DESTINATION:  UplLimitAction.asp.           
'
'Dundas Software Contact Information:
'	Email:	sales@dundas.com
'   Phone:	(800) 463-1492
'			(416) 467-5100
'	Fax:	(416) 422-4801
'******************************************************************************
Response.Expires = -10000
%>
<html>
<head>
<Script Language="javascript">
<!--
function CheckForCookiesOn()
{
//checks to see if browser has cookie support enabled,
//	if not an alert box is displayed, letting user know we need cookies
//also returns true if cookies disabled, otherwise false is returned	
	var blnCookiesSupported = false;
	
	//set the cookie
	document.cookie = 'testit' + "=" + escape('hi') + ";"
	
	//now attempt to retrieve the cookie
	var aCookie = document.cookie.split(";");
	for (var i=0; i < aCookie.length; i++)
	{ 
		var aCrumb = aCookie[i].split("=");
		if ('testit' == aCrumb[0])
		{
			blnCookiesSupported=true; 
			return false; 
		}	
		if (blnCookiesSupported==false){
			alert('For the progress bar to function correctly (for this particular demo) your browser must be set up so that it utilizes cookies.\nPlease note that cookie support is not required for the Progress Bar itself.');
			return true;
		}
	}
}
//-->
</Script>
<link rel="stylesheet" type="text/css" href="../../board.css">
<link rel="stylesheet" type="text/css" href="../../font.css">
<title>Learning News</title>
</head>
<body color="black" bgcolor="white" >
<center>
<br>
<%
on error resume next

'create UploadProgress object
set UplProg = Server.CreateObject("Dundas.UploadProgress")
'set the StateServer IP address
'UplProg.StateServer = "127.0.0.1"
'retrieve a new progress ID
NewProgressID = UplProg.GetNewProgressID
set UplProg = nothing

if Err <> 0 then
	NewProgressID = -1
	'display an error message
	'Response.Write "<P style='BACKGROUND-COLOR: #a52a2a'><FONT color=#ffffff>"
	'Response.Write "&nbsp;&nbsp;" & "State Server Error:  " & Err.description & "&nbsp;&nbsp;Progress bar will be disabled!</FONT></P>"
end if
%>

<SCRIPT>
NewID = <%=NewProgressID%>;
function dorefresh()
{
	var CookiesOff;
	
	//if cookies are not enabled let user know that browser must be supporting cookies for this demo to run ok
	CookiesOff = CheckForCookiesOn();	
		
	if( NewID != -1 && String(window.document.cookie).indexOf("RefreshProgressID=TRUE") != -1 )
		window.location.reload(1);
	window.document.cookie = "RefreshProgressID=FALSE";

	if (CookiesOff == true){
	//by setting the ProgressID to -1 we make sure progress bar will not be displayed by the Upload function below	
		NewID = -1;
	}	
}
	
function upload()
{ 
	if (NewID != -1){	
	//only open progressbar.asp window if cookies are enabled, since we are using cookies
	//   to store a boolean (RefreshProgressID) to store the ProgressID (identifies this particular upload operation)
		window.document.cookie = "RefreshProgressID=TRUE";
		Param = "SCROLLBARS=no,RESIZABLE=no, TOOLBAR=no,STATUS=no,MENUBAR=no,WIDTH=400,HEIGHT=100";
		Param += ",TOP=" + String(window.screen.Height/2 - 50);
		Param += ",LEFT=" + String(window.screen.Width/2 - 200);
		window.open("ProgressBar.asp?ProgressID=<%=NewProgressID%>" , null, Param);
	}	
	
	document.UploadForm.action = "UploadDemoAction.asp?ProgressID=<%=NewProgressID%>"
	document.UploadForm.submit();
}

//make sure irregardless of how user gets here (e.g. Back button) that a new id is generated
//  every time the page is loaded. 
window.onload = dorefresh;

</SCRIPT>

<form name="UploadForm" action="UploadDemoAction.asp" encType="multipart/form-data" method="post" style="BORDER-BOTTOM: thin; BORDER-RIGHT-STYLE: none">
          <input ID="UniqueNames" NAME="UniqueNames" TYPE="hidden" value="ON">
          <input NAME="FolderName" TYPE="hidden" value="db" style="WIDTH: 94px" size="20">
          <input NAME="MaxUpload" TYPE="hidden" VALUE="50000" style="WIDTH: 94px" size="20">
          <input NAME="MaxFiles" TYPE="hidden" VALUE="1" style="WIDTH: 94px" size="20">
          <input NAME="MaxSize" TYPE="hidden" VALUE="50000" style="WIDTH: 94px" size="20">

  <table border="0" cellspacing="1" width="450">
    <tr bgcolor="#9999cc">
      <td colspan="2" height="30" bgcolor="#FF9933" class=tsize12>&nbsp; <b>Upload Program For User Download</b></td>
    </tr>
    <tr bgcolor=#eeeeee><td align='right' class=tsize8 width=80><b>��������� :</b></td>
    <td><input type=text class=input_post name=topics size=53 maxlength=100></td></tr>
    
    <%
If Request.QueryString("ParentID")<>"" Then
   Response.Write "<input type=hidden name=ParentID value=" & Request.QueryString("ParentID") & ">"
End If


if request.cookies("member_id")<>"" then
id=Cint( request.cookies("member_id") )
%>
<!--#include virtual="/../../conn.asp"-->
<%
set	rs=server.createobject("adodb.recordset")
	sql="select usename,email from emember where member_id='"&id&"'"
	rs.open sql,con,0,3
	name=rs("usename")
	mail=rs("email")
	rs.close
con.close

response.write "<tr bgcolor=#eeeeee><td align='right' class=tsize8><b>���� : </b></td>"
response.write "<td><input type=text class=input_post name=user size=30 maxlength=20 value="&name&"></td>"
response.write "</tr><tr bgcolor=#eeeeee><td align='right' class=tsize8><b>������ :</b></td>"
response.write "<td><input type=text class=input_post name=email size=30 maxlength=50 value="&mail&"></td></tr>"

else
%>
    <tr bgcolor="#eeeeee">
      <td align="right" class=tsize8><b>���� :</b></td>
      <td>
      <input type="text" class="input_post" name="user" size="30" maxlength="20"></td>
    </tr>
    <tr bgcolor="#eeeeee">
      <td align="right" class=tsize8><b>������ : </b></td>
      <td>
      <input type="text" class="input_post" name="email" size="30" maxlength="50"></td>
    </tr>
<%end if%>
    <tr bgcolor="#eeeeee">
      <td valign="top" align="right" class=tsize8><b>��͸Ժ�� : </b></td>
      <td><textarea name="data" class="input_post" cols="54" rows="4"></textarea></td>
    </tr>
    <tr bgcolor="#eeeeee">
      <td align="right" class=tsize8><b>File :</b>
      </td>
      <td>
      <input type="file" class="input_post" name="File1" size="40" maxlength="50"></td>
    </tr>
    <tr bgcolor="#eeeeee" height="35">
      <td></td>
      <td>
      <input TYPE="button" class="input_button2" VALUE="Upload" ONCLICK="upload()">
      <input type="reset" class="input_button2" value="Clear">
	 <input type='button' class=input_button2 value='Back' onclick='javascript:history.back();'>
      </td>
    </tr>
  </table>
</form>
</center>
</BODY>
</html>