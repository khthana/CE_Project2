<html>

<link rel="stylesheet" type="text/css" href="../../board.css">
<link rel="stylesheet" type="text/css" href="../../font.css">
<link rel="stylesheet" type="text/css" href="../../link.css">
<head>
<title>News for Admin</title>
</head>
<script language="JavaScript">
function conf(object){
	if (confirm("Do you want to Delete?")==true){
	return true;
	}
return false;
}
</script>

<body>
<br>
<center>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='550' >
<tr><td>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FF0000" width="100%" id="AutoNumber1" height="40">
  <tr>
    <td width="100%" colspan='2'>
    <p align="right"><b><font face="Impact" size="5" color="#FF6600">&nbsp;</font><font face="Impact" size="6" color="#1E90FF">Download 
    Program</font></b></td>
  </tr>
  <tr>
    <td  class=tsize8  width='390'><hr color="#1E90FF" size="3"></td>
    <td  class=tsize8 align='right' ><font color="#FF0000">Download �����顷����� Program</font></td>
  </tr>
</table>
</td></tr>
<tr><td>
<form method="Post" action="del_program.asp">

<!--#include virtual="/../../conn.asp"--><%
set	rs=server.createobject("adodb.recordset")
if request.cookies("member_id")<>"" then
id=request.cookies("member_id")
	sql="select status from emember where member_id='"&id&"' "
	rs.open sql,con,0,3
		status=Cint( rs("status") )
	rs.close
else
	status=1
end if
'----------------------------------------------------------------------------------------------
'��� Program ������
	if status=2 then
		sql="select * from eloadprog where member_id='"&id&"' "
	else
		sql="select * from eloadprog "
	end if
	rs.open sql,con,3,3
	if rs.eof then 
		response.write "<table border='0'><tr><td>����բ�����</td></tr></table>"
	else
		do while not rs.eof 
		With Response
		.write "<table border='0' cellpadding='2' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='550' >"
		.write "<tr><td colspan='2' class=tsize12 >"
		%>
		<input type=checkbox name='del<%=rs("download_id")%>' value='on' <%if id="" then response.write "disabled" end if%>>
		<%
		.write "<b><font color=cc0000><a class=al href=db/"&rs("lfile")&">"&rs("ltopic")&"</a></font></b>"
		.write "</td></tr>"
		.write "<tr bgcolor='#F5F5F5'><td width='80' align=right valign=top class=tsize8><b>��������´ :</b></td>"
		.write "<td width='450' class=tsize8>"&rs("ldata")&"<hr size='1'>"
	.write "Upload by : <font color=BLUE>"&rs("luser")&"</font>"
	.write " Date : <font color=BLUE>"&rs("ldate")&"</font>" 
	.write " Size : <font color=BLUE>"&rs("lsize")&"</font> byte</td></tr>"
		.write "</table><br>"
		End With

		rs.movenext
		loop
		response.write "<table width='100%'>	"
		response.write "<tr><td width='100%' class=tsize8 align='right'><font color='#FF0000'>Download �����顷����� Program</font></td></tr>"
		response.write "</table>"
	end if
		response.write "<table border='0' cellPadding='0' cellSpacing ='0' style='border-collapse:collapse' width='100%'>"
		response.write "<tr><td width=400>"
		if id<>"" then
		response.write "<input  type=hidden name=action value=dele>"
		response.write "<input class=tsize8 style='HEIGHT: 20px; WIDTH: 50px' type='submit' name=del value='Delete' onclick='return conf(this)'>"
		end if
		response.write "</td><td align=center width=150 bgcolor=#C0C0C0>"
		if id<>"" then
			response.write "<a href='main.asp'><font color='Blue'><b>Upload Program</b></font></a> "
		end if
		response.write "</td></tr></table>"
	rs.close
	Set rs=Nothing	
con.close
set con=Nothing
%>
</form>
</td></tr>
</table>
</center>
</body>
</html>