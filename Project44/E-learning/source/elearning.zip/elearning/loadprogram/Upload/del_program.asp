<!--#include virtual="/../../../conn.asp"--><%
set	rs=server.createobject("adodb.recordset")
if request.form("action")="dele" then
	sql="select download_id,lfile from eloadprog "
	rs.open sql,con,1,3
	if not rs.eof then
		rs.movefirst
		do while not rs.eof
			if request.form("del"&rs("download_id"))="on" then
				if rs("lfile")<>"" then		
				delfile=rs("lfile")
 				RootFolderName = Server.MapPath(".") & "/db/"&delfile
				'ź file
				file_folder = RootFolderName
				set fso=CreateObject("Scripting.FileSystemObject")
				set a=fso.GetFile(file_folder)
				a.delete		'ź File
				end if
				rs.delete		'ź RECORD
			end if
		rs.movenext
		loop
	end if
	rs.close
elseif request.querystring("del")<>"" then
del=request.querystring("del")
	sql="select download_id,lfile from eloadprog where download_id='"&del&"' "
	rs.open sql,con,1,3
	if not rs.eof then
		if rs("lfile")<>"" then		
			delfile=rs("lfile")
			RootFolderName = Server.MapPath(".") & "/db/"&delfile
			'ź file
			file_folder = RootFolderName
			set fso=CreateObject("Scripting.FileSystemObject")
			set a=fso.GetFile(file_folder)
			a.delete		'ź File
		end if
		rs.delete		'ź RECORD
	end if	
end if	
con.close
response.redirect "updatedownload.asp"
%>