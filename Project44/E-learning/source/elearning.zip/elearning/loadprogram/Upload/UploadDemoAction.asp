<%@ENABLESESSIONSTATE=FALSE%>
<!--#include file="../DSUpload.inc"-->
<%
'*********************************************************************************
'Copyright Dundas Software Ltd. 2000. All Rights Reserved.
'
'PURPOSE:           Processes the information POSTED by main.asp, and
'					 display the content of the Files & Form collection of the
'                    Dundas Upload control.
'
'CONTROLS USED:		Dundas Upload control.
'
'Dundas Software Contact Information:
'	Email:	sales@dundas.com
'   Phone:	(800) 463-1492
'			(416) 467-5100
'	Fax:	(416) 422-4801
'*********************************************************************************
%>
<HTML>
<HEAD>
<link rel="stylesheet" type="text/css" href="../../font.css">
</HEAD>
<BODY color="black" bgcolor="white"> 
<%
on error resume next

'check if there is an error, if so then inform user of error. 
private sub CheckErr
	if Err <> 0 then
		' Display error message
		Response.Write "<P style='BACKGROUND-COLOR: #a52a2a'><FONT color=#ffffff>"
		Response.Write "&nbsp;&nbsp;" & "ERROR:  " & Err.description & "</FONT></P>"
		' Clear error
		Err.Clear
	end if
end sub

'create upload component instance
set objUpload = Server.CreateObject("Dundas.Upload")

objUpload.ProgressID = Request.QueryString("ProgressID")
'if the state server was on a different machine then this is where you would need to 
'  set the IP address of the machine where the state server is located
'objUpload.StateServer = "127.0.0.1"

'initialize the root & temp folders names
RootFolderName = Server.MapPath(".") & "\"			'& "\TempData\"
TempFolderName = RootFolderName & objUpload.GetUniqueName

'don't use unique file names in the beginning
objUpload.UseUniqueNames = false

'upload data till first uploaded file is encountered
set NextFile = objUpload.GetNextFile
call CheckErr

'set the various properties specified by the user
if IsEmpty(objUpload.Form("UniqueNames")) then
	objUpload.UseUniqueNames = false
'else
'	'if "unique file names" are selected set the flag
'	objUpload.UseUniqueNames = true
'
'	'change the NextFile object's name to be unique 
'	if not(NextFile is nothing) then	
'		NextFile.FileName = objUpload.GetUniqueName & "_" &	NextFile.FileName
'	end if
end if 

'set the temp. folder name
if not(IsEmpty(objUpload.Form("FolderName"))) then
	TempFolderName = RootFolderName & objUpload.Form.Item("FolderName")
end if 

'set maximum upload size
if not(IsEmpty(objUpload.Form.Item("MaxUpload"))) then
	objUpload.MaxUploadSize = objUpload.Form.Item("MaxUpload")
	if objUpload.MaxUploadSize <> -1 then
		objUpload.MaxUploadSize = objUpload.MaxUploadSize * 1024
	end if
end if

'set the maximum number of files which can be uploaded at one time
if not(IsEmpty(objUpload.Form.Item("MaxFiles"))) then
	objUpload.MaxFileCount = objUpload.Form.Item("MaxFiles")
end if
'set the maximum file size allowed
if not(IsEmpty(objUpload.Form.Item("MaxSize"))) then
	objUpload.MaxFileSize = objUpload.Form.Item("MaxSize")
	if objUpload.MaxFileSize <> -1 then
		objUpload.MaxFileSize = objUpload.MaxFileSize * 1024
	end if
end if	

'create temp folder
objUpload.DirectoryCreate TempFolderName
call CheckErr

'upload the rest of the files one by one
do until NextFile is nothing
	'save file into the temp. folder
	NextFile.Save TempFolderName
	
	'get Nextfile object
	set NextFile = nothing
	set NextFile = objUpload.GetNextFile

	'exit the loop in case of error	
	if Err <> 0 then
		call CheckErr
		exit do
	end if
loop

topic=objUpload.Form.Item("topics")
user=objUpload.Form.Item("user")
email=objUpload.Form.Item("email")
gdata=objUpload.Form.Item("data")
data=replace(gdata,chr(13),"<br>")
temptime=now
if topic="" or user="" or data="" then
response.write "<table><tr><td>��� Post �������ó� ��سҵ�Ǩ�ͺ��á�͡������<b>�ú��ǹ�������!!</b></td></tr></table>"
else
   With Response
      .Write "<br><table align=center width='100%'>"
      .Write "<tr bgcolor=#0099ff>"
      .Write "<td colspan=2><b>&nbsp;" &topic& "</b></td>"
      .Write "</tr><tr>"
      .Write "<td width='35%' bgcolor=#eeeeee valign=top>" &User& "<br><a href=mailto:" &Email& ">" &Email& "</a><br>" &temptime& "</td>"
      .Write "<td valign=top bgcolor=#eeeeee>" &Data& "</td>"
      .Write "</tr>"
      .Write "</table>"
   End With
end if

'show file items collection
Response.Write "<P style='BACKGROUND-COLOR: #6495ed'><FONT color=#ffffff>"
Response.Write "&nbsp;Number of files uploaded: " & CStr(objUpload.Files.Count) & "</FONT></P>"
it = 0
for each item in objUpload.Files
	Response.Write "<TABLE border=0 cellPadding=0 cellSpacing=1 width='100%'"
	if cint(it/2.)*2 = it then
		Response.Write " style='BACKGROUND-COLOR: #ffffe0'>" 
	else
		Response.Write " style='BACKGROUND-COLOR: #ffffff'>" 
	end if 
	Response.Write "<TR><TD width='18%'>Input Tag name:</TD>"
	Response.Write "<TD>" & item.TagName & "</TD></TR>"
	Response.Write "<TR><TD>Content type:</TD>"
	Response.Write "<TD>" & item.ContentType & "</TD></TR>"
	Response.Write "<TR><TD>Size:</TD>"
	Response.Write "<TD>" & CStr(item.Size) & "</TD></TR>"
	Response.Write "<TR><TD>Original path:</TD>"
	Response.Write "<TD>" & item.OriginalPath & "</TD></TR>"
	Response.Write "<TR><TD>Server path:</TD>"
	Response.Write "<TD>" & item.Path & "</TD></TR>"
	Response.Write "</TABLE>"
	
	if topic="" or user="" or data="" then
	item.Delete		' Delete uploaded file
	end if
	
	it = it + 1
	svp=item.Path
	bsize=item.Size
next
temppath=TempFolderName

call CheckErr

set objUpload = nothing
a=len(svp)
b=len(temppath)
c=a-(b+1)
nfile=Right(svp,c)
%>
<!--#include virtual="/../../conn.asp"-->
<%

	if topic<>"" and user<>"" and data<>"" then
	set	rs=server.createobject("adodb.recordset")
	rs.open "eloadprog",con,0,3,512
	rs.addnew
	rs("ltopic")=topic
	rs("luser")=user
	rs("lmail")=email
	rs("ldata")=data
	rs("ldate")=temptime
	rs("lfile")=nfile
	rs("member_id")=Cint( request.cookies("member_id") )
	rs("lsize")=Cint( bsize )
	rs.update
	rs.close
	end if
con.close
%>
</BODY>
</HTML>
<%
response.redirect "updatedownload.asp"
%>