/* Keyboard driver for PC's and AT's.
 *
 */

#include "kernel.h"
#include <termios.h>
#include <signal.h>
#include <unistd.h>
#include <minix/callnr.h>
#include <minix/com.h>
#include "tty.h"

/* Function key map to CTRL code */
#define	P_MAP   0x0010		/* CTRL+P : map to p_dmp() */
#define MEM_MAP	0x001D		/* CTRL+] : map to mem_dmp() */
#define DP_MAP	0x0005		/* CTRL+E : map to dp_dump() */
#define RESET	0x001E		/* CTRL+SHIFT+6 : map to wreboot() */
#define CATOS   0x001F		/* CTRL+SHIFT+- : show catos logo */
#define COM86	0x0014		/* CTRL+T : show com86 internal register */

/* Miscellaneous. */
#define ESC_KEY	      0x001B    /* ESC key */
#define CONSOLE		   0	/* line number for console */

#define kb_addr()	(&kb_lines[0])	/* there is only one keyboard */
#define KB_IN_BYTES	  32	/* size of keyboard input buffer */

PRIVATE char numpad_map[] =
		{'H', 'Y', 'A', 'B', 'D', 'C', 'V', 'U', 'G', 'S', 'T', '@'};

/* Keyboard structure, 1 per console. */
struct kb_s {
  char *ihead;			/* next free spot in input buffer */
  char *itail;			/* scan code to return to TTY */
  int icount;			/* # codes in buffer */
  char ibuf[KB_IN_BYTES];	/* input buffer */
};

PRIVATE struct kb_s kb_lines[NR_CONS];

FORWARD _PROTOTYPE( int func_key, (int scode) );
FORWARD _PROTOTYPE( void kb_read, (struct tty *tp) );


/*===========================================================================*
 *				kbd_hw_int				     *
 *===========================================================================*/
PUBLIC void kbd_hw_int(void)
{
  char ch;
  register struct kb_s *kb;

  /* Fetch the character from the keyboard buffer pool */
  ch = scan_keyboard();
  if (!ch) return;

  /* Store the character in memory so the task can get at it later. */
  kb = kb_addr();
  if (kb->icount < KB_IN_BYTES) {
	*kb->ihead++ = ch;
	if (kb->ihead == kb->ibuf + KB_IN_BYTES) kb->ihead = kb->ibuf;
	lock(); 
	kb->icount++;
	tty_table[current].tty_events = 1;
	force_timeout(); 
	unlock(); 
  }
}


/*==========================================================================*
 *				kb_read					    *
 *==========================================================================*/
PRIVATE void kb_read(tp)
tty_t *tp;
{
/* Process characters from the circular keyboard buffer. */

  struct kb_s *kb;
  char buf[3];
  char ch;

  kb = kb_addr();
  tp = &tty_table[current];		/* always use the current console */

  while (kb->icount > 0) {
	ch = *kb->itail++;		/* take one key code */
	if (kb->itail == kb->ibuf + KB_IN_BYTES) kb->itail = kb->ibuf;
	lock();
	kb->icount--;
	unlock();

	/* Function keys are being used for debug dumps. */
	if (func_key(ch)) continue; 

	/* check RESET key first */
	if (ch == RESET) wreboot(RBT_HALT);

	/* check for NORMAL key press */
	if (ch <= 0xFF) {
		/* A normal character. */
		buf[0] = ch;
		(void) in_process(tp, buf, 1);
	} 
  }
}


/*===========================================================================*
 *				kb_init					     *
 *===========================================================================*/
PUBLIC void kb_init(tp)
tty_t *tp;
{
/* Initialize the keyboard driver. */

  register struct kb_s *kb;

  /* Input function. */
  tp->tty_devread = kb_read;

  kb = kb_addr();

  /* Set up input queue. */
  kb->ihead = kb->itail = kb->ibuf;
}


/*===========================================================================*
 *				func_key				     *
 *===========================================================================*/
PRIVATE int func_key(ch)
char ch;					/* char for a function key */
{
/* This procedure traps function keys for debugging and control purposes. */

  switch (ch) {					/* include modifiers */
  	case P_MAP:	p_dmp(); break;		/* print process table */
  	case MEM_MAP:	map_dmp(); break;	/* print memory map */
#if ENABLE_NETWORKING
  	case DP_MAP:	dp_dump(); break;	/* network statistics */
#endif
	case CATOS:	p_catos_logo(); break;  /* CATOS logo */
	case COM86:     p_com86(); break;       /* com86 parameter */
  	default:	return(FALSE);
  }
  return(TRUE);
}


/*==========================================================================*
 *				wreboot					    *
 *==========================================================================*/
PUBLIC void wreboot(how)
int how;		/* 0 = halt, 1 = reboot, 2 = panic!, ... */
{
/* Wait for keystrokes for printing debugging info and reboot. */

  int quiet;
  char ch;
  struct tasktab *ttp;

  /* Tell several tasks to stop. */
  cons_stop();
  dp8390_stop();
  clock_stop(); 

  if (how == RBT_HALT) {
	printf("System Halted\n"); 
	how = RBT_PANIC; 
  } 

  if (how == RBT_PANIC) {
	/* A panic! */
	printf("Hit ESC to reboot or F-Keys for debug dumps\n"); 
	for (;;) {
		milli_delay(100);		/* pause for a decisecond */
		ch = scan_keyboard();
		if (ch == ESC_KEY) break; 	/* reboot if ESC typed */
		(void) func_key(ch);	     	/* process function key */
	}
	how = RBT_REBOOT;
  }

  if (how == RBT_REBOOT) printf("Rebooting\n");

  /* Reset the system by jumping to the reset address (real mode) */
  level0(reset); 
}

