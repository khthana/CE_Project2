/* This file contains routines for initializing the 8259 interrupt controller:
 *	get_irq_handler: address of handler for a given interrupt
 *	put_channel_handler: register an interrupt handler
 *	intr_init:	initialize the interrupt controller(s)
 */

#include "kernel.h"
#define NR_EXCEPTION     8

typedef _PROTOTYPE( void (*vecaddr_t), (void) );
FORWARD _PROTOTYPE( int spurious_channel, (int ch) );
FORWARD _PROTOTYPE( void set_vec, (int vec_nr, vecaddr_t addr) );

PRIVATE vecaddr_t exception_vec[] = {
  int00, int01, int02, int03, int04, int05, int06, int07,
};

PRIVATE vecaddr_t channel_vec[] = {
  hwint00, hwint01, hwint02, hwint03, hwint04, hwint05, hwint06, hwint07,
  hwint08, hwint09, hwint10, hwint11, hwint12, hwint13, hwint14, 
};

/*==========================================================================*
 *				intr_init				    *
 *==========================================================================*/
PUBLIC void intr_init(mine)
int mine;
{
  int i;
  lock();
  /* Use the BIOS interrupt vectors in real mode.  We only reprogram the
   * exceptions here, the interrupt vectors are reprogrammed on demand.
   * SYS_VECTOR is the Minix system call for message passing.
   */
  for (i = 0; i < NR_EXCEPTION; i++) set_vec(i, exception_vec[i]);
  set_vec(SYS_VECTOR, s_call);

  /* Initialize the table of interrupt handlers. */
  for (i = 0; i < NR_CHANNEL_VECTORS; i++) channel_table[i] = spurious_channel;
}

/*=========================================================================*
 *				spurious_channel				   *
 *=========================================================================*/
PRIVATE int spurious_channel(ch)
int ch;
{
/* Default interrupt handler.  It complains a lot. */

  if (ch < 0 || ch >= NR_CHANNEL_VECTORS)
	panic("invalid call to spurious_channel", ch);

  printf("spurious channel %d\n", ch);
  p_dmp();
  map_dmp();
  p_com86();

  return 1;	/* Reenable interrupt */
}

/*=========================================================================*
 *				put_channel_handler				   *
 *=========================================================================*/
PUBLIC void put_channel_handler(vec_nr, ch, handler)
int vec_nr;
int ch;
irq_handler_t handler;
{
/* Register an interrupt handler. */

  if (ch < 0 || ch >= NR_CHANNEL_VECTORS)
	panic("invalid call to put_channel_handler", ch);

  if (channel_table[ch] == handler)
	return;		/* extra initialization */

  if (channel_table[ch] != spurious_channel)
	panic("attempt to register second channel handler for channel", ch);

  disable_channel(ch);
  set_vec(vec_nr, channel_vec[ch]);
  channel_table[ch]= handler;
  channel_use |= 1 << ch;
}

/*===========================================================================*
 *                                   set_vec                                 *
 *===========================================================================*/
PRIVATE void set_vec(vec_nr, addr)
int vec_nr;			/* which vector */
vecaddr_t addr;			/* where to start */
{
/* Set up a real mode interrupt vector. */

  u16_t vec[2];

  /* Build the vector in the array 'vec'. */
  vec[0] = (u16_t) addr;
  vec[1] = (u16_t) physb_to_hclick(code_base);

  /* Copy the vector into place. */
  phys_copy(vir2phys(vec), vec_nr * 4L, 4L);
}
