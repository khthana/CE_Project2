object Form1: TForm1
  Left = 254
  Top = 222
  Width = 704
  Height = 480
  Caption = 'Form1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 112
    Top = 8
    Width = 577
    Height = 433
    Caption = 'GroupBox1'
    TabOrder = 1
  end
  object Memo1: TMemo
    Left = 128
    Top = 32
    Width = 545
    Height = 393
    Lines.Strings = (
      'Memo1')
    TabOrder = 0
  end
  object Button1: TButton
    Left = 16
    Top = 24
    Width = 75
    Height = 25
    Caption = 'Button1'
    TabOrder = 2
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 16
    Top = 72
    Width = 75
    Height = 25
    Caption = 'Button2'
    TabOrder = 3
  end
  object OpenDialog1: TOpenDialog
    Left = 640
    Top = 408
  end
end
