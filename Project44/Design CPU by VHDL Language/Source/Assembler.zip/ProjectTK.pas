unit ProjectTK;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ComCtrls, StdCtrls;

type
  TForm1 = class(TForm)
    GroupBox1: TGroupBox;
    Memo1: TMemo;
    Button1: TButton;
    StatusBar1: TStatusBar;
    OpenDialog1: TOpenDialog;
    GroupBox2: TGroupBox;
    Memo2: TMemo;
    SaveDialog1: TSaveDialog;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

const
  REG : Array[0..31] of String = ('00000','00001','00010','00011',
                                  '00100','00101','00110','00111',
                                  '01000','01001','01010','01011',
                                  '01100','01101','01110','01111',
                                  '10000','10001','10010','10011',
                                  '10100','10101','10110','10111',
                                  '11000','11001','11010','11011',
                                  '11100','11101','11110','11111');

var
  Form1: TForm1;
  source :PChar;
  Molecule          : String;
  LD1,LD2,ALU1,ALU2 : String;
  inst,src,dest     : String;
  opcode,operand    : String;
  num               : integer;
  inst_type         : integer;
  decode,line_num   : String;

implementation

{$R *.dfm}

Procedure Atomic (line : String);
begin
  line := line + ' ';
  While Pos(' ',line) = 1 do Delete(line,1,1); { delete space before first atom }
  LD1 := Copy(line,1,Pos(';',line));           { first atom }
  Delete(line,1,Pos(';',line));
  While Pos(' ',line) = 1 do Delete(line,1,1);
  ALU1 := Copy(line,1,Pos(';',line));           { third atom }
  Delete(line,1,Pos(';',line));
end;

Procedure Chop(code : String);
begin
  if Pos(' ',code) = 0 then { inst; ? etc NOP; }
    inst := Copy(code,1,Pos(';',code)-1)
  else
  if (Pos(' ',code) > 0) and (Pos(',',code) = 0) then { inst dest; ? etc PUSH r0; }
  begin
    inst := Copy(code,1,Pos(' ',code)-1);
    Delete(code,1,Pos(' ',code));
    While Pos(' ',code) = 1 do Delete(code,1,1);
    dest := Copy(code,1,Pos(';',code)-1);
  end else
  if Pos(',',code) > 0 then { inst dest,src; ? etc MOV ro,r1; }
  begin
    inst := Copy(code,1,Pos(' ',code)-1);
    Delete(code,1,Pos(' ',code));
    While Pos(' ',code) = 1 do Delete(code,1,1);
    dest := Copy(code,1,Pos(',',code)-1);
    Delete(code,1,Pos(',',code));
    While Pos(' ',code) = 1 do Delete(code,1,1);
    src := Copy(code,1,Pos(';',code)-1);
  end;
end;

Procedure DecInst_ALU_LS;
begin
     if (inst = 'mov') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00100' + '000000000000';
     end
     else
     if (inst = 'mov') and (inst_type = 1) then
     begin
          opcode := opcode + '0' + '00001' + '000000000000';
     end
     else
     if (inst = 'mov') and (inst_type = 2) then
     begin
          opcode := opcode + '0' + '00010' + '000000000000';
     end
     else
     if (inst = 'mov') and (inst_type = 3) then
     begin
          opcode := opcode + '0' + '100'+'000';
     end
     else
     if (inst = 'mov') and (inst_type = 4) then
     begin
          opcode := opcode + '0' + '101'+'000';
     end
     else
     if (inst = 'mov') and (inst_type = 5) then
     begin
          opcode := opcode + '0' + '110'+'000';
     end
     else
     if (inst = 'mov') and (inst_type = 6) then
     begin
          opcode := opcode + '0' + '111'+'000';
     end
     else
     if (inst = 'push') and (inst_type = 7) then
     begin
          opcode := opcode + '0' + '01000' + '00000000000000000';
     end
     else
     if (inst = 'pop') and (inst_type = 7) then
     begin
          opcode := opcode + '0' + '01001' + '00000000000000000';
     end
     else
     if (inst = 'puship') and (inst_type = 9) then
     begin
          opcode := opcode + '0' + '01010' + '0000000000000000000000';
     end
     else
     if (inst = 'popip') and (inst_type = 9) then
     begin
          opcode := opcode + '0' + '01011' + '0000000000000000000000';
     end
     else
     if (inst = 'pushf') and (inst_type = 9) then
     begin
          opcode := opcode + '0' + '01100' + '0000000000000000000000';
     end
     else
     if (inst = 'popf') and (inst_type = 9) then
     begin
          opcode := opcode + '0' + '01101' + '0000000000000000000000';
     end
     else

     if (inst = 'add') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000000' + '000000000';
     end
     else
     if (inst = 'adc') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000001' + '000000000';
     end
     else
     if (inst = 'sub') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000010' + '000000000';
     end
     else
     if (inst = 'sbb') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000011' + '000000000';
     end
     else
     if (inst = 'mul') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000100' + '000000000';
     end
     else
     if (inst = 'imul') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000101' + '000000000';
     end
     else
     if (inst = 'div') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000110' + '000000000';
     end
     else
     if (inst = 'idiv') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00000111' + '000000000';
     end
     else
     if (inst = 'cmp') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00001000' + '000000000';
     end
     else
     if (inst = 'and') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010000' + '000000000';
     end
     else
     if (inst = 'or') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010001' + '000000000';
     end
     else
     if (inst = 'xor') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010010' + '000000000';
     end
     else
     if (inst = 'test') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010011' + '000000000';
     end
     else
     if (inst = 'bt') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010100' + '000000000';
     end
     else
     if (inst = 'btc') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010101' + '000000000';
     end
     else
     if (inst = 'btr') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010110' + '000000000';
     end
     else
     if (inst = 'bts') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00010111' + '000000000';
     end
     else
     if (inst = 'rcl') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011000' + '000000000';
     end
     else
     if (inst = 'rcr') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011001' + '000000000';
     end
     else
     if (inst = 'rol') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011010' + '000000000';
     end
     else
     if (inst = 'ror') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011011' + '000000000';
     end
     else
     if ((inst = 'shl') or (inst = 'sal')) and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011100' + '000000000';
     end
     else
     if (inst = 'shr') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011101' + '000000000';
     end
     else
     if (inst = 'sar') and (inst_type = 0) then
     begin
        opcode := opcode + '0' + '00011110' + '000000000';
     end
     else

     if (inst = 'add') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100000';
     end
     else
     if (inst = 'adc') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100001';
     end
     else
     if (inst = 'sub') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100010';
     end
     else
     if (inst = 'sbb') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100011';
     end
     else
     if (inst = 'mul') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100100';
     end
     else
     if (inst = 'imul') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100101';
     end
     else
     if (inst = 'div') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100110';
     end
     else
     if (inst = 'idiv') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '100111';
     end
     else
     if (inst = 'cmp') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '101000';
     end
     else
     if (inst = 'and') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110000';
     end
     else
     if (inst = 'or') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110001';
     end
     else
     if (inst = 'xor') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110010';
     end
     else
     if (inst = 'test') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110011';
     end
     else
     if (inst = 'bt') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110100';
     end
     else
     if (inst = 'btc') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110101';
     end
     else
     if (inst = 'btr') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110110';
     end
     else
     if (inst = 'bts') and (inst_type = 5) then
     begin
        opcode := opcode + '0' + '110111';
     end
     else

     if (inst = 'rcl') and (inst_type = 10) then
     begin
        opcode := opcode + '0' + '00111000' + '000000';
     end
     else
     if (inst = 'rcr') and (inst_type = 10) then
     begin
        opcode := opcode + '0' + '00111001' + '000000';
     end                 
     else
     if (inst = 'rol') and (inst_type = 10) then
     begin
        opcode := opcode + '0' + '00111010' + '000000';
     end
     else
     if (inst = 'ror') and (inst_type = 10) then
     begin
        opcode := opcode + '0' + '00111011' + '000000';
     end
     else
     if ((inst = 'shl') or (inst = 'sal')) and (inst_type = 10) then
     begin
        opcode := opcode + '0' + '00111100' + '000000';
     end
     else
     if (inst = 'shr') and (inst_type = 10) then
     begin
        opcode := opcode + '0' + '00111101' + '000000';
     end
     else
     if (inst = 'sar') and (inst_type = 10) then
      begin
        opcode := opcode + '0' + '00111110' + '000000';
     end
     else

     if (inst = 'not') and (inst_type = 7) then
     begin
        opcode := opcode + '0' + '01011000' + '00000000000000';
     end
     else
     if (inst = 'inc') and (inst_type = 7) then
     begin
        opcode := opcode + '0' + '01011001' + '00000000000000';
     end
     else
     if (inst = 'dec') and (inst_type = 7) then
     begin
        opcode := opcode + '0' + '01011010' + '00000000000000';
     end
     else
     if (inst = 'neg') and (inst_type = 7) then
     begin
        opcode := opcode + '0' + '01011011' + '00000000000000';
     end
     else

     if (inst = 'stc') and (inst_type = 9) then
     begin
        opcode := opcode + '0' + '01100000' + '0000000000000000000';
     end
     else
     if (inst = 'clc') and (inst_type = 9) then
     begin
        opcode := opcode + '0' + '01100001' + '0000000000000000000';
     end
     else
     if (inst = 'cmc') and (inst_type = 9) then
     begin
        opcode := opcode + '0' + '01100010' + '0000000000000000000';
     end
     else
     if (inst = 'flag') and (inst_type = 9) then
     begin
        opcode := opcode + '0' + '01110000' + '0000000000000000000';
     end
     else
     if (inst = 'nop') and (inst_type = 9) then
     begin
        opcode := opcode + '0' + '01111111' + '0000000000000000000';
     end
     else
        showmessage('Error At Line'+line_num+' ');
end;

Procedure DecInst_ALU;
begin
     if (inst = 'add') and (inst_type = 0) then
     begin
        opcode := opcode + '00000000' + '000000000';
     end
     else
     if (inst = 'adc') and (inst_type = 0) then
     begin
        opcode := opcode + '00000001' + '000000000';
     end
     else
     if (inst = 'sub') and (inst_type = 0) then
     begin
        opcode := opcode + '00000010' + '000000000';
     end
     else
     if (inst = 'sbb') and (inst_type = 0) then
     begin
        opcode := opcode + '00000011' + '000000000';
     end
     else
     if (inst = 'mul') and (inst_type = 0) then
     begin
        opcode := opcode + '00000100' + '000000000';
     end
     else
     if (inst = 'imul') and (inst_type = 0) then
     begin
        opcode := opcode + '00000101' + '000000000';
     end
     else
     if (inst = 'div') and (inst_type = 0) then
     begin
        opcode := opcode + '00000110' + '000000000';
     end
     else
     if (inst = 'idiv') and (inst_type = 0) then
     begin
        opcode := opcode + '00000111' + '000000000';
     end
     else
     if (inst = 'cmp') and (inst_type = 0) then
     begin
        opcode := opcode + '00001000' + '000000000';
     end
     else
     if (inst = 'and') and (inst_type = 0) then
     begin
        opcode := opcode + '00010000' + '000000000';
     end
     else
     if (inst = 'or') and (inst_type = 0) then
     begin
        opcode := opcode + '00010001' + '000000000';
     end
     else
     if (inst = 'xor') and (inst_type = 0) then
     begin
        opcode := opcode + '00010010' + '000000000';
     end
     else
     if (inst = 'test') and (inst_type = 0) then
     begin
        opcode := opcode + '00010011' + '000000000';
     end
     else
     if (inst = 'bt') and (inst_type = 0) then
     begin
        opcode := opcode + '00010100' + '000000000';
     end
     else
     if (inst = 'btc') and (inst_type = 0) then
     begin
        opcode := opcode + '00010101' + '000000000';
     end
     else
     if (inst = 'btr') and (inst_type = 0) then
     begin
        opcode := opcode + '00010110' + '000000000';
     end
     else
     if (inst = 'bts') and (inst_type = 0) then
     begin
        opcode := opcode + '00010111' + '000000000';
     end
     else
     if (inst = 'rcl') and (inst_type = 0) then
     begin
        opcode := opcode + '00011000' + '000000000';
     end
     else
     if (inst = 'rcr') and (inst_type = 0) then
     begin
        opcode := opcode + '00011001' + '000000000';
     end
     else
     if (inst = 'rol') and (inst_type = 0) then
     begin
        opcode := opcode + '00011010' + '000000000';
     end
     else
     if (inst = 'ror') and (inst_type = 0) then
     begin
        opcode := opcode + '00011011' + '000000000';
     end
     else
     if ((inst = 'shl') or (inst = 'sal')) and (inst_type = 5) then
     begin
        opcode := opcode + '00011100' + '000000000';
     end
     else
     if (inst = 'shr') and (inst_type = 0) then
     begin
        opcode := opcode + '00011101' + '000000000';
     end
     else
     if (inst = 'sar') and (inst_type = 0) then
     begin
        opcode := opcode + '00011110' + '000000000';
     end
     else

     if (inst = 'add') and (inst_type = 5) then
     begin
        opcode := opcode + '100000';
     end
     else
     if (inst = 'adc') and (inst_type = 5) then
     begin
        opcode := opcode + '100001';
     end
     else
     if (inst = 'sub') and (inst_type = 5) then
     begin
        opcode := opcode + '100010';
     end
     else
     if (inst = 'sbb') and (inst_type = 5) then
     begin
        opcode := opcode + '100011';
     end
     else
     if (inst = 'mul') and (inst_type = 5) then
     begin
        opcode := opcode + '100100';
     end
     else
     if (inst = 'imul') and (inst_type = 5) then
     begin
        opcode := opcode + '100101';
     end
     else
     if (inst = 'div') and (inst_type = 5) then
     begin
        opcode := opcode + '100110';
     end
     else
     if (inst = 'idiv') and (inst_type = 5) then
     begin
        opcode := opcode + '100111';
     end
     else
     if (inst = 'cmp') and (inst_type = 5) then
     begin
        opcode := opcode + '101000';
     end
     else
     if (inst = 'and') and (inst_type = 5) then
     begin
        opcode := opcode + '110000';
     end
     else
     if (inst = 'or') and (inst_type = 5) then
     begin
        opcode := opcode + '110001';
     end
     else
     if (inst = 'xor') and (inst_type = 5) then
     begin
        opcode := opcode + '110010';
     end
     else
     if (inst = 'test') and (inst_type = 5) then
     begin
        opcode := opcode + '110011';
     end
     else
     if (inst = 'bt') and (inst_type = 5) then
     begin
        opcode := opcode + '110100';
     end
     else
     if (inst = 'btc') and (inst_type = 5) then
     begin
        opcode := opcode + '110101';
     end
     else
     if (inst = 'btr') and (inst_type = 5) then
     begin
        opcode := opcode + '110110';
     end
     else
     if (inst = 'bts') and (inst_type = 5) then
     begin
        opcode := opcode + '110111';
     end
     else

     if (inst = 'rcl') and (inst_type = 10) then
     begin
        opcode := opcode + '00111000' + '000000';
     end
     else
     if (inst = 'rcr') and (inst_type = 10) then
     begin
        opcode := opcode + '00111001' + '000000';
     end
     else
     if (inst = 'rol') and (inst_type = 10) then
     begin
        opcode := opcode + '00111010' + '000000';
     end
     else
     if (inst = 'ror') and (inst_type = 10) then
     begin
        opcode := opcode + '00111011' + '000000';
     end
     else
     if ((inst = 'shl') or (inst = 'sal')) and (inst_type = 10) then
     begin
        opcode := opcode + '00111100' + '000000';
     end
     else
     if (inst = 'shr') and (inst_type = 10) then
     begin
        opcode := opcode + '00111101' + '000000';
     end
     else
     if (inst = 'sar') and (inst_type = 10) then
      begin
        opcode := opcode + '00111110' + '000000';
     end
     else

     if (inst = 'not') and (inst_type = 7) then
     begin
        opcode := opcode + '01011000' + '00000000000000';
     end
     else
     if (inst = 'inc') and (inst_type = 7) then
     begin
        opcode := opcode + '01011001' + '00000000000000';
     end
     else
     if (inst = 'dec') and (inst_type = 7) then
     begin
        opcode := opcode + '01011010' + '00000000000000';
     end
     else
     if (inst = 'neg') and (inst_type = 7) then
     begin
        opcode := opcode + '01011011' + '00000000000000';
     end
     else

     if (inst = 'jo') and (inst_type = 7) then
     begin
        opcode := opcode + '01000000' + '00000000000000';
     end
     else
     if (inst = 'jno') and (inst_type = 7) then
     begin
        opcode := opcode + '01000001' + '00000000000000';
     end
     else
     if ((inst = 'jb') or (inst = 'jnae')) and (inst_type = 7) then
     begin
        opcode := opcode + '01000010' + '00000000000000';
     end
     else
     if ((inst = 'jae') or (inst = 'jnb')) and (inst_type = 7) then
     begin
        opcode := opcode + '01000011' + '00000000000000';
     end
     else
     if ((inst = 'jne') or (inst = 'jnz')) and (inst_type = 7) then
     begin
        opcode := opcode + '01000100' + '00000000000000';
     end
     else
     if ((inst = 'je') or (inst = 'jz')) and (inst_type = 7) then
     begin
        opcode := opcode + '01000101' + '00000000000000';
     end
     else
     if ((inst = 'jbe') or (inst = 'jna')) and (inst_type = 7) then
     begin
        opcode := opcode + '01000110' + '00000000000000';
     end
     else
     if ((inst = 'ja') or (inst = 'jnbe')) and (inst_type = 7) then
     begin
        opcode := opcode + '01000111' + '00000000000000';
     end
     else
     if (inst = 'js') and (inst_type = 7) then
     begin
        opcode := opcode + '01001000' + '00000000000000';
     end
     else
     if (inst = 'jns') and (inst_type = 7) then
     begin
        opcode := opcode + '01001001' + '00000000000000';
     end
     else
     if ((inst = 'jp') or (inst = 'jpe')) and (inst_type = 7) then
     begin
        opcode := opcode + '01001010' + '00000000000000';
     end
     else
     if ((inst = 'jnp') or (inst = 'jpo')) and (inst_type = 7) then
     begin
        opcode := opcode + '01001011' + '00000000000000';
     end
     else
     if ((inst = 'jl') or (inst = 'jnge')) and (inst_type = 7) then
     begin
        opcode := opcode + '01001100' + '00000000000000';
     end
     else
     if ((inst = 'jnl') or (inst = 'jge')) and (inst_type = 7) then
     begin
        opcode := opcode + '01001101' + '00000000000000';
     end
     else
     if ((inst = 'jle') or (inst = 'jng')) and (inst_type = 7) then
     begin
        opcode := opcode + '01001110' + '00000000000000';
     end
     else
     if ((inst = 'jg') or (inst = 'jnle')) and (inst_type = 7) then
     begin
        opcode := opcode + '01001111' + '00000000000000';
     end
     else
     if (inst = 'jmp') and (inst_type = 7) then
     begin
        opcode := opcode + '01010000' + '00000000000000';
     end
     else

     if (inst = 'stc') and (inst_type = 9) then
     begin
        opcode := opcode + '01100000' + '0000000000000000000';
     end
     else
     if (inst = 'clc') and (inst_type = 9) then
     begin
        opcode := opcode + '01100001' + '0000000000000000000';
     end
     else
     if (inst = 'cmc') and (inst_type = 9) then
     begin
        opcode := opcode + '01100010' + '0000000000000000000';
     end
     else
     if (inst = 'flag') and (inst_type = 9) then
     begin
        opcode := opcode + '01110000' + '0000000000000000000';
     end
     else
     if (inst = 'nop') and (inst_type = 9) then
     begin
        opcode := opcode + '01111111' + '0000000000000000000';
     end
     else
        showmessage('Error At Line'+line_num+' ');
end;

function hextobin(S: string): string;
var
  I     : Integer;
  ret   : string;
begin
  ret :='';
  for I := 1 to Length(S) do
  case S[I] of
       '0':  ret := ret +'0000';
       '1':  ret := ret +'0001';
       '2':  ret := ret +'0010';
       '3':  ret := ret +'0011';
       '4':  ret := ret +'0100';
       '5':  ret := ret +'0101';
       '6':  ret := ret +'0110';
       '7':  ret := ret +'0111';
       '8':  ret := ret +'1000';
       '9':  ret := ret +'1001';
       'A':  ret := ret +'1010';
       'B':  ret := ret +'1011';
       'C':  ret := ret +'1100';
       'D':  ret := ret +'1101';
       'E':  ret := ret +'1110';
       'F':  ret := ret +'1111';
  end;
  hextobin := ret;
end;

Procedure DecOperand;
var       num_src,num_dest : integer;
          Code             : Integer;
          num         : string;

begin
     { r0,r1}
     if (pos('r',dest) = 1) and (pos('[',dest)=0) and (pos('#',dest)=0) and (pos('[',src)=0) and (pos('r',src)=1) and (pos('#',src)=0)then
     begin
          delete(src,Pos('r',src),1);
          val(src,num_src,Code);
          delete(dest,Pos('r',dest),1);
          val(dest,num_dest,Code);
          operand := reg[num_src] + reg[num_dest];
          inst_type := 0;
     end
     else
     { r0,[r1]}
     if (pos('r',dest) = 1) and (pos('[',dest)=0) and (pos('#',dest)=0) and (pos('[',src)=1) and (pos('r',src)=2) and (pos('#',src)=0) then
     begin
          delete(src,Pos('[',src),1);
          delete(src,Pos('r',src),1);
          delete(src,Pos(']',src),1);
          val(src,num_src,Code);
          delete(dest,Pos('r',dest),1);
          val(dest,num_dest,Code);
          operand := reg[num_src] + reg[num_dest];
          inst_type := 1;
     end
     else
     { [r0],r1}
     if (pos('r',dest) = 2) and (pos('[',dest)=1) and (pos('#',dest)=0) and (pos('[',src)=0) and (pos('r',src)=1) and (pos('#',src)=0) then
     begin
          delete(src,Pos('r',src),1);
          val(src,num_src,Code);
          delete(dest,Pos('[',dest),1);
          delete(dest,Pos('r',dest),1);
          delete(dest,Pos(']',dest),1);
          val(dest,num_dest,Code);
          operand := reg[num_src] + reg[num_dest];
          inst_type := 2;
     end
     else
     { r0,[#0000]}
     if (pos('r',dest) = 1) and (pos('[',dest)=0) and (pos('#',dest)=0) and (pos('[',src)=1) and (pos('r',src)=0) and (pos('#',src)=2) then
     begin
          delete(src,Pos('[',src),1);
          delete(src,Pos('#',src),1);
          delete(src,Pos(']',src),1);
          num := hextobin(src);
          delete(dest,Pos('r',dest),1);
          val(dest,num_dest,Code);
          operand := num + reg[num_dest];
          inst_type := 3;
     end
     else
     { [#0000],r0}
     if (pos('r',dest) = 0) and (pos('[',dest)=1) and (pos('#',dest)=2) and (pos('[',src)=0) and (pos('r',src)=1) and (pos('#',src)=0) then
     begin
          delete(src,Pos('r',src),1);
          val(src,num_src,Code);
          delete(dest,Pos('[',dest),1);
          delete(dest,Pos('#',dest),1);
          delete(dest,Pos(']',dest),1);
          num := hextobin(dest);
          operand := num + reg[num_src];
          inst_type := 4;
     end
     else
     { r0,#0000}
     if (pos('r',dest) = 1) and (pos('[',dest)=0) and (pos('#',dest)=0) and (pos('[',src)=0) and (pos('r',src)=0) and (pos('#',src)=1) and (length(src)=5) then
     begin
          delete(src,Pos('#',src),1);
          num := hextobin(src);
          delete(dest,Pos('r',dest),1);
          val(dest,num_dest,Code);
          operand := num + reg[num_dest];
          inst_type := 5;
     end
     else
     { [r0],#0000}
     if (pos('r',dest) = 2) and (pos('[',dest)=1) and (pos('#',dest)=0) and (pos('[',src)=0) and (pos('r',src)=0) and (pos('#',src)=1) then
     begin
          delete(src,Pos('#',src),1);
          num := hextobin(src);
          delete(dest,Pos('[',dest),1);
          delete(dest,Pos('r',dest),1);
          delete(dest,Pos(']',dest),1);
          val(dest,num_dest,Code);
          operand := num + reg[num_dest];
          inst_type := 6;
     end
     else
     { r0}
     if (pos('[',dest) = 0)and (pos('r',dest)=1) and (pos('#',src) =0) and (pos('[',src)=0) and (pos('r',src)=0) then
     begin
          delete(dest,Pos('r',dest),1);
          val(dest,num_dest,Code);
          operand := reg[num_dest];
          inst_type := 7;
     end
     else
     { #0000}
     if (pos('[',dest) = 0)and (pos('#',dest)=1) and (pos('#',src) =0) and (pos('[',src)=0) and (pos('r',src)=0) then
     begin
          delete(dest,Pos('#',dest),1);
          num := hextobin(dest);
          operand := num;
          inst_type := 8;
     end
     else
     { non}
     if (dest = '') and (src = '') then
     begin
          operand := '';
          inst_type := 9;
     end
     else
     { r0,#00}
     if (pos('r',dest) = 1) and (pos('[',dest)=0) and (pos('#',dest)=0) and (pos('[',src)=0) and (pos('r',src)=0) and (pos('#',src)=1) and (length(src)=3) then
     begin
          delete(src,Pos('#',src),1);
          num := hextobin(src);
          delete(dest,Pos('r',dest),1);
          val(dest,num_dest,Code);
          operand := num + reg[num_dest];
          inst_type := 10;
     end
     else
        showmessage('Error At Line'+line_num+' ');     
end;

Procedure DecLD1;
begin
     DecOperand;
     DecInst_ALU_LS;
     decode := decode + opcode + operand;
end;

Procedure DecALU;
begin
     DecOperand;
     DecInst_ALU;
     decode := decode + opcode + operand;
end;

procedure TForm1.Button1Click(Sender: TObject);
var f:textfile; tmp,temp :string;
begin
  if opendialog1.Execute() then
  begin
    assignfile(f,opendialog1.FileName);
    reset(f);
    memo1.Clear();
    memo2.Clear();
    num := 0;
    while not eof(f) do
    begin
      num := num +1;
      readln(f,temp);
      str(num,line_num);
      memo1.Lines.Add(line_num+'    '+temp);
      molecule := temp;
      Atomic(molecule);
      Chop(LD1);
      DecLD1;
      opcode :='';
      dest :='';
      src :='';
      tmp := decode;
      decode :='';
    	Chop(ALU1);
      DecALU;
      opcode :='';
      dest :='';
      src :='';
      tmp := tmp + decode;
      memo2.Lines.Add(tmp);
      tmp :='';
      opcode :='';
      decode :='';
      dest :='';
      src :='';
     end;
    closefile(f);
  end;
end;

end.
