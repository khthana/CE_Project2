object Form1: TForm1
  Left = 222
  Top = 147
  Width = 755
  Height = 511
  Caption = 'TK Ass Emble'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 176
    Top = 24
    Width = 561
    Height = 217
    Caption = '  Input  :  '
    TabOrder = 0
    object Memo1: TMemo
      Left = 16
      Top = 24
      Width = 529
      Height = 177
      Font.Charset = THAI_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Cordia New'
      Font.Style = []
      ParentFont = False
      ScrollBars = ssVertical
      TabOrder = 0
    end
  end
  object Button1: TButton
    Left = 40
    Top = 40
    Width = 75
    Height = 25
    Caption = 'Open'
    TabOrder = 1
    OnClick = Button1Click
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 465
    Width = 747
    Height = 19
    Panels = <>
    SimplePanel = False
  end
  object GroupBox2: TGroupBox
    Left = 32
    Top = 256
    Width = 705
    Height = 193
    Caption = '  Output  :  '
    TabOrder = 3
    object Memo2: TMemo
      Left = 16
      Top = 24
      Width = 673
      Height = 153
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Cordia New'
      Font.Style = []
      Lines.Strings = (
        '')
      ParentFont = False
      ScrollBars = ssVertical
      TabOrder = 0
    end
  end
  object OpenDialog1: TOpenDialog
    Filter = 'ASM Files  ( *.asm )|*.asm'
    Left = 8
    Top = 400
  end
  object SaveDialog1: TSaveDialog
    Left = 56
    Top = 400
  end
end
