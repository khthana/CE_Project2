
#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>

#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/l2cap_con.h>
#include <linux/bluetooth/sdp.h>
#include <linux/bluetooth/tcs.h>
#include <linux/bluetooth/test.h>
#include <linux/bluetooth/rfcomm.h>
#include <linux/bluetooth/btcommon.h>
#else
#include <string.h>

#include "include/hci.h"
#include "include/l2cap_con.h"
#include "include/sdp.h"
#include "include/tcs.h"
#include "include/test.h"
#include "include/rfcomm.h"
#include "include/btcommon.h"
#endif

extern rfcomm_con rfcomm_con_list[7];

extern rpn_values rpn_val;

extern tcs_con tcs[1];

extern sdp_con sdp_con_list[7];

extern l2cap_con *testcon; /* is set in test.c */
extern s32 emulate_pending; /* is set in test.c */
extern s32 test_inmtu;
extern s32 dont_send_config_req;
extern s32 use_multiple_conf_params;
extern s32 disable_testpsm;
s32 test_role;

/* ======================================================================== */ 
/* Unplug Test Cases 1-13 */

/* [Test-01] Service search request for UUID 0x1103 (DialUp Profile) */
unsigned char q1_1[] = {0x02, 0x77, 0x77, 0x00, 0x08,
		      0x35, 0x03, 0x19, 0x11, 0x03, 0x00, 0xff, 0x00};

/* Service attribute request for Rec Hdl 00010000
 * Attr :  ProtDescrList 
 */
unsigned char q1_2[] = {0x04, 0x77, 0x77, 0x00, 0x0c,
			0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35, 0x03,
			0x09, 0x00, 0x04, 0x00};

/*  [Test-02] Service browsing. 
 *  Service Search Attribute Req for UUID 1002 (Public 
 *  Browse Group) Attr : ServiceName 
 */
unsigned char q2[] = {0x06, 0x77, 0x77, 0x00, 0x0d,
		      0x35, 0x03, 0x19, 0x10, 0x02, 0x00, 0xff, 0x35,
		      0x03, 0x09, 0x01, 0x00, 0x00};

/* [Test-3] 
 * Continued query with limiting MaximumAttrByteCount
 */
unsigned char q3_1[] = {0x06, 0x77, 0x77, 0x00, 0x0f,
			0x35, 0x03, 0x19, 0x11, 0x05, 0x00, 0x45, 0x35,
			0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00};

/* The continued request */
unsigned char q3_2[] = {0x06, 0x88, 0x88, 0x00, 0x13,
			0x35, 0x03, 0x19, 0x11, 0x05, 0x00, 0x45, 0x35,
			0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x01, 0x00};

/* [Test-04] 
 * Search for non-existing service 
 */
unsigned char q4[] = {0x02, 0x88, 0x88, 0x00, 0x08,
		      0x35, 0x03, 0x19, 0x12, 0x35, 0x00, 0xff, 0x00};

unsigned char q5[] = {0x04, 0x88, 0x88, 0x00, 0x0c,
		      0x12, 0x34, 0x56, 0x78, 0x00, 0xff, 0x35, 0x03,
		      0x09, 0x00, 0x06, 0x00};

unsigned char q6[] = {0x06, 0x88, 0x88, 0x00, 0x0d,
		      0x35, 0x03, 0x19, 0x11, 0x11, 0x00, 0xff, 0x35, 0x03,
		      0x09, 0xab, 0xcd, 0x00};

unsigned char q7[] = {0x04, 0x88, 0x88, 0x00, 0x50,
		      0x00, 0x01, 0x00, 0x02, 0x00, 0xff, 0x35, 0x03, 0x09,
		      0x00, 0x09, 0x00};

unsigned char q8[] = {0x06, 0x88, 0x88, 0x00, 0x0d,
		      0x35, 0x03, 0x09, 0x11, 0x11, 0x00, 0xff, 0x35, 0x03,
		      0x09, 0x00, 0x09, 0x00};

unsigned char q9[] = {0x06, 0x88, 0x88, 0x00, 0x13,
		      0x35, 0x09, 0x19, 0x11, 0x05, 0x19, 0x00, 0x03, 0x19,
		      0x01, 0x00, 0x00, 0xff, 0x35, 0x03, 0x09, 0x00, 0x04,
		      0x00};

unsigned char q10[] = {0x02, 0x88, 0x88, 0x00, 0x08,
		       0x35, 0x03, 0x19, 0x00, 0x03, 0x00, 0x02, 0x00};

unsigned char q11[] = {0x04, 0x88, 0x88, 0x00, 0x12,
		       0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35, 0x09, 0x09,
		       0x00, 0x06, 0x09, 0x00, 0x11, 0x09, 0x01, 0x00, 0x00};

/* ======================================================================== */ 

unsigned char sdp_data_52111[] = { 0x02, 0x77, 0x77, 0x00, 0x08,
				   0x35, 0x03, 0x19, 0x00, 0x01, 0x00, 0xff,
				   0x00 };

unsigned char sdp_data_52113_1[] = { 0x02, 0x77, 0x77, 0x00, 0x08,
				     0x35, 0x03, 0x19, 0x00, 0x01, 0x00, 0x01,
				     0x00 };

unsigned char sdp_data_52113_2[] = { 0x02, 0x77, 0x77, 0x00, 0x09,
				     0x35, 0x03, 0x19, 0x00, 0x01, 0x00, 0x01,
				     0x01, 0x00 };

unsigned char sdp_data_52114[] = { 0x02, 0x77, 0x77, 0x00, 0x08,
				   0x35, 0x03, 0x19, 0x12, 0x34, 0x00, 0xff,
				   0x00 };

unsigned char sdp_data_52121[] = { 0x02, 0x77, 0x77, 0x00, 0x0a,
				   0x35, 0x03, 0x19, 0x00, 0x01, 0x00, 0xff,
				   0x00 };

unsigned char sdp_data_52122[] = { 0x02, 0x77, 0x77, 0x00, 0x06,
				   0x19, 0x00, 0x01, 0x00, 0xff, 0x00 };
  
unsigned char sdp_data_53111[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				   0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				   0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_53113_1[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				     0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x35,
				     0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_53113_2[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				     0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x35,
				     0x03, 0x09, 0x00, 0x01, 0x01 };

unsigned char sdp_data_53114[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				   0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				   0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_53115[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				   0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				   0x03, 0x09, 0x00, 0x04, 0x00 };

unsigned char sdp_data_53118[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				   0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				   0x03, 0x09, 0x00, 0x05, 0x00 };

unsigned char sdp_data_531110[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				    0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				    0x03, 0x09, 0x00, 0x08, 0x00 };

unsigned char sdp_data_531117[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				    0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				    0x03, 0x09, 0x00, 0x09, 0x00 };

unsigned char sdp_data_531120[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				    0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				    0x03, 0x09, 0x01, 0xff, 0x00 };

unsigned char sdp_data_53121[] = { 0x04, 0x88, 0x88, 0x00, 0x0c,
				   0x00, 0x00, 0x00, 0xff, 0x00, 0xff, 0x35,
				   0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_53122[] = { 0x04, 0x88, 0x88, 0x00, 0x0a,
				   0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x09,
				   0x00, 0x01, 0x00 };

unsigned char sdp_data_53123[] = { 0x04, 0x88, 0x88, 0x00, 0x0a,
				   0x00, 0x00, 0x00, 0xff, 0x00, 0xff, 0x35,
				   0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_54111[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				   0x35, 0x03, 0x19, 0x12, 0x34, 0x00, 0xff,
				   0x35, 0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_54112[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				   0x35, 0x03, 0x19, 0x00, 0x01, 0x00, 0xff,
				   0x35, 0x03, 0x09, 0x01, 0xff, 0x00 };

unsigned char sdp_data_54113[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				   0x35, 0x03, 0x19, 0x12, 0x34, 0x00, 0xff,
				   0x35, 0x03, 0x09, 0x01, 0xff, 0x00 };

unsigned char sdp_data_54114[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				   0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				   0x35, 0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_54116_1[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				     0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0x06,
				     0x35, 0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_54116_2[] = { 0x06, 0x88, 0x88, 0x00, 0x0e,
				     0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0x06,
				     0x35, 0x03, 0x09, 0x00, 0x01, 0x01, 0x00 };

unsigned char sdp_data_541110[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				    0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				    0x35, 0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_541111[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				    0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				    0x35, 0x03, 0x09, 0x00, 0x04, 0x00 };

unsigned char sdp_data_541112[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				    0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				    0x35, 0x03, 0x09, 0x00, 0x05, 0x00 };

unsigned char sdp_data_541120[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				    0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				    0x35, 0x03, 0x09, 0x00, 0x09, 0x00 };

unsigned char sdp_data_54121[] = { 0x06, 0x88, 0x88, 0x00, 0x0b,
				   0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				   0x09, 0x00, 0x09, 0x00 };

unsigned char sdp_data_54122[] = { 0x06, 0x88, 0x88, 0x00, 0x0f,
				   0x35, 0x03, 0x19, 0x10, 0x00, 0x00, 0xff,
				   0x35, 0x03, 0x09, 0x00, 0x01, 0x00 };

unsigned char sdp_data_55111_1[] = { 0x02, 0x77, 0x77, 0x00, 0x08,
				     0x35, 0x03, 0x19, 0x10, 0x02, 0x00, 0xff,
				     0x00 };

unsigned char sdp_data_55111_2[] = { 0x04, 0x88, 0x88, 0x00, 0x0e,
				     0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0x35,
				     0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00 };

unsigned char sdp_data_55111_3[] = { 0x04, 0x88, 0x88, 0x00, 0x0e,
				     0x00, 0x10, 0x00, 0x00, 0x00, 0xff, 0x35,
				     0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00 };

unsigned char sdp_data_55111_4[] = { 0x04, 0x88, 0x88, 0x00, 0x0e,
				     0x00, 0x10, 0xff, 0xff, 0x00, 0xff, 0x35,
				     0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00 };

unsigned char sdp_data_55111_5[] = { 0x04, 0x88, 0x88, 0x00, 0x0e,
				     0x00, 0x11, 0xff, 0xff, 0x00, 0xff, 0x35,
				     0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00 };

unsigned char sdp_data_55111_6[] = { 0x04, 0x88, 0x88, 0x00, 0x0e,
				     0x01, 0x00, 0xff, 0xff, 0x00, 0xff, 0x35,
				     0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00 };

unsigned char sdp_data_55111_7[] = { 0x04, 0x88, 0x88, 0x00, 0x0e,
				     0x01, 0x01, 0xff, 0xff, 0x00, 0xff, 0x35,
				     0x05, 0x0a, 0x00, 0x00, 0xff, 0xff, 0x00 };

unsigned char sdp_data_55111_8[] = { 0x02, 0x77, 0x77, 0x00, 0x08,
				     0x35, 0x03, 0x19, 0x10, 0x01, 0x00, 0xff,
				     0x00 };

unsigned char sdp_data_55112_1[] = { 0x06, 0x88, 0x88, 0x00, 0x0f,
				     0x35, 0x03, 0x19, 0x10, 0x02, 0x00, 0xff,
				     0x35, 0x05, 0x0a, 0x00, 0x00, 0xff, 0xff,
				     0x00 };

unsigned char sdp_data_55112_2[] = { 0x06, 0x88, 0x88, 0x00, 0x0f,
				     0x35, 0x03, 0x19, 0x10, 0x01, 0x00, 0xff,
				     0x35, 0x05, 0x0a, 0x00, 0x00, 0xff, 0xff,
				     0x00 };

extern u8 testdata[];
static u8 test_is_initialized = 0;

static void
unplug_test_init(void)
{
	/* initializes temp data */
	s32 i;
	printk("Initializing Unplug Test\n");

	/* group data into 0xff chunks */
	for (i = 0; i < UPTEST_DATA_LEN; i++) {
		*(testdata+i) = (u8) i%0x100;
	}
	test_is_initialized = 1;
}

#define SERVER 0
#define CLIENT 1

static s32 test_server(void)
{
	printk("Now we are test server (device A)\n");
	test_role = SERVER;
	return 0;
}

static s32 test_client(void)
{
	printk("Now we are test client (device B)\n");
	test_role = CLIENT;
	return 0;
}



/* 
 * FIXME - do complete test 'scripts' that runs through all the test
 * on one section 
 */

/* 
 * L2CAP stuff 
 */


/*
 * Test case 1 : Opening of a Connection-Oriented Channel, 
 *
 * (see bttest.c, issue command 'test_conn <bd addr> <psm>')
 */

/*
 * Test case : Data transfer via Open L2CAP Channel (L2CAP Test 2)
 */

/*
 * Test case : Data transfer via Open L2CAP Channel (L2CAP Test 3)
 */

static s32 test_2_2_1(void)
{
	/* client sends 10 bytes */
	printk("test_2_2_1, client sends 10 bytes\n"); 
	return test_send_data(testcon, testdata, 10);
}

static s32 test_2_2_2(void)
{
	/* client sends 350 bytes */
	printk("test_2_2_2, client sends 350 bytes\n"); 
	return test_send_data(testcon, testdata, 350);
}

static s32 test_2_2_3(void)
{
	/* client sends 672 bytes */
	printk("test_2_2_3, client sends 672 bytes\n"); 
	return test_send_data(testcon, testdata, 672);
}

static s32 test_2_2_4(void)
{
	/* server sends 10 bytes */
	printk("test_2_2_4, server sends 10 bytes\n"); 
	return test_send_data(testcon, testdata, 10);
}

static s32 test_2_2_5(void)
{
	/* server sends 350 bytes */
	printk("test_2_2_5, server sends 350 bytes\n"); 
	return test_send_data(testcon, testdata, 350);
}

static s32 test_2_2_6(void)
{
	/* server sends 672 bytes */
	printk("test_2_2_6, server sends 672 bytes\n"); 
	return test_send_data(testcon, testdata, 672);
}

static s32 test_2_3(void)
{
	printk("test_2_3, disconnect\n");
	return test_disconnect_req(testcon);
}


 
/*
 * Test case : Echo
 * Device A Initiator (L2CAP Test 4)
 *
 */
/*  upt t 241 */

/*

 * Test case : Re-Configuration, using assymetric MTU:s and
 * Data Transferred (L2CAP Test 5)
 */

#define OPTION_MTU1 4096
#define OPTION_MTU2 8192

static s32 test_2_5_1(void)
{
	s32 retval = 0;
	printk("[Client] Sending config req for mtu = %d\n", OPTION_MTU1);
	if ((retval = l2ca_config_req(testcon, OPTION_MTU1, NULL, 0, 0)) < 0) {
		D_ERR("l2ca_connect_cfm : Configuration request failed\n");
	}
	return retval;
}

static s32 test_2_5_2(void)
{
	printk("[Server] Set our in_mtu to :%d\n", OPTION_MTU2);
	test_inmtu = OPTION_MTU2;
	return 0;
}


static s32 test_2_5_3(void)
{
	s32 retval = 0;
	printk("[Client] Sending config req for mtu = %d\n", OPTION_MTU2);
	if ((retval = l2ca_config_req(testcon, OPTION_MTU2, NULL, 0xffff, 0)) < 0) {
		D_ERR("l2ca_connect_cfm : Configuration request failed\n");
	}
	return retval;
}

static s32 test_2_5_4(void)
{
	printk("[Server] Set our in_mtu to :%d\n", OPTION_MTU1);
	test_inmtu = OPTION_MTU1;
	return 0;
}

static s32 test_2_5_5(void)
{
	/* Client sends 8192 bytes of data */
	printk("Sends 8192 bytes\n");
	return test_send_data(testcon, testdata, 8192);
}

static s32 test_2_5_6(void)
{
	printk("Sending 4096 bytes\n");
	/* Server sends 4096 bytes of data */
	return test_send_data(testcon, testdata, 4096);
}

/*
 * Test case : Connection reject on psm 0x4561
 */

static s32 test_2_6_1(void)
{
	printk("Now disabling test psm\n");
	disable_testpsm = 1;
	return 0;
}

/*
 * Test case : Echo (server) (L2CAP Test 7)
 * handled automatically in l2cap
 */
 
/*
 * Test case : Connection Request Rejected (L2CAP Test 8, 9)
 * (see btd.c, issue 'test_con <bd> 4561' )
 */


static s32 test_2_7_2(void)
{
	printk("Emulating authorization pending...\n");
	emulate_pending = 1;
	return 0;
}

static s32 test_2_8_1(void)
{
	printk("Client sends 350 bytes on testcon 1\n");
	return test_send_data(testcon, testdata, 350);
}

static s32 test_2_8_2(void)
{
	printk("Server sends 350 bytes on testcon 1\n");
	return test_send_data(testcon, testdata, 350);
}

static s32 test_2_8_3(void)
{
	printk("Client sends 350 bytes on testcon 2\n");
	return test_send_data(testcon2, testdata, 350);
}

static s32 test_2_8_4(void)
{
	printk("Server sends 350 bytes on testcon 2\n");
	return test_send_data(testcon2, testdata, 350);
}

static s32 test_2_9_1(void)
{
	s32 retval = 0;
	printk("Now testing timeout in reconfigure state\n");
	printk("Client tries to reconfigure mtu 4096\n");

	if ((retval = l2ca_config_req(testcon, 4096, NULL, 0xffff, 0)) < 0){
		D_ERR("test_connect_cfm : Configuration request failed\n");
	}
	return retval;
}

static s32 test_2_9_2(void)
{
	printk("Server won't send a config req back...\n");
	dont_send_config_req = 1;
	return 0;
}


static s32 test_2_10(void)
{
	/* set to use mutiple config parameters */
	printk("Using multiple config parameters\n");
	use_multiple_conf_params = 1;
	return 0;
}

#if 0
typedef struct flow {
	u8 type; /* = 0x3 or 0x4 ??? */
	u8 len; /* = 22 (0x16) */
	u8 flags; /* default 0 */
	u8 service; /* default 0x01 (best effort) */
	u32 token_rate;
	u32 bucket_size; /* bytes */
	u32 peak; /* bps */
	u32 latency; /* ms */ 
	u32 delay; /* ms */
} flow;
#endif

static s32 test_2_13_1(void)
{
	s32 retval = 0;
	flow qos;
	init_flow(&qos);
	qos.bucket_size = 0x16;
	qos.flags = 0;
	qos.service = 0x2;

	printk("Client sending QOS options\n");
	if ((retval = l2ca_config_req(testcon, 0, &qos, 0, 0)) < 0) {
		D_ERR("test_connect_cfm : Configuration request failed\n");
	}
	return retval;
}



static s32 test_2_13_5(void)
{
	printk("test_2_13_5, client sending 672 bytes\n"); 
	return test_send_data(testcon, testdata, 672);	
}

static s32 test_2_13_6(void)
{
	printk("test_2_13_6, server sending 672 bytes\n"); 
	return test_send_data(testcon, testdata, 672);	
}

/*
 * SDP Stuff
 */

s32 do_sdp_test(int n)
{
	unsigned char *q;
	int q_len;
	printk(__FUNCTION__" -- %d\n", n);
	switch(n) {
		
	case 101: q = q1_1; break;
	case 102: q = q1_2; break;
	case 2:  q = q2; break;
	case 301: q = q3_1; break;
	case 302: q = q3_2; break;
	case 4:  q = q4; break;
	case 5:  q = q5; break;
	case 6:  q = q6; break;
	case 7:  q = q7; break;
	case 8:  q = q8; break;
	case 9:  q = q9; break;
	case 10: q = q10; break;
	case 11: q = q11; break;
	default: printk("Unknown SDP test.\n");
		return -1;
	}

	q_len = q[4] + 5; /* assumes less than 255 bytes long pdu:s */
	
	/* Now send the request */  
	return sdp_send_data(&sdp_con_list[0], q, q_len);
}



static s32 sdp_test_52111(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_52111, sdp_data_52111[4] + 5);
}

static s32 sdp_test_52113(void)
{
	static int t = 0;
	s32 retval = 0;
	
	if (!t) {
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_52113_1, sdp_data_52113_1[4] + 5);
		t = 1;
	} else {
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_52113_2, sdp_data_52113_2[4] + 5);
		t = 0;
	}
	return retval;
}


static s32 sdp_test_52114(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_52114, sdp_data_52114[4] + 5);
}

static s32 sdp_test_52121(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_52121, sdp_data_52121[4] + 5);
}

static s32 sdp_test_52122(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_52122, sdp_data_52122[4] + 5);
}

static s32 sdp_test_53111(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53111, sdp_data_53111[4] + 5);
}

static s32 sdp_test_53113(void)
{
	static int t = 0;
	s32 retval;
	
	if (!t) {
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_53113_1, sdp_data_53113_2[4] + 5);
		t = 1;
	} else {
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_53113_2, sdp_data_53113_2[4] + 5);
		t = 0;
	}
	return retval;
}

static s32 sdp_test_53114(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53114, sdp_data_53114[4] + 5);
}

static s32 sdp_test_53115(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53115, sdp_data_53115[4] + 5);
}

static s32 sdp_test_53118(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53118, sdp_data_53118[4] + 5);
}

static s32 sdp_test_531110(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_531110, sdp_data_531110[4] + 5);
}

static s32 sdp_test_531117(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_531117, sdp_data_531117[4] + 5);
}

static s32 sdp_test_531120(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_531120, sdp_data_531120[4] + 5);
}

static s32 sdp_test_53121(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53121, sdp_data_53121[4] + 5);
}

static s32 sdp_test_53122(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53122, sdp_data_53122[4] + 5);
}

static s32 sdp_test_53123(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_53123, sdp_data_53123[4] + 5);
}

static s32 sdp_test_54111(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_54111, sdp_data_54111[4] + 5);
}

static s32 sdp_test_54112(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_54112, sdp_data_54112[4] + 5);
}

static s32 sdp_test_54113(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_54113, sdp_data_54113[4] + 5);
}

static s32 sdp_test_54114(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_54114, sdp_data_54114[4] + 5);
}

static s32 sdp_test_54116(void)
{
	static int t = 0;
	s32 retval;
	if (!t) {
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_54116_1, sdp_data_54116_1[4] + 5);
		t = 1;
	} else {
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_54116_2, sdp_data_54116_2[4] + 5);
		t = 0;
	} 
	return retval;
}

static s32 sdp_test_541110(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_541110, sdp_data_541110[4] + 5);
}

static s32 sdp_test_541111(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_541111, sdp_data_541111[4] + 5);
}

static s32 sdp_test_541112(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_541112, sdp_data_541112[4] + 5);
}

static s32 sdp_test_541120(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_541120, sdp_data_541120[4] + 5);
}

static s32 sdp_test_54121(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_54121, sdp_data_54121[4] + 5);
}

static s32 sdp_test_54122(void)
{
	return sdp_send_data(&sdp_con_list[0], sdp_data_54122, sdp_data_54122[4] + 5);
}

static s32 sdp_test_55111(void)
{
	static int t = 0;
	s32 retval = 0;
	
	switch (t) {
	case 0:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_1, sdp_data_55111_1[4] + 5);
		t = 1;
		break;

	case 1:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_2, sdp_data_55111_2[4] + 5);
		t = 2;
//		break;
	case 2:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_3, sdp_data_55111_3[4] + 5);
		t = 3;
//		break;
	case 3:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_4, sdp_data_55111_4[4] + 5);
		t = 4;
//		break;
	case 4:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_5, sdp_data_55111_5[4] + 5);
		t = 5;
//		break;
	case 5:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_6, sdp_data_55111_6[4] + 5);
		t = 6;
//		break;
	case 6:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_7, sdp_data_55111_7[4] + 5);
		t = 7;
//		break;
	case 7:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55111_8, sdp_data_55111_8[4] + 5);
		t = 0;
		break;  
	} 
	return retval;
}

static s32 sdp_test_55112(void)
{
	static int t = 0;
	s32 retval = 0;
	switch (t) {
	case 0:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55112_1, sdp_data_55112_1[4] + 5);
		t = 1;
		break;

	case 1:
		retval = sdp_send_data(&sdp_con_list[0], sdp_data_55112_2, sdp_data_55112_2[4] + 5);
		t = 0;
		break;
	}
	return retval;
}


/*
 * Serial Port Profile Stuff
 */

static s32 spp_test_52211(void)
{
	static int t = 0;
	s32 retval = 0;
  
	unsigned char sdp_query[] = { 0x06, 0x88, 0x88, 0x00, 0x0d,
				      0x35, 0x03, 0x19, 0x11, 0x01, 0x00, 0xff,
				      0x35, 0x03, 0x09, 0x00, 0x04, 0x00 };

	switch (t) {
	case 0:
		retval = sdp_send_data(&sdp_con_list[0], sdp_query, sdp_query[4] + 5);
		t++;
		break;

	case 1:
		printk(__FUNCTION__": Establish RFCOMM on channel 0\n");
		t++;
		break;

	case 2:
		printk(__FUNCTION__": Establish RFCOMM on channel 2\n");
		t = 0;
		break;
	}
	return retval;
}

static s32 spp_test_52311(void)
{
	static int t = 0;
	s32 retval = 0;
	
	switch (t) {
	case 0:
		retval = hci_sniff_mode(rfcomm_con_list[0].l2cap->hci_hdl, 0xff, 0xf0, 0x10, 0x05);
		t = 1;
		break;

	case 1:
		retval = hci_exit_sniff_mode(rfcomm_con_list[0].l2cap->hci_hdl);
		t = 0;
		break;
	}
	return retval;
}

static s32 spp_test_52312(void)
{
	static int t = 0;
	s32 retval = 0;

	switch (t) {
	case 0:
		retval = hci_park_mode(rfcomm_con_list[0].l2cap->hci_hdl, 0xfff, 0xf0);
		t = 1;
		break;

	case 1:
		retval = hci_exit_park_mode(rfcomm_con_list[0].l2cap->hci_hdl);
		t = 0;
		break;
	}
	return retval;
}

static s32 spp_test_52313(void)
{
	return hci_hold_mode(rfcomm_con_list[0].l2cap->hci_hdl, 0xfff, 0xf0);
}

static s32 spp_test_52314(void)
{
	printk(__FUNCTION__": Do test 52211, then do a M/S switch\n");
	return 0;
}


static s32 spp_test_53112(void)
{
	/* Establish a L2CAP channel in PSM 3 (RFCOMM), before doing this test */

	return rfcomm_sabm_msg(&rfcomm_con_list[0], 0);
}

static s32 spp_test_53211(void)
{
	/* This test has to be done rigth after test 53112 */

	return rfcomm_disc_msg(&rfcomm_con_list[0], 0);
}

static s32 spp_test_53312(void)
{
	/* Establish a L2CAP channel in PSM 3 (RFCOMM), and establish DLCI 0
	   before doing this test */

	return rfcomm_sabm_msg(&rfcomm_con_list[0], 2);
}

static s32 spp_test_53411(void)
{
	/* Establish a L2CAP channel in PSM 3 (RFCOMM), and establish DLCI 0
	   and 2 before doing this test */

	/* Here the BAP should send the disc command so we just have to wait
	   for that, rf_disc should probably work in the BAP */
	return 0;
}

static s32 spp_test_53412(void)
{
	/* This test has to be done rigth after test 53116 */

	return rfcomm_disc_msg(&rfcomm_con_list[0], 2);
}

static s32 spp_test_53511(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */

	/* Send data from the BAp with the rf_send command */
  
	return rfcomm_msc_msg(&rfcomm_con_list[0], 0x85 ,MCC_CMD, 2);
}

static s32 spp_test_53611(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */
  
	/* Then send data from the BAP with the rf_send command */
	return 0;
}

static s32 spp_test_53711(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */

	unsigned char data[] = {0,1,2,3,4,5,6,7,9};

	/* We send a test messages of ten bytes size */
	return rfcomm_test_msg(&rfcomm_con_list[0], data, 10, MCC_CMD);
}

static s32 spp_test_53811(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */
	s32 retval = 0;
	static int t = 0;

	switch (t) {
	case 0:
		retval = rfcomm_fcoff_msg(&rfcomm_con_list[0], MCC_CMD);
		printk(__FUNCTION__": Flow is set to OFF\n");
		t++;
		break;

	case 1:
		retval = rfcomm_fcon_msg(&rfcomm_con_list[0], MCC_CMD);
		printk(__FUNCTION__": Flow is set to ON\n");
		t = 0;
		break;
	}
	return retval;
}

static s32 spp_test_53911(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */

	return rfcomm_rls_msg(&rfcomm_con_list[0], MCC_CMD, 2, 0x05);
}

static s32 spp_test_531011(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */

	static int t = 0;
	s32 retval = 0;

	switch (t) {
	case 0:
		retval = rfcomm_pn_msg(&rfcomm_con_list[0], 2, 0, 1000);
		t++;
		break;

	case 1:
		retval = rfcomm_pn_msg(&rfcomm_con_list[0], 2, 0, 667);
		break;
	}
	return retval;
}

static s32 spp_test_531111(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */

	return rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 4, 0);
}

static s32 spp_test_531112(void)
{
	/* Do test 52211 before to establish RFCOMM, DLCI 1 and 2. You also
	   have to verify so both sides have sent a MSC command with flow on */

	return rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 4, 1);
}

static s32 spp_test_55111(void)
{
	/* Establish a L2CAP channel on PSM 1 (SDP) before doing this test */

	unsigned char sdp_query[] = { 0x02, 0x77, 0x77, 0x00, 0x08,
				      0x35, 0x03, 0x19, 0x00, 0x03, 0x00, 0xff, 0x00 };

	return sdp_send_data(&sdp_con_list[0], sdp_query, sdp_query[4] + 5);
}

static s32 spp_test_55112(void)
{
	/* Establish a L2CAP channel on PSM 1 (SDP) before doing this test */

	unsigned char sdp_query[] = { 0x04, 0x88, 0x88, 0x00, 0x12,
				      0x01, 0x00, 0xff, 0xff, 0x00, 0xff, 0x35, 0x09,
				      0x09, 0x00, 0x01, 0x09, 0x00, 0x04, 0x09, 0x01,
				      0x00, 0x00 };

	return sdp_send_data(&sdp_con_list[0], sdp_query, sdp_query[4] + 5);
}

static s32 spp_test_55113(void)
{
	/* Establish a L2CAP channel on PSM 1 (SDP) before doing this test */

	unsigned char sdp_query[] = { 0x06, 0x88, 0x88, 0x00, 0x13,
				      0x35, 0x03, 0x19, 0x12, 0x34, 0x00, 0xff, 0x35,
				      0x09, 0x09, 0x00, 0x01, 0x09, 0x00, 0x04, 0x09,
				      0x01, 0x00, 0x00 };

	return sdp_send_data(&sdp_con_list[0], sdp_query, sdp_query[4] + 5);
}


static s32 spp_test_56211(void)
{
	/* Run the hci_write_encryption_mode(1) in hci_init */
	return 0;
}

/* 
 * RFCOMM stuff 
 */

static s32 test_4_1(void)
{
	/* Create a connection */
	printk("Please use rf_conn server channel 2\n");
	return 0;
}

static s32 test_4_2_1(void)
{
	/* Send stop flow command on dlci 4*/
	printk("test_4_2\n");
	return rfcomm_msc_msg(&rfcomm_con_list[0], 0x87 ,MCC_CMD, 4);
}

static s32 test_4_2_2(void)
{
	/* Send start flow command on dlci 4 */
	printk("test_4_2\n");
	return rfcomm_msc_msg(&rfcomm_con_list[0], 0x85 ,MCC_CMD, 4);
}

static s32 test_4_2_3(void)
{
	/* Send start flow command  on dlci 4 */
	printk("test_4_2\n");
	return rfcomm_msc_msg(&rfcomm_con_list[0], 0x85 ,MCC_CMD, 3);
}

static s32 test_4_2_4(void)
{
	/* Send start flow command  on dlci 4 */
	printk("test_4_2\n");
	return rfcomm_msc_msg(&rfcomm_con_list[0], 0x85 ,MCC_CMD, 2);
}

static s32 test_4_3(void)
{
	s32 retval = 0;
	/* Here we should send data after we received a flow stop command */
	printk("test_4_3\n");
	
	if ((retval = rfcomm_send_data(CREATE_RFCOMM_ID(0,4),testdata, 1024)) < 0) {
		D_ERR("rfcomm_send_data: Failed\n");
	}
	return retval;
}

static s32 test_4_4(void)
{
	/* If we should initiate the disconnection we do this */
	printk("test_4_4\n");
	return rfcomm_disconnect_req(0);
}

static s32 test_4_5_1(void)
{
	printk("test_4_5_1\n");
	return rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 4, 1);
}

static s32 test_4_5_2(void)
{
	s32 retval = 0;
	printk("test_4_5_2\n");
	rpn_val.rtr_input = 1;
	rpn_val.rtr_output = 1;
	rpn_val.pm.rtr_input = 1;
	rpn_val.pm.rtr_output = 1;
	retval = rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 4, 0);
	rpn_val.pm.rtr_input = 0;
	rpn_val.pm.rtr_output = 0;
	return retval;
}

static s32 test_4_6(void)
{
	u8 data[1];

	printk("test_4_6\n");
	data[0] = 'b';
	/* We send a test messages of one byte size */
	return rfcomm_test_msg(&rfcomm_con_list[0], data, 1, MCC_CMD);
}

static s32 test_4_7(void)
{
	printk("test_4_7\n");
	return rfcomm_rls_msg(&rfcomm_con_list[0], MCC_CMD, 4, 0x03);
}

static s32 test_4_8_1(void)
{
	/* Here we send a fcoff command */
	printk("test_4_8\n");
	return rfcomm_fcoff_msg(&rfcomm_con_list[0], MCC_CMD);
}

static s32 test_4_8_2(void)
{
	/* Here we send a fcon command */
	printk("test_4_8\n");
	return rfcomm_fcon_msg(&rfcomm_con_list[0], MCC_CMD);
}

static s32 test_4_9(void)
{
	/* Test to send data after received fcoff command */
	printk("test_4_9\n");
	return test_4_3();
}

static s32 test_4_10(void)
{
	/* Create a connection on serverchannel one */
	printk("Please use rfcomm_connect server channel 1, line 0 instead\n");
	return 0;
}

static s32 test_4_11(void)
{
	/* Same as test 4.10, but here we should be the responder */
	printk("test_4_11\n");
	return test_4_10();
}

static s32 test_4_12(void)
{
	printk("test_4_12\n");
	return test_4_4();
}

static s32 test_4_13(void)
{	
	printk("test_4_13\n");
	return rfcomm_set_mtu(&rfcomm_con_list[0], 4, 500);
	printk("MTU set to 500\n");
	printk("Please use rfcomm_connect server channel 2, line 0 to connect\n");
}

static s32 test_4_14(void)
{
	printk("test_4_14\n");
	printk("PLease use rfcomm_conn on serverchannel 4\n");
	return 0;
}

static s32 test_4_15(void)
{
	printk("test_4_15\n");
	return rfcomm_crap_msg(&rfcomm_con_list[0]);
}

static s32 test_4_16(void)
{
	printk("test_4_16\n");
	return rfcomm_msc_msg(&rfcomm_con_list[0], 0x8d ,MCC_CMD, 8);
}

static s32 test_4_21_1(void)
{
	printk("test_4_21_1\n");
	return rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 2, 1);
}

static s32 test_4_21_2(void)
{
	s32 retval = 0;
	printk("test_4_21_2\n");
	rpn_val.rtr_input = 1;
	rpn_val.rtr_output = 1;
	rpn_val.pm.rtr_input = 1;
	rpn_val.pm.rtr_output = 1;
	retval = rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 2, 0);
	rpn_val.pm.rtr_input = 0;
	rpn_val.pm.rtr_output = 0;
	return retval;
}

static s32 test_4_22_1(void)
{
	s32 retval = 0;
	printk("test_4_22_1\n");
	rpn_val.rtr_input = 1;
	rpn_val.rtr_output = 1;
	rpn_val.pm.rtr_input = 1;
	rpn_val.pm.rtr_output = 1;
	retval = rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 2, 0);
	rpn_val.pm.rtr_input = 0;
	rpn_val.pm.rtr_output = 0;
	return retval;
}

static s32 test_4_22_2(void)
{
	printk("test_4_22_2\n");
	return rfcomm_sabm_msg(&rfcomm_con_list[0], 2);;
}

static s32 test_4_22_3(void)
{
	printk("test_4_21_1\n");
	return rfcomm_rpn_msg(&rfcomm_con_list[0], MCC_CMD, 2, 1);
}

static s32 test_4_23_1(void)
{
	printk("test_4_23_1\n");
	return test_4_22_1();
}

static s32 test_4_23_2(void)
{
	printk("test_4_23_2\n");
	return rfcomm_pn_msg(&rfcomm_con_list[0], 2, 0, 127);
}

static s32 test_4_23_3(void)
{
	printk("test_4_23_2\n");
	return rfcomm_sabm_msg(&rfcomm_con_list[0], 2);
}

static s32 test_4_23_4(void)
{
	printk("test_4_23_1\n");
	return test_4_22_3();
}

static s32 test_4_24_1(void)
{
	printk("test_4_23_1\n");
	return test_4_23_2();
}

static s32 test_4_24_2(void)
{
	printk("test_4_23_2\n");
	return test_4_23_1();
}

static s32 test_4_24_3(void)
{
	printk("test_4_23_2\n");
	return rfcomm_sabm_msg(&rfcomm_con_list[0], 2);
}

static s32 test_4_24_4(void)
{
	printk("test_4_23_1\n");
	return rfcomm_sabm_msg(&rfcomm_con_list[0], 2);
}

static s32 test_4_25_1(void)
{
	printk("test_4_25_1\n");
	return rfcomm_pn_msg(&rfcomm_con_list[0], 2, 0, 500);
}

static s32 test_4_25_2(void)
{
	printk("test_4_25_2\n");
	rfcomm_con_list[0].l2cap->local_mtu = 65;
	return 0;
}

static s32 test_4_25_3(void)
{
	printk("test_4_25_3\n");
	return rfcomm_sabm_msg(&rfcomm_con_list[0], 2);
}

static s32 test_4_26(void)
{
	printk("test_4_26\n");
	return rfcomm_pn_msg(&rfcomm_con_list[0], 4, 0, 127);
}

static s32 test_4_27(void)
{
	printk("test_4_27\n");
	return rfcomm_pn_msg(&rfcomm_con_list[0], 4, 10, 127);
}

static s32 test_4_28(void)
{
	printk("test_4_28\n");
	return rfcomm_send_credits(&rfcomm_con_list[0], 4, 10);
}



/*
 * TCS stuff
 */

static s32 test_5_1(void)
{
	if (!tcs[0].l2cap) {
		printk("Please connect TCS first with tcs_connect bd_addr\n");
		return -1;
	}
	return tcs_setup(tcs[0].l2cap, NULL, 0);
}

static s32 test_5_1_1(void)
{
	u8 nbr[2];

	if (!tcs[0].l2cap) {
		printk("Please connect TCS first with tcs_connect bd_addr\n");
		return -1;
	}
  
	nbr[0] = '0';
	nbr[1] = '4';
	nbr[2] = '6';
	nbr[3] = '7';
	nbr[4] = '0';
	nbr[5] = '8';
	nbr[6] = '7';
	nbr[7] = '1';
	nbr[8] = '4';
	nbr[9] = '5';
	nbr[10] = '7';
	nbr[11] = '2';
  
	return tcs_setup(tcs[0].l2cap, nbr, 12);
}


static s32 test_5_2(void)
{
	if (!tcs[0].l2cap) {
		printk("Please connect TCS first with tcs_connect bd_addr\n");
		return -1;
	}
	return tcs_connect(tcs[0].l2cap);
}

static s32 test_5_3(void)
{
	if (!tcs[0].l2cap) {
		printk("Please connect TCS first with tcs_connect bd_addr\n");
		return -1;
	}
	return tcs_disconnect(tcs[0].l2cap);
}

static s32 test_5_4(void)
{
	return test_5_1();
}

static s32 test_5_5(void)
{
	return test_5_2();
}

static s32 test_5_6(void)
{
	return test_5_3();
}

static s32 test_5_7(void)
{
	if (!tcs[0].l2cap) {
		printk("Please connect TCS first with tcs_connect bd_addr\n");
		return -1; 
	}
	return tcs_send_information(tcs[0].l2cap, '1');
}

static s32 test_gateway_call(void)
{
	unsigned char *atd = "ATD4257272353\r\n";

	printk("test_gateway_call, sending %s\n", atd);
	return rfcomm_send_data(CREATE_RFCOMM_ID(0,2), atd, strlen(atd));
}

s32 process_test_cmd(s32 test_case)
{
	if (!test_is_initialized) {
		unplug_test_init();
	}
    
	printk("test_case %d\n",test_case);

	switch (test_case) {
	case 0: return test_server();
	case 1: return test_client();

	case 221: return test_2_2_1();
	case 222: return test_2_2_2();
	case 223: return test_2_2_3();
	case 224: return test_2_2_4();
	case 225: return test_2_2_5();
	case 226: return test_2_2_6();
        case 23: return test_2_3();
	case 251: return test_2_5_1();
	case 252: return test_2_5_2();
	case 253: return test_2_5_3();
	case 254: return test_2_5_4();
	case 255: return test_2_5_5();
	case 256: return test_2_5_6();
	case 261: return test_2_6_1();
	case 272: return test_2_7_2();
	case 281: return test_2_8_1();
	case 282: return test_2_8_2();
	case 283: return test_2_8_3();
	case 284: return test_2_8_4();

	case 291: return test_2_9_1();
	case 292: return test_2_9_2();

	case 210: return test_2_10();

	case 2131 : return test_2_13_1();

	case 52111: return sdp_test_52111();
	case 52113: return sdp_test_52113();
	case 52114: return sdp_test_52114();
	case 52121: return sdp_test_52121();
	case 52122: return sdp_test_52122();
	case 53111: return sdp_test_53111();
	case 53113: return sdp_test_53113();
	case 53114: return sdp_test_53114();
	case 53115: return sdp_test_53115();
	case 53118: return sdp_test_53118();
	case 531110: return sdp_test_531110();
	case 531117: return sdp_test_531117();
	case 531120: return sdp_test_531120();
	case 53121: return sdp_test_53121();
	case 53122: return sdp_test_53122();
	case 53123: return sdp_test_53123();
	case 54111: return sdp_test_54111();
	case 54112: return sdp_test_54112();
	case 54113: return sdp_test_54113();
	case 54114: return sdp_test_54114();
	case 54116: return sdp_test_54116();
	case 541110: return sdp_test_541110();
	case 541111: return sdp_test_541111();
	case 541112: return sdp_test_541112();
	case 541120: return sdp_test_541120();
	case 54121: return sdp_test_54121();
	case 54122: return sdp_test_54122();
	case 55111: return sdp_test_55111();
	case 55112: return sdp_test_55112();

	case 62211: return spp_test_52211();

	case 62311: return spp_test_52311();
	case 62312: return spp_test_52312();
	case 62313: return spp_test_52313();
	case 62314: return spp_test_52314();
	case 63112: return spp_test_53112();
	case 63211: return spp_test_53211();
	case 63312: return spp_test_53312();
	case 63411: return spp_test_53411();
	case 63412: return spp_test_53412();
	case 63511: return spp_test_53511();
	case 63611: return spp_test_53611();
	case 63711: return spp_test_53711();
	case 63811: return spp_test_53811();
	case 63911: return spp_test_53911();
	case 631011: return spp_test_531011();
	case 631111: return spp_test_531111();
	case 631112: return spp_test_531112();
	case 66211: return spp_test_56211();

	case 41: return test_4_1();
	case 421: return test_4_2_1();
	case 422: return test_4_2_2();
	case 423: return test_4_2_3();
	case 424: return test_4_2_4();
	case 43: return test_4_3();
	case 44: return test_4_4();
	case 451: return test_4_5_1();
	case 452: return test_4_5_2();
	case 46: return test_4_6();
	case 47: return test_4_7();
	case 481: return test_4_8_1();
	case 482: return test_4_8_2();
	case 49: return test_4_9();
	case 410: return test_4_10();
	case 411: return test_4_11();
	case 412: return test_4_12();
	case 413: return test_4_13();
	case 414: return test_4_14();
	case 415: return test_4_15();
	case 416: return test_4_16();
	case 4211: return test_4_21_1();
	case 4212: return test_4_21_2();
	case 4221: return test_4_22_1();
	case 4222: return test_4_22_2();
	case 4223: return test_4_22_3();
	case 4231: return test_4_23_1();
	case 4232: return test_4_23_2();
	case 4233: return test_4_23_3();
	case 4234: return test_4_23_4();
	case 4241: return test_4_24_1();
	case 4242: return test_4_24_2();
	case 4243: return test_4_24_3();
	case 4244: return test_4_24_4();
	case 4251: return test_4_25_1();
	case 4252: return test_4_25_2();
	case 426: return test_4_26();
	case 427: return test_4_27();
	case 428: return test_4_28();
	case 51: return test_5_1();
	case 511: return test_5_1_1();
	case 52: return test_5_2();
	case 53: return test_5_3();
	case 54: return test_5_4();
	case 55: return test_5_5();
	case 56: return test_5_6();
	case 57: return test_5_7();
	case 100: return test_gateway_call();
	default:
		printk("Unknown test case\n");
		return -1;
	}
}
