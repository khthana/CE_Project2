
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/malloc.h>
#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/sdp.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/btmem.h>
#include <linux/proc_fs.h>
#include <linux/random.h>
#else /* user mode */
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <asm/unaligned.h>

#include "include/bluetooth.h"
#include "include/btcommon.h"
#include "include/sdp.h"
#include "include/l2cap.h"
#include "include/btmem.h"
#endif
#include <stdio.h>
/****************** DEBUG CONSTANT AND MACRO SECTION ************************/

#if SDP_DEBUG_XMIT
#define D_XMIT(fmt...) printk(SDP_DBG_STR fmt)
#else
#define D_XMIT(fmt...)
#endif

#if SDP_DEBUG_REC
#define D_REC(fmt...) printk(SDP_DBG_STR fmt)
#else
#define D_REC(fmt...)
#endif

#if SDP_DEBUG_MISC
#define D_MISC(fmt...) printk(SDP_DBG_STR fmt)
#else
#define D_MISC(fmt...)
#endif

#if SDP_DEBUG_PROC
#define D_PROC(fmt...) printk(fmt)
#else
#define D_PROC(fmt...)
#endif

#if SDP_PRINT_DATA
#define PRINTPKT(str, data, len) print_data(str, data, len)
#else
#define PRINTPKT(str, data, len)
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,2,14)
#define USE_NEW_PROC
#endif

#ifndef __KERNEL__
#define SDP_SRV_SOCK "/tmp/sdp_sock"
#endif

#define GET_TYPE(ch) (((ch) >> 3) & 0x1f)
#define GET_SIZE(ch) ((ch) & 0x7)
#define SET_DE_HDR(type,size) ((((type) << 3) & 0xf8) + ((size) & 0x7))

#define SDP_HDR_SIZE 5
/* The size of the SDP packet header */

#define DES_HDR 0x35
#define DES_HDR_LEN 2

#define UUID16_HDR 0x19
#define UUID32_HDR 0x1a

/* Maximum record counts */
#define MAX_SERVICERECORD_COUNT 8
#define MAX_ATTR_COUNT 0x100

/* The maximum number of sdp connections */
#define MAX_NBR_SDP 7

/* PDU ID */
#define SDP_ERROR_RSP 1
#define SDP_SERVICESEARCH_REQ 2
#define SDP_SERVICESEARCH_RSP 3
#define SDP_SERVICEATTR_REQ 4
#define SDP_SERVICEATTR_RSP 5
#define SDP_SERVICESEARCHATTR_REQ 6
#define SDP_SERVICESEARCHATTR_RSP 7

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static sdp_con* get_free_sdp_con(void);

#ifdef __KERNEL__

#ifdef USE_NEW_PROC
static ssize_t sdp_database_read(struct file *f, char *buf, size_t count,
				 loff_t *offset);
static ssize_t sdp_database_write(struct file *f, const char *buf, 
				  size_t count, loff_t *offset);
#else
static s32 sdp_database_read(struct inode *inode, struct file * file,
			     char * buf, s32 count);
static s32 sdp_database_write(struct inode *inode, struct file * file,
			      const char * buf, s32 count);

#endif
static s32 sdp_proc_dir_entry_read(char *buf, char **start, off_t offset,
				   s32 len, s32 unused);

#else /* USERMODE STACK */
static s32 open_socket(char *name);
static s32 sdp_doquery(s32 fd, u8 *request, s32 len);
static s32 send_error_rsp(sdp_con *sdp, u16 trans_id, u16 err_code);
#endif
u8 sdp_get_line(void); //kainui add : use for get line
//void sdp_buf_send_data(unsigned int sdp_id,unsigned char *data); //kainui add
u8 sdp_data[512];
/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/
#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct wait_queue *database_wq = NULL;
#else
static wait_queue_head_t database_wq;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct file_operations sdp_procfile_operation = {
	NULL,                   /* lseek - default */
	sdp_database_read,      /* read - bad */
	sdp_database_write,     /* write - bad */
	NULL,                   /* readdir */
	NULL,                   /* select - default */
	NULL,                   /* ioctl - default */
	NULL,                   /* mmap */
	NULL,                   /* no special open code */
	NULL,                   /* no special release code */
	NULL                    /* can't fsync */
};
#else
static struct file_operations sdp_procfile_operation = {
	NULL,                   /* module owner */
	NULL,                   /* lseek - default */
	sdp_database_read,      /* read - bad */
	sdp_database_write,     /* write - bad */
	NULL,                   /* readdir */
	NULL,                   /* select - default */
	NULL,                   /* ioctl - default */
	NULL,                   /* mmap */
	NULL,                   /* no special open code */
	NULL,                   /* no special release code */
	NULL                    /* can't fsync */
};
#endif
 
 /*
  * proc directories can do almost nothing..
  */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct inode_operations sdp_proc_inode_operations = {
	&sdp_procfile_operation,   /* default net file-ops */
	NULL,                   /* create */
	NULL,                   /* lookup */
	NULL,                   /* link */
	NULL,                   /* unlink */
	NULL,                   /* symlink */
	NULL,                   /* mkdir */
	NULL,                   /* rmdir */
	NULL,                   /* mknod */
	NULL,                   /* rename */
	NULL,                   /* readlink */
	NULL,                   /* follow_link */
	NULL,                   /* readpage */
	NULL,                   /* writepage */
	NULL,                   /* bmap */
	NULL,                   /* truncate */
	NULL                    /* permission */
};
#else
static struct inode_operations sdp_proc_inode_operations = {
	NULL,                   /* create */
	NULL,                   /* lookup */
	NULL,                   /* link */
	NULL,                   /* unlink */
	NULL,                   /* symlink */
	NULL,                   /* mkdir */
	NULL,                   /* rmdir */
	NULL,                   /* mknod */
	NULL,                   /* rename */
	NULL,                   /* readlink */
	NULL,                   /* follow_link */
	NULL,                   /* readpage */
	NULL,                   /* writepage */
	NULL,                   /* bmap */
	NULL,                   /* truncate */
	NULL                    /* permission */
};
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct proc_dir_entry sdp_proc_entry = {
	0,
	7, "sdp_srv",
	S_IFREG | S_IRUGO | S_IWUSR,
	1, 0, 0,
	0,
	&sdp_proc_inode_operations,
	sdp_proc_dir_entry_read,
};
#else
static struct proc_dir_entry sdp_proc_entry = {
	0,
	7, "sdp_srv",
	S_IFREG | S_IRUGO | S_IWUSR,
	1, 0, 0,
	0,
	&sdp_proc_inode_operations,
	&sdp_procfile_operation,
};
#endif /* LINUX_VERSION_CODE */

#endif /* __KERNEL__ */

typedef struct data_struct {
	u16 l2cap_mtu;
	u16 sdp_con_id;
	u16 len;
	u8 data[0];
} __attribute__ ((packed)) data_struct;

struct database_query {
	u32 count;
	u8 query[256];
} database_query;

sdp_con sdp_con_list[MAX_NBR_SDP];

static int role;

/* Transaction id used for request */
//static u16 req_trans_id = 0xaabb;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct wait_queue *sdp_disc_wq = NULL;
#else
static wait_queue_head_t sdp_disc_wq;
#endif /* LINUX_VERSION_CODE */

#ifdef __KERNEL__
static bt_tx_buf *db_write_tx_buf;
static s32 db_write_recv;
#endif

#ifndef __KERNEL__
static s32 sdp_sock;
#endif

/****************** FUNCTION DEFINITION SECTION *****************************/

#ifndef __KERNEL__
int
open_socket(char *name)
{
	struct sockaddr_un server_address;
	s32 client_sockfd;
	s32 server_len;

	printf("Opening socket %s\n", name);

	client_sockfd = socket(AF_UNIX, SOCK_STREAM, 0);

	/* 'destination' socket */
	server_address.sun_family = AF_UNIX;
	strcpy(server_address.sun_path, name);
	server_len = sizeof(server_address);
  
	if (connect(client_sockfd, 
		    (struct sockaddr *)&server_address, server_len) < 0) {
		perror("connect client socket");
		D_ERR("Couldn't open socket, sdp will not be used\n");
		return -1;
	}

	printf("Socket connected to %s\n", server_address.sun_path);
	return client_sockfd;
}
#endif /* !__KERNEL__ */

void 
sdp_init(s32 srv)
{
	s32 i;
	protocol_layer this_layer;
	DSYS("Initialising SDP\n");

	database_query.count = 0;
	
	/* Set the confirm and indication functions for the L2CAP-layer */

	this_layer.con_ind = sdp_connect_ind;
	this_layer.con_pnd = sdp_connect_pnd;
	this_layer.conf_ind = sdp_config_ind;
	this_layer.disc_ind = sdp_disconnect_ind;

	this_layer.con_cfm = sdp_connect_cfm;
	this_layer.conf_cfm = sdp_config_cfm;
	this_layer.disc_cfm = sdp_disconnect_cfm;

	this_layer.receive_data = sdp_receive_data;

	/* Register SDP in the L2AP layer*/
	l2cap_register_upper(SDP_LAYER, &this_layer); 

	for (i = 0; i < MAX_NBR_SDP; i++) {
		sdp_con_list[i].id = i;
		sdp_con_list[i].l2cap = NULL;
		sdp_con_list[i].state = SDP_DISCONNECTED;
		sdp_con_list[i].initiator = 0;
		sdp_con_list[i].line = 0;
	}

	if (srv) {
		DSYS("Init SDP as server\n");
		role = 1;
#ifndef __KERNEL__
		sdp_sock = open_socket(SDP_SRV_SOCK);
#endif
	} else {
		DSYS("Init SDP as client\n");
		role = 0;
	}
}

void 
sdp_shutdown(void)
{
	s32 i;
	DSYS("Shutting down SDP\n");

	for (i = 0; i < MAX_NBR_SDP; i++) {
		if (sdp_con_list[i].state != SDP_DISCONNECTED) {
			sdp_disconnect_req(i);
		}
	}

#ifdef __KERNEL__
	unsubscribe_bt_buf(db_write_tx_buf);
	db_write_tx_buf = NULL;
	db_write_recv = 0;
#endif
        return;
}

#ifdef __KERNEL__
s32
sdp_create_proc_file(void)
{
	s32 procfs_status = -ENOENT;

	/* The database_wq wait queue must be initialised before anyone tries
	   to read from the /proc/sdp_srv file, so we initialise the wait
	   queues here */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	init_waitqueue_head(&database_wq);
	init_waitqueue_head(&sdp_disc_wq);
#endif /* LINUX_VERSION_CODE */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	{
		struct proc_dir_entry *entry;

		if ((entry = create_proc_entry(sdp_proc_entry.name,
					       sdp_proc_entry.mode,
					       &proc_root))) {
			/*---------------------------------------------------*/
			/* If the proc entry was registered successfully,    */
			/* then set all the necessary structure information. */
			/*---------------------------------------------------*/
			entry->proc_iops = sdp_proc_entry.proc_iops;
			entry->proc_fops = sdp_proc_entry.proc_fops;
			procfs_status = 0;
		}
	}
#elif LINUX_VERSION_CODE > KERNEL_VERSION(2,2,0)
	procfs_status = proc_register(&proc_root, &sdp_proc_entry);
#else
	procfs_status = proc_register_dynamic(&proc_root, &sdp_proc_entry);
#endif /* LINUX_VERSION_CODE */

	if (procfs_status < 0) {
		D_ERR("Couldn't register proc file for sdp database %d\n",
		      procfs_status);
	}

	return procfs_status;
}

s32
sdp_remove_proc_file(void)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	remove_proc_entry(sdp_proc_entry.name, &proc_root);
#else
	proc_unregister(&proc_root, sdp_proc_entry.low_ino);
#endif
	return 0;
}
#endif /* __KERNEL__ */

s32
sdp_connect_req(u8* bd_addr, u8 line)
{
	sdp_con *sdp;
  
	sdp = get_free_sdp_con();
	if (!sdp) {
		DSYS(__FUNCTION__ " WARNING couldn't find free sdp connection\n");
		/* fixme -- use bt_connect_cfm with correct con_id */
		return 0;
	}
	sdp->state = SDP_CONNECTING;
	sdp->initiator = TRUE;
	sdp->line = line;
	
	if (l2ca_connect_req(bd_addr, SDP_LAYER)) {
		D_ERR(__FUNCTION__ " ERROR l2ca_connect_req failed\n");
		return -1;
	}
	return sdp->id;
}

/* only client receives connect pnd */
void sdp_connect_pnd(l2cap_con *l2cap, s32 status)
{
	printk("sdp_connect_pnd : reason %d\n", status);	
	//PRINTPSM(l2cap);
}

void 
sdp_connect_ind(l2cap_con *l2cap) 
{
	sdp_con *sdp;
	D_MISC(__FUNCTION__ " remote cid : %d\n", l2cap->remote_cid);
   
	sdp = get_free_sdp_con();
	if (!sdp) {
		DSYS(__FUNCTION__ " WARNING couldn't find free sdp connection\n");
		if (l2ca_connect_rsp(l2cap, RES_NOSRC, STAT_NOINFO)) {
			D_ERR(__FUNCTION__ " l2ca_connect_rsp failed\n");
		}
	} else {
		if (l2ca_connect_rsp(l2cap, RES_SUCCESS, STAT_NOINFO)) {
			D_ERR(__FUNCTION__ " l2ca_connect_rsp failed\n"); 
		}
		sdp->initiator = FALSE;
		sdp->state = SDP_CONNECTING;
		sdp->l2cap = l2cap;
		l2cap->upper_con = (void*) sdp;
	}
}

void 
sdp_connect_cfm(l2cap_con *l2cap, s32 status)
{
	sdp_con *sdp = NULL;
	s32 i = 0;
	s32 stop = 0;
  
	if (status) {
		DSYS(__FUNCTION__ " Connection failed\n");
		bt_connect_cfm(CREATE_SDP_ID(sdp->line, 0), -1);
		return;
	}

	/* Find the connecting sdp_con */
	while ((i < MAX_NBR_SDP) && (!stop)) {
		if ((sdp_con_list[i].state == SDP_CONNECTING) && 
		    (sdp_con_list[i].initiator == TRUE)) {
			sdp = &sdp_con_list[i];
			stop = TRUE;
		}
		i++;
	}
  
	if (sdp != NULL) {
		/*-----------------------------------------------------------*/
		/* Set the connection in bt.                                 */
		/*-----------------------------------------------------------*/
		bt_register_sdp(sdp->line, sdp->id);

		if (!l2ca_local_conf_done(l2cap)) {
			/* still haven't sent config request yet */
			if (l2ca_config_req(l2cap, 0, NULL, 0, 0)) {
				D_ERR(__FUNCTION__ " Configuration request failed\n");
			}
			/* store connection */
			sdp->l2cap = l2cap;
			l2cap->upper_con = (void*) sdp;
		} else 
			DSYS(__FUNCTION__ " already sent back a pos response\n");
	} else {
		D_ERR(__FUNCTION__ " couldn't find the correct sdp_connection\n");
		bt_connect_cfm(CREATE_SDP_ID(sdp->line, 0), -1);
	}
}

/* Sends back info about  MTU, outflow, flush timeout
   Get this data from some parameter area controlled by 
   control block ? */

void 
sdp_config_ind(l2cap_con* l2cap)
{
	D_MISC(__FUNCTION__ " remote cid : %d\n", l2cap->remote_cid);

	/* FIXME -- Check whether the received params are 
	   acceptable, accept all for now */

	/* check if we have sent a pos response yet */
	if (!l2ca_remote_conf_done(l2cap)) {
		/* still haven't sent a pos configure response*/
		if (l2ca_config_rsp(l2cap, 0, NULL, CONF_SUCCESS)) {
			D_ERR(__FUNCTION__ " Conf rsp failed\n");
		}
	} else 
		DSYS("already have sent back a pos response\n");

	/* check if we received a pos response on a 
	   previous config req */ 
	if (!l2ca_local_conf_done(l2cap)) {
		/* FIXME -- use real options not static values */
		
		if (l2ca_config_req(l2cap, 0, NULL, 0, 0)) {
			D_ERR(__FUNCTION__ " Config request failed\n");
		}
	} else 
		D_REC("already ready with config req\n");
}

#ifdef __KERNEL__
/*---------------------------------------------------------------------------*/
/* sdpStartRequest() - This function is used to initiate a SDP request.      */
/*---------------------------------------------------------------------------*/
int sdpStartRequest(u8 sdpIndex, u8 sdpCommand, u8 *pduData, u16 pduLength)
{
	s32 returnValue = -1;

	/*-------------------------------------------------------------------*/
	/* Check the connection state.  State must be SDP_CONNECTED.         */
	/*-------------------------------------------------------------------*/
	if (sdp_con_list[sdpIndex].state == SDP_CONNECTED) {
		/*-----------------------------------------------------------*/
		/* Initiate a query here. Send a SDP_SERVICESEARCH_REQ.      */
		/*-----------------------------------------------------------*/
		sdp_tx_buf *sdp_buf;
		bt_tx_buf *tx_buf;
		u32 sdp_frame_len;
		u16 trans_id;
   
		/*-----------------------------------------------------------*/
		/* What are we sending in the PDU?                           */
		/*                                                           */
		/* A BB CC D E F GG                                          */
		/* A   = SDP_SERVICESEARCH_REQ                               */
		/* BB  = Transaction ID                                      */
		/* CC  = PDU Length (not including header).                  */
		/* D   = Data Element Sequence Header (0x35)                 */
		/* E   = Number of bytes (which in this case is 3)           */
		/* F   = UUID16_HDR (1 bytes) (0x19).                        */
		/* GG  = PublicBrowseGroup (0x1002).                         */
		/* Total number of bytes 10.                                 */
		/*-----------------------------------------------------------*/

		/*-----------------------------------------------------------*/
		/* Generate random tranaction ID.                            */
		/*-----------------------------------------------------------*/
		get_random_bytes(&trans_id, 2 /* bytes */);
   
		/*-----------------------------------------------------------*/
		/* Allocate the buffer.                                      */
		/*-----------------------------------------------------------*/
		sdp_frame_len = SDP_HDR_SIZE + pduLength;
		tx_buf = subscribe_bt_buf(sizeof(sdp_tx_buf) + sdp_frame_len);

		if (!tx_buf) {
			D_ERR(__FUNCTION__ " failed to get tx buffer\n");
		} else {
			/*---------------------------------------------------*/
			/* Set the current length of the transmission buffer */
			/*---------------------------------------------------*/
			tx_buf->cur_len = sdp_frame_len;

			/*---------------------------------------------------*/
			/* Poke the SDP header.                              */
			/* Notice that the "poking" is in little endian      */
			/*---------------------------------------------------*/
			sdp_buf = (sdp_tx_buf*) (tx_buf->data);
			sdp_buf->frame[0] = sdpCommand;
			sdp_buf->frame[1] = (trans_id >> 8) & 0xff;
			sdp_buf->frame[2] = trans_id & 0xff;
			sdp_buf->frame[3] = (pduLength >> 8) & 0xff;
			sdp_buf->frame[4] = pduLength & 0xff;

			/*---------------------------------------------------*/
			/* Copy the pduData.                                 */
			/*---------------------------------------------------*/
			memcpy(&sdp_buf->frame[5], pduData, pduLength);

			/*---------------------------------------------------*/
			/* Send the l2cap data transfer.                     */
			/*---------------------------------------------------*/
			l2cap_send_data(tx_buf, sdp_con_list[sdpIndex].l2cap);
			DSYS(__FUNCTION__ " Client finished sending data.\n");
			returnValue = 0; 
		}
	} else {
		/*-----------------------------------------------------------*/
		/* No active SDP connection here!.  This is an error.        */
		/*-----------------------------------------------------------*/
		D_ERR(__FUNCTION__ " No active connection on SDP ID = %d\n", sdpIndex);
	}

	return returnValue;
}  /* End of sdpStartRequest() */

#endif /* __KERNEL__ */

void 
sdp_config_cfm(l2cap_con *l2cap, s32 status)
{
	sdp_con *sdp = NULL;

	D_MISC(__FUNCTION__ ", remote cid : %d\n", l2cap->remote_cid);

	if (!l2cap->upper_con) {
		D_ERR("%s l.%d NULL/magic failed\n", 
		      __FILE__, __LINE__);
		return;
	}

	/*-------------------------------------------------------------------*/
	/* Get a pointer to the correct SDP data connection structure entry. */
	/*-------------------------------------------------------------------*/
	sdp = (sdp_con *)l2cap->upper_con;

	/*-------------------------------------------------------------------*/
	/* Set the state of this SDP connection to SDP_CONNECTED.            */
	/*-------------------------------------------------------------------*/
	sdp->state = SDP_CONNECTED;

	/*-------------------------------------------------------------------*/
	/* Check to see if we're the initiator on this running stack.  If    */
	/* initator, this is a SDP client connection request.  If not, then  */
	/* we're the server and must process requests.                       */
	/*-------------------------------------------------------------------*/
	if (sdp->initiator) {
		/*-----------------------------------------------------------*/
		/* We are the initator.  Therefore a SDP client on on this   */
		/* machine initiated the connection.  Inform the "ioctl" or  */
		/* bluetooth layer.                                          */
		/*-----------------------------------------------------------*/
		bt_connect_cfm(CREATE_SDP_ID(sdp->line, 0),
			       ((sdp_con *)l2cap->upper_con)->id);
	} else {
		DSYS(__FUNCTION__ ", we are the server\n");
	}
}

void 
sdp_disconnect_req(u32 sdp_id)
{
	s32 err;
	
	/*-------------------------------------------------------------------*/
	/* Get a handle to the proper SDP connection entry.                  */
	/*-------------------------------------------------------------------*/
	sdp_con *sdp = &sdp_con_list[sdp_id];

	/*-------------------------------------------------------------------*/
	/* Do some sanity checking.  If the sdpConnectionIndex is within     */
	/* range AND the state is either SDP_CONNECTING or SDP_CONNECTED     */
	/* then disconnect this connection.                                  */
	/*-------------------------------------------------------------------*/
	if (sdp_id <= MAX_NBR_SDP &&
	    (sdp->state == SDP_CONNECTING || sdp->state == SDP_CONNECTED)) {
		if ((err = l2ca_disconnect_req(sdp_con_list[sdp_id].l2cap)) != 0) {
			D_ERR(__FUNCTION__ ", An error with error code %d occured during disconnetion of sdp channel %d\n", err, sdp_id);
			sdp_con_list[sdp_id].state = SDP_DISCONNECTED;
			sdp_con_list[sdp_id].l2cap = NULL;  
		} 
#if 0
		/* sdp_disconnect_cfm wakes up this queue, but by the time we
		   get here it already did, so we sleep forever!
		 */
else {
			interruptible_sleep_on(&sdp_disc_wq);
		}
#endif
	}
}

void 
sdp_disconnect_ind(l2cap_con *l2cap) 
{
	sdp_con *sdp;
	D_MISC(__FUNCTION__ ", remote cid : %d\n", l2cap->remote_cid);
   
	sdp = (sdp_con*) l2cap->upper_con;
	sdp->state = SDP_DISCONNECTED;
	sdp->l2cap = NULL;

	l2ca_disconnect_rsp(l2cap);
}

void 
sdp_disconnect_cfm(l2cap_con *l2cap)
{
	sdp_con *sdp;
	u8 line;

	D_MISC(__FUNCTION__ ", remote cid : %d\n", l2cap->remote_cid);

	sdp = (sdp_con*) l2cap->upper_con;
	line = sdp->line;
	sdp->state = SDP_DISCONNECTED;
	sdp->l2cap = NULL;  

	bt_unregister_sdp(line);
	wake_up_interruptible(&sdp_disc_wq);
}

void 
sdp_receive_data(l2cap_con *l2cap, u8* data, u32 len)
{
        sdp_con *sdp;
	data_struct *db_hdl;
        int ii;


        D_REC(__FUNCTION__ "\n");

	if (role == 0) {
                bzero((unsigned char *) &sdp_data, sizeof(sdp_data));
                for (ii=0;ii<len;ii++)
                        sdp_data[ii] = data[ii];
                //printf("kainui : sdp_receive1\n");
                bt_sdp_receive_top(sdp_data);
		print_data(__FUNCTION__, data, len);
		return;
	}

	PRINTPKT(__FUNCTION__, data, len);
	sdp = (sdp_con*) l2cap->upper_con;

#ifndef __KERNEL__
	if (sdp_sock < 0) {
		send_error_rsp(sdp, le16_to_cpu(get_unaligned((u16 *)&data[1])), 6);
	}
#endif

	/*--------------------------------------------------------*/
	/* If __KERNEL__ mode, we must bounce the received data   */
	/* up if this stack initiated the request.                */
	/*--------------------------------------------------------*/
#if __KERNEL__
	if (sdp->initiator) {
		u8 *dataPointer = NULL;

		/*------------------------------------------------------*/
		/* Grab a copy of the data to send up.                  */
		/*------------------------------------------------------*/
		dataPointer = (u8 *) kmalloc(len, GFP_ATOMIC);
		memcpy(dataPointer, data, len);
		bt_send_sdp_data_received(sdp->line, dataPointer, len);
	} else
#endif
	{
		db_hdl = (data_struct*)database_query.query;

		db_hdl->l2cap_mtu = l2cap->remote_mtu;
		db_hdl->sdp_con_id = sdp->id;
		db_hdl->len = len;
		memcpy(db_hdl->data, data, len);

		database_query.count = sizeof(data_struct) + len;

#ifdef __KERNEL__
		D_PROC("wake_up process %i (%s) awakening\n", current->pid, current->comm);
		wake_up_interruptible(&database_wq);
		D_PROC("wake_up process %i (%s) woke up\n", current->pid, current->comm);
#else
		sdp_doquery(sdp_sock, database_query.query, database_query.count);
#endif
	}
        bzero((unsigned char *) &sdp_data, sizeof(sdp_data));
        for (ii=0;ii<len;ii++)
                sdp_data[ii] = db_hdl->data[ii];
        //printf("kainui : sdp_receive2\n");
                bt_sdp_receive_top(sdp_data);
}

#ifndef __KERNEL__ 
s32
send_error_rsp(sdp_con *sdp, u16 trans_id, u16 err_code)
{
	sdp_tx_buf *sdp_buf;
	bt_tx_buf *tx_buf;
	u32 sdp_frame_len;
	u32 pdu_len;

	/* Since we do not send any error information the pdu length is just
	   the size of the error code length, which is two bytes */
	pdu_len = 2;
	sdp_frame_len = SDP_HDR_SIZE + pdu_len;

	tx_buf = subscribe_bt_buf(sizeof(sdp_tx_buf) + sdp_frame_len);

	if (!tx_buf) {
		D_ERR(__FUNCTION__ " failed to get tx buffer\n");
		return -1;
	}

	tx_buf->cur_len = sdp_frame_len;
	
	sdp_buf = (sdp_tx_buf*) (tx_buf->data);

	sdp_buf->frame[0] = SDP_ERROR_RSP;
	sdp_buf->frame[1] = (trans_id >> 8) & 0xff;
	sdp_buf->frame[2] = trans_id & 0xff;
	sdp_buf->frame[3] = (pdu_len >> 8) & 0xff;
	sdp_buf->frame[4] = pdu_len & 0xff;

	sdp_buf->frame[5] = (err_code >> 8) & 0xff;
	sdp_buf->frame[6] = err_code & 0xff;
	
	return l2cap_send_data(tx_buf, sdp->l2cap);
}
#endif

#ifdef __KERNEL__
s32 sdp_proc_dir_entry_read(char *buf, char **start, off_t offset,
			    s32 len, s32 unused)
{
#ifdef USE_NEW_PROC
	return sdp_database_read(NULL, buf, len, 0);
#else
	return sdp_database_read(NULL, NULL, buf, len);
#endif
}

#ifdef USE_NEW_PROC
ssize_t sdp_database_read(struct file *f, char *buf, 
			  size_t count, loff_t *offset)
#else
s32 sdp_database_read(struct inode *inode, struct file * file,
		      char * buf, s32 count)
#endif
{
	s32 len;
	
	D_PROC(__FUNCTION__ " Someone is trying to read %d bytes from sdp proc-file\n",
	       count);
	cli();
	if (database_query.count <= 0) {
		D_PROC(__FUNCTION__ " No bytes available, going to sleep\n");
		interruptible_sleep_on(&database_wq);
	}
	sti();

	len = MIN(count, database_query.count);

	copy_to_user(buf, database_query.query, len);

	if (database_query.count > len) {
		memmove(database_query.query,
			database_query.query + len,
			database_query.count - len);
	}
	database_query.count -= len;
	D_PROC(__FUNCTION__ " Returning %d bytes\n", len);

	return len;
}

#ifdef USE_NEW_PROC
ssize_t sdp_database_write(struct file *f, const char *buf, 
			   size_t count, loff_t *offset)
#else
s32 sdp_database_write(struct inode *inode, struct file * file,
		       const char * buf, s32 count)
#endif
{
	static data_struct db_hdl;
	sdp_tx_buf *sdp_buf;
	s32 read1 = 0;
	s32 read2 = 0;

	D_PROC(__FUNCTION__ " Someone wrote %d bytes to sdp proc-file\n", count);

	if (!bt_initiated())
		return 0;
	
	if (!db_write_tx_buf) {
		read1 = MIN(sizeof db_hdl - db_write_recv, count);
		copy_from_user(&db_hdl + db_write_recv, buf, read1);

		db_write_recv += read1;

		if (db_write_recv < sizeof db_hdl)
			return read1;

		db_write_tx_buf = subscribe_bt_buf(sizeof *sdp_buf + db_hdl.len);

		if (!db_write_tx_buf) {
			D_ERR(__FUNCTION__ " failed to get tx buffer\n");
			db_write_recv -= read1;
			return -ENOMEM;
		}

		db_write_tx_buf->cur_len = db_hdl.len;

		count -= read1;
		buf += read1;
		db_write_recv = 0;
	}

	sdp_buf = (sdp_tx_buf*)db_write_tx_buf->data;

	if (db_write_recv < db_hdl.len) {
		read2 = MIN(db_hdl.len - db_write_recv, count);
		copy_from_user(sdp_buf->frame + db_write_recv, buf, read2);
		db_write_recv += read2;

		if (db_write_recv < db_hdl.len)
			return read1 + read2;
	}

	D_XMIT(__FUNCTION__ " preparing to send %d bytes data to sdp_con[%d]\n", db_hdl.len, db_hdl.sdp_con_id);
	PRINTPKT("Data to be sent to client:", db_hdl.data, db_hdl.len);

	l2cap_send_data(db_write_tx_buf, sdp_con_list[db_hdl.sdp_con_id].l2cap);
	db_write_tx_buf = NULL;
	db_write_recv = 0;

	return read1 + read2;
}
#else /* __KERNEL__ */

s32 sdp_doquery(s32 fd, u8 *request, s32 len)
{
	s32 n;
	u8 tmpbuf[512];
	data_struct *db_hdl;
	s32 recv;

	D_XMIT("sdp_doquery : sending request %d bytes\n", len);
	write(fd, request, len);
	
	if ((n = read(fd, tmpbuf, 512)) < 0)
		return n;

	D_REC(__FUNCTION__ ", Received %d bytes\n", n);

	db_hdl = (data_struct*) tmpbuf;

	/* what if not all is written once */

	for (recv = n; recv < sizeof *db_hdl + db_hdl->len; recv += n)
		if ((n = read(fd, tmpbuf + recv, 512 - recv)) < 0)
			return n;

        sdp_send_data(&sdp_con_list[db_hdl->sdp_con_id], db_hdl->data, db_hdl->len);

	return recv;
}
#endif

s32
sdp_send_data(sdp_con *sdp, u8 *data, u32 len)        //kainui : sdp_con is struct in btcommon.h
{
	sdp_tx_buf *sdp_buf;
	bt_tx_buf *tx_buf;

	tx_buf = subscribe_bt_buf(sizeof(sdp_tx_buf) + len);

        printf("kainui : sdp_send_data\n");

	if (!tx_buf) {
		D_ERR("sdp_send_data:  failed to get tx buffer\n");
		return -1;
	}

	tx_buf->cur_len = len;

	sdp_buf = (sdp_tx_buf*) (tx_buf->data);

	memcpy(sdp_buf->frame, data, len);
	PRINTPKT("SDP sending:", (u8*) data, len);

        printf("kainui : data is %s\n",data);

        return l2cap_send_data(tx_buf, sdp->l2cap);
}

sdp_con*
get_free_sdp_con(void)
{
	s32 i = 0;

	while ((i < MAX_NBR_SDP) && 
	       (sdp_con_list[i].state != SDP_DISCONNECTED)) {
		i++;
	}

	if (i == MAX_NBR_SDP) {
		return 0;
	}

	return &sdp_con_list[i];
}

//kainui add : use for get line

u8 sdp_get_line(void)
{
        if (sdp_con_list[0].state != SDP_DISCONNECTED)
        {
		return sdp_con_list[0].line;
	}
        else return -1;

}

//kainui add : use for send data. it is called by bt_sdp_send_data
void sdp_buf_send_data(unsigned int sdp_id,unsigned char *data)
{
        unsigned int len;
        printf("kainui : sdp_buf_send_data\n");
        printf("kainui : sdp_id = %d\n",sdp_id);
        len = strlen(data);
        sdp_send_data(&sdp_con_list[sdp_id],data,len);
}

u8* sdp_get_data()
{
        return sdp_data;
}


/****************** END OF FILE sdp.c ***************************************/
