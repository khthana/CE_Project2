
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/config.h>
#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/malloc.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/sched.h>

#include <asm/unaligned.h>

#include <linux/bluetooth/rfcomm.h>
#include <linux/bluetooth/rfcomm_sec.h>
#include <linux/bluetooth/btmem.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/btconfig.h>
#include <linux/bluetooth/bt_errno.h>
#else
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <asm/unaligned.h>

#include "include/rfcomm.h"
#include "include/rfcomm_sec.h"
#include "include/btmem.h"
#include "include/l2cap.h"
#include "include/bluetooth.h"
#include "include/local.h"
#include "include/bt_errno.h"
#endif

/****************** DEBUG CONSTANT AND MACRO SECTION ************************/

/* Defines for the debug macros */

#if DEBUG_RFCOMM_RECEIVE_FLOW
#define D_REC(fmt...) printk(RFCOMM_DBG_STR fmt)
#else
#define D_REC(fmt...) 
#endif

#if DEBUG_RFCOMM_SEND_PROCESS
#define D_SND(fmt...) printk(RFCOMM_DBG_STR fmt)
#else
#define D_SND(fmt...)
#endif

#if DEBUG_RFCOMM_INTERNAL_SIGNALING
#define D_CTRL(fmt...) printk(RFCOMM_DBG_STR fmt)
#else
#define D_CTRL(fmt...)
#endif

#if PRINT_DATA_ENABLE
#define RF_DATA(str, data, len) print_data(str, data, len)
#else
#define RF_DATA(str, data, len)
#endif

#define FNC __FUNCTION__ ": "

/****************** CONSTANT AND MACRO SECTION ******************************/

#define SET_PF(ctr) ((ctr) | (1 << 4)) 
/* Sets the P/F-bit in the control field */
#define CLR_PF(ctr) ((ctr) & 0xef)
/* clears the P/F-bit in the control field */
#define GET_PF(ctr) (((ctr) >> 4) & 0x1)
/* Returns the P/F bit */

#define SHORT_CRC_CHECK 2
/* Used for uih packets */
#define LONG_CRC_CHECK 3
/* Used for all packet exepts for the uih packets */
#define SHORT_HDR 2
/* Short header for short uih packets */
#define LONG_HDR 3
/* and long header for long uih packets */

/* FIXME: Should thsi one be define here? */
#define SHORT_PAYLOAD_SIZE 127
#define EA 1
/* Used for setting the EA field in different packets,  really neccessary? */
#define FCS_SIZE 1
/* Yes the FCS size is only one byte */

#define RFCOMM_MAX_HDR_SIZE 5

#define MAX_CREDITS   30
#define START_CREDITS 7
#define MIN_CREDITS   15

#define DEF_RFCOMM_MTU 127

/* The values in the control field when sending ordinary rfcomm packets */
#define SABM      0x2f
#define SABM_SIZE 4
#define UA        0x63
#define UA_SIZE   4
#define DM        0x0f
#define DISC      0x43
#define UIH       0xef

/* The values in the type field in a multiplexer command packet */
#define TEST  0x08
#define FCON  0x28
#define FCOFF 0x18
#define MSC   0x38
#define RPN   0x24
#define RLS   0x14
#define PN    0x20
#define NSC   0x04

/* Define of some V.24 signals modem control signals in RFCOMM */
#define FC  0x02
#define RTC 0x04
#define RTR 0x08
#define DV  0x80

/* endian-swapping macros for structs */
#define swap_long_frame(x) ((x)->h.length.val = le16_to_cpu((x)->h.length.val))
#define swap_mcc_long_frame(x) (swap_long_frame(x))

#define RFCOMM_CON_TIMEOUT (5*HZ)

/****************** TYPE DEFINITION SECTION *********************************/

/* Typedefinitions of stuctures used for creating and parsing packets, for a
   further description of the structures please se the bluetooth core
   specification part F:1 and the ETSI TS 07.10 specification  */

#include <asm/byteorder.h>
#ifdef __LITTLE_ENDIAN_BITFIELD

typedef struct address_field {
	u8 ea:1;
	u8 cr:1;
	u8 d:1;
	u8 server_chn:5;
} __attribute__ ((packed)) address_field;

typedef struct short_length {
	u8 ea:1;
	u8 len:7;
} __attribute__ ((packed)) short_length;

typedef union long_length {
	struct bits {
		u16 ea:1;
		u16 len:15;
	} __attribute__ ((packed)) bits;
	u16 val;
} __attribute__ ((packed)) long_length;

typedef struct short_frame_head {
	address_field addr;
	u8 control;
	short_length length;
} __attribute__ ((packed)) short_frame_head;

typedef struct short_frame {
	short_frame_head h;
	u8 data[0];
} __attribute__ ((packed)) short_frame;

typedef struct long_frame_head {
	address_field addr;
	u8 control;
	long_length length;
	u8 data[0];
} __attribute__ ((packed)) long_frame_head;

typedef struct long_frame {
	long_frame_head h;
	u8 data[0];
} __attribute__ ((packed)) long_frame;

/* Typedefinitions for structures used for the multiplexer commands */
typedef struct mcc_type {
	u8 ea:1;
	u8 cr:1;
	u8 type:6;
} __attribute__ ((packed)) mcc_type;

typedef struct mcc_short_frame_head {
	mcc_type type;
	short_length length;
	u8 value[0];
} __attribute__ ((packed)) mcc_short_frame_head;

typedef struct mcc_short_frame {
	mcc_short_frame_head h;
	u8 value[0];
} __attribute__ ((packed)) mcc_short_frame;

typedef struct mcc_long_frame_head {
	mcc_type type;
	long_length length;
	u8 value[0];
} __attribute__ ((packed)) mcc_long_frame_head;

typedef struct mcc_long_frame {
	mcc_long_frame_head h;
	u8 value[0];
} __attribute__ ((packed)) mcc_long_frame;

/* MSC command */
typedef struct v24_signals {
	u8 ea:1;
	u8 fc:1;
	u8 rtc:1;
	u8 rtr:1;
	u8 reserved:2;
	u8 ic:1;
	u8 dv:1;
} __attribute__ ((packed)) v24_sigs;

typedef struct brk_sigs {
	u8 ea:1;
	u8 b1:1;
	u8 b2:1;
	u8 b3:1;
	u8 len:4;
} __attribute__ ((packed)) brk_sigs;

typedef struct msc_msg {
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	address_field dlci;
	u8 v24_sigs;
//	brk_sigs break_signals;
	u8 fcs;
} __attribute__ ((packed)) msc_msg;

/* RPN command */
typedef struct rpn_msg {
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	address_field dlci;
	rpn_values rpn_val;
	u8 fcs;
} __attribute__ ((packed)) rpn_msg;

/* RLS command */  
typedef struct rls_msg {
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	address_field dlci;
	u8 error:4;
	u8 res:4;
	u8 fcs;
} __attribute__ ((packed)) rls_msg;

/* PN command */
typedef struct pn_msg {
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
/* The res1, res2 and res3 values have to be set to 0 by the sender */
	u8 dlci:6;
	u8 res1:2;
	u8 frame_type:4;
	u8 credit_flow:4;
	u8 prior:6;
	u8 res2:2;
	u8 ack_timer;
	u16 frame_size;
	u8 max_nbrof_retrans;
	u8 credits;
	u8 fcs;
} __attribute__ ((packed)) pn_msg;

/* NSC-command */
typedef struct nsc_msg {
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	mcc_type command_type;
	u8 fcs;
} __attribute__ ((packed)) nsc_msg;

#elif defined(__BIG_ENDIAN_BITFIELD)

typedef struct address_field {
	u8 server_chn:5;
	u8 d:1;
	u8 cr:1;
	u8 ea:1;
} __attribute__ ((packed)) address_field;

typedef struct short_length {
	u8 len:7;
	u8 ea:1;
} __attribute__ ((packed)) short_length;

typedef union long_length {
	struct bits {
		u16 len:15;
		u16 ea:1;
	} __attribute__ ((packed)) bits;
	u16 val;
} __attribute__ ((packed)) long_length;

typedef struct short_frame_head { 
	address_field addr;
	u8 control;
	short_length length;
} __attribute__ ((packed)) short_frame_head;

typedef struct short_frame {
	short_frame_head h;
	u8 data[0];
} __attribute__ ((packed)) short_frame;

typedef struct long_frame_head { 
	address_field addr;
	u8 control;
	long_length length;
	u8 data[0];
} __attribute__ ((packed)) long_frame_head;

typedef struct long_frame { 
	long_frame_head h;
	u8 data[0];
} __attribute__ ((packed)) long_frame;

/* Typedefinitions for structures used for the multiplexer commands */
typedef struct mcc_type { 
	u8 type:6;
	u8 cr:1;
	u8 ea:1;
} __attribute__ ((packed)) mcc_type;

typedef struct mcc_short_frame_head { 
	mcc_type type;
	short_length length;
	u8 value[0];
} __attribute__ ((packed)) mcc_short_frame_head;

typedef struct mcc_short_frame { 
	mcc_short_frame_head h;
	u8 value[0];
} __attribute__ ((packed)) mcc_short_frame;

typedef struct mcc_long_frame_head { 
	mcc_type type;
	long_length length;
	u8 value[0];
} __attribute__ ((packed)) mcc_long_frame_head;

typedef struct mcc_long_frame { 
	mcc_long_frame_head h;
	u8 value[0];
} __attribute__ ((packed)) mcc_long_frame;

/* MSC command */
typedef struct v24_signals { 
	u8 dv:1;
	u8 ic:1;
	u8 reserved:2;
	u8 rtr:1;
	u8 rtc:1;
	u8 fc:1;
	u8 ea:1;
} __attribute__ ((packed)) v24_sigs;

typedef struct brk_sigs { 
	u8 len:4;
	u8 b3:1;
	u8 b2:1;
	u8 b1:1;
	u8 ea:1;
} __attribute__ ((packed)) brk_sigs;

typedef struct msc_msg { 
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	address_field dlci;
	u8 v24_sigs;
//	brk_sigs break_signals;
	u8 fcs;
} __attribute__ ((packed)) msc_msg;

/* RPN command */
typedef struct rpn_msg { 
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	address_field dlci;
	rpn_values rpn_val;
	u8 fcs;
} __attribute__ ((packed)) rpn_msg;

/* RLS command */  
typedef struct rls_msg { 
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	address_field dlci;
	u8 res:4;
	u8 error:4;
	u8 fcs;
} __attribute__ ((packed)) rls_msg;

/* PN command */
typedef struct pn_msg { 
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
/* The res1, res2 and res3 values have to be set to 0 by the sender */
	u8 res1:2;
	u8 dlci:6;
	u8 credit_flow:4;
	u8 frame_type:4;
	u8 res2:2;
	u8 prior:6;
	u8 ack_timer;
	u16 frame_size;
	u8 max_nbrof_retrans;
	u8 credits;
	u8 fcs;
} __attribute__ ((packed)) pn_msg;

/* NSC-command */
typedef struct nsc_msg { 
	short_frame_head s_head;
	mcc_short_frame_head mcc_s_head;
	mcc_type command_type;
	u8 fcs;
} __attribute__ ((packed)) nsc_msg;

#else /* __XXX_ENDIAN */
#error Processor endianness unknown!
#endif /* __XXX_ENDIAN */

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static void process_mcc(u8* data, u32 len, rfcomm_con *rfcomm, s32 long_pkt);
static s32 send_ua(rfcomm_con *rfcomm, u8 dlci);
static s32 send_dm(rfcomm_con *rfcomm, u8 dlci);
static s32 send_sabm(rfcomm_con *rfcomm, u8 dlci);
static s32 send_disc(rfcomm_con *rfcomm, u8 dlci);
static s32 send_uih(u8 *data, u32 len, rfcomm_con *rfcomm, u8 dlci);

static s32 send_pn_msg(rfcomm_con *rfcomm, u8 prior, u32 frame_size, u8 credit_flow, u8 credits, u8 dlci, u8 cr);
static s32 send_nsc_msg(rfcomm_con *rfcomm, mcc_type cmd, u8 cr);
static void set_uih_hdr(short_frame *uih_pkt, u8 dlci, u32 len, u8 cr);
static u32 crc_check(u8 *data, u32 length, u8 check_sum);
static u8 crc_calc(u8 *data, u32 length);
static void create_crctable(u8 table[]);
static rfcomm_con* get_new_rfcomm_con(void);
static rfcomm_con* get_rfcomm_con(u8 line);
static s32 get_connected_dlci(rfcomm_con *rfcomm);

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/* The crctable for the FEC field */
static u8 crctable[256];

/* One RFCOMM connection for each ttyBTx */
rfcomm_con rfcomm_con_list[BT_NBR_DATAPORTS];

#ifdef __KERNEL__
static struct timer_list rfcomm_timer;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct wait_queue *rfcomm_disconnect_wq = NULL;
#else
static wait_queue_head_t rfcomm_disconnect_wq;
#endif /* LINUX_VERSION_CODE */

rpn_values rpn_val;

/****************** FUNCTION DEFINITION SECTION *****************************/

/****************************************************************************
 * Functions reachable outside this file
 ****************************************************************************/

void rfcomm_reset_con(u8 line)
{	
	s32 j;

	/* check if valid line number */
	if (line >= BT_NBR_DATAPORTS)
	{
		D_ERR(FNC"invalid line!\n");
		return;
	}

	D_CTRL(FNC"line %d\n", line);

	rfcomm_con_list[line].magic = RFCOMM_MAGIC;
	rfcomm_con_list[line].line = line;
	rfcomm_con_list[line].credit_flow = 0;
	for (j = 0; j < 62; j++) {
		rfcomm_con_list[line].dlci[j].local_credits = 0;
		rfcomm_con_list[line].dlci[j].state = DISCONNECTED;
		rfcomm_con_list[line].dlci[j].mtu = DEF_RFCOMM_MTU;
		rfcomm_con_list[line].dlci[j].initiated = FALSE;
		rfcomm_con_list[line].dlci[j].initiator = FALSE;
	}
	rfcomm_con_list[line].initiator = FALSE;
	rfcomm_con_list[line].l2cap = NULL;
}

s32
rfcomm_module_init(void)
{
#ifdef __KERNEL__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	init_waitqueue_head(&rfcomm_disconnect_wq);
#endif /* LINUX_VERSION_CODE */
#endif /* __KERNEL__ */

	return 0;
}

void
rfcomm_init(void)
{
	s32 i;
	protocol_layer this_layer;

	DSYS("Initialising RFCOMM\n");
	create_crctable(crctable);
	
	/* Set the confirm and indication functions for the L2CAP-layer */
	this_layer.con_ind = rfcomm_connect_ind;
	this_layer.con_pnd = rfcomm_connect_pnd;
	this_layer.conf_ind = rfcomm_config_ind;
	this_layer.disc_ind = rfcomm_disconnect_ind;
	this_layer.con_cfm = rfcomm_connect_cfm;
	this_layer.conf_cfm = rfcomm_config_cfm;
	this_layer.disc_cfm = rfcomm_disconnect_cfm;
	this_layer.receive_data = rfcomm_receive_data;
        //printf("kainui : %s\n",this_layer.receive_data);

	/* Register RFCOMM in the L2CAP layer*/
	l2cap_register_upper(RFCOMM_LAYER, &this_layer);
 
	/* Initiate rfcomm lines */
	for (i = 0; i < BT_NBR_DATAPORTS; i++) {
		rfcomm_reset_con(i);
	}

	/* Set the values in the rpn octets */
	rpn_val.bit_rate = 7; /* Irrelevent here */
	rpn_val.data_bits = 3; /* 8 databits */
	rpn_val.stop_bit = 0; /*One stopbit */
	rpn_val.parity = 0;
	rpn_val.parity_type = 0;
	rpn_val.res1 = 0;
	rpn_val.xon_input = 0;
	rpn_val.xon_output = 0;
	rpn_val.rtr_input = 0;
	rpn_val.rtr_output = 0;
	rpn_val.rtc_input = 0;
	rpn_val.rtc_output = 0;
	rpn_val.res2 = 0;
	rpn_val.xon_u8 = 0x11;
	rpn_val.xoff_u8 = 0x13;
	memset(&rpn_val.pm, 0 , 2); /* Set the mask to zero */
        
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
        rfcomm_sec_man_init();
#endif
}

s32
rfcomm_set_mtu(rfcomm_con *rfcomm, u8 dlci, u32 new_mtu)
{
	DSYS(FNC"MTU set to:%d\n", new_mtu);
	if (rfcomm->dlci[dlci].state == DISCONNECTED) {
		rfcomm->dlci[dlci].mtu = new_mtu;
		return 0;
	} else {
		return -1;
	}
}

static char* state2name(u8 state)
{
	switch(state)
	{
	case DISCONNECTED :
		return "DISCONNECTED";
	case CONNECTING :
		return "CONNECTING";
	case NEGOTIATING :
		return "NEGOTIATING";
	case CONNECTED :
		return "CONNECTED";
	case DISCONNECTING :
		return "DISCONNECTING";
	default :
		return "Invalid State";
	}
}

void 
rfcomm_close(void)
{
	s32 i;
  
	DSYS("Shutting down RFCOMM\n");

	/* First try disconnecting */
	for (i = 0; i < BT_NBR_DATAPORTS; i++) {
		rfcomm_con *rfcomm = get_rfcomm_con(i);

		/* fixme -- handle the case where only the control 
		   channel is left on a rfcomm session */

		if (get_connected_dlci(rfcomm) > 0) {
			DSYS(FNC"Now disconnecting rfcomm line %d\n", i);
			rfcomm_disconnect_req(i);
		}		
	}

	/* If still connections left, terminate them */
	for (i = 0; i < BT_NBR_DATAPORTS; i++) {
		rfcomm_reset_con(i);
	}

}

/* This function creates an rfcomm connection over the control channel DCLI 0 */
  
s32 
rfcomm_connect_req(u8* bd_addr, u8 server_chn, u8 line)
{
	rfcomm_con *rfcomm;
	u8 tmp_dlci;
	s32 retval = 0;
  
	D_CTRL(FNC"server channel:%d, line:%d\n",
	       server_chn, line);

	if (!(rfcomm = get_rfcomm_con(line))) {
		D_ERR(FNC"%d is an invalid line\n", line);
		return -MSGCODE(MSG_LAYER_RFCOMM, RFCOMM_INVALID_LINE);
	}

	if (rfcomm->dlci[0].state == DISCONNECTED) {
		rfcomm->initiator = TRUE;
	}
	
	rfcomm->line = line;
	rfcomm->server_chn = server_chn;
	tmp_dlci = (server_chn << 1) | (~rfcomm->initiator & 0x1);
	
	if (!(rfcomm->l2cap)) {

		rfcomm->dlci[0].state = CONNECTING;    

		/* we don't have a l2cap connection yet */
		if ((retval = l2ca_connect_req(bd_addr, RFCOMM_LAYER)) < 0) {
			D_ERR(FNC"l2ca_connect_req failed\n");
			return retval;
		}
	} else if (!((rfcomm->l2cap)->current_state == OPEN)) {
		
		D_ERR(FNC"L2CAP_CON exists but is not in OPEN state (yet?)\n");
		/* FIXME: Should we really return no error here? */
		return 0;
	} else if (rfcomm->dlci[0].state != CONNECTED) {

		/* we have an l2cap channel (server ch) */
		D_CTRL(FNC"we already have an l2cap channel)\n");

		/* fixme -- strange case ... */
		if (rfcomm->dlci[0].state != DISCONNECTED) {
			D_ERR(FNC"DLCI:0 neither CONNECTED nor DISCONNECTED\n");
			return -1;
		} else {
			rfcomm->dlci[0].state = CONNECTING;
			/* Establish the control channel */
			return send_sabm(rfcomm, 0);
		}
	} else if (rfcomm->dlci[tmp_dlci].state != DISCONNECTED) {

		D_ERR(FNC"trying to connect a non DISCONNECTED server channel (%d)\n",server_chn);
		return -MSGCODE(MSG_LAYER_RFCOMM, RFCOMM_SRVCHN_CONNECTED);
	} else {
		D_CTRL(FNC"We are negotiating rfcomm (pn msg)\n");
		rfcomm->dlci[tmp_dlci].state = NEGOTIATING;
		/* must fit i l2cap mtu */
		D_CTRL(FNC"negotiate mtu : %d bytes\n",
		       rfcomm->l2cap->remote_mtu - 5);
		return send_pn_msg(rfcomm, 7, rfcomm->dlci[tmp_dlci].mtu, 0, 0,
			    tmp_dlci, TRUE);
	}

	return 0;
}


/* fixme -- this should be on dlci/rfcomm con basis not line ... */

s32
rfcomm_disconnect_req(u8 line)
{
	rfcomm_con *rfcomm;
	s32 tmp;

	D_CTRL("rfcomm_disconnect_req %d\n", line);
	if(line >= BT_NBR_DATAPORTS) {
		D_ERR("rfcomm_disconnect_req : Invalid line\n");
		return -MSGCODE(MSG_LAYER_RFCOMM, RFCOMM_INVALID_LINE);
	}
	
	if (!(rfcomm = &rfcomm_con_list[line]))
	{
		D_ERR("rfcomm_disconnect_req : no rfcomm con\n");
		return -EINVAL;
	}

	tmp = get_connected_dlci(rfcomm);

	if (tmp > 0) {
		l2cap_con *l2cap = rfcomm->l2cap;

		rfcomm->dlci[tmp].state = DISCONNECTING;
		
		send_disc(rfcomm, tmp);

#ifdef __KERNEL__
		start_wq_timer(&rfcomm_timer, RFCOMM_CON_TIMEOUT,
			       &rfcomm_disconnect_wq);
#endif

		/* FIXME -- check that we haven't already received 
		   disconnect 'acknowledge' */
		interruptible_sleep_on(&rfcomm_disconnect_wq);

		/* Check that rfcomm session really disconnected */
		/* FIXME -- add timer obj with status in rfcomm obj */

		/* check control channel */
		if (rfcomm->dlci[0].state != DISCONNECTED)
		{
			D_ERR("Rfcomm disconnect failed, reset session\n");
#ifdef __KERNEL__			
			bt_unregister_rfcomm(rfcomm->line);
			bt_disconnect_cfm(CREATE_RFCOMM_ID(rfcomm->line, 0), 
					  rfcomm->l2cap->c_result);
#endif
			rfcomm_reset_con(rfcomm->line);
		}

		/* Now rfcomm is disconnected, disconnect l2cap */
		return l2ca_disconnect_req(l2cap);
	}
	else
		D_WARN("rfcomm_disconnect_req : line not connected !\n");

	return 0;
}
	

/* The lower protocol layer, L2CAP, indicates that a new connection has been
   established at a lower layer. RFCOMM should ask the control block whether
   to accept or reject the connection and then reply to L2CAP with
   l2cap_connect_rsp. */

void 
rfcomm_connect_ind(l2cap_con *l2cap)
{
	rfcomm_con *rfcomm;
	D_CTRL("rfcomm_connect_ind\n");  
	if (!(rfcomm = get_new_rfcomm_con())) {
		D_ERR("rfcomm_connect_ind: error: couldn't find free tty\n");
		
		/* fixme -- respond neg ! */

		return;
	} else {
          
		if (l2ca_connect_rsp(l2cap, RES_SUCCESS, STAT_NOINFO)) {
			D_ERR("rfcomm_connect_ind: l2ca_connect_rsp failed\n");
			return;
		}
		rfcomm->initiator = FALSE;
		rfcomm->dlci[0].state = CONNECTING;
		rfcomm->l2cap = l2cap;
		l2cap->upper_con = (void*) rfcomm;
	}
}

/* only client receives connect pnd */
void rfcomm_connect_pnd(l2cap_con *l2cap, s32 status)
{
	printk("rfcomm_connect_pnd : reason %d\n", status);	
}

void 
rfcomm_connect_cfm(l2cap_con *l2cap, s32 status)
{
	s32 i = 0;
	s32 stop = FALSE;

	rfcomm_con *rfcomm = NULL;

	D_CTRL(FNC"status %d\n", status);

	/* FIXME -- use bt session list (which holds pointers to all layers
	   con objs) to see which rfcomm that was trying to connect */

	/* Find the connecting rfcomm_con */
	while ((i < BT_NBR_DATAPORTS) && (!stop)) {
		if ((rfcomm_con_list[i].dlci[0].state == CONNECTING) && 
		    (rfcomm_con_list[i].initiator == TRUE)) {
			rfcomm = &rfcomm_con_list[i];
			stop = TRUE;
		}
		i++;
	}
 
	if (status) {
		/* reset this rfcomm connection !*/
		rfcomm_reset_con(rfcomm->line);
		bt_connect_cfm(CREATE_RFCOMM_ID(rfcomm->line,0), status);
		return;
	}

	if (rfcomm != NULL) {
		rfcomm->l2cap = l2cap;
		l2cap->upper_con = (void*) rfcomm;
		if (!l2ca_local_conf_done(l2cap))
		{
			/* still haven't sent config request yet */
			
			/* Zero indicates that default values will be used */
			if (l2ca_config_req(l2cap, 0, NULL, 0, 0)) {
				D_ERR(FNC"l2ca_config_req failed\n");
			} 
		} else 
			DSYS(FNC"already have sent back a pos response\n");
	} else {
		D_ERR(FNC"couldn't find the correct rfcomm_con object\n");
	}

}


/* The lower protocol layer, L2CAP, indicates that it has received a
   configuration indication signal and RFCOMM should reply with proper 
   configuration parameters to the L2CAP layer, with a l2cap_config_rsp
   messages and then send a own configuration request messages. */

void 
rfcomm_config_ind(l2cap_con* l2cap)
{

	/* 
	   FIXME
	   Check whether the received params are acceptable, 
	   accept all for now
	*/

	D_CTRL("rfcomm_config_ind : remote cid %d\n", l2cap->remote_cid);
	/* check if we have sent a pos response yet */
	if (!l2ca_remote_conf_done(l2cap)){
		/* still haven't sent a pos configure response*/
		
		if (l2ca_config_rsp(l2cap, l2cap->remote_mtu, 
				    NULL, CONF_SUCCESS)) {
			D_ERR(FNC"l2ca_config_rsp failed\n");
		}
	} else 
		DSYS(FNC"already have sent back a pos response\n");


	/* check if we received a pos response on a previous conf req */ 
	if (((rfcomm_con*) l2cap->upper_con)->initiator == FALSE) {

		/* check if we received a pos response on a 
		   previous config req */ 
		if (!l2ca_local_conf_done(l2cap))
		{
			l2cap->local_mtu=l2cap->remote_mtu;

			DSYS(FNC"Local l2cap mtu set to %d\n", 
			      l2cap->local_mtu);

			if (l2ca_config_req(l2cap, 0, NULL, 
					    0, 0)) {
				D_ERR(FNC"l2ca_config_req failed\n");
			}
		} else 
			DSYS(FNC"already ready with config req\n");

	} 

}

/* The lower protocol layer, L2CAP, indicates that the configuration
   procedure has succeeded */

void 
rfcomm_config_cfm(l2cap_con *l2cap, s32 status)
{
	rfcomm_con *rfcomm;
	rfcomm = (rfcomm_con *) l2cap->upper_con;

	D_CTRL(FNC"\n");

	if (status) {
		DSYS(FNC"l2cap configuration failed\n");
		/* notify usermode and reset connection */
		bt_connect_cfm(CREATE_RFCOMM_ID(rfcomm->line,0), status);
		rfcomm_reset_con(rfcomm->line);
		return;
	} else {
		DSYS(FNC"l2cap is now open\n");
		
		if (rfcomm->initiator && 
		    rfcomm->dlci[0].state == CONNECTING) {
			D_CTRL("sending sabm\n");
			send_sabm(rfcomm, 0);
		}
		else if (!rfcomm->initiator && 
                         ((l2cap->remote_mtu-5) < DEF_RFCOMM_MTU) )
                {
			
			s32 j;
			DSYS(FNC"Setting RFCOMM frame size to %d\n", 
			     l2cap->remote_mtu-5);
			
			for (j = 0; j < 62; j++) {
				rfcomm->dlci[j].mtu = (l2cap->remote_mtu-5);
			}
                }
        }
        

}

/* The lower protocol layer, L2CAP, indicates that the lower layer 
   connection is about to disconnect */
void 
rfcomm_disconnect_ind(l2cap_con *l2cap)
{
	rfcomm_con *rfcomm;

	DSYS(FNC "remote cid %d\n", l2cap->remote_cid);

	if ((rfcomm = (rfcomm_con*)l2cap->upper_con)) {
		/* This l2cap connection is going down, remove all rfcomm cons 
		   and notify upper tty */

		if (!l2cap->link_up) {
			DSYS(FNC "Baseband is down, reset this RFCOMM session\n");
#ifdef __KERNEL__
			bt_unregister_rfcomm(rfcomm->line);
#endif
			bt_disconnect_ind(CREATE_RFCOMM_ID(rfcomm->line, 0));
		}

		rfcomm_reset_con(rfcomm->line);
	}

	/* always try to send back rsp (if link is down con is deleted) */
	if (l2ca_disconnect_rsp(l2cap)) {
		D_ERR(FNC "l2ca_disconnect_rsp failed\n");
		return;
	}
}


void 
rfcomm_disconnect_cfm(l2cap_con *l2cap)
{

	rfcomm_con *rfcomm;
  
	D_CTRL(FNC"disconnected\n");

	rfcomm = (rfcomm_con*) l2cap->upper_con;

	/* fixme -- should we indicate to bt interface when rfcomm is 
	   down or when l2cap for rfcomm is down ? */
  	bt_disconnect_ind(CREATE_RFCOMM_ID(rfcomm->line, 0));

	/* fixme -- add these glue layer functions in userstack */
#ifdef __KERNEL__
	bt_unregister_rfcomm(rfcomm->line);

	/* wake up bt line */
	bt_disconnect_cfm(CREATE_RFCOMM_ID(rfcomm->line, 0), 
			  l2cap->c_result);
#endif	
	rfcomm_reset_con(rfcomm->line);
	

}

/* This function should be called from the L2CAP layer data should pos32 at
   the beginning of the RFCOMM data, and len should be the length of that 
   data.*/

void 
rfcomm_receive_data(l2cap_con *l2cap, u8 *data, u32 len)
{
	rfcomm_con *rfcomm;
	short_frame *short_pkt; 
	long_frame *long_pkt;
	u8* uih_data_start;
	u32 uih_len;
	u8 tmp_dlci;

	RF_DATA(FNC"rfcomm_receive_data:",data,len);
	
	D_REC(FNC"%d bytes, our cid is %d\n",len, 
	      l2cap->remote_cid);
	short_pkt = (short_frame*) data;

	tmp_dlci = (((short_pkt->h.addr.server_chn & 0x1f) << 1) |
		    (short_pkt->h.addr.d & 0x1));

	switch (CLR_PF(short_pkt->h.control)) {
	case SABM:
		D_CTRL(FNC"SABM-packet received\n");
    
		if (crc_check((u8*) short_pkt, LONG_CRC_CHECK, 
			      short_pkt->data[0]) < 0) {
			break;
		}

		/* If the SABM command wants to open the control channel, we
		   have to create a new rfcomm_con object */
		if ((tmp_dlci) == 0) {

			D_CTRL(FNC"server channel == 0\n");
			rfcomm = ((rfcomm_con*) l2cap->upper_con);
      
			D_CTRL(FNC"setting l2cap_con, no serv.channel yet\n");
			rfcomm->dlci[0].state = CONNECTED;

                        D_CTRL(FNC"sending back UA - control channel\n");
                        send_ua((rfcomm_con*) l2cap->upper_con, tmp_dlci);
			bt_connect_ind(CREATE_RFCOMM_ID(rfcomm->line, 0));
		}
	
		/* If the channel isn't the control channel, we know that the
		   object exist. If we haven't opened any other channel than
		   the control channel we open the new channel here */

		else if (valid_dlci(tmp_dlci)) {
			rfcomm = ((rfcomm_con*) l2cap->upper_con);

			D_REC(FNC"setting server channel %d\n",
			      short_pkt->h.addr.server_chn);

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
                        rfcomm_check_allowed_security(rfcomm->l2cap->remote_bd,
                                                      tmp_dlci, rfcomm);

			/* fixme -- check result and send neg response if not allowed */
			
#else
			bt_connect_ind(CREATE_RFCOMM_ID(rfcomm->line, tmp_dlci));
			rfcomm->dlci[tmp_dlci].state = CONNECTED;

			/* registers in bt driver */
                        bt_register_rfcomm(rfcomm, tmp_dlci);

			/* wake up any blocking connect/waits */ 
			bt_connect_cfm(CREATE_RFCOMM_ID(rfcomm->line, tmp_dlci), 0 /* status ok*/ );

                        D_CTRL(FNC"sending back UA - other channel\n");
                        
                        send_ua(rfcomm, tmp_dlci);
#endif /* CONFIG_BLUETOOTH_USE_SECURITY_MANAGER */
		} else {

			D_CTRL(FNC"no server on channel %d, sending DM\n",
			      tmp_dlci);
      
			send_dm(((rfcomm_con*) l2cap->upper_con),tmp_dlci);
		}

		break;
    
	case UA:
		rfcomm = ((rfcomm_con*) l2cap->upper_con);

		if (rfcomm->magic != RFCOMM_MAGIC) {
			D_ERR(FNC"Invalid magic number\n");
			break;
		}
		
		D_CTRL(FNC"UA packet received on line %d\n", rfcomm->line);

		if (rfcomm->dlci[0].state == CONNECTING) {
			/* Now we are the initiating side and we have got a
			   respons to our SABM command. We then send a PN
			   messages to negotiat the frame length */
			rfcomm->dlci[0].state = CONNECTED;
			tmp_dlci = ((rfcomm->server_chn << 1) |
				    ((~rfcomm->initiator) & 0x1));
			
			/* must fit in l2cap mtu incl rfcomm hdrs */
			send_pn_msg(rfcomm, 7, rfcomm->dlci[tmp_dlci].mtu, 0,
				    0, tmp_dlci, TRUE);
			rfcomm->dlci[tmp_dlci].state = NEGOTIATING;

		} else if (rfcomm->dlci[tmp_dlci].state == NEGOTIATING) {

			rfcomm->dlci[tmp_dlci].state = CONNECTED;

			/* registers in bt driver */
                        bt_register_rfcomm(rfcomm, tmp_dlci);
 
			/* wake up any blocking connect/waits */ 
			bt_connect_cfm(CREATE_RFCOMM_ID(rfcomm->line, tmp_dlci), 0 /* status ok*/ );
			
			D_CTRL(FNC"successfully connected on DLCI:%d\n",
			       tmp_dlci);
			
			/* FIXME: Should we always do this ? */
			rfcomm_msc_msg(rfcomm, EA | RTC | RTR | DV, MCC_CMD,
				       tmp_dlci);
			rfcomm->dlci[tmp_dlci].initiator = TRUE;

		} else if (rfcomm->dlci[tmp_dlci].state == DISCONNECTING) {
		  
			if (tmp_dlci == 0) {
				/* Control channel */
#ifdef __KERNEL__
				release_wq_timer(&rfcomm_timer);
#endif
				DSYS(FNC"RFCOMM disconnected ctrl ch (local) on line [%d]\n", rfcomm->line);
				rfcomm->dlci[0].state = DISCONNECTED;
				
				/* this will take down l2cap aswell */
				wake_up_interruptible(&rfcomm_disconnect_wq);
				
			} else {
				/* Data channel */
				s32 tmp;
				rfcomm->dlci[tmp_dlci].state = DISCONNECTED;
				tmp = get_connected_dlci(rfcomm);

				if (tmp >= 0) {
					rfcomm->dlci[tmp].state = DISCONNECTING;
					send_disc(rfcomm, tmp);
				} else {
					D_ERR("Could not find connected DLCI\n");
				}
				
			}
		} else if (rfcomm->dlci[tmp_dlci].state == DISCONNECTED) {
			rfcomm->dlci[tmp_dlci].state = CONNECTED;
		} else {
			D_WARN(FNC" Something wrong receiving UA packet\n");
		}    
		break;
    
		/* Disconnect mode, 'NAK on SABM/DISC' */
	case DM:
		D_CTRL(FNC"DM packet received\n");
		rfcomm = ((rfcomm_con*) l2cap->upper_con);
		rfcomm->dlci[tmp_dlci].state = DISCONNECTED;

		/* Notify upper tty */
		/* bt_disconnect_ind() ? */

		break;
    
	case DISC:
		D_CTRL(FNC"DISC packet received\n");
		if (crc_check(data, LONG_CRC_CHECK, short_pkt->data[0]) < 0) {
			break;
		}
		rfcomm = ((rfcomm_con*) l2cap->upper_con);
		/* When the serverchannel is closing the whole connection
		   should be removed */
		if (rfcomm->dlci[tmp_dlci].state == DISCONNECTED) {
			send_dm(rfcomm, tmp_dlci);
		} else if ((short_pkt->h.addr.server_chn) == 0) {
			rfcomm->dlci[0].state = DISCONNECTED;

			DSYS("RFCOMM control ch disconnected (remotely) [line:%d]\n", 
			       rfcomm->line);
			send_ua(rfcomm, 0);
		} else {
			rfcomm->dlci[tmp_dlci].state = DISCONNECTED;
			send_ua(rfcomm, tmp_dlci);
			D_CTRL("dlci %d was disconnected\n", tmp_dlci);
			bt_disconnect_ind(CREATE_RFCOMM_ID(rfcomm->line, 
							   tmp_dlci));
#ifdef __KERNEL__
			bt_unregister_rfcomm(rfcomm->line);
#endif
		}
		break;
    
	case UIH:
   
		rfcomm = ((rfcomm_con*) l2cap->upper_con);

		if ((short_pkt->h.length.ea) == 0) {
			/* Then we cast the rfcomm packet to a long rfcomm
			   packet */ 
			D_REC(FNC"Long UIH packet received\n");
			long_pkt = (long_frame*) data;
			swap_long_frame(long_pkt);
			uih_len = long_pkt->h.length.bits.len;
			uih_data_start = long_pkt->h.data;
			D_REC(FNC"long packet length %d\n",
			      uih_len);
			if (uih_len > (len - 5)) {
				D_WARN(FNC", Long packet length doesn't match, setting length to l2cap len - 5\n");
				uih_len = len - 5;
			}
			
		} else {
			D_REC(FNC"Short UIH pkt received\n");
			uih_len = short_pkt->h.length.len;
			uih_data_start = short_pkt->data;
			if (uih_len > (len - 4)) {
				D_WARN(FNC", Short packet length doesn't match, setting length to l2cap len - 4\n");
				uih_len = len - 4;
			}
		}

		if (GET_PF(short_pkt->h.control)) {
			D_REC(FNC" %d more credits on dlci:%d...\n", 
			       *uih_data_start, tmp_dlci);

			rfcomm->dlci[tmp_dlci].local_credits += uih_data_start[0];
#ifdef __KERNEL__
			bt_feedstack();
#endif
			D_REC(FNC"Local_credits:%d\n", rfcomm->dlci[tmp_dlci].local_credits); 
			uih_data_start++;
			if (uih_len == 0) {
				break;
			}
			
			/* feed uih data to tty if any */

		}

		if (crc_check(data, SHORT_CRC_CHECK,
			      *(uih_data_start + uih_len)) < 0) {
			break;
		}

		if (short_pkt->h.addr.server_chn == 0) {
			D_REC(FNC"UIH on serv_channel 0\n");
			process_mcc(data, len, rfcomm,
				    !(short_pkt->h.length.ea));
		} else {
			u32 con_id = CREATE_RFCOMM_ID(rfcomm->line, tmp_dlci);

			if (rfcomm->credit_flow) {
				--rfcomm->dlci[tmp_dlci].remote_credits;
				D_CTRL(FNC": Remote credits: %d\n",rfcomm->dlci[tmp_dlci].remote_credits);
				if (rfcomm->dlci[tmp_dlci].remote_credits < MIN_CREDITS) {
					u8 newcredits = MAX_CREDITS - rfcomm->dlci[tmp_dlci].remote_credits;
					rfcomm_send_credits(rfcomm, tmp_dlci, newcredits);
					rfcomm->dlci[tmp_dlci].remote_credits += newcredits;

					D_SND(FNC"Remote credits: %d\n",rfcomm->dlci[tmp_dlci].remote_credits);

				}
			}
                        printf("kainui : rfcomm\n");
			bt_receive_top(con_id, uih_data_start, uih_len);
		}
		break;
    
	default:
		D_REC(FNC"illegal packet\n");
		break;
	}

}


/* Copies the tty data into the stack and creates headers and FCS, then the
   packet is sent to the lower layer L2CAP. The packet must not be larger
   than the actual MTU for the L2CAP layer. */

s32 
rfcomm_send_data(u32 con_id, u8 *data, u32 count)
{
	u32 c;
	u32 total = 0;
	u8 line;
	u8 dlci;
	rfcomm_con *rfcomm;

	line = GET_LINE(con_id);
	dlci = GET_RFCOMMDLCI(con_id);
	
	if (dlci == 0) {
		D_ERR(FNC"Not allowed to send data on DLCI 0\n");
		return -MSGCODE(MSG_LAYER_RFCOMM, RFCOMM_NO_DATA_ALLOWED);
	}
	
	rfcomm = &rfcomm_con_list[line];
	RF_DATA(FNC, data, count);

	if (rfcomm == NULL) {
		D_ERR(FNC" ERROR rfcomm_con == NULL\n");
		return -MSGCODE(MSG_LAYER_RFCOMM, RFCOMM_NO_CONNECTION);
	} else if (rfcomm->magic != RFCOMM_MAGIC) {
		D_ERR(FNC"ERROR magic test failed\n");
		return -MSGCODE(MSG_LAYER_RFCOMM, RFCOMM_BAD_MAGIC_NUMBER);
	} else if(rfcomm->dlci[0].state == FLOW_STOPPED) {
		D_SND(FNC"Flow stopped on all channels, returning zero\n");
		return 0;
	} else if (rfcomm->dlci[dlci].state == FLOW_STOPPED) {
		D_SND(FNC"Flow stopped, returning zero\n");
		return 0;
	}
	/* Check whether there are any data channels connected */
	else if (rfcomm->dlci[dlci].state == CONNECTED) {

		D_SND(FNC"trying to send %d bytes\n", count);
		while (count) {	
			if (rfcomm->credit_flow &&(rfcomm->dlci[dlci].local_credits <= 0)) {
				D_SND(FNC"Flow stopped, no credits returning %d\n", total);
				return total;
			}
			
			/* As long as there are anything to send we try to send
			   it. We split the data into parts not bigger than the
			   current MTU size. */
			
			c = MIN(count, rfcomm->dlci[dlci].mtu);
			
			/* FIXME: Optimize c! If we try to send 200 bytes and
			   there are only 150 bytes space in buffer, set c to
			   150 - sizeof(rfcomm_tx_buf)
			*/
			c = send_uih(data, c, rfcomm, dlci);

			if (c < 0) {
				return c; /* error */
			} else if (c == 0) {
				return total;
			} else {
				if (rfcomm->credit_flow) {
					--rfcomm->dlci[dlci].local_credits;
					D_SND(FNC"Local credits:%d\n", rfcomm->dlci[dlci].local_credits);
				}

				total += c;
				data += c;
				count -= c;
			}
		}
		D_SND(FNC"sent %d bytes\n", total);
		return total;
	} else {
		D_ERR(FNC"DLCI %d not connected\n", dlci);
#ifdef __KERNEL__
		/* FIXME - should we return an _error_ if rfcomm isn't up 
		   yet or only tell user process that 0 bytes was written 
		   ??? */
		return 0;
#else
		return -1;
#endif
	}

}

s32
rfcomm_flow_stop(u8 line, u8 dlci)
{
	if (rfcomm_con_list[line].credit_flow &&(rfcomm_con_list[line].dlci[dlci].local_credits <= 0)) {
		return TRUE;
	} else if (rfcomm_con_list[line].dlci[dlci].state == FLOW_STOPPED) {
		return TRUE;
	} else if (rfcomm_con_list[line].dlci[0].state == FLOW_STOPPED) {
		return TRUE;
	} else {
		return FALSE;
	}
}

void 
rfcomm_send_testdata(u32 count, u8 line)
{
	static u8 testdata[1024];
	static s32 testdata_init = 0;
	s32 i;
	u32 con_id = CREATE_RFCOMM_ID(line, PPP_DLCI);

	DSYS("rfcomm_send_testdata: sending %d bytes\n",count);
	if (!testdata_init) {
		for (i = 0; i < 1024; i++) {
			testdata[i] = (i%25)+ 65;
		}
	} 
	rfcomm_send_data(con_id, testdata, count);
}

/* Parses a multiplexer control channel packet */
void 
process_mcc(u8* data, u32 len, rfcomm_con *rfcomm, s32 longpkt)
{
	mcc_short_frame *mcc_short_pkt;
    
	D_CTRL("process_mcc\n");

	if (longpkt) {
		mcc_short_pkt = (mcc_short_frame*)(((long_frame*)data)->data);
	} else {
		mcc_short_pkt = (mcc_short_frame*)(((short_frame*)data)->data);
	}
  
	switch (mcc_short_pkt->h.type.type) {
	case TEST:
		if (mcc_short_pkt->h.type.cr == MCC_RSP) {
			D_CTRL(FNC"Received test command\n");
		} else {
			if ((mcc_short_pkt->h.length.ea) == 0) {
				mcc_long_frame *mcc_long_pkt;
				mcc_long_pkt = (mcc_long_frame*) mcc_short_pkt;
				swap_mcc_long_frame(mcc_long_pkt);
				rfcomm_test_msg(rfcomm, mcc_long_pkt->value,
					      mcc_long_pkt->h.length.bits.len,
					      MCC_RSP);
			} else {
				rfcomm_test_msg(rfcomm, mcc_short_pkt->value, 
					      mcc_short_pkt->h.length.len,
					      MCC_RSP);
			}
		}
		break;
    
	case FCON:  /* Flow control on command */
		D_CTRL(FNC"Received Flow control on command\n");
		if (mcc_short_pkt->h.type.cr == MCC_CMD) {
			rfcomm->dlci[0].state = CONNECTED;
			rfcomm_fcon_msg(rfcomm, MCC_RSP);
		}
		break;
    
	case FCOFF:  /* Flow control off command */
		D_CTRL(FNC"Received Flow control off command\n");
		if (mcc_short_pkt->h.type.cr == MCC_CMD) {
			rfcomm->dlci[0].state = FLOW_STOPPED;
			rfcomm_fcoff_msg(rfcomm, MCC_RSP);
		}
		break;
    
	case MSC:  /* Modem status command */
	{
		u8 dlci;
		u8 v24_sigs;
		
		dlci = (mcc_short_pkt->value[0]) >> 2;
		v24_sigs = mcc_short_pkt->value[1];

		if (rfcomm->dlci[dlci].state == DISCONNECTED) {
			send_dm(rfcomm, dlci);
			break;
		}
		if (mcc_short_pkt->h.type.cr == MCC_CMD) {
			D_CTRL(FNC"Received Modem status command\n");
			if (v24_sigs & 2) {
				D_CTRL(FNC"Device unable to accept frames\n");
				rfcomm->dlci[dlci].state = FLOW_STOPPED;
			} else {
				rfcomm->dlci[dlci].state = CONNECTED;
				D_CTRL(FNC"Flow ON, dlci %d\n", dlci);
  			}

			rfcomm_msc_msg(rfcomm, v24_sigs, MCC_RSP, dlci);
			
			if (!(rfcomm->dlci[dlci].initiated) && !(rfcomm->dlci[dlci].initiator)) {
				rfcomm_msc_msg(rfcomm, EA | RTR | RTC | DV,
					       MCC_CMD, dlci);
				rfcomm->dlci[dlci].initiated = TRUE;
			}
		} else {
			D_CTRL(FNC"Received Modem status response\n");

			if (v24_sigs & 2) {
				D_CTRL(FNC"Flow stop accepted\n");
			}
		}
		break;
	}
    
	case RPN:  /* Remote port negotiation command */
	{
		u8 tmp_dlci;

		tmp_dlci = (mcc_short_pkt->value[0]) >> 2;
		
		if (mcc_short_pkt->h.type.cr == MCC_CMD) {
			if (mcc_short_pkt->h.length.len == 1) {
				D_CTRL(FNC"Received Remote port negotiation command\n");
				rfcomm_rpn_msg(rfcomm, MCC_RSP, tmp_dlci, 0);
			} else {
				/* Accept the other sides settings (accept all
				   for now) */
				D_CTRL(FNC"Received Remote port negotiation respons\n");
				memcpy(&rpn_val, &mcc_short_pkt->value[1], 8);
				rfcomm_rpn_msg(rfcomm, MCC_RSP, tmp_dlci, 0);
				/* Zero the parametermask after respons */
				memset(&rpn_val.pm, 0, 2);
			}
		}	
		break;
	}

	case RLS: /* Remote line status */
	{
		u8 tmp_dlci;
		u8 err_code;
			
		D_CTRL(FNC"Received Remote line status\n");
		if (mcc_short_pkt->h.type.cr == MCC_CMD) {
			tmp_dlci = mcc_short_pkt->value[0] >> 2;
			err_code = mcc_short_pkt->value[1];
		
			rfcomm_rls_msg(rfcomm, MCC_RSP, tmp_dlci, err_code);
		}
		break;
	}

	case PN:  /* DLC parameter negotiation */
	{
		pn_msg *pn_pkt;

		D_CTRL(FNC"Received DLC parameter negotiation, PN\n");
		if (longpkt) {
			/* If a long length field is used, then move the
			   payload pointer one byte ahead */
			data++;
		}  
		pn_pkt = (pn_msg*) data;

		if (pn_pkt->mcc_s_head.type.cr == MCC_CMD) {
			u8 tmp_dlci;
			u16 frame_size;
			u8 credit, nbrof_credits;
			
			/* If the incoming messages is a command we send
			   back a response */

			tmp_dlci = pn_pkt->dlci;
			frame_size = le16_to_cpuu(&pn_pkt->frame_size);

			frame_size = MIN(frame_size, rfcomm->l2cap->local_mtu - RFCOMM_MAX_HDR_SIZE);
			credit = pn_pkt->credit_flow;
			nbrof_credits = pn_pkt->credits;
			if (credit) {
				DSYS(FNC"Using credit flow control, initiating credits are %d on dlci %d\n", nbrof_credits, tmp_dlci);

				rfcomm->credit_flow = TRUE;
				rfcomm->dlci[tmp_dlci].local_credits = nbrof_credits;
				D_CTRL(FNC"Local credits:%d\n", rfcomm->dlci[tmp_dlci].local_credits); 
				rfcomm->dlci[tmp_dlci].remote_credits = START_CREDITS;
				D_CTRL(FNC"Remote credits: %d\n",rfcomm->dlci[tmp_dlci].remote_credits);
				send_pn_msg(rfcomm, pn_pkt->prior, frame_size,
					    credit ^ 1, START_CREDITS, 
					    tmp_dlci, MCC_RSP);
			} else {
				send_pn_msg(rfcomm, pn_pkt->prior, frame_size,
					    0, 0, tmp_dlci, MCC_RSP);
			}
			rfcomm->dlci[tmp_dlci].mtu = frame_size;
			D_CTRL(FNC"process_mcc : mtu set to %d\n", 
			      rfcomm->dlci[tmp_dlci].mtu);
		} else {
			u8 tmp_dlci;
			tmp_dlci = pn_pkt->dlci;
			D_CTRL(FNC"received PN response with:\n");
			D_CTRL(FNC"Frame size:%d\n", le16_to_cpuu(&pn_pkt->frame_size));
			D_CTRL(FNC"credit_flow:%d\n", pn_pkt->credit_flow);
			D_CTRL(FNC"credits:%d\n", pn_pkt->credits);
			
			rfcomm->dlci[tmp_dlci].mtu  = le16_to_cpuu(&pn_pkt->frame_size);
			
			if (pn_pkt->credit_flow == 0xe) {
				DSYS(FNC"Credit flow control used\n");
				rfcomm->credit_flow = TRUE;
				rfcomm->dlci[tmp_dlci].local_credits = pn_pkt->credits;
				D_CTRL(FNC"Local credits:%d\n", rfcomm->dlci[tmp_dlci].local_credits); 
			}

			D_CTRL(FNC"process_mcc : mtu set on dlci:%d to %d\n", 
			       tmp_dlci, rfcomm->dlci[tmp_dlci].mtu);

			if (rfcomm->dlci[tmp_dlci].state == NEGOTIATING) {
				send_sabm(rfcomm, tmp_dlci);
			}
		}
		break;
	}
    
	case NSC: /* Non supported command resonse */
		D_CTRL(FNC"Received Non supported command response\n");
		break;
    
	default:  /* Non supported command received */
		D_REC(FNC"Received a non supported command\n");
    
		send_nsc_msg(rfcomm, mcc_short_pkt->h.type, MCC_RSP);
    
		break;
	}
}


/* Sending packet functions */

/* Creates a UA packet and puts it at the beginning of the pkt pointer */
                         
s32 
send_ua(rfcomm_con *rfcomm, u8 dlci)
{
	bt_tx_buf *tx_buf;
	short_frame *ua_pkt;
	u32 rfcomm_frame_size;
  
	D_CTRL("send_ua: Creating UA packet to DLCI %d\n",dlci);

	rfcomm_frame_size = sizeof(short_frame) + FCS_SIZE;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);
	
	if (!tx_buf) {
		D_ERR("send_ua : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}
	
	tx_buf->cur_len = rfcomm_frame_size;
  
	ua_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
  
	/* Always one in the address field */
	ua_pkt->h.addr.ea = 1;
	/* If we are the responder the cr bit should be set in a response */
	ua_pkt->h.addr.cr = ((~(rfcomm->initiator)) & 0x1);
	/* The control channel is on DLCI 0, i.e. d-bit should not be set */
	ua_pkt->h.addr.d = (dlci) & 0x1;
	ua_pkt->h.addr.server_chn = (dlci) >> 0x1;
	/* In RFCOMM the F-bit should always be set when sending UA packets */
	ua_pkt->h.control = SET_PF(UA);
	/* The UA packet has length zero, and then the ea bit in the length
	   field should  be set */
	ua_pkt->h.length.ea = 1;
	ua_pkt->h.length.len = 0;
	ua_pkt->data[0] = crc_calc((u8*) ua_pkt, LONG_CRC_CHECK);
  
	return l2cap_send_data(tx_buf,rfcomm->l2cap);
}

/* Creates a DM packet and puts it at the beginning of the pkt pointer */

s32 
send_dm(rfcomm_con *rfcomm, u8 dlci)
{
	bt_tx_buf *tx_buf;
	short_frame *dm_pkt;
	u32 rfcomm_frame_size;
  
	D_CTRL("send_dm: Creating DM packet to DLCI %d\n",dlci);
  
	rfcomm_frame_size = sizeof(short_frame) + FCS_SIZE;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("send_dm : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	dm_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));

	/* Always one in the address field */
	dm_pkt->h.addr.ea = 1;
	/* If we are the responder the cr bit should be set in a response */
	dm_pkt->h.addr.cr =  ((~(rfcomm->initiator)) & 0x1);
	/* The control channel is on DLCI 0, i.e. d-bit should not be set */
	dm_pkt->h.addr.d = dlci & 0x1;
	dm_pkt->h.addr.server_chn = dlci >> 0x1;
	/* In RFCOMM the F-bit should always be set when sending DM packets */
	dm_pkt->h.control = SET_PF(DM);
	/* The DM packet has length zero, and then the ea bit in the length
	   field should  be set */
	dm_pkt->h.length.ea = 1;
	dm_pkt->h.length.len = 0;
	dm_pkt->data[0] = crc_calc((u8*) dm_pkt, LONG_CRC_CHECK);

	return l2cap_send_data(tx_buf,rfcomm->l2cap);
}

s32 
send_sabm(rfcomm_con *rfcomm, u8 dlci)
{
	bt_tx_buf *tx_buf;
	short_frame *sabm_pkt;
	u32 rfcomm_frame_size;

	D_CTRL("send_sabm: Creating SABM packet to DLCI %d\n",dlci);

	rfcomm_frame_size = sizeof(short_frame) + FCS_SIZE;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);
	
	if (!tx_buf) {
		D_ERR("send_sabm : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	sabm_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
  
	/* Always one in the address field */
	sabm_pkt->h.addr.ea = 1;
	/* If we are the responder the cr bit should be set in a response */
	sabm_pkt->h.addr.cr = ((rfcomm->initiator) & 0x1);
	sabm_pkt->h.addr.d = dlci & 0x1;
	sabm_pkt->h.addr.server_chn = dlci >> 0x1;
	/* In RFCOMM the F-bit should always be set when sending SABM packets
	 */
	sabm_pkt->h.control = SET_PF(SABM);
	/* The SABM packet has length zero, and then the ea bit in the length
	   field should  be set */
	sabm_pkt->h.length.ea = 1;
	sabm_pkt->h.length.len = 0;
	sabm_pkt->data[0] = crc_calc((u8*) sabm_pkt, LONG_CRC_CHECK);
  
	return l2cap_send_data(tx_buf,rfcomm->l2cap);
}

s32 
send_disc(rfcomm_con *rfcomm, u8 dlci)
{
	bt_tx_buf *tx_buf;
	short_frame *disc_pkt;
	u32 rfcomm_frame_size;

	D_CTRL("send_disc: Creating DISC packet to DLCI %d\n",dlci);

	rfcomm_frame_size = sizeof(short_frame) + FCS_SIZE;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("send_disc : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	disc_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
  
	/* Always one in the address field */
	disc_pkt->h.addr.ea = 1;
	/* If we are the responder the cr bit should be set in a response */
	disc_pkt->h.addr.cr = ((rfcomm->initiator) & 0x1);
	disc_pkt->h.addr.d = dlci & 0x1;
	disc_pkt->h.addr.server_chn = dlci >> 0x1;
	/* In RFCOMM the F-bit should always be set when sending DISC packets
	 */
	disc_pkt->h.control = SET_PF(DISC);
	/* The DISC packet has length zero, and then the ea bit in the length
	   field should  be set */
	disc_pkt->h.length.ea = 1;
	disc_pkt->h.length.len = 0;
	disc_pkt->data[0] = crc_calc((u8*) disc_pkt, LONG_CRC_CHECK);
  
	return l2cap_send_data(tx_buf,rfcomm->l2cap);
} 


/* Creates a UIH packet and puts it at the beginning of the pkt pointer
   The funtion returns how many bytes the UIH packet consist of */

s32 
send_uih(u8 *data, u32 len, rfcomm_con *rfcomm, u8 dlci)
{
	bt_tx_buf *tx_buf;
	u32 rfcomm_frame_size;
	u8  send_credit = 0;
	s32 retval = 0;
		
	D_CTRL(FNC"Creating UIH packet with %d bytes data to DLCI %d\n",
	       len, dlci);

	if (!rfcomm->l2cap->link_up) {
		D_ERR(FNC"could not send data, baseband down\n");
#ifdef __KERNEL__
		return 0;
#else
		return -1; /* FIXME - see comment in rfcomm_send_data */
#endif
	}

	if (rfcomm->credit_flow &&(rfcomm->dlci[dlci].remote_credits < MIN_CREDITS)) {
			D_SND(FNC"Sending more credits to remote port\n");
			send_credit = 1;
		}
	
	if (len > SHORT_PAYLOAD_SIZE) {
		long_frame *l_pkt;
    
		rfcomm_frame_size = sizeof(long_frame) + len + FCS_SIZE + send_credit;

		/* Check for space in buffer, don't forget the size of the
		   L2CAP and HCI headers */
		if (buf_write_room() < (rfcomm_frame_size
					+ sizeof(rfcomm_tx_buf))) {
			return 0;
		}

		tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf)
					  + rfcomm_frame_size);    
		if (!tx_buf) {
			D_ERR(FNC"didn't get a valid tx_buf\n");
			return -ENOMEM;
		}
		tx_buf->cur_len = rfcomm_frame_size;
    
		l_pkt = (long_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
		set_uih_hdr((void*) l_pkt, dlci, len, rfcomm->initiator);
		if (send_credit) {
			u8 newcredits = MAX_CREDITS - rfcomm->dlci[dlci].remote_credits;
			l_pkt->h.control = SET_PF(UIH);
			l_pkt->data[0] = (newcredits);
			rfcomm->dlci[dlci].remote_credits += newcredits;
			D_SND(FNC": Remote credits: %d\n",rfcomm->dlci[dlci].remote_credits);
			memcpy(l_pkt->data + 1, data, len);
		} else {
			memcpy(l_pkt->data, data, len);
		}
		l_pkt->data[len + send_credit] = crc_calc((u8*) l_pkt, SHORT_CRC_CHECK);
		swap_long_frame(l_pkt);
	} else {
		short_frame *s_pkt;

		rfcomm_frame_size = sizeof(short_frame) + len + FCS_SIZE + send_credit;
		/* Check for space in buffer, don't forget the size of the
		   L2CAP and HCI headers */
		if (buf_write_room() < (rfcomm_frame_size
					+ sizeof(rfcomm_tx_buf))) {
			return 0;
		}
		tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf)
					  + rfcomm_frame_size);
		if (!tx_buf) {
			D_ERR(FNC"didn't get a valid tx_buf\n");
			return -ENOMEM;
		}
		tx_buf->cur_len = rfcomm_frame_size;
    
		s_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
		/* Always one */
		set_uih_hdr((void*) s_pkt, dlci, len, rfcomm->initiator);
		if (send_credit) {
			u8 newcredits = MAX_CREDITS - rfcomm->dlci[dlci].remote_credits;
			
			s_pkt->h.control = SET_PF(UIH);
			s_pkt->data[0] = (newcredits);
			rfcomm->dlci[dlci].remote_credits += newcredits;
			D_SND(FNC": Remote credits: %d\n",rfcomm->dlci[dlci].remote_credits);
			memcpy(s_pkt->data + 1, data, len);
		} else {
			memcpy(s_pkt->data, data, len);
		}
		s_pkt->data[len + send_credit] = crc_calc((u8*) s_pkt, SHORT_CRC_CHECK);
	}

	/* FIXME - How should we propagate result up to higher layers ?
	   through len or success/no success? */
	tx_buf->line = rfcomm->line;
	if((retval = l2cap_send_data(tx_buf, rfcomm->l2cap)) < 0) {
		return retval;
	}
	
	return len;
}

s32
rfcomm_send_credits(rfcomm_con *rfcomm, u8 dlci, u8 credits)
{
	bt_tx_buf *tx_buf;
	short_frame *uih_pkt;
	u32 rfcomm_frame_size;
  
	D_CTRL(FNC"give %d credits to dlci %d\n", credits, dlci);

	rfcomm_frame_size = (sizeof(short_frame) + 1 + FCS_SIZE);
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("rfcomm_fcon_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	uih_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
	set_uih_hdr(uih_pkt, dlci, 0, (~rfcomm->initiator)^1);
	uih_pkt->h.control = SET_PF(UIH);

	uih_pkt->data[0] = credits;
	uih_pkt->data[1] = crc_calc((u8*) uih_pkt, SHORT_CRC_CHECK);
	
	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}


/* Sends Multiplexer command packets funktions */

/* Sends a test messages with a specific test pattern. */

s32 
rfcomm_test_msg(rfcomm_con *rfcomm, u8 *test_pattern, u32 len, u8 cr)
{
	bt_tx_buf *tx_buf;
	u32 rfcomm_frame_size;
   
	if (len > SHORT_PAYLOAD_SIZE) {
		long_frame *uih_pkt;
		mcc_long_frame *mcc_pkt;
    
		/* Create long uih packet and long mcc packet */
		rfcomm_frame_size = (sizeof(long_frame)
				     + sizeof(mcc_long_frame) + len +FCS_SIZE);
		tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf)
					  + rfcomm_frame_size);
		if (!tx_buf) {
			D_ERR("rfcomm_test_msg : didn't get a valid tx_buf\n");
			return -ENOMEM;
		}
		tx_buf->cur_len = rfcomm_frame_size;
		uih_pkt = (long_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
    
		set_uih_hdr((short_frame*) uih_pkt, CTRL_CHAN, len + 
			    sizeof(mcc_long_frame), rfcomm->initiator);
		uih_pkt->data[uih_pkt->h.length.bits.len] = crc_calc((u8*) uih_pkt, 
								SHORT_CRC_CHECK);
		mcc_pkt = (mcc_long_frame*) uih_pkt->data;

		/* Always one in the TEST messages */
		mcc_pkt->h.type.ea = EA;
		/* cr tells whether it is a commmand (1) or a response (0) */
		mcc_pkt->h.type.cr = cr;
		mcc_pkt->h.type.type = TEST;
		mcc_pkt->h.length.bits.ea = EA;
		mcc_pkt->h.length.bits.len = len;
		swap_long_frame(uih_pkt);
		swap_mcc_long_frame(mcc_pkt);
		memcpy(mcc_pkt->value,test_pattern,len);
	} else if (len > (SHORT_PAYLOAD_SIZE-sizeof(mcc_short_frame))) {
		long_frame *uih_pkt;
		mcc_short_frame *mcc_pkt;
    
		/* Create long uih packet and short mcc packet */
		rfcomm_frame_size = (sizeof(long_frame)
				     + sizeof(mcc_short_frame) + len+FCS_SIZE);
		tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf)
					  + rfcomm_frame_size);
		if (!tx_buf) {
			D_ERR("rfcomm_test_msg : didn't get a valid tx_buf\n");
			return -ENOMEM;
		}
		
		tx_buf->cur_len = rfcomm_frame_size;

		uih_pkt = (long_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
    
		set_uih_hdr((short_frame*) uih_pkt, CTRL_CHAN, len +
			    sizeof(mcc_short_frame), rfcomm->initiator);
		uih_pkt->data[uih_pkt->h.length.bits.len] = crc_calc((u8*) uih_pkt, 
								SHORT_CRC_CHECK);
		mcc_pkt = (mcc_short_frame*) uih_pkt->data;

		/* Always one in the TEST messages */
		mcc_pkt->h.type.ea = EA;
		/* cr tells whether it is a commmand (1) or a response (0) */
		mcc_pkt->h.type.cr = cr;
		mcc_pkt->h.type.type = TEST;
		mcc_pkt->h.length.ea = EA;
		mcc_pkt->h. length.len = len;
		swap_long_frame(uih_pkt);
		memcpy(mcc_pkt->value,test_pattern,len);
	} else {
		short_frame *uih_pkt;
		mcc_short_frame *mcc_pkt;

		/* Creat short uih packet and short mcc packet */
		rfcomm_frame_size = (sizeof(short_frame)
				     + sizeof(mcc_short_frame) + len+FCS_SIZE);
		tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf)
					  + rfcomm_frame_size);
		if (!tx_buf) {
			D_ERR("rfcomm_test_msg : didn't get a valid tx_buf\n");
			return -ENOMEM;
		}
		
		tx_buf->cur_len = rfcomm_frame_size;
    
		uih_pkt = (short_frame*) (tx_buf->data +sizeof(rfcomm_tx_buf));
    
		set_uih_hdr((void*) uih_pkt, CTRL_CHAN, len
			    + sizeof(mcc_short_frame), rfcomm->initiator);
		uih_pkt->data[uih_pkt->h.length.len] = crc_calc((u8*) uih_pkt, 
								SHORT_CRC_CHECK);
		mcc_pkt = (mcc_short_frame*) uih_pkt->data;
    
		/* Always one in the TEST messages */
		mcc_pkt->h.type.ea = EA;
		/* cr tells whether it is a commmand (1) or a response (0) */
		mcc_pkt->h.type.cr = cr;
		mcc_pkt->h.type.type = TEST;
		mcc_pkt->h.length.ea = EA;
		mcc_pkt->h. length.len = len;
		memcpy(mcc_pkt->value,test_pattern,len);
    
	}
	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}

/* Turns on the RFCOMM flow control */

s32 
rfcomm_fcon_msg(rfcomm_con *rfcomm, u8 cr)
{
	bt_tx_buf *tx_buf;
	short_frame *uih_pkt;
	mcc_short_frame *mcc_pkt;
	u32 rfcomm_frame_size;
  
	rfcomm_frame_size = (sizeof(short_frame) + sizeof(mcc_short_frame)
			     + FCS_SIZE);
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("rfcomm_fcon_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	uih_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
	set_uih_hdr(uih_pkt, CTRL_CHAN, sizeof(mcc_short_frame),
		    rfcomm->initiator);
	uih_pkt->data[sizeof(mcc_short_frame)] = crc_calc((u8*) uih_pkt, 
							  SHORT_CRC_CHECK);
	mcc_pkt = (mcc_short_frame*) (uih_pkt->data);
  
	mcc_pkt->h.type.ea = EA;
	mcc_pkt->h.type.cr = cr;
	mcc_pkt->h.type.type = FCON;
	mcc_pkt->h.length.ea = EA;
	mcc_pkt->h.length.len = 0;
  
	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}

/* Turns off the RFCOMM flow control */

s32 
rfcomm_fcoff_msg(rfcomm_con *rfcomm, u8 cr)
{
	bt_tx_buf *tx_buf;
	short_frame *uih_pkt;
	mcc_short_frame *mcc_pkt;
	u32 rfcomm_frame_size;
  
	rfcomm_frame_size = (sizeof(short_frame) + sizeof(mcc_short_frame)
			     + FCS_SIZE);
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("rfcomm_fcoff_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	uih_pkt = (short_frame*) (tx_buf->data + sizeof(rfcomm_tx_buf));
	set_uih_hdr(uih_pkt, CTRL_CHAN, sizeof(mcc_short_frame),
		    rfcomm->initiator);
	uih_pkt->data[sizeof(mcc_short_frame)] = crc_calc((u8*) uih_pkt, 
							  SHORT_CRC_CHECK);
	mcc_pkt = (mcc_short_frame*) (uih_pkt->data);

	mcc_pkt->h.type.ea = 1;
	mcc_pkt->h.type.cr = cr;
	mcc_pkt->h.type.type = FCOFF;
	mcc_pkt->h.length.ea = 1;
	mcc_pkt->h.length.len = 0;

	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}

s32 rfcomm_rpn_msg(rfcomm_con *rfcomm, u8 cr, u8 dlci, u8 req)
{
	bt_tx_buf *tx_buf;
	rpn_msg* rpn_pkt;
	u32 rfcomm_frame_size;
	u32 rfcomm_payload_size;

	rfcomm_frame_size = sizeof(rpn_msg);

	if (req) {
		rfcomm_frame_size -= sizeof(rpn_values);
	}
	
	rfcomm_payload_size = (rfcomm_frame_size - sizeof(short_frame)
			       - FCS_SIZE);
	
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("rfcomm_rpn_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	rpn_pkt = (rpn_msg*) (tx_buf->data + sizeof(rfcomm_tx_buf));
  
	set_uih_hdr((short_frame*) rpn_pkt, CTRL_CHAN, rfcomm_payload_size,
		    rfcomm->initiator);

	rpn_pkt->fcs = crc_calc((u8*) rpn_pkt, SHORT_CRC_CHECK);

	rpn_pkt->mcc_s_head.type.ea = EA;
	rpn_pkt->mcc_s_head.type.cr = cr;
	rpn_pkt->mcc_s_head.type.type = RPN;
	rpn_pkt->mcc_s_head.length.ea = EA;

	rpn_pkt->dlci.ea = EA;
	rpn_pkt->dlci.cr = 1; /* Fixed value */
	rpn_pkt->dlci.d = dlci & 1;
	rpn_pkt->dlci.server_chn = (dlci >> 1);
	
	if (req) {
		rpn_pkt->mcc_s_head.length.len = 1;
		/* Fix, since the packet is ends here when it is a request */
		rpn_pkt->rpn_val.bit_rate = rpn_pkt->fcs;
		return l2cap_send_data(tx_buf, rfcomm->l2cap);
	} else {
		rpn_pkt->mcc_s_head.length.len = 8;
		memcpy(&(rpn_pkt->rpn_val), &rpn_val, sizeof(rpn_values));
		//print_data("",(u8*) rpn_pkt, rfcomm_frame_size);
		return l2cap_send_data(tx_buf, rfcomm->l2cap);
	}
}

s32 
rfcomm_rls_msg(rfcomm_con *rfcomm, u8 cr, u8 dlci, u8 err_code)
{
	bt_tx_buf *tx_buf;
	rls_msg* rls_pkt;
	u32 rfcomm_frame_size;
	u32 rfcomm_payload_size;

	rfcomm_frame_size = sizeof(rls_msg);
	rfcomm_payload_size = rfcomm_frame_size - sizeof(short_frame)-FCS_SIZE;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("rfcomm_rls_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
  
	rls_pkt = (rls_msg*) (tx_buf->data + sizeof(rfcomm_tx_buf));
  
	set_uih_hdr((short_frame*) rls_pkt, CTRL_CHAN, rfcomm_payload_size,
		    rfcomm->initiator);
	rls_pkt->fcs = crc_calc((u8*) rls_pkt, SHORT_CRC_CHECK);
  
	rls_pkt->mcc_s_head.type.ea = EA;
	rls_pkt->mcc_s_head.type.cr = cr;
	rls_pkt->mcc_s_head.type.type = RLS;
	rls_pkt->mcc_s_head.length.ea = EA;
	rls_pkt->mcc_s_head.length.len = 2;
  
	rls_pkt->dlci.ea = EA;
	rls_pkt->dlci.cr = 1; /* Fixed value */
	rls_pkt->dlci.d = dlci & 1;
	rls_pkt->dlci.server_chn = dlci >> 1;
	rls_pkt->error = err_code;
	rls_pkt->res = 0;
  
	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}
/* Sends an PN-messages and sets the not negotiable parameters to their
   default values in RFCOMM */

s32 
send_pn_msg(rfcomm_con *rfcomm, u8 prior, u32 frame_size, u8 credit_flow, u8 credits, u8 dlci, u8 cr)
{
	bt_tx_buf *tx_buf;
	pn_msg *pn_pkt;
	u32 rfcomm_frame_size;
	D_CTRL("send_pn_msg: DLCI 0x%02x, prior:0x%02x, frame_size:%d, credit_flow:%x, credits:%d, cr:%x\n",
	      dlci, prior, frame_size, credit_flow, credits, cr);

	rfcomm_frame_size = sizeof *pn_pkt;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("send_pn_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;

	pn_pkt = (pn_msg*) (tx_buf->data + sizeof(rfcomm_tx_buf));
	/* Set the UIH headers */
	set_uih_hdr((void*) pn_pkt, CTRL_CHAN, rfcomm_frame_size - 
		    (sizeof(short_frame) + FCS_SIZE), rfcomm->initiator);
	pn_pkt->fcs = crc_calc((u8*) pn_pkt, SHORT_CRC_CHECK);

	/* set the MCC-packet header */
	pn_pkt->mcc_s_head.type.ea = 1;
	pn_pkt->mcc_s_head.type.cr = cr;
	pn_pkt->mcc_s_head.type.type = PN;
	pn_pkt->mcc_s_head.length.ea = 1;
	/* The PN packet has a fix length of 8 bytes */
	pn_pkt->mcc_s_head.length.len = 8;

	/* Set the parameters in the PN-packet */
	pn_pkt->res1 = 0;
	pn_pkt->res2 = 0;
	pn_pkt->dlci = dlci;
	pn_pkt->frame_type = 0;
	pn_pkt->credit_flow = credit_flow;
	pn_pkt->prior = prior;
	pn_pkt->ack_timer = 0;
	put_unaligned(cpu_to_le16(frame_size), &pn_pkt->frame_size);
	pn_pkt->credits = credits;
	pn_pkt->max_nbrof_retrans = 0;
  
	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}

/* Sendares a Not supported command - command, which needs 3 bytes */

s32 
send_nsc_msg(rfcomm_con *rfcomm, mcc_type cmd, u8 cr) 
{
	bt_tx_buf *tx_buf;
	nsc_msg *nsc_pkt;
	u32 rfcomm_frame_size;
  
	rfcomm_frame_size = sizeof(nsc_msg);
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR("send_nsc_msg : didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;
	
	nsc_pkt = (nsc_msg*) (tx_buf->data + sizeof(rfcomm_tx_buf));
 
	set_uih_hdr((void*) nsc_pkt, CTRL_CHAN, sizeof(nsc_msg)
		    - sizeof(short_frame) - FCS_SIZE, rfcomm->initiator);

	nsc_pkt->fcs = crc_calc((u8*) nsc_pkt, SHORT_CRC_CHECK);

	nsc_pkt->mcc_s_head.type.ea = 1;
	nsc_pkt->mcc_s_head.type.cr = cr;
	nsc_pkt->mcc_s_head.type.type = NSC;
	nsc_pkt->mcc_s_head.length.ea = 1;
	nsc_pkt->mcc_s_head.length.len = 1;

	nsc_pkt->command_type.ea = 1;
	nsc_pkt->command_type.cr = cmd.cr;
	nsc_pkt->command_type.type = cmd.type;

	return l2cap_send_data(tx_buf, rfcomm->l2cap);
}

s32 rfcomm_msc_msg(rfcomm_con *rfcomm, u8 value, u8 cr, u8 dlci)
{
	bt_tx_buf *tx_buf;
	msc_msg *msc_pkt;
	u32 rfcomm_frame_size;
  
	D_CTRL(FNC"val:%d, cr:%d, dlci:%d\n", value, cr, dlci);

	rfcomm_frame_size = sizeof(msc_msg);
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR(FNC"didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;

	msc_pkt = (msc_msg*) (tx_buf->data + sizeof(rfcomm_tx_buf));
 
	set_uih_hdr((void*) msc_pkt, CTRL_CHAN, sizeof(msc_msg)
		    - sizeof(short_frame) - FCS_SIZE, rfcomm->initiator);

	msc_pkt->fcs = crc_calc((u8*) msc_pkt, SHORT_CRC_CHECK);

	msc_pkt->mcc_s_head.type.ea = 1;
	msc_pkt->mcc_s_head.type.cr = cr;
	msc_pkt->mcc_s_head.type.type = MSC;
	msc_pkt->mcc_s_head.length.ea = 1;
	msc_pkt->mcc_s_head.length.len = 2;

	msc_pkt->dlci.ea = 1;
	msc_pkt->dlci.cr = 1;
	msc_pkt->dlci.d = dlci & 1;
	msc_pkt->dlci.server_chn = (dlci >> 1) & 0x1f;

	msc_pkt->v24_sigs = value;
return l2cap_send_data(tx_buf, rfcomm->l2cap);
}

void
set_uih_hdr(short_frame *uih_pkt, u8 dlci, u32 len, u8 cr)
{
	uih_pkt->h.addr.ea = 1;
	uih_pkt->h.addr.cr = cr;
	uih_pkt->h.addr.d = dlci & 0x1;
	uih_pkt->h.addr.server_chn = dlci >> 1;
	uih_pkt->h.control = CLR_PF(UIH);
	
	if (len > SHORT_PAYLOAD_SIZE) {
		((long_frame*) uih_pkt)->h.length.bits.ea = 0;
		((long_frame*) uih_pkt)->h.length.bits.len = len;  
	} else {
		uih_pkt->h.length.ea = 1;
		uih_pkt->h.length.len = len;  
	}

}


rfcomm_con* 
get_new_rfcomm_con(void)
{
	s32 i = 0;

	D_CTRL(FNC"rfcomm_con -> ttyBT%d\n",i);

        for (i = 0 ; i < BT_NBR_DATAPORTS ; i ++)
        {
           if (rfcomm_con_list[i].dlci[0].state == DISCONNECTED)
           {
              rfcomm_con_list[i].l2cap = NULL;
              return &rfcomm_con_list[i];
           }
        }
        return NULL;
}

rfcomm_con* 
get_rfcomm_con(u8 line)
{
	if(line >= BT_NBR_DATAPORTS) {
		return NULL;
	}
	return &rfcomm_con_list[line];
}

s32
valid_dlci(u8 dlci)
{
	if ((dlci < 62) && (dlci > 1)) {
		return TRUE;
	} else {
		return FALSE;
	}
}

/* fetches the 'last' non DISCONNECTED dlci number in this session, 
   returns -1 if no connected dlci was found */

s32 get_connected_dlci(rfcomm_con *rfcomm)
{
	s32 tmp;

	tmp = 61;
	while ((tmp >= 0) && (rfcomm != NULL) && 
	       (rfcomm->dlci[tmp].state == DISCONNECTED)) {
		tmp--;
	}
	return tmp;
}

/* Functions for the crc-check and calculation */

#define CRC_VALID 0xcf

/* This functions check whether the checksum is correct or not. Length is
   the number of bytes in the message, data points to the beginning of the
   message */

u32 
crc_check(u8 *data, u32 length, u8 check_sum)
{
	u8 fcs = 0xff;

	RF_DATA(FNC, data, length);
	while (length--) {
		fcs = crctable[fcs ^ *data++];
	}
	fcs = crctable[fcs ^ check_sum];
	D_REC(FNC"fcs : %d\n", fcs);
	if (fcs == (uint) 0xcf) /* CRC_VALID) */ {
		D_REC(FNC"CRC check OK\n");
		return 0;
	} else {
		D_WARN(FNC"CRC check failed, data will be discarded\n");
		return -1;
	}
}

/* Calculates the checksum according to the RFCOMM specification */

u8 
crc_calc(u8 *data, u32 length)
{
	u8 fcs = 0xff;
  
	while (length--) {
		fcs = crctable[fcs^*data++];
	}
  
	/*Ones complement*/
	return 0xff-fcs;
}

/* Calculates a reversed CRC table for the FCS check */

void
create_crctable(u8 table[])
{
	s32 i,j;
  
	u8 data;
	u8 code_word = (u8) 0xe0;  /* pol = x8+x2+x1+1 */
	u8 sr = (u8) 0;            /* Shiftregister initiated to zero */

	for (j = 0; j < 256; j++) {
		data = (u8) j;
    
		for (i = 0; i < 8; i++) {
			if ((data & 0x1)^(sr & 0x1)) {
				sr >>= 1;
				sr ^= code_word;
			} else {
				sr >>= 1;
			}
      
			data >>= 1;
			sr &= 0xff;
		}
    
		table[j] = sr;
		sr = 0;
	} 
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* /proc file functions */



s32 rfcomm_sprint_con(u8 *buf)
{
	s32 i, j;
	s32 len=0;

	for (i = 0; i < BT_NBR_DATAPORTS; i++) {

		/* FIXME - move mtu etc into each dlci port, 
		   should not be in 'line' struct */
		
		for (j = 0; j < 62; j++){	
			if (rfcomm_con_list[i].dlci[j].state != DISCONNECTED){
				
				len+=sprintf(buf+len, "line[%d] mtu[%d] ",
					     rfcomm_con_list[i].line, 
					     rfcomm_con_list[i].dlci[j].mtu);
				
				len+=sprintf(buf+len, "dlci#%d state[%s]\n", 
					     j, state2name(rfcomm_con_list[i].dlci[j].state));
			}
		}
	}
	return len;
}


s32 rfcomm_sprint_status(u8 *buf)
{
	s32 len=0;
	len+=sprintf(buf+len, "\n[RFCOMM]\n\n");
	len+=rfcomm_sprint_con(buf+len);
	return len;
}


s32
rfcomm_crap_msg(rfcomm_con *rfcomm)
{
	bt_tx_buf *tx_buf;
	u8 *data;	
	u32 rfcomm_frame_size;
  
	rfcomm_frame_size = 6;
	tx_buf = subscribe_bt_buf(sizeof(rfcomm_tx_buf) + rfcomm_frame_size);

	if (!tx_buf) {
		D_ERR(FNC"didn't get a valid tx_buf\n");
		return -ENOMEM;
	}

	tx_buf->cur_len = rfcomm_frame_size;

	data = (u8*) (tx_buf->data + sizeof(rfcomm_tx_buf));

	data[0] = 0x03;
	data[1] = 0xef;
	data[2] = 0x05;
	data[3] = 0xd3;
	data[4] = 0x01;
	data[5] = 0x70;

	return l2cap_send_data(tx_buf, rfcomm->l2cap);
  
}

s32
rfcomm_sabm_msg(rfcomm_con *rfcomm, u8 dlci)
{
	return send_sabm(rfcomm, dlci);
}

s32
rfcomm_pn_msg(rfcomm_con *rfcomm, u8 dlci, u8 credits, u32 frame_size)
{
	if (credits) {
		DSYS(FNC"using %d credits\n", credits);
		return send_pn_msg(rfcomm, 0, frame_size, 0xf, credits, dlci,
				   TRUE);
	} else {
		return send_pn_msg(rfcomm, 0, frame_size, 0, 0, dlci, TRUE);
	}
	
}

s32
rfcomm_ua_msg(rfcomm_con *rfcomm, u8 dlci)
{
	return send_ua(rfcomm, dlci);
}

s32
rfcomm_dm_msg(rfcomm_con *rfcomm, u8 dlci)
{
	return send_dm(rfcomm, dlci);
}

s32
rfcomm_disc_msg(rfcomm_con *rfcomm, u8 dlci)
{
	return send_disc(rfcomm, dlci);
}

/****************** END OF FILE rfcomm.c ************************************/
