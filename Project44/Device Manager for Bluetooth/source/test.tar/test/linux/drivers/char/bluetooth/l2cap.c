
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/config.h>
#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/malloc.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/hci_internal.h>
#include <linux/bluetooth/rfcomm.h>
#include <linux/bluetooth/sdp.h>
#include <linux/bluetooth/test.h>
#include <linux/bluetooth/btmem.h>
#include <linux/bluetooth/l2cap_internal.h>
#include <linux/bluetooth/l2cap_con.h>
#include <linux/bluetooth/l2cap_sec.h>
#include <linux/bluetooth/bt_errno.h>
#include <asm/byteorder.h>
#include <asm/unaligned.h>
#else /* user mode */
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <signal.h>
#include <errno.h>
#include <asm/unaligned.h>

#include "include/l2cap.h"
#include "include/hci.h"
#include "include/hci_internal.h"
#include "include/l2cap_internal.h"
#include "include/l2cap_con.h"
#include "include/l2cap_sec.h"
#include "include/rfcomm.h"
#include "include/sdp.h"
#include "include/test.h"
#include "include/btmem.h"
#include "include/local.h"
#include "include/bt_errno.h"
#endif

/****************** DEBUG CONSTANT AND MACRO SECTION ************************/

#if L2CAP_DEBUG_STATE
/* State machine */
#define D_STATE(fmt...) printk(L2CAP_DBG_STR fmt)
#define PRINTSTATE(con) (printk(L2CAP_DBG_STR "Current state of (%d:%d) is %s\n", con->local_cid, con->remote_cid, state_name[con->current_state]))
#else
/* State machine */
#define D_STATE(fmt...)
#define PRINTSTATE(con)
#endif

#if L2CAP_DEBUG_TIMER
#define D_TIM(fmt...) printk(L2CAP_DBG_STR fmt)
#else
#define D_TIM(fmt...)
#endif

#if L2CAP_DEBUG_CON
/* Connection manager */
#define D_CON(fmt...) printk(L2CAP_DBG_STR fmt)

#define SHOW_CON(str, con) show_con(str, con)
#define SHOW_LIST() show_list()
#else
#define D_CON(fmt...)
#define SHOW_CON(str, con)
#define SHOW_LIST()
#endif

#if L2CAP_DEBUG_RCV
/* Receive data */
#define D_RCV(fmt...) printk(L2CAP_DBG_STR fmt)
#else
#define D_RCV(fmt...)
#endif

#if L2CAP_DEBUG_XMIT
/* Send data */
#define D_XMIT(fmt...) printk(L2CAP_DBG_STR fmt)
#else
#define D_XMIT(fmt...)
#endif

#if L2CAP_DEBUG_MISC
/* Misc */
#define D_MISC(fmt...) printk(L2CAP_DBG_STR fmt)
#else
#define D_MISC(fmt...)
#endif

#if L2CAP_DEBUG_DATA
#define PRINTPKT(str, data, len) print_data(str, data, len)
#else
#define PRINTPKT(str, data, len)
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#define CON_LESS 0
#define CON_ORIENTED 1

#define MIN_CID 0x0040
#define MAX_CID 0xffff

/* EVEN => REQUEST */ 
#define ISREQUEST(x) (!(x%2))
#define SET_L2CAP_HDR(frame, len, cid) {\
        (*(u8 *)(frame)) = (u8)(((len) & 0xff)); \
        (*(u8 *)(frame + 1)) = (u8)((len) >> 8); \
        (*(u8 *)(frame + 2)) = (u8)(((cid) & 0xff)); \
        (*(u8 *)(frame + 3)) = (u8)((cid) >> 8); \
}

#define ENTERSTATE(con, state) (con->current_state = state)

#define RCID_NOT_SET 0
#define RCID_SET 1

#define CMDREJ_NOTUNDERSTOOD 0x0
#define CMDREJ_MTUEXCEEDED 0x1
#define CMDREJ_INVALIDCID 0x2

#define CONFREQ_NO_OPTIONS 0x11

const u8* psm2str(u16 psm)
{
	switch (psm) {
	case 1:
		return "SDP";
		break;

	case 3:
		return "RFCOMM";
		break;

	case 5:
		return "TCS";
		break;

	case 0x1231:
		return "TEST";
		break;

	case 0x1233:
		return "TEST-2";
		break;

	case 0x4561:
		return "TEST-3";
		break;

	default :
		return "unknown";
	}
}

const u8* cmdrej_reason[] = {
	"Command not understood",
	"Signalling MTU exceeded",
	"Invalid CID in request",
};

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

/* MISC */
static u8 set_id(l2cap_con* con);
static u8 get_id(void);
static s32 id_matched(l2cap_con* con, u8 rcv_id);

static s32 parse_options(l2cap_con* con, u8 *data, u32 len);
static void print_flow(flow *f);
static s32 l2cap_cmdrej(s32 hci_hdl, u8 reason, u8 *opt_data, s32 opt_len);

static s32 insert_upper(protocol_layer *upper_layer);
static protocol_layer* get_upper(u32 psm);
static void remove_all_upper(void);

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS

/* fixme -- calculate this using flush timeout */
#define MAX_NO_RTX 3
#define RTX_TIMEOUT 2 /* sec */
#define ERTX_TIMEOUT 60 /* sec */


#ifdef __KERNEL__
static void l2cap_rtx_timeout(unsigned long ptr);
static void l2cap_ertx_timeout(unsigned long ptr);
#else /* usermode stack */
static l2cap_con *timeout_con = NULL;
static s32 timer_cancelled = 0;
static void l2cap_rtx_timeout(void);
static void l2cap_ertx_timeout(unsigned long ptr);
#endif

static void start_rtx(l2cap_con *con, unsigned short timeout, unsigned short action);
static void disable_rtx(l2cap_con *con);

static void start_ertx(l2cap_con *con, unsigned short timeout);
static void disable_ertx(l2cap_con *con);

#endif

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

static l2cap_layer l2capmain; /* Main structure */
static l2cap_layer* l2cap;
static struct protocol_layer default_protocol;
extern int bt_max_connections;
extern hci_controller hci_ctrl;

/****************** FUNCTION DEFINITION SECTION *****************************/
  
/*********************************************************************/
/*---------------------- INIT AND SHUTDOWN --------------------------*/
/*********************************************************************/

s32
l2cap_init(void)
{
	s32 i;
	u8 bd_name[20];
	DSYS("Initialising L2CAP\n");
	l2cap = &l2capmain;
	init_con_list();
        l2cap->cid_count = MIN_CID; /* Moved from init_con_list */

	/* Set all upper layers to default */

	l2cap_protocol_default(&default_protocol);
	
	l2cap->id_count = 1;
	l2cap->mtu = MTU_DEFAULT ;
	l2cap->flush_timeout = FLUSHTIMEOUT_DEFAULT; /* Always retransmit */
	l2cap->upper_layers = NULL;
	init_flow(&l2cap->qos);

	/* get local bd address */
	hci_read_local_bd(l2cap->my_bd);

	/* check result... */
	if (!l2cap->my_bd[0] && !l2cap->my_bd[1] && !l2cap->my_bd[2] &&
	    !l2cap->my_bd[3] && !l2cap->my_bd[4] && !l2cap->my_bd[5])
		D_ERR(__FUNCTION__ ": Failed to get local BD addr\n");
	else {
		i = l2cap_sprint_bd(bd_name, l2cap->my_bd);
		bd_name[i] = 0;
		DSYS("Local bd [%s]\n", bd_name);
	}

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
        /* Initialize security */
        l2cap_sec_man_init();
#endif
        
#if L2CAP_SELFTEST
	test_conlist();
#endif
#ifdef CONFIG_BLUETOOTH_L2CAP_CONNECTIONLESS
	l2cap->allow_conless = 1;
#else
	l2cap->allow_conless = 0;
#endif
	l2cap->initiated = 1;
	return 0;
}

void 
l2cap_protocol_default(struct protocol_layer *prot)
{
	prot->psm = 0;
	prot->con_pnd = not_registered_cfm;
	prot->con_cfm = not_registered_cfm;
	prot->conf_cfm = not_registered_cfm;
	prot->disc_cfm = not_registered_cfm_noparams;

	prot->con_ind = not_registered_ind;
	prot->conf_ind = not_registered_ind;
	prot->disc_ind = not_registered_ind;

	prot->receive_data = not_registered_rcv;
	prot->next_layer = NULL;
}

void 
l2cap_register_default_upper(struct protocol_layer *prot)
{
	memcpy(&default_protocol, prot, sizeof default_protocol);
}

s32 
l2cap_shutdown(void)
{
	DSYS("Shutting down L2CAP\n");
	if (!l2cap->initiated) {
		D_ERR(__FUNCTION__ ": L2CAP not initiated\n");
		return -1;
	}
	
	/* fixme -- experimental */
#if 0
	{
		l2cap_con *con;
		con = get_first_con();
		while (con != NULL) {
			if (l2ca_disconnect_req(con) != 0)
				break;
			con = get_first_con();
		}
	}
#endif

	free_con_list();
	remove_all_upper();

	/* ALWAYS SUCCESS */
	return 0;
}

/* is called with a struct of functions to handle incoming data */


s32 
l2cap_register_upper(u16 psm, struct protocol_layer *prot) 
{
        if (((psm % 2) == 0) || (prot == NULL)) {
		D_ERR(__FUNCTION__ ": incorrect parameters\n");
		return -EINVAL;
        }
    
	D_MISC(__FUNCTION__ ": psm 0x%x\n", psm);

        if ((psm > MAX_PSM) && (psm < MIN_DYNAMIC_PSM)) {
		D_ERR(__FUNCTION__ ": value of psm reserved\n");
		return -EINVAL;
        }

        if (psm > MAX_DYNAMIC_PSM) {
		D_ERR(__FUNCTION__ ": psm not valid!\n");
		return -EINVAL;
        }

	prot->psm = psm;
	return insert_upper(prot);
}

/* Inserts the function pointers to a new upper layer in the list */

s32
insert_upper(protocol_layer *upper_layer)
{
	protocol_layer *new_layer;
	D_MISC(__FUNCTION__ ": Inserting layer psm:0x%x\n", upper_layer->psm);

	if (!(new_layer = kmalloc(sizeof *new_layer, GFP_ATOMIC)))
		return -ENOMEM;

	memcpy(new_layer, upper_layer, sizeof *new_layer);

	/* Add to head of list of upper layers */
	new_layer->next_layer = l2cap->upper_layers;
	l2cap->upper_layers = new_layer;

	return 0;
}
 
protocol_layer*
get_upper(u32 psm)
{
	protocol_layer *tmp_layer;
	
	/* Check PSM value */
        if((psm % 2) == 0) {
		D_ERR(__FUNCTION__ ": incorrect psm\n");
		return &default_protocol;
        }
        if((psm > MAX_PSM) && (psm < MIN_DYNAMIC_PSM)) {
		D_ERR(__FUNCTION__ ": value of psm reserved\n");
		return &default_protocol;
        }
        if(psm > MAX_DYNAMIC_PSM) {
		D_ERR(__FUNCTION__ ": psm not valid!\n");
		return &default_protocol;
        }

	D_MISC(__FUNCTION__ ": Try to retrieve psm 0x%x\n",psm);
	tmp_layer = l2cap->upper_layers;
	while (tmp_layer != NULL) {
		if (tmp_layer->psm == psm) {
			D_MISC(__FUNCTION__ ": Actually got psm:0x%x\n",
			       tmp_layer->psm);
			return tmp_layer;
		}
		tmp_layer = tmp_layer->next_layer;
	}
	D_MISC(__FUNCTION__ ": Didn't get any layer, returning default\n");
	return &default_protocol;
}

void
remove_all_upper(void)
{
	protocol_layer *tmp_layer;

	D_MISC(__FUNCTION__ ": Freeing all upper layers\n");

	while (l2cap->upper_layers != NULL) {
		tmp_layer = l2cap->upper_layers;
		l2cap->upper_layers = tmp_layer->next_layer;
		kfree(tmp_layer);
	}
}

/* needed ? */
void 
not_registered_cfm(l2cap_con *con, s32 result)
{
	DSYS("No upper layer confirm function defined (psm:0x%x)\n", con->psm);
	DSYS("silent discard...\n");
}

void 
not_registered_cfm_noparams(l2cap_con *con)
{
	DSYS("No upper layer confirm function defined (psm:0x%x)\n", con->psm);
	DSYS("silent discard...\n");
}

void 
not_registered_ind(l2cap_con *con)
{
	DSYS("No upper layer ind function defined (psm:0x%x)\n", con->psm);
	DSYS("silent discard...\n");
}

void 
not_registered_rcv(l2cap_con *con, u8 *data, u32 len)
{
	DSYS("No upper layer receive_data function defined (psm:0x%x)\n", 
	     con->psm);
	DSYS("silent discard...\n");
}

/****************************************************************/
/*---------------------- STATE MACHINE -------------------------*/
/****************************************************************/



/* If l2cap_len is 0 then we know we have a new frame. Parse the length field
   and set l2cap_len and compare len to this value each time new data arrives.
   When equal a whole frame is received and we can parse it */  

void 
l2cap_receive_data(u8 *data,  u32 len, u16 hci_handle, /*u8 pb_flag,*/
                   /*u8 bc_flag,*/ u32 *l2cap_len)
{
	l2cap_packet *pkt = NULL;
	l2cap_con *con;
	u16 pkt_len;
	CID pkt_cid;

	D_RCV(__FUNCTION__ ": got %d bytes on hci_handle : %d\n", len, hci_handle);
	PRINTPKT(__FUNCTION__ ": ", data, len);

	if (*l2cap_len == 0) {
		/* Start of a new frame received,
		   parse header and set l2cap_len */

		if (len < 4) {
			D_RCV(__FUNCTION__ ": Incomplete frame header!\n");
			return;
		}

		pkt = (l2cap_packet *)data;

		pkt_len = le16_to_cpu(pkt->len);
		pkt_cid = le16_to_cpu(pkt->cid);

		/* Do some sanity checks */
		if (pkt_len > HCI_IN_SIZE)
                {
                  /* Packet won't fit in inbuffers */
                  D_ERR(__FUNCTION__": packet too big [%d], discard packet\n",
                        pkt_len);
                  hci_clear_buffer(hci_handle);
                  return;
                }

		if ((pkt_cid != 1) && (pkt_cid != 2) &&
                    ((pkt_cid < 0x0040) || (pkt_cid > 0xffff)))
                {
                  D_ERR(__FUNCTION__": invalid CID [%d], discard packet\n",
                        pkt_cid);
                  hci_clear_buffer(hci_handle);
                  return;
                }

		/* l2cap_len is checked in hci, when l2cap_len bytes
		   has been received in hci this function is called again */
		*l2cap_len = pkt_len + L2CAP_HDRSIZE;

		D_RCV(__FUNCTION__ ": New frame len:%d cid:%d\n", pkt_len, pkt_cid);

		/* check length */
		if (!(pkt_len == (len - L2CAP_HDRSIZE)))
			return;
	} else if (len != *l2cap_len) {
		/* Not recieved full frame yet or BIG packet */

		if (len > *l2cap_len) {
			DSYS(__FUNCTION__ ": BIG PACKET ! (%d bytes) discard\n", len);
			hci_clear_buffer(hci_handle);
		}
		return;
	}

	/* A whole frame is received */
	pkt = (l2cap_packet *)data;
	pkt_len = le16_to_cpu(pkt->len);
	pkt_cid = le16_to_cpu(pkt->cid);

	switch (pkt_cid) {
	case CIDSIG:
		/* Signalling channel */
		D_RCV(__FUNCTION__ ": Signal data !\n");

		signal_handler(hci_handle, data + L2CAP_HDRSIZE,
			       len-L2CAP_HDRSIZE);
		break;

	case CIDRCVCONLESS:
		if (!l2cap->allow_conless) {
			D_WARN("Connection less data not allowed\n");
			hci_clear_buffer(hci_handle);
			return;
		}

                D_RCV(__FUNCTION__ ": Connectionless data\n");

		/* FIXME: Move data 2 bytes ahead since there is a psm value
		   in the connection less packet */
		con = get_con_hcihdl(hci_handle);

		get_upper(le16_to_cpu(get_unaligned((u16 *)&pkt->data[0])))->
			receive_data(con, pkt->data + 2, pkt_len - 2);
		break;

	default:
		/* Data channel */
		con = get_lcon(pkt_cid);

		if (con == NULL) {
			D_WARN(__FUNCTION__": No connection object found\n");
			hci_clear_buffer(hci_handle);
			return;
		}

		if (con->current_state == OPEN ) {
			process_frame(con, pkt->data, pkt_len);
		} else {
			D_ERR(__FUNCTION__ ": not OPEN yet, discard data\n");
		}
		break;
	}


	/* free hci inbuffer */
	hci_clear_buffer(hci_handle);
}

/* Signalling between two l2cap entities on remote devices */

void
signal_handler(u16 hci_handle, u8 *data,
	       u32 len)
{
	sig_cmd *cmd;
	s32 pos = 0; /* position in packet */

	cmd = (struct sig_cmd *)(data + pos);
  
	cmd->len = le16_to_cpu(cmd->len);

	D_RCV(__FUNCTION__ ": received %d bytes\n", len);
	PRINTPKT(__FUNCTION__ ": data", data, len);

	if (len < (cmd->len + 4)) {
		D_ERR(__FUNCTION__ ": Length doesn't match\n");
		return; 
	} else if (len > (cmd->len + 4)) {  
		D_RCV(__FUNCTION__ ": Multiple commands !\n");  
	} else {
		D_RCV(__FUNCTION__ ": Single command\n");
	}  

	while (pos < len) {
		D_RCV(__FUNCTION__ ": got packet (%d bytes) with ID : %d\n",
		      cmd->len, cmd->id);
    
		if (ISREQUEST(cmd->code)) { 
			process_request(hci_handle, cmd);
		} else {
			process_response(hci_handle, cmd);
		}
    
		pos += (cmd->len + 4); /* General command header 4 bytes */
		
		/* parse next command header if more cmds left in packet */
		if (pos < len) {
			cmd = (struct sig_cmd *)(data + pos);
			cmd->len = le16_to_cpu(cmd->len);
			DSYS("another command in same packet...(%d bytes)\n",
			     cmd->len);
		}
	} 
}


void process_request(u16 hci_handle, struct sig_cmd *req)
{
	sig_conreq *conreq;
	sig_confreq *confreq;
	sig_discreq *discreq;
	l2cap_con *con = NULL;
	D_STATE(__FUNCTION__ ": Got request : 0x%x id:%d\n", req->code, req->id);
	
	/* FIXME -- Add check for cmd len in each request type 
	   (used to detect corrupt packets) */

	switch (req->code) {
	case SIG_CONREQ:
                /* Request for connection */
		conreq = (sig_conreq *)req->data;
		conreq->psm = le16_to_cpu(conreq->psm);
		conreq->src_cid = le16_to_cpu(conreq->src_cid);
		
		D_STATE(__FUNCTION__ ": Connection request\n");
		D_STATE(__FUNCTION__ ": id:%d len:%d PSM 0x%x src_cid:%d\n",
			req->id, req->len, conreq->psm, conreq->src_cid);
                /* 
		   Two cases :

		   1) This is the first connection  request on 
		   this hci handle
		
		   2) We already have a hci handle and wants 
		   another connection over the same physical
		   link
		*/

		/* FIXMARK -- use new function which looks in hci link list 
		   if found */
		
		if ((con = check_remote_cid(hci_handle, 
					    conreq->src_cid)) == NULL) {
			D_ERR(__FUNCTION__ ": couldn't find l2cap connection\n");
			l2cap_cmdrej(hci_handle, CMDREJ_INVALIDCID,
				     "Invalid CID", 13);
			return;
		}
		
		if (PARANOIA_CHECKCON(con)) {
			D_ERR(__FUNCTION__ ": Paranoia check failed\n");
			return;
		}
                
		ENTERSTATE(con, W4_L2CA_CONNECT_RSP);
		PRINTSTATE(con);
		
		con->psm = conreq->psm;

		con->sig_id_rcv = req->id;

		/* Other side initiated (default) */
		con->initiator = FALSE; 
		
		/* we must send a configure request */
		con->conf_req_ready=FALSE;
		con->conf_rsp_ready=FALSE;

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER                
                l2cap_check_allowed_security(con->psm, con->remote_bd, con);
#else
                l2ca_connect_ind(con);
#endif
		break; /* SIG_CONREQ*/
	
	case SIG_CONFREQ:
                /* Request for configuration */
		confreq = (sig_confreq *)req->data;
		confreq->dst_cid = le16_to_cpu(confreq->dst_cid);
		confreq->flags = le16_to_cpu(confreq->flags);
		
		D_STATE(__FUNCTION__ ": config request cid:%d flags: 0x%x\n", 
			confreq->dst_cid, confreq->flags);
		
		if ((con = get_lcon(confreq->dst_cid)) == NULL) {
			D_ERR(__FUNCTION__ ": Couldn't find local CID\n");
			/* send back response ? */
			l2cap_cmdrej(hci_handle, CMDREJ_INVALIDCID, NULL, 0);
			return;
		}
		
		switch (con->current_state) {
		case CLOSED:
			/* FIXME - send peer 
			   'l2cap_config_rsp_neg' */
			break;
			
		case CONFIG: {
			s32 result = CONF_SUCCESS;
			/* Parse remote options and store it in con */

			if ((req->len - 4) > 0) {
				result = parse_options(con, confreq->options,
						       req->len-4);
			}

			/* Are we expecting more config requests ? */
			con->remote_flags = confreq->flags;

			if (result != CONF_SUCCESS) {
				/* we didn't like the options... */
				DSYS("parse_options failed, send neg rsp\n");

				/* send back negative response */
				if (l2ca_config_rsp(con, result, STAT_NOINFO, 
						    CONF_FAILURE) < 0) {
					D_ERR(__FUNCTION__ ": Couldn't send conf rsp\n");
				}
				
				return;
			}
			
			con->sig_id_rcv = req->id;

			l2ca_config_ind(con);
			break;
		}
		
		case OPEN: {	
			s32 result = CONF_SUCCESS;

			/* 
			   FIXME - Suspend data transmission at a 
			   convenient point 
			*/
			
			D_STATE(__FUNCTION__ "Got conf req in OPEN, renegotiate !\n");

			ENTERSTATE(con, CONFIG);
			PRINTSTATE(con);
			
			if ((req->len - 4) > 0) {
				result = parse_options(con, confreq->options,
						       req->len-4);
			} else {
				D_ERR(__FUNCTION__": Remote peer tried to renegotiate but cinf req contained no options !\n");
				return;
			}
			
			/* Are we expecting more config requests ? */
			con->remote_flags = confreq->flags;

			if (result != RES_SUCCESS) {
				
				/* we didn't like the options... */
				
				/* send back negative response */
				if (l2ca_config_rsp(con, result, 
						    STAT_NOINFO, 
						    CONF_FAILURE) < 0) {
					D_ERR(__FUNCTION__": Couldnt send conf rsp\n");
				}
				return;
			}

			con->sig_id_rcv = req->id;

			/* we haven't replied pos on other side's 
			   config request yet */
			
			con->conf_rsp_ready=FALSE;
			con->conf_req_ready=FALSE;
			
			l2ca_config_ind(con);
			break;
		}
           
		default:
			D_ERR(__FUNCTION__": Got config req in invalid state! [%s]\n",
			      state_name[con->current_state]);
			PRINTSTATE(con);
			break;
		}  
		break; /* SIG_CONFREQ*/
			
	case SIG_DISCREQ:
		discreq = (sig_discreq *)req->data;
		discreq->dst_cid = le16_to_cpu(discreq->dst_cid);
		discreq->src_cid = le16_to_cpu(discreq->src_cid);

		D_STATE(__FUNCTION__ ": disconnection request id %d\n", 
			req->id);

		if ((con = get_lcon(discreq->dst_cid)) == NULL) {
			DSYS(__FUNCTION__"Disconnecting NULL object!\n");
			return;
		}

		SHOW_CON("disc req\n", con);

		con->sig_id_rcv = req->id;

		/* if already closed, simply acknowledge */
		if ((con->current_state == CLOSED)) {
			D_STATE(__FUNCTION__ ": connection closed, send disc rsp\n");
			l2cap_disconnect_rsp(con);
			return;
		}

		/* else notify upper layers */
		ENTERSTATE(con, W4_L2CA_DISCONNECT_RSP);
		PRINTSTATE(con);
         
		l2ca_disconnect_ind(con);          
		break; /* SIG_DISCREQ */
       
	case SIG_ECHOREQ: {
		sig_echo_pkt* echo;
		D_STATE(__FUNCTION__ ": Echo request\n");
		
		echo = (sig_echo_pkt *)(req->data);		

		l2cap_echo_rsp(hci_handle, req->id, 
			       req->data, req->len - sizeof(sig_echo_pkt));
		break;
	}
       
	case SIG_INFOREQ: {
		/* Implementation specific */
 		sig_info_req *info;
		D_STATE(__FUNCTION__ ": Info request\n");
		
		info = (sig_info_req*)(req->data);
		info->type = le16_to_cpu(info->type);
		
		switch(info->type) {
		case INFO_CONNLESS_MTU:
			DSYS("Request for connectionless MTU\n");
			
			l2cap_info_rsp(hci_handle, req->id, info->type,
				       NULL, 0, 1 /* not supported */);
			break;

		default:
			D_ERR(__FUNCTION__ ": Unknown info request: type 0x%x\n", info->type);
			l2cap_cmdrej(hci_handle, CMDREJ_NOTUNDERSTOOD,
				     NULL, 0);
			break;		
		}
		break;
	}    
       
	case SIG_RESERVED:
		D_STATE(__FUNCTION__ ": Reserved!\n");
		break;
        
	default:
		/* Not a valid command */
		DSYS(__FUNCTION__ ": Invalid command (code 0x%x)s\n", req->code);
		l2cap_cmdrej(hci_handle, CMDREJ_NOTUNDERSTOOD, NULL, 0);
		break;
	}
}

void process_response(u16 hci_handle, struct sig_cmd *rsp)
{
	sig_conrsp *conrsp;
	sig_confrsp *confrsp;
	sig_discrsp *discrsp;
	sig_echo_pkt *echo;
	sig_info_rsp *info;
	sig_cmdreject *cmdreject;
	l2cap_con *con = NULL;
	s32 failure = 0;
	u16 opt_len = 0;

	D_STATE(__FUNCTION__ ": Got response: 0x%x id:%d\n",
		rsp->code, rsp->id);

	/* FIXME -- Add check for cmd len in each response type 
	   (used to detect corrupt packets) */

	switch (rsp->code) {
	case SIG_CMDREJECT:
		D_STATE(__FUNCTION__ ": Command reject - \n");
		DSYS("Got command reject\n");
		cmdreject = (sig_cmdreject*)rsp->data;
		cmdreject->reason = le16_to_cpu(cmdreject->reason);
		opt_len = rsp->len - sizeof(sig_cmdreject);
		switch (cmdreject->reason) {
		case 0:
			D_ERR(__FUNCTION__ ": Command not understood\n"); 
			break;
           
		case 1:
			D_ERR(__FUNCTION__ ": Signalling MTU exceeded\n");
			break;
           
		case 2:
			D_ERR(__FUNCTION__ ": Invalid CID in request\n");
			break;
           
		default:
			D_ERR(__FUNCTION__ ": Unrecognized cmd reject "\
			      "reason\n");
			break;
		}
		
		if (opt_len > 0)
			print_data(__FUNCTION__ ": optional data : ", 
				 cmdreject->data, rsp->len-2);

		/* find connection object using id field */
		
		con = get_first_con();

		while (con && (con->sig_id_sent != rsp->id))
			con = get_next_con(con);

		if (con) {                  
			/* fixme -- set 'real' reason code */
			con->c_status = CSTATUS_CMDREJECT;
			
			l2ca_wakeup("l2cap cmd reject", con);
			
#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
			disable_rtx(con);
#endif
		} else
			D_ERR(__FUNCTION__ ": Could not find an l2cap "\
			      "connection for this ID\n");
		break;
       
	case SIG_CONRSP:
		/* client */
		D_STATE(__FUNCTION__ ": Got connection response\n");
		conrsp = (sig_conrsp *)rsp->data;
		conrsp->src_cid = le16_to_cpu(conrsp->src_cid);
		conrsp->dst_cid = le16_to_cpu(conrsp->dst_cid);
		conrsp->result  = le16_to_cpu(conrsp->result);
		conrsp->status  = le16_to_cpu(conrsp->status);

		/* find connection */
		if ((con = get_lcon(conrsp->src_cid)) == NULL) {
			D_ERR(__FUNCTION__ ": con rsp, NO CONNECTION FOUND\n");
			return;
		}

		con->remote_cid = conrsp->dst_cid;

		/* match id with request */
		if (!id_matched(con, rsp->id)) {
			D_ERR(__FUNCTION__ ": ID doesn't match ! [%d:%d]\n", con->sig_id_sent, rsp->id);
			return;
		}
         
		con->c_status = conrsp->result;		

		switch (conrsp->result) {
		case RES_SUCCESS:

			con->c_result = RES_SUCCESS;
			l2ca_wakeup("l2cap con rsp", con);

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
                        disable_rtx(con);
#endif
			ENTERSTATE(con, CONFIG);
			PRINTSTATE(con);
			l2ca_connect_cfm(con, conrsp->result);
			break;
           
		case RES_PENDING:

			/* wake up when real con resp comes */
			l2ca_connect_pnd(con, conrsp->status);
#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
			/* Disable RTX timer and start ERTX */
                        disable_rtx(con);
			start_ertx(con, ERTX_TIMEOUT);
#endif
			D_STATE(__FUNCTION__ ": connection pending\n");
			break;

		case RES_PSMNEG:
			DSYS(__FUNCTION__ ": connection refused, psm 0x%x not supp\n", 
			     con->psm);
			failure = 1;
			break;

		case RES_SECNEG:
			DSYS(__FUNCTION__ ": connection refused, security block\n");
			failure = 1;
			break;
           
		case RES_NOSRC:
			DSYS(__FUNCTION__ ": connection refused, no resources\n");
			failure = 1;
			break;
           
		default:
			D_ERR(__FUNCTION__ ": SIG_CONRSP\n");
			break;
		}
         
		if (failure) {

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
			disable_rtx(con);
			disable_ertx(con);
#endif

			l2ca_connect_cfm(con, MSGCODE(MSG_LAYER_L2CAP, conrsp->result));

			l2ca_wakeup("Got connect rsp neg", con);
			
			ENTERSTATE(con, CLOSED);
			delete_con(con);
		}
		break;
       
	case SIG_CONFRSP:
		D_STATE(__FUNCTION__ ": Got configuration response\n");
		confrsp = (sig_confrsp *)rsp->data;
		confrsp->src_cid = le16_to_cpu(confrsp->src_cid);
		confrsp->flags = le16_to_cpu(confrsp->flags);
		confrsp->result = le16_to_cpu(confrsp->result);
		opt_len = rsp->len - sizeof(sig_confrsp);

		PRINTPKT(__FUNCTION__ ": config response", rsp->data, rsp->len);

		/* check that remote CID is in list */
		if ((con = get_lcon(confrsp->src_cid)) == NULL)
			return;

		if (con->current_state != CONFIG) {
			D_ERR(__FUNCTION__ ": SIG_CONFRSP invalid state\n");
			PRINTSTATE(con);
			return; 
		}
			       
		/* match id with request */
		if (!id_matched(con, rsp->id)) {
			D_ERR(__FUNCTION__ ": ID doesn't match ! [%d:%d]\n", con->sig_id_sent, rsp->id);			
			return;
		}

		switch (confrsp->result) {
		case CONF_SUCCESS:

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
			disable_rtx(con);
#endif
			con->conf_req_ready = TRUE;

 			if (!con->conf_rsp_ready) {
				/* Upper layers still haven't replied pos */
				D_STATE(__FUNCTION__": Still haven't replied pos on other sides conf req\n");
				return ;
			} else {				
				ENTERSTATE(con, OPEN);
				PRINTSTATE(con);
				DSYS("l2cap channel (%d,%d) [%s] connected\n", 
				     con->local_cid, con->remote_cid, 
				     psm2str(con->psm));
				
				/* notify upper layers that we successfully
				   opened a connection ! */
				l2ca_config_cfm(con, confrsp->result);

				/* reset variable */
				con->conf_req_sent = 0;
				return;
			}
			
		case CONF_FAILURE:

			/* store remote side configuration */
			parse_options(con, confrsp->options, opt_len);

			D_STATE(__FUNCTION__ ": config failure, unacceptable params\n");
			l2ca_config_cfm(con, confrsp->result);
			break;
           
		case CONF_REJ:
			D_STATE(__FUNCTION__ ": connection refused, no reason\n");
			l2ca_config_cfm(con, confrsp->result);
			break;
           
		case CONF_UNKNOWN:
			D_STATE(__FUNCTION__ ": connection refused, unknown options\n");
			l2ca_config_cfm(con, confrsp->result);
			break;
            
		default:
			D_ERR(__FUNCTION__ ": SIG_CONFRSP\n");
			break;
		}
     
		/* If we end up here, config failed */

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
		disable_rtx(con);
#endif

		if (con->current_state != CONFIG)
			D_ERR(__FUNCTION__ ": SIG_CONFRSP invalid state\n");
		PRINTSTATE(con);

		/* print failed options */
		if (opt_len > 0)
			print_data("Options not accepted\n", confrsp->options, 
				   rsp->len - sizeof(sig_confrsp));

		break;
        
	case SIG_DISCRSP:
		D_STATE(__FUNCTION__ ": Got disconnect response\n");
		discrsp = (sig_discrsp *)rsp->data;
		discrsp->dst_cid = le16_to_cpu(discrsp->dst_cid);
		discrsp->src_cid = le16_to_cpu(discrsp->src_cid);
		PRINTPKT(__FUNCTION__ ": disconnect response", rsp->data, rsp->len);

		/* find connection */
		if ((con = get_lcon(discrsp->src_cid)) == NULL)
			return;

		if (con->current_state != W4_L2CAP_DISCONNECT_RSP) {
			D_ERR(__FUNCTION__ ": SIG_DISCRSP invalid state\n");
			PRINTSTATE(con);
			return; 
		}
	       	       
		/* match id with request */
		if (!id_matched(con, rsp->id)) {
			D_ERR(__FUNCTION__ ": ID doesn't match ! [%d:%d]\n", 
			      con->sig_id_sent, rsp->id);
			return;
		}

		con->c_status = CSTATUS_SUCCESS;	

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
		disable_rtx(con);
#endif
		con->c_result = RES_SUCCESS;
		l2ca_disconnect_cfm(con);
		l2ca_wakeup("l2cap disc rsp", con);
		break;
       
	case SIG_ECHORSP: {
		l2cap_con *tempcon;
		
		D_STATE(__FUNCTION__ ": Got echo response\n");		

		if ((tempcon = get_con_hcihdl(hci_handle))==NULL) {
			D_STATE(__FUNCTION__": Echo rsp, could not find connection\n");
			return;
		}
		
		echo = (sig_echo_pkt *)(rsp->data);
		opt_len = rsp->len;
			
		if (opt_len > 0)
			PRINTPKT(__FUNCTION__ ": optional data ", 
				 echo->data, rsp->len-sizeof(sig_echo_pkt));

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
		disable_rtx(tempcon);
#endif
		/* now wake up l2ca_ping */

		tempcon->c_status = CSTATUS_SUCCESS;
		tempcon->c_result = RES_SUCCESS;
		l2ca_wakeup("echo resp received", tempcon);

		break;
	}    
       
	case SIG_INFORSP: {
		l2cap_con *tempcon;

		if ((tempcon = get_con_hcihdl(hci_handle))==NULL) {
			D_STATE(__FUNCTION__": Echo rsp, could not find connection\n");
			return;
		}

		info = (sig_info_rsp *)(rsp->data);
		info->type = le16_to_cpu(info->type);
		info->result = le16_to_cpu(info->result);
		
		D_STATE(__FUNCTION__ ": Got info response: result %d\n", info->result);

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
		disable_rtx(tempcon);
#endif
		/* now wake up l2ca_ping */
		
		tempcon->c_status = RES_SUCCESS;
		l2ca_wakeup("info resp received", tempcon);
		
		break;
	}
	
	default:
		/* Not a valid command */
		DSYS(__FUNCTION__ ": Invalid command 0x%x\n", rsp->code);
		l2cap_cmdrej(hci_handle, CMDREJ_NOTUNDERSTOOD, NULL, 0);
		break;
	}
}


/*******************************************************************/
/*-------------------------- EVENTS -------------------------------*/
/*******************************************************************/

/*

  Events are all incoming messages to the L2CA layer along with the
  timeouts. Events are partitioned into five categories :
  1. Indications and confirms from lower layers
  2. Signal requests and responses from peers
  3. L2CAP to L2CAP Data
  4. Requests and responses from upper layers
  5. Events caused by timers

 */

/*******************************************************************/
/* (E1) Lower layer to l2cap */
/****************************/

/* Indicates the lower protocol has successfully established connection */
void 
lp_connect_ind(BD_ADDR bd_addr)
{
	PRINTPKT(__FUNCTION__ ": from: ", bd_addr, 6);

        /* Check BD_ADDR */
        if (!bd_addr[0] && !bd_addr[1] && !bd_addr[2] &&
            !bd_addr[3] && !bd_addr[4] && !bd_addr[5]) {
		D_ERR(__FUNCTION__ ": no BD addr\n");
		return;
        }
 
	/* FIXME - add check with control block if this bd_addr is allowed */

	/* We are server and creates an l2cap connection object 
	   which we set hci handle when we received lp_connect_cfm */
	/* Denying a connection at this state does not allow
	   SDP queries when max amount of connections is reached*/

	if (hci_ctrl.nbr_of_connections < bt_max_connections) {
		D_CON(__FUNCTION__ ": Accepting connection\n");
		l2cap_create_con(bd_addr);
		lp_connect_rsp(bd_addr, 1);
	} else {
		D_CON(__FUNCTION__ ": Denying connection. Current connections: %d, max connections: %d\n", hci_ctrl.nbr_of_connections, bt_max_connections);
		lp_connect_rsp(bd_addr, 0);
	}
}
	
/* is called when we accept a _new_ baseband connection */
void 
l2cap_create_con(BD_ADDR bd)
{
	l2cap_con *con;
	D_RCV(__FUNCTION__ "\n");	
	PRINTPKT(__FUNCTION__ ": bd ", bd, 6);

	/* create a new l2cap connection obj and insert it in list */

	/* HACK! - remote CID = 0 indicates that remote cid has not '
	   been set yet */

	con = create_con(0 /* not yet set*/ , get_cid(), 0/*not yet set*/);
	
	/* Check connection */
        if (con == NULL) {
		D_ERR(__FUNCTION__ ": no connection created");
		return;
        }
        
	con->link_up = TRUE;
	memcpy(con->remote_bd, bd, 6);

	/* have not received l2cap connection req yet */
	ENTERSTATE(con, CLOSED); 
	insert_con(con);
	return;
}


/* 
   Confirms the request to establish a baseband connection
*/
  
s32
lp_connect_cfm(u8 *bd_addr, u32 status, u16 con_hdl)
{
	l2cap_con *con;
	u8 rev_bd[6];
	s32 i;

	D_STATE(__FUNCTION__ ": %s (hci_handle : %d)\n", 
		get_err_msg(status), con_hdl);

	/* reverse byte order */
	for (i = 0; i < 6; i++) {
		rev_bd[5-i] = bd_addr[i];
	}

	D_STATE(__FUNCTION__ ": bd %s\n", bd2str(rev_bd));

	/* FIXME -- use bt session list to notify upper layers that 
	   con failed !!! */

	/* search for the corresponding l2cap connection */
	if ((con = get_con(bd_addr, CLOSED)) == NULL) {
		D_ERR(__FUNCTION__ ": couldn't find l2cap con!\n");
		return 0;
	}

	con->c_status = status;
	con->c_result = status;

	if (status == 0) {
		/* pos cfm */
		con->hci_hdl = con_hdl;
		con->link_up = TRUE;

		/* see if there is someone to wakeup */
		l2ca_wakeup("lp_connect_cfm (pos)", con);
		
		if (con->c_flags & FLAG_RETURNNOW) {
			D_STATE(__FUNCTION__" Return NOW\n");
			/* clear flag & set status */
			con->c_flags &= ~FLAG_RETURNNOW;
			return 0;
		}
		
		if (!(con->initiator)) {		
			D_STATE("We are server\n");
			/* now wait for a connection request */
		} else {
			D_STATE("We are client\n");
			PRINTPKT(__FUNCTION__ ": HCI connected to ", 
				 bd_addr, 6);
      
			ENTERSTATE(con, W4_L2CAP_CONNECT_RSP);
			PRINTSTATE(con);
			
			l2ca_wakeup(__FUNCTION__, con);
		}

		return 1;
	} else {
		/* neg cfm */
		D_STATE(__FUNCTION__ ": (neg) %s\n",get_err_msg(status));
		con->link_up = FALSE;

		l2ca_wakeup(__FUNCTION__ " (neg)", con);
		
		if (con->c_flags & FLAG_RETURNNOW) {
			con->c_flags &= ~FLAG_RETURNNOW;
			return 0;
		}

		if (con->initiator) {
			/* only notify upper layers if we are initiator */
			l2ca_connect_cfm(con, MSGCODE(MSG_LAYER_HCI, 
						      status));
		} else {
			/* delete connection if non-initiator */
			delete_con(con);
		} 

		return 0;
	}
}
 
/* Indicates that one of the baseband connections has been shutdown */
s32
lp_disconnect_ind(u32 con_hdl)
{
	l2cap_con *con;
	s32 found = 0;

	/* temp link down */
	DSYS(__FUNCTION__": Connection handle %d disconnected\n",
	     con_hdl);

	/* find & notify/remove l2cap connection(s) on this hci handle */

	SHOW_LIST();

	while (((con = get_con_hcihdl(con_hdl)) != NULL)) {
		D_STATE("l2cap connection (%d:%d) found on handle %d\n", 
			con->local_cid, con->remote_cid, con_hdl);
		D_STATE("now closing it...\n");
		
		PRINTSTATE(con);
    
		/* flag phys link as down */
		con->link_up = FALSE;

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
		/* cancel any outstanding timers */
		disable_rtx(con);
		disable_ertx(con);
#endif

		/* if not connected yet simply remove it */
		if (con->current_state == CLOSED) {      
			D_STATE("connection closed, remove it!\n");
			delete_con(con);
		} else {
			ENTERSTATE(con, W4_L2CA_DISCONNECT_RSP);
			DSYS("closing l2cap con (%d,%d)\n",
			     con->local_cid, con->remote_cid);

			/* notify upper layers that phys link is down */
			get_upper(con->psm)->disc_ind(con);
		}

		found = 1;
	}

	D_CON(__FUNCTION__ ": no more l2cap cons on this handle\n");

	/* flush old buffers waiting to be sent on this handle */
	btmem_flushhandle((u16)con_hdl);

	return found;
}

/* FIXME - lp_qos_violation_ind() */
/* FIXME - lp_qos_cfm() */

 
/********************************************************************/
/* (E2) l2cap to l2cap signalling */
/*********************************/

/* is handled in signal_handler() */

/******************************************************************/
/* (E3) L2CAP to L2CAP Data*/
/**************************/


void 
process_frame(l2cap_con *con, u8 *data, u32 len)
{  
	PRINTPKT(__FUNCTION__ ": ", data, len);

	if (len > (con->local_mtu)) {
		DSYS("l2cap process_frame : len > local_mtu (%ld/%d)\n", 
		     (long)(len - L2CAP_HDRSIZE), con->local_mtu);
		l2cap_cmdrej(con->hci_hdl, CMDREJ_MTUEXCEEDED, NULL, 0);
		return;
	} 

	get_upper(con->psm)->receive_data(con, data, len);
}


/**************************************************************/
/* (E4) Upper layers to l2cap */
/*****************************/

s32 
l2ca_connect_req(BD_ADDR bd, u16 psm)
{
	l2cap_con *con;
	l2cap_con *tmpcon;
	s32 i, retval = 0;
	u8 rev_bd[6];

	D_RCV(__FUNCTION__ "\n");
	PRINTPKT(__FUNCTION__ ": sent to bd ",bd, 6);

	/* Check bd_addr */
	if (!bd[0] && !bd[1] && !bd[2] && !bd[3] && !bd[4] && !bd[5]) {
		D_ERR(__FUNCTION__ ": No BD-addr\n");
		return -EINVAL;
	}

	/* Check PSM */
	if ((psm % 2) == 0) {
		D_ERR(__FUNCTION__ ": incorrect PSM value\n");
		return -EINVAL;
	}
	if ((psm > MAX_PSM) && (psm < MIN_DYNAMIC_PSM)) {
		D_ERR(__FUNCTION__ ": value of PSM preserved\n");
		return -EINVAL;
	}
	if (psm > MAX_DYNAMIC_PSM) {
		D_ERR(__FUNCTION__ ": PSM value not valid\n");
		return -EINVAL;
	}
	
	/* bd is big endian, reverse byte order to little endian */
	for (i = 0; i < 6; i++) {
		rev_bd[5-i] = bd[i];
	}

	tmpcon = get_con(rev_bd, ANY_STATE);
  
	/* Create connection object, hci_handle is set from lp_connect_cfm */
	con = create_con(0/* not yet set */, get_cid(), 0/* not yet set */);
	/* Check connection */
        if (con == NULL) {
		D_ERR(__FUNCTION__ ": no connection created\n");
		return -ENOMEM;
        }

	memcpy(con->remote_bd, rev_bd, 6);
	print_data("bd", con->remote_bd, 6);
	/* we are client */
	con->initiator = 1; 

	/* we must send and receive a configure req */
	con->conf_req_ready=0;
	con->conf_rsp_ready=0;

	con->psm = psm;
	con->flush_timeout = FLUSHTIMEOUT_DEFAULT;

	/* is set when receiving a pos lp_connect_cfm */
	con->link_up = 0; 
  
	insert_con(con);

	/* if this physical bd link exist for another l2cap con, use that! */
	if (tmpcon) {
		D_STATE(__FUNCTION__ ": hci handle already exist.\n");
		con->hci_hdl = tmpcon->hci_hdl;
		con->link_up = 1;
		ENTERSTATE(con, W4_L2CAP_CONNECT_RSP);
		PRINTSTATE(con);
	} else {
		D_STATE(__FUNCTION__ ": create new baseband link\n");
		retval = lp_connect_req(con->remote_bd);
		if(retval < 0) {
			D_ERR(__FUNCTION__ ": failed (status %d)\n", retval);
			return retval;
		}

		/* wait here until we received a lp_connect_cfm */
		l2ca_wait(__FUNCTION__ ": wait baseband", con);
		
		if (con->c_status != RES_SUCCESS) {
			D_ERR(__FUNCTION__ ": lp_connect_req failed, no connection (status %d)\n", con->c_status);
			retval = -MSGCODE(MSG_LAYER_HCI, con->c_status);
			delete_con(con);
			return retval;
		}
	}	

	/* Now send connect req */
	con->c_status = CSTATUS_RTX_TIMEOUT;

	/* Leave loop when either status failed or success */
	while (con->c_status == CSTATUS_RTX_TIMEOUT) {
		/* baseband is up, now initiate send connect req */
		retval = l2cap_connect_req(con, con->psm);
		if(retval < 0) {
			D_ERR(__FUNCTION__ ": failed (status %d)\n", retval);
		}
		/* wait until we received a response or after timeout */
		l2ca_wait(__FUNCTION__ ": wait rsp", con);
	}

	if (con->c_status == CSTATUS_MAX_NO_RTX && !retval) {
		retval = -MSGCODE(MSG_LAYER_L2CAP, L2CAP_RTX_TIMEOUT);
	}
	return retval;
}

/* params determines how we would like to receive data */
s32 
l2ca_config_req(l2cap_con *con, u16 in_mtu, flow *outflow, 
                u16 flush_timeout, u16 link_to)
{  
	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return -EINVAL;
	}

	D_STATE("l2ca_config_req remote cid %d, in_mtu %d\n", 
		con->remote_cid, in_mtu);

	/* should already be in CONFIG state */

	if (con->current_state == CONFIG) {  
		/* local mtu is set in l2cap_config_req */
                
		con->conf_req_sent = 1;

		return l2cap_config_req(con, in_mtu, outflow, 
					flush_timeout, link_to);  

	} else if (con->current_state == CLOSED) {
		l2ca_config_cfm(con, CONF_REJ);
		return -MSGCODE(MSG_LAYER_L2CAP, L2CAP_NO_CONNECTION);
	} else if (con->current_state == OPEN) {
		DSYS("l2ca_config_req: state OPEN, reconfiguration !\n");

		/* FIXME - 
		   Is data automatically suspended while reconfiguring  ?
		*/

		ENTERSTATE(con, CONFIG);
		PRINTSTATE(con);
		
		/* local mtu is set in l2cap_config_req */

		con->conf_req_ready = FALSE;
		con->conf_rsp_ready = FALSE;

		return l2cap_config_req(con, in_mtu, outflow, 
					flush_timeout, link_to);  
	} else {
		D_ERR(__FUNCTION__ ": invalid state\n");
		PRINTSTATE(con);
		return -MSGCODE(MSG_LAYER_L2CAP, L2CAP_INVALID_STATE);
	}
}

s32 
l2ca_disconnect_req(l2cap_con *con)
{
	s32 retval = 0;
	u16 tmp_hdl = con->hci_hdl;

	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return -EINVAL;
	}

	D_STATE(__FUNCTION__ ": remote cid : %d\n", con->remote_cid);

	if (con->current_state == OPEN || con->current_state == CONFIG) {
		ENTERSTATE(con, W4_L2CAP_DISCONNECT_RSP);
		PRINTSTATE(con);
		do {
			retval = l2cap_disconnect_req(con);
			if(retval < 0) {
				/* This will result in a timeout and we need to try again
				   as the error is a result of insufficent space in our
				   memorypool and we try again after a timeout */
				D_ERR(__FUNCTION__ ": Failed (status %d)\n", retval);
			}
			
			l2ca_wait(__FUNCTION__, con);
			PRINTSTATE(con);
			
		} while (con->c_status == CSTATUS_RTX_TIMEOUT);
	} else {
		D_ERR(__FUNCTION__ ": Invalid state!\n");
		PRINTSTATE(con);
		return -MSGCODE(MSG_LAYER_L2CAP, L2CAP_INVALID_STATE);    
	}
	
	if(con->c_status != CSTATUS_MAX_NO_RTX) {
		if (con->current_state == CLOSED) {	
			/* remove l2cap connection */
			delete_con(con);
		} else {
			/* FIXME: If we reach here, should we delete the connection? */
			D_ERR(__FUNCTION__ ": Failed (Connection not closed)");
			PRINTSTATE(con);
			retval = -MSGCODE(MSG_LAYER_L2CAP, L2CAP_FAILED);
		}
	}
	
	
	/* fixme -- if we want to keep baseband connection we must 
	   leave the l2cap connection which holds the hci handle 
	   simply just clear l2cap params but keep hci handle ! */
	
	if (count_con(tmp_hdl) == 0) {
		DSYS("l2ca_disconnect_req : (C) no more l2cap cons\n");
		DSYS("Shutdown baseband\n");
		lp_disconnect(tmp_hdl);
	}

	return retval;
}


/* Response from upper layer to the indication of a channel to a remote 
   device */
s32 
l2ca_connect_rsp(l2cap_con* con, u16 response, u16 status)
{
	s32 result;

	D_STATE(__FUNCTION__ "\n");

	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return -EINVAL;
	}

	/* optionally send l2cap_connect_rsp_pnd() */  

	if (con->current_state != W4_L2CA_CONNECT_RSP) {
		D_ERR(__FUNCTION__ ": invalid state \n");
		PRINTSTATE(con);
		return -1;
	}
  
	result = l2cap_connect_rsp(con, response, status);
	
	if (response == RES_SUCCESS) {  
		ENTERSTATE(con, CONFIG);
		PRINTSTATE(con);
	} else if (response == RES_PENDING) {
		/* remain in same state */
	} else if (response >= RES_PSMNEG) {
		/* 'l2ca_connect_rsp_neg()' */
		ENTERSTATE(con, CLOSED);
		PRINTSTATE(con);

		/* remove connection */
		delete_con(con);
	}  
	return result;
}

s32 
l2ca_config_rsp(l2cap_con* con, u32 out_mtu, flow *in_flow, s32 result)
{
	s32 ret_val = -1;

	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return -EINVAL;
	}

	D_STATE(__FUNCTION__ ": remote cid %d remote mtu %d\n", 
		con->remote_cid, con->remote_mtu);

	if (con->current_state != CONFIG) {
		D_ERR(__FUNCTION__": invalid state\n");
		PRINTSTATE(con);
		return -1;
	}

	if (result == CONF_SUCCESS) {
		/* upper layers responded OK */
		con->conf_rsp_ready = TRUE;

		ret_val = l2cap_config_rsp(con, out_mtu, in_flow, result);

		/* check if we have sent a configure request yet */
		if (con->conf_req_ready && !con->remote_flags) {
			/* all done, proceed to OPEN */
			ENTERSTATE(con, OPEN);
			PRINTSTATE(con);
			DSYS("l2cap channel (%d,%d) [%s] connected\n", 
			     con->local_cid, con->remote_cid, 
			     psm2str(con->psm));

			/* reset variable */
			con->conf_req_sent = 0;

			/* notify upper layers that we are opened */
			l2ca_config_cfm(con, RES_SUCCESS);

		} else {
			D_STATE(__FUNCTION__ ": Conf not done or flags set\n");
		}
	} else {
		D_STATE("We don't accepted remote options\n");
		ret_val = l2cap_config_rsp(con, out_mtu, in_flow, result);
	}

	return ret_val;
}

s32 
l2ca_disconnect_rsp(l2cap_con* con)
{
	s32 result = -1;
	D_STATE(__FUNCTION__ "\n");

	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return -EINVAL;
	}

	SHOW_CON("disconnecting : ", con);

	if (con->current_state == W4_L2CA_DISCONNECT_RSP) {
		/* if we got a link down unexpectedly we cannot send 
		   back a response, send nothing... */
		if (con->link_up)
			result = l2cap_disconnect_rsp(con);
		else {
			/* tell upper layers that disconnection was 
			   'successful' */
			result=0;
			D_STATE("baseband link down, cannot send rsp\n");
		}
		
		ENTERSTATE(con, CLOSED);		

		PRINTSTATE(con);
 
		DSYS("l2cap channel (%d,%d) [%s] disconnected\n", 
		     con->local_cid, con->remote_cid, psm2str(con->psm));

		if (count_con(con->hci_hdl) > 1) {
			delete_con(con);     
		}
	} else {
		D_ERR(__FUNCTION__ ": invalid state !\n\n");
		PRINTSTATE(con);
	}
	return result;
}

/* only supports one call at a time */
void
l2ca_wait(const char *str, l2cap_con *con)
{
	if (!(con->c_flags & FLAG_WAKEMEUP)) {
		if (con->c_flags & FLAG_DONTSLEEP) {
			printk("l2ca_wait : don't sleep flag set\n");
			return;
		}

		con->c_flags |= FLAG_WAKEMEUP;
		printk("%s, sleep on wq 0x%x\n", str, (int)&con->wq);
		interruptible_sleep_on(&con->wq);
		printk("%s, woke up !\n", str);
	} else {
		printk("%s, wq already in use\n", str);
	}
}

void 
l2ca_wakeup(const char *str, l2cap_con *con)
{
	if (con->c_flags & FLAG_WAKEMEUP) {
		if (con->c_flags & FLAG_DONTSLEEP) {
			printk("l2ca_wakeup : don't sleep flag set\n");
			con->c_flags &= ~FLAG_DONTSLEEP;
			return;
		}

		con->c_flags &= ~FLAG_WAKEMEUP;
		printk("%s, wake up wq 0x%x\n", str,(int)&con->wq);
		wake_up_interruptible(&con->wq);
	} else {
		printk("%s, wake up flag not set\n", str);
	}
}

/*******************************************************************/
/* (E5) Timer events */
/********************/

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS

void l2ca_timeoutind(l2cap_con *con)
{
	DSYS("l2ca_timeoutind\n");
	con->c_status = CSTATUS_RTX_TIMEOUT;	
	l2ca_wakeup("l2ca_timeoutind ", con);
}

#ifdef __KERNEL__
void
l2cap_rtx_timeout(unsigned long ptr)
{
	l2cap_con *con = (l2cap_con*)ptr;
#else /* usermode timer */
void
l2cap_rtx_timeout(void)
{
	l2cap_con *con = timeout_con;

	if (timer_cancelled) {
		D_TIM("RTX timer already cancelled\n");
		return;
	}
#endif
	/* do some paranoia checks */

	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return;
	}

	D_TIM(__FUNCTION__ ": current no rtx : %d\n", con->timer.rtx_no);

	con->timer.rtx_inuse = 0;

	if (con->timer.rtx_no == MAX_NO_RTX) {
		con->c_status = CSTATUS_MAX_NO_RTX;

		D_TIM("Connection unresponsive\n");

		show_con("Connection unresponsive\n", con);

		con->c_result = MSGCODE(MSG_LAYER_L2CAP, 
					L2CAP_CON_UNRESPONSIVE);

		l2ca_wakeup("rtx_timeout", con);

		/* reset rtx counter */
		con->timer.rtx_no = 0;

		if (con->timer.rtx_action == RTX_ACTION_START_ERTX) {
			/* start ertx timer */
			D_TIM("Starting ERTX\n");
			start_ertx(con, ERTX_TIMEOUT);
		} else if (con->timer.rtx_action == RTX_ACTION_TERMINATE) {
			D_TIM("Removing connection\n");
			l2ca_disconnect_ind(con);
			ENTERSTATE(con, CLOSED);
			delete_con(con);
		}
	} else {
		con->timer.rtx_no++;
		l2ca_timeoutind(con);	
	}

#ifndef __KERNEL__
	timeout_con = NULL;
#endif
}

void
l2cap_ertx_timeout(unsigned long ptr)
{
	l2cap_con *con;
	D_TIM(__FUNCTION__ "\n");
	con = (l2cap_con*)ptr;

	/* do paranoia check */
	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		return;
	}

	if (con->timer.ertx_action == ERTX_ACTION_TERMINATE) {
		D_TIM("Removing connection\n");
		l2ca_disconnect_ind(con);
		ENTERSTATE(con, CLOSED);
		delete_con(con);
	} else if (con->timer.ertx_action == ERTX_ACTION_DISCONNECT) {
		
		D_TIM("Disconnect connection\n");
		/* set dont sleep flag so that we wont do sleep 
		   when not running in usermode context */
		con->c_flags |= FLAG_DONTSLEEP;
		ENTERSTATE(con, CONFIG); /* CERT HACK ! */
		l2ca_disconnect_req(con);
	}
}

#endif /* CONFIG_BLUETOOTH_L2CAP_USE_TIMERS */

/*******************************************************************/
/*-------------------------- ACTIONS ------------------------------*/
/*******************************************************************/

/*
  
  Actions are partitioned into five categories:
    1. l2cap to lower layers
    2. l2cap to l2cap signalling
    3. l2cap to l2cap data transmission
    4. l2cap to upper layers
    5. setting timers
    
 */

/*******************************************************************/
/* (A1) l2cap to lower layers */
/*****************************/

/* FIXME - lp_qos_req() */

/*******************************************************************/
/* (A2) l2cap to l2cap signalling */
/**********************************/

/****************************/
/* l2cap request functions  */
/****************************/

s32 
l2cap_connect_req(l2cap_con *con, u16 psm)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_conreq *req;
	u16 payload_len;

        D_XMIT(__FUNCTION__ ": Connecting %s (rcid:%d)\n",psm2str(psm), 
               con->remote_cid);
	
	if (con->current_state != W4_L2CAP_CONNECT_RSP) {
		D_ERR(__FUNCTION__ ": Invalid state\n");
		return -MSGCODE(MSG_LAYER_L2CAP, L2CAP_INVALID_STATE);
	}

	payload_len = SIGCMD_HDRSIZE + CON_REQSIZE;  /*2 x 4*/

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);
  
	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	req = (sig_conreq*)(l2cap_buf->frame + L2CAP_HDRSIZE + SIGCMD_HDRSIZE);

	/* Now fill in header fields */  
	req->psm = cpu_to_le16(con->psm);
	req->src_cid = cpu_to_le16(con->local_cid);
  
	cmd->code = SIG_CONREQ;

        /* Don't increment ID if retransmission */
        if (con->timer.rtx_no == 0)
                cmd->id = set_id(con); /* S
ets sig_id_sent in l2cap_con */
        else
                DSYS("RTX, use same ID\n");

	cmd->len = cpu_to_le16(CON_REQSIZE);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased as lower layers
						      add header data */  
	
#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
	/* start retransmission timer */
	start_rtx(con, RTX_TIMEOUT, RTX_ACTION_START_ERTX);
#endif
	return hci_send_data(tx);
}

/* only specify inparam if it differs from default value */
s32 
l2cap_config_req(l2cap_con *con, u16 in_mtu, flow *outflow,
		 u16 flush_timeout, u16 link_timeout)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_confreq *req;
	u16 payload_len;
	s32 opt_len = 0;
	struct l2cap_option *opt;

	D_XMIT(__FUNCTION__ ": rcid :%d\n", con->remote_cid);

	/******************************************************************/
	/* | len2 | CID2 || code1 | id1 || destcid2 | flags1 | options? | */
	/* -------------------------------------------------------------- */
	/* | l2cap hdr   || sig cmd hdr ||             data             | */
	/******************************************************************/

	D_STATE(__FUNCTION__ ": inmtu : %d, local mtu : %d\n",
		in_mtu, con->local_mtu);

	if (in_mtu != 0) {
		DSYS("Setting local mtu to %d\n", in_mtu);
		con->local_mtu = in_mtu;
		opt_len += 4;
	}

	if (flush_timeout != 0) {
		/* We inform peer about our flush timeout */
		
		/* FIXME -- who controls this ? Upper layer ? */
		opt_len +=4;
	}
	
	if (outflow != NULL) {
		/* We inform peer about our QOS settings */
		opt_len += sizeof *outflow + 2; /* include type/len */
	}
	
	payload_len = SIGCMD_HDRSIZE + CONF_REQSIZE + opt_len;  
 
	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);
  
	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	req = (sig_confreq*)(l2cap_buf->frame + L2CAP_HDRSIZE + SIGCMD_HDRSIZE);
	
	if (opt_len > 0) {
		/* if the negotiated mtu differs from the current, send it */
          
		opt = (struct l2cap_option*)(l2cap_buf->frame+L2CAP_HDRSIZE + 
			SIGCMD_HDRSIZE + CONF_REQSIZE);
 
		if (in_mtu != 0) {
			DSYS("Sending in_mtu %d\n", in_mtu);
			opt->type = OPT_MTU;
			opt->len = 2;
			*(opt->option_data) = (u8)(in_mtu & 0x00ff);
			*(opt->option_data+1) = (u8)(in_mtu >> 8) & 0x00ff;
	
			/* forward pointer for other options */
			opt = (struct l2cap_option*)((char *)opt + 4);
		}
		
		if (flush_timeout != 0) {
			DSYS("Sending flush_timeout %d\n", flush_timeout);
			opt->type = OPT_FLUSH;
			opt->len = 2;
			*(opt->option_data) = (u8)(flush_timeout & 0x00ff);
			*(opt->option_data+1) = (u8)(flush_timeout >> 8) &0x00ff;

			/* forward pointer for other options */
			opt = (struct l2cap_option*)((char *)opt + 4);
		}
		
		if (outflow != NULL) { 
			DSYS("Sending conf req outflow\n");
			print_flow(outflow);
			opt->type = OPT_QOS;
			opt->len = sizeof *outflow;
			memcpy((char*)opt+2, outflow, sizeof *outflow);
		}
	}

	/* Request header */
	req->dst_cid = cpu_to_le16(con->remote_cid); /* Sending end */
	req->flags = 0; /* Negotiate same as remote */

	/* Signalling header */
	cmd->code = SIG_CONFREQ;

        /* Don't increment ID if retransmission */
        if (con->timer.rtx_no == 0)
                cmd->id = set_id(con); /* Sets sig_id_sent in l2cap_con */
        else
                DSYS("RTX, use same ID\n");

	/* fixme -- wrong len field should be 2 more */

	cmd->len = cpu_to_le16(CONF_REQSIZE + opt_len);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased when lower
						      layers add header data */

	opt = (struct l2cap_option*)(l2cap_buf->frame+L2CAP_HDRSIZE + 
				     SIGCMD_HDRSIZE + CONF_REQSIZE);
	
	print_data("l2cap options: ", (char*)opt , opt_len);
#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
	/* start retransmission timer */
	start_rtx(con, RTX_TIMEOUT, RTX_ACTION_START_ERTX);
#endif
	return hci_send_data(tx);
}

s32 
l2cap_disconnect_req(l2cap_con *con)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_discreq *req;
	u16 payload_len;
 
	D_XMIT(__FUNCTION__ ": rcid %d\n", con->remote_cid);

	payload_len = SIGCMD_HDRSIZE + DISC_REQSIZE;  

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	req = (sig_discreq*)(l2cap_buf->frame + L2CAP_HDRSIZE + SIGCMD_HDRSIZE);

	/* Now fill in header fields */  
	req->dst_cid = cpu_to_le16(con->remote_cid);
	req->src_cid = cpu_to_le16(con->local_cid);

	cmd->code = SIG_DISCREQ;
        
        /* Don't increment ID if retransmission */
        if (con->timer.rtx_no == 0)
                cmd->id = set_id(con); /* Sets sig_id_sent in l2cap_con */
        else
                DSYS("RTX, use same ID\n");
        
	cmd->len = cpu_to_le16(DISC_REQSIZE);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len;

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
	/* start retransmission timer */
	start_rtx(con, RTX_TIMEOUT, RTX_ACTION_TERMINATE);
#endif
	return hci_send_data(tx);
}

s32 
l2cap_echo_req(l2cap_con *con, u8 *opt_data, u16 opt_len)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_echo_pkt *req;
	u16 payload_len;
	u16 hci_hdl = con->hci_hdl;

	payload_len = SIGCMD_HDRSIZE + sizeof(sig_echo_pkt) + opt_len;

	D_XMIT(__FUNCTION__ "\n");
	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);
  
	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	req = (sig_echo_pkt*)(l2cap_buf->frame + L2CAP_HDRSIZE +SIGCMD_HDRSIZE);
    
	/* Now fill in header fields */
	if (opt_len)
		memcpy(req->data, opt_data, opt_len);
  
	cmd->code = SIG_ECHOREQ;
	cmd->id = get_id();
  
	cmd->len = cpu_to_le16(opt_len);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = hci_hdl;
	tx->bc_flag = NO_BROADCAST;

        /* Increased when lower layers add header data */
	tx->cur_len = L2CAP_HDRSIZE + payload_len;

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
	start_rtx(con, RTX_TIMEOUT, RTX_ACTION_DISCONNECT);
#endif
        return hci_send_data(tx);
}

s32 
l2cap_echo_rsp(s32 hci_hdl, s32 id, u8 *opt_data, u16 opt_len)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_echo_pkt *rsp;
	u16 payload_len;

	D_XMIT(__FUNCTION__ "\n");

	payload_len = SIGCMD_HDRSIZE + opt_len;

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	} 

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	rsp = (sig_echo_pkt*)(l2cap_buf->frame + L2CAP_HDRSIZE +SIGCMD_HDRSIZE);
    
	/* Now fill in header fields */
	if (opt_len)
		memcpy(rsp->data, opt_data, opt_len);
  
	cmd->code = SIG_ECHORSP;
	cmd->id = id;
	cmd->len = cpu_to_le16(opt_len);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased as lower layers
						      add header data */  
	return hci_send_data(tx);
}

s32
l2cap_info_req(l2cap_con *con, u16 info_type)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_info_req *req;
	s32 payload_len;
	u16 hci_hdl = con->hci_hdl;

	payload_len = SIGCMD_HDRSIZE + sizeof(sig_info_req);

	D_XMIT(__FUNCTION__ "\n");

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);
  
	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	req = (sig_info_req*)(l2cap_buf->frame + L2CAP_HDRSIZE +SIGCMD_HDRSIZE);
	req->type = cpu_to_le16(info_type);
    
	cmd->code = SIG_INFOREQ;
	cmd->id = get_id();
	cmd->len = cpu_to_le16(sizeof(sig_info_req));

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased when lower
						      layers add header data */
#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
	start_rtx(con, RTX_TIMEOUT, RTX_ACTION_TERMINATE);
#endif
	return hci_send_data(tx);
}
 
s32 
l2cap_info_rsp(s32 hci_hdl, s32 id, u16 info_type, u8 *info_data, 
	       s32 info_len, s32 result)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_info_rsp *rsp;
	s32 payload_len;

	D_XMIT(__FUNCTION__ "\n");

	payload_len = SIGCMD_HDRSIZE + sizeof(sig_info_rsp) + info_len;

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE + payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	} 

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	rsp = (sig_info_rsp*)(l2cap_buf->frame + L2CAP_HDRSIZE +SIGCMD_HDRSIZE);

	rsp->type = cpu_to_le16(info_type);
	rsp->result = cpu_to_le16(result);	

	/* Now fill in header fields */
	if (info_len) {
		memcpy(rsp->infodata, info_data, info_len);
	}

	cmd->code = SIG_INFORSP;
	cmd->id = id;
	cmd->len = cpu_to_le16(sizeof(sig_info_rsp) + info_len);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased as lower layers
						      add header data */  
	return hci_send_data(tx);
}

s32 
l2cap_cmdrej(s32 hci_hdl, u8 reason, u8 *opt_data, s32 opt_len)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_cmdreject *cmdrej;
	u16 payload_len;

	payload_len = SIGCMD_HDRSIZE + sizeof(sig_cmdreject) + opt_len;

	D_XMIT(__FUNCTION__ ": %s\n", cmdrej_reason[reason]);

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}  

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	cmdrej = (sig_cmdreject*)(l2cap_buf->frame
				  + L2CAP_HDRSIZE + SIGCMD_HDRSIZE);
    
	/* Now fill in header fields */
	if (opt_len)
		memcpy(cmdrej->data, opt_data, opt_len);
  
	cmd->code = SIG_CMDREJECT;
	cmd->id = get_id();
	cmd->len = cpu_to_le16(sizeof(sig_cmdreject) + opt_len);

	/* FIXME: set the reason parameter */
	/* Ok. Does this work? (gjm) */
	cmdrej->reason = cpu_to_le16((u16)reason);
	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased when lower
						      layers add header data */
	return hci_send_data(tx);
}

/****************************/
/* l2cap response functions */
/****************************/

s32 
l2cap_connect_rsp(l2cap_con* con, u16 response, u16 status)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_conrsp *rsp;
	u16 payload_len;
  
	D_XMIT(__FUNCTION__ ": rcid:%d lcid:%d result:%d status:%d \n",
	       con->remote_cid, con->local_cid, response, status);

	payload_len = SIGCMD_HDRSIZE + CON_RSPSIZE;
  
	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	rsp = (sig_conrsp*)(l2cap_buf->frame + L2CAP_HDRSIZE + SIGCMD_HDRSIZE);
  
	/* Now fill in header fields */
	rsp->dst_cid = cpu_to_le16(con->local_cid); /* sending end */
	rsp->src_cid = cpu_to_le16(con->remote_cid); /* receiving end */

	if ((rsp->result = cpu_to_le16(response)) == RES_PENDING)
		rsp->status = cpu_to_le16(status);
	else {
		rsp->status = cpu_to_le16(STAT_NOINFO);
	}
	
	cmd->code = SIG_CONRSP;
	cmd->id = con->sig_id_rcv; /* Send back same id as received on req */
	cmd->len = cpu_to_le16(CON_RSPSIZE);

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased when lower
						      layers add header data */
	return hci_send_data(tx);  
}
 

s32 
l2cap_config_rsp(l2cap_con* con, u32 out_mtu, flow *in_flow, s32 result)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_confrsp *rsp;
	u16 payload_len;
	int opt_len = 0;
	struct l2cap_option *opt;

	D_XMIT(__FUNCTION__ ": rcid : %d, out_mtu: %d \n", 
	       con->remote_cid, out_mtu);

	/* If negative, the accepted options are sent back */
	if (result != RES_SUCCESS) {

		DSYS("Neg config rsp !\n");

		if (out_mtu != 0) {
			con->remote_mtu = out_mtu;
			opt_len += 4;
		}
		if (in_flow != NULL) {
			/* The accepted settings for incoming traffic */
			opt_len += sizeof *in_flow;
		}
	}

	payload_len = SIGCMD_HDRSIZE + CONF_RSPSIZE + opt_len;

	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + 
			      L2CAP_HDRSIZE + payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	rsp = (sig_confrsp*)(l2cap_buf->frame + L2CAP_HDRSIZE + 
			     SIGCMD_HDRSIZE);

	/* Now fill in header fields */  
	rsp->src_cid = cpu_to_le16(con->remote_cid);
	rsp->flags = con->remote_flags;
	rsp->result = cpu_to_le16((u16)result);

	/* Include unaccepted options if any */
	if (opt_len) {
		opt = (struct l2cap_option*)((u8*)rsp + CONF_RSPSIZE);

		if (out_mtu != 0) {
			DSYS("Sending out_mtu %d\n", out_mtu);
			opt->type = OPT_MTU;
			opt->len = 2;
			opt->option_data[0] = (u8)(out_mtu & 0x00ff);
			opt->option_data[1] = (u8)(out_mtu >> 8) & 0x00ff;
	
			/* forward pointer for other options */
			opt = (struct l2cap_option*)((char *)opt + 4);
		}
		
		if (in_flow != NULL) { 
			DSYS("Sending conf req in_flow\n");
			print_flow(in_flow);
			opt->type = OPT_QOS;
			opt->len = sizeof *in_flow;
			memcpy((char*)opt->option_data, in_flow, sizeof *in_flow);
		}
		print_data("options: ", (u8*)rsp + CONF_RSPSIZE, opt_len);
	}
	
	cmd->code = SIG_CONFRSP;
	cmd->id = con->sig_id_rcv; /* Send back same id as received on 
				      request */

	cmd->len = cpu_to_le16(CONF_RSPSIZE + opt_len);
	
	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	
	/* Increased when lower layers add header data */
	tx->cur_len = L2CAP_HDRSIZE + payload_len;

	PRINTPKT("config rsp: ", (u8*)l2cap_buf,
		 L2CAP_HDRSIZE + payload_len);
	return hci_send_data(tx);
}

s32 
l2cap_disconnect_rsp(l2cap_con* con /*FIXME - , u16 status*/)
{
	bt_tx_buf *tx; 
	l2cap_tx_buf *l2cap_buf;  /* Entire l2cap frame + lower layer hdrs */
	sig_cmd *cmd;
	sig_discrsp *rsp;
	u16 payload_len;
 
	payload_len = SIGCMD_HDRSIZE + sizeof(sig_discrsp);

	D_XMIT(__FUNCTION__ ": rcid %d\n", con->remote_cid);
	tx = subscribe_bt_buf(sizeof(l2cap_tx_buf) + L2CAP_HDRSIZE+payload_len);
	if (!tx) {
		D_ERR(__FUNCTION__ ": didn't get a valid tx buf\n");
		return -ENOMEM;
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	cmd = (sig_cmd*)(l2cap_buf->frame + L2CAP_HDRSIZE);
	rsp = (sig_discrsp*)(l2cap_buf->frame + L2CAP_HDRSIZE + SIGCMD_HDRSIZE);
    
	/* Now fill in header fields */
	rsp->dst_cid = cpu_to_le16(con->local_cid);
	rsp->src_cid = cpu_to_le16(con->remote_cid);
  
	cmd->code = SIG_DISCRSP;
	cmd->id = con->sig_id_rcv; /* Send back same id as received on req */
	cmd->len = cpu_to_le16(sizeof(sig_discrsp));

	SET_L2CAP_HDR(l2cap_buf->frame, payload_len, CIDSIG);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;
	tx->cur_len = L2CAP_HDRSIZE + payload_len; /* Increased when lower
						      layers add header data */
	return hci_send_data(tx);
}
 
/*******************************************************************/
/* (A3) l2cap to l2cap data transmission */
/*****************************************/
 
s32 
l2cap_send_data(bt_tx_buf *tx, l2cap_con *con)
{
	l2cap_tx_buf *l2cap_buf;

	if (PARANOIA_CHECKCON(con)) {
		D_ERR(__FUNCTION__ ": Paranoia check failed\n");
		tx->flushed = 1; /* flush this buffer */
		return -EINVAL;
	}

	D_XMIT(__FUNCTION__ ": hdl : %d, rcid : %d, len:%d \n",
	       con->hci_hdl, con->remote_cid, tx->cur_len);

	if (tx->cur_len > con->remote_mtu) {
		D_ERR("%s tries to send more than remote mtu, ignore\n", 
		      psm2str(con->psm));
		D_ERR(__FUNCTION__ ": Flushing this buffer\n");
		tx->flushed = 1;
		return -MSGCODE(MSG_LAYER_L2CAP, L2CAP_EXCEED_REMOTE_MTU);
	}

	/* Only send on an OPEN channel */
	if (con->current_state != OPEN) {
		D_ERR(__FUNCTION__ ": not in open state\n");
		D_ERR(__FUNCTION__ ": Flushing this buffer\n");
		tx->flushed = 1;
		return -MSGCODE(MSG_LAYER_L2CAP, L2CAP_INVALID_STATE);
	}

	l2cap_buf = (l2cap_tx_buf *)(tx->data);

	SET_L2CAP_HDR(l2cap_buf->frame, tx->cur_len, con->remote_cid);

	/* pb_flag is set from hci_send_data */
	tx->hci_hdl = con->hci_hdl;
	tx->bc_flag = NO_BROADCAST;

	tx->cur_len += L2CAP_HDRSIZE; /* At this stage cur_len indicates
				       payload len of l2cap i.e an entire
				       frame of upper layers*/

	PRINTPKT(__FUNCTION__ ": ", l2cap_buf->frame, tx->cur_len);

	return hci_send_data(tx);
}

/*******************************************************************/
/* (A4) l2cap to upper layers */
/*****************************/

void 
l2ca_connect_ind(l2cap_con *con) 
{
	D_STATE(__FUNCTION__ ": remote cid : %d psm 0x%x\n", 
		con->remote_cid, con->psm);

	if (get_upper(con->psm) == &default_protocol) {
		D_STATE(__FUNCTION__ ": PSM not registered\n");
		l2ca_connect_rsp(con, RES_PSMNEG, STAT_NOINFO);
		return;
	}
  
	get_upper(con->psm)->con_ind(con);
}

void 
l2ca_connect_pnd(l2cap_con *con, s32 status)
{
	D_STATE(__FUNCTION__ ": rCID %d, status %d\n", 
		con->remote_cid, status);
	
	if (!con->initiator) { 
                D_ERR(__FUNCTION__": server is not initiator !\n"); 
                return;
	}
	
	con->c_result = L2CAP_CON_PENDING;
	
	get_upper(con->psm)->con_pnd(con, status); 
}

void 
l2ca_connect_cfm(l2cap_con *con, s32 result)
{
	D_STATE(__FUNCTION__ ": rCID %d, result %d\n", 
		con->remote_cid, result);
	
	if (!con->initiator) { 
                D_ERR(__FUNCTION__ ": server is not initiator !\n"); 
                return;
	}

	get_upper(con->psm)->con_cfm(con, result); 
}

void 
l2ca_config_ind(l2cap_con* con)
{  
	D_STATE(__FUNCTION__ ": remote cid : %d\n", con->remote_cid); 
  
	get_upper(con->psm)->conf_ind(con); 
}

/* according to spec this could be sent to upper layers after 
   receiving a config req but some stacks send their conf req 
   before sending their response we don't send cfm upwards
   until we really reached OPEN state. */
void 
l2ca_config_cfm(l2cap_con *con, s32 result)
{
	D_STATE(__FUNCTION__ ": remote cid : %d result %d\n", 
		con->remote_cid, result);

	get_upper(con->psm)->conf_cfm(con, result); 
}

void 
l2ca_disconnect_ind(l2cap_con *con)
{
	D_STATE(__FUNCTION__ "\n");

	get_upper(con->psm)->disc_ind(con);
}

void
l2ca_disconnect_cfm(l2cap_con *con)
{
	D_STATE(__FUNCTION__ ": remote cid : %d\n", con->remote_cid);

	/* tell upper layers that connection is down */
	get_upper(con->psm)->disc_cfm(con);

	ENTERSTATE(con, CLOSED);
	PRINTSTATE(con);

	DSYS("l2cap channel (%d,%d) [%s] disconnected\n", 
	     con->local_cid, con->remote_cid, psm2str(con->psm));
}

s32 l2ca_ping(BD_ADDR bd, u8 *opt_data, u16 len)
{
	l2cap_con *con;
	s32 i, retval = 0;
	u8 rev_bd[6];

	D_XMIT("Sending ping\n");
	print_data("Ping destination: bd ", bd, 6);

	/* bd is big endian, reverse byte order to little endian */
	for (i = 0; i < 6; i++) {
		rev_bd[5-i] = bd[i];
	}
	
	con = get_con(rev_bd, ANY_STATE);

	if (con == NULL) {
		D_STATE(__FUNCTION__ ": create new baseband link\n");
		con = create_con(0/* not yet set */, 
				 get_cid(), 0/* not yet set */);
		if (con == NULL) {
			D_ERR(__FUNCTION__ ": no connection created");
			return -ENOMEM;
		}

		memcpy(con->remote_bd, rev_bd, 6);
		con->link_up = 0;
		con->initiator = 1;
		insert_con(con);

		/* c_flags used to not try to connect l2cap when 
		 lp_connect_cfm arrives */
		con->c_flags |= FLAG_RETURNNOW;

		retval = lp_connect_req(con->remote_bd);
		if(retval < 0) {
			D_ERR(__FUNCTION__ ": lp_connect_req failed (status %d)\n", retval);
			return retval;
		}

		/* wait here until we received a lp_connect_cfm */
		l2ca_wait(__FUNCTION__ ": wait baseband", con);
		
		if (con->c_status == RES_SUCCESS) {
			/* check status */
			D_XMIT("Now we got baseband, send echo req !\n");
		} else {
			D_ERR(__FUNCTION__ ": lp_connect_req failed, no connection (status %d)\n", con->c_status);
			retval = -MSGCODE(MSG_LAYER_HCI, con->c_status);
			delete_con(con);
			return retval;
		}
	}

	/* Now send echo req */	

	con->c_status = CSTATUS_RTX_TIMEOUT;

	/* leave loop when either status failed or success */
	while (con->c_status == CSTATUS_RTX_TIMEOUT) {
		D_XMIT("Sending echo req...\n");
		l2cap_echo_req(con, opt_data, len);	

		/* wait until we received a response or after timeout */

		D_XMIT("Waiting for response or timeout\n");

		l2ca_wait(__FUNCTION__ ": wait echo resp", con);
	}

	if (con->c_status == CSTATUS_MAX_NO_RTX) {
		/* max number reached, try to disconnect */
		retval = l2ca_disconnect_req(con);
	}

	return retval;
}

s32 l2ca_getinfo(BD_ADDR bd, u16 infotype)
{
	l2cap_con *con;
	s32 i ;
	u8 rev_bd[6];
	s32 retval = 0;
	
	D_XMIT("Sending GetInfo : type 0x%x\n", infotype);

	/* bd is big endian, reverse byte order to little endian */
	for (i = 0; i < 6; i++) {
		rev_bd[5-i] = bd[i];
	}
	
	con = get_con(rev_bd, ANY_STATE);

	if (con == NULL) {
		D_STATE(__FUNCTION__ ": create new baseband link\n");
		con = create_con(0/* not yet set */, 
				 get_cid(), 0/* not yet set */);
		if (con == NULL) {
			D_ERR(__FUNCTION__ ": no connection created");
			return -ENOMEM;
		}

		memcpy(con->remote_bd, rev_bd, 6);
		con->link_up = 0;
		con->initiator = 1;
		insert_con(con);

		/* c_flags used to not try to connect l2cap when 
		 lp_connect_cfm arrives */
		con->c_flags |= FLAG_RETURNNOW;

		retval = lp_connect_req(con->remote_bd);
		if(retval < 0) {
			D_ERR(__FUNCTION__ ": lp_connect_req failed (status %d)\n", retval);
			delete_con(con);
			return retval;
		}

		/* wait here until we received a lp_connect_cfm */
		l2ca_wait(__FUNCTION__ ": wait baseband", con);
		
		if (con->c_status == RES_SUCCESS) {
			/* check status */
			D_XMIT("Now we got baseband, send info req !\n");
		} else {
			D_ERR(__FUNCTION__ ": lp_connect_req failed, no connection (status %d)\n", con->c_status);
			delete_con(con);
			return -MSGCODE(MSG_LAYER_HCI, con->c_status);
		}
	}

	/* Now send info req */	

	con->c_status = CSTATUS_RTX_TIMEOUT;

	/* leave loop when either status failed or success */
	while (con->c_status == CSTATUS_RTX_TIMEOUT) {
		D_XMIT("Sending info req...\n");
		retval = l2cap_info_req(con, infotype);
		if(retval < 0) {
			D_ERR(__FUNCTION__ ": l2cap_info_req failed (status %d)\n", retval);
			/* Timeout and then try again */
		}

		/* wait until we received a response or after timeout */
		l2ca_wait(__FUNCTION__ ": wait echo resp", con);
	}
	
	if (con->c_status == CSTATUS_MAX_NO_RTX && !retval) {
		retval = -MSGCODE(MSG_LAYER_L2CAP, L2CAP_RTX_TIMEOUT);
	}

	return retval;
}

/*******************************************************************/
/* (A5) setting timers */
/***********************/

/* used to resend lost l2cap commands */

#ifdef CONFIG_BLUETOOTH_L2CAP_USE_TIMERS

/* Action is used when the sending function doesn't want
   to handle the action it self */
void
start_rtx(l2cap_con *con, unsigned short timeout, u16 action)
{
	/* multiply by 2 each rtx */

	if (con->timer.rtx_no > 0)
		timeout = timeout*(2 << (con->timer.rtx_no - 1));

	/* FIXME -- use flush timeout to calculate number of
	   retransmissions */

	D_TIM("Starting RTX timer (%d sec)\n", timeout);

	/* fixme -- add timer list for multiple calls */
	if (con->timer.rtx_inuse) {
		D_ERR(__FUNCTION__ ": timer already used\n");
		return;
	}

#ifdef __KERNEL__	
	init_timer(&con->timer.rtx);
	con->timer.rtx.function = l2cap_rtx_timeout;
	con->timer.rtx.data = (unsigned long)con;
	con->timer.rtx.expires = jiffies + timeout*HZ;
	con->timer.rtx_inuse = 1;
	con->timer.rtx_action = action;
	add_timer(&con->timer.rtx);  

#else /* Usermode stack */

	/* FIXME */
	D_ERR("Use NO timer in usermode stack yet...\n");
	return;
#if 0
	struct itimerval t = {{0,0},{timeout, 0}};

	D_TIM("Starting RTX timer (%d sec)\n", timeout);

	if (timeout_con)
		D_ERR("Timer already in use !!!\n");

	timeout_con = con;

	signal(SIGALRM, (void*)l2cap_rtx_timeout);

	if (setitimer(ITIMER_REAL,&t,NULL) < 0)
		D_ERR("*** Setitimer ***\n");

	timer_cancelled = 0;
#endif

#endif /* __KERNEL__ */

}

void
disable_rtx(l2cap_con *con)
{
	D_TIM("Disabling RTX timer\n");
#ifdef __KERNEL__
	if (con->timer.rtx_inuse) {
		del_timer(&con->timer.rtx);
		con->timer.rtx_inuse = 0;
		con->timer.rtx_no = 0;
		con->timer.rtx_action = RTX_ACTION_DISCONNECT;
	} else
		D_TIM("RTX never started\n");
#else
	timer_cancelled = 1;
	timeout_con = NULL;
#endif
}


void
start_ertx(l2cap_con *con, unsigned short timeout)
{
	D_TIM("Starting ERTX timer (%d sec)\n", timeout);

	if (con->timer.ertx_inuse) {
		D_TIM(__FUNCTION__ ": timer already used\n");
		return;
	}

#ifdef __KERNEL__
	init_timer(&con->timer.ertx);
	con->timer.ertx.function = l2cap_ertx_timeout;
	con->timer.ertx.data = (unsigned long)con;
	con->timer.ertx.expires = jiffies + timeout*HZ;
	con->timer.ertx_inuse = 1;
	add_timer(&con->timer.ertx);
#else
	/* fixme */
	con->timer.ertx_inuse = 1;
#endif
}

void
disable_ertx(l2cap_con *con)
{
	D_TIM("Disabling ERTX timer\n");
#ifdef __KERNEL__
	if (con->timer.ertx_inuse) {
		del_timer(&con->timer.ertx);
		con->timer.ertx_inuse = 0;
		con->timer.ertx_action = ERTX_ACTION_DISCONNECT;
	} else
		D_TIM("ERTX never started\n");
#else /* Usermode stack */
        /* FIXME */
        D_ERR("disable_ertx FIXME\n");
	con->timer.ertx_inuse = 0;
	con->timer.ertx_action = ERTX_ACTION_DISCONNECT;
#endif
}
#endif /* CONFIG_BLUETOOTH_L2CAP_USE_TIMERS */

/***************************************************************/
/*--------------------- MISCELLANEOUS ------------------------ */
/***************************************************************/

s32 l2ca_opened(l2cap_con *con)
{
	return (con->current_state==OPEN);
}

s32 l2ca_remote_conf_done(l2cap_con *con)
{
	return con->conf_rsp_ready;
}

s32 l2ca_local_conf_done(l2cap_con *con)
{
	return con->conf_req_ready;
}

/* Parse and set remote options in l2cap con */
s32 
parse_options(l2cap_con *con, u8 *data, u32 len)
{
	u32 pos = 0;
	l2cap_option *opt;
	s32 found_option = 0;

	D_RCV(__FUNCTION__ ": Storing remote options on rCID %d\n", 
	      con->remote_cid);

	PRINTPKT(__FUNCTION__ ": ", data, len);

	while (pos < len) {
		opt = (l2cap_option*)(data + pos);
		switch (opt->type) {
		case OPT_MTU:
			con->remote_mtu = *(opt->option_data) | 
				(*(opt->option_data + 1) << 8);

			D_RCV("Setting remote mtu (%d:%d) to %d bytes\n",
			      con->local_cid, con->remote_cid, 
			      con->remote_mtu);

			DSYS("Setting remote mtu (%d:%d) to %d bytes\n",
			      con->local_cid, con->remote_cid, 
			      con->remote_mtu);
			found_option = 1;
			break;
      
		case OPT_FLUSH:
			con->flush_timeout = *(opt->option_data) | 
				(*(opt->option_data + 1) << 8);

			/* FIXME -- return error code if not accepted */
			
			D_RCV(__FUNCTION__ ": flush timeout %d ms\n", 
			      con->flush_timeout);

			found_option = 1;
			break;
      
		case OPT_QOS:
			memcpy((u8*)&con->remote_qos, opt->option_data, 
			       sizeof(struct flow));
			
			/* FIXME -- return error code if not accepted */

			D_RCV(__FUNCTION__ ": qos\n");
			print_flow(&con->remote_qos);
			found_option = 1;
			break;
      
		default:
			D_RCV(__FUNCTION__ ": Invalid type !\n");
			break;
		}
		pos += opt->len + 2; /* 2 bytes header */
	}

	if (!found_option)
		D_WARN(__FUNCTION__ ": found NO valid options !\n");
	
	return RES_SUCCESS;
}

/* 
   Enter ID in IDlist when sending the request 
   When receiving response check id against registered l2cap_con->sig_id_sent
*/

/* Sets id and returns value */
u8 
set_id(l2cap_con* con)
{
	if (l2cap->id_count > 255) /* Wrap */
		l2cap->id_count = 0;

	return con->sig_id_sent = l2cap->id_count++;
};

s32 
id_matched(l2cap_con* con, u8 rcv_id)
{
	return (con->sig_id_sent == rcv_id);
}

/* Get id and returns value */
u8 get_id()
{
	if (l2cap->id_count > 255) /* Wrap */
		l2cap->id_count = 0;
	return l2cap->id_count++;
};

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

s32 l2cap_sprint_bd(u8 *buf, BD_ADDR bd) 
{
	/* stored in little endian format */
	return sprintf(buf, "%02x:%02x:%02x:%02x:%02x:%02x", 
		       bd[5], bd[4], bd[3], bd[2], bd[1], bd[0]);
}

s32 l2cap_sprint_status(u8 *buf)
{
	u16 pos = 0;

	pos += sprintf(buf+pos, "\n[L2CAP]\n\n");
	/* This device bd address */
	pos += sprintf(buf+pos, "local bd :[");
	pos += l2cap_sprint_bd(buf+pos, l2cap->my_bd);
	pos += sprintf(buf+pos, "]\n");
	/* print active connections */
	pos += l2cap_sprint_active(buf+pos);
	pos += sprintf(buf+pos,"\n");

	/* other stuff ... */

	return pos;
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

void 
print_flow(flow *f)
{
	if (f == NULL) {
		printk("   flow: NULL\n");
		return;
	} else {
		printk("   flow:\n");
		printk("   flags:%d service: 0x%x token_rate: 0x%d\n",
		       f->flags, f->service, (unsigned int) f->token_rate);
		printk("   bucket_size:%d bytes peak:%d bps latency:%d ms delay:%d ms\n",
		       (unsigned int)f->bucket_size, (unsigned int)f->peak, 
		       (unsigned int)f->latency, (unsigned int)f->delay);
	}
}
/* Returns a free cid in range 0x0040 - 0xffff */
/* FIXME - search from MIN_CID every time ? */
u16 get_cid(void)
{
	CID cid;
	s32 i = 0;

	while (1) {
		if (l2cap->cid_count == MAX_CID)
			l2cap->cid_count = MIN_CID;

		cid = l2cap->cid_count++;
		if (get_lcon(cid) == NULL) /* free CID */
			return cid;  
		else if (i == MAX_CID)
			return 0;
		i++;
	}
}

/****************** END OF FILE l2cap.c *************************************/
