
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>
#include <linux/string.h>
#include <linux/types.h>
#include <linux/delay.h>

#include <asm/byteorder.h>
#include <asm/unaligned.h>

#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/bcsp.h>
#include <linux/bluetooth/bcsp_debug.h>
#else
#include <stdlib.h>
#include <errno.h>

#include <asm/unaligned.h>

#include "include/btcommon.h"
#include "include/bluetooth.h"
#include "include/hci.h"
#include "include/bcsp.h"
#include "include/bcsp_debug.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#if BCSP_DEBUG
#define D(fmt...) printk("BCSP:      "fmt)
#define BCSPDUMP(data, len) print_data(__FUNCTION__, data, len)
#else
#define D(fmt...)
#define BCSPDUMP(data, len)
#endif

#define BCSP_OCF 0

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

void bcsp_sync_timeout(unsigned long ptr);
extern void csr_waitcmdnum(void);

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

#ifdef __KERNEL__
static struct timer_list bcsp_sync_timer;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
static wait_queue_head_t bcsp_sync_wq;
#else
static struct wait_queue *bcsp_sync_wq = NULL;
#endif
static u32 bcsp_sync = FALSE;

/****************** FUNCTION DEFINITION SECTION *****************************/

/*                 -----------------------
 *                 | The Bluetooth stack |
 *                 -----------------------
 *       ---------------------------------------------
 * TOP   | bcsp_receive_top()  |  bcsp_write_top()   |
 *       ---------------------------------------------
 *                ^                       |
 *                |                       V
 *                     THE BCSP STACK
 *           -----------------------------------
 *           | bcsp_datagram.c bcsp_sequence.c |
 *           |           bcsp_mux.c            |
 *           |   bcsp_integrity.c (uses crc.c) |
 *           |           bcsp_slip.c           |
 *           -----------------------------------
 *                ^                       |
 *                |                       V
 *        --------------------------------------------
 * BOTTOM | bcsp_receive_lower()| bcsp_write_lower() |
 *        --------------------------------------------
 *                        "The UART driver"
 */

s32
bcsp_init(void)
{
	DSYS("Initializing BCSP\n");
	
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	init_waitqueue_head(&bcsp_sync_wq);
#endif

	bcsp_datagram_init();
	bcsp_sequence_init();
	
	/* Start sync status timer */

#ifdef __KERNEL__
	init_timer(&bcsp_sync_timer);
	bcsp_sync_timer.function = bcsp_sync_timeout;
	bcsp_sync_timer.data = 0;
	bcsp_sync_timer.expires = jiffies + 5*HZ;
	add_timer(&bcsp_sync_timer);
#endif

	/* Start syncing */
	bcsp_send_sync(SYNC);

	cli();
	if (!bcsp_sync) {
		interruptible_sleep_on(&bcsp_sync_wq);
	}
	sti();

	/* notify bt driver that sync failed */
	if (!bcsp_sync) {
		return -1;
	} else if (!bt_dfu_mode(-1)) {
		csr_waitcmdnum(); /* Wait for command status */
	}
	return 0;	
}

void
bcsp_shutdown(void)
{
	DSYS("Shutting down BCSP\n");
	bcsp_datagram_shutdown(); /* choke datastream */
	bcsp_sequence_shutdown();
	bcsp_sync = FALSE;
}

void 
bcsp_sync_timeout(unsigned long ptr)
{
	D_ERR(__FUNCTION__": sync failed\n");
	wake_up_interruptible(&bcsp_sync_wq);
}

u32 
bcsp_issyncronized(void)
{
  return bcsp_sync;
}


void
bcsp_syncronized(void)
{
	cli();
	bcsp_sync = TRUE;
	sti();

#ifdef __KERNEL__
	del_timer(&bcsp_sync_timer);
#endif

	DSYS("BCSP initialized and syncronized\n");
	wake_up_interruptible(&bcsp_sync_wq);
}

s32
bcsp_receive_top(u8 *data, u32 len, u8 chn)
{
	switch(chn) {
	case BCSP_BCCMD_CHN:
		hci_receive_bcsp(data, len);
		break;
	case BCSP_HQ_CHN:
		hci_receive_hq(data, len);
		break;
	case BCSP_EVT_CHN:
		hci_receive_event(data, (s32)len);
		break;
	case BCSP_ACL_CHN:
		hci_receive_acl(data, (s32)len);
		break;
	case BCSP_DFU_CHN:
		hci_receive_dfu(data, len);
		break;
	default:
		D_ERR(__FUNCTION__ ": Unknown channel: %d\n", chn);
		break;
	}
	return 0;
}

s32
bcsp_receive_lower(u8 *data, u32 len)
{
	s32 handled = 0;

	D(__FUNCTION__ ": Incoming data:\n");

	BCSPDUMP(data, len);

	while (handled < len) {
		handled += bcsp_slip_receive(data + handled, len - handled);
		D(__FUNCTION__ ": So far handled: %d bytes\n", handled);
	}
	return 0;
}

s32
bcsp_write_top(u8 *data, u32 len)
{
	u16 opcode;
	s32 ret = -EINVAL;
	
	switch (data[0]) {
	case CMD_PKT:
		opcode = le16_to_cpu(get_unaligned((u16 *)&data[1]));
		if (hci_get_ocf(opcode) == BCSP_OCF) {
			ret = bcsp_sequence_send(data + 5, len - 5, data[4] & 0x3f);
		} else {
			ret = bcsp_sequence_send(data + 1, len - 1, BCSP_CMD_CHN);
		}
		break;
	case ACL_PKT:
		ret = bcsp_sequence_send(data + 1, len - 1, BCSP_ACL_CHN);
		break;
	case SCO_PKT:
		ret = bcsp_sequence_send(data + 1, len - 1, BCSP_SCO_CHN);
		break;
	default:
		D_ERR(__FUNCTION__ ": Unknown packet type: 0x%x\n", data[0]);
		break;
	}

	return ret;
}

s32
bcsp_write_lower(u8 *data, u32 len)
{
	D(__FUNCTION__ ": Outgoing data:\n");

	BCSPDUMP(data, len);

	return bt_write_lower_driver_real(data, len);
}

void
bcsp_init_packet(struct bcsp *bcsp)
{
	memset(bcsp, 0, sizeof *bcsp);
};

/****************** END OF FILE bcsp.c **************************************/
