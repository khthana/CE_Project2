
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/config.h>
#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/malloc.h>
#include <linux/timer.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/hci_internal.h>
#include <linux/bluetooth/btdebug.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/btmem.h>
#include <linux/delay.h>
#include <linux/interrupt.h>

#else /* user mode */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "include/bluetooth.h"
#include "include/hci.h"
#include "include/hci_internal.h"
#include "include/btdebug.h"
#include "include/btmem.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#ifdef CONFIG_BLUETOOTH_ERICSSON
/* Ericsson defines */
#define ERICSSON_SET_UART_BAUD_RATE        0x09
#define ERICSSON_WRITE_BD_ADDR             0x0D
#define ERICSSON_READ_REVISION_INFORMATION 0x0F

#define ERICSSON_ENTER_TEST_MODE           0x11
#define ERICSSON_TEST_CONTROL              0x12
#define ERICSSON_TX_TEST                   0x19
#endif

#ifdef CONFIG_BLUETOOTH_DIGIANSWER
/* Digianswer defines */
#endif

#define BT_HW_INFO_MAX 255

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/* These are declared in hci.c */
extern cmd_pkt c_pkt;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
extern struct wait_queue *hci_wq;
extern struct wait_queue *set_baudrate_wq;
#else
extern wait_queue_head_t hci_wq;
extern wait_queue_head_t set_baudrate_wq;
#endif /* LINUX_VERSION_CODE */

extern hci_controller hci_ctrl;

static u8 bt_hw_firmware_info[BT_HW_INFO_MAX+1];

/****************** FUNCTION DEFINITION SECTION *****************************/

#ifdef CONFIG_BLUETOOTH_ERICSSON
/*****************************************************************************/
/********************** Ericsson functions ***********************************/
/*****************************************************************************/

#define VENDOR " [Ericsson]"

s32 
hci_set_bd_addr(u8 bd[6])
{
	u8 tmp_bd[6];
	s32 i;
  
	D_CMD(__FUNCTION__ VENDOR "\n");

	for (i = 0; i < 6; i++) {
		tmp_bd[5-i] = bd[i];
	}
  
	PRINTPKT(__FUNCTION__ VENDOR ":", bd, 6);
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ERICSSON_WRITE_BD_ADDR, MANUFACTURER_SPEC);
	c_pkt.len = 6;
	memcpy(c_pkt.data, tmp_bd, 6);

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}
 
s32
hci_read_firmware_rev_info(void)
{
	D_CMD(__FUNCTION__ VENDOR "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ERICSSON_READ_REVISION_INFORMATION, MANUFACTURER_SPEC);
	c_pkt.len = 0;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

s32 
hci_set_baudrate(u32 baudrate)
{
	/* Due to the fact that the Ericsson module after P9A sends the reply
	   on the new baudrate, this function can not block (Since btd sets the
	   new physical device speed when this function returns). */  

	D_CMD(__FUNCTION__ VENDOR " (%u baud)\n", baudrate);
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ERICSSON_SET_UART_BAUD_RATE, MANUFACTURER_SPEC);
	c_pkt.len = 1;
	switch (baudrate) {
	case 9600:
		c_pkt.data[0] = 0x14;
		break;
	case 14400:
		c_pkt.data[0] = 0x05;
		break;
	case 19200:
		c_pkt.data[0] = 0x13;
		break;
	case 28800:
		c_pkt.data[0] = 0x04;
		break;
	case 38400:
		c_pkt.data[0] = 0x12;
		break;
	case 57600:
		c_pkt.data[0] = 0x03;
		break;
	case 115200:
		c_pkt.data[0] = 0x02;
		break;
	case 230400:
		c_pkt.data[0] = 0x01;
		break;
	case 460800:
		c_pkt.data[0] = 0x00;
		break;
	default:
		D_ERR(__FUNCTION__ VENDOR  ": Baudrate not supported\n");
		return -EINVAL;
	}

#ifdef CONFIG_BLUETOOTH_SET_BAUDRATE_BLOCKING
	send_cmd_block((u8*) &c_pekt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
#else
	if (hci_ctrl.hc_buf.cmd_num < 1) {
		DSYS(__FUNCTION__ VENDOR  ": sleeping\n");
		interruptible_sleep_on(&set_baudrate_wq);
	}
	bt_write_lower_driver((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
  
	hci_ctrl.hc_buf.cmd_num--;
#endif
	/* We don't really know if the card accepted the change, but we did
	   succeed in trying to send it. --gmcnutt */
	return 0;
}

void
process_vendor_return_param(u32 ocf, u8* r_val)
{
	switch (ocf) {
	case 0x04:
		D_CMD(__FUNCTION__ VENDOR " Synth on set\n");
		release_cmd_timer();
		wake_up_interruptible(&hci_wq);
		break;
    
	case ERICSSON_SET_UART_BAUD_RATE:
		D_CMD(__FUNCTION__ VENDOR " baudrate set\n");
#ifdef CONFIG_BLUETOOTH_SET_BAUDRATE_BLOCKING
		release_cmd_timer();
		wake_up_interruptible(&hci_wq);
#endif
		break;

	case ERICSSON_WRITE_BD_ADDR:
		D_CMD(__FUNCTION__ VENDOR " BD_ADDR set\n");
		release_cmd_timer();
		wake_up_interruptible(&hci_wq);
		break;
    
	case ERICSSON_READ_REVISION_INFORMATION:
		release_cmd_timer();
		printk("Ericsson HW revision info: %s\n\n", r_val + 1);
    
		/* Store this for later retrieval */
		strncpy(bt_hw_firmware_info, r_val + 1, BT_HW_INFO_MAX);
		bt_hw_firmware_info[BT_HW_INFO_MAX] = '\0';

		wake_up_interruptible(&hci_wq);
		break;
    
	case ERICSSON_ENTER_TEST_MODE:
		release_cmd_timer();
		if (r_val[0]) {
			D_ERR(__FUNCTION__ VENDOR " ENTER_TEST_MODE %s\n",
			      get_err_msg(r_val[0]));
		}
		wake_up_interruptible(&hci_wq);
		break;
    
	case ERICSSON_TEST_CONTROL:
		release_cmd_timer();
		if (r_val[0]) {
			D_ERR(__FUNCTION__ VENDOR " TEST_CONTROL %s\n",
			      get_err_msg(r_val[0]));
		}
		wake_up_interruptible(&hci_wq);
		break;
    
	case ERICSSON_TX_TEST:
		release_cmd_timer();
		if (r_val[0]) {
			D_ERR(__FUNCTION__ VENDOR " TX_TEST %s\n", get_err_msg(r_val[0]));
		}
		wake_up_interruptible(&hci_wq);
		break;
    
	default:
		release_cmd_timer();
		D_ERR(__FUNCTION__ VENDOR " Manufacturer specific: Invalid reply (0x%x)\n", ocf);
		wake_up_interruptible(&hci_wq);
		break;
	}
}

void
process_vendor_event(u8 *buf, u32 len, u32 event_code)
{
	D_ERR(__FUNCTION__ VENDOR " Vendor specific event not recognized.\n");
}

char*
bt_hw_vendor(void)
{
	return "Ericsson";
}

#elif defined(CONFIG_BLUETOOTH_DIGIANSWER)
/*****************************************************************************/
/************************* Digianswer functions ******************************/
/*****************************************************************************/

#define VENDOR " [Digianswer]"

s32 
hci_set_bd_addr(u8 bd[6])
{
	D_ERR(__FUNCTION__ VENDOR " not supported.\n");
	return 0;
}

s32
hci_read_firmware_rev_info(void)
{
	D_ERR(__FUNCTION__ VENDOR " not supported.\n");
	return 0;
}

s32 
hci_set_baudrate(u32 baudrate)
{
	u8 pkt[5];
	s32 tmp;

	D_CMD(__FUNCTION__ VENDOR " (%u baud)\n", baudrate);
	pkt[0] = CMD_PKT;
	pkt[1] = 0x07;
	pkt[2] = 0xfc;
	pkt[3] = 0x01;
	switch (baudrate) {
	case 9600:
		pkt[4] = 0x03;
		break;
	case 19200:
		pkt[4] = 0x05;
		break;
	case 38400:
		pkt[4] = 0x07;
		break;
	case 57600:
		pkt[4] = 0x09;
		break;
	case 115200:
		pkt[4] = 0x09;
		break;
	}
	tmp = send_cmd(pkt, 5);
  
	start_cmd_timer();
	interruptible_sleep_on(&hci_wq);
  
	return tmp;
}


u8*
get_digi_err_code(u8 code)
{
	switch (code) {
	case 0x01:
		return "The data packet is too large, No valid packet types\n";
    
	case 0x02:
		return "The data packet is too large, Max slots exceeded\n";
    
	case 0x10:
		return "No connection for data. The connection handle specified by the data packet is not in use\n";
    
	case 0x20:
		return "The UCP2 synchronization signal is not right\n";
    
	case 0xFF:
		return "Unspecified error\n";
    
	default:
		return "Unkown error digianswer code\n";
	}
}

void
process_vendor_event(u8 *buf, u32 len, u32 event_code)
{
	D_REC(__FUNCTION__ VENDOR "\n");
	if (len == 0x01) {
		D_REC(__FUNCTION__ VENDOR " RESET REQUEST EVENT\n");
	} else {			
		printk(get_digi_err_code(buf[0]));
	}
}

void
process_vendor_return_param(u32 ocf, u8* r_val)
{
	switch (ocf) {
	case 0x07:
		D_CMD(__FUNCTION__ VENDOR " baudrate set\n");
		release_cmd_timer();
		wake_up_interruptible(&hci_wq);
		break;
    
	default:
		D_ERR(__FUNCTION__ VENDOR " Manufacturer specific: Invalid reply (0x%x)\n", ocf);
		break;
	}
}

char*
bt_hw_vendor(void)
{
	return "Digianswer";
}

#if RS232_SUPPORT
s32 
send_negotiation_pkt(void)
{
	u8 pkt[8];
	D_CTRL(__FUNCTION__ VENDOR "\n");
	pkt[0] = NEG_PKT;
	pkt[1] = seq_nbr;
	seq_nbr++;
	pkt[2] = SET_UART(0x0, 0x0, 0x0, 0xb);
	pkt[3] = SET_BAUD_RATE(115200) & 0xff;
	pkt[4] = (SET_BAUD_RATE(115200) >> 8) & 0xff;
	pkt[5] = 10; /*?!? Try with this ?!?*/
	pkt[6] = 0;
	pkt[7] = SET_PROTOCOL_MODE(0, 0, 0, 1, 0, 0);
  
	return send_cmd(pkt, 8);
}
#endif

#elif defined(CONFIG_BLUETOOTH_CSR)

/*****************************************************************************/
/****************************** CSR functions ********************************/
/*****************************************************************************/

#define VENDOR " [CSR]"

#define CSR_CH_ID_BCCMD              0x02
#define CSR_CH_ID_HQ                 0x03

#define CSR_MSGTYPE_GETREQ           0x0000
#define CSR_MSGTYPE_GETRESP          0x0001
#define CSR_MSGTYPE_SETREQ           0x0002

#define CSR_STATUS_OK                0x0000
#define CSR_STATUS_NO_SUCH_VARID     0x0001
#define CSR_STATUS_TOO_BIG           0x0002
#define CSR_STATUS_NO_VALUE          0x0003
#define CSR_STATUS_BAD_REQ           0x0004
#define CSR_STATUS_NO_ACCESS         0x0005
#define CSR_STATUS_READ_ONLY         0x0006
#define CSR_STATUS_WRITE_ONLY        0x0007
#define CSR_STATUS_ERROR             0x0008
#define CSR_STATUS_PERMISSION_DENIED 0x0009

#define CSR_CMD_CONFIG_UART          0x6802
#define CSR_CMD_BUILD_ID             0x2819
#define CSR_CMD_CHIP_VER             0x281a
#define CSR_CMD_CHIP_REV             0x281b
#define CSR_CMD_PS                   0x7003

#define CSR_PS_BDADDR                0x0001
#define CSR_PS_MAX_ACL_PKT_LEN       0x0011
#define CSR_PS_MAX_ACL_PKTS          0x0013
#define CSR_PS_UART_CONFIG           0x0191
#define CSR_PS_BAUD_RATE             0x0204

#define CSR_UART_RATE_9K6            0x0027
#define CSR_UART_RATE_19K2           0x004f
#define CSR_UART_RATE_38K4           0x009d
#define CSR_UART_RATE_57K6           0x00ec
#define CSR_UART_RATE_115K2          0x01d8
#define CSR_UART_RATE_230K4          0x03b0
#define CSR_UART_RATE_460K8          0x075f
#define CSR_UART_RATE_921K6          0x0ebf

#define CSR_UART_ONE_STOP_BIT        0x0000
#define CSR_UART_TWO_STOP_BITS       0x2000

#define CSR_UART_NO_PARITY           0x0000
#define CSR_UART_ODD_PARITY          0x4000
#define CSR_UART_EVEN_PARITY         0xc000

#define CSR_VARID_RSSI_REPORT        0x0801
#define CSR_VARID_PACKET_STAT_REPORT 0x1001
#define CSR_VARID_BITERR_REPORT      0x1006

#define CSR_GET_CH_ID(msg)     GET_BITS((msg)->descr, 0, 6)
#define CSR_SET_CH_ID(msg, id) SET_BITS((msg)->descr, 0, 6, id)

#define CSR_GET_FIRST(msg)     GET_BITS((msg)->descr, 6, 1)
#define CSR_SET_FIRST(msg, x)  SET_BITS((msg)->descr, 6, 1, (x) != 0)

#define CSR_GET_LAST(msg)      GET_BITS((msg)->descr, 7, 1)
#define CSR_SET_LAST(msg, x)   SET_BITS((msg)->descr, 7, 1, (x) != 0)

typedef struct csr_msg
{
	u8 descr;
	u8 msg[0];
} __attribute__ ((packed)) csr_msg;

typedef struct csr_bccmd
{
	u16 type;
	u16 len; /* in 16 bit integers */
	u16 seq;
	u16 var_id;
	u16 status;
	u16 payload[0];
} __attribute__ ((packed)) csr_bccmd;
  
typedef struct csr_bccmd_ps
{
	u16 ps_key;
	u16 ps_len; /* len of only ps_val */
	u16 unused; /* always 0x0000 */
	u16 ps_val[0];
} __attribute__ ((packed)) csr_bccmd_ps;

typedef struct csr_rssi_rep
{  
	u16 rssi;
} __attribute__ ((packed)) csr_rssi_rep;

typedef struct csr_packstat_rep
{  
	u16 n_pkts;
	u16 n_good;
	u16 n_corr;
	u16 rssi;
	u16 rssi_valid;
} __attribute__ ((packed)) csr_packstat_rep;

typedef struct csr_biterr_rep
{  
	u16 index;
	u16 val_last;
	u16 val_tot;
} __attribute__ ((packed)) csr_biterr_rep;

static u16 csr_count = 0;

static s32 csr_send_general_hq(csr_bccmd *cmd);

#define PSRETBUF_SIZE 10 /* should be enough for what we want to do */
static u16 ps_retbuf[PSRETBUF_SIZE];


#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP

void
hci_receive_bcsp(u8 *data, u32 count)
{
	csr_bccmd *cmd;
	csr_bccmd_ps *ps;
	
	D_REC(__FUNCTION__ "\n");

	hci_ctrl.hc_buf.cmd_num = 1;  

	release_cmd_timer();

	cmd = (struct csr_bccmd *)data;
	ps = (struct csr_bccmd_ps *)cmd->payload;

	if (cmd->status == CSR_STATUS_OK) {
		if (cmd->type == CSR_MSGTYPE_GETRESP) {
			switch (cmd->var_id) {

			case CSR_CMD_CONFIG_UART:
				break;
				
			case CSR_CMD_BUILD_ID:
				/* Store this for later retrieval */
				sprintf(bt_hw_firmware_info,
					"\n Firmware version: %d",
					cmd->payload[0]);
				break;
				
			case CSR_CMD_CHIP_VER:
				break;
				
			case CSR_CMD_CHIP_REV:
				break;
				
			case CSR_CMD_PS:
				D_CMD(__FUNCTION__": ps key[0x%x]\n", 
				      ps->ps_key);
				PRINTPKT("", (u8*)ps->ps_val, 
					 ps->ps_len*sizeof(u16));
				
				/* Now copy this data to return buf */
				memcpy(ps_retbuf, ps->ps_val, 
				       ps->ps_len*sizeof(u16));
				break;
				
			default:
				break;
			}
		} else {
			DSYS(__FUNCTION__": Not a GETRESP msg\n");
			print_data(__FUNCTION__, data, count);
		}
	} else {
		D_ERR(__FUNCTION__": BCSP status error 0x%x\n", cmd->status);
		print_data(__FUNCTION__, data, count);
	}

	wake_up_interruptible(&hci_wq);	
}

void
hci_receive_hq(u8 *data, u32 count)
{
	csr_bccmd *cmd;
	csr_bccmd_ps *ps;
	
	D_REC(__FUNCTION__"\n");
	
	/* FIXME -- is there only one cmd buffer available ? */
	hci_ctrl.hc_buf.cmd_num = 1;  

	release_cmd_timer();

	cmd = (struct csr_bccmd *)data;
	ps = (struct csr_bccmd_ps *)cmd->payload;

	if (cmd->status == CSR_STATUS_OK) {
		if (cmd->type == CSR_MSGTYPE_GETRESP) {
	
			switch (cmd->var_id) {
			case CSR_VARID_RSSI_REPORT:
			{
				csr_rssi_rep *rep;
				rep = (csr_rssi_rep *)cmd->payload;
				DSYS("RSSI report, rssi : %d\n", rep->rssi);
				break;
			}
			
			case CSR_VARID_PACKET_STAT_REPORT:
			{
				csr_packstat_rep *rep;
				rep = (struct csr_packstat_rep*)cmd->payload;
				DSYS("Packet status report : n_pkts %d, n_good %d, n_corr %d, rssi %d, rssi_valid %d\n", rep->n_pkts, rep->n_good, rep->n_corr, rep->rssi, rep->rssi_valid);
				break;
			}
			
			case CSR_VARID_BITERR_REPORT:
			{
				csr_biterr_rep *rep;
				rep = (struct csr_biterr_rep*)cmd->payload;
				DSYS("Biterror report : index %d, val_last %d, val_tot %d\n", rep->index, rep->val_last, rep->val_tot);
				break;
			}
			default:
				D_ERR("Unknown varid [0x%x]!\n", cmd->var_id);
				break;
			}
		} else if (cmd->type == CSR_MSGTYPE_SETREQ) {
			DSYS(__FUNCTION__": Received a SETREQ, sending back GETRESP\n");
			print_data(__FUNCTION__, data, count);
			cmd->type = CSR_MSGTYPE_GETRESP;
	
			csr_send_general_hq(cmd);
			
		} else if (cmd->type == CSR_MSGTYPE_GETREQ) {
			DSYS(__FUNCTION__": Received a GETREQ\n");
			print_data(__FUNCTION__, data, count);
		} else {
			DSYS(__FUNCTION__": Unknown message type\n");
			print_data(__FUNCTION__, data, count);
		}
	} else {
		D_ERR(__FUNCTION__": HQ status error 0x%x\n", cmd->status);
		print_data(__FUNCTION__, data, count);
	}
	
	wake_up_interruptible(&hci_wq);	
}

static struct dfu_response
{
	struct dfu_response *next;
	u32 length;
	u8 data[0];
} *dfu_responses = NULL;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct wait_queue *dfu_wq = NULL;
#else
static wait_queue_head_t dfu_wq;
#endif /* LINUX_VERSION_CODE */

void
hci_dfu_module_init(void)
{
#ifdef __KERNEL__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	init_waitqueue_head(&dfu_wq);
#endif /* LINUX_VERSION_CODE */
#endif  /*  __KERNEL__  */
}

void
hci_shutdown_dfu(void)
{
	struct dfu_response *response;

	while (dfu_responses) {
		cli();
		response = dfu_responses;
		dfu_responses = response->next;
		sti();

		kfree(response);
	}

	wake_up_interruptible(&dfu_wq);
}

void
hci_receive_dfu(u8 *data, u32 count)
{
	struct dfu_response *response;

	if ((response = kmalloc(sizeof(*response) + count, GFP_ATOMIC))) {
		response->length = count;
		memcpy(response->data, data, count);

		cli();
		response->next = dfu_responses;
		dfu_responses = response;
		sti();

		wake_up_interruptible(&dfu_wq);
	}
}

s32
hci_read_dfu(u8* data, u32 count)
{
	struct dfu_response *response;
	u32 length;

	if (!dfu_responses)
		interruptible_sleep_on(&dfu_wq);

	cli();
	response = dfu_responses;
	dfu_responses = response->next;
	sti();

        if (!response)
                return -EINTR;
        
	length = response->length;

	if (count < length) {
		cli();
		response->next = dfu_responses;
		dfu_responses = response;
		sti();

		printk(__FUNCTION__ ": DFU response was too big!\n");

		return -E2BIG;
	}

	copy_to_user(data, response->data, length);

	kfree(response);

	return (s32)length;
}

s32
csr_send_general_hq(csr_bccmd *cmd)
{
	csr_msg *msg;

	/* HCI Manufacturer specific header */
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
	c_pkt.len = 1 + cmd->len * 2;
	
	msg = (csr_msg *)c_pkt.data;
	
	/* General msg header */
	CSR_SET_LAST(msg, 1); /* first and last segment */
	CSR_SET_FIRST(msg, 1);
	CSR_SET_CH_ID(msg, CSR_CH_ID_HQ);

	memcpy(msg->msg, cmd, cmd->len * 2);

	print_data(__FUNCTION__, (u8*)&c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
	
	return bt_write_lower_driver((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/* When using BCSP this function is used to wait for the
   COMMAND_STATUS which contains cmd_num */

void csr_waitcmdnum(void)
{
	D_CMD(__FUNCTION__"\n");
	hci_ctrl.hc_buf.cmd_num = 0;
	/* wait for command status */
	while (hci_ctrl.hc_buf.cmd_num == 0)
	{
		current->state = TASK_INTERRUPTIBLE;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,2,0)
		schedule_timeout(HZ/100);
#else
		current->timeout = HZ/100;
		schedule();
		current->timeout = 0;
#endif
	}
}

#endif /* CONFIG_BLUETOOTH_SUPPORT_BCSP */

s32 
csr_pskey(u16 ps_key, u16 rw_mode, u16 *retb, u16 n_pars)
{
	s32 tmp;
	csr_msg *msg;
	csr_bccmd *cmd;
	csr_bccmd_ps *ps;

	D_CMD(__FUNCTION__" : ps_key 0x%x [%d]\n", ps_key, rw_mode);	
	PRINTPKT("pars : ", (u8*)retb, n_pars*sizeof(u16));

	/* HCI Manufacturer specific header */
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
	c_pkt.len = 1 + 5*sizeof(u16) + 3*sizeof(u16) + n_pars*sizeof(u16);

	msg = (csr_msg *)c_pkt.data;
	cmd = (csr_bccmd *)msg->msg;
	ps = (csr_bccmd_ps *)cmd->payload;

 	/* General msg header */
	CSR_SET_LAST(msg, 1); /* first and last segment */
	CSR_SET_FIRST(msg, 1);
	CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

	/* BCCMD type */

	cmd->type = rw_mode;
	cmd->len = 5 + 3 + n_pars;
	cmd->seq = csr_count++;
	cmd->var_id = CSR_CMD_PS;
	cmd->status = CSR_STATUS_OK; /* always OK in SETREQ */

	/* Actual PS key request */
	ps->ps_key = ps_key;
	ps->ps_len = n_pars; /* x 16 bits */
	ps->unused = 0x0000;

	if (rw_mode == CSR_MSGTYPE_GETREQ)
	  memset(ps->ps_val, 0, n_pars*sizeof(u16)); /* zero params in GETREQ */
	else  
	  memcpy(ps->ps_val, retb, n_pars*sizeof(16)); /* copy params in SETREQ */

	/* Clear return buf */
	memset(ps_retbuf, 0, PSRETBUF_SIZE*2);

	tmp = send_cmd_block((u8*) &c_pkt, 
			     c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	 
	if (rw_mode == CSR_MSGTYPE_GETREQ)
	  memcpy(retb, ps_retbuf, n_pars*sizeof(u16));
	
	/* Signal status back in SETREQ ? */

	return tmp;
}

s32 
hci_set_bd_addr(u8 bd[6])
{
	csr_msg *msg;
	csr_bccmd *cmd;
	csr_bccmd_ps *ps;

	D_CMD(__FUNCTION__"\n");

	/* HCI Manufacturer specific header */
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
	c_pkt.len = 1 + 5*sizeof(u16) + 3*sizeof(u16) + 4*sizeof(u16);

	msg = (csr_msg *)c_pkt.data;
	cmd = (csr_bccmd *)msg->msg;
	ps = (csr_bccmd_ps *)cmd->payload;

 	/* General msg header */
	CSR_SET_LAST(msg, 1); /* first and last segment */
	CSR_SET_FIRST(msg, 1);
	CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

	/* BCCMD type */
	cmd->type = CSR_MSGTYPE_SETREQ;
	cmd->len = 5 + 3 + 4;
	cmd->seq = csr_count++;
	cmd->var_id = CSR_CMD_PS;
	cmd->status = CSR_STATUS_OK; /* always OK in SETREQ */

	/* Actual PS key request */
	ps->ps_key = CSR_PS_BDADDR;
	ps->ps_len = 4; /* x 16 bits */
	ps->unused = 0x0000;

	ps->ps_val[0] = ((u16)bd[3]) & 0x00ff;
	ps->ps_val[1] = ((((u16)bd[4]) << 8) | ((u16)bd[5]));
	ps->ps_val[2] = (u16)bd[2];
	ps->ps_val[3] = (((u16)bd[0] << 8) | ((u16)bd[1]));

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

s32
hci_read_firmware_rev_info(void)
{
	s32 tmp;
	csr_msg *msg;
	csr_bccmd *cmd;

	D_CMD(__FUNCTION__ VENDOR " BuildID/ChipVer/ChipRev\n");
	
	/* HCI Manufacturer specific header */
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
	c_pkt.len = 1 + 5*sizeof(u16) + 6*sizeof(u16);

	msg = (csr_msg *)c_pkt.data;
	cmd = (csr_bccmd *)msg->msg;

	/* General msg header */
	CSR_SET_LAST(msg, 1); /* first and last segment */
	CSR_SET_FIRST(msg, 1);
	CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

	/* BCCMD type */
	cmd->type = CSR_MSGTYPE_GETREQ;
	cmd->len = 5 + 6;
	cmd->seq = csr_count++;
	cmd->var_id = CSR_CMD_BUILD_ID;
	cmd->status = CSR_STATUS_OK; /* always OK in GETREQ */
	memset(cmd->payload, 0, 6*sizeof(u16));

	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0)
		return tmp;

	cmd->seq = csr_count++;
	cmd->var_id = CSR_CMD_CHIP_VER;
	memset(cmd->payload, 0, 6*sizeof(u16));
	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0)
		return tmp;

	cmd->seq = csr_count++;
	cmd->var_id = CSR_CMD_CHIP_REV;
	memset(cmd->payload, 0, 6*sizeof(u16));
	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);

	return tmp;
}

s32
hci_set_baudrate(u32 baudrate)
{
	s32 tmp;
	csr_msg *msg;
	csr_bccmd *cmd;
	csr_bccmd_ps *ps;
	u16 baud_divider;

	D_CMD(__FUNCTION__ VENDOR " (%u baud)\n", baudrate);

	switch (baudrate) {
	case 9600:
		baud_divider = CSR_UART_RATE_9K6;
		break;
	case 19200:
		baud_divider = CSR_UART_RATE_19K2;
		break;
	case 38400:
		baud_divider = CSR_UART_RATE_38K4;
		break;
	case 57600:
		baud_divider = CSR_UART_RATE_57K6;
		break;
	case 115200:
		baud_divider = CSR_UART_RATE_115K2;
		break;
	case 230400:
		baud_divider = CSR_UART_RATE_230K4;
		break;
	case 460800:
		baud_divider = CSR_UART_RATE_460K8;
		break;
	case 921600:
		baud_divider = CSR_UART_RATE_921K6;
		break;
	default:
		D_ERR(__FUNCTION__ VENDOR ": Baudrate %u not supported\n", baudrate);
		return -EINVAL;
	}

	/* HCI Manufacturer specific header */
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(0x00, MANUFACTURER_SPEC);
	c_pkt.len = 1 + 5*sizeof(u16) + 4*sizeof(u16);

	msg = (csr_msg *)c_pkt.data;
	cmd = (csr_bccmd *)msg->msg;
	ps = (csr_bccmd_ps *)cmd->payload;

	/* General msg header */
	CSR_SET_LAST(msg, 1); /* first and last segment */
	CSR_SET_FIRST(msg, 1);
	CSR_SET_CH_ID(msg, CSR_CH_ID_BCCMD);

	cmd->type = CSR_MSGTYPE_SETREQ;
	cmd->len = 5 + 4;
	cmd->seq = csr_count++;
	cmd->var_id = CSR_CMD_CONFIG_UART;
	cmd->status = CSR_STATUS_OK; /* always OK in SETREQ */

	memset(cmd->payload, 0, 4*sizeof(u16));

	if (bt_use_bcsp(-1))
	{
		cmd->payload[0] = baud_divider | CSR_UART_EVEN_PARITY | 
			CSR_UART_ONE_STOP_BIT;
	} else {
		cmd->payload[0] = baud_divider | CSR_UART_NO_PARITY | 
			CSR_UART_ONE_STOP_BIT;
	}

	if (hci_ctrl.hc_buf.cmd_num < 1) {
		DSYS(__FUNCTION__ VENDOR  ": sleeping\n");
		interruptible_sleep_on(&set_baudrate_wq);
	}

	tmp = bt_write_lower_driver((u8*) &c_pkt, 
				    c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

#ifdef __KERNEL__
	bt_wait_tx(2000); /* wait until DMA empty + 2 ms */
#endif
	hci_ctrl.hc_buf.cmd_num--;

	return tmp;
}

//#define VERBOSE
void
process_vendor_event(u8 *buf, u32 len, u32 event_code)
{
	csr_msg *msg;
	csr_bccmd *cmd;
	csr_bccmd_ps *ps;
	
	D_REC(__FUNCTION__ VENDOR "\n");
	
	/* FIXME -- is there only one cmd buffer available ? */
	hci_ctrl.hc_buf.cmd_num = 1;  

	release_cmd_timer();

	msg = (struct csr_msg *)buf;
	cmd = (struct csr_bccmd *)msg->msg;
	ps = (struct csr_bccmd_ps *)cmd->payload;

	switch (CSR_GET_CH_ID(msg)) {
	case CSR_CH_ID_BCCMD:
		if (cmd->type == CSR_MSGTYPE_GETRESP &&
		    cmd->status == CSR_STATUS_OK) {
			switch (cmd->var_id) {

			case CSR_CMD_CONFIG_UART:
				break;

			case CSR_CMD_BUILD_ID:
				/* Store this for later retrieval */
				sprintf(bt_hw_firmware_info,
					"\n Firmware version: %d",
					cmd->payload[0]);
				break;

			case CSR_CMD_CHIP_VER:
				break;

			case CSR_CMD_CHIP_REV:
				break;

			case CSR_CMD_PS:
				D_CMD(__FUNCTION__": ps key[0x%x]\n", 
				      ps->ps_key);
				PRINTPKT("", (u8*)ps->ps_val, 
					 ps->ps_len*sizeof(u16));
				
				/* Now copy this data to return buf */
				
				memcpy(ps_retbuf, ps->ps_val, 
				       ps->ps_len*sizeof(u16));
				break;
				
			default:
				break;
			}
		}
		break;
		
	case CSR_CH_ID_HQ:
		switch (cmd->var_id) 
		{
		case CSR_VARID_RSSI_REPORT:
		{
			csr_rssi_rep *rep;
			rep = (csr_rssi_rep *)cmd->payload;
			DSYS("RSSI report, rssi : %d\n", rep->rssi);
			break;
		}
		
		case CSR_VARID_PACKET_STAT_REPORT:
		{
			csr_packstat_rep *rep;
			rep = (struct csr_packstat_rep*)cmd->payload;
			DSYS("Packet status report : n_pkts %d, n_good %d, n_corr %d, rssi %d, rssi_valid %d\n", rep->n_pkts, rep->n_good, rep->n_corr, rep->rssi, rep->rssi_valid);
			break;
		}
		
		case CSR_VARID_BITERR_REPORT:
		{
			csr_biterr_rep *rep;
			rep = (struct csr_biterr_rep*)cmd->payload;
			DSYS("Biterror report : index %d, val_last %d, val_tot %d\n", rep->index, rep->val_last, rep->val_tot);
			break;
		}
		}
		break;
		
	default:
		D_ERR("Unknown varid [0x%x]!\n", cmd->var_id);
		break;
	}		

#ifdef VERBOSE
	printk("msg: last: %d, first: %d, chID: %d\n", 
	       CSR_GET_LAST(msg), CSR_GET_FIRST(msg), CSR_GET_CH_ID(msg));

	printk("cmd: type: 0x%04X, msg_len: %d, seq_nbr: %d, varid: 0x%04X, status: 0x%04X\n",
	       cmd->type, cmd->len, cmd->seq, cmd->var_id, cmd->status);

	switch (CSR_GET_CH_ID(msg)) {
	case CSR_CH_ID_BCCMD:
		printk("BCCMD MSG\n");

		switch (cmd->type) {
		case CSR_MSGTYPE_GETREQ:
			printk("GETREQ\n");
			break;

		case CSR_MSGTYPE_GETRESP:
			printk("GETRESP\n");
			break;

		case CSR_MSGTYPE_SETREQ:
			printk("SETREQ\n");
			break;

		default:
			break;
		}

		if (cmd->status == CSR_STATUS_OK)
			printk("Command successful\n");

		if (cmd->type == CSR_MSGTYPE_GETRESP &&
		    cmd->status == CSR_STATUS_OK) {
			switch (cmd->var_id) {
			case CSR_CMD_CONFIG_UART:
				printk("UART config: 0x%04X\n", cmd->payload[0]);
				break;

			case CSR_CMD_BUILD_ID:
				printk("Firmware version: %d\n", cmd->payload[0]);
				break;

			case CSR_CMD_CHIP_VER:
				printk("Chip Version: %d\n", cmd->payload[0]);
				break;

			case CSR_CMD_CHIP_REV:
				printk("Chip Revision: %d\n", cmd->payload[0]);
				break;

			case CSR_CMD_PS:
				break;

			default:
				break;
			}
		}
		break;

	case CSR_CH_ID_HQ:
		printk("HQ MSG\n");
		break;

	default:
		printk("Unknown MSG type\n");
		break;
	}
#endif /* VERBOSE */
	
	/* FIXME -- if using raw interface we haven't slept */
	wake_up_interruptible(&hci_wq);	
}

void
process_vendor_return_param(u32 ocf, u8* r_val)
{
	D_ERR(__FUNCTION__ VENDOR " Manufacturer specific: Invalid reply (0x%x)\n", ocf);
}

char*
bt_hw_vendor(void)
{
	return "CSR";
}

#elif defined(CONFIG_BLUETOOTH_INFINEON_BMI)
/*****************************************************************************/
/***************** Functions for Infineon BlueMoon I chips *******************/
/*****************************************************************************/

#define VENDOR " [Infineon]"

s32
hci_set_bd_addr(u8 bd[6])
{
	D_ERR(__FUNCTION__ VENDOR " not supported.\n");
	return 0;
}

s32
hci_read_firmware_rev_info(void)
{
	D_CMD(__FUNCTION__ VENDOR "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(0x05, MANUFACTURER_SPEC);
	c_pkt.len = 0;

	return send_cmd_block((u8*) &c_pkt,
			      c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

s32
hci_set_baudrate(u32 baudrate)
{
	u8 pkt[6];
	s32 tmp;

	D_CMD(__FUNCTION__ VENDOR " (%d baud)\n", baudrate);
	pkt[0] = CMD_PKT;
	pkt[1] = 0x06;
	pkt[2] = 0xfc;
	pkt[3] = 0x02;
	switch (baudrate) {
	case 9600:
		pkt[4] = 3;
		pkt[5] = 168;
		break;
	case 19200:
		pkt[4] = 2;
		pkt[5] = 168;
		break;
	case 38400:
		pkt[4] = 1;
		pkt[5] = 168;
		break;
	case 57600:
		pkt[4] = 0;
		pkt[5] = 225;
		break;
	case 115200:
		pkt[4] = 0;
		pkt[5] = 112;
		break;
	case 230400:
		pkt[4] = 0;
		pkt[5] = 55;
		break;
	case 460800:
		pkt[4] = 0;
		pkt[5] = 27;
		break;
	default:
		D_ERR(__FUNCTION__ VENDOR ": Baudrate not supported\n");
	}
	tmp = send_cmd(pkt, 6);

	/* the chip answers with two command complete events, the first using 
	   the old baudrate, the second using the new baudrate. The second 
	   event is send at least 0.125 seconds after the first to let the 
	   host change its baudrate too. */

	start_cmd_timer();
	interruptible_sleep_on(&hci_wq);

	return tmp;
}

void
process_vendor_event(u8 *buf, u32 len, u32 event_code)
{
	D_REC(__FUNCTION__ VENDOR "\n");
	if (len >= 1)  {
		switch (buf[0]) {
		case 0x00:
			printk("Infineon event: Hardware Startup complete.\n");
			break;
		case 0x04:
			printk("Infineon event: invalid packet length.\n");
			break;
		case 0x05:
			printk("Infineon event: BD-Data invalid (check EEPROM).\n");
			break;
		case 0x07:
			printk("Infineon event: invalid packet type.\n");
			break;
		case 0x09:
			printk("Infineon event: invalid ACL_BC_PB_Flag.\n");
			break;
		case 0x0A:
			printk("Infineon event: invalid ACL_CNC_Handle.\n");
			break;
		case 0x0B:
			printk("Infineon event: invalid SCO_CNC_Handle.\n");
			break;
		case 0x0C:
			printk("Infineon event: low power mode start.\n");
			break;
		case 0x0D:
			printk("Infineon event: low power mode end.\n");
			break;

		default:
			D_ERR(__FUNCTION__ VENDOR ": Unknown event\n");
		}  /* end of switch */
	}  else  {
		D_ERR(__FUNCTION__ VENDOR ": Invalid event\n");
	}
}

void
process_vendor_return_param(u32 ocf, u8* r_val)
{
	static int second = 0;

	switch (ocf) {
	case 0x0005:  /* read software version */
		D_CMD(__FUNCTION__ VENDOR ": Software version\n");
		if (r_val[0] != 0)  {
			D_ERR(__FUNCTION__ VENDOR ": Software version read failure\n");
		}  else  {
			printk("Infineon LM-FW version is: %x.%x%x\n",
			       r_val[2] & 0x0F, r_val[1] >> 4, r_val[1] & 0x0F);
			printk("Infineon BB-FW version is: %02x%02x\n", r_val[4], r_val[3]);
		}
		release_cmd_timer();
		wake_up_interruptible(&hci_wq);
		break;

	case 0x0006:  /* set baudrate */
		D_CMD(__FUNCTION__ VENDOR ": Baudrate set\n");
		if ((r_val[0] == 0x00) && (second == 0))  {
			printk("Infineon baudrate changes after this message\n");
			second = 1;
		}  else if ((r_val[0] == 0x00) && second)  {
			printk("Infineon baudrate has changed to new value\n");
			second = 0;
		}  else  {
			D_ERR(__FUNCTION__ VENDOR ": Baudrate set failure %x\n",r_val[0]);
		}
		release_cmd_timer();
		wake_up_interruptible(&hci_wq);
		break;

	default:
		release_cmd_timer();
		D_ERR(__FUNCTION__ VENDOR " Manufacturer specific: Invalid reply (0x%x)\n",
		      ocf);
		wake_up_interruptible(&hci_wq);
		break;
	}  /* end of switch */
}

char*
bt_hw_vendor(void)
{
	return "Infineon";
}

#else
/*****************************************************************************/
/************************* HW_NOINIT and HW_GENERIC **************************/
/*****************************************************************************/

#define VENDOR " [Generic]"

s32 
hci_set_bd_addr(u8 bd[6])
{
	D_ERR(__FUNCTION__ VENDOR " not supported.\n");
	return 0;
}

s32
hci_read_firmware_rev_info(void)
{
	D_ERR(__FUNCTION__ VENDOR " not supported.\n");
	return 0;
}

s32 
hci_set_baudrate(u32 baudrate)
{
	D_ERR(__FUNCTION__ VENDOR " not supported.\n");
	return 0;
}

void
process_vendor_event(u8 *buf, u32 len, u32 event_code)
{
	D_REC(__FUNCTION__ VENDOR " Manufacturer specific: Unknown event.\n");
}

void
process_vendor_return_param(u32 ocf, u8* r_val)
{
	D_ERR(__FUNCTION__ VENDOR " Manufacturer specific: Invalid reply (0x%x)\n", ocf);
}

char*
bt_hw_vendor(void)
{
#if defined(CONFIG_BLUETOOTH_USBMODULE)
	return "USB";
#elif defined(CONFIG_BLUETOOTH_GENERIC)
	return "Generic";
#elif defined(CONFIG_BLUETOOTH_NOINIT)
	return "No Init";
#else
	return "Unknown";
#endif
}
#endif

/*****************************************************************************/

char*
bt_hw_firmware(void)
{
	return bt_hw_firmware_info;
}

/********************* END OF FILE hci_vendor.c ******************************/
