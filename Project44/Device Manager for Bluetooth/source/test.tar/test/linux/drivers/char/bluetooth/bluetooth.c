
/****************** INCLUDE FILES SECTION ***********************************/

#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/config.h>
#include <linux/termios.h>
#include <linux/tty.h>
#include <linux/module.h>
#include <linux/malloc.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/timer.h>

/* Make sure KERNEL_VERSION() is defined */
#ifndef KERNEL_VERSION
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,2,18)
# ifdef MODULE
#  define module_init(x) int init_module(void) { return x(); }
#  define module_exit(x) void cleanup_module(void) { x(); }
# else
#  define module_init(x) int x##_module(void) { return x(); }
#  define module_exit(x) void x##_module(void) { x(); }
# endif
# define __init
# define __exit
#else
# include <linux/init.h>
# if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
#  include <linux/kcomp.h>
# endif
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
# include <linux/interrupt.h>
#endif

#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/btmem.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/hci_internal.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/rfcomm.h>
#include <linux/bluetooth/tcs.h>
#include <linux/bluetooth/sdp.h>
#include <linux/bluetooth/sec_client.h>
#include <linux/bluetooth/bt_errno.h>
#include <linux/bluetooth/test.h>
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
#include <linux/bluetooth/bcsp.h>
#endif

#ifdef CONFIG_BLUETOOTH_USE_TCI
#include <linux/bluetooth/tci.h>
#endif

#ifdef CONFIG_BLUETOOTH_PROC
#include <linux/bluetooth/bt_proc.h>
#endif

#ifdef __CRIS__
#include <asm/io.h>
#endif

/****************** DEBUG CONSTANT AND MACRO SECTION ************************/

#if BT_DRIVER_DEBUG
#define BT_DRIVER(fmt...) printk(BT_DBG_STR"(driver) " fmt)
#else
#define BT_DRIVER(fmt...)
#endif /* BT_DRIVER_DEBUG */

#if BT_DATADUMP_DEBUG
#define BT_DATADUMP(str, data, len) print_data(str, data, len)
#else
#define BT_DATADUMP(str, data, len)
#endif

#if BT_DATA_DEBUG
#if BT_USE_TIMESTAMPS
#define BT_DATA(fmt...) do {print_time(1);printk(BT_DBG_STR"DATA " fmt);} while (0)
#else
#define BT_DATA(fmt...) printk(BT_DBG_STR"DATA " fmt)
#endif

#else /* BT_DATA_DEBUG */
#define BT_DATA(fmt...)
#endif /* BT_DATA_DEBUG */

#if BT_LDISC_DEBUG
#define BT_LDISC(fmt...) printk(BT_DBG_STR"(ldisc) " fmt)
#else
#define BT_LDISC(fmt...)
#endif /* BT_LDISC_DEBUG */

#ifndef BT_DATADUMP
#define BT_DATADUMP(str, data, len)
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#define BLUETOOTH_TYPE_DATA 1
#define BLUETOOTH_TYPE_DATA_VOICE 2

#define BT_TTY_DRIVER_MAGIC 0xb100b100 /* check if free...*/
#define BT_TTY_MAJOR 124 /* Experimental use */

#define BT_PARANOIA_CHECK 0

/****************** TYPE DEFINITION SECTION *********************************/

#ifdef CONFIG_BLUETOOTH_USE_INBUFFER

/* This buffer is used decrease overruns on serial port. Copies data in
   interrupt context and schedules a task which consumes data at 'safe' time */

#define BT_INBUFFER_SIZE 4000

typedef struct bt_inbuffer
{
	u8* head;     /* Start of data buffer */
	u8* tail;     /* End of data buffer */ 
	u8* put;      /* Points to where new data is inserted */
	u8* get;      /* This is where the receive task consumes data */
	u8 data[BT_INBUFFER_SIZE];
} bt_inbuffer;
#endif

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

#ifdef __CRIS__
#define BT_FLASH_LED_TIME   (HZ/50) /* 20 ms */ 
#define BT_FLASH_LED_PAUSE (HZ/100) /* 10 ms */

#define NO_BLUETOOTH_ACTIVITY 0
#define BLUETOOTH_ACTIVITY    1

static struct timer_list bt_clear_led_timer;
static int bt_led_next_time;
static int bt_led_active;
static void bt_clear_led(unsigned long dummy);
static void bt_set_leds(int active);
#endif

static void bt_flash_led(void);

#ifdef CONFIG_BLUETOOTH_USE_INBUFFER
struct tq_struct bt_receive_task;
bt_inbuffer hci_data;
static void hci_receive_data_task(void);
static void bt_handle_indata(const __u8 *data, s32 count);
#endif

static void bt_receive_data(u8* data, u32 count);

static void bt_show_version(void);
static s32 bt_init_stack(void);
static s32 bt_ctrl_init(void);
static s32 bt_connect(u8 *bd_addr, u32 con_id);
static s32 bt_disconnect(u32 con_id);
static const u8* psmname(u16 psm);
static void wq_timeout(unsigned long ptr);
static s32 bt_execute_sdp_request(bt_sdp_request *sdpRequest);

#ifdef __USE_OLD_SYMTAB__
/*
 * LINUX 2.0.X SPECIFIC CODE
 */
static s32 bt_tty_read(struct tty_struct *, struct file *, __u8 *, u32);

/* not needed since we write directly to ttyS0->driver->write (rs_write) */
static s32 bt_tty_write(struct tty_struct *, struct file *, const __u8 *, u32);

static s32 bt_tty_select(struct tty_struct *tty, struct inode *inode,
                         struct file *filp, s32 sel_type, select_table *wait);

#else
/*
 * LINUX 2.2.X SPECIFIC CODE
 */
static ssize_t bt_tty_read(struct tty_struct *tty, struct file *file,
			   u8 *buf, size_t nr);

static ssize_t bt_tty_write(struct tty_struct *tty, struct file *file,
			    const u8 *buf, size_t nr);

static u32 bt_tty_poll(struct tty_struct *tty, struct file *file,
		       struct poll_table_struct *wait);
#endif

static s32 bt_tty_ioctl(struct tty_struct *, struct file *, u32, unsigned long);
static s32 bt_tty_open(struct tty_struct *);
static void bt_tty_close(struct tty_struct *);
static s32 bt_tty_room(struct tty_struct *tty);

/* glue */
static s32 bt_write_top(struct tty_struct * tty, s32 from_user,
			const u8 *buf, s32 count);

static void bt_receive_lower_stack(struct tty_struct *tty, const __u8 * cp,
				   char *fp, s32 count);
static void bt_tty_wakeup(struct tty_struct *tty);

static void bt_reset_session(s32 line);

//#define BT_USELINEBUF

/* windoz fix... */
#ifdef BT_USELINEBUF
void bt_reset_linebuf(void);
void bt_linebuf_add(s32 line, u8 *data, s32 len);
void bt_linebuf_send(s32 line);
#endif

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

extern hci_controller hci_ctrl;

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct semaphore ioctl_sem = MUTEX;
#else
static struct semaphore ioctl_sem;
#endif /* LINUX_VERSION_CODE */

static struct bt_ctrl_struct bt_ctrl;

/* some defines for easier reading */
#define BTCTRL bt_ctrl /* the name of the struct that holds all data */
#define GET_UPPERTTY(line) (BTCTRL.session[line].upper_tty)
#define SESSIONSTATE(line) (BTCTRL.session[line].state)
#define NBR_ACTIVE BTCTRL.nbr_active
#define NBR_UPPER BTCTRL.nbr_upper
#define NBR_CTRL_FDS BTCTRL.ctrl_tty_count

struct bt_stat_struct bt_stat;

static struct tty_driver bt_driver;

static s32 bluetooth_refcount;

static struct tty_struct *sertty;

static s32 bt_stack_initiated = 0;

/* used when copying data from user level */
static u8 *tmp_bt_buf = NULL;

static struct tty_struct *bt_table[BT_NBR_PORTS];
static struct termios *bt_termios[BT_NBR_PORTS]; 
static struct termios *bt_termios_locked[BT_NBR_PORTS];

#ifdef BT_USELINEBUF
/* temp buffer used to store data received at upper tty when line is not 
   active yet */

#define TTY_LINEBUFLEN 256
#define TTY_NOLINE 256 /* valid line range 0-255 */
/* only works for 1 line at a time (to preserve memory) 
   whole buffer is sent to upper tty once tty line goes active */
typedef struct tty_linebuffer {
	s32 line;
	u32 cur_len;
	u8 data[TTY_LINEBUFLEN];
} tty_linebuffer;

static tty_linebuffer tty_linebuf;
#endif /* BT_USELINEBUF */

static struct timer_list bt_timer;

#define BT_CON_TIMEOUT (10*HZ)

/****************** FUNCTION DEFINITION SECTION *****************************/

/*

Short description of new stack integration in kernel
----------------------------------------------------


1) PPP over serial (standard way): 

  user app (pppd)
       / \
-------| |------------------
       \ /
  -------------
  |   tty      |
  |           <----> line discipline (PPP)
  -------------
  | tty driver | (serial driver)
  -------------
       / \
-------| |------------------
       \ /
       UART



2) PPP over bluetooth:

  user app (pppd)
       / \
-------| |------------------
       \ / ttyBT0
   --------------
   | tty | ldisc-> PPP ldisc
-----------------------------------------------
   | tty driver | (bluetooth driver)
   -------------
   |            | <-------        
   |  BT STACK  | <-----  |            ADDED
   |            | <---  | | 
   -------------      | | |
   |   ttyS0    |     V V V
   |       ldisc->  BT ldisc 
-----------------------------------------------
   | tty driver | (serial driver)
   -------------
        / \
--------| |------------------
        \ /
       UART

ttySx is a standard serial port tty.
ttyBTx has a separate major nbr and has been registered to 
use bt driver as tty driver.

ttySx is opened initially from a bluetooth control-application
which sets the bt line discipline and keeps the tty open.

When ttyBT is opened from pppd it is set to use ppp discipline 
which in turn uses the driver registered in its tty i.e the bt 
driver.

At the stack top it acts like a serial driver for ppp
At the bottom the stack acts like any line discipline used from 
the standard serial tty.


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


             - Glue Layers for stack - 

                "APPLICATION" (here:ttyBT)
       ---------------------------------------------
 TOP   | bt_recieve_top()  |    bt_write_top()     |
       ---------------------------------------------
                ^                       |
                |                       V
  
 
                     T H E  S T A C K 
     
                                     
                ^                       |
                |                       V
        ----------------------------------------------------
 BOTTOM | bt_receive_lower_stack()| bt_write_lower_driver()|
        ----------------------------------------------------
              "PHYSICAL DRIVER" (here:serial driver)


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

*/


/***********************************/
/* STACK TOP (TTY DRIVER FUNCTIONS)*/
/***********************************/

static s32
bt_open(struct tty_struct *tty, struct file * filp)
{
	s32 line = GET_TTYLINE(tty);
	s32 ret_val;
	
	BT_DRIVER(__FUNCTION__ ": Line %d\n", line);	
	
	ret_val = bt_register_tty(tty) ;

	if (ret_val < 0)
		return ret_val;
	
	MOD_INC_USE_COUNT;

	/* store calling tty in control block */
	return ret_val;
}

static void
bt_close(struct tty_struct *tty, struct file * filp)
{
	s32 line = GET_TTYLINE(tty);

	BT_DRIVER(__FUNCTION__ ": Line %d\n", line);

	/* FIXME - flush channels etc */
	/* close rfcomm channel associated with this tty ?? */

	if (bt_unregister_tty(tty, line) < 0)
		return ;

	MOD_DEC_USE_COUNT;
}

static void
bt_put_char(struct tty_struct *tty, u8 ch)
{
	BT_DRIVER(__FUNCTION__ ": %c\n", ch);
	bt_write_top(tty, 0, &ch, 1);
}

static void
bt_flush_chars(struct tty_struct *tty)
{
	BT_DRIVER(__FUNCTION__ "\n");
	if (sertty != NULL && sertty->driver.flush_chars)
		sertty->driver.flush_chars(sertty);
}


static s32 
bt_write_room(struct tty_struct *tty)
{
	s32 n = buf_write_room();

	BT_DRIVER(__FUNCTION__ ": %d\n", n);
	return n;
}

static s32
bt_chars_in_buffer(struct tty_struct *tty)
{
	u16 n = buf_byte_count(GET_TTYLINE(tty));

	BT_DRIVER(__FUNCTION__ ": %d\n", n);
	return n;
}

static void
bt_flush_buffer(struct tty_struct *tty)
{
	/* Clearing the buffers here may lead to them being cleared before
	   they are sent when diconnecting a connection */
	BT_DRIVER(__FUNCTION__ ": Ignored\n");
#if 0
	bt_tx_buf* tx_buf;
	while ((tx_buf = get_bt_buf())) {
		unsubscribe_bt_buf(tx_buf);
	}
#endif
}


static s32
__bt_ioctl(struct tty_struct *tty, struct file * file,
	 u32 cmd, unsigned long arg)
{
	s32 tmp;
	u32 utmp;
	s32 err = 0;
	s32 size = _IOC_SIZE(cmd);
	bt_connection btcon;
	u8 bd_addr[6];
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	static u8 dfu_data[2044];
#endif

	/* The direction is a bitmask, and VERIFY_WRITE catches R/W transfer.
	   The ioctl direction is user-oriented, while verify_area is kernel-
	   oriented, so the concept of "read" and "write" is reversed */

	if (_IOC_DIR(cmd) & _IOC_READ) {
		err = verify_area(VERIFY_WRITE, (void*)arg, size);
		if (err) {
			BT_DRIVER("verify_area(VERIFY_WRITE) error:%d\n", err);
			return err;
		}
	} else if (_IOC_DIR(cmd) & _IOC_WRITE) {
		err = verify_area(VERIFY_READ, (void*)arg, size);
		if (err) {
			BT_DRIVER("verify_area(VERIFY_READ) error:%d\n", err);
			return err;
		}
	}	

	switch (cmd) {
	case BT_SDP_REQUEST:
	{
		bt_sdp_request sdpRequest;
		int returnValue = -1;

		/* Copy arguments to kernel space */

		BT_DRIVER(__FUNCTION__ ": Copying arguments from user to kernel space\n");
		copy_from_user(&sdpRequest, (s32*)arg, size);
		
		/* Now execute the request */

		BT_DRIVER(__FUNCTION__ ": Executing bt_execute_sdp_request\n");

		if ((returnValue = bt_execute_sdp_request(&sdpRequest)) >= 0) {

			/* Copy the data back to user space and return */

			BT_DRIVER(__FUNCTION__ ": Copying data back to user space\n");
			copy_to_user((s32*)arg, &sdpRequest, size);
		}

		return returnValue;
	}

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER  
        case BT_GETCACHEDLINKKEY:
        {
		unsigned char link_key_info[6 + 16];

		/* Now execute the request */
		BT_DRIVER(__FUNCTION__ ": Executing sec_man_get_cached_link_key\n");

		sec_man_get_cached_link_key(link_key_info);

		BT_DRIVER(__FUNCTION__ ": Copying data back to user space\n");
		copy_to_user((s32*)arg, link_key_info, 6 + 16);

		return 0;
        }
#endif        

	case BTCONNECT: 
		/* argument is an object with all info to start a remote 
		   connection */
		copy_from_user(&btcon, (s32*)arg, size);

		BT_DRIVER(__FUNCTION__ ": BTCONNECT\n");
		return bt_connect(btcon.bd, btcon.id);
	
	case BTDISCONNECT:
	{
		s32 con_id;

		BT_DRIVER(__FUNCTION__ ": BTDISCONNECT\n");
		copy_from_user(&con_id, (s32*)arg, size);
		return bt_disconnect(con_id);
	}

	case BTWAITFORCONNECTION:
	{
		s32 line;

		copy_from_user(&line, (s32*)arg, size);

		/* check if we already have a connection otherwise wait... */
		if ((SESSIONSTATE(line) == BT_LOWERCONNECTED)||
		    (SESSIONSTATE(line) == BT_ACTIVE)) {
			BT_DRIVER("Already got connection on line %d\n", line); 
			return 0;
		}
		BT_DRIVER("Waiting on line %d\n", line);
		interruptible_sleep_on(&bt_ctrl.connect_wq[line]);
		BT_DRIVER("Got connection on line %d\n", line);
		break;
	}
	
	case BTWAITNEWCONNECTIONS:
		/* wait for any new connections coming in */
		BT_DRIVER("Waiting for new connections\n");
		interruptible_sleep_on(&bt_ctrl.any_wq);
		break;

	case BTISLOWERCONNECTED:
	{
		s32 line;	  

		copy_from_user(&line, (s32*)arg, size);
		return SESSIONSTATE(line) == BT_LOWERCONNECTED;
	}
	
	case BTINITSTACK:
		return bt_init_stack();

	case BTSHUTDOWN:
		bt_shutdown();
		break;

        case BTREADREMOTEBDADDR:
	{
		BD_ADDR rev_bd;
		s32 line;	  
		u16 i;

                BT_DRIVER(__FUNCTION__ ": BTREADREMOTEBDADDR\n");

		copy_from_user(&line, (s32*)arg, size);

		get_remote_bd(line, bd_addr);

		/* return as big endian */
		for (i = 0; i < 6; i++) {
			rev_bd[5-i] = bd_addr[i];
		}
		copy_to_user((s32*)arg, rev_bd, 6);
		break;
	}

	case BTRESETPHYSICALHW:
		bt_reset_phys_hw();
		break;
		
        case BTISINITIATED:
		put_user(bt_stack_initiated, (s32*)arg);
		break;

        case BTHWVENDOR:
		copy_to_user((u8*)arg, bt_hw_vendor(), strlen(bt_hw_vendor())+1);
		break;

        case BTFIRMWAREINFO:
                BT_DRIVER(__FUNCTION__ ": BTFIRMWAREINFO\n");
		copy_to_user((u8*)arg, bt_hw_firmware(), strlen(bt_hw_firmware())+1);
		break;

	case BTSENDTESTDATA:
		copy_from_user(&tmp, (s32*)arg, 4);
		copy_from_user(&utmp, (s32*)arg + 1, 4);
		rfcomm_send_testdata(tmp, utmp);
                break;
	
	case HCITESTCONNECTREQ:
	{
		u8 bd[6];

		copy_from_user(bd, (s32*)arg, 6);
		return hci_test_connect_req(bd);
	}

	/* First byte is length */ 
	case BTTESTCOMMAND:
	{
		u8 cmd[261];

		copy_from_user(cmd, (u8*)arg, 260);
		
		test_process_cmd(cmd+1, cmd[0]);
		return 0;
	}

	/* Ioctls executing HCI commands */
	
	/* Link Control Command */

	case HCIINQUIRY:
	{ 
		inquiry_results *inq_res;
		s32 in_param[2];
		u8 lap[3];
		int ret;
		
		BT_DRIVER(__FUNCTION__ ": HCINQUIRY\n");
		
		copy_from_user(in_param, (s32*)arg, 8);

		if ((inq_res = 
		     (inquiry_results*) kmalloc(sizeof(inquiry_results)
						+ 6 * in_param[0], 
						GFP_ATOMIC)) < 0) {
			ret = -ENOMEM;
			goto hci_inq_exit0;
		}

		if ((ret = hci_inquiry(lap, in_param[1], in_param[0],
				       inq_res)) < 0)
			goto hci_inq_exit1;

		copy_to_user((s32*)arg, inq_res, size + 6 * 
			     inq_res->nbr_of_units);
		
hci_inq_exit1:
		kfree(inq_res);		
hci_inq_exit0:
		return ret;
	}
	
	case HCILINKKEYREPLY:
	{
		u8 param[size];
		s32 result;
		
		BT_DRIVER(__FUNCTION__ ": HCILINKKEYREPLY\n");
		copy_from_user(param, (s32*)arg, size);
		/* First part of param contains BD address, last part link key,
		   see Bluetooth specification for more info*/
		result = hci_link_key_request_reply(param, param + 6);
		put_user(result, (s32*)arg);
		break;
	}

	case HCILINKKEYNEGATIVEREPLY:
	{
		u8 bd_addr[size];
		s32 result;
		
		BT_DRIVER(__FUNCTION__ ": HCILINKKEYNEGATIVEREPLY\n");
		copy_from_user(bd_addr, (s32*)arg, size);
		result = hci_link_key_request_negative_reply(bd_addr);
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCIPINCODEREPLY:
	{
		u8 param[size];
		s32 result;
		
		BT_DRIVER(__FUNCTION__ ": HCIPINCODEREPLY\n");
		copy_from_user(param, (s32*)arg, size);
		/* First part of param contains BD address, second part of the
		   pin code, and the last part och the pin code length */
		result = hci_pin_code_request_reply(param, param + 6, *(param + 22));
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCIPINCODENEGATIVEREPLY:
	{
		u8 bd_addr[size];
		s32 result;
		
		BT_DRIVER(__FUNCTION__ ": HCIPINCODENEGATIVEREPLY\n");
		copy_from_user(bd_addr, (s32*)arg, size);
		result = hci_pin_code_request_negative_reply(bd_addr);
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCIAUTHENTICATION_REQUESTED:
	{
		u8 bd_addr[size];
		
		BT_DRIVER(__FUNCTION__ ": HCIAUTHENTICATION_REQUESTED\n");
		copy_from_user(bd_addr, (s32*)arg, size);
		hci_authentication_requested_bd(bd_addr);
		break;
	}
		
	case HCISETCONNECTION_ENCRYPTION:
	{
		u8 param[7];
				
		BT_DRIVER(__FUNCTION__ ": HCISETCONNECTION_ENCRYPTION\n");
		copy_from_user(param, (s32*)arg, size);
		hci_set_connection_encryption_bd(param + 1, *param);
		break;
	}
	/* Link Policy Commands */
	
	case HCISWITCHROLE:
	{
		u8 param[size];

		copy_from_user(param, (s32*)arg, size);
		
		hci_switch_role(&param[0], param[6]);
		break;
	}

	/* Host Controller & Baseband Commands */

	case HCIRESET:
		hci_reset();
		break;
		
	case HCIFLUSH:
		break;

	case HCICREATE_NEW_UNIT_KEY:
	{
		s32 result;

		BT_DRIVER(__FUNCTION__ ": HCICREATE_NEW_UNIT_KEY\n");
		result = hci_create_new_unit_link_key();
		put_user(result, (s32*)arg);
		break;
	}

	case HCIREADSTOREDLINKKEY:
	{
		s32 result;
		u8 param[size];

		BT_DRIVER(__FUNCTION__ ": HCIREADSTOREDLINKKEY\n");
		copy_from_user(param, (s32*)arg, size);

		result = hci_read_stored_link_key(param + 1, *param);
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCIWRITESTOREDLINKKEY:
	{
		s32 result;
		u8 param[size];
		
		BT_DRIVER(__FUNCTION__ ": HCIWRITESTOREDLINKKEY\n");
		copy_from_user(param, (s32*)arg, size);
		
		result = hci_write_stored_link_key(param, param + 6);
		put_user(result, (s32*)arg);
		break;
	}

	case HCIDELETESTOREDLINKKEY:
	{
		s32 result;
		u8 param[size];

		BT_DRIVER(__FUNCTION__ ": HCIDELETESTOREDLINKKEY\n");
		copy_from_user(param, (s32*)arg, size);

		result = hci_delete_stored_link_key(param + 1, *param);
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCISETLOCALNAME:
	{
		/* FIXME: If we send the length of the string too, we don't
		   have to copy all the 248 byte... */
		u8 local_name[248];

		BT_DRIVER(__FUNCTION__ ": HCISETLOCALNAME\n");
		copy_from_user(local_name, (s32*)arg, 248);
		hci_change_local_name(local_name);
		break;
	}

	case HCIREADSCANENABLE:
		BT_DRIVER("Reading scan enable\n");
		tmp = hci_read_scan_enable();
		put_user(tmp, (s32*)arg);
		break;
	
	case HCIWRITESCANENABLE:
		GET_USER(tmp, (s32*)arg);
		BT_DRIVER("Setting write scan enable: [0x%x]\n", tmp);
		hci_write_scan_enable(tmp);
		break;
		
	case HCIWRITEPAGESCANACTIVITY:
	{
		u32 par[2];

		copy_from_user(&par, (s32*)arg, size);
		BT_DRIVER("Setting write page scan activity: [0x%x,0x%x]\n", 
			  par[0], par[1]);
		hci_write_pagescan_activity(par[0], par[1]);
                break;
	}

	case HCIWRITECLASSOFDEVICE:
	{
		u8 class_of_device[3];

		BT_DRIVER(__FUNCTION__ ": HCIWRITECLASSOFDEVICE\n");
		copy_from_user(class_of_device, (s32*)arg, size);
		hci_write_class_of_device(class_of_device);
		break;
	}

	case HCIREAD_AUTHENTICATION_ENABLE:
	{
		s32 result = hci_read_authentication_enable();

		BT_DRIVER(__FUNCTION__ ": HCIREAD_AUTHENTICATION_ENABLE\n");
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCIWRITE_AUTHENTICATION_ENABLE:
	{
		u8 enable;
		s32 result = 0;

		BT_DRIVER(__FUNCTION__ ": HCIWRITE_AUTHENTICATION_ENABLE\n");
		GET_USER(tmp, (s32*)arg);

		enable = (u8)(tmp & 0xff);
		hci_write_authentication_enable(enable);
		put_user(result, (s32*)arg);
		break;
	}
		
	case HCIREAD_ENCRYPTION_MODE:
	{
		s32 result = hci_read_encryption_mode();

		BT_DRIVER(__FUNCTION__ ": HCIREAD_ENCRYPTION_MODE\n");
		put_user(result, (s32*)arg);
		break;
	}
	
	case HCIWRITE_ENCRYPTION_MODE:
	{
		u8 enable;
		s32 result = 0;

		BT_DRIVER(__FUNCTION__ ": HCIWRITE_ENCRYPTION_MODE\n");
		GET_USER(tmp, (s32*)arg);

		enable = (u8)(tmp & 0xff);
		hci_write_encryption_mode(enable);
		put_user(result, (s32*)arg);
		
		break;
	}
		
	case HCISET_EVENT_FILTER:
	{
		u8 param[size];

		BT_DRIVER(__FUNCTION__ ": HCISET_EVENT_FILTER\n");
		copy_from_user(param, (s32*)arg, size);
		
		hci_set_event_filter(param);
		break;
	}	
		
	/* Informational Parameters */

	case HCIREADLOCALBDADDR:
	{
		BD_ADDR rev_bd;
		u16 i;

		BT_DRIVER(__FUNCTION__ ": HCIREADLOCALBDADDR\n");
		
		hci_read_local_bd(bd_addr);

		/* return as big endian */
		for (i = 0; i < 6; i++) {
			rev_bd[5-i] = bd_addr[i];
		}
		copy_to_user((s32*)arg, rev_bd, 6);
		break;
	}

	case HCIREADCOUNTRYCODE:
		BT_DRIVER(__FUNCTION__ ": HCIREADCOUNTRYCODE\n");
		
		tmp = hci_read_country_code();
		put_user(tmp, (s32*) arg);
		break;
		
	/* Status Parameters */

	/* Testing Commands */

	case HCIENABLEDUT:
		hci_enable_dut();
                break;

	/* ioctls vendor specific HCI commands */
		 
	case HCISETBAUDRATE:
	{	
		s32 tmp;

		/* Set baudrate in hardware */ 
		GET_USER(tmp, (s32*)arg);
		BT_DRIVER(__FUNCTION__ ": Setting baudrate in host controller to %d\n", tmp);
		tmp = hci_set_baudrate(tmp);
		return tmp;
	}
	
	case HCIWRITEBDADDR:
		copy_from_user(&bd_addr, (s32*)arg, size);
		BT_DRIVER(__FUNCTION__ ": Setting BD_ADDR to\n");
		print_data("bd:",(u8*)bd_addr,6);
		hci_set_bd_addr(bd_addr);
		break;
		
		/* | len (1) | hci header (4) | data (max 256)| */
	case HCISENDRAWDATA:
	{
		u8 len;
		u8 data[261];

		/* first byte contains length of whole hci message */
		copy_from_user(&len, (u8*)arg, 1);
		BT_DRIVER("Copying %d bytes to raw interface\n", len);
		copy_from_user(data, (u8*)arg + 1, len);
		BT_DRIVER("Sending %d bytes\n", len);
		BT_DATADUMP("RAW: ", data, len);
		hci_send_raw_data(data, len);
		break;
	}

	case BTPING:
	{
		ping_struct ping;
		
		copy_from_user(&ping, (u8*)arg, 8);
		print_data("ping bd: ", ping.bd, 6);

		copy_from_user(&ping+8, (u8*)arg+8, ping.len);

		printk("len: %d\n", ping.len);

		return l2ca_ping(ping.bd, ping.data, ping.len);
	}

	case BTGETINFO:
	{
		u8 bd[6];
		u16 type;

		/* first byte contains length of whole hci message */
		copy_from_user(&bd, (u8*)arg, 6);
		copy_from_user(&type, (u8*)arg + 6, 2);

		BT_DRIVER("BTGETINFO: Type %d\n", type);

		return l2ca_getinfo(bd, type);
	}

	/* force m/s switch as server */
	case BTSETMSSWITCH:
	{
		u8 enable;

		GET_USER(tmp, (s32*)arg);

		enable = (u8)(tmp & 0xff);
		
		BT_DRIVER("BTSETMSSWITCH: %d\n", enable);
		hci_force_msswitch(enable);
		return 0;
	}

	/* Set max number of connections */
	case BTSETMAXCONNECTIONS:
		GET_USER(tmp, (s32*)arg);

		BT_DRIVER("BTSETMAXCONNECTIONS: %d\n", tmp);
		return hci_set_max_connections(tmp);

	case BTSETBCSPMODE:
		GET_USER(tmp, (s32*)arg);

		BT_DRIVER("BTSETBCSPMODE: %d\n", tmp);
		
		tmp = bt_use_bcsp(tmp);
		put_user(tmp, (s32*)arg);
		return 0;

	case BT_SET_DFU_MODE:
		GET_USER(tmp, (s32*)arg);

		BT_DRIVER("BT_SET_DFU_MODE: %d\n", tmp);

		tmp = bt_dfu_mode(tmp);
		put_user(tmp, (s32*)arg);
		return 0;

#ifdef CONFIG_BLUETOOTH_CSR
	/* | ps_key (u16) | rw_mode (u16) | len (u16) | params (u16[])| */
	case BT_CSR_PSKEY:
	{
		u16 u16_size = CSR_PSKEY_MSGHDR_SIZE + CSR_PSKEY_MAXPARAMS;
		u16 msg[size];
		
		copy_from_user(msg, (u8*)arg, u16_size*sizeof(u16));
		BT_DRIVER("BT_CSR_PSKEY [ps:%d type:%d]\n", msg[0], msg[1]);
		csr_pskey(msg[0], msg[1], &msg[3], msg[2]);
		
		copy_to_user((s32*)arg, msg, u16_size*sizeof(u16));
		return 0;
	}
#endif /* CONFIG_BLUETOOTH_CSR */

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	case BTINITBCSP:
		BT_DRIVER("BTINITBCSP\n");
		if (bcsp_init() < 0) {
			printk("Sync failed\n");
			return -ETIMEDOUT;
		}
		return 0;

	case BT_SEND_DFU_COMMAND:
        {
                int ret;
                s32 dfu_len;

		if (!bt_use_bcsp(-1))
			return -EPERM;

		GET_USER(dfu_len, (s32*)arg);
                if (dfu_len > sizeof dfu_data)
                        return -EINVAL;

                copy_from_user(dfu_data, (s32*)arg + 1, dfu_len);

                ret = bcsp_sequence_send(dfu_data, dfu_len, BCSP_DFU_CHN);
                if (ret < 0)
                        return ret;
                return 0;
        }

	case BT_RETRIEVE_DFU_RESPONSE:
        {
                s32 dfu_len;

		if (!bt_use_bcsp(-1))
			return -EPERM;

		GET_USER(dfu_len, (s32*)arg);
                if (dfu_len > sizeof dfu_data)
                        return -EINVAL;
                        
                dfu_len = hci_read_dfu((u8*)((s32*)arg + 1), dfu_len);
                if (dfu_len < 0)
                        return dfu_len;

		put_user(dfu_len, (s32*)arg);
                return 0;
        }
#endif /* CONFIG_BLUETOOTH_SUPPORT_BCSP */

	default:		
		return -ENOIOCTLCMD;
	}

	return 0;
}

static s32
bt_ioctl(struct tty_struct *tty, struct file * file,
	 u32 cmd, unsigned long arg)
{
	s32 tmp;

//	printk(__FUNCTION__ ": [%s:%x] lock !\n", current->comm, cmd);
	down(&ioctl_sem);
//	printk(__FUNCTION__ ": [%s:%x] running...\n", current->comm, cmd);
	tmp = __bt_ioctl(tty, file, cmd, arg);
	up(&ioctl_sem);
	return tmp;
}

static void
bt_throttle(struct tty_struct * tty)
{
	BT_DRIVER(__FUNCTION__ ": Nothing done\n");
}

static void
bt_unthrottle(struct tty_struct * tty)
{
	BT_DRIVER(__FUNCTION__ ": Nothing done\n");
}


static void
bt_set_termios(struct tty_struct *tty, struct termios *old_termios)
{
	BT_DRIVER(__FUNCTION__ ": Forwarding to serial driver\n");

	/* modify serial tty not bt tty */
	if (sertty != NULL)
		sertty->driver.set_termios(sertty, old_termios);
	else
		D_ERR(__FUNCTION__ ": No sertty set!!\n");
}

static void bt_start(struct tty_struct *tty)
{
	BT_DRIVER(__FUNCTION__ ": Nothing done\n");
}

static void
bt_stop(struct tty_struct *tty)
{
	BT_DRIVER(__FUNCTION__ ": Nothing done\n");
}

void
bt_hangup(struct tty_struct *tty)
{
	BT_DRIVER(__FUNCTION__ ": Line %d (nothing done) pid %d (%s)\n",
		  GET_TTYLINE(tty), current->pid, current->comm);
}

/********************************************/
/* STACK BOTTOM FUNCTIONS (LINE DISCIPLINE) */
/********************************************/

/*
 * TTY callbacks
 */

#ifdef __USE_OLD_SYMTAB__
/*****************************************************************************/
/* LINUX 2.0.X SPECIFIC CODE                                                 */
/*****************************************************************************/
static s32 bt_tty_read(struct tty_struct *tty, struct file *file,
                       __u8 * buf, u32 nr)
#else
/*****************************************************************************/
/* LINUX 2.2.X SPECIFIC CODE                                                 */
/*****************************************************************************/
static ssize_t bt_tty_read(struct tty_struct * tty, struct file * file,
			   u8 * buf, size_t nr)
#endif
{
	/* should not read data directly over serial tty */
	BT_LDISC(__FUNCTION__ ": Disabled\n");
	return 0;
}

#ifdef __USE_OLD_SYMTAB__
/*****************************************************************************/
/* LINUX 2.0.X SPECIFIC CODE                                                 */
/*****************************************************************************/
static s32
bt_tty_write(struct tty_struct *tty, struct file *file, const __u8 * data,
             u32 count)
#else
/*****************************************************************************/
/* LINUX 2.2.X SPECIFIC CODE                                                 */
/*****************************************************************************/
static ssize_t
bt_tty_write(struct tty_struct * tty, struct file * file, const u8 * data,
	     size_t count)
#endif
{
	/* should simply discard data since ttySx only exists for internal use
	 */
	BT_LDISC(__FUNCTION__ ": (%d) done!\n", count);
  
	return tty->driver.write(tty, 1/*from user*/, data, count);
}


static s32
bt_tty_ioctl(struct tty_struct *tty, struct file * file,
	     u32 cmd, unsigned long arg)
{
	switch (cmd) {
	default:
		/* forward rest to n_tty line discipline, it takes care of
		   termios settings etc, the rest goes to the tty driver 
		   (serial driver) */
		BT_LDISC(__FUNCTION__ ": Forwarding ioctl 0x%x to n_tty line disc\n", cmd);
		return n_tty_ioctl(tty, file, cmd, arg);
	}
	return -ENOIOCTLCMD;
}

#ifdef __USE_OLD_SYMTAB__
/*****************************************************************************/
/* LINUX 2.0.X SPECIFIC CODE                                                 */
/*****************************************************************************/
static s32
bt_tty_select(struct tty_struct *tty, struct inode *inode,
	      struct file *filp, s32 sel_type, select_table * wait)
{
	BT_LDISC(__FUNCTION__ ": Nothing done!\n");
	return 0;
}
#else
/*****************************************************************************/
/* LINUX 2.2.X SPECIFIC CODE                                                 */
/*****************************************************************************/
static u32 bt_tty_poll(struct tty_struct *tty,
		       struct file *file,
		       struct poll_table_struct *wait)
{
	BT_LDISC(__FUNCTION__ ": Nothing done!\n");
	return 0;
}
#endif

static s32
bt_tty_open(struct tty_struct *tty)
{
	BT_LDISC(__FUNCTION__ "\n");
	DSYS("Setting BT driver to use serial tty\n");
	sertty = tty;
	return 0;
}


static void
bt_tty_close(struct tty_struct *tty)
{
	struct tty_struct *upper_tty;
	s32 line = 0;
	
	/* Now hangup all active upper tty:s */
	
	while (line < BT_NBR_DATAPORTS)
	{
		if ((SESSIONSTATE(line) == BT_ACTIVE) ||
		    (SESSIONSTATE(line) == BT_UPPERCONNECTED))
		{
			BT_LDISC("Hanging up line %d\n", line);
			upper_tty = GET_UPPERTTY(line);
			if (upper_tty)
				tty_hangup(upper_tty);
		}
		line++;
	}

	sertty = NULL;
}

/*
 * Callback function from tty driver. Return the amount of space left
 * in the receiver's buffer to decide if remote transmitter is to be
 * throttled.
 */

static s32
bt_tty_room(struct tty_struct *tty)
{
	BT_LDISC(__FUNCTION__ ": Return 65536!\n");
	return 65536;	    /* We can handle an infinite amount of data. :-) */
}

/*
 * This function is called by the tty driver when the transmit buffer has
 * additional space. 
 */

static void
bt_tty_wakeup(struct tty_struct *tty)
{
	printk(__FUNCTION__ ": Nothing done\n");
}

void bt_reset_phys_hw(void)
{
#ifdef __CRIS__
#ifdef CONFIG_BLUETOOTH_CSR
	int do_reset = 1;
#else
	int do_reset = 0;
#endif

#if defined(CONFIG_BLUETOOTH_RESET_PA7)
	BT_DRIVER(__FUNCTION__ ": Resetting Bluetooth hardware using pin PA7 (Active %s)\n", (do_reset ? "High" : "Low"));
	REG_SHADOW_SET(R_PORT_PA_DATA, port_pa_data_shadow, 7, do_reset);
	udelay(1000);
	REG_SHADOW_SET(R_PORT_PA_DATA, port_pa_data_shadow, 7, !do_reset);
#elif defined(CONFIG_BLUETOOTH_RESET_PB5)
	BT_DRIVER(__FUNCTION__ ": Resetting Bluetooth hardware using pin PB5 (Active %s)\n", (do_reset ? "High" : "Low"));
	REG_SHADOW_SET(R_PORT_PB_DATA, port_pb_data_shadow, 5, do_reset);
	udelay(1000);
	REG_SHADOW_SET(R_PORT_PB_DATA, port_pb_data_shadow, 5, !do_reset);
#elif defined(CONFIG_BLUETOOTH_RESET_G10)
	BT_DRIVER(__FUNCTION__ ": Resetting Bluetooth hardware using pin G10 (Active %s)\n", (do_reset ? "High" : "Low"));
	REG_SHADOW_SET(R_PORT_G_DATA, port_g_data_shadow, 10, do_reset);
	udelay(1000);
	REG_SHADOW_SET(R_PORT_G_DATA, port_g_data_shadow, 10, !do_reset);
#elif defined(CONFIG_BLUETOOTH_RESET_G11)
	BT_DRIVER(__FUNCTION__ ": Resetting Bluetooth hardware using pin G11 (Active %s)\n", (do_reset ? "High" : "Low"));
	REG_SHADOW_SET(R_PORT_G_DATA, port_g_data_shadow, 11, do_reset);
	udelay(1000);
	REG_SHADOW_SET(R_PORT_G_DATA, port_g_data_shadow, 11, !do_reset);
#else
	D_ERR(__FUNCTION__ ": Resetting Bluetooth hardware: No reset pin defined\n");
#endif
#else
	BT_DRIVER(__FUNCTION__ ": Do not know how to reset the Bluetooth hardware!\n");
#endif /* __CRIS__ */
}

/************************/
/* glue layer functions */
/************************/

/*
 * HCI calls this function to write to lower layer driver
 */

s32
bt_write_lower_driver(u8 *data, s32 len)
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
{
        if (bt_use_bcsp(-1))
                return bcsp_write_top(data, len);
        else
                return bt_write_lower_driver_real(data, len);
}

s32
bt_write_lower_driver_real(u8 *data, s32 len)
#endif
{
	if (len < 0) { /* (!) */
		D_ERR(__FUNCTION__ ": Can't write negative length...\n");
		return 0;
	}
	
	/* get lower layer tty and call its write function directly 
	   without using its registered line discipline */

	BT_DATA("<--|X|    %3d\n", len);

	if (sertty) {
		s32 tmp;
		s32 sent;
		
		if ((tmp = sertty->driver.write_room(sertty)) < len) {
			printk(__FUNCTION__ ": ser tx buffers can't send all, wait (%d/%d)\n",
			       tmp, len);
			return 0;
		} else {
			bt_flash_led();
			BT_DATADUMP("<--|X|", (u8*)data, len);
			sent = sertty->driver.write(sertty, 0, data, len);
		}
		
		if (sent != len) {
			printk(__FUNCTION__ ": Only sent %d of total %d\n", 
			       sent, len);
			/* fixme -- discard packet and add tx error in stat */
		}
		len -= sent;

		return sent;
	} else {
		D_ERR(__FUNCTION__ ": No sertty is set\n");
	}
	return 0;
}

/*
 * Callback function when data is available at the tty driver.
 * Context: timer task or (less likely) hard interrupt.
 */
 
static void
bt_receive_lower_stack(struct tty_struct *tty, const __u8 *data,
		       char *flags, s32 count)
{
	BT_DATA("-->|X|    %3d\n", count);
	BT_DATADUMP("-->|X|", (u8*)data, count);

	bt_flash_led();

#ifdef CONFIG_BLUETOOTH_USE_INBUFFER
	/* store in bt inbuffer and schedule a hci receive task if none is started  */
	bt_handle_indata(data, count);
#else
	/* process data right away */
	bt_receive_data((u8*)data, count);
#endif /* CONFIG_BLUETOOTH_USE_INBUFFER */
}

/* 
 * Upper tty writes to top of stack (BT drivers write()) 
 */

static s32
bt_write_top(struct tty_struct * tty, s32 from_user,
	     const u8 *buf, s32 count)
{
	s32 line = GET_TTYLINE(tty);
	s32 bytes_sent;
	u32 rfcomm_conid;
	struct bt_session *bt;

	BT_DATA("   |X|<-- %3d [%d]\n", count, line);
	BT_DATADUMP("|X|<--", (u8*)buf, count);

	bt = (bt_session *)tty->driver_data;
	
	if ((bt->rfcomm != NULL) && (bt->rfcomm->magic != RFCOMM_MAGIC)) {
		D_ERR(__FUNCTION__ ": rfcomm magic failed (0x%x != 0x%x)\n", 
		      bt->rfcomm->magic, RFCOMM_MAGIC);
		return 0;
	}

	if (SESSIONSTATE(line) != BT_ACTIVE) {
		D_WARN(__FUNCTION__ ": Line %d is not in active state\n",
		       line);
		return 0;
	}

	rfcomm_conid = CREATE_RFCOMM_ID(line, bt->dlci);
	
	if (from_user) {
		/* Our tmp_bt_buf is only one page, but nothing prevents the
		 * caller from giving us more than that to send. Make sure we
		 * don't try to write beyond the end of tmp_bt_buf.
		 */
		count = MIN(count, PAGE_SIZE);
		copy_from_user(tmp_bt_buf, buf, count);
		bytes_sent = rfcomm_send_data(rfcomm_conid, tmp_bt_buf, count);
	} else {
		bytes_sent = rfcomm_send_data(rfcomm_conid, (u8*)buf, count);
	}

	bt_stat.bytes_sent += bytes_sent;

	return bytes_sent;
}

/*
 * RFCOMM calls this function to write to higher layer 
 * "application" e.g ttyBT
 */

s32
bt_receive_top(u32 con_id, u8 *data, s32 len) 
{
	struct tty_struct *upper_tty;
	u32 line;

	line = GET_LINE(con_id);
	
	/* get upper tty and call its ldisc->receive_buf */

	BT_DATA("   |X|--> %3d [%d]\n", len, line);
	BT_DATADUMP("|X|-->", data, len);
	
	if (SESSIONSTATE(line) != BT_ACTIVE) {
		/* change debug macro... */

#ifdef BT_USELINEBUF
		/* WINDOZE FIX */
		BT_DATA(__FUNCTION__ ": (%d) line %d not active yet..., buffer it !\n", len, line);
		/* FIXME -- only buffer first packet ? */
		bt_linebuf_add(line, data, len);
#else
		BT_DATA(__FUNCTION__ ": (%d) line %d not active yet... silent discard!\n", len, line);
#endif
		return 0;
	}

	bt_stat.bytes_received += len;

	upper_tty = GET_UPPERTTY(line);

	if (upper_tty) {
		upper_tty->ldisc.receive_buf(upper_tty, data, NULL, len);  
	} else {
//		D_ERR(__FUNCTION__ ": No upper tty registered !!!\n");
		return -1;
	}
	return 0;
}

//#define IMPROVE_RFCOMM_FLOW

void bt_feedstack(void)
{
	struct tty_struct *upper_tty = NULL;
	s32 check_line;
	s32 nbr_checked = 0;

	if (NBR_ACTIVE == 0) {
		return;
	}

	/* If buffer usage is less than BTMEM_UNTHROTTLE_SIZE check if we 
	   should wake up ldisc */
	if (buf_byte_count(-1) >= BTMEM_UNTHROTTLE_SIZE) {
		return;
	}	
	
	/* Choose next line to check */

	if (NBR_ACTIVE == 1) {
		/* check same as last time */
		check_line = bt_ctrl.tty_last_unthrottled;
	} else if (bt_ctrl.tty_last_unthrottled == BT_NBR_DATAPORTS-1) {
		/* wrap */
		check_line = 0;
	} else {
		check_line = bt_ctrl.tty_last_unthrottled+1;	
	}
		
//	BT_DATA(__FUNCTION__ ": Start on line %d\n", check_line);
		
	/* skip non-active and control port (last) */
	while ((SESSIONSTATE(check_line) != BT_ACTIVE) && 
	       (nbr_checked <= BT_NBR_DATAPORTS)) {
		check_line++;
		nbr_checked++;
		if (check_line == BT_NBR_DATAPORTS) /* wrap */
			check_line = 0;
	}

	/* check if we really found an active */
	if (nbr_checked > BT_NBR_DATAPORTS)
		return;

//	BT_DATA(__FUNCTION__ ": Wakeup line %d !\n", check_line);
	upper_tty = GET_UPPERTTY(check_line);
	bt_ctrl.tty_last_unthrottled = check_line;
		
	if (!upper_tty) {
//		BT_DATA("No active line to feed from!\n");
		return;
	}

#ifdef IMPROVE_RFCOMM_FLOW
	/* FIXME: How should we know what serverchannel we are using ? */
	if (rfcomm_flow_stop(check_line, 2)) {
		BT_DATA(__FUNCTION__ ": Flow stopped in RFCOMM\n");
		return;
	}
#endif
	if ((upper_tty->flags & (1 << TTY_DO_WRITE_WAKEUP)) &&
	    upper_tty->ldisc.write_wakeup) {
//		BT_DATA("   |X|<<***     [%d]\n", check_line);
		
		/* TTY_DO_WRITE_WAKEUP bit is cleared in 
		   upper_tty->flags which means user mode process 
		   will be able to write more data */

		(upper_tty->ldisc.write_wakeup)(upper_tty);
	} else if (!upper_tty->ldisc.write_wakeup) {     
		/* if no wake_up function is defined (N_TTY ldisc)
		   wake up wait queue */
//		BT_DATA("   |X|<<***     [%d] (n_tty)\n", check_line);
		wake_up_interruptible(&upper_tty->write_wait);
	}
}

/* Used to wait for dma to finish transmission */
void bt_wait_tx(s32 trim_delay)
{
	while (sertty->driver.chars_in_buffer(sertty) > 0)
		udelay(100);
	udelay(trim_delay);
}

#ifdef CONFIG_BLUETOOTH_USE_INBUFFER
static void bt_handle_indata(const __u8 *data, s32 count)
{
	s32 free;

	/* Check if there is data that hasn't been passed up to hci yet. 
	   In that case there is a task scheduled for this and we shouldn't 
	   add another one. */

	if (hci_data.put == hci_data.get) {
		bt_receive_task.routine = (void*)hci_receive_data_task;
		bt_receive_task.data = NULL;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
		queue_task(&bt_receive_task, &tq_scheduler);
#else
		queue_task(&bt_receive_task, &tq_immediate);
		mark_bh(IMMEDIATE_BH);
#endif
	}

	if (hci_data.put >= hci_data.get) {
		/* check for overruns... */
		if (hci_data.put + count - BT_INBUFFER_SIZE >= hci_data.get) {
			D_ERR(__FUNCTION__ ": Buffer overrun!\n");
		} else {
			/* Calculate how much space there is left at the end 
			   of the buffer */
			free = hci_data.tail - hci_data.put + 1;

			/* normal case, data fits in buffer */
			if (count < free) {
				memcpy(hci_data.put, (u8*)data, count);
			} else {
				/* wrap buffer */
				memcpy(hci_data.put, (u8*)data, free);
				memcpy(hci_data.head, (u8*)(data + free), count - free);    
			}
		}
	} else { 
		/* hci_data.put < hci_data.get */
		/* check for overruns ... */
		if (hci_data.put + count >= hci_data.get) {
			D_ERR(__FUNCTION__ ": Buffer overrun!\n");
		} else {
			/* Copy the data to the buffer */
			memcpy(hci_data.put, (u8*)data, count);
		}
	}
  
	hci_data.put += count;
	if (hci_data.put > hci_data.tail)
		hci_data.put -= BT_INBUFFER_SIZE; 
}

static void
hci_receive_data_task(void)
{
	s32 size_end;
	s32 size_start;
	u8* getTemp;

	cli();
	if (hci_data.get == hci_data.put) {
		sti();
		return;
	} else if (hci_data.get > hci_data.put) {
		/* buffer is wrapped */
		size_end = hci_data.tail - hci_data.get + 1;
		size_start = hci_data.put - hci_data.head;
		getTemp = hci_data.get;

		/* Indicate that all data has been fetched (or soon will be) 
		   by setting get == put. */
		hci_data.get = hci_data.put;
		sti();

		bt_receive_data(getTemp, size_end);
		bt_receive_data(hci_data.head, size_start);
	}
	else {
		/* no wrapped buffer */
		size_end = hci_data.put - hci_data.get;
		getTemp = hci_data.get;
		/* Indicate that all data has been fetched (or soon will be)
		   by setting get == put. */
		hci_data.get = hci_data.put;
		sti();

		bt_receive_data(getTemp, size_end);
	}
}
#endif /* CONFIG_BLUETOOTH_USE_INBUFFER */


/* 
 * Searches data buffer for number of completed packets (NCP) 
 * If only NCP data was found tell serial driver not to 
 * schedule a flip of DMA inbuffer.
 */
int bt_catch_ncp(u8* data, u32 count)
{
	int index = 0;

	/* fixme -- do this for BCSP as well */
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
        if (bt_use_bcsp(-1))
		return 0;
#endif

	/* || uart hdr | event code | par_len | nbr_handles | [data...] || */

	while (index+2 < count &&
	       data[index] == EVENT_PKT && 
	       data[index+1] == NBR_OF_COMPLETED_PACKETS) {
		/* we found a NCP */
		index += (3 + data[index + 2]); /* event hdr + par len */
	}

	if (index == count) {
		/* Contains _only_ NCP data, parse it ! */

		/* The easy way would be to call bt_receive_data(data, count),
		   but since it calls hci_receive_data() which is a state
		   machine, we might mess up its state... */
		index = 0;
		while (index+2 < count) {
			update_ncp(data[index+3], data+index+4);
			index += (3 + data[index + 2]);
		}

		return 1;
	}
	
	/* Contains more than NCP data, tell serial 
	   driver to queue it up as usual */
	return 0;
}


static void
bt_receive_data(u8* data, u32 count)
{
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
        if (bt_use_bcsp(-1))
                bcsp_receive_lower(data, count);
        else
#endif
                hci_receive_data(data, count);
}

/* Opens a connection to the selected PSM, layer specific is the same as the
 * lowest part on the connection ID, in RFCOMM this is line | dlci, each one
 * is 8-bits 
 */

s32
bt_connect(u8 *bd_addr, u32 con_id)
{
	u8 line = GET_LINE(con_id);				
	s32 retval = 0;

	/* Check if we already got a connection on the line */
	if ((SESSIONSTATE(line) == BT_LOWERCONNECTED)||
	    (SESSIONSTATE(line) == BT_ACTIVE)) {
		D_WARN(__FUNCTION__ ": Already got connection on line %d\n", 
		       line); 
		return -MSGCODE(MSG_BT_INTERFACE, BT_LINE_BUSY);
	}
	
	switch (GET_PSM(con_id)) {
	case RFCOMM_LAYER:
	{
		u8 srv_ch;
		s32 retval = 0;
		
		CHECK_RFCOMM(con_id);
		srv_ch = GET_RFCOMMSRVCH(con_id); 

		bt_ctrl.session[line].connect_status = -1;

		BT_DRIVER(__FUNCTION__ ": Connecting srv ch %d on line %d\n",
			  srv_ch, line);
		BT_DATADUMP("Remote BD: ", bd_addr, 6);

		if ((retval = rfcomm_connect_req(bd_addr, srv_ch, line)) < 0) {
			BT_DRIVER(__FUNCTION__ ": Failed\n");
			return retval;
		}
                
                /* sleep if not yet connected */
                if (bt_ctrl.session[line].connect_status == -1) {
			start_wq_timer(&bt_timer, BT_CON_TIMEOUT, 
				       &bt_ctrl.connect_wq[line]);
			interruptible_sleep_on(&bt_ctrl.connect_wq[line]);
                }
		return bt_ctrl.session[line].connect_status;
	}
	break;

	case SDP_LAYER:
	{
		int sdp_connection_id = -1;
		int return_value;

		/* Initiate the connection */

		BT_DRIVER(__FUNCTION__ ": Connecting SDP on line %d\n", line);
		BT_DATADUMP("Remote BD: ", bd_addr, 6);
		if ((sdp_connection_id = sdp_connect_req(bd_addr, line)) >= 0) {
		  
			/* 
			 * If here, we have successfully created an SDP     
			 * connection entry and are starting the sequence of 
			 * opening an l2cap connection. Allow the bottom     
			 * half to process the request and get back to us.   
			 */
			
			/* I seem to be having a lot of trouble with the L2CAP
			   traffic just not appearing on this side of the link
			   while I'm waiting for the SDP conneciton to finish
			   up. So let's start a timer to wake us up if things
			   don't appear to be working out.
			   --gmcnutt
			 */
			/* fixme -- we probably need a lock on this timer since
			   multiple processes could be trying to use it at the
			   same time... or maybe use one timer per session.
			 */
			start_wq_timer(&bt_timer, BT_CON_TIMEOUT, 
				       &bt_ctrl.connect_wq[line]);

			/* The timeout routine doesn't have a hendle to our 
			   session status, so set things up to reflect a 
			   timeout error by default. If we really do get a 
			   connection then this value _should_ be changed by
			   the time we wake up to reflect a good connection.
			   --gmcnutt
			 */
			bt_ctrl.session[line].connect_status = -ETIMEDOUT;

			BT_DRIVER(__FUNCTION__ ": Sleep on line %d\n", line);
			interruptible_sleep_on(&bt_ctrl.connect_wq[line]);

			/* 
			 * If the connect_status is >= 0, then the lower
			 * stack did not have a problem handling the request.
			 * Therefore return the sdp_connection_id            
			 */
			
			BT_DRIVER(__FUNCTION__ ": Wake up - line %d\n", line);
			if (bt_ctrl.session[line].connect_status >= 0) {
				return_value = sdp_connection_id;
			} else {
				return_value = bt_ctrl.session[line].connect_status;
			}
		} else {
			return_value = sdp_connection_id;
		}

		return return_value;
	}
	break;

	case L2CAP_TEST_LAYER:
	case L2CAP_TEST2_LAYER:
	case L2CAP_TEST3_LAYER:
		BT_DRIVER(__FUNCTION__ ": Connecting TEST_LAYER (psm %02X) on line %d\n", GET_PSM(con_id), line);

		if((retval = test_connect_psmreq(bd_addr, GET_PSM(con_id))) < 0) {
			BT_DRIVER(__FUNCTION__ ": Failed\n");
			return retval;
		}
    
		return retval;

	case TCS_LAYER:
		return tcs_connect_req(bd_addr);

	default:    
		BT_DRIVER(__FUNCTION__ ": PSM %d not supported as client\n",
			  GET_PSM(con_id));
		break;
	}
	return -1;
}

static s32 bt_execute_sdp_request(bt_sdp_request *sdpRequest)
{
	int line = GET_LINE(sdpRequest->conID);
	int sdpIndex = GET_SDPINDEX(sdpRequest->conID);

	if (SESSIONSTATE(line) != BT_ACTIVE) {

		/* SDP connection not active!  Don't issue the request */

		BT_DRIVER(__FUNCTION__ ": Line %d does not have an active connection!\n", line);
		return -ENOTCONN;
	}

	BT_DRIVER(__FUNCTION__ ": Line %d SDP index %d\n",
		  line, sdpIndex);

	if (sdpStartRequest(sdpIndex,
			    sdpRequest->sdpCommand,
			    sdpRequest->pduPayload,
			    sdpRequest->pduLength) < 0)
		return -1; /* fixme -- EPERM probably not appropriate */

	/* Sleep on this line while the response is going through */

	printk(__FUNCTION__ ": Sleep on line %d\n", line);
	interruptible_sleep_on(&bt_ctrl.connect_wq[line]);

	/* If we're back, there may be data to send back.
	   Copy into sdpRequest and return */
	
	if (bt_ctrl.session[line].sdpRequestResponseData) {

		BT_DRIVER(__FUNCTION__ ": sdpRequestResponseData 0x%x - copying\n", 
			  (int)bt_ctrl.session[line].sdpRequestResponseData);

		memcpy(sdpRequest->requestResponse,
		       bt_ctrl.session[line].sdpRequestResponseData, 
		       bt_ctrl.session[line].sdpRequestResponseDataLength);
		sdpRequest->responseLength = 
			bt_ctrl.session[line].sdpRequestResponseDataLength;

	}

	return 0;
}
 
void
bt_connect_ind(u32 con_id) 
{
	if (GET_PSM(con_id) == RFCOMM_LAYER)
		BT_DRIVER(__FUNCTION__ ": RFCOMM dlci : %d\n", 
			  GET_RFCOMMDLCI(con_id));
	else
		BT_DRIVER(__FUNCTION__ ": PSM %d\n", GET_PSM(con_id));
}

void
bt_connect_cfm(u32 con_id, s32 status)
{
	u16 psm;
	s32 line = GET_LINE(con_id);
	psm = GET_PSM(con_id);

	if ((line < 0) || (line > BT_NBR_DATAPORTS)) {
		D_ERR(__FUNCTION__ ": Invalid line (%d)\n", line);
		return;
	}
	
	switch (psm) {
	case RFCOMM_LAYER:
		CHECK_RFCOMM(con_id);
		bt_ctrl.session[line].connect_status = status;

		BT_DRIVER(__FUNCTION__ ": Line %d [%s]\n",
			  line, psmname(psm));

		release_wq_timer(&bt_timer);
		wake_up_interruptible(&bt_ctrl.connect_wq[line]);
		wake_up_interruptible(&bt_ctrl.any_wq);
		break;
	
	case SDP_LAYER:
                /* Record the connection status for bt_connect() to process. */
		bt_ctrl.session[line].connect_status = status;
		BT_DRIVER(__FUNCTION__ ": Line %d [%s]\n", line, psmname(psm));
		BT_DRIVER(__FUNCTION__ ": Wake up line %d\n", line);
		release_wq_timer(&bt_timer);
		wake_up_interruptible(&bt_ctrl.connect_wq[line]);
		wake_up_interruptible(&bt_ctrl.any_wq);
		break;
		
	case TCS_LAYER:
		BT_DRIVER(__FUNCTION__ ": [%s]\n", psmname(psm));
		break;

	default:
		D_ERR(__FUNCTION__ ": Unknown layer %d\n", psm);
		break;
	}
}

void 
bt_send_sdp_data_received(u8 line, u8 *data, int len)
{
	/* Check the line for validity */
	if (line > BT_NBR_DATAPORTS) {
		D_ERR(__FUNCTION__ ": Invalid line (%d)\n", line);
		return;
	}

	/* When data received for this line, we simply attach the
	   data (& length) and wake up */
	
	BT_DRIVER(__FUNCTION__ ": data 0x%x len %d\n", (int)data, len);
	/* If previous data, deallocate it */

	if (bt_ctrl.session[line].sdpRequestResponseData) {
		D_WARN(__FUNCTION__ ": sdpRequestResponseData set - deallocate\n");
		kfree(bt_ctrl.session[line].sdpRequestResponseData);
		bt_ctrl.session[line].sdpRequestResponseData = NULL;
		bt_ctrl.session[line].sdpRequestResponseDataLength = 0;
	}

	bt_ctrl.session[line].sdpRequestResponseData = data;
	bt_ctrl.session[line].sdpRequestResponseDataLength = len;
	wake_up_interruptible(&bt_ctrl.connect_wq[line]);
	return;
}

static s32 
bt_disconnect(u32 con_id)
{
	int line = GET_LINE(con_id);
	s32 retval = 0;

	if ((SESSIONSTATE(line) != BT_LOWERCONNECTED) && 
		    (SESSIONSTATE(line) != BT_ACTIVE)) {
		D_ERR(__FUNCTION__ ": Line not connected\n");
		return -MSGCODE(MSG_BT_INTERFACE, BT_NOTCONNECTED);
	}
	

	switch(GET_PSM(con_id))
	{
	case RFCOMM_LAYER:
		BT_DRIVER(__FUNCTION__ ": Disconnecting line %d (ONLY RFCOMM)\n", 
			  line);

		CHECK_RFCOMM(con_id);

		bt_ctrl.session[line].disconnect_status = -1;

		if ((retval = rfcomm_disconnect_req(line)) < 0) {
			BT_DRIVER(__FUNCTION__ ": Failed\n");
			return retval;
		}

		/* fixme -- remove timers, useless when rfcomm blocks ? */

		/* Sleep if not yet disconnected */
		if (bt_ctrl.session[line].disconnect_status == -1) {
			start_wq_timer(&bt_timer, BT_CON_TIMEOUT, 
				       &bt_ctrl.connect_wq[line]);
			interruptible_sleep_on(&bt_ctrl.connect_wq[line]);
		}
		
		return bt_ctrl.session[line].disconnect_status;
	  
	case L2CAP_TEST_LAYER:
		retval = test_disconnect_req(testcon); /* extern l2cap_con set in test.c */
		return bt_ctrl.session[line].disconnect_status;

	case L2CAP_TEST2_LAYER:
		retval = test_disconnect_req(testcon2);
		return bt_ctrl.session[line].disconnect_status;

	case L2CAP_TEST3_LAYER:
		retval = test_disconnect_req(testcon3);
		return bt_ctrl.session[line].disconnect_status;

	default:
		BT_DRIVER(__FUNCTION__ ": Can't disconnect this layer (PSM %x)\n", GET_PSM(con_id));
		return -EINVAL;
	}
	return retval;
}

/* This function is currently not used in OpenBT for any useful stuff,
   however other ports of OpenBT uses this to notify applications */
void
bt_disconnect_ind(u32 con_id) 
{
	if (GET_PSM(con_id) == RFCOMM_LAYER)
		BT_DRIVER(__FUNCTION__ ": RFCOMM dlci: %d\n", 
			  GET_RFCOMMDLCI(con_id));
	else
		BT_DRIVER(__FUNCTION__ ": PSM %d\n", GET_PSM(con_id));
}

void
bt_disconnect_cfm(u32 con_id, s32 status) 
{
	u32 line = GET_LINE(con_id);

        BT_DRIVER(__FUNCTION__ ": PSM %d, status %d\n", 
		  GET_PSM(con_id), status);

	bt_ctrl.session[line].disconnect_status = status;

	release_wq_timer(&bt_timer);
	wake_up_interruptible(&bt_ctrl.connect_wq[line]);
}

/* notified upper tty application that this line is down */
void
bt_hangupline(s32 line)
{
	struct tty_struct *upper_tty;

	BT_DRIVER(__FUNCTION__ ": Hanging up line %d\n", line);

	/* find corresponding upper tty */
	upper_tty = GET_UPPERTTY(line);
  
	if (upper_tty)
		tty_hangup(upper_tty);
	else
		D_WARN(__FUNCTION__ ": No upper tty\n");
}

#ifdef __CRIS__
/* is run once every 10 jiffies which clears any lit led if it 
   has been lit for at least BT_FLASH_LED_TIME jiffies */
static void
bt_clear_led(unsigned long dummy)
{
	if (bt_led_active && jiffies > bt_led_next_time) {
		bt_set_leds(NO_BLUETOOTH_ACTIVITY);

		/* Set the earliest time we may set the LED */
		bt_led_next_time = jiffies + BT_FLASH_LED_PAUSE;
		bt_led_active = 0;
	}

	bt_clear_led_timer.expires = jiffies + HZ/10;
	add_timer(&bt_clear_led_timer);
}

static void
bt_flash_led(void)
{
	if (!bt_led_active && jiffies > bt_led_next_time) {
		bt_set_leds(BLUETOOTH_ACTIVITY);

		/* Set the earliest time we may clear the LED */
		bt_led_next_time = jiffies + BT_FLASH_LED_TIME;
		bt_led_active = 1;
	}
}

static void
bt_set_leds(int active)
{
	if ((!hci_ctrl.nbr_of_connections && active == BLUETOOTH_ACTIVITY) ||
            (hci_ctrl.nbr_of_connections && active == NO_BLUETOOTH_ACTIVITY)) {
		LED_ACTIVE_SET(bt_dfu_mode(-1) ? LED_ORANGE : LED_GREEN);
	} else {
		LED_ACTIVE_SET(LED_OFF);
	}
}

#else
static void
bt_flash_led(void)
{
	/* blink blink :) */
}
#endif

/**********************************/
/* Bluetooth Stack Initialisation */
/**********************************/

#if defined(MODULE) || defined(__KERNEL__)
static int __init bt_init(void)
#else
s32 bt_init(void)
#endif
{
	static struct tty_ldisc	bt_ldisc;
	s32 status;
#ifdef CONFIG_BLUETOOTH_PROC
	s32 procfs_status = -1;
#endif

	bt_show_version();

	/* Initialise the tty_driver structure */

	memset(&bt_driver, 0, sizeof(bt_driver));
	bt_driver.magic = BT_TTY_DRIVER_MAGIC;
	bt_driver.name = "ttyBT";
	bt_driver.major = BT_TTY_MAJOR;
	bt_driver.minor_start = 0;
	bt_driver.num = BT_NBR_PORTS;
	bt_driver.type = TTY_DRIVER_TYPE_SERIAL;
	bt_driver.subtype = BLUETOOTH_TYPE_DATA;
	bt_driver.init_termios = tty_std_termios;
	bt_driver.init_termios.c_cflag =
		B115200 | CS8 | CREAD | HUPCL | CLOCAL;
 
	/* no output processing */
	bt_driver.init_termios.c_oflag = 0;
	/* no echo ... */
	bt_driver.init_termios.c_lflag = 0;
	
	bt_driver.flags = TTY_DRIVER_REAL_RAW;
	bt_driver.refcount = &bluetooth_refcount;
 	bt_driver.table = bt_table; 

	bt_driver.termios = bt_termios;
	bt_driver.termios_locked = bt_termios_locked;
 
	/* Register the interface against usermode applications */

	bt_driver.open = bt_open;
	bt_driver.close = bt_close;
	bt_driver.write = bt_write_top;
	bt_driver.put_char = bt_put_char;
	bt_driver.flush_chars = bt_flush_chars;
	bt_driver.write_room = bt_write_room;
	bt_driver.chars_in_buffer = bt_chars_in_buffer;
	bt_driver.flush_buffer = bt_flush_buffer;
	bt_driver.ioctl = bt_ioctl;
	bt_driver.throttle = bt_throttle;
	bt_driver.unthrottle = bt_unthrottle;
	bt_driver.set_termios = bt_set_termios;
	bt_driver.stop = bt_stop;
	bt_driver.start = bt_start;
	bt_driver.hangup = bt_hangup;
  
	if (tty_register_driver(&bt_driver))
		panic("Could not register bluetooth driver\n");

	DSYS("Bluetooth driver registered as %s\n", bt_driver.name);

/*
 * Register the tty discipline
 * (Interface against lower hardware driver)
 */
	
	memset(&bt_ldisc, 0, sizeof(bt_ldisc));
	bt_ldisc.magic		= TTY_LDISC_MAGIC;
	bt_ldisc.open		= bt_tty_open;
	bt_ldisc.close		= bt_tty_close;
	bt_ldisc.read		= bt_tty_read;
	bt_ldisc.write		= bt_tty_write; /* bypass stack ...*/
	bt_ldisc.ioctl		= bt_tty_ioctl;
#ifdef __USE_OLD_SYMTAB__
	bt_ldisc.select	        = bt_tty_select;
#else
	bt_ldisc.poll  	        = bt_tty_poll;
#endif
	bt_ldisc.receive_room	= bt_tty_room;
	bt_ldisc.receive_buf	= bt_receive_lower_stack;
	bt_ldisc.write_wakeup	= bt_tty_wakeup;
	
	status = tty_register_ldisc(N_BT, &bt_ldisc);
	if (status == 0) {
		DSYS("Bluetooth line discipline registered.\n");
	} else {
		printk (KERN_ERR "Error registering line discipline: %d\n",
			status);
		return status;
	}

	/* Initialise the tty_driver structure */
	bt_ctrl_init();
	
	sertty = NULL;

	DSYS("Registering BT proc files\n");
 
#ifdef CONFIG_BLUETOOTH_PROC
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	{
		procfs_status = -1;
		if (create_proc_info_entry(bt_status.name,
					   bt_status.mode,
					   &proc_root,
					   bt_status.get_info))
			procfs_status = 1;
	}
#elif LINUX_VERSION_CODE > KERNEL_VERSION(2,2,0)
	procfs_status = proc_register(&proc_root, &bt_status);
#else
	procfs_status = proc_register_dynamic(&proc_root, &bt_status);
#endif /* LINUX_VERSION_CODE */

	if (procfs_status < 0) {
		D_ERR("Couldn't register proc file bt_status %d\n", 
		      procfs_status);
	}
	
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	{
		procfs_status = -1;
		if (create_proc_info_entry(bt_internal_info.name,
					   bt_internal_info.mode,
					   &proc_root,
					   bt_internal_info.get_info))
			procfs_status = 1;
	}
#elif LINUX_VERSION_CODE > KERNEL_VERSION(2,2,0)
	procfs_status = proc_register(&proc_root, &bt_internal_info);
#else
	procfs_status = proc_register_dynamic(&proc_root, &bt_internal_info);
#endif /* LINUX_VERSION_CODE */

	if (procfs_status < 0) {
		D_ERR("Could not register proc file bt_internal_info %d\n",
		      procfs_status);
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	{
		procfs_status = -1;
		if (create_proc_info_entry(bt_proc_doit.name,
					   bt_proc_doit.mode,
					   &proc_root,
					   bt_proc_doit.get_info))
			procfs_status = 1;
}
#elif LINUX_VERSION_CODE > KERNEL_VERSION(2,2,0)
	procfs_status = proc_register(&proc_root, &bt_proc_doit);
#else
	procfs_status = proc_register_dynamic(&proc_root, &bt_proc_doit);
#endif /* LINUX_VERSION_CODE */

	if (procfs_status < 0) {
		D_ERR("Could not register proc file bt_status %d\n", 
		      procfs_status);
	}

#endif /* CONFIG_BLUETOOTH_PROC */

#ifdef CONFIG_BLUETOOTH_USE_TCI
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	{
		procfs_status = -1;
		if (create_proc_info_entry(tci_proc_entry.name,
					   tci_proc_entry.mode,
					   &proc_root,
					   tci_proc_entry.get_info))
			procfs_status = 1;
	}
#elif LINUX_VERSION_CODE > KERNEL_VERSION(2,2,0)
	procfs_status = proc_register(&proc_root, &tci_proc_entry);
#else
	procfs_status = proc_register_dynamic(&proc_root, &tci_proc_entry);
#endif /* LINUX_VERSION_CODE */

	if (procfs_status < 0) {
		D_ERR("Could not register proc file for tci database %d\n",
		      procfs_status);
	}
#endif /* CONFIG_BLUETOOTH_USE_TCI */
	
	sdp_create_proc_file();


#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
	sec_man_create_proc_file();
#endif

	DSYS("Bluetooth Driver Using ttyBT[0-%d] (data), ttyBTC (ctrl [%d])\n",
	     BT_NBR_DATAPORTS-1, BT_NBR_PORTS-1);

#ifdef CONFIG_BLUETOOTH_USE_INBUFFER
	DSYS("Using BT Inbuffers [%d]\n", BT_INBUFFER_SIZE);
        /* Init hci inbuffer */
        hci_data.head = &hci_data.data[0];
        hci_data.tail = &hci_data.data[BT_INBUFFER_SIZE-1];
        hci_data.put = hci_data.head;
        hci_data.get = hci_data.head;;
#endif

#ifdef __KERNEL__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	sema_init(&ioctl_sem, 1);
#endif /* LINUX_VERSION_CODE */
#endif  /*  __KERNEL__  */

	hci_module_init();
	rfcomm_module_init();
        
	return 0; /* success */
}

static void
bt_show_version(void)
{
	printk("Bluetooth Driver v1.3, Copyright (c) 2000, 2001 Axis Communications AB\n");
}

s32
bt_initiated(void)
{
	return bt_stack_initiated;
}

s32
bt_use_bcsp(s32 new_use_bcsp)
{  
	/* default val */
#ifdef CONFIG_BLUETOOTH_USE_BCSP
        static s32 use_bcsp = 1;
#else
        static s32 use_bcsp = 0;
#endif
        s32 old = use_bcsp;

        if (new_use_bcsp >= 0)
        {
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
		use_bcsp = new_use_bcsp;
#endif
        }
        return old;
}

s32
bt_dfu_mode(s32 new_dfu_mode)
{  
        static s32 dfu_mode = 0;
        s32 old = dfu_mode;

        if (new_dfu_mode >= 0)
        {
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
		dfu_mode = new_dfu_mode;
#endif
        }
        return old;
}

s32
bt_init_stack(void)
{
	unsigned long page;	

	/* shutdown if already initiated */
	if (bt_stack_initiated)
		bt_shutdown();

	/* The following part of the code is originally from the Linux serial 
	   driver (serial.c). The last conditional is used to prevent that only
	   one "tmp_bt_buf" is allocated even if many tty's are opened. This
	   is because the kernel may schedule after get_free_page is called. */
	
	if (!tmp_bt_buf) {
		page = get_free_page(GFP_KERNEL);
		if (!page)
			return -ENOMEM;

		if (tmp_bt_buf)
			free_page(page);
		else
			tmp_bt_buf = (u8 *) page;
	}

	/* Initialise all layers in the bluetooth stack */
	
	DSYS("Initialising Bluetooth Stack\n");

	DSYS("Current HW: %s\n", bt_hw_vendor());

#ifdef __CRIS__
	/* start led timer */
	bt_set_leds(NO_BLUETOOTH_ACTIVITY);
	init_timer(&bt_clear_led_timer);
	bt_clear_led_timer.function = &bt_clear_led;
	bt_clear_led_timer.expires = jiffies + HZ/10;
	add_timer(&bt_clear_led_timer);
#endif

	btmem_init();

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	if (bt_use_bcsp(-1) && !bcsp_issyncronized()) {  
		if (bcsp_init() < 0) {
			bcsp_shutdown();
			goto init_failed_exit0;
		}
 	}
#endif

	/* Always check if hci succeeded */
	if (hci_init() < 0) {
		D_ERR("HCI failed to initialise\n");
		goto init_failed_exit1;
	}

	if (!bt_dfu_mode(-1)) {
		l2cap_init();

#ifdef CONFIG_BLUETOOTH_USE_TCI
		tci_init();
#else
		rfcomm_init();
		sdp_init(1); /* For now always init as server */
		tcs_init();
		test_init();
#endif
	}

	bt_stack_initiated = 1;
	bt_stat.bytes_received = 0;
	bt_stat.bytes_sent = 0;
#ifdef BT_USELINEBUF
	bt_reset_linebuf();
#endif

	return 0;

init_failed_exit1: 
	hci_shutdown();
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	bcsp_shutdown();
#endif
init_failed_exit0:
	btmem_shutdown();
	if (tmp_bt_buf) {
		free_page((unsigned long) tmp_bt_buf);
		tmp_bt_buf = NULL;
	}
#ifdef __CRIS__
	del_timer(&bt_clear_led_timer);
	bt_set_leds(NO_BLUETOOTH_ACTIVITY);
#endif
	return -1;
}

#ifdef BT_USELINEBUF
void bt_reset_linebuf()
{
	/* init tty line buffer */
	tty_linebuf.line = TTY_NOLINE;
	tty_linebuf.cur_len = 0;
	memset(tty_linebuf.data, 0, TTY_LINEBUFLEN);
}

void bt_linebuf_add(s32 line, u8 *data, s32 len)
{
	/* check if this line was the one previously used */
	if ((line != tty_linebuf.line) && (tty_linebuf.line != TTY_NOLINE)) {
		D_ERR(__FUNCTION__ ": Line %d not active and linebuf busy, silent discard...\n", line);
		return;
	} else if (tty_linebuf.line == TTY_NOLINE)
		tty_linebuf.line = line;

	/* is there room for data ? */
	if ((tty_linebuf.cur_len + len) > TTY_LINEBUFLEN) {
		D_ERR(__FUNCTION__ ": Line %d not active and linebuf full, silent discard (consider increasing line buffer [%d])\n", line, TTY_LINEBUFLEN);
		return;
	}
	
	/* ok, add it ! */
	DSYS(__FUNCTION__ ": Adding %d bytes\n", len);
	memcpy(tty_linebuf.data+tty_linebuf.cur_len, data, len);
	tty_linebuf.cur_len += len;
}

void bt_linebuf_send(s32 line)
{
	struct tty_struct *upper_tty = GET_UPPERTTY(line);

	if (line != tty_linebuf.line)
		return;

	if (upper_tty && tty_linebuf.cur_len > 0) {
		DSYS(__FUNCTION__ ": Now sending buffered data [%d] to line %d\n", tty_linebuf.cur_len, line);

		upper_tty->ldisc.receive_buf(upper_tty, tty_linebuf.data, 
					     NULL, tty_linebuf.cur_len);  

		bt_reset_linebuf();
	} else
		DSYS(__FUNCTION__ ": No data sent\n");
}
#endif /* BT_USELINEBUF */

s32
bt_ctrl_init(void)
{
	s32 i;
	BT_DRIVER("Initialising bt ctrl struct\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	for (i = 0; i < BT_NBR_PORTS; i++) {
		bt_ctrl.connect_wq[i] = NULL;
		bt_reset_session(i);
	}
	bt_ctrl.any_wq = NULL;
#else
	for (i = 0; i < BT_NBR_PORTS; i++) {
		init_waitqueue_head(&bt_ctrl.connect_wq[i]);
		bt_reset_session(i);
	}
	init_waitqueue_head(&bt_ctrl.any_wq);
#endif

	bt_ctrl.nbr_upper = 0;
	bt_ctrl.nbr_active = 0;
	bt_ctrl.tty_last_unthrottled = 0;
	bt_ctrl.ctrl_tty_count = 0;

	return 0;
}
 
void bt_reset_session(s32 line)
{
	/* don't touch con/disc status here */
	bt_ctrl.session[line].upper_tty = NULL;
	bt_ctrl.session[line].pid = 0;
	bt_ctrl.session[line].rfcomm = NULL;
	bt_ctrl.session[line].dlci = 0; 
	bt_ctrl.session[line].state = BT_INACTIVE;
}

u8 *statename(s32 state)
{
	switch (state)
	{
	case BT_INACTIVE:
		return "BT_INACTIVE";
	case BT_LOWERCONNECTED:
		return "BT_LOWERCONNECTED";
	case BT_UPPERCONNECTED:
		return "BT_UPPERCONNECTED";
	case BT_ACTIVE:
		return "BT_ACTIVE";
	default:
		return "Unknown";	
	}
}

s32 bt_sprintf_status(u8 *buf)
{
	s32 pos = 0;
	s32 line;
	
	/* print all active sessions */
	pos += sprintf(buf+pos, "\n[BT Interface]\n");
	
	/* Data TTY:s */
	for (line = 0; line < BT_NBR_DATAPORTS; line++) {
		pos += sprintf(buf+pos, "line[%d] state: %s\n", line,
			       statename(SESSIONSTATE(line)));
	}

	/* Ctrl TTY */
	pos += sprintf(buf+pos, "BT CTRL state: %s [%d open]\n",
		       statename(SESSIONSTATE(line)), NBR_CTRL_FDS);

	pos += sprintf(buf+pos, "\n[BTMEM]\n");
	pos += sprintf(buf+pos, "Buffer holds: %d\n", buf_byte_count(-1));
	pos += sprintf(buf+pos, "Bytes left:   %d\n", buf_write_room());

	return pos;
}

/*
 * FIXME -- make this register function more general i.e
 * enable registering any layer. 
 * Parameters: line, protocol type, protocol specific struct
 */
s32
bt_register_rfcomm(struct rfcomm_con *rfcomm, u8 dlci)
{
	s32 line = rfcomm->line;
	s32 found = -1;

	if ((SESSIONSTATE(line) == BT_INACTIVE) || 
	    (SESSIONSTATE(line) == BT_UPPERCONNECTED)) {
		/* now register ! */
		DSYS(__FUNCTION__ ": dlci %d on line %d\n", dlci, line);
		
		bt_ctrl.session[line].rfcomm = rfcomm; 
		bt_ctrl.session[line].dlci = dlci;
		if (SESSIONSTATE(line) == BT_INACTIVE)
			SESSIONSTATE(line) = BT_LOWERCONNECTED;
		else {	
			SESSIONSTATE(line) = BT_ACTIVE;
			NBR_ACTIVE++;
		}
		found = 1;
	}
	
	if (!found)
		D_WARN(__FUNCTION__ ": Line %d busy [%s]\n", 
		       line, statename(SESSIONSTATE(line)));
	return found;
}

s32
bt_register_sdp(u8 line, u8 sdpID)
{
	s32 found = 0;

	if (!bt_stack_initiated) {
		D_WARN(__FUNCTION__ ": Bluetooth stack not initialised\n");
		return -1;	
	}

	/* Better not have any sdp data pending for this connection */

	if (bt_ctrl.session[line].sdpRequestResponseData) {
		D_WARN(__FUNCTION__ ": Pending SDP data for this new connection on line %d\n", line);
	}

	if (SESSIONSTATE(line) == BT_INACTIVE) {
		/* now register ! */
		DSYS(__FUNCTION__ ": Line %d\n", line);
		SESSIONSTATE(line) = BT_ACTIVE;
		bt_ctrl.session[line].sdpID = sdpID;
		found = 1;
	}

	if (!found)
		D_WARN(__FUNCTION__ ": Could not find any available lines\n");

	return found;
}

s32
bt_unregister_rfcomm(s32 line)
{
	BT_DRIVER(__FUNCTION__ ": Line %d\n", line);	

	if (SESSIONSTATE(line) == BT_ACTIVE) {
		bt_ctrl.session[line].rfcomm = 0; 
		bt_ctrl.session[line].dlci = 0;

		/* FIXME -- should rfcomm always send bt_hangupline 
		   when disconnecting ? */

                BT_DRIVER("Upper tty still open...\n");
                SESSIONSTATE(line) = BT_UPPERCONNECTED;
		NBR_ACTIVE--;
        } else if (SESSIONSTATE(line) == BT_LOWERCONNECTED) {
		bt_reset_session(line);		
        } else {
		D_WARN(__FUNCTION__ ": Inactive session\n");
		return -1;
	}

	/* notify upper tty that this rfcomm connection is down */
#ifdef __KERNEL__
	bt_hangupline(line);
#endif
	return 0;
}

s32 bt_unregister_sdp(s32 line)
{
	BT_DRIVER(__FUNCTION__ ": Line %d\n", line);	

	if (!bt_stack_initiated) {
		D_WARN(__FUNCTION__ ": Bluetooth stack not initialised\n");
		return -1;	
	}

	/* Part of unregistering SDP is to deallocate any sdp request
	   response data AND clear length and pointer */

	if (bt_ctrl.session[line].sdpRequestResponseData) {
		DSYS(__FUNCTION__ ": Free request data 0x%x\n",
		     (unsigned int)bt_ctrl.session[line].sdpRequestResponseData);
		kfree(bt_ctrl.session[line].sdpRequestResponseData);
		bt_ctrl.session[line].sdpRequestResponseData = NULL;
		bt_ctrl.session[line].sdpRequestResponseDataLength = 0;
	}

	if (SESSIONSTATE(line) == BT_ACTIVE) {
		SESSIONSTATE(line) = BT_INACTIVE;
		bt_ctrl.session[line].sdpID = -1;
	}

	return 0;
}

s32
bt_register_tty(struct tty_struct *tty)
{
	s32 line = GET_TTYLINE(tty);
 
	BT_DRIVER("Registering tty on line %d (%s)\n", line, current->comm);
	
	/* Allow multiple open for ttyBTC */
	if (line == BT_NBR_PORTS-BT_NBR_CTRLPORTS) {
		NBR_CTRL_FDS++;
		
		BT_DRIVER("Now %d open fd:s for ttyBTC [%s]\n", 
			  NBR_CTRL_FDS, current->comm);
		if (NBR_CTRL_FDS > 1)
			return 0; /* already registered state */
	} else {
		/* Data line ! */
		if (!bt_stack_initiated) {
			D_WARN(__FUNCTION__ ": Bluetooth stack not initialised\n");
			return -EPERM;
		}
	}

	if ((SESSIONSTATE(line) == BT_LOWERCONNECTED) ||
	    (SESSIONSTATE(line) == BT_INACTIVE)) {
		NBR_UPPER++;
		bt_ctrl.session[line].upper_tty = tty;
		bt_ctrl.session[line].pid = current->pid;
		tty->driver_data = &bt_ctrl.session[line];

		if (SESSIONSTATE(line) == BT_INACTIVE)
                        SESSIONSTATE(line) = BT_UPPERCONNECTED;
                else {
                        SESSIONSTATE(line) = BT_ACTIVE;
			NBR_ACTIVE++;
#ifdef BT_USELINEBUF
			/* check if there are pending data */
			bt_linebuf_send(line);
#endif
		}
		return 0;
	} else {
		D_WARN(__FUNCTION__ ": Line busy !\n");
	}
	return -EBUSY;
}

s32
bt_unregister_tty(struct tty_struct *tty, s32 line)
{
	BT_DRIVER("Unregistering tty on line %d\n", line);

	if (line == BT_NBR_PORTS-BT_NBR_CTRLPORTS) {
		if (--NBR_CTRL_FDS != 0)
			return 0; /* still more open fd:s on ttyBTC */
	} else if (current->pid != bt_ctrl.session[line].pid) {
		/* The pid closing the tty is not the one that opened it */
		BT_DRIVER(__FUNCTION__ ": Invalid pid\n");
		return -1;
	}

	/* Check that it is ok to close this line ... 
	   (flush buffers etc etc etc) */

	if ((SESSIONSTATE(line) == BT_ACTIVE) || 
	    (SESSIONSTATE(line) == BT_UPPERCONNECTED)) {
                if (SESSIONSTATE(line) == BT_ACTIVE) {
			SESSIONSTATE(line) = BT_LOWERCONNECTED;
			NBR_ACTIVE--;
		}
                else
                        bt_reset_session(line);

		NBR_UPPER--;
	}
	else {
		D_WARN(__FUNCTION__ ": TTY not previously registered\n");
		return -ENODEV;
	}
	return 0; /* Until the above is fixed */
}

void
bt_shutdown(void)
{
	s32 i;
	struct bt_session *bt;
	DSYS("Shutting down bluetooth stack\n");

	if (bt_stack_initiated) {
		if (!bt_dfu_mode(-1)) {
			/* disconnect all active connections */
			for (i = 0; i < BT_NBR_DATAPORTS;i++) {
				bt = &bt_ctrl.session[i];
				if ((bt->state == BT_ACTIVE) || 
				    (bt->state == BT_LOWERCONNECTED)) {
					DSYS("Disconnecting dlci %d on line %d\n", 
					     bt->dlci, i);
					rfcomm_disconnect_req(i);
					bt->dlci = 0;
					bt->rfcomm = NULL;
				}
			}

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
			sec_client_shutdown(); /* Inform that stack is getting closed */
#endif

			rfcomm_close();
			sdp_shutdown();
			tcs_shutdown();
			l2cap_shutdown();
		}

		hci_shutdown();
	}

	bt_dfu_mode(0);

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	bcsp_shutdown();
#endif

	btmem_shutdown();

#ifdef __CRIS__
	del_timer(&bt_clear_led_timer);
	bt_set_leds(NO_BLUETOOTH_ACTIVITY);
#endif

	bt_stack_initiated = 0;
	
	if (tmp_bt_buf) {
		free_page((unsigned long) tmp_bt_buf);
		tmp_bt_buf = NULL;
	}
}

static inline s32
bt_paranoia_check(struct tty_driver *bt_tty, kdev_t device, const u8 *routine)
{
#if BT_PARANOIA_CHECK
	if (!bt_tty) {
		printk("Warning: Null tty_driver struct for (%s) in %s\n",
		       kdevname(device), routine);
		return -EINVAL;
	}

	if (bt_tty->magic != BT_TTY_DRIVER_MAGIC) {
		printk("Warning: Bad magic number for bluetooth driver struct (%s) in %s\n", kdevname(device), routine);
		return -EINVAL;
	}
#endif
	return 0;
}

static const u8*
psmname(u16 psm)
{
	switch (psm)
	{
	case RFCOMM_LAYER:
		return "RCOMM";
	case SDP_LAYER:
		return "SDP";
	case  TCS_LAYER:
		return "TCS";
	default:
		return "UNKNOWN";
	}
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
void
start_wq_timer(struct timer_list *wq_timer,
	       u32 timeout, wait_queue_head_t *wq)
#else
void
start_wq_timer(struct timer_list *wq_timer,
	       u32 timeout, struct wait_queue **wq)
#endif /* LINUX_VERSION_CODE */
{
	init_timer(wq_timer);
	wq_timer->function = wq_timeout;
	wq_timer->data = (unsigned long)wq;
	wq_timer->expires = jiffies + timeout;
	add_timer(wq_timer);
//	printk(__FUNCTION__ ": wq: 0x%x, timer: 0x%x\n", wq, wq_timer);
}


/* fixme -- only works for one function call at a time */
void
release_wq_timer(struct timer_list *wq_timer)
{
	del_timer(wq_timer);
//	printk(__FUNCTION__ ": timer: 0x%x\n", wq_timer);
}

void
wq_timeout(unsigned long ptr)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	wait_queue_head_t *wq = (wait_queue_head_t *)ptr;
#else
	struct wait_queue **wq = (struct wait_queue **)ptr;
#endif /* LINUX_VERSION_CODE */
	DSYS(__FUNCTION__ "\n");

	/* wake up wait queue */
	wake_up_interruptible(wq);
}

/************************ MODULE STUFF **************************************/

#if defined(MODULE) || defined(__KERNEL__)

static void
__exit bt_exit(void) 
{
	unsigned long flags;
	s32 error;

	save_flags(flags);
	cli();
	if ((error = tty_unregister_driver(&bt_driver)))
		printk("SERIAL: Failed to unregister bluetooth driver (%d)\n",
		       error);
	restore_flags(flags);

	/* clear line discipline */
	tty_register_ldisc(N_BT, NULL);

	/* FIXME - Shut down all active tty:s if any */

	if (bt_stack_initiated)
		bt_shutdown();

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
	sec_man_remove_proc_file();
#endif
	sdp_remove_proc_file();

#ifdef CONFIG_BLUETOOTH_PROC
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	remove_proc_entry(bt_status.name, &proc_root);
	remove_proc_entry(bt_internal_info.name, &proc_root);
	remove_proc_entry(bt_proc_doit.name, &proc_root);
#ifdef CONFIG_BLUETOOTH_USE_TCI
	remove_proc_entry(tci_proc_entry.name, &proc_root);
#endif /* CONFIG_BLUETOOTH_USE_TCI */
#else
	proc_unregister(&proc_root, bt_status.low_ino);
	proc_unregister(&proc_root, bt_internal_info.low_ino);
	proc_unregister(&proc_root, bt_proc_doit.low_ino);
#ifdef CONFIG_BLUETOOTH_USE_TCI
	proc_unregister(&proc_root, tci_proc_entry.low_ino);
#endif /* CONFIG_BLUETOOTH_USE_TCI */
#endif /* LINUX_VERSION_CODE */
#endif /* CONFIG_BLUETOOTH_PROC */

	DSYS("Bluetooth Driver unregistered\n");
}

module_init(bt_init);
module_exit(bt_exit);

#endif /* MODULE */

/****************** END OF FILE bluetooth.c *********************************/
