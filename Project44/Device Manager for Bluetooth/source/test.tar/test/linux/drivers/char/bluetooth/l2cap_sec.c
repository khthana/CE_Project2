
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>
#include <linux/bluetooth/l2cap_sec.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/sec_client.h>
#include <linux/bluetooth/btmem.h>
#else /* user mode */
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <signal.h>
#include "include/l2cap_sec.h"
#include "include/l2cap.h"
#include "include/sec_client.h"
#include "include/btmem.h"
#endif

/****************** DEBUG CONSTANT AND MACRO SECTION ************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/****************** FUNCTION DEFINITION SECTION *****************************/

/* fixme --  add debug and return values in all functions called from stack to 
   indicate status */

void 
l2cap_sec_man_init(void)
{
	sec_man_init(L2CAP);
}

void
l2cap_check_allowed_security(u16 psm, BD_ADDR bd_addr, l2cap_con *con)
{
	/* If pending response should be sent, do it here */
	
	sec_man_check(L2CAP, bd_addr, psm, (u32) con);
}

void l2cap_process_sec_man_response(u16 result, u32 user_data)
{
	l2cap_con *con = (l2cap_con *) user_data;
	
	//printk("l2cap_process_sec_man_response : result %d\n", result);
	switch (result) {
	case SECURITY_OK: 
		/* send l2ca_connect_ind */
		l2ca_connect_ind(con);
		break;

	case UNKNOWN_REQUEST_TYPE:
	case UNKNOWN_REQUEST_VALUE:
		/* send connection response PSM not supported */
		l2ca_connect_rsp(con, RES_PSMNEG, STAT_NOINFO);
		break;

	case PSM_SECURITY_BLOCK:
	case AUTHENTICATION_FAILURE:
	case ENCRYPTION_FAILURE:
		/* send connection response PSM security block */
		l2ca_connect_rsp(con, RES_SECNEG, STAT_NOINFO);
		break;

	case GENERAL_FAILURE:
		/* send connection response PSM security block */
		l2ca_connect_rsp(con, RES_SECNEG, STAT_NOINFO);
		break;

	default:
		/* Print error message */
		break;
	}
}

/****************** END OF FILE l2cap_sec.c *********************************/
