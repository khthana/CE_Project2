
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>

#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/btmem.h>
#include <linux/bluetooth/bcsp.h>
#include <linux/bluetooth/bcsp_debug.h>
#else
#include <stdlib.h>
#include <errno.h>

#include "include/btcommon.h"
#include "include/btmem.h"
#include "include/bcsp.h"
#include "include/bcsp_debug.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#if SLIP_DEBUG
#define D(fmt...) printk("SLIP:      " fmt)
#define PRINTPKT(data, len) print_data(NULL, data, len)
#else
#define D(fmt...)
#define PRINTPKT(data, len)
#endif

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static void slip_send_add_byte(struct bcsp* bcsp, u8 data);

#if BCSP_PARSELOWER
static void slip_debug(const u8 *str, const struct bcsp *bcsp);
#endif

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/****************** FUNCTION DEFINITION SECTION *****************************/

s32
bcsp_slip_send(struct bcsp* bcsp)
{
	s32 i;

	D(__FUNCTION__ ":\n");
	PRINTPKT(bcsp->payload, bcsp->payload_length);

	if (!(bcsp->packet = kmalloc(2 * (4 + bcsp->payload_length) + 2, GFP_ATOMIC))) {
		return -ENOMEM;
	}

	bcsp->packet_length = 0;

	bcsp->packet[bcsp->packet_length++] = 0xC0;
	
	/* Send the BCSP header */
	slip_send_add_byte(bcsp, bcsp->flags);
	slip_send_add_byte(bcsp, bcsp->identifier | ((bcsp->payload_length & 0x0F) << 4));
	slip_send_add_byte(bcsp, bcsp->payload_length >> 4);
	slip_send_add_byte(bcsp, bcsp->checksum);

	/* Send the payload */
	for (i = 0; i < bcsp->payload_length; i++) {
		slip_send_add_byte(bcsp, bcsp->payload[i]);
	}

	/* Send CRC if wanted */
	if (BCSP_GET_CRC_PRESENT(bcsp)) {
		slip_send_add_byte(bcsp, bcsp->crc >> 8);
		slip_send_add_byte(bcsp, bcsp->crc & 0xFF);
	}

	bcsp->packet[bcsp->packet_length++] = 0xC0;

#if BCSP_PARSELOWER
	slip_debug("<== ", bcsp);
#endif 

	bcsp_write_lower(bcsp->packet, bcsp->packet_length);
	kfree(bcsp->packet);

	return bcsp->packet_length;
}

s32
bcsp_slip_receive(const u8* packet, u32 len)
{
	static u8 buffer[4 + 4096 + 2 + 1];
	static s32 length = 0;
	static s32 skipping = TRUE;
	struct bcsp bcsp;
	s32 i = 0;

	D(__FUNCTION__ "\n");

	bcsp_init_packet(&bcsp);
	
	if (skipping) {
		while (i < len) {
			if (packet[i++] == 0xC0) {
				length = 0;
				skipping = FALSE;
				break;
			}
		}

		bcsp.packet = NULL;
	}

	for (; i < len && !skipping; i++) {
		switch (packet[i]) {
		case 0xC0:
			skipping = TRUE;
			if (!length) {
				i--;
			}
			else if ((bcsp.packet = kmalloc(length, GFP_ATOMIC))) {
				memcpy(bcsp.packet, buffer, length);
				bcsp.packet_length = length;
			}
			break;

		case 0xDB:
			switch (packet[++i]) {
			case 0xDC:
				buffer[length++] = 0xC0;
				break;

			case 0xDD:
				buffer[length++] = 0xDB;
				break;

			default:
				skipping = TRUE;
				break;
			}
			break;

		default:
			buffer[length++] = packet[i];
			break;
		}

		if (length == sizeof(buffer)) {
			skipping = TRUE;
		}
	}

	if (bcsp.packet) {
#if BCSP_PARSELOWER
		slip_debug("==> ", &bcsp);
#endif
		bcsp_integrity_receive(&bcsp);
		kfree(bcsp.packet);
	}

        return i;
}

void
slip_send_add_byte(struct bcsp* bcsp, u8 data)
{
	switch (data) {
	case 0xC0:
		bcsp->packet[bcsp->packet_length++] = 0xDB;
		bcsp->packet[bcsp->packet_length++] = 0xDC;
		break;

	case 0xDB:
		bcsp->packet[bcsp->packet_length++] = 0xDB;
		bcsp->packet[bcsp->packet_length++] = 0xDD;
		break;

	default:
		bcsp->packet[bcsp->packet_length++] = data;
		break;
	}
}

#if BCSP_PARSELOWER

/*
 * Used to parse headers of sent/incoming BCSP packets
 * Also prints other potentially interesting stats 
 */

#include <linux/bluetooth/hci_internal.h>

void
slip_debug(const u8 *str, const struct bcsp *bcsp)
{
	extern hci_controller hci_ctrl;
	extern u8 winspace;
	extern u8 txseq;
	extern u8 txack;
	extern u8 rxack;
	extern u8 expected_rxseq;

	printk("%sseq: %ld, ack: %ld, winsize: %d, acl: %d, bufc: %d, length: %d\n",
	       str, BCSP_GET_SEQ(bcsp), BCSP_GET_ACK(bcsp), winspace,
	       hci_ctrl.hc_buf.acl_num, buf_byte_count(-1),
	       bcsp->packet_length);

	printk("Status: txseq: %d, txack: %d, cur_rxack: %d, exp_rxseq: %d\n",
	       txseq, txack, rxack, expected_rxseq);
}
#endif

/****************** END OF FILE slip.c **************************************/
