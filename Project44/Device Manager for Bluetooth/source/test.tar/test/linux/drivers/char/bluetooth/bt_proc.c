
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/module.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/malloc.h>
#include <linux/fs.h>
#include <linux/locks.h>
#include <linux/sched.h>
#include <linux/ioctl.h>
#include <linux/stat.h>
#include <asm/byteorder.h>
#include <linux/proc_fs.h>

#include <linux/bluetooth/bt_proc.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/rfcomm.h>

#else

#include "include/bluetooth.h"
#include "include/btcommon.h"
#include "include/hci.h"
#include "include/l2cap.h"
#include "include/rfcomm.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/****************** FUNCTION DEFINITION SECTION *****************************/

#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static s32 bt_read_status(char *buf, char **start, off_t offset, 
			  int len, int unused)
#else
static s32 bt_read_status(char *buf, char **start, off_t offset, int len)
#endif
#else
int bt_read_status(char *buf, int len)
#endif
{
	len = 0;
	len += sprintf(buf + len, "[LOCAL INFO]\n");
	len += sprintf(buf + len, "stack_initiated  : ");
	
	if (!bt_initiated()) {
		len += sprintf(buf + len, "FALSE\n");
		return len;
	} else {
		len += sprintf(buf + len, "TRUE\n");
	}

	len += sprintf(buf + len, "bytes_received   : %u\n",           //kainui : %u = unsigned integer
		       bt_stat.bytes_received);
	len += sprintf(buf + len, "bytes_sent       : %u\n",
		       bt_stat.bytes_sent);
	len += sprintf(buf + len, "local_bd_address : ");
	len += hci_sprint_local_bd(buf + len);
	len += sprintf(buf + len, "\n");
	
	len += sprintf(buf + len, "\n[REMOTE INFO]\n");
	len += hci_sprint_remote_info(buf + len);

	return len;
}
 

/* Read internal variables used for debugging */

#ifdef __KERNEL__
extern s32 bt_sprintf_status(u8 *buf);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
s32 bt_read_internal(char *buf, char **start, off_t offset,
		     int len, int unused)
#else
s32 bt_read_internal(char *buf, char **start, off_t offset, int len)
#endif /* LINUX_VERSION_CODE */
#else
int bt_read_internal(char *buf, int len)
#endif
{
	len = 0;
        len += sprintf(buf + len, "\n[Bluetooth Status]\n");
        len += sprintf(buf + len, "-----------------------------------------\n");

        if (!bt_initiated()) {
                len += sprintf(buf + len, "\nStack not initiated\n\n");
                return len;
        }

        len += sprintf(buf + len, "bytes received : %u\n",
                     bt_stat.bytes_received);
        len += sprintf(buf + len, "bytes sent     : %u\n",
                     bt_stat.bytes_sent);

	/* HW Info */
        len += sprintf(buf + len, "\n[Hardware]\n");
	len += sprintf(buf + len, "Vendor:        %s\n", bt_hw_vendor());
	len += sprintf(buf + len, "Firmware info: %s\n", bt_hw_firmware());

	/* print all active sessions */

#ifdef __KERNEL__
	len += bt_sprintf_status(buf + len);
#endif
        len += rfcomm_sprint_status(buf + len);
        len += l2cap_sprint_status(buf + len);
	len += sprintf(buf + len, "\n[HCI]\n");
	len += hci_sprint_remote_info(buf + len);
        len += hci_sprint_local_info(buf + len);

        len += sprintf(buf + len, "\n---------------------------------------\n");
        return len;
}


/*
 * General test function
 */

#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static s32 bt_doit(char *buf, char **start, off_t offset, int len, int unused)
#else
static s32 bt_doit(char *buf, char **start, off_t offset, int len)
#endif /* LINUX_VERSION_CODE */
#else
int bt_doit(char *buf, int len)
#endif
{
	len = 0;

	/*
	 * trigger something...
	 */

	len += sprintf(buf + len, "\n did it !\n");

	return len;
}

#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
struct proc_dir_entry bt_status = {
	0, /* dynamic */
	9, "bt_status", /* namelen and name*/
	S_IFREG | S_IRUGO, /* mode */
	1, 0, 0, /* nlinks, owner, group */
	0, /* size (unused) */
	NULL, /* operations, use default */
	&bt_read_status,
};


struct proc_dir_entry bt_internal_info = {
	0, /* dynamic */
	11, "bt_internal", /* namelen and name*/
	S_IFREG | S_IRUGO, /* mode */
	1, 0, 0, /* nlinks, owner, group */
	0, /* size (unused) */
	NULL, /* operations, use default */
	&bt_read_internal,
};


struct proc_dir_entry bt_proc_doit = {                    
	0, /* dynamic */
	7, "bt_doit", /* namelen and name*/
	S_IFREG | S_IRUGO, /* mode */
	1, 0, 0, /* nlinks, owner, group */
	0, /* size (unused) */
	NULL, /* operations, use default */
	&bt_doit,
};

#else /* LINUX_VERSION >= 2,4,0 */

struct proc_dir_entry bt_status = {
	0, /* dynamic */
	9, "bt_status", /* namelen and name*/
	S_IFREG | S_IRUGO, /* mode */
	1, 0, 0, /* nlinks, owner, group */
	0, /* size (unused) */
	NULL, /* inode operations, use default */
	NULL, /* file operations, use default */
	&bt_read_status,
};


struct proc_dir_entry bt_internal_info = {
	0, /* dynamic */
	11, "bt_internal", /* namelen and name*/
	S_IFREG | S_IRUGO, /* mode */
	1, 0, 0, /* nlinks, owner, group */
	0, /* size (unused) */
	NULL, /* operations, use default */
	NULL, /* file operations, use default */
	&bt_read_internal,
};


struct proc_dir_entry bt_proc_doit = {                    
	0, /* dynamic */
	7, "bt_doit", /* namelen and name*/
	S_IFREG | S_IRUGO, /* mode */
	1, 0, 0, /* nlinks, owner, group */
	0, /* size (unused) */
	NULL, /* operations, use default */
	NULL, /* file operations, use default */
	&bt_doit,
};

#endif  /* LINUX_VERSION_CODE */
#endif /* __KERNEL__ */

/****************** END OF FILE bt_proc.c ***********************************/
