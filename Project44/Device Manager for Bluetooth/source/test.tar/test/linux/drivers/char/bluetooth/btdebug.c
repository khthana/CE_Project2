
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/bluetooth/btdebug.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/time.h>
#else
#include "include/btdebug.h"
#endif
   
/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/****************** FUNCTION DEFINITION SECTION *****************************/

#ifdef __KERNEL__

static u8 buf[20];
static struct timeval tv_old = {0, 0};

u8* print_time(s32 use_stdout)
{
	s32 len, diff;
	struct timeval tv;  

	do_gettimeofday(&tv);
	
	diff = ((tv.tv_sec - tv_old.tv_sec)*1000000 + tv.tv_usec) - 
		tv_old.tv_usec;
	
	if (use_stdout == 1) {
		printk("[%03d,%06d<%06d>] ", 
		       (int)tv.tv_sec, (int)tv.tv_usec, diff);
	}
	else
	{
		len = sprintf(buf, "[%03d,%06d<%06d>] ", 
			      (int)tv.tv_sec, tv.tv_usec, diff);
		buf[len] = 0;
	}
	tv_old = tv;
	return buf;
}

#else

/* No timestamps in usermode yet */
char* print_time(int use_stdout)
{
	printf("No timestamps in usermode stack yet\n");
	return "No timestamps in usermode stack yet\n";
}
#endif

void 
print_data(const u8 *message, u8 *buf, s32 len)
{ 
	s32 t = 0;

#if BT_USE_TIMESTAMPS
	if (message)
		printk("\n%s %s (%d):\n", print_time(0), message, len);
#else
	if (message)
		printk("\n%s (%d):\n", message, len);
#endif
	while (t < len)
	{
		printk("0x%02x ", buf[t++]);
		if (!(t % 16))
			printk("\n");
	}
	if (t % 16)
		printk("\n");
}

const char* bd2str(const unsigned char *bd)
{
  static char buf[20];

  sprintf(buf, "%02X:%02X:%02X:%02X:%02X:%02X",
          bd[0], bd[1], bd[2], bd[3], bd[4], bd[5]);

  return buf;
}

/****************** END OF FILE debug.c *************************************/
