
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>

#include <linux/bluetooth/bcsp.h>
#include <linux/bluetooth/bcsp_debug.h>
#else
#include "include/bcsp.h"
#include "include/bcsp_debug.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#if MUX_DEBUG
#define D(fmt...) printk("MUX:       " fmt)
#else
#define D(fmt...)
#endif

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/****************** FUNCTION DEFINITION SECTION *****************************/

s32
bcsp_mux_receive(struct bcsp *bcsp)
{
	/* If we received an ack packet, we discard the packet, sice the ack
	   has already been handled by signal_rxack */

	if (bcsp->identifier == 0) {
		D(__FUNCTION__ ": Received ack, returning\n");
		bcsp_signal_rxack(BCSP_GET_ACK(bcsp));
		return 0;
	}
	
	if (BCSP_GET_PROTOCOL_TYPE(bcsp) == BCSP_RELIABLE) {
		D(__FUNCTION__ ": Sending to sequencing layer\n");
		return bcsp_sequence_receive(bcsp);
	} else if (BCSP_GET_PROTOCOL_TYPE(bcsp) == BCSP_UNRELIABLE) {
		D(__FUNCTION__ ": Sending to datagram layer\n");
		return bcsp_datagram_receive(bcsp);
	} else {
		/* This shouldn't be possible */
		BCSP_SYS(__FUNCTION__ ": Packet is neither reliable nor unreliable\n");
	}
	return 0;
}

s32
bcsp_mux_send(struct bcsp *bcsp)
{
	D(__FUNCTION__ "\n");
	return bcsp_integrity_send(bcsp);
}

s32 bcsp_send_txack(u8 txack)
{
	struct bcsp bcsp;

	D(__FUNCTION__ ": txack: 0x%x\n", txack);

	bcsp_init_packet(&bcsp);
	
	BCSP_SET_ACK(&bcsp, txack);
	BCSP_SET_SEQ(&bcsp, 0);
	bcsp.identifier = 0;  /* According to AN004.pdf page 20 */
	bcsp.payload_length = 0;

	return bcsp_integrity_send(&bcsp);
}

/****************** END OF FILE mux.c ***************************************/
