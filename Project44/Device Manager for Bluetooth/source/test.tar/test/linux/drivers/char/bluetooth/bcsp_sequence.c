
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>
#include <linux/types.h>
#include <linux/interrupt.h>
#include <linux/timer.h>

#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/bluetooth/btmem.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/bcsp.h>
#include <linux/bluetooth/bcsp_debug.h>
#else
#include "include/btmem.h"
#include "include/hci.h"
#include "include/bcsp.h"
#include "include/bcsp_debug.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#if SEQUENCE_DEBUG
#define D(fmt...) printk("SEQUENCE:  "fmt)
#else
#define D(fmt...)
#endif

#define WINSIZE 4
#define SEQUENCE_TIMEOUT (HZ/4) /* default 250 ms */

#define BCSP_RTX_MAX 20

/****************** TYPE DEFINITION SECTION *********************************/

typedef struct resend_buf {
	u32 len;
	u8 chn;
	u8 seq_nbr;
	u8 data[280];
} resend_buf;

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static void sequence_resend(void);
static void send_ack(void);

static void start_resend_timer(void);
static void release_resend_timer(void);

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

#ifdef __KERNEL__
static struct tq_struct resend_data_task;
static struct tq_struct send_ack_task;
#endif

#if BCSP_PARSELOWER
u8 txseq;
u8 txack;
u8 rxack;
u8 expected_rxseq;
u8 winspace;
#else
static u8 txseq;
static u8 txack;
static u8 rxack;
static u8 expected_rxseq;
static u8 winspace;
#endif

static u8 rtx_count = BCSP_RTX_MAX;

#ifdef __KERNEL__
static struct timer_list resend_timer;
#endif

static u8 resend_timer_active = FALSE;

static struct resend_buf resend_buffer[8];

/****************** FUNCTION DEFINITION SECTION *****************************/

void
bcsp_sequence_init(void)
{
#ifdef __KERNEL__
	resend_data_task.routine = (void*)sequence_resend;
	resend_data_task.data = NULL;

	send_ack_task.routine = (void*)send_ack;
	send_ack_task.data = NULL;
#endif

	txseq = 0;
	txack = 0;
	rxack = 0;
	expected_rxseq = 0;
	winspace = WINSIZE;
}

void
bcsp_sequence_shutdown(void)
{
	release_resend_timer();
}

s32
bcsp_sequence_receive(struct bcsp *bcsp)
{
	if (!bcsp_issyncronized()){	
		D(__FUNCTION__": Still not synced\n");
		return 0;
	}
	
	D(__FUNCTION__": txack:%d, expected_rxseq:%d, BCSP_GET_SEQ(bcsp):%d\n", txack, expected_rxseq, BCSP_GET_SEQ(bcsp));

	if (expected_rxseq == BCSP_GET_SEQ(bcsp)) {

		cli();
		txack = (BCSP_GET_SEQ(bcsp) + 1) % 8;
		expected_rxseq = (expected_rxseq + 1) % 8;
		sti();

		bcsp_signal_rxack(BCSP_GET_ACK(bcsp));
		
		/* FIXME: Do we need to schedule when winsize > 0 ? */
		if ((winspace > 0) && buf_count() && (hci_acl_num_cnt() > 0)) {
			/* ack is piggybacked in next tx data packet */
			D("<-data ack\n");
		} else {
			D("<-ack\n");
			send_ack();
		}
		
		bcsp_receive_top(bcsp->payload, bcsp->payload_length,
				 bcsp->identifier);
	} else { /* out of order rx seq nbr */ 
		if ((winspace > 0) && (hci_trig_send())) {
			/* ack is piggybacked in next tx data packet */
			printk("seq out-of-order [exp:%d, got:%ld]\n", 
			       expected_rxseq, BCSP_GET_SEQ(bcsp));

		} else {
			printk("seq out-of-order [exp:%d, got:%ld], send ack\n",
			       expected_rxseq, BCSP_GET_SEQ(bcsp));
			send_ack();
		}
	}

	return 0;
}

s32
bcsp_sequence_send(u8 *data, u32 len, u8 chn)
{
	struct bcsp bcsp;

	D(__FUNCTION__": rxack:%d, txack:%d, txseq:%d, winspace:%d\n", rxack, txack, txseq, winspace);
	
	if (winspace > 0) {
		bcsp_init_packet(&bcsp);

		bcsp.identifier = chn;

		BCSP_SET_PROTOCOL_TYPE(&bcsp, BCSP_RELIABLE);

		cli();
		BCSP_SET_SEQ(&bcsp, txseq);
		BCSP_SET_ACK(&bcsp, txack);
		bcsp.payload = data;
		bcsp.payload_length = len;
		sti();

		memcpy(resend_buffer[txseq].data, data, len);
		resend_buffer[txseq].len = len;
		resend_buffer[txseq].chn = chn;
		
		cli();
		txseq = (txseq + 1) % 8;
		winspace--;
		sti();
		
		D(__FUNCTION__": winspace:%d, txreq:%d\n", winspace, txseq);

		/* restart timer */
		start_resend_timer();
	} else {
#ifdef DBG_BCSPHEADER
		printk(__FUNCTION__": win=0\n");
#endif
		return 0;
	}

	return bcsp_mux_send(&bcsp);
}

void
bcsp_signal_rxack(u8 new_ack)
{
	s32 trig_send = FALSE;
	D(__FUNCTION__": Got new ack:%d, rxack is:%d, txseq:%d, winspace:%d\n", new_ack, rxack, txseq, winspace);

	if (rxack == new_ack) { /* Same ack again... */
		return;
	}

	cli();
	if (winspace == 0) {
		trig_send = TRUE;
	}

	D(__FUNCTION__": winspace before:%d [%d, %d]\n", 
	  winspace, rxack, new_ack);
	if (new_ack > rxack) {
		winspace += (new_ack - rxack);
	} else {
		winspace += (8 - (rxack - new_ack));
	}

	D(__FUNCTION__" win_up:%d\n", winspace);

	rxack = new_ack;
	rtx_count = BCSP_RTX_MAX;
	
	sti();
	
	if (winspace == WINSIZE) {
		release_resend_timer();
	} else if (winspace > WINSIZE) {
		printk(__FUNCTION__": ERROR  winspace > WINSIZE [%d]\n", 
		       winspace);
		winspace = WINSIZE;
		release_resend_timer();
	} 
	
	if (trig_send) {
		hci_trig_send();
	}
}

void
sequence_resend(void)
{
	struct bcsp bcsp;
	u8 resend_cnt = rxack;
	
	cli();
	while (rtx_count && (resend_cnt != txseq)) {
		sti();
		D(__FUNCTION__ ": seq_nbr:%d, last_ack:%d, cur_seq:%d\n",
                  resend_cnt, rxack, txseq);
		
		bcsp_init_packet(&bcsp);
		
		bcsp.identifier = resend_buffer[resend_cnt].chn;
		
		BCSP_SET_PROTOCOL_TYPE(&bcsp, BCSP_RELIABLE);
		
		BCSP_SET_SEQ(&bcsp, resend_cnt);
		cli();
		BCSP_SET_ACK(&bcsp, txack);
		sti();
		bcsp.payload = resend_buffer[resend_cnt].data;
		bcsp.payload_length = resend_buffer[resend_cnt].len;
		
		bcsp_mux_send(&bcsp);
		resend_cnt = (resend_cnt + 1) % 8;
	}       
	sti();

	rtx_count--;
	
	if (rtx_count == 0) {
		printk("ERROR : giving up on rtx!\n");
		/* fixme -- signal link down etc. */
	} else {
		start_resend_timer();
	}
}

void
send_ack(void)
{
	u8 tmp;
	cli();
	tmp = txack;
	sti();
	bcsp_send_txack(tmp);
}

void
start_resend_timer(void)
{
	if (resend_timer_active) {
		release_resend_timer();
	}

#ifdef __KERNEL__
	init_timer(&resend_timer);
	resend_timer.function = (void*)sequence_resend;
	resend_timer.data = 0;
	resend_timer.expires = jiffies + SEQUENCE_TIMEOUT;
	
	resend_timer_active = TRUE;
	
	add_timer(&resend_timer);
#endif
}

void
release_resend_timer(void)
{
	if (resend_timer_active) {
		resend_timer_active = FALSE;
#ifdef __KERNEL__
		del_timer(&resend_timer);
#endif
	}
}

/****************** END OF FILE sequence.c **********************************/
