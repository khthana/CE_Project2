/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>

#include <asm/byteorder.h>
#include <asm/unaligned.h>

#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/bcsp.h>
#include <linux/bluetooth/bcsp_debug.h>
#else
#include <asm/unaligned.h>

#include "include/btcommon.h"
#include "include/bcsp.h"
#include "include/bcsp_debug.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#if DATAGRAM_DEBUG
#define D(fmt...) printk("DATAGRAM:  " fmt)
#define PRINTPKT(data, len) print_data(NULL, data, len)
#else
#define D(fmt...)
#define PRINTPKT(data, len)
#endif

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static s32 handle_sync_pkt(struct bcsp *bcsp);

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

static s32 bcsp_datagram_initiated = 0;

/****************** FUNCTION DEFINITION SECTION *****************************/

void 
bcsp_datagram_init(void)
{
	bcsp_datagram_initiated = 1;
}

void 
bcsp_datagram_shutdown(void)
{
	bcsp_datagram_initiated = 0;
}

s32
bcsp_datagram_receive(struct bcsp *bcsp)
{
	if (!bcsp_datagram_initiated)
		return 0;            /* FIXME: Should this be an error code? */

	if (handle_sync_pkt(bcsp)) {
		return 0;
	}

	D(__FUNCTION__ ": Datagram packet received:\n");
	PRINTPKT(bcsp->payload, bcsp->payload_length);
	
	return 0;
}

s32
bcsp_datagram_send(u8 *data, u32 len, u8 chn)
{
	struct bcsp bcsp;
	
	bcsp_init_packet(&bcsp);

	BCSP_SET_PROTOCOL_TYPE(&bcsp, BCSP_UNRELIABLE);
	
	bcsp.payload = data;
	bcsp.payload_length = len;
	
	return bcsp_mux_send(&bcsp);
}

s32
handle_sync_pkt(struct bcsp *bcsp)
{
	u32 sync_string;

	if (bcsp->payload_length < sizeof(u32)) {
		return FALSE;
	}
	
	sync_string = le32_to_cpu(get_unaligned((u32 *)bcsp->payload));

	switch (sync_string) {

	case SYNC:	
		D(__FUNCTION__ ": Found SYNC\n");
		D(__FUNCTION__ ": Send SYNC_RSP\n");
		bcsp_send_sync(SYNC_RSP);
		return TRUE;

	case SYNC_RSP:
		D(__FUNCTION__": Found SYNC_RSP\n");
		bcsp_syncronized();
		return TRUE;

	case CONF: /* this should always be done */
		D(__FUNCTION__ ": Found CONF, silent discard\n");
		return TRUE;

	case CONF_RSP:
		D(__FUNCTION__": Found CONF_RSP\n");
		return TRUE;
	default:
		return FALSE;
	}
}

s32
bcsp_send_sync(u32 type)
{
	struct bcsp bcsp;
	u32 payload = cpu_to_le32(type);
	
	bcsp_init_packet(&bcsp);
	
	bcsp.identifier = 1; 
	bcsp.payload = (u8 *)&payload;
	bcsp.payload_length = sizeof(u32);

	return bcsp_mux_send(&bcsp);
}

/****************** END OF FILE sequence.c **********************************/
