
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/malloc.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/rfcomm.h>
#include <linux/bluetooth/rfcomm_internal.h>
#include <linux/bluetooth/rfcomm_sec.h>
#include <linux/bluetooth/sec_client.h>
#include <linux/bluetooth/btmem.h>
#else /* user mode */
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <signal.h>
#include "include/bluetooth.h"
#include "include/l2cap.h"
#include "include/rfcomm.h"
#include "include/rfcomm_internal.h"
#include "include/rfcomm_sec.h"
#include "include/sec_client.h"
#include "include/btmem.h"
#endif

/****************** DEBUG CONSTANT AND MACRO SECTION ************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

/****************** FUNCTION DEFINITION SECTION *****************************/
  
void 
rfcomm_sec_man_init(void)
{
	sec_man_init(RFCOMM);
}

void 
rfcomm_check_allowed_security(BD_ADDR bd_addr, u8 dlci, rfcomm_con *rfcon)
{
	sec_man_check(RFCOMM, bd_addr, dlci, (u32) rfcon);
}

void
rfcomm_process_sec_man_response(u16 result, u32 user_data, u32 request_value)
{
	u8 tmp_dlci;
	rfcomm_con *rfcon = (rfcomm_con*) user_data;

	tmp_dlci = (u8) request_value;
	
	switch (result) {
	case SECURITY_OK: 
		rfcon->dlci[tmp_dlci].state = CONNECTED;

		if (valid_dlci(tmp_dlci))
		{
			
			bt_register_rfcomm(rfcon, tmp_dlci);
			bt_connect_cfm(CREATE_RFCOMM_ID(rfcon->line, tmp_dlci), 0 /* status ok*/ );			

#if 0
			/* This part was taken from rfcomm.c and should perhaps
			   reside there */
			/* Here we could send a PN packet for negotiating the
			   frame size, but sice we are the server it's not sure
			   that the oposite side will respond correctly ?!? */

			/* rfcomm mtu must be less than l2cap mtu due to 
			   rfcomm header size */
			printk("rfcomm (S) trying to negotiate mtu (%d)...\n",
			       l2cap->remote_mtu-5);

			send_pn_msg(rfcomm, 7, (l2cap->remote_mtu-5), 0, 0,
				    tmp_dlci, TRUE);
			rfcon->dlci[tmp_dlci].state = NEGOTIATING;
#endif

			rfcomm_ua_msg(rfcon, tmp_dlci);
		}
		else
		{
			printk("rfcomm_process_sec_man_response : invalid dlci [%d]\n", tmp_dlci);
		}
		break;

	case UNKNOWN_REQUEST_TYPE:
	case UNKNOWN_REQUEST_VALUE:
		/* send negative connection response */
		rfcon->dlci[tmp_dlci].state = DISCONNECTED;
		rfcomm_dm_msg(rfcon,tmp_dlci);
		break;

	case PSM_SECURITY_BLOCK:
	case AUTHENTICATION_FAILURE:
	case ENCRYPTION_FAILURE:
		/* send negative connection response */
		rfcon->dlci[tmp_dlci].state = DISCONNECTED;
		rfcomm_dm_msg(rfcon,tmp_dlci);
		break;

	case GENERAL_FAILURE:
		/* send negative connection response */
		rfcon->dlci[tmp_dlci].state = DISCONNECTED;
		rfcomm_dm_msg(rfcon,tmp_dlci);
		break;

	default:
		/* Print error message */
		break;
	}
}

/****************** END OF FILE rfcomm_sec.c *********************************/
