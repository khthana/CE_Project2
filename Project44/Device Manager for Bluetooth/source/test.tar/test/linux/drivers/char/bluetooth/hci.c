
/****************** INCLUDE FILES SECTION ***********************************/

#define __NO_VERSION__ /* don't define kernel_version in module.h */

#ifdef __KERNEL__
#include <linux/config.h>
#include <linux/bluetooth/sysdep-2.1.h>
#include <linux/malloc.h>
#include <linux/timer.h>
#include <linux/bluetooth/hci.h>
#include <linux/bluetooth/hci_internal.h>
#include <linux/bluetooth/btdebug.h>
#include <linux/bluetooth/bluetooth.h>
#include <linux/bluetooth/l2cap.h>
#include <linux/bluetooth/l2cap_con.h>
#include <linux/bluetooth/tcs.h>
#include <linux/bluetooth/btmem.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/bluetooth/sec_client.h>
#include <asm/io.h>
#include <asm/byteorder.h>
#include <asm/unaligned.h>

#else /* user mode */
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <asm/unaligned.h>

#include "include/bluetooth.h"
#include "include/hci.h"
#include "include/hci_internal.h"
#include "include/btdebug.h"
#include "include/l2cap.h"
#include "include/l2cap_con.h"
#include "include/btmem.h"
#include "include/tcs.h"
#include "include/sec_client.h"
#include "include/local.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#define ACL_LINK 1
#define SCO_LINK 0

#define HCI_BLOCK 1
#define HCI_NON_BLOCK 0

/* If using host flow control, this is what we can store in our inbuffers */
#define HCI_ACL_LEN 500
#define HCI_SCO_LEN 255
#define HCI_ACL_NUM 4
#define HCI_SCO_NUM 2

/* Now we will define all the different packet types */

#define DM1 0x0008
#define DM3 0x0400
#define DM5 0x4000
#define DH1 0x0010
#define DH3 0x0800
#define DH5 0x8000

/* master slave switch stuff */
#define MS_SWITCH_BECOME_MASTER 0x00
#define MS_SWITCH_REMAIN_SLAVE  0x01
#define DONT_ALLOW_ROLE_SWITCH  0x00
#define ALLOW_ROLE_SWITCH       0x01

#define HCI_SYNC_FIX

#ifdef HCI_EMULATION
#define ACL_NUM 10
#define ACL_LEN 800 

#define SCO_NUM 2
#define SCO_LEN 100

#define HCI_HDL 0
#define ACL_CON 0x1
#endif

#define USE_NCPTIMER 
#define NCP_TIMEOUT (2*HZ)

/****************** TYPE DEFINITION SECTION *********************************/

/* cmd_t and cmd_buf are structures used to handle the queue of commands
   waiting to be sent on the serial port */

typedef struct cmd_t {
	u8* data;
	u8 len; /* max 255 */
} cmd_t;

struct cmd_buf {
	u32 first_free; /* index in cmd_buf */
	u32 next_to_send; /* index in cmd_buf */
	u8 count;
	cmd_t buf[NBR_CMD_BUFS];
};

/**************kainui add*************/
struct remote_device {
        u8  bd_addr[6];
        unsigned char* friendly_name;
        int status;
};

struct device_con {
        u8  bd_addr[6];
        unsigned char* friendly_name;
};
/*************************************/

/* These are the states the state machine in hci_receive_data can be in */
enum states { WAIT_FOR_PACKET_TYPE, WAIT_FOR_EVENT_TYPE, WAIT_FOR_EVENT_LENGTH,
	      WAIT_FOR_EVENT_PARAM, WAIT_FOR_ACL_HDR, WAIT_FOR_ACL_DATA, 
	      WAIT_FOR_SCO_HDR, WAIT_FOR_SCO_DATA, WAIT_FOR_TIMEOUT };

#ifdef HCI_EMULATION

/* If we are using the HCI emulation, we need a definition of the event packet
   to, see part H:1 chapter 4.4.2 of the baseband core specification for a
   description of the HCI event packet. */

typedef struct event_struct {
	u8 pkt_type;
	u8 event_type;
	u8 len;
	u8 data[0];
} __attribute__ ((packed)) event_struct;
#endif

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static void process_event(u8 *buf, u32 len, u32 event_code);
static void process_return_param(u8 *buf);
static void process_acl_data(hci_in_buffer* in_buf, u32 pb_flag);
static void process_sco_packet(u8 *data, u32 hci_hdl, u32 len);
static hci_in_buffer* get_inbuffer(u32 hci_hdl);
static hci_in_buffer* get_free_inbuffer(void);
static u32 send_acl_packet(bt_tx_buf *tx_buf);
static void set_acl_hdr(u8 *data, u32 len, u8 pb, u8 bc, u32 hci_hdl);
static u16 hci_handle(void *data);
static cmd_t* get_next_cmd(void); 
static s32 insert_cmd(u8* cmd, u8 len);
static void init_cmd_buf(void);
static void send_cmd_queue(void);
static void update_nhcp(s32 nhcp);
static s32 send_inq_cmd_block(u8 *cmd, u8 len, u8 inq_len);
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
static u8* get_bd(u16 con_hdl);
#endif
static s32 get_con_hdl(u8 *bd);

/* Link Control Commands */
static s32 create_connection(u8 *bd, u32 pkt_type, u8 psrm, u8 psm, u32 c_off, u32 rol_sw);
static s32 disconnect(u32 hdl, u8 reason);
static s32 accept_connection_request(u8 bd_addr[], u8 role);
static s32 reject_connection_request(u8 bd_addr[], u32 reason);
static s32 change_connection_packet_type(u32 hci_hdl, u32 pkt_type);
static s32 remote_name_request(u8 *bd);

/* Link Policy Commands */
static s32 role_discovery(u16 con_hdl);
static s32 write_link_policy_settings(u16 con_hdl, u16 settings);

/* Host Controller and Baseband Commands */
static s32 write_inquiryscan_activity(u32 interval, u32 wind);
static s32 write_automatic_flush_timeout(u16 con_hdl, u16 n);
static s32 hci_set_host_controller_flow_control(u32 enable);
static s32 hci_host_buffer_size(u16 acl_len, u8 sco_len, u16 acl_num, u16 sco_num);
static s32 host_nbrcompleted_packets(u32 hci_hdl, u32 nbr_of_packets);

/* Informational Parameters (HCI_IP) */

/* Other functions */
static s32 hci_update_load_factor(void);
static s32 hci_read_buffer_size(s32 block); 
static void set_hci_con(u8 *bd, s32 con_hdl);
static void set_hci_con_name(u8 *bd, u8 *name);
static void reset_hci_con_bd(u16 con_hdl);

#ifdef USE_NCPTIMER
static void start_ncp_timer(void);
static void release_ncp_timer(void);
#endif

#define USE_INQTIMER 1
#ifdef USE_INQTIMER
static void start_inq_timer(u8 inq_len);
static void release_inq_timer(void);
#endif

#ifdef __KERNEL__
#ifdef USE_NCPTIMER
static void ncp_timeout(unsigned long ptr);
#endif
static void cmd_timeout(unsigned long ptr);
#ifdef USE_INQTIMER
static void inq_timeout(unsigned long ptr);
#endif
#endif

#ifdef HCI_EMULATION
static void hci_emulator(u8 *data, u32 len);
static void command_handler(u8 *data);
static s32 set_cmd_status_event(event_struct *event, u8 *cmd);
static s32 set_con_req_event(event_struct *event, u8 *bd, u8 con_type);
static s32 set_con_cpl_event(event_struct *event, u8 status, u8 *bd,
			     u16 hci_hdl,u8 con_type);
static s32 set_discon_cpl_event(event_struct *event, u16 hci_hdl, u8 reason);
#endif

static void send_acl_data_task(void);

unsigned char* get_remote_friendly_name(u8* tmp_bd); //kainui add
int get_num_remote_device(void);
int get_num_inquiry_result(void);
unsigned char* get_device_con_address(int num_remote_device1);
struct remote_device remote_device[2];  //kainui add
struct device_con device_con[2]; //kainui add
int num_remote_device = 0; //kainui add : number of remote device that found
int num_inquiry_result = 0; //kainui add
int num_device_con = 0;

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

static struct cmd_buf cmd_buf;

/* Struct used for sending command packets */
cmd_pkt c_pkt;

/* The states for the switch-statement in hci_receive_data fuction */
static enum states state;

/* General HCI controller struct, contains vital information about buffer
   sizes and connections */
hci_controller hci_ctrl = {{0, 0, 0, 0, 0}};


#ifdef __KERNEL__
#ifdef USE_NCPTIMER
static struct timer_list hci_ncp_timer;
#endif

static struct timer_list hci_cmd_timer;

#ifdef USE_INQTIMER
static struct timer_list hci_inq_timer;
#endif

#ifdef USE_NCPTIMER
static struct hw_info {
	u32 max_acl_num;
	u32 acl_num_count; /* since last timeout */
} hw;
#endif

/* ================================= */

static struct tq_struct send_cmd_task;
static struct tq_struct send_data_task;

/* semaphore for protecting shared data */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
static struct semaphore hci_cmd_semaphore = MUTEX;
static struct semaphore hci_inq_semaphore = MUTEX;
#else
static struct semaphore hci_cmd_semaphore;
static struct semaphore hci_inq_semaphore;
#endif /* LINUX_VERSION_CODE */

#endif /* __KERNEL__ */

static u32 hci_cmd_pending = 0;
static u32 hci_inq_pending = 0;
static u8 hci_inq_aborted = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
struct wait_queue *hci_wq = NULL;
struct wait_queue *inq_wq = NULL;
struct wait_queue *set_baudrate_wq = NULL;
struct wait_queue *test_wq = NULL;
#else
wait_queue_head_t hci_wq;
wait_queue_head_t inq_wq;
wait_queue_head_t set_baudrate_wq;
wait_queue_head_t test_wq;
#endif /* LINUX_VERSION_CODE */

static s32 test_wq_active = 0;

static s32 result_param;

static struct inquiry_results *inq_res = NULL;

static s32 test_hci_hdl;

/* temp solution to handle m/s switch */
static s32 force_msswitch = 0;
static s32 i_am_initiator = 0;

/* In order to change load factor, store the other class of device parameters */
static u8 class_of_device[3];
/* If maximum BT connections is not set from above, use 7 as default */
int bt_max_connections = 7;
int i;
u8* friendly_name = "";
u8* remote_friendly_name = "no connection";

/****************** FUNCTION DEFINITION SECTION *****************************/

/*
 * Parses the serial data and sends it to either the parse_acl_packet,
 * parse_sco_packet or the parse_event_packet, depending on the packet type
 */

void
hci_receive_data(u8* data, u32 count)
{
	static u32 event_len;
	static u32 data_len;
	static u32 event_type;
	static u32 pb_flag;
	static u32 bc_flag;
	static u32 hci_hdl;
	static u8 event_buf[256];
	static u8 hdr[4];
	static hci_in_buffer *in_buf;
	static u32 tmp_pos;

	u32 c;     /* Temporary variable for index calculations */   
	u8 *buf; /* Temporary pointer to the incoming data */
	u32 tmp_data_len;
 
	PRINTPKT(__FUNCTION__ ": ", data, count);
  
	tmp_data_len = count;
	buf = data;

	/* Here we get a chunk of data from the serial port. When a complete 
	   packet is received it is copied into a buffer and sent to the 
	   processing function */
  
	D_INDATA(__FUNCTION__ ": hci-%d\n", tmp_data_len);
	while (count > 0) {
		switch (state) {
			
		  /* The first byte will tell us whether it is an event or a
		     data packet */
		case WAIT_FOR_PACKET_TYPE:
			D_STATE(__FUNCTION__ ": WAIT_FOR_PACKET_TYPE\n");
			tmp_pos = 0;
			switch(*buf) {
			case EVENT_PKT: state = WAIT_FOR_EVENT_TYPE; break;
			case ACL_PKT: state = WAIT_FOR_ACL_HDR; break;
			case SCO_PKT: state = WAIT_FOR_SCO_HDR; break;
			default:
				D_ERR(__FUNCTION__ ": discarding %d bytes\n",
				      count);
				/* An unrecognized HCI header type is usually a
				 * sign of a problem with the lower level 
				 * driver. For example, if the UART drops some
				 * bytes due to high interrupt latency. In this
				 * case we'll try to resync by just dropping 
				 * this buffer and trying again at the start of
				 * the next one.
				 * --gmcnutt
				 */
				return;
			}
			buf++;
			count--;
			break;

			/* If it is an event packet we wait for the next byte
			   which tell us which kind of event it is */ 
		case WAIT_FOR_EVENT_TYPE:
			D_STATE(__FUNCTION__ ": WAIT_FOR_EVENT_TYPE\n");
			event_type = *buf;
			state = WAIT_FOR_EVENT_LENGTH;
			buf++;
			count--;
			break;

			/* If it is an event the length-field is one byte */
		case WAIT_FOR_EVENT_LENGTH:
			D_STATE(__FUNCTION__ ": WAIT_FOR_EVENT_LENGTH\n");
			event_len = *buf;
			buf++;
			count--;

			/* If we don't check this and the lower level driver
			   gives us some trashed values then we might write
			   beyond the end of our event buffer in a memcpy 
			   below.
			   --gmcnutt
			 */
			if (event_len > sizeof(event_buf)) {
				D_ERR(__FUNCTION__ ": %d is too big for our "\
				      "event buffer -- discarding buffer\n",
				      event_len);
				state = WAIT_FOR_PACKET_TYPE;
				return;
			}

			if (event_len <= count) {
				process_event(buf, event_len, event_type);
                                buf += event_len;
				count -= event_len;
				state = WAIT_FOR_PACKET_TYPE;
			} else {
				state = WAIT_FOR_EVENT_PARAM;
			}
			break;

			/* Before we can parse the event, we wait for the
			   whole event */
		case WAIT_FOR_EVENT_PARAM:
			D_STATE(__FUNCTION__ ": WAIT_FOR_EVENT_PARAM\n");
			if (tmp_pos < event_len) {
				c = MIN(count, event_len - tmp_pos);
				memcpy(event_buf + tmp_pos, buf, c);
				tmp_pos += c;
				count -= c;
				buf += c;
				if (tmp_pos == event_len) {
					process_event(event_buf, event_len,
						      event_type);
                                        state = WAIT_FOR_PACKET_TYPE;
				}
			}
			break;

			/* Here we wait for the whole data header, four bytes*/
		case WAIT_FOR_ACL_HDR:
			D_STATE(__FUNCTION__ ": WAIT_FOR_ACL_HDR\n");
			c = MIN(count, ACL_HDR_LEN - tmp_pos);
			memcpy(hdr + tmp_pos, buf, c);
			tmp_pos += c;
			buf += c;
			count -= c;
			if (tmp_pos == ACL_HDR_LEN) {
				u32 tmp_hdr = le32_to_cpuu(hdr);
				hci_hdl = GET_BITS(tmp_hdr, 0, 12);
				pb_flag = GET_BITS(tmp_hdr, 12, 2);
				bc_flag = GET_BITS(tmp_hdr, 14, 2);
				data_len = GET_BITS(tmp_hdr, 16, 16);

				/* Check the length to make sure we won't 
				   overrun in_buf->buf_ptr in a memcpy later.
				   --gmcnutt
				 */
				if (data_len > HCI_IN_SIZE) {
					D_ERR(__FUNCTION__ ": %d is too big "\
					      "for our HCI input buffers -- "\
					      "discarding buffer\n",
					      data_len);
					state = WAIT_FOR_PACKET_TYPE;
					return;
				}

				if (pb_flag == L2CAP_FRAME_START) {
					D_REC(__FUNCTION__ ": New frame\n");
					in_buf = get_free_inbuffer();
					if (in_buf) {
						in_buf->nbr_of_hci_pkt = 1;
						in_buf->hci_hdl = hci_hdl;
					}	
				} else {
					D_REC(__FUNCTION__ ": Cont frame\n");
					in_buf = get_inbuffer(hci_hdl);
					if (in_buf) {
						in_buf->nbr_of_hci_pkt++;
					}
				}

				host_nbrcompleted_packets(hci_hdl, 1);

				/* When we change state we reset data_index,
				   because we are using separate buffers for
				   the HCI header and the HCI data */
				tmp_pos = 0;
				state = WAIT_FOR_ACL_DATA;
			} else if (tmp_pos < ACL_HDR_LEN) {
				D_REC(__FUNCTION__ ": Didn't got whole header length, waiting for more\n");
			} else {
				D_ERR(__FUNCTION__ ": incorredt ACL header length\n");
			}
			break;

			/* Finally we process the data, i.e we wait for the
			   whole data packet and then we send it to a higher
			   protocol layer, in this case the L2CAP-layer */
		case WAIT_FOR_ACL_DATA:
			D_STATE(__FUNCTION__ ": WAIT_FOR_ACL_DATA\n");
			/* Find out how much data we can copy, don't copy more
			   than one HCI packet at time */
			c = MIN(count, data_len - tmp_pos);
			if (in_buf) {
				memcpy(in_buf->buf_ptr, buf, c);
				in_buf->buf_ptr += c;
				in_buf->count += c;
				D_REC(__FUNCTION__ ": in_buf->count = %d\n",in_buf->count);
			}
      
			/* Increase the data_index and decrease the amount of
			   data */
			tmp_pos += c;
			count -= c;
      
			D_REC(__FUNCTION__ ": Copied %d bytes into inbuffer\n",c);
			if (tmp_pos == data_len) {
				if (in_buf) {
					process_acl_data(in_buf, pb_flag);
				} else {
					D_ERR("invalid inbuffer\n");
				}
				state = WAIT_FOR_PACKET_TYPE;
			}
			buf += c;
			break;
      
			/* wait for the SCO header, three bytes */
		case WAIT_FOR_SCO_HDR:
			D_STATE(__FUNCTION__ ": WAIT_FOR_SCO_HDR\n");
			if (tmp_pos < SCO_HDR_LEN) {
				c = MIN(count,SCO_HDR_LEN - tmp_pos);
				memcpy(hdr + tmp_pos, buf, c);
				tmp_pos += c;
				buf += c;
				count -= c;
				if (tmp_pos == SCO_HDR_LEN) {
					hci_hdl = hci_handle(hdr);
					data_len = hdr[2];
					tmp_pos = 0;
					state = WAIT_FOR_SCO_DATA;
				}
			}
			break;

			/* Wait for the rest of the SCO packet and send it to
			   the tty */
		case WAIT_FOR_SCO_DATA:
			D_STATE(__FUNCTION__ ": WAIT_FOR_SCO_DATA\n");
			c = MIN(count, data_len - tmp_pos);
			process_sco_packet(buf, hci_hdl, c);
			tmp_pos += c;
			buf += c;
			count -= c;
			if (tmp_pos == data_len) {
				state = WAIT_FOR_PACKET_TYPE;
        
				/* FIXME - Send the data to the audio tty */

			}
			break;

		default:
			D_ERR(__FUNCTION__ ": Oops shouldn't be possible...\n");
			break;
		}
	}
}

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
void
hci_receive_event(u8 *data, s32 count)
{
	u8 event_type, event_len;
	u8 *tmp_buf;

	tmp_buf = data;
	
	while (count > 0) {
		event_type = tmp_buf[0];
		event_len = tmp_buf[1];
		tmp_buf += EVENT_HDR_LEN;
		count -= EVENT_HDR_LEN;

		D_REC(__FUNCTION__ ": Received event 0x%02x with len:%d\n", event_type, event_len);

		process_event(tmp_buf, event_len, event_type);
                tmp_buf += event_len;
		count -= event_len;
	}
}

void
hci_receive_acl(u8 *data, s32 count)
{
	u8 *tmp_buf;
	u16 hci_hdl;
	u8 pb_flag;
	u8 bc_flag;
	u16 data_len;
	hci_in_buffer *in_buf;

	tmp_buf = data;

	while (count > 0) {
		u32 tmp_hdr = le32_to_cpuu(tmp_buf);

		/* Parse the ACL header */
		hci_hdl = GET_BITS(tmp_hdr, 0, 12);
		pb_flag = GET_BITS(tmp_hdr, 12, 2);
		bc_flag = GET_BITS(tmp_hdr, 14, 2);
		data_len = GET_BITS(tmp_hdr, 16, 16);

		tmp_buf += ACL_HDR_LEN;
		count -= ACL_HDR_LEN;
		
		/* Check the length to make sure we won't 
		   overrun in_buf->buf_ptr in a memcpy later.
		   --gmcnutt
		*/
		if (data_len > HCI_IN_SIZE) {
			D_ERR(__FUNCTION__ ": %d is too big "\
			      "for our HCI input buffers -- "\
			      "discarding buffer\n",
			      data_len);
			return;
		}
		
		if (pb_flag == L2CAP_FRAME_START) {
			D_REC(__FUNCTION__ ": New L2CAP frame\n");
			in_buf = get_free_inbuffer();
			if (in_buf) {
				in_buf->nbr_of_hci_pkt = 1;
				in_buf->hci_hdl = hci_hdl;
			}	
		} else {
			D_REC(__FUNCTION__ ": Cont L2CAP frame\n");
			in_buf = get_inbuffer(hci_hdl);
			if (in_buf) {
				in_buf->nbr_of_hci_pkt++;
			}
		}
		
		if (in_buf) {
			memcpy(in_buf->buf_ptr, tmp_buf, data_len);
			D_REC(__FUNCTION__ ": Copied %d bytes into inbuffer\n",
			      data_len);
			in_buf->buf_ptr += data_len;
			in_buf->count += data_len;
			D_REC(__FUNCTION__ ": in_buf->count: %d\n", in_buf->count);
		} else {
			D_ERR(__FUNCTION__ ": No inbuffer was found, "\
			      "discarding data\n");
			return;
		}
		
		/* Decrease the amount of remaining data */
		count -= data_len;
		
		process_acl_data(in_buf, pb_flag);
		tmp_buf += data_len;
	}
}
#endif

s32
hci_trig_send(void)
{
#ifdef __KERNEL__
	if (buf_count() && (hci_ctrl.hc_buf.acl_num > 0)) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
		queue_task(&send_data_task, &tq_scheduler);
#else
		queue_task(&send_data_task, &tq_immediate);
		mark_bh(IMMEDIATE_BH);
#endif
		return TRUE;
	} else {
		return FALSE;
	}
#else
        /* FIXME? */
        return FALSE;
#endif
}

s32
hci_acl_num_cnt(void)
{
	return hci_ctrl.hc_buf.acl_num;
}

void
update_ncp(u8 nbr_of_hdl, u8 *pkt)
{
	s32 i;
#ifdef __KERNEL__
	unsigned long flags;

	save_flags(flags);
	cli();
#endif

	D_REC(__FUNCTION__ ": acl_num before: %d\n", hci_ctrl.hc_buf.acl_num);
	
	/* FIXME */
	/* Check if we have to register which connection handlers that
	   have been sent, or if we just need to know how many packets
	   that have been sent */

	for (i = 0; i < 4 * nbr_of_hdl; i += 4) {
		hci_ctrl.hc_buf.acl_num += le16_to_cpuu(&pkt[i+2]);
	}
	
	D_QUEUE("<NCP:%d>\n", hci_ctrl.hc_buf.acl_num);

	D_REC(__FUNCTION__ ": acl_num after: %d\n", hci_ctrl.hc_buf.acl_num);

	/* We've just been notified that the hardware has free buffers.
	   If we have any outstanding packets, send_acl_data_task will try
	   to send as many packets as possible. */

#ifdef __KERNEL__
	if (buf_count()) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
		queue_task(&send_data_task, &tq_scheduler);
#else
		queue_task(&send_data_task, &tq_immediate);
		mark_bh(IMMEDIATE_BH);
#endif
	}

#ifdef USE_NCPTIMER
	hw.acl_num_count += hci_ctrl.hc_buf.acl_num;
#endif

	bt_feedstack();

	restore_flags(flags);
#else
	if (buf_count())
		send_acl_data_task();
#endif	
}

/*
 * Parses an eventpacket, buf is the event parameters, length the event length
 * and event_code is the event's opcode
 */

void
process_event(u8 *buf, u32 len, u32 event_code)
{
	u16 hci_hdl;
	s32 i;

	PRINTPKT(__FUNCTION__, buf, len);

        switch (event_code) {
	case INQUIRY_COMPLETE:
		D_CMD("INQUIRY_COMPLETE\n");
                hci_inq_pending = 0;
#if USE_INQTIMER
		release_inq_timer();
#endif
		wake_up_interruptible(&inq_wq);
#ifndef __KERNEL__
		for (i = 0; i < inq_res->nbr_of_units; i++) {
			D_CMD(__FUNCTION__ ": BD %d: %02x:%02x:%02x:%02x:%02x:%02x\n",i,
			      inq_res->bd_addr[0+6*i],inq_res->bd_addr[1+6*i],
			      inq_res->bd_addr[2+6*i],inq_res->bd_addr[3+6*i],
			      inq_res->bd_addr[4+6*i],inq_res->bd_addr[5+6*i]);
		}
                printf("kainui : inquiry complete\n");
#endif
		break;

	case INQUIRY_RESULT:
	{
		s32 j;
		u8 tmp_bd[6];
                int i;

                num_inquiry_result++;
		D_CMD(__FUNCTION__ ": INQUIRY_RESULT\n");
		for(i = 1; i < (buf[0] * 14) + 1; i += 14) {
			printk("BD addr %d\n", i % 14);

			for (j = 0; j < 6; j++) {
				tmp_bd[5-j] = buf[i + j];
                        }
			print_data("BD", tmp_bd, 6);
                        for (j=0; j<6; j++) {
                                remote_device[num_remote_device].bd_addr[j] = tmp_bd[j];
                        }
                        num_remote_device++;
                        //print_data("kainui : ",remote_device[num_remote_device-1].bd_addr,6);
                        //printf("kainui : num : %d\n",num_remote_device);
			for (j = 0; j < inq_res->nbr_of_units; j++) {
				if (!memcmp(inq_res->bd_addr + j * 6, tmp_bd, 6)) {
					break;
				}
			}
			if (j >= inq_res->nbr_of_units) {
				memcpy(inq_res->bd_addr +
				       inq_res->nbr_of_units * 6, tmp_bd, 6);
				inq_res->nbr_of_units++;
			}
		}
                printf("kainui : inquiry result\n");
		break;
	}

	case CONNECTION_COMPLETE:
	{
		u8 link_type;
                u8 tmp_bd[6];
                int i;


                printf("kainui : connection complete\n");
                for (i=0;i<6;i++)
                        device_con[num_device_con].bd_addr[i] = buf[8-i];
                num_device_con++;
		D_CMD(__FUNCTION__ ": CONNECTION_COMPLETE: %s\n",
		      get_err_msg(buf[0]));

		link_type = buf[9];
		hci_hdl = hci_handle(&buf[1]);
		test_hci_hdl = hci_hdl;

  		if (link_type == ACL_LINK) {
			if (lp_connect_cfm(buf + 3, (u32) buf[0], hci_hdl)) {
				hci_ctrl.nbr_of_connections++;
				hci_update_load_factor();
			}

#ifndef HCI_EMULATION
			if (buf[0]) {
				/* remove hci handle if connection failed */
				DSYS(__FUNCTION__ ": CONNECTION_COMPLETE %s\n",
				     get_err_msg(buf[0]));

				reset_hci_con_bd(hci_hdl);
			} else {
				DSYS(__FUNCTION__ ": ACL link is up\n");

#ifdef CONFIG_BLUETOOTH_ERICSSON
				change_connection_packet_type(hci_hdl,
							      DM3|DH3|DM5|DH5);
#else
				change_connection_packet_type(hci_hdl,
							      DM1|DH1|DM3|DH3|DM5|DH5);
#endif
				set_hci_con(buf + 3, hci_hdl);
				remote_name_request(buf + 3);

				/* enable m/s switch */
				write_link_policy_settings(hci_hdl, 0x01);

				/* we demand role switch as server */
				if (force_msswitch && !i_am_initiator) {
					/* FIXME -- check return code */
#ifndef CONFIG_BLUETOOTH_EARLY_MSSWITCH
					hci_switch_role(buf + 3, 0);
#endif
				}
				/* reset variable again */
				i_am_initiator = 0;
			}
#endif /* HCI_EMULATION */

			if (test_wq_active) {
				test_wq_active = 0;
				wake_up_interruptible(&test_wq);
			}
  		} else {
			hci_ctrl.nbr_of_connections++;
			hci_update_load_factor();
  			tcs_add_sco_link(buf[0], hci_hdl);
  		}
		
		break;
	}

	case CONNECTION_REQUEST:
		D_CMD(__FUNCTION__ ": CONNECTION_REQUEST\n");

		if (buf[9] == ACL_LINK) {
			lp_connect_ind(buf); /* BD_ADDRESS */
		} else {
			printk(__FUNCTION__ ": CONNECTION_REQUEST for SCO LINK");
			accept_connection_request(buf, 0x01); /* role ignored for SCO */
		}
		break;

	case DISCONNECTION_COMPLETE:

                num_remote_device=0;
                i=0;
                while ((num_device_con>1)&&(i<num_device_con))
                {
                        int ii;
                        device_con[i].friendly_name = device_con[i+1].friendly_name;
                        for (ii=0; ii<6; ii++)
                        {
                               device_con[i].bd_addr[ii] = device_con[i+1].bd_addr[ii];
                                printf("%x:",device_con[i].bd_addr[ii]);
                                printf("%x:",device_con[i+1].bd_addr[ii]);
                        }
                        i++;
                }
                if (num_device_con>0)
                        num_device_con--;
                printf("kainui : device_con(disc) %x:%x:%x:%x:%x:%x %s\n",device_con[num_device_con].bd_addr[0]
                        ,device_con[num_device_con].bd_addr[1],device_con[num_device_con].bd_addr[2]
                        ,device_con[num_device_con].bd_addr[3],device_con[num_device_con].bd_addr[4]
                        ,device_con[num_device_con].bd_addr[5],device_con[num_device_con].friendly_name);

                for (i=0;i<6;i++ )
                {
                        remote_device[0].bd_addr[i] = 0 ;
                        remote_device[1].bd_addr[i] = 0 ;
                }
                remote_device[0].friendly_name = '\0';
                remote_device[1].friendly_name = '\0';
                remote_device[0].status = 0;
                remote_device[1].status = 0;
                DSYS(__FUNCTION__ ": DISCONNECTION_COMPLETE %s\n", get_err_msg(buf[3]));

		release_cmd_timer();
		wake_up_interruptible(&hci_wq);

		if (lp_disconnect_ind(hci_handle(&buf[1])))
			if (hci_ctrl.nbr_of_connections > 0) {
				hci_ctrl.nbr_of_connections--;
				hci_update_load_factor();
			}

		/* FIXME: No more NBR_OF_COMPLETE_PACKETS will arrive for this
		   connection handle, if we only support point-to-point
		   connections we can acl_num by reading the buffersizes again,
		   but this will not work in a multipoint connection. */

		reset_hci_con_bd(hci_handle(&buf[1]));
		
		if (hci_ctrl.nbr_of_connections <= 0) {
			hci_read_buffer_size(HCI_NON_BLOCK);
		}
		break;

	case AUTHENTICATION_COMPLETE:
		DSYS(__FUNCTION__ ": AUTHENTICATION_COMPLETE\n");
		release_cmd_timer();
		
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
		if (buf[0]) {
			D_ERR(__FUNCTION__ ": AUTHENTICATION_COMPLETE: %s\n", get_err_msg(buf[0]));

		}

		sec_man_event(HCI, get_bd(hci_handle(&buf[1])), AUTHENTICATION_COMPLETE, buf, 1);
#endif
		wake_up_interruptible(&hci_wq);
		break;

	case REMOTE_NAME_REQUEST_COMPLETE:
		D_CMD(__FUNCTION__ ": REMOTE_NAME_REQUEST_COMPLETE %s\n", buf + 7);
                remote_device[num_remote_device-1].friendly_name = buf+7; //kainui
                remote_device[num_remote_device-1].status = 1;//kainui : connect = 1
                device_con[num_device_con-1].friendly_name = buf+7;
                printf("kainui : device_con %x:%x:%x:%x:%x:%x %s\n",device_con[num_device_con-1].bd_addr[0]
                ,device_con[num_device_con-1].bd_addr[1],device_con[num_device_con-1].bd_addr[2]
                ,device_con[num_device_con-1].bd_addr[3],device_con[num_device_con-1].bd_addr[4]
                ,device_con[num_device_con-1].bd_addr[5],device_con[num_device_con-1].friendly_name);
                printf("kainui : REMOTE_NAME_REQUEST_COMPLETE : %s : %d\n",remote_device[num_remote_device-1].friendly_name,remote_device[num_remote_device-1].status);
		if (buf[0]) {
			D_ERR(__FUNCTION__ ": REMOTE_NAME_REQUEST_COMPLETE(1): %s\n",
			      get_err_msg(buf[0]));
		} else {
			if (strlen(buf + 7) > 248) {
				D_ERR(__FUNCTION__ ": REMOTE_NAME_REQUEST_COMPLETE: too long name length %d\n", (int)strlen(buf + 7));
                                break;
			}
			set_hci_con_name(buf + 1, buf + 7);
		}
		break;

	case ENCRYPTION_CHANGE:
		DSYS(__FUNCTION__ ": ENCRYPTION_CHANGE\n");
		release_cmd_timer();
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
		if (buf[0]) {
			D_ERR(__FUNCTION__ ": ENCRYPTION_CHANGE: %s\n", get_err_msg(buf[0]));
		}

                {
                        u8 tmp[2];
                        tmp[0] = buf[0];
                        tmp[1] = buf[3];
		
                        sec_man_event(HCI, get_bd(hci_handle(&buf[1])), ENCRYPTION_CHANGE, tmp, 2);
                }
#endif
		wake_up_interruptible(&hci_wq);
		break;
	
	case CHANGE_CONNECTION_LINK_KEY_COMPLETE:
		DSYS(__FUNCTION__ ": CHANGE_CONNECTION_LINK_KEY_COMPLETE Not implemented!\n");
		break;

	case MASTER_LINK_KEY_COMPLETE:
		DSYS(__FUNCTION__ ": MASTER_LINK_KEY_COMPLETE Not implemented!\n");
		break;

	case READ_REMOTE_SUPPORTED_FEATURES_COMPLETE:
		DSYS(__FUNCTION__ ": READ_REMOTE_SUPPORTED_FEATURES_COMPLETE Not implemented!\n");
		break;

	case READ_REMOTE_VERSION_INFORMATION_COMPLETE:
		DSYS(__FUNCTION__ ": READ_REMOTE_VERSION_INFORMATION_COMPLETE Not implemented!\n");
		break;

	case QOS_SETUP_COMPLETE:
		DSYS(__FUNCTION__ ": QOS_SETUP_COMPLETE\n");
		break;

	case COMMAND_COMPLETE:
		D_CMD(__FUNCTION__ ": COMMAND_COMPLETE\n");

		/* FIXME - stop any outstanding send timers if cmd_num is > 0*/
		D_QUEUE("<CC>\n");

		process_return_param(buf);
		update_nhcp(buf[0]);
		break;

		/* used to prevent host from waiting on reply when a 
		   command has been received in HW and is currently 
		   performing the task for this command */
		
	case COMMAND_STATUS:
		release_cmd_timer();
		D_CMD(__FUNCTION__ ": COMMAND_STATUS\n");
		
		if (buf[0]) {			
			/* fixme -- add parser for command status e.g when
			   trying to connect an acl link which already is
			   connected, a command status with "ACL link already
			   exist" is returned. This must be signalled using
			   lp_connect_cfm (neg) */
			D_ERR(__FUNCTION__ ": COMMAND_STATUS: %s\n", get_err_msg(buf[0]));

#ifdef USE_INQTIMER
			if (hci_inq_pending)
				release_inq_timer();
#endif
		}
		
		update_nhcp(buf[1]);
		wake_up_interruptible(&hci_wq);
		break;

	case FLUSH_OCCURRED:
		D_CMD(__FUNCTION__ ": FLUSH_OCCURRED on hci_hdl %d\n",
		      hci_handle(buf));
		btmem_flushhandle(hci_handle(buf));
		break;

	case HARDWARE_ERROR:
		D_ERR(__FUNCTION__ ": A hardware error with error code 0x%02X occurred.\n", buf[0]);
		D_ERR(__FUNCTION__ ": Please refer to your Bluetooth module's manual.\n");
		break;

	case ROLE_CHANGED:
		DSYS(__FUNCTION__ ": ROLE_CHANGED\n");
                printf("kainui : role change\n");

		if (buf[0]) { 
			D_ERR(__FUNCTION__ ": Role changed failed due to %s\n",
			      get_err_msg(buf[0]));
			
			/* fixme -- Notify l2cap that this BD will go down */
			
		} else if (buf[7]) {
			DSYS(__FUNCTION__ ": Current master is 0x%04x%08x\n", 
			     le16_to_cpuu(&buf[5]), le32_to_cpuu(&buf[1]));
		} else {
			DSYS(__FUNCTION__ ": Our role is master for BD Address 0x%04x%08x\n",
			     le16_to_cpuu(&buf[5]), le32_to_cpuu(&buf[1]));
		}
		break;

	case NBR_OF_COMPLETED_PACKETS: 
		D_CMD(__FUNCTION__ ": NUMBER_OF_COMPLETED_PACKETS\n");

		update_ncp(buf[0], buf + 1);
		break;

	case MODE_CHANGE:
		D_CMD(__FUNCTION__ ": MODE_CHANGE on hci_hdl %d\n",
		      hci_handle(&buf[1]));
		break;

	case RETURN_LINK_KEYS:
		D_CMD(__FUNCTION__ ": RETURN_LINK_KEYS event\n");
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
                {
                        u8 tmp_str[23];

                        for (i = 0; i < buf[0]; i++) {
                                D_CMD("%d: ", i);
                                tmp_str[0] = i;
                                memcpy(tmp_str + 1, (buf + 1) + (i * 6), 6);
                                memcpy(tmp_str + 7, (buf + 1) + (buf[0] * 6) + (i * 16), 16);
                                sec_man_event(HCI, buf + 1, RETURN_LINK_KEYS, tmp_str, 17);
                        }
                }
#endif
		break;
	
	case PIN_CODE_REQUEST:
		D_CMD(__FUNCTION__ ": PIN_CODE_REQUEST forwarding event to security manager\n");
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
		sec_man_event(HCI, buf, PIN_CODE_REQUEST, NULL, 0);
#endif
		break;
	
	case LINK_KEY_REQUEST:
                D_CMD(__FUNCTION__ ": LINK_KEY_REQUEST\n");
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
		sec_man_event(HCI, buf, LINK_KEY_REQUEST, NULL, 0);
#endif
		break;

	case LINK_KEY_NOTIFICATION:
		D_CMD(__FUNCTION__ ": LINK_KEY_NOTIFICATION forwarding event to security manager\n");
#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
		sec_man_event(HCI, buf, LINK_KEY_NOTIFICATION, buf + 6, 16);
#endif
		break;

	case LOOPBACK_COMMAND:
		DSYS(__FUNCTION__ ": LOOPBACK_COMMAND, loopback mode not supported\n");
		break;

	case DATA_BUFFER_OVERFLOW:
		D_ERR(__FUNCTION__ ": DATA_BUFFER_OVERFLOW\n");
		break;

	case MAX_SLOTS_CHANGE:
		D_CMD(__FUNCTION__ ": MAX_SLOTS_CHANGE to %d\n", (u32) buf[2]);
		break;

	case READ_CLOCK_OFFSET_COMPLETE:
		D_CMD(__FUNCTION__ ": READ_CLOCK_OFFSET_COMPLETE\n");
		break;

	case CONNECTION_PACKET_TYPE_CHANGED:
		D_CMD(__FUNCTION__ ": CHANGE_CONNECTION_PACKET_TYPE\n");
		break;

	case QOS_VIOLATION:
		D_CMD(__FUNCTION__ ": QOS_VIOLATION\n");
		break;

	case PAGE_SCAN_MODE_CHANGE:
		DSYS(__FUNCTION__ ": PAGE_SCAN_MODE_CHANGE Not implemented\n");
		break;

	case PAGE_SCAN_REPETITION_MODE_CHANGE:
		DSYS(__FUNCTION__ ": PAGE_SCAN_REPETITION_MODE_CHANGE Not implemented\n");
		break;

	case VENDOR_EVENT:
                process_vendor_event(buf, len, event_code);
		break;

	default:
		DSYS(__FUNCTION__ ": UNKNOWN EVENT CODE 0x%x\n", event_code);
		break;
	}
//        return 1;
}


/* Parses the return parameters from the command complete event, see the
   bluetooth baseband specification part H:1, chapter 5.2.14 for a further
   description of the command complete event. */

void 
process_return_param(u8 *buf)
{
	u32 ogf,ocf;
	u8 *r_val;

	/* buf points at the start of the event parameters of the command
	   complete event. The second and third byte (buf[1] and buf[2])
	   contains the op-code, which consists of the OGF and the OCF values,
	   see the baseband specification part H:1, chapter 4.4.1 for a
	   description of these.

	   r_val is set to point at the beginning of the return parameters at
	   the command complete event */

	ogf = (u32) buf[2] >> 2;
	ocf = le16_to_cpuu(&buf[1]) & 0x03FF;
	r_val = buf + 3;

	switch (ogf) {
	case HCI_LC:
		switch (ocf) {
		case LINK_KEY_REQUEST_REPLY:
			release_cmd_timer();
			
			D_CMD(__FUNCTION__ ": LINK_KEY_REQUEST_REPLY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": LINK_KEY_REQUEST_REPLY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0]; 
			}
			else {
				D_CMD(__FUNCTION__ ": LINK_KEY_REQUEST_REPLY Success\n");
				result_param = 0;
			}
			
			wake_up_interruptible(&hci_wq);
			break;
		
		case LINK_KEY_REQUEST_NEGATIVE_REPLY:
			release_cmd_timer();
			
			D_CMD(__FUNCTION__ ": LINK_KEY_REQUEST_NEGATIVE_REPLY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": LINK_KEY_REQUEST_NEGATIVE_REPLY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0]; 
			}
			else {
				D_CMD(__FUNCTION__ ": LINK_KEY_REQUEST_NEGATIVE_REPLY Success\n");
				result_param = 0;
			}
			
			wake_up_interruptible(&hci_wq);
			break;
		
		case PIN_CODE_REQUEST_REPLY:
			release_cmd_timer();
					
			D_CMD(__FUNCTION__ ": PIN_CODE_REQUEST_REPLY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": PIN_CODE_REQUEST_REPLY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0]; 
			}
			else {
				D_CMD(__FUNCTION__ ": PIN_CODE_REQUEST_REPLY  Success\n");
				result_param = 0;
			}

			wake_up_interruptible(&hci_wq);
			break;


		case PIN_CODE_REQUEST_NEGATIVE_REPLY:
			release_cmd_timer();
			
			D_CMD(__FUNCTION__ ": PIN_CODE_REQUEST_NEGATIVE_REPLY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": PIN_CODE_REQUEST_NEGATIVE_REPLY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0]; 
			}
			else {
				D_CMD(__FUNCTION__ ": PIN_CODE_REQUEST_NEGATIVE_REPLY Success\n");
				result_param = 0;
			}

			wake_up_interruptible(&hci_wq);
			break;	

		default:
			D_CMD(__FUNCTION__ ": HCI_LC, ocf %d not recognised!\n", ocf);
			break;
		}
		break;

	case HCI_HC:                 /* Host Controller commands */
		release_cmd_timer();
		/* FIXME -- correct timer should be released */
          
		switch (ocf) {
		case CREATE_NEW_UNIT_KEY:
			D_CMD(__FUNCTION__ ": CREATE_NEW_UNIT_KEY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": CREATE_NEW_UNIT_KEY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0]; 
			} else {
				D_CMD(__FUNCTION__ ": CREATE_NEW_UNIT_KEY Success\n");
				result_param = 0;
			}
			break;
			
			
		case READ_STORED_LINK_KEY:
			DSYS(__FUNCTION__ ": READ_STORED_LINK_KEY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_STORED_LINK_KEY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} else {
				D_CMD(__FUNCTION__ ": READ_STORED_LINK_KEY Success\n");
				result_param = le32_to_cpuu(&r_val[1]);
			}
			DSYS(__FUNCTION__ ": Max number of Linkkeys: %d\n",
			     le16_to_cpuu(&r_val[1]));
			DSYS(__FUNCTION__ ": Number of Linkkeys read: %d\n",
			     le16_to_cpuu(&r_val[3]));
			break;

		case WRITE_STORED_LINK_KEY:
			D_CMD(__FUNCTION__ ": WRITE_STORED_LINK_KEY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_STORED_LINK_KEY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0]; 
			}
			else {
				D_CMD(__FUNCTION__ ": WRITE_STORED_LINK_KEY Success\n");
				result_param = 0;
			}
			break;

		case DELETE_STORED_LINK_KEY:
			D_CMD(__FUNCTION__ ": DELETE_STORED_LINK_KEY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": DELETE_STORED_LINK_KEY %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} else {
				D_CMD(__FUNCTION__ ": DELETE_STORED_LINK_KEY Success\n");
				result_param = le16_to_cpuu(&r_val[1]);
			}
			
			D_CMD(__FUNCTION__ ": Number of Linkkeys deleted: %d\n",
			      le16_to_cpuu(&r_val[1]));
			break;	
            
		case READ_TRANSMIT_POWER_LEVEL:                                
		  
			printk(__FUNCTION__ ": READ_TRANSMIT_POWER_LEVEL\n");
			if (r_val[0]) {
			D_ERR(__FUNCTION__ ": READ_TRANSMIT_POWER_LEVEL: %s\n",
				      get_err_msg(r_val[0]));
				break;
			} else {
				DSYS("READ_TRANSMIT_POWER_LEVEL: handle %d, %d dBm\n", hci_handle(&r_val[1]), r_val[3]);
			}
			break;

		case SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL:
			D_CMD(__FUNCTION__ ": SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}
			break;
            
		case HOST_BUFFER_SIZE:  
			D_CMD(__FUNCTION__ ": HOST_BUFFER_SIZE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": HOST_BUFFER_SIZE: %s\n",
				      get_err_msg(r_val[0]));
			}
			break;
            
		case CHANGE_LOCAL_NAME:
			D_CMD(__FUNCTION__ ": CHANGE_LOCAL_NAME\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": CHANGE_LOCAL_NAME: %s\n",
				      get_err_msg(r_val[0]));
			}
			break;

		case READ_SCAN_ENABLE:
			D_CMD(__FUNCTION__ ": READ_SCAN_ENABLE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_SCAN_ENABLE: %s\n",
				      get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} else {
				result_param = r_val[1];
			}
			printk("READ_SCAN_ENABLE %d\n", result_param);
                        /*if (result_param == 0) printf("No scan enable\n");
                        else  if (result_param == 1) printf("Cannot run in this mode\n");
                        else  if (result_param == 2) printf("Inquiry scan disabled , Page scan enabled\n");
                        else  if (result_param == 3) printf("Inquiry scan enabled , Page scan enabled\n");
			//break;*/
			break;

		case WRITE_SCAN_ENABLE:
			D_CMD(__FUNCTION__ ": WRITE_SCAN_ENABLE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_SCAN_ENABLE: %s\n",
				      get_err_msg(r_val[0]));
			}
			break;

		case WRITE_PAGESCAN_ACTIVITY:
			D_CMD(__FUNCTION__ ": WRITE_PAGESCAN_ACTIVITY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_PAGESCAN_ACTIVITY: %s\n",
				      get_err_msg(r_val[0]));
			}
			break;
            
		case WRITE_INQUIRYSCAN_ACTIVITY:
			D_CMD(__FUNCTION__ ": WRITE_INQUIRYSCAN_ACTIVITY\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_INQUIRYSCAN_ACTIVITY: %s\n",
				      get_err_msg(r_val[0]));
				result_param = -r_val[0];
			}
			break;

		case READ_AUTHENTICATION_ENABLE:
			D_CMD(__FUNCTION__ ": READ_AUTHENTICATION_ENABLE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_AUTHENTICATION_ENABLE: %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} else {
				result_param = r_val[1];
			}
			break;
			
		case WRITE_AUTHENTICATION_ENABLE:
			D_CMD(__FUNCTION__ ": WRITE_AUTHENTICATION_ENABLE\n");
			if(r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_AUTHENTICATION_ENABLE: %s\n",
				      get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} 
			break;
			
		case READ_ENCRYPTION_MODE:
			D_CMD(__FUNCTION__ ": READ_ENCRYPTION_MODE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_ENCRYPTION_MODE: %s\n", get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} else {
				result_param = r_val[1];
			}
			break;
			
		case WRITE_ENCRYPTION_MODE:
			D_CMD(__FUNCTION__ ": WRITE_AUTHENTICATION_ENABLE\n");
			if(r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_AUTHENTICATION_ENABLE: %s\n",
				      get_err_msg(r_val[0]));
				result_param = -r_val[0];
			}
			break;
			
		case WRITE_CLASS_OF_DEVICE:
                        printf("kainui : write_class_of_device\n");
			D_CMD(__FUNCTION__ ": WRITE_CLASS_OF_DEVICE\n");
			if(r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_CLASS_OF_DEVICE: %s\n",
				      get_err_msg(r_val[0]));
			}
			break;

		case WRITE_AUTOMATIC_FLUSH_TIMEOUT:
			D_CMD(__FUNCTION__ ": WRITE_AUTOMATIC_FLUSH_TIMEOUT\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_AUTOMATIC_FLUSH_TIMEOUT: %s\n",
				      get_err_msg(r_val[0]));
			} else {
				D_CMD(__FUNCTION__ ": WRITE_AUTOMATIC_FLUSH_TIMEOUT Success\n");
			}
			
			break;

            
		case READ_LINK_SUPERVISION_TIMEOUT:
			D_CMD(__FUNCTION__ ": Link supervision timeout is: %d\n",
			      le16_to_cpuu(&buf[3]));
			break;
            
		case WRITE_LINK_SUPERVISION_TIMEOUT:
			D_CMD(__FUNCTION__ ": WRITE_LINK_SUPERVISION_TO (%d)\n", r_val[0]);
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_LINK_SUPERVISION_TO: %s\n",
				      get_err_msg(r_val[0]));
			}
			break;
            
		case RESET:
			D_CMD(__FUNCTION__ ": RESET\n");
			break;
            
		case SET_EVENT_FILTER:
			D_CMD(__FUNCTION__ ": SET_EVENT_FILTER\n");
			break;
            
		default:
			D_CMD(__FUNCTION__ ": HCI_HC, ocf %d not recognised!\n", ocf);
			break;
		}
                /* FIX ME : Wake up from the correct queue */
		wake_up_interruptible(&hci_wq);
		break;

	case HCI_LP:                 /* Link policy commands */
		switch (ocf) {
		case ROLE_DISCOVERY:
			D_CMD(__FUNCTION__ ": ROLE_DISCOVERY: ");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": ROLE_DISCOVERY: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}
			if (r_val[3])
				printk("Connected as Slave.\n");
			else
				printk("Connected as Master. \n");
			break;
		case WRITE_LINK_POLICY_SETTINGS:
			D_CMD(__FUNCTION__ ": WRITE_LINK_POLICY_SETTINGS \n ");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": WRITE_LINK_POLICY_SETTINGS: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}
			break;
		default:
			D_CMD(__FUNCTION__ ": HCI_LP, ocf %d not recognised!\n", ocf);
			break;
		}
		break;
		
	case HCI_IP:                 /* Informational parameters */
		release_cmd_timer();

		switch (ocf) {
		case READ_COUNTRY_CODE:
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_COUNTRY_CODE : %s\n",
				      get_err_msg(r_val[0]));
				result_param = -r_val[0];
			} else {
				result_param = r_val[1];
				D_CMD(__FUNCTION__ ": READ_COUNTRY_CODE : %d\n",
				      result_param);
			}
			break;
			

		case READ_LOCAL_VERSION_INFORMATION:
			D_CMD(__FUNCTION__ ": READ_LOCAL_VERSION_INFORMATION\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_LOCAL_VERSION_INFORMATION: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}

			break;

		case READ_BUFFER_SIZE:
			D_CMD(__FUNCTION__ ": READ_BUFFER_SIZE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_BUFFER_SIZE: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}
			hci_ctrl.hc_buf.acl_len = le16_to_cpuu(&r_val[1]);
			hci_ctrl.hc_buf.sco_len = (u32) r_val[3];
			hci_ctrl.hc_buf.acl_num = le16_to_cpuu(&r_val[4]);
			hci_ctrl.hc_buf.sco_num = le16_to_cpuu(&r_val[6]);
                        printk("\nHW module contains...\n");
			printk("%d ACL buffers at %d bytes\n%d SCO buffers at %d bytes\n\n",
			       hci_ctrl.hc_buf.acl_num, hci_ctrl.hc_buf.acl_len,
			       hci_ctrl.hc_buf.sco_num, hci_ctrl.hc_buf.sco_len);

#ifdef __KERNEL__
#ifdef USE_NCPTIMER
			hw.max_acl_num = hci_ctrl.hc_buf.acl_num;
#endif
#endif
			wake_up_interruptible(&hci_wq);
			break;
            
		case READ_BD_ADDR:
			D_CMD(__FUNCTION__ ": READ_BD_ADDR\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": READ_BD_ADDR: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}            
			PRINTPKT(__FUNCTION__ ": READ_BD_ADDR : ", &r_val[1], 6);
			memcpy(hci_ctrl.local_bd, &r_val[1],6);
			break;
            
		default:
			D_CMD(__FUNCTION__ ": HCI_IP, ocf %d not recognised!\n", ocf);
			break;
		}
		wake_up_interruptible(&hci_wq);
		break;
          
	case HCI_TC:                 /* Test Commands */
		release_cmd_timer();

		switch (ocf) {  
		case READ_LOOPBACK_MODE:
			D_ERR(__FUNCTION__ ": READ_LOOPBACK_MODE -- not impl\n");
			break;
            
		case WRITE_LOOPBACK_MODE:
			D_ERR(__FUNCTION__ ": WRITE_LOOPBACK_MODE -- not impl\n");
			break;
            
		case ENABLE_DEVICE_UNDER_TEST_MODE:
			DSYS(__FUNCTION__ ": ENABLE_DEVICE_UNDER_TEST_MODE\n");
			if (r_val[0]) {
				D_ERR(__FUNCTION__ ": ENABLE_DEVICE_UNDER_TEST_MODE: %s\n",
				      get_err_msg(r_val[0]));
				break;
			}
			printk(__FUNCTION__ ": *** Local device now under test\n***");
			break;
            
		default:
			D_ERR(__FUNCTION__ ": HCI_TC, ocf %d not recognised!\n", ocf);
			break;
		}
		wake_up_interruptible(&hci_wq);
		break;
          
	case MANUFACTURER_SPEC:      /* Manufacturer specific */
		D_CMD(__FUNCTION__ ": MANUFACTURER_SPEC\n");
		process_vendor_return_param(ocf, r_val);
		break;
        
	default:
		D_CMD(__FUNCTION__ ": ogf %d, not recognised! \n", ogf);
		break;
	}
}


/*Parses an ACL-data packet and copies it into the hci_in-buffer, data is a 
  pointer to the data in the memory, pb_flag is the packet boundary flag 
  which tells whether it is a beginning or a continuing fragment of an 
  L2CAP-packet */

void 
process_acl_data(hci_in_buffer *in_buf, u32 pb_flag)
{
	D_REC(__FUNCTION__ ": in_buf->count:%d, in_buf->l2cap_len:%d\n",
	      in_buf->count, in_buf->l2cap_len);

	if (pb_flag == L2CAP_FRAME_START) {
		in_buf->l2cap_len = 0;
		l2cap_receive_data(in_buf->buf, in_buf->count,
				   in_buf->hci_hdl, &in_buf->l2cap_len);

	} else if (in_buf->count >= in_buf->l2cap_len) {
		l2cap_receive_data(in_buf->buf, in_buf->count,
				   in_buf->hci_hdl, &in_buf->l2cap_len);
	}
}

/* Process an SCO-data packet, i.e. received audio from the Bluetooth module */

void
process_sco_packet(u8 *data, u32 hci_hdl, u32 len)
{
	hci_in_buffer *in_buf;
	if (!(in_buf = get_free_inbuffer())) {
		printk(__FUNCTION__ ": couldn't find free in buffer\n");
		return;
	}
	memcpy(in_buf->buf_ptr, data, len);
	in_buf->hci_hdl = hci_hdl;
	in_buf->buf_ptr += len;
	in_buf->count += len;

	/* FIXME - Finish this function... */
}

void
set_hci_con(u8 *bd, s32 con_hdl)
{
	s32 i;

	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i++) {
		if (hci_ctrl.con[i].state == NOT_CONNECTED) {
			memcpy(hci_ctrl.con[i].bd, bd, 6);
			hci_ctrl.con[i].con_hdl = con_hdl;
			hci_ctrl.con[i].state = UNIT_ACTIVE;
			return;
		}
	}

        D_ERR(__FUNCTION__ ": No free connection object\n");
}

void reset_hci_con_bd(u16 con_hdl)
{
	s32 i;

	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i++) {
		if (hci_ctrl.con[i].con_hdl == con_hdl) {
			hci_ctrl.con[i].state = NOT_CONNECTED;
			hci_ctrl.con[i].con_hdl = -1;
			hci_ctrl.con[i].name[0] = 0;
			return;
		}
	}

        D_ERR(__FUNCTION__ ": Didn't find connection with con_hdl %d\n", con_hdl);
}

void
set_hci_con_name(u8 *bd, u8 *name)
{
	s32 i;

	if (!name) {
		D_ERR(__FUNCTION__ ": set_hci_con_name: No name defined\n");
		return;
	}

	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i++) {
		if (memcmp(hci_ctrl.con[i].bd, bd, 6) == 0) {
			strcpy(hci_ctrl.con[i].name, name);
			return;
		}
	}

        D_ERR(__FUNCTION__ ": Didn't fin connecton with BD adress 0x%02x:%02x:%02x:%02x:%02x:%02x\n", bd[5],bd[4],bd[3],bd[2],bd[1],bd[0]);
}

s32 hci_sprint_local_bd(u8 *buf)
{
	return sprintf(buf, "%02x:%02x:%02x:%02x:%02x:%02x",
		       hci_ctrl.local_bd[5], hci_ctrl.local_bd[4],
		       hci_ctrl.local_bd[3], hci_ctrl.local_bd[2],
		       hci_ctrl.local_bd[1], hci_ctrl.local_bd[0]);
}

		       

s32 hci_sprint_remote_info(u8 *buf)
{
	s32 pos = 0;
	s32 i;

	pos += sprintf(buf + pos, "unit_id unit_bd_address unit_mode unit_name\n");

	/* Then we printout the other connections bd addresses and their user
	   friendly device names */
	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i++) {
		if (hci_ctrl.con[i].state != NOT_CONNECTED) {
			pos += sprintf(buf + pos, "%d ", i);
			pos += sprintf(buf + pos,"%02X:%02X:%02X:%02X:%02X:%02X ",
				       hci_ctrl.con[i].bd[5], hci_ctrl.con[i].bd[4],
				       hci_ctrl.con[i].bd[3], hci_ctrl.con[i].bd[2],
				       hci_ctrl.con[i].bd[1], hci_ctrl.con[i].bd[0]);
			if (hci_ctrl.con[i].state == UNIT_ACTIVE) {
				pos += sprintf(buf + pos, "active ");
			} else if (hci_ctrl.con[i].state == UNIT_PASSIVE) {
				pos += sprintf(buf + pos, "passive ");
			} else {
				pos += sprintf(buf + pos, "unknown ");
			}
			pos += sprintf(buf + pos, "%s\n", hci_ctrl.con[i].name);
		}
	}
	
	return pos;
}

s32 hci_sprint_local_info(u8 *buf)
{
	s32 pos = 0;
	s32 i;

	pos += sprintf(buf + pos, "The connected hci handlers are:\n");
	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i++) {
		if (hci_ctrl.con[i].state != NOT_CONNECTED) {
			pos += sprintf(buf + pos, "HCI handle:%d\n", hci_ctrl.con[i].con_hdl);
		}
	}	
	
	pos += sprintf(buf + pos, "\nFree data buffers in HW : %d\n", 
		       hci_ctrl.hc_buf.acl_num);
	pos += sprintf(buf + pos, "Free command buffers in HW : %d\n", 
		       hci_ctrl.hc_buf.cmd_num);
	return pos;
}

/* Marks the buffer empty, so new hci data, from the same or another
   connection handler can be written in it */

void 
hci_clear_buffer(u32 hci_hdl)
{
	hci_in_buffer *in_buf = NULL;
  
	D_CTRL(__FUNCTION__ "\n");

	if (!(in_buf = get_inbuffer(hci_hdl))) {
		printk(__FUNCTION__ ": couldn't find in buffer hci_hdl %d\n", hci_hdl);
		return;
	}

	in_buf->buf_ptr = in_buf->buf;
	in_buf->count = 0;
	in_buf->l2cap_len = 0;
	in_buf->empty = TRUE;
	in_buf->nbr_of_hci_pkt = 0;
}

/* Finds the in buffer for a given connection handler */
 
hci_in_buffer*
get_inbuffer(u32 hci_hdl)
{
	u32 i;

	for (i = 0 ; i < NBR_OF_HCI_INBUFFERS ; i ++) { 
		if (hci_ctrl.hci_in_buf[i].hci_hdl == hci_hdl) {
			break;
		}
	}

        if (i >= NBR_OF_HCI_INBUFFERS) {
		D_ERR(__FUNCTION__ ": WARNING! No inbuffer with hci_hdl %d\n", hci_hdl);
		return NULL;
        }
	
	D_CTRL(__FUNCTION__ ": Found inbuffer for hci_hdl %d %p\n",hci_hdl, 
	       &hci_ctrl.hci_in_buf[i]);

	return &hci_ctrl.hci_in_buf[i];
}

/* Finds a free inbuffer */

hci_in_buffer* 
get_free_inbuffer(void)
{
	u32 i;

	for (i = 0 ; i < NBR_OF_HCI_INBUFFERS ; i ++) {
		if (hci_ctrl.hci_in_buf[i].empty) {
			break;
		}
	}

        if (i >= NBR_OF_HCI_INBUFFERS) {
		D_ERR(__FUNCTION__ ": No free buffer found, discarding data\n");
		return NULL;
        }
	
	D_CTRL(__FUNCTION__ ": inbuffer %d was free\n",i);
	hci_ctrl.hci_in_buf[i].empty = FALSE;
	return &hci_ctrl.hci_in_buf[i];
}

s32
hci_module_init(void)
{
#ifdef __KERNEL__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	init_waitqueue_head(&hci_wq);
	init_waitqueue_head(&inq_wq);
	init_waitqueue_head(&set_baudrate_wq);
	init_waitqueue_head(&test_wq);
	sema_init(&hci_cmd_semaphore, 1);
	sema_init(&hci_inq_semaphore, 1);
#endif /* LINUX_VERSION_CODE */
#endif /* __KERNEL__ */

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	hci_dfu_module_init();
#endif

	return 0;
}

s32
hci_init(void)
{
	u32 i;

	DSYS("Initialising HCI\n");

#ifdef HCI_EMULATION
	DSYS("*** HCI emulator on ***\n");
#else
	DSYS("HCI emulator off\n");
#endif
	
	DSYS("Initialising HCI inbuffers [%d]\n", HCI_IN_SIZE);
	
	/* Initiate the hci inbuffers */
	for (i = 0; i < NBR_OF_HCI_INBUFFERS; i++) {
		hci_ctrl.hci_in_buf[i].buf_ptr = hci_ctrl.hci_in_buf[i].buf;
		hci_ctrl.hci_in_buf[i].count = 0;
		hci_ctrl.hci_in_buf[i].l2cap_len = 0;
		hci_ctrl.hci_in_buf[i].empty = TRUE;
		hci_ctrl.hci_in_buf[i].nbr_of_hci_pkt = 0;
	}
	
	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i ++) {
		hci_ctrl.con[i].state = NOT_CONNECTED;
		hci_ctrl.con[i].con_hdl = -1;
	}

        /* Here we set the buffer sizes to zero, just to avoid that they
           get undefined values if we fail to read the buffer sizes below */
	hci_ctrl.hc_buf.acl_len = 0;
	hci_ctrl.hc_buf.sco_len = 0;
	hci_ctrl.hc_buf.acl_num = 0;
	hci_ctrl.hc_buf.sco_num = 0;

	init_cmd_buf();
 
	hci_ctrl.nbr_of_connections = 0;

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
	/* If we use bcsp cmd_num is set from command status event after
	   syncronizing bcsp */
	if (!bt_use_bcsp(-1)) {
		hci_ctrl.hc_buf.cmd_num = 1;
	}
#else
	hci_ctrl.hc_buf.cmd_num = 1;
#endif

#ifdef __KERNEL__
	send_data_task.routine = (void *)send_acl_data_task;
	send_data_task.data = NULL;

	if (bt_dfu_mode(-1))
		return 0;
#endif
        
	DSYS("Reading buffer sizes in HW module\n");
	hci_read_buffer_size(HCI_BLOCK);

	DSYS("Reading firmware info in HW module\n");
        hci_read_firmware_rev_info();	

#ifdef HOST_FLOW_CTRL
	DSYS("Host flow control enabled\n");
	hci_set_host_controller_flow_control(TRUE);
#else
	DSYS("Host flow control not enabled\n");
#endif
	hci_host_buffer_size(HCI_ACL_LEN,HCI_SCO_LEN,HCI_ACL_NUM,HCI_SCO_NUM);

#ifdef USE_NCPTIMER
	start_ncp_timer();	
#endif

#ifdef CONFIG_BLUETOOTH_ENABLE_MSSWITCH
	DSYS("M/S switch enabled\n");

	hci_force_msswitch(1);
#else /* CONFIG_BLUETOOTH_ENABLE_MSSWITCH */
	DSYS("M/S switch disabled\n");

	hci_force_msswitch(0);
#endif

	/* Check that hci initialized properly */
	if (hci_ctrl.hc_buf.acl_num == 0)
		return -1;	  
	
	return 0;
}

void 
hci_shutdown(void)
{
	/* take down any open acl links */

	hci_ctrl.nbr_of_connections = 0;

#ifdef USE_NCPTIMER
	release_ncp_timer();
#endif

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
        hci_shutdown_dfu();
#endif
}

/* Start of the definition of the functions performing all the different
   HCI commands. The functions will be defined in the same order as they are
   described in the HCI specification, part H:1 of the bluetooh core
   specification. Functions that begins with hci_ can be reached from utside
   this file. */

/* Definition of Link Control Commands */

/* This function will cause the Bluetooth device to enter Inquiry Mode. Inquiry
   Mode is used to discover other nearby Bluetooth devices. The LAP input
   parameter contains the LAP from which the inquiry access code shall be
   derived when the inquiry procedure is made. The Inquiry_length parameter
   specifies the total duration of the Inquiry Mode and, when this time 
   expires, Inquiry will be halted. The Num_Responses parameter specifies 
   the number of responses that can be received before the Inquiry is halted.*/

int hci_inquiry(u8 *lap, u8 inq_len, u8 num_resp, inquiry_results *results)
{
	s32 tmp;

        //num_inquiry_result = 0;

	D_CMD(__FUNCTION__ ": Sending inquiry()\n");

	if (!results)
		return -EINVAL;

	inq_res = results;

	/* FIXME: Check if lap is valid first */
	/* Set default lap */
	lap[0] = 0x33;
	lap[1] = 0x8b;
	lap[2] = 0x9e;

	inq_res->nbr_of_units = 0;

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(INQUIRY, HCI_LC);

	memcpy(c_pkt.data, lap, 3);
	c_pkt.data[3] = inq_len;
	c_pkt.data[4] = num_resp;
	c_pkt.len = 5;

	print_data("hci_inquiry", (u8*) &c_pkt ,
		   c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	tmp = send_inq_cmd_block((u8*) &c_pkt, 
				 c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN,
				 inq_len);
	return tmp;
}

/* This function will cause the Link Manager to create a connection to the
   Bluetooth device with the BD_ADDR specified by the function parameters.
   This function causes the local Bluetooth device to begin the Page process
   to create a link level connection. The other parameters are psrm: Pagescan
   repetition mode; psm: Pagescan mode; c_off: Clock offset */

s32 
create_connection(u8 bd_addr[], u32 pkt_type, u8 psrm, u8 psm, u32 c_off,
		  u32 rol_sw)
{ 
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(CREATE_CONNECTION, HCI_LC);

	memcpy(c_pkt.data, bd_addr, 6);

	c_pkt.data[6] = (pkt_type & 0xff);
	c_pkt.data[7] = (pkt_type >> 8);
	c_pkt.data[8] = psrm;
	c_pkt.data[9] = psm;
	c_pkt.data[10] = (c_off & 0xff);
	c_pkt.data[11] = (c_off >> 8);
	c_pkt.data[12] = rol_sw;
	c_pkt.len = 13;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);  
}


s32
hci_add_sco_connection(u32 hci_hdl)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ADD_SCO_CONNECTION, HCI_LC);

	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = hci_hdl >> 8;
	c_pkt.data[2] = 0xe0;
	c_pkt.data[3] = 0x00;
	c_pkt.len = 4;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

/* The Hci_Disconnect function is used to terminate an existing connection.
   The Connection_Handle function parameter indicates which connection is to be
   disconnected. The Reason function parameter indicates the reason for ending
   the connection, see page 552 specification core 1.0B */
s32 
disconnect(u32 hdl, u8 reason)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(DISCONNECT, HCI_LC);

	c_pkt.data[0] = hdl & 0xff;
	c_pkt.data[1] = hdl >> 8;
	c_pkt.data[2] = reason;
	c_pkt.len = 3;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, 
			      DEFAULT_TIMEOUT);
}

/* A positive response to a previous connection request, role = 0 sets master,
   role = 1 sets slave */
s32 
accept_connection_request(u8 bd[], u8 role)
{
	D_CMD(__FUNCTION__ ": bd_addr %x %x %x %x %x %x\n",bd[0], bd[1], bd[2],
	      bd[3], bd[4], bd[5]);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ACCEPT_CONNECTION_REQUEST, HCI_LC);

	memcpy(c_pkt.data, bd, 6);
	c_pkt.data[6] = role;
	c_pkt.len = 7;  

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/* The Reject_Connection_Request function is used to decline a new incoming
   connection request. The Reject_Connection_Request function shall only be
   called after a Connection Request event has occurred. */

s32 
reject_connection_request(u8 bd[], u32 reason)
{
	u32 c = 0;
	
	D_CMD(__FUNCTION__ ": Rejecting bd_addr %x %x %x %x %x %x\n",
	      bd[0],bd[1],bd[2],bd[3],bd[4],bd[5]);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(REJECT_CONNECTION_REQUEST, HCI_LC);

	memcpy(c_pkt.data, bd, 6);
	c += 6;
	c_pkt.data[c++] = reason;
	c_pkt.len = c;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_link_key_request_reply(u8 *bd, u8* link_key)
{
	u32 c = 0;
	s32 tmp;
	
	print_data(__FUNCTION__ ":  BD_addr", bd, 6);
	print_data(__FUNCTION__ ":  Link Key", link_key, 16);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(LINK_KEY_REQUEST_REPLY, HCI_LC);

	memcpy(c_pkt.data, bd, 6);
	c += 6;
	memcpy(c_pkt.data + c, link_key, 16);
	c += 16;
	c_pkt.len = c;

	tmp = send_cmd_block((u8*) &c_pkt , c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}


s32
hci_link_key_request_negative_reply(u8 *bd)
{
	s32 tmp;
	
	print_data(__FUNCTION__ ":  BD_addr", bd, 6);
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(LINK_KEY_REQUEST_NEGATIVE_REPLY, HCI_LC);

	memcpy(c_pkt.data, bd, 6);
	
	c_pkt.len = 6;

	tmp = send_cmd_block((u8*) &c_pkt , c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
        printk(__FUNCTION__ ": Returned from send_secblock\n");
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}


/* fixme -- does this really need to be non blocking ? */
s32
hci_pin_code_request_reply(u8 *bd, u8 *pin, u8 pin_len)
{
	u32 c = 0;
	s32 tmp;
	
	print_data(__FUNCTION__ ": New pin is\n", pin, pin_len); 

	print_data(__FUNCTION__ ":  BD_addr", bd, 6);
	print_data(__FUNCTION__ ":  pin", pin, pin_len);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(PIN_CODE_REQUEST_REPLY, HCI_LC);

	memcpy(c_pkt.data, bd, 6);
	c += 6;
	c_pkt.data[c++] = pin_len;
	memcpy(c_pkt.data + c, pin, 16);
	c += 16;

	c_pkt.len = c;
	
	tmp = send_cmd_block((u8*) &c_pkt , c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}


s32
hci_pin_code_request_negative_reply(u8 *bd)
{
	s32 tmp;
	
	print_data(__FUNCTION__ ":  BD_addr", bd, 6);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(PIN_CODE_REQUEST_NEGATIVE_REPLY, HCI_LC);

	memcpy(c_pkt.data, bd, 6);

	c_pkt.len = 6;
	
	tmp = send_cmd_block((u8*) &c_pkt , c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}


/* The Change_Connection_Packet_Type function is used to change which
   packet types can be used for a connection that is currently established.
   See page 564 in the BT specification core v1.0B for more info about the
   packet types.
*/



s32
change_connection_packet_type(u32 hci_hdl, u32 pkt_type)
{
	D_CMD(__FUNCTION__ ": for connnection handle 0x%x\n", hci_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(CHANGE_CONNECTION_PACKET_TYPE, HCI_LC);

	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = (hci_hdl >> 8) & 0xff;
	c_pkt.data[2] = pkt_type & 0xff;
	c_pkt.data[3] = (pkt_type >> 8) & 0xff;
	c_pkt.len = 4;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/*
 * The Authentication_Requested command is used to try to authenticate the
 * remote device associated with the specified Connection Handle. The Host
 * must not issue the Authentication_Requested command with a
 * Connection_Handle corresponding to an encrypted link. On an authentication
 * failure, the Host Controller or Link Manager shall not automatically detach
 * the link. The Host is responsible for issuing a Disconnect command to
 * terminate the link if the action is appropriate.
 */

/*
 * The response to AUTHENTICATION_REQUESTED can be:
 *  1) Authentication Complete or
 *  2) Link Key Request
 */

s32
hci_authentication_requested_bd(BD_ADDR bd)
{
	s32 tmp;

	tmp = get_con_hdl(bd);
	
        if (tmp < 0) {
		D_ERR(__FUNCTION__ ": No connection handle found for bd 0x%02x:%02x:%02x:%02x:%02x:%02x:\n", bd[5], bd[4], bd[3], bd[2], bd[1], bd[0]);
		return -1;
	} else {
		return hci_authentication_requested((u16)tmp);
	}
}

s32
hci_authentication_requested(u16 con_hdl)
{

	D_CMD(__FUNCTION__ ": At connection handle %d\n", con_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(AUTHENTICATION_REQUESTED, HCI_LC);

	c_pkt.data[0] = con_hdl & 0xff;
	c_pkt.data[1] = (con_hdl >> 8) & 0xff;
	c_pkt.len = 2;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

/*
 * The Set_Connection_Encryption command is used to enable and disable the
 * link level encryption. Note: the Connection_Handle command parameter is
 * used to identify the other Bluetooth device which forms the connection. The
 * Connection Handle should be a Connection Handle for an ACL connection.
 * While the encryption is being changed, all ACL traffic must be turned off
 * for all Connection Handles associated with the remote device.
 */


s32
hci_set_connection_encryption_bd(BD_ADDR bd, u8 enable)
{
	s32 tmp;

	tmp = get_con_hdl(bd);
	
        if (tmp < 0) {
		D_ERR(__FUNCTION__ ": No connection handle found for bd 0x%02x:%02x:%02x:%02x:%02x:%02x:\n", bd[5], bd[4], bd[3], bd[2], bd[1], bd[0]);
		return -1;
	} else {
		return hci_set_connection_encryption((u16)tmp, enable);
	}
	
}

s32
hci_set_connection_encryption(u16 con_hdl, u8 enable)
{
	D_CMD(__FUNCTION__ ": enable:%d at connection handle %d\n", enable, con_hdl);
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(SET_CONNECTION_ENCRYPTION, HCI_LC);

	c_pkt.data[0] = con_hdl & 0xff;
	c_pkt.data[1] = (con_hdl >> 8) & 0xff;
	c_pkt.data[2] = enable;
	c_pkt.len = 3;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}


/* fixme -- fix return code so we know whether role change was succesful 
   or not */
s32
hci_switch_role(u8 *bd, u8 role)
{
	DSYS(__FUNCTION__ ": role %d\n", role);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(SWITCH_ROLE, HCI_LP);

	memcpy(c_pkt.data, bd, 6);
	c_pkt.data[6] = role;

	c_pkt.len = 7;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}



s32
role_discovery(u16 con_hdl)
{
	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ROLE_DISCOVERY, HCI_LP);

	c_pkt.data[0] = con_hdl & 0xff;
	c_pkt.data[1] = (con_hdl >> 8) & 0xff;
	c_pkt.len = 2;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
write_link_policy_settings(u16 con_hdl, u16 settings)
{
	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_LINK_POLICY_SETTINGS, HCI_LP);

	c_pkt.data[0] = con_hdl & 0xff;
	c_pkt.data[1] = (con_hdl >> 8) & 0xff;
	c_pkt.data[2] = settings & 0xff;
	c_pkt.data[3] = (settings >> 8) & 0xff;
	c_pkt.len = 4;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);	
}

s32
remote_name_request(u8 *bd)
{
	s32 c = 0;
	s32 zero = 0;

	D_CMD(__FUNCTION__ ":  for bd address 0x%02x:%02x:%02x:%02x:%02x:%02x\n"
	      , bd[5], bd[4], bd[3], bd[2], bd[1], bd[0]);
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(REMOTE_NAME_REQUEST, HCI_LC);

	memcpy(c_pkt.data, bd, 6);
	c += 6;
	memcpy(c_pkt.data + c, &zero, 4);
	c += 4;

	c_pkt.len = c;
        printf("kainui : remote_name_request\n");

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/* Definitions of the Link Policy Commands functions */

/* Definitions of the Host Controller & Basband Command functions */

void
hci_flush_all()
{
	s32 i;
	
	for (i = 0; i < MAX_NBR_OF_CONNECTIONS; i++) {
		if (hci_ctrl.con[i].state != NOT_CONNECTED) {
			printk(__FUNCTION__ ": Flushing handle:%d\n",hci_ctrl.con[i].con_hdl);
			hci_flush(hci_ctrl.con[i].con_hdl);
		}
	}	
}


s32 
hci_flush(u32 hdl)
{
	D_CMD(__FUNCTION__ "\n");
  
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(FLUSH, HCI_HC);

	c_pkt.data[0] = (hdl & 0xff);
	c_pkt.data[1] = ((hdl >> 8) & 0xff);
	c_pkt.len = 2;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

s32
hci_create_new_unit_link_key(void)
{
	s32 tmp;
	D_CMD(__FUNCTION__ "\n");
  
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(CREATE_NEW_UNIT_KEY, HCI_HC);

	c_pkt.len = 0;

	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}	
}

s32
hci_read_stored_link_key(u8 *bd, u8 flag)
{
	s32 tmp;
	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_STORED_LINK_KEY, HCI_HC);
	memcpy(c_pkt.data, bd , 6);
	c_pkt.data[6] = flag;
	c_pkt.len = 7;
  
	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);

	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}	
}

s32
hci_write_stored_link_key(u8 *bd, u8* link_key)
{
	s32 tmp;
	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_STORED_LINK_KEY, HCI_HC);
	/* For now we only stor one key att time with this command */
	c_pkt.data[0] = 1; 
	memcpy(c_pkt.data + 1, bd , 6);
	memcpy(c_pkt.data + 7, link_key, 16);
	c_pkt.len = 23;
  
	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}

s32
hci_delete_stored_link_key(u8 *bd, u8 flag)
{
	s32 tmp;
	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(DELETE_STORED_LINK_KEY, HCI_HC);
	memcpy(c_pkt.data, bd , 6);
	c_pkt.data[6] = flag;
	c_pkt.len = 7;
  
	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);

	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}	
}


/*kainui : change friendly name*/
s32
hci_change_local_name(u8 *new_name)
{
#define NAME_LEN 248
        //printf("kainui : new name is %s\n",new_name);
	D_CMD(__FUNCTION__ ": New name: %s\n", new_name);
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(CHANGE_LOCAL_NAME, HCI_HC);

	memset(c_pkt.data, 0, NAME_LEN);
	strcpy(c_pkt.data, new_name);
        friendly_name = new_name;
        //printf("kainui : new name(2) is %s\n",c_pkt.data);
	c_pkt.len = NAME_LEN;

	return send_cmd_block((u8*) &c_pkt , c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
#undef NAME_LEN
}

/*kainui add : read my friendly name*/
s32
hci_read_local_name(unsigned char friendly_name1[])
{
        //printf("My friendly name is %s\n",friendly_name);
        strcpy(friendly_name1,friendly_name);
        return 1;
}


s32
hci_read_scan_enable(void)
{
	s32 tmp;
	
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_SCAN_ENABLE, HCI_HC);
  
	c_pkt.len = 0;

	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}

/*
 * This function will write the value for the Scan_Enable parameter. The
 * Scan_Enable parameter controls whether or not the Bluetooth device will 
 * periodically scan for page attempts and/or inquiry requests from other
 * Bluetooth devices.
 */

s32 
hci_write_scan_enable(u32 enable)
{
	D_CMD(__FUNCTION__ ": enable %d\n", enable);
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_SCAN_ENABLE, HCI_HC);
  
	c_pkt.data[0] = enable;
	c_pkt.len = 1;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT); 
}

/*
 * This function will write the value for Page_Scan_Activity configuration
 * parameter. The Page_Scan_Interval configuration parameter defines the
 * amount of time between consecutive page scans.
 */

s32 
hci_write_pagescan_activity(u32 interval, u32 wind)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_PAGESCAN_ACTIVITY, HCI_HC);

	c_pkt.data[0] = (interval & 0xff);
	c_pkt.data[1] = ((interval >> 8) & 0xff);
	c_pkt.data[2] = (wind & 0xff);
	c_pkt.data[3] = ((wind >> 8) & 0xff);
        c_pkt.len = 4;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

/*
 * This function will write the value for Inquiry_Scan_Activity configuration
 * parameter. The Inquiry_Scan_Interval configuration parameter defines the
 * amount of time between consecutive inquiry scans.
 */

s32 
write_inquiryscan_activity(u32 interval, u32 wind)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_INQUIRYSCAN_ACTIVITY, HCI_HC);
  
	c_pkt.data[0] = (interval & 0xff);
	c_pkt.data[1] = ((interval >> 8) & 0xff);
	c_pkt.data[2] = (wind & 0xff);
	c_pkt.data[3] = ((wind >> 8) & 0xff);
        c_pkt.len = 4;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_read_authentication_enable(void)
{
	s32 tmp;
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_AUTHENTICATION_ENABLE, HCI_HC);
	c_pkt.len = 0;
  
	print_data(__FUNCTION__, (u8*)&c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}

/*
 * This command will write the value for the Encryption_Mode parameter. The
 * Encryption_Mode parameter controls if the local device requires encryption
 * to the remote device at connection setup. At connection setup, only the
 * device(s) with the Authentication_Enable parameter enabled and
 * Encryption_Mode parameter enabled will try to encrypt the connection to
 * the other device. 
 */

s32
hci_write_authentication_enable(u8 enable)
{
	s32 tmp;

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_AUTHENTICATION_ENABLE, HCI_HC);
	c_pkt.data[0] = enable & 0xff;
	c_pkt.len = 1;
  
	print_data(__FUNCTION__, (u8*)&c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}


s32
hci_read_encryption_mode(void)
{
	s32 tmp;

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_ENCRYPTION_MODE, HCI_HC);
	c_pkt.len = 0;
  
	print_data(__FUNCTION__, (u8*)&c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}

s32
hci_write_encryption_mode(u8 mode)
{
	s32 tmp;
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_ENCRYPTION_MODE, HCI_HC);
	c_pkt.data[0] = mode & 0xff;
	c_pkt.len = 1;
  
	print_data(__FUNCTION__, (u8*)&c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	tmp = send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	if (tmp < 0) {
		return tmp;
	} else {
		return result_param;
	}
}


s32
hci_write_class_of_device(u8 *class_of_dev)
{
	class_of_device[0] = class_of_dev[0];
	class_of_device[1] = class_of_dev[1];
	class_of_device[2] = class_of_dev[2];

	D_CMD(__FUNCTION__ ": Service class 0x%02x, major:0x%01x, minor:0x%01x\n",(class_of_device[2] << 3) | (class_of_device[1] >> 5), (class_of_device[1] & 0x1f), (class_of_device[0] >> 2));

	D_CMD(__FUNCTION__ ": %01x:%01x:%01x\n", class_of_device[2], class_of_device[1], class_of_device[0]);
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_CLASS_OF_DEVICE, HCI_HC);
	c_pkt.data[0] = class_of_device[0];
	c_pkt.data[1] = class_of_device[1];
	c_pkt.data[2] = class_of_device[2];

	c_pkt.len = 3;
  
	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

void
hci_read_class_of_device()
{
        printf("Service class 0x%02x, major:0x%01x, minor:0x%01x\n",(class_of_device[2] << 3) | (class_of_device[1] >> 5), (class_of_device[1] & 0x1f), (class_of_device[0] >> 2));
}


s32
hci_set_max_connections(s32 max_connections)
{
	if (max_connections < 0 || max_connections > 7)
		return -EINVAL;
  
	bt_max_connections = max_connections;
	DSYS("Setting max BT connections to %d\n", bt_max_connections);
	hci_update_load_factor();
        return 0;
}


/* Change the 3-bit load factor (all bits set is max load, all zero is min load).
 * Renew load factor if: Any client is connected, disconnected or if the
 * maximum number of simultaneous connections is altered. 
*/
s32
hci_update_load_factor(void)
{
	static unsigned char load;

	/* Calculate the current load */
	if (!bt_max_connections)
		load = 7;
	else
		load = 7 * hci_ctrl.nbr_of_connections / bt_max_connections;

	/* Make sure only bit2 to bit0 are used */
	load &= 0x07;

	D_CMD(__FUNCTION__ ": Load factor changed from %d to %d\n", ((class_of_device[0] >> 5) & 0x07), load);

	/* Clear bit7 to bit5 for old load factor */
	class_of_device[0] &= 0x1F;

	/* Mask in new load factor value */
	class_of_device[0] |= (load << 5);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_CLASS_OF_DEVICE, HCI_HC);
	c_pkt.data[0] = class_of_device[0];
	c_pkt.data[1] = class_of_device[1];
	c_pkt.data[2] = class_of_device[2];
	c_pkt.len = 3;
  
	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}


s32
hci_set_event_filter(u8 *data)
{
	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(SET_EVENT_FILTER, HCI_HC);
	c_pkt.data[0] = data[0];
	c_pkt.data[1] = data[1];
	c_pkt.data[2] = data[2];

	c_pkt.len = 3;
  
	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}


s32
write_automatic_flush_timeout(u16 con_hdl, u16 n)
{
	D_CMD(__FUNCTION__ ": con_hdl: %d, n:%d\n", con_hdl, n);
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_AUTOMATIC_FLUSH_TIMEOUT, HCI_HC);
	c_pkt.data[0] = con_hdl & 0xff;
	c_pkt.data[1] = (con_hdl >> 8) & 0xff;
	c_pkt.data[2] = n & 0xff;
	c_pkt.data[3] = (n >> 8) & 0xff;
	
	c_pkt.len = 4;
  
	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/* This function is used by the Host to turn flow control on or off in the
   direction from the Host Controller to the Host */

s32 
hci_set_host_controller_flow_control(u32 enable)
{
#ifdef HOST_FLOW_CTRL
	D_CMD(__FUNCTION__ ": enable:%d\n",enable);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL, HCI_HC);
  
	c_pkt.data[0] = enable;
	c_pkt.len = 1;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
#else
	return 0;
#endif
}

s32
hci_read_power_transmit_level(u32 con_hdl, unsigned char type)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_TRANSMIT_POWER_LEVEL, HCI_LP);
	c_pkt.len = 3;
        c_pkt.data[0] = con_hdl & 0xff;
        c_pkt.data[1] = (con_hdl >> 8) & 0xff;
	c_pkt.data[2] = type;
	
        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/* The hci_host_buffer_size function is used by the Host to notify the Host
   Controller about the maximum size of the data portion of HCI ACL and
   SCO Data Packets sent from the Host Controller to the Host. The Host
   Controller will segment the data to be transmitted from the Host
   Controller to the Host according to these size so that the HCI Data
   Packets will contain data with up to these sizes */

s32 
hci_host_buffer_size(u16 acl_len, u8 sco_len, u16 acl_num, u16 sco_num)
{
#ifdef HOST_FLOW_CTRL
	u32 c = 0;

	printk("Setting host buffers, ALC_LEN:%d, SCO_LEN:%d, ACL_NUM:%d, SCO_NUM:%d\n", acl_len, sco_len, acl_num, sco_num);


	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(HOST_BUFFER_SIZE, HCI_HC);
  
	c_pkt.data[c++] = acl_len & 0xff;
	c_pkt.data[c++] = (acl_len >> 8) & 0xff;
	c_pkt.data[c++] = sco_len;
	c_pkt.data[c++] = acl_num & 0xff;
	c_pkt.data[c++] = (acl_num >> 8) & 0xff;
	c_pkt.data[c++] = sco_num & 0xff;
	c_pkt.data[c++] = (sco_num >> 8) & 0xff;

	return send_cmd_block((u8*) &c_pkt, c + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
#else
	return 0;
#endif
}

s32 
host_nbrcompleted_packets(u32 hci_hdl, u32 nbr_of_packets)
{
#ifdef HOST_FLOW_CTRL
	s32 tmp;
	
	D_CMD(__FUNCTION__ ": hci_hdl:0x%x, for %d packets\n", hci_hdl,nbr_of_packets);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(HOST_NUMBER_OF_COMPLETED_PACKETS, HCI_HC);

	c_pkt.data[0] = 1;
	c_pkt.data[1] = (hci_hdl & 0xff);
	c_pkt.data[2] = ((hci_hdl >> 8) & 0xff);
	c_pkt.data[3] = (nbr_of_packets & 0xff);
	c_pkt.data[4] = ((nbr_of_packets >> 8) & 0xff);
	c_pkt.len = 5;

	
        /*FIXME -- Risk for race against sending acl packets ?  */
	tmp = bt_write_lower_driver((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
	return tmp;
#else
	return 0;
#endif
}

s32 
hci_read_link_supervision_to(u32 hdl)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_LINK_SUPERVISION_TIMEOUT, HCI_HC);
	c_pkt.data[0] = hdl & 0xff;
	c_pkt.data[1] = (hdl >> 8) & 0xff;
	c_pkt.len = 2;

        return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

s32 
hci_write_link_supervision_to(u32 hdl, u32 link_to)
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(WRITE_LINK_SUPERVISION_TIMEOUT, HCI_HC);
	c_pkt.data[0] = hdl & 0xff;
	c_pkt.data[1] = (hdl >> 8) & 0xff;
	c_pkt.data[2] = link_to & 0xff;
	c_pkt.data[3] = (link_to >> 8) & 0xff;
	c_pkt.len = 4;
  
	print_data("write_link_to:",(u8*)&c_pkt,
		   c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}

/* Defines of Informational Parameters function */


/* The Hci_Read_Buffer_Size function is used to read the maximum size of the
   data portion of HCI ACL and SCO Data Packets sent from the Host to the Host 
   Controller. The function can be called from both the process currently in the
   driver and the interrupt handler, therefore the option to block or not. */

s32
hci_read_buffer_size(s32 block)
{
	D_CMD(__FUNCTION__ "\n");
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_BUFFER_SIZE, HCI_IP);
	c_pkt.len = 0;

	if (block) {
		return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
        }
        else
		return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

#if 0
s32
hci_read_local_version_info(s32 block)
{
	D_CMD(__FUNCTION__ "\n");
	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_LOCAL_VERSION_INFORMATION, HCI_IP);
	c_pkt.len = 0;

        if (block)
		return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
        else
		return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}
#endif

s32 hci_read_country_code(void)
{
	s32 tmp;

	D_CMD(__FUNCTION__ "\n");

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_COUNTRY_CODE, HCI_IP);
	c_pkt.len = 0;
	
	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN,
			     DEFAULT_TIMEOUT);

	return tmp < 0 ? tmp : result_param;
}

/*
 * This command will read the value for the BD_ADDR parameter of the local
 * unit, returns bd in little endian
 */

s32
hci_read_local_bd(u8 *bd)
{
	/* Consider changing bd to BD_ADDR */
	s32 tmp;

	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(READ_BD_ADDR, HCI_IP);
	c_pkt.len = 0;
	
	/* Init to all zeroes in case cmd fails...*/

	memset(bd, 0, 6); 

	tmp = send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
	memcpy(bd, hci_ctrl.local_bd, 6);
	return tmp;
} 

/* Sends reset command to the host controller */
s32
hci_reset()
{
	D_CMD(__FUNCTION__ "\n");
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(RESET, HCI_HC);
	c_pkt.len = 0;
  
	return send_cmd_block((u8*) &c_pkt , c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}


s32
hci_hold_mode(u16 hci_hdl, u16 max_int, u16 min_int)
{  
	D_CMD(__FUNCTION__ ": for connnection handle 0x%x\n", hci_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(HOLD_MODE, HCI_LP);
	
	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = (hci_hdl >> 8) & 0xff;
	c_pkt.data[2] = max_int & 0xff;
	c_pkt.data[3] = (max_int >> 8) & 0xff;
	c_pkt.data[4] = min_int & 0xff;
	c_pkt.data[5] = (min_int >> 8) & 0xff;
	c_pkt.len = 6;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_sniff_mode(u16 hci_hdl, u16 max_int, u16 min_int, u16 attempt, u16 timeout)
{  
	D_CMD(__FUNCTION__ ": for connnection handle 0x%x\n", hci_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(SNIFF_MODE, HCI_LP);
	
	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = (hci_hdl >> 8) & 0xff;
	c_pkt.data[2] = max_int & 0xff;
	c_pkt.data[3] = (max_int >> 8) & 0xff;
	c_pkt.data[4] = min_int & 0xff;
	c_pkt.data[5] = (min_int >> 8) & 0xff;
	c_pkt.data[6] = attempt & 0xff;
	c_pkt.data[7] = (attempt >> 8) & 0xff;
	c_pkt.data[8] = timeout & 0xff;
	c_pkt.data[9] = (timeout >> 8) & 0xff;
	
	c_pkt.len = 10;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_exit_sniff_mode(u16 hci_hdl)
{ 
	D_CMD(__FUNCTION__ ": for connnection handle 0x%x\n", hci_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(EXIT_SNIFF_MODE, HCI_LP);
	
	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = (hci_hdl >> 8) & 0xff;
	c_pkt.len = 2;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_park_mode(u16 hci_hdl, u16 max_int, u16 min_int)
{  
	D_CMD(__FUNCTION__ ": for connnection handle 0x%x\n", hci_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(PARK_MODE, HCI_LP);
	
	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = (hci_hdl >> 8) & 0xff;
	c_pkt.data[2] = max_int & 0xff;
	c_pkt.data[3] = (max_int >> 8) & 0xff;
	c_pkt.data[4] = min_int & 0xff;
	c_pkt.data[5] = (min_int >> 8) & 0xff;
	c_pkt.len = 6;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_exit_park_mode(u16 hci_hdl)
{  
	D_CMD(__FUNCTION__ ": for connnection handle 0x%x\n", hci_hdl);

	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(EXIT_PARK_MODE, HCI_LP);
	
	c_pkt.data[0] = hci_hdl & 0xff;
	c_pkt.data[1] = (hci_hdl >> 8) & 0xff;
	c_pkt.len = 2;

	return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}



s32
get_con_hdl(u8 *bd)
{
	u32 i;
	
	for (i = 0 ; i < MAX_NBR_OF_CONNECTIONS ; i ++) {
		if (memcmp(hci_ctrl.con[i].bd, bd, 6) == 0) {
			return hci_ctrl.con[i].con_hdl;
		}
	}

	D_ERR(__FUNCTION__ ": No connection handle found for bd 0x%02x:%02x:%02x:%02x:%02x:%02x:\n", bd[5], bd[4], bd[3], bd[2], bd[1], bd[0]);
	return -1;
}

#ifdef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
u8*
get_bd(u16 con_hdl)
{
	u32 i;
 
	for (i = 0 ; i < MAX_NBR_OF_CONNECTIONS ; i ++) {
		if (hci_ctrl.con[i].con_hdl == con_hdl) {
			return hci_ctrl.con[i].bd;
		}
	}

	D_ERR(__FUNCTION__ ": No BD Address found for connection handle %d\n", con_hdl);
	return NULL;
}
#endif /* CONFIG_BLUETOOTH_USE_SECURITY_MANAGER */

/*
 * This function will return the BD address for a specific line
 */

/* Consider changing bd to BD_ADDR */

s32
get_remote_bd(s32 line, u8 *bd)
{
        D_CMD(__FUNCTION__ "\n");

	memset(bd, 0, 6);

        if (line >= 0 && line < MAX_NBR_OF_CONNECTIONS) {
		memcpy(bd, hci_ctrl.con[line].bd, 6);
		DSYS(__FUNCTION__ ": %02x:%02x:%02x:%02x:%02x:%02x\n",
		     bd[5], bd[4], bd[3], bd[2], bd[1], bd[0]);
		return 0;
        } else {
		/* No connection yet */
		D_WARN(__FUNCTION__ ": Unknown line: %d!\n", line);
		return -1;
        }
}

/* Defines of Testing Commands functions */
s32
hci_enable_dut(void)
{
	DSYS("Enabling device under test mode (RESET to release)\n");	
	c_pkt.type = CMD_PKT;
	c_pkt.opcode = hci_put_opcode(ENABLE_DEVICE_UNDER_TEST_MODE, HCI_TC);
	c_pkt.len = 0;

	return send_cmd_block((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN, DEFAULT_TIMEOUT);
}


/* This function is used to send custom commands/data over the HCI interface. */

s32
hci_send_raw_data(u8 *data, u8 len)
{
	print_data(__FUNCTION__, data, len);
	
	return bt_write_lower_driver(data, len);
}

s32
hci_test_connect_req(u8 *bd)
{
	/* Must add a l2cap con to store bd address in !!! */
	
#ifdef CONFIG_BLUETOOTH_ENABLE_MSSWITCH
	if (create_connection(bd, 0xcc18, 0x00, 0x00, 0x00, DONT_ALLOW_ROLE_SWITCH)) {
		D_ERR("hci_test_connect_req, error sending command\n");
	}
#else
	if (create_connection(bd, 0xcc18, 0x00, 0x00, 0x00, ALLOW_ROLE_SWITCH)) {
		D_ERR("hci_test_connect_req, error sending command\n");
	}
#endif
	test_wq_active = 1;
	interruptible_sleep_on(&test_wq);
	return test_hci_hdl;
}

void
hci_force_msswitch(u8 enable)
{
	DSYS("Force M/S switch set to %d\n", enable);
	force_msswitch = enable; 
}

s32
hci_write_page_to(u32 page_to)
{
        c_pkt.type = CMD_PKT;
        c_pkt.opcode = hci_put_opcode(WRITE_PAGE_TIMEOUT, HCI_HC);
        c_pkt.len = 2;
        c_pkt.data[0] = page_to & 0xff;
        c_pkt.data[1] = (page_to >> 8) & 0xff;

        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32
hci_write_hold_mode_activity(u32 hma)
{
        c_pkt.type = CMD_PKT;
        c_pkt.opcode = hci_put_opcode(WRITE_HOLD_MODE_ACTIVITY, HCI_HC);
        c_pkt.len = 1;
        c_pkt.data[0] = hma & 0xff;

        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32 hci_write_connection_accept_to(u32 co_ac_to)
{
        c_pkt.type = CMD_PKT;
        c_pkt.opcode = hci_put_opcode(WRITE_CONNECTION_ACCEPT_TIMEOUT, HCI_HC);
        c_pkt.len = 2;
        c_pkt.data[0] = co_ac_to & 0xff;
        c_pkt.data[1] = (co_ac_to >> 8) & 0xff;
        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32 hci_inquiry_cancel(void)
{
        c_pkt.type = CMD_PKT;
        c_pkt.opcode = hci_put_opcode(INQUIRY_CANCEL, HCI_LC);
        c_pkt.len = 0;
        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32 hci_read_clock_offset(u32 hdl)
{
        c_pkt.type = CMD_PKT;
        c_pkt.opcode = hci_put_opcode(READ_CLOCK_OFFSET, HCI_LC);
        c_pkt.data[0] = (hdl & 0xff);
        c_pkt.data[1] = ((hdl >> 8) & 0xff);
        c_pkt.len = 2;
        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

s32 hci_read_rssi(u32 hdl)
{
        c_pkt.type = CMD_PKT;
        c_pkt.opcode = hci_put_opcode(READ_RSSI, HCI_SP);
        c_pkt.data[0] = (hdl & 0xff);
        c_pkt.data[1] = ((hdl >> 8) & 0xff);
        c_pkt.len = 2;
        return send_cmd((u8*) &c_pkt, c_pkt.len + CMD_HDR_LEN + HCI_HDR_LEN);
}

/* Sends a connect request to the BT unit with the address bd_addr */
s32 
lp_connect_req(u8 bd_addr[])
{
	PRINTPKT(__FUNCTION__ ": bd address is: ", bd_addr, 6);
	/* FIXME, store the inparameters in the ctrl-block instead */

	if (!get_con(bd_addr, ANY_STATE))
		l2cap_create_con(bd_addr);
  
	i_am_initiator = 1;

#ifdef CONFIG_BLUETOOTH_ENABLE_MSSWITCH
	  return create_connection(bd_addr, 0xcc18, 0x00, 0x00, 
                                   0x00, ALLOW_ROLE_SWITCH);
#else
	  return create_connection(bd_addr, 0xcc18, 0x00, 0x00, 
				   0x00, DONT_ALLOW_ROLE_SWITCH);
#endif
}

/* A response from L2CAP to a previous lp_connect_ind */
s32 
lp_connect_rsp(u8 bd_addr[], u32 cfm)
{ 
	D_CMD(__FUNCTION__ ": Status: %d\n", cfm);
	if (cfm) {
#ifdef CONFIG_BLUETOOTH_EARLY_MSSWITCH
		if (force_msswitch) {
			DSYS(__FUNCTION__ ": Early m/s switch\n");
			return accept_connection_request(bd_addr, MS_SWITCH_BECOME_MASTER);
		} else
			return accept_connection_request(bd_addr, MS_SWITCH_REMAIN_SLAVE);

#else
		return accept_connection_request(bd_addr, MS_SWITCH_REMAIN_SLAVE);
#endif


	} else {
		return reject_connection_request(bd_addr, 0x0d);
		/* FIXME: 0x0d = due to limited resourses store this
		   somewhere else */
	}
}


/* Disconnect a certain connection handler */
s32 
lp_disconnect(u32 hci_hdl)
{
	return disconnect(hci_hdl, DISCMSG_USER_ENDED_CONNECTION);
}


/* Starts a task that will send the data that bt_tx_buf points at. */
s32
hci_send_data(bt_tx_buf *tx_buf)
{
	D_SND(__FUNCTION__ ": %d bytes\n", tx_buf->cur_len);

	/* Indicate that this is a L2CAP start frame. If the whole frame
	   can't be sent, send_acl_data will fragment it an set the
	   remaining chunks to L2CAP_FRAME_CONT. Then start a task that
	   sends the data. */
	tx_buf->pb_flag = L2CAP_FRAME_START;

#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
        queue_task(&send_data_task, &tq_scheduler);
#else
        queue_task(&send_data_task, &tq_immediate);
        mark_bh(IMMEDIATE_BH);
#endif
#else
        send_acl_data_task();
#endif
	return 0;
}


/* Tries to sends all hci data chunks until either the whole frame has
   been sent or the hardware can't accept any more packets
   (hci_ctrl.hc_buf.acl_num == 0) */
void
send_acl_data_task(void)
{
	s32 bytes2send = 0;
	s32 sent_bytes = 0;
	bt_tx_buf *tx_buf;
	
	/* get pointer to next unsent transmission chunk */
	tx_buf = get_bt_buf();
	if (tx_buf) {
		bytes2send = tx_buf->cur_len;
		D_SND(__FUNCTION__ ": %d bytes \n", tx_buf->cur_len);
	}

	D_SND(__FUNCTION__ ": %d bytes \n", bytes2send);
	
	/* while there is space in the hardware buffers and we have
	   hci packets to send, we send them. After each sent packet
	   we assume that the space in the hardware buffers have
	   decreased by one and checks whether there are more packets
	   to send.  Turn off interrupts since number_of_completed_packets
	   interrupt can change hci_ctrl.hc_buf.acl_num. */
	cli();
	while ((hci_ctrl.hc_buf.acl_num > 0) && bytes2send ) {
		sti();
		
		/* FIXME -- what if send_acl_packet fails ??? 
		   Then acl_num will decrease anyway ... */ 

		sent_bytes = send_acl_packet(tx_buf);

		if (sent_bytes != 0) {
			bytes2send -= sent_bytes;
			cli();
			hci_ctrl.hc_buf.acl_num--;
			sti();
		} else {
			break;
		}

			
		D_QUEUE("<--%d (%d)\n", buf_byte_count(-1), 
			hci_ctrl.hc_buf.acl_num);
		
		if (bytes2send == 0) {
			/* The current frame has now been sent, check if more
			   data is waiting to be sent from the driver. */
			tx_buf = get_bt_buf();

			if (tx_buf) {
				bytes2send = tx_buf->cur_len;
			}				
		}
		cli();
	}
	sti();
}

u32
send_acl_packet(bt_tx_buf *tx_buf)
{
	u32 c;
	u8* cur_data;

	/* Calculate the maximum packet length we can send */
	c = MIN(tx_buf->cur_len, hci_ctrl.hc_buf.acl_len);

	D_SND(__FUNCTION__ ": send %d bytes (excl HCI header) out of %d\n",
	      c, tx_buf->cur_len);
  
	/* Set the temporary cur_data pointer to point at the current data to
	   be sent */
	cur_data = tx_buf->data + (tx_buf->subscr_len - tx_buf->cur_len);
 
	D_SND(__FUNCTION__ ": There are %d bytes space for the headers\n",
	      tx_buf->subscr_len - tx_buf->cur_len);
  
	/* Move the pointer so the HCI header can be filled in, higher
	   layers should have allocated space for this */
	cur_data -= (ACL_HDR_LEN + HCI_HDR_LEN);
	
	if ((cur_data < tx_buf->data) || 
	    (cur_data > (tx_buf->data+tx_buf->subscr_len)))
	{
		D_ERR("send_acl_packet : Corrupting btmem buffers !!!\n");
	}
	
	/* Fills in the HCI header in the packet */
	set_acl_hdr(cur_data, c, tx_buf->pb_flag, tx_buf->bc_flag, 
		    tx_buf->hci_hdl);

	/* Send the whole packet plus its header to the serial driver */
	PRINTPKT(__FUNCTION__ ": ", cur_data, c + ACL_HDR_LEN + HCI_HDR_LEN);

#ifdef HCI_EMULATION
	hci_emulator(cur_data, c + ACL_HDR_LEN + HCI_HDR_LEN);
#else
	/* bt_write_lower_driver checks in serial driver if there are room 
	   in serial tx buffer, if 0 is returned there was insufficient 
	   room */

	if (!bt_write_lower_driver(cur_data, 
				   c + ACL_HDR_LEN + HCI_HDR_LEN)) {
		
		/* let the packet stay in bt buffers for later transmission
		   either send all or nothing... 
		   (HW need complete packets) */
		
		D_SND(__FUNCTION__ ": cannot send now, leave in buffers\n");
		return 0;
	}
#endif
	/* We always set the next part to be a continous part of the packet */
	tx_buf->pb_flag = L2CAP_FRAME_CONT;

	/* Decrease the current length of the packet */
	tx_buf->cur_len -= c;

	D_SND(__FUNCTION__ ": now c = %d\n", c);
  
	/* Check whether to unsubscribe the subscribed buffer or not */
	if (tx_buf->cur_len == 0) {
		D_SND(__FUNCTION__ ": unsubscribing tx_buf.\n");
		unsubscribe_bt_buf(tx_buf);
	}
	else if (tx_buf->cur_len < 0) {
		D_ERR(__FUNCTION__ ": negative cur_len... (%d)\n", 
		       tx_buf->cur_len);
#ifndef __KERNEL__
		sleep(10);
#endif
	}
	return c;
}

void 
set_acl_hdr(u8 *data, u32 len, u8 pb, u8 bc, u32 hci_hdl)
{
	u32 tmp_hdr = 0;

	SET_BITS(tmp_hdr, 0, 12, hci_hdl);
	SET_BITS(tmp_hdr, 12, 2, pb);
	SET_BITS(tmp_hdr, 14, 2, bc);
	SET_BITS(tmp_hdr, 16, 16, len);

	data[0] = ACL_PKT;
	put_unaligned(cpu_to_le32(tmp_hdr), (u32*)&data[1]);
}

u16
hci_handle(void *data)
{
	return GET_BITS(le16_to_cpuu(data), 0, 12);
}

/* Returns the error messages according to the specification page 746 */
u8* 
get_err_msg(u32 err_code)
{
	switch (err_code) {
	case 0x00: return "Success!";
	case 0x01: return "Unknown HCI Command";
	case 0x02: return "No Connection";
	case 0x03: return "Hardware Failure";
	case 0x04: return "Page Timeout";
	case 0x05: return "Authentication Failure";
	case 0x06: return "Key Missing";
	case 0x07: return "Memory Full";
	case 0x08: return "Connection Timeout";
	case 0x09: return "Max Number Of Connections";
	case 0x0A: return "Max Number Of SCO Connections To A Device";
	case 0x0B: return "ACL connection already exists";
	case 0x0C: return "Command Disallowed";
	case 0x0D: return "Host Rejected due to limited resources";
	case 0x0E: return "Host Rejected due to security reasons";
	case 0x0F: return "Host Rejected due to remote device is only a personal device";
	case 0x10: return "Host Timeout";
	case 0x11: return "Unsupported Feature or Parameter Value";
	case 0x12: return "Invalid HCI Command Parameters";
	case 0x13: return "Other End Terminated Connection: User Ended Connection";
	case 0x14: return "Other End Terminated Connection: Low Resources";
	case 0x15: return "Other End Terminated Connection: About to Power Off";
	case 0x16: return "Connection Terminated by Local Host";
	case 0x17: return "Repeated Attempts";
	case 0x18: return "Pairing Not Allowed";
	case 0x19: return "Unknown LMP PDU";
	case 0x1A: return "Unsupported Remote Feature";
	case 0x1B: return "SCO Offset Rejected";
	case 0x1C: return "SCO Interval Rejected";
	case 0x1D: return "SCO Air Mode Rejected";
	case 0x1E: return "Invalid LMP Parameters";
	case 0x1F: return "Unspecified Error";
	case 0x20: return "Unsupported LMP Parameter Value";
	case 0x21: return "Role Change Not Allowed";
	case 0x22: return "LMP Response Timeout";
	case 0x23: return "LMP Error Transaction Collision";
	case 0x24: return "LMP PDU Not Allowed";
	case 0x25: return "Encryption Mode Not Acceptable";
	case 0x26: return "Unit Key Used";
	case 0x27: return "QOS is Not Supported";
	case 0x28: return "Instant Passed";
	case 0x29: return "Pairing with Unit Key Not Supported";
	}

	return "No debug msg defined";
}

/********************* HCI EMULATOR STUFF **********************************/
#ifdef HCI_EMULATION

void 
hci_emulator(u8 *data, u32 len)
{
#ifndef __KERNEL__
	/* Add a sleep here to avoid race problems when running 
	 usermode stack (using busy wait 'wait queues') */
	usleep(10000);
#endif
	if (*data == SCO_PKT) {
		bt_write_lower_driver(data, len);
		hci_ctrl.hc_buf.sco_num++;
	} else if (*data == ACL_PKT) {
		/* forward everything to other side */
		bt_write_lower_driver(data, len);
		hci_ctrl.hc_buf.acl_num++;
	} else if (*data == CMD_PKT) {
		/* convert command to event */
		command_handler(data);
		hci_ctrl.hc_buf.cmd_num++;
	}
}

void 
command_handler(u8 *data)
{
	u8 o_event[256];
	u32 o_len;

	cmd_pkt *cmd = (cmd_pkt *)data;
	event_struct *out_event = (event_struct *)o_event;

	PRINTPKT(__FUNCTION__, data, cmd->len + CMD_HDR_LEN + HCI_HDR_LEN);

	switch (hci_get_ogf(cmd->opcode)) {

	case HCI_LC:                 /* Host Controller commands */
		switch (hci_get_ocf(cmd->opcode)) {

		case CREATE_CONNECTION:
			/* Send connection request event */
			D_CMD(__FUNCTION__ ": CREATE_CONNECTION->connection request\n");
			o_len = set_con_req_event(out_event, cmd->data, 1);
			bt_write_lower_driver(o_event, o_len);
			break;

		case DISCONNECT:
			/* Send disconnection complete to both sides, 0x16 is
			   the conde for "Connection Terminated by Local Host"
			   and 0x13 is the code for "Other End Terminated
			   Connection: User Ended Connection" */
			D_CMD(__FUNCTION__ ": DISCONNECT->disconnection complete\n");
			o_len = set_discon_cpl_event(out_event, hci_handle(cmd->data), 0x13);
			bt_write_lower_driver(o_event, o_len);
			if (lp_disconnect_ind(hci_handle(cmd->data)))
				if (hci_ctrl.nbr_of_connections > 0) {
					hci_ctrl.nbr_of_connections--;
					hci_update_load_factor();
				}
			break;

		case ACCEPT_CONNECTION_REQUEST:
			D_CMD(__FUNCTION__ ": ACCEPT_CONNECTION->connection complete\n");
			o_len = set_con_cpl_event(out_event, 0, cmd->data,
						  HCI_HDL, ACL_CON);
#ifndef __KERNEL__
			sleep(1);
#endif
			bt_write_lower_driver(o_event, o_len);
			if (lp_connect_cfm(data + 4, 0, 0)) {
				hci_ctrl.nbr_of_connections++;
				hci_update_load_factor();
			}
			break;

		case REJECT_CONNECTION_REQUEST:
			D_CMD(__FUNCTION__ ": REJECT_CONNECTION->connection complete\n");
			o_len = set_con_cpl_event(out_event, cmd->data[6],
						  cmd->data, HCI_HDL, ACL_CON);
#ifndef __KERNEL__
			sleep(1);
#endif
			bt_write_lower_driver(o_event, o_len);
			lp_connect_cfm(data + 4, 0xd, 0);
			break;

		default:
			printk(__FUNCTION__ ": Unknown command ogf:0x%x,ocf:0x%x\n",
			       hci_get_ogf(cmd->opcode), hci_get_ocf(cmd->opcode));
			break;
		}
		break;

	case HCI_IP:                 /* Informational parameters */
		switch (hci_get_ocf(cmd->opcode)) {

		case READ_BUFFER_SIZE:
			D_CMD(__FUNCTION__ ": READ_BUFFER_SIZE->setting buffer size\n");
			hci_ctrl.hc_buf.acl_num = ACL_NUM;
			hci_ctrl.hc_buf.acl_len = ACL_LEN;
			hci_ctrl.hc_buf.sco_num = SCO_NUM;
			hci_ctrl.hc_buf.sco_len = SCO_LEN;
			break;

		default:
			printk(__FUNCTION__ ": Unknown command ogf:0x%x,ocf:0x%x\n",
			       hci_get_ogf(cmd->opcode), hci_get_ocf(cmd->opcode));
			break;
		}
		break;

	default:
		printk(__FUNCTION__ ": Unknown command ogf:0x%x,ocf:0x%x\n",
		       hci_get_ogf(cmd->opcode), hci_get_ocf(cmd->opcode));
		break;
	}
}

s32 
set_cmd_status_event(event_struct *event, u8 *cmd)
{
	event->pkt_type = EVENT_PKT;
	event->event_type = 0x0f;
	event->len = 4;
	event->data[0] = 0x00;
	event->data[1] = 0x01;
	event->data[2] = cmd[0];
	event->data[3] = cmd[1];
	return event->len + EVENT_HDR_LEN + HCI_HDR_LEN;
}

s32 
set_con_req_event(event_struct *event, u8 *bd, u8 con_type)
{
	event->pkt_type = EVENT_PKT;
	event->event_type = 0x04;
	event->len = 10;
	event->data[0] = bd[0]; 
	event->data[1] = bd[1];
	event->data[2] = bd[2];
	event->data[3] = bd[3];
	event->data[4] = bd[4];
	event->data[5] = bd[5];
	event->data[6] = 0;
	event->data[7] = 0;
	event->data[8] = 0;
	event->data[9] = con_type;
	return event->len + EVENT_HDR_LEN + HCI_HDR_LEN;
}

s32 
set_con_cpl_event(event_struct *event, u8 status, u8 *bd, u16 hci_hdl,
                  u8 con_type)
{
	event->pkt_type = EVENT_PKT;
	event->event_type = 0x03;
	event->len = 11;
	event->data[0] = status;
	event->data[1] = hci_hdl & 0xff;
	event->data[2] = hci_hdl >> 8;
	event->data[3] = bd[0];
	event->data[4] = bd[1];
	event->data[5] = bd[2];
	event->data[6] = bd[3];
	event->data[7] = bd[4];
	event->data[8] = bd[5];
	event->data[9] = con_type;
        event->data[10] = 0x00; /* Encryption disabled */
	return event->len + EVENT_HDR_LEN + HCI_HDR_LEN;
}

s32 
set_discon_cpl_event(event_struct *event, u16 hci_hdl, u8 reason)
{
	event->pkt_type = EVENT_PKT;
	event->event_type = 0x05;
	event->len = 4;
	event->data[0] = 0x00; /* Connection successfully disconnected */
	event->data[1] = hci_hdl & 0xff;
	event->data[2] = hci_hdl >> 8;
	event->data[3] = reason;
	return event->len + EVENT_HDR_LEN + HCI_HDR_LEN;
}

#endif /* HCI_EMULATION */

/****************************************************************************/
/********************* cmd queue handling ***********************************/
/****************************************************************************/

void 
init_cmd_buf(void)
{
	u32 i;
	cmd_t *tmp = NULL;
 
	D_CTRL(__FUNCTION__ ": Initializing\n");
  
	while ((tmp = get_next_cmd()) != NULL) {
		kfree(tmp->data);
		tmp->data = NULL;
	}
  
	cmd_buf.first_free = 0;
	cmd_buf.next_to_send = 0;
	cmd_buf.count = 0;
	for (i = 0; i < NBR_CMD_BUFS; i++) {
		cmd_buf.buf[i].data = NULL;
	}        
}


/* returns next cmd buf to send, NULL if nothing in buf */ 
cmd_t*
get_next_cmd(void)
{
	cmd_t *tmp;

	if (cmd_buf.count > 0) {
		/* If buffer contains data, get next_to_send */
		tmp = &(cmd_buf.buf[cmd_buf.next_to_send]);

		cmd_buf.count--;
    
		/* update next_to_send */
		if (cmd_buf.next_to_send >= (NBR_CMD_BUFS - 1)) {
			/* If we are at last cmd in buffer, wrap ! */
			cmd_buf.next_to_send = 0;
			D_CTRL(__FUNCTION__ ": next_to_send WRAP\n");
		} else {
			cmd_buf.next_to_send++;
		}
	} else {
		/* no cmd:s in buffer */
		tmp = NULL;
	}
	return tmp;
}


s32 
insert_cmd(u8 *cmd, u8 len)
{
	D_CTRL(__FUNCTION__ "\n"); 

	cli();
	if (cmd_buf.count == NBR_CMD_BUFS) {
		D_ERR("insert_cmd: WARNING Command buffer full !\n");
		sti();
		return -ENOMEM;
	}

	/* Allocate memory (freed from send_cmd_queue) */
	cmd_buf.buf[cmd_buf.first_free].data = (u8*)kmalloc(len, GFP_ATOMIC);

	memcpy(cmd_buf.buf[cmd_buf.first_free].data, cmd, len);
	cmd_buf.buf[cmd_buf.first_free].len = len;
	cmd_buf.count++;

	if (cmd_buf.first_free >= (NBR_CMD_BUFS - 1)) {
		cmd_buf.first_free = 0; /* wrap */
		D_CTRL(__FUNCTION__ ": WRAP\n");
	} else {
		cmd_buf.first_free++;
	}
	sti();
	return 0;
}


/* Inserts the command into a queue and starts a task that will send it. The
   function is called from both process and interrupt context. Having a
   seperate task that handles the command queue protects it from concurrent
   use.
*/
s32 
send_cmd(u8 *cmd, u8 len)
{
	s32 tmp;
	tmp = insert_cmd(cmd, len);
	if (tmp < 0) {
		return tmp;
	}

#ifdef __KERNEL__
	send_cmd_task.routine = (void *)send_cmd_queue;
	send_cmd_task.data = NULL;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	queue_task(&send_cmd_task, &tq_scheduler);
#else
	queue_task(&send_cmd_task, &tq_immediate);
	mark_bh(IMMEDIATE_BH);
#endif /* LINUX_VERSION_CODE */
#else
	send_cmd_queue();
#ifdef HCI_EMULATION
	hci_cmd_pending = 0;
#endif
	
#endif	
        return 0;
}


void
update_nhcp(s32 nhcp)
{
	hci_ctrl.hc_buf.cmd_num = nhcp;

	D_CTRL(__FUNCTION__ ": Num_HCI_Command_Packets=%d\n", hci_ctrl.hc_buf.cmd_num);
	
#ifdef __KERNEL__
	send_cmd_task.routine = (void *)send_cmd_queue;
	send_cmd_task.data = NULL;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	queue_task(&send_cmd_task, &tq_scheduler);
#else
	queue_task(&send_cmd_task, &tq_immediate);
   mark_bh(IMMEDIATE_BH);
#endif /* LINUX_VERSION_CODE */
#else
	send_cmd_queue();
#endif	
}


void 
send_cmd_queue(void)
{
	cmd_t *tmp = NULL;
  
	D_CTRL(__FUNCTION__ ": start: Num_HCI_Command_Packets=%d\n", 
	      hci_ctrl.hc_buf.cmd_num);

	cli();
	while ((hci_ctrl.hc_buf.cmd_num > 0)
	       && ((tmp = get_next_cmd()) != NULL)) {
		sti();
   
		PRINTPKT(__FUNCTION__ ": ", tmp->data, tmp->len);
		/* more in queue and we can send */
#ifdef HCI_EMULATION
		hci_emulator(tmp->data, tmp->len);
#else
		bt_write_lower_driver(tmp->data, tmp->len);
#endif
		kfree(tmp->data);
		tmp->data = NULL;

		cli();
		hci_ctrl.hc_buf.cmd_num--;
	}
	sti();
	
	D_CTRL(__FUNCTION__ ": end : %d cmds left in queue\n", cmd_buf.count);

	/*FIXME: this should really be fixed... */
	if (hci_ctrl.hc_buf.cmd_num > 0) {
		wake_up_interruptible(&set_baudrate_wq);
	}
}

#ifdef USE_NCPTIMER
static void
start_ncp_timer(void)
{
#ifdef __KERNEL__
	init_timer(&hci_ncp_timer);
	hci_ncp_timer.function = ncp_timeout;
	hci_ncp_timer.data = 0;
	hci_ncp_timer.expires = jiffies + NCP_TIMEOUT;

	/* reset buffer counter */
	hw.acl_num_count = 0;

	add_timer(&hci_ncp_timer);
#endif
}

static void
release_ncp_timer(void)
{
#ifdef __KERNEL__
	if (hci_ncp_timer.function)
		del_timer(&hci_ncp_timer);
#endif
}

#ifdef __KERNEL__
static void
ncp_timeout(unsigned long ptr)
{
	/* trigger bt_feedstack if we got no new ncp for NCP_TIMEOUT jiffies */

	if (!hw.acl_num_count && /* no new buffers since last timeout */ 
	    hci_ctrl.hc_buf.acl_num != hw.max_acl_num) {
		bt_feedstack();
	}

	/* lets restart */
	start_ncp_timer();
}
#endif

#endif /* USE_NCPTIMER */

void
start_cmd_timer(u8 max_time)
{
#ifdef __KERNEL__
	D_CTRL(__FUNCTION__ "\n");
	init_timer(&hci_cmd_timer);
	hci_cmd_timer.function = cmd_timeout;
	hci_cmd_timer.data = 0;
	hci_cmd_timer.expires = jiffies + max_time*HZ;
	add_timer(&hci_cmd_timer);
#endif
}

void
release_cmd_timer(void)
{
#ifdef __KERNEL__
	del_timer(&hci_cmd_timer);
	D_CMD(__FUNCTION__ "\n");
#endif
        hci_cmd_pending = 0;
}

#ifdef __KERNEL__
static void
cmd_timeout(unsigned long ptr)
{
	/* The command timed out, then we reset the command buffer 
	   counter to 1 again */
	hci_ctrl.hc_buf.cmd_num = 1;
	
	printk(__FUNCTION__ ": Timeout when waiting for command response\n");
        hci_cmd_pending = 0;
	wake_up_interruptible(&hci_wq);
}
#endif

#ifdef USE_INQTIMER
static void

start_inq_timer(u8 inq_len)
{
#ifdef __KERNEL__
#define INQ_FUDGE_FACTOR (2 * HZ)
	D_CMD(__FUNCTION__ "\n");
	init_timer(&hci_inq_timer);
	hci_inq_timer.function = inq_timeout;
	hci_inq_timer.data = 0;
	hci_inq_timer.expires = jiffies + inq_len * INQ_FUDGE_FACTOR;
	add_timer(&hci_inq_timer);
#endif
}

static void
release_inq_timer(void)
{
#ifdef __KERNEL__
	D_CMD(__FUNCTION__ "\n");
	del_timer(&hci_inq_timer);
#endif
        hci_inq_pending = 0;
}

#ifdef __KERNEL__
static void
inq_timeout(unsigned long ptr)
{
	/* The command timed out, then we reset the command buffer 
	   counter to 1 again */
        /* FIX ME: What to do here !! */

/*	hci_ctrl.hc_buf.cmd_num = 1;*/

	printk(__FUNCTION__ ": Timeout when waiting for inquiry response\n");
        hci_inq_pending = 0;
	hci_inq_aborted = 1;
	wake_up_interruptible(&inq_wq);
}
#endif
#endif

s32 
send_cmd_block(u8 *cmd, u8 len, u8 max_time)
{
	u32 tmp;
#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	struct wait_queue wait = { current, NULL};
#else
        DECLARE_WAITQUEUE(wait, current);
#endif

	down(&hci_cmd_semaphore);
 
	add_wait_queue(&hci_wq, &wait);
	current->state = TASK_INTERRUPTIBLE;

#endif
	hci_cmd_pending = 1;
  
	start_cmd_timer(max_time);
	
	tmp = send_cmd(cmd, len);

#ifdef __KERNEL__
	while (hci_cmd_pending)
		schedule();

	remove_wait_queue(&hci_wq, &wait);

	up(&hci_cmd_semaphore);
#else
	while (hci_cmd_pending)		
		usleep(10000);
#endif       
	return tmp;
}

s32 
send_inq_cmd_block(u8 *cmd, u8 len, u8 inq_len)
{
	u32 tmp;

#ifdef __KERNEL__
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	struct wait_queue wait = { current, NULL};
#else
	DECLARE_WAITQUEUE(wait, current);
#endif

	down(&hci_inq_semaphore);
	add_wait_queue(&inq_wq, &wait);
	current->state = TASK_INTERRUPTIBLE;	
	hci_inq_pending = 1;

	if ((tmp = send_cmd(cmd, len)) < 0)
		goto inq_done;
  
#ifdef USE_INQTIMER
	hci_inq_aborted = 0;
	start_inq_timer(inq_len);
#endif
	while (hci_inq_pending)
		schedule();

#ifdef USE_INQTIMER
	if (hci_inq_aborted)
		tmp = -ETIME;
#endif

 inq_done:
	remove_wait_queue(&inq_wq, &wait);
	up(&hci_inq_semaphore);

#else /* __KERNEL__ */

	tmp = send_cmd(cmd, len);

#endif /* __KERNEL__ */

	return tmp;
}

#if 0
/* Used for testing */
void 
show_cmd_buf(void)
{
	s32 i;
	printk("------------------------------------------\n");
	printk("show_cmd_buf: count %d first_free : %d next_to_send : %d\n",
	       cmd_buf.count, cmd_buf.first_free, cmd_buf.next_to_send);

  
	for (i = 0; i < NBR_CMD_BUFS; i++) {
		printk("%d\n", i);
		if (cmd_buf.buf[i].len > 0)
			PRINTPKT(__FUNCTION__ ": cmd_buf: ", cmd_buf.buf[i].data, cmd_buf.buf[i].len);      
	}  
	printk("------------------------------------------\n");
}
#endif


unsigned char* get_remote_friendly_name(unsigned char tmp_bd[])
{
        int i=0;
        int check=1;
        int ii;

        printf("kainui : num_remote_device(hci) => %d\n",num_remote_device);
        while ((i<num_remote_device)&&(check==1))
        {
                if((ii=strncmp(tmp_bd,remote_device[i].bd_addr,6))==0)
                {
                       check = 0;
                       return  remote_device[i].friendly_name;
                }
                i++;
        }
        return 0;

}

unsigned char* get_device_con_friendly_name(unsigned char tmp_bd[])
{
        int i=0;
        int check=1;
        int ii;

        printf("kainui : num_device_con(hci) => %d\n",num_device_con);
        while ((i<num_device_con)&&(check==1))
        {
                printf("kainui : tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
                printf("kainui : remote_bd %x:%x:%x:%x:%x:%x\n",device_con[i].bd_addr[0],device_con[i].bd_addr[1],device_con[i].bd_addr[2],device_con[i].bd_addr[3],device_con[i].bd_addr[4],device_con[i].bd_addr[5]);
                if((ii=strncmp(tmp_bd,device_con[i].bd_addr,6))==0)
                {
                       check = 0;
                       return  device_con[i].friendly_name;
                }
                i++;
        }
        return 0;

}


//unsigned char* get_remote_device
int get_num_remote_device(void)
{
        return num_remote_device;
}

int get_num_device_con(void)
{
        return num_device_con;
}

int get_num_inquiry_result(void)
{
        int tmp;
        tmp = num_inquiry_result;
        num_inquiry_result = 0;
        return tmp;
}

unsigned char* get_remote_address(int num_remote_device1)
{
        int j;
        unsigned char tmp_bd[6];
        for (j=0; j<6; j++)
        {
                tmp_bd[j] = (unsigned char)remote_device[num_remote_device1-1].bd_addr[j];
        }
        return tmp_bd;
}

unsigned char* get_device_con_address(int num_device_con)
{
        int j;
        unsigned char tmp_bd[6];
        for (j=0; j<6; j++)
        {
                tmp_bd[j] = (unsigned char)device_con[num_device_con-1].bd_addr[j];
        }
        return tmp_bd;
}

/****************** END OF FILE hci.c ***************************************/
