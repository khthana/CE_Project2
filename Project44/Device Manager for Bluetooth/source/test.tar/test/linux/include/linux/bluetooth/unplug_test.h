
#ifndef UNPLUGTEST_H
#define UNPLUGTEST_H


void unplug_test_init(void);
s32 process_test_cmd(s32 test_case);
s32 do_sdp_test(int n);

#endif
