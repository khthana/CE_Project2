
#ifndef L2CAP_CON_H
#define L2CAP_CON_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/bluetooth/btcommon.h>
#include <linux/types.h>
#else
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

/* internal test of connection manager */
#define L2CAP_SELFTEST 0

/****************** TYPE DEFINITION SECTION *********************************/

/* con->c_flags */
#define FLAG_WAKEMEUP  0x0001 /* wake up con->wq */
#define FLAG_RETURNNOW 0x0002 /* return immediately, used when setting up 
				 baseband */
#define FLAG_DONTSLEEP 0x0004 /* used when e.g ertx_timeout calls disc req */

/* con->c_status */
#define CSTATUS_SUCCESS      0 /* return status success to upper caller */
#define CSTATUS_FAILED       1 /* return status failed to upper caller */
#define CSTATUS_RTX_TIMEOUT  2 /* resend request */
#define CSTATUS_ERTX_TIMEOUT 3 /* disconnect link */
#define CSTATUS_MAX_NO_RTX   4
#define CSTATUS_CMDREJECT    5

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/


/*********************************************************************/
/*---------------------- INIT AND SHUTDOWN --------------------------*/
/*********************************************************************/

void init_con_list(void);
void free_con_list(void);

l2cap_con* create_con(u16 hci_hdl, CID lcid, CID rcid);
s32 delete_con(l2cap_con *con);

void insert_con(l2cap_con *con);
void reset_con(l2cap_con* con);
l2cap_con* get_first_con(void);
l2cap_con* get_next_con(l2cap_con* con);

void init_flow(flow *f);

/*******************************************************************/
/*-------------------------- ACTIONS ------------------------------*/
/*******************************************************************/

l2cap_con* get_rcon(CID rcid);
l2cap_con* get_lcon(CID lcid);
l2cap_con* get_con(BD_ADDR bd, s32 STATE);
l2cap_con* get_con_hcihdl(u16 hdl);
l2cap_con* check_remote_cid(u16 hdl, CID remote_cid);

u16 get_cid(void);
void show_con(const u8* head, l2cap_con* con);
void show_list(void);
s32 count_con(u16 hci_hdl);


#if L2CAP_SELFTEST
void test_conlist(void);
s32 remove_rcid(CID rcid);
#endif

s32 l2cap_sprint_con(u8 *buf, l2cap_con* con);
s32 l2cap_sprint_active(u8 *buf);

#endif
/****************** END OF FILE l2cap_con.h *********************************/
