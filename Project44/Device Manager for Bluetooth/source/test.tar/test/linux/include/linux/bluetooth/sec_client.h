
#ifndef SEC_CLIENT_H
#define SEC_CLIENT_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/bluetooth/btcommon.h>
#include <linux/types.h>
#else
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

enum security_requests{
	HCI,
	L2CAP,
	RFCOMM
};

enum security_results{
	SECURITY_OK,
	AUTHENTICATION_PENDING,
	UNKNOWN_REQUEST_TYPE,
	UNKNOWN_REQUEST_VALUE,
	PSM_SECURITY_BLOCK,
	AUTHENTICATION_FAILURE,
	ENCRYPTION_FAILURE,
	GENERAL_FAILURE
};

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

extern struct proc_dir_entry sec_man_proc_entry;

void sec_client_shutdown(void);

void sec_man_init(enum security_requests user);

#ifdef __KERNEL__
s32 sec_man_create_proc_file(void);
s32 sec_man_remove_proc_file(void);
#endif

void sec_man_check(enum security_requests user, BD_ADDR bd_addr,
                   u32 service_data, u32 user_data);

void sec_man_event(enum security_requests user, BD_ADDR bd_addr, u8 event,
		   u8 *param, u8 param_len);

void sec_man_get_cached_link_key(u8 *param);

#endif
/****************** END OF FILE sec_client.h *********************************/
