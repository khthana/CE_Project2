
#ifndef BTCOMMON_H
#define BTCOMMON_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/bluetooth/btdebug.h>
#include <linux/bluetooth/btconfig.h>
#include <linux/timer.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/version.h>
#else
#include "local.h"
#include "btdebug.h"
#include "btconfig.h"
#include <sys/unistd.h> /* for the sleep ..*/
#endif

/* Defines common to all files */

#define FALSE 0
#define TRUE  1

/* KERNEL_VERSION() is not defined in all 2.0.x versions of the linux kernel.
   Define it here so we can use it in the code without having to check whether
   it is defined or not */

#ifndef KERNEL_VERSION
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#endif

#ifndef __KERNEL__
#define kmalloc(size,prio) malloc((size))
#define kfree(obj) free((obj))
#define wake_up_interruptible(p) do {*(p) = 0;} while (0)
#define interruptible_sleep_on(p) do {(int)*(p)=1; while (*(p)){ usleep(10000);}; } while (0)
#define cli()
#define sti()
#endif

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

#define GET_BITS(var, bit, bits) (((var) >> (bit)) & ((1UL << (bits)) - 1))
#define SET_BITS(var, bit, bits, x)                                    \
	do {                                                           \
		(var) = ((var) & ~(((1UL << (bits)) - 1) << (bit))) |  \
		        (((x) & ((1UL << (bits)) - 1)) << (bit));      \
	} while (0)

/* extract line number from tty */
#define GET_TTYLINE(tty) (MINOR(tty->device) - tty->driver.minor_start)

/* These two macros are the same as le16_to_cpup() and le32_to_cpup()
   only that they work with unaligned addresses */
#define le16_to_cpuu(addr) (le16_to_cpu(get_unaligned((u16 *)addr)))
#define le32_to_cpuu(addr) (le32_to_cpu(get_unaligned((u32 *)addr)))

/****************** Defines realted to the bluetooth implementation *********/

#define SERIAL_PORT_PROFILE 0
/* FIXME: Will this be specified in the spec somewhere... */ 

/* The BC flag in the HCI header */
#define NO_BROADCAST 0
#define ACTIVE_BROADCAST 1
#define PICONET_BROADCAST 2

#define MAX_NBR_OF_CONNECTIONS 7

/* Macro to extract the linenumber in a conid used by applications/stack. */
#define GET_LINE(conID)  ( ((conID & 0xff00) >> 8) )

/* Define to control usage of the security manager */  

/****************** Defines realated to the management of the bt-driver *****/


#define BT_NBR_DATAPORTS 7
#define BT_NBR_CTRLPORTS 1
#define BT_NBR_PORTS (BT_NBR_CTRLPORTS + BT_NBR_DATAPORTS)

/* Define the ioctls to the bt driver */
#define BT_IOC_MAGIC 'B' /* Use B as a magic number */
#define BT_IOC_MAXNR 255

#define BTCONNECT _IOW(BT_IOC_MAGIC, 0x00, bt_connection)
#define BTDISCONNECT _IOW(BT_IOC_MAGIC, 0x01, u32)
#define BTSETSPEED _IOW(BT_IOC_MAGIC, 0x02, s32)
#define BTINITSTACK _IO(BT_IOC_MAGIC, 0x03)
#define BTSETSERTTY _IO(BT_IOC_MAGIC, 0x04)
#define BTSETMODEMDUMMY _IOW(BT_IOC_MAGIC, 0x05, s32)
#define BTSHUTDOWN _IO(BT_IOC_MAGIC, 0x06)
#define BTREADREMOTEBDADDR _IOWR(BT_IOC_MAGIC, 0x07, u8[6])
#define BTRESETPHYSICALHW _IO(BT_IOC_MAGIC, 0x08)
#define BTISINITIATED _IOR(BT_IOC_MAGIC, 0x09, s32)
#define BTHWVENDOR _IOR(BT_IOC_MAGIC, 0x0A, char[20])
#define BTFIRMWAREINFO _IOR(BT_IOC_MAGIC, 0x0B, char[80])
#define BTWAITFORCONNECTION _IOW(BT_IOC_MAGIC, 0x0C, s32)
#define BTWAITNEWCONNECTIONS _IO(BT_IOC_MAGIC, 0x0D)
#define BTISLOWERCONNECTED _IOW(BT_IOC_MAGIC, 0x0E, s32)
#define BT_SDP_REQUEST _IOW(BT_IOC_MAGIC, 0x0F, bt_sdp_request)
#define BT_GETCACHEDLINKKEY _IOWR(BT_IOC_MAGIC, 0x10, u8[22])

/* Ioctls executing HCI commands */

/* Link Control Command */
#define HCIINQUIRY _IOWR(BT_IOC_MAGIC, 0x20, inquiry_results)
#define HCILINKKEYREPLY _IOWR(BT_IOC_MAGIC, 0x21, u8[22])
#define HCILINKKEYNEGATIVEREPLY _IOWR(BT_IOC_MAGIC, 0x22, u8[6])
#define HCIPINCODEREPLY _IOWR(BT_IOC_MAGIC, 0x23, u8[23])
#define HCIPINCODENEGATIVEREPLY _IOWR(BT_IOC_MAGIC, 0x24, u8[6])
#define HCIAUTHENTICATION_REQUESTED _IOW(BT_IOC_MAGIC, 0x25, u8[6])
#define HCISETCONNECTION_ENCRYPTION _IOW(BT_IOC_MAGIC, 0x26, u8[7])

/* Link Policy Commands */
#define HCISWITCHROLE _IOW(BT_IOC_MAGIC, 0x28, u8[7])

/* Host Controller & Baseband Commands */
#define HCIRESET _IO(BT_IOC_MAGIC, 0x30)
#define HCIFLUSH _IO(BT_IOC_MAGIC, 0x31)
#define HCICREATE_NEW_UNIT_KEY _IOR(BT_IOC_MAGIC, 0x32, s32)
#define HCIREADSTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x33, u8[7])
#define HCIWRITESTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x34, u8[22])
#define HCIDELETESTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x35, u8[7])
#define HCISETLOCALNAME _IOW(BT_IOC_MAGIC, 0x36, u8[248])
#define HCIREADSCANENABLE _IOR(BT_IOC_MAGIC, 0x37, s32)
#define HCIWRITESCANENABLE _IOW(BT_IOC_MAGIC, 0x38, s32)
#define HCIWRITEPAGESCANACTIVITY _IOW(BT_IOC_MAGIC, 0x39, u32[2])
#define HCIWRITECLASSOFDEVICE _IOW(BT_IOC_MAGIC, 0x3a, u8[3])
#define HCIREAD_AUTHENTICATION_ENABLE _IOR(BT_IOC_MAGIC, 0x3b, s32)
#define HCIWRITE_AUTHENTICATION_ENABLE _IOWR(BT_IOC_MAGIC, 0x3c, s32)
#define HCIREAD_ENCRYPTION_MODE _IOR(BT_IOC_MAGIC, 0x3d, s32)
#define HCIWRITE_ENCRYPTION_MODE _IOWR(BT_IOC_MAGIC, 0x3e, s32)
#define HCISET_EVENT_FILTER _IOW(BT_IOC_MAGIC, 0x3f, u8[3])
#define HCIREADTRANSMITPOWERLEVEL _IOWR(BT_IOC_MAGIC, 0x40, u8)

/* Informational Parameters */
#define HCIREADCOUNTRYCODE _IOR(BT_IOC_MAGIC, 0x43, s32)
#define HCIREADLOCALBDADDR _IOR(BT_IOC_MAGIC, 0x45, u8[6])

/* Status Parameters */

/* Testing Commands */
#define HCIENABLEDUT _IO(BT_IOC_MAGIC, 0x65)

/* ioctls vendor specific HCI commands */
#define HCISETBAUDRATE _IOW(BT_IOC_MAGIC, 0x70, s32)
#define HCIWRITEBDADDR _IOW(BT_IOC_MAGIC, 0x71, u8[6])

/* | len 1 byte | 4 bytes hci header | data (max 256) | */
#define HCISENDRAWDATA _IOW(BT_IOC_MAGIC, 0x72, u8[261])

/* | BD(6) | len(2) | data |*/
#define BTPING _IOW(BT_IOC_MAGIC, 0x73, ping_struct)

/* | BD(6) | type (2) |*/
#define BTGETINFO _IOW(BT_IOC_MAGIC, 0x74, u8[8])

/* other ioctls used for testing */
#define BTSENDTESTDATA _IOW(BT_IOC_MAGIC, 0xf0, s32[2])
#define HCITESTCONNECTREQ _IOW(BT_IOC_MAGIC, 0xf1, u8[6])

/* | len (1) | test string | -- used for unplug tests */
#define BTTESTCOMMAND _IOW(BT_IOC_MAGIC, 0xf2, u8[261])

#define BTSETMSSWITCH _IOW(BT_IOC_MAGIC, 0xf3, u8)

#define BTSETBCSPMODE _IOWR(BT_IOC_MAGIC, 0xf4, s32)


#define CSR_PSKEY_MSGHDR_SIZE 3
#define CSR_PSKEY_MAXPARAMS 40

#define BT_CSR_PSKEY _IOWR(BT_IOC_MAGIC, 0xf5, u16[CSR_PSKEY_MSGHDR_SIZE + CSR_PSKEY_MAXPARAMS])

#define BTINITBCSP _IO(BT_IOC_MAGIC, 0xf6)

#define BT_SET_DFU_MODE _IOWR(BT_IOC_MAGIC, 0xf7, s32)
#define BT_SEND_DFU_COMMAND _IOWR(BT_IOC_MAGIC, 0xf8, u8[2048])
#define BT_RETRIEVE_DFU_RESPONSE _IOWR(BT_IOC_MAGIC, 0xf9, u8[2048])

#define BTSETMAXCONNECTIONS _IOW(BT_IOC_MAGIC, 0xfa, u8)

/* NOTE !
 * N_BT should be defined in /include/asm/termios.h 
 * However, if you are compiling this source standalone, the following define
 * may be useful. If this number is already used simply change it to something
 * that is not used.
 */

#ifndef N_BT
#define N_BT 15 /* hopefully available :) */
#endif

#define MAX_BT_TMP_BUF 4096

/****************** TYPE DEFINITION SECTION *********************************/

/* The BT transmit object used when sending data */
typedef struct bt_tx_buf {
	u32 magic;
	u32 hci_hdl; /* The destination hci connection handle */
	u8 pb_flag; /* Packet boundary flag */
	u8 bc_flag; /* Broadcast flag */
	s32 line;  /* -1 means that the buffer isn't allocated for a line */
	
	/* 'Filled in' data length  (up to this point) when creating object.
	   Also used when sending data to mark how much that has been sent
	   hci_send_data calculates what to send by : 
	   to_send=tx_buf->data+tx_buf->subscr_len-tx->cur_len */
	s32 cur_len; 
	/* Total length of the data area not including this buffer hdr  */
	s32 subscr_len; 
	s32 flushed;  /* If set, discard at send level */
	u8 data[0]; /* The actual data segment to send */
} __attribute__ ((packed)) bt_tx_buf;

/* TCI layer object */
typedef struct tci_tx_buf{
	u8 hci_hdr[5]; 
	u8 l2cap_hdr[4];
	u8 frame[0];
} __attribute__ ((packed)) tci_tx_buf;


/* SDP layer object */
typedef struct sdp_tx_buf{
	u8 hci_hdr[5]; 
	u8 l2cap_hdr[4];
	u8 frame[0];
} __attribute__ ((packed)) sdp_tx_buf;

/* RFComm layer object */
typedef struct rfcomm_tx_buf{
	u8 hci_hdr[5];
	u8 l2cap_hdr[4];
	u8 frame[0];
} __attribute__ ((packed)) rfcomm_tx_buf;

/* TCS layer object */
typedef struct tcs_tx_buf{
	u8 hci_hdr[5];
	u8 l2cap_hdr[4];
	u8 frame[0];
} __attribute__ ((packed)) tcs_tx_buf;

/* L2CAP layer object */
typedef struct l2cap_tx_buf{
	u8 hci_buf[5];  
	u8 frame[0];  
} __attribute__ ((packed)) l2cap_tx_buf;

#define BT_TX_HDRSIZE sizeof(bt_tx_buf)
#define L2CAP_TX_HDRSIZE sizeof(l2cap_tx_buf)
#define RFCOMM_TX_HDRSIZE sizeof(rfcomm_tx_buf)
#define SDP_TX_HDRSIZE sizeof(sdp_tx_buf)

/****************** Some typedefs used in the l2cap_con struct **************/

typedef u8 BD_ADDR[6];

typedef u16 CID;

typedef struct flow {
	u8 flags; /* default 0 */
	u8 service; /* default 0x01 (best effort) */
	u32 token_rate;
	u32 bucket_size; /* bytes */
	u32 peak; /* bps */
	u32 latency; /* ms */ 
	u32 delay; /* ms */
} __attribute__ ((packed)) flow;
 
/****************** Definintion of the L2CAP connection object **************/

/* FIXME -- move all layer specific structs into each layers .h file 
   and fix include order ! */

/* RTX Actions */
#define RTX_ACTION_DISCONNECT 0 /* default */
#define RTX_ACTION_START_ERTX 1  /* during con*/
#define RTX_ACTION_TERMINATE 2 /* if we tried to disconnect and got no resp */

#define ERTX_ACTION_DISCONNECT 0xf0 /* default */
#define ERTX_ACTION_TERMINATE 0xf1

typedef struct l2cap_timer_obj
{
#ifdef __KERNEL__
	struct timer_list rtx;
	struct timer_list ertx;
	struct timer_list crtx; /* Maximum negotiation time 120 sec */
#else
	/* dummy */
	int rtx;
	int ertx;
	int crtx; /* Maximum negotiation time 120 sec */
#endif
	u16 rtx_no; /* nbr retries */
	u16 rtx_action; /* preferred action when rtx expires */	
	u16 rtx_inuse; /* to avoid concurrent use */

	u16 ertx_action; /* preferred action when ertx expires */	
	u16 ertx_inuse;

  

	//struct timeval caller_id; /* used to identify caller */
} __attribute__ ((packed)) l2cap_timer_obj;

typedef struct l2cap_con {
	s32 magic;
	BD_ADDR remote_bd; /* 6 bytes */
	u16 hci_hdl;

	/* FIXME - add multiple HCI handles for group 
	   management functionality */

	u16 local_cid;
	u16 remote_cid;
	s32 current_state;
	u16 psm;
	u16 local_mtu;

	/* Config options from remote peer */
	u16 remote_mtu;
	u16 flush_timeout;
	flow remote_qos;
	u16 remote_flags; /* more config options to come */
	
	u16 local_flags; /* indicates more config options to be sent */

	u8 initiator;

	u8 link_up;  
	u8 sig_id_sent; /* last sent command id */
	u8 sig_id_rcv; /* last received command id */
	
	s32 conf_req_sent;
	s32 conf_req_ready; /* indicates if we received pos rsp on our req */
	s32 conf_rsp_ready; /* indicates if we replied pos on a config req */

	/* Fixme -- fix multicall */
	struct l2cap_timer_obj timer;

	/* Fixme -- fix all return values according this system */
	s32 c_result; /* returns result to higher layers, used together with
		          MSGCODE macro */
	s32 c_status; /* used to indicate status up caller */
	u32 c_flags;  /* internal connection flags see l2cap_con.h for 
			 flag codes */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
	struct wait_queue *wq;
#else
	wait_queue_head_t wq;
#endif /* LINUX_VERSION_CODE */

	/* stats packets sent/received/lost etc*/

	void *upper_con; /* upper layer connection object */

	struct l2cap_con *prev;
	struct l2cap_con *next; /* Next connection in list */
} __attribute__ ((packed)) l2cap_con;

/* Function pointers to upper layers, confirm and indication functions */
typedef struct protocol_layer {
	u32 psm;
	/* add psm value and skip registered */
	void (*con_ind)(l2cap_con *con);
	void (*conf_ind)(l2cap_con *con);
	void (*disc_ind)(l2cap_con *con);

	void (*con_pnd)(l2cap_con *con, s32 status);
	void (*con_cfm)(l2cap_con *con, s32 result);
	void (*conf_cfm)(l2cap_con *con, s32 result);
	void (*disc_cfm)(l2cap_con *con);

	void (*receive_data)(l2cap_con *con, u8 *data, u32 len);
	struct protocol_layer *next_layer; 
} __attribute__ ((packed)) protocol_layer;

/****************** RFCOMM connection object ****************************/

enum rfcomm_states{DISCONNECTED, CONNECTING, NEGOTIATING, CONNECTED, DISCONNECTING, FLOW_STOPPED};

typedef struct dlci_struct{
	enum rfcomm_states state;
	u8 local_credits;
	u8 remote_credits;
	u8 initiated;
	u8 initiator;
	u16 mtu;
} __attribute__ ((packed)) dlci_struct;

typedef struct rfcomm_con{
	u32 magic;
	u8 line;
	u8 credit_flow;
	dlci_struct dlci[62];
	u8 initiator;
	u8 server_chn;
	l2cap_con *l2cap;
} __attribute__ ((packed)) rfcomm_con;

/****************** SDP connection object ****************************/
enum sdp_states{SDP_DISCONNECTED, SDP_CONNECTING, SDP_CONNECTED};

typedef struct sdp_con{
	l2cap_con *l2cap;
	u32 initiator;
	enum sdp_states state;
	u32 id;
	u8 line;
} __attribute__ ((packed)) sdp_con;


/****************** BT connection object ********************************/

/* Connection id (32 bits) |PSM(16 bits)|layer_specific(16 bits)|�*/

/* General connection id macros */
#define GET_PSM(con_id) (con_id >> 16)


/* see rfcomm.h for layer specific macros */


/* fixme -- SDP connection ID macros  */


typedef struct bt_connection{
	u8 bd[6];
	u32 id; /* | psm(16 bits)�| layer_specific (16 bits)�|�*/
} bt_connection;

typedef struct bt_sdp_request
{
	u32 conID;
	u8 sdpCommand;
	u8 pduPayload[256];
	int pduLength;
	u8 requestResponse[256];
	int responseLength;
} bt_sdp_request;

/****************** Other structures used in the stack **********************/

enum bt_session_states { BT_INACTIVE, BT_LOWERCONNECTED, 
			 BT_UPPERCONNECTED, BT_ACTIVE };

/* tty->driver_data... */
typedef struct bt_session
{
	/* general */
	struct tty_struct *upper_tty;
	unsigned int pid;
	volatile s32 connect_status;
	volatile s32 disconnect_status;
	/* hci link */

	/* rfcomm */
	rfcomm_con *rfcomm;
	u8 dlci;
	s32 state;

	/* sdp */
	u8 *sdpRequestResponseData;
	u16 sdpRequestResponseDataLength;
	int sdpID;

	/* tcs ? */
} bt_session;

#define ANY_LINE 255
#define NO_LINE 256

#ifdef __KERNEL__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
typedef struct bt_ctrl_struct {
	struct bt_session session[BT_NBR_PORTS];
	wait_queue_head_t connect_wq[BT_NBR_PORTS]; 
	wait_queue_head_t any_wq;
	s32 nbr_active;
	s32 nbr_upper;
	s32 ctrl_tty_count; /* number of open file descriptors to ttyBTC */
	s32 tty_last_unthrottled; /* indicated which line that was woken 
				     up last time buffers were below the 
				     unthrottle level */
} bt_ctrl_struct;
#else
typedef struct bt_ctrl_struct {
	struct bt_session session[BT_NBR_PORTS];
	struct wait_queue *connect_wq[BT_NBR_PORTS]; 
	struct wait_queue *any_wq;
	s32 nbr_active;
	s32 nbr_upper;
	s32 ctrl_tty_count; /* number of open file descriptors to ttyBTC */
	s32 tty_last_unthrottled; /* indicated which line that was woken 
				     up last time buffers were below the 
				     unthrottle level */
} bt_ctrl_struct;
#endif /* LINUX_VERSION_CODE */
#endif /* __KERNEL__ */

typedef struct bt_stat_struct
{
	u32 bytes_sent;
	u32 bytes_received;
} __attribute__ ((packed)) bt_stat_struct;

extern bt_stat_struct bt_stat;

typedef struct inquiry_results {
	u32 nbr_of_units;
	u32 inq_time;
	u8 bd_addr[0];
} inquiry_results;

typedef struct ping_struct
{
	u8 bd[6];
	u16 len;
	u8 data[1024];
} ping_struct;

typedef struct serport_profile_info {
	s32 rfcomm_serv_chan;
	u32 serport_name_length;
	u8 serport_name[64];
} serport_profile_info;

#endif
/****************** END OF FILE btcommon.h **********************************/
