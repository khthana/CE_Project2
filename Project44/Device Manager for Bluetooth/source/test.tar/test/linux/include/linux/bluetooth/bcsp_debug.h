
#ifndef BCSP_DEBUG_H
#define BCSP_DEBUG_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/bluetooth/btdebug.h>
#else
#include "btdebug.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#define BCSP_SYS_DEBUG 0

#ifdef BCSP_SYS_DEBUG 
#define BCSP_SYS(fmt...) printk("BCSP: " fmt)
#else
#define BCSP_SYS(fmt...)
#endif

#define BCSP_DEBUG 0

#define BCSP_PARSELOWER 0 /* Parses in/outgoing BCSP headers */

#define SLIP_DEBUG 0

#define INTERGRITY_DEBUG 0

#define MUX_DEBUG 0

#define DATAGRAM_DEBUG 0

#define SEQUENCE_DEBUG 0

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

#endif
/****************** END OF FILE bcsp_debug.h ********************************/
