
#ifndef TEST_H
#define TEST_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/bluetooth/btcommon.h>
#else
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

extern l2cap_con *testcon;
extern l2cap_con *testcon2;
extern l2cap_con *testcon3;

#define UPTEST_DATA_LEN 16384

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

void test_init(void);
void test_shutdown(void);
s32 test_connect_req(BD_ADDR bd);
s32 test_connect_psmreq(BD_ADDR bd, u16 psm);
void test_connect_ind(l2cap_con *l2cap);
void test_connect_cfm(l2cap_con *l2cap, s32 status);
void test_connect_pnd(l2cap_con *l2cap, s32 status);
void test_config_ind(l2cap_con* l2cap);
void test_config_cfm(l2cap_con *l2cap, s32 status);
s32 test_disconnect_req(l2cap_con *con);
void test_disconnect_ind(l2cap_con *l2cap);
void test_disconnect_cfm(l2cap_con *l2cap);
void test_receive_data(l2cap_con *l2cap, u8 *data, u32 len);
s32 test_send_data(l2cap_con *con, u8 *testdata, s32 len);
s32 test_process_cmd(u8 *cmd, s32 size);

#endif
/****************** END OF FILE sdp.h ***************************************/
