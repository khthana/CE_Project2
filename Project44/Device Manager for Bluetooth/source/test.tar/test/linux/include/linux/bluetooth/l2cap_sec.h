
#ifndef L2CAP_SEC_H
#define L2CAP_SEC_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/bluetooth/btcommon.h>
#include <linux/types.h>
#else
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

void l2cap_sec_man_init(void);

void l2cap_check_allowed_security(u16 psm, BD_ADDR bd_addr, l2cap_con *con);

/* Called from sec_client */
void l2cap_process_sec_man_response(u16 result, u32 user_data);

#endif
/****************** END OF FILE l2cap_sec.h **********************************/
