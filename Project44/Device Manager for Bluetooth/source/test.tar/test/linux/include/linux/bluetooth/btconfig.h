
#ifdef __KERNEL__
#include <linux/config.h>
#endif

/*
 * When the stack is included as part of the kernel source tree, this macro
 * is defined, and we can use the standard Linux kernel config instead of
 * this next section. See Config.in in the source directory.
 * --gmcnutt
 */
#ifndef CONFIG_BLUETOOTH
/******************
 *    General     *
 ******************/

/* Bluetooth HW defines used to setup different HW and to cope with 
   limitations in HW */

/* This sets current HW */
#undef CONFIG_BLUETOOTH_NOINIT
#undef CONFIG_BLUETOOTH_CSR
#undef CONFIG_BLUETOOTH_DIGIANSWER
#define CONFIG_BLUETOOTH_ERICSSON
#undef CONFIG_BLUETOOTH_INFINEON_BMI
#undef CONFIG_BLUETOOTH_GENERIC    
#undef CONFIG_BLUETOOTH_USBMODULE  /* Not implemented */

/* Use TCI layer or not */
#undef CONFIG_BLUETOOTH_USE_TCI

/* use of /proc files to read status information */
#define CONFIG_BLUETOOTH_PROC

/* Used to decrease overruns on serial port (see bluetooth.c) */
#undef CONFIG_BLUETOOTH_USE_INBUFFER

#ifdef __CRIS__
#define CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
#else
#undef CONFIG_BLUETOOTH_USE_SECURITY_MANAGER
#endif

#undef CONFIG_BLUETOOTH_ENABLE_MSSWITCH
#undef CONFIG_BLUETOOTH_EARLY_MSSWITCH

#ifdef CONFIG_BLUETOOTH_CSR
/* This is set from the Makefile, so do not set it here */
//#define CONFIG_BLUETOOTH_SUPPORT_BCSP
#undef CONFIG_BLUETOOTH_USE_BCSP
#endif

/* Use testcode or not */
/* This is set from the Makefile if appropriate, so do not set it here */
//#undef CONFIG_BLUETOOTH_UNPLUG_TEST

/***************
 *     HCI     *
 ***************/

/* This should be defined if you are using Ericsson firmware that is
   older than P9A */
#undef CONFIG_BLUETOOTH_SET_BAUDRATE_BLOCKING

/****************
 *     L2CAP    *
 ****************/

#define CONFIG_BLUETOOTH_L2CAP_USE_TIMERS
#undef CONFIG_BLUETOOTH_L2CAP_CONNECTIONLESS

/*****************
 *     RFCOMM    *
 *****************/

/***************
 *     SDP     *
 ***************/
#endif /* CONFIG_BLUETOOTH */

/***************************************************************************/

/* The following configurations cannot be set using the kernel
   configuration tools */

/* HCI emulation enables using the stack without any bluetooth hardware. 
   With this option defined you can test the stack by connecting two Linux 
   machines with a nullmodem cabel. (If you are defining this you must start 
   btd with no hw init) */

//#define HCI_EMULATION

/* This define is used during test of the host flow control */
//#define HOST_FLOW_CTRL

#ifdef __KERNEL__
/* Don't define these four, they are only used for AXIS internal tests */
//#define EMC_TEST
//#define EMC_TEST_INITIATOR
//#define EMC_LISTNER_ADDR 0x1810ce
//#define EMC_TEST_DATA_SIZE 678
#endif
