
#ifndef RFCOMM_SEC_H
#define RFCOMM_SEC_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/bluetooth/btcommon.h>
#include <linux/types.h>
#else
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

void rfcomm_sec_man_init(void);

void rfcomm_check_allowed_security(BD_ADDR bd_addr, u8 dlci,
                                   rfcomm_con *rfcon);

/* Called from sec_client */
void rfcomm_process_sec_man_response(u16 result, u32 user_data,
                                     u32 request_value);

#endif
/****************** END OF FILE rfcomm_sec.h *********************************/
