
#ifndef BLUETOOTH_H
#define BLUETOOTH_H

#ifdef __KERNEL__
#include <linux/config.h>
#include <linux/bluetooth/btcommon.h>
#else
#include "btcommon.h"
#endif

/* glue functions */
s32 bt_write_lower_driver(u8 *data, s32 len);
#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
s32 bt_write_lower_driver_real(u8 *data, s32 len);
#endif
s32 bt_receive_top(u32 con_id, u8 *data, s32 len);

void parse_event(u8 *event);
s32 check_event(u8 event);

/***********************************/
/* Init, shutdown and registration */
/***********************************/

#if !defined(MODULE) && !defined(__KERNEL__)
s32 bt_init(void);
#endif

s32 bt_register_rfcomm(rfcomm_con *rfcomm, u8 dlci);
s32 bt_unregister_rfcomm(s32 line);
s32 bt_register_sdp(u8 line, u8 sdpID);
s32 bt_unregister_sdp(s32 line);

s32 bt_register_tty(struct tty_struct *tty);
s32 bt_unregister_tty(struct tty_struct *tty, s32 line);
s32 bt_registered(struct tty_struct *tty);

void bt_shutdown(void);
void bt_hangupline(s32 line);
void bt_feedstack(void);
void bt_wait_tx(s32 trim_delay);

void bt_connect_ind(u32 con_id);
void bt_disconnect_ind(u32 con_id);
void bt_disconnect_cfm(u32 con_id, s32 status);

/******************/
/* Misc functions */
/******************/

s32 bt_initiated(void);
s32 bt_use_bcsp(s32 new_use_bcsp);
s32 bt_dfu_mode(s32 new_dfu_mode);
void bt_connect_cfm(u32 con_id, s32 status);
s32 bt_sprint_status(u8 *buf);
void bt_send_sdp_data_received(u8 line, u8 *data, int len);
void bt_reset_phys_hw(void);

/* Handles wakeup of failed blocking function calls */
#ifdef __KERNEL__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
void start_wq_timer(struct timer_list *wq_timer,
		    u32 timeout, wait_queue_head_t *wq);
#else
void start_wq_timer(struct timer_list *wq_timer,
		    u32 timeout, struct wait_queue **wq);

#endif /* LINUX_VERSION_CODE */
void release_wq_timer(struct timer_list *wq_timer);
#endif /* __KERNEL__ */

#endif
/****************** END OF FILE bluetooth.h *********************************/
