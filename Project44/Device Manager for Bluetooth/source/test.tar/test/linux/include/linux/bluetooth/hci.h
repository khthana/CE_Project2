
#ifndef HCI_H
#define HCI_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/config.h>
#include <linux/types.h>
#include <linux/bluetooth/btcommon.h>
#else
#include "local.h"
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

/* Defines for the packet types */
#define CMD_PKT 0x01
#define ACL_PKT 0x02
#define SCO_PKT 0x03
#define EVENT_PKT 0x04
#define ERROR_PKT 0x05
#define NEG_PKT 0x06

#define INQUIRY_PAGESCAN_DISABLE 0
#define INQUIRY_SCAN_ENABLE 1
#define PAGE_SCAN_ENABLE 2

/* check in l2cap that MTU doesn't exceed this value */
#ifdef CONFIG_BLUETOOTH_UNPLUG_TEST
#define HCI_IN_SIZE 16386
#else
#define HCI_IN_SIZE 800
#endif
/* Struct defining a HCI command packet, the meaning of the type field is
   decribed in part H:4 chapter 2 in the baseband core specification. The
   other fields are described in section H:1 chapter 4.4.1 in the baseband
   core specification */ 

typedef struct cmd_pkt {
	u8 type;
	u16 opcode;
	u8 len;
	u8 data[256];
} __attribute__ ((packed)) cmd_pkt;

#define hci_put_opcode(ocf, ogf)(cpu_to_le16(((ocf) & 0x03ff) | ((ogf) << 10 & 0xfc00)))
//#define hci_put_le16(buf, val) { *((char*)buf) = (val) & 0xff; *((char*)buf + 1) = (val) >> 8; }
#define hci_get_ocf(opcode) (cpu_to_le16((opcode) & 0x3ff))
#define hci_get_ogf(opcode) (cpu_to_le16(((opcode) & 0xfc00) >> 10))

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

s32 hci_trig_send(void);
s32 hci_acl_num_cnt(void);
s32 hci_module_init(void);
s32 hci_init(void);
void hci_shutdown(void);
void hci_clear_buffer(u32 con_hdl);
void hci_receive_data(u8* data, u32 count);
s32 hci_send_data(bt_tx_buf *tx_buf);

s32 hci_set_max_connections(s32 max_connections);

#ifdef CONFIG_BLUETOOTH_SUPPORT_BCSP
void hci_receive_event(u8 *data, s32 count);
void hci_receive_acl(u8 *data, s32 count);
void hci_receive_hq(u8 *data, u32 count);
void hci_receive_bcsp(u8 *data, u32 count);
void hci_receive_dfu(u8 *data, u32 count);

s32 hci_read_dfu(u8* data, u32 count);

void hci_dfu_module_init(void);
void hci_shutdown_dfu(void);
#endif

#ifdef CONFIG_BLUETOOTH_CSR
s32 csr_pskey(u16 ps_key, u16 rw_mode, u16 *retb, u16 n_pars);
#endif

s32 lp_connect_req(u8 bd_addr[]);
s32 lp_connect_rsp(u8 bd_addr[], u32 cfm);
s32 lp_disconnect(u32 con_hdl);

u8* get_err_msg(u32 err_code);
s32 get_client_bd_addr(u8 *bd);

s32 hci_sprint_remote_info(u8 *buf);
s32 hci_sprint_local_info(u8 *buf);
s32 hci_sprint_local_bd(u8 *buf);

int hci_inquiry(u8 lap[], u8 inq_len, u8 num_resp, inquiry_results*);
s32 hci_add_sco_connection(u32 hci_hdl);

/* Link control commands */
s32 hci_link_key_request_reply(u8 *bd, u8* link_key);
s32 hci_link_key_request_negative_reply(u8 *bd);
s32 hci_pin_code_request_reply(u8 *bd, u8 *pin, u8 pin_len);
s32 hci_pin_code_request_negative_reply(u8 *bd);
s32 hci_authentication_requested(u16 con_hdl);
s32 hci_authentication_requested_bd(BD_ADDR bd);
s32 hci_set_connection_encryption(u16 con_hdl, u8 enable);
s32 hci_set_connection_encryption_bd(BD_ADDR bd, u8 enable);

/* Link Policy Commands */
s32 hci_hold_mode(u16 hci_hdl, u16 max_int, u16 min_int);
s32 hci_sniff_mode(u16 hci_hdl, u16 max_int, u16 min_int, u16 attempt, u16 timeout);
s32 hci_exit_sniff_mode(u16 hci_hdl);
s32 hci_park_mode(u16 hci_hdl, u16 max_int, u16 min_int);
s32 hci_exit_park_mode(u16 hci_hdl);
s32 hci_switch_role(u8 *bd, u8 role);

/* Host Controller and Baseband Commands */
s32 hci_reset(void);
void hci_flush_all(void);
s32 hci_flush(u32 hdl);
s32 hci_create_new_unit_link_key(void);
s32 hci_read_stored_link_key(u8 *bd, u8 flag);
s32 hci_write_stored_link_key(u8 *bd, u8* link_key);
s32 hci_delete_stored_link_key(u8 *bd, u8 flag);
s32 hci_read_local_name(unsigned char friendly_name1[]); //kainui add : read my friendly name
s32 hci_change_local_name(u8 *new_name);
s32 hci_read_scan_enable(void);
s32 hci_write_scan_enable(u32 enable);
s32 hci_write_pagescan_activity(u32 interval, u32 wind);
s32 hci_read_authentication_enable(void);
s32 hci_write_authentication_enable(u8 enable);
s32 hci_read_encryption_mode(void);
s32 hci_write_encryption_mode(u8 mode);
s32 hci_read_link_supervision_to(u32 hdl);
s32 hci_write_link_supervision_to(u32 hdl, u32 link_to);
s32 hci_write_class_of_device(u8 *class_of_device);
s32 hci_set_event_filter(u8 *data);
s32 hci_read_power_transmit_level(u32 con_hdl, unsigned char type);
s32 hci_write_page_to(u32 page_to);
s32 hci_write_hold_mode_activity(u32 hma);
s32 hci_write_connection_accept_to(u32 co_ac_to);
s32 hci_inquiry_cancel(void);
s32 hci_read_clock_offset(u32 hdl);
s32 hci_read_rssi(u32 hdl);

/* Informational Parameters */
s32 hci_read_local_bd(u8 *bd);
s32 hci_read_local_version_info(s32 block);
s32 hci_read_country_code(void);

/* Internal */
/* FIXME -- add parameter to choose from different devices */
s32 get_remote_bd(int line, u8 *bd);

void update_ncp(u8 nbr_of_hdl, u8 *pkt);

/* Testing commands */
s32 hci_enable_dut(void);
s32 hci_test_connect_req(u8 *bd);
s32 hci_send_raw_data(u8 *data, u8 len);

void hci_force_msswitch(u8 enable);

/* Vendor specific */
s32 hci_set_bd_addr(u8 bd[6]);
s32 hci_set_baudrate(u32 baudrate);
s32 hci_read_firmware_rev_info(void);

char *bt_hw_vendor(void);
char *bt_hw_firmware(void);



#endif
/****************** END OF FILE hci.h ***************************************/
