
#ifndef SDP_H
#define SDP_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/bluetooth/btcommon.h>
#include <linux/bluetooth/l2cap.h>
#else
#include "btcommon.h"
#include "local.h"
#include "l2cap.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#define SERPORT_PROFILE 0
#define LAN_PROFILE 1

/*--------------------------------------------------------------------------*/
/* SDP connection ID macros.                                                */
/* line = bt connection line.  Really not relevant to SDP....only relevant  */
/* to the bluetooth.c connection layer.  (provides the index into the       */
/* bt_ctrl data structure).                                                 */
/* index = The SDP connection data structure.                               */
/*--------------------------------------------------------------------------*/

#define CREATE_SDP_ID(line, index) ( ((SDP_LAYER << 16) & 0xffff0000) | ((line << 8) & 0x0000ff00) | (index & 0xff) )
#define GET_SDPINDEX(conID) ( (conID & 0xff) )

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

extern struct proc_dir_entry sdp_proc_entry;

void sdp_init(s32 server);
void sdp_shutdown(void);
#ifdef __KERNEL__
s32 sdp_create_proc_file(void);
s32 sdp_remove_proc_file(void);
#endif
s32 sdp_connect_req(u8* bd_addr, u8 line);
void sdp_connect_ind(l2cap_con *l2cap);
void sdp_connect_pnd(l2cap_con *l2cap, int status);
void sdp_connect_cfm(l2cap_con *l2cap, s32 status);
void sdp_config_ind(l2cap_con* l2cap);
void sdp_config_cfm(l2cap_con *l2cap, s32 status);
void sdp_disconnect_req(u32 sdp_hdl);
void sdp_disconnect_ind(l2cap_con *l2cap);
void sdp_disconnect_cfm(l2cap_con *l2cap);
void sdp_receive_data(l2cap_con *l2cap, u8* data, u32 len);
s32 sdp_send_data(sdp_con *sdp, u8 *data, u32 len);

#ifdef __KERNEL__
s32 sdpStartRequest(u8 sdpIndex, u8 sdpCommand, u8 *pduData, u16 pduLength);
#endif

#endif
void sdp_buf_send_data(unsigned int sdp_id,unsigned char *data);
void sdp_read_service_data(void); //kainui add

/****************** END OF FILE sdp.h ***************************************/
