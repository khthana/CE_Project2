
#ifndef L2CAP_INTERNAL_H
#define L2CAP_INTERNAL_H

/****************** INCLUDE FILES SECTION ***********************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

/* FIXME --  make this a function with default case */
static const u8* state_name[] = {
	"CLOSED",
	"W4_L2CAP_CONNECT_RSP",
	"W4_L2CA_CONNECT_RSP",
	"CONFIG",
	"OPEN", 
	"W4_L2CAP_DISCONNECT_RSP",
	"W4_L2CA_DISCONNECT_RSP",
	"ANY_STATE"
};

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

u16 get_cid(void);
const u8* psm2str(u16 psm);

/*********************************************************************/
/*---------------------- INIT AND SHUTDOWN --------------------------*/
/*********************************************************************/

/*******************************************************************/
/*-------------------------- ACTIONS ------------------------------*/
/*******************************************************************/

#endif
/****************** END OF FILE l2cap_internal.h *****************************/
