
#ifndef LOCAL_H
#define LOCAL_H

/****************** INCLUDE FILES SECTION ***********************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

#include <asm/byteorder.h>
/* In kernel mode either __LITTLE_ENDIAN or __BIG_ENDIAN is defined, but in user usermode
 * both are defined. In usermode __BYTE_ORDER contains the correct endianess. So let's undefine
 * one of them.
 * __LITTLE_ENDIAN_BITTFIELD and __BIG_ENDIAN_BITFIELD do not cause such problems.
 */
#ifndef __KERNEL__
# if (__BYTE_ORDER == __LITTLE_ENDIAN)
#  undef __BIG_ENDIAN
# endif
# if (__BYTE_ORDER == __BIG_ENDIAN)
#  undef __LITTLE_ENDIAN
# endif
#endif
 
#ifndef __KERNEL__
 
#  ifdef __LITTLE_ENDIAN
#    define cpu_to_le16(x) (x)
#    define cpu_to_le32(x) (x)
#    define cpu_to_be16(x) htons((x))
#    define cpu_to_be32(x) htonl((x))
#  else
#    define cpu_to_be16(x) (x)
#    define cpu_to_be32(x) (x)
     extern inline __u16 cpu_to_le16(__u16 x) { return (x<<8) | (x>>8);}
     extern inline __u32 cpu_to_le32(__u32 x) { return((x>>24) |
             ((x>>8)&0xff00) | ((x<<8)&0xff0000) | (x<<24));}
#  endif
 
#  define le16_to_cpu(x)  cpu_to_le16(x)
#  define le32_to_cpu(x)  cpu_to_le32(x)
#  define be16_to_cpu(x)  cpu_to_be16(x)
#  define be32_to_cpu(x)  cpu_to_be32(x)
 
#endif

/****************** TYPE DEFINITION SECTION *********************************/

typedef short           s16; 
typedef int             s32;  
typedef unsigned short  u16; 
typedef unsigned int    u32;
typedef unsigned char   u8; 

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

#endif
/****************** END OF FILE local.h *************************************/
