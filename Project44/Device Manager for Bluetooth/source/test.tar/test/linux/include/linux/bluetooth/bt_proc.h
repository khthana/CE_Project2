#ifndef __LINUX_BT_PROC_H__
#define __LINUX_BT_PROC_H__

#ifdef __KERNEL__
#include <linux/proc_fs.h>
extern struct proc_dir_entry bt_proc_doit;
extern struct proc_dir_entry sdp_proc_entry;
extern struct proc_dir_entry bt_status;
extern struct proc_dir_entry bt_internal_info;
#else
extern int bt_read_internal(u8 *buf);
#endif

#endif /*__LINUX_BT_PROC_H__*/
