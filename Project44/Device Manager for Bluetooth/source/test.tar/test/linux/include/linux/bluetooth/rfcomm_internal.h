
#ifndef RFCOMM_INTERNAL_H
#define RFCOMM_INTERNAL_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/bluetooth/btcommon.h>
#else
#include "local.h"
#include "btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

/****************** TYPE DEFINITION SECTION *********************************/

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

s32 send_ua(rfcomm_con *rfcomm, u8 dlci);
s32 send_dm(rfcomm_con *rfcomm, s32 dlci);

#endif
/****************** END OF FILE rfcomm_internal.h ***************************/
