
#ifndef BCSP_H
#define BCSP_H

/****************** INCLUDE FILES SECTION ***********************************/

#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/bluetooth/btcommon.h>
#else
#include "local.h"
#include "include/btcommon.h"
#endif

/****************** CONSTANT AND MACRO SECTION ******************************/

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#define BCSP_BCCMD_CHN 2
#define BCSP_HQ_CHN    3
#define BCSP_CMD_CHN   5
#define BCSP_EVT_CHN   5
#define BCSP_ACL_CHN   6
#define BCSP_SCO_CHN   7
#define BCSP_DFU_CHN   12

#define SYNC     0xEDEDDCDA
#define SYNC_RSP 0xEEEFAFAC
#define CONF     0xEDACEFAD
#define CONF_RSP 0xD0D0ADDE

#define BCSP_CRC_NOT_PRESENT 0
#define BCSP_CRC_PRESENT     1

#define BCSP_UNRELIABLE      0
#define BCSP_RELIABLE        1

#define BCSP_HDR_SIZE 4
#define BCSP_CRC_SIZE 2

#define ERR_CHECKSUM 1
#define ERR_PAYLOAD_LENGTH 2

#define BCSP_GET_SEQ(bcsp)              GET_BITS((bcsp)->flags, 0, 3)
#define BCSP_SET_SEQ(bcsp, x)           SET_BITS((bcsp)->flags, 0, 3, x)
#define BCSP_GET_ACK(bcsp)              GET_BITS((bcsp)->flags, 3, 3)
#define BCSP_SET_ACK(bcsp, x)           SET_BITS((bcsp)->flags, 3, 3, x)
#define BCSP_GET_CRC_PRESENT(bcsp)      (GET_BITS((bcsp)->flags, 6, 1) ? BCSP_CRC_PRESENT : BCSP_CRC_NOT_PRESENT)
#define BCSP_SET_CRC_PRESENT(bcsp, x)   SET_BITS((bcsp)->flags, 6, 1, x)
#define BCSP_GET_PROTOCOL_TYPE(bcsp)    (GET_BITS((bcsp)->flags, 7, 1) ? BCSP_RELIABLE : BCSP_UNRELIABLE)
#define BCSP_SET_PROTOCOL_TYPE(bcsp, x) SET_BITS((bcsp)->flags, 7, 1, x)

#define BCSP_GET_FLAGS(bcsp)          ((bcsp)->packet[0])
#define BCSP_GET_IDENTIFIER(bcsp)     ((bcsp)->packet[1] & 0x0F) 
#define BCSP_GET_PAYLOAD_LENGTH(bcsp) (((bcsp)->packet[2] << 4) | (((bcsp)->packet[1] >> 4) & 0xFF))
#define BCSP_GET_CHECKSUM(bcsp)       ((bcsp)->packet[3])

/****************** TYPE DEFINITION SECTION *********************************/

struct bcsp
{
	u8 flags;
	u8 identifier;
	u16 payload_length;
	u8 checksum;
	u8* payload;
	u16 crc;
	u8* packet;
	u16 packet_length;
};

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

/************************* functions in bcsp.c ******************************/

s32 bcsp_init(void);
void bcsp_shutdown(void);
u32 bcsp_issyncronized(void);
void bcsp_syncronized(void);
s32 bcsp_write_top(u8 *data, u32 len);
s32 bcsp_write_lower(u8 *data, u32 len);
s32 bcsp_receive_top(u8 *data, u32 len, u8 chn);
s32 bcsp_receive_lower(u8 *data, u32 len);
void bcsp_init_packet(struct bcsp *bcsp);

/************************* functions in slip.c ******************************/

s32 bcsp_slip_send(struct bcsp* bcsp);
s32 bcsp_slip_receive(const u8* packet, u32 len);

/************************* functions in integrity.c **************************/

s32 bcsp_integrity_send(struct bcsp *bcsp);
s32 bcsp_integrity_receive(struct bcsp *bcsp);

/************************* functions in mux.c *******************************/

s32 bcsp_mux_send(struct bcsp *bcsp);
s32 bcsp_mux_receive(struct bcsp *bcsp);
s32 bcsp_mux_send(struct bcsp *bcsp);
s32 bcsp_send_txack(u8 txack);

/************************* functions in sequence.c **************************/

void bcsp_sequence_init(void);
void bcsp_sequence_shutdown(void);
s32 bcsp_sequence_receive(struct bcsp *bcsp);
s32 bcsp_sequence_send(u8 *data, u32 len, u8 chn);
void bcsp_signal_rxack(u8 ack);

/************************* functions in datagram.c ***************************/

void bcsp_datagram_init(void);
void bcsp_datagram_shutdown(void);
s32 bcsp_datagram_receive(struct bcsp *bcsp);
s32 bcsp_datagram_send(u8 *data, u32 len, u8 chn);
s32 bcsp_send_sync(u32 type);

#endif
/****************** END OF FILE bcsp.h **************************************/
