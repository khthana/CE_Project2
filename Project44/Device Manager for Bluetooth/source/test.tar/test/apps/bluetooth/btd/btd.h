
#ifndef BTD_H
#define BTD_H

/****************** INCLUDE FILES SECTION ***********************************/

//#include "nui.h"

/****************** CONSTANT AND MACRO SECTION ******************************/

/* Ioctls for the BT driver */

#define BT_IOC_MAGIC 'B' /* Use B as a magic number */
#define BT_IOC_MAXNR 255

#define BTCONNECT _IOW(BT_IOC_MAGIC, 0x00, bt_connection)
#define BTDISCONNECT _IOW(BT_IOC_MAGIC, 0x01, unsigned int)

#define BTSETSPEED _IOW(BT_IOC_MAGIC, 0x02, int)
#define BTINITSTACK _IO(BT_IOC_MAGIC, 0x03)
#define BTSETSERTTY _IO(BT_IOC_MAGIC, 0x04)
#define BTSETMODEMDUMMY _IOW(BT_IOC_MAGIC, 0x05, int)
#define BTSHUTDOWN _IO(BT_IOC_MAGIC, 0x06)
#define BTREADREMOTEBDADDR _IOWR(BT_IOC_MAGIC, 0x07, unsigned char[6])
#define BTRESETPHYSICALHW _IO(BT_IOC_MAGIC, 0x08)
#define BTISINITIATED _IOR(BT_IOC_MAGIC, 0x09, int)
#define BTHWVENDOR _IOR(BT_IOC_MAGIC, 0x0A, char[20])
#define BTFIRMWAREINFO _IOR(BT_IOC_MAGIC, 0x0B, char[80])

#define BTWAITFORCONNECTION _IOW(BT_IOC_MAGIC, 0x0C, int)
#define BTWAITNEWCONNECTIONS _IO(BT_IOC_MAGIC, 0x0D)
#define BTISLOWERCONNECTED _IOW(BT_IOC_MAGIC, 0x0E, int)

//#define BT_SDP_REQUEST _IOW(BT_IOC_MAGIC, 0x0F, bt_sdp_request)
#define BT_GETCACHEDLINKKEY _IOWR(BT_IOC_MAGIC, 0x10, unsigned char[22])

/* ioctls executing HCI commands */

/* Link Control Command */
#define HCIINQUIRY _IOWR(BT_IOC_MAGIC, 0x20, inquiry_results)
#define HCILINKKEYREPLY _IOWR(BT_IOC_MAGIC, 0x21, unsigned char[22])
#define HCILINKKEYNEGATIVEREPLY _IOWR(BT_IOC_MAGIC, 0x22, unsigned char[6])
#define HCIPINCODEREPLY _IOWR(BT_IOC_MAGIC, 0x23, unsigned char[23])
#define HCIPINCODENEGATIVEREPLY _IOWR(BT_IOC_MAGIC, 0x24, unsigned char[6])
#define HCIAUTHENTICATION_REQUESTED _IOW(BT_IOC_MAGIC, 0x25, unsigned char[6])
#define HCISETCONNECTION_ENCRYPTION _IOW(BT_IOC_MAGIC, 0x26, unsigned char[7])

/* Link Policy Commands */
#define HCISWITCHROLE _IOW(BT_IOC_MAGIC, 0x28, unsigned char[7])

/* Host Controler & Basband Commands */
#define HCIRESET _IO(BT_IOC_MAGIC, 0x30)
#define HCIFLUSH _IO(BT_IOC_MAGIC, 0x31)
#define HCICREATE_NEW_UNIT_KEY _IO(BT_IOC_MAGIC, 0x32)
#define HCIREADSTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x33, unsigned char[7])
#define HCIWRITESTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x34, unsigned char[22])
#define HCIDELETESTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x35, unsigned char[7])
#define HCISETLOCALNAME _IOW(BT_IOC_MAGIC, 0x36, unsigned char[248])
#define HCIREADSCANENABLE _IOR(BT_IOC_MAGIC, 0x37, int)
#define HCIWRITESCANENABLE _IOW(BT_IOC_MAGIC, 0x38, int)
#define HCIWRITEPAGESCANACTIVITY _IOW(BT_IOC_MAGIC, 0x39, unsigned int[2])
#define HCIWRITECLASSOFDEVICE _IOW(BT_IOC_MAGIC, 0x3a, unsigned char[3])
#define HCIREAD_AUTHENTICATION_ENABLE _IOR(BT_IOC_MAGIC, 0x3b, int)
#define HCIWRITE_AUTHENTICATION_ENABLE _IOWR(BT_IOC_MAGIC, 0x3c, int)
#define HCIREAD_ENCRYPTION_MODE _IOR(BT_IOC_MAGIC, 0x3d, int)
#define HCIWRITE_ENCRYPTION_MODE _IOWR(BT_IOC_MAGIC, 0x3e, int)
#define HCISET_EVENT_FILTER _IOW(BT_IOC_MAGIC, 0x3f, unsigned char[3])

/* Informational Parameters */
#define HCIREADLOCALBDADDR _IOR(BT_IOC_MAGIC, 0x45, unsigned char[6])

/* Status Parameters */

/* Testing Commands */
#define HCIENABLEDUT _IO(BT_IOC_MAGIC, 0x65)


/* ioctls vendor specific HCI commands */
#define HCISETBAUDRATE _IOW(BT_IOC_MAGIC, 0x70, int)
#define HCIWRITEBDADDR _IOW(BT_IOC_MAGIC, 0x71, unsigned char[6])
#define HCISENDRAWDATA _IOW(BT_IOC_MAGIC, 0x72, unsigned char[261])

/* other ioctls used for testing */
#define BTSENDTESTDATA _IOW(BT_IOC_MAGIC, 0xf0, int[2])
#define HCITESTCONNECTREQ _IOW(BT_IOC_MAGIC, 0xf1, unsigned char[6])

/* NOTE !
   N_BT should be defined in /include/asm/termios.h 
   However, if you are compiling this source standalone
   the following define can be useful. If this number is taken 
   simply change it to something not taken.*/
#ifndef N_BT
#define N_BT 15
#endif

#define INQUIRY_SCAN_ENABLE 1
#define PAGE_SCAN_ENABLE    2
#define SDP_LAYER    1
#define RFCOMM_LAYER 3
#define TCS_LAYER    5

#define CREATE_RFCOMM_ID(line, dlci) ( ((RFCOMM_LAYER << 16)&0xffff0000) | ((line<<8)&0xff00) | ((dlci) & 0xff) )
#define GET_PSM(con_id) (con_id >> 16)

/****************** TYPE DEFINITION SECTION *********************************/

typedef struct bt_connection
{
  unsigned char bd[6];
  unsigned int id; /* | psm(16 bits)�| layer_specific (16 bits)�|�*/
} bt_connection;

typedef struct inquiry_results
{
  unsigned int nbr_of_units;
  unsigned int inq_time;
  unsigned char bd_addr[0];
} inquiry_results;

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

#endif
/****************** END OF FILE btd.h ***************************************/
