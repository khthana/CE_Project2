#define BTD_USERSTACK
#ifdef BTD_USERSTACK

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
extern Fl_Window *foo_window;
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Select_Browser.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Return_Button.H>
#include <FL/Fl_Round_Button.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Multiline_Input.H>
#include <FL/Fl_Multiline_Output.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Int_Input.H>
#include <FL/Fl_Secret_Input.H>
#include <FL/Fl_Output.H>
#include <FL/fl_ask.H>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
//#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
//#include <stdlib.h>
//#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>


#include "bt.h"
#include "btd.h"



/****************************function in C file****************************/
extern "C" int init_program(int argc, char **argv);
extern "C" void write_device_data(void);
extern "C" void change_friendly_name(unsigned char *st);
extern "C" void get_my_friendly_name(unsigned char friendly_name[]);
extern "C" void get_remote_name(char friendly_name[]);
extern "C" int get_bt_cfd(void);
extern "C" void change_str_to_addr(unsigned char *st,unsigned char tmp_bd[]);
extern "C" void change_addr_to_str(unsigned char st[],unsigned char *tmp_bd);
extern "C" void set_new_address(int bt_cfd,int *tmp_bd);
extern "C" void read_my_address(int bt_cfd,unsigned char *tmp_bd);
extern "C" void set_scan_mode(int inq,int page);
extern "C" int read_scan_mode(void);
extern "C" void check_connect(void);
extern "C" void find_all_device(int nbr_rsp,int t,int page);
extern "C" void check_online_offline(char online[],char offline[],int *num_online,int *num_offline);
extern "C" void show_tmp_device(char tmp_device[],int *num);
extern "C" void disc_req(void);
extern "C" int search_specific(char key[],int type,char tmp_list[]);
extern "C" void show_tmp_service(int device_id,char tmp_list[],int *num);
extern "C" int search_service(char line[]);
extern "C" void add_new_device_page1(char name[]);
extern "C" int show_service(char name[],char tmp_list[]);
extern "C" void con_rfcomm(char name[]);
extern "C" void bt_sdp_send_data(char name[],char st[]);
extern "C" int send_data(char *st,int repeat,int line);
extern "C" void disc_sdp(void);
/**************************************************************************/

void show_all_device(void);
void get_device(void);
void search(void);
void search_page1(void);
void show_service_page2(void);
extern "C" void test_call(void);
extern "C" void chat_receive(char msg[]);
extern "C" int req_window(void);
extern "C" void chat_window(void);
extern "C" void req_window_1(void);
extern "C" void req_window_2(void);



Fl_Window *foo_window=(Fl_Window *)0;
Fl_Group *Group12,*Group23,*Group32,*Group1,*Group2,*Group3;
Fl_Button *Button2,*Button3,*Add11,*Call23,*Stop31,*Search31,*Add32,*one,*two,*three;
Fl_Round_Button* Device31,*Service31;
Fl_Browser* Browser23,* Browser21, *Browser22,*Browser11,*Browser12,*Browser32;
Fl_Multiline_Output*History;
Fl_Window *w;
Fl_Tabs *Tab;
Fl_Output *text;
char buffer[80]="";
char Address[17];
char Message[100];
int Inquiry;
int Page;
Fl_Input *tmp_friendly_name,*key;
void input_cb(Fl_Widget *,void*);


void test_call(void)
{
        printf("pon : test_call\n");
}

void chat_receive(char msg[])
{
     int i;

     printf("pon : msg = %s\n",msg);
     for (i=0;i<100;i++)
        Message[i] = '\0';
     strcat(Message,msg);
     History->value(Message);
}

/*void req_window(void)
{
  Fl_Window window(450,100);
  window.label("Request");
  Fl_Box *box = new Fl_Box(0,20,450,20,"Do you want to give Ann_PC the permission for using File Transfer?");
  box->type(FL_UP_BOX);
  Fl_Return_Button *o1=new Fl_Return_Button(130,50, 80, 30, "Yes");
  o1->callback((Fl_Callback*)cb_process);
  Fl_Return_Button *o2=new Fl_Return_Button(230,50, 90, 30, "No");
  o2->callback((Fl_Callback*)cb_close);
  window.end();
  window.set_modal();
  window.show();
  for (;;)
  { Fl::wait();
    Fl_Widget *o1;
    while ((o1 = Fl::readqueue()))
    {}
  }
} */

void cb_cancel(Fl_Button*, void*)
{

        disc_req();
        write_device_data();
        exit(1);
}

void cb_OK(Fl_Return_Button*, void*)
{ exit(0);
}

void cb_process(Fl_Window*,void* )
{ Fl_Window* window;
  Fl_Widget* w = window;
  w->do_callback();
  Group2->show();
  Button2->activate();
  Button3->activate();
}

void cb_close(Fl_Window*,void* )
{ Fl_Window* window;
  Fl_Widget* w = window;
  window->hide();
  printf("123\n");
  Group2->show();
  Button2->activate();
  Button3->activate();
}

void cb_Browser11(Fl_Widget* o, void*)
{

  search_page1();
  Add11->activate();
  Group12->show();
}

void cb_Browser21(Fl_Widget* o,void*)
{
  Browser23->clear();
  show_service_page2();
  Group23->activate();
}

void cb_Browser23(Fl_Widget* o,void*)
{ Call23->activate();
}

void cb_Chat(Fl_Widget* o3)
{

  char tmp[20],tmp1[20],tmp3[200];
  unsigned char f_name[20];
  int i;

  printf("pon : cb_chat\n");
  Fl_Window window(320,480);
  window.label("Chat");
  Fl_Output*Name=new Fl_Output(50,10,180,20,"Name:");
  for (i=0;i<20;i++)
  {
        tmp[i] = '\0';
        f_name[i] = '\0';
        tmp1[i] = '\0';
  }
  printf("pon : cb_chat1\n");

  get_remote_name(tmp);
  tmp[strlen(tmp)] = '\0';
  printf("pon : tmp = %s\n",tmp);
  printf("pon : len tmp = %d\n",strlen(tmp));
  //strcpy(tmp,Browser21->text(Browser21->value()));
  Name->value(tmp);   /*other name*/

  get_my_friendly_name(f_name);
  strcpy(tmp1,(char *)f_name);
  printf("pon : cb_chat2\n");
  //Fl_Multiline_Output*History=new Fl_Multiline_Output(10,40,300,300);
  History=new Fl_Multiline_Output(10,40,300,300);
  Fl_Multiline_Input*input=new Fl_Multiline_Input(10,345,300,80);
  input->value("Type your message here");
  Fl_Button send(110,435,90,30,"Send");
  Fl_Return_Button o2(220,435, 90, 30, "Exit");
 // o2.callback((Fl_Callback*)cb_close);
  for (int i=0;i<100;i++){Message[i]='\0';}
  window.end();
  window.set_modal();
  window.show();
  printf("pon : cb_chat3\n");
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    { if (o==&send)  /*send*/
      {
        //strcpy(tmp,Browser21->text(Browser21->value()));
        for (i=0;i<200;i++)
                tmp3[i] = '\0';
        strcat(Message,tmp1);          /*my name*/
        strcat(Message," :  ");
        strcat(Message,input->value());
        strcat(Message,"\n\n");
        input->value("\0");
        //printf("pon : input = %s\n",input->value());
        History->value(Message);
        strcat(tmp3,"001chat");
        strcat(tmp3,Message);
        printf("pon : send tmp = %s\n",tmp);
        printf("pon : len tmp = %d\n",strlen(tmp));
        printf("pon : send tmp3 = %s\n",tmp3);
        //bt_sdp_send_data(tmp,tmp3);
        send_data(tmp3,1,0);
        //bt_sdp_send_data("aaa","test2");
        //req_window();

      }
      else if (o == &o2)
      { History->value("\0");
        window.hide();
      }
    }
  }
}

void chat_window(void)
{

        //bt_sdp_send_data("bbb","test1");
        //cb_Chat(w);

        char tmp[20],tmp1[20],tmp3[200];
  unsigned char f_name[20];
  int i;

  printf("pon : chat window\n");
  Fl_Window window(320,480);
  window.label("Chat");
  Fl_Output*Name=new Fl_Output(50,10,180,20,"Name:");
  for (i=0;i<20;i++)
  {
        tmp[i] = '\0';
        f_name[i] = '\0';
        tmp1[i] = '\0';
  }
  printf("pon : cb_chat1\n");

  get_remote_name(tmp);
  tmp[strlen(tmp)] = '\0';
  printf("pon : tmp = %s\n",tmp);
  printf("pon : len tmp = %d\n",strlen(tmp));
  //strcpy(tmp,Browser21->text(Browser21->value()));
  Name->value(tmp);   /*other name*/

  get_my_friendly_name(f_name);
  strcpy(tmp1,(char *)f_name);
  printf("pon : cb_chat2\n");
  //Fl_Multiline_Output*History=new Fl_Multiline_Output(10,40,300,300);
  History=new Fl_Multiline_Output(10,40,300,300);
  Fl_Multiline_Input*input=new Fl_Multiline_Input(10,345,300,80);
  input->value("Type your message here");
  Fl_Button send(110,435,90,30,"Send");
  Fl_Return_Button o2(220,435, 90, 30, "Exit");
 // o2.callback((Fl_Callback*)cb_close);
  for (int i=0;i<100;i++){Message[i]='\0';}
  window.end();
  window.set_modal();
  window.show();
  printf("pon : cb_chat3\n");
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    { if (o==&send)  /*send*/
      {
        //strcpy(tmp,Browser21->text(Browser21->value()));
        for (i=0;i<200;i++)
                tmp3[i] = '\0';
        strcat(Message,tmp1);          /*my name*/
        strcat(Message," :  ");
        strcat(Message,input->value());
        strcat(Message,"\n\n");
        input->value("\0");
        //printf("pon : input = %s\n",input->value());
        History->value(Message);
        strcat(tmp3,"001chat");
        strcat(tmp3,Message);
        printf("pon : send tmp = %s\n",tmp);
        printf("pon : len tmp = %d\n",strlen(tmp));
        printf("pon : send tmp3 = %s\n",tmp3);
        //bt_sdp_send_data(tmp,tmp3);
        send_data(tmp3,1,0);
        //bt_sdp_send_data("aaa","test2");
        //req_window();

      }
      else if (o == &o2)
      { History->value("\0");
        window.hide();
      }
    }
  }
}


void cb_FTP(Fl_Widget* o3)
{ Fl_Window window(270,240);
  window.label("File Transfer");
  Fl_Input*Host=new Fl_Input(110,10,140,20,"Host Address:");
  Fl_Input*User=new Fl_Input(110,40,140,20,"Username:");
  Fl_Secret_Input*Pwd=new Fl_Secret_Input(110,70,140,20,"Password:");
  Pwd->maximum_size(8);
  Fl_Input*Path=new Fl_Input(110,100,140,20,"Path:");
  Fl_Round_Button* Upload=new Fl_Round_Button(110,140,10,10,"Upload");
  Upload->type(102);
  Upload->value(1);
  Upload->down_box(FL_ROUND_DOWN_BOX);
  Fl_Round_Button* Download=new Fl_Round_Button(110,170,10,10,"Download");
  Download->type(102);
  Download->down_box(FL_ROUND_DOWN_BOX);
  Fl_Return_Button *o1=new Fl_Return_Button(50,200, 80, 30, "OK");
  o1->callback((Fl_Callback*)cb_process);
  Fl_Return_Button *o2=new Fl_Return_Button(160,200, 90, 30, "cancel");
  o2->callback((Fl_Callback*)cb_close);
  window.end();
  window.set_modal();
  window.show();
  for (;;)
  { Fl::wait();
    Fl_Widget *o1;
    while ((o1 = Fl::readqueue()))
    {}
  }
}

void cb_request(Fl_Widget* o3)
{  Fl_Window window(450,100);
  window.label("Request");
  Fl_Box *box = new Fl_Box(0,20,450,20,"Do you want to give Ann_PC the permission for using File Transfer?");
  box->type(FL_UP_BOX);
  Fl_Return_Button yes(130,50, 80, 30, "Yes");
 // o1->callback((Fl_Callback*)cb_process);
  Fl_Return_Button no(230,50, 90, 30, "No");
 // o2->callback((Fl_Callback*)cb_close);
  window.end();
  window.set_modal();
  window.show();
  printf("pon : cb_req1\n");
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    {
        printf("pon : cb_req in loop\n");
        if (o==&yes)
        {
        //chat_window();
        //printf("pon : after chat_window\n");

        printf("pon : yes\n");
        window.do_callback();
        //window.hide();

        //cb_Chat(Browser23);
      }
      else if (o==&no)
      {
        window.hide();
        printf("pon : no\n");
      }
    }
  }
}

int req_window(void)
{
  printf("pon : req_window\n");
  //cb_request(w);
  Fl_Window window(450,100);
  window.label("Request");
  Fl_Box *box = new Fl_Box(0,20,450,20,"Do you want to give Ann_PC the permission for using File Transfer?");
  box->type(FL_UP_BOX);
  Fl_Return_Button ok(130,50, 80, 30, "Yes");
  //o1->callback((Fl_Callback*)cb_process);
  Fl_Return_Button cancel(230,50, 90, 30, "No");
  //o2->callback((Fl_Callback*)cb_close);
  window.end();
  window.set_modal();
  window.show();
 for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    { if (o==&ok)
      {
        //chat_window();
        //printf("pon : after chat_window\n");

        //window.hide();
        printf("pon : yes\n");
        //window.hide();
        //chat_window();
        //cb_Chat(Browser23);
        window.do_callback();
        //chat_window();
        return 1;
        //chat_window();
        //cb_Chat(Browser23);
      }
      else if (o==&cancel)
      {
        printf("pon : no\n");
        window.hide();

        return 0;
      }
    }
  }
}

void req_window_1(void)
{
        int i = 0;
        char tmp[20];

        printf("pon : req_window_1\n");
        i = req_window();
        printf("pon : after req_window i = %d\n",i);
        if (i==1)
        {
                for(i=0;i<20;i++)
                        tmp[i] = '\0';
                printf("pon : chat\n");
                get_remote_name(tmp);
                //bt_sdp_send_data(tmp,"test");
                //printf("pon : after\n");
                //disc_sdp();
                chat_window();
        }
        else printf("pon : don't chat\n");
        return;
}

void req_window_2(void)
{
        chat_window();
}

void switch1(Fl_Widget*o,void*)
{
  Group2->hide();
  Group3->hide();
  //Group1->show();
  Browser11->clear();
  Browser12->clear();
  get_device();
  Group1->show();
}

void switch2(Fl_Widget*o,void*)
{ Group1->hide();
  Group3->hide();
  //Group2->show();
  Browser21->clear();
  Browser22->clear();
  Browser23->clear();
  show_all_device();
  printf("111\n");
  Group2->show();
}

void switch3(Fl_Widget*o,void*)
{ Group1->hide();
  Group2->hide();
  Browser32->clear();
  Group3->show();
}

void cb_decline(Fl_Widget* o3)
{ Fl_Window window(300,100);
  window.label("Response");
  Fl_Box *box = new Fl_Box(0,20,300,20,"Server doesn't give you the permission.");
  box->type(FL_UP_BOX);
  Fl_Return_Button ok(110,50, 80, 30, "OK");
//  o1->callback((Fl_Callback*)cb_process);
  window.end();
  window.set_modal();
  window.show();
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    {
       if (o==&ok)
       {
         window.hide();
       }
    }
  }
}

void show_all_device(void)
{
        char online[100];
        char offline[100];
        int *num_online;
        int *num_offline;
        int x = 0;
        int y = 0;
        int i,ii,j;
        char tmp[20];

        check_connect();
        printf("pon2\n");
        find_all_device(1,4,2);
        printf("pon : after find_all_device\n");
        num_online = &x;
        num_offline = &y;
        printf("pon : after set num_online\n");
        printf("pon : num_online = %d\n",*num_online);
        //printf("pon : offline_name = %s\n",offline[0]);
        for (i=0;i<100;i++)
        {
                online[i] = '\0';
                offline[i] = '\0';
        }
        check_online_offline(online,offline,num_online,num_offline);
        printf("pon : num_online(after) = %d\n",*num_online);
        printf("pon : num_offline = %d\n",*num_offline);
        i = 0;
        ii = 0;
        while (i<(*num_online))
        {
                printf("pon : online_name = %s\n",online);
                for (j=0; j<20;j++)
                        tmp[j] = '\0';
                j = 0;
                while (online[ii]!=',')
                {
                        tmp[j] = online[ii];
                        ii++;
                        j++;
                }
                ii++;
                //strncpy(tmp,offline,3);
                Browser21->insert(i+1,tmp);
                Browser21->text(i+1,tmp);
                i++;
        }
        i = 0;
        ii = 0;
        while (i<(*num_offline))
        {
                printf("pon : offline_name = %s\n",offline);
                for (j=0; j<20;j++)
                        tmp[j] = '\0';
                j = 0;
                while (offline[ii]!=',')
                {
                        tmp[j] = offline[ii];
                        ii++;
                        j++;
                }
                ii++;
                //strncpy(tmp,offline,3);
                Browser22->insert(i+1,tmp);
                Browser22->text(i+1,tmp);
                i++;
        }
        //Browser21->insert(1,"pon");
        //Browser21->text(1,"pon");
}

void get_device(void)
{
  char tmp_device[100];
  char tmp[20];
  int *num;
  int i,j,ii;
  int x = 0;

  find_all_device(1,8,1);
  for (i=0; i<100; i++)
        tmp_device[i] = '\0';
  num = &x;
  show_tmp_device(tmp_device,num);
  i = 0;
  ii = 0;
  while (i<*num)
  {
         printf("pon : tmp_device = %s\n",tmp_device);
         for (j=0; j<20;j++)
                tmp[j] = '\0';
         j = 0;
         while (tmp_device[ii]!=',')
         {
                tmp[j] = tmp_device[ii];
                ii++;
                j++;
         }
         ii++;
         Browser11->text(i+1,tmp);
         Browser11->insert(i+1,tmp);
         i++;
  }

}

void search(void)
{
  char tmp[10],tmp1[30],tmp2[30],tmp3[100];
  int result = 0;
  char tmp_list[200];
  int i,*num,ii,j;
  int x = 0;

    Stop31->activate();
  Search31->deactivate();
  strcpy(tmp,key->value());
  //printf("kainui(pon) : key = %s\n",tmp);
  if (Device31->value()==1)  /*search device*/
  {
        printf("search device\n");
        result = 0;
        for (i=0; i<200; i++)
                tmp_list[i] = '\0';
        result = search_specific(tmp,Device31->value(),tmp_list);
        if (result==0)
        {
                printf("pon : no match\n");
        }
        else
        {
                printf("pon : match\n");
                for (i=0; i<200; i++)
                        tmp_list[i] = '\0';
                num = &x;
                show_tmp_service(result-1,tmp_list,num);
                //printf("pon : num = %d tmp_list = %s\n",*num,tmp_list);
                i = 0;
                ii = 0;
                while (i<*num)
                {
                        //printf("pon : tmp_list = %s\n",tmp_list);
                        for (j=0; j<30;j++)
                        {       tmp1[j] = '\0';
                                tmp2[j] = '\0';
                        }
                        j = 0;
                        while (tmp_list[ii]!=',')
                        {
                                tmp1[j] = tmp_list[ii];
                                ii++;
                                j++;
                        }
                        //printf("pon : tmp1 = %s\n",tmp1);
                        ii++;
                        j = 0;
                        while (tmp_list[ii]!=',')
                        {
                                tmp2[j] = tmp_list[ii];
                                ii++;
                                j++;
                        }
                        //printf("pon : tmp2 = %s\n",tmp2);
                        ii++;
                        for (j=0;j<100;j++)
                                tmp3[j] = '\0';
                        strcat(tmp3,tmp1);
                        for (j=0;j<(30-strlen(tmp1));j++)
                                strcat(tmp3," ");
                        strcat(tmp3,tmp2);
                        Browser32->text(i+1,tmp3);
                        Browser32->insert(i+1,tmp3);
                        i++;
                }
        }

  }
  else /*search service*/
  {
        printf("search service\n");
        for (i=0; i<200; i++)
                tmp_list[i] = '\0';
        result = search_specific(tmp,Device31->value(),tmp_list);
        if (result==0)
        {
                printf("pon : no match\n");
        }
        else
        {
                i = 0;
                ii = 0;
                j =0;
                while (i<result)
                {
                        for (j=0; j<30;j++)
                        {       tmp1[j] = '\0';
                                tmp2[j] = '\0';
                        }
                        j = 0;
                        while (tmp_list[ii]!=',')
                        {
                                tmp1[j] = tmp_list[ii];
                                ii++;
                                j++;
                        }
                        //printf("pon : tmp1 = %s\n",tmp1);
                        ii++;
                        j = 0;
                        while (tmp_list[ii]!=',')
                        {
                                tmp2[j] = tmp_list[ii];
                                ii++;
                                j++;
                        }
                        //printf("pon : tmp2 = %s\n",tmp2);
                        ii++;
                        for (j=0;j<100;j++)
                                tmp3[j] = '\0';
                        strcat(tmp3,tmp1);
                        for (j=0;j<(30-strlen(tmp1));j++)
                                strcat(tmp3," ");
                        strcat(tmp3,tmp2);
                        Browser32->text(i+1,tmp3);
                        Browser32->insert(i+1,tmp3);
                        i++;

                }
        }
  }

}

void search_page1(void)
{
  char tmp[20];
  int j,i,ii,index,*num;
  char tmp_list[200];
  int x = 0;


  if (Browser11->text(Browser11->value())!=NULL)
  {
  strcpy(tmp,Browser11->text(Browser11->value()));
  index = 0;
  index = search_service(tmp);
  for (i=0; i<100; i++)
        tmp_list[i] = '\0';
  num = &x;
  show_tmp_service(index,tmp_list,num);
  i = 0;
  ii = 0;
  while (i<*num)
  {
        for (j=0; j<20; j++)
                tmp[j] = '\0';
        while (tmp_list[ii]!=',')
        {
                ii++;
        }
        ii++;
        j = 0;
        while (tmp_list[ii]!=',')
        {
                tmp[j] = tmp_list[ii];
                ii++;
                j++;
        }
        ii++;
        Browser12->text(i+1,tmp);
        Browser12->insert(i+1,tmp);
        i++;
  }
  //printf("pon : cb_Browser11\n");

  //printf("pon : name = %s\n",tmp);
  }
}

void show_service_page2(void)
{
  int result = 0;
  int i,ii,j;
  char tmp_list[200],tmp[30];

  for (i=0; i<200; i++)
        tmp_list[i] = '\0';
  for (i=0; i<30; i++)
        tmp[i] = '\0';
  printf("pon : %s\n",Browser21->text(Browser21->value()));
  if (Browser21->text(Browser21->value())!=NULL)
  {
  strcpy(tmp,Browser21->text(Browser21->value()));
  printf("kainui2\n");
  result = show_service(tmp,tmp_list);
  printf("pon : tmp_list = %s\n",tmp_list);

  ii=0;
  i = 0;
  while (i<result)
  {
        for (j=0; j<30; j++)
                tmp[j] = '\0';
        j=0;
        while (tmp_list[ii]!=',')
        {
                tmp[j] = tmp_list[ii];
                ii++;
                j++;
        }
        ii++;
        printf("pon : tmp = %s\n",tmp);
        Browser23->text(i+1,tmp);
        Browser23->insert(i+1,tmp);
        i++;
  }
  }

}

void cb_Browser32(Fl_Widget* o,void*)
{ Add32->activate();
}

void Application(Fl_Widget* o,void*)
{
  char tmp[20],name[20],tmp1[20],tmp2[20];
  int i;

  if (Browser23->text(Browser23->value())!=NULL)
  {
        for(i=0;i<20;i++)
        {
                tmp[i] = '\0';
                tmp1[i] = '\0';
                tmp2[i] = '\0';
        }
        strcpy(tmp,Browser23->text(Browser23->value()));
        printf("kainui : tmp = %s\n",tmp);
        if (strncmp(tmp,"Chat",4)==0)
        {
                for (i=0;i<20;i++)
                        name[i] = '\0';
                //strcpy(name,Browser21->text(Browser21->value()));
                get_remote_name(name);
                con_rfcomm(name);
                sleep(2);
                printf("pon : after con_rfcomm\n");
                /*strcpy(tmp1,"0001chat_req");
                strcpy(tmp2,Browser21->text(Browser21->value()));
                tmp2[strlen(tmp2)] = '\0';
                printf("pon : tmp1 = %s\n",tmp1);
                printf("pon : tmp2 = %s\n",tmp2);
                bt_sdp_send_data(tmp2,tmp1);*/
                //req_window();
                cb_Chat(Browser23);
                //chat_window();
        }
        else if (strncmp(tmp,"File Transfer",13)==0)
        {
                cb_FTP(Browser23);
        }
  }
}

void Add_page1(Fl_Widget* o)
{
    char tmp[20];
    int i;

    for (i=0;i<20;i++)
        tmp[i] = '\0';
    strcpy(tmp,Browser11->text(Browser11->value()));
    add_new_device_page1(tmp);
}

void Add_page3(Fl_Widget* o)
{
    char tmp[200],tmp1[20];
    int i;

    for (i=0;i<20;i++)
        tmp[i] = '\0';
    strcpy(tmp,Browser32->text(Browser32->value()));
    printf("pon : tmp = %s\n",tmp);
    for (i=0;i<20;i++)
        tmp1[i] = '\0';
    i = 0;
    while (tmp[i]!=' ')
    {
        tmp1[i] = tmp[i];
        i++;
    }
    printf("pon : tmp1 = %d , %s\n",strlen(tmp1),tmp1);
    add_new_device_page1(tmp1);
}


void Add(Fl_Widget* o)
{

  unsigned char *tmp;
  int tmp_bt_cfd,tmp1[6];
  unsigned char tmp_bd[6],st[20];

  Fl_Window window(300, 120);
  window.label("Set Friendly Name");
  for (int i=0;i<16;i++){Address[i]='\0';}
  Fl_Input tmp_friendly_name(120, 10, 150, 25, "Friendly Name : ");
  Fl_Output*Address1=new Fl_Output (147, 45, 125, 25,"Bluetooth Address : ");

  tmp_bt_cfd = get_bt_cfd();
  read_my_address(tmp_bt_cfd,tmp_bd);
  //printf("pon : tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
  change_addr_to_str(st,tmp_bd);
  strcpy(Address,(char*)st);
  //printf("pon : address = %s\n",Address);
  Address1->value(Address);
/*  Address1->maximum_size(2);
  Fl_Input*Address2=new Fl_Int_Input (183, 45, 27, 25,":");
  Address2->maximum_size(2);
  Fl_Input*Address3=new Fl_Int_Input (220, 45, 27, 25,":");
  Address3->maximum_size(2);
  Fl_Input*Address4=new Fl_Int_Input (257, 45, 27, 25,":");
  Address4->maximum_size(2);
  Fl_Input*Address5=new Fl_Int_Input (294, 45, 27, 25,":");
  Address5->maximum_size(2);
  Fl_Input*Address6=new Fl_Int_Input (331, 45, 27, 25,":");
  Address6->maximum_size(2);*/
  Fl_Return_Button ok(100, 80, 60, 30, "OK");
  Fl_Return_Button cancel(200, 80, 80, 30, "cancel");
  window.end();
  window.set_modal();
  window.show();
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    { if (o == &ok)
      { strcpy(buffer,tmp_friendly_name.value());
        /*strcat(Address,Address1->value());
        strcat(Address,":");
        strcat(Address,Address2->value());
        strcat(Address,":");
        strcat(Address,Address3->value());
        strcat(Address,":");
        strcat(Address,Address4->value());
        strcat(Address,":");
        strcat(Address,Address5->value());
        strcat(Address,":");
        strcat(Address,Address6->value());*/
        tmp = (unsigned char*)buffer;
        //printf("pon : %s\n",tmp);
        change_friendly_name(tmp);
        //printf("pon : address %s\n",Address);
        //tmp_bt_cfd = get_bt_cfd();
        //printf("pon : bt_cfd = %d\n",tmp_bt_cfd);
        change_str_to_addr((unsigned char*)Address,tmp_bd);
        //printf("pon : tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        /*tmp1[0] = atoi(Address1->value());
        printf("pon : tmp1 = %d\n",tmp1[0]);
        tmp1[1] = atoi(Address2->value());
        tmp1[2] = atoi(Address3->value());
        tmp1[3] = atoi(Address4->value());
        tmp1[4] = atoi(Address5->value());
        tmp1[5] = atoi(Address6->value());*/

        //set_new_address(tmp_bt_cfd,tmp1);
        //read_my_address(tmp_bt_cfd,tmp_bd);
        //printf("pon : tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        //printf("pon : already\n");
        window.do_callback();
        one->activate();
        two->activate();
        three->activate();
        //show_all_device();
        printf("222\n");
        Group3->hide();
        Group1->hide();
        Group2->show();
        Button2->activate();
        Button3->activate();
      }
      else if (o == &cancel)
      { window.hide();
        one->activate();
        two->activate();
        three->activate();
        printf("333\n");
        Group1->hide();
        Group3->hide();
        Group2->show();
        Button2->activate();
        Button3->activate();
      }
    }
  }
}

void cb_Search31(Fl_Button *,void *)
{  search();
  Group32->show();
  Search31->activate();
  Stop31->deactivate();
}

void Mode(Fl_Widget*o1)
{ Fl_Window window(190, 120);
  window.label("Set Scan Mode");
  Fl_Check_Button Inquiry1(20,10,30,30,"Inquiry Scan");
  Inquiry1.value(0);
  Fl_Check_Button Page1(20,40,30,30,"Page Scan");
  Page1.value(0);
  Fl_Return_Button ok(20, 80, 60, 30, "OK");
  Fl_Return_Button cancel(100, 80, 80, 30, "cancel");
  window.end();
  window.set_modal();
  window.show();
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    { if (o == &ok) {
    Inquiry=Inquiry1.value();
    Page=Page1.value();
    set_scan_mode(Inquiry,Page);
      window.do_callback();}
    else if (o == &cancel){window.hide();}
    }
  }
}

void Info(Fl_Widget*o2)
{
  int t,tmp_bt_cfd;
  unsigned char f_name[20],tmp_bd[6],st[20];

  Fl_Window window(280, 310);
  window.label("Get My Information");
  { Fl_Box* box1=new Fl_Box(20,10,60,25,"My Address");
    box1->box(FL_NO_BOX);
    Fl_Output * text=new Fl_Output(120,40,145,25,"Friendly Name");
    get_my_friendly_name(f_name);
    //printf("pon : f_name = %s\n",f_name);
    strcpy(buffer,(char *)f_name);
    text->value(buffer);
    Fl_Output* add=new Fl_Output(147,75,120,25,"Bluetooth Address");
    tmp_bt_cfd = get_bt_cfd();
    read_my_address(tmp_bt_cfd,tmp_bd);
    //printf("pon : tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
    change_addr_to_str(st,tmp_bd);
    strcpy(Address,(char*)st);
    printf("pon : address = %s\n",Address);
    add->value(Address);
    Fl_Box* box2=new Fl_Box(60,100,170,25,"________________________________");
    box2->box(FL_NO_BOX);
  }
  { Fl_Box* box1=new Fl_Box(20,140,80,25,"My Scan Mode");
    box1->box(FL_NO_BOX);
    Fl_Output* name=new Fl_Output(110,175,60,25,"Inquiry Scan ");
    Fl_Output* add=new Fl_Output(110,210,60,25,"Page Scan   ");
    t = read_scan_mode();
    if(t==0){ name->value("Disable"); add->value("Disable");}
    else if(t==1){ name->value("Disable"); add->value("Disable");}
    else if(t==2){ name->value("Disable"); add->value("Enable");}
    else if(t==3){ name->value("Enable"); add->value("Enable");}
    Fl_Box* box2=new Fl_Box(60,235,170,25,"________________________________");
    box2->box(FL_NO_BOX);
  }
  Fl_Return_Button ok(200, 270, 60, 30, "OK");
  window.end();
  window.set_modal();
  window.show();
  for (;;)
  { Fl::wait();
    Fl_Widget *o;
    while ((o = Fl::readqueue()))
    {if (o == &ok){window.hide();}}
  }
}

int main(int argc, char **argv)
{
  init_program(argc,argv);
  Fl_Window* w;
  { Fl_Window* o = foo_window = new Fl_Window(320, 480);
    w = o;
    o->label("Bluetooth Application");
    Fl_Button* Button1=new Fl_Button (10, 420,85, 45, "Set Friendly Name");
    Button1->activate();
    Button1->align(FL_ALIGN_WRAP);
    Button1->callback(Add);
    Button2=new Fl_Button(95,420,75, 45, "Set Scan Mode");
    Button2->deactivate();
    Button2->align(FL_ALIGN_WRAP);
    Button2->callback(Mode);
    Button3=new Fl_Button(170,420,90, 45, "Get My Information");
    Button3->deactivate();
    Button3->align(FL_ALIGN_WRAP);
    Button3->callback(Info);
 //   Fl_Button* bt1= new Fl_Button(0,0,10,480);
 //   bt1->type(FL_NO_BOX);
//  Fl_Button* bt2= new Fl_Button();
    Fl_Button* exit = new Fl_Button(260, 420,50, 45, "Exit");
    exit->callback((Fl_Callback*)cb_cancel);
    o->callback((Fl_Callback*)cb_cancel);
    one=new Fl_Button(18,10,82,22,"Get Device");
    one->deactivate();
    one->callback(switch1);
    two=new Fl_Button(100,10,122,22,"Show All Device");
    two->deactivate();
    two->callback(switch2);
    three=new Fl_Button(222,10,80,22,"Search");
    three->deactivate();
    three->callback(switch3);
    /*{ Tab = new Fl_Tabs(10, 10, 300, 400);
      Tab->selection_color(15);
      Tab->hide();
      Tab->callback(show_all_device);*/
      { Group1 = new Fl_Group(10, 30, 300, 400);
        Group1->hide();
        { Fl_Group* Group11 = new Fl_Group(15,50,291,210,"Devices                                                    ");
           Group11->box(FL_ENGRAVED_FRAME);
           { Browser11 = new Fl_Select_Browser(20,60,280,152);
             Browser11->type(FL_HOLD_BROWSER);
             //Browser11->text(1,"aaa");
             //Browser11->insert(1,"aaa");
             //Browser11->insert(2,"bbb");
             //Browser11->text(2,"bbb");
             //Browser11->insert(3,"ccc");
             //Browser11->text(3,"ccc");
             Browser11->has_scrollbar(Fl_Browser::BOTH);
             Browser11->callback(cb_Browser11);
             Add11=new Fl_Button(200,220,100,30,"Add");
             Add11->deactivate();
             Add11->callback(Add_page1);
           }
           Group11->end();
         }
         { Group12 = new Fl_Group(15,280,291,120,"Services                                                   ");
           Group12->box(FL_ENGRAVED_FRAME);
           Group12->hide();
           { Browser12= new Fl_Select_Browser(20,290,280,95);
             Browser12->type(FL_HOLD_BROWSER);
             //Browser12->add("Chat");
             //Browser12->add("DialupNetworking");
             //Browser12->add("vCard");
             Browser12->has_scrollbar(Fl_Browser::BOTH);
           }
           Group12->end();
         }
        Group1->end();
      }

      { Group2 = new Fl_Group(10, 30, 300, 400);
        Group2->hide();
        { Fl_Group* Group21 = new Fl_Group(15,50,172,218,"Online                            ");
          Group21->box(FL_ENGRAVED_FRAME);
          { Browser21 =new Fl_Browser(20,60,160,200);
            Browser21->type(FL_HOLD_BROWSER);
       //     Browser21->add("Ann_PC");
       //     Browser21->add("Jack_PC");
       //     Browser21->add("Jan_Mobile");
            Browser21->has_scrollbar(Fl_Browser::BOTH);
            Browser21->callback(cb_Browser21);
          }
          Group21->end();
        }
        { Fl_Group* Group22 = new Fl_Group(15,282,172,118,"Offline                             ");
          Group22->box(FL_ENGRAVED_FRAME);
          { Browser22=new Fl_Browser(20,292,160,100);
            Browser22->type(FL_HOLD_BROWSER);
            //Browser22->add("Alice_Notebook");
            //Browser22->add("Brian_PDA");
            Browser22->has_scrollbar(Fl_Browser::BOTH);
          }
          Group22->end();
        }

        { Group23 = new Fl_Group(194,50,112,350,"Services        ");
          Group23->box(FL_ENGRAVED_FRAME);
          Group23->deactivate();
          { Browser23=new Fl_Select_Browser(200,60,100,290);
            Browser23->type(FL_HOLD_BROWSER);
            //Browser23->insert(1,"Chat");
            //Browser23->text(1,"Chat");
            //Browser23->insert(2,"DialupNetworking");
            //Browser23->text(2,"DialupNetworking");
            //Browser23->insert(3,"FileTransfer");
            //Browser23->text(3,"FileTransfer");
            //Browser23->insert(4,"vCard");
            //Browser23->text(4,"vCard");
            //Browser23->insert(5,"vCalendar");
            //Browser23->text(5,"vCalendar");
            Browser23->has_scrollbar(Fl_Browser::BOTH);
            Browser23->callback(cb_Browser23);
            Call23=new Fl_Button(200,360,100,30,"Call Service");
            Call23->deactivate();
            Call23->callback(Application);
          }
          Group23->end();
        }
        Group2->end();
      }

      { Group3 = new Fl_Group(10, 30, 300, 400);
        Group3->hide();
        { Fl_Group* Group31 = new Fl_Group(15,50,291,110,"Search                                                    ");
          Group31->box(FL_ENGRAVED_FRAME);
          { Search31=new Fl_Button(40,120,165,30,"Search Now");
            key=new Fl_Input(40,60,240,25);
            Device31=new Fl_Round_Button(75,95,10,10,"Device");
            Device31->type(102);
            Device31->value(1);
            Device31->down_box(FL_ROUND_DOWN_BOX);
            Service31=new Fl_Round_Button(195,95,10,10,"Service");
            Service31->type(102);
            Service31->down_box(FL_ROUND_DOWN_BOX);
            Search31->callback((Fl_Callback*)cb_Search31);
            Stop31 = new Fl_Button(230,120,50,30,"Stop");
            Stop31->deactivate();
          }
          Group31->end();
        }
        { Group32 = new Fl_Group(15,180,291,218,"Results                                                    ");
          Group32->box(FL_ENGRAVED_FRAME);
          Group32->hide();
          {  Browser32=new Fl_Select_Browser(20,210,280,140);
             Browser32->type(FL_HOLD_BROWSER);
             Browser32->has_scrollbar(Fl_Browser::BOTH);

             Browser32->column_char('!');
            // Browser32->column_widths(2);
             //const int* i = 2;
             //column_widths();
             //i=;
            //Browser32->add("Jan_!Mobile\t\t Chat");
             //Browser32->add("Jan_Mobile\t\t DialupNetworking");
             //Browser32->add("Jan_Mobile\t\t vCard");
             //Browser32->add("Joe_!Notebook\t       Chat");
             //Browser32->add("Joe_Notebook\t       DialupNetworking");
             //Browser32->add("Joe_Notebook\t       FileTransfer");
             //Browser32->add("Joe_Notebook\t       vCard");
             //Browser32->add("Joe_Notebook\t       vCalendar");
             Browser32->callback(cb_Browser32);
             Fl_Button* Device32=new Fl_Button(20,190,140,20,"Device");
             Fl_Button* Service32=new Fl_Button(160,190,140,20,"Service");
             Add32 =new Fl_Button(200,360,100,30,"Add");
             Add32->deactivate();
             Add32->callback(Add_page3);
          }
          Group32->end();
        }
        Group3->end();
      }
    /*  Tab->end();
      Fl_Group::current()->resizable(o);
    } */
    o->end();
  }
  w->show(argc, argv);
  return Fl::run();
}

#endif