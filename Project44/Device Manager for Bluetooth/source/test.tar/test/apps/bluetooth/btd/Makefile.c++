# $Id: Makefile,v 1.11 2001/10/18 15:56:25 pkj Exp $

ifdef APPS
AXIS_USABLE_LIBS = UCLIBC
include $(APPS)/Rules.elinux
endif

PROGS     = btd

# Define HAVE_READLINE_READLINE if you have readline support, with the include
# files in $(include_dir)/readline. Define HAVE_READLINE if you have the
# include files in $(include_dir). Define neither if you do not want to use
# readline.
HAVE_READLINE_READLINE = 1
#HAVE_READLINE = 1

INSTDIR   = $(prefix)/bin/
INSTMODE  = 0755
INSTOWNER = root
INSTGROUP = root

SRCS      = btd.c

OBJS      = btd.o nui.o bt.o

ifdef HAVE_READLINE_READLINE
LDLIBS   += -lreadline -ltermcap
CFLAGS   += -DHAVE_READLINE_READLINE -I$(prefix)/include
endif

ifdef HAVE_READLINE
LDLIBS   += -lreadline -ltermcap
CFLAGS   += -DHAVE_READLINE -I$(prefix)/include
endif

PLIBS +=  -I/usr/local/include:
PPLIBS +=  -L/usr/local/lib -L/usr/X11R6/lib -lfltk -lXext -lX11 -lm

#LDLIBS   += -lreadline -ltermcap

CFLAGS   += -MMD -Wall

all:	$(PROGS)

$(PROGS):	$(OBJS)
	g++ $(OBJS) $(LDLIBS) $(PPLIBS) -o $(PROGS)

bt.o :  bt.cxx bt.h
	g++ $(PLIBS) -c -Wall bt.cxx

#btd:	btd.o nui.o
#	$(CC) $(CFLAGS) btd.o nui.o -o btd
#
#btd.o:	btd.c btd.h
#	$(CC) $(CFLAGS) -c btd.c

#nui.o:	nui.c nui.h
#	$(CC) $(CFLAGS) -c nui.c

install:	$(PROGS)
	$(INSTALL) -d $(INSTDIR)
	$(INSTALL) -m $(INSTMODE) -o $(INSTOWNER) -g $(INSTGROUP) $(PROGS) $(INSTDIR)

clean:
	rm -f $(PROGS) *.o *.d core *~

-include *.d
