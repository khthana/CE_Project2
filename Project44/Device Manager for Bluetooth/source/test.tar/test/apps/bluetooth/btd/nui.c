#include <pty.h>
#include <pthread.h>

#include "nui.h"

#ifdef NUI1_FNC

int nui1(int a)//(int argc,char **argv)
{
        return 2;
}
#endif
