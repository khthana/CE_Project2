//#include "btd.h"
#define NUI1_FNC
//extern "C" 
//	int nui1(int a);//(int argc,char **argv)
