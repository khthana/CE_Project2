
#include "bt.h"

#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>

/* The following includes are required to be able to determine the local
 * address by examining eth0 */
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <arpa/inet.h>

#if defined(HAVE_READLINE_READLINE)
#include <readline/readline.h>
#include <readline/history.h>
#elif defined(HAVE_READLINE)
#include <readline.h>
#include <history.h>
#endif

#define RESTART_ENABLED

#define USE_IPASSIGN

/* automatic restart of application after a hw reset */
#ifdef RESTART_ENABLED
#include <setjmp.h>
#endif

/* USER SPACE STACK TEST */

/* defined in Makefile */
#ifdef BTD_USERSTACK

#define USE_PSEUDOTERMINALS /* remove ? */
#include <pty.h>
#include <pthread.h>
#include "include/btcommon.h"
#include "include/btmem.h"
#include "include/hci.h"
#include "include/l2cap.h"
#include "include/l2cap_con.h"
#include "include/sdp.h"
#include "include/tcs.h"
#include "include/test.h"
#include "include/rfcomm.h"
#include "include/btdebug.h"
#include "include/bt_proc.h"
#include "include/unplug_test.h"

#include "bt.h"




/*
 * Local functions
 */

static int init_read_thread(void);
static void hci_receive_thread(void);
int open_pty(void);
static int init_pty_thread(void);
static void pty_receive_thread(void);

const char* psmname(unsigned short psm);
int bt_write_lower_driver(unsigned char *data, int len);
int bt_write_top(char *buf, int count, int line);
int bt_receive_top(unsigned int con_id, unsigned char *data, int len);
void bt_rfcomm_connection_ready(int status);
void bt_sdp_connection_ready(int status);
int bt_initiated(void);
int bt_use_bcsp(int new_use_bcsp);
int bt_dfu_mode(int new_dfu_mode);
extern int bt_read_proc(char *buf, int len);
bt_stat_struct bt_stat;
static int bt_initdone = 0;
rfcomm_con *test_rfcomm;
int test_dlci;
                           
#ifdef USE_PSEUDOTERMINALS

static int pty_master_fd;
static int pty_slave_fd;

/* pty device name */
char   ptydev[256];

pthread_t pty_thread;

#endif /* USE_PSEUDOTERMINALS */

/* thread used to read data on "physical" device */
pthread_t read_thread;

#if BT_DATA_DEBUG
#define BT_DATA(fmt...) printf("BT DATA "fmt)
#else
#define BT_DATA(fmt...)
#endif

#if BT_DATADUMP_DEBUG
#define PRINTPKT(str, data, len) print_data(str, data, len)
#else
#define PRINTPKT(str, data, len)
#endif

/*
 *  Socket stuff, used to run two instances of the stack on the same computer
 *  against each other
 */

/* local UNIX socket */
int use_local_socket = 0; /* default */
#define SOCKET_NAME "/tmp/bt_server"

int use_tcp_socket = 0; /* default */
char *tcp_address; /* ip address and port string argument */

/* returns fd to socket */
static int open_tcpsocket(char *addrstr, int role);

#else /* standard mode using kernel stack */

/* ioctls defines etc */
#include "btd.h"

static int bt_disc = N_BT;
#endif /* BTD_USERSTACK */

/*
 * Local functions common to both userstack and standard btd
 */

static int open_device(char* dev, int flags, int role);
static void close_device(int fd);
static void fd_setup(int fd, int speed, int flow);
static int translate_speed(int spd);

static void init_phys(int fd);
static void init_stack(int spd);
static void shutdown_stack(void);
static void init_hw(int spd);
static int process_cmd(char *buf, int bt_fd);

static char* get_local_addr(void);
static void start_pppd(void);
static void build_pppdopt(int role);
static void btd_cleanup(void);
static void btd_killchilds(void);
static void btd_sighandler(int sig);
static void init_sighandler(void);
static int open_socket(char *name, int role);

static int sdpsrv_pid = 0;
static int start_sdp_server(void);

/*************kainui add**********************/
unsigned char msg[50];
//unsigned char nui[6];

extern void test_call(void);
extern void chat_receive(char msg[]);
extern int req_window(void);
extern void chat_window(void);
extern void req_window_1(void);
extern void req_window_2(void);

int init_program(int argc, char **argv);
void disc_sdp(void);
void change_friendly_name(unsigned char *st);
void get_my_friendly_name(unsigned char friendly_name[]);
void get_remote_name(char friendly_name[]);
int get_bt_cfd(void);
void set_new_address(int bt_cfd,int *tmp_bd);
void read_my_address(int bt_cfd,unsigned char *tmp_bd);
int read_scan_mode(void);
void set_scan_mode(int inq,int page);
void remote_friendly_name(unsigned char bd[]);
int search_specific(char key[],int type,char tmp_list[]);
int search_service(char line[]);
void disc_req(void);
unsigned char bt_sdp_get_line(void);
void con_to_send_data(unsigned int tmp[]);
void con_rfcomm(char name[]);
int send_data(char *st,int repeat,int line);
void send_data_disc(int line);
void bt_sdp_send_data(char name[],char st[]);
int chat(void);
unsigned char* rfcomm_get_data(void);
void read_device_data(void);
void write_device_data(void);
void read_my_service_data(void);
void int_to_char(int num,char *st);
void change_str_to_addr(unsigned char *st,unsigned char tmp_bd[]);
void change_addr_to_str(unsigned char st[],unsigned char *tmp_bd);
int compare_addr(unsigned char *addr1,unsigned char *addr2);
void find_all_device(int nbr_rsp,int t,int page);
void apps_page1(void);
void apps_page2(void);
void apps_page3(void);
int find_specific_device(int i,unsigned char st1[]);
int find_specific_service_bak(int i,unsigned char st1[]);
int find_specific_service(int i,unsigned char st1[],char tmp_list[]);
void add_tmp_device_data(unsigned char tmp_bd[],unsigned int sdp_id);
void show_tmp_device_bak(void);
void show_tmp_device(char tmp_device[],int *num);
void show_tmp_service(int device_id,char tmp_list[],int *num);
void show_tmp_service_bak(int device_id);
void show_service_bak(int device_id);
int show_service(char name[],char tmp_list[]);
void check_online_offline(char online[],char offline[],int *num_online,int *num_offline);
void update_device_data(int ii,unsigned char tmp_bd[],unsigned int sdp_id);
void add_new_device_req(int device_id);
void add_new_device_res(int device_id);
void add_new_device(int device_id);
void add_new_device_page1(char name[]);
void add_device_data(unsigned char tmp_bd[],unsigned int sdp_id);
void check_connect(void);
void bt_sdp_receive_top(unsigned char *data);
void bt_sdp_write_top(unsigned int sdp_id,unsigned char *data);
void service_browse_req(unsigned int device_id);
void service_browse_res(int device_id,int sdp_id);
void detect_service_res(unsigned int device_id,unsigned char *tmp_st);

struct service{
        unsigned char service_record_handle[30];
        unsigned char service_classID_list[30];
        unsigned char protocol_descriptor_list[30];
        unsigned char browse_group_list[30];
        unsigned char bt_profile_descriptor_list[30];
        unsigned char service_name[30];
        unsigned char service_description[500];
        unsigned char groupID[30];
}service;

struct device{
        unsigned char friendly_name[30];
        unsigned char bd_addr[20];
        unsigned char type[30];
        int num_service;
        struct service service_list[10];      //service_list[x][0] = service_id , service_list[x][1] = service_name
        int last_modified;
        int status;                             // 0 = not connect; 1 = rfcomm; 2 = sdp; 3=both;
        unsigned int sdp_id;
}device;


FILE *fp;
FILE *fs;
struct device device_list[10];
struct device tmp_device_list[10];
struct service my_service_list[10];
int num_tmp_device = 0;
int num_device = 0;
int num_my_service = 0;
/*********************************************/



/* misc */
#ifndef BTD_USERSTACK
static void set_bt_line_disc(int phys_fd, int bt_disc, char* physdev);
#endif
static void bt_connect(int bt_fd, unsigned char *bd, unsigned int con_id);
static void bt_disconnect(int bt_fd, unsigned int con_id);
static void bt_waitline(int bt_fd, int line);
static void bt_inquiry(int bt_cfd, int nbr_rsp, int t);
static void bt_set_bd_addr(int bt_cfd, int* bd);
static void read_local_bd(int bt_cfd, unsigned char *bd_addr);
static void read_remote_bd(int bt_cfd, int line, unsigned char *bd_addr);
static void role_switch(int bt_cfd, unsigned char *bd_addr, int role);
#ifndef BTD_USERSTACK
static char* bt_hw_vendor(void);
#endif
static void reset_hw(void);
static void bt_set_classofdevice(int bt_fd, unsigned short service_class, unsigned char major_class, unsigned char minor_class, unsigned char format);


/* Misc */
static void show_menu(void);

static int hw_vendor(void);

static void csr_init_phys(int fd);
static void csr_init_hw(int spd);
static void digianswer_init_phys(int fd);
static void digianswer_init_hw(int spd);
static void ericsson_init_phys(int fd);
static void ericsson_init_hw(int spd);
static void infineon_init_phys(int fd);
static void infineon_init_hw(int spd);
static void usb_init_phys(int fd);
static void usb_init_hw(int spd);
static void generic_init_phys(int fd);
static void generic_init_hw(int spd);
static void no_init_phys(int fd);
static void no_init_hw(int spd);
static void unknown_init_phys(int fd);
static void unknown_init_hw(int spd);


#undef ECS_TEST_FUNCTIONS


#if !defined(HAVE_READLINE) && !defined(HAVE_READLINE_READLINE)
void read_history(char *hist_file_name);
void write_history(char *hist_file_name);
void add_history(char *command);
char *readline(char *promt);
#endif

/* Modem emulator stuff */

#define CONNECT 1
#define NULLCONNECT 2
#define RESTART 3
#define SHUTDOWN 4
#define HELLOCONNECT 5
#define DO_PPP 6
#define SEND_OK 7

#define PPP_DELIMITER 0x7e
#define PPP_PROT_LCP 0xc021
#define PPP_TERM_REQ 0x5

static int parse_modem_data(char *databuf, int len, int bt_fd);
static void modem_emulator(int bt_fd, char *data, int len);
#ifdef PALM_FIX
static int search_str(char *data, const char *searchstr);
#endif

/*
 * Some defines
 */

#define PID_FILE "/var/run/btd.pid"

#define PPPDCMD "pppd"

#ifdef BTD_USERSTACK
#define SDPSRV_CMD "sdp_user"
#else
#define SDPSRV_CMD "sdp_server"
#endif

#define BT_CTRL_TTY "/dev/ttyBTC"

/* default settings */
#define CLIENT 0
#define SERVER 1

#ifdef __CRIS__
#define DEFAULT_PHYS_DEV "/dev/ttyBT"
#define DEFAULT_SPEED "460800"
#else
#define DEFAULT_PHYS_DEV "/dev/ttyS0"
#define DEFAULT_SPEED "115200"
#endif

#define DEFAULT_BT_DEV "/dev/ttyBT0"

#define DEFAULT_ROLE SERVER

#define USE_NO_FLOW 0
#define USE_FLOW_CTRL 1

#define START_PPP 1
#define QUIT_BTD 2

#define LOCAL_NAME_LENGTH  32
#define HOST_NAME_LENGTH   100
#define DOMAIN_NAME_LENGTH 100

#define BTD_HISTORY_FILE "/tmp/btd_history"

#define HW_NOT_PROBED -1
#define HW_CSR        0
#define HW_DIGIANSWER 1
#define HW_ERICSSON   2
#define HW_INFINEON   3
#define HW_USB        4
#define HW_GENERIC    5
#define HW_NO_INIT    6
#define HW_UNKNOWN    7

/*
   Bluetooth discipline define. Should reside in /include/asm/termios.h
   However, if compiling this standalone simply use the define in bluetooth.h
 */

static int pid_fd = -1;
static int phys_fd = -1;
static int bt_fd = -1;
static int bt_cfd = -1;
static char* physdev = DEFAULT_PHYS_DEV;
static char* btdev = DEFAULT_BT_DEV;
static int hw_init = 1;
static char* speedstring = DEFAULT_SPEED;
static int modem_emulation = 1;
static int modem_connected = 0;
static int enter_cmd_mode = 0;
static int role = DEFAULT_ROLE;
static int do_reset = 0;
static int start_ppp = 1;
static int pppd_pid = 0;
static char *pppd_options[32];
static char local_bd_string[18];
static char remote_bd_string[18];
static char local_name[LOCAL_NAME_LENGTH+1];
static int btd_shuttingdown = 0;/* used to know in modem emulator whether
				   to restart or exit */
#ifdef USE_IPASSIGN

/* IP assign stuff */
enum ipa_requests{
  GETCLIENTIP,
  GETDNSSERVERS,
  RETURNCLIENTIP
};

typedef struct ipa_client
{
  struct in_addr ip;               /* Returns IP address for the client */
  struct in_addr dns[2];           /* Returned DNS servers */
  int nbr_of_dns;                  /* Returns number of found DNS servers. */
  struct in_addr wins[2];          /* Returned MS WINS servers */
  int nbr_of_wins;                  /* Returns number of found MS WINS servers. */
  struct in_addr netmask;          /* Returns the netmask to be used(clients)*/
  int proxyarp;                    /* Returns 1 if proxyarp will be used */
  int useradius;                   /* Returns 1 if RADIUS is being used */
  int useradiusip;                 /* Returns 1 if IP address assignment via
                                    *  RADIUS is allowed */
  int usingmasq;                   /* Returns 1 if NAT is being used */
}ipa_client;

typedef struct ipa_request
{
  unsigned short type; /* type of request */
  unsigned char remote_bd[6]; /* Requestors BD address */
  struct ipa_client client; /* return client */
} ipa_request;


#define SRVSOCKET "/tmp/ipa_server"

int ipa_sock = -1;
static char ipa_buf[128];
struct ipa_client *ipa_send(ipa_request *req);
static void ipa_getpars(void);
static struct ipa_request ipa_req;
static struct ipa_client a_client;

#endif

/* Locals used for IP settings to pppd */
char ip_addresses[35]; /* Max length 255.255.255.255:255.255.255.255 */
char *local_address = NULL;
char *remote_address = NULL;
char *ppp_netmask = NULL;

static char *prim_dns = NULL;
static char *sec_dns = NULL;
static char *prim_wins = NULL;
static char *sec_wins = NULL;

static int use_proxyarp = 1;
static int use_radius = 0;
static int using_masq = 0;
static int use_radius_ip_assign = 0;
static int use_ipassign = 0;

#ifdef RESTART_ENABLED
sigjmp_buf jmpbuffer;
#endif


static int option_index = 0;

/* long option list */
static struct option long_options[] =
{
  {"physdev", 1, NULL, 'u'},                 /* phys device used from stack */
  {"btdev", 1, NULL, 'b'},                   /* bluetooth device */
  {"client", 0, &role, CLIENT},
  {"server", 0, &role, SERVER},
  {"speed", 1, NULL, 's'},                    /* uart speed towards hw */
  {"local-name", 1, NULL, 'n'},               /* set local bluetooth name */
  {"local", 1, 0, 'd'},                       /* set local ip address */
  {"remote", 1, 0, 'D'},                      /* set remote ip address */
  {"modem", 1, NULL, 'e'},                    /* modem emulation */
  {"reset", 0, &do_reset, 1},                 /* reset BT HW */
  {"cmdmode", 0, &enter_cmd_mode, 1},         /* enter command line mode */
  {"tcpsock", 1, 0, 'T'},                     /* use network socket*/
  {"unixsock", 0, 0, 'S'},                    /* use local socket */
  {"radius", 0, &use_radius, 1},              /* enable radius */
  {0, 0, 0, 0}
};

/******************************************(menu)*****************************************************/
char* menu[] =
{

#ifdef BTD_USERSTACK
  "----My Project--------",
  "  set_new_address <xx:xx:xx:xx:xx:xx>", /* only ericsson HW */
  "  read_my_address", /* read module bd address */
  "  reset", /* reset board */
  "  read_scan_mode",
  "  set_scan_mode (inquiry scan) (page scan)",
  "  find_device <Max number of responses> (inquiry scan) ",
  "  find_all_device <Max number of responses> (inquiry scan) ",
  "  read_remote_bd_sdp", /*read remote address*/
  "  read_remote_bd_rf", /*read remote address*/
  "  get_role", /*get my role*/
  "  remote_friendly_name <xx:xx:xx:xx:xx:xx>", /*read remote friendly name*/
  "  friendly_name", /*read my friedly name*/
  "  change_friendly_name <new name>", /*change my friendly name*/
  "  role_switch <xx:xx:xx:xx:xx:xx> <role>",
  "  con_for_service  <xx:xx:xx:xx:xx:xx> <profile>",
  "  con_to_send_data <xx:xx:xx:xx:xx:xx> <srv ch> <line>",
  "  send_data <message> <nbr repeats> <line>", /*send data pass rfcomm layer*/
  "  send_data_disc <line>",
  "  sdp_disc", /*shuwdown sdp all id*/
  "  disc", /* disconnect all (both) test connections */
  "  stat ", /* similar to reading the /proc/bt */
  "  read_class_of_device",
  "  set_service_class <service class>",
  "  set_major_class <major class>",
  "  set_minor_class <minor class>",
  "  sdp_send_data <message> <sdp_id>",
  "  sdp_get_data",
  "  rfcomm_get_data",
  "  apps_page1",
  "  apps_page2",
  "  apps_page3",
  "  check_online_offline",
  "  quit",
  "",
  "-----Application------",
  "  chat", /*client start chat*/
  "  start", /*server start chat*/
  "",
#endif
  NULL
};
/*******************************************(end menu)************************************************/

/*********************************************(init_program function)*********************************************/
int
init_program(int argc, char **argv)
{
  int opt;
  int spd;
  char pid_buf[80];

  printf("Bluetooth Control Application\n");
  printf("-----------------------------\n");

  if (atexit(btd_cleanup) < 0)
  {
    printf("btd failed to register cleanup function.\n");
    exit(1);
  }

#ifndef BTD_USERSTACK

  if ((pid_fd = open(PID_FILE, O_CREAT | O_WRONLY | O_TRUNC | O_EXCL, 0666)) < 0)
  {
    if (errno == EEXIST)
    {
      printf("There is already another version of btd running.\n");
    }
    else
    {
      printf("Could not create pid file for btd.\n");
    }

    exit(0);
  }

#endif

  sprintf(pid_buf, "%d\n", getpid());
  write(pid_fd, pid_buf, strlen(pid_buf));
  close(pid_fd);
  /* do not set pid_fd to -1, we use it to mark that we created the pid file */

  /* now parse options */
#define OPTIONS_STRING "a:b:d:D:e:i:mn:r:Rs:ST:u:X"

  while ((opt = getopt_long(argc, argv, OPTIONS_STRING,
                            long_options, &option_index)) != -1)
  {
    switch(opt)
    {
     case 'u':
      /* uart device */
      physdev = optarg;
      break;

     case 'b':
      /* bluetooth device */
      btdev = optarg;
      break;

     case 'd':
      /* Sets local ipaddress in pppd options */
      local_address = strdup(optarg);
      break;

     case 'D':
      /* Sets remote ipaddress in pppd options */
      remote_address = strdup(optarg);
      break;

     case 'e':
      /* switches on/off the modem emulation */
      modem_emulation = atoi(optarg);
      break;

     case 'm':
      /* enter command line mode */
      enter_cmd_mode = 1;
      break;

     case 'n':
      strncpy(local_name, optarg, LOCAL_NAME_LENGTH);
      local_name[LOCAL_NAME_LENGTH] = '\0';
      break;

     case 'r':
      /* role */
      if (strcmp(optarg, "client") == 0)
        role = CLIENT;
      else if (strncmp(optarg, "server", 6) == 0)
        role = SERVER;
      break;

     case 'R':
      /* try to reset the hardware */
      do_reset = 1;
      break;

     case 's':
      /* speed */
      speedstring = optarg;
      break;

#ifdef BTD_USERSTACK
     case 'S':
      /* Use local unix socket together with hci emulation */
      use_local_socket = 1;
      /* adjust invalid settings */
      do_reset = 0;
      modem_emulation = 0;
      hw_init = 0;
      enter_cmd_mode = 1; /* temp fix until bt_waitline works for usermode */
      break;

     case 'T':
       /* Use TCP socket together with hci emulation */
       use_tcp_socket = 1;
       tcp_address = optarg; /* ipaddress:port */

       /* adjust invalid settings */
       do_reset = 0;
       hw_init = 0;
       modem_emulation = 0;
       enter_cmd_mode = 1; /* force */
       break;
#endif

     case '?':
/*      printf("unknown option: %c\n", optopt); */
      break;
    }
  }

  init_sighandler();

  /* Hardreset of BT hardware */
  if (do_reset)
      reset_hw();

#ifdef RESTART_ENABLED
  /* restart point after setting bd address in ericsson hw */
  if (sigsetjmp(jmpbuffer, 1) != 0)
  {
    printf("restart...\n\n\n\n");
  }
#endif

  if (role == SERVER)
    printf("Running as server\n");
  else {
    printf("Running as client\n");
    enter_cmd_mode = 1; /* force */
  }

#ifdef BTD_USERSTACK
  printf("Running stack in user mode\n");

  if (use_local_socket)
  {
    physdev = SOCKET_NAME;
    printf("Using local UNIX socket %s\n", physdev);
  }
  else if (use_tcp_socket)
  {
    physdev = tcp_address;
    printf("Using TCP socket to %s\n", physdev);
  }
  else
  {
    printf("Physdev %s, btdev (not used), speed %s baud\n",
           physdev, speedstring);
  }

#else
  printf("Physdev %s, btdev %s, speed %s baud\n",
         physdev, btdev, speedstring);
#endif

  if (role == SERVER)
	  sdpsrv_pid = start_sdp_server();

  spd = atoi(speedstring);

  if ((phys_fd = open_device(physdev, O_RDWR, role)) < 0)
  {
    perror("could not open phys dev\n");
    exit(1);
  }

  init_phys(phys_fd);

#ifndef BTD_USERSTACK
  /* Set the current tty to the bluetooth discpline */
  set_bt_line_disc(phys_fd, bt_disc, physdev);
#endif

  if ((bt_cfd = open_device(BT_CTRL_TTY, O_RDWR, 0)) < 0)
  {
    perror("could not open control\n");
    exit(1);
  }
  printf("bt_cfd = %d\n",bt_cfd);

  init_stack(spd);

  /* Now set phys device speed to whatever HW was set to */
  fd_setup(phys_fd, spd, USE_FLOW_CTRL);

  tcflush(phys_fd, TCIOFLUSH);

#ifdef BTD_USERSTACK
  open_pty();
  init_pty_thread();
#endif

  printf("num_device = %d\n",num_device);
  printf("num_my_service = %d\n",num_my_service);
  read_device_data();
  read_my_service_data();
  printf("after read_my_service\n");

}
/**************************************************(end fucntion)*****************************************************/



/* readline replacement  - mfuchs */
#if !defined(HAVE_READLINE) && !defined(HAVE_READLINE_READLINE)
#define MAXLINE 100

void read_history(char *hist_file_name)
{
}

void write_history(char *hist_file_name)
{
}

void add_history(char *command)
{
}

char *readline(char *promt)
{
  int len;
  char *line;

  if ((line = malloc(MAXLINE)))
  {
    printf("%s", promt);
    fflush(stdout);
    *line = 0;
    if ((len = read(STDIN_FILENO, line, MAXLINE-1)) >= 0)
    {
      line[len] = 0;
    }
  }

  return line;
}
#endif /* !HAVE_READLINE */

#define SDPSRV_CONF "/etc/sdp.xml"

#ifdef BTD_USERSTACK
#define SDPSRV_PROC "/tmp/sdp_sock"
#else
#define SDPSRV_PROC "/proc/sdp_srv"
#endif

int start_sdp_server(void)
{
  int sdpsrv_pid;
  char *args[] = { SDPSRV_CMD, SDPSRV_CONF, SDPSRV_PROC, NULL };

  syslog(LOG_INFO, "Starting SDP server [%s]\n", SDPSRV_CMD);

  if (!(sdpsrv_pid = vfork()))
  {
    execvp(SDPSRV_CMD, args);

    fprintf(stderr, "%s: no such file or directory\n", SDPSRV_CMD);
    syslog(LOG_INFO, "%s not found", SDPSRV_CMD);

    _exit(0);
  }
  return sdpsrv_pid;
}

static void start_pppd(void)
{

  /* run pppd in a child */
  if (!(pppd_pid = vfork()))
  {
    /* modem emulation resides in stack for now */

    if (role == SERVER)
      syslog(LOG_INFO, "Starting ppp server on %s", btdev);
    else
      syslog(LOG_INFO, "Starting ppp client on %s", btdev);

    execvp(PPPDCMD, pppd_options);

    fprintf(stderr, "%s: no such file or directory\n", PPPDCMD);

    _exit(0);
  }

  /* in parent, we let pppd run in the background */
  syslog(LOG_INFO, "Spawned pppd[%d] in the background", pppd_pid);

  /* Parent, wait for ppp child to die */
  wait4(pppd_pid, NULL, 0, NULL);
  pppd_pid = 0;

#ifdef USE_IPASSIGN
  if (use_ipassign)
  {
    syslog(LOG_INFO, "Returning IP address to IPA");

    /* Return IP address! */
    ipa_req.type = RETURNCLIENTIP;
    //ipa_req.remote_bd
    memcpy(&ipa_req.client, &a_client, sizeof(struct ipa_client));

    if (!ipa_send(&ipa_req))
      syslog(LOG_ERR, "Failed to return IP address to IPA\n");
  }
#endif
}

/* FIXME -- use separate options file 'pppd file <optionfile>' for
   most common options */

void build_pppdopt(int role)
{
  int i = 0;

#ifdef USE_IPASSIGN
  if (use_ipassign)
    ipa_getpars();
#endif

  /* we have no local ip address, get it from eth0 */
  if (!local_address)
    local_address = get_local_addr();

  /* we have no remote ip address, skip it ! */
  if (!remote_address){
    syslog(LOG_INFO, "Didn't get any remote IP\n");
    remote_address = strdup("");
  }

  /* create pppd option */
  sprintf(ip_addresses,"%s:%s",local_address, remote_address);

  /* deallocate strings */
  if (local_address)
    free(local_address);

  if (remote_address)
    free(remote_address);

  local_address = NULL;
  remote_address = NULL;

  syslog(LOG_INFO, "IP addresses used : %s",ip_addresses);

  /* general options */

  pppd_options[i++] = (char*)PPPDCMD;

#ifndef USE_PSEUDOTERMINALS
  pppd_options[i++] = btdev;
#else
  pppd_options[i++] = ptydev;
#endif
  pppd_options[i++] = speedstring;
  pppd_options[i++] = "crtscts";
/*  pppd_options[i++] = "debug";    --- moved to options file */
/*  pppd_options[i++] = "local";    --- moved to options file */
/*  pppd_options[i++] = "nodetach"; --- moved to options file (-detach) */

  if (role==SERVER)
  {
    pppd_options[i++] = "nopersist";
    pppd_options[i++] = "silent";
    pppd_options[i++] = "passive";

    if (use_radius)
    {
      pppd_options[i++] = "useradius";
      pppd_options[i++] = "auth";
      pppd_options[i++] = "login";
      if (use_radius_ip_assign)
      {
        pppd_options[i++] = "useautoip";
      }
#ifdef USE_IPASSIGN
      pppd_options[i++] = "localbdaddr";
      pppd_options[i++] = local_bd_string;
      pppd_options[i++] = "remotebdaddr";
      pppd_options[i++] = remote_bd_string;
#endif /* USE_IPASSIGN */
    }
    else
    {
      pppd_options[i++] = "noauth";
    }

    if (use_proxyarp)
    {
	    pppd_options[i++] = "proxyarp";
	    /* ktune only works on pppd version > 2.3.10 */
	    /* similar as doing ' echo 1 > /proc/sys/net/ipv4/ip_forward */
	    pppd_options[i++] = "ktune"; /* enables ip_forwarding */
    }

    if (using_masq)
    {
      pppd_options[i++] = "usingmasq";
    }

    if (ip_addresses)
    {
      pppd_options[i++] = ip_addresses;
    }

    if (ppp_netmask)
    {
      pppd_options[i++] = "netmask";
      pppd_options[i++] = ppp_netmask;
    }

    if (prim_dns)
    {
      pppd_options[i++] = "ms-dns";
      pppd_options[i++] = prim_dns;
    }

    if (sec_dns)
    {
      pppd_options[i++] = "ms-dns";
      pppd_options[i++] = sec_dns;
    }

    if (prim_wins)
    {
      pppd_options[i++] = "ms-wins";
      pppd_options[i++] = prim_wins;
    }

    if (sec_wins)
    {
      pppd_options[i++] = "ms-wins";
      pppd_options[i++] = sec_wins;
    }

  }
  else
  {
    pppd_options[i++] = strdup("defaultroute");
    pppd_options[i++] = ip_addresses;
  }

  pppd_options[i] = NULL;

#if 0
  /* print pppd_options */
  i = 0;
  while (pppd_options[i])
    syslog(LOG_INFO, "%s\n", pppd_options[i++]);
#endif
}


int
translate_speed(int spd)
{
  int speed_c = 0;

  switch(spd)
  {
   case 9600:
    speed_c = B9600;
    break;
   case 19200:
    speed_c = B19200;
    break;
   case 38400:
    speed_c = B38400;
    break;
   case 57600:
    speed_c = B57600;
    break;
   case 115200:
    speed_c = B115200;
    break;
   case 230400:
    speed_c = B230400;
    break;
   case 460800:
    speed_c = B460800;
    break;
   default:
    printf("Bad baudrate %d.\n", spd);
    break;
  }
  return speed_c;
}

void
fd_setup(int fd, int speed, int flow)
{
  struct termios t;

#ifdef BTD_USERSTACK
  if (use_local_socket || use_tcp_socket)
    return ;
#endif

  if (fd < 0)
  {
    perror("fd_setup");
    exit(1);
  }

  if (tcgetattr(fd, &t) < 0)
  {
    perror("tcgetattr");
    exit(1);
  }

  cfmakeraw(&t);

  t.c_cflag &= ~CBAUD;
  t.c_cflag |= translate_speed(speed) | CS8 | CLOCAL;
  t.c_oflag = 0; /* turn off output processing */
  t.c_lflag = 0; /* no local modes */

  if (flow)
    t.c_cflag |= CRTSCTS;
  else
    t.c_cflag &= ~CRTSCTS;

  if (tcsetattr(fd, TCSANOW, &t) < 0)
  {
    perror("fd_setup : tcsetattr");
    exit(1);
  }
  return;
}

void
show_menu(void)
{
  char** option;

  option = menu;
  while (*option)
  {
    printf("%s\n", *option);
    option++;
  }
}

/********************************(process_cmd function)*******************************/
/*This function used to test in text mode*/
int
process_cmd(char *buf, int bt_fd)
{
  int bd[6];
  unsigned char my_bd_addr[6];
  unsigned int tmp[11];
  int repeat;
  int i, line, nbr_rsp,t;
  int j,k; //kainui
  char *st; //kainui
  unsigned char remote_bd[6];     //kainui
  unsigned char *service_class ;    //kainui
  unsigned char *major_class ;      //kainui
  unsigned char *minor_class ;      //kainui
  unsigned int sdp_id = 10;


#ifdef BTD_USERSTACK
  unsigned char tmp_bd[6]; /* used for byte swapping */
  int server_channel, profile;
#endif

  if (!strncmp(buf, "quit", 4))
  {
    return QUIT_BTD;
  }
  else if (!strncmp(buf, "ppp", 3))
  {
    return START_PPP;
  }

/*
 * Non usermode stack functions for the stuff
 * below will be added later on
 */

#ifdef BTD_USERSTACK
 /***************my project*********************/
  else if (sscanf(buf, "set_new_address %x:%x:%x:%x:%x:%x",
                  &bd[0], &bd[1], &bd[2], &bd[3], &bd[4], &bd[5]) == 6)
  {
    bt_set_bd_addr(bt_cfd, &bd[0]);
  }
  else if (strncmp(buf, "read_my_address", 15) == 0)
  {
    read_local_bd(bt_cfd, my_bd_addr);
  }
  else if (strncmp(buf, "reset", 5) == 0)
  {
    close_device(bt_cfd);
    close_device(phys_fd);
    bt_cfd = -1;
    phys_fd = -1;
    reset_hw();
#ifdef RESTART_ENABLED
    /* must set baud rate to default for hw again... */
    siglongjmp(jmpbuffer, 1);
#endif
  }
  else if (strncmp(buf, "read_scan_mode", 14) == 0)
  {
        read_scan_mode();
  }
  else if (sscanf(buf, "set_scan_mode %d %d", &j, &k) == 2)
  {
        set_scan_mode(j,k);
  }
  else if (sscanf(buf, "find_device %d %d", &nbr_rsp, &t) == 2)
  {
    int i=0;
    bt_inquiry(bt_cfd, nbr_rsp, t);
    sleep(10);
    i = get_num_inquiry_result();
    printf("num_inquiry_result : %d\n",i);
  }
  else if (sscanf(buf, "find_all_device %d %d", &nbr_rsp, &t) == 2)
  {
     find_all_device(nbr_rsp,t,2); //apps_page2
  }

  else if (strncmp(buf, "read_remote_bd_sdp", 18) == 0)
  {

     unsigned char line;
     line = bt_sdp_get_line();
     printf("line is %d\n",line);
     printf("Client bd addr(Before) : %02X:%02X:%02X:%02X:%02X:%02X\n",
                remote_bd[0], remote_bd[1], remote_bd[2],
                remote_bd[3], remote_bd[4], remote_bd[5]);
     read_remote_bd(bt_cfd,line,remote_bd);         //kainui
     printf("Client bd addr : %02X:%02X:%02X:%02X:%02X:%02X\n",
                remote_bd[0], remote_bd[1], remote_bd[2],
                remote_bd[3], remote_bd[4], remote_bd[5]);

  }
  else if (strncmp(buf, "read_remote_bd_rf", 17) == 0)
  {

     unsigned char line;
     line = GET_LINE(0);
     printf("line is %d\n",line);
     printf("Client bd addr(Before) : %02X:%02X:%02X:%02X:%02X:%02X\n",
                remote_bd[0], remote_bd[1], remote_bd[2],
                remote_bd[3], remote_bd[4], remote_bd[5]);
     read_remote_bd(bt_cfd,line,remote_bd);         //kainui
     printf("Client bd addr : %02X:%02X:%02X:%02X:%02X:%02X\n",
                remote_bd[0], remote_bd[1], remote_bd[2],
                remote_bd[3], remote_bd[4], remote_bd[5]);

  }
  else if (strncmp(buf, "get_role",8) ==0)
  {
        if (role == SERVER) printf("Role is Server. %d\n",role);
        else if (role == CLIENT) printf("Role is Client. %d\n",role);
  }
  else if (sscanf(buf, "remote_friendly_name %x:%x:%x:%x:%x:%x",
		 &bd[0], &bd[1], &bd[2], &bd[3], &bd[4], &bd[5]) ==6)
  {
        u8* remote_friendly_name = "";

        int num_device_con;

        num_device_con = get_num_device_con();
        printf("num_device_con => %d\n",num_device_con);
        if (num_device_con>0)
        {
              for (i = 0; i < 6; i++)
              {
                   tmp_bd[i] = (unsigned char)bd[i];
              }
              remote_friendly_name = (unsigned char*)get_device_con_friendly_name(tmp_bd);
              printf("remote friendly name is %s\n",remote_friendly_name);
        }
        else printf("cannot get remote friendly name\n ");
  }
  else if (strncmp(buf, "friendly_name",13) ==0)
  {
        unsigned char friendly_name[20];
        get_my_friendly_name(friendly_name);
        printf("friendly_name is %s\n",friendly_name);
  }
  else if (sscanf(buf, "change_friendly_name %s",st) ==1)
  {
        change_friendly_name(st);
  }
  else if(sscanf(buf, "role_switch %x:%x:%x:%x:%x:%x %d ",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5], &tmp[6]) == 7)
  {

          unsigned char tmp_bd[6];
	  for (i = 0; i < 6; i++)
	  {
		  tmp_bd[i] = (unsigned char)tmp[i];
	  }
	  role_switch(bt_cfd, &tmp_bd[0], tmp[6]);
          printf("role is %d\n",role);
  }
  else if(sscanf(buf, "con_for_service %x:%x:%x:%x:%x:%x %d",
		 &bd[0], &bd[1], &bd[2], &bd[3], &bd[4], &bd[5], &profile) ==7)
  {
    int check;
    unsigned char tmp_bd2[6];
    for (i = 0; i < 6; i++)
    {
      tmp_bd[i] = (unsigned char)bd[i];
    }

    printf("Connecting SDP to bd : %02X:%02X:%02X:%02X:%02X:%02X\n",
           tmp_bd[0], tmp_bd[1], tmp_bd[2],
           tmp_bd[3], tmp_bd[4], tmp_bd[5]);

    sdp_id = sdp_connect_req(tmp_bd, 0);
    check = 0;
    while ((i<num_device)&&(check==0))
    {
           change_str_to_addr(device_list[i].bd_addr,tmp_bd2);
           check = compare_addr(tmp_bd,tmp_bd2);
           i++;
    }
    if (check==1)
        if (device_list[i-1].status == 0)
                device_list[i-1].status = 2;
        else if (device_list[i-1].status == 1)
                device_list[i-1].status = 3;
    printf("sdp_id = %d\n",sdp_id);
  }

  else if (sscanf(buf, "con_to_send_data %x:%x:%x:%x:%x:%x %d %d",
	     &tmp[0], &tmp[1], &tmp[2],
	     &tmp[3], &tmp[4], &tmp[5],
	     &tmp[6], &tmp[7]) == 8)
  {
    con_to_send_data(&tmp);
  }
  else if (sscanf(buf, "send_data %s %d %d", st, &repeat, &line) == 3)
  {
        send_data(st,repeat,line);

  }
  else if (sscanf(buf, "send_data_disc %d", &line) == 1)
  {
     send_data_disc(line);
  }
  else if (strncmp(buf, "sdp_disc", 8) == 0)
  {
        sdp_shutdown();
  }
  else if (strncmp(buf, "disc", 4) == 0)
  {
    disc_req();
  }

  else if (strncmp(buf, "stat", 4) == 0)
  {

    char tmp[4096];
    int len;
    len = bt_read_internal(tmp);        //bt_proc.c
    tmp[len] = 0;
    printf("%s", tmp);
  }
  else if (!strncmp(buf, "quit", 4))
  {
    return QUIT_BTD;
  }
  else if (strncmp(buf,"read_class_of_device",20)==0)
  {
        hci_read_class_of_device();
  }
  else if (sscanf(buf, "sdp_send_data %s %d", st ,&sdp_id) == 2)
  {
        bt_sdp_write_top(sdp_id,st);
  }
  else if (strncmp(buf, "sdp_get_data", 12) == 0)
  {
        bzero((unsigned char *) &st, sizeof(st));
        st = sdp_get_data();
        printf("sdp_get_data => %s\n",st);
  }
  else if (strncmp(buf, "rfcomm_get_data", 15) == 0)
  {
        bzero((unsigned char *) &st, sizeof(st));
        st = rfcomm_get_data();
        printf("rfcomm_get_data => %s\n",st);
  }
  else if (strncmp(buf, "apps_page1", 10) == 0)
  {
        apps_page1();
  }
  else if (strncmp(buf, "apps_page2", 10) == 0)
  {
        apps_page2();
  }
  else if (strncmp(buf, "apps_page3", 10) == 0)
  {
        apps_page3();
  }

/***********************Application*******************************/
  else if (strncmp(buf, "chat", 4) == 0)
  {
        printf("start chat(client)\n");
        chat();
  }

  else if (strncmp(buf, "start",5)==0)     //start chat
  {
        printf("start chat(server)\n");
        chat();
  }

/*****************************************************************/

#endif /* BTD_USERSTACK */
  else
  {
    printf("> error: command not recognized or wrong syntax\n");
    show_menu();
  }

  return 0;
}
/*************************************(end function)*******************************/

/*
 * Set server_name to the numerical IP of eth0 instead of using DNS or
 * relying on /etc/hosts being correct. for now.
 */
char* get_local_addr(void)
{
  char *local_address = NULL;
  int fd = socket(AF_INET, SOCK_DGRAM, 0);
  struct ifreq ifr;

  ifr.ifr_addr.sa_family = AF_INET;
  strcpy(ifr.ifr_name, "eth0");
  ioctl(fd, SIOCGIFADDR, (int)&ifr);
  close_device(fd);
  local_address = strdup(inet_ntoa(((struct sockaddr_in *)
				    &ifr.ifr_addr)->sin_addr));

  if (!local_address)
  {
    printf("could not determine local IP address!\n");
  }
  return local_address;
}


void set_local_name(const char *local_name)
{
  unsigned char domainname[DOMAIN_NAME_LENGTH+1];
  unsigned char buf[LOCAL_NAME_LENGTH+HOST_NAME_LENGTH+DOMAIN_NAME_LENGTH+5];
  int len = 0;

  *buf = '\0';
  *domainname = '\0';

  if (*local_name)
  {
    while (*local_name && len < LOCAL_NAME_LENGTH)
    {
      if (*local_name >= ' ' && *local_name <= 'z')
      {
        buf[len++] = *local_name++;
      }
    }

    if (len)
    {
      buf[len++] = ' ';
      buf[len++] = '(';
      buf[len] = '\0';
    }
  }

  gethostname(&buf[len], HOST_NAME_LENGTH);

  if (!strchr(&buf[len], '.'))
  {
    getdomainname(domainname, DOMAIN_NAME_LENGTH);
    if (*domainname)
    {
      strcat(buf, ".");
      strcat(buf, domainname);
    }
  }

  if (len)
  {
    strcat(buf, ")");
  }

#ifndef BTD_USERSTACK
  if (ioctl(bt_cfd, HCISETLOCALNAME, buf) < 0)
  {
    perror("HCI set local name");
    exit(1);
  }
#else
  hci_change_local_name(buf);
#endif
}

void init_stack(int spd)
{
  printf("Init stack\n");

#ifdef BTD_USERSTACK
  /* Direct function calls instead of ioctls... */

  init_read_thread();

  /* Initialise all layers in the bluetooth stack */
  DSYS("Initialising Bluetooth Stack\n");

  hci_init();
  l2cap_init();
  rfcomm_init();

  sdp_init(role);
  tcs_init();
  test_init();
  btmem_init();
  bt_stat.bytes_received = 0;
  bt_stat.bytes_sent = 0;

  bt_initdone = 1;

#else /* Kernel mode stack */

  /* FIXME -- add ioctls for all hci functions */

  if (ioctl(bt_cfd, BTINITSTACK)<0)
  {
    perror("Init stack");
    exit(1);
  }

#endif

  /* FIXME: Maybe we should read this parameters from somwhere... */
  bt_set_classofdevice(bt_cfd, 0x10, 0x3, 0x0, 0x0);

#ifndef __CRIS__
  set_local_name(local_name);
#endif

  if (hw_init)
    init_hw(spd);
}


void shutdown_stack(void)
{
  syslog(LOG_INFO, "Shutting down bluetooth stack\n");
#ifndef BTD_USERSTACK
  if (bt_cfd != -1 && (ioctl(bt_cfd, BTSHUTDOWN) < 0))
  {
    syslog(LOG_ERR, "Shutting down stack failed (bt_cfd = %d)", bt_cfd);
  }
#else
  if (bt_initdone)
  {
    rfcomm_close();
    sdp_shutdown();
    tcs_shutdown();
    l2cap_shutdown();
    btmem_shutdown();
    bt_initdone = 0;
  }
#endif

  btd_killchilds();

}

int open_device(char* dev, int flags, int role)
{
  int fd;

#ifdef BTD_USERSTACK
  /* if opening bt dev or control dev simply discard and return fake fd */
  if ((strcmp(dev, btdev) == 0) || (strcmp(dev, BT_CTRL_TTY) == 0))
    return 0xb055e;

  if (use_local_socket)
    return open_socket(dev, role);
  else if (use_tcp_socket)
    return open_tcpsocket(dev, role);
#endif

  syslog(LOG_INFO, "Opening dev %s\n", dev);
  if ((fd = open(dev, flags | O_NOCTTY)) < 0)
  {
    perror("open_device");
    exit(1);
  }

  tcflush(fd, TCIOFLUSH);
  return fd;
}

void close_device(int fd)
{
  syslog(LOG_INFO, "close_device");

#ifdef BTD_USERSTACK
  /* if fake fd is used, ignore close since there are no open fd */
  if (fd != 0xb055e)
    close(fd);
#else
  if (fd != -1)
    close(fd);
#endif
}


//#define PALM_FIX

#ifdef PALM_FIX
int
search_str(char *data, const char *searchstr)
{
  int cur = 0;
  int len = strlen(data);

  if (len < 0)
    return 0;

  while (cur < (len-strlen(searchstr)))
  {
    if(!strncasecmp(data+cur, searchstr, strlen(searchstr)))
    {
      /* found searchstr */
      //printf("search_str : found %s!\n", (char*)search_str);
     return 1;
    }
    cur++;
  }
  return 0;
}
#endif

int
parse_modem_data(char *databuf, int len, int bt_fd)
{
  int i;
  syslog(LOG_INFO, "parse_modem_data : %d chars", len);
  databuf[len] = 0;
  syslog(LOG_INFO, "data : %s", databuf);

  if (len <= 0)
  {
    if (btd_shuttingdown)
      return SHUTDOWN;
    else
      return RESTART;
  }

  /* Check if data is a ppp frame, if so start pppd right away
     and hope we catch a retransmission */

  for (i = 0; i < len; i++)
  {
    if (databuf[i] == PPP_DELIMITER)
    {
      /* fixme<3> -- check prot field + LCP code for conf req aswell
         we are also depening on a non-fragmented ppp frame i.e the
         delimiter comes in the same chunk as the rest... */

      if ((len - i) >= 7)
      {
	if (((databuf[i+7]^0x20) == PPP_TERM_REQ))
        {
          syslog(LOG_INFO, "Found PPP Terminate don't start pppd");
          return RESTART;
        }
      }
      return DO_PPP;
    }
  }

  if(!strncasecmp(databuf, "ATD", 3)) /* windows standard modem */
  {
    syslog(LOG_INFO, "got ATD");
    return CONNECT;
  }
  else if(!strncasecmp(databuf, "CLIENT", 6)) /* windows null modem */
  {
    syslog(LOG_INFO, "got CLIENT");
    return NULLCONNECT;
  }
#ifdef PALM_FIX
  else if (search_str(databuf, "DT")) /* palm */
  {
    syslog(LOG_INFO, "found DT");
    return CONNECT;
  }
#endif
  else if (!strncasecmp(databuf, "HELLO", 5)) /* windows null modem */
  {
    syslog(LOG_INFO, "got HELLO");
    return HELLOCONNECT;
  }
  else if (!strncasecmp(databuf, "AT", 2)) /* AT command */
  {
    return SEND_OK;
  }
  else
    return SEND_OK;
}

void modem_emulator(int bt_fd, char *data, int len)
{
  int done = 0;
  /* FIXME -- adjust this to real speed */
  char *connect = "CONNECT 115200\r\n";
  char *client_server = "CLIENTSERVER\r\n";
  char *ok = "OK\r\n";
  char *hello = "HELLO\r\n";

#ifdef BTD_USERSTACK
  if ((bt_fd == 0xb055e) && (len > 0))
  {
    data[len] = 0;
    done = parse_modem_data(data, len, bt_fd);

    if (done == CONNECT)
    {
#ifdef PALM_FIX
      sleep(2); /* wait for client */
#endif
      syslog(LOG_INFO, "Write : %s", connect);
      bt_write_top(connect, strlen(connect), 0);
      syslog(LOG_INFO, "Modem connected !");
      modem_connected = 1;
    }
    else if (done == NULLCONNECT)
    {
      bt_write_top(client_server, strlen(client_server),0);
      syslog(LOG_INFO, "Nullmodem connected !");
      modem_connected = 1;
    }
    else if (done == RESTART)
    {
      /* If we got a SIGHUP from kernel reopen btdev */
      syslog(LOG_INFO, "Restart modem emulator...");
      close_device(bt_fd);
      bt_fd = open_device(btdev, O_RDWR, 0);
      done = 0;
    }
    else if (done == HELLOCONNECT)
    {
      bt_write_top(hello, strlen(hello), 0);
      syslog(LOG_INFO, "Hellomodem connected !");
      modem_connected = 1;
    }
    else if (done == DO_PPP)
    {
      syslog(LOG_INFO, "LAN Access no CLIENT - CLIENTSERVER");
      modem_connected = 1;
    }
    else if (done == SEND_OK)
    {
      syslog(LOG_INFO, "Modem emulator replies %s", ok);
      bt_write_top(ok, strlen(ok), 0);
    }
    else
    {
      syslog(LOG_INFO, "LAN Access no CLIENT - CLIENTSERVER");
      modem_connected = 0;
    }
  }
  /* return and possibly wait for new modem data
     (is fed from bt_receive_top) */
  return;

#else /* BTD_USERSTACK */

  fd_set rfd;
  char databuf[128];

  while (!modem_connected)
  {
    FD_ZERO(&rfd);
    FD_SET(bt_fd, &rfd);

    select(FD_SETSIZE, &rfd, NULL, NULL, NULL);

    if (FD_ISSET(bt_fd, &rfd))
    {
      int len = read(bt_fd, &databuf, 128);

      databuf[len] = 0;
      done = parse_modem_data(databuf, len, bt_fd);

      if (done == CONNECT)
      {
#ifdef PALM_FIX
	sleep(2); /* wait for client */
#endif
	syslog(LOG_INFO, "Write : %s", connect);
	write(bt_fd, connect, strlen(connect));
        syslog(LOG_INFO, "Modem connected !");
        modem_connected = 1;
      }
      else if (done == NULLCONNECT)
      {
        write(bt_fd, client_server, strlen(client_server));
        syslog(LOG_INFO, "Nullmodem connected !");
        modem_connected = 1;
      }
      else if (done == RESTART)
      {
        /* If we got a SIGHUP from kernel reopen btdev */
        syslog(LOG_INFO, "Restart modem emulator...");
        close_device(bt_fd);
        bt_fd = open_device(btdev, O_RDWR, 0);
        done = 0;
      }
      else if (done == SHUTDOWN)
      {
        syslog(LOG_INFO, "Shutting down modem emulator\n");
        return;
      }
      else if (done == HELLOCONNECT)
      {
        write(bt_fd, hello, strlen(hello));
        syslog(LOG_INFO, "Hellomodem connected !");
        modem_connected = 1;
      }
      else if (done == DO_PPP)
      {
        syslog(LOG_INFO, "LAN Access no CLIENT - CLIENTSERVER");
        modem_connected = 1;
      }
      else if (done == SEND_OK)
      {
        syslog(LOG_INFO, "Modem emulator replies %s", ok);
        write(bt_fd, ok, strlen(ok));
      }
      else
      {
	syslog(LOG_INFO, "Modem emulator replies OK");
	write(bt_fd, ok, strlen(ok));
      }
    }
  }
#endif
}


static void
btd_cleanup(void)
{
  btd_killchilds();

  shutdown_stack();

  if (bt_fd != -1)
  {
    close_device(bt_fd);
    bt_fd = -1;
  }

  if (bt_cfd != -1)
  {
    close_device(bt_cfd);
    bt_cfd = -1;
  }

  /* now close phys device */
  if (phys_fd != -1)
  {
    tcflush(phys_fd, TCIOFLUSH);
    close_device(phys_fd);
    phys_fd = -1;
  }

  /* pid_fd is set if we created the pid file when we started */
  if (pid_fd != -1)
  {
    unlink(PID_FILE);
  }
}


static void
btd_killchilds(void)
{
  if (sdpsrv_pid > 0 && role == SERVER)
  {
    syslog(LOG_INFO, "Killing SDP server\n");
    kill(sdpsrv_pid, SIGTERM);
    if (waitpid(sdpsrv_pid, NULL, 0) < 0)
      perror("waitpid sdp server");

    sdpsrv_pid = 0;
  }

  if (pppd_pid > 0)
  {
    syslog(LOG_INFO, "Killing pppd\n");
    kill(pppd_pid, SIGTERM);
    if (waitpid(pppd_pid, NULL, 0) < 0)
      perror("waitpid pppd");
    pppd_pid = 0;
  }
}


const char*
signame(int sig)
{
  switch (sig)
  {
  case SIGHUP:
    return "SIGHUP";
    break;

  case SIGINT:
    return "SIGINT";
    break;

  case SIGCHLD:
    return "SIGCHLD";
    break;

  case SIGQUIT:
    return "SIGQUIT";
    break;

  case SIGTERM:
    return "SIGTERM";
    break;

  default :
    return "Unknown signal";
  }
}


static void
btd_sighandler(int sig)
{
#ifdef __CRIS__
  if (sig == SIGUSR1)
  {
#ifdef RESTART_ENABLED
    printf("resetting hw to activate bd change\n");
    btd_killchilds();
    shutdown_stack();
    close_device(bt_fd);
    close_device(bt_cfd);
    close_device(phys_fd);
    bt_fd = -1;
    bt_cfd = -1;
    phys_fd = -1;
    reset_hw();
    siglongjmp(jmpbuffer, 1);
#else
    printf("reset HW to activate bd change\n");
    return;
#endif
  }
#endif /* __CRIS__ */

  if (btd_shuttingdown)
  {
    syslog(LOG_INFO, "Why are we getting more than one signal here ?\n");
    return;
  }

  btd_shuttingdown = 1;

  exit(0);
}


static void
init_sighandler(void)
{
  struct sigaction act;

  syslog(LOG_INFO, "Initiating signal handler\n");
  act.sa_handler = btd_sighandler;
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  sigaction(SIGHUP, &act, 0);
  sigaction(SIGINT, &act, 0);
  sigaction(SIGQUIT, &act, 0);
  sigaction(SIGTERM, &act, 0);
#ifdef __CRIS__
  sigaction(SIGUSR1, &act, 0);
#endif
}

//#define BTD_USERSTACK
#ifdef BTD_USERSTACK

/*
 * USER STACK FUNCTIONS (instead of bluetooth.c)
 */

int init_read_thread(void)
{
  printf("Initiating read thread\n");
  if (pthread_create(&read_thread, NULL,
                     (void*)hci_receive_thread, NULL)!=0)
    perror("pthread_create");

  return 0;
}

void hci_receive_thread(void)
{
  fd_set rfd;
  char databuf[4096];

  printf("hci_receive_thread\n");
  while (1)
  {
    FD_ZERO(&rfd);
    FD_SET(phys_fd, &rfd);

    select(phys_fd+1, &rfd, NULL, NULL, NULL);

    if (FD_ISSET(phys_fd, &rfd))
    {
      int len = read(phys_fd, &databuf, 4096);

      if (len > 0)
      {
	BT_DATA("-->|X|    %3d\n", len);
	PRINTPKT("data rec : ", databuf, len);
	hci_receive_data(databuf, len);
      }
    }
  }
}

/*
 * Allocate a pty master-slave pair.
 */
int open_pty(void)
{
  struct termios settings;
  int result;


  printf("Open pty.\n");
  result = openpty(&pty_master_fd, &pty_slave_fd, ptydev, NULL, NULL);
  if (result < 0)
  {
    perror("openpty");
    return result;
  }

  /* modify pty settinges -> turn off echo - mfuchs */
  result = tcgetattr(pty_master_fd, &settings);
  if (result < 0)
  {
    perror("tcgetattr");
    return result;
  }

  cfmakeraw(&settings);
  settings.c_lflag &= ~ECHO;

  result = tcsetattr(pty_master_fd, TCSANOW, &settings);
  if (result < 0)
  {
    perror("tcsetattr");
    return result;
  }
  return 0;
}

/* Create a thread that reads data from the pty and
   passes it to the rfcomm layer */
int init_pty_thread(void)
{
  printf("Initiating pty thread\n");
  if (pthread_create(&pty_thread, NULL,
                     (void*)pty_receive_thread, NULL)!=0)
    perror("pthread_create");
  sleep(1); /* wait for thread to start */
  return 0;
}

void pty_receive_thread(void)
{
  fd_set rfd;
  char databuf[4096];

  while (1)
  {
    FD_ZERO(&rfd);
    FD_SET(pty_master_fd, &rfd);

    select(pty_master_fd+1, &rfd, NULL, NULL, NULL);

    if (FD_ISSET(pty_master_fd, &rfd))
    {
      int len = read(pty_master_fd, &databuf, 4096);

      if (len > 0)
      {
	bt_write_top(databuf,len,0);
      }
    }
  }
}

int bt_write_lower_driver(unsigned char *data, int len)
{
  int i;

  BT_DATA("<--|X|    %3d\n", len);

  PRINTPKT("bt_write_lower_driver ", data, len);
  i = write(phys_fd, data, len);
  return i;
}


/* Only works for the last connected rfcomm session */
int
bt_write_top(char *buf, int count, int line)               //set bytes_sent (may be)
{                                                           //buf is data
  int retval;
  int bytes_sent = 0;
  unsigned int con_id;

  printf("bt_write_top : try sending data on last connected ch\n");

  BT_DATA("   |X|<-- %3d [%d]\n", count, line);

  while (bytes_sent!=count)
  {
    con_id = CREATE_RFCOMM_ID(line,test_dlci);
    printf("con_id : %d\n",con_id);
    retval = rfcomm_send_data(con_id,
			      buf + bytes_sent, count-bytes_sent);

    printf("retval = %d\n",retval);
   if (retval > 0)
      bytes_sent+=retval;
    else if (retval==0)
      usleep(100000); /* wait some ... */
   else
   {
     printf("error\n");
     return retval;
   }
    usleep(1000); /* wait some time ... */
  };

  bt_stat.bytes_sent+=bytes_sent;

  return bytes_sent;
}

int bt_receive_top(unsigned int con_id, unsigned char *data, int len)
{
  int n;
  int i=0;
  char tmp[200];

  printf("data : %s\n",data);

  BT_DATA("   |X|--> %3d [%d]\n", len, GET_LINE(con_id));

  if (!strncmp(data, "001chat", 7))
  {
                printf("rfcomm recevice data (001chat) => %d %s\n",len,data);
                for (i=0;i<200;i++)
                        tmp[i] = '\0';
                //for (i=0; i<(strlen(data)-7);i++)
                for (i=0; i<(len-7);i++)
                        tmp[i] = data[i+7];
                chat_receive(tmp);
  }
  else
  {
  if (modem_emulation && !modem_connected)
  {
    modem_emulator(0xb055e, data, len);
    return len;
  }

  /* feed this to PTY connected to pppd or whatever application
     that may be running there... */


  if ((n = write(pty_master_fd, data, len)) != len)
  {
    BT_DATA("bt_receive_top: tried to write %d bytes, wrote %d\n", len, n);
  }


  }
  bt_stat.bytes_received+=n;
  return n;

}

/******************kainui add*********************/
unsigned char bt_sdp_get_line(void)
{
        unsigned char line;
        line = sdp_get_line();
        return line;
}

unsigned char* rfcomm_get_data(void)
{
        return msg;
}

/*This function used to test text mode before integrate with graphic mode. appplication page1*/
void apps_page1(void)
{
        char *line;
        int i = 0;
        int ii;
        int check = 0;

        num_tmp_device = 0;

        find_all_device(1,8,1);      //inquiry and connect sdp
        show_tmp_device_bak();
        /*get friendly name that wanted to search service*/
        if (num_tmp_device>0)
        {
                line = readline("select device> ");
                while ((i<num_tmp_device)&&(check==0))
                {
                        printf("find device that wanted to search service\n");
                        if ((ii = strcmp(tmp_device_list[i].friendly_name,line)) == 0)
                                check = 1;
                        i++;
                }
                service_browse_req(i-1);
                sleep(1);
                show_tmp_service_bak(i-1);
                line = readline("do u want to add> ");
                if ((strcmp(line,"add"))==0)
                {
                        add_new_device_req(i-1);
                        add_new_device(i-1);
                }
                else printf("not add device\n");
        }
        else printf("no device in range.\n");
}

/*This function used to test text mode before integrate with graphic mode. appplication page2*/
void apps_page2(void)
{
        char *line;
        int check=0;
        int i=0;
        int ii = 0;

        check_connect();
        find_all_device(1,4,2);
        //check_online_offline();
        line = readline("select device> ");
        while ((i<num_device)&&(check==0))
        {
                printf("find device that wanted to search service\n");
                if ((ii = strncmp(device_list[i].friendly_name,line,strlen(line))) == 0)
                        check = 1;
                i++;
        }
        if (check==1) //have in database
        {
                if (device_list[i-1].status!=0) //online
                {
                        show_service_bak(i-1);
                        line = readline("select service> ");
                        if (!strncmp(line,"chat",4))
                        {
                                printf("run application chat\n");
                        }
                        else if (!strncmp(line,"file",4))
                        {
                                printf("run application file transfer\n");
                        }
                        else printf("cannot run this application\n");
                }
                else printf("have in databse but it's offline.\n");
        }
        else printf("not have in database.\n");

}

/*This function used to test text mode before integrate with graphic mode. appplication page3*/
void apps_page3(void)
{
        char *line1,*line2;
        char st1[20],st2[20];
        int i = 0;
        int ii = 0;
        int check = 0;
        int j = 0;

        line2 = readline("specific device or service> ");
        line1 = readline("specific name> ");

        for (j=0; j<20; j++)
                st1[j] = '\0';
        for (j=0; j<strlen(line1); j++)
        {
                if (isupper(line1[j])!=0)
                        st1[j] = tolower(line1[j]);
                else st1[j] = line1[j];
        }
        num_tmp_device = 0;

        find_all_device(1,8,1);      //inquiry and connect sdp
        show_tmp_device_bak();
        i=0;
        while (i<num_tmp_device)
        {
                if ((ii = strncmp(line2,"device",6)) == 0)
                {
                        find_specific_device(i,st1);

                }
                else if ((ii = strncmp(line2,"service",7)) == 0)
                {
                        find_specific_service_bak(i,st1);

                }
                i++;
        }
        line1 = readline("select device name> ");
        printf("device_name = %s\n",line1);
        line2 = readline("do u want to add> ");
        printf("add = %s\n",line2);

        /*add device into list*/
        if ((ii = strncmp(line2,"add",3)) == 0)
        {
                show_tmp_device_bak();
                printf("i (show_tmp_service) = %d\n",i-1);
                show_tmp_service_bak(i-1);
                add_new_device_req(i-1);
                add_new_device(i-1);
        }
        else ("not add device\n");
}

/*This function used to show service for test mode*/
void show_service_bak(int device_id)
{
        int i = 0;
        int check = 0;
        int ii = 0;
        int j = 0;

        printf("show_service\n");
        if (device_list[device_id].num_service==0)
        {

                printf("num_tmp_device = %d\n",num_tmp_device);
                while ((i<num_tmp_device)&&(check==0))
                {
                        if ((ii = strncmp(tmp_device_list[i].bd_addr,device_list[device_id].bd_addr,17)) == 0)
                                check = 1;
                        i++;
                }
                if (check==1)  j = i-1;
                else j = 0;
                {
                        service_browse_req(j);
                        sleep(1);
                        device_list[device_id].num_service = tmp_device_list[j].num_service;
                        for (ii=0;ii<device_list[device_id].num_service;ii++)
                        {
                                strcpy(device_list[device_id].service_list[ii].service_record_handle,tmp_device_list[j].service_list[ii].service_record_handle);
                                strcpy(device_list[device_id].service_list[ii].service_classID_list,tmp_device_list[j].service_list[ii].service_classID_list);
                                strcpy(device_list[device_id].service_list[ii].protocol_descriptor_list,tmp_device_list[j].service_list[ii].protocol_descriptor_list);
                                strcpy(device_list[device_id].service_list[ii].browse_group_list,tmp_device_list[j].service_list[ii].browse_group_list);
                                strcpy(device_list[device_id].service_list[ii].bt_profile_descriptor_list,tmp_device_list[j].service_list[ii].bt_profile_descriptor_list);
                                strcpy(device_list[device_id].service_list[ii].service_name,tmp_device_list[j].service_list[ii].service_name);
                                strcpy(device_list[device_id].service_list[ii].service_description,tmp_device_list[j].service_list[ii].service_description);
                                strcpy(device_list[device_id].service_list[ii].groupID,tmp_device_list[j].service_list[ii].groupID);

                        }
                }
        }
        i = 0;
        while (i<device_list[device_id].num_service)
        {
                printf("service %d is %s\n",i+1,device_list[device_id].service_list[i].service_name);
                i++;
        }
}


void add_new_device_res(int device_id)
{

        service_browse_req(device_id);
        sleep(1);
        show_tmp_service_bak(device_id);

}

/*************************************************/

void
bt_connect_ind(unsigned int con_id)
{
  DSYS("Got connect indication on PSM %d\n", GET_PSM(con_id));
}

void
bt_connect_cfm(unsigned int con_id, int status)
{
  unsigned short psm;
  int line;

  psm = GET_PSM(con_id);

  printf("con_id : %d\n",con_id);
  if (status) {
    /* fixme -- only works for rfcomm now */
    line = GET_LINE(con_id);

    if ((line < 0) || (line > BT_NBR_DATAPORTS)) {
      printf("bt_connect_cfm on invalid line (%d)\n", line);
      return;
    }
    printf("bt_connect_cfm : failed, status %d [%s] line %d\n", status, psmname(psm), line);
    return;
  }

  switch (psm) {
  case RFCOMM_LAYER:
    printf("bt_connect_cfm [%s]\n", psmname(psm));
    break;

  case SDP_LAYER:
    printf("bt_connect_cfm [%s]\n", psmname(psm));
    break;

  case TCS_LAYER:
    printf("bt_connect_cfm [%s]\n", psmname(psm));
    break;

  default:
    printf("bt_connect_cfm : unknown layer %d\n", psm);
    break;
  }
}

void
bt_disconnect_ind(unsigned int con_id)
{
  DSYS("Got disconnect indication on PSM %d\n", GET_PSM(con_id));
}


int
bt_register_rfcomm(struct rfcomm_con *rfcomm, u8 dlci)
{
  test_rfcomm = rfcomm;
  test_dlci = dlci;
  return 0;
}

int bt_register_sdp(u8 line)
{
  return 0;
}

int bt_unregister_sdp(u8 line)
{
  return 0;
}

int bt_initiated(void)
{
  return bt_initdone;
}

int bt_use_bcsp(int new_use_bcsp)
{
  return 0;
}

int bt_dfu_mode(int new_dfu_mode)
{
  return 0;
}

/* TCP socket */
static int open_tcpsocket(char *addrstr, int role)
{
  int server_sockfd;
  struct sockaddr_in server_address;
  int client_sockfd;
  struct sockaddr_in client_address;

  int server_len;
  int client_len;
  int port;
  char ipstr[16];
  char *pos;
  
  /* parse address string */

  if (!(pos = strchr(addrstr, ':')))
  {
    fprintf(stderr, "Port argument missing!\n");
    exit(1);
  }

  /* copy ip address */
  *pos = '\0';
  strncpy(ipstr, addrstr, sizeof ipstr);
  ipstr[sizeof ipstr - 1] = '\0';

  /* extract port number */
  port = atoi(pos+1);

  if (role == SERVER)
  {
    /* open socket */
    server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    server_address.sin_family = AF_INET;

    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(port);

    server_len = sizeof(server_address);

    if (bind(server_sockfd, (struct sockaddr *)&server_address, server_len))
    {
      perror("bind");
      exit(1);
    }

    if (listen(server_sockfd, 5))
    {
      perror("listen");
      exit(1);
    }

    /* request for a new connection */
    client_sockfd = accept(server_sockfd,
			   (struct sockaddr *)&(client_address),
			   &client_len);
  }
  else
  {
    /* Client */

    printf("Connecting to TCP server socket [%s:%d]\n", ipstr, port);

    /* open socket */
    client_sockfd = socket(AF_INET, SOCK_STREAM, 0);

    /* destination address */
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(ipstr);
    server_address.sin_port = htons(port); /* for example... */
    server_len = sizeof(server_address);

    if (connect(client_sockfd, 
		(struct sockaddr *)&server_address, 
		server_len) < 0) {
      perror("open_tcpsocket");
      exit(1);
    }
  }

  return client_sockfd;
}

#endif /* BTD_USERSTACK */

/* Local UNIX socket stuff */
static int open_socket(char *name, int role)
{
  int server_sockfd;
  struct sockaddr_un server_address;
  int client_sockfd;
  struct sockaddr_un client_address;
  int server_len;
  int client_len;

  syslog(LOG_INFO, "Opening socket %s ", name);
  if (role == SERVER)
  {
    /* remove any old socket */
    unlink(name);

    /* open socket */
    server_sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
    server_address.sun_family = AF_UNIX;
    strcpy(server_address.sun_path, name);
    server_len = sizeof(server_address);
    bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
    listen(server_sockfd, 5);
    client_sockfd = accept(server_sockfd,
                           (struct sockaddr *)&(client_address),
                           &client_len);
  }
  else
  {
    /* Client */
    client_sockfd = socket(AF_UNIX, SOCK_STREAM, 0);

    /* 'destination' socket */
    server_address.sun_family = AF_UNIX;
    strcpy(server_address.sun_path, name);
    server_len = sizeof(server_address);

    if (connect(client_sockfd,
                (struct sockaddr *)&server_address,
                server_len) < 0) {
      syslog(LOG_ERR, "open_socket %s failed", name);
      return -1;
    }

    syslog(LOG_INFO, "Socket connected to %s\n", server_address.sun_path);
  }

  return client_sockfd;
}

#ifdef USE_IPASSIGN

struct ipa_client* ipa_send(ipa_request *req)
{
  int len;
  struct ipa_client *rsp = NULL;

  syslog(LOG_INFO, "Opening socket to IP Assigner\n");

  if ((ipa_sock = open_socket(SRVSOCKET, CLIENT)) < 0)
  {
    perror("open_socket");
    return NULL;
  }

  syslog(LOG_INFO, "ipa_send : sending ipa request\n");
  write(ipa_sock, req, sizeof(struct ipa_request));

  syslog(LOG_INFO, "ipa_send : listening for incoming responses");

  len = read(ipa_sock, &ipa_buf, 128);

  /* FIXME -- clean up */

  if(!strncasecmp((char *)&ipa_buf, "OK", 2))
  {
    syslog(LOG_INFO, "ipa_send : request succeeded");
    syslog(LOG_INFO, "ipa_send : closing ipa socket");
    close(ipa_sock);
    return (struct ipa_client *)ipa_buf; /* FIXME !*/
  }
  else if(!strncasecmp((char *)&ipa_buf, "ERROR", 5))
  {
    syslog(LOG_INFO, "ipa_send : request failed");
    syslog(LOG_INFO, "ipa_send : closing ipa socket");
    close(ipa_sock);
    return (struct ipa_client *)NULL;
  }
  else if (len == sizeof(struct ipa_client))
  {
    syslog(LOG_INFO, "ipa_send : request succeeded");
    rsp = (struct ipa_client*)ipa_buf;
  }

  syslog(LOG_INFO, "ipa_send : closing ipa socket");
  close(ipa_sock);
  return rsp;
}


void ipa_getpars(void)
{
  unsigned char local_bd[6];
  unsigned char remote_bd[6];
  char *ms_dns = NULL;
  char *ms_dns2 = NULL;
  char *ms_wins = NULL;
  char *ms_wins2 = NULL;
  struct ipa_client *client;

  read_local_bd(bt_cfd, local_bd);

  /* fixme -- for now only use line 0 */
  read_remote_bd(bt_cfd, 0, remote_bd);

  /*
   * Get options from IPAssigner
   */
  ipa_req.type = GETCLIENTIP;
  memcpy(&ipa_req.remote_bd, remote_bd, 6);

  syslog(LOG_INFO, "ipa_getpars sending req");

  /* send request */
  client = ipa_send(&ipa_req);

  if (client == NULL)
  {
    syslog(LOG_INFO, "Failed to get client settings");
    sleep(3);

    /* Use noip if not set from btd option */
    if (!remote_address)
    {
      remote_address = strdup("");
    }   
    use_radius = 0;
    use_radius_ip_assign = 0;
    use_proxyarp = 1;
  }
  else 
  {
    a_client = *client;
    
    /* Set local values */
    use_proxyarp = a_client.proxyarp;
    use_radius = a_client.useradius;
    use_radius_ip_assign = a_client.useradiusip;

    if (!remote_address)
    {     
      remote_address = strdup(inet_ntoa(a_client.ip));
    }
    else
    {
      syslog(LOG_INFO, "remote_address already set from btd option!");
    }

    ppp_netmask = strdup(inet_ntoa(a_client.netmask));
    syslog(LOG_INFO, "Client IP : %s", remote_address);

    /* Since most clients should be able to receive the DNS configuration the 
       MS style we send them with ms-dns (if we got any)! */
    
    if(a_client.nbr_of_dns > 0)
    {
      ms_dns = "ms-dns";
      prim_dns = strdup(inet_ntoa(a_client.dns[0]));
      if(a_client.nbr_of_dns > 1)
      {
        ms_dns2 = "ms-dns";
        sec_dns = strdup(inet_ntoa(a_client.dns[1]));
      }
      printf("DNS used : prim: %s sec: %s\n", prim_dns?prim_dns:"none",
             sec_dns?sec_dns:"none");
      syslog(LOG_INFO, "DNS used : prim: %s sec: %s\n", prim_dns?prim_dns:"none", sec_dns?sec_dns:"none");
    }
    else
      syslog(LOG_INFO, "No DNS configured");

    if(a_client.nbr_of_wins > 0)
    {
      ms_wins = "ms-wins";
      prim_wins = strdup(inet_ntoa(a_client.wins[0]));
      if(a_client.nbr_of_wins > 1)
      {
        ms_wins2 = "ms-wins";
        sec_wins = strdup(inet_ntoa(a_client.wins[1]));
      }
      printf("MS WINS used : prim: %s sec: %s\n", prim_wins?prim_wins:"none",
             sec_wins?sec_wins:"none");
      syslog(LOG_INFO, "MS WINS used : prim: %s sec: %s\n", prim_wins?prim_wins:"none", sec_wins?sec_wins:"none");
    }
    else
      syslog(LOG_INFO, "No WINS configured");


    sprintf(local_bd_string, "%02X:%02X:%02X:%02X:%02X:%02X",
            local_bd[0], local_bd[1], local_bd[2],
            local_bd[3], local_bd[4], local_bd[5]);

    sprintf(remote_bd_string, "%02X:%02X:%02X:%02X:%02X:%02X",
            remote_bd[0], remote_bd[1], remote_bd[2],
            remote_bd[3], remote_bd[4], remote_bd[5]);

    syslog(LOG_INFO, "local bd %s, remote bd %s", local_bd_string, remote_bd_string);
  }
}

#endif /* USE_IPASSIGN */


void
set_bt_line_disc(int phys_fd, int bt_disc, char* physdev)
{
  if (ioctl(phys_fd, TIOCSETD, &bt_disc) < 0)
  {
    perror("Set bt line disc");
    printf("Forgot to insmod bt.o ? [bt_disc %d]\n", bt_disc);
    exit(1);
  }
  printf("Registered bluetooth line discipline on %s\n", physdev);
}

/* unique message status codes 32 bits : | layer 16 bits | code 16 bits | */

#define MSG_LAYER_HCI    0
#define MSG_LAYER_L2CAP  1
#define MSG_LAYER_RFCOMM 2
#define MSG_LAYER_SDP    4
#define MSG_LAYER_TCS    8

/* Result in responses in L2CAP */
#define RES_PSMNEG 0x02
#define RES_SECNEG 0x03
#define RES_NOSRC  0x04

const char *error_msg(int err)
{
  int layer = (err >> 16) & 0xffff;
  int code = err & 0xffff;

  switch (layer)
  {
  case MSG_LAYER_HCI:
    switch(code)
    {
    case 4:        
      return "HCI - Page Timeout";
    default:
      return "HCI - Unknown reason";
      break;
    }
    break;
    
   case MSG_LAYER_L2CAP:
     switch(code)
     {
     case RES_PSMNEG:
       return "L2CAP - PSM not valid";
     case RES_SECNEG:
       return "L2CAP - Security block";
     case RES_NOSRC:
       return "L2CAP - Remote side has no resources";
     default:
       return "L2CAP - unknown reason";
     }
     break;
    
  default:
    return "Unknown layer - unknown reason";
  }
}

const char* psmname(unsigned short psm)
{
  switch(psm)
  {
  case RFCOMM_LAYER:
    return "RCOMM";
  case SDP_LAYER:
    return "SDP";
  case  TCS_LAYER:
    return "TCS";
  default:
    return "UNKNOWN";
  }
}

void
bt_connect(int bt_fd, unsigned char *bd, unsigned int con_id)
{
  bt_connection con;
  int result;
	  
  memcpy(con.bd, bd, 6);

  /* only connects rfcomm (as client) currently */
  if (GET_PSM(con_id) == RFCOMM_LAYER)
    con.id = con_id;
  else
  {
    printf("Only connects rfcomm as client !\n");
    return ;
  }

#ifndef BTD_USERSTACK
  if ((result = ioctl(bt_fd, BTCONNECT, &con)))
    printf("Connect failed [%s ((%d))]\n", error_msg(result), result);
  else
    printf("Connected.\n");
#else
  {
    u8 srv_ch;
    u8 line;
    
    CHECK_RFCOMM(con_id);
    srv_ch = GET_RFCOMMSRVCH(con_id);
    line = GET_LINE(con_id);
 
    if (line != 0)
    {
      printf("Use line 0 instead ! (usermode only)\n");
      return;
    }

    printf("Connecting srv ch %d on line %d\n", srv_ch, line);
    result = rfcomm_connect_req(bd, srv_ch, line);		
  }
#endif
  return; //kainui
}

void
bt_disconnect(int bt_fd, unsigned int con_id)
{
#ifndef BTD_USERSTACK
  if (ioctl(bt_fd, BTDISCONNECT, &con_id) < 0)
  {
    perror("Disconnect");
    exit(1);
  }
#else
  /* fixme -- only works for rfcomm */
  u8 line;				

  CHECK_RFCOMM(con_id);
  line = GET_LINE(con_id);

  if (line != 0)
  {
    printf("Use line 0 instead ! (usermode only)\n");
    return;
  }

  rfcomm_disconnect_req(GET_LINE(con_id));
#endif
  printf("Disconnected!\n");
}

void
bt_waitline(int bt_fd, int line)
{
  printf("wait for a connection on line %d\n", line);
#ifndef BTD_USERSTACK
  if (ioctl(bt_fd, BTWAITFORCONNECTION, &line) < 0)
  {
    perror("bt_waitline");
    exit(1);
  }
  printf("bt_waitline : got a connection !\n");
#else
  /* fixme -- !*/
  printf("bt_waitline : not impl in usermode stack\n");
  sleep(2);
#endif
}

void
bt_inquiry(int bt_cfd, int nbr_rsp, int t)
{
#ifdef BTD_USERSTACK
  char inq_lap[6];
  inquiry_results *inq_res;

  printf("Inquiring...\n");

  inq_lap[0] = 0x33;
  inq_lap[1] = 0x8b;
  inq_lap[2] = 0x9e;

  inq_res = (inquiry_results*) malloc(sizeof(inquiry_results) + nbr_rsp * 6);
  hci_inquiry(inq_lap, t, nbr_rsp, inq_res);
#else
  int i;
  inquiry_results *inq_res;

  inq_res = (inquiry_results*) malloc(sizeof(inquiry_results) + nbr_rsp * 6);
  inq_res->nbr_of_units = nbr_rsp;
  inq_res->inq_time = t;

  printf("(before)ifndef BTD_USERSTACK\n");//kainui
  for (i = 0; i < inq_res->nbr_of_units; i++)
  {
    printf("BD %d: %02x:%02x:%02x:%02x:%02x:%02x\n",i,
           inq_res->bd_addr[0+6*i],inq_res->bd_addr[1+6*i],
           inq_res->bd_addr[2+6*i],inq_res->bd_addr[3+6*i],
           inq_res->bd_addr[4+6*i],inq_res->bd_addr[5+6*i]);
  }          //kainui

  if (ioctl(bt_cfd, HCIINQUIRY, inq_res) < 0)
  {
    perror("Inquiry");
    return;
  }

  printf("(after)ifndef BTD_USERSTACK\n");//kainui
  for (i = 0; i < inq_res->nbr_of_units; i++)
  {
    printf("BD %d: %02x:%02x:%02x:%02x:%02x:%02x\n",i,
           inq_res->bd_addr[0+6*i],inq_res->bd_addr[1+6*i],
           inq_res->bd_addr[2+6*i],inq_res->bd_addr[3+6*i],
           inq_res->bd_addr[4+6*i],inq_res->bd_addr[5+6*i]);
  }
#endif
}


void
bt_set_bd_addr(int bt_cfd, int* bd)
{
  int i;
  unsigned char new_bd[6];

  for (i = 0; i < 6; i++)
  {
    new_bd[i] = (unsigned char) *bd++;
  }

#ifndef BTD_USERSTACK
  printf("ifndef BTD_USERSTACK\n"); //kainui
  if (ioctl(bt_cfd, HCIWRITEBDADDR, new_bd) < 0)
  {
    perror("Set bd addr");
  }
#else
  hci_set_bd_addr(new_bd);
#endif

  printf("New Bluetooth device address set to: %02X:%02X:%02X:%02X:%02X:%02X\n",
         new_bd[0], new_bd[1], new_bd[2],
         new_bd[3], new_bd[4], new_bd[5]);

#ifdef RESTART_ENABLED
  printf("resetting hw to activate bd change\n");
  btd_killchilds();

  /* FIXME -- use bt_cfd when in command line mode and only open ttyBT0-6
     when there is data transfers to be made */

  close_device(bt_fd); /* in command line mode ttyBT0 is opened */
  close_device(bt_cfd);
  close_device(phys_fd);
  bt_fd = -1;
  bt_cfd = -1;
  phys_fd = -1;
  reset_hw();

  siglongjmp(jmpbuffer, 1);
  
#else
  printf("reset HW to activate bd change\n");
#endif
}

void
read_local_bd(int bt_cfd, unsigned char *bd_addr)
{
#ifndef BTD_USERSTACK
  printf("ifndef BTD_USERSTACK\n"); //kainui
  if (ioctl(bt_cfd, HCIREADLOCALBDADDR, bd_addr) < 0)
  {
    perror("Read bd addr");
  }
#else
  BD_ADDR rev_bd;
  int i;

  hci_read_local_bd(rev_bd);

  /* return as big endian */
  for (i = 0; i < 6; i++) {
    bd_addr[i] = rev_bd[5-i];
  }
#endif

  printf("Current bd addr : %02X:%02X:%02X:%02X:%02X:%02X\n",
         bd_addr[0], bd_addr[1], bd_addr[2],
         bd_addr[3], bd_addr[4], bd_addr[5]);
}



/* FIXME -- add "line" parameter to differentiate between the remote devices */
void
read_remote_bd(int bt_cfd, int line, unsigned char *bd_addr)
{
#ifndef BTD_USERSTACK
  *(int*)bd_addr = line;

  if (ioctl(bt_cfd, BTREADREMOTEBDADDR, bd_addr) < 0)
  {
    perror("Read client bd addr");
  }
#else
  BD_ADDR rev_bd;
  int i;

  get_remote_bd(line, rev_bd);

  /* return as big endian */
  for (i = 0; i < 6; i++) {
    bd_addr[i] = rev_bd[5-i];
  }
#endif

  /*printf("Client bd addr : %02X:%02X:%02X:%02X:%02X:%02X\n",
         bd_addr[0], bd_addr[1], bd_addr[2],
         bd_addr[3], bd_addr[4], bd_addr[5]);*/
}

void
bt_set_classofdevice(int bt_fd, unsigned short service_class,
		     unsigned char major_class, unsigned char minor_class,
		     unsigned char format)
{
  unsigned char class_of_device[3];

  switch (format)
  {
  case 0:
    class_of_device[0] = (minor_class << 2);
    class_of_device[1] = ((service_class & 0x7) << 5) | (major_class & 0x1f);
    class_of_device[2] = (service_class  & 0x7f8) >> 3;
    
#ifndef BTD_USERSTACK
    if (ioctl(bt_fd, HCIWRITECLASSOFDEVICE, class_of_device) < 0)
    {
      perror("bt_set_classofdevice");
      exit(1);
    }
#else
    hci_write_class_of_device(class_of_device);
#endif
    break;
  case 1:
    printf("bt_set_classofdevice, Unsupported format 0x%02x\n", format);
    break;
  case 2:
    printf("bt_set_classofdevice, Unsupported format 0x%02x\n", format);
    break;
  default:
    printf("bt_set_classofdevice, Unsupported format 0x%02x\n", format);
    break;
  }
}

void
role_switch(int bt_cfd, unsigned char* bd_addr, int role1)
{
  int i;
  unsigned char tmp[7];

  printf("Performing role switch to peer: %02X:%02X:%02X:%02X:%02X:%02X\n",
         bd_addr[0], bd_addr[1], bd_addr[2],
         bd_addr[3], bd_addr[4], bd_addr[5]);

  for (i = 0; i < 6; i++)
  {
    tmp[5-i] = (unsigned char) *bd_addr++;
  }

  tmp[6] = (unsigned char) role1;
  printf("i = %d \n",i);

#ifndef BTD_USERSTACK
  if (ioctl(bt_cfd, HCISWITCHROLE, tmp) < 0)
  {
    perror("role_switch");
  }
#else
  i = hci_switch_role(bd_addr, role1);
#endif
  printf("i => %d\n",i);
  role=role1;

}

#ifndef BTD_USERSTACK
char*
bt_hw_vendor(void)
{
  int bt_cfd = open(BT_CTRL_TTY, O_RDWR | O_NOCTTY);
  static char buffer[20];

  if (bt_cfd < 0 || ioctl(bt_cfd, BTHWVENDOR, buffer) < 0)
  {
    perror(__FUNCTION__);
    return NULL;
  }
  close(bt_cfd);
  return buffer;
}
#endif

void
reset_hw(void)
{
#ifdef __CRIS__
  int devfd;

  printf("Resetting HW board...\n");
  if ((devfd = open(BT_CTRL_TTY, O_RDWR | O_NOCTTY)) >= 0)
  {
    if (ioctl(devfd, BTRESETPHYSICALHW) < 0)
    {
      perror("Resetting hardware");
      exit(1);
    }
    sleep(2);

    close(devfd);

    printf("Done.\n");
  }
  else
  {
    printf("ERROR! Failed to open " BT_CTRL_TTY "\n");
  }
#else
  printf("Please reset HW board within 5 seconds\n");
  sleep(5);
#endif
  //write_device_data();
  num_my_service = 0;
  num_device = 0;
}

/*********************************************************************/
/****************** Vendor dependent functions ***********************/
/*********************************************************************/

void
init_phys(int fd)
{
  switch (hw_vendor())
  {
  case HW_CSR:
    csr_init_phys(fd);
    break;

  case HW_DIGIANSWER:
    digianswer_init_phys(fd);
    break;

  case HW_ERICSSON:
    ericsson_init_phys(fd);
    break;

  case HW_INFINEON:
    infineon_init_phys(fd);
    break;

  case HW_USB:
    usb_init_phys(fd);
    break;

  case HW_GENERIC:
    generic_init_phys(fd);
    break;

  case HW_NO_INIT:
    no_init_phys(fd);
    break;

  case HW_UNKNOWN:
  default:
    unknown_init_phys(fd);
    break;
  }
}

void
init_hw(int spd)
{
  switch (hw_vendor())
  {
  case HW_CSR:
    csr_init_hw(spd);
    break;

  case HW_DIGIANSWER:
    digianswer_init_hw(spd);
    break;

  case HW_ERICSSON:
    ericsson_init_hw(spd);
    break;

  case HW_INFINEON:
    infineon_init_hw(spd);
    break;

  case HW_USB:
    usb_init_hw(spd);
    break;

  case HW_GENERIC:
    generic_init_hw(spd);
    break;

  case HW_NO_INIT:
    no_init_hw(spd);
    break;

  case HW_UNKNOWN:
  default:
    unknown_init_hw(spd);
    break;
  }
}

int
hw_vendor(void)
{
  static int hw_vendor = HW_NOT_PROBED;

  if (hw_vendor == HW_NOT_PROBED)
  {
    char *vendor = bt_hw_vendor();

    if (!vendor)
      hw_vendor = HW_UNKNOWN;
    else if (!strcmp(vendor, "CSR"))
      hw_vendor = HW_CSR;
    else if (!strcmp(vendor, "Digianswer"))
      hw_vendor = HW_DIGIANSWER;
    else if (!strcmp(vendor, "Ericsson"))
      hw_vendor = HW_ERICSSON;
    else if (!strcmp(vendor, "Infineon"))
      hw_vendor = HW_INFINEON;
    else if (!strcmp(vendor, "USB"))
      hw_vendor = HW_USB;
    else if (!strcmp(vendor, "Generic"))
      hw_vendor = HW_GENERIC;
    else if (!strcmp(vendor, "No Init"))
      hw_vendor = HW_NO_INIT;
    else
      hw_vendor = HW_UNKNOWN;
  }

  return hw_vendor;
}

/* ===============================================================*/
/* CSR specific commands                                          */
/* ===============================================================*/

/* Set the phys device to CSR default, 115200 */
void
csr_init_phys(int fd)
{
  fd_setup(fd, 115200, USE_FLOW_CTRL);
}

/* fixme -- remove hardcoded values */
void
csr_init_hw(int spd)
{
#ifndef BTD_USERSTACK
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);
  unsigned char evfilter[3]; 
  unsigned int tmp[2];

  tmp[0] = 0x800;
  tmp[1] = 0x12;

  sleep(1);
  printf("Setting write_scan_enable in CSR module!\n");
  
  if (ioctl(bt_cfd, HCIWRITESCANENABLE, &wrscan) < 0)
  { 
    perror("HCIWRITESCANENABLE");
    exit(1);
  }

  /* improves reliability when doing a connect */
  printf("Setting write_pagescan_activity in CSR module!\n");
  if (ioctl(bt_cfd, HCIWRITEPAGESCANACTIVITY, &tmp) < 0)
  { 
    perror("HCIWRITESCANENABLE");
    exit(1);
  }

  sleep(1);
  evfilter[0] = 0x02; /* Connection setup */
  evfilter[1] = 0x00; /* All devices */
  evfilter[2] = 0x01; /* No auto accept */
  printf("Setting event filter in CSR module!\n");
  if (ioctl(bt_cfd, HCISET_EVENT_FILTER, &evfilter) < 0)
  { 
    perror("HCISET_EVENT_FILTER");
    exit(1);
  }
#else
  printf("Setting write_scan_enable in CSR module!\n");
  hci_write_scan_enable(PAGE_SCAN_ENABLE|INQUIRY_SCAN_ENABLE);
  printf("Setting write_pagescan_activity in CSR module!\n");
  hci_write_pagescan_activity(0x50, 0x20); /* more reliable connection process */
  sleep(1); /* wait for HW */
#endif
}

/* ===============================================================*/
/* Digianswer specific commands                                   */
/* ===============================================================*/

/* Set the phys device to Digianswer default, 9600 */ 
void
digianswer_init_phys(int fd)
{
  fd_setup(fd, 9600, USE_FLOW_CTRL);
}

void
digianswer_init_hw(int spd)
{
  printf("Setting baudrate in Digianswer PC card\n");
#ifndef BTD_USERSTACK
  if (ioctl(bt_cfd, HCISETBAUDRATE, &spd) < 0)
  {
    perror("HCISETBAUDRATE");
    exit(1);
  }
#else
  hci_set_baudrate(spd);
#if DIGI_DONGLE_SUPPORT
  // FIXME - what to do about this?
  hci_set_baudrate(115200);
#endif

#endif /* BTD_USERSTACK */
}

/* ===============================================================*/
/* Ericsson specific commands                                     */
/* ===============================================================*/

/* Set the phys device to Ericsson default speed, 57600 */
void
ericsson_init_phys(int fd)
{
  fd_setup(fd, 57600, USE_FLOW_CTRL);
}

void
ericsson_init_hw(int spd)
{
#ifndef BTD_USERSTACK
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);
  unsigned char evfilter[3];

  /* wait for Ericsson module to boot if running this app directly at startup
   */
  sleep(1);

  printf("Setting write_scan_enable in Ericsson module!\n");
  if (ioctl(bt_cfd, HCIWRITESCANENABLE, &wrscan) < 0)
  {
    perror("HCIWRITESCANENABLE");
    exit(1);
  }

  /* set_event_filter must be called for m/s switch on IrmaC! */
  sleep(1);
  evfilter[0] = 0x02; /* Connection setup */
  evfilter[1] = 0x00; /* All devices */
  evfilter[2] = 0x01; /* No auto accept */
  printf("Setting event filter in Ericsson module!\n");
  if (ioctl(bt_cfd, HCISET_EVENT_FILTER, &evfilter) < 0)
  {
    perror("HCISET_EVENT_FILTER");
    exit(1);
  }

  sleep(1); // wait for HW... 
  printf("Setting baudrate in Ericsson module!\n");  
  if (ioctl(bt_cfd, HCISETBAUDRATE, &spd) < 0)
  {
    perror("HCISETBAUDRATE");
    exit(1);
  }
#else  
  printf("Setting write_scan_enable in Ericsson module!\n");
  hci_write_scan_enable(PAGE_SCAN_ENABLE|INQUIRY_SCAN_ENABLE);
  sleep(1); /* wait for HW... */

  tcflush(phys_fd, TCIOFLUSH);

  printf("Setting baudrate in Ericsson module!\n");  
  hci_set_baudrate(spd);  
  usleep(10000); /* needed for some reason... */
#endif
}

/* ===============================================================*/
/* Infineon specific commands                                     */
/* ===============================================================*/

void infineon_init_phys(int fd)
{
  fd_setup(fd, 115200, USE_FLOW_CTRL);
}

void
infineon_init_hw(int spd)
{
#ifndef BTD_USERSTACK
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);

  sleep(1);
  printf("Setting write_scan_enable in Infineon chip!\n");
  if (ioctl(bt_cfd, HCIWRITESCANENABLE, &wrscan) < 0)
  { 
    perror("HCIWRITESCANENABLE");
    exit(1);
  }

  sleep(1); // wait for HW... 
  printf("Setting baudrate in Infineon module!\n");
  if (ioctl(bt_cfd, HCISETBAUDRATE, &spd) < 0)
  {
    perror("HCISETBAUDRATE");
    exit(1);
  }
  printf("read Firmware version number\n");

#else  
  printf("Setting write_scan_enable in Infineon chip!\n");
  hci_write_scan_enable(PAGE_SCAN_ENABLE|INQUIRY_SCAN_ENABLE);          
  sleep(1); /* wait for HW... */

  tcflush(phys_fd, TCIOFLUSH);

  printf("Setting baudrate in Infineon chip!\n");
  hci_set_baudrate(spd);  
#endif
}

/* ===============================================================*/
/* USB specific commands                                          */
/* ===============================================================*/

void
usb_init_phys(int fd)
{
  fd_setup(fd, 115200, USE_FLOW_CTRL);
}

void
usb_init_hw(int spd)
{
#ifndef BTD_USERSTACK
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);
  sleep(1);
  printf("Setting write_scan_enable in USB module!\n");
  
  if (ioctl(bt_cfd, HCIWRITESCANENABLE, &wrscan) < 0)
  { 
    perror("HCIWRITESCANENABLE");
    exit(1);
  }
#else
  hci_write_scan_enable(PAGE_SCAN_ENABLE|INQUIRY_SCAN_ENABLE);
  sleep(1); /* wait for HW */
#endif
}

/* ===============================================================*/
/* Generic commands                                               */
/* ===============================================================*/

void
generic_init_phys(int fd)
{
  fd_setup(fd, 115200, USE_FLOW_CTRL);
}

void
generic_init_hw(int spd)
{
#ifndef BTD_USERSTACK
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);
  sleep(1);
  printf("Setting write_scan_enable in USB module!\n");
  
  if (ioctl(bt_cfd, HCIWRITESCANENABLE, &wrscan) < 0)
  {
    perror("HCIWRITESCANENABLE");
    exit(1);
  }
#else
  hci_write_scan_enable(PAGE_SCAN_ENABLE|INQUIRY_SCAN_ENABLE);
  sleep(1); /* wait for HW */
#endif
}

/* ===============================================================*/
/* No HW init commands                                            */
/* ===============================================================*/

void
no_init_phys(int fd)
{
}

void
no_init_hw(int spd)
{
}

/* ===============================================================*/
/* Default                                                        */
/* ===============================================================*/

void
unknown_init_phys(int fd)
{
  printf("ERROR: init_phys() not implemented!\n");
}

void
unknown_init_hw(int spd)
{
  printf("ERROR: init_hw() not implemented!\n");
}

/*****************************kainui add************************************/
void con_to_send_data(unsigned int tmp[])
{
    int i,check;
    unsigned int con_id;
    unsigned short srv_ch, line;
    unsigned char tmp_bd[6],tmp_bd2[6];

    for (i = 0; i < 6; i++)
    {
      tmp_bd[i] = (unsigned char)tmp[i];
    }

    check = 0;
    while ((i<num_device)&&(check==0))
    {
           change_str_to_addr(device_list[i].bd_addr,tmp_bd2);
           check = compare_addr(tmp_bd,tmp_bd2);
           i++;
    }
    if (check==1)
        if (device_list[i-1].status == 0)
                device_list[i-1].status = 1;
        else if (device_list[i-1].status == 2)
                device_list[i-1].status = 3;

    /* layer specific for rfcomm is 16 bits => | line | dlci | */

    line = (unsigned short)(tmp[7]);
    srv_ch = (unsigned short)(tmp[6]);
    con_id = CREATE_RFCOMM_ID(line, srv_ch<<1);
    printf("con_id(connect rfcomm) : %d\n",con_id);

    bt_connect(bt_fd, tmp_bd, con_id);
    return;
}

int send_data(char *st,int repeat,int line)
{
#define  MAXSIZE (4096*2)
    struct timeval start_t, stop_t;
    int bytes_tot;
    int avg_speed = 0; /* bps */
    unsigned int ms;
    char tmp[MAXSIZE];
    char dev[20];
    int fd;
    int j,i;

    sprintf(dev, "/dev/ttyBT%d",line);
    i = strlen(st);
#ifndef BTD_USERSTACK
    printf("Opening %s\n", dev);
    if ((fd = open_device(dev, O_RDWR, CLIENT)) < 0)
    {
      perror("open_device");
      return 0;
    }
    printf("Done.\n");

    bt_waitline(fd, line);

#else
    /* FIXME -- currently only uses line 0 */
    if (line != 0)       {
      printf("No support for sending data on line %d, use line 0 instead ! (userstack only)\n", line);
      fd=-1;
      return 0;
    }
#endif

    if (i > MAXSIZE)
    {
      printf("Max 8192 bytes per write!\n");
      i = MAXSIZE;
    }

    /* fill them with letters... */
    for(j = 0; j < i; j++)
    {
      tmp[j] = st[j];
    }

    bytes_tot = i*repeat;

    printf("\nNow sending %d %d-bytes packet (%d kB) on line %d\n",
           repeat, i, bytes_tot/1000, line);

    gettimeofday(&start_t, NULL);

    while (repeat)
    {
      int n = 0;
#ifndef BTD_USERSTACK
      n = write(fd, tmp, i);
#else
      printf("bt_write_top tmp = %s\n",tmp);
      n = bt_write_top(tmp, i, line);  //tmp is data , i is strlen
#endif

      if (n <=0)
      {
        printf("couldn't write any more data...\n\n");
        bytes_tot = bytes_tot-repeat*i;
        break;
      }

      repeat--;
      printf("%6d kB left to send... \r",
             ((repeat*i)/1000));
      fflush(stdout);
    }
    gettimeofday(&stop_t, NULL);
    printf("\ndone.\n");

    ms = (stop_t.tv_sec-start_t.tv_sec)*1000 +
      (stop_t.tv_usec-start_t.tv_usec)/1000;
    if (ms)
      avg_speed = ((8*bytes_tot)/ms);
    printf("Average TX rate : %d kbps (%d kB/s)\n", avg_speed, avg_speed/8);
#ifndef BTD_USERSTACK
    printf("Closing %s\n", dev);
    close_device(fd);
#endif

}

void send_data_disc(int line)
{
    unsigned int con_id;
    con_id = CREATE_RFCOMM_ID(line, 0 /* fixme -- don't care */);
    bt_disconnect(bt_fd, con_id);
}

int chat(void)
{
        char *buf;
        buf = "start";
        while (!strncmp(buf, "exit", 4) == 0)
        {
                buf = readline("");
                send_data(buf,1,0);
        }
        send_data_disc(0);
        return 1;
}

void read_device_data(void)
{
  int eof = 0;
  int ii;
  char st[30];
  char tmp[4];
  int t;
  unsigned char tmp_bd[6];
  unsigned char my_bd_addr[6];
/* get data from DeviceDatabase.txt and put into struct
   device => device_list[num_device].                 */

   printf("read_device_data\n");

   bzero((unsigned char *) &device_list, sizeof(struct device));
   /*open device file*/
   if ((fp = fopen("DeviceDatabase.txt","r"))==NULL)
         printf("cannot open file\n");
   else printf("open file already.\n");

   num_device = 0;
   read_local_bd(bt_cfd, my_bd_addr);

   /*read device file*/
   while ((eof = feof(fp))==0)
   {
        int i=0;
        int check = 0;

        fgets(st,30,fp);

        bzero((unsigned char *) &device_list[num_device].bd_addr, sizeof(device_list[num_device].bd_addr));
        fgets(device_list[num_device].bd_addr,20,fp);
        change_str_to_addr(device_list[num_device].bd_addr,tmp_bd);
        printf("bd_addr  %s\n",device_list[num_device].bd_addr);

        bzero((unsigned char *) &device_list[num_device].friendly_name, sizeof(device_list[num_device].friendly_name));
        fgets(device_list[num_device].friendly_name,30,fp);
        printf("friendly_name = %s\n",device_list[num_device].friendly_name);
        printf("len = %d\n",strlen(device_list[num_device].friendly_name));

        bzero((unsigned char *) &device_list[num_device].type, sizeof(device_list[num_device].type));
        fgets(device_list[num_device].type,31,fp);
        printf("type => %s\n",device_list[num_device].type);

        fgets(st,30,fp);
        device_list[num_device].num_service = atoi(st);
        printf("st => %s\n",st);
        printf("num_service => %d\n",device_list[num_device].num_service);

        while (i<device_list[num_device].num_service)
        {
                fgets(st,30,fp);
                fgets(st,20,fp);

                bzero((unsigned char *) &device_list[num_device].service_list[i].service_record_handle, sizeof(device_list[i].service_list[i].service_record_handle));
                fgets(device_list[num_device].service_list[i].service_record_handle,30,fp);
                device_list[num_device].service_list[i].service_record_handle[strlen(device_list[num_device].service_list[i].service_record_handle)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].service_classID_list, sizeof(device_list[num_device].service_list[i].service_classID_list));
                fgets(device_list[num_device].service_list[i].service_classID_list,30,fp);
                device_list[num_device].service_list[i].service_classID_list[strlen(device_list[num_device].service_list[i].service_classID_list)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].protocol_descriptor_list, sizeof(device_list[num_device].service_list[i].protocol_descriptor_list));
                fgets(device_list[num_device].service_list[i].protocol_descriptor_list,30,fp);
                device_list[num_device].service_list[i].protocol_descriptor_list[strlen(device_list[num_device].service_list[i].protocol_descriptor_list)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].browse_group_list, sizeof(device_list[num_device].service_list[i].browse_group_list));
                fgets(device_list[num_device].service_list[i].browse_group_list,30,fp);
                device_list[num_device].service_list[i].browse_group_list[strlen(device_list[num_device].service_list[i].browse_group_list)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].bt_profile_descriptor_list, sizeof(device_list[num_device].service_list[i].bt_profile_descriptor_list));
                fgets(device_list[num_device].service_list[i].bt_profile_descriptor_list,30,fp);
                device_list[num_device].service_list[i].bt_profile_descriptor_list[strlen(device_list[num_device].service_list[i].bt_profile_descriptor_list)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].service_name, sizeof(device_list[num_device].service_list[i].service_name));
                fgets(device_list[num_device].service_list[i].service_name,31,fp);
                device_list[num_device].service_list[i].service_name[strlen(device_list[num_device].service_list[i].service_name)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].service_description, sizeof(device_list[num_device].service_list[i].service_description));
                fgets(device_list[num_device].service_list[i].service_description,500,fp);
                device_list[num_device].service_list[i].service_description[strlen(device_list[num_device].service_list[i].service_description)] = '\0';

                bzero((unsigned char *) &device_list[num_device].service_list[i].groupID, sizeof(device_list[num_device].service_list[i].groupID));
                fgets(device_list[num_device].service_list[i].groupID,30,fp);
                device_list[num_device].service_list[i].groupID[strlen(device_list[num_device].service_list[i].groupID)] = '\0';

                fgets(st,20,fp);
                i++;
        }


        fgets(st,10,fp);
        device_list[num_device].last_modified = atoi(st);

        fgets(st,10,fp);
        device_list[num_device].status = atoi(st);

        fgets(st,10,fp);
        device_list[num_device].sdp_id = atoi(st);

        fgets(st,20,fp);

        if ((check = compare_addr(my_bd_addr,tmp_bd))==0)
                num_device++;
   }

   fclose(fp);   //close device file
   printf("you have %d devices in database.\n",num_device);

}

void write_device_data(void)
{
  int ii=0;
  int i =0;
  char st[300];
/* write data from struct into DeviceDatabase.txt */

   printf("write_device_data\n");
   /*open device file*/
   if ((fp = fopen("DeviceDatabase.txt","w"))==NULL)
         printf("cannot open file\n");
   else printf("open file already.\n");

   printf("num_device => %d\n",num_device);
   /*read device file*/
   while (ii<num_device)
   {
        int i=0;

        if (ii==0)  fputs("{\n",fp);
        else fputs("\n{\n",fp);

        bzero((unsigned char *) &st, sizeof(st));
        memcpy(st,(char*)device_list[ii].bd_addr,strlen((char*)device_list[ii].bd_addr));
        fputs(st,fp);

        bzero((unsigned char *) &st, sizeof(st));
        memcpy(st,(char*)device_list[ii].friendly_name,strlen((char*)device_list[ii].friendly_name));
        fputs(st,fp);

        bzero((unsigned char *) &st, sizeof(st));
        memcpy(st,(char*)device_list[ii].type,strlen((char*)device_list[ii].type));
        if (st[0]=='\0') memcpy(st,"Computer\n",9);
        fputs(st,fp);

        bzero((unsigned char *) &st, sizeof(st));
        int_to_char(device_list[ii].num_service,st);
        st[strlen(st)] = '\n';
        fputs(st,fp);

        while (i<device_list[ii].num_service)
        {
                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].service_name,strlen((char*)device_list[ii].service_list[i].service_name));
                fputs(st,fp);

                fputs("{\n",fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].service_record_handle,strlen((char*)device_list[ii].service_list[i].service_record_handle));
                fputs(st,fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].service_classID_list,strlen((char*)device_list[ii].service_list[i].service_classID_list));
                fputs(st,fp);


                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].protocol_descriptor_list,strlen((char*)device_list[ii].service_list[i].protocol_descriptor_list));
                fputs(st,fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].browse_group_list,strlen((char*)device_list[ii].service_list[i].browse_group_list));
                fputs(st,fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].bt_profile_descriptor_list,strlen((char*)device_list[ii].service_list[i].bt_profile_descriptor_list));
                fputs(st,fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].service_name,strlen((char*)device_list[ii].service_list[i].service_name));
                fputs(st,fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].service_description,strlen((char*)device_list[ii].service_list[i].service_description));
                fputs(st,fp);

                bzero((unsigned char *) &st, sizeof(st));
                memcpy(st,(char*)device_list[ii].service_list[i].groupID,strlen((char*)device_list[ii].service_list[i].groupID));
                fputs(st,fp);

                fputs("}\n",fp);
                i++;
        }

        bzero((unsigned char *) &st, sizeof(st));
        int_to_char(device_list[ii].last_modified,st);
        st[strlen(st)] = '\n';
        fputs(st,fp);

        bzero((unsigned char *) &st, sizeof(st));
        if (device_list[ii].status != 0)
                device_list[ii].status = 0;
        int_to_char(device_list[ii].status,st);
        st[strlen(st)] = '\n';
        fputs(st,fp);

        bzero((unsigned char *) &st, sizeof(st));
        int_to_char(device_list[ii].sdp_id,st);
        st[strlen(st)] = '\n';
        fputs(st,fp);

        fputs("}",fp);

        ii++;
   }


   fclose(fp);   //close device file
   printf("you have %d devices in database.\n",num_device);
}

void read_my_service_data(void)
{
        int eof;
        unsigned char st[20];
        FILE *fp;

        /*open service file*/
        if ((fp = fopen("ServiceDatabase.txt","r"))==NULL)
         printf("cannot open file\n");
        else printf("open file already.\n");

        /*read service file*/
        while ((eof = feof(fp))==0)
        {
                fgets(st,20,fp);

                fgets(st,20,fp);

                bzero((unsigned char *) &my_service_list[num_my_service].service_record_handle, sizeof(my_service_list[num_my_service].service_record_handle));
                fgets(my_service_list[num_my_service].service_record_handle,20,fp);
                my_service_list[num_my_service].service_record_handle[strlen(my_service_list[num_my_service].service_record_handle)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].service_classID_list, sizeof(my_service_list[num_my_service].service_classID_list));
                fgets(my_service_list[num_my_service].service_classID_list,20,fp);
                my_service_list[num_my_service].service_classID_list[strlen(my_service_list[num_my_service].service_classID_list)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].protocol_descriptor_list, sizeof(my_service_list[num_my_service].protocol_descriptor_list));
                fgets(my_service_list[num_my_service].protocol_descriptor_list,20,fp);
                my_service_list[num_my_service].protocol_descriptor_list[strlen(my_service_list[num_my_service].protocol_descriptor_list)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].browse_group_list, sizeof(my_service_list[num_my_service].browse_group_list));
                fgets(my_service_list[num_my_service].browse_group_list,20,fp);
                my_service_list[num_my_service].browse_group_list[strlen(my_service_list[num_my_service].browse_group_list)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].bt_profile_descriptor_list, sizeof(my_service_list[num_my_service].bt_profile_descriptor_list));
                fgets(my_service_list[num_my_service].bt_profile_descriptor_list,20,fp);
                my_service_list[num_my_service].bt_profile_descriptor_list[strlen(my_service_list[num_my_service].bt_profile_descriptor_list)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].service_name, sizeof(my_service_list[num_my_service].service_name));
                fgets(my_service_list[num_my_service].service_name,31,fp);
                my_service_list[num_my_service].service_name[strlen(my_service_list[num_my_service].service_name)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].service_description, sizeof(my_service_list[num_my_service].service_description));
                fgets(my_service_list[num_my_service].service_description,301,fp);
                my_service_list[num_my_service].service_description[strlen(my_service_list[num_my_service].service_description)] = '\0';

                bzero((unsigned char *) &my_service_list[num_my_service].groupID, sizeof(my_service_list[num_my_service].groupID));
                fgets(my_service_list[num_my_service].groupID,20,fp);
                my_service_list[num_my_service].groupID[strlen(my_service_list[num_my_service].groupID)] = '\0';

                fgets(st,20,fp);

                printf("num_my_service => %d\n",num_my_service);

                num_my_service++;
        }
}



void int_to_char(int num,char *st)
{

        if (num==0) st[0] = '0';
        else if (num==1) st[0] = '1';
        else if (num==2) st[0] = '2';
        else if (num==3) st[0] = '3';
        else if (num==4) st[0] = '4';
        else if (num==5) st[0] = '5';
        else if (num==6) st[0] = '6';
        else if (num==7) st[0] = '7';
        else if (num==8) st[0] = '8';
        else if (num==9) st[0] = '9';
        else printf("num error\n");

        st[strlen(st)]= '\0';

        return ;
}

void change_str_to_addr(unsigned char *st,unsigned char tmp_bd[])
{
        unsigned char tmp;
        unsigned char tmp_st[2];
        int i = 0;
        int ii = 0;

        tmp_st[1] = '\0';
        while (st[i]!='\0')
        {
                tmp_st[0] = st[i];
                tmp = (atoi(tmp_st)) * (0x10);
                tmp_st[0] = st[i+1];
                tmp = tmp + ((atoi(tmp_st)) * (0x1));
                i = i + 2;
                tmp_bd[ii] = tmp;
                ii++;
                if (i<16) i++;
        }
}

int compare_addr(unsigned char *addr1,unsigned char *addr2)
{
        int i = 0;
        for (i=0; i<6; i++)
        {
                if (addr1[i]!=addr2[i])
                        return 0;
        }
        return 1;
}

void change_addr_to_str(unsigned char st[],unsigned char *tmp_bd)
{
      char ss[2];
      int tmp;
      int i = 0;

      for (i=0; i<20; i++)
          st[i] = '\0';
      for (i=0; i<6; i++)
      {
           tmp = (tmp_bd[i])/(0x10);
           int_to_char(tmp,ss);
           strcat(st,ss);
           tmp = (tmp_bd[i])%(0x10);
           int_to_char(tmp,ss);
           strcat(st,ss);
           if (i!=5) strcat(st,":");
      }
}

void check_online_offline(char online[],char offline[],int *num_online,int *num_offline)
{
        int i,ii;
        unsigned char tmp_bd[6],remote_bd[6];
        int check = 0;
        char tmp_offline[20];
        char *tmp_online;

        printf("check_online_offline\n");
        printf("num_online(before) = %d\n",*num_online);
        printf("num_offline(before) = %d\n",*num_offline);
        printf("num_device = %d\n",num_device);
        for (i=0; i<num_device; i++)
        {
               if (device_list[i].status==0)
                {
                        for (ii=0;ii<20;ii++)
                                tmp_offline[ii] = '\0';
                        strncat(offline,device_list[i].friendly_name,strlen(device_list[i].friendly_name)-1);
                        strcat(offline,",");
                        (*num_offline)++;
                }
                else
                {
                        printf("online\n");
                        strncat(online,device_list[i].friendly_name,strlen(device_list[i].friendly_name)-1);
                        strcat(online,",");
                        (*num_online)++;
                        printf("online is bd %s",device_list[i].bd_addr);
                        printf("         friendly_name %s\n",online);
                }
        }
        printf("num_online = %d\n",*num_online);
        printf("num_offline = %d\n",*num_offline);
}

void change_friendly_name(unsigned char *st)
{
        #ifdef BTD_USERSTACK
        hci_change_local_name(st);
        test_call();
        //req_window();
        #endif
        printf("finished change friendly name\n");
        test_call();
}

void get_my_friendly_name(unsigned char friendly_name[])
{
        int i=0;
        for (i=0;i<20;i++)
                friendly_name[i] = '\0';
        #ifdef BTD_USERSTACK
        hci_read_local_name(friendly_name);
        printf("my_friendly_name = %s\n",friendly_name);
        printf("finished change friendly name\n");
        #endif
}

int get_bt_cfd(void)
{
        return bt_cfd;
}

void set_new_address(int bt_cfd,int *tmp_bd)
{
        int *bd;
        unsigned char tmp[2];
        printf("set_new_address\n");
        bt_set_bd_addr(bt_cfd,&tmp_bd[0]);
}

void read_my_address(int bt_cfd,unsigned char *my_bd_addr)
{
        read_local_bd(bt_cfd, my_bd_addr);
}

void set_scan_mode(int inq,int page)
{
        if ((inq==0) && (page==0))              //inquiry scan and page scan disabled
        {
                #ifdef BTD_USERSTACK
                hci_write_scan_enable(0);
                printf("No scan enable\n");
                #endif
        }
        else if ((inq==1) && (page==0))         //inquiry scan enabled and page scan disabled
        {
                printf("Cannot run in this mode\n");
        }
        else if ((inq==0) && (page==1))         //inquiry scan disabled and page scan enabled
        {
                #ifdef BTD_USERSTACK
                hci_write_scan_enable(2);
                printf("Inquiry scan disabled , Page scan enabled\n");
                #endif
        }
        else if ((inq==1) && (page==1))         //inquiry scan and page scan enabled
        {
                #ifdef BTD_USERSTACK
                hci_write_scan_enable(3);
                printf("Inquiry scan enabled , Page scan enabled\n");
                #endif
        }
}

int read_scan_mode(void)
{
        int t;
        #ifdef BTD_USERSTACK
        t = hci_read_scan_enable();  //kainui
        #endif
        if (t==0) printf("No scan enable\n");
        else if (t==1) printf("Cannot run in this mode\n");
        else if (t==2) printf("Inquiry scan disabled , Page scan enabled\n");
        else if (t==3) printf("Inquiry scan enabled , Page scan enabled\n");
        return t;
}

/*this function is used of check connection before apps_page2. if it have connection,it's not connect again*/
void check_connect(void)
{
        int num_device_con;
        unsigned char tmp_bd[6],tmp_bd2[6];
        unsigned char* tmp_bd_addr;
        int check,ii,i;

        #ifdef BTD_USERSTACK
        ii = 0;
        printf("check_connect\n");
        num_device_con = get_num_device_con();
        while (num_device_con>0)
        {
                tmp_bd_addr = (unsigned char*)get_device_con_address(num_device_con);
                for (i=0; i<6; i++)
                {
                        tmp_bd[i] = tmp_bd_addr[i];
                }
                check = 0;
                while ((ii<num_device)&&(check==0))
                {
                        change_str_to_addr(device_list[ii].bd_addr,tmp_bd2);
                        check = compare_addr(tmp_bd,tmp_bd2);
                        ii++;
                }
                if (check == 1) update_device_data(ii,tmp_bd,device_list[ii].sdp_id); //have connection
                num_device_con--;
        }
        #endif
}

void find_all_device(int nbr_rsp,int t,int page)
{
    int num_remote_device=0;
    int num_inquiry_result=0;
    unsigned char* friendly_name;
    int i=0;
    int ii = 0;
    unsigned char* tmp_bd_addr;
    unsigned char  tmp_bd[6],tmp_bd2[6],st[20];
    int check;
    int sdp_id;

    #ifdef BTD_USERSTACK
    bt_inquiry(bt_cfd, nbr_rsp, t);
    sleep(10);
    num_inquiry_result = get_num_inquiry_result();

    if (num_inquiry_result>0)
    {
        num_remote_device = get_num_remote_device();
        while (num_remote_device>0)
        {
                tmp_bd_addr = (unsigned char*)get_remote_address(num_remote_device);
                for (i=0; i<6; i++)
                {
                        tmp_bd[i] = tmp_bd_addr[i];
                }
                check = 0;
                /*does this device have data in database? if it have,check=1. otherwise check=0*/
                printf("num_device = %d\n",num_device);
                ii=0;
                while ((ii<num_device)&&(check==0))
                {
                        change_str_to_addr(device_list[ii].bd_addr,tmp_bd2);
                        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
                        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd2[0],tmp_bd2[1],tmp_bd2[2],tmp_bd2[3],tmp_bd2[4],tmp_bd2[5]);
                        check = compare_addr(tmp_bd,tmp_bd2);
                        ii++;
                }

                if (page==1) //apps_page1 and no have this bd in device data
                {
                        sdp_id = sdp_connect_req(tmp_bd,0);
                        sleep(5);
                        add_tmp_device_data(tmp_bd,sdp_id);
                }
                else if (page==2)
                {
                        printf("kainui1\n");
                        if (check==1)
                        {
                                printf("kainui2\n");
                                sdp_id = sdp_connect_req(tmp_bd,0);
                                sleep(5);
                                update_device_data(ii,tmp_bd,sdp_id);
                        }
                }

                num_remote_device--;
        }
    }
    else printf("no device in range\n");
    #endif
}

void disc_req(void)
{
    #ifdef BTD_USERSTACK
    int j;
    l2cap_con *con = get_first_con();
    printf("Disconnecting all l2cap cons\n");

#if 1
    con = get_first_con();
    while (con!= NULL) {
      l2ca_disconnect_req(con);
      con = get_first_con();
      sleep(1);
    }
#else
    test_disconnect_req(testcon); /* extern l2cap_con set in test.c */
    sleep(2);
    test_disconnect_req(testcon2);
    sleep(2);
    test_disconnect_req(testcon3);
#endif
    for (j=0; j<num_device; j++)
        device_list[j].status = 0;

    /* shutdown baseband ? */
    #endif
}

void show_tmp_device_bak(void)
{
        int i;
        i = 0;

        printf("show_tmp_device\n");
        while (i<num_tmp_device)
        {
                printf("tmp_device%d is %s\n",i+1,tmp_device_list[i].friendly_name);
                i++;
        }
}

void show_tmp_device(char tmp_device[],int *num)
{
        int i;
        i = 0;

        printf("show_tmp_device\n");
        while (i<num_tmp_device)
        {
                printf("tmp_device%d is %s\n",i+1,tmp_device_list[i].friendly_name);
                strncat(tmp_device,tmp_device_list[i].friendly_name,strlen(tmp_device_list[i].friendly_name)-1);
                strcat(tmp_device,",");
                i++;
        }
        *num = i;
}

int search_specific(char key[],int type,char tmp_list[])
{
        int i;
        int result = 0;

        find_all_device(1,8,1);
        printf("key = %s\n",key);
        if (type==1)
        {
                i = 0;
                printf("search device\n");
                while (i<num_tmp_device)
                {
                        result = find_specific_device(i,key);
                        i++;
                }

        }
        else
        {
                i = 0;
                printf("search service\n");
                while (i<num_tmp_device)
                {
                        result = find_specific_service(i,key,tmp_list);
                        i++;
                }
        }
        return result;
}

int find_specific_device(int i,unsigned char st1[])
{
        int j,ii;
        char st2[20];

        printf("find specific device\n");
        for (j=0; j<20; j++)
                st2[j] = '\0';
        for (j=0; j<strlen(tmp_device_list[i].friendly_name); j++)
        {
                if (isupper(tmp_device_list[i].friendly_name[j])!=0)
                        st2[j] = tolower(tmp_device_list[i].friendly_name[j]);
                else st2[j] = tmp_device_list[i].friendly_name[j];
        }

        if ((ii = strncmp(st2,st1,strlen(st1))) == 0)
        {
                printf("friendly_name = %s\n",tmp_device_list[i].friendly_name);
                service_browse_req(i);
                sleep(1);
                show_tmp_service_bak(i);
                return i+1;
         }
         else
         {
                printf("not match\n");
                /*should disconnect*/
                //sdp_shutdown();
                num_tmp_device--;
                return 0;
         }
}

int find_specific_service_bak(int i,unsigned char st1[])
{
        int j,jj,ii;
        char st2[20];

        printf("find specific service\n");
        service_browse_req(i);
        sleep(1);
        for (j=0;j<tmp_device_list[i].num_service;j++)
        {
                for (jj=0; jj<20; jj++)
                        st2[jj] = '\0';
                for (jj=0; jj<strlen(tmp_device_list[i].service_list[j].service_name); jj++)
                {
                        if (isupper(tmp_device_list[i].service_list[j].service_name[jj])!=0)
                                st2[jj] = tolower(tmp_device_list[i].service_list[j].service_name[jj]);
                        else st2[jj] = tmp_device_list[i].service_list[j].service_name[jj];
                }

                if ((ii = strncmp(st2,st1,strlen(st1))) == 0)  /*have*/
                {
                        printf("friendly_name = %s\n",tmp_device_list[i].friendly_name);
                        printf("service_name = %s\n",tmp_device_list[i].service_list[j].service_name);
                        return i+1;
                }
                else return 0;
        }
}

int find_specific_service(int i,unsigned char st1[],char tmp_list[])
{
        int j,jj,ii;
        char st2[20];
        int match = 0;

        printf("find specific service\n");
        service_browse_req(i);
        sleep(1);
        for (j=0;j<tmp_device_list[i].num_service;j++)
        {
                for (jj=0; jj<20; jj++)
                        st2[jj] = '\0';
                for (jj=0; jj<strlen(tmp_device_list[i].service_list[j].service_name); jj++)
                {
                        if (isupper(tmp_device_list[i].service_list[j].service_name[jj])!=0)
                                st2[jj] = tolower(tmp_device_list[i].service_list[j].service_name[jj]);
                        else st2[jj] = tmp_device_list[i].service_list[j].service_name[jj];
                }

                if ((ii = strncmp(st2,st1,strlen(st1))) == 0)  /*have*/
                {
                        printf("friendly_name = %s\n",tmp_device_list[i].friendly_name);
                        printf("service_name = %s\n",tmp_device_list[i].service_list[j].service_name);
                        strncat(tmp_list,tmp_device_list[i].friendly_name,strlen(tmp_device_list[i].friendly_name)-1);
                        strcat(tmp_list,",");
                        strncat(tmp_list,tmp_device_list[i].service_list[j].service_name,strlen(tmp_device_list[i].service_list[j].service_name)-1);
                        strcat(tmp_list,",");
                        match++;
                }
        }
        return match;
}


void service_browse_req(unsigned int device_id)
{
        unsigned char st[20];
        unsigned char tmp_st[2];
        int i;

        strcpy(st,"1browse_req");
        st[strlen(st)] = '\0';
        for (i=0; i<2; i++)
                tmp_st[i] = '\0';
        int_to_char(device_id,tmp_st);
        strcat(st,tmp_st);
        for (i=0; i<2; i++)
                tmp_st[i] = '\0';
        int_to_char(tmp_device_list[device_id].sdp_id,tmp_st);
        strcat(st,tmp_st);
        bt_sdp_write_top(tmp_device_list[device_id].sdp_id,st);
        return;
}

void show_tmp_service_bak(int device_id)
{
        int i = 0;

        while (i<tmp_device_list[device_id].num_service)
        {
                printf("service %d is %s\n",i+1,tmp_device_list[device_id].service_list[i].service_name);
                i++;
        }
}

void show_tmp_service(int device_id,char tmp_list[],int *num)
{
        int i = 0;

        while (i<tmp_device_list[device_id].num_service)
        {
                printf("service %d is %s\n",i+1,tmp_device_list[device_id].service_list[i].service_name);
                strncat(tmp_list,tmp_device_list[device_id].friendly_name,strlen(tmp_device_list[device_id].friendly_name)-1);
                strcat(tmp_list,",");
                strncat(tmp_list,tmp_device_list[device_id].service_list[i].service_name,strlen(tmp_device_list[device_id].service_list[i].service_name)-1);
                strcat(tmp_list,",");
                i++;
        }
        *num = i;
}

void bt_sdp_send_data(char name[],char st[])
{
    int i,ii,check;

    i = 0;
    check = 0;
    while ((i<num_device)&&(check==0))
    {
        if ((ii = strncmp(device_list[i].friendly_name,name,strlen(name)-1)) == 0)
                check = 1;
        i++;
    }

    printf("check = %d\n",check);
    printf("sdp_id = %d\n",device_list[i-1].sdp_id);
    printf("friendly_name = %s111\n",device_list[i-1].friendly_name);
    bt_sdp_write_top(device_list[i-1].sdp_id,st);
}


void bt_sdp_write_top(unsigned int sdp_id,unsigned char *data)
{
        printf("bt_sdp_write_top = %s\n",data);
        #ifdef BTD_USERSTACK
        printf("loop\n");
        sdp_buf_send_data(sdp_id,data);
        #endif
}

void bt_sdp_receive_top(unsigned char *data)
{
        int device_id;
        int sdp_id,i;
        unsigned char st[2];
        unsigned char tmp_st[500],tmp_bd[6];


        if (!strncmp(data, "1browse_req", 11))
        {
                printf("return service browse response\n");
                st[1] = '\0';
                st[0] = data[11];
                device_id = atoi(st);
                st[0] = data[12];
                sdp_id = atoi(st);
                service_browse_res(device_id,sdp_id);
        }
        else if (!strncmp(data, "1browse_res", 11))
        {
                for (i=0; i<500; i++)
                        tmp_st[i] = '\0';
                st[1] = '\0';
                st[0] = data[11];
                device_id = atoi(st);
                strncpy(tmp_st,&data[12],strlen(data)-12);
                detect_service_res(device_id,tmp_st);
        }
        else if (!strncmp(data, "0001add_req", 11))
        {
                printf("return add new device response\n");
                st[1] = '\0';
                st[0] = data[11];
                sdp_id = atoi(st);
                for (i=0; i<500; i++)
                       tmp_st[i] = '\0';
                strncpy(tmp_st,&data[12],17);
                printf("tmp_address = %s\n",tmp_st);
                change_str_to_addr(tmp_st,tmp_bd);
                printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
                add_tmp_device_data(tmp_bd,sdp_id);
                add_device_data(tmp_bd,sdp_id);
        }
        else  if (!strncmp(data, "0001chat_req", 12))
        {
                printf("sdp recevice data chat_req => %d %s\n",strlen(data),data);
                req_window_1();
                //chat_window();
        }
        else  if (!strncmp(data, "test", 4))
        {
                req_window_2();
        }
        else printf("sdp recevice data => %d %s\n",strlen(data),data);
        //return;
}

void service_browse_res(int device_id,int sdp_id)
{
       unsigned char st[500];
       unsigned char tmp_st[10];
       int i,j;
       int ii;

       printf("service_browse_res\n");
       ii=0;
       while (ii<num_my_service)
       {
                j=0;
                for (i=0; i<500; i++)
                        st[i] = '\0';
                strcpy(st,"1browse_res");
                st[strlen(st)] = '\0';
                for (i=0; i<10; i++)
                        tmp_st[i] = '\0';
                int_to_char(device_id,tmp_st);
                strcat(st,tmp_st);
                for (i=0; i<10; i++)
                        tmp_st[i] = '\0';
                int_to_char(num_my_service,tmp_st);
                strcat(st,tmp_st);
                strncat(st,my_service_list[ii].service_record_handle,10);
                strncat(st,my_service_list[ii].service_classID_list,6);
                strncat(st,my_service_list[ii].protocol_descriptor_list,6);
                strncat(st,my_service_list[ii].browse_group_list,6);
                strncat(st,my_service_list[ii].bt_profile_descriptor_list,6);
                strncat(st,my_service_list[ii].service_name,strlen(my_service_list[ii].service_name)-2);
                strcat(st,":");
                strncat(st,my_service_list[ii].service_description,strlen(my_service_list[ii].service_description)-2);
                strcat(st,":");
                strncat(st,my_service_list[ii].groupID,6);
                for (i=0; i<10; i++)
                        tmp_st[i] = '\0';
                j = num_my_service - ii -1;
                int_to_char(j,tmp_st);
                strcat(st,tmp_st);

                bt_sdp_write_top(sdp_id,st);
                ii++;
       }

       return;
}

void detect_service_res(unsigned int device_id,unsigned char *tmp_st)
{
        unsigned char st[2];
        int num_tmp_service;
        int i;

        printf("detect_service_res\n");
        st[1] = '\0';
        st[0] = tmp_st[strlen(tmp_st)-1];
        num_tmp_service = atoi(st);

        st[0] = tmp_st[0];
        tmp_device_list[device_id].num_service = atoi(st);


        strncpy(tmp_device_list[device_id].service_list[num_tmp_service].service_record_handle,&tmp_st[1],10);
        tmp_device_list[device_id].service_list[num_tmp_service].service_record_handle[strlen(tmp_device_list[device_id].service_list[num_tmp_service].service_record_handle)]='\n';
        strncpy(tmp_device_list[device_id].service_list[num_tmp_service].service_classID_list,&tmp_st[11],6);
        tmp_device_list[device_id].service_list[num_tmp_service].service_classID_list[strlen(tmp_device_list[device_id].service_list[num_tmp_service].service_classID_list)]='\n';
        strncpy(tmp_device_list[device_id].service_list[num_tmp_service].protocol_descriptor_list,&tmp_st[17],6);
        tmp_device_list[device_id].service_list[num_tmp_service].protocol_descriptor_list[strlen(tmp_device_list[device_id].service_list[num_tmp_service].protocol_descriptor_list)]='\n';
        strncpy(tmp_device_list[device_id].service_list[num_tmp_service].browse_group_list,&tmp_st[23],6);
        tmp_device_list[device_id].service_list[num_tmp_service].browse_group_list[strlen(tmp_device_list[device_id].service_list[num_tmp_service].browse_group_list)]='\n';
        strncpy(tmp_device_list[device_id].service_list[num_tmp_service].bt_profile_descriptor_list,&tmp_st[29],6);
        tmp_device_list[device_id].service_list[num_tmp_service].bt_profile_descriptor_list[strlen(tmp_device_list[device_id].service_list[num_tmp_service].bt_profile_descriptor_list)]='\n';

        i = 35;
        bzero((unsigned char *) &tmp_device_list[device_id].service_list[num_tmp_service].service_name, sizeof(tmp_device_list[device_id].service_list[num_tmp_service].service_name));
        while (tmp_st[i]!=':')
        {
                st[0] = tmp_st[i];
                strcat(tmp_device_list[device_id].service_list[num_tmp_service].service_name,st);
                i++;
        }

        tmp_device_list[device_id].service_list[num_tmp_service].service_name[strlen(tmp_device_list[device_id].service_list[num_tmp_service].service_name)]='\n';
        i++;
        bzero((unsigned char *) &tmp_device_list[device_id].service_list[num_tmp_service].service_description, sizeof(tmp_device_list[device_id].service_list[num_tmp_service].service_description));
        while (tmp_st[i]!=':')
        {
                st[0] = tmp_st[i];
                strcat(tmp_device_list[device_id].service_list[num_tmp_service].service_description,st);
                i++;
        }
        i++;
        tmp_device_list[device_id].service_list[num_tmp_service].service_description[strlen(tmp_device_list[device_id].service_list[num_tmp_service].service_description)]='\n';
        strncpy(tmp_device_list[device_id].service_list[num_tmp_service].groupID,&tmp_st[i],6);
        tmp_device_list[device_id].service_list[num_tmp_service].groupID[strlen(tmp_device_list[device_id].service_list[num_tmp_service].groupID)]='\n';
}

void add_tmp_device_data(unsigned char tmp_bd[],unsigned int sdp_id)
{
        unsigned char st[20];
        int i,ii;
        unsigned char* friendly_name;
        int check = 0;

        printf("kainui  : add_tmp_device_data\n");



        /*set bd_addr*/
        for (i=0; i<20; i++)
                st[i] = '\0';
        printf("kainui11\n");
        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        change_addr_to_str(st,tmp_bd);
        printf("kainui22\n");

        i=0;
        check =0;
        while ((i<num_tmp_device)&&(check==0))
        {

                if ((ii = strncmp(device_list[i].bd_addr,st,17)) == 0)
                        check = 1;
                i++;
        }

        if (check==0)
        {
        for(i=0; i<20; i++)
                tmp_device_list[num_tmp_device].bd_addr[i] = '\0';
        memcpy(tmp_device_list[num_tmp_device].bd_addr,st,strlen(st));
        tmp_device_list[num_tmp_device].bd_addr[strlen(tmp_device_list[num_tmp_device].bd_addr)] = '\n';

        /*set friendly_name*/
        #ifdef BTD_USERSTACK
        friendly_name = (unsigned char*)get_device_con_friendly_name(tmp_bd);
        #endif
        for(i=0; i<20; i++)
                tmp_device_list[num_tmp_device].friendly_name[i] = '\0';
        memcpy(tmp_device_list[num_tmp_device].friendly_name,friendly_name,strlen(friendly_name));
        tmp_device_list[num_tmp_device].friendly_name[strlen(tmp_device_list[num_tmp_device].friendly_name)] = '\n';

        /*set sdp_id*/
        tmp_device_list[num_tmp_device].sdp_id = sdp_id;

        /*set status*/
        if (tmp_device_list[num_device].status == 0)   //no connection
               tmp_device_list[num_device].status = 2;     //connect sdp
        else if (tmp_device_list[num_device].status == 1)   //connect rfcomm
               tmp_device_list[num_device].status = 3;     //connect sdp and rfcomm

        printf("num_tmp_device = %d\n",num_tmp_device+1);
        num_tmp_device++;
        }
        else printf("have in tmp_device_list\n");
}

void add_device_data(unsigned char tmp_bd[],unsigned int sdp_id)
{
        unsigned char st[20];
        int i,ii,check,device_id;
        unsigned char* friendly_name;

        printf("add_device_data\n");


        for (i=0; i<20; i++)
               st[i] = '\0';
        printf("%x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        change_addr_to_str(st,tmp_bd);

        i=0;
        check =0;
        while ((i<num_device)&&(check==0))
        {

                if ((ii = strncmp(device_list[i].bd_addr,st,17)) == 0)
                        check = 1;
                i++;
        }
        device_id = i-1;

        if (check==0)
        {
        #ifdef BTD_USERSTACK
        friendly_name = (unsigned char*)get_device_con_friendly_name(tmp_bd);
        #endif
        memcpy(device_list[num_device].friendly_name,friendly_name,strlen(friendly_name));
        device_list[num_device].friendly_name[strlen(device_list[num_device].friendly_name)] = '\n';

        for(i=0; i<20; i++)
               device_list[num_device].bd_addr[i] = '\0';
        memcpy(device_list[num_device].bd_addr,st,strlen(st));
        device_list[num_device].bd_addr[strlen(device_list[num_device].bd_addr)] = '\n';
        printf("bd => %s\n",device_list[num_device].bd_addr);

        device_list[num_device].sdp_id = sdp_id;

        if (device_list[num_device].status == 0)   //no connection
               device_list[num_device].status = 2;     //connect sdp
        else if (device_list[num_device].status == 1)   //connect rfcomm
               device_list[num_device].status = 3;     //connect sdp and rfcomm
        num_device++;
        }
        else
        {
                printf("have in database\n");
                if (device_list[device_id].status == 0)   //no connection
                        device_list[device_id].status = 2;     //connect sdp
                else if (device_list[device_id].status == 1)   //connect rfcomm
                        device_list[device_id].status = 3;     //connect sdp and rfcomm

        }
}



int search_service(char line[])
{
        int i,ii,check;

        i = 0;
        check = 0;
        while ((i<num_tmp_device)&&(check==0))
        {
                printf("find device that wanted to search service\n");
                if ((ii = strcmp(tmp_device_list[i].friendly_name,line)) == 0)
                        check = 1;
                i++;
        }
        if (tmp_device_list[i-1].num_service==0)
                service_browse_req(i-1);
        sleep(1);
        show_tmp_service_bak(i-1);
        return i-1;
}

void add_new_device_page1(char name[])
{
        int i,ii,check;

        i=0;
        check = 0;
        while ((i<num_tmp_device)&&(check==0))
        {
                printf("find device that wanted to search service\n");
                printf("friendly_name = %d , %s\n",strlen(tmp_device_list[i].friendly_name),tmp_device_list[i].friendly_name);
                printf("name = %d , %s\n",strlen(name),name);
                if ((ii = strncmp(tmp_device_list[i].friendly_name,name,strlen(name))) == 0)
                        check = 1;
                i++;
        }
        if (check==1)
        {
                add_new_device_req(i-1);
                add_new_device(i-1);
        }
        else printf("not add device\n");
}

void add_new_device_req(int device_id)
{
        unsigned char st[100];
        unsigned char tmp_st[20],my_bd_addr[6],tmp_bd[6];
        int i;

        strcpy(st,"0001add_req");
        st[strlen(st)] = '\0';
        for (i=0; i<20; i++)
                tmp_st[i] = '\0';
        int_to_char(tmp_device_list[device_id].sdp_id,tmp_st);
        strcat(st,tmp_st);
        read_local_bd(bt_cfd,my_bd_addr);

        for (i=0;i<6;i++)
                tmp_bd[i] = my_bd_addr[i];
        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        for (i=0; i<20; i++)
                tmp_st[i] = '\0';
        change_addr_to_str(tmp_st,tmp_bd);

        strcat(st,tmp_st);
        printf("add_new_device_req = %s\n",st);
        bt_sdp_write_top(tmp_device_list[device_id].sdp_id,st);
        return;
}

void add_new_device(int device_id)
{
        int check,ii;
        unsigned char tmp_bd[6],tmp_bd2[6];
        int i;
        

        /*check in device data*/
        check = 0;
        ii=0;
        change_str_to_addr(tmp_device_list[device_id].bd_addr,tmp_bd);
        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        while ((ii<num_device)&&(check==0))
        {
               change_str_to_addr(device_list[ii].bd_addr,tmp_bd2);
               printf("tmp_bd2 %x:%x:%x:%x:%x:%x\n",tmp_bd2[0],tmp_bd2[1],tmp_bd2[2],tmp_bd2[3],tmp_bd2[4],tmp_bd2[5]);
               check = compare_addr(tmp_bd,tmp_bd2);
               ii++;
        }
        if (check==0) //have not in device data
        {
                int i;
                strcpy(device_list[num_device].bd_addr,tmp_device_list[device_id].bd_addr);
                strcpy(device_list[num_device].friendly_name,tmp_device_list[device_id].friendly_name);
                strcpy(device_list[num_device].type,tmp_device_list[device_id].type);
                device_list[num_device].num_service = tmp_device_list[device_id].num_service;
                i = 0;
                while (i<tmp_device_list[device_id].num_service)
                {
                        strcpy(device_list[num_device].service_list[i].service_record_handle,tmp_device_list[device_id].service_list[i].service_record_handle);
                        strcpy(device_list[num_device].service_list[i].service_classID_list,tmp_device_list[device_id].service_list[i].service_classID_list);
                        strcpy(device_list[num_device].service_list[i].protocol_descriptor_list,tmp_device_list[device_id].service_list[i].protocol_descriptor_list);
                        strcpy(device_list[num_device].service_list[i].browse_group_list,tmp_device_list[device_id].service_list[i].browse_group_list);
                        strcpy(device_list[num_device].service_list[i].bt_profile_descriptor_list,tmp_device_list[device_id].service_list[i].bt_profile_descriptor_list);
                        strcpy(device_list[num_device].service_list[i].service_name,tmp_device_list[device_id].service_list[i].service_name);
                        strcpy(device_list[num_device].service_list[i].service_description,tmp_device_list[device_id].service_list[i].service_description);
                        strcpy(device_list[num_device].service_list[i].groupID,tmp_device_list[device_id].service_list[i].groupID);
                        i++;
                }
                device_list[num_device].last_modified = tmp_device_list[device_id].last_modified;
                device_list[num_device].status = tmp_device_list[device_id].status;
                device_list[num_device].sdp_id = tmp_device_list[device_id].sdp_id;

                if (device_list[num_device].status == 0)   //no connection
                        device_list[num_device].status = 2;     //connect sdp
                else if (device_list[num_device].status == 1)   //connect rfcomm
                        device_list[num_device].status = 3;     //connect sdp and rfcomm

                num_device++;
        }
        else if (check==1) //have in device data
        {

                /*update device_list*/

                unsigned char tmp_bd_addr[6];

                printf("update tmp_device_list\n");
                change_str_to_addr(tmp_device_list[device_id].bd_addr,tmp_bd_addr);
                for (i=0; i<6; i++)
                {
                        tmp_bd[i] = tmp_bd_addr[i];
                }
                printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
                update_device_data(ii,tmp_bd,tmp_device_list[device_id].sdp_id);
        }


}

void update_device_data(int ii,unsigned char tmp_bd[],unsigned int sdp_id)
{
        int i;
        unsigned char *friendly_name;

        printf("update_device_data\n");
        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);
        #ifdef BTD_USERSTACK
        friendly_name = (unsigned char*)get_device_con_friendly_name(tmp_bd);
        #endif

        if ((i = strcmp(device_list[ii-1].friendly_name,friendly_name)) != 0)
        {
                  /*update friendly_name*/
                  int j;

                  friendly_name[strlen(friendly_name)] = '\n';
                  friendly_name[strlen(friendly_name)] = '\0';
                  printf("len = %d\n",strlen(friendly_name));
                  for (j=0;j<30; j++)
                        device_list[ii-1].friendly_name[j] = '\0';
                  memcpy(device_list[ii-1].friendly_name,friendly_name,strlen(friendly_name));
                  printf("device_list = %s",device_list[ii-1].friendly_name);
        }

        device_list[num_device].sdp_id = sdp_id;
        if (device_list[ii-1].status == 0)   //no connection
                  device_list[ii-1].status = 2;     //connect sdp
        else if (device_list[ii-1].status == 1)   //connect rfcomm
                  device_list[ii-1].status = 3;     //connect sdp and rfcomm
}

int show_service(char name[],char tmp_list[])
{
        int i = 0;
        int check = 0;
        int ii = 0;
        int j = 0;
        int device_id = 0;

        i=0;
        check = 0;
        printf("num_device = %d\n",num_device);
        while ((i<num_device)&&(check==0))
        {
                printf("find device that wanted to search service\n");
                printf("i =%d\n",i);
                printf("friendly_name = %d , %s\n",strlen(device_list[i].friendly_name),device_list[i].friendly_name);
                printf("name = %d , %s\n",strlen(name),name);
                if ((ii = strncmp(device_list[i].friendly_name,name,strlen(name)-1)) == 0)
                        check = 1;
                i++;
        }

        device_id = i-1;

        printf("show_service\n");
        if (device_list[device_id].num_service==0)
        {

                printf("num_tmp_device = %d\n",num_tmp_device);
                i=0;
                check = 0;
                while ((i<num_tmp_device)&&(check==0))
                {
                        if ((ii = strncmp(tmp_device_list[i].bd_addr,device_list[device_id].bd_addr,17)) == 0)
                                check = 1;
                        i++;
                }
                if (check==1)  j = i-1;
                else j = 0;
                printf("j = %d\n",j);
                printf("device_id = %d\n",device_id);
                {
                        service_browse_req(j);
                        sleep(1);
                        device_list[device_id].num_service = tmp_device_list[j].num_service;
                        printf("num_service1 = %d\n",device_list[device_id].num_service);
                        printf("num_service2 = %d\n",tmp_device_list[j].num_service);
                        for (ii=0;ii<device_list[device_id].num_service;ii++)
                        {
                                strcpy(device_list[device_id].service_list[ii].service_record_handle,tmp_device_list[j].service_list[ii].service_record_handle);
                                strcpy(device_list[device_id].service_list[ii].service_classID_list,tmp_device_list[j].service_list[ii].service_classID_list);
                                strcpy(device_list[device_id].service_list[ii].protocol_descriptor_list,tmp_device_list[j].service_list[ii].protocol_descriptor_list);
                                strcpy(device_list[device_id].service_list[ii].browse_group_list,tmp_device_list[j].service_list[ii].browse_group_list);
                                strcpy(device_list[device_id].service_list[ii].bt_profile_descriptor_list,tmp_device_list[j].service_list[ii].bt_profile_descriptor_list);
                                strcpy(device_list[device_id].service_list[ii].service_name,tmp_device_list[j].service_list[ii].service_name);
                                strcpy(device_list[device_id].service_list[ii].service_description,tmp_device_list[j].service_list[ii].service_description);
                                strcpy(device_list[device_id].service_list[ii].groupID,tmp_device_list[j].service_list[ii].groupID);

                        }
                }
        }
        i = 0;
        while (i<device_list[device_id].num_service)
        {
                printf("service %d is %s\n",i+1,device_list[device_id].service_list[i].service_name);
                strcat(tmp_list,device_list[device_id].service_list[i].service_name);
                strcat(tmp_list,",");
                i++;
        }
        return device_list[device_id].num_service;
}

void con_rfcomm(char name[])
{
    int i,ii,check;
    unsigned int con_id;
    unsigned short srv_ch, line;
    unsigned char tmp_bd[6];

    i=0;
    check = 0;
    while ((i<num_device)&&(check==0))
    {
        if ((ii = strncmp(device_list[i].friendly_name,name,strlen(name)-1)) == 0)
                check = 1;
        i++;
    }

    if (check==1)
    {
        if (device_list[i-1].status == 0)
                device_list[i-1].status = 1;
        else if (device_list[i-1].status == 2)
                device_list[i-1].status = 3;

    /* layer specific for rfcomm is 16 bits => | line | dlci | */
        change_str_to_addr(device_list[i-1].bd_addr,tmp_bd);
        line = (unsigned short)(0);
        srv_ch = (unsigned short)(1);
        con_id = CREATE_RFCOMM_ID(line, srv_ch<<1);
        printf("con_id(connect rfcomm) : %d\n",con_id);
        printf("tmp_bd %x:%x:%x:%x:%x:%x\n",tmp_bd[0],tmp_bd[1],tmp_bd[2],tmp_bd[3],tmp_bd[4],tmp_bd[5]);

        bt_connect(bt_fd, tmp_bd, con_id);
    }
    return;
}

void get_remote_name(char friendly_name[])
{
        int i;

        for (i=0; i<num_device; i++)
        {
                if (device_list[i].status!=0)
                {
                        strncpy(friendly_name,device_list[i].friendly_name,strlen(device_list[i].friendly_name)-1);
                        return;
                }

        }

}

void disc_sdp(void)
{
        #ifdef BTD_USERSTACK
        sdp_shutdown();
        #endif
        return;
}

/*********************************************************************/
/*********************************************************************/
