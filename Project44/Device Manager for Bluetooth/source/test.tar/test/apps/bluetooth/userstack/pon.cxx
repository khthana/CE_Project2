#include </usr/local/include/FL/Fl.H>
#include </usr/local/include/FL/Fl_Window.H>
#include </usr/local/include/FL/Fl_Box.H>
//#include </usr/local/include/FL/Fl_Button.H>
#include </usr/local/include/FL/Fl_Input.H>

int main(int argc,char **argv){
Fl_Window *window = new Fl_Window(300,180);
Fl_Box *box = new Fl_Box(20,40,260,100,"Hello, World!");
//Fl_Button *button = new Fl_Button(20,40,10,20,"ponnarak");
//button->type(0);
Fl_Input *input =new Fl_Input(30,50,40,20,"xxx");
input ->value("ponponpon");
box ->box(FL_UP_BOX);
box ->labelsize(36);
box ->labelfont(FL_BOLD+FL_ITALIC);
box ->labeltype(FL_SHADOW_LABEL);
window->end();
window->show(argc, argv);
return Fl::run();
}

/*gcc -c -I/usr/local/include first.cxx
gcc first.o -L/usr/local/lib -L/usr/X11/lib -lfltk - lXext -lX11 -lm  */