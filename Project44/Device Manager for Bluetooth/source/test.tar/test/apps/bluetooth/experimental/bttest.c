
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>

#if defined(HAVE_READLINE_READLINE)
#include <readline/readline.h>
#include <readline/history.h>
#elif defined(HAVE_READLINE)
#include <readline.h>
#include <history.h>
#endif

#include "btd.h"
#include "bttest.h"
#include "bt_if.h"
#include "bt_misc.h"
#include "bt_conf.h"
#include "bt_vendor.h"
#include "bt_errno.h"
/* ============================================================== */

#define BTD_HISTORY_FILE "/tmp/btd_history"

char* menu[] =
{
  "\nMenu",
  "------------------------",
  "  inq <max nbr resp> <inq time>",
  "  rf_conn <xx:xx:xx:xx:xx:xx> <srv ch> <line>",
  "  rf_send <nbr bytes> <nbr repeats> <line>", 
  "  rf_disc <line>",
  "  rf_wait <line>", /* waits for a connection on that line */
  "  ping <xx:xx:xx:xx:xx:xx> <nbr bytes>",
  "  getinfo <xx:xx:xx:xx:xx:xx> <type>",
  "  setbd <xx:xx:xx:xx:xx:xx>", /* only ericsson HW */
  "  readbd", /* read module bd address */
  "  reset", /* reset board */
  "  bt_wrscan <mode>",
  "  force_ms <0/1>", /* force ms switch */
  "  role_switch <xx:xx:xx:xx:xx:xx> <role> (0=master, 1=slave)",
  "  stat ", /* similar to reading the /proc/bt */
#ifdef ECS_TEST_FUNCTIONS
  "  ecs_entertest <handle> (hex)",
  "  ecs_testctrl <par1,par2,...,par9> (hex)",
  "  ecs_txtest   <par1,par2,...,par11> (hex)",
  "  ecs_testcon <xx:xx:xx:xx:xx:xx> (hex)",  
  "  enable_dut", /* enable device under test mode */
#endif
#ifdef CONFIG_BLUETOOTH_UNPLUG_TEST
  "  upt <teststring>", /* e.g testcase 4.3 't 43' */
#endif
  "  quit", 

  "",
  "--- Test commands ------",
  "  sdp_conn  <xx:xx:xx:xx:xx:xx>",
  "  tcs_conn  <xx:xx:xx:xx:xx:xx>",
  "                               ",
  "  test_conn  <xx:xx:xx:xx:xx:xx> <psm> <line>", /* l2cap test using PSM psm */
  "  test_disc <psm>", /* disconnect the connection with psm=psm */
  "  test_case_reject <xx:xx:xx:xx:xx:xx>", 
  "                               ",
  "  bb_conn  <xx:xx:xx:xx:xx:xx>", /* connect only baseband */
  "  bb_disc  <hci handle>", /* disconnect baseband */
  "  lcid_disconnect <lcid>", /* Disconnects a connection with lcid = lcid */
  "                               ",
  "-------- Hotlist -------",
  "  (Use !<num> to expand the bdaddr from the list in any command)",
  "  hotlist_set <pos> <xx:xx:xx:xx:xx:xx>",
  "  hotlist_show", 
  "",

  NULL
};

static unsigned char hotlist[10][6];
static int quit_bttest;

#if !defined(HAVE_READLINE) && !defined(HAVE_READLINE_READLINE)
static void read_history(char *hist_file_name);
static void write_history(char *hist_file_name);
static void add_history(char *command);
static char *readline(char *promt);
#endif 

void
show_menu(void)
{
  char** option;

  option = menu;
  while (*option)
  {
    printf("%s\n", *option);
    option++;
  }         
}

int
main(int argc, char **argv)
{
  int bt_cfd, i , j, tmp;
  FILE *hotlist_fd;
  quit_bttest = 0;

  /* Open BT ctrl device */  
  if ((bt_cfd = bt_openctrl()) < 0)
  {
    perror("Could not open BT control device");
    exit(1);
  }

  /* First of all check that stack is running */
  if (!bt_isinitiated(bt_cfd))
  {
    printf("Stack not initiated, exit\n");
    exit(1);
  }

  if((hotlist_fd = fopen("/etc/.hotlist", "rb")))
  {
    for (i = 0; i < 10 ; i++) 
    {
      for (j = 0 ; j < 6 ; j++) 
      {
        hotlist[i][j] = fgetc(hotlist_fd);
      }
    }
    fclose(hotlist_fd);
  }
  else
  {
    for (i = 0; i < 10 ; i++) 
    {
      for (j = 0 ; j < 6 ; j++) 
      {
        hotlist[i][j] = 0;
      }
    }
  }
  
  if(argc > 1)
  {
    for(i = 1 ; i < argc ; i++)
    {
      if((tmp = process_cmd(argv[i], bt_cfd)) < 0)
      {
	return -1;
      }
    }
    return 0;
  }
      
  read_history(BTD_HISTORY_FILE);  
  
  show_menu();
  
  while (1)
  {
    char *tmp_char, hotlist_entry;
    char tmp_line[200];
    char *line = (char*) readline("> ");
    add_history(line);
    
    if((tmp_char = strstr(line, "!")))
    {
      if(*(tmp_char + 1) >= '0' && *(tmp_char + 1) <= '9')
      {
        hotlist_entry = *(tmp_char + 1) - '0';
        memcpy(&tmp_line[0], line, tmp_char - line);
        sprintf(&tmp_line[tmp_char - line], "%02X:%02X:%02X:%02X:%02X:%02X%s\0", 
                hotlist[hotlist_entry][0],
                hotlist[hotlist_entry][1],
                hotlist[hotlist_entry][2],
                hotlist[hotlist_entry][3],
                hotlist[hotlist_entry][4],
                hotlist[hotlist_entry][5],
                tmp_char + 2);
        tmp = process_cmd(&tmp_line[0], bt_cfd);
      }
    }
    else
    {   
      tmp = process_cmd(line, bt_cfd);
    }

    if (quit_bttest == QUIT_BTD)
    {
      break;
    }
    free(line);
  }
  write_history(BTD_HISTORY_FILE);
  exit(0);
}

int
process_cmd(char *buf, int bt_cfd)
{
  unsigned int i, con_id, tmp[10], repeat, line = 0, profile, srv_ch;
  int retval = 0;
  unsigned char bd[6];

  if (!strncmp(buf, "quit", 4))
  {
    quit_bttest = QUIT_BTD;
  }
  else if (sscanf(buf, "rf_conn %x:%x:%x:%x:%x:%x %d %d",
		  &tmp[0], &tmp[1], &tmp[2],
		  &tmp[3], &tmp[4], &tmp[5],
		  &tmp[6], &tmp[7]) == 8)
  {

    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
    
    /* layer specific for rfcomm is 16 bits => | line | dlci | */
    
    line = (unsigned short)(tmp[7]);
    srv_ch = (unsigned short)(tmp[6]);
    con_id = CREATE_RFCOMM_ID(line, srv_ch<<1);
    
    retval = bt_connect(bt_cfd, bd, con_id);
  }
  else if (sscanf(buf, "bt_wrscan %d", &tmp[0]) == 1)
  {
    printf("Setting wr scan enable to %d\n", tmp[0]);
    bt_write_scan_enable(bt_cfd, tmp[0]);
  }
  else if (sscanf(buf, "rf_disc %d", &line) == 1)
  {
    unsigned int con_id;
    con_id = CREATE_RFCOMM_ID(line, 0 /* fixme -- don't care */);
    retval = bt_disconnect(bt_cfd, con_id);
  }
  else if (sscanf(buf, "rf_wait %d", &line) == 1)
  {
    bt_waitconnection(bt_cfd, line);
    printf("Connect on line %d\n", line);
  }
  else if (sscanf(buf, "inq %d %d", &tmp[0], &tmp[1]) == 2)
  {
    retval = bt_inquiry(bt_cfd, tmp[0], tmp[1]);
  }
  else if (sscanf(buf, "rf_send %d %d %d", &i, &repeat, &line) == 3)
  {
    int btfd;
    char dev[20];
    sprintf(dev, "/dev/ttyBT%d", line);

    btfd = open(dev, O_RDWR | O_NOCTTY);

    if (btfd > 0)
      return bt_send(btfd, i, repeat);
    else
    {
      perror("bt_send");
      return -1;
    }
    
    close(btfd);
  }
  else if (sscanf(buf, "setbd %x:%x:%x:%x:%x:%x",
                  &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5]) == 6)
  { 
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }

    bt_set_bd_addr(bt_cfd, &bd[0]);
  }
  else if (strncmp(buf, "readbd", 6) == 0)
  {  
    read_local_bd(bt_cfd, bd);
    printf("Local BD: %s\n", bd2str(bd));
  }
  else if(sscanf(buf, "role_switch %x:%x:%x:%x:%x:%x %d ",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], 
		 &tmp[5], &tmp[6])== 7)
  {
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
  
    role_switch(bt_cfd, &bd[0], tmp[6]);
  }
  else if (sscanf(buf, "force_ms %d", &tmp[0]) == 1)
  {
    printf("Setting force m/s switch to %d\n", tmp[0]);
    bt_force_msswitch_as_server(bt_cfd, tmp[0]);
  }
#ifdef ECS_TEST_FUNCTIONS
  else if (sscanf(buf, "ecs_testctrl %x,%x,%x,%x,%x,%x,%x,%x,%x",
		  &tmp[0], &tmp[1], &tmp[2],
		  &tmp[3], &tmp[4], &tmp[5],
		  &tmp[6], &tmp[7], &tmp[8]) == 9)
  {
    ericsson_test_control(&tmp[0]);
  }
  else if (sscanf(buf, "ecs_entertest %x", &tmp[0]) == 1)
  {
    ericsson_enter_test_mode(&tmp[0]);    
  }
  else if (sscanf(buf, "ecs_testcon %x:%x:%x:%x:%x:%x",
             &bd[5], &bd[4], &bd[3], &bd[2], &bd[1], &bd[0]) == 6)
  {
    test_connection_req(&bd[0]);
  }
  else if (strncmp(buf, "enable_dut", 10) == 0)
  {
    printf("Enable device under test mode\n");
    enable_dut(bt_cfd);
    printf("done.\n");
  }
  else if (sscanf(buf, "ecs_txtest %x,%x,%x,%x,%x,%x,%x,%x,%x,%x,%x",
		  &tmp[0], &tmp[1], &tmp[2],
		  &tmp[3], &tmp[4], &tmp[5],
		  &tmp[6], &tmp[7], &tmp[8],
		  &tmp[9], &tmp[10]) == 11)
  {
    ericsson_tx_test(&tmp[0]);
  }
#endif
  else if (strncmp(buf, "stat", 4) == 0)
  {
    bt_showstatus();
  }
  else if (sscanf(buf, "ping %x:%x:%x:%x:%x:%x %d",
		  &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5], 
		  &tmp[6]) == 7)
  {
    unsigned char buf[1024];
    int count = tmp[6];

    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
 
    printf("Pinging: %s\n", bd2str(bd));

    /* fill it with something */
    memset(buf, 'A', count);

    retval = bt_ping(bt_cfd, bd, (unsigned char*)&buf , (unsigned short)count);  
  }
  else if (sscanf(buf, "getinfo %x:%x:%x:%x:%x:%x %d",
		  &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5], 
		  &tmp[6]) == 7)
  {
    unsigned short type = tmp[6];

    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
 
    printf("Get info from: %s\n", bd2str(bd));

    bt_getinfo(bt_cfd, bd, type);
  }
#ifdef CONFIG_BLUETOOTH_UNPLUG_TEST
  else if (strncmp(buf, "upt", 3) == 0)
  {
      retval = bt_testcmd(bt_cfd, buf+4);
  }
#endif
  else if (sscanf(buf, "getinfo %x:%x:%x:%x:%x:%x %x",
		  &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5], 
		  &tmp[6]) == 7)
  {
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
 
    printf("Getinfo <%02X:%02X:%02X:%02X:%02X:%02X> type : %d\n",
           bd[0], bd[1], bd[2],
           bd[3], bd[4], bd[5], tmp[6]);
    bt_getinfo(bt_cfd, bd, tmp[6]);
  }
  else if(sscanf(buf, "tcs_conn %x:%x:%x:%x:%x:%x",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5]) == 6)
  {    
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }

    printf("Connecting TCS to bd : %02X:%02X:%02X:%02X:%02X:%02X\n",
           bd[0], bd[1], bd[2],
           bd[3], bd[4], bd[5]);

    retval = bt_connect(bt_cfd, bd, (TCS_LAYER << 16) & 0xffff000);
  }

  /* FIXME so that we can specify which line to connect */
  else if(sscanf(buf, "rf_conn %x:%x:%x:%x:%x:%x %d",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5],
		 &srv_ch) == 7)
  {
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
    
    printf("Connecting RFCOMM to bd : %02X:%02X:%02X:%02X:%02X:%02X\n",
	   bd[0], bd[1], bd[2],
	   bd[3], bd[4], bd[5]);
    
    printf("RFCOMM server channel is %d\n", srv_ch);
    retval = bt_connect(bt_cfd, bd, CREATE_RFCOMM_ID(0, srv_ch << 1));
  }
  else if(sscanf(buf, "sdp_conn %x:%x:%x:%x:%x:%x",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5]) == 6)
  {    
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }
      
    printf("Connecting SDP to bd : %02X:%02X:%02X:%02X:%02X:%02X\n",
           bd[0], bd[1], bd[2],
           bd[3], bd[4], bd[5]);

    retval = bt_connect(bt_cfd, bd, (SDP_LAYER << 16) & 0xFFFF0000);
  }
  else if(sscanf(buf, "test_conn %x:%x:%x:%x:%x:%x %x %d",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5], &tmp[6], &tmp[7]) == 8)
  {
    for (i = 0; i < 6; i++)
    {
      bd[i] = (unsigned char)tmp[i];
    }

    printf("Connecting test layer (psm 0x%x, line %d) to bd : %02X:%02X:%02X:%02X:%02X:%02X\n", 
	   tmp[6], tmp[7], bd[0], bd[1], bd[2], bd[3], bd[4], bd[5]);

    retval = bt_connect(bt_cfd, bd, ((tmp[6] << 16) & 0xffff0000) | tmp[7]);
  }
  else if (sscanf(buf, "test_case_reject %x:%x:%x:%x:%x:%x",
                  &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5]) == 6)
  {
    retval = bt_testcmd(bt_cfd, buf);
  }
  else if (sscanf(buf, "test_disc %x", &tmp[0]) == 1)
  {
    printf("Disconnecting layer (PSM: %x)\n", tmp[0]);
    retval = bt_disconnect(bt_cfd, (tmp[0] << 16) & 0xffff0000);
  }
  else if(sscanf(buf, "bb_conn %x:%x:%x:%x:%x:%x",
		 &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5]) == 6)
  {
    retval = bt_testcmd(bt_cfd, buf);
  }
  else if(sscanf(buf, "bb_disc %d", &i) == 1)
  {
    printf("Disconnecting hci handle %d\n", i);
    retval = bt_testcmd(bt_cfd, buf);
  }
  else if(sscanf(buf, "lcid_disconnect %d", &i) == 1)
  {
    printf("Disconnecting lcid %d", i);
    retval = bt_testcmd(bt_cfd, buf);
  }
  else if(sscanf(buf, "hotlist_set %d %x:%x:%x:%x:%x:%x", 
                 &tmp[6], &tmp[0], &tmp[1], &tmp[2], &tmp[3], &tmp[4], &tmp[5]))
  {
    FILE *hotlist_fd;
    int i, j;
    
    if(tmp[6] > 9)
    {
      printf("Max number in hotlist is 9.\n");
    }
    else
    {
      hotlist[tmp[6]][0] = tmp[0];
      hotlist[tmp[6]][1] = tmp[1];
      hotlist[tmp[6]][2] = tmp[2];
      hotlist[tmp[6]][3] = tmp[3];
      hotlist[tmp[6]][4] = tmp[4];
      hotlist[tmp[6]][5] = tmp[5];
      if((hotlist_fd = fopen("/etc/.hotlist", "wb")))
      {
        for (i = 0; i < 10 ; i++) 
        {
          for (j = 0 ; j < 6 ; j++) 
          {
            fputc(hotlist[i][j], hotlist_fd);
          }
        }
        fclose(hotlist_fd);
      }
    }
  }
  else if(strcmp(buf, "hotlist_show") == 0)
  {
    int i, j;
    for(i = 0 ; i < 10 ; i++)
    {
      printf("%d: %02X:%02X:%02X:%02X:%02X:%02X\n", i, 
             hotlist[i][0], hotlist[i][1], hotlist[i][2], hotlist[i][3], hotlist[i][4], hotlist[i][5]);
    }
  }
  else if(strcmp(buf, "test_case_disable_disconnect") == 0)
  {
    printf("Disabling sending of disconnect respons\n");
    bt_testcmd(bt_cfd, buf);
  }
  else if(strcmp(buf, "test_case_enable_disconnect") == 0)
  {
    printf("Enabling sending of disconnect respons\n");
    bt_testcmd(bt_cfd, buf);
  }   
  else
  {
    printf("> error: command not recognized or wrong syntax\n");
    show_menu();
    return 0;
  }  
      
  return 0;
}

/* readline replacement  - mfuchs */
#if !defined(HAVE_READLINE) && !defined(HAVE_READLINE_READLINE)
#define MAXLINE 100

static void read_history(char *hist_file_name)
{
}

static void write_history(char *hist_file_name)
{
}

static void add_history(char *command)
{
}

static char *readline(char *promt)
{
  int len;
  char *line;

  if ((line = malloc(MAXLINE)))
  {
    printf("%s", promt);
    fflush(stdout);
    *line = 0;
    if ((len = read(STDIN_FILENO, line, MAXLINE-1)) >= 0)
    {
      line[len] = 0;
    }
  }

  return line;
}
#endif /* !HAVE_READLINE */



/* bttest.c */
/* ============================================================== */
