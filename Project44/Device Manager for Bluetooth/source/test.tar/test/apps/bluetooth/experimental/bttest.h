
#ifndef __BT_TEST_H__
#define __BT_TEST_H__

#define START_PPP 1
#define QUIT_BTD 2
int process_cmd(char *buf, int bt_cfd);
#endif /* __BT_TEST_H__*/

