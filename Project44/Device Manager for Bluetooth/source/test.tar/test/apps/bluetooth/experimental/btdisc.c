
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <getopt.h>

#include "btd.h"
#include "bt_if.h"
#include "bt_conf.h"
#include "bt_misc.h"
    
#define DEFAULT_BTDEV "/dev/ttyBT0"

/* 
 * Syntax: btdisc [-d <dev>] -D <rfcomm dlci> 
 */

int
main(int argc, char **argv)
{
  char *btdev = DEFAULT_BTDEV;
  int con_id, bt_cfd, dlci = -1, line, opt;
  int result;

  /* Print header if called via http */
  if (getenv("REQUEST_METHOD") != NULL)
  {
    printf("Content-type: text/plain\r\n\r\n");
  }

  /* now parse options */
  while ((opt = getopt(argc, argv, "d:D:")) != -1)
  {
    switch (opt)
    {
     case 'd':
      /* BT device */
      btdev = optarg;
      printf("btdev: %s\n", btdev);
      break;
          
     case 'D':
      dlci = atoi(optarg);
      printf("RFCOMM dlci: %d\n", dlci);
      break;
      
     default:
      break;
    }
  }

  if (optind < argc || dlci < 0)
  {
    printf("Wrong syntax or missing parameters\n");
    printf("Syntax: %s [-d <dev>] -D <rfcomm dlci>\n", argv[0]);
    exit(0);
  }

  /* Open BT ctrl device */  
  if ((bt_cfd = bt_openctrl()) < 0)
  {
    perror("Could not open BT control device");
    exit(1);
  }

  /* First of all check that stack is running */
  if (!bt_isinitiated(bt_cfd))
  {
    printf("Stack not initiated, exit\n");
    exit(1);
  }

  line = atoi((char*)(btdev+10));
  
  /* Connect RFCOMM session on line */
  printf("Disconnecting line %d [%s]\n", line, btdev);

  con_id = CREATE_RFCOMM_ID(line, dlci);

  result = bt_disconnect(bt_cfd, con_id);

  close(bt_cfd);
  exit(result);
}
