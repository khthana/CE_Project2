
#ifndef __BT_IPA_H__
#define __BT_IPA_H__

#include <sys/types.h>
#include <netinet/in.h>
#include "bt_conf.h"

#define IPASERVER "/tmp/ipa_server"
#define IPA_MSG_MAXSIZE 256

/* ================================================================*/
/* IPA messages */

/* Requests */
#define IPAREQ_GETIPSET 0
#define IPAREQ_RELEASEIPSET 1
#define IPAREQ_GETCLIENTIPDHCP 2
#define IPAREQ_UPDATEIPMAPPING 3

/* Responses */
#define IPARSP_STATUS 10
#define IPARSP_PEERSETTINGS 11

/* Status codes */
#define IPA_STATUSSUCCESS 0
#define IPA_STATUSFAILED 1

/* Error codes */
#define ERR_WRONGSTATE 2
#define ERR_REQUESTFAILED 3

/* ================================================================*/
/* IPA Client struct */

typedef struct ip_set
{
  struct in_addr ip;               /* Returns IP address for the client */
  struct in_addr dns[2];           /* Returned DNS servers */
  int nbr_of_dns;                  /* Returns number of found DNS servers. */
  struct in_addr wins[2];          /* Returned MS WINS servers */
  int nbr_of_wins;                 /* Returns number of found MS WINS 
				      servers*/
  struct in_addr netmask;          /* Returns the netmask to be used */
  int proxyarp;                    /* Returns 1 if proxyarp will be used */
  int useradius;                   /* Returns 1 if RADIUS is being used */ 
  int useradiusip;                 /* Returns 1 if IP address assignment via
                                      RADIUS is allowed */
  int usingmasq;                   /* Returns 1 if NAT is being used */
} ip_set;

/* ================================================================*/
/* IPA message structs */

typedef struct ipa_msg
{
  unsigned short type;
  unsigned short len; /* Length of msg excluding type and len */           
  unsigned char msg[0];
} ipa_msg;

typedef struct ipa_request
{
  unsigned short id;               /* Line associated mapped to this client */
  unsigned char remote_bd[6];      /* Requestors BD address */
} ipa_request;

typedef struct ipa_response
{
  unsigned short id;
  /* add request type ? */
  unsigned short status;
  struct ip_set set;
} ipa_response;

/* acknowledge on a request */
typedef struct ipa_status
{
  unsigned short id;
  unsigned short status;
} ipa_status;


int ipa_open(void);
void ipa_close(int ipa_fd);
int ipa_write(int ipa_fd, ipa_msg *msg);
int ipa_read(int ipa_fd, ipa_msg *msg);
void show_ipset(struct ip_set* set, int line);

#endif /* __BT_IPA_H__ */
