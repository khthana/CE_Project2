
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <getopt.h>
#include <setjmp.h>

#include "btd.h"
#include "bt_conf.h"
#include "bt_vendor.h"
#include "bt_misc.h"
#include "bt_if.h"
#include "bt_ipa.h"

/* 
 * Syntax: btsend -d <device> -s <length> -r <repeat>
 */

int
main(int argc, char **argv)
{
  char *btdev = NULL;
  int line, bt_fd, opt, len = -1, repeat = 1;

  /* First of all check that stack is running */
  if (!bt_isinitiated(-1))
  {
    printf("Stack not initiated, exit\n");
    exit(1);
  }

  /* now parse options */
  while ((opt = getopt(argc, argv, "d:s:r:")) != -1)
  {
    switch(opt)
    {
     case 'd':
      /* BT device */
      btdev = optarg;
      break;
      
     case 's':
      len = atoi(optarg);
      break;
      
     case 'r':
       repeat = atoi(optarg);
       break;

     default:
      break;
    }
  }

  if (!btdev || (len == -1))
  {
    printf("Syntax: btsend -d <device> -s <length> -r <repeat>\n");
    exit(1);
  }

  /* Open BT device */  

  printf("Opening %s\n", btdev);
  if ((bt_fd = open(btdev, O_RDWR | O_NOCTTY)) < 0)
  {
    printf("could not open %s\n", btdev);
    exit(1);
  }    

  line = atoi((char*)(btdev+10));

  /* Wait for an rfcomm connection */
  bt_waitline(bt_fd, line);

  /* Send the data */
  bt_send(bt_fd, len, repeat);
  
  close(bt_fd);

  exit(0);
}
