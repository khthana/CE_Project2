
#ifndef __BT_MISC_H__
#define __BT_MISC_H__

#define USE_NO_FLOW      0 
#define USE_FLOW_CTRL    1
#define USE_CURRENT_FLOW 2

#define CLIENT 0
#define SERVER 1

#define LOCAL_NAME_LENGTH  32

void fd_setup(int fd, const char *speedstr, int flow);
unsigned long speedstrtoli(const char *speedstr);
int translate_speed(int spd);

/* Socket handling */
int open_socket(const char *name, int role);
int open_tcpsocket(const char *addrstr, int role);

int write_pidfile(const char *pidname);

int restart_btd(void);

char *get_local_ip_address(void);
const char *bd2str(const unsigned char *bd);
#ifndef BT_USERSTACK
void print_data(const char *message, const unsigned char *buf, int len);
#endif
void set_pin_code(const char *pin);

#endif /* __BT_MISC_H__*/
