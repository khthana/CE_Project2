
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <syslog.h>
#include <getopt.h>
#include <setjmp.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/wait.h>

#include "btd.h"
#include "bt_conf.h"
#include "bt_vendor.h"
#include "bt_misc.h"
#include "bt_if.h"

#define D(x) //x

/* ========================================================== */
/* General BTD stuff */

static char *physdev = DEFAULT_PHYS_DEV;
static char *speedstr = DEFAULT_SPEED;
static int bt_cfd = -1; /* control tty for bt stack */

static int btd_pid;
static char local_name[LOCAL_NAME_LENGTH+1]; /* 'friendly' name in HW module */
static const char *init_hw_speedstr = NULL; /* not set */
static int do_hwinit = 1; /* do vendor specific initialization */
static int do_reset = 0;  /* reset hw using I/O pins */
static int flow_control = USE_FLOW_CTRL;
static sigjmp_buf jmpbuffer; /* used to jump back in program after doing reset */
static int sdpsrv_pid = 0;
int phys_fd = -1;  /* physical device e.g ttyS0 */

/* long option list */
static struct option long_options[] =
{
  { "noflow",        1, NULL, 'f' },      /* do not use flow control */
  { "initial-speed", 1, NULL, 'i' },      /* initial uart speed */
  { "physdev",       1, NULL, 'u' },      /* phys device used from stack */
  { "local-name",    1, NULL, 'n' },      /* set local bluetooth name */
  { "reset",         0, NULL, 'R' },      /* reset BT HW */
  { "speed",         1, NULL, 's' },      /* uart speed towards hw */
  { 0, 0, 0, 0 }
};

static int option_index = 0;

static void init();
static void init_sighandler(void);
static void btd_cleanup(void);
static void btd_killchilds(void);
static void sighandler(int sig);


int
main(int argc, char **argv)
{  
  int opt;
  int bt_disc = N_BT;

  syslog(LOG_INFO, "Bluetooth daemon starting");

  if (atexit(btd_cleanup) < 0)
  {
    printf("btd failed to register cleanup function.\n");
    exit(1);
  }

  /* now parse options */
  while ((opt = getopt_long(argc, argv, "fi:nRs:u:",
			    long_options, &option_index)) != -1)
  {
    switch(opt)
    {
     case 'f':
      /* do not use flow control */
      flow_control = USE_NO_FLOW;
      D(syslog(LOG_INFO, "no flow control"));
      break;

     case 'i':
      /* uart device */
      init_hw_speedstr = optarg;
      D(syslog(LOG_INFO, "init_hw_speed %s baud", init_hw_speedstr));
      break;

     case 'n':
      D(syslog(LOG_INFO, "setting local name to %s", optarg));
      strncpy(local_name, optarg, LOCAL_NAME_LENGTH);
      local_name[LOCAL_NAME_LENGTH] = '\0';
      break;

     case 'R':
      /* try to reset the hardware */
      D(syslog(LOG_INFO, "reset HW"));
      do_reset = 1;
      break;

     case 's':
      /* speed */
      D(syslog(LOG_INFO, "phys dev running at %s", optarg));
      speedstr = optarg;
      break;

     case 'u':
      /* uart device */
      D(syslog(LOG_INFO, "phys dev: %s", optarg));
      physdev = optarg;
      break;

     default:
      break;
    }
  }

  /* Set restart point */
  if (sigsetjmp(jmpbuffer, 1) != 0)
  {
    syslog(LOG_INFO, "Restart...");
    sleep(1);
  }

  init();

  if ((phys_fd = open(physdev, O_RDWR | O_NOCTTY)) < 0)
  {
    perror("Could not open phys dev");
    exit(1);
  }

  /* Sets initial HW baudrate */

  if (init_hw_speedstr != NULL)
    fd_setup(phys_fd, init_hw_speedstr, flow_control);
  else
    init_phys(phys_fd, flow_control);

  /* Set the current tty to the bluetooth discpline */
  set_bt_line_disc(phys_fd, bt_disc, physdev);
  
  bt_cfd = bt_openctrl();

  tcflush(phys_fd, TCIOFLUSH);

  /* Hardreset of BT hardware */
  if (do_reset)
    reset_hw();
  
  if (init_stack(bt_cfd) < 0)
  {
    /* For some reason, the stack sometimes fails to initialize the first
       time. So let us try an extra time, just to be sure... */
    if (init_stack(bt_cfd) < 0)
    {
      init_failed(bt_cfd, phys_fd, init_hw_speedstr, flow_control);
    }
  }

  if (do_hwinit)
    init_hw(bt_cfd, phys_fd, speedstr);
  
  /* All initialized and ready to accept connections in other BT apps */

  while (1)
    sleep(100);
} /* main */

/* ============================================================= */
/* Signal handler */

static void
init_sighandler(void)
{
  struct sigaction act;

  D(syslog(LOG_INFO, "Initiating signal handler"));
  act.sa_handler = sighandler;
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  sigaction(SIGUSR1, &act, 0); /* Restart application */
  sigaction(SIGTERM, &act, 0); /* Terminate application */
}

static void
sighandler(int sig)
{
  D(syslog(LOG_INFO, "Sighandler got signal: %d", sig));

  if (sig == SIGUSR1)
  {
    /* Shutdown all and restart */
    btd_cleanup();
    siglongjmp(jmpbuffer, 1);
  }
  else if (sig == SIGTERM)
  {
    exit(0);
  }
  return;
}

/* ============================================================= */
/* General BTD stuff */

static void init()
{ 
  btd_pid = write_pidfile(PID_FILE);  
  init_sighandler();
  
  if ((sdpsrv_pid = start_sdp_server()) < 0)
  {
    perror("start_sdp_server");
    exit(1);
  }
}

static void
btd_cleanup(void)
{
  D(syslog(LOG_INFO, __FUNCTION__));
  btd_killchilds();

  printf("Shutting down Bluetooth stack\n");
  shutdown_stack(bt_cfd);

  if (bt_cfd != -1)
  {
    close(bt_cfd);
    bt_cfd = -1;
  }
  
  /* now close phys device */
  if (phys_fd != -1)
  {
    tcflush(phys_fd, TCIOFLUSH);
    close(phys_fd);
    phys_fd = -1;
  }

  /* pid_fd is set if we created the pid file when we started */
  if (btd_pid != -1)
  {
    unlink(PID_FILE);
  }
}

static void
btd_killchilds(void)
{
  if (sdpsrv_pid > 0)
  {
    D(syslog(LOG_INFO, "Killing SDP server"));
    kill(sdpsrv_pid, SIGTERM);
    
    if (waitpid(sdpsrv_pid, NULL, 0) < 0)
      perror("waitpid sdp server");

    sdpsrv_pid = 0;
  }
}

/* ============================================================= */
