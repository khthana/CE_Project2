

/*==================================================================*/
/* Macros used to tell origin of error */

/* Unique status codes 32 bits : | layer 16 bits | code 16 bits | */
#define MSGCODE(layer, msgcode) ((((layer)<<16)&0xffff0000) | ((msgcode)&0xffff))
#define MSG_GET_LAYER(msg) ((msg >> 16) & 0x0000ffff)
#define MSG_GET_CODE(msg) (msg & 0x0000ffff)

/* Layer ID */
#define MSG_LAYER_HCI 1
#define MSG_LAYER_L2CAP 2
#define MSG_LAYER_RFCOMM 3
#define MSG_LAYER_SDP 4
#define MSG_LAYER_TCS 5
#define MSG_BT_INTERFACE 6

/*==================================================================*/
/* HCI */

/* Uses errorcodes as specified in the BT specification */

/*==================================================================*/
/* L2CAP */

#define L2CAP_SUCCESS 0x0
#define L2CAP_CON_PENDING 0x1

/* Signalling response result */
#define L2CAP_PSMNEG 0x02
#define L2CAP_SECNEG 0x03
#define L2CAP_NOSRC 0x04

/* General l2cap return codes */
#define L2CAP_FAILED 0xf0
#define L2CAP_CON_UNRESPONSIVE 0xf1
#define L2CAP_INVALID_STATE 0xf2
#define L2CAP_NO_CONNECTION 0xf3
#define L2CAP_EXCEED_REMOTE_MTU 0xf4
#define L2CAP_RTX_TIMEOUT 0xf5

/*==================================================================*/
/* RFCOMM */
#define RFCOMM_INVALID_LINE 0xf0
#define RFCOMM_SRVCHN_CONNECTED 0xf1
#define RFCOMM_NO_DATA_ALLOWED 0xf2
#define RFCOMM_NO_CONNECTION 0xf3
#define RFCOMM_BAD_MAGIC_NUMBER 0Xf4

/* fixme */

/*==================================================================*/
/* SDP */

/* fixme */

/*==================================================================*/
/* TCS */

/* fixme */

/*==================================================================*/
/* BT INTERFACE */

#define BT_NOTCONNECTED 0x1
#define BT_ALREADYCONNECTED 0x2
#define BT_TIMEOUT 0x3
#define BT_LINE_BUSY 0x4
#define BT_INQ_FAILED 0x5
