
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

/* print in_addr */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h> 

#include "bt_if.h"
#include "bt_ipa.h"
#include "bt_conf.h"
#include "bt_misc.h"

#define D(x) //x

int ipa_open(void)
{
  int ipa_fd;
  
  D(syslog(LOG_INFO, "Opening socket to IP Assigner"));
  if ((ipa_fd = open_socket(IPASERVER, CLIENT)) < 0)
  {  
    perror("open_socket");
    return -1;
  }
  return ipa_fd;
}

void ipa_close(int ipa_fd)
{
  D(syslog(LOG_INFO, "Closing socket to IP Assigner"));
  close(ipa_fd);
}

/* Sends msg to IPA socket */
int ipa_write(int ipa_fd, ipa_msg *msg)
{
  D(syslog(LOG_INFO, __FUNCTION__ ": Sending ipa request (type: %d) len %d",
           msg->type, msg->len));

  return write(ipa_fd, msg, msg->len + sizeof(struct ipa_msg));
}

/* Copies received response into msg */

int ipa_read(int ipa_fd, ipa_msg *msg)
{
  char ipa_buf[256];
  int offset = 0, all_read = 0, msg_len = -1, c;
  ipa_msg *tmp;

  D(syslog(LOG_INFO, __FUNCTION__ ": Reading response"));

  while (!all_read)
  {
    c = read(ipa_fd, &ipa_buf+offset, 256-offset);  

    D(syslog(LOG_INFO, __FUNCTION__ ": Got %d bytes", c));

    if (c < 0)
      return c;

    offset += c;

    /* Have we got whole header ? */
    if (offset > sizeof(struct ipa_msg))
    {
      tmp = (struct ipa_msg*)(ipa_buf);
      msg_len = tmp->len;
    }
    
    if ((msg_len > 0) && (offset == (msg_len + sizeof(struct ipa_msg))))
      all_read = 1;
  }
  
  memcpy(msg, ipa_buf, offset);

  D(syslog(LOG_INFO, __FUNCTION__ ": Got %d bytes total", offset));

  return msg_len;  
}

void show_ipset(struct ip_set* set, int line)
{
  syslog(LOG_INFO, "IP set [line:%d]", line);

  if (set)
  {    
    syslog(LOG_INFO, "         ip: %s", inet_ntoa(set->ip));
    syslog(LOG_INFO, "    netmask: %s", inet_ntoa(set->netmask));

    if (set->nbr_of_dns >= 1)
      syslog(LOG_INFO, "       dns1: %s", inet_ntoa(set->dns[0]));

    if (set->nbr_of_dns >= 2)
      syslog(LOG_INFO, "       dns2: %s", inet_ntoa(set->dns[1]));

    if (set->nbr_of_wins >= 1)
      syslog(LOG_INFO, "      wins1: %s", inet_ntoa(set->wins[0]));

    if (set->nbr_of_wins >= 2)
      syslog(LOG_INFO, "      wins2: %s", inet_ntoa(set->wins[1]));

    syslog(LOG_INFO, "  useradius: %d", set->useradius);
    syslog(LOG_INFO, "useradiusip: %d", set->useradiusip);
    syslog(LOG_INFO, "  usingmasq: %d", set->usingmasq);
  }
}
