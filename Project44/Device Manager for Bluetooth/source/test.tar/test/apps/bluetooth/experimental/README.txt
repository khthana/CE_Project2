
New design of BTD
-----------------

Done :
----
o Split up of functionality into separate files 
o Fixed multipoint ppp
o Small BT apps used to connect/disconect/do inquiry/send data
o New API for IP assigner
o Major clean up

Still to be done :
----------------
o Make library of all helper files (with underscore in the name 
  e.g bt_misc.c)
o Fix usermode stack app
o Fix bt test application (similar as command line mode in old btd)
o Testing

======================================================================

Short description of new applications
-------------------------------------

btinit.c
--------
Minimal app responsible for opening and holding it open of phys dev, 
setting BT ldisc and initializing the stack.  Also starts up / shuts down 
the SDP server and sets local BT name in HW. This app should be used when 
developing non-network profiles e.g OBEX etc. 

Syntax:  ./bti [options]
	     
options: 
  
	-u, --physdev <uart device>
	Sets which uart device that will be used by the stack
	default: ttyS0
  
	-n, --local-name
	prefix used for the local bluetooth device name
	default: nothing
  
	-R, --reset
	reset bluetooth hardware before use
	default: no reset
  
	-s, --speed <speed>
	sets uart speed
	9600, 19200, 38400, 57600, 115200, 230400, 460800
	default: 115200 baud                 
  
	e.g
  	./bti --reset --speed 460800 --physdev /dev/ttyS0 --local-name OpenBT

btd.c 
-----
Works like btinit but also handles multipoint ppp connections,  communicates 
with a IP assign server through an defined API,starts modem emulator if 
enabled which in turn starts pppd after successful negotiation.
For now btd exec is called btdm to differentiate between new btd and old
while testing this one.

Syntax : ./btdm [options] 
        
	Same options as btinit except for 

	-m, --modem-emul <1/0>
	Switch modem emulation on/off (used when emulate modem in 
	windows dialup). 
	default: on

bttest.c
--------

Holds 'old' commandline mode which controls all test functions incl 
unplug tests, and other interaction with the stack.

modememul.c
-----------
Takes a list of args destined for pppd but first acts modem emulator on a 
ttyBT and then starts pppd after successful AT negotiation. Also handles 
autodetect of ppp frames so that modem emulator may always be used when 
testing with clients that does both dialup and standard LAN profile 
connections.

btcon.c 
-------
Opens an rfcomm channel over any ttyBT.

Syntax : btcon -d <device> -p <pincode> -a <BD> -S <rfcomm srv ch>
If using 'disable' as pin, authentication is disabled 

e.g btcon -d /dev/ttyBT0 -p 1234 -a 11:22:33:44:55:66 -S 2

btsend.c
--------
Connects a ttyBT using rfcomm and sends a number of datachunks if connected

Syntax : btsend -d <device> -s <length> -r <repeat>
e.g btsend -d /dev/ttyBT0 -s 1000 -r 100

btdisc.c
--------
Disconnects a ttyBT

Syntax : btdisc -d <dev> -S <rfcomm dlci>
e.g btdisc -d /dev/ttyBT0 -S 2


btinq.c
-------
Perform inquiry scan
Syntax : btinq -n <max # returned> -t <max inq time> 
e.g btinq -n 20 -t 15


By using these small apps together with btinit it will be possible to 
do whole test 'suites' using e.g expect scripts or similar.


======================================================================

Split up functionality into following files
-------------------------------------------

bt_if.c - Holds all interface functions towards the stack both for 
	  usermode and kernel mode (The only file which contains 
	  functionality for both kernel/usermode stack)

bt_vendor.c - Contains all vendor specific functions including test 
	      functions and init of HW.

bt_ipa.c - Jolds API towards the IP assign server. Responsible for getting
	   client IP, DNS, MS-WINS etc options for pppd.

bt_misc.c - Contains various helper functions

bt_conf.h - All configuration of the stack, currently only usermode parts
	    As of HW vendor setting we are considering doing the kernel 
	    parts configurable in runtime instead of setting it at 
	    compile time.

======================================================================
