
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <syslog.h>
#include <getopt.h>
#include <setjmp.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <arpa/inet.h>

#include "btd.h"
#include "bt_conf.h"
#include "bt_vendor.h"
#include "bt_misc.h"
#include "bt_if.h"
#include "bt_ipa.h"

#define D(x) //x

/* ========================================================== */
/* PPPD stuff */

#define NOCONNECTION 0
#define CONNECTED 1
#define WAITING_PPPCONF 2 
#define PPPCONF_DONE 3
#define MODEM_STARTED 4
#define PPPD_STARTED 5
#define WAITING_RETURN_PPPCONF 6

typedef struct peer_struct
{
  int state;
  int pppd_pid;
  int do_modememul;
  unsigned char remote_bd[6];
  struct ip_set *ipset;
} peer_struct;

struct peer_struct peerlist[BT_NBR_DATAPORTS];
struct ip_set ipsetlist[BT_NBR_DATAPORTS];

static unsigned char dev[20];
static unsigned char ip_addresses[35];
static unsigned char ms_dns1[35];
static unsigned char ms_dns2[35];
static unsigned char ms_wins1[35];
static unsigned char ms_wins2[35];
static unsigned char netmask[35];
static char remote_bd_str[18];
static char local_bd_str[18];

static fd_set rfd;
static struct timeval tv;

#define PEER(line) (peerlist[line])
#define IPSET(line) (ipsetlist[line])
#define STATE(line) (peerlist[line].state)

static unsigned char *pppd_options[32];

/* ========================================================== */
/* IPA stuff */

static int ipa_fd = -1;
static struct ipa_msg *msg;
static unsigned char ipa_buf[256];
static int parse_ipa_response(struct ipa_msg *msg);
static int ipa_sendrequest(int line, unsigned char *bd,
			   unsigned short type);

/* ========================================================== */
/* General BTD stuff */

#define PID_FILE "/var/run/btd.pid"
#define MODEMEMULCMD "memul" /* change name !*/
#define PPPDCMD "pppd"

static int do_hwinit = 1; /* do vendor specific initialization */
static int do_reset = 0;  /* reset hw using I/O pins */

static int modem_emul = 1;    /* default modem emulation is enabled */
static char *init_hw_speedstr = NULL; /* not set */

static int flow_control = USE_FLOW_CTRL;

static char *physdev = DEFAULT_PHYS_DEV;
static char *speedstr = DEFAULT_SPEED;
static char local_name[LOCAL_NAME_LENGTH+1]; /* 'friendly' name in HW module */

static int btd_pid = -1;
static int sdpsrv_pid = 0;
static int bt_cfd = -1;   /* control tty for bt stack */
static int phys_fd = -1;  /* physical device e.g ttyS0 */
static sigjmp_buf jmpbuffer; /* used to jump back in program after doing reset */

/* long option list */
static struct option long_options[] =
{
  { "noflow",        1, NULL, 'f' },      /* do not use flow control */
  { "initial-speed", 1, NULL, 'i' },      /* initial uart speed */
  { "physdev",       1, NULL, 'u' },      /* phys device used from stack */
  { "modem-emul",    1, NULL, 'm' },
  { "local-name",    1, NULL, 'n' },      /* set local bluetooth name */
  { "reset",         0, NULL, 'R' },      /* reset BT HW */
  { "speed",         1, NULL, 's' },      /* uart speed towards hw */
  { 0, 0, 0, 0 }
};

static int option_index = 0;

static void init();
static void init_sighandler(void);
static void btd_cleanup(void);
static void btd_killchilds(void);
static void sighandler(int sig);

static void discover_connections(int bt_cfd);
static void build_pppdopts(int line, char **opts);
static int start_pppd(int line, char *speedstr, char **opts);

/* ========================================================== */

int
main(int argc, char **argv)
{  
  int result, opt;
  int bt_disc = N_BT;
  
  syslog(LOG_INFO, "Bluetooth daemon starting");
  
  if (atexit(btd_cleanup) < 0)
  {
    printf("btd failed to register cleanup function.\n");
    exit(1); 
  }
  
  /* now parse options */
  while ((opt = getopt_long(argc, argv, "fi:m:nRs:u:",
			    long_options, &option_index)) != -1)
  {
    switch(opt)
    {
     case 'f':
      /* do not use flow control */
      flow_control = USE_NO_FLOW;
      D(syslog(LOG_INFO, "no flow control"));
      break;

     case 'i':
      /* uart device */
      init_hw_speedstr = optarg;
      D(syslog(LOG_INFO, "init_hw_speed %s baud", init_hw_speedstr));
      break;

     case 'm':
      /* uart device */
       modem_emul = atoi(optarg);
      break;
      
     case 'n':
      D(syslog(LOG_INFO, "setting local name to %s", optarg));
      strncpy(local_name, optarg, LOCAL_NAME_LENGTH);
      local_name[LOCAL_NAME_LENGTH] = '\0';
      break;
      
     case 'R':
      /* try to reset the hardware */
      D(syslog(LOG_INFO, "reset HW"));
      do_reset = 1;
      break;
      
     case 's':
      /* speed */
      D(syslog(LOG_INFO, "phys dev running at %s", optarg));
      speedstr = optarg;
      break;
      
     case 'u':
      /* uart device */
      D(syslog(LOG_INFO, "phys dev: %s", optarg));
      physdev = optarg;
      break;

     default:
      break;
    }
  }

  /* Set restart point */
  if (sigsetjmp(jmpbuffer, 1) != 0)
  {
    syslog(LOG_INFO, "Restart...");
    sleep(1);
  }    
  
  init();

  if ((phys_fd = open(physdev, O_RDWR | O_NOCTTY)) < 0)
  {
    perror("Could not open phys dev");
    exit(1);
  }

  /* Sets initial HW baudrate */
  if (init_hw_speedstr != NULL)
    fd_setup(phys_fd, init_hw_speedstr, flow_control);
  else
    init_phys(phys_fd, flow_control);

  /* Set the current tty to the bluetooth discpline */
  set_bt_line_disc(phys_fd, bt_disc, physdev);

  bt_cfd = bt_openctrl();

  tcflush(phys_fd, TCIOFLUSH);

  /* Hardreset of BT hardware */
  if (do_reset)
    reset_hw();

  if (init_stack(bt_cfd) < 0)
  {
    /* For some reason, the stack sometimes fails to initialize the first
       time. So let us try an extra time, just to be sure... */
    if (init_stack(bt_cfd) < 0)
    {
      init_failed(bt_cfd, phys_fd, init_hw_speedstr, flow_control);
    }
  }

  if (do_hwinit)
    init_hw(bt_cfd, phys_fd, speedstr);
  
  /* All initialized and ready to accept connections */
  
  while (1)
  {
    tv.tv_sec = 0;
    tv.tv_usec = 500000;

    FD_ZERO(&rfd);  

    if (ipa_fd >= 0)
      FD_SET(ipa_fd, &rfd);
    
    result = select(FD_SETSIZE, &rfd, NULL, NULL, &tv);
    switch (result)
    {
     case 0:
      {
#ifdef USE_IPASSIGN
        /* Check for outstanding IPA requests */
        int i = 0, waiting_iparsp = 0;
        while (i < BT_NBR_DATAPORTS)
        {
          if ((STATE(i) == WAITING_PPPCONF) ||
              (STATE(i) == WAITING_RETURN_PPPCONF))
          {
            D(syslog(LOG_INFO, "Waiting for IPA response"));
            waiting_iparsp = 1;
          }
          i++;
        }
        
        if (waiting_iparsp)
          break;
#endif
        
        /* Timeout, check for new rfcomm cons */

        discover_connections(bt_cfd);
      }
      break;
      
     case -1:
      if (errno != EINTR)
      {
        /* Error */
        perror("select");
        
        /* FIXME -- e.g if ipa server restarts !!! */
      }
      break;
      
     default:
      {
#ifdef USE_IPASSIGN
	/* Got data on some fd */
        int retval;

        /* IPA response */
        if (ipa_fd >= 0 && FD_ISSET(ipa_fd, &rfd))
        {
          msg = (struct ipa_msg*) ipa_buf;
          /* Got response from IPA, if ok then start pppd or modem emul */
          ipa_read(ipa_fd, msg);
          if ((retval = parse_ipa_response(msg)) < 0)
          {
            unsigned int con_id;
            int line = ((struct ipa_status*)(msg->msg))->id;
            syslog(LOG_INFO, "Got IPA error %d, disconnecting line %d", retval, line);

            con_id = CREATE_RFCOMM_ID(line, 0);

            if (bt_disconnect(bt_cfd, con_id) < 0)
            {
              /* FIXME: What to do if disconnection fails */
              syslog(LOG_INFO, "Disconnection failed");
            }
            else
            {
              STATE(line) = NOCONNECTION;
            }
          }
        } 
#endif
      }
      break;
    }    
  } /* while */
} /* main */
 
/* Checks for new connections and starts pppd/modememulator */
static void discover_connections(int bt_cfd)
{
  int line;

  D(syslog(LOG_INFO, __FUNCTION__));
  for (line = 0; line < BT_NBR_DATAPORTS; line++)
  {
    if ((STATE(line) == NOCONNECTION) && 
        bt_isconnected(bt_cfd, line))
    {
      syslog(LOG_INFO, "Found connection on line: %d", line);
      STATE(line) = CONNECTED;
      
      read_remote_bd(bt_cfd, line, PEER(line).remote_bd);
      printf("Remote bd: %s\n", bd2str(PEER(line).remote_bd));
      
      if (ipa_fd >= 0)
      {  
        D(syslog(LOG_INFO, "Sending IPA request"));
        
        PEER(line).ipset = &IPSET(line);
        
        STATE(line) = WAITING_PPPCONF;
        if (ipa_sendrequest(line, PEER(line).remote_bd, IPAREQ_GETIPSET) < 0)
        {
          syslog(LOG_INFO, "IPA request failed or no IPA server");
          
          /* Build without IPA anyway */
          STATE(line) = PPPCONF_DONE;
          build_pppdopts(line, (char**)pppd_options);      
          start_pppd(line, speedstr, (char**)pppd_options);     
        }
        else
          D(syslog(LOG_INFO, "IPA request sent"));
      }
      else /* No IPA server available */
      { 
        STATE(line) = PPPCONF_DONE;
        build_pppdopts(line, (char**)pppd_options);      
        start_pppd(line, speedstr, (char**)pppd_options);     
      }
    }
  }
}

/* only server */
void build_pppdopts(int line, char **opts)
{
  int i = 0;
  struct ip_set *ipset = PEER(line).ipset;
  char local_ip[20];
  
  if (ipa_fd >= 0)
    show_ipset(ipset, line);
  
  D(syslog(LOG_INFO, __FUNCTION__));
  
  sprintf(dev, "/dev/ttyBT%d",line);

  /* general options */
  opts[i++] = (char*)PPPDCMD;
  opts[i++] = dev;
  opts[i++] = speedstr;
  
  /* move these to options file ? */
  opts[i++] = "crtscts";
  opts[i++] = "nopersist";
  opts[i++] = "silent";
  opts[i++] = "passive";
  
  /* check if we have used IPA */
  if (ipset)
  {
    /* FIXME -- maybe parhand can modify ppp options 
       file directly */
    
    /* Use radius ? */
    if (ipset->useradius)
    {
      unsigned char local_bd[6];
      
      opts[i++] = "useradius";
      opts[i++] = "auth";
      opts[i++] = "login";
      opts[i++] = "localbdaddr";

      read_local_bd(bt_cfd, local_bd);
        
      sprintf(local_bd_str, "%02x:%02x:%02x:%02x:%02x:%02x", 
	      local_bd[0], 
	      local_bd[1], 
	      local_bd[2], 
	      local_bd[3], 
	      local_bd[4], 
	      local_bd[5]);
      
      opts[i++] = local_bd_str;

      opts[i++] = "remotebdaddr";

      sprintf(remote_bd_str, "%02x:%02x:%02x:%02x:%02x:%02x", 
	      PEER(line).remote_bd[0], 
	      PEER(line).remote_bd[1], 
	      PEER(line).remote_bd[2], 
	      PEER(line).remote_bd[3], 
	      PEER(line).remote_bd[4], 
	      PEER(line).remote_bd[5]);
      
      opts[i++] = remote_bd_str;
      
      if (ipset->useradiusip)
      {
        opts[i++] = "useautoip";
      }   
    }  
    else 
    {
      opts[i++] = "noauth";
    }  
    
    if (ipset->proxyarp)
    {
      opts[i++] = "proxyarp";
      /* ktune only works on pppd version > 2.3.10 */
      /* similar as doing ' echo 1 > /proc/sys/net/ipv4/ip_forward */
      opts[i++] = "ktune"; /* enables ip_forwarding */
    }

    if (ipset->usingmasq)
    {
      pppd_options[i++] = "usingmasq";
    }

    
    strcpy(local_ip, get_local_ip_address());
    /* local/remote ip */
    sprintf(ip_addresses, "%s:%s", local_ip, inet_ntoa(ipset->ip));
    
    printf("IP used: %s\n", ip_addresses);

    opts[i++] = ip_addresses;
    
    /* DNS */
    if (ipset->nbr_of_dns > 0)
    {
      /* at least one... */
      opts[i++] = "ms-dns";
      sprintf(ms_dns1, "%s", inet_ntoa(ipset->dns[0]));
      opts[i++] = ms_dns1;
      
      if (ipset->nbr_of_dns > 1)
      {
        opts[i++] = "ms-dns";
        sprintf(ms_dns2, "%s", inet_ntoa(ipset->dns[1]));
        opts[i++] = ms_dns2;
      }
    }
    
    /* WINS */
    if (ipset->nbr_of_wins > 0)
    {
      /* at least one... */
      opts[i++] = "ms-wins";
      sprintf(ms_wins1, "%s", inet_ntoa(ipset->wins[0]));
      opts[i++] = ms_wins1;
      
      if (ipset->nbr_of_wins > 1)
      {
        opts[i++] = "ms-wins";
        sprintf(ms_wins2, "%s", inet_ntoa(ipset->wins[1]));
        opts[i++] = ms_wins2;
      }
    }
    
    /* Netmask */      
    opts[i++] = "netmask";
    sprintf(netmask, "%s", inet_ntoa(ipset->netmask));
    opts[i++] = netmask;
  }
  else
  {    
    strcpy(local_ip, get_local_ip_address());
    
    /* local IP */
    sprintf(ip_addresses, "%s:", local_ip);

    /* Use /etc/ppp/options file for remote ppp settings.
       IPA is needed for correct multipoint setting or use a 
       ppp options file for each ttyBT e.g options.ttyBT0, 
       options.ttyBT1 which contains the remote IP address, 
       dns, wins etc*/
    
    syslog(LOG_INFO, "WARNING: No remote ip addr set, only local %s", 
	   ip_addresses);

    opts[i++] = ip_addresses;

    /* always do proxyarp */ 
    opts[i++] = "proxyarp";
    
    /* ktune only works on pppd version > 2.3.10 */
    /* similar as doing ' echo 1 > /proc/sys/net/ipv4/ip_forward */
    opts[i++] = "ktune"; /* enables ip_forwarding */

  } /* end -- no ipa */
   
  opts[i] = NULL;
  
#if 0
  /* print pppd_options */
  i = 0;
  syslog(LOG_INFO, "pppd options used:");
  while (opts[i])
    syslog(LOG_INFO, "%s", opts[i++]);
#endif
}

static int start_pppd(int line, char *speedstr, char **opts)
{
  char dev[20];
  
  sprintf(dev, "/dev/ttyBT%d",line);
  
  /* check state */
  if (STATE(line) != PPPCONF_DONE)
  {
    syslog(LOG_INFO, "Warning: PPP config not done (%d)", STATE(line));
    return -1;
  }
  
  if (PEER(line).do_modememul) 
  {
    STATE(line) = MODEM_STARTED;
    
    /* run modem emulator in a child */
    if (!(PEER(line).pppd_pid = vfork()))
    {
      /* replace first arg with MODEMEMULCMD (is handled by 
         modem emulator) */
      
      opts[0] = (char*)MODEMEMULCMD;
      
      execvp(MODEMEMULCMD, opts);
      
      fprintf(stderr, "%s: no such file or directory\n", MODEMEMULCMD);
      
      _exit(0);
    }
    else if (PEER(line).pppd_pid > 0)
    {
      syslog(LOG_INFO, "Started modem emulator on %s [pid: %d]", 
             dev, PEER(line).pppd_pid);
    }
  }
  else
  {
    STATE(line) = PPPD_STARTED;
    if (!(PEER(line).pppd_pid = vfork()))
    {
      /* FIXME -- use opts inparam and not static opts */
      execvp(PPPDCMD, opts);
      
      fprintf(stderr, "%s: no such file or directory\n", PPPDCMD);
      
      _exit(0);
    } 
    else if (PEER(line).pppd_pid > 0)
    {
      D(syslog(LOG_INFO, "Started pppd on %s [pid: %d]", dev, PEER(line).pppd_pid));
    }
  }
  
  return 0; 
}

/* ============================================================= */
/* Signal handler */

static void
init_sighandler(void)
{
  struct sigaction act;
  
  D(syslog(LOG_INFO, "Initiating signal handler"));
  act.sa_handler = sighandler;
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  sigaction(SIGCHLD, &act, 0); /* Catches when pppd childs are done */
  sigaction(SIGUSR1, &act, 0); /* Restart application */
  sigaction(SIGUSR2, &act, 0); /* HW Upgrade ? */
  sigaction(SIGTERM, &act, 0); /* Terminate application */
}

static void
sighandler(int sig)
{
  D(syslog(LOG_INFO, "Sighandler got signal: %d", sig));
  
  if (sig == SIGUSR1)
  {
    /* Shutdown all and restart */
    btd_cleanup();
    siglongjmp(jmpbuffer, 1);
  }
  else if (sig == SIGUSR2) /* ? */
  {    
    /* Close down phys dev, run hw_upgrade and restart btd */
    // btd_cleanup();

    /* FIXME -- execvp(hw_upgrade_prog) */
    // siglongjmp(jmpbuffer, 1);
  }
  else if (sig == SIGTERM)
  { 
    D(syslog(LOG_INFO, "Got SIGTERM, now exiting"));
    exit(0);
  }
  else if (sig == SIGCHLD)  
  {
    int line = 0, pid, status;

    D(syslog(LOG_INFO, "One of the childs terminated"));
    /* Find pid for this child */
    
    if ((pid = waitpid(-1, &status, WNOHANG)) <= 0)
      return;
    
    D(syslog(LOG_INFO, "pid %d terminated with status %d", pid, status));
    
    /* find corresponding line */
    while (line < BT_NBR_DATAPORTS)
    {     
      D(syslog(LOG_INFO, "line %d pid: %d", line, PEER(line).pppd_pid));
      
      if (PEER(line).pppd_pid == pid)
      {
        D(syslog(LOG_INFO, "line %d found", line));
        break;
      }
      line++;
    }
    
    if (line == BT_NBR_DATAPORTS)
    {
      D(syslog(LOG_INFO, "Not a pppd pid"));
      return;
    }
    
    D(syslog(LOG_INFO, "PPP line %d was shutdown", line));
    
    if (ipa_fd >= 0)
    { 
      STATE(line) = WAITING_RETURN_PPPCONF;
      
      if (ipa_sendrequest(line, PEER(line).remote_bd, IPAREQ_RELEASEIPSET) < 0)
      {
        syslog(LOG_INFO, "IPA request failed or no IPA server");
        /* put peer into state NOCONNECTION, if still connected this
           will be discovered in timout */
        STATE(line) = NOCONNECTION;    
      }
    }
    else
    {
      STATE(line) = NOCONNECTION;    
    }

    PEER(line).ipset = NULL;
    PEER(line).pppd_pid = -1;
    
    return;
  }
}

/* ============================================================= */
/* General BTD stuff */
 
static void init()
{ 
  int i;

  btd_pid = write_pidfile(PID_FILE);  
  init_sighandler();

  if ((sdpsrv_pid = start_sdp_server()) < 0)
  {
    perror("start_sdp_server");
    exit(1);
  }

  for (i = 0; i < BT_NBR_DATAPORTS; i++)
  {
    PEER(i).state = NOCONNECTION;
    PEER(i).pppd_pid = -1;
    PEER(i).do_modememul = modem_emul;
    PEER(i).ipset = NULL;
  }

#ifdef USE_IPASSIGN
  /* Look for IPA server */
  ipa_fd = -1;
  i = 1;
  while (ipa_fd < 0) 
  {  
    ipa_fd = open_socket(IPASERVER, CLIENT);
    if (ipa_fd < 0)
    {
      D(syslog(LOG_INFO, "Found no IPA server"));

      if (i > 8)
      {  
	break;
      }
      else
      {
        D(syslog(LOG_INFO, "Retrying in %d sec", i));
        sleep(i);
        i *= 2;
      }      
    }
    else 
    {      
      D(syslog(LOG_INFO, "Found IPA server"));
    }
  } 
#endif

  if (modem_emul == 1)
    D(syslog(LOG_INFO, "Using modem emulation"));
  else
    D(syslog(LOG_INFO, "Using NO modem emulation"));
}

static void
btd_cleanup(void)
{
  D(syslog(LOG_INFO, __FUNCTION__));
  btd_killchilds();
  
  printf("Shutting down Bluetooth stack\n");
  shutdown_stack(bt_cfd);
  printf("Bluetooth stack shut down\n");

  if (bt_cfd != -1)
  {
    close(bt_cfd);
    bt_cfd = -1;
  }
  
  /* now close phys device */
  if (phys_fd != -1)
  {
    tcflush(phys_fd, TCIOFLUSH);
    close(phys_fd);
    phys_fd = -1;
  }

  if (ipa_fd != -1)
  {
    D(syslog(LOG_INFO, "Closing connection to IPA"));
    tcflush(ipa_fd, TCIOFLUSH);
    close(ipa_fd);
    ipa_fd = -1;
  }

  /* pid_fd is set if we created the pid file when we started */
  if (btd_pid != -1)
  {
    unlink(PID_FILE);
  }
}

static void
btd_killchilds(void)
{
  int line;

  if (sdpsrv_pid > 0)
  {
    D(syslog(LOG_INFO, "Killing SDP server"));
    kill(sdpsrv_pid, SIGTERM);
    
    if (waitpid(sdpsrv_pid, NULL, 0) < 0)
      perror("waitpid sdp server");
    
    sdpsrv_pid = 0;
  }
  
  /* Kill all pppd:s */
  for (line = 0; line < BT_NBR_DATAPORTS; line++)
  {
    if (STATE(line) == PPPD_STARTED)
    {
      D(syslog(LOG_INFO, "Killing pppd on line %d", line));
      kill(PEER(line).pppd_pid, SIGTERM);
      if (waitpid(PEER(line).pppd_pid, NULL, 0) < 0)
        perror("waitpid pppd");
      PEER(line).pppd_pid = 0;
    }
  }
}

/* ========================================================== */
/* IPA stuff */

static int ipa_sendrequest(int line, unsigned char *bd, unsigned short type)
{
  unsigned char buf[IPA_MSG_MAXSIZE];
  struct ipa_msg *msg;
  struct ipa_request *req;
  
  D(syslog(LOG_INFO, __FUNCTION__ ": Type %d", type));

  msg = (struct ipa_msg*)buf;
  msg->type = type;
  msg->len = sizeof(struct ipa_request);
  req = (struct ipa_request*)msg->msg;
  req->id = line;
  memcpy(req->remote_bd, bd, 6); 
  return ipa_write(ipa_fd, msg);
}

static int parse_ipa_response(struct ipa_msg *msg)
{
  switch (msg->type)
  {
   case IPARSP_STATUS:
    {
      ipa_status *rsp = (struct ipa_status*)msg->msg;
      D(syslog(LOG_INFO, __FUNCTION__ ": Got status %d on line %d", 
               rsp->status, rsp->id));

      /* Check state */
      if (STATE(rsp->id) != WAITING_RETURN_PPPCONF)
      {
        syslog(LOG_INFO, __FUNCTION__ ": Wrong state (case IPARSP_STATUS)");
        return -ERR_WRONGSTATE;
      }

      /* Check status */
      if (rsp->status == IPA_STATUSFAILED)
      {
        syslog(LOG_INFO, __FUNCTION__ ": Request failed [line:%d]", rsp->id);
        return -IPA_STATUSFAILED;
      }      
      else
	D(syslog(LOG_INFO, __FUNCTION__ ": Request succeeded [line:%d]",
                 rsp->id));

      /* put peer into NOCONNECTION, if still connected this will 
         be discovered from timeout */

      STATE(rsp->id) = NOCONNECTION;

      return 0;
    }
    
   case IPARSP_PEERSETTINGS:
    {
      ipa_response* rsp = (struct ipa_response*)msg->msg;
      D(syslog(LOG_INFO, __FUNCTION__ ": Got client settings"));
      
      /* Check state */
      if (STATE(rsp->id) != WAITING_PPPCONF)
      {
        syslog(LOG_INFO, __FUNCTION__ ": Wrong state case (IPARSP_PEERSETTINGS)");
        return -ERR_WRONGSTATE;
      }

      /* Check status */
      if (rsp->status == IPA_STATUSFAILED)
      {
        /* error */
        syslog(LOG_INFO, __FUNCTION__ ": Failed to get client settings\n");
        return -ERR_REQUESTFAILED;
      }

      /* Store ipa settings in peer struct */
      memcpy(PEER(rsp->id).ipset, &rsp->set, msg->len);

      PEER(rsp->id).state = PPPCONF_DONE;
      
      /* Build options and start ppp */
      build_pppdopts(rsp->id, (char**)pppd_options);
      start_pppd(rsp->id, speedstr, (char**)pppd_options);
      return 0;
    }
    
   default:
    syslog(LOG_INFO, __FUNCTION__ ": Unknown message type");
    break;
  }
  return 0;
}

/* ============================================================= */
