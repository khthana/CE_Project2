

#ifndef __BT_VENDOR_H__
#define __BT_VENDOR_H__

#include "bt_conf.h"
 
/* 
 * HW init defines 
 */

#define MANUFACTURER_SPEC 0x3f

#define HW_NOT_PROBED -1
#define HW_CSR         0
#define HW_DIGIANSWER  1
#define HW_ERICSSON    2
#define HW_INFINEON    3
#define HW_USB         4
#define HW_GENERIC     5
#define HW_NO_INIT     6
#define HW_UNKNOWN     7

/* 
 * Vendor specific functions 
 */

void init_hw(int bt_cfd, int phys_fd, const char *speedstr);
void init_phys(int fd, int flow_control);
void init_failed(int bt_cfd, int phys_fd, const char *speedstr, int flow_control);

int bt_set_max_power(int bt_cfd, short max_power);

int hw_vendor(void);

void csr_bcsp_to_h4(int bt_cfd, int phys_fd, const char *speedstr, int flow_control);
void csr_h4_to_bcsp(int bt_cfd, int phys_fd, const char *speedstr, int flow_control);

void csr_pskey(int bt_cfd, unsigned short ps_key, unsigned short rw_mode, 
               unsigned short *ps_vals, unsigned short n_pars);

#endif /* __BT_VENDOR_H__*/
