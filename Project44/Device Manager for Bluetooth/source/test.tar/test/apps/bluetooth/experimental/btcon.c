
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <getopt.h>

#include "btd.h"
#include "bt_if.h"
#include "bt_conf.h"
#include "bt_misc.h"

#define DEFAULT_BTDEV "/dev/ttyBT0"

/*
 * Syntax: btcon [-d <device>] [-p <pincode>] -a <BD> [-S <rfcomm srv ch>]
 * If using 'disable' as pin, authentication is disabled 
 */

int
main(int argc, char **argv)
{
  char *btdev = DEFAULT_BTDEV;
  char *bd_str = NULL;
  unsigned char bd[6];
  int con_id, opt, i, result;
  int line, bt_cfd, srvch = 1;

  /* Print header if called via http */
  if (getenv("REQUEST_METHOD") != NULL)
  {
    printf("Content-type: text/plain\r\n\r\n");
  }

  /* now parse options */
  while ((opt = getopt(argc, argv, "a:d:r:S:p:")) != -1)
  {
    switch (opt)
    {
     case 'a':
      {
        int tmp[6], all_read = 0;
        bd_str = optarg;
        if (sscanf(optarg, "%2x%2x%2x%2x%2x%2x",
                   &tmp[0], &tmp[1], &tmp[2],
                   &tmp[3], &tmp[4], &tmp[5]) == 6)
        {  
          all_read = 1;
        }
        else if (sscanf(optarg, "%x:%x:%x:%x:%x:%x",
                        &tmp[0], &tmp[1], &tmp[2],
                        &tmp[3], &tmp[4], &tmp[5]) == 6)
        {  
          all_read = 1;
        }
        else if (sscanf(optarg, "%x-%x-%x-%x-%x-%x",
                        &tmp[0], &tmp[1], &tmp[2],
                        &tmp[3], &tmp[4], &tmp[5]) == 6)
        { 
          all_read = 1;
        }
        
        /* now convert to real bd format if syntax was correct */
        if (all_read)
        {
          for (i = 0; i < 6; i++)
          {
            bd[i] = (unsigned char)tmp[i]; 
          }
          printf("Connecting to bd: %2x:%2x:%2x:%2x:%2x:%2x\n",
                 bd[0], bd[1], bd[2], bd[3], bd[4], bd[5]);
        }
        else
        {
          printf("Invalid syntax: %s\n", bd_str);
          exit(1);
        }
      }
      break;
      
     case 'd':
      /* BT device */
      btdev = optarg;
      printf("btdev  %s\n", btdev);
      break;
      
     case 'p':
      /* If using 'disable' as pin, authentication is disabled */
      printf("Using pin code: %s\n", optarg);
      set_pin_code(optarg);
      break;

     case 'S':
      srvch = atoi(optarg);
      printf("Using rfcomm server ch: %d\n", srvch);
      break;
      
     default:
      break;
    }
  }

  if (optind < argc || !bd_str)
  {    
    printf("Wrong syntax or missing parameters\n");
    printf("Syntax: %s [-d <device>] [-p <pincode>] -a <BD> [-S <rfcomm srv ch>]\n", argv[0]);
    exit(1);
  }

  /* Open BT ctrl device */  
  if ((bt_cfd = bt_openctrl()) < 0)
  {
    perror("Could not open BT control device");
    exit(1);
  }

  /* First of all check that stack is running */
  if (!bt_isinitiated(bt_cfd))
  {
    printf("Stack not initiated, exit\n");
    exit(1);
  }

  line = atoi((char*)(btdev+10));
  
  /* Connect RFCOMM session on line */
 
  printf("Connecting to %s on line %d\n", bd2str(bd), line);

  /* Some sanity checks */
  if ((srvch <= 0) || (srvch > 62) || (line < 0) || (line > 6))
  {
    printf("Invalid parameters, srvch [1-62] , line [0-6]\n");
    exit(1);
  }

  con_id = CREATE_RFCOMM_ID(line, srvch << 1);

  result = bt_connect(bt_cfd, bd, con_id);
 
  close(bt_cfd);
  exit(result);
}
