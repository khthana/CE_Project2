
#ifndef __BT_CONF_H__
#define __BT_CONF_H__

/* ========================== GENERAL ========================*/

#define BT_NBR_DATAPORTS 7
#define BT_CTRL_TTY "/dev/ttyBTC"

#ifdef __CRIS__
#define DEFAULT_PHYS_DEV "/dev/ttyBT"
#define DEFAULT_SPEED "460800"
#else
#define DEFAULT_PHYS_DEV "/dev/ttyS0"
#define DEFAULT_SPEED "115200"
#endif

/* ========================================================*/
/* IPA server */

#define USE_IPASSIGN

#endif /* __BT_CONF_H__ */
