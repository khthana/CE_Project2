 
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <syslog.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>

#include "bt_misc.h"
#include "bt_vendor.h"
#include "bt_if.h"

#define D(x) //x

static void csr_init_phys(int fd, int flow_control);
static void csr_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void digianswer_init_phys(int fd, int flow_control);
static void digianswer_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void ericsson_init_phys(int fd, int flow_control);
static void ericsson_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void infineon_init_phys(int fd, int flow_control);
static void infineon_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void usb_init_phys(int fd, int flow_control);
static void usb_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void generic_init_phys(int fd, int flow_control);
static void generic_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void no_init_phys(int fd, int flow_control);
static void no_init_hw(int bt_cfd, int phys_fd, const char *speedstr);
static void unknown_init_phys(int fd, int flow_control);
static void unknown_init_hw(int bt_cfd, int phys_fd, const char *speedstr);

static void csr_change_if(int bt_cfd, int phys_fd, const char *speedstr, int flow_control);
static int csr_set_max_power(int bt_cfd, short max_power);

void
init_phys(int fd, int flow_control)
{
  switch (hw_vendor())
  {
  case HW_CSR:
    csr_init_phys(fd, flow_control);
    break;

  case HW_DIGIANSWER:
    digianswer_init_phys(fd, flow_control);
    break;

  case HW_ERICSSON:
    ericsson_init_phys(fd, flow_control);
    break;

  case HW_INFINEON:
    infineon_init_phys(fd, flow_control);
    break;

  case HW_USB:
    usb_init_phys(fd, flow_control);
    break;

  case HW_GENERIC:
    generic_init_phys(fd, flow_control);
    break;

  case HW_NO_INIT:
    no_init_phys(fd, flow_control);
    break;

  case HW_UNKNOWN:
  default:
    unknown_init_phys(fd, flow_control);
    break;
  }
}

void
init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  switch (hw_vendor())
  {
  case HW_CSR:
    csr_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_DIGIANSWER:
    digianswer_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_ERICSSON:
    ericsson_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_INFINEON:
    infineon_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_USB:
    usb_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_GENERIC:
    generic_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_NO_INIT:
    no_init_hw(bt_cfd, phys_fd, speedstr);
    break;

  case HW_UNKNOWN:
  default:
    unknown_init_hw(bt_cfd, phys_fd, speedstr);
    break;
  }
}

int
bt_set_max_power(int bt_cfd, short max_power)
{
  switch (hw_vendor())
  {
  case HW_CSR:
    return csr_set_max_power(bt_cfd, max_power);

  default:
    errno = EPERM;
    return -1;
  }
}

/* 
 *  This function tries to recover stack if init failed 
 *  For now all other vendors but CSR is left to restart 
 *  btd but later on auto_probe on baudrate could be done.
 */

void
init_failed(int bt_cfd, int phys_fd, const char *speedstr, int flow_control)
{

  static int did_restart = 0; /* only try once */  
 
  if (did_restart)
  {
    syslog(LOG_INFO, "Init failed after second try, giving up...");
    exit(1);
  }

  sleep(1);

  switch (hw_vendor())
  {
   case HW_CSR:
    /* Try changing interface BCSP<->H4 */
    csr_change_if(bt_cfd, phys_fd, speedstr, flow_control);
    did_restart = 1;

    /* Restart btd */
    kill(getpid(), SIGUSR1); 
    break;
    
   default:
    /* Restart btd */
    syslog(LOG_INFO, "Init failed, lets try restarting btd");
    did_restart = 1;

    /* Restart btd */
    kill(getpid(), SIGUSR1);   
    break;
  }
}


int
hw_vendor(void)
{
  static int hw_vendor = HW_NOT_PROBED;

  if (hw_vendor == HW_NOT_PROBED)
  {
    char *vendor = bt_hw_vendor();

    if (!vendor)
      hw_vendor = HW_UNKNOWN;
    else if (!strcmp(vendor, "CSR"))
      hw_vendor = HW_CSR;
    else if (!strcmp(vendor, "Digianswer"))
      hw_vendor = HW_DIGIANSWER;
    else if (!strcmp(vendor, "Ericsson"))
      hw_vendor = HW_ERICSSON;
    else if (!strcmp(vendor, "Infineon"))
      hw_vendor = HW_INFINEON;
    else if (!strcmp(vendor, "USB"))
      hw_vendor = HW_USB;
    else if (!strcmp(vendor, "Generic"))
      hw_vendor = HW_GENERIC;
    else if (!strcmp(vendor, "No Init"))
      hw_vendor = HW_NO_INIT;
    else
      hw_vendor = HW_UNKNOWN;
  }

  return hw_vendor;
}

/* ===============================================================*/
/* CSR specific commands                                          */
/* ===============================================================*/

#define PSKEY_LC_MAX_TX_POWER        0x0017
#define PSKEY_HOSTIO_UART_PS_BLOCK   0x0191
#define PSKEY_HOST_INTERFACE         0x01f9
#define PSKEY_UART_SLEEP_TIMEOUT     0x0222

#define CSR_PSKEY_GETREQ 0x0
#define CSR_PSKEY_SETREQ 0x2

/* Set the phys device to CSR default, 115200 */ 
void
csr_init_phys(int fd, int flow_control)
{
  D(syslog(LOG_INFO, "Setting default speed 115200"));
  fd_setup(fd, "115200", flow_control);
}

/*
 * Read/Write any PS key in CSR module 
 * ps_vals holds return values / set params depending on 
 * type of operation
 */

void csr_pskey(int bt_cfd, unsigned short ps_key, unsigned short rw_mode, 
               unsigned short *ps_vals, unsigned short n_pars)
{
  unsigned short msg[CSR_PSKEY_MAXPARAMS + CSR_PSKEY_MSGHDR_SIZE];

  syslog(LOG_INFO, __FUNCTION__": ps_key 0x%x rw_mode : %d", ps_key, rw_mode);

  msg[0] = ps_key;
  msg[1] = rw_mode;
  msg[2] = n_pars;

  if (n_pars > CSR_PSKEY_MAXPARAMS)
  {
    syslog(LOG_INFO, __FUNCTION__ ": Error: Max nbr pskey params is %d [%d]",
           CSR_PSKEY_MAXPARAMS, n_pars);
    return;
  }
  
  if (rw_mode == CSR_PSKEY_GETREQ)
    memset(&msg[CSR_PSKEY_MSGHDR_SIZE], 0, n_pars*2); /* GETREQ */
  else
    memcpy(&msg[CSR_PSKEY_MSGHDR_SIZE], ps_vals, n_pars*2);    
  
  if (ioctl(bt_cfd, BT_CSR_PSKEY, msg) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }

  /* Copy back return params if READ (skip message header) */
  if (rw_mode == CSR_PSKEY_GETREQ)
    memcpy(ps_vals, &msg[CSR_PSKEY_MSGHDR_SIZE], n_pars*2);
}


int csr_disable_deep_sleep(int bt_cfd)
{
  unsigned short ps_parbuf;

  /* Make sure uart deep sleep is disabled when using BCSP */
  csr_pskey(bt_cfd, PSKEY_UART_SLEEP_TIMEOUT, 
	    CSR_PSKEY_GETREQ, &ps_parbuf, 1);
  
  if (ps_parbuf != 0)
  {
    syslog(LOG_INFO, "Disabling deep sleep timer");
    ps_parbuf = 0; /* disable deep sleep timer */
    csr_pskey(bt_cfd, PSKEY_UART_SLEEP_TIMEOUT, 
              CSR_PSKEY_SETREQ, &ps_parbuf, 1);    
    return 1;
  }
  return 0;
}

/* 
 * Switches host interface in CSR HW (H4<->BCSP) 
 */

void csr_change_if(int bt_cfd, int phys_fd, const char *speedstr, int flow_control)
{
  /* This may seem reversed, but hw_vendor() returns what we want,
     not what we have, in this situation... */
  if (!bt_bcsp_mode(bt_cfd, -1))
  {
    csr_bcsp_to_h4(bt_cfd, phys_fd, speedstr, flow_control);
  }
  else
  {
    csr_h4_to_bcsp(bt_cfd, phys_fd, speedstr, flow_control);
  }
}

void csr_bcsp_to_h4(int bt_cfd, int phys_fd, const char *speedstr, int flow_control)
{
  unsigned short ps_parbuf[10];

  syslog(LOG_INFO, "Changing CSR host IF: BCSP -> H4");

  /* Temporarily set stack to use BCSP framing */
  bt_bcsp_mode(bt_cfd, 1);

  if (speedstr)
    fd_setup(phys_fd, speedstr, flow_control);
  else
    init_phys(phys_fd, flow_control);

  reset_hw();

  if (ioctl(bt_cfd, BTINITBCSP) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }

  sleep(1);

  /* Make sure that deep sleep timer is disabled to 
     prevent problems when setting new ps keys */

  if (csr_disable_deep_sleep(bt_cfd))
  {
    reset_hw();      
    if (ioctl(bt_cfd, BTINITBCSP) < 0)
    {
      perror(__FUNCTION__);
      exit(1);
    }
    sleep(1);
  }

  /* Read params for ps key PSKEY_HOSTIO_UART_PS_BLOCK */
  csr_pskey(bt_cfd, PSKEY_HOSTIO_UART_PS_BLOCK, 
            CSR_PSKEY_GETREQ, ps_parbuf, 10);

  if (ps_parbuf[1] == 6) /* BCSP */
  {
    /* Set UART to no parity, non-bcsp, flow control on */
    ps_parbuf[1] = 0x00a8;
    csr_pskey(bt_cfd, PSKEY_HOSTIO_UART_PS_BLOCK, 
              CSR_PSKEY_SETREQ, ps_parbuf, 10);

    sleep(1);

    /* Set ps key PSKEY_HOST_INTERFACE */
    ps_parbuf[0] = 0x0003; /* H4 */
    csr_pskey(bt_cfd, PSKEY_HOST_INTERFACE, 
              CSR_PSKEY_SETREQ, ps_parbuf, 1);
    sleep(1);
  }
  else
  {
    syslog(LOG_ERR, __FUNCTION__ ": Unknown PS key parameter: %d", ps_parbuf[1]);
  }   

  /* Set back stack to use H4 framing */
  bt_bcsp_mode(bt_cfd, 0);

  shutdown_stack(bt_cfd);
}

void csr_h4_to_bcsp(int bt_cfd, int phys_fd, const char *speedstr, int flow_control)
{
  unsigned short ps_parbuf[10];

  syslog(LOG_INFO, "Changing CSR host IF: H4 -> BCSP");

  /* Set stack to use H4 temporarily */        
  bt_bcsp_mode(bt_cfd, 0);

  if (speedstr)
    fd_setup(phys_fd, speedstr, flow_control);
  else
    init_phys(phys_fd, flow_control);

  reset_hw();    

  sleep(1);

  /* Initialize stack */
  init_stack(bt_cfd);

  if (csr_disable_deep_sleep(bt_cfd))
  {
    reset_hw();
    init_stack(bt_cfd); /* reinitialize */
  }

  /* Read params for ps key PSKEY_HOSTIO_UART_PS_BLOCK */
  csr_pskey(bt_cfd, PSKEY_HOSTIO_UART_PS_BLOCK, 
            CSR_PSKEY_GETREQ, ps_parbuf, 10);

  if (ps_parbuf[1] == 0xa8) /* non-BCSP */
  {
    /* Enable parity bit, disable flow */
    ps_parbuf[1] = 0x6;
    csr_pskey(bt_cfd, PSKEY_HOSTIO_UART_PS_BLOCK, 
              CSR_PSKEY_SETREQ, ps_parbuf, 10);
    sleep(1);

    /* Set ps key PSKEY_HOST_INTERFACE */
    ps_parbuf[0] = 0x1; /* BCSP */
    csr_pskey(bt_cfd, PSKEY_HOST_INTERFACE, 
              CSR_PSKEY_SETREQ, ps_parbuf, 1);
  }
  else
  {
    syslog(LOG_ERR, __FUNCTION__ ": Unknown PS key parameter: %d", ps_parbuf[1]);
  }

  /* Set back stack to use BCSP framing */
  bt_bcsp_mode(bt_cfd, 1);

  shutdown_stack(bt_cfd);
}


/* fixme -- remove hardcoded values */
void
csr_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  /* Connection setup, all devices, no auto accept */
  unsigned char filter[3] = { 0x02, 0x00, 0x01 };
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);
  int firmware = -1;
  char* buf;
  
  if (bt_bcsp_mode(bt_cfd, -1) && csr_disable_deep_sleep(bt_cfd))
      kill(getpid(), SIGUSR1);  /* Restart btd (and HW) to activate changes */

  D(syslog(LOG_INFO, "Setting write_scan_enable in CSR module"));

  bt_write_scan_enable(bt_cfd, wrscan);
  
  /* improves reliability when doing a connect */
  D(syslog(LOG_INFO, "Setting write_pagescan_activity in CSR module"));

  bt_write_pagescan_activity(bt_cfd, 0x0800, 0x12);

  bt_set_event_filter(bt_cfd, filter);

  sleep(1);  

  if ((buf = bt_firmware_info()))
  {
    sscanf(buf, " Firmware version: %d", &firmware);
  }

  if (speedstr)
  {
    /* Only try to set the speed if the CSR firmware is new enough
       (temporarily setting the speed does not work correctly in 9.x) */
    if (firmware >= 90)
    {
      D(syslog(LOG_INFO, "Setting baudrate in CSR module [%s baud]", speedstr));

      bt_set_baudrate(bt_cfd, speedstr);

      /* Now set phys device speed to whatever HW was set to use */
      fd_setup(phys_fd, speedstr, USE_CURRENT_FLOW);
      tcflush(phys_fd, TCIOFLUSH);

      D(syslog(LOG_INFO, "Baudrate set"));
    }
    else
    {
      syslog(LOG_INFO, "Did not set baudrate in CSR module as its firmware is too old (%d)", firmware);
    }
  }
}

int
csr_set_max_power(int bt_cfd, short max_power)
{
  short old_max_power = SHRT_MAX;

  /* We need to wait a little here for some reason, or the reading of the
     current maximum power may fail and return 0 */
  usleep(50000);

  csr_pskey(bt_cfd, PSKEY_LC_MAX_TX_POWER, CSR_PSKEY_GETREQ, (unsigned short *)&old_max_power, 1);

  if (old_max_power != max_power)
  {
    csr_pskey(bt_cfd, PSKEY_LC_MAX_TX_POWER, CSR_PSKEY_SETREQ, (unsigned short *)&max_power, 1);
    if (restart_btd() < 0)
    {
      syslog(LOG_INFO, "Failed to restart btd");
    }
  }

  return 0;
}

/* ===============================================================*/
/* Digianswer specific commands                                   */
/* ===============================================================*/

/* Set the phys device to Digianswer default, 9600 */ 
void
digianswer_init_phys(int fd, int flow_control)
{
  fd_setup(fd, "9600", flow_control);
}

void
digianswer_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  /* Connection setup, all devices, no auto accept */
  unsigned char filter[3] = { 0x02, 0x00, 0x01 };

  D(syslog(LOG_INFO, "Setting baudrate in Digianswer PC card"));

  bt_set_event_filter(bt_cfd, filter);

  if (speedstr)
  {
    bt_set_baudrate(bt_cfd, speedstr);

    if (speedstrtoli(speedstr) > 115200)
    {
      printf("WARNING: Does this HW really support speeds > 115200?\n");
    }

    /* Now set phys device speed to whatever HW was set to use */
    fd_setup(phys_fd, speedstr, USE_CURRENT_FLOW);
    tcflush(phys_fd, TCIOFLUSH);
  }
}

/* ===============================================================*/
/* Ericsson specific commands                                     */
/* ===============================================================*/

/* Set the phys device to Ericsson default speed, 57600 */
void
ericsson_init_phys(int fd, int flow_control)
{
  fd_setup(fd, "57600", flow_control);
}

void
ericsson_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  /* Connection setup, all devices, no auto accept */
  unsigned char filter[3] = { 0x02, 0x00, 0x01 };
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);

  bt_write_scan_enable(bt_cfd, wrscan);

  sleep(1);

  /* set_event_filter must be called for m/s switch on IrmaC! */
  bt_set_event_filter(bt_cfd, filter);

  sleep(1); // wait for HW...

  if (speedstr)
  {
    D(syslog(LOG_INFO, "Setting baudrate in Ericsson module"));
    bt_set_baudrate(bt_cfd, speedstr);
    usleep(10000);

    /* Now set phys device speed to whatever HW was set to use */
    fd_setup(phys_fd, speedstr, USE_CURRENT_FLOW);
    tcflush(phys_fd, TCIOFLUSH);
  }
}

/* ===============================================================*/
/* Infineon specific commands                                     */
/* ===============================================================*/

void
infineon_init_phys(int fd, int flow_control)
{
  fd_setup(fd, "115200", flow_control);
}

void
infineon_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);

  sleep(1);
  D(syslog(LOG_INFO, "Setting write_scan_enable in Infineon module"));
  bt_write_scan_enable(bt_cfd, wrscan);

  sleep(1); // wait for HW...

  if (speedstr)
  {
    D(syslog(LOG_INFO, "Setting baudrate in Infineon module"));
    bt_set_baudrate(bt_cfd, speedstr);

    /* Now set phys device speed to whatever HW was set to use */
    fd_setup(phys_fd, speedstr, USE_CURRENT_FLOW);
    tcflush(phys_fd, TCIOFLUSH);
  }
}

/* ===============================================================*/
/* USB specific commands                                          */
/* ===============================================================*/

void
usb_init_phys(int fd, int flow_control)
{
  fd_setup(fd, "115200", flow_control);
}

void
usb_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  /* Connection setup, all devices, no auto accept */
  unsigned char filter[3] = { 0x02, 0x00, 0x01 };
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);

  D(syslog(LOG_INFO, "Setting write_scan_enable in USB module"));

  bt_write_scan_enable(bt_cfd, wrscan);
  
  /* improves reliability when doing a connect */
  D(syslog(LOG_INFO, "Setting write_pagescan_activity in USB module"));

  bt_write_pagescan_activity(bt_cfd, 0x0800, 0x12);

  sleep(1);

  bt_set_event_filter(bt_cfd, filter);
}

/* ===============================================================*/
/* Generic commands                                               */
/* ===============================================================*/

void
generic_init_phys(int fd, int flow_control)
{
  fd_setup(fd, "115200", flow_control);
}

void
generic_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{  
  /* Connection setup, all devices, no auto accept */
  unsigned char filter[3] = { 0x02, 0x00, 0x01 };
  unsigned int wrscan = (PAGE_SCAN_ENABLE | INQUIRY_SCAN_ENABLE);

  D(syslog(LOG_INFO, "Setting write_scan_enable in generic module"));
  
  bt_write_scan_enable(bt_cfd, wrscan);
  bt_set_event_filter(bt_cfd, filter);
}

/* ===============================================================*/
/* No HW init commands                                            */
/* ===============================================================*/

void
no_init_phys(int fd, int flow_control)
{
}

void
no_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
}

/* ===============================================================*/
/* Default                                                        */
/* ===============================================================*/

void
unknown_init_phys(int fd, int flow_control)
{
  printf("ERROR: init_phys() not implemented!\n");
}

void
unknown_init_hw(int bt_cfd, int phys_fd, const char *speedstr)
{
  printf("ERROR: init_hw() not implemented!\n");
}

/*********************************************************************/
