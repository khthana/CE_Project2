 

#ifndef __BT_IF_H__
#define __BT_IF_H__

#include "btd.h"
#ifdef BT_USERSTACK
#include <pthread.h>
#include "include/rfcomm.h"
#endif

/* ============================================================== */
/* General defines */ 

/* NOTE !
   N_BT should be defined in /include/asm/termios.h 
   However, if you are compiling this source standalone
   the following define can be useful. If this number is taken 
   simply change it to something not taken.*/

#ifndef N_BT
#define N_BT 15
#endif

#define HOST_NAME_LENGTH   100
#define DOMAIN_NAME_LENGTH 100

/* ============================================================== */
/* BT defines */

#define INQUIRY_SCAN_ENABLE 1
#define PAGE_SCAN_ENABLE    2

#define SDP_LAYER    1
#define RFCOMM_LAYER 3
#define TCS_LAYER    5
#define L2CAP_TEST_LAYER 0x1231
#define L2CAP_TEST2_LAYER 0x1233
#define L2CAP_TEST3_LAYER 0x4461

/* ============================================================== */
/* SDP server  */

#define PID_FILE "/var/run/btd.pid"

#ifdef BT_USERSTACK
#define SDPSRV_CMD "sdp_user"
#define SDPSRV_PROC "/tmp/sdp_sock"
#else
#define SDPSRV_CMD "sdp_server"
#define SDPSRV_PROC "/proc/sdp_srv"
#endif

#define SDPSRV_CONF "/etc/sdp.xml"


#ifndef BT_USERSTACK

/* ============================================================== */
/* IF Macros */

#define CREATE_RFCOMM_ID(line, dlci) ( ((RFCOMM_LAYER << 16)&0xffff0000) | ((line<<8)&0xff00) | ((dlci) & 0xff) )

#define CREATE_SDP_ID(line, dlci) ( ((SDP_LAYER << 16)&0xffff0000) | ((line<<8)&0xff00) | ((dlci) & 0xff) )

#define GET_PSM(con_id) (con_id >> 16)

#define ANY_LINE 255
#define NO_LINE 256

/* ============================================================== */
/* Ioctls for the BT driver */

#define BT_IOC_MAGIC 'B' /* Use B as a magic number */
#define BT_IOC_MAXNR 255

#define BTCONNECT _IOW(BT_IOC_MAGIC, 0x00, bt_connection)
#define BTDISCONNECT _IOW(BT_IOC_MAGIC, 0x01, unsigned int)

#define BTSETSPEED _IOW(BT_IOC_MAGIC, 0x02, int)
#define BTINITSTACK _IO(BT_IOC_MAGIC, 0x03)
#define BTSETSERTTY _IO(BT_IOC_MAGIC, 0x04)
#define BTSETMODEMDUMMY _IOW(BT_IOC_MAGIC, 0x05, int)
#define BTSHUTDOWN _IO(BT_IOC_MAGIC, 0x06)
#define BTREADREMOTEBDADDR _IOWR(BT_IOC_MAGIC, 0x07, unsigned char[6])
#define BTRESETPHYSICALHW _IO(BT_IOC_MAGIC, 0x08)
#define BTISINITIATED _IOR(BT_IOC_MAGIC, 0x09, int)
#define BTHWVENDOR _IOR(BT_IOC_MAGIC, 0x0a, char[20])
#define BTFIRMWAREINFO _IOR(BT_IOC_MAGIC, 0x0B, char[80])

#define BTWAITFORCONNECTION _IOW(BT_IOC_MAGIC, 0x0C, int)
#define BTWAITNEWCONNECTIONS _IO(BT_IOC_MAGIC, 0x0D)
#define BTISLOWERCONNECTED _IOW(BT_IOC_MAGIC, 0x0E, int)

//#define BT_SDP_REQUEST _IOW(BT_IOC_MAGIC, 0x0F, bt_sdp_request)
#define BT_GETCACHEDLINKKEY _IOWR(BT_IOC_MAGIC, 0x10, unsigned char[22])

/* ============================================================== */
/* Ioctls for executing HCI commands */

/* Link Control Command */

#define HCIINQUIRY _IOWR(BT_IOC_MAGIC, 0x20, inquiry_results)
#define HCILINKKEYREPLY _IOWR(BT_IOC_MAGIC, 0x21, unsigned char[22])
#define HCILINKKEYNEGATIVEREPLY _IOWR(BT_IOC_MAGIC, 0x22, unsigned char[6])
#define HCIPINCODEREPLY _IOWR(BT_IOC_MAGIC, 0x23, unsigned char[23])
#define HCIPINCODENEGATIVEREPLY _IOWR(BT_IOC_MAGIC, 0x24, unsigned char[6])
#define HCIAUTHENTICATION_REQUESTED _IOW(BT_IOC_MAGIC, 0x25, unsigned char[6])
#define HCISETCONNECTION_ENCRYPTION _IOW(BT_IOC_MAGIC, 0x26, unsigned char[7])

/* Link Policy Commands */

#define HCISWITCHROLE _IOW(BT_IOC_MAGIC, 0x28, unsigned char[7])

/* Host Controller & Baseband Commands */

#define HCIRESET _IO(BT_IOC_MAGIC, 0x30)
#define HCIFLUSH _IO(BT_IOC_MAGIC, 0x31)
#define HCICREATE_NEW_UNIT_KEY _IO(BT_IOC_MAGIC, 0x32)
#define HCIREADSTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x33, unsigned char[7])
#define HCIWRITESTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x34, unsigned char[22])
#define HCIDELETESTOREDLINKKEY _IOWR(BT_IOC_MAGIC, 0x35, unsigned char[7])
#define HCISETLOCALNAME _IOW(BT_IOC_MAGIC, 0x36, unsigned char[248])
#define HCIREADSCANENABLE _IOR(BT_IOC_MAGIC, 0x37, int)
#define HCIWRITESCANENABLE _IOW(BT_IOC_MAGIC, 0x38, int)
#define HCIWRITEPAGESCANACTIVITY _IOW(BT_IOC_MAGIC, 0x39, unsigned int[2])
#define HCIWRITECLASSOFDEVICE _IOW(BT_IOC_MAGIC, 0x3a, unsigned char[3])
#define HCIREAD_AUTHENTICATION_ENABLE _IOR(BT_IOC_MAGIC, 0x3b, int)
#define HCIWRITE_AUTHENTICATION_ENABLE _IOWR(BT_IOC_MAGIC, 0x3c, int)
#define HCIREAD_ENCRYPTION_MODE _IOR(BT_IOC_MAGIC, 0x3d, int)
#define HCIWRITE_ENCRYPTION_MODE _IOWR(BT_IOC_MAGIC, 0x3e, int)
#define HCISET_EVENT_FILTER _IOW(BT_IOC_MAGIC, 0x3f, unsigned char[3])

/* Informational Parameters */

#define HCIREADCOUNTRYCODE _IOR(BT_IOC_MAGIC, 0x43, int)
#define HCIREADLOCALBDADDR _IOR(BT_IOC_MAGIC, 0x45, unsigned char[6])

/* Status Parameters */

/* ============================================================== */
/* Testing Commands */
#define HCIENABLEDUT _IO(BT_IOC_MAGIC, 0x65)

/* ============================================================== */
/* Ioctls Vendor specific HCI commands */

#define HCISETBAUDRATE _IOW(BT_IOC_MAGIC, 0x70, int)
#define HCIWRITEBDADDR _IOW(BT_IOC_MAGIC, 0x71, unsigned char[6])

/* | len 1 byte | 4 bytes hci header | data (max 256) | */
#define HCISENDRAWDATA _IOW(BT_IOC_MAGIC, 0x72, unsigned char[261])

/* | BD(6) | len(2) | data(max 256) |*/
#define BTPING _IOW(BT_IOC_MAGIC, 0x73, ping_struct)

/* | BD(6) | type (2) |*/
#define BTGETINFO _IOW(BT_IOC_MAGIC, 0x74, unsigned char[8])

/* ============================================================== */

/* Used to calculate opcode for HCI commands using raw interface */
#define OPCODE_LSB(ocf, ogf) ((ocf) & 0xff)
#define OPCODE_MSB(ocf, ogf) (((ocf) >> 8) | (((ogf) & 0x3f) << 2))

/* HCI packet types */
#define CMD_PKT 0x01
#define ACL_PKT 0x02
#define SCO_PKT 0x03

/* Define the different OpCode Group Field (OGF) values */
#define HCI_LC 0x01   /* Link Control Command */
#define HCI_LP 0x02   /* Link Policy Command */
#define HCI_HC 0x03   /* Host Controller and Baseband Commands */
#define HCI_IP 0x04   /* Informational Parameters */
#define HCI_SP 0x05   /* StatusParameters */
#define HCI_TC 0x06   /* Test Commands */
#define MANUFACTURER_SPEC 0x3f

/* ============================================================== */
/* Ioctls used for general testing */

#define BTSENDTESTDATA _IOW(BT_IOC_MAGIC, 0xf0, int[2])
#define HCITESTCONNECTREQ _IOW(BT_IOC_MAGIC, 0xf1, unsigned char[6])

/* | len (1) | test string | -- used for unplug tests */
#define BTTESTCOMMAND _IOW(BT_IOC_MAGIC, 0xf2, unsigned char[261])

#define BTSETMSSWITCH _IOW(BT_IOC_MAGIC, 0xf3, unsigned char)
#define BTSETBCSPMODE _IOWR(BT_IOC_MAGIC, 0xf4, int)

#define CSR_PSKEY_MSGHDR_SIZE 3
#define CSR_PSKEY_MAXPARAMS 40

/* 
 *  | ps_key (u16) | rw_mode (u16) | len (u16) | params (u16[])| 
 */
#define BT_CSR_PSKEY _IOWR(BT_IOC_MAGIC, 0xf5, unsigned short[CSR_PSKEY_MSGHDR_SIZE + CSR_PSKEY_MAXPARAMS])

#define BTINITBCSP _IO(BT_IOC_MAGIC, 0xf6)

#define BT_SET_DFU_MODE _IOWR(BT_IOC_MAGIC, 0xf7, int)
#define BT_SEND_DFU_COMMAND _IOWR(BT_IOC_MAGIC, 0xf8, unsigned char[2048])
#define BT_RETRIEVE_DFU_RESPONSE _IOWR(BT_IOC_MAGIC, 0xf9, unsigned char[2048])

#define BTSETMAXCONNECTIONS _IOW(BT_IOC_MAGIC, 0xfa, unsigned char)
/* ============================================================== */
/* Structs  */

typedef struct bt_connection
{
  unsigned char bd[6];
  unsigned int id; /* | psm(16 bits)�| layer_specific (16 bits)�|�*/
} bt_connection;

typedef struct inquiry_results
{
  unsigned int nbr_of_units;
  unsigned int inq_time;
  unsigned char bd_addr[0];
} inquiry_results;

typedef struct ping_struct
{
  unsigned char bd[6];
  unsigned short len;
  unsigned char data[1024];
} ping_struct;

#endif /* BT_USERSTACK */

/* ============================================================== */
/* Functions common to both usermode and kernel stack */

/* 
 * Init/shutdown and control of stack 
 */

int init_stack(int bt_cfd);
int bt_isinitiated(int bt_cfd);
void shutdown_stack(int bt_cfd);
#ifndef BT_USERSTACK
char* bt_hw_vendor(void);
#endif
char* bt_firmware_info(void);
int bt_bcsp_mode(int bt_cfd, int enable);
int bt_dfu_mode(int bt_cfd, int enable);
void reset_hw(void);
int bt_openctrl(void);
void set_bt_line_disc(int phys_fd, int bt_disc, char* physdev);

/* 
 * Connect/Disconnect functions 
 */

int bt_connect(int bt_fd, unsigned char *bd, unsigned int con_id);
int bt_disconnect(int bt_fd, unsigned int con_id);

void bt_waitline(int bt_fd, int line);
void bt_waitconnection(int bt_fd, int line);
void bt_waitnewconnections(int bt_fd);
int bt_isconnected(int bt_cfd, int line);
int bt_send(int fd, int len, int repeat);
void bt_showstatus(void);
int bt_force_msswitch_as_server(int bt_cfd, int enable);
int bt_set_max_conections(int bt_cfd, int connections);

/*  
 * HCI command functions 
 */

int bt_send_raw_hci(int bt_cfd, unsigned char *data, char len);
int bt_send_dfu_command(int bt_cfd, int len, unsigned char *data);
int bt_retrieve_dfu_response(int bt_cfd, int len, unsigned char *data);
int bt_ping(int bt_cfd, unsigned char bd[6], 
	    unsigned char *data, unsigned short len);
int bt_getinfo(int bt_cfd, unsigned char bd[6], unsigned short type);
int bt_testcmd(int bt_cfd, unsigned char *cmd);

int bt_inquiry(int bt_cfd, int nbr_rsp, int t);
int bt_set_baudrate(int bt_cfd, const char *speedstr);
void bt_set_bd_addr(int bt_cfd, unsigned char *bd);
void read_local_bd(int bt_cfd, unsigned char *bd_addr);
void read_remote_bd(int bt_cfd, int line, unsigned char *bd_addr);
void role_switch(int bt_cfd, unsigned char *bd_addr, int role);

int bt_set_event_filter(int bt_cfd, unsigned char filter[3]);
int bt_write_scan_enable(int bt_cfd, unsigned int flags);
void bt_write_pagescan_activity(int bt_cfd, unsigned int interval, 
				unsigned int wind);
void bt_set_classofdevice(int bt_cfd, unsigned short service_class, 
			  unsigned char major_class, 
			  unsigned char minor_class, 
			  unsigned char format);

int bt_read_country_code(int bt_cfd);

void enable_dut(int bt_cfd);


/* Sets friendly name to local_name + hostname in HW */
void set_local_hostname(int bt_cfd, const char *local_name);

/* Sets friendly name to name */
void bt_set_local_name(int bt_cfd, const unsigned char *name);

/* 
 * Misc functions 
 */

int open_device(char* dev, int flags, int role);
void close_device(int fd);
const char *error_msg(int err);
int start_sdp_server(void);

/* ============================================================== */
/* Functions only used in usermode stack */

#ifdef BT_USERSTACK

const char* psmname(unsigned short psm);
int bt_write_lower_driver(unsigned char *data, int len);
int bt_write_top(char *buf, int count, int line);
int bt_receive_top(rfcomm_con *rfcomm, unsigned char *data, int len);
void bt_rfcomm_connection_ready(int status);
void bt_sdp_connection_ready(int status);
int bt_initiated(void);
extern int bt_read_proc(char *buf, int len);
void init_userstack();

#ifdef BT_USERSTACK
int bt_register_rfcomm(struct rfcomm_con *rfcomm, unsigned char dlci);
void bt_connect_cfm(unsigned int con_id, int status);
#endif

/* FIXME<1> clean this up !!! */
bt_stat_struct bt_stat;

/* Thread used to read data on "physical" device i.e where BT HW sits */
pthread_t read_thread;
int init_read_thread(void);
void hci_receive_thread(void);

/* ============================================================== */

#endif
/* ============================================================== */
#endif /* __BT_IF_H__ */
