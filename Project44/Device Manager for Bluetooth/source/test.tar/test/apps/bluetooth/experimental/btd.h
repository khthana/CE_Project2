
#ifndef BTD_H
#define BTD_H

/****************** INCLUDE FILES SECTION ***********************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

#define INFO_DEBUG 1

#if INFO_DEBUG

#define INFO(fmt, args...) do {printf("%s, %d : ", __FILE__, __LINE__); printf(fmt, ## args);} while (0)

#else
#define INFO(fmt, args...) 
#endif

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

#endif
/****************** END OF FILE btd.h ***************************************/
