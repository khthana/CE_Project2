
#ifdef BT_USERSTACK
#include <pty.h>
#include <pthread.h>
#include "include/btcommon.h"
#include "include/btmem.h"
#include "include/hci.h"
#include "include/l2cap.h"
#include "include/sdp.h"
#include "include/tcs.h"
#include "include/test.h"
#include "include/rfcomm.h"
#include "include/btdebug.h"
#include "include/bt_proc.h"
#include "include/btdebug.h"
#include "unplug_test.h"

extern int phys_fd;
int bt_initdone = 0;
int ready_for_ppp = 0;
rfcomm_con *test_rfcomm;
int test_dlci;
#define FD_BTUSERCTRL 0xb055e
#endif
