
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>

#include "btd.h"
#include "bt_if.h"
#include "bt_vendor.h"
#include "bt_misc.h"
#include "bt_conf.h"
#include "bt_user.h"
#include "bt_errno.h"

#define D(x) //x

/* ============================================================= */
/* Functions common for kernel and usermode stack                */
/* ============================================================= */

int init_stack(int bt_cfd)
{
  syslog(LOG_INFO, "Init stack");

#ifndef BT_USERSTACK
  if (ioctl(bt_cfd, BTINITSTACK) < 0)
  {
    return -1;
  }
#else
  init_userstack();
#endif

  if (!bt_dfu_mode(bt_cfd, -1))
  {
    /* fixme<3> -- read these parameters from config file ? */
    bt_set_classofdevice(bt_cfd, 0x10, 0x3, 0x0, 0x0);

#ifndef __CRIS__
    set_local_hostname(bt_cfd, "AXIS");
#endif
  }
  
  return 0;
}

/* ============================================================ */
/* Init/shutdown and control of stack */ 

int bt_isinitiated(int bt_cfd)
{
  int fd = (bt_cfd < 0 ? bt_openctrl() : bt_cfd);
  int stack_initiated = -1;

  if (fd < 0 || ioctl(fd, BTISINITIATED, &stack_initiated) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
  if (bt_cfd < 0)
  {
    close(fd);
  }
  return stack_initiated;
}


void shutdown_stack(int bt_cfd)
{
  syslog(LOG_INFO, "Shutting down bluetooth stack");
#ifndef BT_USERSTACK
  if (bt_cfd != -1 && (ioctl(bt_cfd, BTSHUTDOWN) < 0))
  {
    syslog(LOG_ERR, "Shutting down stack failed (bt_cfd = %d)", bt_cfd);
  }
#else
  if (bt_initdone)
  {
    rfcomm_close();
    sdp_shutdown();
    tcs_shutdown();
    l2cap_shutdown();
    btmem_shutdown();
    bt_initdone = 0;
  }
#endif
}

#ifndef BT_USERSTACK
char* bt_hw_vendor(void)
{
  int bt_cfd = bt_openctrl();
  static char buffer[20];

  if (bt_cfd < 0 || ioctl(bt_cfd, BTHWVENDOR, buffer) < 0)
  {
    perror(__FUNCTION__);
    return NULL;
  }
  close(bt_cfd);
  return buffer;
}
#endif

char* bt_firmware_info(void)
{
#ifndef BT_USERSTACK
  int bt_cfd = bt_openctrl();
  static char buffer[80];

  if (bt_cfd < 0 || ioctl(bt_cfd, BTFIRMWAREINFO, buffer) < 0)
  {
    perror(__FUNCTION__);
    return NULL;
  }
  close(bt_cfd);
  return buffer;
#else
  return bt_hw_firmware();
#endif
}

int
bt_bcsp_mode(int bt_cfd, int enable)
{
#ifndef BT_USERSTACK
  int fd = (bt_cfd < 0 ? bt_openctrl() : bt_cfd);

  if (fd < 0 || ioctl(fd, BTSETBCSPMODE, &enable) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }

  if (bt_cfd < 0)
  {
    close(fd);
  }

  return enable;
#else
  return 0;
#endif
}

int
bt_dfu_mode(int bt_cfd, int enable)
{
#ifndef BT_USERSTACK
  if (ioctl(bt_cfd, BT_SET_DFU_MODE, &enable) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }

  return enable;
#else
  return 0;
#endif
}

void reset_hw(void)
{
#ifdef __CRIS__
  int devfd;

  if ((devfd = bt_openctrl()) >= 0)
  {
    if (ioctl(devfd, BTRESETPHYSICALHW) < 0)
    {
      perror(__FUNCTION__);
      exit(1);
    }
    sleep(2);

    close(devfd);
  }
  else
  {
    fprintf(stderr, "ERROR! Failed to open BT control device\n");
  }
#else
  printf("Please reset HW board within 5 seconds\n");
  sleep(5);
#endif
}

int bt_openctrl(void)
{
  int bt_cfd;

  D(syslog(LOG_INFO, "Now opening BT Ctrl TTY [" BT_CTRL_TTY "]"));
#ifdef BT_USERSTACK
  printf(__FUNCTION__ ": ignored in userstack\n");
  return FD_BTUSERCTRL;
#else 
  if ((bt_cfd = open(BT_CTRL_TTY, O_RDWR | O_NOCTTY)) < 0)
  {
    fprintf(stderr, "Could not open " BT_CTRL_TTY "\n");
    exit(1);
  }
#endif
  return bt_cfd;
}

/* fixme<3> -- sdp connect */

int
bt_connect(int bt_fd, unsigned char *bd, unsigned int con_id)
{
  bt_connection con;
  int result;
#ifdef BT_USERSTACK
  unsigned short srv_ch;
  unsigned short line;
#endif
  
  memcpy(con.bd, bd, 6);
  con.id = con_id;
  switch(GET_PSM(con_id))
  {
   case SDP_LAYER:
   case RFCOMM_LAYER:
   case TCS_LAYER:
   case L2CAP_TEST_LAYER:
   case L2CAP_TEST2_LAYER:
   case L2CAP_TEST3_LAYER:
    break;
    
   default:
    printf(__FUNCTION__" : Unknown layer\n");
    con.id = 0;
    return -1;
  }

#ifndef BT_USERSTACK
  if ((result = ioctl(bt_fd, BTCONNECT, &con)))
    printf("Connect failed [%s (%d)]\n", error_msg(result), MSG_GET_CODE(-result));
  else
    printf("Connected.\n"); 
#else
  {  
    if ((GET_PSM(con_id) == RFCOMM_LAYER) && ((con_id >> 8) & 0xff) != 0)
    {
      printf("Use line 0 instead ! (usermode only)\n");
      return -1;
    }

//  printf("Connecting srv ch %d on line %d\n", srv_ch, line);
    result = bt_connect(bd, con_id);		
  }
#endif
  return result;
}

int
bt_disconnect(int bt_fd, unsigned int con_id)
{
  int ret_val = 0;
  
#ifndef BT_USERSTACK  
  if ((ret_val = ioctl(bt_fd, BTDISCONNECT, &con_id)))
    printf("Disconnect failed [%s (%d)]\n", error_msg(ret_val), MSG_GET_CODE(-ret_val));
  else
    printf("Disconnected.\n");
#else
  if ((GET_PSM(con_id) == RFCOMM_LAYER) && ((con_id >> 8) & 0xff) != 0)
  {
    printf("Use line 0 instead ! (usermode only)\n");
    return -1;
  }
  
  ret_val = bt_disconnect(con_id);
#endif
  return ret_val;
}

/* Check whether this line is lower connected in stack (rfcomm ready) */
int bt_isconnected(int bt_cfd, int line)
{
  int fd = (bt_cfd < 0 ? bt_openctrl() : bt_cfd);
  int ret;
#ifndef BT_USERSTACK
  if (fd < 0 || (ret = ioctl(fd, BTISLOWERCONNECTED, &line)) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
#else
  fprintf(stderr, __FUNCTION__ ": not yet implemented...\n");
  ret = -1;
#endif
  if (bt_cfd < 0)
  {
    close(fd);
  }
  return ret;
}

void bt_showstatus(void)
{
#ifdef BT_USERSTACK
  char tmp[4096];
  int len;

  len = bt_read_internal(tmp);
  tmp[len] = 0;
  printf(tmp);
#else
  system("cat /proc/bt_internal");
#endif 
}

/* fixme<1> --  add usermode stack version */
int
bt_send(int fd, int len, int repeat)
{ 
#define  MAXSIZE (4096*2)
  struct timeval start_t, stop_t;
  int bytes_tot; 
  int avg_speed = 0; /* bps */
  unsigned int ms;
  char tmp[MAXSIZE];
  int j;

  if (len > MAXSIZE)
  {
    printf("Max %d bytes per write!\n", MAXSIZE);
    len = MAXSIZE;
  }
  
  bytes_tot = len*repeat; 

  printf(__FUNCTION__ ": %d X %d bytes [%d k]\n", len, repeat, len*repeat/1000); 
  
  /* fill them with letters... */
  for (j = 0; j < len; j++)
  {
    tmp[j] = (j % 25) + 65;
  }
  
  printf("\nNow sending %d %d-bytes packet (%d kB)\n", 
         repeat, len, bytes_tot/1000);
  
  gettimeofday(&start_t, NULL);
  
  while (repeat)
  {
    int n = 0;
    n = write(fd, tmp, len);   
    
    if (n <= 0)
    {
      printf("couldn't write any more data...\n\n");
      bytes_tot = bytes_tot-repeat*len;
      return -1;
    }
    
    repeat--;
    printf("%6d kB left to send... \r", ((repeat*len)/1000));
    fflush(stdout);
  }
  gettimeofday(&stop_t, NULL);
  printf("\ndone.\n");
  
  ms = (stop_t.tv_sec-start_t.tv_sec)*1000 + 
    (stop_t.tv_usec-start_t.tv_usec)/1000;
  if (ms)
    avg_speed = ((8*bytes_tot)/ms);
  printf("Average TX rate : %d kbps (%d kB/s)\n", avg_speed, avg_speed/8);

  return 0;
}


void
bt_waitline(int bt_fd, int line)
{
  printf("wait for a connection on line %d\n", line);
#ifndef BT_USERSTACK
  if (ioctl(bt_fd, BTWAITFORCONNECTION, &line) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
  printf(__FUNCTION__ ": got a connection !\n");
#else
  /* fixme<1> */
  fprintf(stderr, __FUNCTION__ ": not yet implemented...\n");
#endif
}

void
bt_waitnewconnections(int bt_fd)
{
  printf("Wait for a new connection\n");
#ifndef BT_USERSTACK
  if (ioctl(bt_fd, BTWAITNEWCONNECTIONS) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
  printf(__FUNCTION__ ": found a connection !\n");
#else
  /* fixme<1>*/
  fprintf(stderr, __FUNCTION__ ": not yet implemented...\n");
#endif
}
 
void
bt_waitconnection(int bt_fd, int line)
{
  printf("Wait for a connection on line %d\n", line);
#ifndef BT_USERSTACK
  if (ioctl(bt_fd, BTWAITFORCONNECTION, &line) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
  printf(__FUNCTION__ ": got a connection !\n");
#else
  /* fixme<1>*/
  fprintf(stderr, __FUNCTION__ ": not yet implemented...\n");
#endif
}

int bt_send_raw_hci(int bt_cfd, unsigned char *data, char len)
{
  unsigned char buf[261];

  buf[0] = len;
  
  memcpy(buf+1, data, len);

  print_data("data :", (char*)buf, (int)len+1);

#ifndef BT_USERSTACK 
  if (ioctl(bt_cfd, HCISENDRAWDATA, buf) < 0)
  {
    perror(__FUNCTION__);
    return -1;
  }
#else
  fprintf(stderr, __FUNCTION__ ": not yet implemented...\n");
  //hci_send_raw_data(data, 16);
#endif
  return 0;
}

int
bt_send_dfu_command(int bt_cfd, int len, unsigned char *data)
{
  static unsigned char buf[2048];

  if (len > sizeof buf - sizeof(int))
  {
    errno = EINVAL;
    return -1;
  }

  *(int *)buf = len;
  
  memcpy((int *)buf+1, data, len);

#ifndef BT_USERSTACK 
  if (ioctl(bt_cfd, BT_SEND_DFU_COMMAND, buf) < 0)
  {
    perror(__FUNCTION__);
    return -1;
  }

  return 0;
#else
  fprintf(stderr, __FUNCTION__ ": Not yet implemented...\n");
  errno = EPERM;
  return -1;
#endif
}

int
bt_retrieve_dfu_response(int bt_cfd, int len, unsigned char *data)
{
  *(int *)data = len - sizeof(int);

#ifndef BT_USERSTACK 
  if (ioctl(bt_cfd, BT_RETRIEVE_DFU_RESPONSE, data) < 0)
  {
    perror(__FUNCTION__);
    return -1;
  }

  len = *(int *)data;
  
  memmove(data, (int *)data+1, len);
  return len;
#else
  fprintf(stderr, __FUNCTION__ ": Not yet implemented...\n");
  errno = EPERM;
  return -1;
#endif
}

int bt_ping(int bt_cfd, unsigned char bd[6], 
	    unsigned char *data, unsigned short len)
{
  int ret_val;
  struct ping_struct ping;
  
  print_data(__FUNCTION__ " BD : ", bd, 6);
  memcpy(ping.bd, bd, 6);
  ping.len = len;  
  memcpy(ping.data, data, len);
  
#ifndef BT_USERSTACK 
  if ((ret_val = ioctl(bt_cfd, BTPING, &ping)) < 0)
  {
    printf("Error : [%s (%d)]\n", error_msg(ret_val), MSG_GET_CODE(-ret_val));
  }
  else
    printf("Success!\n");
#else
  ret_val = l2ca_ping(bd, data, len);
#endif
  return ret_val;
}

int 
bt_getinfo(int bt_cfd, unsigned char bd[6], unsigned short type)
{
  int ret_val;
  unsigned char msg[8];
  
  memcpy(msg, bd, 6);
  msg[6] = (unsigned char)(type >> 8);
  msg[7] = (unsigned char)(type & 0xff);

#ifndef BT_USERSTACK 
  if ((ret_val = ioctl(bt_cfd, BTGETINFO, &msg)) < 0)
  {
    printf("Error : [%s (%d)]\n", error_msg(ret_val), MSG_GET_CODE(-ret_val));
  }
  else
    printf("Success!\n");
#else
  ret_val = l2ca_getinfo(bd, type);
#endif
  return ret_val;
}

/* input is a nullterminated string */

int bt_testcmd(int bt_cfd, unsigned char *cmd)
{
  int ret_val = 0;
  unsigned char len = strlen(cmd);
  unsigned char tmp[261];

  tmp[0] = len;
  memcpy(tmp+1, cmd, len+1); /* don't forget nullterminate... */

#ifndef BT_USERSTACK 
  if ((ret_val = ioctl(bt_cfd, BTTESTCOMMAND, tmp)) < 0)
  {
    printf("Error : [%s (%d)]\n", error_msg(ret_val), MSG_GET_CODE(-ret_val));
  }
  else
    printf("Success!\n");
#else
  ret_val = test_process_cmd(&tmp[1], tmp[0]);
#endif
  return ret_val;
}

int bt_force_msswitch_as_server(int bt_cfd, int enable)
{
  syslog(LOG_INFO, __FUNCTION__ ": %d", enable);
#ifndef BT_USERSTACK 
  if (ioctl(bt_cfd, BTSETMSSWITCH, &enable) < 0)
  {
    perror(__FUNCTION__);
    return -1;
  }
#else
  hci_force_msswitch(enable);
#endif
  return 0;
}

int bt_set_max_conections(int bt_cfd, int connections)
{
  syslog(LOG_INFO, __FUNCTION__ ": %d", connections);
#ifndef BT_USERSTACK 
  if (ioctl(bt_cfd, BTSETMAXCONNECTIONS, &connections) < 0)
  {
    perror(__FUNCTION__);
    return -1;
  }

  return 0;
#else
  {
    int ret_val = hci_set_max_connections(connections);

    if (ret_val >= 0)
    {
      return ret_val;
    }

    errno = -ret_val;
    return -1;
  }
#endif
}

/* ============================================================ */
/* HCI functions */


int
bt_inquiry(int bt_cfd, int nbr_rsp, int t)
{
  int retval = 0;
#ifdef BTD_USERSTACK
  char inq_lap[6];

  printf("Inquiring...\n");

  inq_lap[0] = 0x33;
  inq_lap[1] = 0x8b;
  inq_lap[2] = 0x9e;

  retval = hci_inquiry(inq_lap, t, nbr_rsp);
#else
  int i;
  inquiry_results *inq_res;

  if (!(inq_res = malloc(sizeof *inq_res + nbr_rsp * 6)))
  {
    fprintf(stderr, __FUNCTION__ ": Failed to allocate result structure!\n");
    return -ENOMEM;
  }

  inq_res->nbr_of_units = nbr_rsp;
  inq_res->inq_time = t;

  if ((retval = ioctl(bt_cfd, HCIINQUIRY, inq_res)) < 0)
  {
    printf("Inquiry failed [%s (%d)]\n", error_msg(retval), MSG_GET_CODE(-retval));
    free(inq_res);
    return retval;
  }

  for (i = 0; i < inq_res->nbr_of_units; i++)
  {
    printf("BD %d: %02x:%02x:%02x:%02x:%02x:%02x\n",i,
           inq_res->bd_addr[0+6*i], inq_res->bd_addr[1+6*i],
           inq_res->bd_addr[2+6*i], inq_res->bd_addr[3+6*i],
           inq_res->bd_addr[4+6*i], inq_res->bd_addr[5+6*i]);
  }

  free(inq_res);
#endif
  return retval;
}

void
bt_set_bd_addr(int bt_cfd, unsigned char *bd)
{
  printf("Setting BD address to: %02X:%02X:%02X:%02X:%02X:%02X\n",
         bd[0], bd[1], bd[2],
         bd[3], bd[4], bd[5]);
    
#ifndef BT_USERSTACK
  if (ioctl(bt_cfd, HCIWRITEBDADDR, bd) < 0)
  {
    perror(__FUNCTION__);
  }
#else
  hci_set_bd_addr(bd);
#endif 
  printf("Please reset HW to activate bd change\n");
}

/* The HCISETBAUDRATE ioctl is redirected to the correct 
   vendor function in the kernel */

int bt_set_baudrate(int bt_cfd, const char *speedstr)
{
  int result;
  unsigned long spd = speedstrtoli(speedstr);

  syslog(LOG_INFO, __FUNCTION__ ": %lu baud", spd);
#ifdef BT_USERSTACK
  tcflush(phys_fd, TCIOFLUSH);
  result = hci_set_baudrate(spd);
  usleep(10000);
#else
  if ((result = ioctl(bt_cfd, HCISETBAUDRATE, &spd)) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
#endif
  return result;
}

void
read_local_bd(int bt_cfd, unsigned char *bd_addr)
{
#ifndef BT_USERSTACK
  if (ioctl(bt_cfd, HCIREADLOCALBDADDR, bd_addr) < 0)
  {
    perror(__FUNCTION__);
  }
#else
  int i;
  BD_ADDR rev_bd;

  hci_read_local_bd(rev_bd);

  /* return as big endian */
  for (i = 0; i < 6; i++)
  {
    bd_addr[i] = rev_bd[5-i];
  }
#endif
}

void
enable_dut(int bt_cfd)
{
  printf("Enable device under test mode\n");
#ifndef BT_USERSTACK
  if (ioctl(bt_cfd, HCIENABLEDUT) < 0)
  {
    perror(__FUNCTION__);
  }
#else
  hci_enable_dut();
#endif
  printf("done.\n");
}

void
read_remote_bd(int bt_cfd, int line, unsigned char *bd_addr)
{
#ifndef BT_USERSTACK
  *(int*)bd_addr = line;

  if (ioctl(bt_cfd, BTREADREMOTEBDADDR, bd_addr) < 0)
  {
    perror(__FUNCTION__);
  }
#else
  BD_ADDR rev_bd;
  int i;

  get_remote_bd(line, rev_bd);

  /* return as big endian */
  for (i = 0; i < 6; i++) {
    bd_addr[i] = rev_bd[5-i];
  }
#endif
}

int bt_write_scan_enable(int bt_cfd, unsigned int flags)
{
  int result;

  syslog(LOG_INFO, "Setting write_scan_enable: 0x%x", flags);

#ifdef BT_USERSTACK
  result = hci_write_scan_enable(flags);
#else

  if ((result = ioctl(bt_cfd, HCIWRITESCANENABLE, &flags)) < 0)
  { 
    perror(__FUNCTION__);
    exit(1);
  }
#endif	
  return result;
}

void
bt_write_pagescan_activity(int bt_cfd, unsigned int interval, 
                           unsigned int wind)
{
  /* improves reliability when doing a connect */

  syslog(LOG_INFO, "Setting write_pagescan_activity: int:0x%x wind:0x%x", 
	 interval, wind);


#ifdef BT_USERSTACK
  hci_write_pagescan_activity(interval, wind);
#else
  {
    unsigned int tmp[2];

    tmp[0] = interval;
    tmp[1] = wind;

    if (ioctl(bt_cfd, HCIWRITEPAGESCANACTIVITY, &tmp) < 0)
    { 
      perror(__FUNCTION__);
      exit(1);
    }
  }
#endif
}

int bt_set_event_filter(int bt_cfd, unsigned char filter[3])
{
  int result;

  syslog(LOG_INFO, "Setting event filter [0x%x 0x%x 0x%x]", 
	 filter[0], filter[1], filter[2]);

#ifdef BT_USERSTACK
  result = hci_set_event_filter((u8*)&filter);
#else

  if ((result = ioctl(bt_cfd, HCISET_EVENT_FILTER, &filter)) < 0)
  { 
    perror(__FUNCTION__);
    exit(1);
  }
#endif
  return result;
}



void
bt_set_classofdevice(int bt_cfd, unsigned short service_class,
		     unsigned char major_class, unsigned char minor_class,
		     unsigned char format)
{
  unsigned char class_of_device[3]; 

  syslog(LOG_INFO, "bt_set_classofdevice : srv class 0x%x, maj class 0x%x, min class 0x%x, format 0x%x", service_class, major_class, minor_class, format);
  switch (format)
  {
  case 0:
    class_of_device[0] = (minor_class << 2);
    class_of_device[1] = ((service_class & 0x7) << 5) | (major_class & 0x1f);
    class_of_device[2] = (service_class  & 0x7f8) >> 3;
    
#ifndef BT_USERSTACK 
    if (ioctl(bt_cfd, HCIWRITECLASSOFDEVICE, class_of_device) < 0)
    {
      perror(__FUNCTION__);
      exit(1);
    }
#else
    hci_write_class_of_device(class_of_device);
#endif
    break;

  case 1:
    syslog(LOG_INFO, __FUNCTION__ ": Unsupported format 0x%02x", format);
    break;

  case 2:
    syslog(LOG_INFO, __FUNCTION__ ": Unsupported format 0x%02x", format);
    break;

  default:
    syslog(LOG_INFO, __FUNCTION__ ": Unsupported format 0x%02x", format);
    break;
  }
}

void
role_switch(int bt_cfd, unsigned char* bd_addr, int role)
{
  int i;
  unsigned char tmp[7];

  syslog(LOG_INFO, "Performing role switch to peer: %02X:%02X:%02X:%02X:%02X:%02X",
         bd_addr[0], bd_addr[1], bd_addr[2],
         bd_addr[3], bd_addr[4], bd_addr[5]);

  for (i = 0; i < 6; i++)
  {
    tmp[5-i] = (unsigned char)*bd_addr++;
  }

  tmp[6] = (unsigned char)role;

#ifndef BT_USERSTACK
  if (ioctl(bt_cfd, HCISWITCHROLE, tmp) < 0)
  {
    perror(__FUNCTION__);
  }
#else
  hci_switch_role(bd_addr, role);
#endif
}

void
set_bt_line_disc(int phys_fd, int bt_disc, char* physdev)
{
#ifndef BT_USERSTACK
  if (ioctl(phys_fd, TIOCSETD, &bt_disc) < 0)
  {
    perror(__FUNCTION__);
    syslog(LOG_INFO, "Forgot to insmod bt.o ? [bt_disc %d]", bt_disc);
    exit(1);
  }
  syslog(LOG_INFO, "Registered bluetooth line discipline on %s", physdev);
#else
  fprintf(stderr, __FUNCTION__ ": ignored in usermode stack\n");
#endif
}


void set_local_hostname(int bt_cfd, const char *local_name)
{
  unsigned char domainname[DOMAIN_NAME_LENGTH+1];
  unsigned char buf[LOCAL_NAME_LENGTH + HOST_NAME_LENGTH + 
		   DOMAIN_NAME_LENGTH + 5];
  int len = 0;

  *buf = '\0';
  *domainname = '\0';

  if (*local_name)
  {
    while (*local_name && len < LOCAL_NAME_LENGTH)
    {
      if (*local_name >= ' ' && *local_name <= 'z')
      {
        buf[len++] = *local_name++;
      }
    }
 
    if (len)
    {
      buf[len++] = ' ';
      buf[len++] = '(';
      buf[len] = '\0';
    }
  }

  gethostname(&buf[len], HOST_NAME_LENGTH);

  if (!strchr(&buf[len], '.'))
  {
    getdomainname(domainname, DOMAIN_NAME_LENGTH);
    if (*domainname)
    {
      strcat(buf, ".");
      strcat(buf, domainname);
    }
  }

  if (len)
  {
    strcat(buf, ")");
  }

  bt_set_local_name(bt_cfd, buf);

}

void bt_set_local_name(int bt_cfd, const unsigned char *name)
{
  unsigned char buffer[248];
  int i = 0;

  syslog(LOG_INFO, __FUNCTION__ ": %s", name);

  /* Hack to convert ISO 8859-1 to UTF-8 */
  for (; *name && i < sizeof buffer - 3; name++)
  {
    if (*name < 128)
    {
      buffer[i++] = *name;
    }
    else
    {
      buffer[i++] = 0xC0 | (*name >> 6);
      buffer[i++] = 0x80 | (*name & 0x3F);
    }
  }
  buffer[i] = '\0';

#ifndef BT_USERSTACK  
  if (ioctl(bt_cfd, HCISETLOCALNAME, buffer) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
#else
  hci_change_local_name(buffer);
#endif
}

int bt_read_country_code(int bt_cfd)
{
  int result;

#ifndef BT_USERSTACK  
  if (ioctl(bt_cfd, HCIREADCOUNTRYCODE, &result) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
  return result;
#else
  return hci_read_country_code();
#endif
}

/* ============================================================ */
/* Misc functions */

/* See bt_errno.h for error codes */
const char *error_msg(int err)
{
  int layer, code, msg;
  msg = -err;
  layer = MSG_GET_LAYER(msg);
  code = MSG_GET_CODE(msg);
  
  switch(layer) 
  {
   case MSG_LAYER_HCI:
    switch(code) 
    {
     case 0x00: return "HCI: Success!";
     case 0x01: return "HCI: Unknown HCI Command";
     case 0x02: return "HCI: No Connection";
     case 0x03: return "HCI: Hardware Failure";
     case 0x04: return "HCI: Page Timeout";
     case 0x05: return "HCI: Authentication Failure";
     case 0x06: return "HCI: Key Missing";
     case 0x07: return "HCI: Memory Full";
     case 0x08: return "HCI: Connection Timeout";
     case 0x09: return "HCI: Max Number Of Connections";
     case 0x0A: return "HCI: Max Number Of SCO Connections To A Device";
     case 0x0B: return "HCI: ACL connection already exists";
     case 0x0C: return "HCI: Command Disallowed";
     case 0x0D: return "HCI: Host Rejected due to limited resources";
     case 0x0E: return "HCI: Host Rejected due to security reasons";
     case 0x0F: return "HCI: Host Rejected due to remote device is only a personal device";
     case 0x10: return "HCI: Host Timeout";
     case 0x11: return "HCI: Unsupported Feature or Parameter Value";
     case 0x12: return "HCI: Invalid HCI Command Parameters";
     case 0x13: return "HCI: Other End Terminated Connection: User Ended Connection";
     case 0x14: return "HCI: Other End Terminated Connection: Low Resources";
     case 0x15: return "HCI: Other End Terminated Connection: About to Power Off";
     case 0x16: return "HCI: Connection Terminated by Local Host";
     case 0x17: return "HCI: Repeated Attempts";
     case 0x18: return "HCI: Pairing Not Allowed";
     case 0x19: return "HCI: Unknown LMP PDU";
     case 0x1A: return "HCI: Unsupported Remote Feature";
     case 0x1B: return "HCI: SCO Offset Rejected";
     case 0x1C: return "HCI: SCO Interval Rejected";
     case 0x1D: return "HCI: SCO Air Mode Rejected";
     case 0x1E: return "HCI: Invalid LMP Parameters";
     case 0x1F: return "HCI: Unspecified Error";
     case 0x20: return "HCI: Unsupported LMP Parameter Value";
     case 0x21: return "HCI: Role Change Not Allowed";
     case 0x22: return "HCI: LMP Response Timeout";
     case 0x23: return "HCI: LMP Error Transaction Collision";
     case 0x24: return "HCI: LMP PDU Not Allowed";
     case 0x25: return "HCI: Encryption Mode Not Acceptable";
     case 0x26: return "HCI: Unit Key Used";
     case 0x27: return "HCI: QOS is Not Supported";
     case 0x28: return "HCI: Instant Passed";
     case 0x29: return "HCI: Pairing with Unit Key Not Supported";
     default: return "HCI: No debug msg defined";
    }
   case MSG_LAYER_L2CAP:
    switch(code) 
    {
     case L2CAP_SUCCESS: return "L2CAP: Success";
     case L2CAP_CON_PENDING: return "L2CAP: Connection Pending";
     case L2CAP_PSMNEG: return "L2CAP: Connection Refused, PSM Not Accepted";
     case L2CAP_SECNEG: return "L2CAP: Connection Refused, Authentication Failed";
     case L2CAP_NOSRC: return "L2CAP: Connection Refused, No Resources";
     case L2CAP_FAILED: return "L2CAP: General Error";
     case L2CAP_CON_UNRESPONSIVE: return "L2CAP: No Reply From Remote";
     case L2CAP_INVALID_STATE: return "L2CAP: Invalid State";
     case L2CAP_NO_CONNECTION: return "L2CAP: No Connection";
     case L2CAP_EXCEED_REMOTE_MTU: return "L2CAP: Trying to send a frame more than remote MTU";
     case L2CAP_RTX_TIMEOUT: return "L2CAP: Timeout Waiting For Remote To Reply";
     default: return "L2CAP: No debug msg defined";
    }
   case MSG_LAYER_RFCOMM:
    switch(code)
    {
     case RFCOMM_INVALID_LINE: return "RFCOMM: Trying to use an invalid line"; 
     case RFCOMM_SRVCHN_CONNECTED: return "RFCOMM: Serverchannel already connected";
     case RFCOMM_NO_DATA_ALLOWED: return "RFCOMM: No data allowed on control channel";
     case RFCOMM_NO_CONNECTION: return "RFCOMM: No connection";
     case RFCOMM_BAD_MAGIC_NUMBER: return "RFCOMM: Bad magic number"; 
     default: return "RFCOMM: No debug msg defined";
    }
   case MSG_LAYER_SDP:
    switch(code)
    {
     default: return "SDP: No debug msg defined";
    }
   case MSG_LAYER_TCS:
    switch(code)
    {
     default: return "TCS: No debug msg defined";
    }
   case MSG_BT_INTERFACE:
    switch(code)
    {
     case BT_NOTCONNECTED: return "BT_INTERFACE: Line Not Connected";
     case BT_ALREADYCONNECTED: return "BT_INTERFACE: Line Already Connected";
     case BT_TIMEOUT: return "BT_INTERFACE: Timeout When Processing Command";
     case BT_LINE_BUSY: return "BT_INTERFACE: Line Busy";
     default: return "BT_INTERFACE: No debug msg defined";
    }
   default: return "General Failure";
  }
}

const char* psmname(unsigned short psm)
{
  switch(psm)
  {
  case RFCOMM_LAYER:
    return "RCOMM";
  case SDP_LAYER:
    return "SDP";
  case  TCS_LAYER:
    return "TCS";
  default:
    return "UNKNOWN";
  }
}

int open_device(char* dev, int flags, int role)
{
  int fd;

#ifdef BT_USERSTACK  
  /* if opening bt dev or control dev simply discard and return fake fd */
  if ((strncmp(dev, "/dev/ttyBT", 11) == 0) || (strcmp(dev, BT_CTRL_TTY) == 0))
    return 0xb055e;
#if 0 /* fixme */
  if (use_local_socket)
    return open_socket(dev, role);
  else if (use_tcp_socket)
    return open_tcpsocket(dev, role);
#endif
#endif  

  D(syslog(LOG_INFO, "Opening dev %s", dev));
  if ((fd = open(dev, flags | O_NOCTTY)) < 0)
  {
    perror(__FUNCTION__);
    exit(1);
  }
  
  tcflush(fd, TCIOFLUSH);
  return fd;
}

void close_device(int fd)
{
  D(syslog(LOG_INFO, __FUNCTION__));
  
#ifdef BT_USERSTACK
  /* if fake fd is used, ignore close since there are no open fd */
  if (fd != 0xb055e)
    close(fd);
#else
  if (fd != -1)
    close(fd);
#endif
}

int start_sdp_server(void)
{
  int sdpsrv_pid;
  char *args[] = { SDPSRV_CMD, SDPSRV_CONF, SDPSRV_PROC, NULL };

  D(syslog(LOG_INFO, "Starting SDP server [%s]", SDPSRV_CMD));

  if (!(sdpsrv_pid = vfork()))
  {
    execvp(SDPSRV_CMD, args);

    fprintf(stderr, "%s: no such file or directory\n", SDPSRV_CMD);
    syslog(LOG_INFO, "%s not found", SDPSRV_CMD);

    _exit(0);
  }
  return sdpsrv_pid;
}

/* ============================================================= */
/* Functions used in usermode stack only                         */
/* ============================================================= */

/* 
 *
 * FIXME -- NOT CHECKED AT ALL AFTER SPLIT UP OF BTD !!!! 
 * 
 */

#ifdef BT_USERSTACK


#if BT_DATADUMP_DEBUG
#define BT_DATADUMP(str, data, len) print_data(str, data, len)
#else
#define BT_DATADUMP(str, data, len)
#endif

#if BT_DATA_DEBUG
#if BT_USE_TIMESTAMPS
#define BT_DATA(fmt...) do {print_time(1);printk(BT_DBG_STR"DATA " fmt);} while (0)
#else
#define BT_DATA(fmt...) printk(BT_DBG_STR"DATA " fmt)
#endif /* BT_USE_TIMESTAMPS */

#else /* BT_DATA_DEBUG */
#define BT_DATA(fmt...)
#endif /* BT_DATA_DEBUG */


int init_read_thread(void)
{
  printf("Initiating read thread\n");
  if (pthread_create(&read_thread, NULL, (void*)hci_receive_thread, NULL) != 0)
    perror(__FUNCTION__);
  sleep(1); /* wait for thread to start */
  return 0;
}

void hci_receive_thread(void)
{
  fd_set rfd;
  char databuf[4096];

  while (1)
  {  
    FD_ZERO(&rfd); 
    FD_SET(phys_fd, &rfd);
    
    select(phys_fd+1, &rfd, NULL, NULL, NULL);

    if (FD_ISSET(phys_fd, &rfd))
    {
      int len = read(phys_fd, &databuf, 4096);

      if (len > 0)
      {
	BT_DATA("-->|X|    %3d\n", len);
	BT_DATADUMP("-->|X|", databuf, len);
	hci_receive_data(databuf, len);
      }
    }
  }
}

void
init_upper_pty(void)
{
  printf(__FUNCTION__);
//  open_pty();
//  init_pty_thread();  
}


void init_userstack()
{  
 /* Direct function calls instead of ioctls... */
  
  init_read_thread();
  
  /* Initialise all layers in the bluetooth stack */
  DSYS("Initialising Bluetooth Stack\n");

  hci_init();
  l2cap_init();
  rfcomm_init();
  sdp_init(SERVER);
  tcs_init();
  test_init();
  btmem_init();
  unplug_test_init();

  bt_stat.bytes_received = 0;
  bt_stat.bytes_sent = 0;  

  bt_initdone = 1;
}

/* ============================================================= */
/* Stack interface functions */

int bt_write_lower_driver(unsigned char *data, int len)
{
  int i;

  BT_DATA("<--|X|    %3d\n", len);

  BT_DATADUMP("<--|X|", data, len);
  i = write(phys_fd, data, len);
  return i;
}


/* Only works for the last connected rfcomm session */
int
bt_write_top(char *buf, int count, int line)
{
  int retval;
  int bytes_sent = 0;

  BT_DATA("   |X|<-- %3d [%d]\n", count, line);
  BT_DATADUMP("|X|<--", buf, count);

  while (bytes_sent!=count)
  {
    retval = rfcomm_send_data(CREATE_RFCOMM_ID(line,test_dlci), 
			      buf + bytes_sent, count-bytes_sent); 
    
   if (retval > 0)
     bytes_sent+=retval;
   else if (retval==0)
     usleep(1000); /* wait some ... */
   else
   {
     printf("error\n");
     return retval;
   }
   
    usleep(1000); /* wait some time ... */
  };

  bt_stat.bytes_sent+=bytes_sent;
  
  return bytes_sent;
}

int bt_receive_top(rfcomm_con *rfcomm, unsigned char *data, int len)
{
  int n = 0;

  BT_DATA("   |X|--> %3d [%d]\n", len, rfcomm->line);
  BT_DATADUMP("|X|-->", data, len);

#if 0 /* fixme */
  if (modem_emulation && !modem_connected)
  {
    modem_emulator(0xb055e, data, len);
    return len;
  }
  
  /* FIXME<2> -- why is data echoed back if no application is 
     running on top of PTY ?? */

  if (!ready_for_ppp)
    return len;

  /* feed this to PTY connected to pppd or whatever application 
     that may be running there... */
  
  if ((n = write(pty_master_fd, data, len)) != len)
  {
    BT_DATA(__FUNCTION__ ": tried to write %d bytes, wrote %d\n", len, n);
  }
#endif

  bt_stat.bytes_received+=n;

  return n;
}

void
bt_connect_ind(unsigned int con_id) 
{
  if (GET_PSM(con_id) == RFCOMM_LAYER)
    printf(__FUNCTION__ ": RFCOMM dlci : %d\n", 
           GET_RFCOMMDLCI(con_id));
  else
    printf(__FUNCTION__ ": psm %d\n", GET_PSM(con_id));
}

void
bt_connect_cfm(unsigned int con_id, int status)
{
  unsigned short psm;
  int line;

  psm = GET_PSM(con_id);

  if (status) {
    /* fixme -- only works for rfcomm now */
    line = GET_LINE(con_id);

    if ((line < 0) || (line > BT_NBR_DATAPORTS)) {

      fprintf(stderr, __FUNCTION__ ": invalid line (%d)\n", line);
      return;
    }
    fprintf(stderr, __FUNCTION__": failed, status %d [%s] line %d\n", status, psmname(psm), line);

    return;
  }

  switch (psm) {
  case RFCOMM_LAYER:
    printf(__FUNCTION__ ": [%s]\n", psmname(psm));
    break;

  case SDP_LAYER:
    printf(__FUNCTION__ ": [%s]\n", psmname(psm));
    break;

  case TCS_LAYER:
    printf(__FUNCTION__ ": [%s]\n", psmname(psm));
    break;

  default:
    printf(__FUNCTION__ ": unknown layer %d\n", psm);
    break;
  }
}

void
bt_disconnect_ind(unsigned int con_id) 
{
  if (GET_PSM(con_id) == RFCOMM_LAYER)
    printf(__FUNCTION__ ": RFCOMM dlci : %d\n", GET_RFCOMMDLCI(con_id));
  else
    printf(__FUNCTION__ ": psm %d\n", GET_PSM(con_id));
}

int
bt_register_rfcomm(struct rfcomm_con *rfcomm, u8 dlci)
{
  printf(__FUNCTION__ ": dlci %d\n", dlci);
  test_rfcomm = rfcomm;
  test_dlci = dlci;
  return 0;
}

s32
bt_unregister_rfcomm(s32 line)
{
  printf(__FUNCTION__ ": line %d\n", line);
  /* fixme -- stub for now */
}

s32
bt_register_sdp(u8 line, u8 sdpID)
{
  printf(__FUNCTION__ "\n");
  return 0;
}

s32 bt_unregister_sdp(s32 line)
{
  printf(__FUNCTION__ "\n");
  return 0;
}

int bt_initiated(void)
{
  return bt_initdone;
}
#endif /* BT_USERSTACK */
