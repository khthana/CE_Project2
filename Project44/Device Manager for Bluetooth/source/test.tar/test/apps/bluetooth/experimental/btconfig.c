
/****************** INCLUDE FILES SECTION ***********************************/

#include <stdio.h>
#include <syslog.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <stdarg.h>
#include <signal.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <limits.h>

#include "btd.h"
#include "bt_if.h"
#include "bt_conf.h"
#include "bt_misc.h"
#include "bt_vendor.h"

/****************** CONSTANT AND MACRO SECTION ******************************/

#define D(x) //x

#ifndef FALSE
#define FALSE (0)
#endif
#ifndef TRUE
#define TRUE  (1)
#endif

#define MAX_BTNAME_LEN     247
#define HOST_NAME_LENGTH   100
#define DOMAIN_NAME_LENGTH 100
#define BUF_MAXSIZE        300

#define CONF_FILE "/etc/bt.conf"

/****************** TYPE DEFINITION SECTION *********************************/

/****************** LOCAL FUNCTION DECLARATION SECTION **********************/

static void show_usage(void);

/* File parsing functions */
static int parse_file(char *filename);
static int parse_line(char* line, char** field, char** value);
static int configure_field(const char* field, const char* value);

/****************** GLOBAL VARIABLE DECLARATION SECTION *********************/

/****************** LOCAL VARIABLE DECLARATION SECTION **********************/

static int option_index = 0;
static char bt_name[MAX_BTNAME_LEN+1];
static char ip_addr[32] = "0.0.0.0";
static char ip_name[HOST_NAME_LENGTH + DOMAIN_NAME_LENGTH] = "";
static char ip_addrname[36 + HOST_NAME_LENGTH + DOMAIN_NAME_LENGTH] = "";

static int var_add_ip = FALSE;
static int var_add_host_name = FALSE;
static int var_write_scan_enable = -1; /* not yet set */
static int var_force_ms_switch = -1; /* not yet set */
static int var_set_local_name = 0;
static int var_max_connections = -1; /* not yet set */
static short var_max_power = SHRT_MAX; /* not yet set */

/* long option list */
static struct option long_options[] =
{
  { "file",            1, NULL, 'f' },  /* config file name */
  { "help",            0, NULL, 'h' },  /* show help */
  { "force-msswitch",  1, NULL, 'm' },  /* force m/s switch as server */
  { "name",            1, NULL, 'n' },  /* set BT friendly name */
  { "wrscan-enable",   1, NULL, 'w' },  /* sets write scan enable */
  { "max-connections", 1, NULL, 'c' },  /* sets max simultatious connections */
  { 0, 0, 0, 0 }
};

/****************** FUNCTION DEFINITION SECTION *****************************/

void
show_usage(void)
{
  printf("Syntax: btconfig [--force-msswitch (0|1)] [--wrscan-enable <mode>] [--name <name>] [--file <config file>] [--max-connections (0-7)]\n");
}

int
main(int argc, char **argv)
{
  int bt_cfd, opt;
  int opt_write_scan_enable = -1;
  int opt_force_ms_switch = -1;
  int opt_max_connections = -1;
  
  char *opt_name = NULL;
  char *opt_config_file = CONF_FILE;

  /* Parse command line options */

  while ((opt = getopt_long(argc, argv, "f:hm:n:w:c:",
			    long_options, &option_index)) != -1)
  {
    switch (opt)
    {
     case 'f':
      opt_config_file = optarg;
      break;

     case 'h':
      show_usage();
      exit(0);

     case 'm':
      /* Force a master/slave switch as server */
      opt_force_ms_switch = atoi(optarg);
      break;

     case 'n':
      /* Set BT friendly name */
      opt_name = optarg;
      break;
      
     case 'w':
      /* Set write scan enable */
      opt_write_scan_enable = atoi(optarg);
      break;

     case 'c':
      /* Set max connections */
      opt_max_connections = atoi(optarg);
      break;
      
     default:
      break;
    }
  }

  parse_file(opt_config_file);

  /* Command line arguments override the configuration file */

  if (opt_name)
  {
    strncpy(bt_name, opt_name, MAX_BTNAME_LEN);
    bt_name[MAX_BTNAME_LEN] = 0;
    var_set_local_name = 1;
  }
  
  if (opt_write_scan_enable >= 0)
    var_write_scan_enable = opt_write_scan_enable;

  if (opt_force_ms_switch >= 0)
    var_force_ms_switch = opt_force_ms_switch;

  if (opt_max_connections >= 0)
    var_max_connections = opt_max_connections;
  
  /* Configure the stack according to the options specified */

  if (var_set_local_name ||
      var_write_scan_enable >= 0 ||
      var_force_ms_switch >= 0 ||
      var_max_connections >= 0 ||
      var_max_power != SHRT_MAX)
  {
    /* Open BT ctrl device */  
    if ((bt_cfd = bt_openctrl()) < 0)
    {
      perror("Could not open BT control device");
      exit(1);
    }

    /* Wait until stack is initiated */
    while (!bt_isinitiated(bt_cfd))
      sleep(1);

    /* Configure BT local name */
    if (var_set_local_name)
      bt_set_local_name(bt_cfd, bt_name);

    /* Configure Write Scan Enable */
    if (var_write_scan_enable >= 0)
      bt_write_scan_enable(bt_cfd, var_write_scan_enable);

    /* Configure Force M/S switch */
    if (var_force_ms_switch >= 0)
      bt_force_msswitch_as_server(bt_cfd, var_force_ms_switch);

    /* Configure Max BT connections */
    if (var_max_connections >= 0)
      bt_set_max_conections(bt_cfd, var_max_connections);

    if (var_max_power != SHRT_MAX)
      bt_set_max_power(bt_cfd, var_max_power);
    
    close(bt_cfd);
  }

  exit(0);
}

/**************************************************************************/
/* 
 *  File parsing functions 
 */ 

int parse_file(char *filename)
{
  FILE *f;
  char buf[BUF_MAXSIZE];
  
  if (!(f = fopen(filename, "r")))
  {
    return TRUE;
  }

  D(syslog(LOG_INFO, __FUNCTION__": Opened config file '%s'", filename));

  while (fgets(buf, BUF_MAXSIZE, f))
  {
    char *field;
    char *value;

    if (parse_line(buf, &field, &value))
    {
      if (!configure_field(field, value))
      {
        fclose(f);
        return FALSE;
      }
    }
  }

  fclose(f);

  /* Name handling */
  if (*ip_addr || *ip_name)
  {
    strcpy(ip_addrname, " (");
    strcat(ip_addrname, ip_addr);
    if (*ip_name)
    {
      if (*ip_addr) {
        strcat(ip_addrname, ", ");
      }
      strcat(ip_addrname, ip_name);
    }
    strcat(ip_addrname, ")");

    if ((strlen(bt_name) + strlen(ip_addrname)) > MAX_BTNAME_LEN)
    {
      D(syslog(LOG_INFO, __FUNCTION__": Name to long, truncating"));
      strcpy(bt_name + MAX_BTNAME_LEN - strlen(ip_addrname), ip_addrname);
    }
    else
    {
      strcat(bt_name, ip_addrname);
    }
  }

  D(syslog(LOG_INFO, __FUNCTION__": Final name is (%d): %s\n",
           strlen(bt_name), bt_name));

  return TRUE;
} /* parse_file */


int
parse_line(char* line, char** field, char** value)
{
  int is_quoted;

  for (; isspace(*line); line++)
  {
  }

  if (*line == '#')
  {
    return FALSE;
  }
    
  if (!(line = strpbrk(line, " \t")))
  {
    return FALSE;
  }

  for (; isspace(*line); line++)
  {
  }

  *field = line;

  if (!(line = strpbrk(line, " \t\r\n")))
  {
    return FALSE;
  }

  *line++ = '\0';

  for (; isspace(*line); line++)
  {
  }

  is_quoted = FALSE;
  if (*line == '"')
  {
    line++;
    is_quoted = TRUE;
  }

  *value = line;
  
  line += strlen(line);
  while (line > *value && (!*line || isspace(*line)))
  {
    *line-- = '\0';
  }

  if (is_quoted)
  {
    if (*line == '"')
    {
      *line = '\0';
      is_quoted = TRUE;
    }
    else
    {
      return FALSE;
    }
  }

  return TRUE;
} /* parse_line */

int
configure_field(const char* field, const char* value)
{
  if (!strcasecmp(field, "DeviceName"))
  {
    if (strlen(value) <= MAX_BTNAME_LEN)
    {
      strcpy(bt_name, value);
      D(syslog(LOG_INFO, __FUNCTION__": assigned %s to devicename", value));
    }
    else
    {
      strncpy(bt_name, value, MAX_BTNAME_LEN);
      bt_name[MAX_BTNAME_LEN] = 0;
      
      syslog(LOG_INFO, ": Name to long, truncating to (%d): %s",
             (int)strlen(bt_name), bt_name);
    }

    var_set_local_name = 1;
  }
  else if (!strcasecmp(field, "AddIP"))
  {
    var_add_ip = !strcasecmp(value, "yes");

    if (var_add_ip == TRUE)
    {
      D(syslog(LOG_INFO, __FUNCTION__": add IP address"));
      while (1)
      {
        strcpy(ip_addr, get_local_ip_address());
        if (strncmp(ip_addr, "0.0.0.0", 7) == 0)
          sleep(1);
        else
          break;
      } 
    }
    else
    {
      D(syslog(LOG_INFO, __FUNCTION__": Don't add IP to Bluetooth Device Name"));
      *ip_addr = 0;
    }
  }
  else if (!strcasecmp(field, "AddHostName"))
  {
    var_add_host_name = !strcasecmp(value, "yes");

    if (var_add_host_name == TRUE)
    {
      char tmp_str[DOMAIN_NAME_LENGTH];

      D(syslog(LOG_INFO, __FUNCTION__": Add hostname and domain name"));
      
      gethostname(ip_name, HOST_NAME_LENGTH);
      
      if (!strchr(ip_name, '.'))
      {
        getdomainname(tmp_str, DOMAIN_NAME_LENGTH);
        if (*tmp_str)
        {
          strcat(ip_name, ".");
          strcat(ip_name, tmp_str);
        }
      }
    }
    else
    {
      D(syslog(LOG_INFO, __FUNCTION__": Don't add hostname and domain name"));
    }
  }
  else if (!strcasecmp(field, "ForceMSSwitch"))
  {
    var_force_ms_switch = !strcasecmp(value, "yes");
    D(syslog(LOG_INFO, __FUNCTION__ ": Force M/S switch: %s",
	     (var_force_ms_switch ? "yes" : "no")));
  }
  else if (!strcasecmp(field, "MaxBTConnections"))
  { 
    var_max_connections = atoi(value);
    D(syslog(LOG_INFO, __FUNCTION__ ": Maximum BT connections: %s", value));
  }
  else if (!strcasecmp(field, "MaxTransmitPower"))
  { 
    var_max_power = atoi(value);
    D(syslog(LOG_INFO, __FUNCTION__ ": Maximum transmit power: %s", value));
  }
  
  return TRUE;
} /* configure_field */

/****************** END OF FILE btconfig.c **********************************/
