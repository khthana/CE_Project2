
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <getopt.h>

#include "btd.h"
#include "bt_if.h"
#include "bt_conf.h"

/* 
 * Syntax: btinq -n <max # returned> -t <max inq time> 
 */

int
main(int argc, char **argv)
{ 
  int bt_cfd, opt, t = 10, nbr = 10;

  while ((opt = getopt(argc, argv, "n:t:")) != -1)
  {
    switch(opt)
    {
     case 'n':
      nbr = atoi(optarg);
      break;
      
     case 't':
      t = atoi(optarg);
      break;

     default:
      break;
    }
  }

  /* Open BT ctrl device */  
  if ((bt_cfd = bt_openctrl()) < 0)
  {
    perror("Could not open BT control device");
    exit(1);
  }

  /* First of all check that stack is running */
  if (!bt_isinitiated(bt_cfd))
  {
    printf("Stack not initiated, exit\n");
    exit(1);
  }

  bt_inquiry(bt_cfd, nbr, t);
 
  close(bt_cfd);
  exit(0);
}
