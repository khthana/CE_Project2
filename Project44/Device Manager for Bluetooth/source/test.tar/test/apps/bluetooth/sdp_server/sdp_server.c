
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>

#include "xmlparse.h"
#include "sdp_server.h"
#include "sdp_parser.h"

#ifdef BTD_USERSTACK
#define syslog(x, fmt...) do { fprintf(stderr, __FILE__ "::"); fprintf(stderr, fmt); fprintf(stderr, "\n"); } while (0)
#endif

/* Does printouts in all functions called by expat */
#define SDP_DEBUG_SUBFNC 0

/* Does debug printouts in functions related to incomming data from the sdp
   parts in the kernel */
#define SDP_DEBUG_INCOMING 0

/* Other misc functions such as get_values, char2hex etc */
#define SDP_DEBUG_MISC 0

/* Debug for the get attribute functions */
#define SDP_DEBUG_GET_ATTRIBUTES 0

/* Debug for the get record handle functions */
#define SDP_DEBUG_GET_RECORD_HDL 0

/* Debug all malloc and free commands */
#define SDP_DEBUG_MEM 0

/* Printouts data in hex format */
#define SDP_DEBUG_PRINT_DATA 0

#if SDP_DEBUG_SUBFNC
#define S_FNC(fmt...) syslog(LOG_INFO, __FUNCTION__ ": " fmt)
#else
#define S_FNC(fmt...)
#endif

#if SDP_DEBUG_INCOMING
#define D_REC(fmt...) syslog(LOG_INFO, __FUNCTION__ ": " fmt)
#else
#define D_REC(fmt...)
#endif

#if SDP_DEBUG_MISC
#define D_MISC(fmt...) syslog(LOG_INFO, __FUNCTION__ ": " fmt)
#else
#define D_MISC(fmt...)
#endif

#if SDP_DEBUG_GET_ATTRIBUTES
#define D_ATTR(fmt...) syslog(LOG_INFO, __FUNCTION__ ": " fmt)
#else
#define D_ATTR(fmt...)
#endif

#if SDP_DEBUG_GET_RECORD_HDL
#define D_RHDL(fmt...) syslog(LOG_INFO, __FUNCTION__ ": " fmt)
#else
#define D_RHDL(fmt...)
#endif

#if SDP_DEBUG_MEM
#define D_MEM(fmt...) syslog(LOG_INFO, __FUNCTION__ ": " fmt)
#else
#define D_MEM(fmt...)
#endif

#if SDP_DEBUG_PRINT_DATA
#define PRINT_DATA(str, data, len) print_data(str, data, len)
#else
#define PRINT_DATA(str, data, len)
#endif

void start_xml_parser(XML_Parser p, int fd);
void char2hex(const char *char_data, unsigned char* buf);
char* get_values(char *value_string, int value_string_len, int fd);
void set_sdp_hdr(unsigned char *hdr, unsigned char pkt_type,
                 unsigned short trans_id, unsigned short len);

unsigned int* remove_duplicated_rec_hdl(unsigned int *rec_hdl_list_in,
					unsigned int cnt_in);
unsigned int* get_all_rec_hdl(unsigned int *service_class_list,
			      unsigned int service_class_cnt);
unsigned int get_record_handle(unsigned short service_class, int fd);

char* get_attribute_range(int fd, unsigned int record_handle,
                          unsigned int attr_id_code);
char* get_attribute_list(int fd, unsigned int record_handle,
                         unsigned short attr_id_code);
void get_attribute_list_start(void *data, const char *el, const char **attr);
void get_attribute_list_end(void *data, const char *el);
void get_attribute_char_data(void *userData,const XML_Char *s, int len);

char* get_from_xml(int fd, char *tag, char *attr, unsigned char *val);
void get_start(void *data, const char *el, const char **attr);
void get_end(void *data, const char *el);

int* get_all_attributes(int fd);
void get_all_start(void *data, const char *el, const char **attr);
void get_all_end(void *data, const char *el);

void handle_query(database_query_struct *db_hdl);
void handle_service_search_req(service_search_struct *db_hdl);  
void handle_service_attr_req(service_attr_struct *db_hdl);
void handle_service_search_attr_req(service_search_attr_struct *db_hdl);

int set_cont_state_attr(unsigned char *pkt, int len, int max_attr_len);

int set_cont_state_search(unsigned char *pkt, unsigned int len, unsigned int max_rec_cnt);

static int xml_fd;
static int parse_err;

extern int malloc_dbg;

/* pointers to contionuationstate data */
extern cont_state_struct *cont_state_buf;

void
print_data(const char *message, const unsigned char *buf, int len)
{ 
  int t, offs = 0;
  char tmp[100];

  syslog(LOG_INFO, "%s (%d):", message, len);

  for (t = 0; t < len; t++) 
  {
    offs += sprintf(tmp + offs, " 0x%02x", (unsigned int)buf[t]);
    if (!((t+1) % 8))
    {
      syslog(LOG_INFO, tmp);
      offs = 0;
    }
  }

  if (offs)
  {
    syslog(LOG_INFO, tmp);
  }
}

void
init_sdp_server(int fd)
{
  xml_fd = fd;
}

void
set_err(int err)
{
  parse_err = err;
}

int
get_err(void)
{
  int tmp = parse_err;

  parse_err = 0;
  return tmp;
}

int
is_err(void)
{
  return parse_err != 0;
}

void
start_xml_parser(XML_Parser p, int fd)
{
  void *buf;
  int len;

  lseek(fd, 0, SEEK_SET);
      
  do
  {
    buf = XML_GetBuffer(p, BUFFSIZE);
    if (buf == NULL)
    {
      syslog(LOG_ERR, "start_xml_parser: couldn't get a free buffer");
      break;
    }

    len = read(fd, buf, BUFFSIZE);
  
    if (len < 0)
    {
      fprintf(stderr, "start_xml_parser: error when reading xml file\n");
      break;
    }

    if (!XML_ParseBuffer(p, len, len == 0))
    {
      fprintf(stderr, "Parse error at line %d, col %d:\n%s\n",
              XML_GetCurrentLineNumber(p),
              XML_GetCurrentColumnNumber(p),
              XML_ErrorString(XML_GetErrorCode(p)));
      fprintf(stderr, "len: %d\n", len);
      break;
    }

    if (is_err())
    {
      break;
    }
  } while (len);
}

void
char2hex(const char *char_data, unsigned char* buf)
{
  int i;
  int tmp;

  /* FIXME, How will this work when using big endian ? */
  for (i = 0; i < strlen(char_data) / 2; i++)
  {
    sscanf(char_data + i * 2, "%02x", &tmp);
    buf[i] = (unsigned char)(tmp & 0xff);
  }
}

char*
get_values(char *value_string, int value_string_len, int fd)
{
  int value_string_pos = 0;
  static char tmp_list[256];
  char tmp_len = 0;
  char *des_pos[DES_HDR_DEPTH]; /* des stands for Data Element Sequence */
  int des_len[DES_HDR_DEPTH];
  char c_des_len[3][DES_HDR_DEPTH];
  int i;

  D_MISC(__FUNCTION__" value_string _%s_, valstrlen:%d\n", 
         value_string, value_string_len);

  i = 0;
  while (i < value_string_len)
  {
    D_MISC("%s", value_string + i);
    i += strlen(value_string + i) + 1;
  }

  for (i = 0; i < DES_HDR_DEPTH; i++)
  {
    des_pos[i] = NULL;
  }

  /* While we have not reached the end of the string */
  while (value_string_pos < value_string_len)
  {
    /* If we found a hex value instead of a string */
    if (strncmp(value_string + value_string_pos, "0x", 2) == 0)
    {
      D_MISC("Found HEX val\n");

      strcpy(tmp_list + tmp_len, value_string + value_string_pos + 2);
      tmp_len += strlen(value_string + value_string_pos) - 2;

      /* If we found a data element sequence header we need to remember that
         position so we can fill in the length field later */      
      if (strncmp(value_string + value_string_pos, S_DES_HDR, strlen(S_DES_HDR)) == 0)
      {
        unsigned int pos;
        unsigned int j;

        pos = strtoul(value_string + value_string_pos + strlen(S_DES_HDR),
                      NULL, 16);

        /* Now we found a data element sequence header inside another
           data element sequence */

        if (des_pos[pos])
        {
          sprintf(c_des_len[pos], "%02x", des_len[pos]);
          D_MISC("c_des_len[%d]: %s", pos, c_des_len[pos]);
          strncpy(des_pos[pos], c_des_len[pos], 2);
          D_MISC("des_pos[%d]: %s", pos, des_pos[pos]);
        }

        des_pos[pos] = tmp_list + tmp_len - 2;
        des_len[pos] = 0;

        for (j = pos; j > 0; j--)
        {
          des_len[0] += (strlen(value_string + value_string_pos) - 2) / 2;
        }
      }
      else
      {
        des_len[1] += (strlen(value_string + value_string_pos) - 2) / 2;
        des_len[0] += (strlen(value_string + value_string_pos) - 2) / 2;
      }
    }
    else /* Here we found a string, and have to find the hex value for it
            in the database */
    {
      char *tmp_code;

      D_MISC("Searching xml file : TAG SDPTranslationRegister\n");
      D_MISC("String : _%s_\n", value_string+value_string_pos);
      
      /* Get the hex code for the attribute from the xml file */
      tmp_code = get_from_xml(fd, "SDPTranslationRegister",
                              value_string + value_string_pos, NULL);
      
      if (tmp_code == NULL)
      {
        D_MISC("Didn't find the hex code for: %s",
               value_string + value_string_pos);
      }
      else
      {
        int tmp;

        /* Copy the hex value to the temporary attribute list and increas the
           counters */
        strcpy(tmp_list + tmp_len, tmp_code);
        tmp = strlen(tmp_code);
        tmp_len += tmp;
        des_len[1] += tmp / 2;
        des_len[0] += tmp / 2;

        D_MISC("des_len[1]: %d", des_len[1]);
        D_MISC("Found %s", tmp_code);

        /* since get_from_xml allocates space for the reurn paramterer we
           have to do free here */
        D_MEM("<--- free%d 0x%8p", --malloc_dbg, tmp_code);
        free(tmp_code);
      }
    }
    value_string_pos += strlen(value_string + value_string_pos) + 1;
  }
  for (i = 0; i < DES_HDR_DEPTH; i++)
  {
    if (des_pos[i])
    {
      /* Convert the data element sequence length to charactes and copy it
         into the attribute list */
      sprintf(c_des_len[i], "%02x", des_len[i]);
      strncpy(des_pos[i], c_des_len[i], 2);

      D_MISC("%s", des_pos[i]);
      D_MISC("c_des_len[%d]: %s",i, c_des_len[i]);
    }
  }

  D_MISC("return_list %s", tmp_list);

  return tmp_list;
}

void set_sdp_hdr(unsigned char *hdr, unsigned char pkt_type,
                 unsigned short trans_id, unsigned short len)
{
  hdr[SDP_HDR_TYPE]        = pkt_type;
  hdr[SDP_HDR_TRANS_ID_MS] = SHORT2CHAR_MS(trans_id);
  hdr[SDP_HDR_TRANS_ID_LS] = SHORT2CHAR_LS(trans_id);
  hdr[SDP_HDR_LENGTH_MS]   = SHORT2CHAR_MS(len);
  hdr[SDP_HDR_LENGTH_LS]   = SHORT2CHAR_LS(len);
}

unsigned int*
remove_duplicated_rec_hdl(unsigned int *rec_hdl_list_in, unsigned int cnt_in)  
{
    static unsigned int rec_hdl_list_out[128];
    unsigned int i, j, cnt_out = 0;
    unsigned int existing = FALSE;
    
    for (i = 0; i < cnt_in; i++)
    {
      for (j = 0; j < cnt_out; j++)
      {
	if (rec_hdl_list_in[i] == rec_hdl_list_out[j])
	{
	  existing = TRUE;
	}
      }
      
      if(!existing)
      {
	rec_hdl_list_out[cnt_out] = rec_hdl_list_in[i];
	D_RHDL(__FUNCTION__": |||�Keeping record_handle 0x%08x |||", rec_hdl_list_out[cnt_out]);
	cnt_out++;
      }
      existing = FALSE;
    }

    rec_hdl_list_out[cnt_out] = NO_REC_HDL;

    return rec_hdl_list_out;
}

unsigned int*
get_all_rec_hdl(unsigned int *service_class_list, unsigned int service_class_cnt)
{
  unsigned int rec_hdl_list[64];
  unsigned int *tmp_hdl_list;
  unsigned int rec_hdl_cnt = 0;
  int i, j;
  
  D_RHDL(__FUNCTION__": Searching for %d UUID:s...", service_class_cnt);

  for (i = 0; i < service_class_cnt; i++)
  {
    D_RHDL(__FUNCTION__": Now search for UUID : 0x%08x", service_class_list[i]);
    if ((rec_hdl_list[rec_hdl_cnt] = get_record_handle(service_class_list[i], xml_fd)) != NO_REC_HDL)
    {
      D_REC("Found record handle : 0x%08x", rec_hdl_list[rec_hdl_cnt]);
      rec_hdl_cnt++;
    }

    tmp_hdl_list = get_more_rec_hdl(service_class_list[i], xml_fd);

    if (is_err())
    {
      D_MEM("<--- free%d 0x%8p", --malloc_dbg, tmp_hdl_list);
      free(tmp_hdl_list);
      return NULL;
    }

    if (tmp_hdl_list)
    {
      j = 0;
      while (tmp_hdl_list[j] != NO_REC_HDL)
      {
	rec_hdl_list[rec_hdl_cnt] = tmp_hdl_list[j];
	D_REC("Found record handle : 0x%08x", rec_hdl_list[rec_hdl_cnt]);
	rec_hdl_cnt++;
	j++;
      }

      D_RHDL("Found %d record handles using get_more_rec_hdl\n", j);
      
      D_MEM("<--- free%d 0x%8p", --malloc_dbg, tmp_hdl_list);
      free(tmp_hdl_list);
    }
    
  }
 
  D_RHDL("Now __remove__ duplicated entries ?!?!?\n");
 
  tmp_hdl_list = remove_duplicated_rec_hdl(rec_hdl_list, rec_hdl_cnt);
 
  return tmp_hdl_list;
}


/* 
 * Searches for "ServiceClasses" entries in database 
 */
unsigned int
get_record_handle(unsigned short service_class, int fd)
{
  int record_handle = NO_REC_HDL;
  char *service_class_name = NULL;
  char *service_class_id = NULL;
  char tmp[12];

  D_RHDL("Looking for service class %0x\n", service_class);

  /* Before we can get the recordhandle we have to find the name of the
     service class, so we can search for it in the database. When we search
     the service class id, have to be converted to characters. All service
     classes are stored as 16 bits UUIDs*/

  /* Search for UUID as a string among ServiceClasses TAG */
  sprintf(tmp, "0x%04x", service_class);
  service_class_name = get_from_xml(fd, "ServiceClasses", NULL, tmp);

  /* If we didn't find the service class we return here */
  if (service_class_name == NULL)
  {
    D_RHDL("Didn't find ServiceClass name for uuid 0x%04x", service_class);
    return NO_REC_HDL;
  }

  D_RHDL("Found service class name %s\n", service_class_name);

  /* We found service class name, now search for record handle */
  service_class_id = get_from_xml(fd, service_class_name,
                                  "ServiceRecordHandle", NULL);

  D_MEM("<--- free%d 0x%8p", --malloc_dbg, service_class_name);
  free(service_class_name);
  
  /* If we found the record handle we convert it to an unsigned int */
  if (service_class_id != NULL)
  {
    D_RHDL("Found service_class_id : 0x%x\n", service_class_id);
    record_handle = strtoul(service_class_id, NULL, 16);
    D_RHDL("Service class id conv to rec hdl 0x%08x", record_handle);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, service_class_id);
    free(service_class_id);
  }

  return record_handle;
}

void
get_more_rec_hdl_start(void *data, const char *el, const char **attr)
{
  unsigned int *tmp;
  rec_hdl_search_struct *s_hdl = (rec_hdl_search_struct*) data;

  if (attr[0] && strcmp(attr[0], "ServiceRecordHandle") == 0)
  {
    S_FNC("Found Record Handle %s", attr[1]);
    s_hdl->tmp_hdl = strtoul(attr[1], NULL, 16);
    S_FNC("Found Record Handle converted to int 0x%08x", s_hdl->tmp_hdl);
  }
  if ((s_hdl->tmp_hdl != NO_REC_HDL) && (strcmp(el, s_hdl->uuid) == 0))
  {
    if ((s_hdl->hdl_list_len > 0) &&
        (s_hdl->tmp_hdl == s_hdl->hdl_list[s_hdl->hdl_list_len - 1]))
    {
      S_FNC("%s is present in record handle 0x%08x, but already found",
            s_hdl->uuid, s_hdl->tmp_hdl);
    }
    else
    {
      S_FNC("%s is present in record handle 0x%08x",
            s_hdl->uuid, s_hdl->tmp_hdl);

      /* Store the poiter to the allready found record handles, and then if
         necessary allocate new space for both the old and the new record
         handles */

      if (s_hdl->hdl_list_len >= s_hdl->hdl_list_max)
      {
        s_hdl->hdl_list_max += 16;
        tmp = realloc(s_hdl->hdl_list, s_hdl->hdl_list_max * sizeof(*s_hdl->hdl_list));
        D_MEM("---> realloc%d %ld bytes at 0x%8p", malloc_dbg++, s_hdl->hdl_list_max * sizeof(*s_hdl->hdl_list), tmp);
        if (!tmp)
        {
          set_err(SDP_INSUFFICIENT_RESOURCES);
          s_hdl->hdl_list_max -= 16;
          return;
        }

        s_hdl->hdl_list = tmp;
      }
    
      s_hdl->hdl_list[s_hdl->hdl_list_len] = s_hdl->tmp_hdl;
      s_hdl->hdl_list_len++;
    }
  }
}

void
get_more_rec_hdl_end(void *data, const char *el)
{
}

/* 
 * Searches for Attributes in database 
 */
unsigned int*
get_more_rec_hdl(unsigned short service_class, int fd)
{
  rec_hdl_search_struct s_hdl;
  char tmp_ch[12];
  unsigned int *tmp;
  
  XML_Parser p;

  sprintf(tmp_ch, "0x%04x", service_class);

  /* Search for UUID among "Protocols" TAG */

  s_hdl.uuid = get_from_xml(fd, "Protocols", NULL, tmp_ch); 

  /* If we didn't find the service class among the protocols we look for it
     among the ServiceClasses */
  if (s_hdl.uuid == NULL)
  {
    D_RHDL("Didn't find Protocol name for uuid 0x%04x among the protocols",
           service_class);
    s_hdl.uuid = get_from_xml(fd, "ServiceClasses", NULL, tmp_ch); 

    /* If we still didn't find the sevice class, we return NULL */
    if (s_hdl.uuid == NULL)
    {
      D_RHDL("Didn't find Protocol name for uuid 0x%04x", service_class);
      return NULL;
    }
  }

  s_hdl.hdl_list_len = 0;
  s_hdl.hdl_list_max = 16;
  s_hdl.hdl_list = malloc(s_hdl.hdl_list_max * sizeof(*s_hdl.hdl_list));
  D_MEM("---> malloc%d %ld bytes at 0x%8p", malloc_dbg++, s_hdl.hdl_list_max * sizeof(*s_hdl.hdl_list), s_hdl.hdl_list);
  if (!s_hdl.hdl_list)
  {
    set_err(SDP_INSUFFICIENT_RESOURCES);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, s_hdl.uuid);
    free(s_hdl.uuid);
    return NULL;
  }

  p = XML_ParserCreate(NULL);
  XML_SetElementHandler(p, get_more_rec_hdl_start, get_more_rec_hdl_end);
  
  XML_SetUserData(p, (void*)&s_hdl);
    
  start_xml_parser(p, fd);
  XML_ParserFree(p);

  D_MEM("<--- free%d 0x%8p", --malloc_dbg, s_hdl.uuid);
  free(s_hdl.uuid);

  if (is_err())
  {
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, s_hdl.hdl_list);
    free(s_hdl.hdl_list);
    return NULL;
  }

  if (s_hdl.hdl_list_len >= s_hdl.hdl_list_max)
  {
    s_hdl.hdl_list_max++;

    tmp = realloc(s_hdl.hdl_list, s_hdl.hdl_list_max * sizeof(*s_hdl.hdl_list));
    D_MEM("---> realloc%d %ld bytes at 0x%8p", malloc_dbg++, s_hdl.hdl_list_max * sizeof(*s_hdl.hdl_list), tmp);
    if (!tmp)
    {
      set_err(SDP_INSUFFICIENT_RESOURCES);
      D_MEM("<--- free%d 0x%8p", --malloc_dbg, s_hdl.hdl_list);
      free(s_hdl.hdl_list);
      return NULL;
    }

    s_hdl.hdl_list = tmp;
  }

  s_hdl.hdl_list[s_hdl.hdl_list_len] = NO_REC_HDL;

  return s_hdl.hdl_list;
}

char*
get_attribute_range(int fd, unsigned int record_handle,
                    unsigned int attr_id_code)
{
  int *attr_lst, i = 1, pos = 0;
  char *tmp_ptr;
  char *return_sequence;

  /* FIXME: But for now 256 bytes will do */
  return_sequence = malloc(256);
  D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, 256, return_sequence);
  if (!return_sequence)
  {
    set_err(SDP_INSUFFICIENT_RESOURCES);
    return NULL;
  }

  D_ATTR("A range of attributes was requested 0x%04x - 0x%04x",
         (attr_id_code >> 16), (attr_id_code & 0xffff));

  /* Lists all attributes registerd in the database */
  attr_lst = get_all_attributes(fd);

  if (!attr_lst)
  {
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, return_sequence);
    free(return_sequence);
    return NULL;
  }
  
  return_sequence[pos++] = DES_HDR;
  return_sequence[pos++] = 0;
  
  /* Find the first attribute in the range */
  while ((i < attr_lst[0]) && (attr_lst[i] < (attr_id_code >> 16)))
  {
    i++;
  }
  D_ATTR("attr_lst[0]: %d, attr_id_code: 0x%04x",
         attr_lst[0], attr_id_code);
  
  while ((i < attr_lst[0]) && (attr_lst[i] <= (attr_id_code & 0xffff)))
  {
    D_REC("attr_lst[%d]: 0x%04x", i, attr_lst[i]);
    /* we mask the attribute her so we don't by misstake send a range as
       input */
    tmp_ptr = get_attribute_list(fd, record_handle, attr_lst[i] & 0xffff);

    if (tmp_ptr)
    {
      memcpy(return_sequence + pos, tmp_ptr + 2, tmp_ptr[1]);
      pos += tmp_ptr[1];
      D_MEM("<--- free%d 0x%8p", --malloc_dbg, tmp_ptr);
      free(tmp_ptr);
    }
    else if (is_err())
    {
      D_MEM("<--- free%d 0x%8p", --malloc_dbg, return_sequence);
      free(return_sequence);
      return NULL;
    }
    i++;
  }
  
  return_sequence[1] = pos - 2;
  D_MEM("<--- free%d 0x%8p", --malloc_dbg, attr_lst);
  free(attr_lst);

  PRINT_DATA(__FUNCTION__ ": return_sequence", return_sequence, return_sequence[1] + 2);
  
  if (return_sequence[1] == 0)
  {
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, return_sequence);
    free(return_sequence);
    return NULL;
  }
  else
  {
    return return_sequence;
  }
}

void init_attribute_search_struct(sdp_attribute_search *search_struct)
{
  int i;

  for (i = 0; i < 2; i++)
  {
    search_struct->des_len_pos[i] = 0;
    search_struct->des_len[i] = 0;
    search_struct->set_des_len[i] = 0;
  }

  search_struct->service_class_found = 0;
  search_struct->attribute_name_found = 0;
  search_struct->attr2get = 0;
  search_struct->attrlist_index = 0;
}

char*
get_attribute_list(int fd, unsigned int record_handle,
                   unsigned short attr_id_code)
{
#define SEQ_LEN 256

  XML_Parser p;
  char *return_sequence = NULL;
  char *char_tmp = NULL;
  char tmp[12];
  int len;
  sdp_attribute_search search_struct;

  init_attribute_search_struct(&search_struct);
  
  D_ATTR("Searching for attribute 0x%04x for record handle 0x%08x",
         attr_id_code, record_handle);
  
  search_struct.attribute_id = attr_id_code;
  sprintf(tmp, "0x%04x", attr_id_code);
  search_struct.attribute_name = get_from_xml(fd, "AttributeIdentifierCodes", NULL, tmp); 

  if (search_struct.attribute_name == NULL)
  {
    fprintf(stderr, __FUNCTION__ ": Didn't find service attribute id name for uuid 0x%04x\n", attr_id_code);
    return NULL;
  }
  
  D_ATTR("Found %s", search_struct.attribute_name);

  sprintf(tmp, "0x%08x", record_handle);
  search_struct.service_class = get_from_xml(fd, NULL, "ServiceRecordHandle", tmp);
  
  if (search_struct.service_class == NULL)
  {
    fprintf(stderr, __FUNCTION__ ": Didn't find service class name for RecordHandle 0x%08x\n", record_handle);

    set_err(SDP_INVALID_SERVICE_RECORD_HANDLE);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.attribute_name);
    free(search_struct.attribute_name);
    return NULL;
  }
  
  D_ATTR("Found %s", search_struct.service_class);

  p = XML_ParserCreate(NULL);
  XML_SetElementHandler(p, get_attribute_list_start, get_attribute_list_end);
  
  XML_SetUserData(p, (void*)&search_struct);
  XML_SetCharacterDataHandler(p, get_attribute_char_data);
  
  start_xml_parser(p, fd);
  XML_ParserFree(p);

  if (is_err())
  {
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.attribute_name);
    free(search_struct.attribute_name);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.service_class);
    free(search_struct.service_class);

    return NULL;
  }

  if (search_struct.attrlist_index == 0)
  {
    D_ATTR("Didn't find the attribute values for the attribute %s",
           search_struct.attribute_name);

    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.attribute_name);
    free(search_struct.attribute_name);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.service_class);
    free(search_struct.service_class);

    return NULL;
  }
  
  char_tmp = get_values(search_struct.attrlist, search_struct.attrlist_index, fd);
  len = strlen(char_tmp) / 2;

  return_sequence = malloc(len + 2);
  D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, len + 2, return_sequence);
  if (!return_sequence)
  {
    set_err(SDP_INSUFFICIENT_RESOURCES);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.attribute_name);
    free(search_struct.attribute_name);
    D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.service_class);
    free(search_struct.service_class);

    return NULL;
  }
  
  return_sequence[0] = 0x35;
  return_sequence[1] = len;
  char2hex(char_tmp, return_sequence + 2);

  D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.attribute_name);
  free(search_struct.attribute_name);
  D_MEM("<--- free%d 0x%8p", --malloc_dbg, search_struct.service_class);
  free(search_struct.service_class);

  PRINT_DATA(__FUNCTION__ ": return value", return_sequence, len + 2);

  return return_sequence;
}

void
get_attribute_list_start(void *data, const char *el, const char **attr)
{
  int i;
  sdp_attribute_search *search_struct;

  search_struct = (sdp_attribute_search*) data;

  /* If we find the service class we are looking for set the
     service_class_found parameter to TRUE */
  if (strcmp(el, search_struct->service_class) == 0)
  {
    S_FNC("Found service class %s", el);
    search_struct->service_class_found++;
  }
  if (search_struct->service_class_found)
  {
    /* If we find the attribute name, we set the attribute_name_found
       parameter to TRUE */
    if (strcmp(el, search_struct->attribute_name) == 0)
    {
      search_struct->attribute_name_found = 1;
      
      S_FNC("Found attribute name %s", el);

      /* We then inserts the attribute id code of the attribute type we have
         found */
      sprintf(search_struct->attrlist, "0x09%04x", search_struct->attribute_id);
      search_struct->attrlist_index = strlen(search_struct->attrlist) + 1;

      /* Then we browses through the attributes */
      for (i = 0; attr[i]; i += 2)
      {
        /* If there are a number of following entities, we have found a
           data element sequence */
        if (strcmp(attr[i], "NbrOfEntities") == 0)
        {
          search_struct->attr2get = atoi(attr[i + 1]);
          S_FNC("attr2get: %d", atoi(attr[i + 1]));
          /* Set the data element sequence header */
          strcpy(search_struct->attrlist + search_struct->attrlist_index, S_DES_HDR0);
          search_struct->attrlist_index += strlen(S_DES_HDR0) + 1;
        }
        /* Otherwise the wole attribute may be stored as a data element
           sequence */
        else if (attr[i] && attr[i + 1] && (strcmp(attr[i], "type") == 0) &&
                 (strcmp(attr[i + 1], "DES") == 0))
        {
          /* Set the data element sequence header */
          strcpy(search_struct->attrlist + search_struct->attrlist_index, S_DES_HDR1);
          search_struct->attrlist_index += strlen(S_DES_HDR0) + 1;
        }
        /* If we have found a parameter we just insert it into the list */
        else if (strncmp(attr[i], "Parameter", 9) == 0)
        {
          strcpy(search_struct->attrlist + search_struct->attrlist_index,
                 attr[i + 1]);
          search_struct->attrlist_index += strlen(attr[i + 1]) + 1;
        }
        else
        {
          fprintf(stderr, "Unexpected behavior in database when searching for attributes\n");
        }
      }
    }
    /* This is when we found a data element sequence, we here browses
       through all the attributes in the sequence and copies them into our
       list */
    else if (search_struct->attr2get > 0)
    {
      search_struct->attr2get--;

      if (attr[0] && attr[1] &&
          (strcmp(attr[0], "type") == 0) && (strcmp(attr[1], "DES") == 0))
      {
        /* Set the data element sequence header */
        strcpy(search_struct->attrlist + search_struct->attrlist_index, S_DES_HDR1);
        search_struct->attrlist_index += strlen(S_DES_HDR1) + 1;
      }
      /* Copy the first attribute */
      strcpy(search_struct->attrlist + search_struct->attrlist_index, el);
      search_struct->attrlist_index += strlen(el) + 1;
      
      /* Copy the rest of the attributes */
      for (i = 0; attr[i]; i += 2)
      {
        strcpy(search_struct->attrlist + search_struct->attrlist_index,
               attr[i + 1]);
        search_struct->attrlist_index += strlen(attr[i + 1]) + 1;
      }
      
      /* The length field in the data element sequence will be filled in, in
         the function get_values */
    }
  }
}


void
get_attribute_list_end(void *data, const char *el)
{
  sdp_attribute_search *search_hdl = (sdp_attribute_search*) data;
  int i;
  char tmp[3];
  
  /* If we found an end tag for the service class we decrease a counter so we
     can se whether it was the last end tag for the service class or not */
  if (strcmp(el, search_hdl->service_class) == 0)
  {
    S_FNC("Found %s", el);
    search_hdl->service_class_found--;
  }
  /* If we have found the attribute name end tag, there are no more attributes
     to find */
  else if ((strcmp(el, search_hdl->attribute_name) == 0) &&
           (search_hdl->service_class_found))
  {
    search_hdl->attribute_name_found = 0;
  }

  for (i = 0; i < 2; i++)
  {
    if (search_hdl->set_des_len[i])
    {
      sprintf(tmp, "%02x", search_hdl->des_len[i]);
      memcpy(search_hdl->attrlist + search_hdl->des_len_pos[i], tmp, 2);
      search_hdl->set_des_len[i] = 0;
    }
  }

}

void
get_attribute_char_data(void *userData, const XML_Char *s, int len)
{
  sdp_attribute_search *search_hdl = (sdp_attribute_search*) userData;
  int i = 0;

  if (len <= 0)
  {
    return;
  }

  while (i < len && !FIRST_VALID_CHAR(s[i]))
  {
    i++;
  }

  if (i == len)
  {
    return;
  }

  if ((search_hdl->service_class_found) && (search_hdl->attribute_name_found))
  {
    /* We set the length field of the string, now we set it to zero, since we
       will set it to its correct value later */
    sprintf(search_hdl->attrlist + search_hdl->attrlist_index, "0x25");
    search_hdl->attrlist_index += 4;

    /* Stor the length field so we can set the length afterwards */
    search_hdl->des_len_pos[0] = search_hdl->attrlist_index;
    search_hdl->attrlist_index += 2;

    search_hdl->des_len[0] = 0;
    search_hdl->set_des_len[0] = 1;

    for (i = 0; i < len; i++)
    {
      /* We stor the ascii value of each character in two bytes */
      sprintf(search_hdl->attrlist + search_hdl->attrlist_index,
              "%01x%01x" , s[i] / 16, s[i] % 16);
      search_hdl->attrlist_index += 2;
      search_hdl->des_len[0]++;
    }
    
    search_hdl->attrlist[search_hdl->attrlist_index++] = '\0';
  }
}

/* This function search the xml file for the one of tag, attr or val that is
   set to NULL. If more than one is set to NULL the result will be
   unpredicable */

char*
get_from_xml(int fd, char *tag, char *attr, unsigned char *val)
{
#define TAG 0
#define ATTR 1
#define VAL 2

  XML_Parser p;
  sdp_search_handler search_hdl;
  int set_value = -1;

  p = XML_ParserCreate(NULL);
  XML_SetElementHandler(p, get_start, get_end);
  XML_SetUserData(p, &search_hdl);
  
  search_hdl.search_name = tag;
  search_hdl.search_attr = attr;
  search_hdl.search_val = val;
  
  if (!tag)
  {
    S_FNC("Looking for tag");
    set_value = TAG;
  }

  if (!attr)
  {    
    if (set_value != -1)
    {
      fprintf(stderr, __FUNCTION__ ": Error more than one attribute == NULL\n");
      return NULL;
    }

    S_FNC("Looking for attribute");
    set_value = ATTR;
  }
  
  if (!val)
  {
    if (set_value != -1)
    {
      fprintf(stderr, __FUNCTION__ ": Error more than one attribute == NULL\n");
      return NULL;
    }

    S_FNC("Looking for value");
    set_value = VAL;
  }
  
  start_xml_parser(p, fd);
  XML_ParserFree(p);
  
  switch (set_value)
  {
  case TAG:
    return search_hdl.search_name;

  case ATTR:
    return search_hdl.search_attr;

  case VAL:
    return search_hdl.search_val;

  default:
    return NULL;
  }
  
#undef TAG
#undef ATTR
#undef VAl
}


void
get_start(void *data, const char *el, const char **attr)
{
  int i, m_size;

  sdp_search_handler *search_hdl = data;

  if (search_hdl->search_attr == NULL)
  {
    if (strcmp(el, search_hdl->search_name) == 0)
    {
      S_FNC("Found %s", el);
      for (i = 0; attr[i]; i += 2)
      {
        if (strcmp(attr[i + 1], search_hdl->search_val) == 0)
        {
          S_FNC("Found %s", attr[i]);
          m_size = strlen(attr[i]) + 1;
          search_hdl->search_attr = malloc(m_size);
          D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, m_size, search_hdl->search_attr);
          if (search_hdl->search_attr)
          {
            strcpy(search_hdl->search_attr, attr[i]);
          }
          return;
        }
      }
    }    
  }
  else if (search_hdl->search_val == NULL)
  {
    if (strcmp(el, search_hdl->search_name) == 0)
    {
      S_FNC("Found %s", el);
      for (i = 0; attr[i]; i += 2)
      {
        if (strcmp(attr[i], search_hdl->search_attr) == 0)
        {
          S_FNC("Found %s", attr[i + 1]);
          m_size = strlen(attr[i + 1]) + 1;
          search_hdl->search_val = malloc(m_size);
          D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, m_size, search_hdl->search_val);
          if (search_hdl->search_val)
          {
            strcpy(search_hdl->search_val, attr[i + 1]);
          }
          return;
        }
      }
    } 
  }
  else if (search_hdl->search_name == NULL)
  {
    for (i = 0; attr[i]; i += 2)
    {
      if ((strcmp(search_hdl->search_attr, attr[i]) == 0) &&
          (strcmp(search_hdl->search_val, attr[i + 1]) == 0))
      {
        m_size = strlen(el) + 1;
        search_hdl->search_name = malloc(m_size);
        D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, m_size, search_hdl->search_name);
        if (search_hdl->search_name)
        {
          strcpy(search_hdl->search_name, el);
        }
        return;
      }
    }
  }
}
  
void
get_end(void *data, const char *el)
{
}

int*
get_all_attributes(int fd)
{
  XML_Parser p;
  unsigned int *attr_lst, i;
  sdp_search_handler search_hdl;

  search_hdl.search_name = "AttributeIdentifierCodes";  
  search_hdl.search_val = NULL;
  search_hdl.search_attr = NULL;

  p = XML_ParserCreate(NULL);
  XML_SetElementHandler(p, get_all_start, get_all_end);

  XML_SetUserData(p, &search_hdl);
  XML_UseParserAsHandlerArg(p);

  /* Start the parser */
  start_xml_parser(p, fd);

  attr_lst = (unsigned int*)search_hdl.search_val;

  XML_ParserFree(p);
  
  /* If we didn't find the service class we return here */
  if (!attr_lst)
  {
    D_ATTR("Didn't find anything");
    return NULL;
  }

  for (i = 1; i <= attr_lst[0]; i++)
  {
    D_ATTR("Attribute %d: 0x%04x", i , attr_lst[i]);
  }
    
  return attr_lst;
}

void get_all_start(void *data, const char *el, const char **attr)
{
  int i, attr_cnt, m_size;
  sdp_search_handler *search_hdl;

  search_hdl = (sdp_search_handler*) XML_GetUserData((XML_Parser*) data);
  
  if (strncmp(el, search_hdl->search_name, strlen(search_hdl->search_name)) == 0)
  {
    unsigned int *attributes;

    S_FNC("Found %s", el);
    attr_cnt = XML_GetSpecifiedAttributeCount((XML_Parser*) data);
    /* Since attr_cnt is the count of both the attibutes and the attribute
       values, we have to divide it by 2 */
    attr_cnt /= 2;
    
    S_FNC("%d attributes found", attr_cnt);
    /* Allocate space for all the attribute UUIDs plus the attribute count
       in the search_output pointer, */
    m_size = (attr_cnt + 1) * sizeof *attributes;
    search_hdl->search_val = malloc(m_size);
    attributes = (unsigned int *)search_hdl->search_val;
    D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, m_size, attributes);

    if (!attributes)
    {
      set_err(SDP_INSUFFICIENT_RESOURCES);
      return;
    }

    *attributes++ = (unsigned int)attr_cnt;
    for (i = 0; attr[i]; i += 2)
    {
      unsigned int tmp = strtoul(attr[i + 1], NULL, 16); 

      *attributes++ = tmp;
      S_FNC("Attribute %d found", tmp);
    } 
  }
}

void get_all_end(void *data, const char *el)
{
}

void browse_database()
{
}

void browse_database_start(void *data, const char *el, const char **attr)
{
}

void browse_database_end(void *data, const char *el)
{
}

void
handle_query(database_query_struct *db_hdl)
{
  switch (db_hdl->pkt_type) {
  case SDP_SERVICESEARCH_REQ:
    D_REC("Got SDP_SERVICESEARCH_REQ");
    handle_service_search_req((service_search_struct*) db_hdl);
    break;
  
  case SDP_SERVICEATTR_REQ:
    D_REC("Got SDP_SERVICEATTR_REQ");
    handle_service_attr_req((service_attr_struct*) db_hdl);
    break;
  
  case SDP_SERVICESEARCHATTR_REQ:
    D_REC("Got SDP_SERVICESEARCHATTR_REQ");
    handle_service_search_attr_req((service_search_attr_struct*) db_hdl);
    break;
    
  default:
    fprintf(stderr, "Unrecognised packet 0x%02x\n", db_hdl->pkt_type);
    break;
  }
}

/* FIXME: Add features to handle continuation states and multiple service
   classes */


void 
handle_service_search_req(service_search_struct *db_hdl)
{
  unsigned char rsp_pkt[256];
  int rsp_pkt_len;
  unsigned int *rec_hdl_list;
  unsigned int rec_hdl_cnt = 0;
  unsigned int max_rec_cnt;
  int i;

  rec_hdl_list = get_all_rec_hdl(db_hdl->service_class_list, db_hdl->service_class_cnt);

  if (is_err())
  {
    send_error_rsp(&db_hdl->db, get_err());
  }

  if (rec_hdl_list)
  {
    while (rec_hdl_list[rec_hdl_cnt] != NO_REC_HDL)
    {
      rec_hdl_cnt++;
    }
  }

  D_MISC("Found %d rec handles in database\n", rec_hdl_cnt);

  /* Calculate how many records we can fit into response */
  /* SdpHdrSize[5] + TotSrvCnt[2] + CurSrvRevCnt[2] + possibl ContState[2] 
     => 11 bytes. Each rec hdl is 4 bytes */

  max_rec_cnt = MIN(db_hdl->max_rec_cnt, (db_hdl->db.l2cap_mtu - 11)/4);

  if (rec_hdl_cnt > max_rec_cnt) 
  {
    D_REC("Only send %d out of %d record handles\n", max_rec_cnt, rec_hdl_cnt);
    rec_hdl_cnt = max_rec_cnt;
  }
  
  rsp_pkt_len = SDP_HDR_SIZE;  
  
  /* Set the total service record count */
  rsp_pkt[rsp_pkt_len++] = SHORT2CHAR_MS(rec_hdl_cnt);
  rsp_pkt[rsp_pkt_len++] = SHORT2CHAR_LS(rec_hdl_cnt);
  
  /* fixme -- total/current should probably differ sometimes... */
  
  /* Set the current service record count */
  rsp_pkt[rsp_pkt_len++] = SHORT2CHAR_MS(rec_hdl_cnt);
  rsp_pkt[rsp_pkt_len++] = SHORT2CHAR_LS(rec_hdl_cnt);
  
  if (rec_hdl_list)
  {
    for (i = 0; i < rec_hdl_cnt; i++)
    {
      rsp_pkt[rsp_pkt_len++] = (rec_hdl_list[i] >> 24) & 0xff;
      rsp_pkt[rsp_pkt_len++] = (rec_hdl_list[i] >> 16) & 0xff;
      rsp_pkt[rsp_pkt_len++] = (rec_hdl_list[i] >> 8) & 0xff;
      rsp_pkt[rsp_pkt_len++] = rec_hdl_list[i] & 0xff;
    }
  }
  
  set_sdp_hdr(rsp_pkt, SDP_SERVICESEARCH_RSP, db_hdl->db.trans_id,
              rsp_pkt_len - SDP_HDR_SIZE);

  D_REC("l2cap_mtu:%d, mrc:%d, db->mrc:%d\n", db_hdl->db.l2cap_mtu, max_rec_cnt, db_hdl->max_rec_cnt);

  /* If Max Service Record Count is set to a value less than the number of
     available records in database we should not set cont state */

  /* set_cont_state_search searches rsp_pkt for currently set rec cnt 
     and we compare that with max_rec_cnt. If current is larger than
     max rec cnt, we set continuation state and change headers in rsp
     packet. If not we simply put a 0 in the end to indicate no cont 
     state */
  
  /* fixme -- as of today we can only handle continuation state for 
     1 client at a time */

  rsp_pkt_len = set_cont_state_search(rsp_pkt, rsp_pkt_len, max_rec_cnt);

  if (is_err())
  {
    send_error_rsp(&db_hdl->db, get_err());
    return;
  }
  
  write2stack(db_hdl->db.sdp_con_id, rsp_pkt, rsp_pkt_len); 
}

void 
handle_service_attr_req(service_attr_struct *db_hdl)
{
  unsigned char rsp_pkt[256];
  int rsp_pkt_len, i, des_len_pos;
  unsigned char *tmp_ptr;
  unsigned int max_attr_byte_cnt;
    
  /* Skip the sdp header and the attribute byte count field */
  rsp_pkt_len = SDP_HDR_SIZE + 2;

  rsp_pkt[rsp_pkt_len++] = DES_HDR;
  des_len_pos = rsp_pkt_len;
  rsp_pkt_len++;

  for (i = 0; i < db_hdl->attr_cnt; i++)
  {
    if ((db_hdl->attr_list[i] & 0xffff) ^ (db_hdl->attr_list[i] >> 16))
    {
      tmp_ptr = get_attribute_range(xml_fd, db_hdl->rec_hdl, db_hdl->attr_list[i]);
    }
    else
    {
      tmp_ptr = get_attribute_list(xml_fd, db_hdl->rec_hdl, db_hdl->attr_list[i]);
    }

    if (tmp_ptr)
    {
      memcpy(rsp_pkt + rsp_pkt_len, tmp_ptr + 2, tmp_ptr[1]);
      rsp_pkt_len += tmp_ptr[1];

      D_MEM("<--- free%d 0x%8p", --malloc_dbg, tmp_ptr);
      free(tmp_ptr);
    }
    else if (is_err())
    {
      send_error_rsp(&db_hdl->db, get_err());
      return;
    }
  }

  /* Set the attribute byte count to packet length minus sdp pdu header size
     minus attribute byte count field length, minus continuation field length*/
  rsp_pkt[SDP_HDR_SIZE]   = SHORT2CHAR_MS(rsp_pkt_len - SDP_HDR_SIZE - 2);
  rsp_pkt[SDP_HDR_SIZE+1] = SHORT2CHAR_LS(rsp_pkt_len - SDP_HDR_SIZE - 2);

  /* The length of the attribute list is the length of the attribute byte
     count minus the size of the data element sequence header */
  rsp_pkt[des_len_pos] = rsp_pkt_len - SDP_HDR_SIZE - 2 - 2;
  
  set_sdp_hdr(rsp_pkt, SDP_SERVICEATTR_RSP, db_hdl->db.trans_id,
              rsp_pkt_len - SDP_HDR_SIZE);

  max_attr_byte_cnt = MIN(db_hdl->max_attr_byte_cnt, db_hdl->db.l2cap_mtu - 9);
  /* 9 comes from SDP_HDR_SIZE + attr byte nt field + 2 bytes for cont state */

  D_REC("l2cap_mtu:%d, mabc:%d, db->mabc:%d\n", db_hdl->db.l2cap_mtu, max_attr_byte_cnt, db_hdl->max_attr_byte_cnt);
   
  rsp_pkt_len = set_cont_state_attr(rsp_pkt, rsp_pkt_len, max_attr_byte_cnt);

  if (is_err())
  {
    send_error_rsp(&db_hdl->db, get_err());
    return;
  }
  
  write2stack(db_hdl->db.sdp_con_id, rsp_pkt, rsp_pkt_len); 
}

void
handle_service_search_attr_req(service_search_attr_struct *db_hdl)
{
  unsigned char *tmp_ptr;
  unsigned int *rec_hdl_list;
  unsigned int rec_hdl_cnt;
  unsigned char rsp_pkt[1024];
  unsigned int max_attr_byte_cnt;
  int rsp_pkt_len = 0, tmp_len, des_len_pos, i, j = 0;

  rec_hdl_list = get_all_rec_hdl(db_hdl->service_class_list, db_hdl->service_class_cnt);

   D_REC("Got a record handle list");
  
  if (is_err())
  {
    D_REC("Error occured, sending error response");
    send_error_rsp(&db_hdl->db, get_err());
    return;
  }

  if (rec_hdl_list)
  {
    rec_hdl_cnt = 0;
    while (rec_hdl_list[rec_hdl_cnt] != NO_REC_HDL)
    {
      rec_hdl_cnt++;
    }
    D_REC("Found %d record handles", rec_hdl_cnt);
  }
  
  /* Skip the sdp header and the attribute byte count field */
  rsp_pkt_len = SDP_HDR_SIZE + 2;

  rsp_pkt[rsp_pkt_len++] = DES_HDR_2B;
  des_len_pos = rsp_pkt_len;
  rsp_pkt_len += 2;

  for (j = 0; j < rec_hdl_cnt; j++)
  {
    tmp_len = 2;
    for (i = 0; i < db_hdl->attr_cnt; i++)
    {
      if ((db_hdl->attr_list[i] & 0xffff) ^ (db_hdl->attr_list[i] >> 16))
      {
        tmp_ptr = get_attribute_range(xml_fd, rec_hdl_list[j], db_hdl->attr_list[i]);
      }
      else
      {
        tmp_ptr = get_attribute_list(xml_fd, rec_hdl_list[j], db_hdl->attr_list[i]);
      }
      if (tmp_ptr)
      {
        printf(__FUNCTION__ ": Copying %d bytes to rsp_pkt\n", tmp_ptr[1]);
        memcpy(rsp_pkt + rsp_pkt_len + tmp_len, tmp_ptr + 2, tmp_ptr[1]);
        tmp_len += tmp_ptr[1];

        printf(__FUNCTION__ ": list_len: %d\n", tmp_len);

        D_MEM("<--- free%d tmp_ptr 0x%8p", --malloc_dbg, tmp_ptr);
        free(tmp_ptr);
      }
      else if (is_err())
      {
        send_error_rsp(&db_hdl->db, get_err());
        return;
      }
    }
    if (tmp_len > 2) 
    {
      rsp_pkt[rsp_pkt_len] = DES_HDR;
      rsp_pkt[rsp_pkt_len + 1] = tmp_len - 2;
      rsp_pkt_len += tmp_len;
    }
  }

  /* Set the attribute byte count to packet length minus sdp pdu header size
     minus attribute byte count field length */
  rsp_pkt[SDP_HDR_SIZE]   = SHORT2CHAR_MS(rsp_pkt_len - SDP_HDR_SIZE - 2);
  rsp_pkt[SDP_HDR_SIZE+1] = SHORT2CHAR_LS(rsp_pkt_len - SDP_HDR_SIZE - 2);

  /* The length of the attribute list is the same as the packet length minus
     the packet header length minus the attibute byte count filed minus the
     data element sequence header*/
  rsp_pkt[des_len_pos]     = SHORT2CHAR_MS(rsp_pkt_len - SDP_HDR_SIZE - 2 - 3);
  rsp_pkt[des_len_pos + 1] = SHORT2CHAR_LS(rsp_pkt_len - SDP_HDR_SIZE - 2 - 3);

  set_sdp_hdr(rsp_pkt, SDP_SERVICESEARCHATTR_RSP, db_hdl->db.trans_id,
              rsp_pkt_len - SDP_HDR_SIZE);

  max_attr_byte_cnt = MIN(db_hdl->max_attr_byte_cnt, db_hdl->db.l2cap_mtu - 9);
  /* 9 comes from SDP_HDR_SIZE + attr byte nt field + 2 bytes for cont state */

  D_REC("l2cap_mtu:%d, mabc:%d, db->mabc:%d\n", db_hdl->db.l2cap_mtu, max_attr_byte_cnt, db_hdl->max_attr_byte_cnt);
  
  rsp_pkt_len = set_cont_state_attr(rsp_pkt, rsp_pkt_len, max_attr_byte_cnt);
  
  if (is_err())
  {
    send_error_rsp(&db_hdl->db, get_err());
    return;
  }
  
  /* FIXME: Add features to handle continuation state packets */
  write2stack(db_hdl->db.sdp_con_id, rsp_pkt, rsp_pkt_len); 
}

int
set_cont_state_search(unsigned char *pkt, unsigned int len, unsigned int max_rec_cnt)
{
  int cur_rec_cnt;
  int cnt_len;

  cur_rec_cnt = CHAR2INT16(pkt[SDP_HDR_SIZE+2], pkt[SDP_HDR_SIZE+3]);

  if (cur_rec_cnt > max_rec_cnt)
  {
    S_FNC("Setting cont state, cur_rec_cnt:%d, max_rec_cnt:%d",
          cur_rec_cnt, max_rec_cnt);

    pkt[SDP_HDR_SIZE]   = SHORT2CHAR_MS(max_rec_cnt);
    pkt[SDP_HDR_SIZE+1] = SHORT2CHAR_LS(max_rec_cnt);

    pkt[SDP_HDR_SIZE+2] = SHORT2CHAR_MS(max_rec_cnt);
    pkt[SDP_HDR_SIZE+3] = SHORT2CHAR_LS(max_rec_cnt);
    
     /* There are cnt_len byte too much to fit the data in one packet */
    cnt_len = (cur_rec_cnt - max_rec_cnt) * 4;
    
    /* The packet can't be longer than this, excluding the continuation state
       bytes */
    len -= cnt_len;
    
    cont_state_buf = malloc(sizeof(cont_state_struct) + cnt_len);
    D_MEM("---> malloc%d %ld bytes at 0x%8p", malloc_dbg++, sizeof(cont_state_struct) + cnt_len, cont_state_buf);

    if (!cont_state_buf)
    {
      set_err(SDP_INSUFFICIENT_RESOURCES);
      return 0;
    }
    
    cont_state_buf->pdu = pkt[SDP_HDR_TYPE];
    D_MISC("PDU: 0x%02x", cont_state_buf->pdu);
    
    cont_state_buf->len = cnt_len;
    memcpy(cont_state_buf->data, pkt + len, cnt_len);
    
    len = SDP_HDR_SIZE + 2 + 2 + (max_rec_cnt * 4);

    pkt[len++] = 1;
    pkt[len++] = 0;
  }
  else
  {
    D_MISC("No continuation state set\n");
    pkt[len++] = 0;
  }
  
  
  /* Change the length field */
  pkt[SDP_HDR_LENGTH_MS] = SHORT2CHAR_MS(len - SDP_HDR_SIZE);
  pkt[SDP_HDR_LENGTH_LS] = SHORT2CHAR_LS(len - SDP_HDR_SIZE);

  return len;
}

/* FIXME: This function only handles continuation state from one query yet */

int
set_cont_state_attr(unsigned char *pkt, int len, int max_attr_len)
{
  int cur_attr_cnt;
  int cont_len;

  cur_attr_cnt = CHAR2INT16(pkt[SDP_HDR_SIZE], pkt[SDP_HDR_SIZE+1]);

  S_FNC("len %d, max_attr_len %d, cur_attr_cnt %d", len, max_attr_len, cur_attr_cnt);

  PRINT_DATA(__FUNCTION__, pkt, len);

  if (max_attr_len < cur_attr_cnt)
  {
    S_FNC("max_attr_len:%d, cur_attr_cnt:%d and packet length:%d", max_attr_len, cur_attr_cnt, len);

    /* There are cont_len byte to much to fit the data in one packet */
    cont_len = cur_attr_cnt - max_attr_len;

    /* The packet can't be longer than this, excluding the continuation state
       bytes */
    len -= cont_len;

    cont_state_buf = malloc(sizeof(cont_state_struct) + cont_len);
    D_MEM("---> malloc%d %ld bytes at 0x%8p", malloc_dbg++, sizeof(cont_state_struct) + cont_len , cont_state_buf);

    if (!cont_state_buf)
    {
      set_err(SDP_INSUFFICIENT_RESOURCES);
      return 0;
    }
    
    cont_state_buf->pdu = pkt[SDP_HDR_TYPE];
    D_MISC("PDU: 0x%02x", cont_state_buf->pdu);

    cont_state_buf->len = cont_len;
    memcpy(cont_state_buf->data, pkt + len, cont_len);

    pkt[SDP_HDR_SIZE]   = SHORT2CHAR_MS(max_attr_len);
    pkt[SDP_HDR_SIZE+1] = SHORT2CHAR_LS(max_attr_len);
    
    pkt[len++] = 1;
    pkt[len++] = 0;
  }
  else
  {
    S_FNC("No continuation State set");
    pkt[len++] = 0;
  }
  
  /* Change the length field */

  S_FNC("Changing length field");
  pkt[SDP_HDR_LENGTH_MS] = SHORT2CHAR_MS(len - SDP_HDR_SIZE);
  pkt[SDP_HDR_LENGTH_LS] = SHORT2CHAR_LS(len - SDP_HDR_SIZE);

  return len;
}

void
send_cont_state_search_rsp(int len, unsigned char *info, int max_rec_cnt,
			   database_query_struct *db)
{
  unsigned char *send_buf;
  int send_len;
  
  if (!cont_state_buf) {
    send_error_rsp(db, SDP_INVALID_CONTINUATION_STATE);
  }
  else if ((max_rec_cnt * 4) >= cont_state_buf->len)
  {
    /* Allocate space for the SDP header, the attribute byte count field,
       the attributes and the continuation state field */
    send_len = SDP_HDR_SIZE + 2 + 2 + cont_state_buf->len + 1;

    send_buf = malloc(send_len);
    D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, send_len, send_buf);
    if (!send_buf)
    {
      send_error_rsp(db, SDP_INSUFFICIENT_RESOURCES);
      return;
    }

    set_sdp_hdr(send_buf, cont_state_buf->pdu, db->trans_id, send_len - SDP_HDR_SIZE);

    /* Set the attribute byte count field */
    send_buf[SDP_HDR_SIZE]   = SHORT2CHAR_MS(cont_state_buf->len / 4);
    send_buf[SDP_HDR_SIZE+1] = SHORT2CHAR_LS(cont_state_buf->len / 4);

    /* Set the attribute byte count field */
    send_buf[SDP_HDR_SIZE+2] = SHORT2CHAR_MS(cont_state_buf->len / 4);
    send_buf[SDP_HDR_SIZE+3] = SHORT2CHAR_LS(cont_state_buf->len / 4);

    memcpy(send_buf + SDP_HDR_SIZE + 2 + 2, cont_state_buf->data, cont_state_buf->len);

    send_buf[send_len - 1] = 0;

    /* Send the whole buffer */
    write2stack(db->sdp_con_id, send_buf, send_len);

    D_MEM("<--- free%d 0x%8p", --malloc_dbg, send_buf);
    free(send_buf);

    D_MEM("<--- free%d 0x%8p", --malloc_dbg, cont_state_buf);
    free(cont_state_buf);
    cont_state_buf = NULL;
  }
  else
  {
    /* Write as much as possible */

    /* FIXME: Have to implement this too... */

    send_error_rsp(db, SDP_INVALID_SDP_VERSION);
  }
}

void
send_cont_state_attr_rsp(int len, unsigned char *info, int max_attr_cnt,
                         database_query_struct *db)
{
  unsigned char *send_buf;
  int send_len;
  
  if (!cont_state_buf) {
    send_error_rsp(db, SDP_INVALID_CONTINUATION_STATE);
  }
  else if (max_attr_cnt >= cont_state_buf->len)
  {
    /* Allocate space for the SDP header, the attribute byte count field,
       the attributes and the continuation state field */
    send_len = SDP_HDR_SIZE + 2 + cont_state_buf->len + 1;

    send_buf = malloc(send_len);
    D_MEM("---> malloc%d %d bytes at 0x%8p", malloc_dbg++, send_len, send_buf);
    if (!send_buf)
    {
      send_error_rsp(db, SDP_INSUFFICIENT_RESOURCES);
      return;
    }

    set_sdp_hdr(send_buf, cont_state_buf->pdu, db->trans_id, send_len - SDP_HDR_SIZE);

    /* Set the attribute byte count field */
    send_buf[SDP_HDR_SIZE]   = SHORT2CHAR_MS(cont_state_buf->len);
    send_buf[SDP_HDR_SIZE+1] = SHORT2CHAR_LS(cont_state_buf->len);

    memcpy(send_buf + SDP_HDR_SIZE + 2, cont_state_buf->data, cont_state_buf->len);

    send_buf[send_len - 1] = 0;

    /* Send the whole buffer */
    write2stack(db->sdp_con_id, send_buf, send_len);

    D_MEM("<--- free%d 0x%8p", --malloc_dbg, send_buf);
    free(send_buf);

    D_MEM("<--- free%d 0x%8p", --malloc_dbg, cont_state_buf);
    free(cont_state_buf);
    cont_state_buf = NULL;
  }
  else
  {
    /* Write as much as possible */

    /* FIXME: Have to implement this too... */

    send_error_rsp(db, SDP_INVALID_SDP_VERSION);
  }
}
