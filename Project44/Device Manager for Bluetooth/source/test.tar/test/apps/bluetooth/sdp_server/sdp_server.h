
#ifndef SDP_SERVER_H
#define SDP_SERVER_H

/****************** INCLUDE FILES SECTION ***********************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

#define SHORT2CHAR_MS(x) (((x) >> 8) & 0xff)
#define SHORT2CHAR_LS(x) ((x) & 0xff)

#define FIRST_VALID_CHAR(x) (((x)>0x20) && ((x)<0x7f))

#define BUFFSIZE 1024

#define SDP_HDR_TYPE        0
#define SDP_HDR_TRANS_ID_MS 1
#define SDP_HDR_TRANS_ID_LS 2
#define SDP_HDR_LENGTH_MS   3
#define SDP_HDR_LENGTH_LS   4
#define SDP_HDR_SIZE        5

#define DES_HDR 0x35
#define DES_HDR_2B 0x36

#define DES_HDR_DEPTH 2
#define S_DES_HDR "0x35"
#define S_DES_HDR1 "0x3501" /* Data element sequence header with size one */
#define S_DES_HDR0 "0x3500" /* Data element sequence header with size zero */

#define STR_HDR "0x25"

#define NO_REC_HDL 1

#define SDP_ERROR_RSP             1
#define SDP_SERVICESEARCH_REQ     2
#define SDP_SERVICESEARCH_RSP     3
#define SDP_SERVICEATTR_REQ       4
#define SDP_SERVICEATTR_RSP       5
#define SDP_SERVICESEARCHATTR_REQ 6
#define SDP_SERVICESEARCHATTR_RSP 7

/****************** TYPE DEFINITION SECTION *********************************/

typedef struct rec_hdl_search_struct
{
  char *uuid;
  unsigned int tmp_hdl;
  unsigned int hdl_list_len;
  unsigned int hdl_list_max;
  unsigned int *hdl_list;
} rec_hdl_search_struct;

typedef struct sdp_search_handler
{
  char *search_name;
  char *search_attr;
  char *search_val;
} sdp_search_handler;

typedef struct sdp_attribute_search
{
  char *service_class;
  int service_class_found;
  char *attribute_name;
  int attribute_name_found;
  int attribute_id;
  int attr2get;
  char attrlist[256];
  int attrlist_index;
  int des_len_pos[2];
  int des_len[2];
  int set_des_len[2];
} sdp_attribute_search;

typedef struct database_query_struct
{
  unsigned short l2cap_mtu; 
  unsigned short sdp_con_id;
  unsigned short trans_id;
  unsigned short pkt_type;
} database_query_struct;

typedef struct service_search_struct
{
  struct database_query_struct db;
  unsigned int max_rec_cnt;
  unsigned int service_class_cnt;
  unsigned int service_class_list[12];
} service_search_struct;

typedef struct service_attr_struct
{
  struct database_query_struct db;
  unsigned int max_attr_byte_cnt;
  unsigned int rec_hdl;
  unsigned int attr_cnt;
  unsigned int attr_list[0];
} service_attr_struct;

typedef struct service_search_attr_struct
{
  struct database_query_struct db;
  unsigned int max_attr_byte_cnt;
  unsigned int service_class_cnt;
  unsigned int service_class_list[12];
  unsigned int attr_cnt;
  unsigned int attr_list[0];
} service_search_attr_struct;

typedef struct cont_state_struct
{
  unsigned char pdu;
  int len;
  unsigned char data[0];
} cont_state_struct;

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

void handle_query(database_query_struct *db_hdl);
void init_sdp_server(int fd);
void print_data(const char *message, const unsigned char *buf, int len);
void
send_cont_state_search_rsp(int len, unsigned char *info, int max_rec_cnt,
			   database_query_struct *db);
void
send_cont_state_attr_rsp(int len, unsigned char *info, int max_attr_cnt,
                              database_query_struct *db);
unsigned int *get_more_rec_hdl(unsigned short servive_class, int fd);
void send_error_rsp(database_query_struct *db, unsigned short err_code);


#endif
/****************** END OF FILE sdp_server.h ********************************/
