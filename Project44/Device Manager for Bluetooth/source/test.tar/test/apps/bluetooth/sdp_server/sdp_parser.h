
#ifndef SDP_PARSER_H
#define SDP_PARSER_H

/****************** INCLUDE FILES SECTION ***********************************/

/****************** CONSTANT AND MACRO SECTION ******************************/

#define SDP_XML_FILE "/etc/sdp.xml"
#ifndef BTD_USERSTACK
#define SDP_PROC_FILE "/proc/sdp_srv"
#else
#define SDP_PROC_FILE "/tmp/sdp_sock"
#endif

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

#define CHAR2INT10(c1,c0) (((unsigned int)((c1) & 0x03) << 8) + \
			   (unsigned int)((c0) & 0xff))

#define CHAR2INT12(c1,c0) (((unsigned int)((c1) & 0x0f) << 8) + \
			   (unsigned int)((c0) & 0xff))

#define CHAR2INT16(c1,c0) (((unsigned int)((c1) & 0xff) << 8) + \
			   (unsigned int)((c0) & 0xff))

#define CHAR2INT32(c3,c2,c1,c0) (((unsigned int)((c3) & 0xff) << 24) + \
				 ((unsigned int)((c2) & 0xff) << 16) + \
				 ((unsigned int)((c1) & 0xff) << 8) + \
				 (unsigned int)((c0) &0xff))

#define SDP_INVALID_SDP_VERSION           0x0001
#define SDP_INVALID_SERVICE_RECORD_HANDLE 0x0002
#define SDP_INVALID_REQUEST_SYNTAX        0x0003
#define SDP_INVALID_PDU_SIZE              0x0004
#define SDP_INVALID_CONTINUATION_STATE    0x0005
#define SDP_INSUFFICIENT_RESOURCES        0x0006

/****************** TYPE DEFINITION SECTION *********************************/

typedef struct data_struct {
  unsigned short l2cap_mtu;
  unsigned short sdp_con_id;
  unsigned short len;
  unsigned char data[0];
} __attribute__ ((packed)) data_struct;

/****************** EXPORTED FUNCTION DECLARATION SECTION *******************/

void write2stack(int sdp_con_id, char *data, int len);

#endif
/****************** END OF FILE sdp_parser.h ********************************/
