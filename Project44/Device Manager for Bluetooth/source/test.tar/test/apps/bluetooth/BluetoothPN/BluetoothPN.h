

#ifndef BTNeighborhood_h
#define BTNeighborhood_h
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <stdlib.h>
#include <stdio.h>
#include <FL/Fl_Group.h>
#include <FL/Fl_Menu_Bar.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Return_Button.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Toggle_Tree.H>
#include <FL/Fl_Scroll.H>
#include <FL/Fl_Clock.H>

class BTNeighborhood {
public:
  BTNeighborhood();
  Fl_Window *btMainWindow;
  Fl_Menu_Bar *btMainMenuBar;
  static Fl_Menu_Item menu_btMainMenuBar[];
private:
  static Fl_Menu_Item *btFileMenu;
  static Fl_Menu_Item *btFileMenuCloseItem;
  inline void cb_btFileMenuCloseItem_i(Fl_Menu_*, void*);
  static void cb_btFileMenuCloseItem(Fl_Menu_*, void*);
  static Fl_Menu_Item *btViewMenu;
  static Fl_Menu_Item *btViewMenuRefreshItem;
  inline void cb_btViewMenuRefreshItem_i(Fl_Menu_*, void*);
  static void cb_btViewMenuRefreshItem(Fl_Menu_*, void*);
  static Fl_Menu_Item *btHelpMenu;
public:
  static Fl_Menu_Item *btHelpMenuAboutItem;
private:
  inline void cb_btHelpMenuAboutItem_i(Fl_Menu_*, void*);
  static void cb_btHelpMenuAboutItem(Fl_Menu_*, void*);
  Fl_Window *btHelpMenuAboutItemWindow;
  Fl_Box *btHelpMenuAboutItem1;
  Fl_Box *btHelpMenuAboutItem2;
  Fl_Box *btHelpMenuAboutItem3;
  Fl_Return_Button *btHelpMenuAboutItemWindowOKButton;
  inline void cb_btHelpMenuAboutItemWindowOKButton_i(Fl_Return_Button*, void*);
  static void cb_btHelpMenuAboutItemWindowOKButton(Fl_Return_Button*, void*);
  Fl_Scroll *scrollWidgetV;
public:
  Fl_Window *btErrorCantFindBTDriverWindow;
private:
  inline void cb_OK_i(Fl_Button*, void*);
  static void cb_OK(Fl_Button*, void*);
  inline void cb_OK1_i(Fl_Button*, void*);
  static void cb_OK1(Fl_Button*, void*);
public:
  void show(int argc, char **argv);
private:
  void btScanForBluetoothDevices();
};

static  Fl_Window *btErrorHCIInquiry;
static  Fl_Window *btScanForBluetoothDevicesInProgressWindow;
static  Fl_Box *btScanForBluetoothDevicesProgressWindowLine1;
static  Fl_Clock *btScanForBluetoothDevicesInProgressClock;
static  Fl_Box *btScanForBluetoothDevicesProgressWindowLine2;
static  Fl_Toggle_Tree *treeWidget;

static  Fl_Pixmap *bluetoothIcon;
static  Fl_Pixmap *fileSmall;

#endif
