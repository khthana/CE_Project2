#include "BluetoothPN.h"

int main(int argc, char **argv)
{
//BTNeighborhood *mainWindow = new BTNeighborhood();
BTNeighborhood mainWindow;
mainWindow.show(argc, argv);
Fl::run();
}
