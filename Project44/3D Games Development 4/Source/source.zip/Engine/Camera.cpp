/////////////////////////////////////////////////////////////////////////////
//
//	Copyright (c) 2001, Maetee Supreanruey and Anusorn Krasantisuk
//	All Rights Reserved.
//
//	This is UNPUBLISHED PROPRIETARY SOURCE CODE of Maetee Supreanruey 
//	and Anusorn Krasantisuk, the contents of this file may not be 
//	disclosed to third parties, copied or duplicated in any form, 
//	in whole or in part, without the prior written permission of 
//	Maetee Supreanruey and Anusorn Krasantisuk.
//
/////////////////////////////////////////////////////////////////////////////


#include "..\stdafx.h"
#include "Camera.h"
#include <cmath>                    // for trigonometry functions
#include "GLGfx.h"
#include "Util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CCamera::CCamera()
{
	m_fLimitPhi = 80.0f;

    // Set attributes for the view matrix
    SetViewParams( D3DXVECTOR3(0.0f,0.0f,-5.0f), 
		           D3DXVECTOR3(0.0f,0.0f, 0.0f),
                   D3DXVECTOR3(0.0f,1.0f, 0.0f) );

    // Set attributes for the projection matrix
    SetProjParams( D3DX_PI/4, 1.0f, 1.0f, 1000.0f );
}

CCamera::~CCamera()
{

}

//-----------------------------------------------------------------------------
// Name: SetViewParams
// Desc: Set View Parameter
//-----------------------------------------------------------------------------
VOID CCamera::SetViewParams( D3DXVECTOR3 &vEyePt, D3DXVECTOR3& vLookatPt,
                                D3DXVECTOR3& vUpVec )
{
    // Set attributes for the view matrix
    m_vEyePt    = vEyePt;
    m_vLookatPt = vLookatPt;
    m_vUpVec    = vUpVec;
    D3DXVec3Normalize( &m_vView, &(m_vLookatPt - m_vEyePt) );
    D3DXVec3Cross( &m_vCross, &m_vView, &m_vUpVec );

    D3DXMatrixLookAtLH( &m_matView, &m_vEyePt, &m_vLookatPt, &m_vUpVec );
    D3DXMatrixInverse( &m_matBillboard, NULL, &m_matView );
    m_matBillboard._41 = 0.0f;
    m_matBillboard._42 = 0.0f;
    m_matBillboard._43 = 0.0f;

	// =============================New================================

	float dx = vLookatPt.x - m_vEyePt.x;
	float dy = vLookatPt.y - m_vEyePt.y;
	float dz = vLookatPt.z - m_vEyePt.z;
	
	// set r
	m_dR = float( sqrt( ( dx * dx ) +
		              ( dy * dy ) +
		 	          ( dz * dz ) ) );
 
	// set phi
	if (m_dR != 0)
	{

		m_dPhi = D3DXToDegree( Math::ASinf( (dy / m_dR)) );

		
		if ((cos( (D3DXToRadian( m_dPhi )) )) != 0.0f )
		{
			

			if (dx >= 0)
			{
				m_dZetha =  D3DXToDegree( Math::ACosf(dz / (m_dR * Math::Cosf(D3DXToRadian( m_dPhi )))));
			}
			else
			{
				m_dZetha =  D3DXToDegree(-Math::ACosf(dz / (m_dR * Math::Cosf(D3DXToRadian( m_dPhi )))));
			}
			
		};

	};


}

//-----------------------------------------------------------------------------
// Name: SetProjParams
// Desc: Set Projection Parameter
//-----------------------------------------------------------------------------
VOID CCamera::SetProjParams( FLOAT fFOV, FLOAT fAspect, FLOAT fNearPlane,
                                FLOAT fFarPlane )
{
    // Set attributes for the projection matrix
    m_fFOV        = fFOV;
    m_fAspect     = fAspect;
    m_fNearPlane  = fNearPlane;
    m_fFarPlane   = fFarPlane;

    D3DXMatrixPerspectiveFovLH( &m_matProj, fFOV, fAspect, fNearPlane, fFarPlane );
}

VOID CCamera::View()
{
	GLGfx::SetMatProj( &m_matProj );
	GLGfx::SetMatView( &m_matView );
}

// Camera System1 NormalStyle "At point and Look point"
VOID CCamera::SetParamsSystem1(float atx,float aty,float atz,
	  						   float lx ,float ly ,float lz,
					           float ux ,float uy ,float uz)
{
    D3DXVECTOR3 vEyePt    = D3DXVECTOR3( atx, aty, atz );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3(  lx,  ly, lz  );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3(  ux,  uy, uz  );
    
	SetViewParams( vEyePt, vLookatPt, vUpVec );
}

// Camera System2 QuakeStyle 
void CCamera::SetParamsSystem2(float atx,float  aty   ,float  atz ,
					           float r  ,float zetha  ,float phi ,
                               float ux ,float  uy    ,float  uz )
{

    D3DXVECTOR3 vEyePt;
    D3DXVECTOR3 vLookatPt;
    D3DXVECTOR3 vUpVec;

	vEyePt.x = atx;
	vEyePt.y = aty;
	vEyePt.z = atz;

	// Set r
	m_dR      = r;


	while (zetha>=360.0)
	{
		zetha -= 360.0f;
	};
	

	while (zetha < 0.0)
	{
	    zetha = zetha + 360.0f;		
	};

	while (phi>=360.0)
	{
	    phi -= 360.0f;
	};

	while (phi<0.0)
	{
	    phi += 360.0f;
	};


	// Set phi
	m_dPhi   = phi;

	// Set zetha
	m_dZetha = zetha; 

	 
	((vLookatPt).x) = atx + (float(r) * Math::Cosf(D3DXToRadian( m_dPhi )) * Math::Sinf(D3DXToRadian( m_dZetha )));
	((vLookatPt).y) = aty + (float(r) * Math::Sinf(D3DXToRadian( m_dPhi )));
	((vLookatPt).z) = atz + (float(r) * Math::Cosf(D3DXToRadian( m_dPhi )) * Math::Cosf(D3DXToRadian( m_dZetha )));

	(vUpVec).x = ux;
	(vUpVec).y = uy;
	(vUpVec).z = uz;


	SetViewParams( vEyePt, vLookatPt, vUpVec );

};

void CCamera::S2_MoveForward( float fStep )
{
	SetParamsSystem2( m_vEyePt.x + fStep * Math::Sinf( D3DXToRadian( m_dZetha ) ), 
		              m_vEyePt.y , 
					  m_vEyePt.z + fStep * Math::Cosf( D3DXToRadian( m_dZetha ) ),
					  m_dR        , m_dZetha    , m_dPhi,
					  0          , 1          , 0 ); 
}

void CCamera::S2_MoveBackward( float fStep )
{
	SetParamsSystem2( m_vEyePt.x - fStep * Math::Sinf( D3DXToRadian( m_dZetha ) ), 
		              m_vEyePt.y , 
					  m_vEyePt.z - fStep * Math::Cosf( D3DXToRadian( m_dZetha ) ),
					  m_dR        , m_dZetha    , m_dPhi,
					  0          , 1          , 0 ); 
}

void CCamera::S2_MoveLeft( float fStep )
{
	SetParamsSystem2( m_vEyePt.x + fStep * Math::Sinf( D3DXToRadian( m_dZetha - 90 )),
					  m_vEyePt.y, 
					  m_vEyePt.z + fStep * Math::Cosf( D3DXToRadian( m_dZetha - 90 )),
					  m_dR				, m_dZetha   , m_dPhi,
					  0					, 1         , 0 ); 
}

void CCamera::S2_MoveRight( float fStep )
{
	SetParamsSystem2( m_vEyePt.x  + fStep * Math::Sinf( D3DXToRadian( m_dZetha + 90 )) , 
					  m_vEyePt.y, 
					  m_vEyePt.z  + fStep * Math::Cosf( D3DXToRadian( m_dZetha + 90 )),
					  m_dR				, m_dZetha   , m_dPhi,
					  0                 , 1         , 0 ); 
}


void CCamera::S2_MoveUp( float fStep )
{
	SetParamsSystem2( m_vEyePt.x , 
					  m_vEyePt.y + fStep, 
					  m_vEyePt.z,
					  m_dR				, m_dZetha   , m_dPhi,
					  0                 , 1         , 0 ); 
}

void CCamera::S2_MoveDown( float fStep )
{
	SetParamsSystem2( m_vEyePt.x , 
					  m_vEyePt.y - fStep, 
					  m_vEyePt.z,
					  m_dR				, m_dZetha   , m_dPhi,
					  0                 , 1         , 0 ); 
}

void CCamera::S2_RotateUp( float Angle )
{
	double AngleTest = m_dPhi + Angle;
	if( AngleTest <= m_fLimitPhi )
	{
		SetParamsSystem2( m_vEyePt.x , m_vEyePt.y , m_vEyePt.z ,
						  m_dR        , m_dZetha    , m_dPhi + Angle,
						  0          , 1          , 0 ); 
	}
	else
	{
		SetParamsSystem2( m_vEyePt.x , m_vEyePt.y , m_vEyePt.z ,
						  m_dR        , m_dZetha    , m_fLimitPhi,
						  0          , 1          , 0 ); 		
	}
}

void CCamera::S2_RotateDown( float Angle )
{
	double AngleTest = m_dPhi-Angle;
	if( AngleTest >= -m_fLimitPhi  )
	{
		SetParamsSystem2( m_vEyePt.x , m_vEyePt.y , m_vEyePt.z ,
						  m_dR        , m_dZetha    , m_dPhi - Angle,
						  0          , 1          , 0 ); 
	}
	else
	{
		SetParamsSystem2( m_vEyePt.x , m_vEyePt.y , m_vEyePt.z ,
						  m_dR        , m_dZetha    , -m_fLimitPhi,
						  0          , 1          , 0 ); 
	}
}

void CCamera::S2_RotateLeft( float Angle )
{
	SetParamsSystem2( m_vEyePt.x , m_vEyePt.y     , m_vEyePt.z ,
					  m_dR        , m_dZetha - Angle, m_dPhi,
					  0          , 1              , 0 ); 
}

void CCamera::S2_RotateRight( float Angle )
{
	SetParamsSystem2( m_vEyePt.x , m_vEyePt.y     , m_vEyePt.z ,
					  m_dR        , m_dZetha + Angle, m_dPhi,
					  0          , 1              , 0 ); 
}

// Camera System3 QuakeStyle 
void CCamera::SetParamsSystem3(float lx ,float  ly    ,float  lz ,
					           float r ,float zetha ,float phi ,
                               float ux ,float  uy    ,float  uz )
{
    D3DXVECTOR3 vEyePt;
    D3DXVECTOR3 vLookatPt;
    D3DXVECTOR3 vUpVec;

	vEyePt.x = lx;
	vEyePt.y = ly;
	vEyePt.z = lz;

	// Set r
	m_dR     = r;

	while (zetha>=360)
	{
		zetha -= 360;
	};
	
	while (zetha < 0)
	{
	    zetha += 360;
	};

	while (phi>=360)
	{
	    phi -= 360;
	};

	while (phi<0)
	{
	    phi += 360;
	};

	// Set phi
	m_dPhi   = phi;

	// Set zetha
	m_dZetha = zetha; 

	((vLookatPt).x) = lx + float(r * Math::Cosf(D3DXToRadian( m_dPhi )) * Math::Sinf(D3DXToRadian( m_dZetha )));
	((vLookatPt).y) = ly + float(r * Math::Sinf(D3DXToRadian( m_dPhi )));
	((vLookatPt).z) = lz + float(r * Math::Cosf(D3DXToRadian( m_dPhi )) * Math::Cosf(D3DXToRadian( m_dZetha )));

	(vUpVec).x = ux;
	(vUpVec).y = uy;
	(vUpVec).z = uz;

	SetViewParams( vLookatPt, vEyePt, vUpVec );
};