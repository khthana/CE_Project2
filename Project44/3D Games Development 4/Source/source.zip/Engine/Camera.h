/////////////////////////////////////////////////////////////////////////////
//
//	Copyright (c) 2001, Maetee Supreanruey and Anusorn Krasantisuk
//	All Rights Reserved.
//
//	This is UNPUBLISHED PROPRIETARY SOURCE CODE of Maetee Supreanruey 
//	and Anusorn Krasantisuk, the contents of this file may not be 
//	disclosed to third parties, copied or duplicated in any form, 
//	in whole or in part, without the prior written permission of 
//	Maetee Supreanruey and Anusorn Krasantisuk.
//
/////////////////////////////////////////////////////////////////////////////

#pragma once
#include "d3dx8.h"

class CCamera  
{
public:
	CCamera();
	virtual ~CCamera();

private:
	D3DXVECTOR3 m_vEyePt;       // Attributes for view matrix
	D3DXVECTOR3 m_vLookatPt;
	D3DXVECTOR3 m_vUpVec;

	// polar coordinate
	float m_dR;
	float m_dZetha;  // Angle of (m_dR on (xy plane)) and +z 
	float m_dPhi;    // Angle of (m_dR and xy plane)     
	
	D3DXVECTOR3 m_vView;
	D3DXVECTOR3 m_vCross;

	D3DXMATRIX  m_matView;
	D3DXMATRIX  m_matBillboard; // Special matrix for billboarding effects

	FLOAT       m_fFOV;         // Attributes for projection matrix
	FLOAT       m_fAspect;
	FLOAT       m_fNearPlane;
	FLOAT       m_fFarPlane;
	D3DXMATRIX  m_matProj;
	float       m_fLimitPhi;
public:
	inline float GetLimitPhi() const 
		{ return m_fLimitPhi; };
	inline float SetLimitPhi( float fLimitPhi ) 
		{ m_fLimitPhi = fLimitPhi; };

public:
	// Interface
	D3DXVECTOR3 GetEyePt()           { return m_vEyePt; }
	D3DXVECTOR3 GetLookatPt()        { return m_vLookatPt; }
	D3DXVECTOR3 GetUpVec()           { return m_vUpVec; }
	D3DXVECTOR3 GetViewDir()         { return m_vView; }
	D3DXVECTOR3 GetCross()           { return m_vCross; }
	float      GetR()               { return m_dR; };
	float      GetPhi()             { return m_dPhi; };
	float      GetZetha()           { return m_dZetha; };

	D3DXMATRIX  GetViewMatrix()      { return m_matView; }
	D3DXMATRIX  GetBillboardMatrix() { return m_matBillboard; }
	D3DXMATRIX  GetProjMatrix()      { return m_matProj; }

public:
	// Basic Set Function Use only in this class
	void SetViewParams( D3DXVECTOR3 &vEyePt, D3DXVECTOR3& vLookatPt,
						D3DXVECTOR3& vUpVec );

	void SetProjParams( FLOAT fFOV, FLOAT fAspect, FLOAT fNearPlane,
						FLOAT fFarPlane );

	// View Function
	void View();

	// Camera System1 NormalStyle "At point and Look point"
	void SetParamsSystem1(float atx, float aty, float atz,
	  					float lx , float ly , float lz,
						float ux , float uy , float uz);

	// Quake Style Camera
	void SetParamsSystem2(float  atx, float  aty   , float  atz ,
						float r  , float zetha , float phi ,
						float  ux , float  uy    , float  uz );

	void S2_MoveForward ( float fStep );
	void S2_MoveBackward( float fStep );
	void S2_MoveLeft    ( float fStep );
	void S2_MoveRight   ( float fStep );
	void S2_MoveUp   ( float fStep );
	void S2_MoveDown   ( float fStep );

	void S2_RotateUp    ( float Angle );
	void S2_RotateDown  ( float Angle );
	void S2_RotateLeft  ( float Angle );
	void S2_RotateRight ( float Angle );

	// Zelda Style Camera
	void SetParamsSystem3(float lx ,float  ly    ,float  lz ,
						float r ,float zetha ,float phi,
						float ux ,float  uy    ,float  uz );
};

