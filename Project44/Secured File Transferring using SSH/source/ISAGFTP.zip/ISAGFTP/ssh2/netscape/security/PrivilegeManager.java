package ISAGFTP.ssh2.netscape.security;

public class PrivilegeManager {
  public static void enablePrivilege(String target) throws ForbiddenTargetException {
  }
}
