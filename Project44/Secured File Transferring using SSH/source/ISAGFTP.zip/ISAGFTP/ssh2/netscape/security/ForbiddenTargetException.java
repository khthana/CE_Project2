package ISAGFTP.ssh2.netscape.security;

public class ForbiddenTargetException extends Exception {
}
