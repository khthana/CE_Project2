package ISAGFTP.ssh2.javax.crypto.interfaces;

import ISAGFTP.ssh2.javax.crypto.spec.DHParameterSpec;

public interface DHKey {
    public DHParameterSpec getParams();
}
