package ISAGFTP.ssh2.javax.crypto;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.Provider;
import ISAGFTP.ssh2.ssh2engine.jca.security.SecureRandom;
import ISAGFTP.ssh2.ssh2engine.jca.security.Key;
import ISAGFTP.ssh2.ssh2engine.jca.security.NoSuchAlgorithmException;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidKeyException;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidAlgorithmParameterException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.AlgorithmParameterSpec;

public abstract class KeyAgreementSpi {

    public KeyAgreementSpi() {
    }

    protected abstract void engineInit(Key key, SecureRandom random)
	throws InvalidKeyException;

    protected abstract void engineInit(Key key, AlgorithmParameterSpec params,
				       SecureRandom random)
	throws InvalidKeyException, InvalidAlgorithmParameterException;

    protected abstract Key engineDoPhase(Key key, boolean lastPhase)
	throws InvalidKeyException, IllegalStateException;

    protected abstract byte[] engineGenerateSecret()
	throws IllegalStateException;

    protected abstract int engineGenerateSecret(byte[] sharedSecret, int offset)
	throws IllegalStateException, ShortBufferException;

    protected abstract SecretKey engineGenerateSecret(String algorithm)
	throws IllegalStateException, NoSuchAlgorithmException,
	       InvalidKeyException;

}
