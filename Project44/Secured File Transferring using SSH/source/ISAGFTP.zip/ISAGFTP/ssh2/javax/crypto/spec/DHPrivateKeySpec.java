package ISAGFTP.ssh2.javax.crypto.spec;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.spec.KeySpec;

public class DHPrivateKeySpec extends DHParamsImpl implements KeySpec {

    protected BigInteger x;

    public DHPrivateKeySpec(BigInteger x, BigInteger p, BigInteger g) {
	super(p, g);
	this.x = x;
    }

    public BigInteger getX() {
	return x;
    }

}
