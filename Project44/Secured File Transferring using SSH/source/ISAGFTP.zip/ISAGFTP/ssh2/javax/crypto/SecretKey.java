package ISAGFTP.ssh2.javax.crypto;

import ISAGFTP.ssh2.ssh2engine.jca.security.Key;

public interface SecretKey extends Key {
}
