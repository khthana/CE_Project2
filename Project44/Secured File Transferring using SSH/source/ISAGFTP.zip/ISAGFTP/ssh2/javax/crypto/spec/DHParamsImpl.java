package ISAGFTP.ssh2.javax.crypto.spec;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.spec.AlgorithmParameterSpec;

public abstract class DHParamsImpl {
    protected BigInteger p;
    protected BigInteger g;

    protected DHParamsImpl(BigInteger p, BigInteger g) {
	this.p = p;
	this.g = g;
    }

    public final BigInteger getP() {
	return p;
    }

    public final BigInteger getG() {
	return g;
    }

}
