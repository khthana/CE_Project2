package ISAGFTP.ssh2.javax.crypto.interfaces;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;

public interface DHPublicKey extends DHKey, PublicKey {
    public BigInteger getY();
}
