package ISAGFTP.ssh2.javax.crypto.interfaces;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;

public interface DHPrivateKey extends DHKey, PrivateKey {
    public BigInteger getX();
}
