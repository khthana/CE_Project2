package ISAGFTP.ssh2.javax.crypto;

import ISAGFTP.ssh2.ssh2engine.jca.security.GeneralSecurityException;

public class ShortBufferException extends GeneralSecurityException {
    public ShortBufferException(String msg) {
	super(msg);
    }
}
