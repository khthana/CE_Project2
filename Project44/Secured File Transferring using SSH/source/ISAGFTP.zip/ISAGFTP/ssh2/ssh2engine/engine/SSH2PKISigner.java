package ISAGFTP.ssh2.ssh2engine.engine;

/**
 * This interface is a simple abstraction of a PKI signing mechanism. An
 * implementation of this interface can use certificates or plain public keys,
 * this is something which is defined by the ssh2 specific algorithm name used
 * to identify it.
 *
 * @see SSH2AuthPublicKey
 */
public interface SSH2PKISigner {
    public String getAlgorithmName();
    public byte[] getPublicKeyBlob() throws SSH2SignatureException;
    public byte[] sign(byte[] data) throws SSH2SignatureException;
    public void setIncompatibility(SSH2Transport transport);
}
