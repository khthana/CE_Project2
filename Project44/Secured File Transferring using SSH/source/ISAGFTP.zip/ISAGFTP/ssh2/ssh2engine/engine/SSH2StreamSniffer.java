package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;

import ISAGFTP.ssh2.ssh2engine.util.HexDump;

public class SSH2StreamSniffer implements SSH2StreamFilter,
					  SSH2StreamFilterFactory
{
    protected int id;

    protected class SniffOutput extends FilterOutputStream {

	public SniffOutput(OutputStream toBeFiltered) {
	    super(toBeFiltered);
	}

	public void write(byte b[], int off, int len) throws IOException {
	    HexDump.print("ch. #" + id + " tx:", true, b, off, len);
	    out.write(b, off, len);
	}

    }

    protected class SniffInput extends FilterInputStream {

	public SniffInput(InputStream toBeFiltered) {
	    super(toBeFiltered);
	}

	public int read(byte b[], int off, int len) throws IOException {
	    int n = in.read(b, off, len);
	    if(n >= 0) {
		HexDump.print("ch. #" + id + " rx:", true, b, off, n);
	    } else {
		System.out.println("ch. #" + id + " rx: EOF");
	    }
	    return n;
	}

    }

    private static SSH2StreamSniffer factoryInstance;

    public SSH2StreamSniffer() {
    }

    public static synchronized SSH2StreamSniffer getFilterFactory() {
	if(factoryInstance == null) {
	    factoryInstance = new SSH2StreamSniffer();
	}
	return factoryInstance;
    }

    public SSH2StreamFilter createFilter(SSH2Connection connection,
                                         SSH2StreamChannel channel) {
	SSH2StreamSniffer sniffer = new SSH2StreamSniffer();
	sniffer.id = channel.getId();
        return sniffer;
    }

    public InputStream getInputFilter(InputStream toBeFiltered) {
        return new SniffInput(toBeFiltered);
    }

    public OutputStream getOutputFilter(OutputStream toBeFiltered) {
	return new SniffOutput(toBeFiltered);
    }

}
