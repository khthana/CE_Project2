package ISAGFTP.ssh2.ssh2engine.engine;

public interface SSH2AuthModule {

 
    public SSH2TransportPDU startAuthentication(SSH2UserAuth userAuth)
	throws SSH2Exception;

    public SSH2TransportPDU processMethodMessage(SSH2UserAuth userAuth,
						 SSH2TransportPDU pdu)
	throws SSH2Exception;

}
