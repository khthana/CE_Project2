package ISAGFTP.ssh2.ssh2engine.engine;

import java.net.Socket;
import java.util.Properties;

import ISAGFTP.ssh2.ssh2engine.util.SecureRandomAndPad;

public class SSH2SimpleClient {

    protected SSH2Transport  transport;
    protected SSH2Connection connection;
    protected SSH2UserAuth   userAuth;

    /**
     * Simple constructor to use when password authentication is sufficient.
     *
     * @param socket   connected socket to ssh2 server
     * @param rand     source of randomness for padding and keys
     * @param username name of user
     * @param password password of user
     * @param prefs    preferences for transport layer
     *
     * @see SSH2TransportPreferences
     */
    public SSH2SimpleClient(Socket socket, SecureRandomAndPad rand,
			    String username, String password,
			    Properties prefs)
	throws SSH2Exception
    {
	this(socket, rand,
	     username, "password", new SSH2AuthPassword(password),
	     prefs);
    }

    /**
     * Constructor to use when other authentication than password is needed.
     *
     * @param socket     connected socket to ssh2 server
     * @param rand       source of randomness for padding and keys
     * @param username   name of user
     * @param authType   type of authentication (e.g. publickey)
     * @param authModule authentication module (e.g. <code>SSH2AuthPublicKey</code>)
     * @param prefs      preferences for transport layer
     *
     * @see SSH2TransportPreferences
     */
    public SSH2SimpleClient(Socket socket, SecureRandomAndPad rand,
			    String username,
			    String authType, SSH2AuthModule authModule,
			    Properties prefs)
	throws SSH2Exception
    {
	transport = new SSH2Transport(socket,
				      new SSH2TransportPreferences(prefs),
				      rand);
	transport.boot();

	if(!transport.waitForKEXComplete()) {
	    throw new SSH2FatalException("KEX failed");
	}

	SSH2Authenticator authenticator = new SSH2Authenticator(username);

	authenticator.addModule(authType, authModule);

	userAuth = new SSH2UserAuth(transport, authenticator);
	if(!userAuth.authenticateUser("ssh-connection")) {
	    throw new SSH2FatalException("Permission denied");
	}

	connection = new SSH2Connection(userAuth, transport);
	transport.setConnection(connection);
    }

    public SSH2Transport getTransport() {
	return transport;
    }

    public SSH2Connection getConnection() {
	return connection;
    }

}
