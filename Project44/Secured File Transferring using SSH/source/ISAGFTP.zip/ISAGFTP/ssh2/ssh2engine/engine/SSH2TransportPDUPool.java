package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2TransportPDUPool extends SSH2TransportPDU {

    final static int POOL_SIZE = 32;

    protected class InPDU extends SSH2TransportPDU {
	protected InPDU(int pktType, int bufSize) {
	    super(pktType, bufSize);
	}
	public void release() {
	    this.reset();
	    this.pktSize = 0;
	    releaseIn(this);
	}
    }

    protected class OutPDU extends SSH2TransportPDU {
	protected OutPDU(int pktType, int bufSize) {
	    super(pktType, bufSize);
	}
	public void release() {
	    this.reset();
	    this.pktSize = 0;
	    releaseOut(this);
	}
    }

    int inCnt;
    int outCnt;

    SSH2TransportPDU[] inPool;
    SSH2TransportPDU[] outPool;

    protected SSH2TransportPDUPool() {
	inPool  = new SSH2TransportPDU[POOL_SIZE];
	outPool = new SSH2TransportPDU[POOL_SIZE];
	inCnt   = POOL_SIZE;
	outCnt  = POOL_SIZE;
	for(int i = 0; i < POOL_SIZE; i++) {
	    inPool[i]  = new InPDU(0, PACKET_DEFAULT_SIZE);
	    outPool[i] = new OutPDU(0, PACKET_DEFAULT_SIZE * 2);
	}
    }

    protected SSH2TransportPDU createInPDU(int bufSize) {
	synchronized(inPool) {
	    if(inCnt == 0) {
		return new InPDU(0, PACKET_DEFAULT_SIZE);
	    } else {
		return inPool[--inCnt];
	    }
	}
    }

    protected SSH2TransportPDU createOutPDU(int pktType, int bufSize) {
	if(bufSize > (PACKET_DEFAULT_SIZE * 2)) {
	    return new SSH2TransportPDU(pktType, bufSize);
	}
	SSH2TransportPDU pdu = null;
	synchronized(outPool) {
	    if(outCnt == 0) {
		return new OutPDU(pktType, (PACKET_DEFAULT_SIZE * 2));
	    } else {
		pdu = outPool[--outCnt];
	    }
	}
	pdu.pktType = pktType;
	return pdu;
    }

    protected void releaseIn(InPDU pdu) {
	synchronized(inPool) {
	    if(inCnt < POOL_SIZE) {
		inPool[inCnt++] = pdu;
	    } else {
		/* stat */
	    }
	}
    }

    protected void releaseOut(OutPDU pdu) {
	synchronized(outPool) {
	    if(outCnt < POOL_SIZE) {
		outPool[outCnt++] = pdu;
	    } else {
		/* stat */
	    }
	}
    }

}
