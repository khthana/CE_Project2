package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2CompressionException extends SSH2FatalException {

    public SSH2CompressionException(String message) {
	super(message, null);
    }

}
