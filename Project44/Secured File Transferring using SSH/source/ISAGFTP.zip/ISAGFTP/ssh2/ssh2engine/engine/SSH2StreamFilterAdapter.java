package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.InputStream;
import java.io.OutputStream;

public class SSH2StreamFilterAdapter implements SSH2StreamFilter {
    public InputStream getInputFilter(InputStream toBeFiltered) {
	return toBeFiltered;
    }

    public OutputStream getOutputFilter(OutputStream toBeFiltered) {
	return toBeFiltered;
    }
}
