package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2AccessDeniedException extends SSH2Exception {
    public SSH2AccessDeniedException(String message) {
	super(message);
    }
}
