package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.File;
import java.io.OutputStream;

public final class SSH2SCP1Client extends SSH2ConsoleRemote {

    private SSHSCP1 scp1;

    public SSH2SCP1Client(File cwd, SSH2Connection connection,
			  OutputStream stderr, boolean verbose) {
	super(connection, stderr);
	this.scp1 = new SSHSCP1(cwd, this, verbose);
    }

    public SSHSCP1 scp1() {
	return scp1;
    }

}
