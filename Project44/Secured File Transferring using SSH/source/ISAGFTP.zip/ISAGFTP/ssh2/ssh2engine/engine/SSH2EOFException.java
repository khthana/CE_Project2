package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2EOFException extends SSH2Exception {

    public SSH2EOFException(String message) {
	super(message, null);
    }

}
