package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;

public class SSH2ConsoleRemote implements SSHConsoleRemote {

    protected SSH2Connection     connection;
    protected SSH2SessionChannel session;
    protected OutputStream       stderr;

    public SSH2ConsoleRemote(SSH2Connection connection) {
	this(connection, null);
    }

    public SSH2ConsoleRemote(SSH2Connection connection, OutputStream stderr) {
	this.connection = connection;
	this.stderr     = stderr;
    }

    public boolean command(String command) {
	session = connection.newSession();
	if(stderr != null) {
	    session.changeStdErr(stderr);
	}
	return session.doSingleCommand(command);
    }

    public boolean connect() {
	session = connection.newSession();
	return session.doShell();
    }

    public void close() {
	session.close();
	session = null;
    }

    public void changeStdOut(OutputStream out) {
	session.changeStdOut(out);
    }

    public InputStream getStdOut() {
	return session.getStdOut();
    }

    public OutputStream getStdIn() {
	return session.getStdIn();
    }

}
