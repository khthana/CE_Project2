package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.OutputStream;
import java.io.IOException;

import ISAGFTP.ssh2.ssh2engine.terminal.TerminalWin;
import ISAGFTP.ssh2.ssh2engine.terminal.TerminalInputListener;

public class SSH2TerminalAdapterImpl implements SSH2TerminalAdapter,
						TerminalInputListener {
    TerminalWin        terminal;
    SSH2SessionChannel session;
    TerminalOutStream  stdout;

    final class TerminalOutStream extends OutputStream {
	public void write(int b) throws IOException {
	    terminal.write((char)b);
	}
	public void write(byte b[], int off, int len) throws IOException {
	    terminal.write(b, off, len);
	}
    }

    public SSH2TerminalAdapterImpl(TerminalWin terminal) {
	this.terminal = terminal;
	this.stdout   = new TerminalOutStream();
    }

    public void attach(SSH2SessionChannel session) {
	this.session = session;
	session.changeStdOut(this.stdout);
	terminal.addInputListener(this);
    }

    public void detach() {
	if(terminal != null) {
	    terminal.removeInputListener(this);
	}
	// !!! TODO want to do this ?
	// session.changeStdOut(
    }

    public void typedChar(char c) {
	try {
	    session.stdin.write((int)c);
	} catch (IOException e) {
	    session.connection.getLog().error("SSH2TerminalAdapterImpl",
					      "typedChar",
					      "error writing to stdin: " +
					      e.getMessage());
	}
    }

    public void sendBytes(byte[] b) {
	try {
	    session.stdin.write(b, 0, b.length);
	} catch (IOException e) {
	    session.connection.getLog().error("SSH2TerminalAdapterImpl",
					      "sendBytes",
					      "error writing to stdin: " +
					      e.getMessage());
	}
    }

    public void signalWindowChanged(int rows, int cols,
				    int vpixels, int hpixels) {
	session.sendWindowChange(rows, cols);
    }

}
