package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2FatalException extends SSH2Exception {

    public SSH2FatalException(String message) {
	this(message, null);
    }

    public SSH2FatalException(String message, Throwable rootCause) {
        super(message, rootCause);
    }

}
