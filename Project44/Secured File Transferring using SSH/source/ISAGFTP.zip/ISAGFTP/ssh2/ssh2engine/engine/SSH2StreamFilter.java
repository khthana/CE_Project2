package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.InputStream;
import java.io.OutputStream;

public interface SSH2StreamFilter {
    public InputStream getInputFilter(InputStream toBeFiltered);
    public OutputStream getOutputFilter(OutputStream toBeFiltered);
}
