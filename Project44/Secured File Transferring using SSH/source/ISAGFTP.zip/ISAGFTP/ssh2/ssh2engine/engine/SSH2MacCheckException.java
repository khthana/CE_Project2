package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2MacCheckException extends SSH2FatalException {

    public SSH2MacCheckException(String message) {
	super(message, null);
    }

}
