package ISAGFTP.ssh2.ssh2engine.engine;

import java.util.Hashtable;

import ISAGFTP.ssh2.ssh2engine.jca.security.MessageDigest;

public abstract class SSH2KeyExchanger {

    private static Hashtable algorithms;

    static {
	algorithms = new Hashtable();

	algorithms.put("diffie-hellman-group1-sha1",
		       SSH2KEXDHGroup1SHA1.class);
	algorithms.put("diffie-hellman-group-exchange-sha1",
		       SSH2KEXDHGroupXSHA1.class);
    }

    protected SSH2KeyExchanger() {
    }

    public static SSH2KeyExchanger getInstance(String algorithm)
	throws SSH2KEXFailedException
    {
	Class            alg = (Class)algorithms.get(algorithm);
	SSH2KeyExchanger kex = null;
	if(alg != null) {
	    try {
		kex = (SSH2KeyExchanger)alg.newInstance();
	    } catch (Throwable t) {
		kex = null;
	    }
	}
	if(kex == null) {
	    throw new SSH2KEXFailedException("Unknown kex algorithm: " +
					     algorithm);
	}
	return kex;
    }

    public abstract void init(SSH2Transport transport) throws SSH2Exception;

    public abstract void processKEXMethodPDU(SSH2TransportPDU pdu)
	throws SSH2Exception;

    public abstract MessageDigest getExchangeHashAlgorithm();

    public abstract byte[] getSharedSecret_K();

    public abstract byte[] getExchangeHash_H();

    public abstract String getHostKeyAlgorithms();

}
