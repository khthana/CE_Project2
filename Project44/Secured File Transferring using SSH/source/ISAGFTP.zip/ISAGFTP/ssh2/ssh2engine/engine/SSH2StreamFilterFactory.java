package ISAGFTP.ssh2.ssh2engine.engine;

public interface SSH2StreamFilterFactory {
    public SSH2StreamFilter createFilter(SSH2Connection connection,
					 SSH2StreamChannel channel);

}
