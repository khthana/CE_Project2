package ISAGFTP.ssh2.ssh2engine.engine;

public class SSH2UserCancelException extends SSH2Exception {

    public SSH2UserCancelException(String message) {
        super(message, null);
    }

}
