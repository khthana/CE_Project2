package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.InetAddress;

public class SSH2RetryingTCPChannel extends SSH2TCPChannel {

    private int  numOfRetries;
    private long retryDelayTime;

    public SSH2RetryingTCPChannel(int channelType, SSH2Connection connection,
				  Object creator,
				  Socket endpoint,
				  String remoteAddr, int remotePort,
				  String originAddr, int originPort)
	throws IOException
    {
	super(channelType, connection, creator,
	      endpoint, remoteAddr, remotePort, originAddr, originPort);
	this.numOfRetries   = 3;
	this.retryDelayTime = 200L;
    }

    protected void setRetries(int numOfRetries) {
	this.numOfRetries = numOfRetries;
    }

    public void setRetryDelay(long retryDelayTime) {
	this.retryDelayTime = retryDelayTime;
    }

    protected boolean openFailureImpl(int reasonCode, String reasonText,
				      String langTag) {
	boolean retry = true;
	if(numOfRetries > 0) {
	    if(getCreator() instanceof SSH2Listener) {
		try {
		    Thread.sleep(retryDelayTime);
		} catch (InterruptedException e) {
		}
		connection.getLog().notice("SSH2RetryingTCPChannel",
					   "retry (" + numOfRetries +
					   ") connection on ch. #" + getId() +
					   " to " + remoteAddr + ":" + remotePort);
		SSH2Listener listener = (SSH2Listener)getCreator();
		listener.sendChannelOpen(this, endpoint);
	    } else {
		connection.getLog().error("SSH2RetryingTCPChannel",
					  "openFailureImpl",
					  "unexpected use of this class");
	    }
	} else {
	    outputClosed();
	    retry = false;
	}
	numOfRetries--;

	return retry;
    }

}
