package ISAGFTP.ssh2.ssh2engine.engine;

public interface SSH2TerminalAdapter {
    public void attach(SSH2SessionChannel session);
    public void detach();
}
