package ISAGFTP.ssh2.ssh2engine.engine;

public interface SSH2Interactor {
    public String promptLine(String prompt, boolean echo)
	throws SSH2UserCancelException;
    public String[] promptMulti(String[] prompts, boolean[] echos)
	throws SSH2UserCancelException;
    public String[] promptMultiFull(String name, String instruction,
			     String[] prompts, boolean[] echos)
	throws SSH2UserCancelException;
    public int promptList(String name, String instruction, String[] choices)
	throws SSH2UserCancelException;
}
