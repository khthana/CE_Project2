package ISAGFTP.ssh2.ssh2engine.engine;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.KeyFactory;
import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.RSAPublicKeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.interfaces.RSAPublicKey;

public final class SSH2RSA extends SSH2SimpleSignature {
    public final static String SSH2_KEY_FORMAT = "ssh-rsa";

    public SSH2RSA() {
	super("SHA1withRSA", SSH2_KEY_FORMAT);
    }

    public byte[] encodePublicKey(PublicKey publicKey) throws SSH2Exception {
	SSH2DataBuffer buf = new SSH2DataBuffer(8192);

	if(!(publicKey instanceof RSAPublicKey)) {
	    throw new SSH2FatalException("SSH2RSA, invalid public key type: " +
					 publicKey);
	}

	RSAPublicKey rsaPubKey = (RSAPublicKey)publicKey;

	buf.writeString(SSH2_KEY_FORMAT);
	buf.writeBigInt(rsaPubKey.getPublicExponent());
	buf.writeBigInt(rsaPubKey.getModulus());

	return buf.readRestRaw();
    }

    public PublicKey decodePublicKey(byte[] pubKeyBlob) throws SSH2Exception {
	BigInteger e, n;
	SSH2DataBuffer buf = new SSH2DataBuffer(pubKeyBlob.length);

	buf.writeRaw(pubKeyBlob);

	String type = buf.readJavaString();
	if(!type.equals(SSH2_KEY_FORMAT)) {
	    throw new SSH2FatalException("SSH2RSA, keyblob type mismatch, got '"
					 + type + ", (execpted + '" +
					 SSH2_KEY_FORMAT + "')");
	}

	e = buf.readBigInt();
	n = buf.readBigInt();

	try {
	    KeyFactory       rsaKeyFact = KeyFactory.getInstance("RSA");
	    RSAPublicKeySpec rsaPubSpec = new RSAPublicKeySpec(n, e);

	    return rsaKeyFact.generatePublic(rsaPubSpec);

	} catch (Exception ee) {
	    throw new SSH2FatalException("SSH2RSA, error decoding public key blob: " +
					 ee);
	}
    }

}
