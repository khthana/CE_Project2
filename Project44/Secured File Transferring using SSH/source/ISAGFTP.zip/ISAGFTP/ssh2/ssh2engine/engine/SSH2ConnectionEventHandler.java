package ISAGFTP.ssh2.ssh2engine.engine;

import java.net.Socket;

public interface SSH2ConnectionEventHandler
{

    public void channelAdded(SSH2Connection connection, SSH2Channel channel);


    public void channelDeleted(SSH2Connection connection, SSH2Channel channel);

   
    public void channelClosed(SSH2Connection connection, SSH2Channel channel);

    
    public void listenerAccept(SSH2Listener listener, Socket fwdSocket);

  
    public void listenerConnect(SSH2Listener listener, Socket fwdSocket);

    public void localForwardedConnect(SSH2Connection connection,
				    SSH2Listener listener,
				    SSH2Channel channel);
   
    public void localDirectConnect(SSH2Connection connection,
				   SSH2Listener listener,
				   SSH2Channel channel);

    public void localSessionConnect(SSH2Connection connection,
				    SSH2Channel channel);

    public void localX11Connect(SSH2Connection connection,
				SSH2Listener listener,
				SSH2Channel channel);

    public void localChannelOpenFailure(SSH2Connection connection,
					SSH2Channel channel,
					int reasonCode, String reasonText,
					String languageTag);

    public void remoteForwardedConnect(SSH2Connection connection,
				       String remoteAddr, int remotePort,
				       SSH2Channel channel);

    public void remoteDirectConnect(SSH2Connection connection,
				    SSH2Channel channel);

    public void remoteSessionConnect(SSH2Connection connection,
				     String remoteAddr, int remotePort,
				     SSH2Channel channel);

    public void remoteX11Connect(SSH2Connection connection,
				 SSH2Channel channel);

    public void remoteChannelOpenFailure(SSH2Connection connection,
					 String channelType,
					 String targetAddr, int targetPort,
					 String originAddr, int originPort,
					 SSH2Exception cause);

}
