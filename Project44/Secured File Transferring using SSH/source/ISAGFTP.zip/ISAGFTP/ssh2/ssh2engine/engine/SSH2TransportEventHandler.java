package ISAGFTP.ssh2.ssh2engine.engine;

import java.io.IOException;

public interface SSH2TransportEventHandler {

    public void gotConnectInfoText(SSH2Transport tp, String text);

    public void gotPeerVersion(SSH2Transport tp, String versionString,
			       int major, int minor, String packageVersion);

    public void kexStart(SSH2Transport tp);

    public void kexAgreed(SSH2Transport tp,
			  SSH2TransportPreferences ourPrefs,
			  SSH2TransportPreferences peerPrefs);

    public boolean kexAuthenticateHost(SSH2Transport tp,
				       SSH2Signature serverHostKey);

    public void kexComplete(SSH2Transport tp);

    public void msgDebug(SSH2Transport tp, boolean alwaysDisplay,
			 String message, String languageTag);

    public void msgIgnore(SSH2Transport tp, byte[] data);

    public void msgUnimplemented(SSH2Transport tp, int rejectedSeqNum);

    public void peerSentUnknownMessage(SSH2Transport tp, int pktType);

    public void normalDisconnect(SSH2Transport tp, String description,
				 String languageTag);

    public void fatalDisconnect(SSH2Transport tp, int reason,
				String description, String languageTag);

    public void peerDisconnect(SSH2Transport tp, int reason,
			       String description, String languageTag);

}
