package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1IA5String extends ASN1String {

    public ASN1IA5String() {
	super(ASN1.TAG_IA5STRING);
    }

}
