package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1Sequence extends ASN1Structure {

    protected ASN1Sequence(int size) {
	super(ASN1.TAG_SEQUENCE, size);
    }

}
