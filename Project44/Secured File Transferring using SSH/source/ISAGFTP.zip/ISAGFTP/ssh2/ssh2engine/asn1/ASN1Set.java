package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1Set extends ASN1Structure {

    protected ASN1Set(int size) {
	super(ASN1.TAG_SET, size);
    }

}
