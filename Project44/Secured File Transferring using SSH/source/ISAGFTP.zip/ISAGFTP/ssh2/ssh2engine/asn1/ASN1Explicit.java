package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1Explicit extends ASN1Structure {

    protected ASN1Explicit(int tag, ASN1Object underlying) {
	super(tag, 1);
	setComponent(0, underlying);
    }

}
