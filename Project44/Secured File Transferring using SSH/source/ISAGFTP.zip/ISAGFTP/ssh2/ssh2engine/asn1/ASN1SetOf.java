package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1SetOf extends ASN1Set {

    protected ASN1SetOf(Class type) {
	super(5);
	this.ofType = type;
    }

}
