package ISAGFTP.ssh2.ssh2engine.asn1;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public class ASN1Implicit extends ASN1Object {

    protected ASN1Object underlying;

    protected ASN1Implicit(int tag, ASN1Object underlying) {
	super(tag | (underlying.getTag() & ASN1.TYPE_CONSTRUCTED));
	this.underlying = underlying;
    }

    public int encodeValue(ASN1Encoder encoder, OutputStream out)
    	throws IOException
    {
	return underlying.encodeValue(encoder, out);
    }

    public void decodeValue(ASN1Decoder decoder, InputStream in, int length)
	throws IOException
    {
	underlying.decodeValue(decoder, in, length);
    }

}
