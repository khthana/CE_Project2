package ISAGFTP.ssh2.ssh2engine.asn1;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public abstract class ASN1Object {

    protected int tag;

    protected ASN1Object(int tag) {
	this.tag = tag;
    }

    public final int getTag() {
	return tag;
    }

    public abstract int encodeValue(ASN1Encoder encoder, OutputStream out)
	throws IOException;

    public abstract void decodeValue(ASN1Decoder decoder,
				     InputStream in, int len)
	throws IOException;

}
