package ISAGFTP.ssh2.ssh2engine.asn1;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class ASN1Integer extends ASN1Object {

    private BigInteger value;

    public ASN1Integer() {
	super(ASN1.TAG_INTEGER);
    }

    public int encodeValue(ASN1Encoder encoder, OutputStream out)
    	throws IOException
    {
	return encoder.encodeInteger(out, value);
    }

    public void decodeValue(ASN1Decoder decoder, InputStream in, int len)
    	throws IOException
    {
	value = decoder.decodeInteger(in, len);
    }

    public void setValue(BigInteger value) {
	this.value = value;
    }

    public void setValue(long value) {
	this.value = BigInteger.valueOf(value);
    }

    public BigInteger getValue() {
	return value;
    }

}
