package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1OctetString extends ASN1String {

    public ASN1OctetString() {
	super(ASN1.TAG_OCTETSTRING);
    }

}
