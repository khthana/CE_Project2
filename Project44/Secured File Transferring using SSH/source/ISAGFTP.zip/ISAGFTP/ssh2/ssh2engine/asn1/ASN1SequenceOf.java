package ISAGFTP.ssh2.ssh2engine.asn1;

public class ASN1SequenceOf extends ASN1Sequence {

    protected ASN1SequenceOf(Class type) {
	super(5);
	this.ofType = type;
    }

}
