package ISAGFTP.ssh2.ssh2engine.util;

public interface Progress {
	public void progress(int value);
}