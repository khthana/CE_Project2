package ISAGFTP.ssh2.ssh2engine.util;

public final class StringUtil {
    public static String trimLeft(String str) {
	char[] val = str.toCharArray();
	int st = 0;
	while ((st < val.length) && (val[st] <= ' ')) {
	    st++;
	}
	return str.substring(st);
    }

    public static String trimRight(String str) {
	char[] val = str.toCharArray();
	int    end = val.length;
	while ((end > 0) && (val[end - 1] <= ' ')) {
	    end--;
	}
	return str.substring(0, end);
    }
}
