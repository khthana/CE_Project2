package ssh2.ssh2engine.terminal;

public interface TerminalClipboardHandler {
    public void   setSelection(String selection);
    public String getSelection();
    public void   clearSelection();
}
