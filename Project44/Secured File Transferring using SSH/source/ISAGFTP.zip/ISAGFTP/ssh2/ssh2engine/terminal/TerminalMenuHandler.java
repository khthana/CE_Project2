package ssh2.ssh2engine.terminal;

public class TerminalMenuHandler {
    public void setTerminalWin(TerminalWin term) {
    }
    public void setTerminalMenuListener(TerminalMenuListener listener) {
    }
    public void updateSelection(boolean selectionAvailable) {
    }
    public void update() {
    }
    public void setEnabledOpt(int opt, boolean val) {
    }
    public void setStateOpt(int opt, boolean val) {
    }
}
