package ssh2.ssh2engine.terminal;

public interface TerminalOutputListener {
    public void write(char c);
    public void write(char[] c, int off, int len);
    public void write(byte[] c, int off, int len);
}
