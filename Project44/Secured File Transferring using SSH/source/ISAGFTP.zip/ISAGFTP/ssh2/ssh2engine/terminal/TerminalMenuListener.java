package ssh2.ssh2engine.terminal;

public interface TerminalMenuListener {
    public void update();
    public void close(TerminalMenuHandler originMenu);
}
