package ISAGFTP.ssh2.ssh2engine.jca.security.spec;

import ISAGFTP.ssh2.ssh2engine.jca.security.GeneralSecurityException;

public class InvalidKeySpecException extends GeneralSecurityException {

    public InvalidKeySpecException() {
	super();
    }

    public InvalidKeySpecException(String msg) {
	super(msg);
    }

}
