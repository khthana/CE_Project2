package ISAGFTP.ssh2.ssh2engine.jca.security;

public class DigestException extends GeneralSecurityException {
	public DigestException() { super(); }
	public DigestException(String msg) { super(msg); }
}