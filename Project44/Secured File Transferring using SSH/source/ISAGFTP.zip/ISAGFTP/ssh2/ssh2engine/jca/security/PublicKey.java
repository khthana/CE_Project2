package ISAGFTP.ssh2.ssh2engine.jca.security;

public interface PublicKey extends Key {
}
