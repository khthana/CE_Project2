package ISAGFTP.ssh2.ssh2engine.jca.security;

public class NoSuchAlgorithmException extends GeneralSecurityException {
	public NoSuchAlgorithmException() {	super(); }
	public NoSuchAlgorithmException(String msg) { super(msg); }
}