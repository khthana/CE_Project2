package ISAGFTP.ssh2.ssh2engine.jca.security;

public class SignatureException extends GeneralSecurityException {
	public SignatureException() { super(); }
	public SignatureException(String msg) {	super(msg); }
}