package ISAGFTP.ssh2.ssh2engine.jca.security.spec;

import ISAGFTP.ssh2.ssh2engine.jca.security.GeneralSecurityException;

public class InvalidParameterSpecException extends GeneralSecurityException {

    public InvalidParameterSpecException() {
	super();
    }

    public InvalidParameterSpecException(String msg) {
	super(msg);
    }

}
