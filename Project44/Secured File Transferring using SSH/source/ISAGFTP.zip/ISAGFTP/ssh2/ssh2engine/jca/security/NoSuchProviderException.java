package ISAGFTP.ssh2.ssh2engine.jca.security;

public class NoSuchProviderException extends GeneralSecurityException {
	public NoSuchProviderException() { super(); }
	public NoSuchProviderException(String msg) { super(msg); }
}