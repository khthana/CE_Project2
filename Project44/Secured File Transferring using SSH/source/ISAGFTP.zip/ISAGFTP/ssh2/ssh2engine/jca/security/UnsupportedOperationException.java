package ISAGFTP.ssh2.ssh2engine.jca.security;

public class UnsupportedOperationException extends RuntimeException {
	public UnsupportedOperationException() { super(); }
	public UnsupportedOperationException(String msg) { super(msg); }
}