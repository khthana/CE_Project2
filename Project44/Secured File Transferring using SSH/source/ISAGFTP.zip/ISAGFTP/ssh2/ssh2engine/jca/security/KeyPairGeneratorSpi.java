package ISAGFTP.ssh2.ssh2engine.jca.security;

import ISAGFTP.ssh2.ssh2engine.jca.security.SecureRandom;
import ISAGFTP.ssh2.ssh2engine.jca.security.KeyPair;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidAlgorithmParameterException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.AlgorithmParameterSpec;

public abstract class KeyPairGeneratorSpi {

    public KeyPairGeneratorSpi() {
    }

    public abstract void initialize(int keysize, SecureRandom random);

    public void initialize(AlgorithmParameterSpec params, SecureRandom random)
	throws InvalidAlgorithmParameterException
    {
	throw new UnsupportedOperationException(
	"'initialize(AlgorithmParameterSpec, SecureRandom)' not supported");
    }

    public abstract KeyPair generateKeyPair();

}
