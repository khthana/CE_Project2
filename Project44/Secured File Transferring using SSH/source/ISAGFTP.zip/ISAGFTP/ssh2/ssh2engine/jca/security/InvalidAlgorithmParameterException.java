package ISAGFTP.ssh2.ssh2engine.jca.security;

public class InvalidAlgorithmParameterException
extends GeneralSecurityException {
	public InvalidAlgorithmParameterException(String msg) { super(msg); }
}