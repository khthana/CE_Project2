package ISAGFTP.ssh2.ssh2engine.jca.security.interfaces;

import java.math.BigInteger;

public interface RSAKey {
    public BigInteger getModulus();
}
