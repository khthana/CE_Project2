package ISAGFTP.ssh2.ssh2engine.jca.security.interfaces;

public interface DSAKey {
    public DSAParams getParams();
}
