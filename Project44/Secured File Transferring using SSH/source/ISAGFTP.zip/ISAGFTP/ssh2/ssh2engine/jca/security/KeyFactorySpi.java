package ISAGFTP.ssh2.ssh2engine.jca.security;

import ISAGFTP.ssh2.ssh2engine.jca.security.spec.KeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.InvalidKeySpecException;

public abstract class KeyFactorySpi {

    public KeyFactorySpi() {
    }

    protected abstract PublicKey engineGeneratePublic(KeySpec keySpec)
	throws InvalidKeySpecException;

    protected abstract PrivateKey engineGeneratePrivate(KeySpec keySpec)
	throws InvalidKeySpecException;

    protected abstract KeySpec engineGetKeySpec(Key key, Class keySpec)
	throws InvalidKeySpecException;

    protected abstract Key engineTranslateKey(Key key)
	throws InvalidKeyException;

}
