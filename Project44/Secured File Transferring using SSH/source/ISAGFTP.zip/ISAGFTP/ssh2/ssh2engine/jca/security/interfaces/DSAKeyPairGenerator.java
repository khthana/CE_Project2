package ISAGFTP.ssh2.ssh2engine.jca.security.interfaces;

import ISAGFTP.ssh2.ssh2engine.jca.security.SecureRandom;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidParameterException;

public interface DSAKeyPairGenerator {
    public void initialize(DSAParams params, SecureRandom random)
	throws InvalidParameterException;
    public void initialize(int modlen, boolean genParams, SecureRandom random)
	throws InvalidParameterException;
}
