package ISAGFTP.ssh2.ssh2engine.jca.security.interfaces;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;

public interface DSAPrivateKey extends DSAKey, PrivateKey {
    public BigInteger getX();
}
