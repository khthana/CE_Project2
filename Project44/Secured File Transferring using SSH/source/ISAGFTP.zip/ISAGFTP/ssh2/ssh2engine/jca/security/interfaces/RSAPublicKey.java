package ISAGFTP.ssh2.ssh2engine.jca.security.interfaces;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;

public interface RSAPublicKey extends RSAKey, PublicKey {
    public BigInteger getPublicExponent();
}
