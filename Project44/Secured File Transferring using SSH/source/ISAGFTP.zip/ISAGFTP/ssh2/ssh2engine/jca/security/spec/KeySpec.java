package ISAGFTP.ssh2.ssh2engine.jca.security.spec;

public interface KeySpec {
}
