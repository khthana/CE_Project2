package ISAGFTP.ssh2.ssh2engine.jca.security;

import java.util.Properties;
import java.util.Vector;
import java.util.Enumeration;

public final class Security {

	private static Vector providers;

	static {
		providers = new Vector();
	};

	public static int addProvider(Provider provider) {
		if(getProvider(provider.getName()) != null)
			return -1;
		providers.addElement(provider);
		return providers.size();
	}

	public static Provider getProvider(String name) {

		// !!! REMOVE !!! shortcircuit
		//
		if(providers.size() == 0) {
			providers.addElement(new ISAGFTP.ssh2.ssh2engine.security.Mindbright());
		}

		Enumeration enum = providers.elements();
		while(enum.hasMoreElements()) {
			Provider prov = (Provider)enum.nextElement();
			if(prov.getName().equals(name)) {
				return prov;
			}
		}
		return null;
	}

		public static String getAlgorithmProperty(String algName, String propName) {
	return null;
		}

		public static String getProperty(String key) {
	return null;
		}

		public static Provider[] getProviders() {
	return null;
		}

		/*
		public static Provider[] getProviders(Map filter) {
		}
		*/

		public static Provider[] getProviders(String filter) {
	return null;
		}

		public static int insertProviderAt(Provider provider, int position) {
	return 0;
		}

		public static void removeProvider(String name) {
		}

		public static void setProperty(String key, String datum) {
		}

}
