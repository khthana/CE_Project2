package ISAGFTP.ssh2.ssh2engine.jca.security;

public class KeyException extends GeneralSecurityException {
	public KeyException() { super(); }
	public KeyException(String msg) {	super(msg); }
}