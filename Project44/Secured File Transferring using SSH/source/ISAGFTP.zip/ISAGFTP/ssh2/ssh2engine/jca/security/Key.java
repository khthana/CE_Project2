package ISAGFTP.ssh2.ssh2engine.jca.security;

public interface Key extends java.io.Serializable {
    public String getAlgorithm();
    public String getFormat();
    public byte[] getEncoded();
}
