package ISAGFTP.ssh2.ssh2engine.jca.security;

public class InvalidParameterException extends IllegalArgumentException {
	public InvalidParameterException() { super(); }
	public InvalidParameterException(String msg) { super(msg); }
}