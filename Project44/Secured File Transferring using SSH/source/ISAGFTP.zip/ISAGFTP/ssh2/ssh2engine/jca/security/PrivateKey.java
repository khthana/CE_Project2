package ISAGFTP.ssh2.ssh2engine.jca.security;

public interface PrivateKey extends Key {
}
