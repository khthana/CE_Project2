package ISAGFTP.ssh2.ssh2engine.jca.security;

public class GeneralSecurityException extends Exception {
	public GeneralSecurityException() { super(); }
	public GeneralSecurityException(String msg) { super(msg); }
}