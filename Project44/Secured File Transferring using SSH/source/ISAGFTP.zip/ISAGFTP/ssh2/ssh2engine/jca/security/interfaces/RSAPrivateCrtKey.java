package ISAGFTP.ssh2.ssh2engine.jca.security.interfaces;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;

public interface RSAPrivateCrtKey extends RSAPrivateKey {
    public BigInteger getCrtCoefficient();
    public BigInteger getPrimeExponentP();
    public BigInteger getPrimeExponentQ();
    public BigInteger getPrimeP();
    public BigInteger getPrimeQ();
    public BigInteger getPublicExponent();
}
