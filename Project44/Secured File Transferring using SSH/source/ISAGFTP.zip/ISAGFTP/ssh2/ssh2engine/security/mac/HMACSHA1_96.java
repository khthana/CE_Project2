package ISAGFTP.ssh2.ssh2engine.security.mac;

public final class HMACSHA1_96 extends HMACSHA1 {
    public HMACSHA1_96() {
	super();
	macLength = 96 / 8;
    }
}
