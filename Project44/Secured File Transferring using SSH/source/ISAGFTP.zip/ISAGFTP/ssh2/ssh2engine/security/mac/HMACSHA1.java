package ISAGFTP.ssh2.ssh2engine.security.mac;

public class HMACSHA1 extends HMAC {
    public HMACSHA1() {
	super("SHA1");
    }
}
