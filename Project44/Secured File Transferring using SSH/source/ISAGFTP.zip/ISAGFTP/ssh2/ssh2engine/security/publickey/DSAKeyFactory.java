package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.Key;
import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.KeyFactorySpi;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidKeyException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.KeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.DSAPublicKeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.DSAPrivateKeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.InvalidKeySpecException;

public class DSAKeyFactory extends KeyFactorySpi {

    protected PublicKey engineGeneratePublic(KeySpec keySpec)
	throws InvalidKeySpecException {
	if(!(keySpec instanceof DSAPublicKeySpec)) {
	    throw new InvalidKeySpecException("KeySpec " + keySpec +
					      ", not supported");
	}
	DSAPublicKeySpec dsaPub = (DSAPublicKeySpec)keySpec;
	return new DSAPublicKey(dsaPub.getY(),
				dsaPub.getP(), dsaPub.getQ(), dsaPub.getG());
    }

    protected PrivateKey engineGeneratePrivate(KeySpec keySpec)
	throws InvalidKeySpecException
    {
	if(!(keySpec instanceof DSAPrivateKeySpec)) {
	    throw new InvalidKeySpecException("KeySpec " + keySpec +
					      ", not supported");
	}
	DSAPrivateKeySpec dsaPrv = (DSAPrivateKeySpec)keySpec;
	return new DSAPrivateKey(dsaPrv.getX(),
				 dsaPrv.getP(), dsaPrv.getQ(), dsaPrv.getG());
    }

    protected KeySpec engineGetKeySpec(Key key, Class keySpec)
	throws InvalidKeySpecException {
	// !!! TODO
	return null;
    }

    protected Key engineTranslateKey(Key key)
	throws InvalidKeyException {
	// !!! TODO
	return null;
    }

}
