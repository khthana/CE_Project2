package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.KeyPair;
import ISAGFTP.ssh2.ssh2engine.jca.security.KeyPairGenerator;
import ISAGFTP.ssh2.ssh2engine.jca.security.SecureRandom;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidAlgorithmParameterException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.AlgorithmParameterSpec;

public class RSAKeyPairGenerator extends KeyPairGenerator {

    protected SecureRandom random;
    protected int          keysize;

    public RSAKeyPairGenerator() {
	super("RSA");
    }

    public void initialize(int keysize, SecureRandom random) {
	this.random  = random;
	this.keysize = keysize;
    }

    public void initialize(AlgorithmParameterSpec params, SecureRandom random)
	throws InvalidAlgorithmParameterException
    {
	throw new Error("Not implemented: " +
			"'RSAKeyPairGenerator.initialize(int, SecureRandom)'");
    }

    public KeyPair generateKeyPair() {
	if(random == null) {
	    random = new SecureRandom();
	}
	return RSAAlgorithm.generateKeyPair(keysize, random);
    }

}
