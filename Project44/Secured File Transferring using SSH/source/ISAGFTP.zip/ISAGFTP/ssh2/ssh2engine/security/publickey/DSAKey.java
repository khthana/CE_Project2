package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.Key;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.DSAParameterSpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.interfaces.DSAParams;

public class DSAKey extends DSAParameterSpec
    implements ISAGFTP.ssh2.ssh2engine.jca.security.interfaces.DSAKey, Key {

    protected DSAKey(BigInteger p, BigInteger q, BigInteger g) {
	super(p, q, g);
    }

    public String getAlgorithm() {
	return "DSA";
    }

    public byte[] getEncoded() {
	return null;
    }

    public String getFormat() {
	return null;
    }

    public DSAParams getParams() {
	return this;
    }

}
