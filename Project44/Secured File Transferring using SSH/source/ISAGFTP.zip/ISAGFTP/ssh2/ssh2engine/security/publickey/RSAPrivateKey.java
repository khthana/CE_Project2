package ISAGFTP.ssh2.ssh2engine.security.publickey;

import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;

import java.math.BigInteger;

public class RSAPrivateKey extends RSAKey 
    implements ISAGFTP.ssh2.ssh2engine.jca.security.interfaces.RSAPrivateKey {

    protected BigInteger privateExponent;

    public RSAPrivateKey(BigInteger modulus, BigInteger privateExponent) {
	super(modulus);
	this.privateExponent = privateExponent;
    }

    public BigInteger getPrivateExponent() {
	return privateExponent;
    }

}
