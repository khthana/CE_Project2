package ISAGFTP.ssh2.ssh2engine.security.publickey;

public class RSAWithMD5 extends RSAWithAny {

    public RSAWithMD5() {
	super("MD5");
    }

}
