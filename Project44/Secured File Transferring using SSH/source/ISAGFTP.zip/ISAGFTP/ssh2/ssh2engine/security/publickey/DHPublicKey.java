package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

public class DHPublicKey extends DHKey
    implements ISAGFTP.ssh2.javax.crypto.interfaces.DHPublicKey
{
    protected BigInteger y;

    public DHPublicKey(BigInteger y, BigInteger p, BigInteger g) {
	super(p, g);
	this.y = y;
    }

    public BigInteger getY() {
	return y;
    }
}
