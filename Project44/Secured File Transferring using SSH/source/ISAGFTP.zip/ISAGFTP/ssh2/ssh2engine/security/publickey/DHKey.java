package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.Key;
import ISAGFTP.ssh2.javax.crypto.spec.DHParameterSpec;

public class DHKey extends DHParameterSpec
    implements ISAGFTP.ssh2.javax.crypto.interfaces.DHKey, Key
{

    protected DHKey(BigInteger p, BigInteger g) {
	super(p, g);
    }

    public String getAlgorithm() {
	return "DiffieHellman";
    }

    public String getFormat() {
	return null;
    }

    public byte[] getEncoded() {
	return null;
    }

    public DHParameterSpec getParams() {
	return this;
    }

}
