package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.Key;
import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.KeyFactorySpi;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidKeyException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.KeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.RSAPublicKeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.RSAPrivateKeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.RSAPrivateCrtKeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.InvalidKeySpecException;

public class RSAKeyFactory extends KeyFactorySpi {

    protected PublicKey engineGeneratePublic(KeySpec keySpec)
	throws InvalidKeySpecException
    {
	if(!(keySpec instanceof RSAPublicKeySpec)) {
	    throw new InvalidKeySpecException("KeySpec " + keySpec +
					      ", not supported");
	}
	RSAPublicKeySpec rsaPub = (RSAPublicKeySpec)keySpec;
	return new RSAPublicKey(rsaPub.getModulus(),
				rsaPub.getPublicExponent());
    }

    protected PrivateKey engineGeneratePrivate(KeySpec keySpec)
	throws InvalidKeySpecException
    {
	if(!(keySpec instanceof RSAPrivateKeySpec)) {
	    throw new InvalidKeySpecException("KeySpec " + keySpec +
					      ", not supported");
	}

	if(keySpec instanceof RSAPrivateCrtKeySpec) {
	    RSAPrivateCrtKeySpec rsaPrv = (RSAPrivateCrtKeySpec)keySpec;
	    return new RSAPrivateCrtKey(rsaPrv.getModulus(),
					rsaPrv.getPublicExponent(),
					rsaPrv.getPrivateExponent(),
					rsaPrv.getPrimeP(),
					rsaPrv.getPrimeQ(),
					rsaPrv.getPrimeExponentP(),
					rsaPrv.getPrimeExponentQ(),
					rsaPrv.getCrtCoefficient());
	} else {
	    RSAPrivateKeySpec rsaPrv = (RSAPrivateKeySpec)keySpec;
	    return new RSAPrivateKey(rsaPrv.getModulus(),
				     rsaPrv.getPrivateExponent());
	}
    }

    protected KeySpec engineGetKeySpec(Key key, Class keySpec)
	throws InvalidKeySpecException {
	// !!! TODO
	return null;
    }

    protected Key engineTranslateKey(Key key)
	throws InvalidKeyException {
	// !!! TODO
	return null;
    }

}
