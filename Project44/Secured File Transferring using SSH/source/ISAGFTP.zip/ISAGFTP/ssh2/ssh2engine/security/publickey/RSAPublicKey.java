package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

public class RSAPublicKey extends RSAKey
    implements ISAGFTP.ssh2.ssh2engine.jca.security.interfaces.RSAPublicKey {

    protected BigInteger publicExponent;

    public RSAPublicKey(BigInteger modulus, BigInteger publicExponent) {
	super(modulus);
	this.publicExponent = publicExponent;
    }

    public BigInteger getPublicExponent() {
	return publicExponent;
    }

}
