package ISAGFTP.ssh2.ssh2engine.security.publickey;

public class RSAWithMD2 extends RSAWithAny {

    public RSAWithMD2() {
	super("MD2");
    }

}
