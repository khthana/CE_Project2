package ISAGFTP.ssh2.ssh2engine.security.mac;

public class HMACRIPEMD160 extends HMAC {
    public HMACRIPEMD160() {
	super("RIPEMD160");
    }
}
