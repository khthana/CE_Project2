package ISAGFTP.ssh2.ssh2engine.security.publickey;

public class RSAWithSHA1 extends RSAWithAny {

    public RSAWithSHA1() {
	super("SHA1");
    }

}
