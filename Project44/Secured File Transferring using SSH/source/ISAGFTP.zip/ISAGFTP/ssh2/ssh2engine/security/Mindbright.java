package ISAGFTP.ssh2.ssh2engine.security;

import ISAGFTP.ssh2.ssh2engine.jca.security.Provider;

public class Mindbright extends Provider {

	public Mindbright() {
		super("Mindbright", 1.0, "Mindbright JCA/JCE provider v1.0");

		put("Cipher.DES",                   "ISAGFTP.ssh2.ssh2engine.security.cipher.DES");
		put("Cipher.DES/ECB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.DES");
		put("Cipher.DES/CBC",               "ISAGFTP.ssh2.ssh2engine.security.cipher.DES");
		put("Cipher.DES/CFB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.DES");
		put("Cipher.DES/OFB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.DES");
		put("Cipher.3DES",                  "ISAGFTP.ssh2.ssh2engine.security.cipher.DES3");
		put("Cipher.3DES/ECB",              "ISAGFTP.ssh2.ssh2engine.security.cipher.DES3");
		put("Cipher.3DES/CBC",              "ISAGFTP.ssh2.ssh2engine.security.cipher.DES3");
		put("Cipher.3DES/CFB",              "ISAGFTP.ssh2.ssh2engine.security.cipher.DES3");
		put("Cipher.3DES/OFB",              "ISAGFTP.ssh2.ssh2engine.security.cipher.DES3");
		put("Cipher.3DES/CBC/PKCS5Padding", "ISAGFTP.ssh2.ssh2engine.security.cipher.DES3");
		put("Cipher.Blowfish",              "ISAGFTP.ssh2.ssh2engine.security.cipher.Blowfish");
		put("Cipher.Blowfish/ECB",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Blowfish");
		put("Cipher.Blowfish/CBC",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Blowfish");
		put("Cipher.Blowfish/CFB",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Blowfish");
		put("Cipher.Blowfish/OFB",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Blowfish");
		put("Cipher.Twofish",               "ISAGFTP.ssh2.ssh2engine.security.cipher.Twofish");
		put("Cipher.Twofish/ECB",           "ISAGFTP.ssh2.ssh2engine.security.cipher.Twofish");
		put("Cipher.Twofish/CBC",           "ISAGFTP.ssh2.ssh2engine.security.cipher.Twofish");
		put("Cipher.Twofish/CFB",           "ISAGFTP.ssh2.ssh2engine.security.cipher.Twofish");
		put("Cipher.Twofish/OFB",           "ISAGFTP.ssh2.ssh2engine.security.cipher.Twofish");
		put("Cipher.Rijndael",              "ISAGFTP.ssh2.ssh2engine.security.cipher.Rijndael");
		put("Cipher.Rijndael/ECB",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Rijndael");
		put("Cipher.Rijndael/CBC",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Rijndael");
		put("Cipher.Rijndael/CFB",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Rijndael");
		put("Cipher.Rijndael/OFB",          "ISAGFTP.ssh2.ssh2engine.security.cipher.Rijndael");
		put("Cipher.IDEA",                  "ISAGFTP.ssh2.ssh2engine.security.cipher.IDEA");
		put("Cipher.IDEA/ECB",              "ISAGFTP.ssh2.ssh2engine.security.cipher.IDEA");
		put("Cipher.IDEA/CBC",              "ISAGFTP.ssh2.ssh2engine.security.cipher.IDEA");
		put("Cipher.IDEA/CFB",              "ISAGFTP.ssh2.ssh2engine.security.cipher.IDEA");
		put("Cipher.IDEA/OFB",              "ISAGFTP.ssh2.ssh2engine.security.cipher.IDEA");
		put("Cipher.CAST128",               "ISAGFTP.ssh2.ssh2engine.security.cipher.CAST128");
		put("Cipher.CAST128/ECB",           "ISAGFTP.ssh2.ssh2engine.security.cipher.CAST128");
		put("Cipher.CAST128/CBC",           "ISAGFTP.ssh2.ssh2engine.security.cipher.CAST128");
		put("Cipher.CAST128/CFB",           "ISAGFTP.ssh2.ssh2engine.security.cipher.CAST128");
		put("Cipher.CAST128/OFB",           "ISAGFTP.ssh2.ssh2engine.security.cipher.CAST128");
		put("Cipher.RC2",                   "ISAGFTP.ssh2.ssh2engine.security.cipher.RC2");
		put("Cipher.RC2/ECB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.RC2");
		put("Cipher.RC2/CBC",               "ISAGFTP.ssh2.ssh2engine.security.cipher.RC2");
		put("Cipher.RC2/CFB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.RC2");
		put("Cipher.RC2/OFB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.RC2");
		put("Cipher.RC4/OFB",               "ISAGFTP.ssh2.ssh2engine.security.cipher.ArcFour");
		put("Alg.Alias.Cipher.AES",                     "Rijndael/ECB");
		put("Alg.Alias.Cipher.AES/ECB",                 "Rijndael/ECB");
		put("Alg.Alias.Cipher.AES/CBC",                 "Rijndael/CBC");
		put("Alg.Alias.Cipher.AES/CFB",                 "Rijndael/CFB");
		put("Alg.Alias.Cipher.AES/OFB",                 "Rijndael/OFB");
		put("Alg.Alias.Cipher.DESede",                  "3DES/ECB");
		put("Alg.Alias.Cipher.DESede/ECB",              "3DES/ECB");
		put("Alg.Alias.Cipher.DESede/CBC",              "3DES/CBC");
		put("Alg.Alias.Cipher.DESede/CFB",              "3DES/CFB");
		put("Alg.Alias.Cipher.DESede/OFB",              "3DES/OFB");
		put("Alg.Alias.Cipher.DESede/CBC/PKCS5Padding", "3DES/CBC/PKCS5Padding");
		put("Alg.Alias.Cipher.RC4",                     "RC4/OFB");
		put("Alg.Alias.Cipher.ArcFour",                 "RC4/OFB");
		put("Alg.Alias.Cipher.CAST5",                   "CAST128");
		put("Alg.Alias.Cipher.CAST5/ECB",               "CAST128/ECB");
		put("Alg.Alias.Cipher.CAST5/CBC",               "CAST128/CBC");
		put("Alg.Alias.Cipher.CAST5/CFB",               "CAST128/CFB");
		put("Alg.Alias.Cipher.CAST5/OFB",               "CAST128/OFB");

		put("MessageDigest.MD2",       "ISAGFTP.ssh2.ssh2engine.security.digest.MD2");
		put("MessageDigest.MD5",       "ISAGFTP.ssh2.ssh2engine.security.digest.MD5");
		put("MessageDigest.SHA",       "ISAGFTP.ssh2.ssh2engine.security.digest.SHA1");
		put("MessageDigest.RIPEMD160", "ISAGFTP.ssh2.ssh2engine.security.digest.RIPEMD160");
		put("Alg.Alias.MessageDigest.SHA-1", "SHA");
		put("Alg.Alias.MessageDigest.SHA1",  "SHA");

		put("Mac.HmacSHA1",         "ISAGFTP.ssh2.ssh2engine.security.mac.HMACSHA1");
		put("Mac.HmacMD5",          "ISAGFTP.ssh2.ssh2engine.security.mac.HMACMD5");
		put("Mac.HmacRIPEMD160",    "ISAGFTP.ssh2.ssh2engine.security.mac.HMACRIPEMD160");
		put("Mac.HmacSHA1-96",      "ISAGFTP.ssh2.ssh2engine.security.mac.HMACSHA1_96");
		put("Mac.HmacMD5-96",       "ISAGFTP.ssh2.ssh2engine.security.mac.HMACMD5_96");
		put("Mac.HmacRIPEMD160-96", "ISAGFTP.ssh2.ssh2engine.security.mac.HMACRIPEMD160_96");

		put("SecureRandom.BlumBlumShub", "ISAGFTP.ssh2.ssh2engine.security.prng.BlumBlumShub");

		put("Signature.SHA1withDSA",      "ISAGFTP.ssh2.ssh2engine.security.publickey.DSAWithSHA1");
		put("Signature.SHA1withRSA",      "ISAGFTP.ssh2.ssh2engine.security.publickey.RSAWithSHA1");
		put("Signature.MD5withRSA",       "ISAGFTP.ssh2.ssh2engine.security.publickey.RSAWithMD5");
		put("Signature.MD2withRSA",       "ISAGFTP.ssh2.ssh2engine.security.publickey.RSAWithMD2");
		put("Signature.RIPEMD160withRSA", "ISAGFTP.ssh2.ssh2engine.security.publickey.RSAWithRIPEMD160");

		put("KeyFactory.RSA", "ISAGFTP.ssh2.ssh2engine.security.publickey.RSAKeyFactory");
		put("KeyFactory.DSA", "ISAGFTP.ssh2.ssh2engine.security.publickey.DSAKeyFactory");
		put("KeyFactory.DH",  "ISAGFTP.ssh2.ssh2engine.security.publickey.DHKeyFactory");

		put("KeyPairGenerator.DH",  "ISAGFTP.ssh2.ssh2engine.security.publickey.DHKeyPairGenerator");
		put("KeyPairGenerator.RSA", "ISAGFTP.ssh2.ssh2engine.security.publickey.RSAKeyPairGenerator");
		put("KeyPairGenerator.DSA", "ISAGFTP.ssh2.ssh2engine.security.publickey.DSAKeyPairGenerator");

		put("KeyAgreement.DH", "ISAGFTP.ssh2.ssh2engine.security.publickey.DHKeyAgreement");
	}

}