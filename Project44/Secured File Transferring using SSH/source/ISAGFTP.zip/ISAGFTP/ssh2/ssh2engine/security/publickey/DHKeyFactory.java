package ISAGFTP.ssh2.ssh2engine.security.publickey;

import java.math.BigInteger;

import ISAGFTP.ssh2.ssh2engine.jca.security.Key;
import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.KeyFactorySpi;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidKeyException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.KeySpec;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.InvalidKeySpecException;

import ISAGFTP.ssh2.javax.crypto.spec.DHPublicKeySpec;
import ISAGFTP.ssh2.javax.crypto.spec.DHPrivateKeySpec;

public final class DHKeyFactory extends KeyFactorySpi {

    protected PublicKey engineGeneratePublic(KeySpec keySpec)
	throws InvalidKeySpecException
    {
	if(!(keySpec instanceof DHPublicKeySpec)) {
	    throw new InvalidKeySpecException("KeySpec " + keySpec +
					      ", not supported");
	}
	DHPublicKeySpec dhPub = (DHPublicKeySpec)keySpec;
	return new DHPublicKey(dhPub.getY(), dhPub.getP(), dhPub.getG());
    }

    protected PrivateKey engineGeneratePrivate(KeySpec keySpec)
	throws InvalidKeySpecException
    {
	if(!(keySpec instanceof DHPrivateKeySpec)) {
	    throw new InvalidKeySpecException("KeySpec " + keySpec +
					      ", not supported");
	}
	DHPrivateKeySpec dhPrv = (DHPrivateKeySpec)keySpec;
	return new DHPrivateKey(dhPrv.getX(), dhPrv.getP(), dhPrv.getG());
    }

    protected KeySpec engineGetKeySpec(Key key, Class keySpec)
	throws InvalidKeySpecException
    {
	// !!! TODO
	throw new Error("DHKeyFactory.engineGetKeySpec() not implemented");
    }

    protected Key engineTranslateKey(Key key) throws InvalidKeyException {
	// !!! TODO
	throw new Error("DHKeyFactory.engineTranslateKey() not implemented");
    }

}
