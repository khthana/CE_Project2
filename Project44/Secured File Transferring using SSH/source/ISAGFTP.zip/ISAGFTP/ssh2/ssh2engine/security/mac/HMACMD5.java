package ISAGFTP.ssh2.ssh2engine.security.mac;

public class HMACMD5 extends HMAC {
    public HMACMD5() {
	super("MD5");
    }
}
