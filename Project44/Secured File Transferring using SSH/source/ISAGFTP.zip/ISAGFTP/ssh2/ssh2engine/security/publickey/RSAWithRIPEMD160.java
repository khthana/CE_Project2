package ISAGFTP.ssh2.ssh2engine.security.publickey;

public class RSAWithRIPEMD160 extends RSAWithAny {

    public RSAWithRIPEMD160() {
	super("RIPEMD160");
    }

}
