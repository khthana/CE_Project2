package ISAGFTP.ssh2.ssh2engine.security.mac;

public class HMACMD5_96 extends HMACMD5 {
    public HMACMD5_96() {
	super();
	macLength = 96 / 8;
    }
}
