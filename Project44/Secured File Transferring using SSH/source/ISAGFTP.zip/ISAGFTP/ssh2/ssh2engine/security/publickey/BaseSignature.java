package ISAGFTP.ssh2.ssh2engine.security.publickey;

import ISAGFTP.ssh2.ssh2engine.jca.security.SignatureSpi;
import ISAGFTP.ssh2.ssh2engine.jca.security.MessageDigest;
import ISAGFTP.ssh2.ssh2engine.jca.security.SecureRandom;
import ISAGFTP.ssh2.ssh2engine.jca.security.PublicKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.PrivateKey;
import ISAGFTP.ssh2.ssh2engine.jca.security.SignatureException;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidKeyException;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidParameterException;
import ISAGFTP.ssh2.ssh2engine.jca.security.InvalidAlgorithmParameterException;
import ISAGFTP.ssh2.ssh2engine.jca.security.NoSuchAlgorithmException;
import ISAGFTP.ssh2.ssh2engine.jca.security.spec.AlgorithmParameterSpec;

public abstract class BaseSignature extends SignatureSpi {
    protected MessageDigest digest;
    protected PublicKey     publicKey;
    protected PrivateKey    privateKey;

    protected BaseSignature(String digAlg) {
	super();
	try {
	    this.digest = MessageDigest.getInstance(digAlg);
	} catch (NoSuchAlgorithmException e) {
	    throw new Error("Error in BaseSignature, no " + digAlg + " found");
	}
    }

    protected final void engineInitVerify(PublicKey publicKey)
	throws InvalidKeyException
    {
	this.publicKey = publicKey;
	initVerify();
    }

    protected final void engineInitSign(PrivateKey privateKey)
	throws InvalidKeyException
    {
	engineInitSign(privateKey, null);
    }

    protected final void engineInitSign(PrivateKey privateKey,
					SecureRandom random)
	throws InvalidKeyException
    {
	this.privateKey = privateKey;
	this.appRandom  = random;
	initSign();
    }

    protected void engineUpdate(byte b)	throws SignatureException {
	digest.update(b);
    }

    protected void engineUpdate(byte[] b, int off, int len)
	throws SignatureException
    {
	digest.update(b, off, len);
    }

    protected byte[] engineSign() throws SignatureException {
	return sign(digest.digest());
    }

    protected int engineSign(byte[] outbuf, int offset, int len)
	throws SignatureException
    {
	byte[] signature = sign(digest.digest());
	if(signature.length < len) {
	    len = signature.length;
	}
	System.arraycopy(signature, 0, outbuf, offset, len);
	return len;
    }

    protected boolean engineVerify(byte[] sigBytes) throws SignatureException {
	return verify(sigBytes, digest.digest());
    }

    protected void engineSetParameter(String param, Object value)
	throws InvalidParameterException
    {
	throw new InvalidParameterException("Param not supported: " + param);
    }

    protected void engineSetParameter(AlgorithmParameterSpec params)
	throws InvalidAlgorithmParameterException
    {
	throw new InvalidAlgorithmParameterException("Param not supported: " +
						     params);
    }

    protected Object engineGetParameter(String param)
	throws InvalidParameterException
    {
	throw new InvalidParameterException("Param not supported: " + param);
    }

    public Object clone() throws CloneNotSupportedException {
	throw new CloneNotSupportedException();
    }

    protected final SecureRandom getRandom() {
	if(appRandom == null) {
	    appRandom = new SecureRandom();
	}
	return appRandom;
    }

    protected abstract void initSign() throws InvalidKeyException;
    protected abstract void initVerify() throws InvalidKeyException;
    protected abstract byte[] sign(byte[] data) throws SignatureException;
    protected abstract boolean verify(byte[] signature, byte[] data)
	throws SignatureException;

}
