package ISAGFTP.ssh1.terminal;

public interface TerminalMenuListener {
  public void update();
}
