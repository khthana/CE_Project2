package ISAGFTP.ssh1.security;

public class KeyException extends GeneralSecurityException {
    public KeyException() {
	super();
    }

    public KeyException(String msg) {
	super(msg);
    }
}
