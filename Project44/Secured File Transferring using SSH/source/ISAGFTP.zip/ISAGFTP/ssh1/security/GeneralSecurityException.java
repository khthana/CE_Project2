package ISAGFTP.ssh1.security;

public class GeneralSecurityException extends Exception {
    public GeneralSecurityException() {
	super();
    }

    public GeneralSecurityException(String msg) {
	super(msg);
    }
}
