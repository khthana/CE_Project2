package ISAGFTP.ssh1.security;

public class NoSuchAlgorithmException extends GeneralSecurityException {
    public NoSuchAlgorithmException() {
	super();
    }

    public NoSuchAlgorithmException(String msg) {
	super(msg);
    }
}
