package ISAGFTP.ssh1.security;

public interface PrivateKey extends Key {
}
