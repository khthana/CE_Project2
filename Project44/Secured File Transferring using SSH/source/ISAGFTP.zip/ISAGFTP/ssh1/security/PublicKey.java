package ISAGFTP.ssh1.security;

public interface PublicKey extends Key {
}
