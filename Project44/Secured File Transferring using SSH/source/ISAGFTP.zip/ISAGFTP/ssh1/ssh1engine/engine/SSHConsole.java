package ISAGFTP.ssh1.ssh1engine.engine;

import ISAGFTP.ssh1.terminal.Terminal;
import ISAGFTP.ssh1.security.Cipher;

public interface SSHConsole {
  public Terminal getTerminal();

  public void stdoutWriteString(byte[] str);
  public void stderrWriteString(byte[] str);

  public void print(String str);
  public void println(String str);

  public void serverConnect(SSHChannelController controller, Cipher sndCipher);
  public void serverDisconnect(String reason);
}
