package ISAGFTP.ssh1.ssh1engine.engine;

import javax.swing.JFrame;
import java.util.Properties;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.net.UnknownHostException;

import ISAGFTP.ssh1.security.*;
import ISAGFTP.ssh1.ssh1engine.*;
import ISAGFTP.isagftp.IsagFrame;
import ISAGFTP.isagftp.IsagSSH1Transfer;

public final class SSHInteractiveClient extends SSHClient
  implements Runnable, SSHInteractor {

  public static final boolean expires  = false;
  public static final boolean licensed = false;

  public static final String licenseMessage = "This copy of isagftp is licensed to ";
  public static final String licensee       = "nobody";

  public static final long validFrom = 965157940452L; // 000801/21:25
  public static final long validTime = (33L * 24L * 60L * 60L * 1000L);

  public static boolean wantHelpInfo       = true;
  public static String  customStartMessage = null;
  public static int    localForwardPort    ; 

  DumbConsoleThread dumbConsoleThread;
  Properties			props;
  IsagSSH1Transfer		transfer;

  SSHStdIO           sshStdIO;
  SSHPropertyHandler propsHandler;
  sftp               secure;
  IsagFrame			 parent;

  public boolean quiet;
  boolean        initQuiet;

	private class DumbConsoleThread extends Thread {
		IsagSSH1Transfer transfer;
		SSHPropertyHandler   sshProps;
		String				 host;
		int				     localForwardPort;
		SSHChannelController controller;
		
		public DumbConsoleThread(IsagSSH1Transfer transfer, SSHChannelController controller, 
								SSHPropertyHandler sshProps, String host, int forwardPort) {
			this.transfer = transfer;
			this.controller = controller;
			this.sshProps = sshProps;
			this.host	= host;
			this.localForwardPort = forwardPort;
		}

		public void run() {
			transfer.setSSHProps(controller, sshProps, host, localForwardPort);
			transfer.connect();
			//transfer.setDirPath();
			transfer.show();
			transfer.setDirPath();
		}
	};

/*	static public class DumbConsoleThread implements Runnable {

		SSHPropertyHandler   prop;
		sftp				 secure;
		int				     localForwardPort;
		Properties			 props;

		public DumbConsoleThread(SSHPropertyHandler prop,
								int localForwardPort, Properties props) {
			this.prop       = prop;
			this.secure     = new sftp();
			this.localForwardPort = localForwardPort;
		}

		public void run() {
			String line;
			try 
			{
				secure.connect("127.0.0.1",localForwardPort);
				secure.setUsername(prop.getUsername());
				secure.setPassword(prop.getPassword());
				Thread.sleep(400);
				secure.Authentication();
				while(true) {
					secure.userCommand();
					Thread.sleep(400);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}	
	}
*/
  public static String copyright() {
    return "Copyright (c) 2000-2001 by ISAG";
  }

  public SSHInteractiveClient(boolean quiet, boolean cmdsh, SSHPropertyHandler propsHandler, 
								IsagSSH1Transfer transfer, Properties props) {
    super(propsHandler, propsHandler);

    this.propsHandler = propsHandler;
	this.transfer = transfer;
	this.props = props;
    this.interactor   = this; // !!! OUCH

    propsHandler.setInteractor(this);
    propsHandler.setClient(this);

    this.quiet     = quiet;
    this.initQuiet = quiet;

    setConsole(new SSHStdIO());
    sshStdIO = (SSHStdIO)console;
    sshStdIO.setClient(this);


	//this.secure = new sftp();
  }

  public SSHPropertyHandler getPropertyHandler() {
      return propsHandler;
  }

  public void printCopyright() {
    console.println(copyright());

    if(licensed) {
	console.println(licenseMessage + licensee);
    }

    if(customStartMessage != null) {
	console.println(customStartMessage);
    }
  }

  void printHelpInfo() {
    if(!wantHelpInfo)
      return;

    if(propsHandler.getSSHHomeDir() != null)
      console.println("isagftp home: " + propsHandler.getSSHHomeDir());

    console.println("");
  }

  boolean hasExpired() {
    boolean expired = false;
    long now = System.currentTimeMillis();

    if(licensed)
      return false;

    if(expires) {
      int daysRemaining = (int)((validTime - (now - validFrom)) / (1000L * 60L * 60L * 24L));
      if(daysRemaining <= 0) {
	console.println("This is a demo version of isagftp, it has expired!");
	console.println("Please go to http://www.IsagFtp.se/mindterm/ to get a copy");
	expired = true;
      } else {
	console.println("");
	console.println("This is a demo version of isagftp, it will expire in " + daysRemaining + " days");
	console.println("");
      }
    } else {
      int daysOld = (int)((now - validFrom) / (1000L * 60L * 60L * 24L));
      console.println("");
      console.println("This is a demo version of isagftp, it is " + daysOld + " days old.");
      console.println("Please go to http://www.IsagFtp.se/mindterm/");
      console.println("\tto check for new versions now and then");
      console.println("");
    }
    return expired;
  }

  public void run() {
    boolean gotExtMsg;
    boolean keepRunning = true;

    //while(keepRunning) {      
      gotExtMsg      = false;
      try {
			console.println("");
			printHelpInfo();

			setProperty(props);
			bootSSH(true);
			startDumbConsole();

		    controller.waitForExit();
		  	stopDumbConsole();

			if(sshStdIO.isConnected()) {
			  sshStdIO.serverDisconnect("\n\r\n\rServer died or connection lost");
			}

			try {
				propsHandler.checkSave();
			} catch (IOException e) {
			}

      } catch(SSHClient.AuthFailException e) {
			console.println("");
			console.println(e.getMessage());
			propsHandler.clearPasswords();

      } catch(SSHStdIO.CtrlDPressedException e) {

      } catch(SSHStdIO.SSHExternalMessage e) {
			gotExtMsg = true;
			console.println("");
			console.println(e.getMessage());

      } catch(UnknownHostException e) {
			String host = e.getMessage();
			if(propsHandler.getProperty("proxytype").equals("none")) {
				console.println("Unknown host: " + host);
			} else {
				console.println("Unknown proxy host: " + host);
			}
			propsHandler.clearServerSetting();

      } catch(FileNotFoundException e) {
			console.println("File not found: " + e.getMessage());

      } catch(Exception e) {
			String msg = e.getMessage();
			if(msg == null || msg.trim().length() == 0)
				msg = e.toString();
			console.println("");
			console.println("Error connecting to " + propsHandler.getProperty("server") + ", reason:");
			console.println("-> " + msg+"(Maybe hasn't secure shell on "+propsHandler.getProperty("server")+")");
			console.println("Switch to normal FTP");
			console.println("Warning : insecure Mode.");
			//try
			//{
				dumbConsoleThread = new DumbConsoleThread(transfer, controller, propsHandler, props.getProperty("address"), 21);
				dumbConsoleThread.start();
				/*sftp sec = new sftp();
				String remoteHost=propsHandler.getProperty("server");
				String user = promptLine(remoteHost+" login: ",null);
				sec.prompt = "insecure FTP> ";
				sec.connect(remoteHost,21);
				sec.setUsername(user);
				sec.setPassword(promptPassword(user+"@"+remoteHost+"\'s password: "));	
				sec.Authentication();
				while(true) {					
				}*/
			//} catch (IOException ex) { System.out.println(ex.getMessage());}


			if(SSH.DEBUGMORE) {
				System.out.println("If an error occured, please send the below stacktrace to s0010058@ce.kmitl.ac.th");
				e.printStackTrace();
			}

      } catch(ThreadDeath death) {
			if(controller != null)
			controller.killAll();
			controller = null;
			throw death;
      }

      propsHandler.passivateProperties();
      activateTunnels = true;
      propsHandler.currentPropsFile = null;

      if(!propsHandler.savePasswords || usedOTP) {
		  propsHandler.clearPasswords();
      }

      if(!gotExtMsg) {
			if(!propsHandler.autoLoadProps) {
				propsHandler.clearPasswords();
				initQuiet = false;
			}
			quiet = false;
      }

      controller = null;
    //}
  }

  public boolean isDumb() {
    return (console.getTerminal() == null);
  }

  public void startDumbConsole() {
    dumbConsoleThread = new DumbConsoleThread(transfer, controller, propsHandler, "127.0.0.1", super.localForwardPort);
	dumbConsoleThread.start();
	/*transfer.setSSHProps(propsHandler, super.localForwardPort);
	transfer.connect();
	transfer.setDirPath();
	transfer.show();*/
	
  }
  public void stopDumbConsole() {
    controller.killAll();
	controller = null;
  }

  public void updateTitle() {
    sshStdIO.updateTitle();
  }

  public void startNewSession(SSHClient client) {}

  public void sessionStarted(SSHClient client) {
      quiet = initQuiet;
  }

  public boolean isVerbose() {
      return wantHelpInfo;
  }

  public String promptLine(String prompt, String defaultVal) throws IOException {
    return sshStdIO.promptLine(prompt, defaultVal, false);
  }

  public String promptPassword(String prompt) throws IOException {
      return sshStdIO.promptLine(prompt, "", true);
  }

  public boolean askConfirmation(String message, boolean defAnswer) {
		return true;
  }

  public void connected(SSHClient client) {
      if(wantHelpInfo) {
	  console.println("Connected to server running " + srvVersionStr);
      }
  }

  public void open(SSHClient client) {}

  public void disconnected(SSHClient client, boolean graceful) {
      sshStdIO.breakPromptLine("Login aborted by user");
  }

  public void report(String msg) {
      console.println(msg);
      console.println("");
  }

  public void alert(String msg) {}
}
