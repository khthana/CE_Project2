package ISAGFTP.ssh1.ssh1engine.engine;

import java.net.*;
import java.io.*;

public interface SSHClientUser {
  public String  getSrvHost(String address) throws IOException;
  public int     getSrvPort();
  //public Socket  getProxyConnection() throws IOException;
  public String  getDisplay();
  public int     getMaxPacketSz();
  public int     getAliveInterval();

  public boolean wantX11Forward();
  public boolean wantPrivileged();
  public boolean wantPTY();

  public SSHInteractor getInteractor();
}
