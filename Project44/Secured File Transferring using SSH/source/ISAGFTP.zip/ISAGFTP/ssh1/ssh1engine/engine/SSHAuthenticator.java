package ISAGFTP.ssh1.ssh1engine.engine;

import java.net.*;
import java.io.*;

import ISAGFTP.ssh1.security.RSAPublicKey;

public interface SSHAuthenticator {
  public String        getUsername(SSHClientUser origin, String name) throws IOException;
  public String        getPassword(SSHClientUser origin, String word) throws IOException;
  public String        getChallengeResponse(SSHClientUser origin, String challenge) throws IOException;
  public int[]         getAuthTypes(SSHClientUser origin);
  public int           getCipher(SSHClientUser origin);
  public SSHRSAKeyFile getIdentityFile(SSHClientUser origin) throws IOException;
  public String        getIdentityPassword(SSHClientUser origin) throws IOException;
  public boolean       verifyKnownHosts(RSAPublicKey hostPub) throws IOException;
}
