package ISAGFTP.ssh1.ssh1engine.engine;

import java.io.*;

public class SSHRxChannel extends SSHChannel {

  protected InputStream  in;
  protected SSHPdu       pduFactory;

  public SSHRxChannel(InputStream in, int channelId) {
    super(channelId);
    this.in = in;
  }

  public void setSSHPduFactory(SSHPdu pduFactory) {
    this.pduFactory = pduFactory;
  }

  public void serviceLoop() throws Exception {
    SSH.logExtra("Starting rx-chan: " + channelId);
    for(;;) {
      SSHPdu pdu;
      pdu = pduFactory.createPdu();
      pdu = listener.prepare(pdu);
      //      pdu = pdu.preProcess(pdu);
      pdu.readFrom(in);
      //      pdu = pdu.postProcess();
      listener.receive(pdu);
    }
  }

  public void forceClose() {
    try {
      in.close();
    } catch (IOException e) {
      // !!!
    }
  }

}
