package ISAGFTP.isagftp;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Properties;
import java.net.*;
import javax.swing.*;
import javax.swing.event.*;

import ISAGFTP.ssh1.ftp.IsagTerm;

public class IsagFrame extends JFrame
implements ActionListener, ListSelectionListener {
	JButton newButton = new JButton("New Server");
	JButton settingButton = new JButton("Setting");
	JButton delButton = new JButton("Delete");
	JButton connectButton = new JButton("Connect");
	JButton disconnectButton = new JButton("Disconnect");
	JList hostList = new JList();

	Container contentPane;
	IsagSSH1Transfer ssh1transfer;
	IsagSSH2Transfer ssh2transfer;
	String ssh;
	boolean isConnect = false;
//	boolean isSelected = false;

	public IsagFrame() {
		super("ISAGFTP - Version 2.0");
		setSize(new Dimension(350, 250));
		setResizable(false);

		contentPane = getContentPane();

		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		contentPane.setLayout(gbl);

		contentPane.add(hostList,  new GridBagConstraints(0, 0, 1, 5, 1.0, 1.0
				,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(14, 14, 19, 0), 202, 173));
		contentPane.add(newButton,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(14, 17, 0, 15), 7, -1));
		contentPane.add(settingButton,  new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(12, 18, 0, 15), 7, -1));
		contentPane.add(delButton,  new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10, 18, 0, 15), 7, -1));
		contentPane.add(connectButton,  new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(11, 18, 0, 15), 7, -1));
		contentPane.add(disconnectButton,  new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(7, 18, 19, 15), 7, -1));

		hostList.setBorder(BorderFactory.createLoweredBevelBorder());
		
		hostList.setSelectionMode(0);
		hostList.addListSelectionListener(this);
		newButton.setMargin(new Insets(1, 1, 1, 1));
		newButton.addActionListener(this);
		settingButton.setMargin(new Insets(1, 14, 1, 14));
		settingButton.addActionListener(this);
		delButton.setMargin(new Insets(1, 15, 1, 15));
		delButton.addActionListener(this);
		connectButton.setMargin(new Insets(1, 10, 1, 10));
		connectButton.addActionListener(this);
		disconnectButton.setMargin(new Insets(1, 1, 1, 1));
		disconnectButton.addActionListener(this);

		setEnable();
		getHostList();

		addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e) {
							/*if (isConnect) {
								disconnect();
							}*/
							System.exit(0);
						}
		});
	}

	public void getHostList() {
		File dir = new File(System.getProperty("user.home") + 
								File.separator + "Known_host");
		File[] f = dir.listFiles();
		Object[] list;
		if (f == null) {
			list = new Object[0];
		}
		else {
			list = new Object[f.length];
			for (int i = 0; i < f.length; i++) {
				String name = f[i].getName();
				list[i] = name.substring(0, name.indexOf("."));			
			}
		}
		
		hostList.setListData(list);
	}

	public void setEnable() {
		if (isConnect) {
			newButton.setEnabled(false);			
			delButton.setEnabled(false);
			connectButton.setEnabled(false);
			disconnectButton.setEnabled(true);
		}
		else {
			newButton.setEnabled(true);
			settingButton.setEnabled(false);
			delButton.setEnabled(true);
			connectButton.setEnabled(true);
			disconnectButton.setEnabled(false);
		}		
	}

	public void actionPerformed(ActionEvent a) {
		if (a.getSource() == newButton) {
			String title = "ISAGFTP - New Server Dialog";
			IsagNewHostDialog dialog = new IsagNewHostDialog(this, title);
			dialog.show();

			getHostList();

			hostList.clearSelection();
			setEnable();
		}
		else if (a.getSource() == settingButton) {
			try
			{
				String title = "ISAGFTP - Setting Dialog";
				Properties prop = getPropFile();
				IsagNewHostDialog dialog = new IsagNewHostDialog(this, title, prop);
				dialog.show();

				getHostList();

				hostList.clearSelection();
				setEnable();
			}
			catch (IOException ioe) {
				String message = ioe.getMessage();
				String title = "ISAGFTP - IOException";
				JOptionPane.showConfirmDialog(this, message, title, -1, 0);
			}						
		}
		else if (a.getSource() == delButton) {
			if (hostList.isSelectionEmpty()) {
				String message = "You must select host name!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				int confirm;
				String message = "Are you sure to delete this host from list";
				String title = "ISAGFTP - Warning";
				confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);

				if (confirm == 0) {
					deleteHost(hostList.getSelectedValue());
				}

				hostList.clearSelection();
				setEnable();
			}
		}
		else if (a.getSource() == connectButton) {
			if (hostList.isSelectionEmpty()) {
				String message = "You must select host name!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {		
				try
				{
					Properties prop = getPropFile();
					connect(prop);
				}
				catch (UnknownHostException uhe) {
					String message = uhe.getMessage();
					String title = "ISAGFTP - UnknowHostException";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
				catch (IOException ioe) {
					String message = ioe.getMessage();
					String title = "ISAGFTP - IOException";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
				catch (Exception ioe) {
					String message = ioe.getMessage();
					String title = "ISAGFTP - Exception";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
			}
		}
		else if (a.getSource() == disconnectButton) {
			//disconnect();
		}		
	}

	public void valueChanged(ListSelectionEvent e) {
		if (hostList.isSelectionEmpty()) {
			settingButton.setEnabled(false);
		}
		else {
			settingButton.setEnabled(true);
		}
	}

	public Properties getPropFile() throws IOException {
		String name = (String)hostList.getSelectedValue();
		Properties prop = new Properties();
		FileInputStream fin = new FileInputStream(
			System.getProperty("user.home") + File.separator + "Known_host" + 
									File.separator + name + ".srv"
			);
		prop.load(fin);
		fin.close();

		return prop;
	}

	public void deleteHost(Object item) {
		String host = (String)item;
		File f = new File(System.getProperty("user.home") + 
										File.separator + "Known_host" + 
										File.separator + host + ".srv");
		f.delete();
		getHostList();
	}

	public void disconnect() {
		isConnect = false;
		hostList.clearSelection();
		setEnable();
	}
/*
	public void disconnect() {
		if (ssh.equals("ssh2")) {
			ssh2transfer.disconnect();
		}
		else if (ssh.equals("ssh1")) {
		//	ssh1transfer.disconnect();
		}
		else {
		}	
		
		isConnect = false;
		hostList.clearSelection();
		setEnable();
	}
*/
	public void connect(Properties props) 
	throws UnknownHostException, IOException, Exception {
		ssh = checkPeerVersion(props);
		//System.out.println(ssh);
		
		if (ssh.equals("ssh2")) {
			boolean isComplete = connectToSSH2(props);
			isConnect = isComplete;
			hostList.clearSelection();
			setEnable();
		}
		else if (ssh.equals("ssh1")) {
			boolean isComplete = connectToSSH1(props);
			isConnect = isComplete;
			hostList.clearSelection();
			setEnable();
		}
		else {
			int confirm;
			String message = "This server can't start SSH1/SSH2 protocaol!\n" +
								"Do you want start with simple FTP";
			String title = "ISAGFTP - Warning";
			confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);

			if (confirm == 0) {
					boolean isComplete = connectToSSH1(props);
					isConnect = isComplete;
					hostList.clearSelection();
					setEnable();
			}
		}
	}

	public String checkPeerVersion(Properties prop) 
	throws UnknownHostException, IOException {			
		Socket socket = new Socket(prop.getProperty("address"), 
								(int)Integer.parseInt(prop.getProperty("port")));
		BufferedInputStream inStream = 
				new BufferedInputStream(socket.getInputStream());
		String peer_version;
		int c = 0;
		int len = 0;
		byte[] buf = new byte[256];

		c = inStream.read();
		while(c != -1) {
			if(c == '\r')
				continue;
			if(c != '\n') {
				buf[len++] = (byte)c;
            } 
			else {
				break;
            }
			c = inStream.read();
		}

		peer_version = new String(buf, 0, len);
		socket.close();
		
		//System.out.println(peer_version);

		if (peer_version.startsWith("SSH-")) {
			int beginIndex;
			int endIndex;

			beginIndex = peer_version.indexOf("-") + 1;
			endIndex = peer_version.indexOf(".");
			String majorVersion = peer_version.substring(beginIndex, endIndex);					
			
			if (majorVersion.equals("2")) {
				return "ssh2";
			}
			else {
				beginIndex = endIndex + 1;
				endIndex = peer_version.indexOf("-", beginIndex);
				String minorVersion = peer_version.substring(beginIndex, endIndex);
				
				if (minorVersion.equals("99")) {
					return "ssh2";
				}
				else {
					return "ssh1";
				}
			}
		}
		else {
			return "ftp";
		}		
	}

	public boolean connectToSSH2(Properties props) throws Exception {
//		boolean complete = checkSSH2Properties(props);
//		if (complete) {
			this.hide();
			ssh2transfer = new IsagSSH2Transfer(this, props);			
			return true;
//		}
//		else {
//			return false;
//		}
	}

	public boolean connectToSSH1(Properties props) {
		this.hide();
		ssh1transfer = new IsagSSH1Transfer(this, props);


		String cipher = props.getProperty("enc-algorithms-cli2srv");
		if (cipher.indexOf("-") != -1) {
			cipher.substring(0, cipher.indexOf("-"));
		}

		String[] argv = new String[2];
		argv[0] = "-cipher";
		argv[1] = cipher;

		IsagTerm controller = new IsagTerm(new Properties(), new Properties(), 
											ssh1transfer, props);
		controller.cmdLineArgs = argv;		
    
		try {
			controller.getApplicationParams();
			controller.start();

			//ssh1transfer.connect();
			//ssh1transfer.setDirPath();
			//ssh1transfer.show();
		} catch (Exception e) {
			String message = e.getMessage();
			String title = "ISAGFTP - Exception";
			JOptionPane.showConfirmDialog(this, message, title, -1, 0);
			return false;
		}

		return true; 
	}
/*
	public boolean checkSSH2Properties(Properties props) {
		
		if (isCipherMatch(props)) {
			if (isSSH2CipherSupport(props)) {
				if (isMacMatch(props)) {
					if (isSSH2MacSupport(props)) {
						return true;
					}
				}
				else {
					String message = "Macs don't matched!";
					String title = "ISAGFTP - Warning";
					JOptionPane.showConfirmDialog(this, message, title, -1, 2);
				}
			}
		}
		else {
			String message = "Ciphers don't matched!";
			String title = "ISAGFTP - Warning";
			JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		}

		return false;
	}

	public boolean isCipherMatch(Properties props) {
		String cipherC2S = props.getProperty("enc-algorithms-cli2srv");
		String cipherS2C = props.getProperty("enc-algorithms-srv2cli");

		if (cipherC2S.equals(cipherS2C)) {
			return true;
		}
		else {
			return false;
		}
	}

	public boolean isMacMatch(Properties props) {
		String macC2S = props.getProperty("mac-algorithms-cli2srv");
		String macS2C = props.getProperty("mac-algorithms-srv2cli");

		if (macC2S.equals(macS2C)) {
			return true;
		}
		else {
			return false;
		}
	}

	public boolean isSSH2CipherSupport(Properties props) {
		String supported = "3des-cbc,blowfish-cbc,twofish256-cbc,twofish192-cbc," +
			"twofish128-cbc,twofish-cbc,aes256-cbc,aes192-cbc,aes128-cbc,arcfour," +
			"serpent256-cbc,serpent192-cbc,serpent128-cbc,idea-cbc,cast128-cbc";
		String cipher = props.getProperty("enc-algorithms-cli2srv");

		int found = supported.indexOf(cipher);
		if (found != -1) {
			return true;
		}
		else {
			String message = "SSH2 protocol doesn't support " + cipher;
			String title = "ISAGFTP - Warning";
			JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			return false;
		}
	}

	public boolean isSSH2MacSupport(Properties props) {
		String supported = "hmac-sha1,hmac-sha1-96,hmac-md5,hmac-md5-96";
		String mac = props.getProperty("mac-algorithms-cli2srv");

		int found = supported.indexOf(mac);
		if (found != -1) {
			return true;
		}
		else {
			String message = "SSH2 protocol doesn't support " + mac;
			String title = "ISAGFTP - Warning";
			JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			return false;
		}
	}
*/
}
