package ISAGFTP.isagftp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.net.Socket;
import java.util.Properties;

import ISAGFTP.ssh2.ssh2engine.engine.*;

public class IsagSSH2Transfer extends JFrame 
implements ActionListener, MouseListener {

	private class RmdirRemoteThread extends Thread {
		IsagSSH2Transfer parent;
		public RmdirRemoteThread(IsagSSH2Transfer parent) {
				this.parent = parent;
		}

		public void run() {
				try
				{
						parent.rmdirRemote();
						parent.rls(remotePath);
				}
				catch (SSH2SFTP.SFTPException e) {
						String message = e.getMessage();
						String title = "ISAGFTP - SFTPException";
						JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
				}
		}
	};

	private class DeleteRemoteThread extends Thread {
		IsagSSH2Transfer parent;
		public DeleteRemoteThread(IsagSSH2Transfer parent) {
				this.parent = parent;
		}

		public void run() {
				try
				{
						parent.deleteRemote();
						parent.rls(remotePath);
				}
				catch (SSH2SFTP.SFTPException e) {
						String message = e.getMessage();
						String title = "ISAGFTP - SFTPException";
						JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
				}
		}
	};

	private class UploadThread extends Thread {
		IsagSSH2Transfer parent;

		public UploadThread(IsagSSH2Transfer parent) {
			this.parent = parent;
		}

		public void run() {
			try
			  {
			  	  parent.upload();
				  parent.rls(remotePath);				  
			  }
			  catch (SSH2SFTP.SFTPException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - SFTPException";
				  JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
			  }
			  catch (FileNotFoundException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - FileNotFoundException";
				  JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
			  }
			  catch (IOException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - IOException";
				  JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
			  }
		}
	};

	private class DownloadThread extends Thread {
		IsagSSH2Transfer parent;
		
		public DownloadThread(IsagSSH2Transfer parent) {
			this.parent = parent;
		}

		public void run() {
			try
			  {
			  	  parent.download();
				  parent.lls(localPath);
			  }
			  catch (SSH2SFTP.SFTPException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - SFTPException";
				  JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
			  }
			  catch (FileNotFoundException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - FileNotFoundException";
				  JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
			  }
			  catch (IOException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - IOException";
				  JOptionPane.showConfirmDialog(parent, message, title, -1, 0);
			  }
		}
	};
	
  JPanel contentPane;
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel8 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JList localList = new JList();
  JList remoteList = new JList();
  JButton lDirUpButton = new JButton();
  JButton rDirUpButton = new JButton();
  JTextField localField = new JTextField(15);
  JTextField remoteField = new JTextField(15);
  JButton lRefreshButton = new JButton();
  JButton rRefreshButton = new JButton();
  JButton uploadButton = new JButton();
  JButton lRenameButton = new JButton();
  JButton lDeleteButton = new JButton();
  JButton lRmdirButton = new JButton();
  JButton lMkdirButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton rMkdirButton = new JButton();
  JButton downloadButton = new JButton();
  JButton rRenameButton = new JButton();
  JButton rDeleteButton = new JButton();
  JButton rRmdirButton = new JButton();
  FlowLayout flowLayout2 = new FlowLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  BorderLayout borderLayout4 = new BorderLayout();
  BorderLayout borderLayout5 = new BorderLayout();
  BorderLayout borderLayout6 = new BorderLayout();
  BorderLayout borderLayout7 = new BorderLayout();

	IsagFrame parent;
	Properties props;
	SSH2Connection		connection;
	SSH2SFTPClient		sftp;

	String localPath;
	String remotePath;

	SSH2SFTP.FileHandle handle;
	SSH2SFTP.FileAttributes attrs;
//	IsagProgressDialog progressBar;
	UploadThread uploadThread;
	DownloadThread downloadThread;

//	public IsagSSH2Transfer() {
  public IsagSSH2Transfer(IsagFrame frame, Properties props) throws Exception {
	this.parent = frame;
	this.props = props;
 //   try {
		connect();
		createChannel();
			
		jbInit();
//		this.setSize(530, 350);
		this.setResizable(false);

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();
		if (frameSize.height > screenSize.height) {
		  frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
		  frameSize.width = screenSize.width;
		}
		this.setLocation((screenSize.width - frameSize.width) / 2, 
							(screenSize.height - frameSize.height) / 2);
		
		this.show();
/*    }
    catch(Exception e) {
		String message = e.getMessage();
		String title = "ISAGFTP - Exception";
		JOptionPane.showConfirmDialog(this, message, title, -1, 0);
    }
	catch (SSH2SFTP.SFTPDisconnectException e) {
		String message = e.getMessage();
		String title = "ISAGFTP - Exception";
		JOptionPane.showConfirmDialog(this, message, title, -1, 0);
	}
	catch (SSH2SFTP.SFTPException e) {
		String message = e.getMessage();
		String title = "ISAGFTP - Exception";
		JOptionPane.showConfirmDialog(this, message, title, -1, 0);
	}*/
  }

  public void connect() throws Exception {
	final SSH2TransportPreferences prefs =
		new SSH2TransportPreferences(props);

	  String host = props.getProperty("address");
	  int port = Integer.valueOf(props.getProperty("port")).intValue();

	  //System.out.println("** SSH2 Server " + host + ":" + port);

	  final SSH2Transport transport =
		  new SSH2Transport(new Socket(host, port),
				  prefs,
				  new ISAGFTP.ssh2.ssh2engine.util.SecureRandomAndPad());

	  transport.boot();
	  transport.waitForKEXComplete();

	  SSH2Authenticator authenticator =
		  new SSH2Authenticator(props.getProperty("user"));

	  String  keyFile = props.getProperty("privatekey");
	  if(keyFile != null) {
		  SSH2DSS dss = null;
		  try {
			  SSH2KeyPairFile kpf = new SSH2KeyPairFile();
			  kpf.load(keyFile, props.getProperty("passphrase"));

			  String        alg  = kpf.getAlgorithmName();
			  SSH2Signature sign = SSH2Signature.getInstance(alg);

			  sign.initSign(kpf.getKeyPair().getPrivate());
			  sign.setPublicKey(kpf.getKeyPair().getPublic());

			  authenticator.addModule("publickey",
						new SSH2AuthPublicKey(sign));
		  } catch (Exception e) {
		/*	  System.out.println("Error getting private file '" + keyFile +
					     "': " + e);*/
		  }
	  }

	  authenticator.addModule("password",
		  new SSH2AuthPassword(props.getProperty("password")));
					  
	  SSH2UserAuth userAuth = new SSH2UserAuth(transport, authenticator);
	  userAuth.authenticateUser("ssh-connection");

	  connection = new SSH2Connection(userAuth, transport);
	  transport.setConnection(connection);
  }

  public void createChannel() throws SSH2SFTP.SFTPDisconnectException, 
		SSH2SFTP.SFTPException, Exception {

		sftp = new SSH2SFTPClient(connection, false);

	    attrs = sftp.realpath(".");
	    remotePath = attrs.lname;			// remote Dir

		handle = null;
  }

  public void disconnect() {
	  SSH2Transport transport = connection.getTransport();
	  transport.normalDisconnect("Disconnect by user");
	  parent.disconnect();
	  parent.setVisible(true);	  
	  this.dispose();			  
  }

  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout5);
    this.setSize(new Dimension(549, 354));
    this.setTitle("ISAGFTP - Transferring");
    jPanel1.setBackground(Color.pink);
    jPanel1.setLayout(borderLayout3);
    jPanel2.setLayout(borderLayout4);
    jPanel2.setBackground(Color.orange);
    jPanel3.setLayout(borderLayout6);
    jPanel4.setLayout(borderLayout1);
    jPanel5.setLayout(flowLayout1);
    jPanel6.setLayout(borderLayout2);
    jPanel7.setLayout(borderLayout7);
    jPanel8.setLayout(flowLayout2);
    lDirUpButton.setIcon(new ImageIcon("ISAGFTP" + File.separator + "isagftp" + 
										File.separator + "dirUp.gif"));
    lDirUpButton.setMargin(new Insets(1, 1, 1, 1));
    rDirUpButton.setMargin(new Insets(0, 0, 1, 1));
    lRefreshButton.setMargin(new Insets(0, 0, 0, 0));
    rDirUpButton.setIcon(new ImageIcon("ISAGFTP" + File.separator + "isagftp" + 
										File.separator + "dirUp.gif"));
    lRefreshButton.setText("refresh");
    rRefreshButton.setText("refresh");
    rRefreshButton.setMargin(new Insets(0, 0, 0, 0));
    uploadButton.setMargin(new Insets(0, 5, 0, 5));
    uploadButton.setText("-->");
    lRenameButton.setText("rename");
    lRenameButton.setMargin(new Insets(0, 0, 0, 0));
    lDeleteButton.setText("delete");
    lDeleteButton.setMargin(new Insets(0, 0, 0, 0));
    lRmdirButton.setMargin(new Insets(0, 0, 0, 0));
    lRmdirButton.setText("rmdir");
    lMkdirButton.setText("mkdir");
    lMkdirButton.setMargin(new Insets(0, 0, 0, 0));
    rMkdirButton.setMargin(new Insets(0, 0, 0, 0));
    rMkdirButton.setText("mkdir");
    downloadButton.setText("<--");
    downloadButton.setMargin(new Insets(0, 5, 0, 5));
    rRenameButton.setMargin(new Insets(0, 0, 0, 0));
    rRenameButton.setText("rename");
    rDeleteButton.setMargin(new Insets(0, 0, 0, 0));
    rDeleteButton.setText("delete");
    rRmdirButton.setText("rmdir");
    rRmdirButton.setMargin(new Insets(0, 0, 0, 0));
    contentPane.add(jPanel1, BorderLayout.WEST);
    jPanel1.add(jPanel3, BorderLayout.NORTH);
    jPanel3.add(lDirUpButton, BorderLayout.WEST);
    jPanel1.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(localList, null);
    jPanel1.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(lMkdirButton, null);
    jPanel5.add(lRmdirButton, null);
    jPanel5.add(lDeleteButton, null);
    jPanel5.add(lRenameButton, null);
    jPanel5.add(uploadButton, null);
    contentPane.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jPanel8, BorderLayout.SOUTH);
    jPanel2.add(jPanel6, BorderLayout.CENTER);
    jPanel6.add(jScrollPane2, BorderLayout.CENTER);
    jScrollPane2.getViewport().add(remoteList, null);
    jPanel2.add(jPanel7, BorderLayout.NORTH);
    jPanel7.add(rDirUpButton, BorderLayout.WEST);
    jPanel3.add(localField, BorderLayout.CENTER);
    jPanel7.add(remoteField, BorderLayout.CENTER);
    jPanel7.add(rRefreshButton, BorderLayout.EAST);
    jPanel3.add(lRefreshButton, BorderLayout.EAST);
    jPanel8.add(downloadButton, null);
    jPanel8.add(rMkdirButton, null);
    jPanel8.add(rRmdirButton, null);
    jPanel8.add(rDeleteButton, null);
    jPanel8.add(rRenameButton, null);

	localField.addActionListener(this);
	lDirUpButton.addActionListener(this);
	lRefreshButton.addActionListener(this);
	localList.addMouseListener(this);
	lMkdirButton.addActionListener(this);
	lRmdirButton.addActionListener(this);
	lDeleteButton.addActionListener(this);
	lRenameButton.addActionListener(this);

	remoteField.addActionListener(this);
	rDirUpButton.addActionListener(this);
	rRefreshButton.addActionListener(this);
	remoteList.addMouseListener(this);
	rMkdirButton.addActionListener(this);
	rRmdirButton.addActionListener(this);
	rDeleteButton.addActionListener(this);
	rRenameButton.addActionListener(this);

	uploadButton.addActionListener(this);
	downloadButton.addActionListener(this);

	addWindowListener(new WindowAdapter() {
					public void windowClosing(WindowEvent e) {								
								disconnect();
					}
	});
	setDirPath();
  }

  public void mouseClicked(MouseEvent a) {
	  if (a.getSource() == localList) {
		  remoteList.clearSelection();
		  if (a.getClickCount() > 1) {
			  String item = (String)localList.getSelectedValue();
			  if (item.startsWith("[")) {
				  String dir = item.substring(1, item.indexOf("]"));
				  localPath = localPath + File.separator + dir;
				  lls(localPath);
			  }
		  }		  
	  }
	  else if (a.getSource() == remoteList) {
		  localList.clearSelection();
		  if (a.getClickCount() > 1) {
			  String item = (String)remoteList.getSelectedValue();
			  if (item.startsWith("[")) {
				  String dir = item.substring(1, item.indexOf("]"));
				  remotePath = remotePath + "/" + dir;
				  try
				  {
				  	  rls(remotePath);
				  }
				  catch (SSH2SFTP.SFTPException e) {
					  String message = e.getMessage();
					  String title = "ISAGFTP - Exception";
					  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
					  remotePath = remotePath.substring(0, remotePath.lastIndexOf("/"));
				  }
			  }
		  }		  
	  }
  }

  public void mouseEntered(MouseEvent a) {
  }

  public void mouseExited(MouseEvent a) {
  }

  public void mousePressed(MouseEvent a) {
  }

  public void mouseReleased(MouseEvent a) {
  }

  public void actionPerformed(ActionEvent a) {
	  if (a.getSource() == localField) {
		  String newPath = localField.getText();
		  if (newPath.endsWith(":")) {
			  newPath = newPath + File.separator;
		  }
		  localPath = newPath;
		  lls(newPath);		  
	  }
	  else if (a.getSource() == lDirUpButton) {		  
		  localPath = localPath.substring(0, localPath.lastIndexOf(File.separator));
		  if (localPath.endsWith(":")) {
			  localPath = localPath + File.separator;
		  }
		  lls(localPath);
	  }
	  else if (a.getSource() == lRefreshButton) {
		  lls(localPath);
	  }
	  else if (a.getSource() == lMkdirButton) {
		  String input;
		  String message = "Please enter folder name";
		  String title = "ISAGFTP - New Folder";
		  input = JOptionPane.showInputDialog(this, message, title, 1);

		  if (input != null && !input.trim().equals("")) {
			  mkdirLocal(input);
			   lls(localPath);
		  }
	  }
	  else if (a.getSource() == lRmdirButton) {
		  if (localList.isSelectionEmpty()) {
			  String message = "Please select folders before delete";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  int confirm;
			  String message = "Are you sure you want to delete selected folders";
			  String title = "ISAGFTP - Removing Folders";
			  confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
			  if (confirm == 0) {
				  rmdirLocal();
				  lls(localPath);
			  }
		  }
	  }
	  else if (a.getSource() == lDeleteButton) {
		  if (localList.isSelectionEmpty()) {
			  String message = "Please select files before delete";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  int confirm;
			  String message = "Are you sure you want to delete selected files";
			  String title = "ISAGFTP - Deleting";
			  confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
			  if (confirm == 0) {
				  deleteLocal();
				  lls(localPath);
			  }
		  }
	  }
	  else if (a.getSource() == lRenameButton) {
		  if (localList.isSelectionEmpty()) {
			  String message = "Please select files before delete";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  Object[] list = localList.getSelectedValues();
			  if (list.length > 1) {
				  String message = "This function doesn't support multiple renaming!";
				  String title = "ISAGFTP - Warning";
				  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			  }
			  else {
				  String input;
				  String message = "Please enter new name";
				  String title = "ISAGFTP - Renaming";
				  input = JOptionPane.showInputDialog(this, message, title, 1);
				  
				  if (input.trim() != null) {
					  renameLocal(input);
					  lls(localPath);
				  }
			  }
		  }
	  }
	  else if (a.getSource() == remoteField) {		  
		  try
		  {
			  remotePath = remoteField.getText();
			  rls(remotePath);
		  }
		  catch (SSH2SFTP.SFTPException e) {
			  String message = e.getMessage();
			  String title = "ISAGFTP - Exception";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
		  }
	  }
	  else if (a.getSource() == rDirUpButton) {
		  if (remotePath.equals("/")) {
			  String message = "This is the root directory!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {			  
			  try
			  {
				  remotePath = remotePath.substring(0, remotePath.lastIndexOf("/"));
				  rls(remotePath);
			  }
			  catch (SSH2SFTP.SFTPException e) {
				  String message = e.getMessage();
				  String title = "ISAGFTP - Exception";
				  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
			  }
		  }
	  }
	  else if (a.getSource() == rRefreshButton) {
		  try
		  {
			  rls(remotePath);
		  }
		  catch (SSH2SFTP.SFTPException e) {
			  String message = e.getMessage();
			  String title = "ISAGFTP - Exception";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
		  }
	  }
	  else if (a.getSource() == rMkdirButton) {
		  String input;
		  String message = "Please enter folder name";
		  String title = "ISAGFTP - New Folder";
		  input = JOptionPane.showInputDialog(this, message, title, 1);

		  if (input != null && !input.trim().equals("")) {
			  try
			  {
			  	  mkdirRemote(input);
				  rls(remotePath);
			  }
			  catch (SSH2SFTP.SFTPException e) {
				  message = e.getMessage();
				  title = "ISAGFTP - Exception";
				  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
			  }
		  }
	  }
	  else if (a.getSource() == rRmdirButton) {
		  if (remoteList.isSelectionEmpty()) {
			  String message = "Please select folders before delete";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  int confirm;
			  String message = "Are you sure you want to delete selected folders";
			  String title = "ISAGFTP - Removing Folders";
			  confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
			  if (confirm == 0) {
				  new RmdirRemoteThread(this).start();
				  /*try
				  {
					  rmdirRemote();
					  rls(remotePath);
				  }
				  catch (SSH2SFTP.SFTPException e) {
					  message = e.getMessage();
					  title = "ISAGFTP - Exception";
					  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				  }	*/	  
			  }
		  }
	  }
	  else if (a.getSource() == rDeleteButton) {
		  if (remoteList.isSelectionEmpty()) {
			  String message = "Please select files before delete";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  int confirm;
			  String message = "Are you sure you want to delete selected files";
			  String title = "ISAGFTP - Deleting";
			  confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
			  if (confirm == 0) {
				  new DeleteRemoteThread(this).start();
				  /*try
				  {
					  deleteRemote();
					  rls(remotePath);
				  }
				  catch (SSH2SFTP.SFTPException e) {
					  message = e.getMessage();
					  title = "ISAGFTP - Exception";
					  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				  }*/	
			  }
		  }
	  }
	  else if (a.getSource() == rRenameButton) {
		  if (remoteList.isSelectionEmpty()) {
			  String message = "Please select files before delete";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  Object[] list = remoteList.getSelectedValues();
			  if (list.length > 1) {
				  String message = "This function doesn't support multiple renaming!";
				  String title = "ISAGFTP - Warning";
				  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			  }
			  else {
				  String input;
				  String message = "Please enter new name";
				  String title = "ISAGFTP - Renaming";
				  input = JOptionPane.showInputDialog(this, message, title, 1);
				  
				  if (input != null && !input.trim().equals("")) {
					  try
					  {
						  renameRemote(input);
						  rls(remotePath);
					  }
					  catch (SSH2SFTP.SFTPException e) {
						  message = e.getMessage();
						  title = "ISAGFTP - Exception";
						  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
					  }	
				  }
			  }
		  }
	  }
	  else if (a.getSource() == uploadButton) {
		  if (localList.isSelectionEmpty()) {
			  String message = "Please select files/folders before upload!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  uploadThread = new UploadThread(this);
			  uploadThread.start();			 
		  }
	  }
	  else if (a.getSource() == downloadButton) {
		  if (remoteList.isSelectionEmpty()) {
			  String message = "Please select files/folders before download!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  downloadThread = new DownloadThread(this);
			  downloadThread.start();			  
		  }
	  }
  }

  public void lls(String path) {
	  try
	  {
		  File dir = new File(path);
		  File[] f = dir.listFiles();
		  Object[] list = new Object[f.length];
		  int top = 0;
		  int bottom = f.length - 1;

		  for (int i = 0; i < f.length; i++) {
			  if (f[i].isDirectory()) {
				  list[top] = "[" + f[i].getName() + "]";
				  top++;
			  }
			  else {
				  list[bottom] = f[i].getName() + " (" + f[i].length() + ")";
				  bottom--;
			  }
		  }

		  localField.setText(localPath);
		  localList.setListData(list);
	  }
	  catch (NullPointerException npe) {
		  String message = "Can't read path " + path + " !";
		  String title = "ISAGFTP - Exception";
		  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
	  }
  }

  public void mkdirLocal(String newDir) {
	  File dir = new File(expandLocal(newDir));
	  if (!dir.mkdir()) {
		  String message = "Can't create new folder by this name!";
		  String title = "ISAGFTP - Error Message";
		  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
	  }
  }

  public void rmdirLocal() {
	  Object[] list = localList.getSelectedValues();
	  for (int i = 0; i < list.length; i++) {
		  String item = (String)list[i];
		  String folderName = isFolder(item);
		  if (folderName == null) {
			  String message = "This function can't delete file outside folder!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  deleteDirLocal(localPath + File.separator + folderName);
		  }
	  }
  }

  public void deleteLocal() {
	  Object[] list = localList.getSelectedValues();
	  for (int i = 0; i < list.length; i++) {
		  String item = (String)list[i];
		  String fileName = isFile(item);
		  if (fileName == null) {
			  String message = "This function can't delete folder!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  File f = new File(localPath + File.separator + fileName);
			  if (!f.delete()) {
				  String message = "Can't delete file " + fileName + "!";
				  String title = "ISAGFTP - Error Message";
				  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
			  }
		  }
	  }
  }

  public void renameLocal(String newName) {
	  String oldName = (String)localList.getSelectedValue();
	  
	  String name = isFolder(oldName);
	  if (name == null) {
		  name = isFile(oldName);
	  }

	  File oldFile = new File(localPath + File.separator + name);
	  if (!oldFile.renameTo(new File(localPath + File.separator + newName))) {
		  String message = "Can't rename " + name + " to " + newName;
		  String title = "ISAGFTP - Error Message";
		  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
	  }
  }

  public void deleteDirLocal(String fullName) {
	  File dir = new File(fullName);
	  File[] list = dir.listFiles();

	  for (int i = 0; i < list.length; i++) {
		  if (list[i].isDirectory()) {
			  deleteDirLocal(fullName + File.separator + list[i].getName());
		  }
		  else {
			  if (!list[i].delete()) {
				  String message = "Can't delete file " + list[i].getName();
				  String title = "ISAGFTP - Error Message";
				  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
			  }
		  }
	  }

	  if (!dir.delete()) {
		  String message = "Can't delete folder " + dir.getName();
		  String title = "ISAGFTP - Error Message";
		  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
	  }
  }

  public String isFolder(String input) {
	  if (input.startsWith("[")) {
		  String folderName = input.substring(1, input.indexOf("]"));
		  return folderName;
	  }
	  else {
		  return null;
	  }
  }

  public String isFile(String input) {
	  if (input.startsWith("[")) {
		  return null;
	  }
	  else {
		  String fileName = input.substring(0, input.indexOf("(")).trim();
		  return fileName;
	  }
  }

  public void setDirPath() {
	  localPath = System.getProperty("user.home");	  
	  lls(localPath);

	  try
	  {
		  rls(remotePath);
	  }
	  catch (SSH2SFTP.SFTPException e) {
		  String message = e.getMessage();
		  String title = "ISAGFTP - Exception";
		  JOptionPane.showConfirmDialog(this, message, title, -1, 0);
	  }
  }

  public void rls(String path) throws SSH2SFTP.SFTPException {
		try 
		{
			handle = sftp.opendir(path);
			SSH2SFTP.FileAttributes[] flist = sftp.readdir(handle);
			Object[] list = new Object[flist.length];
			int top = 0;
			int bottom = list.length - 1;

			for(int i = 0; i < list.length; i++) {
				if (!flist[i].name.equals(".") && !flist[i].name.equals("..")) {
					if (flist[i].isDirectory()) {
						list[top] = "[" + flist[i].name + "]";
						top++;
					}
					else {
						int size = (new Long(flist[i].size)).intValue();
						list[bottom] = flist[i].name + " (" + size + ")";
						bottom--;
					}
				}				
	  		}

			remoteField.setText(path);
			remoteList.setListData(list);
		} finally {
			try { sftp.close(handle); }
			catch (Exception e) { /* don't care */ }
		}
  }

  public void mkdirRemote(String newDir) throws SSH2SFTP.SFTPException {
	  sftp.mkdir(expandRemote(newDir), new SSH2SFTP.FileAttributes());
  }

  public void rmdirRemote() throws SSH2SFTP.SFTPException {
	  Object[] list = remoteList.getSelectedValues();

	  for (int i = 0; i < list.length; i++) {
		  String item = (String)list[i];
		  String folderName = isFolder(item);
		  if (folderName == null) {
			  String message = "This function can't delete file outside folder!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  deleteDirRemote(expandRemote(folderName));
		  }
	  }	  	  
  }

  public void deleteDirRemote(String fullName) throws SSH2SFTP.SFTPException {
	  try
	  {
	  	  handle = sftp.opendir(fullName);
		  SSH2SFTP.FileAttributes[] flist = sftp.readdir(handle);

		  for (int i = 0; i < flist.length; i++) {
			  if (!flist[i].name.equals(".") && !flist[i].name.equals("..")) {
				  if (flist[i].isDirectory()) {
					  deleteDirRemote(fullName + "/" + flist[i].name);
				  }
				  else {
					  sftp.remove(fullName + "/" + flist[i].name);
				  }
			  }
		  }		  

		  sftp.rmdir(fullName);
	  }
	  finally {
		  try { sftp.close(handle); }
		  catch (Exception e) {  }
	  }	  	  
  }

  public void deleteRemote() throws SSH2SFTP.SFTPException {	  	
	  Object[] list = remoteList.getSelectedValues();
	  
	  for (int i = 0; i < list.length; i++) {
		  String item = (String)list[i];
		  String fileName = isFile(item);
		  if (fileName == null) {
			  String message = "This function can't delete folder!";
			  String title = "ISAGFTP - Warning";
			  JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		  }
		  else {
			  sftp.remove(expandRemote(fileName));
		  }
	  }
  }

  public void renameRemote(String newName) throws SSH2SFTP.SFTPException {
	  String oldName = (String)remoteList.getSelectedValue();  
	  String name = isFolder(oldName);
	  if (name == null) {
		  name = isFile(oldName);
	  }

	  sftp.rename(expandRemote(name), expandRemote(newName));
  }

  public void upload() 
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {		
	  Object[] list = localList.getSelectedValues();
//	  progressBar = new IsagProgressDialog();	  

	  for (int i = 0; i < list.length; i++) {
		  String name = isFolder((String)list[i]);
		  if (name != null) {
			  uploadFolder(localPath, remotePath, name);
		  }
		  else {
			  name = isFile((String)list[i]);

			  String localName = expandLocal(name);
			  String remoteName = expandRemote(name.replace(File.separatorChar, '/'));
			  uploadFile(localName, remoteName);
			  rls(remotePath);
		  }
	  }

	  String message = "Upload complete!";
	  String title = "ISAGFTP - Uploading";
	  JOptionPane.showConfirmDialog(this, message, title, -1, 1);

//	  progressBar.setButton();
  }

  public void uploadFolder(String lParentPath, String rParentPath, String folderName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
	  mkdirRemote(folderName);	  
	  rls(rParentPath);
	  remotePath = expandRemote(folderName);
	  
	  File dir = new File(expandLocal(folderName));
	  localPath = expandLocal(folderName);
	  File[] list = dir.listFiles();

	  for (int i = 0; i < list.length; i++) {
		  if (list[i].isDirectory()) {
			  uploadFolder(localPath, remotePath, list[i].getName());
		  }
		  else {
			  String localName = expandLocal(list[i].getName());
			  String remoteName = expandRemote(list[i].getName());
			  uploadFile(localName, remoteName);
			  rls(remotePath);
		  }
	  }

	  localPath = lParentPath;
	  remotePath = rParentPath;
  }

  public void uploadFile(String localName, String remoteName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
			  
	  File f = new File(localName);
	  handle = sftp.open(remoteName,
			   SSH2SFTP.SSH_FXF_WRITE |
			   SSH2SFTP.SSH_FXF_TRUNC |
			   SSH2SFTP.SSH_FXF_CREAT,
			   new SSH2SFTP.FileAttributes());
	  
	  FileInputStream fin = new FileInputStream(f);
/*
	  ProgressDialog progressDialog = 
		  new ProgressDialog(this, "Uploading", localName, remoteName, f.length());
	  handle.addAsyncListener(progressDialog);
*/
	  sftp.writeFully(handle, fin);
	  fin.close();
  }

  public void download() 
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {
	  Object[] list = remoteList.getSelectedValues();
//	  progressBar = new IsagProgressDialog();

	  for (int i = 0; i < list.length; i++) {
		  String name = isFolder((String)list[i]);
		  if (name != null) {
			  //name = name.replace('/', File.separatorChar);
			  downloadFolder(localPath, remotePath, name);
		  }
		  else {
			  name = isFile((String)list[i]);

			  String localName = expandLocal(name.replace('/', File.separatorChar));
			  String remoteName = expandRemote(name);
			  downloadFile(localName, remoteName);
			  lls(localPath);
		  }
	  }

	  String message = "Download complete!";
	  String title = "ISAGFTP - Downloading";
	  JOptionPane.showConfirmDialog(this, message, title, -1, 1);

//	  progressBar.setButton();
  }

  public void downloadFolder(String lParentPath, String rParentPath, String folderName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {
	  mkdirLocal(folderName);
	  lls(lParentPath);

	  localPath = expandLocal(folderName);	  
	  remotePath = expandRemote(folderName);

	  try
	  {
	  	  handle = sftp.opendir(remotePath);
		  SSH2SFTP.FileAttributes[] flist = sftp.readdir(handle);

		for (int i = 0; i < flist.length; i++) {
			if (!flist[i].name.equals(".") && !flist[i].name.equals("..")) {			  
				  if (flist[i].isDirectory()) {
					  //flist[i].name = flist[i].name.replace('/', File.separatorChar);
					  downloadFolder(localPath, remotePath, flist[i].name);
				  }
				  else {
					  String localName = expandLocal(flist[i].name.replace('/', File.separatorChar));
					  String remoteName = expandRemote(flist[i].name);
					  downloadFile(localName, remoteName);
					  lls(localPath);
				  }
			  }
		  }

		  localPath = lParentPath;
		  remotePath = rParentPath;
	  }
	  finally {
		  try { sftp.close(handle); }
		  catch (Exception e) {  }
	  }		  
  }

  public void downloadFile(String localName, String remoteName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
			  
	  handle = sftp.open(remoteName,
				SSH2SFTP.SSH_FXF_READ,
				new SSH2SFTP.FileAttributes());

	  attrs = sftp.fstat(handle);

	  RandomAccessFile file = new RandomAccessFile(localName, "rw");

	  int len = (int)attrs.size;
	  int foffs = 0;
	  int cnt   = 0;
/*
	  ProgressDialog progressDialog = 
		  new ProgressDialog(this, "Downloading", localName, remoteName, len);
	  handle.addAsyncListener(progressDialog);
*/
	  while(foffs < len) {
		  int n = (32768 < (len - foffs) ? 32768 : (int)(len - foffs));
		  sftp.read(handle, foffs, file, n);
		  foffs += n;
		  if(++cnt == 24) {
			  cnt = 0;
			  handle.asyncWait(12);
		  }
	  }
	  handle.asyncWait();

	  file.close();
	  sftp.close(handle);
  }

  public String expandRemote(String name) {
	  if(name.charAt(0) != '/')
	      name = remotePath + "/" + name;
	  return name;
  }

  public String expandLocal(String name) {
	  if(name.length() > 1 &&
	     name.charAt(0) != File.separatorChar &&
	     name.charAt(1) != ':') {
		 name = localPath + File.separator + name;
	  }
	  return name;
  }

  /*
  public static void main(String args[]) {
	  IsagTransferFrame frame = new IsagTransferFrame();
	  frame.show();
  }*/
}
