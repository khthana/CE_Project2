package ISAGFTP.isagftp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.UIManager;

public class IsagFTP
{
	public static final String version = "ISAGFTP_2.0";

	public IsagFTP() {
		IsagFrame frame = new IsagFrame();
		frame.show();		
	}

	public static void main(String[] args) {
		try 
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
	    catch(Exception e) {
			e.printStackTrace();
		}
    
		new IsagFTP();
	}
}
