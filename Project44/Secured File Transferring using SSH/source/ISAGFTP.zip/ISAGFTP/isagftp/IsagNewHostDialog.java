package ISAGFTP.isagftp;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Properties;
import javax.swing.*;
import javax.swing.event.*;

public class IsagNewHostDialog extends JDialog implements ActionListener
{
	IsagFrame parent;
	JTextField nameField = new JTextField(10);
	JTextField addressField = new JTextField(10);
	JTextField portField = new JTextField(5);
	JTextField userField = new JTextField(10);
	JPasswordField passwordField = new JPasswordField(10);
	JComboBox keyBox;
	JComboBox cipherC2SBox;
	JComboBox cipherS2CBox;
	JComboBox macC2SBox;
	JComboBox macS2CBox;
	JComboBox compC2SBox;
	JComboBox compS2CBox;
	JButton acceptButton = new JButton("Accept");
	JButton cancelButton = new JButton("Cancel");

	Object[] key = { "ssh-dss", "ssh-rsa" };
	Object[] cipher = {	
		"3des-cbc", "blowfish-cbc", "aes128-cbc", "twofish128-cbc", "cast128-cbc",
		"idea-cbc", "arcfour" };
	Object[] mac = { "hmac-sha1", "hmac-md5", "hmac-sha1-96", "hmac-md5-96" };
	Object[] comp = { "none", "zlib" };

	Container contentPane;
	Properties prop = new Properties(); 

	public IsagNewHostDialog(IsagFrame frame, String title) {
		super();
		parent = frame;
		jinit(title);
		pack();
	}

	public IsagNewHostDialog(IsagFrame frame, String title, Properties prop) {
		super();
		parent = frame;
		jinit(title);
		pack();

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();
		if (frameSize.height > screenSize.height) {
		  frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
		  frameSize.width = screenSize.width;
		}
		this.setLocation((screenSize.width - frameSize.width) / 2, 
							(screenSize.height - frameSize.height) / 2);

		getProperties(prop);
	}

	public void jinit(String title) {
		//setSize();
		setTitle(title);
		setResizable(false);
		setModal(true);		

		keyBox = new JComboBox(key);
		cipherC2SBox = new JComboBox(cipher);
		cipherS2CBox = new JComboBox(cipher);
		macC2SBox = new JComboBox(mac);
		macS2CBox = new JComboBox(mac);
		compC2SBox = new JComboBox(comp);
		compS2CBox = new JComboBox(comp);
		portField.setText("22");
		
		JPanel topPanel = new JPanel();
		JPanel centerPanel = new JPanel();
		JPanel bottomPanel = new JPanel();

		contentPane = getContentPane();
		contentPane.add(topPanel, "North");
		contentPane.add(centerPanel, "Center");
		contentPane.add(bottomPanel, "South");

		GridBagLayout gl1 = new GridBagLayout();
		topPanel.setLayout(gl1);
		GridBagConstraints gc1 = new GridBagConstraints();		
		gc1.weightx = 0;
		gc1.weighty = 0;
		gc1.fill = GridBagConstraints.NONE;
		gc1.anchor = GridBagConstraints.EAST;
		add(topPanel, new JLabel("Server name :"), gc1, 0, 0, 1, 1);
		add(topPanel, new JLabel("Address :"), gc1, 0, 1, 1, 1);
		add(topPanel, new JLabel("Username :"), gc1, 0, 2, 1, 1);
		add(topPanel, new JLabel("Key algorithm :"), gc1, 0, 3, 1, 1);
		gc1.anchor = GridBagConstraints.WEST;
		add(topPanel, nameField, gc1, 1, 0, 1, 1);
		add(topPanel, addressField, gc1, 1, 1, 1, 1);
		add(topPanel, userField, gc1, 1, 2, 1, 1);
		add(topPanel, keyBox, gc1, 1, 3, 1, 1);
		gc1.anchor = GridBagConstraints.EAST;
		add(topPanel, new JLabel("Port :"), gc1, 2, 1, 1, 1);
		add(topPanel, new JLabel("Password :"), gc1, 2, 2, 1, 1);
		gc1.anchor = GridBagConstraints.WEST;
		add(topPanel, portField, gc1, 3, 1, 1, 1);
		add(topPanel, passwordField, gc1, 3, 2, 1, 1);

		GridBagLayout gl2 = new GridBagLayout();
		centerPanel.setLayout(gl2);
		GridBagConstraints gc2 = new GridBagConstraints();		
		gc2.weightx = 0;
		gc2.weighty = 0;
		gc2.fill = GridBagConstraints.NONE;
		gc2.anchor = GridBagConstraints.CENTER;
		add(centerPanel, new JLabel("Transport Pref."), gc2, 0, 0, 1, 1);
		add(centerPanel, new JLabel("Client to Server"), gc2, 1, 0, 1, 1);
		add(centerPanel, new JLabel("Server to Client"), gc2, 2, 0, 1, 1);
		add(centerPanel, new JLabel("Cipher"), gc2, 0, 1, 1, 1);
		add(centerPanel, new JLabel("Mac"), gc2, 0, 2, 1, 1);
		add(centerPanel, new JLabel("Compression"), gc2, 0, 3, 1, 1);
		gc2.fill = GridBagConstraints.HORIZONTAL;
		add(centerPanel, cipherC2SBox, gc2, 1, 1, 1, 1);
		add(centerPanel, cipherS2CBox, gc2, 2, 1, 1, 1);
		add(centerPanel, macC2SBox, gc2, 1, 2, 1, 1);
		add(centerPanel, macS2CBox, gc2, 2, 2, 1, 1);
		add(centerPanel, compC2SBox, gc2, 1, 3, 1, 1);
		add(centerPanel, compS2CBox, gc2, 2, 3, 1, 1);

		bottomPanel.add(acceptButton);
		bottomPanel.add(cancelButton);

		acceptButton.setMargin(new Insets(1, 1, 1, 1));
		acceptButton.addActionListener(this);
		cancelButton.setMargin(new Insets(1, 1, 1, 1));
		cancelButton.addActionListener(this);

		addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e) {
							dispose();
						}
		});		
	}	

	public void add(JPanel panel, Component c, GridBagConstraints gbc, 
						int x, int y, int w, int h) {
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.gridwidth = w;
		gbc.gridheight = h;
		panel.add(c, gbc);
	}

	public void getProperties(Properties prop) {
		nameField.setText(prop.getProperty("server"));
		addressField.setText(prop.getProperty("address"));
		portField.setText(prop.getProperty("port"));
		userField.setText(prop.getProperty("user"));
		keyBox.setSelectedItem(prop.getProperty("server-host-key-algorithms"));
		cipherC2SBox.setSelectedItem(prop.getProperty("enc-algorithms-cli2srv"));
		cipherS2CBox.setSelectedItem(prop.getProperty("enc-algorithms-srv2cli"));
		macC2SBox.setSelectedItem(prop.getProperty("mac-algorithms-cli2srv"));
		macS2CBox.setSelectedItem(prop.getProperty("mac-algorithms-srv2cli"));
		compC2SBox.setSelectedItem(prop.getProperty("comp-algorithms-cli2srv"));
		compS2CBox.setSelectedItem(prop.getProperty("comp-algorithms-srv2cli"));
	}

	public void setProperties() {
		String name = nameField.getText().trim();
		String address = addressField.getText().trim();
		String port = portField.getText().trim();
		String user = userField.getText().trim();
		String password = new String(passwordField.getPassword()).trim();
		String key = (String)keyBox.getSelectedItem();
		String cipherC2S = (String)cipherC2SBox.getSelectedItem();
		String cipherS2C = (String)cipherS2CBox.getSelectedItem();
		String macC2S = (String)macC2SBox.getSelectedItem();
		String macS2C = (String)macS2CBox.getSelectedItem();
		String compC2S = (String)compC2SBox.getSelectedItem();
		String compS2C = (String)compS2CBox.getSelectedItem();

		prop.setProperty("server", name);
		prop.setProperty("address", address);
		prop.setProperty("port", port);		
		prop.setProperty("user", user);
		prop.setProperty("password", password);
		prop.setProperty("kex-algorithms", "diffie-hellman-group1-sha1");
		prop.setProperty("server-host-key-algorithms", key);
		prop.setProperty("enc-algorithms-cli2srv", cipherC2S);
		prop.setProperty("enc-algorithms-srv2cli", cipherS2C);
		prop.setProperty("mac-algorithms-cli2srv", macC2S);
		prop.setProperty("mac-algorithms-srv2cli", macS2C);
		prop.setProperty("comp-algorithms-cli2srv", compC2S);
		prop.setProperty("comp-algorithms-srv2cli", compS2C);
		prop.setProperty("languages-cli2srv", "");
		prop.setProperty("languages-srv2cli", "");

	}

	public void makePropFile(String name) throws FileNotFoundException, IOException {
		File Known_Host = new File(System.getProperty("user.home") + 
									File.separator + "Known_host");
		Known_Host.mkdir();

		FileOutputStream fout = new FileOutputStream(
			System.getProperty("user.home") + File.separator + "Known_host" + 
								File.separator + name + ".srv");
		prop.store(fout, "ISAGFTP properties file");
		fout.close();
	}

	public boolean hasBlank() {
		String name = nameField.getText();
		String address = addressField.getText();
		String port = portField.getText();
		String user = userField.getText();
		String password = new String(passwordField.getPassword());
		
		if ((name.trim().equals("")) || (name == null) || 
			(address.trim().equals("")) || (address == null) ||
			(port.trim().equals("")) ||	(port == null) ||
			(user.trim().equals("")) || (user == null) ||
			(password.trim().equals("")) || (password == null)) {
			return true;
		}
		else {
			return false;
		}
	}

	public void actionPerformed(ActionEvent a) {
		if (a.getSource() == acceptButton) {
			if (hasBlank()) {
				String message = "You must fill all input!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				setProperties();
				try
				{
					makePropFile(prop.getProperty("server"));
				}
				catch (FileNotFoundException fnfe) {
					String message = fnfe.getMessage();
					String title = "ISAGFTP - FileNotFoundException";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
				catch (IOException ioe) {
					String message = ioe.getMessage();
					String title = "ISAGFTP - IOException";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
				dispose();
			}
		}
		else if (a.getSource() == cancelButton) {
			dispose();
		}
	}
}
