package ISAGFTP.isagftp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.util.Properties;

import ISAGFTP.ssh1.ssh1engine.sftp;
import ISAGFTP.ssh1.ssh1engine.engine.SSHPropertyHandler;
import ISAGFTP.ssh1.ssh1engine.engine.SSHChannelController;

public class IsagSSH1Transfer extends JFrame 
implements ActionListener, MouseListener {
	
	private class ChangeDirThread extends Thread {
		IsagSSH1Transfer	transfer;
		sftp sec;
		String path;
		public ChangeDirThread(IsagSSH1Transfer transfer, sftp sec, String path) {
			this.transfer = transfer;
			this.sec = sec;
			this.path = path;
		}

		public void run() {
			try
			{
					String[] cmd = new String[2];
					cmd[0] = "cd";
					cmd[1] = path;
					sec.userCommand(cmd);
					transfer.setRemotePath(path);
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();					
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}					
			}
		}				
	};

	private class ListThread extends Thread {
		IsagSSH1Transfer	 transfer;
		sftp sec;
		public ListThread(IsagSSH1Transfer transfer, sftp sec) {
			this.transfer = transfer;
			this.sec = sec;
		}

		public void run() {
			try
			{
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	private class MkdirRemoteThread extends Thread {
		IsagSSH1Transfer transfer;
		sftp sec;
		String name;
		public MkdirRemoteThread(IsagSSH1Transfer transfer, sftp sec, String name) {
			this.transfer = transfer;
			this.sec = sec;
			this.name = name;
		}

		public void run() {
			try
			{
					//transfer.mkdirRemote(name);
					String[] cmd = new String[2];
					cmd[0] = "mkdir";
					cmd[1] = name;
					sec.userCommand(cmd);
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	private class RmdirRemoteThread extends Thread {
		IsagSSH1Transfer	 transfer;
		sftp sec;
		String name;
		public RmdirRemoteThread(IsagSSH1Transfer transfer, sftp sec, String name) {
			this.transfer = transfer;
			this.sec = sec;
			this.name = name;
		}

		public void run() {
			try
			{
					//transfer.rmdirRemote();
					String[] cmd = new String[2];
					cmd[0] = "rmdir";
					cmd[1] = name;
					sec.userCommand(cmd);
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	private class DeleteRemoteThread extends Thread {
		IsagSSH1Transfer	 transfer;
		sftp sec;
		String[] items;
		public DeleteRemoteThread(IsagSSH1Transfer transfer, sftp sec, String[] items) {
			this.transfer = transfer;
			this.sec = sec;
			this.items = items;
		}

		public void run() {
			try
			{
					//transfer.deleteRemote();
					for (int i = 0; i < items.length; i++) {
							String[] cmd = new String[2];
							cmd[0] = "delete";
							cmd[1] = items[i];
							sec.userCommand(cmd);
					}					
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	private class RenameRemoteThread extends Thread {
		IsagSSH1Transfer transfer;
		sftp sec;
		String oldName;
		String newName;
		public RenameRemoteThread(IsagSSH1Transfer transfer, sftp sec, String oldName, String newName) {
			this.transfer = transfer;
			this.sec = sec;
			this.oldName = oldName;
			this.newName = newName;
		}

		public void run() {
			try
			{
					String[] cmd = new String[3];
					cmd[0] = "rename";
					cmd[1] = oldName;
					cmd[2] = newName;
					sec.userCommand(cmd);
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	private class UploadThread extends Thread {
		IsagSSH1Transfer transfer;
		sftp sec;
		String[] items;
		String localDir;
		String remoteDir;
		public UploadThread(IsagSSH1Transfer transfer, sftp sec, String localDir, String remoteDir, String[] items) {
			this.transfer = transfer;
			this.sec = sec;			
			this.localDir = localDir;
			this.remoteDir = remoteDir;
			this.items = items;
		}

		public void run() {
			try
			{
					String[] cmd = new String[items.length + 1];
					cmd[0] = "mput";
					for (int i = 0; i < items.length; i++) {
							cmd[i + 1] = items[i];
					}
					sec.setLocalDir(localDir);
					sec.setRemoteDir(remoteDir);
					sec.userCommand(cmd);
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.rls();
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	private class DownloadThread extends Thread {
		IsagSSH1Transfer transfer;
		sftp sec;
		String localDir;
		String remoteDir;
		String[] items;
		public DownloadThread(IsagSSH1Transfer transfer, sftp sec, String localDir, String remoteDir, String[] items) {
			this.transfer = transfer;
			this.sec = sec;
			this.localDir = localDir;
			this.remoteDir = remoteDir;
			this.items = items;
		}

		public void run() {
			try
			{
					String[] cmd = new String[items.length + 1];
					cmd[0] = "mget";
					for (int i = 0; i < items.length; i++) {
							cmd[i + 1] = items[i];
					}
					sec.setLocalDir(localDir);
					sec.setRemoteDir(remoteDir);
					sec.userCommand(cmd);
					String[] cmdLs = new String[1];
					cmdLs[0] = "ls";
					sec.userCommand(cmdLs);
					transfer.lls(localDir);
			}
			catch (IOException ioe) {
					String message = ioe.getMessage();
					if (message.equals("NLST")) {
							transfer.setEmptyList();
					}
					else {
							String title = "ISAGFTP - IOException";
							JOptionPane.showConfirmDialog(transfer, message, title, -1, 0);
					}
			}
		}
	};

	JPanel contentPane;
	JPanel jPanel1 = new JPanel();
	JPanel jPanel2 = new JPanel();
	JPanel jPanel3 = new JPanel();
	JPanel jPanel4 = new JPanel();
	JPanel jPanel5 = new JPanel();
	JPanel jPanel6 = new JPanel();
	JPanel jPanel7 = new JPanel();
	JPanel jPanel8 = new JPanel();
	BorderLayout borderLayout1 = new BorderLayout();
	BorderLayout borderLayout2 = new BorderLayout();
	JScrollPane jScrollPane1 = new JScrollPane();
	JScrollPane jScrollPane2 = new JScrollPane();
	JList localList = new JList();
	JList remoteList = new JList();
	JButton lDirUpButton = new JButton();
	JButton rDirUpButton = new JButton();
	JTextField localField = new JTextField(15);
	JTextField remoteField = new JTextField(15);
	JButton lRefreshButton = new JButton();
	JButton rRefreshButton = new JButton();
	JButton uploadButton = new JButton();
	JButton lRenameButton = new JButton();
	JButton lDeleteButton = new JButton();
	JButton lRmdirButton = new JButton();
	JButton lMkdirButton = new JButton();
	FlowLayout flowLayout1 = new FlowLayout();
	JButton rMkdirButton = new JButton();
	JButton downloadButton = new JButton();
	JButton rRenameButton = new JButton();
	JButton rDeleteButton = new JButton();
	JButton rRmdirButton = new JButton();
	FlowLayout flowLayout2 = new FlowLayout();
	BorderLayout borderLayout3 = new BorderLayout();
	BorderLayout borderLayout4 = new BorderLayout();
	BorderLayout borderLayout5 = new BorderLayout();
	BorderLayout borderLayout6 = new BorderLayout();
	BorderLayout borderLayout7 = new BorderLayout();

	String localPath;
	String remotePath;
	
	sftp					sec;	
	SSHPropertyHandler		sshProp;
	SSHChannelController controller;
	String					host;
	int						localForwardPort;
	IsagFrame				parent;
	Properties				props;
	Properties				lists;

	public IsagSSH1Transfer(IsagFrame parent, Properties props) {
		this.parent = parent;
		this.props = props;

		jbInit();
	}

	public void setSSHProps(SSHChannelController controller, SSHPropertyHandler sshProp, String host, int localForwardPort) {
		this.controller = controller;
		this.sshProp       = sshProp;
		this.host				= host;
		this.localForwardPort = localForwardPort;
	}

	public void connect() {
		try 
		{
			sec = new sftp();
			sec.connect(this, host, localForwardPort);
			sec.Authentication(props.getProperty("user"), props.getProperty("password"));			
			sec.setPassive(true);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}	

	public void jbInit() {
		contentPane = (JPanel) this.getContentPane();
		contentPane.setLayout(borderLayout5);
		this.setSize(new Dimension(549, 354));	
		this.setResizable(false);
		this.setTitle("ISAGFTP - Transferring");
		jPanel1.setBackground(Color.pink);
		jPanel1.setLayout(borderLayout3);
		jPanel2.setLayout(borderLayout4);
		jPanel2.setBackground(Color.orange);
		jPanel3.setLayout(borderLayout6);
		jPanel4.setLayout(borderLayout1);
		jPanel5.setLayout(flowLayout1);
		jPanel6.setLayout(borderLayout2);
		jPanel7.setLayout(borderLayout7);
		jPanel8.setLayout(flowLayout2);
		lDirUpButton.setIcon(new ImageIcon("ISAGFTP" + File.separator + "isagftp" + 
										File.separator + "dirUp.gif"));
		lDirUpButton.setMargin(new Insets(1, 1, 1, 1));
		rDirUpButton.setMargin(new Insets(0, 0, 1, 1));
		lRefreshButton.setMargin(new Insets(0, 0, 0, 0));
		rDirUpButton.setIcon(new ImageIcon("ISAGFTP" + File.separator + "isagftp" + 
										File.separator + "dirUp.gif"));
		lRefreshButton.setText("refresh");
		rRefreshButton.setText("refresh");
		rRefreshButton.setMargin(new Insets(0, 0, 0, 0));
		uploadButton.setMargin(new Insets(0, 5, 0, 5));
		uploadButton.setText("-->");
		lRenameButton.setText("rename");
		lRenameButton.setMargin(new Insets(0, 0, 0, 0));
		lDeleteButton.setText("delete");
		lDeleteButton.setMargin(new Insets(0, 0, 0, 0));
		lRmdirButton.setMargin(new Insets(0, 0, 0, 0));
		lRmdirButton.setText("rmdir");
		lMkdirButton.setText("mkdir");
		lMkdirButton.setMargin(new Insets(0, 0, 0, 0));
		rMkdirButton.setMargin(new Insets(0, 0, 0, 0));
		rMkdirButton.setText("mkdir");
		downloadButton.setText("<--");
		downloadButton.setMargin(new Insets(0, 5, 0, 5));
		rRenameButton.setMargin(new Insets(0, 0, 0, 0));
		rRenameButton.setText("rename");
		rDeleteButton.setMargin(new Insets(0, 0, 0, 0));
		rDeleteButton.setText("delete");
		rRmdirButton.setText("rmdir");
		rRmdirButton.setMargin(new Insets(0, 0, 0, 0));
		contentPane.add(jPanel1, BorderLayout.WEST);
		jPanel1.add(jPanel3, BorderLayout.NORTH);
		jPanel3.add(lDirUpButton, BorderLayout.WEST);
		jPanel1.add(jPanel4, BorderLayout.CENTER);
		jPanel4.add(jScrollPane1, BorderLayout.CENTER);
		jScrollPane1.getViewport().add(localList, null);
		jPanel1.add(jPanel5, BorderLayout.SOUTH);
		jPanel5.add(lMkdirButton, null);
		jPanel5.add(lRmdirButton, null);
		jPanel5.add(lDeleteButton, null);
		jPanel5.add(lRenameButton, null);
		jPanel5.add(uploadButton, null);
		contentPane.add(jPanel2, BorderLayout.CENTER);
		jPanel2.add(jPanel8, BorderLayout.SOUTH);
		jPanel2.add(jPanel6, BorderLayout.CENTER);
		jPanel6.add(jScrollPane2, BorderLayout.CENTER);
		jScrollPane2.getViewport().add(remoteList, null);
		jPanel2.add(jPanel7, BorderLayout.NORTH);
		jPanel7.add(rDirUpButton, BorderLayout.WEST);
		jPanel3.add(localField, BorderLayout.CENTER);
		jPanel7.add(remoteField, BorderLayout.CENTER);
		jPanel7.add(rRefreshButton, BorderLayout.EAST);
		jPanel3.add(lRefreshButton, BorderLayout.EAST);
		jPanel8.add(downloadButton, null);
		jPanel8.add(rMkdirButton, null);
		jPanel8.add(rRmdirButton, null);
		jPanel8.add(rDeleteButton, null);
		jPanel8.add(rRenameButton, null);

		localField.addActionListener(this);
		lDirUpButton.addActionListener(this);
		lRefreshButton.addActionListener(this);
		localList.addMouseListener(this);
		lMkdirButton.addActionListener(this);
		lRmdirButton.addActionListener(this);
		lDeleteButton.addActionListener(this);
		lRenameButton.addActionListener(this);

		remoteField.addActionListener(this);
		rDirUpButton.addActionListener(this);
		rRefreshButton.addActionListener(this);
		remoteList.addMouseListener(this);
		rMkdirButton.addActionListener(this);
		rRmdirButton.addActionListener(this);
		rDeleteButton.addActionListener(this);
		rRenameButton.addActionListener(this);

		uploadButton.addActionListener(this);
		downloadButton.addActionListener(this);

		addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e) {
								disconnect();		
						}
		});		

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();
		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}
		this.setLocation((screenSize.width - frameSize.width) / 2, 
							(screenSize.height - frameSize.height) / 2);						
	}

	public void disconnect() {
		try
		{
			sec.closeServer();
			controller.killAll();
			controller = null;
			parent.disconnect();			
			parent.show();
			this.dispose();
		} catch (IOException e) {
			// ****************************** /
		}
	}
/*
	public void connect() {
	//  String host = props.getProperty("address");
	//  int port = Integer.parseInt(props.getProperty("port"));
	//  String username = props.getProperty("user");
	//  String password = props.getProperty("password");

		IsagTerm controller = new IsagTerm(new Properties(), new Properties(), props);
//		controller.cmdLineArgs = argv;
    
		try {
			controller.getApplicationParams();
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			System.exit(1);
		}

		try {
			controller.start();
		} catch (Exception e) {
			System.out.println("Error, please mail below stack-trace to s0010058@ce.kmitl.ac.th");
			e.printStackTrace();
		}	  
	}
*/
	public void mouseClicked(MouseEvent a) {
		if (a.getSource() == localList) {
			remoteList.clearSelection();
			if (a.getClickCount() > 1) {
				String item = (String)localList.getSelectedValue();
				if (item.startsWith("[")) {
					String dir = item.substring(1, item.indexOf("]"));
					localPath = localPath + File.separator + dir;
					lls(localPath);
				}
			}		  
		}
		else if (a.getSource() == remoteList) {
			localList.clearSelection();
			if (a.getClickCount() > 1) {
				String item = (String)remoteList.getSelectedValue();
				if (item.startsWith("[")) {
					String dir = item.substring(1, item.indexOf("]"));
					//remotePath = expandRemote(remotePath);	
					//try
					//{
						//rls(remotePath);
						new ChangeDirThread(this, sec, dir).start();
						//sec.userCommand("cd " + dir);
						//sec.userCommand("ls");
					//} catch (IOException e) {
						// ****************************** /
					//}										
				}
			}		  
		}
	}

	public void mouseEntered(MouseEvent a) {
	}

	public void mouseExited(MouseEvent a) {
	}

	public void mousePressed(MouseEvent a) {
	}

	public void mouseReleased(MouseEvent a) {
	}

	public void actionPerformed(ActionEvent a) {
		if (a.getSource() == localField) {
			String newPath = localField.getText();
			if (newPath.endsWith(":")) {
				newPath = newPath + File.separator;
			}
			localPath = newPath;
			lls(newPath);		  
		}
		else if (a.getSource() == lDirUpButton) {		  
			localPath = localPath.substring(0, localPath.lastIndexOf(File.separator));
			if (localPath.endsWith(":")) {
				localPath = localPath + File.separator;
			}
			lls(localPath);
		}
		else if (a.getSource() == lRefreshButton) {
			lls(localPath);
		}
		else if (a.getSource() == lMkdirButton) {
			String input;
			String message = "Please enter folder name";
			String title = "ISAGFTP - New Folder";
			input = JOptionPane.showInputDialog(this, message, title, 1);

			if (input != null && !input.trim().equals("")) {
				mkdirLocal(input);			  
			}
		}
		else if (a.getSource() == lRmdirButton) {
			if (localList.isSelectionEmpty()) {
				String message = "Please select folders before delete";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				int confirm;
				String message = "Are you sure you want to delete selected folders";
				String title = "ISAGFTP - Removing Folders";
				confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
				if (confirm == 0) {
					rmdirLocal();
					lls(localPath);
				}
			}
		}
		else if (a.getSource() == lDeleteButton) {
			if (localList.isSelectionEmpty()) {
				String message = "Please select files before delete";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				int confirm;
				String message = "Are you sure you want to delete selected files";
				String title = "ISAGFTP - Deleting";
				confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
				if (confirm == 0) {
					deleteLocal();
					lls(localPath);
				}
			}
		}
		else if (a.getSource() == lRenameButton) {
			if (localList.isSelectionEmpty()) {
				String message = "Please select files before delete";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				Object[] list = localList.getSelectedValues();
				if (list.length > 1) {
					String message = "This function doesn't support multiple renaming!";
					String title = "ISAGFTP - Warning";
					JOptionPane.showConfirmDialog(this, message, title, -1, 2);
				}
				else {
					String input;
					String message = "Please enter new name";
					String title = "ISAGFTP - Renaming";
					input = JOptionPane.showInputDialog(this, message, title, 1);
				  
					if (input.trim() != null) {
						renameLocal(input);
						lls(localPath);
					}
				}
			}
		}
		else if (a.getSource() == remoteField) {
			//try
			//{
				String path = remoteField.getText();
				new ChangeDirThread(this, sec, path).start();
				/*sec.userCommand("cd " + remotePath);
				sec.userCommand("ls");*/
				//rls(remotePath);
			//} catch (IOException e) {
				// *************************** /
			//}			
		}
		else if (a.getSource() == rDirUpButton) {
			if (remotePath.equals("/")) {
				String message = "This is the root directory!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {			  
				//try
				//{
					String path = remotePath.substring(0, remotePath.lastIndexOf("/"));
					new ChangeDirThread(this, sec, path).start();
					/*sec.userCommand("cd " + remotePath);
					sec.userCommand("ls");*/
					//f.cdup();
					//rls(remotePath);
				//} catch (IOException e) {
					// *************************** /
				//}			
			}
		}
		else if (a.getSource() == rRefreshButton) {
			//try
			//{
				//rls(remotePath);
				new ListThread(this, sec).start();
				//sec.userCommand("ls");				
			//} catch (IOException e) {
				// ******************************** /
			//}
	
		}
		else if (a.getSource() == rMkdirButton) {
			String input;
			String message = "Please enter folder name";
			String title = "ISAGFTP - New Folder";
			input = JOptionPane.showInputDialog(this, message, title, 1);

			if (input != null && !input.trim().equals("")) {
				//try
				//{
					new MkdirRemoteThread(this, sec, input).start();
					/*mkdirRemote(input);
					sec.userCommand("ls");*/
				//} catch (IOException e) {
					// *************************** /
				//}
			}
		}
		else if (a.getSource() == rRmdirButton) {
			if (remoteList.isSelectionEmpty()) {
				String message = "Please select folders before delete";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				int confirm;
				String message = "Are you sure you want to delete selected folders";
				String title = "ISAGFTP - Removing Folders";
				confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
				if (confirm == 0) {
					Object[] list = remoteList.getSelectedValues();
					for (int i = 0; i < list.length; i++) {
						String item = (String)list[i];
						String folderName = isFolder(item);
						if (folderName == null) {
							message = "This function can't delete file !";
							title = "ISAGFTP - Warning";
							JOptionPane.showConfirmDialog(this, message, title, -1, 2);
						}
						else {
							//deleteDirRemote(expandRemote(folderName));
							new RmdirRemoteThread(this, sec, folderName).start();
							//sec.userCommand("rmdir " + folderName);
						}
					}					
				}
			}
		}
		else if (a.getSource() == rDeleteButton) {
			if (remoteList.isSelectionEmpty()) {
				String message = "Please select files before delete";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				int confirm;
				String message = "Are you sure you want to delete selected files";
				String title = "ISAGFTP - Deleting";
				confirm = JOptionPane.showConfirmDialog(this, message, title, 0, 2);
				if (confirm == 0) {
					Object[] list = remoteList.getSelectedValues();
					int len = 0;
					for (int i = 0; i < list.length; i++) {
						String fileName = (String)list[i];
						fileName = isFile(fileName);
						if (fileName == null) {
							message = "This function can't delete folder!";
							title = "ISAGFTP - Warning";
							JOptionPane.showConfirmDialog(this, message, title, -1, 2);
						}
						else { 
							len++;
						}
					}
					String[] items = new String[len];
					len = 0;
					for (int i = 0; i < list.length; i++) {
						String fileName = (String)list[i];
						fileName = isFile(fileName);
						if (fileName != null) {
							items[len] = fileName;
							len++;
						}						
							//sec.userCommand("delete " + fileName);
						//}
					}
					new DeleteRemoteThread(this, sec, items).start();
				}
			}
		}
		else if (a.getSource() == rRenameButton) {
			if (remoteList.isSelectionEmpty()) {
				String message = "Please select files before delete";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				Object[] list = remoteList.getSelectedValues();
				if (list.length > 1) {
					String message = "This function doesn't support multiple renaming!";
					String title = "ISAGFTP - Warning";
					JOptionPane.showConfirmDialog(this, message, title, -1, 2);
				}
				else {
					String input;
					String message = "Please enter new name";
					String title = "ISAGFTP - Renaming";
					input = JOptionPane.showInputDialog(this, message, title, 1);
				  
					if (input != null && !input.trim().equals("")) {
						//try
						//{
							String oldName = (String)remoteList.getSelectedValue();
							if (oldName.startsWith("[")) {
									oldName = oldName.substring(1, oldName.indexOf("]"));
							}
							new RenameRemoteThread(this, sec, oldName, input).start();
							/*renameRemote(input);
							sec.userCommand("ls");*/
							//rls(remotePath);
						//} catch (IOException e) {
							// ******************************** /
						//}
					}
				}
			}
		}
		else if (a.getSource() == uploadButton) {
			if (localList.isSelectionEmpty()) {
				String message = "Please select files/folders before upload!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				Object[] object = localList.getSelectedValues();
				String[] items = new String[object.length];
				for (int i = 0; i < object.length; i++) {
						//items[i] = expandLocal((String)object[i]);
						items[i] = (String)object[i];
						if (items[i].startsWith("[")) {
								items[i] = items[i].substring(1, items[i].indexOf("]"));
						}
						else {
								items[i] = items[i].substring(0, items[i].indexOf("("));
								items[i].trim();
						}
				}
				new UploadThread(this, sec, localPath, remotePath, items).start();
			 	//upload();
				//sec.userCommand("ls");
			//	rls(remotePath);
			  
			}
		}
		else if (a.getSource() == downloadButton) {
			if (remoteList.isSelectionEmpty()) {
				String message = "Please select files/folders before download!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				Object[] object = remoteList.getSelectedValues();
				String[] items = new String[object.length];
				for (int i = 0; i < object.length; i++) {
						//items[i] = expandRemote((String)object[i]);
						items[i] = (String)object[i];
						if (items[i].startsWith("[")) {
								items[i] = items[i].substring(1, items[i].indexOf("]"));
						}						
				}
				new DownloadThread(this, sec, localPath, remotePath, items).start();
			 	//download();
				//sec.userCommand("ls");
			//	lls(localPath);
			  
			}
		}
	}

	public void lls(String path) {
		try
		{
			File dir = new File(path);
			File[] f = dir.listFiles();
			Object[] list = new Object[f.length];
			int top = 0;
			int bottom = f.length - 1;

			for (int i = 0; i < f.length; i++) {
				if (f[i].isDirectory()) {
					list[top] = "[" + f[i].getName() + "]";
					top++;
				}
				else {
					list[bottom] = f[i].getName() + " (" + f[i].length() + ")";
					bottom--;
				}
			}

			localField.setText(localPath);
			localList.setListData(list);
		}
		catch (NullPointerException npe) {
			String message = "Can't read path " + path + " !";
			String title = "ISAGFTP - Exception";
			JOptionPane.showConfirmDialog(this, message, title, -1, 2);
		}
	}

	public void mkdirLocal(String newDir) {
		File dir = new File(localPath + File.separator + newDir);
		if (dir.mkdir()) {
			lls(localPath);
		}
		else {
			String message = "Can't create new folder by this name!";
			String title = "ISAGFTP - Error Message";
			JOptionPane.showConfirmDialog(this, message, title, -1, 0);
		}
	}

	public void rmdirLocal() {
		Object[] list = localList.getSelectedValues();
		for (int i = 0; i < list.length; i++) {
			String item = (String)list[i];
			String folderName = isFolder(item);
			if (folderName == null) {
				String message = "This function can't delete file outside folder!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				deleteDirLocal(localPath + File.separator + folderName);
			}
		}
	}

	public void deleteLocal() {
		Object[] list = localList.getSelectedValues();
		for (int i = 0; i < list.length; i++) {
			String item = (String)list[i];
			String fileName = isFile(item);
			if (fileName == null) {
				String message = "This function can't delete folder!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				fileName = fileName.substring(0, fileName.indexOf("("));
				fileName.trim();
				File f = new File(localPath + File.separator + fileName);
				if (!f.delete()) {
					String message = "Can't delete file " + fileName + "!";
					String title = "ISAGFTP - Error Message";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
			}
		}
	}

	public void renameLocal(String newName) {
		String oldName = (String)localList.getSelectedValue();	  
		String name = isFolder(oldName);
		if (name == null) {
			name = isFile(oldName);
		}

		File oldFile = new File(localPath + File.separator + name);
		if (!oldFile.renameTo(new File(localPath + File.separator + newName))) {
			String message = "Can't rename " + name + " to " + newName;
			String title = "ISAGFTP - Error Message";
			JOptionPane.showConfirmDialog(this, message, title, -1, 0);
		}
	}

	public void deleteDirLocal(String fullName) {
		File dir = new File(fullName);
		File[] list = dir.listFiles();

		for (int i = 0; i < list.length; i++) {
			if (list[i].isDirectory()) {
				deleteDirLocal(fullName + File.separator + list[i].getName());
			}
			else {
				if (!list[i].delete()) {
					String message = "Can't delete file " + list[i].getName();
					String title = "ISAGFTP - Error Message";
					JOptionPane.showConfirmDialog(this, message, title, -1, 0);
				}
			}
		}

		if (!dir.delete()) {
			String message = "Can't delete folder " + dir.getName();
			String title = "ISAGFTP - Error Message";
			JOptionPane.showConfirmDialog(this, message, title, -1, 0);
		}
	}

	public String isFolder(String input) {
		if (input.startsWith("[")) {
			String folderName = input.substring(1, input.indexOf("]"));
			return folderName;
		}
		else {
			return null;
		}
	}

	public String isFile(String input) {
		if (input.startsWith("[")) {
			return null;
		}
		else {
			return input;
		}
	}

	public void setDirPath() {
		localPath = System.getProperty("user.home");	  
		lls(localPath);
		try
		{
			//remotePath = "/";
			//rls(remotePath);
			String[] cmd = new String[1];
			cmd[0] = "ls";
			sec.userCommand(cmd);
			rls();
		} catch (IOException ioe) {
				String message = ioe.getMessage();
				String title = "ISAGFTP - IOException";
				JOptionPane.showConfirmDialog(this, message, title, -1, 0);
		}
	}

	public void setListFiles(Properties lists) {
			this.lists = lists;
	}

	public void setEmptyList() {
			Object[] list = {"" };
			remoteList.setListData(list);	
	}

	public void setRemotePath(String path) {
		remotePath = expandRemote(path);
		remoteField.setText(remotePath);
	}
/*
	public void setFileList(Properties remoteFileList) {
		this.remoteFileList = remoteFileList;
	}
*/
	public void rls() throws IOException {
		Object[] list = new Object[lists.size()];
		int top = 0;
		int bottom = list.length - 1;

		for(int i = 0; i < list.length; i++) {
		//	if (!flist[i].name.equals(".") && !flist[i].name.equals("..")) {
			String file = lists.getProperty(Integer.toString(i));
			if (file.indexOf(".") == -1) {
				list[top] = "[" + file + "]";
				top++;
			}
			else {
				list[bottom] = file;
				bottom--;
			}
	/*		list[top] = ls.getProperty(Integer.toString(top));
			top++;*/
	  	}
		//remoteField.setText(path);
		String[] cmd = new String[1];
		cmd[0] = "pwd";
		sec.userCommand(cmd);
		remoteList.setListData(list);	
	}
/*
	public void mkdirRemote(String newDir) throws IOException {
		sec.userCommand("mkdir " + newDir);
	}
*/
/*
	public void rmdirRemote() throws IOException {	
		Object[] list = remoteList.getSelectedValues();
		for (int i = 0; i < list.length; i++) {
			String item = (String)list[i];
			String folderName = isFolder(item);
			if (folderName == null) {
				String message = "This function can't delete file !";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				//deleteDirRemote(expandRemote(folderName));
				sec.userCommand("rmdir " + folderName);
			}
		}	  	  
	}
*/
/*
	public void deleteDirRemote(String fullName) throws IOException {
	 		Properties ls = f.ls(fullName);
			int len = 0;

			while (ls.hasMoreTokens()) {
				len++;
			}

			Object[] list = new Object[len];
			int top = 0;
			int bottom = list.length - 1;
	*/
		//	for (int i = 0; i < list.length; i++) {
			/*	if (!flist[i].name.equals(".") && !flist[i].name.equals("..")) {
					if (flist[i].isDirectory()) {
						deleteDirRemote(fullName + "/" + flist[i].name);
					}
					else {
						f.delete(fullName + "/" + flist[i].name);
					}
				}	
		//	}		  

		//	f.rmdir(fullName);
	}
*/
/*
	public void deleteRemote() throws IOException {
		Object[] list = remoteList.getSelectedValues();
		for (int i = 0; i < list.length; i++) {
			String item = (String)list[i];
			String fileName = isFile(item);
			if (fileName == null) {
				String message = "This function can't delete folder!";
				String title = "ISAGFTP - Warning";
				JOptionPane.showConfirmDialog(this, message, title, -1, 2);
			}
			else {
				sec.userCommand("delete " + fileName);
			}
		}
	}

	public void renameRemote(String newName) throws IOException {
		String oldName = (String)remoteList.getSelectedValue();  
		sec.userCommand("rename " + expandRemote(oldName) + expandRemote(newName));		
	/*	String oldName = (String)remoteList.getSelectedValue();  
		String name = isFolder(oldName);
		if (name == null) {
			name = isFile(oldName);
		}

		f.rename(expandRemote(name), expandRemote(newName));
	}
*//*
  public void upload() {
  }
  */
/*
  public void uploadFolder(String lParentPath, String rParentPath, String folderName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
	  mkdirRemote(folderName);	  
	  rls(rParentPath);
	  remotePath = expandRemote(folderName);
	  
	  File dir = new File(expandLocal(folderName));
	  localPath = expandLocal(folderName);
	  File[] list = dir.listFiles();

	  for (int i = 0; i < list.length; i++) {
		  if (list[i].isDirectory()) {
			  uploadFolder(localPath, remotePath, list[i].getName());
		  }
		  else {
			  String localName = expandLocal(list[i].getName());
			  String remoteName = expandRemote(list[i].getName());
			  uploadFile(localName, remoteName);
			  rls(remotePath);
		  }
	  }

	  localPath = lParentPath;
	  remotePath = rParentPath;
  }

	public void uploadFile(String localName, String remoteName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
			  
	  File f = new File(localName);
	  handle = sftp.open(remoteName,
			   SSH2SFTP.SSH_FXF_WRITE |
			   SSH2SFTP.SSH_FXF_TRUNC |
			   SSH2SFTP.SSH_FXF_CREAT,
			   new SSH2SFTP.FileAttributes());
	  
	  FileInputStream fin = new FileInputStream(f);
  
//	  progressBar.setSenderLocation(localName);
//	  progressBar.setReceiverLocation(remoteName);
//	  handle.addAsyncListener(progressBar);
//	  progressBar.start((int)f.length());

	  sftp.writeFully(handle, fin);
	  fin.close();
  }
*//*
  public void download() {
  }
  */
/*
  public void downloadFolder(String lParentPath, String rParentPath, String folderName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
	  mkdirLocal(folderName);
	  lls(lParentPath);

	  localPath = expandLocal(folderName);	  
	  remotePath = expandRemote(folderName);

	  try
	  {
	  	  handle = sftp.opendir(remotePath);
		  SSH2SFTP.FileAttributes[] flist = sftp.readdir(handle);

		  for (int i = 0; i < flist.length; i++) {
			  if (flist[i].isDirectory()) {
				  downloadFolder(localPath, remotePath, flist[i].name);
			  }
			  else {
				  String localName = expandLocal(flist[i].name.replace('/', File.separatorChar));
				  String remoteName = expandRemote(flist[i].name);
				  downloadFile(localName, remoteName);
				  lls(localPath);
			  }
		  }

		  localPath = lParentPath;
		  remotePath = rParentPath;
	  }
	  finally {
		  try { sftp.close(handle); }
		  catch (Exception e) {  }
	  }		  
  }

  public void downloadFile(String localName, String remoteName)
  throws SSH2SFTP.SFTPException, FileNotFoundException, IOException {	  
			  
	  handle = sftp.open(remoteName,
				SSH2SFTP.SSH_FXF_READ,
				new SSH2SFTP.FileAttributes());

	  attrs = sftp.fstat(handle);

	  RandomAccessFile file = new RandomAccessFile(localName, "rw");

	  int len = (int)attrs.size;
	  int foffs = 0;
	  int cnt   = 0;

//	  progressBar.setSenderLocation(localName);
//	  progressBar.setReceiverLocation(remoteName);
//	  handle.addAsyncListener(progressBar);
//	  progressBar.start(len);

	  while(foffs < len) {
		  int n = (32768 < (len - foffs) ? 32768 : (int)(len - foffs));
		  sftp.read(handle, foffs, file, n);
		  foffs += n;
		  if(++cnt == 24) {
			  cnt = 0;
			  handle.asyncWait(12);
		  }
	  }
	  handle.asyncWait();

	  file.close();
	  sftp.close(handle);
  }
*/
	public String expandRemote(String name) {
		if(name.charAt(0) != '/')
			name = remotePath + "/" + name;
		return name;
	}

	public String expandLocal(String name) {
		if(name.length() > 1 &&
			name.charAt(0) != File.separatorChar &&
			name.charAt(1) != ':') {
			name = localPath + File.separator + name;
		}
		return name;
	}

}
