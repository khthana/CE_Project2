package ISAGFTP.isagftp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import ISAGFTP.ssh2.ssh2engine.engine.SSH2SFTP;

public class ProgressDialog extends JDialog 
implements SSH2SFTP.AsyncListener {

	IsagSSH2Transfer parent;
	JPanel panel1 = new JPanel();
	JLabel localLabel = new JLabel();
	JLabel remoteLabel = new JLabel();
	JLabel speedLabel = new JLabel();
	JProgressBar progressBar = new JProgressBar();
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	
	long totalSize;
	long curSize;
	long start;
	static final String[] prefix = { "", "k", "M", "G", "T" };

	public ProgressDialog(IsagSSH2Transfer parent, String direction, 
							String local, String remote, long maxSize) {
		
		super(parent, "ISAGFTP - " + direction, true);		
		this.totalSize = maxSize;
		this.curSize   = 0;
		start = System.currentTimeMillis();

		localLabel.setText("From " + local);
		remoteLabel.setText("To   " + remote);
		progressBar.setMinimum(0);
		progressBar.setMaximum((int)maxSize);
		progressBar.setValue(0);
		jbInit();
	}

	public void progress(long size) {
		long now = System.currentTimeMillis();

		curSize += size;
		int perc = (int)(totalSize > 0 ?
				 ((100 * curSize) / totalSize) : 100);
		progressBar.setValue(perc);

		int i;
		StringBuffer buf = new StringBuffer();

		//buf.append("\r " + perc + "%\t|");
		//int len = (int)((double)32 * ((double)perc / 100));

		/*for(i = 0; i < len; i++) {
		buf.append('*');
		}
		for(i = len; i < 32; i++) {
		buf.append(' ');
		}*/
		long printSize = curSize;
		i = 0;
		while(printSize >= 100000) {
		i++;
		printSize >>>= 10;
		}
		buf.append("|  " + printSize + " " + prefix[i] + "bytes");

		long elapsed = (now - start);
		if(elapsed == 0) {
		elapsed = 1;
		}

		int curSpeed = (int)((double)curSize / ((double)elapsed / 1000));

		i = 0;
		while(curSpeed >= 100000) {
		i++;
		curSpeed >>>= 10;
		}
		buf.append(" (" + curSpeed + " " + prefix[i] + "B/sec)   ");

		//linereader.print(buf.toString());
		speedLabel.setText(buf.toString());
	}

	public void jbInit() {
		this.setResizable(false);
		panel1.setLayout(gridBagLayout1);
		getContentPane().add(panel1);
		panel1.add(remoteLabel,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
				,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(7, 1, 0, 7), 1, 8));
		panel1.add(speedLabel,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
				,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(7, 1, 0, 7), 1, 8));
		panel1.add(localLabel,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
				,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(1, 1, 0, 7), 1, 8));
		panel1.add(progressBar,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 1, 6, 5), 1, 9));
		addWindowListener(new WindowAdapter() {
					public void windowClosing(WindowEvent e) {					
					}
		});
		this.pack();
		this.show();
	}
}