<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<jsp:useBean id="user" 
			 class="java.util.Vector"
			 scope="application" />
<BODY>
<%
	String name = request.getParameter("Name");
	session.putValue("Name",name);
	session.putValue("ListenTo",name);
	user.addElement(name);
%>
<h1>Select room</h1>
<A HREF="ChatRoom.html">��ͧ�á</A>
</BODY>
</HTML>
