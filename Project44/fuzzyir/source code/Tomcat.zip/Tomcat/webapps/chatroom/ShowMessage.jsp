<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<META HTTP-EQUIV=Refresh CONTENT="5; URL=ShowMessage.jsp">
</HEAD>

<jsp:useBean id="board" 
			 class="Board"
			 scope="application" />

<BODY>
<H1>Message display here</H1>
<% 
	String listenTo = (String)session.getValue("ListenTo");		
	int lastIndex = board.getNumLine() - 1;
	String curMessage = board.getMessage(lastIndex);
	String user = board.getName(lastIndex);
	if (user.equals(listenTo)){
		String oldMessage = (String)session.getValue("OldMessage");
		if (oldMessage == null) oldMessage = new String("Old Message");
		if (!curMessage.equals(oldMessage)){
			String path = "c:\\Tomcat\\webapps\\chatroom\\";			
			String fileWave = "chat.wav";
			String voice = board.getLastVoice();
			SynthesizerTest st = new SynthesizerTest();			
			st.setVoice(voice);
			st.speakToFile(curMessage, path + fileWave);			
			out.println("<bgsound src=\"" + fileWave + "\">");
			session.putValue("OldMessage", curMessage);
		}
	}

	for (int i=0; i<board.getNumLine(); i++){
		out.println("<h4>" + board.getName(i) + " : " + board.getMessage(i) + "</h4>"); 
	}
%>
</BODY>
</HTML>
