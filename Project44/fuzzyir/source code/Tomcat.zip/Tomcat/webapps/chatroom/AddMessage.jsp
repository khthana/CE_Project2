<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<jsp:useBean id="board" 
			 class="Board"
			 scope="application" />

<jsp:useBean id="user" 
			 class="java.util.Vector"
			 scope="application" />
<% 
	String userName = (String)session.getValue("Name");
	String message = request.getParameter("Message");	
	String vo = request.getParameter("Voice");

	if (message==null) message = "Welcome " + userName;	    // default message
	if (vo == null) vo = new String("Microsoft Mary");		// default voice

	if (!message.equals("")){
		board.addMessage(message,userName,vo);
	}	
	String listenTo = request.getParameter("ListenTo");
	if (listenTo == null) listenTo = userName;				// default listento
	session.putValue("ListenTo",listenTo);
%>

<BODY>
<H2><%= userName %></H2>
<FORM METHOD=POST ACTION="AddMessage.jsp">	
<TABLE width="100%" height="90%" border="2">
<TR>
	<TD>
	Send message	
	<INPUT TYPE="text" NAME="Message">
	<INPUT TYPE="submit">
	<A HREF="logout.jsp" target="_parent">Logout</A>
	</TD>
</TR>
<TR>
	<TD>
	Select your engine<br>
	<%		
		SynthesizerTest s = new SynthesizerTest();
		String v[] = s.getAllVoice();
		//System.out.println(voice);
		for (int i=0; i<v.length; i++){
			//System.out.print(v[i]);
			if (v[i].equals(vo)){
				//System.out.println("Equal");
				out.println(	"<INPUT " +
								"TYPE=\"radio\" " +
								"NAME=\"Voice\" " +
								"VALUE=\"" + v[i] + "\" " +
								"CHECKED>" + 
								v[i] + "<br>");
			}
			else{
				//System.out.println("NotEqual");
				out.println(	"<INPUT " +
								"TYPE=\"radio\" " +
								"NAME=\"Voice\" " +
								"VALUE=\"" + v[i] + "\">" +
								v[i] + "<br>");
			}
		}
	%>
	</TD>

</TR>
<TR>
	<TD>
	Listen to
	<SELECT NAME="ListenTo">
		<% 
			for(int i=0; i<user.size(); i++)
			{
				String u = (String)user.elementAt(i);
				if (u.equals(listenTo))
					out.println("<OPTION SELECTED>" + u + "</OPTION>");
				else
					out.println("<OPTION >" + u + "</OPTION>");
			}
		%>
	</SELECT>
	<INPUT TYPE="submit" value="Update">
	</TD>
</TR>
</TABLE>
</form>
</BODY>
</HTML>
