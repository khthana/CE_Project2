public class Board 
{
	private final int numLine = 13;
	private String message[] = new String[numLine];	
	private String owner[] = new String[numLine];	
	private String lastVoice = new String("");
	
	public Board(){
		for (int i=0; i<numLine; i++){
			message[i] = new String("Empty");			
			owner[i] = new String("Nobody");
		}
	}
	public void addMessage(String m, String o, String v){
		// shift message
		for (int j=0; j<numLine-1; j++)	{
			message[j] = message[j+1];
			owner[j] = owner[j+1];
		}		
		message[numLine-1] = m;
		owner[numLine-1] = o;
		lastVoice = v;
	}

	public int getNumLine(){
		return numLine;
	}

	public String getLastVoice(){
		return lastVoice;
	}

	public String getMessage(int i){
		return message[i];
	}

	public String getName(int i){
		return owner[i];
	}
	
	public String toString(){
		String s = new String("Board class \n");
		for (int i=0; i<numLine; i++){
			s = s + owner[i] + " : " + message[i] + "\n";
		}
		return s;
	}
				
	public static void main(String[] args) 
	{
		System.out.println("Test stub");
		Board b = new Board();
		//b.addMessage("Hello Kan", "AU");
	//	b.addMessage("Hi, How are you?", "KAN");
	//	b.addMessage("I 'm fine thank you", "AU");
		System.out.println(b.toString());		
	}
}
