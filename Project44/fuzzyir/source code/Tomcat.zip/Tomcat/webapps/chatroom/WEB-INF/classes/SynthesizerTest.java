import examples.*;
import examples.synthesis.*;
import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class SynthesizerTest {
	private Synthesizer synth = null;
	private SpeakableAdapter sad;
	private SynthesizerProperties props;
	private Voice[] vs;
	private AudioManager audioMan;

    public SynthesizerTest(){
		try {
            SynthesizerModeDesc desc = new SynthesizerModeDesc(Locale.ENGLISH);
            synth = Central.createSynthesizer(desc);
            desc = (SynthesizerModeDesc)synth.getEngineModeDesc();
            synth.addEngineListener(new TestEngineListener());
            
			sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
			audioMan = synth.getAudioManager();

            synth.allocate();
            synth.resume();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            props = synth.getSynthesizerProperties();
            props.setVolume(1.0f);
            props.setSpeakingRate(200.0f);

			vs = desc.getVoices();		
			
        } catch(Exception e) {
            e.printStackTrace();
        } catch(Error e1) {
            e1.printStackTrace();
        } 
	}
	public String[] getAllVoice(){
		String sArray[] = new String[vs.length];
		for (int i=0; i<vs.length; i++){
			sArray[i] = new String(vs[i].getName());
			//System.out.println(sArray[i]);
		}
		return sArray;
	}
	public void speakToFile(String plainText, String filename){
		try {
                audioMan.setOutputFile(filename,11,8);
                synth.speakPlainText(plainText,null);
                //speakPlainText is synchronous when outputting to a file, 
                //so no need to wait till queue is empty,because when we reach 
                //this point in the code, the wave file is already written.
                
                //but remember to close the output file otherwise the results are uncertain
                audioMan.closeOutputFile();
            } catch(IOException ioe) {
                //If the file cannot be opened (eg if it is already opened by 
                //another application) we will get an IOException
                ioe.printStackTrace();
            } catch(AudioException ae) {
				ae.printStackTrace();
			} catch(EngineException ee) {
				ee.printStackTrace();
			}

	}
	public void speakAll(){
		try{
			synth.speak("Here are all my English voices",null);
			synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
			for(int i=0;i<vs.length;i++) {
				String name = vs[i].getName();
		        props.setVoice(vs[i]);
				synth.speak("Hello, my name is "+name,null);
				synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
	        }           
			props.setVoice(vs[0]);
		}
		catch (Exception e){
			e.printStackTrace();			
		}
	}

	public void setVoice(String vName){
		for (int i=0; i<vs.length; i++)
		{
			if (vName.equals(vs[i].getName()))
			{
				props.setVoice(vs[i]);
				break;
			}
		}
	}
		
	public void finalize(){
		synth.cancelAll();
        try {
			synth.deallocate();
            synth.waitEngineState(Synthesizer.DEALLOCATED);			
        } catch(Exception e2) { e2.printStackTrace(); }
	}
        
    public static void main(String[] args) {        
        SynthesizerTest st = new SynthesizerTest();
		System.out.println("Engine created");
		//st.speakAll();
		//st.speakToFile("My name is karn", "kan.wav");
		String sa[] = st.getAllVoice();
		System.out.println(sa[1]);
		st.finalize();
		System.exit(0);
    }
}