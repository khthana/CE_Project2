<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Logout from chatroom </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>
<jsp:useBean id="user" 
			 class="java.util.Vector"
			 scope="application" />
<BODY>
<h1>Thank you</h1>
<h2>Thai Engine comming soon...</h2>
<A HREF="LoginForm.html" target="_parent">Chat again</A>
<%
	String name = (String)session.getValue("Name");
	session.removeValue("ListenTo");
	user.removeElement(name);
%>
</BODY>
</HTML>
