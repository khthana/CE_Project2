// Speech Synthesis
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import examples.*;
import examples.synthesis.*;
import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;

public class SpeakServlet extends HttpServlet 
{
	private SynthesizerTest synthTest = new SynthesizerTest();	
	private String basePath = new String("c:\\tomcat\\webapps\\toefl\\waves\\");

	public void doGet( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException
	{		
		PrintWriter output = res.getWriter();
		res.setContentType( "text/html" );
		synthTest.speakToFile("My name is kan" ,basePath + "1.wav");
		output.println("<h1>Speech Synthesis</h1>");
		output.println("<bgsound src=\"http://localhost:8080/toefl/waves/1.wav\">");		
		output.close();
	}

	public void destroy()
	{		
	}


	public static void main(String[] args) 
	{
		System.out.println("Test");
	}
}
