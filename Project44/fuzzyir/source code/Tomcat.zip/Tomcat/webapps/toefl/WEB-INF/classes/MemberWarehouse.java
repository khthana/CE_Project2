import java.sql.*;

public class MemberWarehouse 
{
	private Statement statement = null;
	private Connection connection = null;
	private String URL = "jdbc:odbc:TOEFL";

	private String id;
	private String name;
	private String surname;
	private double listenMark;
	private int listenAccess;
	private double listenHigh;
	

	public MemberWarehouse(){
		try
		{
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
			connection = DriverManager.getConnection( URL, "", "" );
			statement = connection.createStatement();			
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			connection = null;
		}
	}
	public void updateMember(int currentMark, int maxMark){
		listenAccess++;
		double pm = (double)(currentMark)*100/(double)maxMark;
		listenMark = (listenMark * (double)listenAccess + pm)/(double)(listenAccess);
		if (listenHigh < pm){
			listenHigh = pm;
		}

		//debug
		//listenAccess = 1;
		//listenMark = 2;
		//listenHigh = 3;

		try{
			statement.executeUpdate(
				" UPDATE MEMBER " +
				"SET LISTENMARK = " + listenMark +
				", LISTENACCESS = " + listenAccess + 
				", LISTENHIGH = " + listenHigh +
				" WHERE ID = " + id );
			System.out.println("store succes");
			statement.close();							
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

	public void selectMember(String idNumber){
		id = idNumber;
		try
		{
			ResultSet rs = statement.executeQuery(
							"SELECT * " +
							"FROM MEMBER " +
							"WHERE ID = " + id );
			if (!rs.next())
			{
				System.out.println("don't have any row");
				return ;
			}	
			name = rs.getString("Name");
			surname = rs.getString("Surname");
			listenMark = rs.getDouble("ListenMark");
			listenAccess = rs.getInt("ListenAccess");
			listenHigh = rs.getDouble("ListenHigh");	
			//statement.close();
		}
		catch (Exception e){
			e.printStackTrace();
		}		
	}
	
	public String getName(){
		return name;
	}

	public String getSurname(){
		return surname;
	}

	public String getAvg(){
		return Double.toString(listenMark/listenAccess);
	}

	public String getHigh(){
		return Double.toString(listenHigh);
	}

	public String toString(){
		return	"Name = " + name + "\n" + 
				"Surname = " + surname + "\n" +
				"ListenMark = " + listenMark + "\n" +
				"ListenAccess = " + listenAccess + "\n" +
				"ListenHigh = " + listenHigh;
	}
	public void close(){
		try
		{
			connection.close();
		}
		catch ( Exception e )
		{
			System.err.println( "Problem closing the database" );
		}
	}

	public static void main(String[] args) 
	{
		System.out.println("Test stub");
		MemberWarehouse mw = new MemberWarehouse();
		mw.selectMember("1");
		System.out.println(mw.toString());		
		mw.updateMember(3,7);		
		System.out.println(mw.toString());		
		mw.close();
	}
};