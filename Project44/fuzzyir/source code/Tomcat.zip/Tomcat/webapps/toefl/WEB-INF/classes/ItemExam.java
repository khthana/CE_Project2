public class ItemExam 
{
	private int id;
	private String question;
	private String sound;
	private String choiceA;
	private String choiceB;
	private String choiceC;
	private String choiceD;
	private String userAnswer = new String("none");
	private String correctAnswer;
	
	public void setID(int i){
		id = i;
	}
	public void setQuestion(String s){
		question = s;
	}
	public void setSound(String s){
		sound = s;
	}
	public void setChoiceA(String s){
		choiceA = s;
	}
	public void setChoiceB(String s){
		choiceB = s;
	}
	public void setChoiceC(String s){
		choiceC = s;
	}
	public void setChoiceD(String s){
		choiceD = s;
	}
	public void setUserAnswer(String s){
		if (s != null) {
			userAnswer = s;
		}
		else{
			userAnswer = new String("none");
		}		
	}
	public void setCorrectAnswer(String s){
		correctAnswer = s;
	}
	public int getID(){
		return id;
	}
	public String getQuestion(){
		return question;
	}
	public String getSound(){
		return sound;
	}
	public String getChoiceA(){
		return choiceA;
	}
	public String getChoiceB(){
		return choiceB;
	}
	public String getChoiceC(){
		return choiceC;
	}
	public String getChoiceD(){
		return choiceD;
	}
	public String getUserAnswer(){
		return userAnswer;
	}
	public String getCorrectAnswer(){
		return correctAnswer;
	}
	public boolean isCorrect(){
		return correctAnswer.equals(userAnswer);
	}
	public String toString(){
		return "Listening item\n" +
				"id = " + id + "\n" +
				"question = " + question + "\n" +
				"sound = " + sound + "\n" +
				"choiceA = " + choiceA + "\n" +
				"choiceB = " + choiceB + "\n" +
				"choiceC = " + choiceC + "\n" +
				"choiceD = " + choiceD + "\n" +
				"userAnswer = " + userAnswer + "\n" +
				"correctAnswer = " + correctAnswer;
	}

	public static void main(String[] args) 
	{
		System.out.println("Test Stub!");
		ItemExam ie = new ItemExam();
		ie.setID(1);
		System.out.println(ie);
	}
}
