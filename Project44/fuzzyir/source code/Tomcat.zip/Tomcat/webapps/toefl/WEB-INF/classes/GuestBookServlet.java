// Three-Tier Example
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util. *;
import java.sql.*;

public class GuestBookServlet extends HttpServlet 
{
	private Statement statement = null;
	private Connection connection = null;
	private String URL = "jdbc:odbc:db";

	public void init( ServletConfig config ) throws ServletException
	{
		super.init( config );

		try
		{
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
			connection = DriverManager.getConnection( URL, "", "" );
			
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			connection = null;
		}
	}

	public void doPost( HttpServletRequest req, HttpServletResponse res ) throws ServletException, IOException
	{
		String email, firstname, lastname, company, interest, education;

		email = req.getParameter( "Email" );
		firstname = req.getParameter( "FirstName" );
		lastname = req.getParameter( "LastName" );
		company = req.getParameter( "Company" );
		interest = req.getParameter( "Interest" );
		education = req.getParameter( "Education" );
		
		PrintWriter output = res.getWriter();
		res.setContentType( "text/html" );
		
		if (email.equals( "" ) || firstname.equals( "" ) || lastname.equals( "" ))		
		{
			output.println( "<h3>Please comeback and refill email, firstname and lastname</h3>");
			output.close();
			return;
		}
		
		String strdata = "'" + firstname + "', '" + lastname + "', '" + email + "', '" + company + "', '" + interest + "', '" + education + "'";
		System.out.println("String data : " + strdata );
		boolean success = insertIntoDB(strdata);

		if (success)
		{
			output.println( "<h2>Thank you " + firstname + " for registering.</h2>");
		}
		else
		{
			output.println( "<h2>Sorry " + firstname + ", registering fail</h2>");
		}		
		output.close();
	}
	
	private boolean insertIntoDB( String stringStatement )
	{
		try
		{
			statement = connection.createStatement();
			statement.execute("INSERT INTO " +
							  "guestbook(First_name, Last_name, Email_add, Company, Interest, Education) " +
							  "VALUES (" + stringStatement + ");" );
			statement.close();
		}
		catch ( Exception e )
		{
			System.err.println( "Error Problem with adding new entry" );			
			return false;
		}
		return true;
	}

	public void destroy()
	{
		try
		{
			connection.close();
		}
		catch ( Exception e )
		{
			System.err.println( "Problem closing the database" );
		}
	}


	public static void main(String[] args) 
	{
		System.out.println("Test");
	}
}
