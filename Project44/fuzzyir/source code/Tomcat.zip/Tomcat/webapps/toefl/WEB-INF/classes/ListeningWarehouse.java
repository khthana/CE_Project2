import java.sql.*;
public class ListeningWarehouse 
{
	private Statement statement = null;
	private Connection connection = null;
	private String URL = "jdbc:odbc:TOEFL";
	private int totalRow;

	public ListeningWarehouse(){
		try
		{
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
			connection = DriverManager.getConnection( URL, "", "" );
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			connection = null;
		}
		try {
			statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(
							"SELECT COUNT(*) " +
							"FROM LISTENING");
			rs.next();
			totalRow = rs.getInt(1);
			statement.close();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}

	public ItemExam getItemExam(String id) {
		try
		{
			statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(
							"SELECT * " +
							"FROM LISTENING " +
							"WHERE ID = " + id );
			if (!rs.next())
			{
				System.out.println("don't have any row");
				return null;
			}
			ItemExam ieResult = new ItemExam();
			ieResult.setID(rs.getInt("ID"));
			ieResult.setQuestion(rs.getString("QUESTION"));
			ieResult.setSound(rs.getString("SOUND"));
			ieResult.setChoiceA(rs.getString("A"));
			ieResult.setChoiceB(rs.getString("B"));
			ieResult.setChoiceC(rs.getString("C"));
			ieResult.setChoiceD(rs.getString("D"));
			ieResult.setCorrectAnswer(rs.getString("CORRECT_ANS"));
			statement.close();
			return ieResult;
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			return null;
		}
	}
	public int getTotal(){
		return totalRow;
	}
	public int getMaxItem(){
		return 7;
	}
	public String toString(){
		return	"Statement = " + statement + "\n" + 
				"Connection = " + connection + "\n" +
				"URL = " + URL + "\n" +
				"totalRow = " + totalRow;
	}
	public static void main(String[] args) 
	{
		System.out.println("Test stub");
		ListeningWarehouse lw = new ListeningWarehouse();
		System.out.println(lw.toString());
		ItemExam ie = lw.getItemExam("1");
		System.out.println(ie.toString());
	}
};