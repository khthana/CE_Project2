<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> ++Correct Structure++ </TITLE>
<Style>
a:link { Color:blue; TEXT-DECORATION: underline }
a:visited { Color:blue; TEXT-DECORATION: underline } 
a:hover { Color:red; TEXT-DECORATION: underline }
a:active { TEXT-DECORATION: none }

</Style>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">
 
<%
	int num=30;
	String ch[] = new String[num];
	for(int i=0;i<num;i++){
		ch[i]=request.getParameter("ch_"+i);
	}
	
	String ans[] = new String[num];
	for(int i=0;i<num;i++){
		ans[i]=request.getParameter("n_"+i);
	}
	
	//for(int i=0;i<2;i++){
	//	out.println(ch[i]);
	//	out.println(ans[i]);
	//}
	
%>
</HEAD>

<BODY BGCOLOR="#FFFFFF">
<%@  page import="java.sql.*"  %>
<%@ page contentType = "text/html;charset=MS874" %> 
<%

  // ������ѡ
 
   Connection dbconn;
   String msgout = "";
      // Set up database connection
      try 
      {     // ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
            String url = "jdbc:odbc:TOEFL";

            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
            dbconn = DriverManager.getConnection( url );
	    Statement statement = dbconn.createStatement();
	   
%>
<%
				String wrong[]=new String[num];
				String ans_cor[]=new String[num];
				int count=0;
				for(int i=0;i<num;i=i+1){
				
				 String query = "SELECT * FROM STRUCTURE where ID="+ch[i];
				ResultSet  resultset = statement.executeQuery(query);
				resultset.next();
				String temp=resultset.getString("Answer");
				if(temp.equals(ans[i])){count++;}else{wrong[i]=resultset.getString("Correct");ans_cor[i]=temp;}
				}
				%>
					
				
				
<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td><img src="pic_h/logo_min.jpg" width="96" height="77"></td>
		</tr>
		</table>
		<div align="center">
		
  <p><b><font size="+3">Correct the answer <font size="+2">(Sturcture and Written)</font></font></b></p>
  <table width="100%" border="0" cellpadding="2" cellspacing="2">
    <tr> 
      <td width="12%" bgcolor="#CCFFFF"> 
        <div align="center">You correct</div>
      </td>
      <td width="9%" bgcolor="#CCFFFF">
        <div align="center"><%out.println(count);%></div>
      </td>
      <td width="13%" bgcolor="#CCFFFF"> 
        <div align="center">You wrong</div>
      </td>
      <td width="10%" bgcolor="#CCFFFF">
        <div align="center"><%out.println(num-count);%></div>
      </td>
      <td width="18%" bgcolor="#CCFFFF"> 
        <div align="center">Your percentage</div>
      </td>
      <td width="38%" bgcolor="#CCFFFF">
        <div align="center"><%out.println((count*100)/num+" %");%></div>
      </td>
    </tr>
    <tr> 
      <td colspan="6">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="6" height="72" valign="top"> 
        <table width="100%" border="1">
          <tr> 
            <td colspan="2"> 
              <div align="center">The correct answer</div>
            </td>
          </tr>
          <tr>
            <td width="10%">
              <div align="center">Number</div>
            </td>
            <td width="90%">
              <div align="center">Answer</div>
            </td>
          </tr>
          <%for(int i=0;i<num;i++){
			if(wrong[i]!=null){%>
				<tr> 
					<td width="10%"> 
						<div align="center"><%out.println(i+1);%></div>
					</td>
					<td width="90%"> 
						<div align="left"><%out.println("  <font color=red>("+ans_cor[i]+")</font>       "+wrong[i]);%></div>
					</td>
				</tr><%}%>
        <%}%>
	  </table>
      </td>
    </tr>
    <tr> 
      <td colspan="6">&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="6">&nbsp;</td>
    </tr>
  </table>
 </div>
<%
	 String query = "SELECT * FROM MEMBER where ID="+session.getValue("id") ;
	ResultSet  resultset = statement.executeQuery(query);
	resultset.next();
	int acc=resultset.getInt("StrucAccess");
	//out.println(acc);
	double ave=resultset.getDouble("StrucMark");
	//out.println(ave);
	int temp_count=0;
	double n_mark=((ave*acc)+count)/(acc+1);
	int high=resultset.getInt("StrucHigh");
	if(count>high){temp_count=count;}else{temp_count=high;}
	acc++;
	query = "UPDATE MEMBER SET StrucMark= "+n_mark+" ,StrucHigh="+temp_count+" ,StrucAccess="+acc+" WHERE ID="+session.getValue("id");
	statement = dbconn.createStatement();
	statement.executeUpdate(query);
	statement.close();
%>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="1%">&nbsp;</td>
    <td width="98%" bgcolor="#6666FF"> 
      <div align="center"><b><font size="+2" color="#66FF66">Your History</font></b></div>
    </td>
    <td width="1%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="189" width="1%">&nbsp;</td>
    <td height="189" width="98%" valign="top"> 
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td width="31%" bgcolor="#CCFFFF">Name : </td>
          <td width="69%" bgcolor="#CCFFFF"><%out.println(session.getValue("name"));%></td>
        </tr>
        <tr> 
          <td width="31%" bgcolor="#66CCFF">Surname : </td>
          <td width="69%" bgcolor="#66CCFF"><%out.println(session.getValue("surname"));%></td>
        </tr>
        <tr> 
          <td width="31%" bgcolor="#CCFFFF">Your High Score : </td>
          <td width="69%" bgcolor="#CCFFFF"><%out.println(temp_count);%></td>
        </tr>
        <tr> 
          <td width="31%" bgcolor="#66CCFF">Your Average Score : </td>
          <td width="69%" bgcolor="#66CCFF"><%out.println(n_mark+" %");%></td>
        </tr>
      </table>
    </td>
    <td height="189" width="1%">&nbsp;</td>
  </tr>
</table>

<%			
//		msgout = "Connection successful" ;
	dbconn.close();
      }
      catch ( ClassNotFoundException cnfex ) 
      {
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
      }
      catch ( SQLException sqlex ) 
      {    // �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
out.println(msgout);
%>
</BODY>
</HTML>
