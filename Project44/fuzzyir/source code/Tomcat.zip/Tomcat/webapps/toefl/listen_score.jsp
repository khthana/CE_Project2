<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Listening Score </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<h1>Listening Score </h1>
<%@ page errorPage="listen_exam.jsp" %>

<%
	Integer ic = (Integer)session.getValue("itemCount");
	// store answer of last item
	String answer = request.getParameter("answer");
	ItemExam preItem = (ItemExam)session.getValue(ic.toString());
	preItem.setUserAnswer(answer);
	session.putValue(ic.toString(),preItem);
	// scan item
	int score = ic.intValue();
	ItemExam ie = null;
	for (int itemNumber=1; itemNumber<=ic.intValue(); itemNumber++){
		ie = (ItemExam)session.getValue(Integer.toString(itemNumber));
		if (!ie.isCorrect()){				
			score--;
		}
	}
%>

<h2>Your Score is <%= score %></h2>
<table align="Center" border="0" width="80%">
<caption align="Top">Listening Score</caption>
<tr>
	<td bgcolor="#CCCCFF">Wrong Answer</td>
	<td bgcolor="#CCCCFF">Because</td>
</tr>

<% 
	// scan item	
	//System.out.println(session.toString());
	for (int itemNumber=1; itemNumber<=ic.intValue(); itemNumber++){
		ie = (ItemExam)session.getValue(Integer.toString(itemNumber));
		//System.out.println(ie.toString());
		if (!ie.isCorrect()){							
%>
<tr>
	<td bgcolor="#CCCCFF">
	<TABLE ALIGN="center" WIDTH="80%" BORDER="0" CELLSPACING="0">
	<TR>
		<TD COLSPAN="2">
			<%= itemNumber %>. <%= ie.getQuestion() %><br>
			<embed src="practices/music/<%= ie.getSound() %>" autostart="false" width="160" height="45">
		</TD>
	</TR>
	<TR>
		<TD></TD>
		<TD>
			A. <%= ie.getChoiceA() %> <BR>
			B. <%= ie.getChoiceB() %> <BR>
			C. <%= ie.getChoiceC() %> <BR>
			D. <%= ie.getChoiceD() %> <BR>
		</TD>
	</TR>	
	</TABLE>
	</td>
	<td bgcolor="#CCCCFF">
	<table border="0">
<tr>
	<td bgcolor="#CCCCFF">Your answer: <%= ie.getUserAnswer()%></td>
</tr>
<tr>
	<td bgcolor="#CCCCFF">Correct answer: <%= ie.getCorrectAnswer() %></td>
</tr>
</table>
	</td>
</tr>
<%		}
		session.removeValue(Integer.toString(itemNumber));
	}		
	session.removeValue("itemCount");
	MemberWarehouse mw = new MemberWarehouse();
	mw.selectMember(/*(String)session.getValue("id")*/"1");
	mw.updateMember(score,7);
	mw.close();
%>
</table>
<br>
<br>
<table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="1%">&nbsp;</td>
    <td width="98%" bgcolor="#6666FF"> 
      <div align="center"><b><font size="+2" color="#66FF66">Your History</font></b></div>
    </td>
    <td width="1%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="189" width="1%">&nbsp;</td>
    <td height="189" width="98%" valign="top"> 
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td width="31%" bgcolor="#CCFFFF">Name : </td>
          <td width="69%" bgcolor="#CCFFFF"><%= mw.getName() %></td>
        </tr>
        <tr> 
          <td width="31%" bgcolor="#66CCFF">Surname : </td>
          <td width="69%" bgcolor="#66CCFF"><%= mw.getSurname() %></td>
        </tr>
        <tr> 
          <td width="31%" bgcolor="#CCFFFF">Your Highest Percent : </td>
          <td width="69%" bgcolor="#CCFFFF"><%= mw.getHigh() %>%</td>
        </tr>
	<tr> 
          <td width="31%" bgcolor="#66CCFF">Your Average Score : </td>
          <td width="69%" bgcolor="#66CCFF"><%= mw.getAvg() %>%</td>
        </tr>
       </table>
    </td>
    <td height="189" width="1%">&nbsp;</td>
  </tr>
</table>
</BODY>
</HTML>
