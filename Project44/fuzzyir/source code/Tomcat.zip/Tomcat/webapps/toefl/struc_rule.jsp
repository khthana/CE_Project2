<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=">
<Style>
a:link { Color:blue; TEXT-DECORATION: none }
a:visited { Color:blue; TEXT-DECORATION: none } 
a:hover { Color:red; TEXT-DECORATION: none }
a:active { TEXT-DECORATION: none }
</Style>

<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF" onLoad="MM_preloadImages('pic_h/Structure_down.jpg')">
<p>&nbsp;</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="289" height="466" rowspan="2"><img src="pic_h/logo.jpg" width="289" height="233"></td>
    <td height="178">
      <p align="center"><b><font size="6">Structure and Written Expression </font></b></p>
      <p align="center">�շ����� 40 ��ͤس�����ҷ� 30 �ҷ� ��Ҿ�������� ������ѹ���</p>
    </td>
  </tr>
<%if(session.getValue("id")!=null){%>  
  <tr>
    <td> 
      <div align="center"><a href="struc_write.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','pic_h/Structure_down.jpg',1)"><img name="Image2" border="0" src="pic_h/Structure_up.jpg" width="180" height="31"></a></div>
    </td>
  </tr>
<%}else{%>
	<tr>
		<td>
			<div align="center"><b><font size"2" color="red">Please login or </font><a href="regis.jsp">Regis</a></b></div>
		</td>
	</tr>
<%}%>
</table>
<p>&nbsp;</p>
</body>
</html>
