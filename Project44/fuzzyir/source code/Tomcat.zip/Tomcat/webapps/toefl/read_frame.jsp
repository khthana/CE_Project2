<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> read frame </TITLE>

</HEAD>
<frameset rows="80,*" frameborder="NO" border="0" framespacing="0"> 
  <frame name="topFrame" scrolling="NO" noresize src="clock2.htm" >
  <frame name="mainFrame" scrolling="yes" src="read.jsp">
</frameset>
<noframes><body bgcolor="#FFFFFF">

</body></noframes>

</HTML>
