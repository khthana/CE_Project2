<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>auten</TITLE>
<Style>
a:link { Color:#ffff00; TEXT-DECORATION: none }
a:visited { Color:#ffff00; TEXT-DECORATION: none } 
a:hover { Color:blue; TEXT-DECORATION: none }
a:active { TEXT-DECORATION: none }

</Style>
<%@  page import="java.sql.*"  %>
<%@ page contentType = "text/html;charset=MS874" %> 
<%

  // ������ѡ
   String password=request.getParameter("password");
   String login=request.getParameter("login");
   Connection dbconn;
   String msgout = "";
      // Set up database connection
      try 
      {     // ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
            String url = "jdbc:odbc:TOEFL";

            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
            dbconn = DriverManager.getConnection( url );
	    Statement statement = dbconn.createStatement();

	    String query = "SELECT * FROM MEMBER";
	    ResultSet  resultset = statement.executeQuery(query);	
		int boo=0;
		while(resultset.next()){
			 String temp_log=resultset.getString("Login");
			 String temp_pass=resultset.getString("Password");
			 if(temp_log.equals(login)&&temp_pass.equals(password)){
				boo=1;
				String sec_name=(String)session.getValue("name");
				String sec_id=(String)session.getValue("id");
				String sec_surname=(String)session.getValue("surname");
				sec_id=resultset.getString("ID");
				sec_name=resultset.getString("Name");
				sec_surname=resultset.getString("Surname");
				session.putValue("id",sec_id);
				session.putValue("name",sec_name);
				session.putValue("surname",sec_surname);
			 }
		}
		out.println(boo);
//		msgout = "Connection successful" ;
	dbconn.close();
	response.sendRedirect("menu.jsp");
      }
      catch ( ClassNotFoundException cnfex ) 
      {
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
      }
      catch ( SQLException sqlex ) 
      {    // �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
out.println(msgout);
%>
</HEAD>

<BODY BGCOLOR="#FFFFFF">

</BODY>
</HTML>
