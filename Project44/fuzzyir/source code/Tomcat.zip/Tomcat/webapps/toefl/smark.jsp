<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Show mark </TITLE>
<Style>
a:link { Color:blue; TEXT-DECORATION: underline }
a:visited { Color:blue; TEXT-DECORATION: underline } 
a:hover { Color:red; TEXT-DECORATION: underline }
a:active { TEXT-DECORATION: none }

</Style>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">
</HEAD>

<BODY BGCOLOR="#FFFFFF">
<%@  page import="java.sql.*"  %>
<%@ page contentType = "text/html;charset=MS874" %> 
<%

  // ������ѡ
 
   Connection dbconn;
   String msgout = "";
      // Set up database connection
      try 
      {     // ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
            String url = "jdbc:odbc:TOEFL";

            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
            dbconn = DriverManager.getConnection( url );
	    Statement statement = dbconn.createStatement();
	   
%>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td><img src="pic_h/logo_min.jpg" width="96" height="77"></td>
		</tr>
		</table>
		<p><div align="center"><b><font size="+3">Display Your Mark</font></b></div>
<%if(session.getValue("id")==null){%>
	<div align="center"><b><font size="2" color="blue">Please Login</font></b></div>
<%}else{%>
	<%
		 String query = "SELECT * FROM MEMBER where ID="+session.getValue("id");
		ResultSet  resultset = statement.executeQuery(query);
		resultset.next();
	%>

	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="1%">&nbsp;</td>
    <td width="98%" bgcolor="#6666FF"> 
      <div align="center"><b><font size="+2" color="#66FF66">Your Mark History</font></b></div>
    </td>
    <td width="1%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="189" width="1%">&nbsp;</td>
    <td height="189" width="98%" valign="top"> 
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td width="36%" bgcolor="#CCFFFF">Name : </td>
          <td width="64%" bgcolor="#CCFFFF"><%out.println(session.getValue("name"));%></td>
        </tr>
        <tr> 
          <td width="36%" bgcolor="#66CCFF">Surname : </td>
          <td width="64%" bgcolor="#66CCFF"><%out.println(session.getValue("surname"));%></td>
        </tr>
        <tr> 
          <td width="36%" bgcolor="#CCFFFF">Listening Access : </td>
          <td width="64%" bgcolor="#CCFFFF"><%out.println(resultset.getInt("ListenAccess"));%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#66CCFF">Listening Average Percentage : </td>
          <td width="64%" bgcolor="#66CCFF"><%out.println(resultset.getDouble("ListenMark")+" %");%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#CCFFFF">Listening High Percentage : </td>
          <td width="64%" bgcolor="#CCFFFF"><%out.println(resultset.getDouble("ListenHigh")+" %");%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#66CCFF">Structure Access : </td>
          <td width="64%" bgcolor="#66CCFF"><%out.println(resultset.getInt("StrucAccess"));%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#CCFFFF">Structure Average Percentage : </td>
          <td width="64%" bgcolor="#CCFFFF"><%out.println(resultset.getDouble("StrucMark")+" %");%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#66CCFF">Structure High Score</td>
          <td width="64%" bgcolor="#66CCFF"><%out.println(resultset.getInt("StrucHigh"));%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#CCFFFF">Reading Access : </td>
          <td width="64%" bgcolor="#CCFFFF"><%out.println(resultset.getInt("ReadAccess"));%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#66CCFF">Reading Average Percentage : </td>
          <td width="64%" bgcolor="#66CCFF"><%out.println(resultset.getDouble("ReadMark")+" %");%></td>
        </tr>
	<tr> 
          <td width="36%" bgcolor="#CCFFFF">Reading High Percentage : </td>
          <td width="64%" bgcolor="#CCFFFF"><%out.println(resultset.getDouble("ReadHigh")+" %");%></td>
        </tr>
       </table>
    </td>
    <td height="189" width="1%">&nbsp;</td>
  </tr>
</table>
<%}%>
<%//		msgout = "Connection successful" ;
	dbconn.close();
      }
      catch ( ClassNotFoundException cnfex ) 
      {
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
      }
      catch ( SQLException sqlex ) 
      {    // �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
out.println(msgout);
%>

</BODY>
</HTML>
