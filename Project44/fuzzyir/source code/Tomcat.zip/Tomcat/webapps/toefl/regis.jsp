<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> ++Registration++ </TITLE>
<Style>
a:link { Color:blue; TEXT-DECORATION: underline }
a:visited { Color:blue; TEXT-DECORATION: underline } 
a:hover { Color:red; TEXT-DECORATION: underline }
a:active { TEXT-DECORATION: none }

</Style>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">
</HEAD>

<BODY BGCOLOR="#FFFFFF">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="pic_h/logo_min.jpg" width="96" height="77"></td>
  </tr>
</table>
<div align="center">
		
  <p><b><font size="+3">REGISTRATION</font></b></p>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="22%">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td width="22%" height="200" rowspan="2">&nbsp;</td>
      <td rowspan="2" height="242" valign="top" colspan="2"> 
        <form action="addmem.jsp" method="post">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#CCFFFF">
          <tr> 
              <td width="50%">&nbsp;</td>
              <td width="50%">&nbsp;</td>
          </tr>
          <tr> 
              <td width="50%"> 
                <div align="right">First Name : </div>
            </td>
              <td width="50%"> 
                <input type="text" name="firstname" size="15">
            </td>
          </tr>
          <tr> 
              <td width="50%"> 
                <div align="right">Last Name : </div>
            </td>
              <td width="50%"> 
                <input type="text" name="surname" size="15">
            </td>
          </tr>
          <tr> 
              <td width="50%"> 
                <div align="right">Login : </div>
            </td>
              <td width="50%"> 
                <input type="text" name="login" size="9" maxlength="13">
            </td>
          </tr>
          <tr> 
              <td width="50%"> 
                <div align="right">Password : </div>
            </td>
              <td width="50%"> 
                <input type="password" name="password" size="5" maxlength="8">
            </td>
          </tr>
          <tr> 
              <td width="50%"> 
                <div align="right">Confirm Password : </div>
            </td>
              <td width="50%"> 
                <input type="password" name="conpassword" size="5" maxlength="8">
            </td>
          </tr>
          <tr> 
              <td width="50%">&nbsp;</td>
              <td width="50%"> 
                <div align="center"> 
                <input type="submit" name="Submit" value="REGIS">
              </div>
            </td>
          </tr>
          <tr> 
              <td width="50%">&nbsp;</td>
              <td width="50%"> 
                <div align="center"> </div>
            </td>
          </tr>
        </table>
	</form>
      </td>
      <td height="19" colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td width="0%" height="121" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="29%" height="121">&nbsp;</td>
    </tr>
    <tr> 
      <td width="22%" height="25">&nbsp;</td>
      <td width="8%" height="25">&nbsp;</td>
      <td width="41%" height="25" bgcolor="#FFFFFF">&nbsp;</td>
      <td height="25" bgcolor="#FFFFFF" width="0%">&nbsp;</td>
      <td height="25" width="29%">&nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>


</BODY>
</HTML>
