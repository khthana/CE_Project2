<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
</HEAD>

<BODY>
<h1>Speech Synthesis</h1>
<jsp:useBean id="synthTest" class="SynthesizerTest" />
<% 	
	String synthStr = request.getParameter("sentence");
	if (synthStr == null) {
		synthStr = new String("Welcom to Speech Synthesis");
	}
	synthTest.speakToFile(synthStr,	"c:\\tomcat\\webapps\\toefl\\waves\\AUTOGEN.WAV");
%>
<bgsound src="waves\AUTOGEN.WAV">
<FORM METHOD=POST ACTION="synthesizer.jsp">
<table>
<tr> 
  <td>Text:</td>   
  <td><INPUT TYPE="text" NAME="sentence"></td> 
</tr>
<tr> 
  <td>Engine:</td> 
  <td>
    <SELECT NAME="engine">
	<% //synthTest.showAllVoice(); %>
	</SELECT>
  </td> 
</tr>
<tr>
<td></td>
<td>
  <INPUT TYPE="submit">
</td>
</tr>
</table>
</FORM>
</BODY>
</HTML>
