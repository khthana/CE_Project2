<html>
<head>
<title>menu</title>
<Style>
a:link { Color:#ffff00; TEXT-DECORATION: none }
a:visited { Color:#ffff00; TEXT-DECORATION: none } 
a:hover { Color:blue; TEXT-DECORATION: none }
a:active { TEXT-DECORATION: none }

</Style>


<body bgcolor="#006699">
<%@ page contentType = "text/html;charset=MS874" %> 
<%
	//String sec_name=(String)session.getValue("name");
	//String sec_id=(String)session.getValue("id");
	//String sec_surname=(String)session.getValue("surname");

	//sec_id="dfsdadf";
	//session.putValue("id",sec_id);
	//out.println(session.getValue("id")+" ass");
%>
<table width="100%" border="0" cellpadding="5" cellspacing="5">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <%if(session.getValue("id")==null){%>
  <form action="menuauten.jsp" method="post">
  <tr bgcolor="#FF99CC"> 
    <td><font color="#FFFF33">Login : 
      <input type="text" name="login" size="9" maxlength="13">
      </font></td>
  </tr>
  
  
  <tr bgcolor="#FF99CC"> 
    <td><font color="#FFFF00">Password : 
      <input type="password" name="password" size="5" maxlength="8">
      </font></td>
  </tr>
  <tr bgcolor="#FF99CC"> 
    <td> 
      <div align="right"> 
        <input type="submit" name="Submit" value="Submit">
      </div>
    </td>
  </tr>
  </form>
  <%}else{%>
   <tr bgcolor="#FF99CC"> 
    <td><div align="center"><font color="#FFFF33">Now User 
      </font></div></td>
  </tr>
  
  
  <tr bgcolor="#FF99CC"> 
    <td><font color="#FFFF00">Name : <%out.println(session.getValue("name"));%>
      </font></td>
  </tr>
  <tr bgcolor="#FF99CC"> 
    <td> 
     <font color="#FFFF00">Surname : <%out.println(session.getValue("surname"));%>
      </font>
    </td>
  </tr>
  <%}%>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td > </td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="index.jsp" target="mainFrame">- ˹����ѡ</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="regis.jsp" target="mainFrame">- ��Ѥ���Ҫԡ</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="smark.jsp" target="mainFrame">- �٤�ṹ</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="#">- Tutorial</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="listen_exam.jsp" target="mainFrame">- Listening</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="struc_rule.jsp" target="mainFrame">- Structure</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="read_rule.jsp" target="mainFrame">- Reading</a></td>
  </tr>
  <tr> 
    <td bgcolor="#0099FF"><a href="logout.jsp">- Log out</a></td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>
