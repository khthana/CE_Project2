<%@  page errorPage="nologin.jsp" %>
<%!
	// Share data
	private ListeningWarehouse lw = new ListeningWarehouse();		
%>

<% 
	// jspservice()
	// save anwser previous anwser
	/*Object  x  = session.getValue("id");
	if (x==null) {
		throw new Exception(); // no login exception
	}*/

	ItemExam ite = new ItemExam();
	String action;
	Integer ic = new Integer(0);

	ic = (Integer)session.getValue("itemCount");	
	if (ic == null) {	// first item
		ic = new Integer(0);
		//System.out.println("Welcome, Newcommer");
	}
	else {				// other item
		//System.out.println("Read answer");
		String answer = request.getParameter("answer");
		ItemExam preItem = (ItemExam)session.getValue(ic.toString()); // read
		preItem.setUserAnswer(answer);
		session.putValue(ic.toString(), preItem); // write back
	}
	if (ic.intValue() < lw.getMaxItem()){ // end test?
		// creat next item
		boolean random_again = true;
		int rd = 0;
		//System.out.println("Start search next item");
		while (random_again) {
			rd = (int)(lw.getMaxItem() * Math.random() + 1);
			//System.out.println("try " + rd);
			random_again = false;
			for (int i=1; i<=ic.intValue(); i++) {
				ItemExam tested = (ItemExam)session.getValue(Integer.toString(i));
				if (tested.getID() == rd) {
					random_again = true;
					break;
				}
			}		
		}
		ite = lw.getItemExam(Integer.toString(rd));
		ic = new Integer(ic.intValue() + 1);
		//System.out.println("Display " + ic + " with item " + rd);
		session.putValue("itemCount", ic);
		session.putValue(ic.toString(), ite);
		
	}	
	if (ic.intValue() < lw.getMaxItem())
		action = new String("listen_exam.jsp");
	else{
		action = new String("listen_score.jsp");
		//System.out.println("you should go to listen_score.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Listening Examination </TITLE>
<META NAME="Generator" CONTENT="">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<META HTTP-EQUIV=Refresh CONTENT="15; URL=<%= action %>">
</HEAD>

<BODY>
<BGSOUND SRC="practices/music/<%= ite.getSound() %>">
<FORM ACTION="<%= action %>" METHOD="POST">
<TABLE ALIGN="center" WIDTH="70%" BORDER="0" CELLSPACING="20"
<TR>
	<TD COLSPAN="2">
	<%= ic %>.  ���͡��ͷ���դ������������§�Ѻ���§���س���Թ.(�س������ 15 �Թҷ�/���)
	</TD>
</TR>
<TR>
  <TD></TD>
	<TD>
	<INPUT NAME="answer" TYPE="Submit" VALUE="A">. <%= ite.getChoiceA() %> <BR>
	<INPUT NAME="answer" TYPE="Submit" VALUE="B">. <%= ite.getChoiceB() %> <BR>
	<INPUT NAME="answer" TYPE="Submit" VALUE="C">. <%= ite.getChoiceC() %> <BR>
	<INPUT NAME="answer" TYPE="Submit" VALUE="D">. <%= ite.getChoiceD() %> <BR>
	</TD>
</TR>
</TR>
</TABLE>
</FORM>
</BODY>
</HTML>