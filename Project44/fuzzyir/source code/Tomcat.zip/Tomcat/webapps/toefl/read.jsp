<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Reading </TITLE>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">
<script language="JavaScript">
		var sec=0;
		var min=0;
		var hour=0;
		function sub(){
			testform1.submit();
		}
		function setClock(){
				sec=sec+1;
				if(sec==60){min=min+1;sec=0;}
				if(min==60){hour=hour+1;min=0;}
				if((min==10)&&(sec==1)){alert("time over please click finish");sub();}
				
				setTimeout("setClock()",1000)
		}

		


		</script>
</HEAD>

<BODY BGCOLOR="#FFFFFF" BGCOLOR="#FFFFFF" onload = "setClock()">
<%@ page contentType = "text/html;charset=MS874" %> 
<%@  page import="java.sql.*"  %>
<%
  // ������ѡ
  int num=1+(int)(Math.random()*4);
	//out.println(num);
		
   Connection dbconn;
   String msgout = "";
      // Set up database connection
      try 
      {     // ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
            String url = "jdbc:odbc:TOEFL";

            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
            dbconn = DriverManager.getConnection( url );
	    Statement statement = dbconn.createStatement();
	   
%>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="pic_h/logo_min.jpg" width="96" height="77"></td>
  </tr>
</table>
		<div align="center">
		<p><b><font size="+3">READING COMPREHENSION</font></b></p></div>
		<p>
		<%
				 String query = "SELECT * FROM WREAD WHERE GRead="+num;
				//out.println(query);
				ResultSet  resultset = statement.executeQuery(query);
				resultset.next();
				out.println(resultset.getString("Eng"));
				
		  %>
						
<ol>	
		<form name="testform1" action="correct_read.jsp" method="post">
		<%
			query="SELECT * FROM READING WHERE GRead="+num+" Order by ID";
			resultset = statement.executeQuery(query);
			int i=0;
			while(resultset.next()){
			
		%>
	
		<li><%out.println(resultset.getString("Question"));%></li>
				<table width="80%" border="0" cellspacing="0" cellpadding="0">
				<tr> 
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="A" >
					(A) <%out.println(resultset.getString("Cha"));%></td>
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="B" >
					(B) <%out.println(resultset.getString("Chb"));%></td>
				</tr>
				<tr> 
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="C" >
					(C) <%out.println(resultset.getString("Chc"));%></td>
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="D" >
					(D) <%out.println(resultset.getString("Chd"));%></td>
				</tr>
				</table>
				
				<p>&nbsp;</p>
				<%i++;%>
	
		<%}
		i--;%>
		<input type="hidden" name=count value=<%=i%>>
		<input type="hidden" name=ch value=<%="'"+num+"'"%> >
		<input type="submit" value="FINISH">
		</form>
		</ol>
<%//		msgout = "Connection successful" ;
	dbconn.close();
      }
      catch ( ClassNotFoundException cnfex ) 
      {
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
      }
      catch ( SQLException sqlex ) 
      {    // �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
out.println(msgout);
%>
</BODY>
</HTML>
