<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Structure and Written expression </TITLE>
<Style>
a:link { Color:blue; TEXT-DECORATION: underline }
a:visited { Color:blue; TEXT-DECORATION: underline } 
a:hover { Color:red; TEXT-DECORATION: underline }
a:active { TEXT-DECORATION: none }

</Style>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">

<script language="JavaScript">
		var sec=0;
		var min=0;
		var hour=0;
		function sub() {
			testform1.submit();
		}
		function setClock(){
				sec=sec+1;
				if(sec==60){min=min+1;sec=0;}
				if(min==60){hour=hour+1;min=0;}
				if((min==30)&&(sec==1)){alert("time over please click finish");sub();}
				//var value =""+((hour>12)? hour-12:hour)+((min<10)? ":0":":")+min+((sec<10)? ":0":":")+sec;
				//document.clocktext.clock.value=value;
				setTimeout("setClock()",1000)
		}
		
</script>	
</HEAD>

<BODY BGCOLOR="#FFFFFF" onload = "setClock()">
<%@ page contentType = "text/html;charset=MS874" %> 
<%@  page import="java.sql.*"  %>

<%
  // ������ѡ
   int num=30;
   int temp_id[] = new int[num];
		for(int i=0; i<num; i=i+1){
			int j = 1+(int)(Math.random()*num);
			int boo=1;
			for (int k=0;k<i;k=k+1){
				if(j==temp_id[k]){boo=0;}
			}
			if(boo==1){temp_id[i]=j;}
			if(boo==0){i--;}
		}
		//for(int i=0;i<2;i=i+1){out.println(temp_id[i]);}
   Connection dbconn;
   String msgout = "";
      // Set up database connection
      try 
      {     // ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
            String url = "jdbc:odbc:TOEFL";

            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
            dbconn = DriverManager.getConnection( url );
	    Statement statement = dbconn.createStatement();
	   
%>		
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td><img src="pic_h/logo_min.jpg" width="96" height="77"></td>
		</tr>
		</table>
		<div align="center">
		
		<p><b><font size="+3">STRUCTURE AND WRITTEN EXPRESSION </font></b></p></div>
		<form name="testform1" action=correct_struc.jsp method="post">
		<ol>
			
		<%for(int i=0;i<num;i=i+1){
				 String query = "SELECT * FROM STRUCTURE where ID="+temp_id[i];
				//out.println(query);
				ResultSet  resultset = statement.executeQuery(query);
				resultset.next();

				String  col2 =resultset.getString("Question");
				String  cola =resultset.getString("Cha");
				if (cola==null){cola=" ";}
				String  colb =resultset.getString("Chb");
				if (colb==null){colb=" ";}
				String  colc =resultset.getString("Chc");
				if (colc==null){colc=" ";}
				String  cold =resultset.getString("Chd");
				if (cold==null){cold=" ";}
		  %>
				
				<li><%out.println(col2);%></li>
				<table width="80%" border="0" cellspacing="0" cellpadding="0">
				<tr> 
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="A" >
					(A) <%out.println(cola);%></td>
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="B" >
					(B) <%out.println(colb);%></td>
				</tr>
				<tr> 
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="C" >
					(C) <%out.println(colc);%></td>
				<td> 
				<input type="radio" name=<%= "n_"+i%> value="D" >
					(D) <%out.println(cold);%></td>
				</tr>
				</table>
				<input type="hidden" name=<%="ch_"+i%> value=<%="'"+temp_id[i]+"'"%> >
				<p>&nbsp;</p>
		<%}%>	
		</ol>
		<input type="submit" value="FINISH">
		</form>
<%//		msgout = "Connection successful" ;
	dbconn.close();
      }
      catch ( ClassNotFoundException cnfex ) 
      {
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
      }
      catch ( SQLException sqlex ) 
      {    // �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
out.println(msgout);
%>
</BODY>
</HTML>

