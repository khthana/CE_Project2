<html>
<head>
<title>++structure and written expression++</title>
<meta http-equiv="Content-Type" content="text/html; charset=">
</head>

<frameset rows="80,*" frameborder="NO" border="0" framespacing="0"> 
  <frame name="topFrame" scrolling="NO" noresize src="clock.htm" >
  <frame name="mainFrame" scrolling="yes" src="structure.jsp">
</frameset>
<noframes><body bgcolor="#FFFFFF">

</body></noframes>
</html>
