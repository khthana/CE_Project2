<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> ++Regis++ </TITLE>
<Style>
a:link { Color:blue; TEXT-DECORATION: underline }
a:visited { Color:blue; TEXT-DECORATION: underline } 
a:hover { Color:red; TEXT-DECORATION: underline }
a:active { TEXT-DECORATION: none }

</Style>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">
</HEAD>

<BODY BGCOLOR="#FFFFFF">
<%@ page contentType = "text/html;charset=MS874" %> 
<%@  page import="java.sql.*"  %>
<%
  // ������ѡ
  
   String Name=request.getParameter("firstname");
   String Surname=request.getParameter("surname");
   String Login=request.getParameter("login");
   String Password=request.getParameter("password");
   String conPassword=request.getParameter("conpassword");
   
   Connection dbconn;
   String msgout = "";
      // Set up database connection
      try 
      {     // ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
            String url = "jdbc:odbc:TOEFL";

            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
            dbconn = DriverManager.getConnection( url );
	    Statement statement = dbconn.createStatement();
	    int resultupdate=0;
		
		String query = "SELECT Password FROM MEMBER";
		ResultSet  resultset = statement.executeQuery(query);
		int boo=1;
		
		if(Password.equals("")||Name.equals("")||Surname.equals("")||conPassword.equals("")){boo=0;}
		if(!Password.equals(conPassword)){boo=0;}
		//out.println("1 "+boo);
		if(boo==1){
			while(resultset.next()){
				String temp=resultset.getString("Password");
				if(temp.equals(Password)){boo=0;}
			}
		}
		//out.println("2 "+boo);
%>

<%
		if(boo==1){
			query = "INSERT INTO MEMBER(Name,Surname,Login,Password)  VALUES('"+Name+"','"+Surname+"', '"+Login+"','"+Password+"')";
			statement = dbconn.createStatement();
			resultupdate = statement.executeUpdate(query);
			statement.close();
		}
%>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="pic_h/logo_min.jpg" width="96" height="77"></td>
  </tr>
</table>
<div align="center">
		
  <p><b><font size="+3">REGISTRATION</font></b></p></div>
	<%if(boo==1){%>
		<div align="center"><b><font size="+2" color="blue">Registration success</font></b></div>
		<div align="center"><a  href="index.jsp">go to main page</a></div>
	<%}else{%>
		<div align="center"><b><font size="+2" color="red">Registration not success</font></b></div>	
		<div align="center"><a  href="regis.jsp">regis again</a></div>	
	<%}%>

<%//		msgout = "Connection successful" ;
	dbconn.close();
      }
      catch ( ClassNotFoundException cnfex ) 
      {
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
      }
      catch ( SQLException sqlex ) 
      {    // �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
out.println(msgout);
%>

</BODY>
</HTML>
