<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> logout </TITLE>

<%@ page contentType = "text/html;charset=MS874" %> 
<%				
		//String sec_name=(String)session.getValue("name");
		//String sec_id=(String)session.getValue("id");
		//String sec_surname=(String)session.getValue("surname");
		//sec_id=null;
		//sec_name=null;
		//sec_surname=null;
		session.removeValue("id");
		session.removeValue("name");
		session.removeValue("surname");
		response.sendRedirect("menu.jsp");
%>
</HEAD>

<BODY BGCOLOR="#FFFFFF">

</BODY>
</HTML>
