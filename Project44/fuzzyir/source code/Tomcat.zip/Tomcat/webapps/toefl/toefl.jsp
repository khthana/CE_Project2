<html>
<head>
<title>++TOEFL++</title>
<Style>
a:link { Color:blue; TEXT-DECORATION: underline }
a:visited { Color:blue; TEXT-DECORATION: underline } 
a:hover { Color:red; TEXT-DECORATION: underline }
a:active { TEXT-DECORATION: none }

</Style>
<LINK rel="stylesheet"
      href="fig0810.css"
      type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=">
</head>

<frameset cols="180,849*" frameborder="YES" border="1" framespacing="1" rows="*" bordercolor="#CCCCCC"> 
  <frame name="leftFrame" scrolling="NO" noresize src="menu.jsp">
  <frame name="mainFrame" src="index.jsp">
</frameset>
<noframes><body bgcolor="#FFFFFF">

</body></noframes>
</html>
