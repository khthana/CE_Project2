package examples.synthesis;

import examples.*;

import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class HelloWorldThread extends Thread {
    
    public static void main(String[] args) {
        int mode=2;
        if(mode == 0 || mode == 2) {
            HelloWorldThread hwt = new HelloWorldThread();
            hwt.start();
        }
        if(mode == 1 || mode == 2) {
            HelloWorldThread hw2 = new HelloWorldThread();
            hw2.start();
        }
        //System.exit(0);
    }
    
    public void run() {
        Synthesizer synth = null;
        try {
            SynthesizerModeDesc desc = new SynthesizerModeDesc(Locale.ENGLISH);
            synth = Central.createSynthesizer(desc);
            desc = (SynthesizerModeDesc)synth.getEngineModeDesc();
            
            SpeakableAdapter sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
            synth.allocate();
            synth.resume();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            SynthesizerProperties props = synth.getSynthesizerProperties();
            
            Voice v = new Voice("Microsoft Mary",Voice.GENDER_FEMALE,
            Voice.AGE_MIDDLE_ADULT, null);
            props.setVoice(v);
            props.setVolume(1.0f);
            props.setSpeakingRate(200.0f);
            synth.speak("<emp>Hello</emp> World, can you <emp>hear</emp> me?",null);
            
            synth.waitEngineState(synth.QUEUE_EMPTY);
            
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            try {
                synth.deallocate();
                synth.waitEngineState(synth.DEALLOCATED);
                System.out.println("Bye!");
            } catch(Exception e2) {}
            //System.exit(0);
        }
    }
}
