package examples.synthesis;

import javax.speech.*;
import javax.speech.synthesis.*;

public class TestSpeakableListener extends SpeakableAdapter {
    public void wordStarted(SpeakableEvent e) {
	System.out.println(" "+e.getText().substring(e.getWordStart(),e.getWordEnd()));
    }
    public void markerReached(SpeakableEvent e) {
	System.out.println("Mark = "+e.getText());
    }
}
