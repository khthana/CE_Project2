package examples.synthesis;

import examples.*;

import javax.speech.*;
import javax.speech.recognition.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class MultiSynthRecTest {
    
    public static void main(String[] args) {
        Synthesizer synth = null;
        try {
            SynthesizerModeDesc desc = new SynthesizerModeDesc(Locale.ENGLISH);
            synth = Central.createSynthesizer(desc);
            Synthesizer[] syns = new Synthesizer[20];
            for(int i=0;i<20;i++) {
                syns[i] = Central.createSynthesizer(new SynthesizerModeDesc(null,null,null,Boolean.FALSE,null));
                syns[i].allocate();
                syns[i].resume();
                syns[i].waitEngineState(Synthesizer.ALLOCATED);
                System.out.println("Made synthesizer "+i);
            }
            
            Recognizer[] recs = new Recognizer[20];
            for(int i=0;i<20;i++)  {
                recs[i] = Central.createRecognizer(new RecognizerModeDesc(null,null,null,Boolean.FALSE,null,null));
                recs[i].allocate();
                recs[i].resume();
                recs[i].waitEngineState(Engine.ALLOCATED);
                System.out.println("Made recognizer "+i);
                RuleGrammar gram = recs[i].newRuleGrammar("time");
                for(int g=0;g<20;g++) {
                    gram = recs[i].newRuleGrammar("time"+g);
                    gram.setRule("testRule",new RuleToken("hello"),true);
                    gram.setEnabled(true);
                    System.out.println("Made grammar "+g+" for recognizer "+i);
                }
            }
            
            desc = (SynthesizerModeDesc)synth.getEngineModeDesc();
            
            SpeakableAdapter sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
            synth.allocate();
            synth.resume();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            SynthesizerProperties props = synth.getSynthesizerProperties();
            
            Voice v = new Voice("Microsoft Mary",Voice.GENDER_FEMALE,
            Voice.AGE_MIDDLE_ADULT, null);
            props.setVoice(v);
            props.setVolume(1.0f);
            props.setSpeakingRate(200.0f);
            synth.speak("<emp>Hello</emp> World, can you <emp>hear</emp> me?",null);
            
            synth.waitEngineState(synth.QUEUE_EMPTY);
            
            for(int i=0;i<20;i++) {
                syns[i].deallocate();
                syns[i].waitEngineState(Synthesizer.DEALLOCATED);
                System.out.println("Deallocated synth "+i);
            }
            
            for(int i=0;i<20;i++)  {
                recs[i].deallocate();
                recs[i].waitEngineState(Engine.DEALLOCATED);
                System.out.println("Deallocated recognizer "+i);
            }

        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            try {
                synth.deallocate();
                synth.waitEngineState(synth.DEALLOCATED);
                System.out.println("Bye!");
            } catch(Exception e2) {}
            System.exit(0);
        }
    }
}
