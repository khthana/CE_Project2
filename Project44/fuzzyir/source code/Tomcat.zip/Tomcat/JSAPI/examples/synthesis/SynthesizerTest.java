package examples.synthesis;

import examples.*;

import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class SynthesizerTest {
    
    public static void main(String[] args) {
        Synthesizer synth = null;
        try {
            SynthesizerModeDesc desc = new SynthesizerModeDesc(Locale.ENGLISH);
            synth = Central.createSynthesizer(desc);
            desc = (SynthesizerModeDesc)synth.getEngineModeDesc();
            synth.addEngineListener(new TestEngineListener());
            
            SpeakableAdapter sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
            synth.allocate();
            synth.resume();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            SynthesizerProperties props = synth.getSynthesizerProperties();
            props.setVolume(1.0f);
            props.setSpeakingRate(200.0f);
            
            Voice[] vs = desc.getVoices();
            Voice v1 = new Voice("Microsoft Sam",Voice.GENDER_DONT_CARE,
            Voice.AGE_MIDDLE_ADULT, "");
            Voice v2 = new Voice("Microsoft Mary",Voice.GENDER_FEMALE,
            Voice.AGE_MIDDLE_ADULT, null);
            props.setVoice(v1);
            props.setVolume(1.0f);
            props.setSpeakingRate(200.0f);
            synth.speak("<emp>Hello</emp> World, how are you?",null);
            
            Thread.currentThread().sleep(700);
            synth.pause();
            
            Thread.currentThread().sleep(2000);
            synth.resume();
            
            synth.waitEngineState(synth.QUEUE_EMPTY);
            props.setVoice(v2);
            synth.speak("and Hello World again",null);
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            synth.speak("... this sentence should be cancelled if it goes on for more than 2 seconds",null);
            Thread.currentThread().sleep(2000);
            synth.cancel();
            synth.speak("... this sentence should be spoken in it's place",null);
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            synth.speak("Here are all my English voices",null);
            for(int i=0;i<vs.length;i++) {
                String name = vs[i].getName();
                props.setVoice(vs[i]);
                synth.speak("Hello, my name is "+name,null);
                synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            }
            
            props.setVoice(vs[0]);
            
            synth.removeSpeakableListener(sad);
            
            synth.speak("Now I'll read from a file",null);
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            
            URL jsml=new File("examples/testJSML.xml").toURL();
            synth.speak(jsml,sad);
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            synth.cancelAll();
            try {
                synth.deallocate();
                synth.waitEngineState(Synthesizer.DEALLOCATED);
            } catch(Exception e2) {}
            System.exit(0);
        }
    }
}
