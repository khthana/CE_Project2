package examples.synthesis;

import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.Locale;
import java.io.IOException;

/**
 * Demonstrates the new methods in AudioManager to save speech to
 * a wave file.
 */
public class SpeakToFile {
    public static void main(String args[]) {
        Synthesizer synth = null;
        try {
            synth = Central.createSynthesizer(new
            SynthesizerModeDesc(Locale.ENGLISH));
            AudioManager audioMan = synth.getAudioManager();
            
            synth.allocate();
            synth.resume();
            
            synth.speakPlainText("I'm getting ready to make waves",null);
            //Wait till all done or you'll speak to the wave file...
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            
            //... which is opened here.
            try {
                audioMan.setOutputFile("hello1.wav",11,8);
                synth.speakPlainText("Hello world",null);
                //speakPlainText is synchronous when outputting to a file, 
                //so no need to wait till queue is empty,because when we reach 
                //this point in the code, the wave file is already written.
                
                //but remember to close the output file otherwise the results are uncertain
                audioMan.closeOutputFile();
            } catch(IOException e) {
                //If the file cannot be opened (eg if it is already opened by 
                //another application) we will get an IOException
                e.printStackTrace();
            }
            
            //Speak to a different file...
            try {
                audioMan.setOutputFile("hello2.wav",22,8);
                synth.speakPlainText("and how are you today?",null);
                audioMan.closeOutputFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            
            //...and now speak to the default audio device
            try {
                audioMan.setOutputFile(null,0,0);
            } catch(IOException e) {
                e.printStackTrace();
            }
            synth.speakPlainText("and now I'm all done",null);
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                synth.deallocate();
                //wait till we are deallocated...
                synth.waitEngineState(Engine.DEALLOCATED);
            } catch(Exception e2) {
                e2.printStackTrace();
            }
            System.out.println("All Done - now play the audio files");
            System.out.println("hello1.wav and hello2.wav to hear if it worked");
        }
        //...before closing up shop
        System.exit(0);
    }
}

