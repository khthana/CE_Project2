package examples.synthesis;

import examples.*;

import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class HelloWorld_finnish {
    
    public static void main(String[] args) {
        Synthesizer synth = null;
        try {
            SynthesizerModeDesc desc = new SynthesizerModeDesc(Locale.ENGLISH);
            synth = Central.createSynthesizer(desc);

            desc = (SynthesizerModeDesc)synth.getEngineModeDesc();
            
            SpeakableAdapter sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
            synth.allocate();
            synth.resume();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            SynthesizerProperties props = synth.getSynthesizerProperties();
            
            Voice v = new Voice("Microsoft Mary",Voice.GENDER_FEMALE,
				Voice.AGE_MIDDLE_ADULT, null);
            props.setVoice(v);
            props.setVolume(1.0f);
            props.setSpeakingRate(170.0f);
            //synth.speak("<emp>Hello</emp> World, can you <emp>hear</emp> me?",null);
            
            AudioManager am = synth.getAudioManager();
            am.setOutputFile("finnish.wav",11,8);
            
            VocabManager vm = synth.getVocabManager();
            String pron;
            pron = "t eh r - v ey  t t uw - l - ow 1 - aa";
            vm.removeWord(new Word("tervetuloa1","tervetuloa",
            null, Word.DONT_CARE));
            vm.removeWord(new Word("tervetuloa2","tervetuloa",
            null, Word.DONT_CARE));
            vm.removeWord(new Word("tervetuloa3","tervetuloa",
            null, Word.DONT_CARE));
            vm.removeWord(new Word("tervetuloa4","tervetuloa",
            null, Word.DONT_CARE));
            
            vm.addWord(new Word("tervetuloa1","tervetuloa",
            new String[] {pron}, Word.DONT_CARE));
            synth.speakPlainText("tervetuloa1",null);
            
            pron = "t ey r - v ey - 2 t uh - l - ow 1 - aa";
            vm.addWord(new Word("tervetuloa2","tervetuloa",
            new String[] {pron}, Word.DONT_CARE));
            synth.speakPlainText("tervetuloa2",null);
            
            pron = "t ah r - v ah - 2 t uh - l - ow 1 - aa";
            vm.addWord(new Word("tervetuloa3","tervetuloa",
            new String[] {pron}, Word.DONT_CARE));
            synth.speakPlainText("tervetuloa3",null);
            
            pron = "t eh r - v eh - 2 t uh - l - ow 1 - aa";
            vm.addWord(new Word("tervetuloa4","tervetuloa",
            new String[] {pron}, Word.DONT_CARE));
            synth.speakPlainText("tervetuloa4",null);
            
            //pron = "h  iy v 0276 0276  y 00F8 t aa";
            pron = "h  iy v aa 2 & y uh 1 t aa";
            vm.removeWord(new Word("hyvaa","hyvaa",null,Word.DONT_CARE));
            vm.addWord(new Word("hyvaa","hyvaa",
            new String[] {pron}, Word.DONT_CARE));
            synth.speakPlainText("hyvaa",null);
            
            am.closeOutputFile();
            
            synth.waitEngineState(synth.QUEUE_EMPTY);
            
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            try {
                synth.deallocate();
		synth.waitEngineState(synth.DEALLOCATED);
		System.out.println("Bye!");
            } catch(Exception e2) {}
            System.exit(0);
        }
    }
}
