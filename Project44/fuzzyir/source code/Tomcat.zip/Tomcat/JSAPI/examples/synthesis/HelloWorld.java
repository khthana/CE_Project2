package examples.synthesis;

import examples.*;

import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

/**
 * Demonstrates simple speech synthesis, but also the 
 * addition of a word (with pronunciation)
 * to the VocabManager, and JSML tags in the speech string.
 */
public class HelloWorld {
    
    public static void main(String[] args) {
        Synthesizer synth = null;
        try {
            SynthesizerModeDesc desc = new SynthesizerModeDesc(Locale.ENGLISH);
            synth = Central.createSynthesizer(desc);

            desc = (SynthesizerModeDesc)synth.getEngineModeDesc();
            
            SpeakableAdapter sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
            synth.allocate();
            synth.resume();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            SynthesizerProperties props = synth.getSynthesizerProperties();
            
            Voice v = new Voice("Microsoft Mary",Voice.GENDER_FEMALE,
				Voice.AGE_DONT_CARE, null);
            props.setVoice(v);
            props.setVolume(1.0f);
            props.setSpeakingRate(200.0f);

            //Demonstrating adding a new pronunciation for an existing word
            //Capitalization is important!
            //For the phonetic symbols, refer to the Microsoft SAPI 5.0 Help
            //documentation under "American English Phoneme Representation"
            String pron = "h aw 1 d iy ";
            VocabManager vm = synth.getVocabManager();
            Word howdy = new Word("Hello","hello",new String[] {pron}, Word.DONT_CARE);
            vm.addWord(howdy);
            
            synth.speak("<emp>Hello</emp> World, can you <emp>hear</emp> me?",null);
            
            synth.waitEngineState(synth.QUEUE_EMPTY);
            
            vm.removeWord(howdy);
            
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            try {
                synth.deallocate();
		synth.waitEngineState(synth.DEALLOCATED);
		System.out.println("Deallocated");
            } catch(Exception e2) {}
            System.exit(0);
        }
    }
}
