package examples;

import examples.*;

import javax.speech.*;
import javax.speech.recognition.*;
import javax.speech.synthesis.*;
import java.util.*;
import java.net.*;
import java.io.*;

/**
 * Just lists all the available Synthesizers (with Voices) amd Recognizers (with SpeakerProfiles)
 */
public class ListEngineTest {
    
    public static void main(String[] args) {
        EngineList list;
        
        list = Central.availableSynthesizers(new SynthesizerModeDesc(Locale.ENGLISH));
        for(int i = 0; i<list.size(); i++) {
            System.out.println("English Synthesizer number "+(i+1)+"\n"+list.elementAt(i));
        }
        
        list = Central.availableSynthesizers(new SynthesizerModeDesc(Locale.SIMPLIFIED_CHINESE));
        for(int i = 0; i<list.size(); i++) {
            System.out.println("Chinese Synthesizer number "+(i+1)+"\n"+list.elementAt(i));
        }
        
        list = Central.availableSynthesizers(new SynthesizerModeDesc(Locale.JAPANESE));
        for(int i = 0; i<list.size(); i++) {
            System.out.println("Japanese Synthesizer number "+(i+1)+"\n"+list.elementAt(i));
        }
        
        list = Central.availableRecognizers(new RecognizerModeDesc(Locale.ENGLISH,Boolean.TRUE));
        for(int i = 0; i<list.size(); i++) {
            System.out.println("English Recognizer number "+(i+1)+"\n"+list.elementAt(i));
        }
        list = Central.availableRecognizers(new RecognizerModeDesc(Locale.SIMPLIFIED_CHINESE,Boolean.TRUE));
        for(int i = 0; i<list.size(); i++) {
            System.out.println("Chinese Recognizer number "+(i+1)+"\n"+list.elementAt(i));
        }
    }
}