package examples.recognition;

import examples.*;
import javax.speech.*;
import javax.speech.recognition.*;
import java.io.*;
import java.net.*;

public class LoadJSGFFromURL {
    static Recognizer rec = null;
    
    /**
     * Demonstrates loading a grammar consisting of an initial
     * grammar, grammars.helloWorld, and an imported grammar,
     * grammars.numbers, from a single URL
     */
    public static void main(String[] args) {
        try {
            rec = Central.createRecognizer(null);
            rec.addEngineListener(new TestEngineListener());
            rec.addResultListener(new TestResultListener(rec));
            
            RecognizerAudioAdapter raud = new TestAudioListener();
            rec.getAudioManager().addAudioListener(raud);
            
            rec.allocate();
            
            rec.waitEngineState(Recognizer.ALLOCATED);
            RecognizerProperties props = rec.getRecognizerProperties();
            props.setNumResultAlternatives(5);
            
            //URL dir=new File("dummy").toURL(); //If you use this line
            //the recognizer will look for the grammars in the system classpath
            
            URL dir=new File("examples").toURL(); //The recognizer will look
            //for the grammar files starting from the examples directory
            
            RuleGrammar gram = rec.loadJSGF(dir,"grammars.helloWorld",
            true,true,null);
            String[] names = gram.listRuleNames();
            for(int i=0;i<names.length; i++) {
                Rule rule = gram.getRule(names[i]);
                System.out.println("Adding rule "+names[i]+"\n"+rule);
            }
            
            gram.setEnabled(true);
            
            rec.commitChanges();
            
            rec.requestFocus();
            rec.resume();
            
            rec.waitEngineState(Recognizer.DEALLOCATED);
            //three recognitions and we deallocate
            
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            try {
                rec.deallocate();
            } catch(Exception e2) {
                e2.printStackTrace(System.out);
            }
            System.exit(0);
        }
    }
}
