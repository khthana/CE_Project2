package examples.recognition;

import javax.speech.*;
import javax.speech.recognition.*;

/**
 * Class to display result events. Also demonstrates playback
 * of recorded speech and use of tokenCorrection (except the
 * actual tokenCorrection line has been commented out).
 */
public class TestResultListener extends ResultAdapter {
    private int nRecs = 0;
    private Recognizer rec;
    
    public TestResultListener(Recognizer rec) {
        this.rec = rec;
    }
    
    public void resultRejected(ResultEvent e) {
        Result r = (Result)(e.getSource());
        System.out.println("Result Rejected ");
    }
    public void resultCreated(ResultEvent e) {
        Result r = (Result)(e.getSource());
        System.out.println("Result Created ");
    }
    public void resultUpdated(ResultEvent e) {
        Result r = (Result)(e.getSource());
        System.out.println("Result Updated: "+r);
    }
    public void resultAccepted(ResultEvent e) {
        try {
            FinalResult r = (FinalResult)(e.getSource());
            ResultToken tokens[] = null;
            //only way to find out if it's a FinalRuleResult or a FinalDictationResult is to see whether
            //it's grammar is a Rule or Dictation Grammar, since all Results obtained from a ResultEvent
            //implement both FinalRuleResult and FinalDictationResult interfaces (see JSAPI documentation)
            if(r.getGrammar() instanceof RuleGrammar) {
                System.out.println("RuleGrammar name="+((FinalRuleResult)r).getRuleGrammar(0).getName());
                System.out.println("Rule name="+((FinalRuleResult)r).getRuleName(0));
                tokens = ((FinalRuleResult)r).getAlternativeTokens(0);
            } else {
                System.out.println("Grammar name="+r.getGrammar().getName());
                tokens = r.getBestTokens();
            }

            System.out.println("Speaking all tokens of recorded speech");
            java.applet.AudioClip clip = r.getAudio(0,tokens.length-1);
            
            if(clip != null) clip.play();
            //release it so it doesn't hang about wasting space
            r.releaseAudio();
            //... but you won't be able to play it again...
            if(clip != null) clip.play();
            //...see, you should have heard nothing the second time play is called
            
            
            //Test out token correction - here we just get the "nAlt"th alternative
            //and "correct" the result using it
            //(except here we've commented out the tokenCorrection call
            //...include that line if you actually want to update your profile randomly!
            
            try {
                ResultToken[][] toks = r.getAlternativeTokens(0,tokens.length-1,5);
                int nAlt=1;
                if(toks != null && toks.length > nAlt) {
                    String[] stoks = new String[toks[nAlt].length];
                    for(int i=0;i<stoks.length;i++) stoks[i] = toks[nAlt][i].getSpokenText();
                    System.out.print("Correcting ");
                    for(int i=0;i<tokens.length;i++)
                        System.out.print(tokens[i].getSpokenText()+" ");
                    System.out.print("\nWith ");
                    for(int i=0;i<stoks.length;i++)
                        System.out.print(stoks[i]+" ");
                    System.out.println("\nExcept the tokenCorrection call is commented out");
                    //r.tokenCorrection(stoks,0,tokens.length-1, 0);
                }
            } catch(ResultStateError er) {
                er.printStackTrace(System.out);
                //Result is not a DictationResult
            }
            
            System.out.print("Result Accepted: "+r);
        } catch(Exception e1) {
            e1.printStackTrace(System.out);
        } catch(ResultStateError er) {
            er.printStackTrace(System.out);
        }
        if(++nRecs == 3) {
            try {
                rec.deallocate();
            } catch(Exception e2) {
                e2.printStackTrace(System.out);
            }
        }
    }
}
