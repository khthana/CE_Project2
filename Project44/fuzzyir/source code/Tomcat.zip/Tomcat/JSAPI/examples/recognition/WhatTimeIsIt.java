package examples.recognition;

import examples.*;
import examples.synthesis.*;
import javax.speech.*;
import javax.speech.recognition.*;
import javax.speech.synthesis.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class WhatTimeIsIt {
    public static Recognizer rec = null;
    public static Synthesizer synth = null;
    
    public static void main(String[] args) {
        try {
            rec = Central.createRecognizer(null);
            rec.addEngineListener(new TestEngineListener());
            rec.addResultListener(new TestResultListener(rec));
            rec.addResultListener(new ResultAdapter() {
                public void resultAccepted(ResultEvent e) {
                    try {
                        FinalRuleResult r =
                        (FinalRuleResult)(e.getSource());
                        String tags[] = r.getTags();
                        SimpleDateFormat df;
                        Date d = new Date();
                        if(tags[0].equals("TIME")) {
                            df = new SimpleDateFormat("h:mm a, zzzz");
                            synth.speak("The time is "+df.format(d),null);
                        } else if(tags[0].equals("DATE")) {
                            df = new SimpleDateFormat("EEE, MMM d, yyyy");
                            synth.speak("The date is "+df.format(d),null);
                        } else return;
                            /*
                              If you put a waitEngineState in here you will get
                              deadlock because the Synthesizer will wait for
                              an EngineEvent but the EngineEvent can't be sent
                              because the Synchronizer is also waiting for the
                              EventQueue to be released, but that can't happen
                              till this resultAccepted method returns!
                             
                              The solution here is to put the
                              synth.waitEngineState call in the main method
                              after rec.waitEngineState(Engine.DEALLOCATED).
                             
                              If such a solution is not possible you can turn
                              off AWT synchronization with the System Property
                              "noawtsync"
                             
                              //synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
                             */
                        rec.deallocate();
                    } catch(Exception e1) {
                        e1.printStackTrace(System.out);
                    }
                }
            }
            );
            
            RecognizerAudioAdapter raud = new TestAudioListener();
            rec.getAudioManager().addAudioListener(raud);
            
            rec.allocate();
            
            rec.waitEngineState(Recognizer.ALLOCATED);
            RuleSequence rs1 = new RuleSequence();
            RuleToken rt1 = new RuleToken("what");
            rs1.append(rt1);
            RuleTag rt2 = new RuleTag(new RuleToken("time"),"TIME");
            RuleTag rt3 = new RuleTag(new RuleToken("date"),"DATE");
            RuleAlternatives ra1 = new RuleAlternatives();
            ra1.append(rt2);
            ra1.append(rt3);
            rs1.append(ra1);
            RuleToken rt4 = new RuleToken("is it");
            rs1.append(rt4);
            RuleGrammar gram = rec.newRuleGrammar("time");
            gram.setRule("testRule",rs1,true);
            
            gram.setEnabled(true);
            
            RecognizerProperties rprops = rec.getRecognizerProperties();
            //Retain audio so it can be played back later (see TestResultListener)
            rprops.setResultAudioProvided(true);
            
            synth = Central.createSynthesizer(null);
            synth.addEngineListener(new TestEngineListener());
            
            synth.allocate();
            synth.waitEngineState(Synthesizer.ALLOCATED);
            synth.resume();
            
            SynthesizerProperties sprops = synth.getSynthesizerProperties();
            Voice v = new Voice("Microsoft Mary",Voice.GENDER_FEMALE,
            Voice.AGE_MIDDLE_ADULT, null);
            sprops.setVoice(v);
            
            SpeakableAdapter sad = new TestSpeakableListener();
            synth.addSpeakableListener(sad);
            
            SynthesizerProperties props = synth.getSynthesizerProperties();
            sprops.setVolume(1.0f);
            sprops.setSpeakingRate(200.0f);
            
            rec.commitChanges();
            
            rec.requestFocus();
            rec.resume();
            
            rec.waitEngineState(Recognizer.DEALLOCATED);
            //one recognition and we deallocate
            
            //See resultAccepted method for note about possible deadlock
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } catch(Error e1) {
            e1.printStackTrace(System.out);
        } finally {
            try {
                synth.deallocate();
                rec.deallocate();
                rec.waitEngineState(Synthesizer.DEALLOCATED);
                synth.waitEngineState(Synthesizer.DEALLOCATED);
            } catch(Exception e2) {
                e2.printStackTrace(System.out);
            }
            System.exit(0);
        }
    }
}
