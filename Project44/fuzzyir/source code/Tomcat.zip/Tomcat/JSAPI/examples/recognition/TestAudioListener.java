package examples.recognition;

import javax.speech.*;
import javax.speech.recognition.*;

public class TestAudioListener extends RecognizerAudioAdapter {
    public void speechStarted(RecognizerAudioEvent e) {
	System.out.println("Speech started");
    }
    public void speechStopped(RecognizerAudioEvent e) {
	System.out.println("Speech stopped");
    }
}
