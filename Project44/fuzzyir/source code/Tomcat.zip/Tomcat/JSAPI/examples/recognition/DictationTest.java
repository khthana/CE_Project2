package examples.recognition;

import examples.*;
import javax.speech.*;
import javax.speech.recognition.*;
import java.io.*;

public class DictationTest {
    static Recognizer rec = null;

    public static void main(String[] args) {
	try {
	    rec = Central.createRecognizer(null);
	    rec.addEngineListener(new TestEngineListener());
	    rec.addResultListener(new TestResultListener(rec));

	    RecognizerAudioAdapter raud = new TestAudioListener();
	    rec.getAudioManager().addAudioListener(raud);

	    rec.allocate();

	    rec.waitEngineState(Recognizer.ALLOCATED);
	    RecognizerProperties props = rec.getRecognizerProperties();
	    props.setNumResultAlternatives(5);
            
            //Retain audio so it can be played back later (see TestResultListener)
            props.setResultAudioProvided(true);

            //Lets list all the speaker profiles and set the current profile to the first one in
            //the list
            SpeakerManager speakerManager = rec.getSpeakerManager();
            SpeakerProfile[] profs = speakerManager.listKnownSpeakers();
            for(int i=0;i<profs.length; i++) {
                System.out.println("Found Profile "+i+" = "+profs[i].getName());
            }
            System.out.println("Current Profile="+speakerManager.getCurrentSpeaker().getName());
            speakerManager.setCurrentSpeaker(profs[0]);
            System.out.println("Changed Current Profile to "+speakerManager.getCurrentSpeaker().getName());

	    DictationGrammar dictation;
	    //You may only load and enable EITHER dictation or spelling
	    int mode = 1; //For dictation
	    //mode = 2; //For spelling
	    if(mode == 1) {
		dictation = rec.getDictationGrammar("dictation");
	    } else {
		dictation = rec.getDictationGrammar("spelling");
	    }
	    dictation.setEnabled(true);
	    
	    rec.commitChanges();

	    rec.requestFocus();
	    rec.resume();

	    rec.waitEngineState(Recognizer.DEALLOCATED); 
	    //three recognitions and we deallocate

	} catch(Exception e) {
	    e.printStackTrace(System.out);
	} catch(Error e1) {
	    e1.printStackTrace(System.out);
	} finally {
	    try {
		rec.deallocate();
	    } catch(Exception e2) {
		e2.printStackTrace(System.out);
	    }
	    System.exit(0);
	}
    }
}
