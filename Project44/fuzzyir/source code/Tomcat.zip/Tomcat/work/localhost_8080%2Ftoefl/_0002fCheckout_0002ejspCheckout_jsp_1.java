import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fCheckout_0002ejspCheckout_jsp_1 extends HttpJspBase {

    // begin [file="C:\\Checkout.jsp";from=(9,0);to=(11,26)]
    // end

    static {
    }
    public _0002fCheckout_0002ejspCheckout_jsp_1( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\Checkout.jsp";from=(0,0);to=(9,0)]
                out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<HTML>\r\n<HEAD>\r\n<TITLE> Logout from chatroom </TITLE>\r\n<META NAME=\"Generator\" CONTENT=\"EditPlus\">\r\n<META NAME=\"Author\" CONTENT=\"\">\r\n<META NAME=\"Keywords\" CONTENT=\"\">\r\n<META NAME=\"Description\" CONTENT=\"\">\r\n</HEAD>\r\n");
            // end
            // begin [file="C:\\Checkout.jsp";from=(9,0);to=(11,26)]
                java.util.Vector user = null;
                boolean _jspx_specialuser  = false;
                 synchronized (application) {
                    user= (java.util.Vector)
                    pageContext.getAttribute("user",PageContext.APPLICATION_SCOPE);
                    if ( user == null ) {
                        _jspx_specialuser = true;
                        try {
                            user = (java.util.Vector) Beans.instantiate(getClassLoader(), "java.util.Vector");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"java.util.Vector");
                        }
                        pageContext.setAttribute("user", user, PageContext.APPLICATION_SCOPE);
                    }
                 } 
                if(_jspx_specialuser == true) {
            // end
            // begin [file="C:\\Checkout.jsp";from=(9,0);to=(11,26)]
                }
            // end
            // HTML // begin [file="C:\\Checkout.jsp";from=(11,26);to=(16,0)]
                out.write("\r\n<BODY>\r\n<h1>Thank you</h1>\r\n<h2>Thai Engine comming soon...</h2>\r\n<A HREF=\"Nickname.html\" target=\"_parent\">Chat again</A>\r\n");
            // end
            // begin [file="C:\\Checkout.jsp";from=(16,2);to=(20,0)]
                
                	String name = (String)session.getValue("Name");
                	session.removeValue("ListenTo");
                	user.removeElement(name);
            // end
            // HTML // begin [file="C:\\Checkout.jsp";from=(20,2);to=(23,0)]
                out.write("\r\n</BODY>\r\n</HTML>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
