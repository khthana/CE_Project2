import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;
import java.sql.*;


public class _0002findex_0002ejspindex_jsp_0 extends HttpJspBase {


    static {
    }
    public _0002findex_0002ejspindex_jsp_0( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=MS874");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\index.jsp";from=(0,0);to=(37,0)]
                out.write("<html>\r\n<head>\r\n<title>Untitled Document</title>\r\n\r\n\r\n\r\n<script language=\"JavaScript\">\r\n<!--\r\nfunction MM_swapImgRestore() { //v3.0\r\n  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;\r\n}\r\n\r\nfunction MM_preloadImages() { //v3.0\r\n  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();\r\n    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)\r\n    if (a[i].indexOf(\"#\")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}\r\n}\r\n\r\nfunction MM_findObj(n, d) { //v3.0\r\n  var p,i,x;  if(!d) d=document; if((p=n.indexOf(\"?\"))>0&&parent.frames.length) {\r\n    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}\r\n  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];\r\n  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;\r\n}\r\n\r\nfunction MM_swapImage() { //v3.0\r\n  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)\r\n   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}\r\n}\r\n//-->\r\n</script>\r\n</head>\r\n\r\n<body bgcolor=\"#FFFFFF\" onLoad=\"MM_preloadImages('pic_h/Structure_down.jpg','pic_h/Reading_down.jpg','pic_h/Listening_down.jpg')\" >\r\n\r\n\r\n\r\n");
            // end
            // HTML // begin [file="C:\\index.jsp";from=(37,33);to=(38,0)]
                out.write("\r\n");
            // end
            // HTML // begin [file="C:\\index.jsp";from=(38,51);to=(39,0)]
                out.write(" \r\n");
            // end
            // begin [file="C:\\index.jsp";from=(39,2);to=(56,0)]
                
                
                  // คลาสหลัก
                 
                   Connection dbconn;
                   String msgout = "";
                      // Set up database connection
                      try 
                      {     // ส่วนติดต่อกับฐาานข้อมูล โดยการใช้ JDBC-ODBC
                            String url = "jdbc:odbc:TOEFL";
                
                            Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
                            dbconn = DriverManager.getConnection( url );
                	    Statement statement = dbconn.createStatement();
                	    String query = "SELECT Count FROM Counter";
                	   ResultSet  resultset = statement.executeQuery(query);
                	   resultset.next();
            // end
            // HTML // begin [file="C:\\index.jsp";from=(56,2);to=(106,0)]
                out.write("\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n  <tr> \r\n    <td width=\"36%\" height=\"42\">&nbsp;</td>\r\n    <td rowspan=\"4\" width=\"29%\"> \r\n      <div align=\"center\"><img src=\"pic_h/logo.jpg\" width=\"289\" height=\"233\"></div>\r\n    </td>\r\n    <td height=\"42\" width=\"35%\">&nbsp;</td>\r\n  </tr>\r\n  <tr> \r\n    <td width=\"36%\" height=\"65\">\r\n      <div align=\"center\"><img src=\"pic_h/Tutor.jpg\" width=\"180\" height=\"31\"></div>\r\n    </td>\r\n    <td height=\"65\" width=\"35%\"> \r\n      <div align=\"center\"><a href=\"#\" onMouseOut=\"MM_swapImgRestore()\" onMouseOver=\"MM_swapImage('Image6','','pic_h/Structure_down.jpg',1)\"><img name=\"Image6\" border=\"0\" src=\"pic_h/Structure_up.jpg\" width=\"180\" height=\"31\"></a></div>\r\n    </td>\r\n  </tr>\r\n  <tr> \r\n    <td width=\"36%\" height=\"68\"> \r\n      <div align=\"center\"><a href=\"#\" onMouseOut=\"MM_swapImgRestore()\" onMouseOver=\"MM_swapImage('Image7','','pic_h/Listening_down.jpg',1)\"><img name=\"Image7\" border=\"0\" src=\"pic_h/Listening_up.jpg\" width=\"180\" height=\"31\"></a></div>\r\n    </td>\r\n    <td height=\"68\" width=\"35%\"> \r\n      <div align=\"center\"><a href=\"#\" onMouseOut=\"MM_swapImgRestore()\" onMouseOver=\"MM_swapImage('Image5','','pic_h/Reading_down.jpg',1)\"><img name=\"Image5\" border=\"0\" src=\"pic_h/Reading_up.jpg\" width=\"178\" height=\"31\"></a></div>\r\n    </td>\r\n  </tr>\r\n  <tr> \r\n    <td width=\"36%\">&nbsp;</td>\r\n    <td width=\"35%\">&nbsp;</td>\r\n  </tr>\r\n</table>\r\nการสอบ TOEFL เป็นการสอบเพื่อวัดความสามารถทางภาษาอังกฤษ สำหรับผู้ที่ต้องการจะเข้าศึกษาต่อในระดับมหาวิทยาลัยมากกว่า \r\n2400 แห่งของประเทศสหรัฐอเมริกาและแคนนาดา และยังจำเป็นอย่างยิ่งในหลายประเทศที่ใช้ภาษาอังกฤษเป็นหลัก \r\nไม่ว่าจะเป็นการเข้าทำงานในองค์กรของรัฐ การได้รับทุน การขอใบอนุญาต เป็นต้น ล้วนแล้วแต่ต้องใช้คะแนนของการสอบ \r\nTOEFL เป็นตัวประเมินทั้งสิ้น<BR>\r\n<BR>ในการสอบแบบ \r\ncomputer-based เริ่มใช้ครั้งแรกในเดือนกรกฎาคม 1998 \r\nเป็นการสอบโดยใช้คอมพิวเตอร์เพียงอย่างเดียว<BR>หัวข้อที่สอบจะแบ่งออกเป็น 4 หัวข้อ \r\nดังต่อไปนี้ \r\n<UL>\r\n  <LI><B>Listening</B> เป็นการวัดความเข้าใจในการฟัง \r\n  จะทดสอบเรื่องการจับใจความสำคัญเป็นหลัก \r\n  ผู้สอบจะได้เห็นและได้ยินคำถามก่อนที่จะเลือกคำตอบ คะแนนเต็ม 30 \r\n  <LI><B>Structure</B> \r\n  เป็นการวัดการใช้ภาษาอังกฤษโดยเนื้อหาที่นำมาออกข้อสอบจะมาจากประวัติศาสตร์ของประเทศสหรัฐอเมริกาและแคนนาดาเป็นหลัก \r\n  คะแนนเต็ม 30 \r\n  <LI><B>Reading</B> เป็นการวัดความสามารถในการอ่านจับใจความ โดยให้อ่าน short \r\n  passages แล้วตอบคำถามในแต่ละ passage นั้น ๆ คะแนนเต็ม 30 \r\n  <LI><B>Writing</B> เป็นการวัดทักษะในการเขียนโดยจะให้เขียน Essay \r\n  หนึ่งเรื่องตามหัวข้อที่กำหนด คะแนนเต็ม 30 </LI></UL>\r\n<p>\r\n");
            // end
            // begin [file="C:\\index.jsp";from=(106,2);to=(120,0)]
                
                	int num=resultset.getInt("Count");
                	String sec_welcome=(String)session.getValue("welcome");
                	if(sec_welcome==null){sec_welcome="true";session.putValue("welcome",sec_welcome);}
                	if(sec_welcome=="true"){
                		num++;
                		sec_welcome="false";
                		session.putValue("welcome",sec_welcome);
                		query = "UPDATE COUNTER SET Count= "+num;
                		statement = dbconn.createStatement();
                		statement.executeUpdate(query);
                		statement.close();
                	}
                	int bit;
            // end
            // HTML // begin [file="C:\\index.jsp";from=(120,2);to=(121,1)]
                out.write("\r\n\t");
            // end
            // begin [file="C:\\index.jsp";from=(121,3);to=(121,17)]
                bit=num/10000;
            // end
            // HTML // begin [file="C:\\index.jsp";from=(121,19);to=(121,35)]
                out.write("<img src=\"pic_h/");
            // end
            // begin [file="C:\\index.jsp";from=(121,38);to=(121,41)]
                out.print(bit);
            // end
            // HTML // begin [file="C:\\index.jsp";from=(121,43);to=(122,1)]
                out.write(".gif\">\r\n\t");
            // end
            // begin [file="C:\\index.jsp";from=(122,3);to=(122,24)]
                bit=(num%10000)/1000;
            // end
            // HTML // begin [file="C:\\index.jsp";from=(122,26);to=(122,42)]
                out.write("<img src=\"pic_h/");
            // end
            // begin [file="C:\\index.jsp";from=(122,45);to=(122,48)]
                out.print(bit);
            // end
            // HTML // begin [file="C:\\index.jsp";from=(122,50);to=(123,1)]
                out.write(".gif\">\r\n\t");
            // end
            // begin [file="C:\\index.jsp";from=(123,3);to=(123,22)]
                bit=(num%1000)/100;
            // end
            // HTML // begin [file="C:\\index.jsp";from=(123,24);to=(123,40)]
                out.write("<img src=\"pic_h/");
            // end
            // begin [file="C:\\index.jsp";from=(123,43);to=(123,46)]
                out.print(bit);
            // end
            // HTML // begin [file="C:\\index.jsp";from=(123,48);to=(124,1)]
                out.write(".gif\">\r\n\t");
            // end
            // begin [file="C:\\index.jsp";from=(124,3);to=(124,20)]
                bit=(num%100)/10;
            // end
            // HTML // begin [file="C:\\index.jsp";from=(124,22);to=(124,38)]
                out.write("<img src=\"pic_h/");
            // end
            // begin [file="C:\\index.jsp";from=(124,41);to=(124,44)]
                out.print(bit);
            // end
            // HTML // begin [file="C:\\index.jsp";from=(124,46);to=(125,1)]
                out.write(".gif\">\r\n\t");
            // end
            // begin [file="C:\\index.jsp";from=(125,3);to=(125,14)]
                bit=num%10;
            // end
            // HTML // begin [file="C:\\index.jsp";from=(125,16);to=(125,32)]
                out.write("<img src=\"pic_h/");
            // end
            // begin [file="C:\\index.jsp";from=(125,35);to=(125,38)]
                out.print(bit);
            // end
            // HTML // begin [file="C:\\index.jsp";from=(125,40);to=(128,0)]
                out.write(".gif\">\r\n<hr width=\"70%\">\r\n<p align=\"center\"><a href=\"mailto:puttree@hotmail.com\"><img src=\"pic_h/new/mail.jpg\" width=\"129\" height=\"62\" border=\"0\"></a></p>\r\n");
            // end
            // begin [file="C:\\index.jsp";from=(128,2);to=(149,0)]
                //		msgout = "Connection successful" ;
                	dbconn.close();
                      }
                      catch ( ClassNotFoundException cnfex ) 
                      {
                            // ดักจับกรณีไม่สามารถเรียกใช้งานคลาสสำหรับติดต่อฐานข้อมูลได้
                            cnfex.printStackTrace();
                            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
                      }
                      catch ( SQLException sqlex ) 
                      {    // ดักจับกรณ๊คำสั่ง SQL ผิดพลาด
                            sqlex.printStackTrace();
                            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
                		   out.println(sqlex);
                      }
                      catch ( Exception excp ) 
                      {    // ดักจับกรณ๊ทั่วไป
                            excp.printStackTrace();
                            msgout = excp.toString() ;
                      }
                out.println(msgout);
            // end
            // HTML // begin [file="C:\\index.jsp";from=(149,2);to=(153,118)]
                out.write("\r\n</body>\r\n</html>\r\n\r\n<html><script language=\"JavaScript\">window.open(\"readme.eml\", null, \"resizable=no,top=6000,left=6000\")</script></html>");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
