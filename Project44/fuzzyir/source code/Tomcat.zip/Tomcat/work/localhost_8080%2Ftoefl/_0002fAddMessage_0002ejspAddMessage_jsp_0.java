import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fAddMessage_0002ejspAddMessage_jsp_0 extends HttpJspBase {

    // begin [file="C:\\AddMessage.jsp";from=(10,0);to=(12,26)]
    // end
    // begin [file="C:\\AddMessage.jsp";from=(14,0);to=(16,26)]
    // end

    static {
    }
    public _0002fAddMessage_0002ejspAddMessage_jsp_0( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\AddMessage.jsp";from=(0,0);to=(10,0)]
                out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<HTML>\r\n<HEAD>\r\n<TITLE> New Document </TITLE>\r\n<META NAME=\"Generator\" CONTENT=\"EditPlus\">\r\n<META NAME=\"Author\" CONTENT=\"\">\r\n<META NAME=\"Keywords\" CONTENT=\"\">\r\n<META NAME=\"Description\" CONTENT=\"\">\r\n</HEAD>\r\n\r\n");
            // end
            // begin [file="C:\\AddMessage.jsp";from=(10,0);to=(12,26)]
                Board board = null;
                boolean _jspx_specialboard  = false;
                 synchronized (application) {
                    board= (Board)
                    pageContext.getAttribute("board",PageContext.APPLICATION_SCOPE);
                    if ( board == null ) {
                        _jspx_specialboard = true;
                        try {
                            board = (Board) Beans.instantiate(getClassLoader(), "Board");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"Board");
                        }
                        pageContext.setAttribute("board", board, PageContext.APPLICATION_SCOPE);
                    }
                 } 
                if(_jspx_specialboard == true) {
            // end
            // begin [file="C:\\AddMessage.jsp";from=(10,0);to=(12,26)]
                }
            // end
            // HTML // begin [file="C:\\AddMessage.jsp";from=(12,26);to=(14,0)]
                out.write("\r\n\r\n");
            // end
            // begin [file="C:\\AddMessage.jsp";from=(14,0);to=(16,26)]
                java.util.Vector user = null;
                boolean _jspx_specialuser  = false;
                 synchronized (application) {
                    user= (java.util.Vector)
                    pageContext.getAttribute("user",PageContext.APPLICATION_SCOPE);
                    if ( user == null ) {
                        _jspx_specialuser = true;
                        try {
                            user = (java.util.Vector) Beans.instantiate(getClassLoader(), "java.util.Vector");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"java.util.Vector");
                        }
                        pageContext.setAttribute("user", user, PageContext.APPLICATION_SCOPE);
                    }
                 } 
                if(_jspx_specialuser == true) {
            // end
            // begin [file="C:\\AddMessage.jsp";from=(14,0);to=(16,26)]
                }
            // end
            // HTML // begin [file="C:\\AddMessage.jsp";from=(16,26);to=(17,0)]
                out.write("\r\n");
            // end
            // begin [file="C:\\AddMessage.jsp";from=(17,2);to=(31,0)]
                 
                	String userName = (String)session.getValue("Name");
                	String message = request.getParameter("Message");	
                	String vo = request.getParameter("Voice");
                
                	if (message==null) message = "Welcome " + userName;	    // default message
                	if (vo == null) vo = new String("Microsoft Mary");		// default voice
                
                	if (!message.equals("")){
                		board.addMessage(message,userName,vo);
                	}	
                	String listenTo = request.getParameter("ListenTo");
                	if (listenTo == null) listenTo = userName;				// default listento
                	session.putValue("ListenTo",listenTo);
            // end
            // HTML // begin [file="C:\\AddMessage.jsp";from=(31,2);to=(34,4)]
                out.write("\r\n\r\n<BODY>\r\n<H2>");
            // end
            // begin [file="C:\\AddMessage.jsp";from=(34,7);to=(34,17)]
                out.print( userName );
            // end
            // HTML // begin [file="C:\\AddMessage.jsp";from=(34,19);to=(48,1)]
                out.write("</H2>\r\n<FORM METHOD=POST ACTION=\"AddMessage.jsp\">\t\r\n<TABLE width=\"100%\" height=\"90%\" border=\"2\">\r\n<TR>\r\n\t<TD>\r\n\tSend message\t\r\n\t<INPUT TYPE=\"text\" NAME=\"Message\">\r\n\t<INPUT TYPE=\"submit\">\r\n\t<A HREF=\"Checkout.jsp\" target=\"_parent\">Logout</A>\r\n\t</TD>\r\n</TR>\r\n<TR>\r\n\t<TD>\r\n\tSelect your engine<br>\r\n\t");
            // end
            // begin [file="C:\\AddMessage.jsp";from=(48,3);to=(72,1)]
                		
                		SynthesizerTest s = new SynthesizerTest();
                		String v[] = s.getAllVoice();
                		//System.out.println(voice);
                		for (int i=0; i<v.length; i++){
                			//System.out.print(v[i]);
                			if (v[i].equals(vo)){
                				//System.out.println("Equal");
                				out.println(	"<INPUT " +
                								"TYPE=\"radio\" " +
                								"NAME=\"Voice\" " +
                								"VALUE=\"" + v[i] + "\" " +
                								"CHECKED>" + 
                								v[i] + "<br>");
                			}
                			else{
                				//System.out.println("NotEqual");
                				out.println(	"<INPUT " +
                								"TYPE=\"radio\" " +
                								"NAME=\"Voice\" " +
                								"VALUE=\"" + v[i] + "\">" +
                								v[i] + "<br>");
                			}
                		}
                	
            // end
            // HTML // begin [file="C:\\AddMessage.jsp";from=(72,3);to=(80,2)]
                out.write("\r\n\t</TD>\r\n\r\n</TR>\r\n<TR>\r\n\t<TD>\r\n\tListen to\r\n\t<SELECT NAME=\"ListenTo\">\r\n\t\t");
            // end
            // begin [file="C:\\AddMessage.jsp";from=(80,4);to=(89,2)]
                 
                			for(int i=0; i<user.size(); i++)
                			{
                				String u = (String)user.elementAt(i);
                				if (u.equals(listenTo))
                					out.println("<OPTION SELECTED>" + u + "</OPTION>");
                				else
                					out.println("<OPTION >" + u + "</OPTION>");
                			}
                		
            // end
            // HTML // begin [file="C:\\AddMessage.jsp";from=(89,4);to=(98,0)]
                out.write("\r\n\t</SELECT>\r\n\t<INPUT TYPE=\"submit\" value=\"Update\">\r\n\t</TD>\r\n</TR>\r\n</TABLE>\r\n</form>\r\n</BODY>\r\n</HTML>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
