import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fShowMessage_00031_0002ejspShowMessage1_jsp_2 extends HttpJspBase {

    // begin [file="C:\\ShowMessage1.jsp";from=(11,0);to=(13,26)]
    // end

    static {
    }
    public _0002fShowMessage_00031_0002ejspShowMessage1_jsp_2( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\ShowMessage1.jsp";from=(0,0);to=(11,0)]
                out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<HTML>\r\n<HEAD>\r\n<TITLE> New Document </TITLE>\r\n<META NAME=\"Generator\" CONTENT=\"EditPlus\">\r\n<META NAME=\"Author\" CONTENT=\"\">\r\n<META NAME=\"Keywords\" CONTENT=\"\">\r\n<META NAME=\"Description\" CONTENT=\"\">\r\n<META HTTP-EQUIV=Refresh CONTENT=\"5; URL=ShowMessage.jsp\">\r\n</HEAD>\r\n\r\n");
            // end
            // begin [file="C:\\ShowMessage1.jsp";from=(11,0);to=(13,26)]
                Board board1 = null;
                boolean _jspx_specialboard1  = false;
                 synchronized (application) {
                    board1= (Board)
                    pageContext.getAttribute("board1",PageContext.APPLICATION_SCOPE);
                    if ( board1 == null ) {
                        _jspx_specialboard1 = true;
                        try {
                            board1 = (Board) Beans.instantiate(getClassLoader(), "Board");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"Board");
                        }
                        pageContext.setAttribute("board1", board1, PageContext.APPLICATION_SCOPE);
                    }
                 } 
                if(_jspx_specialboard1 == true) {
            // end
            // begin [file="C:\\ShowMessage1.jsp";from=(11,0);to=(13,26)]
                }
            // end
            // HTML // begin [file="C:\\ShowMessage1.jsp";from=(13,26);to=(17,0)]
                out.write("\r\n\r\n<BODY>\r\n<H1>Message display here</H1>\r\n");
            // end
            // begin [file="C:\\ShowMessage1.jsp";from=(17,2);to=(42,0)]
                 
                	String listenTo = (String)session.getValue("ListenTo");	
                	String first = (String)session.getValue("First");
                	int lastIndex = board1.getNumLine() - 1;
                	String curMessage = board1.getMessage(lastIndex);
                	String user = board1.getName(lastIndex);
                	if (user.equals(listenTo) || first != null){
                		String oldMessage = (String)session.getValue("OldMessage");
                		if (oldMessage == null) oldMessage = new String("Old Message");
                		if (!curMessage.equals(oldMessage) || first != null){
                			String path = "c:\\Tomcat\\webapps\\chatroom\\";			
                			String fileWave = "chat.wav";
                			String voice = board1.getLastVoice();
                			SynthesizerTest st = new SynthesizerTest();			
                			st.setVoice(voice);
                			st.speakToFile(curMessage, path + fileWave);			
                			out.println("<bgsound src=\"" + fileWave + "\">");
                			session.putValue("OldMessage", curMessage);
                			session.removeValue("First");
                		}
                	}
                
                	for (int i=0; i<board1.getNumLine(); i++){
                		out.println("<h4>" + board1.getName(i) + " : " + board1.getMessage(i) + "</h4>"); 
                	}
            // end
            // HTML // begin [file="C:\\ShowMessage1.jsp";from=(42,2);to=(45,0)]
                out.write("\r\n</BODY>\r\n</HTML>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
