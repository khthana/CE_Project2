import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fAddUserToRoom_0002ejspAddUserToRoom_jsp_1 extends HttpJspBase {

    // begin [file="C:\\AddUserToRoom.jsp";from=(10,0);to=(12,24)]
    // end

    static {
    }
    public _0002fAddUserToRoom_0002ejspAddUserToRoom_jsp_1( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\AddUserToRoom.jsp";from=(0,0);to=(10,0)]
                out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<HTML>\r\n<HEAD>\r\n<TITLE> New Document </TITLE>\r\n<META NAME=\"Generator\" CONTENT=\"EditPlus\">\r\n<META NAME=\"Author\" CONTENT=\"\">\r\n<META NAME=\"Keywords\" CONTENT=\"\">\r\n<META NAME=\"Description\" CONTENT=\"\">\r\n</HEAD>\r\n\r\n");
            // end
            // begin [file="C:\\AddUserToRoom.jsp";from=(10,0);to=(12,24)]
                java.util.Vector user1 = null;
                boolean _jspx_specialuser1  = false;
                 synchronized (application) {
                    user1= (java.util.Vector)
                    pageContext.getAttribute("user1",PageContext.APPLICATION_SCOPE);
                    if ( user1 == null ) {
                        _jspx_specialuser1 = true;
                        try {
                            user1 = (java.util.Vector) Beans.instantiate(getClassLoader(), "java.util.Vector");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"java.util.Vector");
                        }
                        pageContext.setAttribute("user1", user1, PageContext.APPLICATION_SCOPE);
                    }
                 } 
                if(_jspx_specialuser1 == true) {
            // end
            // begin [file="C:\\AddUserToRoom.jsp";from=(10,0);to=(12,24)]
                }
            // end
            // HTML // begin [file="C:\\AddUserToRoom.jsp";from=(12,24);to=(14,0)]
                out.write("\r\n<BODY>\r\n");
            // end
            // begin [file="C:\\AddUserToRoom.jsp";from=(14,2);to=(18,0)]
                
                	String name = request.getParameter("Name");
                	session.putValue("Name",name);
                	session.putValue("ListenTo",name);	
            // end
            // HTML // begin [file="C:\\AddUserToRoom.jsp";from=(18,2);to=(24,0)]
                out.write("\r\n<h1>Select room</h1>\r\n<A HREF=\"Room1.html\">Room1</A>\r\n<A HREF=\"Room2.html\">Room2</A>\r\n</BODY>\r\n</HTML>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
