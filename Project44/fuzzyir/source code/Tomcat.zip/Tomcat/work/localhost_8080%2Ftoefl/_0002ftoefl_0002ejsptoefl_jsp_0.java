import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002ftoefl_0002ejsptoefl_jsp_0 extends HttpJspBase {


    static {
    }
    public _0002ftoefl_0002ejsptoefl_jsp_0( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\toefl.jsp";from=(0,0);to=(24,0)]
                out.write("<html>\r\n<head>\r\n<title>++TOEFL++</title>\r\n<Style>\r\na:link { Color:blue; TEXT-DECORATION: underline }\r\na:visited { Color:blue; TEXT-DECORATION: underline } \r\na:hover { Color:red; TEXT-DECORATION: underline }\r\na:active { TEXT-DECORATION: none }\r\n\r\n</Style>\r\n<LINK rel=\"stylesheet\"\r\n      href=\"fig0810.css\"\r\n      type=\"text/css\">\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=\">\r\n</head>\r\n\r\n<frameset cols=\"180,849*\" frameborder=\"YES\" border=\"1\" framespacing=\"1\" rows=\"*\" bordercolor=\"#CCCCCC\"> \r\n  <frame name=\"leftFrame\" scrolling=\"NO\" noresize src=\"menu.jsp\">\r\n  <frame name=\"mainFrame\" src=\"index.jsp\">\r\n</frameset>\r\n<noframes><body bgcolor=\"#FFFFFF\">\r\n\r\n</body></noframes>\r\n</html>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
