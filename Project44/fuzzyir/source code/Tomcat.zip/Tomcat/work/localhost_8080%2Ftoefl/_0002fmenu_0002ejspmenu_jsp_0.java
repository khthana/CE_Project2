import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fmenu_0002ejspmenu_jsp_0 extends HttpJspBase {


    static {
    }
    public _0002fmenu_0002ejspmenu_jsp_0( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=MS874");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\menu.jsp";from=(0,0);to=(13,0)]
                out.write("<html>\r\n<head>\r\n<title>menu</title>\r\n<Style>\r\na:link { Color:#ffff00; TEXT-DECORATION: none }\r\na:visited { Color:#ffff00; TEXT-DECORATION: none } \r\na:hover { Color:blue; TEXT-DECORATION: none }\r\na:active { TEXT-DECORATION: none }\r\n\r\n</Style>\r\n\r\n\r\n<body bgcolor=\"#006699\">\r\n");
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(13,51);to=(14,0)]
                out.write(" \r\n");
            // end
            // begin [file="C:\\menu.jsp";from=(14,2);to=(22,0)]
                
                	//String sec_name=(String)session.getValue("name");
                	//String sec_id=(String)session.getValue("id");
                	//String sec_surname=(String)session.getValue("surname");
                
                	//sec_id="dfsdadf";
                	//session.putValue("id",sec_id);
                	//out.println(session.getValue("id")+" ass");
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(22,2);to=(27,2)]
                out.write("\r\n<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"5\">\r\n  <tr> \r\n    <td>&nbsp;</td>\r\n  </tr>\r\n  ");
            // end
            // begin [file="C:\\menu.jsp";from=(27,4);to=(27,37)]
                if(session.getValue("id")==null){
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(27,39);to=(49,2)]
                out.write("\r\n  <form action=\"menuauten.jsp\" method=\"post\">\r\n  <tr bgcolor=\"#FF99CC\"> \r\n    <td><font color=\"#FFFF33\">Login : \r\n      <input type=\"text\" name=\"login\" size=\"9\" maxlength=\"13\">\r\n      </font></td>\r\n  </tr>\r\n  \r\n  \r\n  <tr bgcolor=\"#FF99CC\"> \r\n    <td><font color=\"#FFFF00\">Password : \r\n      <input type=\"password\" name=\"password\" size=\"5\" maxlength=\"8\">\r\n      </font></td>\r\n  </tr>\r\n  <tr bgcolor=\"#FF99CC\"> \r\n    <td> \r\n      <div align=\"right\"> \r\n        <input type=\"submit\" name=\"Submit\" value=\"Submit\">\r\n      </div>\r\n    </td>\r\n  </tr>\r\n  </form>\r\n  ");
            // end
            // begin [file="C:\\menu.jsp";from=(49,4);to=(49,10)]
                }else{
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(49,12);to=(57,37)]
                out.write("\r\n   <tr bgcolor=\"#FF99CC\"> \r\n    <td><div align=\"center\"><font color=\"#FFFF33\">Now User \r\n      </font></div></td>\r\n  </tr>\r\n  \r\n  \r\n  <tr bgcolor=\"#FF99CC\"> \r\n    <td><font color=\"#FFFF00\">Name : ");
            // end
            // begin [file="C:\\menu.jsp";from=(57,39);to=(57,77)]
                out.println(session.getValue("name"));
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(57,79);to=(62,37)]
                out.write("\r\n      </font></td>\r\n  </tr>\r\n  <tr bgcolor=\"#FF99CC\"> \r\n    <td> \r\n     <font color=\"#FFFF00\">Surname : ");
            // end
            // begin [file="C:\\menu.jsp";from=(62,39);to=(62,80)]
                out.println(session.getValue("surname"));
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(62,82);to=(66,2)]
                out.write("\r\n      </font>\r\n    </td>\r\n  </tr>\r\n  ");
            // end
            // begin [file="C:\\menu.jsp";from=(66,4);to=(66,5)]
                }
            // end
            // HTML // begin [file="C:\\menu.jsp";from=(66,7);to=(102,0)]
                out.write("\r\n  <tr> \r\n    <td>&nbsp;</td>\r\n  </tr>\r\n  <tr> \r\n    <td > </td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"index.jsp\" target=\"mainFrame\">- หน้าหลัก</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"regis.jsp\" target=\"mainFrame\">- สมัครสมาชิก</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"smark.jsp\" target=\"mainFrame\">- ดูคะแนน</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"#\">- Tutorial</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"listen_exam.jsp\" target=\"mainFrame\">- Listening</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"struc_rule.jsp\" target=\"mainFrame\">- Structure</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"read_rule.jsp\" target=\"mainFrame\">- Reading</a></td>\r\n  </tr>\r\n  <tr> \r\n    <td bgcolor=\"#0099FF\"><a href=\"logout.jsp\">- Log out</a></td>\r\n  </tr>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n</body>\r\n</html>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
