import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fShowMessage_0002ejspShowMessage_jsp_0 extends HttpJspBase {

    // begin [file="C:\\ShowMessage.jsp";from=(11,0);to=(13,26)]
    // end

    static {
    }
    public _0002fShowMessage_0002ejspShowMessage_jsp_0( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="C:\\ShowMessage.jsp";from=(0,0);to=(11,0)]
                out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<HTML>\r\n<HEAD>\r\n<TITLE> New Document </TITLE>\r\n<META NAME=\"Generator\" CONTENT=\"EditPlus\">\r\n<META NAME=\"Author\" CONTENT=\"\">\r\n<META NAME=\"Keywords\" CONTENT=\"\">\r\n<META NAME=\"Description\" CONTENT=\"\">\r\n<META HTTP-EQUIV=Refresh CONTENT=\"5; URL=ShowMessage.jsp\">\r\n</HEAD>\r\n\r\n");
            // end
            // begin [file="C:\\ShowMessage.jsp";from=(11,0);to=(13,26)]
                Board board = null;
                boolean _jspx_specialboard  = false;
                 synchronized (application) {
                    board= (Board)
                    pageContext.getAttribute("board",PageContext.APPLICATION_SCOPE);
                    if ( board == null ) {
                        _jspx_specialboard = true;
                        try {
                            board = (Board) Beans.instantiate(getClassLoader(), "Board");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"Board");
                        }
                        pageContext.setAttribute("board", board, PageContext.APPLICATION_SCOPE);
                    }
                 } 
                if(_jspx_specialboard == true) {
            // end
            // begin [file="C:\\ShowMessage.jsp";from=(11,0);to=(13,26)]
                }
            // end
            // HTML // begin [file="C:\\ShowMessage.jsp";from=(13,26);to=(17,0)]
                out.write("\r\n\r\n<BODY>\r\n<H1>Message display here</H1>\r\n");
            // end
            // begin [file="C:\\ShowMessage.jsp";from=(17,2);to=(40,0)]
                 
                	String listenTo = (String)session.getValue("ListenTo");		
                	int lastIndex = board.getNumLine() - 1;
                	String curMessage = board.getMessage(lastIndex);
                	String user = board.getName(lastIndex);
                	if (user.equals(listenTo)){
                		String oldMessage = (String)session.getValue("OldMessage");
                		if (oldMessage == null) oldMessage = new String("Old Message");
                		if (!curMessage.equals(oldMessage)){
                			String path = "c:\\Tomcat\\webapps\\chatroom\\";			
                			String fileWave = "chat.wav";
                			String voice = board.getLastVoice();
                			SynthesizerTest st = new SynthesizerTest();			
                			st.setVoice(voice);
                			st.speakToFile(curMessage, path + fileWave);			
                			out.println("<bgsound src=\"" + fileWave + "\">");
                			session.putValue("OldMessage", curMessage);
                		}
                	}
                
                	for (int i=0; i<board.getNumLine(); i++){
                		out.println("<h4>" + board.getName(i) + " : " + board.getMessage(i) + "</h4>"); 
                	}
            // end
            // HTML // begin [file="C:\\ShowMessage.jsp";from=(40,2);to=(43,0)]
                out.write("\r\n</BODY>\r\n</HTML>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
