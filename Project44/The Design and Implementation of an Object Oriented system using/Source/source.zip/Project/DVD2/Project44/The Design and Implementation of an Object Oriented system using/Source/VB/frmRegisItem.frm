VERSION 5.00
Object = "{C37EFBE6-BC76-11D2-B65D-0000F87C2780}#1.0#0"; "CACHEQUERY.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmRegisItem 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "RegisItem"
   ClientHeight    =   4125
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   6960
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4212.766
   ScaleMode       =   0  'User
   ScaleWidth      =   6924.925
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame fra_Main 
      BorderStyle     =   0  'None
      Caption         =   "fra_Main"
      Height          =   4005
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   6945
      Begin VB.CommandButton SetGrad 
         Caption         =   "SetGrad"
         Height          =   385
         Left            =   5695
         TabIndex        =   28
         Top             =   3000
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Exit 
         Caption         =   "Cancel"
         Height          =   385
         Left            =   5695
         TabIndex        =   24
         Top             =   2370
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Close 
         Caption         =   "&Close"
         Height          =   385
         Left            =   5695
         TabIndex        =   23
         Top             =   1980
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Delete 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   5695
         TabIndex        =   22
         Top             =   1500
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Save 
         Caption         =   "&Save"
         Height          =   385
         Left            =   5695
         TabIndex        =   21
         Top             =   1110
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Find 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   5695
         TabIndex        =   20
         Top             =   630
         Width           =   1095
      End
      Begin VB.CommandButton cmd__New 
         Caption         =   "&New"
         Height          =   385
         Left            =   5695
         TabIndex        =   19
         Top             =   240
         Width           =   1095
      End
      Begin VB.TextBox txtSubjectStatus 
         Height          =   318
         Left            =   1462
         TabIndex        =   18
         Text            =   "txtSubjectStatus"
         Top             =   3055
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectGrad 
         Height          =   318
         Left            =   1462
         TabIndex        =   16
         Text            =   "txtSubjectGrad"
         Top             =   2702
         Width           =   1176
      End
      Begin VB.TextBox txtSubjectUnit 
         Height          =   318
         Left            =   1462
         TabIndex        =   14
         Text            =   "txtSubjectUnit"
         Top             =   2350
         Width           =   1176
      End
      Begin VB.TextBox txtSubjectSecNo 
         Height          =   318
         Left            =   1462
         TabIndex        =   12
         Text            =   "txtSubjectSecNo"
         Top             =   1998
         Width           =   1176
      End
      Begin VB.TextBox txtSubjectYear 
         Height          =   318
         Left            =   1462
         TabIndex        =   10
         Text            =   "txtSubjectYear"
         Top             =   1645
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectTerm 
         Height          =   318
         Left            =   1462
         TabIndex        =   8
         Text            =   "txtSubjectTerm"
         Top             =   1292
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectName 
         Height          =   318
         Left            =   1462
         TabIndex        =   6
         Text            =   "txtSubjectName"
         Top             =   940
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectCode 
         Height          =   318
         Left            =   1462
         TabIndex        =   4
         Text            =   "txtSubjectCode"
         Top             =   588
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectStdCode 
         Height          =   318
         Left            =   1462
         TabIndex        =   2
         Text            =   "txtSubjectStdCode"
         Top             =   235
         Width           =   4020
      End
      Begin VB.Label lblSubjectStdCode 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectStdCode"
         Height          =   325
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label lblSubjectCode 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectCode"
         Height          =   325
         Left            =   120
         TabIndex        =   3
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label lblSubjectName 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectName"
         Height          =   325
         Left            =   120
         TabIndex        =   5
         Top             =   960
         Width           =   1215
      End
      Begin VB.Label lblSubjectTerm 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectTerm"
         Height          =   325
         Left            =   120
         TabIndex        =   7
         Top             =   1320
         Width           =   1215
      End
      Begin VB.Label lblSubjectYear 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectYear"
         Height          =   325
         Left            =   120
         TabIndex        =   9
         Top             =   1680
         Width           =   1215
      End
      Begin VB.Label lblSubjectSecNo 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectSecNo"
         Height          =   325
         Left            =   120
         TabIndex        =   11
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label lblSubjectUnit 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectUnit"
         Height          =   325
         Left            =   120
         TabIndex        =   13
         Top             =   2400
         Width           =   1215
      End
      Begin VB.Label lblSubjectGrad 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectGrad"
         Height          =   325
         Left            =   120
         TabIndex        =   15
         Top             =   2760
         Width           =   1215
      End
      Begin VB.Label lblSubjectStatus 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectStatus"
         Height          =   325
         Left            =   120
         TabIndex        =   17
         Top             =   3120
         Width           =   1215
      End
   End
   Begin VB.PictureBox picPatch 
      BorderStyle     =   0  'None
      Height          =   250
      Left            =   0
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   27
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.VScrollBar VSCroll 
      Height          =   1175
      LargeChange     =   24
      Left            =   6945
      TabIndex        =   26
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.HScrollBar HSCroll 
      Height          =   250
      LargeChange     =   24
      Left            =   0
      TabIndex        =   25
      Top             =   4080
      Visible         =   0   'False
      Width           =   1206
   End
   Begin CACHEQUERYLib.CacheQuery CacheQuery1 
      Left            =   2865
      Top             =   1515
      _Version        =   65536
      _ExtentX        =   847
      _ExtentY        =   847
      _StockProps     =   0
      ClassName       =   ""
      QueryName       =   ""
   End
   Begin MSComDlg.CommonDialog dlgCommon 
      Left            =   2865
      Top             =   1515
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuObject 
      Caption         =   "&Object"
      Begin VB.Menu mnu__New 
         Caption         =   "&New"
      End
      Begin VB.Menu mnu__Find 
         Caption         =   "&Find..."
      End
      Begin VB.Menu mnu__Bar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Save 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnu__Delete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnu__Close 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnu__Bar2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Exit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "frmRegisItem"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const m_classname = "Registration.RegisItem"

Private m_Factory As Object
Private m_object As Object
Private m_modified As Boolean
Private m_WaitFlag As Integer
Private id As Variant
Private disableclick As Boolean

Private Sub cmd__Close_Click()
    actionClose

End Sub

Private Sub cmd__Delete_Click()
    actionDelete

End Sub

Private Sub cmd__Exit_Click()
    actionExit

End Sub

Private Sub cmd__Find_Click()
    actionFind

End Sub

Private Sub cmd__New_Click()
    actionNew

End Sub

Private Sub cmd__Save_Click()
    actionSave

End Sub

Private Sub Form_Load()
    Dim sdir As String
    actionClose
    Set m_Factory = CacheForm.Factory
'    sdir = m_factory.ConnectDlg
'    If sdir <> "" Then
'        m_factory.connect sdir
'    Else
'        End
'    End If
End Sub

Private Sub Form_Resize()
picPatch.Visible = False
If Me.ScaleWidth < fra_Main.Width Then
    HSCroll.Top = Me.ScaleHeight - HSCroll.Height
    HSCroll.Width = Me.ScaleWidth
    HSCroll.max = (fra_Main.Width - Me.ScaleWidth) \ 15
    HSCroll.Visible = True
    HSCroll.ZOrder
    If Me.ScaleHeight - HSCroll.Height < fra_Main.Height Then
        HSCroll.Width = Me.ScaleWidth - VSCroll.Width
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight - HSCroll.Height
        HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        picPatch.Top = HSCroll.Top
        picPatch.Left = HSCroll.Width
        picPatch.Visible = True
        picPatch.ZOrder
    Else
        VSCroll.Visible = False
    End If
Else
   HSCroll.Visible = False
    If Me.ScaleHeight < fra_Main.Height Then
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        If Me.ScaleWidth - VSCroll.Width < fra_Main.Width Then
            VSCroll.Height = Me.ScaleHeight - HSCroll.Height
            HSCroll.Top = Me.ScaleHeight - HSCroll.Height
            HSCroll.Width = Me.ScaleWidth - VSCroll.Width
            VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
            HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
            HSCroll.Visible = True
            HSCroll.ZOrder
            picPatch.Top = HSCroll.Top
            picPatch.Left = HSCroll.Width
            picPatch.Visible = True
            picPatch.ZOrder
        End If
    Else
        VSCroll.Visible = False
    End If
End If
End Sub

Private Sub HScroll_Change()
    fra_Main.Left = -HSCroll.Value * 15
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

Private Sub mnu__Close_Click()
    actionClose

End Sub

Private Sub mnu__Delete_Click()
    actionDelete

End Sub

Private Sub mnu__Exit_Click()
    actionExit

End Sub

Private Sub mnu__Find_Click()
    actionFind

End Sub

Private Sub mnu__New_Click()
    actionNew

End Sub

Private Sub mnu__Save_Click()
    actionSave

End Sub

Private Sub SetGrad_Click()
    'm_object.SetGrad (txtSubjectGrad.Text)
    txtSubjectStatus.Text = "Pass"
    m_modified = True
End Sub

Private Sub txtSubjectCode_Change()
    m_modified = True

End Sub

Private Sub txtSubjectGrad_Change()
    m_modified = True

End Sub

Private Sub txtSubjectName_Change()
    m_modified = True

End Sub

Private Sub txtSubjectSecNo_Change()
    m_modified = True

End Sub

Private Sub txtSubjectStatus_Change()
    m_modified = True

End Sub

Private Sub txtSubjectStdCode_Change()
    m_modified = True

End Sub

Private Sub txtSubjectTerm_Change()
    m_modified = True

End Sub

Private Sub txtSubjectUnit_Change()
    m_modified = True

End Sub

Private Sub txtSubjectYear_Change()
    m_modified = True

End Sub

Private Sub VScroll_Change()
    fra_Main.Top = -VSCroll.Value * 15
End Sub

Private Sub VScroll_Scroll()
    VScroll_Change
End Sub

Private Sub actionNew()
    actionClose
    Set m_object = m_Factory.New(m_classname)
    If m_object Is Nothing Then
         MsgBox "Cannot create new object."
         actionClose
    Else
         EnableScreen True
         SyncObjectToScreen
         m_modified = True
         cmd__Delete.Enabled = False
         mnu__Delete.Enabled = False
    End If
End Sub

Private Sub actionFind()
    actionClose
    Set CacheQuery1.Factory = m_Factory
    CacheQuery1.ClassName = m_classname
    id = CacheQuery1.FindId
    If id = "" Then Exit Sub
    Set m_object = m_Factory.OpenId(m_classname, id)
    If m_object Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableScreen True
        SyncObjectToScreen
        m_modified = False
    End If
End Sub

Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDelete()
    If id = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObject
    On Error GoTo actionDeleteError
    BeginWait
    m_object.sys_DeleteId (id)
    actionClose
    EndWait
    m_modified = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_object Is Nothing Then
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    id = ""
    m_modified = False
End Sub

Private Sub actionExit()
    actionClose
    Unload Me
End Sub

Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

Private Function minmax(val As Long, min As Long, max As Long)
    minmax = val
    If min <> -1 And val < min Then minmax = min
    If max <> -1 And val > max Then minmax = max
End Function

Public Sub ListView_ColumnClick(hList As ListView, ByVal ColumnHeader As MSComctlLib.ColumnHeader)
    'Handle any listview
    If hList.Sorted = False Then
       hList.Sorted = True
       hList.SortKey = ColumnHeader.Index - 1
       hList.SortOrder = lvwAscending
       Exit Sub
    End If
    If hList.SortKey = (ColumnHeader.Index - 1) Then
        If hList.SortOrder = lvwAscending Then
            hList.SortOrder = lvwDescending
        Else
            hList.SortOrder = lvwAscending
        End If
    Else
        hList.SortKey = ColumnHeader.Index - 1
    End If
End Sub
Private Sub EnableScreen(Enabled As Boolean)
    lblSubjectStdCode.Enabled = Enabled
    txtSubjectStdCode.Enabled = Enabled
    lblSubjectCode.Enabled = Enabled
    txtSubjectCode.Enabled = Enabled
    lblSubjectName.Enabled = Enabled
    txtSubjectName.Enabled = Enabled
    lblSubjectTerm.Enabled = Enabled
    txtSubjectTerm.Enabled = Enabled
    lblSubjectYear.Enabled = Enabled
    txtSubjectYear.Enabled = Enabled
    lblSubjectSecNo.Enabled = Enabled
    txtSubjectSecNo.Enabled = Enabled
    lblSubjectUnit.Enabled = Enabled
    txtSubjectUnit.Enabled = Enabled
    lblSubjectGrad.Enabled = Enabled
    txtSubjectGrad.Enabled = Enabled
    lblSubjectStatus.Enabled = Enabled
    txtSubjectStatus.Enabled = Enabled
    SetGrad.Enabled = Enabled
    mnu__Save.Enabled = Enabled
    mnu__Close.Enabled = Enabled
    mnu__Delete.Enabled = Enabled
    cmd__Save.Enabled = Enabled
    cmd__Close.Enabled = Enabled
    cmd__Delete.Enabled = Enabled
End Sub

Private Sub EraseScreen()
    txtSubjectStdCode.Text = ""
    txtSubjectCode.Text = ""
    txtSubjectName.Text = ""
    txtSubjectTerm.Text = ""
    txtSubjectYear.Text = ""
    txtSubjectSecNo.Text = ""
    txtSubjectUnit.Text = ""
    txtSubjectGrad.Text = ""
    txtSubjectStatus.Text = ""
End Sub

Private Sub SyncObjectToScreen()
    Dim obj As Object
    Dim i As Integer
    Dim Item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtSubjectStdCode.Text = m_object.SubjectStdCode
    txtSubjectCode.Text = m_object.SubjectCode
    txtSubjectName.Text = m_object.SubjectName
    txtSubjectTerm.Text = m_object.SubjectTerm
    txtSubjectYear.Text = m_object.SubjectYear
    txtSubjectSecNo.Text = m_object.SubjectSecNo
    txtSubjectUnit.Text = m_object.SubjectUnit
    txtSubjectGrad.Text = m_object.SubjectGrad
    txtSubjectStatus.Text = m_object.SubjectStatus
End Sub

Private Sub SyncScreenToObject()
    m_object.SubjectStdCode = txtSubjectStdCode.Text
    m_object.SubjectCode = txtSubjectCode.Text
    m_object.SubjectName = txtSubjectName.Text
    m_object.SubjectTerm = txtSubjectTerm.Text
    m_object.SubjectYear = txtSubjectYear.Text
    m_object.SubjectSecNo = txtSubjectSecNo.Text
    m_object.SubjectUnit = txtSubjectUnit.Text
    m_object.SubjectGrad = txtSubjectGrad.Text
    m_object.SubjectStatus = txtSubjectStatus.Text
End Sub

