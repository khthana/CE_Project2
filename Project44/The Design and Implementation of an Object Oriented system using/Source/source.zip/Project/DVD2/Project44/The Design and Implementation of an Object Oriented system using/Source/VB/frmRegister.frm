VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.Form frmRegister 
   Caption         =   "RegistrationForm"
   ClientHeight    =   7128
   ClientLeft      =   4152
   ClientTop       =   2772
   ClientWidth     =   7536
   LinkTopic       =   "Form1"
   ScaleHeight     =   7128
   ScaleWidth      =   7536
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtRegSub 
      Height          =   330
      Left            =   480
      TabIndex        =   12
      Top             =   5760
      Width           =   3135
   End
   Begin VB.TextBox TextFaculty 
      Height          =   330
      Left            =   3840
      TabIndex        =   11
      Text            =   "Text4"
      Top             =   1920
      Width           =   2655
   End
   Begin VB.TextBox TextDepartment 
      Height          =   330
      Left            =   480
      TabIndex        =   10
      Text            =   "Text3"
      Top             =   1920
      Width           =   2655
   End
   Begin VB.TextBox TextStudentSurname 
      Height          =   330
      Left            =   3840
      TabIndex        =   9
      Text            =   "Text2"
      Top             =   1200
      Width           =   2655
   End
   Begin VB.TextBox TextStudentName 
      Height          =   330
      Left            =   480
      TabIndex        =   8
      Text            =   "Text1"
      Top             =   1200
      Width           =   2655
   End
   Begin VB.CommandButton cmdCancelReg 
      Caption         =   "OK"
      Height          =   495
      Left            =   4800
      TabIndex        =   7
      Top             =   6240
      Width           =   1215
   End
   Begin VB.CommandButton cmdSubject 
      Caption         =   "FindSubject"
      Height          =   495
      Left            =   3240
      TabIndex        =   6
      Top             =   6240
      Width           =   1215
   End
   Begin VB.CommandButton cmdDeleteItem 
      Caption         =   "Delete"
      Height          =   495
      Left            =   1800
      TabIndex        =   5
      Top             =   6240
      Width           =   1215
   End
   Begin VB.CommandButton cmdRegister 
      Caption         =   "Register"
      Height          =   495
      Left            =   360
      TabIndex        =   4
      Top             =   6240
      Width           =   1215
   End
   Begin VB.ComboBox ComboYear 
      Height          =   330
      Left            =   5400
      TabIndex        =   3
      Text            =   "Combo2"
      Top             =   480
      Width           =   1455
   End
   Begin VB.ComboBox ComboTerm 
      Height          =   330
      Left            =   3840
      TabIndex        =   2
      Text            =   "Combo1"
      Top             =   480
      Width           =   1335
   End
   Begin VB.TextBox TextStudentcode 
      Height          =   330
      Left            =   480
      TabIndex        =   1
      Text            =   "Text1"
      Top             =   480
      Width           =   2655
   End
   Begin MSComctlLib.ListView ListViewSubject 
      Height          =   2775
      Left            =   480
      TabIndex        =   0
      Top             =   2760
      Width           =   6375
      _ExtentX        =   11240
      _ExtentY        =   4890
      View            =   3
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   4
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "SubjectCode"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "SubjectName"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Text            =   "Unit"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   3
         Text            =   "Section"
         Object.Width           =   2540
      EndProperty
   End
   Begin VB.Label Label7 
      Caption         =   "Faculty"
      Height          =   255
      Left            =   3840
      TabIndex        =   19
      Top             =   1680
      Width           =   1335
   End
   Begin VB.Label Label6 
      Caption         =   "Department"
      Height          =   375
      Left            =   480
      TabIndex        =   18
      Top             =   1680
      Width           =   1095
   End
   Begin VB.Label Label5 
      Caption         =   "Surname"
      Height          =   375
      Left            =   3840
      TabIndex        =   17
      Top             =   960
      Width           =   1215
   End
   Begin VB.Label Label4 
      Caption         =   "StudentName"
      Height          =   375
      Left            =   480
      TabIndex        =   16
      Top             =   960
      Width           =   1215
   End
   Begin VB.Label Label3 
      Caption         =   "Year"
      Height          =   375
      Left            =   5400
      TabIndex        =   15
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label Label2 
      Caption         =   "Term"
      Height          =   255
      Left            =   3840
      TabIndex        =   14
      Top             =   240
      Width           =   975
   End
   Begin VB.Label Label1 
      Caption         =   "Code"
      Height          =   255
      Left            =   480
      TabIndex        =   13
      Top             =   240
      Width           =   1335
   End
End
Attribute VB_Name = "frmRegister"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private m_object As Object
Private m_modified As Boolean

Private Sub cmdCancelReg_Click()
 If m_object Is Nothing Then
 
 Else
    m_object.SYS_Close
 End If
  

Unload Me
End Sub

Private Sub cmdDeleteItem_Click()
    Dim dd As Boolean
    Dim ii As Integer
    m_modified = True
    ii = ListViewSubject.SelectedItem.Index
    If (ii > ListViewSubject.ListItems.Count) Then Exit Sub
    ListViewSubject.ListItems.Remove (ii)
    ListViewSubject.Refresh
    ii = ListViewSubject.ListItems.Count
    If (ii <= 0) Then
        cmdDeleteItem.Enabled = False
    End If
End Sub
Private Sub cmdLookup_Click()
   Dim objectID As Long
   objectID = val(frmLookup.Lookup(CacheForm.Factory, "Registration.StudentRegistrationHistory", "ByCode", _
      "Select Subject", , , True, 2, TextStudentcode.Text))
   If objectID = 0 Then Exit Sub
    Set m_object = CacheForm.Factory.OpenId("Registration.StudentRegistrationHistory", objectID)
   If m_object Is Nothing Then
       MsgBox "Can not open object."
       actionClose
   Else
       EnableScreen True
       SyncObjectToScreen
       m_modified = False
   End If
End Sub

Private Sub cmdRegister_Click()
    Dim num, Index As Integer
    Dim ff As Boolean
    Dim ls As ListItem
    num = ListViewSubject.ListItems.Count
    Index = 1
    While Index <= num
        Set ls = ListViewSubject.ListItems.Item(Index)
        ff = m_object.AddSubject(ls.Text, ComboTerm.Text, ComboYear.Text, ls.SubItems(3))
        If ff = False Then
            MsgBox ls.Text + " can't regist", vbOKOnly
            ListViewSubject.ListItems.Remove (Index)
            Index = Index - 1
            num = num - 1
        End If
        Index = Index + 1
    Wend
'    num = m_object.GetNumSub(ComboTerm.Text, ComboYear.Text)
'    If num > 0 Then
'    ff = m_object.ChangeSubject("10000003", "10000001", ComboTerm.Text, ComboYear.Text, 1)
'    End If
    ListViewSubject.Enabled = False
    cmdRegister.Enabled = False
    cmdSubject.Enabled = False
    txtRegSub.Enabled = False
    cmdDeleteItem.Enabled = False
End Sub

Private Sub cmdSubject_Click()
Dim objectID As Long
        objectID = val(frmLookup.Lookup(CacheForm.Factory, "Curriculum.SubjectItem", "All", _
        "Select Subject", , , True, 2, txtRegSub.Text))
        If objectID = 0 Then Exit Sub
       ' If Not (m_object Is Nothing) Then m_object.SYS_Close
        Set myobject = CacheForm.Factory.OpenId("Curriculum.SubjectItem", objectID)
        If myobject Is Nothing Then
            MsgBox "Can not open object."
        Else
            Dim Listt As ListItem
            ListViewSubject.FullRowSelect = True
            Set Listt = ListViewSubject.ListItems.Add(, , myobject.SubjectCode)
            Listt.SubItems(1) = myobject.SubjectName
            Listt.SubItems(2) = Format(myobject.TheoryUnit + myobject.LabUnit)
            Listt.SubItems(3) = 1
            myobject.SYS_Close
            m_modified = True
            cmdDeleteItem.Enabled = True
        End If
End Sub


Private Sub Form_Load()
    ComboYear.AddItem ("2545")
    ComboYear.AddItem ("2544")
    ComboYear.AddItem ("2543")
    ComboYear.AddItem ("2542")
    ComboTerm.AddItem ("1")
    ComboTerm.AddItem ("2")
    ComboTerm.Text = "1"
    ComboYear.Text = "2545"
    TextStudentcode.Text = ""
    EraseScreen
    EnableScreen False
End Sub
Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_object Is Nothing Then
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    m_modified = False
End Sub

Private Sub SyncObjectToScreen()
    TextStudentcode.Text = m_object.StdCode
    TextStudentName.Text = m_object.StdName
    TextStudentSurname.Text = m_object.StdSurname
    TextDepartment.Text = m_object.MajorName
    TextFaculty.Text = m_object.Faculty
 End Sub

Private Sub SyncScreenToObject()
    m_object.StdCode = TextStudentcode.Text
    m_object.StdName = TextStudentName.Text
    m_object.StdSurname = TextStudentSurname.Text
    m_object.MajorName = TextDepartment.Text
    m_object.Faculty = TextFaculty.Text
End Sub

Private Sub EraseScreen()
    TextStudentcode.Text = ""
    TextFaculty.Text = ""
    TextStudentName.Text = ""
    TextStudentSurname.Text = ""
    TextDepartment.Text = ""
End Sub

Private Sub EnableScreen(Enabled As Boolean)
    TextStudentcode.Enabled = True
    TextFaculty.Enabled = False
    TextStudentName.Enabled = False
    TextStudentSurname.Enabled = False
    TextDepartment.Enabled = False
    txtRegSub.Enabled = Enabled
    Label1.Enabled = True
    Label2.Enabled = Enabled
    Label3.Enabled = Enabled
    Label4.Enabled = False
    Label5.Enabled = False
    Label6.Enabled = False
    Label7.Enabled = False
    ComboTerm.Enabled = Enabled
    ComboYear.Enabled = Enabled
    cmdRegister.Enabled = Enabled
    cmdDeleteItem.Enabled = Enabled
End Sub

Private Sub TextStudentcode_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = 13 Then
        cmdLookup_Click
        cmdDeleteItem.Enabled = False
       Dim num As Integer
        num = ListViewSubject.ListItems.Count
        While num > 0
            ListViewSubject.ListItems.Remove (num)
            num = ListViewSubject.ListItems.Count
        Wend
     End If
End Sub
Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub


Private Sub txtRegSub_KeyDown(KeyCode As Integer, Shift As Integer)
   Dim objectID As Long
   Dim myobject As Object
   If KeyCode = 13 Then
        objectID = val(frmLookup.Lookup(CacheForm.Factory, "Curriculum.SubjectItem", "All", _
        "Select Subject", , , True, 2, txtRegSub.Text))
        If objectID = 0 Then Exit Sub
        Set myobject = CacheForm.Factory.OpenId("Curriculum.SubjectItem", objectID)
        If myobject Is Nothing Then
            MsgBox "Can not open object."
        Else
            Dim Listt As ListItem
            ListViewSubject.FullRowSelect = True
            Set Listt = ListViewSubject.ListItems.Add(, , myobject.SubjectCode)
            Listt.SubItems(1) = myobject.SubjectName
            Listt.SubItems(2) = Format(myobject.TheoryUnit + myobject.LabUnit)
            Listt.SubItems(3) = 1
            myobject.SYS_Close
            m_modified = True
            cmdDeleteItem.Enabled = True
        End If
    End If
End Sub
