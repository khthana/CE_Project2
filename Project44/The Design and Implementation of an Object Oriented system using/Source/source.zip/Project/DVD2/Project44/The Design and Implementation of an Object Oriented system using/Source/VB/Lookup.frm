VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmLookup 
   Caption         =   "Lookup"
   ClientHeight    =   8505
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8055
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   8505
   ScaleMode       =   0  'User
   ScaleWidth      =   8055
   StartUpPosition =   1  'CenterOwner
   Begin VB.PictureBox Picture1 
      Align           =   2  'Align Bottom
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   615
      Left            =   0
      ScaleHeight     =   615
      ScaleWidth      =   8055
      TabIndex        =   21
      Top             =   7890
      Width           =   8055
      Begin VB.CommandButton cmdCancel 
         Caption         =   "Cancel"
         Height          =   375
         Left            =   5400
         TabIndex        =   24
         Top             =   120
         Width           =   1095
      End
      Begin VB.CommandButton cmdMore 
         Caption         =   "More"
         Height          =   375
         Left            =   3120
         TabIndex        =   23
         Top             =   120
         Width           =   1095
      End
      Begin VB.CommandButton cmdSelect 
         Caption         =   "Select"
         Height          =   375
         Left            =   840
         TabIndex        =   22
         Top             =   120
         Width           =   1095
      End
   End
   Begin VB.Frame Frame1 
      Height          =   5175
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   7455
      Begin MSComctlLib.ListView ListView1 
         Height          =   2655
         Left            =   120
         TabIndex        =   20
         TabStop         =   0   'False
         Top             =   2040
         Width           =   7215
         _ExtentX        =   12726
         _ExtentY        =   4683
         View            =   3
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   0
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   8
         Left            =   4920
         TabIndex        =   9
         Top             =   1680
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   7
         Left            =   2520
         TabIndex        =   8
         Top             =   1680
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   6
         Left            =   120
         TabIndex        =   7
         Top             =   1680
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   5
         Left            =   4920
         TabIndex        =   6
         Top             =   1080
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   4
         Left            =   2520
         TabIndex        =   5
         Top             =   1080
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   3
         Left            =   120
         TabIndex        =   4
         Top             =   1080
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   2
         Left            =   4920
         TabIndex        =   3
         Top             =   480
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   1
         Left            =   2520
         TabIndex        =   2
         Top             =   480
         Width           =   2295
      End
      Begin VB.TextBox txtParam 
         Height          =   285
         Index           =   0
         Left            =   120
         TabIndex        =   1
         Top             =   480
         Width           =   2295
      End
      Begin VB.Label Label 
         Caption         =   "Label8"
         Height          =   255
         Index           =   8
         Left            =   4920
         TabIndex        =   19
         Top             =   1440
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label7"
         Height          =   255
         Index           =   7
         Left            =   2520
         TabIndex        =   18
         Top             =   1440
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label6"
         Height          =   255
         Index           =   6
         Left            =   120
         TabIndex        =   17
         Top             =   1440
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label5"
         Height          =   255
         Index           =   5
         Left            =   4920
         TabIndex        =   16
         Top             =   840
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label4"
         Height          =   255
         Index           =   4
         Left            =   2520
         TabIndex        =   15
         Top             =   840
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label3"
         Height          =   255
         Index           =   3
         Left            =   120
         TabIndex        =   14
         Top             =   840
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label2"
         Height          =   255
         Index           =   2
         Left            =   4920
         TabIndex        =   13
         Top             =   240
         Width           =   2175
      End
      Begin VB.Label Label 
         Caption         =   "Label1"
         Height          =   255
         Index           =   1
         Left            =   2520
         TabIndex        =   12
         Top             =   240
         Width           =   2175
      End
      Begin VB.Label lblRecords 
         Caption         =   "nnnn records found"
         Height          =   255
         Left            =   2640
         TabIndex        =   11
         Top             =   4800
         Width           =   1695
      End
      Begin VB.Label Label 
         Caption         =   "Label0"
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   10
         Top             =   240
         Width           =   2175
      End
   End
End
Attribute VB_Name = "frmLookup"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private m_Factory As cacheobject.Factory
Private ClassName As String, QueryName As String, FormTitle As String
Private result As cacheobject.ResultSet
Private maxrows As Integer ' max number of rows to fetch in one chunk(100)
Private morebuttonrequested As Boolean
Private auto As Boolean

Private SelectedId As String ' selected Id or ""
Private par(8) As String ' 9 params, 0-8
Private quiet As Boolean ' don't react while loading
Private numrows As Long ' how many rows do we have in the grid now
Private moretofetch As Boolean ' more rows to fetch ?
Private IDs() As String ' array of object IDs
Private IdCol As Integer ' which column has the ID ?
Private ColWidths() As Long ' max width of each column
Private paramcount As Integer ' how many params
Private numprows As Integer ' how many rows of params
Public Function Lookup(Factory As cacheobject.Factory, _
                        class As String, _
                        Query As String, _
                        Optional Title As String, _
                        Optional Maxitems As Long, _
                        Optional MoreButton As Boolean, _
                        Optional AutoSelect As Boolean, _
                        Optional MsgBoxIfNone As Integer, _
                        Optional P1 As String, _
                        Optional P2 As String, _
                        Optional P3 As String, _
                        Optional P4 As String, _
                        Optional P5 As String, _
                        Optional P6 As String, _
                        Optional P7 As String, _
                        Optional P8 As String, _
                        Optional P9 As String) As String
    ' This function provides a general-purpose lookup window, based on a
    '  object class query.
    ' It returns the ID of the selected object, or "" if none selected
    ' Parameters :
    '   Factory         Mandatory CacheObject factory object, connected
    '   class           Mandatory Name of the class for the query
    '   query           Mandatory Name of the query within the class
    '   Title           Optional title for the window, default "Lookup"
    '   Maxitems        Optional maximum number of items to fetech, default 100
    '   MoreButton      Optional flag if a 'More' button is required if more than
    '                       Maxitems records found.  If button is pressed, another
    '                       Maxitems will be fetched and added to the display,
    '                       default 'False'
    '   AutoSelect      Optional flag if the function should auto-select (without
    '                       displaying the window) if exactly one record matches
    '                       the criteria, default 'False'
    '   MsgBoxIfNone    Optional flag if the function should display a msgbox
    '                       if no records match, or just return a null Id.
    '                       0 = just returns ""
    '                       1 = display msgbox then returns ""
    '                       2 = just display empty grid
    '                       Default 0 = just return ""
    '   P1              Starting value for first parameter, default ""
    '   P2              Starting value for second parameter, default ""
    '   P3              Starting value for third parameter, default ""
    '   P4              Starting value for fourth parameter, default ""
    '   P5              Starting value for fifth parameter, default ""
    '   P6              Starting value for sixth parameter, default ""
    '   P7              Starting value for seventh parameter, default ""
    '   P8              Starting value for eigth parameter, default ""
    '   P9              Starting value for ninth parameter, default ""
    
    Set m_Factory = Factory
    ClassName = class
    QueryName = Query
    FormTitle = Title
    If Maxitems = 0 Then
        maxrows = 100
    Else
        maxrows = Maxitems
    End If
    morebuttonrequested = MoreButton
    auto = AutoSelect
    
    par(0) = P1
    par(1) = P2
    par(2) = P3
    par(3) = P4
    par(4) = P5
    par(5) = P6
    par(6) = P7
    par(7) = P8
    par(8) = P9
    
    numrows = 0
    
    Set result = m_Factory.ResultSet(ClassName, QueryName)
    result.Execute P1, P2, P3, P4, P5, P6, P7, P8, P9
    
    Me.Visible = False ' Form_Load - invisibly !!!
    
    Dim rowcount As Long
    rowcount = ListView1.ListItems.count
    If rowcount = 0 Then
        If MsgBoxIfNone = 0 Then
            SelectedId = ""
        End If
        If MsgBoxIfNone = 1 Then
            MsgBox "No Matching Records Found"
            SelectedId = ""
        End If
        If MsgBoxIfNone = 2 Then
            Me.Show vbModal ' display empty grid
        End If
    Else
        If rowcount = 1 And auto Then
            SelectedId = IDs(1)
        Else
            Me.Show vbModal ' Form_Activate
        End If
    End If
    
    Set m_Factory = Nothing
    result.Close
    Set result = Nothing
        
    ' return "" for Cancel; Id for Select
    Lookup = SelectedId
    Unload Me
    
End Function
Private Sub Form_Load()
    
    If FormTitle <> "" Then Me.Caption = FormTitle
    
    quiet = True
    SetUpParams
    LoadGridHeaders
    LoadGrid
    quiet = False
    
End Sub
Private Sub form_activate()
    cmdCancel.SetFocus
    If txtParam(6).Visible Then txtParam(6).SetFocus
    If txtParam(3).Visible Then txtParam(3).SetFocus
    If txtParam(0).Visible Then txtParam(0).SetFocus
End Sub
Private Sub SetUpParams()
    ' Get list of params for the query and put them
    ' into the text boxes.

    Dim i As Integer
    
    paramcount = result.GetParamCount
    
    For i = 0 To 8
        Label(i).Visible = paramcount > i
        txtParam(i).Visible = paramcount > i
        If paramcount > i Then
            Label(i).Caption = result.GetParamName(i + 1)
            txtParam(i).Text = par(i)
            txtParam(i).SelStart = Len(par(i))
        End If
    Next i
    
    If paramcount = 0 Then          ' no params
        numprows = 0
    ElseIf paramcount < 4 Then      ' 1 row
        numprows = 1
    ElseIf paramcount < 7 Then      ' 2 rows
        numprows = 2
    Else                            ' 3 rows
        numprows = 3
    End If
    
End Sub
Private Sub LoadGridHeaders()
' load column headers for grid based on query
    
    ListView1.ColumnHeaders.Clear
    ListView1.ListItems.Clear

    Dim rescol As Integer ' index to Getdata
    Dim col As Integer ' index to Colwidths and Grid
    Dim item As ListItem
    Dim colhdr As String
    
    ReDim ColWidths(result.GetColumnCount) As Long ' one extra in case ID missing !
    
    IdCol = result.ContainsID ' which column has ID, if any
    
    ' Set up columns
    col = 0
    For rescol = 1 To result.GetColumnCount
        If rescol <> IdCol Then
            col = col + 1
            colhdr = result.GetColumnHeader(rescol)
            ColWidths(col) = Me.TextWidth(colhdr)
            ListView1.ColumnHeaders.Add , , colhdr, ColWidths(col)
            If col > 1 Then ListView1.ColumnHeaders.item(col).Alignment = lvwColumnCenter
        End If
    Next rescol

End Sub
Private Sub LoadGrid()

    Dim itemcount As Long
    
    Screen.MousePointer = vbHourglass
    
    ' if numrows=0 then this is the first time
    If numrows = 0 Then
        ListView1.ListItems.Clear
        numrows = maxrows
        ReDim IDs(numrows) As String
        itemcount = 0
        
    ' else it is a subsequent call - note that the first record of this chunk
    '  has aleady been 'read'
    Else
        numrows = numrows + maxrows
        ReDim Preserve IDs(numrows) As String
        itemcount = 1
        AddItem
    End If
    
    moretofetch = True
    For itemcount = itemcount + 1 To maxrows
        If result.Next Then
            AddItem
        Else
            moretofetch = False
            Exit For
        End If
    Next itemcount
    If moretofetch And Not result.Next Then moretofetch = False ' probe one record forward
    
    ' display record count
    If moretofetch Then
        lblRecords = ">" & ListView1.ListItems.count & " records found"
    Else
        ' break it down for language translation !
        If ListView1.ListItems.count = 0 Then
            lblRecords = "No records found"
        ElseIf ListView1.ListItems.count = 1 Then
            lblRecords = "1 record found"
        Else
            lblRecords = ListView1.ListItems.count & " records found"
        End If
    End If
    
    ' deselect all
    Set ListView1.selecteditem = Nothing
    
    ' display More button if requested
    If moretofetch And morebuttonrequested Then
        cmdMore.Visible = True
    Else
        cmdMore.Visible = False
    End If
    
    ' disable Select button and change Cancel to OK if no IDCol provided
    If IdCol = 0 Then
        cmdSelect.Visible = False
        cmdCancel.Caption = "OK"
    End If
    
    Screen.MousePointer = vbDefault
    
End Sub
Private Sub AddItem()
    ' read data from query; store id's in data slot
    
    Dim item As ListItem
    Dim colvalue As String
    Dim colwidth As Long
    Dim rescol As Integer ' index to Getdata()
    Dim col As Integer ' index to Grid()
    
    
    ' Very confusing numbering (e.g.) :
    '                       ID      Name    Sex     DOB     SSN
    '   GetData(rescol)      1        2      3       4       5
    '   col                           1      2       3       4
    '   index (of item)               1      2       3       4
    '   subitem                              1       2       3
    ' Or
    '                       Name     Sex    ID     DOB     SSN
    '   GetData(rescol)      1        2      3       4       5
    '   col                  1        2              3       4
    '   index (of item)      1        2              3       4
    '   subitem                       1              2       3
    
    
    Set item = ListView1.ListItems.Add
        
    If IdCol Then
        IDs(ListView1.ListItems.count) = result.GetData(IdCol) ' save ID for later
    End If
    
    col = 0
    For rescol = 1 To result.GetColumnCount
        If rescol <> IdCol Then
            col = col + 1
            colvalue = result.GetData(rescol)
            colwidth = Me.TextWidth(colvalue)
            If colwidth < 700 Then colwidth = 700 ' min 700 pixels
            If colwidth > 1500 Then colwidth = 1500 ' max 30 chars
            If colwidth > ColWidths(col) Then
                ColWidths(col) = colwidth
                ListView1.ColumnHeaders.item(col).Width = colwidth
            End If
        
            ' first field goes into .Text
            If col = 1 Then
                item.Text = colvalue
            ' rest into .SubItems
            Else
                item.SubItems(col - 1) = colvalue
            End If
            
        End If
    Next rescol

End Sub
Private Sub AdjustSizes()
    ' subroutine to adjust the format of the lookup according to the data
    '  and the size of the form
    
    On Error Resume Next ' in case anything goes negative
    
    ' First the heights.
    '  The form is made up of
    '     - a gap (frame1.top)
    '     - the frame
    '     - a gap (= frame1.top)
    '     - the picture (bottom-aligned) for the buttons (picture1.height)
    ' Adjust the frame height to match the space left
    Frame1.Height = Me.ScaleHeight - Frame1.Top - Frame1.Top - Picture1.Height
    
    ' Inside the frame:
    '    - a gap (Label(0).top)
    '    - the parameters : numprows *  (txtParam(0).height + Label(0).height)
    '    - a gap (100: if numprows>0)
    '    - the grid
    '    - a gap (100)
    '    - lblRecords
    '    - a gap (100)
    ' Adjust the grid height to match the space left
    Dim pheight As Long
    pheight = (txtParam(0).Height + Label(0).Height) * numprows
    If numprows > 0 Then pheight = pheight + 100
    ListView1.Top = Label(0).Top + pheight
    ListView1.Height = Frame1.Height - Label(0).Top - pheight - 100 - lblRecords.Height - 100
    ' Move the lblRecords into place
    lblRecords.Top = Label(0).Top + pheight + ListView1.Height + 100
    
    
    ' Now the widths
    '  First the picture, containing
    '     - a gap
    '     - the select button
    '     - a gap
    '     - the more button, if requested and needed
    '     - a gap (if more button present)
    '     - the exit button
    '     - a gap
    ' Adjust the button spacing to match the space left
    Dim buttonswidth As Long, buttongap As Long
    buttonswidth = cmdSelect.Width + cmdCancel.Width
    If cmdMore.Visible Then
        buttonswidth = buttonswidth + cmdMore.Width
        buttongap = (Me.ScaleWidth - buttonswidth) / 4
    Else
        buttongap = (Me.ScaleWidth - buttonswidth) / 3
    End If
    cmdSelect.Left = buttongap
    If cmdMore.Visible Then
        cmdMore.Left = cmdSelect.Left + cmdSelect.Width + buttongap
        cmdCancel.Left = cmdMore.Left + cmdMore.Width + buttongap
    Else
        cmdCancel.Left = cmdSelect.Left + cmdSelect.Width + buttongap
    End If
    
    '  The form is made up of
    '     - a gap (frame1.left)
    '     - the frame
    '     - a gap (=frame1.left)
    ' Adjust the frame width
    Frame1.Width = Me.ScaleWidth - Frame1.Left - Frame1.Left
    
    ' Within the frame, we have
    '   - a gap (txtParam(0).left)
    '   - the parameters/listview/lblRecords (viewwidth)
    '   - a gap (=txtParam(0).left)
    Dim viewwidth As Long
    viewwidth = Frame1.Width - txtParam(0).Left - txtParam(0).Left
    
    ' special case : if exactly one parameter, make it full width
    If (paramcount = 1) Then
        txtParam(0).Width = viewwidth
        quiet = True
        ' don't ask me why, but you need these next 2 lines to make the text
        '  display properly !!
        txtParam(0).Text = ""
        txtParam(0).Text = par(0)
        quiet = False
    End If
    ' Adjust the listview
    ListView1.Width = viewwidth
    ' Adjust the lblRecords location
    lblRecords.Left = (Frame1.Width - lblRecords.Width) / 2
    
    On Error GoTo 0
End Sub
Private Sub cmdMore_Click()
    LoadGrid
End Sub
Private Sub cmdSelect_Click()
    Dim idx As Integer
    If ListView1.selecteditem Is Nothing Then
        Beep
        Exit Sub
    Else
        If IdCol > 0 Then ' can only return ID if IDCol provided
            ' return selected object
            idx = ListView1.selecteditem.Index
            SelectedId = IDs(idx)
        End If
    End If

    Unload Me
End Sub
Private Sub cmdCancel_Click()
    SelectedId = ""
    Unload Me
End Sub
Private Sub Form_Resize()
    AdjustSizes
End Sub
Private Sub ListView1_DblClick()
    cmdSelect_Click
End Sub
Private Sub txtParam_Change(Index As Integer)
    If quiet Then Exit Sub
    numrows = 0
    result.Close
    result.Execute txtParam(0).Text, txtParam(1).Text, txtParam(2).Text, _
                   txtParam(3).Text, txtParam(4).Text, txtParam(5).Text, _
                   txtParam(6).Text, txtParam(7).Text, txtParam(8).Text
    LoadGrid
End Sub
