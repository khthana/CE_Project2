VERSION 5.00
Object = "{C37EFBE6-BC76-11D2-B65D-0000F87C2780}#1.0#0"; "CACHEQUERY.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form frmArchitecTeacher 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "ArchitectureDepartmentTeacher"
   ClientHeight    =   6555
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   10395
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6681.545
   ScaleMode       =   0  'User
   ScaleWidth      =   10358.95
   StartUpPosition =   2  'CenterScreen
   Begin TabDlg.SSTab SSTab1 
      Height          =   6375
      Left            =   0
      TabIndex        =   10
      Top             =   120
      Width           =   9015
      _ExtentX        =   15901
      _ExtentY        =   11245
      _Version        =   393216
      Style           =   1
      Tabs            =   2
      Tab             =   1
      TabsPerRow      =   6
      TabHeight       =   520
      TabCaption(0)   =   "PrivateData"
      TabPicture(0)   =   "frmArchitecTeacher.frx":0000
      Tab(0).ControlEnabled=   0   'False
      Tab(0).Control(0)=   "txtIdentifierNumber"
      Tab(0).Control(1)=   "txtGender"
      Tab(0).Control(2)=   "txtName"
      Tab(0).Control(3)=   "txtSurname"
      Tab(0).Control(4)=   "txtTeacherNameEng"
      Tab(0).Control(5)=   "txtTeacherSurnameEng"
      Tab(0).Control(6)=   "txtDegreeName"
      Tab(0).Control(7)=   "txtBirthDay"
      Tab(0).Control(8)=   "txtBlood"
      Tab(0).Control(9)=   "txtWeight"
      Tab(0).Control(10)=   "txtHight"
      Tab(0).Control(11)=   "txtCitizen"
      Tab(0).Control(12)=   "txtNation"
      Tab(0).Control(13)=   "txtReligion"
      Tab(0).Control(14)=   "txtCurrentStatus"
      Tab(0).Control(15)=   "lblCurrentStatus"
      Tab(0).Control(16)=   "lblReligion"
      Tab(0).Control(17)=   "lblNation"
      Tab(0).Control(18)=   "lblCitizen"
      Tab(0).Control(19)=   "lblHight"
      Tab(0).Control(20)=   "lblWeight"
      Tab(0).Control(21)=   "lblBlood"
      Tab(0).Control(22)=   "lblBirthDay"
      Tab(0).Control(23)=   "lblTeacherSurnameEng"
      Tab(0).Control(24)=   "lblTeacherNameEng"
      Tab(0).Control(25)=   "lblSurname"
      Tab(0).Control(26)=   "lblDegreeName"
      Tab(0).Control(27)=   "lblName"
      Tab(0).Control(28)=   "lblIdentifierNumber"
      Tab(0).Control(29)=   "lblGender"
      Tab(0).ControlCount=   30
      TabCaption(1)   =   "TeacherData"
      TabPicture(1)   =   "frmArchitecTeacher.frx":001C
      Tab(1).ControlEnabled=   -1  'True
      Tab(1).Control(0)=   "lblDepartment"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).Control(1)=   "lblFaculty"
      Tab(1).Control(1).Enabled=   0   'False
      Tab(1).Control(2)=   "lblFillDate"
      Tab(1).Control(2).Enabled=   0   'False
      Tab(1).Control(3)=   "lblStartDate"
      Tab(1).Control(3).Enabled=   0   'False
      Tab(1).Control(4)=   "lblBeginSalary"
      Tab(1).Control(4).Enabled=   0   'False
      Tab(1).Control(5)=   "lblStartPosition"
      Tab(1).Control(5).Enabled=   0   'False
      Tab(1).Control(6)=   "lblHomeAddrDetail"
      Tab(1).Control(6).Enabled=   0   'False
      Tab(1).Control(7)=   "lblHomeRd"
      Tab(1).Control(7).Enabled=   0   'False
      Tab(1).Control(8)=   "lblHomeSoy"
      Tab(1).Control(8).Enabled=   0   'False
      Tab(1).Control(9)=   "lblHomeMoo"
      Tab(1).Control(9).Enabled=   0   'False
      Tab(1).Control(10)=   "lblHomeProvince"
      Tab(1).Control(10).Enabled=   0   'False
      Tab(1).Control(11)=   "lblHomePostzip"
      Tab(1).Control(11).Enabled=   0   'False
      Tab(1).Control(12)=   "lblHomeEmailAddr"
      Tab(1).Control(12).Enabled=   0   'False
      Tab(1).Control(13)=   "lblHomeSubdivision"
      Tab(1).Control(13).Enabled=   0   'False
      Tab(1).Control(14)=   "lblArtSkill"
      Tab(1).Control(14).Enabled=   0   'False
      Tab(1).Control(15)=   "lblHomeCalledRegion"
      Tab(1).Control(15).Enabled=   0   'False
      Tab(1).Control(16)=   "txtArtSkill"
      Tab(1).Control(16).Enabled=   0   'False
      Tab(1).Control(17)=   "txtStartPosition"
      Tab(1).Control(17).Enabled=   0   'False
      Tab(1).Control(18)=   "txtBeginSalary"
      Tab(1).Control(18).Enabled=   0   'False
      Tab(1).Control(19)=   "txtStartDate"
      Tab(1).Control(19).Enabled=   0   'False
      Tab(1).Control(20)=   "txtFillDate"
      Tab(1).Control(20).Enabled=   0   'False
      Tab(1).Control(21)=   "txtFaculty"
      Tab(1).Control(21).Enabled=   0   'False
      Tab(1).Control(22)=   "txtHomeSoy"
      Tab(1).Control(22).Enabled=   0   'False
      Tab(1).Control(23)=   "txtHomeSubdivision"
      Tab(1).Control(23).Enabled=   0   'False
      Tab(1).Control(24)=   "txtHomeEmailAddr"
      Tab(1).Control(24).Enabled=   0   'False
      Tab(1).Control(25)=   "txtHomePostzip"
      Tab(1).Control(25).Enabled=   0   'False
      Tab(1).Control(26)=   "txtHomeProvince"
      Tab(1).Control(26).Enabled=   0   'False
      Tab(1).Control(27)=   "txtHomeMoo"
      Tab(1).Control(27).Enabled=   0   'False
      Tab(1).Control(28)=   "txtHomeRd"
      Tab(1).Control(28).Enabled=   0   'False
      Tab(1).Control(29)=   "txtHomeAddrDetail"
      Tab(1).Control(29).Enabled=   0   'False
      Tab(1).Control(30)=   "txtDepartment"
      Tab(1).Control(30).Enabled=   0   'False
      Tab(1).Control(31)=   "txtHomeCalledRegion"
      Tab(1).Control(31).Enabled=   0   'False
      Tab(1).ControlCount=   32
      Begin VB.TextBox txtHomeCalledRegion 
         Height          =   345
         Left            =   4200
         TabIndex        =   69
         Text            =   "txtHomeCalledRegion"
         Top             =   5640
         Width           =   2775
      End
      Begin VB.TextBox txtDepartment 
         Height          =   345
         Left            =   720
         TabIndex        =   68
         Text            =   "txtDepartment"
         Top             =   960
         Width           =   2775
      End
      Begin VB.TextBox txtHomeAddrDetail 
         Height          =   345
         Left            =   4200
         TabIndex        =   59
         Text            =   "txtHomeAddrDetail"
         Top             =   960
         Width           =   2775
      End
      Begin VB.TextBox txtHomeRd 
         Height          =   345
         Left            =   4200
         TabIndex        =   58
         Text            =   "txtHomeRd"
         Top             =   1740
         Width           =   2775
      End
      Begin VB.TextBox txtHomeMoo 
         Height          =   345
         Left            =   4200
         TabIndex        =   57
         Text            =   "txtHomeMoo"
         Top             =   3300
         Width           =   1335
      End
      Begin VB.TextBox txtHomeProvince 
         Height          =   345
         Left            =   4200
         TabIndex        =   56
         Text            =   "txtHomeProvince"
         Top             =   4080
         Width           =   2775
      End
      Begin VB.TextBox txtHomePostzip 
         Height          =   345
         Left            =   7320
         TabIndex        =   55
         Text            =   "txtHomePostzip"
         Top             =   4080
         Width           =   1335
      End
      Begin VB.TextBox txtHomeEmailAddr 
         Height          =   345
         Left            =   4200
         TabIndex        =   54
         Text            =   "txtHomeEmailAddr"
         Top             =   4860
         Width           =   2775
      End
      Begin VB.TextBox txtHomeSubdivision 
         Height          =   345
         Left            =   5880
         TabIndex        =   53
         Text            =   "txtHomeSubdivision"
         Top             =   3300
         Width           =   2775
      End
      Begin VB.TextBox txtHomeSoy 
         Height          =   345
         Left            =   4200
         TabIndex        =   52
         Text            =   "txtHomeSoy"
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox txtFaculty 
         Height          =   345
         Left            =   720
         TabIndex        =   45
         Text            =   "txtFaculty"
         Top             =   1740
         Width           =   2775
      End
      Begin VB.TextBox txtFillDate 
         Height          =   345
         Left            =   720
         TabIndex        =   44
         Text            =   "txtFillDate"
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox txtStartDate 
         Height          =   345
         Left            =   720
         TabIndex        =   43
         Text            =   "txtStartDate"
         Top             =   3300
         Width           =   2775
      End
      Begin VB.TextBox txtBeginSalary 
         Height          =   345
         Left            =   720
         TabIndex        =   42
         Text            =   "txtBeginSalary"
         Top             =   4080
         Width           =   2775
      End
      Begin VB.TextBox txtStartPosition 
         Height          =   345
         Left            =   720
         TabIndex        =   41
         Text            =   "txtStartPosition"
         Top             =   4860
         Width           =   2775
      End
      Begin VB.TextBox txtIdentifierNumber 
         Height          =   345
         Left            =   -74280
         TabIndex        =   25
         Text            =   "txtIdentifierNumber"
         Top             =   1740
         Width           =   2775
      End
      Begin VB.TextBox txtGender 
         Height          =   345
         Left            =   -74280
         TabIndex        =   24
         Text            =   "txtGender"
         Top             =   960
         Width           =   1338
      End
      Begin VB.TextBox txtName 
         Height          =   345
         Left            =   -74280
         TabIndex        =   23
         Text            =   "txtName"
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox txtSurname 
         Height          =   345
         Left            =   -74280
         TabIndex        =   22
         Text            =   "txtSurname"
         Top             =   3300
         Width           =   2775
      End
      Begin VB.TextBox txtTeacherNameEng 
         Height          =   345
         Left            =   -74280
         TabIndex        =   21
         Text            =   "txtTeacherNameEng"
         Top             =   4080
         Width           =   2775
      End
      Begin VB.TextBox txtTeacherSurnameEng 
         Height          =   345
         Left            =   -74280
         TabIndex        =   20
         Text            =   "txtTeacherSurnameEng"
         Top             =   4860
         Width           =   2775
      End
      Begin VB.TextBox txtDegreeName 
         Height          =   345
         Left            =   -70800
         TabIndex        =   19
         Text            =   "txtDegreeName"
         Top             =   960
         Width           =   2775
      End
      Begin VB.TextBox txtBirthDay 
         Height          =   345
         Left            =   -70800
         TabIndex        =   18
         Text            =   "txtBirthDay"
         Top             =   4080
         Width           =   3615
      End
      Begin VB.TextBox txtBlood 
         Height          =   345
         Left            =   -68700
         TabIndex        =   17
         Text            =   "txtBlood"
         Top             =   1740
         Width           =   1338
      End
      Begin VB.TextBox txtWeight 
         Height          =   345
         Left            =   -68700
         TabIndex        =   16
         Text            =   "txtWeight"
         Top             =   3300
         Width           =   1338
      End
      Begin VB.TextBox txtHight 
         Height          =   345
         Left            =   -68700
         TabIndex        =   15
         Text            =   "txtHight"
         Top             =   2520
         Width           =   1338
      End
      Begin VB.TextBox txtCitizen 
         Height          =   345
         Left            =   -70800
         TabIndex        =   14
         Text            =   "txtCitizen"
         Top             =   3300
         Width           =   1338
      End
      Begin VB.TextBox txtNation 
         Height          =   345
         Left            =   -70800
         TabIndex        =   13
         Text            =   "txtNation"
         Top             =   1740
         Width           =   1338
      End
      Begin VB.TextBox txtReligion 
         Height          =   345
         Left            =   -70800
         TabIndex        =   12
         Text            =   "txtReligion"
         Top             =   2520
         Width           =   1338
      End
      Begin VB.TextBox txtCurrentStatus 
         Height          =   345
         Left            =   -74280
         TabIndex        =   11
         Text            =   "txtCurrentStatus"
         Top             =   5640
         Width           =   3615
      End
      Begin VB.TextBox txtArtSkill 
         Height          =   345
         Left            =   720
         TabIndex        =   70
         Text            =   "txtArtSkill"
         Top             =   5640
         Width           =   2775
      End
      Begin VB.Label lblHomeCalledRegion 
         Caption         =   "Home CalledRegion"
         Height          =   330
         Left            =   4200
         TabIndex        =   72
         Top             =   5400
         Width           =   1815
      End
      Begin VB.Label lblArtSkill 
         Caption         =   "ArtSkill"
         Height          =   330
         Left            =   720
         TabIndex        =   71
         Top             =   5400
         Width           =   1020
      End
      Begin VB.Label lblHomeSubdivision 
         Caption         =   "Home Subdivision"
         Height          =   330
         Left            =   5880
         TabIndex        =   67
         Top             =   3060
         Width           =   1335
      End
      Begin VB.Label lblHomeEmailAddr 
         Caption         =   "Home EmailAddr"
         Height          =   330
         Left            =   4200
         TabIndex        =   66
         Top             =   4620
         Width           =   1335
      End
      Begin VB.Label lblHomePostzip 
         Caption         =   "Home Postzip"
         Height          =   330
         Left            =   7320
         TabIndex        =   65
         Top             =   3840
         Width           =   1335
      End
      Begin VB.Label lblHomeProvince 
         Caption         =   "Home Province"
         Height          =   330
         Left            =   4200
         TabIndex        =   64
         Top             =   3840
         Width           =   1335
      End
      Begin VB.Label lblHomeMoo 
         Caption         =   "Home Moo"
         Height          =   330
         Left            =   4200
         TabIndex        =   63
         Top             =   3060
         Width           =   1335
      End
      Begin VB.Label lblHomeSoy 
         Caption         =   "Home Soy"
         Height          =   330
         Left            =   4200
         TabIndex        =   62
         Top             =   2280
         Width           =   975
      End
      Begin VB.Label lblHomeRd 
         Caption         =   "Home Rd"
         Height          =   330
         Left            =   4200
         TabIndex        =   61
         Top             =   1500
         Width           =   1335
      End
      Begin VB.Label lblHomeAddrDetail 
         Caption         =   "Home AddrDetail"
         Height          =   330
         Left            =   4200
         TabIndex        =   60
         Top             =   720
         Width           =   1335
      End
      Begin VB.Label lblStartPosition 
         Caption         =   "StartPosition"
         Height          =   330
         Left            =   720
         TabIndex        =   51
         Top             =   4620
         Width           =   1335
      End
      Begin VB.Label lblBeginSalary 
         Caption         =   "BeginSalary"
         Height          =   330
         Left            =   720
         TabIndex        =   50
         Top             =   3840
         Width           =   1020
      End
      Begin VB.Label lblStartDate 
         Caption         =   "StartDate"
         Height          =   330
         Left            =   720
         TabIndex        =   49
         Top             =   3060
         Width           =   1020
      End
      Begin VB.Label lblFillDate 
         Caption         =   "FillDate"
         Height          =   330
         Left            =   720
         TabIndex        =   48
         Top             =   2280
         Width           =   1020
      End
      Begin VB.Label lblFaculty 
         Caption         =   "Faculty"
         Height          =   330
         Left            =   720
         TabIndex        =   47
         Top             =   1500
         Width           =   1020
      End
      Begin VB.Label lblDepartment 
         Caption         =   "Department"
         Height          =   330
         Left            =   720
         TabIndex        =   46
         Top             =   720
         Width           =   1020
      End
      Begin VB.Label lblCurrentStatus 
         Caption         =   "CurrentStatus"
         Height          =   330
         Left            =   -74280
         TabIndex        =   40
         Top             =   5400
         Width           =   1020
      End
      Begin VB.Label lblReligion 
         Caption         =   "Religion"
         Height          =   330
         Left            =   -70800
         TabIndex        =   39
         Top             =   2280
         Width           =   1020
      End
      Begin VB.Label lblNation 
         Caption         =   "Nation"
         Height          =   330
         Left            =   -70800
         TabIndex        =   38
         Top             =   1530
         Width           =   1020
      End
      Begin VB.Label lblCitizen 
         Caption         =   "Citizen"
         Height          =   330
         Left            =   -70800
         TabIndex        =   37
         Top             =   3060
         Width           =   1020
      End
      Begin VB.Label lblHight 
         Caption         =   "Hight"
         Height          =   330
         Left            =   -68700
         TabIndex        =   36
         Top             =   2280
         Width           =   1020
      End
      Begin VB.Label lblWeight 
         Caption         =   "Weight"
         Height          =   330
         Left            =   -68700
         TabIndex        =   35
         Top             =   3060
         Width           =   1575
      End
      Begin VB.Label lblBlood 
         Caption         =   "Blood"
         Height          =   330
         Left            =   -68700
         TabIndex        =   34
         Top             =   1530
         Width           =   1575
      End
      Begin VB.Label lblBirthDay 
         Caption         =   "BirthDay"
         Height          =   330
         Left            =   -70800
         TabIndex        =   33
         Top             =   3840
         Width           =   1575
      End
      Begin VB.Label lblTeacherSurnameEng 
         Caption         =   "TeacherSurnameEng"
         Height          =   330
         Left            =   -74280
         TabIndex        =   32
         Top             =   4620
         Width           =   1575
      End
      Begin VB.Label lblTeacherNameEng 
         Caption         =   "TeacherNameEng"
         Height          =   330
         Left            =   -74280
         TabIndex        =   31
         Top             =   3840
         Width           =   1575
      End
      Begin VB.Label lblSurname 
         Caption         =   "Surname"
         Height          =   330
         Left            =   -74280
         TabIndex        =   30
         Top             =   3060
         Width           =   1575
      End
      Begin VB.Label lblDegreeName 
         Caption         =   "DegreeName"
         Height          =   330
         Left            =   -70800
         TabIndex        =   29
         Top             =   720
         Width           =   1575
      End
      Begin VB.Label lblName 
         Caption         =   "Name"
         Height          =   330
         Left            =   -74280
         TabIndex        =   28
         Top             =   2280
         Width           =   1575
      End
      Begin VB.Label lblIdentifierNumber 
         Caption         =   "IdentifierNumber"
         Height          =   330
         Left            =   -74280
         TabIndex        =   27
         Top             =   1500
         Width           =   1575
      End
      Begin VB.Label lblGender 
         Caption         =   "Gender"
         Height          =   330
         Left            =   -74280
         TabIndex        =   26
         Top             =   720
         Width           =   975
      End
   End
   Begin VB.Frame fra_Main 
      BorderStyle     =   0  'None
      Caption         =   "fra_Main"
      Height          =   3885
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   10380
      Begin VB.CommandButton cmd__Exit 
         Caption         =   "Cancel"
         Height          =   385
         Left            =   9129
         TabIndex        =   7
         Top             =   2610
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Close 
         Caption         =   "&Close"
         Height          =   385
         Left            =   9129
         TabIndex        =   6
         Top             =   2220
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Delete 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   9129
         TabIndex        =   5
         Top             =   1740
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Save 
         Caption         =   "&Save"
         Height          =   385
         Left            =   9129
         TabIndex        =   4
         Top             =   1350
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Find 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   9129
         TabIndex        =   3
         Top             =   870
         Width           =   1095
      End
      Begin VB.CommandButton cmd__New 
         Caption         =   "&New"
         Height          =   385
         Left            =   9129
         TabIndex        =   2
         Top             =   480
         Width           =   1095
      End
   End
   Begin VB.PictureBox picPatch 
      BorderStyle     =   0  'None
      Height          =   250
      Left            =   0
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   9
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.VScrollBar VSCroll 
      Height          =   1177
      LargeChange     =   24
      Left            =   10380
      TabIndex        =   8
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.HScrollBar HSCroll 
      Height          =   250
      LargeChange     =   24
      Left            =   0
      TabIndex        =   1
      Top             =   3885
      Visible         =   0   'False
      Width           =   1204
   End
   Begin CACHEQUERYLib.CacheQuery CacheQuery1 
      Left            =   4590
      Top             =   1695
      _Version        =   65536
      _ExtentX        =   847
      _ExtentY        =   847
      _StockProps     =   0
      ClassName       =   ""
      QueryName       =   ""
   End
   Begin MSComDlg.CommonDialog dlgCommon 
      Left            =   4590
      Top             =   1695
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuObject 
      Caption         =   "&Object"
      Begin VB.Menu mnu__New 
         Caption         =   "&New"
      End
      Begin VB.Menu mnu__Find 
         Caption         =   "&Find..."
      End
      Begin VB.Menu mnu__Bar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Save 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnu__Delete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnu__Close 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnu__Bar2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Exit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "frmArchitecTeacher"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const m_classname = "PersonInfo.ArchitecTeacher"

Private m_factory As Object
Private m_object As Object
Private m_modified As Boolean
Private m_WaitFlag As Integer
Private id As Variant
Private disableclick As Boolean

Private Sub cmd__Close_Click()
    actionClose

End Sub

Private Sub cmd__Delete_Click()
    actionDelete

End Sub

Private Sub cmd__Exit_Click()
    actionExit

End Sub

Private Sub cmd__Find_Click()
    actionFind

End Sub

Private Sub cmd__New_Click()
    actionNew

End Sub

Private Sub cmd__Save_Click()
    actionSave

End Sub

Private Sub Form_Load()
    Dim sdir As String
    actionClose
    Set m_factory = CacheForm.Factory
'    sdir = m_factory.ConnectDlg
'    If sdir <> "" Then
'        m_factory.connect sdir
'    Else
'        End
'    End If
End Sub

Private Sub Form_Resize()
picPatch.Visible = False
If Me.ScaleWidth < fra_Main.Width Then
    HSCroll.Top = Me.ScaleHeight - HSCroll.Height
    HSCroll.Width = Me.ScaleWidth
    HSCroll.max = (fra_Main.Width - Me.ScaleWidth) \ 15
    HSCroll.Visible = True
    HSCroll.ZOrder
    If Me.ScaleHeight - HSCroll.Height < fra_Main.Height Then
        HSCroll.Width = Me.ScaleWidth - VSCroll.Width
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight - HSCroll.Height
        HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        picPatch.Top = HSCroll.Top
        picPatch.Left = HSCroll.Width
        picPatch.Visible = True
        picPatch.ZOrder
    Else
        VSCroll.Visible = False
    End If
Else
   HSCroll.Visible = False
    If Me.ScaleHeight < fra_Main.Height Then
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        If Me.ScaleWidth - VSCroll.Width < fra_Main.Width Then
            VSCroll.Height = Me.ScaleHeight - HSCroll.Height
            HSCroll.Top = Me.ScaleHeight - HSCroll.Height
            HSCroll.Width = Me.ScaleWidth - VSCroll.Width
            VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
            HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
            HSCroll.Visible = True
            HSCroll.ZOrder
            picPatch.Top = HSCroll.Top
            picPatch.Left = HSCroll.Width
            picPatch.Visible = True
            picPatch.ZOrder
        End If
    Else
        VSCroll.Visible = False
    End If
End If
End Sub

Private Sub HScroll_Change()
    fra_Main.Left = -HSCroll.Value * 15
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

Private Sub mnu__Close_Click()
    actionClose

End Sub

Private Sub mnu__Delete_Click()
    actionDelete

End Sub

Private Sub mnu__Exit_Click()
    actionExit

End Sub

Private Sub mnu__Find_Click()
    actionFind

End Sub

Private Sub mnu__New_Click()
    actionNew

End Sub

Private Sub mnu__Save_Click()
    actionSave

End Sub

Private Sub txtArtSkill_Change()
    m_modified = True

End Sub

Private Sub txtBeginSalary_Change()
    m_modified = True

End Sub

Private Sub txtBirthDay_Change()
    m_modified = True

End Sub

Private Sub txtBlood_Change()
    m_modified = True

End Sub

Private Sub txtCitizen_Change()
    m_modified = True

End Sub

Private Sub txtCurrentStatus_Change()
    m_modified = True

End Sub

Private Sub txtDegreeName_Change()
    m_modified = True

End Sub

Private Sub txtDepartment_Change()
    m_modified = True

End Sub

Private Sub txtFaculty_Change()
    m_modified = True

End Sub

Private Sub txtFillDate_Change()
    m_modified = True

End Sub

Private Sub txtGender_Change()
    m_modified = True

End Sub

Private Sub txtHight_Change()
    m_modified = True

End Sub

Private Sub txtHomeAddrDetail_Change()
    m_modified = True

End Sub

Private Sub txtHomeCalledRegion_Change()
    m_modified = True

End Sub

Private Sub txtHomeEmailAddr_Change()
    m_modified = True

End Sub

Private Sub txtHomeMoo_Change()
    m_modified = True

End Sub

Private Sub txtHomePostzip_Change()
    m_modified = True

End Sub

Private Sub txtHomeProvince_Change()
    m_modified = True

End Sub

Private Sub txtHomeRd_Change()
    m_modified = True

End Sub

Private Sub txtHomeSoy_Change()
    m_modified = True

End Sub

Private Sub txtHomeSubdivision_Change()
    m_modified = True

End Sub

Private Sub txtIdentifierNumber_Change()
    m_modified = True

End Sub

Private Sub txtName_Change()
    m_modified = True

End Sub

Private Sub txtNation_Change()
    m_modified = True

End Sub

Private Sub txtReligion_Change()
    m_modified = True

End Sub

Private Sub txtStartDate_Change()
    m_modified = True

End Sub

Private Sub txtStartPosition_Change()
    m_modified = True

End Sub

Private Sub txtSurname_Change()
    m_modified = True

End Sub

Private Sub txtTeacherNameEng_Change()
    m_modified = True

End Sub

Private Sub txtTeacherSurnameEng_Change()
    m_modified = True

End Sub

Private Sub txtWeight_Change()
    m_modified = True

End Sub

Private Sub VScroll_Change()
    fra_Main.Top = -VSCroll.Value * 15
End Sub

Private Sub VScroll_Scroll()
    VScroll_Change
End Sub

Private Sub actionNew()
    actionClose
    Set m_object = m_factory.New(m_classname)
    If m_object Is Nothing Then
         MsgBox "Cannot create new object."
         actionClose
    Else
         EnableScreen True
         SyncObjectToScreen
         m_modified = True
         cmd__Delete.Enabled = False
         mnu__Delete.Enabled = False
    End If
End Sub

Private Sub actionFind()
    actionClose
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = m_classname
    id = CacheQuery1.FindId
    If id = "" Then Exit Sub
    Set m_object = m_factory.OpenId(m_classname, id)
    If m_object Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableScreen True
        SyncObjectToScreen
        m_modified = False
    End If
End Sub

Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDelete()
    If id = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObject
    On Error GoTo actionDeleteError
    BeginWait
    m_object.sys_DeleteId (id)
    actionClose
    EndWait
    m_modified = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_object Is Nothing Then
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    id = ""
    m_modified = False
End Sub

Private Sub actionExit()
    actionClose
    Unload Me
End Sub

Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

Private Function minmax(val As Long, min As Long, max As Long)
    minmax = val
    If min <> -1 And val < min Then minmax = min
    If max <> -1 And val > max Then minmax = max
End Function

Public Sub ListView_ColumnClick(hList As ListView, ByVal ColumnHeader As MSComctlLib.ColumnHeader)
    'Handle any listview
    If hList.Sorted = False Then
       hList.Sorted = True
       hList.SortKey = ColumnHeader.Index - 1
       hList.SortOrder = lvwAscending
       Exit Sub
    End If
    If hList.SortKey = (ColumnHeader.Index - 1) Then
        If hList.SortOrder = lvwAscending Then
            hList.SortOrder = lvwDescending
        Else
            hList.SortOrder = lvwAscending
        End If
    Else
        hList.SortKey = ColumnHeader.Index - 1
    End If
End Sub
Private Sub EnableScreen(Enabled As Boolean)
    lblIdentifierNumber.Enabled = Enabled
    txtIdentifierNumber.Enabled = Enabled
    lblGender.Enabled = Enabled
    txtGender.Enabled = Enabled
    lblName.Enabled = Enabled
    txtName.Enabled = Enabled
    lblSurname.Enabled = Enabled
    txtSurname.Enabled = Enabled
    lblTeacherNameEng.Enabled = Enabled
    txtTeacherNameEng.Enabled = Enabled
    lblTeacherSurnameEng.Enabled = Enabled
    txtTeacherSurnameEng.Enabled = Enabled
    lblDegreeName.Enabled = Enabled
    txtDegreeName.Enabled = Enabled
    lblBirthDay.Enabled = Enabled
    txtBirthDay.Enabled = Enabled
    lblBlood.Enabled = Enabled
    txtBlood.Enabled = Enabled
    lblHight.Enabled = Enabled
    txtHight.Enabled = Enabled
    lblWeight.Enabled = Enabled
    txtWeight.Enabled = Enabled
    lblCitizen.Enabled = Enabled
    txtCitizen.Enabled = Enabled
    lblNation.Enabled = Enabled
    txtNation.Enabled = Enabled
    lblReligion.Enabled = Enabled
    txtReligion.Enabled = Enabled
    lblBeginSalary.Enabled = Enabled
    txtBeginSalary.Enabled = Enabled
    lblArtSkill.Enabled = Enabled
    txtArtSkill.Enabled = Enabled
    lblDepartment.Enabled = Enabled
    txtDepartment.Enabled = Enabled
    lblFaculty.Enabled = Enabled
    txtFaculty.Enabled = Enabled
    lblCurrentStatus.Enabled = Enabled
    txtCurrentStatus.Enabled = Enabled
    lblFillDate.Enabled = Enabled
    txtFillDate.Enabled = Enabled
    lblStartDate.Enabled = Enabled
    txtStartDate.Enabled = Enabled
    lblStartPosition.Enabled = Enabled
    txtStartPosition.Enabled = Enabled
    lblHomeAddrDetail.Enabled = Enabled
    txtHomeAddrDetail.Enabled = Enabled
    lblHomeCalledRegion.Enabled = Enabled
    txtHomeCalledRegion.Enabled = Enabled
    lblHomeRd.Enabled = Enabled
    txtHomeRd.Enabled = Enabled
    lblHomeSoy.Enabled = Enabled
    txtHomeSoy.Enabled = Enabled
    lblHomeMoo.Enabled = Enabled
    txtHomeMoo.Enabled = Enabled
    lblHomeSubdivision.Enabled = Enabled
    txtHomeSubdivision.Enabled = Enabled
    lblHomeProvince.Enabled = Enabled
    txtHomeProvince.Enabled = Enabled
    lblHomePostzip.Enabled = Enabled
    txtHomePostzip.Enabled = Enabled
    lblHomeEmailAddr.Enabled = Enabled
    txtHomeEmailAddr.Enabled = Enabled
    mnu__Save.Enabled = Enabled
    mnu__Close.Enabled = Enabled
    mnu__Delete.Enabled = Enabled
    cmd__Save.Enabled = Enabled
    cmd__Close.Enabled = Enabled
    cmd__Delete.Enabled = Enabled
End Sub

Private Sub EraseScreen()
    txtIdentifierNumber.Text = ""
    txtGender.Text = ""
    txtName.Text = ""
    txtSurname.Text = ""
    txtTeacherNameEng.Text = ""
    txtTeacherSurnameEng.Text = ""
    txtDegreeName.Text = ""
    txtBirthDay.Text = ""
    txtBlood.Text = ""
    txtHight.Text = ""
    txtWeight.Text = ""
    txtCitizen.Text = ""
    txtNation.Text = ""
    txtReligion.Text = ""
    txtBeginSalary.Text = ""
    txtArtSkill.Text = ""
    txtDepartment.Text = ""
    txtFaculty.Text = ""
    txtCurrentStatus.Text = ""
    txtFillDate.Text = ""
    txtStartDate.Text = ""
    txtStartPosition.Text = ""
    txtHomeAddrDetail.Text = ""
    txtHomeCalledRegion.Text = ""
    txtHomeRd.Text = ""
    txtHomeSoy.Text = ""
    txtHomeMoo.Text = ""
    txtHomeSubdivision.Text = ""
    txtHomeProvince.Text = ""
    txtHomePostzip.Text = ""
    txtHomeEmailAddr.Text = ""
End Sub

Private Sub SyncObjectToScreen()
    Dim obj As Object
    Dim i As Integer
    Dim item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtIdentifierNumber.Text = m_object.IdentifierNumber
    txtGender.Text = m_object.Gender
    txtName.Text = m_object.Name
    txtSurname.Text = m_object.Surname
    txtTeacherNameEng.Text = m_object.TeacherNameEng
    txtTeacherSurnameEng.Text = m_object.TeacherSurnameEng
    txtDegreeName.Text = m_object.DegreeName
    If m_object.BirthDay <> 0 Then
       txtBirthDay.Text = m_object.BirthDay
    Else
       txtBirthDay.Text = ""
    End If
    txtBlood.Text = m_object.Blood
    txtHight.Text = m_object.Hight
    txtWeight.Text = m_object.Weight
    txtCitizen.Text = m_object.Citizen
    txtNation.Text = m_object.Nation
    txtReligion.Text = m_object.Religion
    txtBeginSalary.Text = m_object.BeginSalary
    txtArtSkill.Text = m_object.ArtSkill
    txtDepartment.Text = m_object.Department
    txtFaculty.Text = m_object.Faculty
    txtCurrentStatus.Text = m_object.CurrentStatus
    If m_object.FillDate <> 0 Then
       txtFillDate.Text = m_object.FillDate
    Else
       txtFillDate.Text = ""
    End If
    If m_object.StartDate <> 0 Then
       txtStartDate.Text = m_object.StartDate
    Else
       txtStartDate.Text = ""
    End If
    txtStartPosition.Text = m_object.StartPosition
    txtHomeAddrDetail.Text = m_object.Home.AddrDetail
    txtHomeCalledRegion.Text = m_object.Home.CalledRegion
    txtHomeRd.Text = m_object.Home.Rd
    txtHomeSoy.Text = m_object.Home.Soy
    txtHomeMoo.Text = m_object.Home.Moo
    txtHomeSubdivision.Text = m_object.Home.Subdivision
    txtHomeProvince.Text = m_object.Home.Province
    txtHomePostzip.Text = m_object.Home.Postzip
    txtHomeEmailAddr.Text = m_object.Home.EmailAddr
End Sub

Private Sub SyncScreenToObject()
    m_object.IdentifierNumber = txtIdentifierNumber.Text
    m_object.Gender = txtGender.Text
    m_object.Name = txtName.Text
    m_object.Surname = txtSurname.Text
    m_object.TeacherNameEng = txtTeacherNameEng.Text
    m_object.TeacherSurnameEng = txtTeacherSurnameEng.Text
    m_object.DegreeName = txtDegreeName.Text
    m_object.BirthDay = txtBirthDay.Text
    m_object.Blood = txtBlood.Text
    m_object.Hight = txtHight.Text
    m_object.Weight = txtWeight.Text
    m_object.Citizen = txtCitizen.Text
    m_object.Nation = txtNation.Text
    m_object.Religion = txtReligion.Text
    m_object.BeginSalary = txtBeginSalary.Text
    m_object.ArtSkill = txtArtSkill.Text
    m_object.Department = txtDepartment.Text
    m_object.Faculty = txtFaculty.Text
    m_object.CurrentStatus = txtCurrentStatus.Text
    m_object.FillDate = txtFillDate.Text
    m_object.StartDate = txtStartDate.Text
    m_object.StartPosition = txtStartPosition.Text
    m_object.Home.AddrDetail = txtHomeAddrDetail.Text
    m_object.Home.CalledRegion = txtHomeCalledRegion.Text
    m_object.Home.Rd = txtHomeRd.Text
    m_object.Home.Soy = txtHomeSoy.Text
    m_object.Home.Moo = txtHomeMoo.Text
    m_object.Home.Subdivision = txtHomeSubdivision.Text
    m_object.Home.Province = txtHomeProvince.Text
    m_object.Home.Postzip = txtHomePostzip.Text
    m_object.Home.EmailAddr = txtHomeEmailAddr.Text
End Sub


