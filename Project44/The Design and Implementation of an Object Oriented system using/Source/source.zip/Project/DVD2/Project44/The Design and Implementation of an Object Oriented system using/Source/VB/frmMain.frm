VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.Form frmMain 
   Caption         =   "RegistrationSystem"
   ClientHeight    =   6432
   ClientLeft      =   4248
   ClientTop       =   2028
   ClientWidth     =   7368
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   PaletteMode     =   2  'Custom
   ScaleHeight     =   26.8
   ScaleMode       =   4  'Character
   ScaleWidth      =   61.4
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command4 
      Caption         =   "����¹����Ԫ�"
      Height          =   972
      Left            =   5040
      TabIndex        =   5
      Top             =   4200
      Width           =   1332
   End
   Begin VB.CommandButton Command3 
      Caption         =   "�͹����Ԫ�"
      Height          =   972
      Left            =   2280
      TabIndex        =   4
      Top             =   4200
      Width           =   1332
   End
   Begin VB.CommandButton Command2 
      Caption         =   "��������Ԫ�"
      Height          =   972
      Left            =   5040
      TabIndex        =   3
      Top             =   2160
      Width           =   1332
   End
   Begin VB.CommandButton Command1 
      Caption         =   "ŧ����¹���¹"
      Height          =   972
      Left            =   2280
      TabIndex        =   2
      Top             =   2160
      Width           =   1332
   End
   Begin MSComctlLib.StatusBar sbStatusBar 
      Align           =   2  'Align Bottom
      Height          =   276
      Left            =   0
      TabIndex        =   0
      Top             =   6156
      Width           =   7368
      _ExtentX        =   12996
      _ExtentY        =   487
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   7387
            Text            =   "Status"
            TextSave        =   "Status"
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   6
            AutoSize        =   2
            TextSave        =   "20/3/2545"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   5
            AutoSize        =   2
            TextSave        =   "8:03"
         EndProperty
      EndProperty
   End
   Begin MSComDlg.CommonDialog dlgCommonDialog 
      Left            =   4920
      Top             =   480
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin MSComctlLib.ImageList imlToolbarIcons 
      Left            =   4920
      Top             =   840
      _ExtentX        =   995
      _ExtentY        =   995
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   12
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":030A
            Key             =   "Open"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":041C
            Key             =   "Cut"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":052E
            Key             =   "Copy"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0640
            Key             =   "Paste"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0752
            Key             =   "Golden Disk"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0A6C
            Key             =   "Lazorbeak"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0D86
            Key             =   "Max3"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":10A0
            Key             =   "Megatron"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13BA
            Key             =   "BA"
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":16D4
            Key             =   "Buttercup"
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":19EE
            Key             =   "Waspinator"
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1D08
            Key             =   "tm-cheetor"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.Toolbar tbToolBar 
      Align           =   1  'Align Top
      Height          =   336
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   7368
      _ExtentX        =   12996
      _ExtentY        =   593
      ButtonWidth     =   487
      ButtonHeight    =   466
      Appearance      =   1
      ImageList       =   "imlToolbarIcons"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   17
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Open"
            Object.ToolTipText     =   "Open"
            ImageKey        =   "Open"
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Cut"
            Object.ToolTipText     =   "Cut"
            ImageKey        =   "Cut"
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Copy"
            Object.ToolTipText     =   "Copy"
            ImageKey        =   "Copy"
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Paste"
            Object.ToolTipText     =   "Paste"
            ImageKey        =   "Paste"
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Golden Disk"
            ImageKey        =   "Golden Disk"
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Lazorbeak"
            ImageKey        =   "Lazorbeak"
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Max3"
            ImageKey        =   "Max3"
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Megatron"
            ImageKey        =   "Megatron"
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Student"
            ImageKey        =   "BA"
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Teacher"
            ImageKey        =   "Buttercup"
         EndProperty
         BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Waspinator"
            ImageKey        =   "Waspinator"
         EndProperty
         BeginProperty Button16 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button17 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Curriculum"
            ImageKey        =   "tm-cheetor"
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuEdit 
      Caption         =   "&Edit"
      Begin VB.Menu mnuEditUndo 
         Caption         =   "&Undo"
      End
      Begin VB.Menu mnuEditBar0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEditCut 
         Caption         =   "Cu&t"
         Shortcut        =   ^X
      End
      Begin VB.Menu mnuEditCopy 
         Caption         =   "&Copy"
         Shortcut        =   ^C
      End
      Begin VB.Menu mnuEditPaste 
         Caption         =   "&Paste"
         Shortcut        =   ^V
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "&View"
      Begin VB.Menu mnuViewToolbar 
         Caption         =   "&Toolbar"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewStatusBar 
         Caption         =   "Status &Bar"
         Checked         =   -1  'True
      End
   End
   Begin VB.Menu mnuRegistration 
      Caption         =   "&Registration"
      Begin VB.Menu mnuRegistrationRegister 
         Caption         =   "Register"
      End
      Begin VB.Menu HistoryMiantain 
         Caption         =   "HistoryMiantain"
      End
      Begin VB.Menu EngineerRegistration 
         Caption         =   "EngineerRegistration"
      End
      Begin VB.Menu mnuRegistrationBar0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuRegistrationAddSubject 
         Caption         =   "AddSubject"
      End
      Begin VB.Menu mnuRegistrationRemoveSubject 
         Caption         =   "DropSubject"
      End
      Begin VB.Menu mnuRegistrationChangeSubject 
         Caption         =   "ChangeSubject"
      End
      Begin VB.Menu Item 
         Caption         =   "ItemViewer"
      End
   End
   Begin VB.Menu mnuStdInfo 
      Caption         =   "StdInfo"
      Begin VB.Menu person 
         Caption         =   "Person"
      End
      Begin VB.Menu mnuStdInfoStdMaintain 
         Caption         =   "StdMaintain"
      End
   End
   Begin VB.Menu mnuTeacherInfo 
      Caption         =   "TeacherInfo"
      Begin VB.Menu Architecteacher 
         Caption         =   "Architecteacher"
      End
      Begin VB.Menu mnuTeacherInfoTeacherMaintain 
         Caption         =   "TeacherMaintain"
      End
   End
   Begin VB.Menu mnuCurrentSubject 
      Caption         =   "CurrentSubject"
      Begin VB.Menu SubjectMaintian 
         Caption         =   "SubjectMaintian"
      End
      Begin VB.Menu mnuCurrentSubjectOpenSubject 
         Caption         =   "OpenSubject"
      End
      Begin VB.Menu mnuCurrentSubjectRemoveSubject 
         Caption         =   "RemoveSubject"
      End
      Begin VB.Menu mnuCurrentSubjectBar0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuCurrentSubjectAddSection 
         Caption         =   "AddSection"
      End
      Begin VB.Menu mnuCurrentSubjectRemoveSection 
         Caption         =   "RemoveSection"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Architecteacher_Click()
frmArchitecTeacher.Show 1
End Sub

Private Sub Command1_Click()
frmRegister.Show 1

End Sub

Private Sub Command2_Click()
frmRegisterAdd.Show 1
End Sub

Private Sub Command3_Click()
frmRegisterDrop.Show 1
End Sub

Private Sub Command4_Click()
frmRegisterChange.Show 1
End Sub

Private Sub EngineerRegistration_Click()
    frmEngineerRegistration.Show 1
End Sub

Private Sub Form_Load()
    Me.Left = GetSetting(App.Title, "Settings", "MainLeft", 1000)
    Me.Top = GetSetting(App.Title, "Settings", "MainTop", 1000)
    Me.Width = GetSetting(App.Title, "Settings", "MainWidth", 6500)
    Me.Height = GetSetting(App.Title, "Settings", "MainHeight", 6500)
End Sub


Private Sub Form_Unload(Cancel As Integer)
    Dim i As Integer
    'close all sub forms
    For i = Forms.Count - 1 To 1 Step -1
        Unload Forms(i)
    Next
    If Me.WindowState <> vbMinimized Then
        SaveSetting App.Title, "Settings", "MainLeft", Me.Left
        SaveSetting App.Title, "Settings", "MainTop", Me.Top
        SaveSetting App.Title, "Settings", "MainWidth", Me.Width
        SaveSetting App.Title, "Settings", "MainHeight", Me.Height
    End If
    'Unload CacheForm
End Sub

Private Sub HistoryMiantain_Click()
    frmStudentRegistrationHistory.Show 1
End Sub

Private Sub Item_Click()
frmRegisItem.Show 1
End Sub

Private Sub person_Click()
    frmPerson.Show (1)
End Sub

Private Sub SubjectMaintian_Click()
    frmSubjectItem.Show 1
End Sub

Private Sub tbToolBar_ButtonClick(ByVal Button As MSComctlLib.Button)
    On Error Resume Next
    Select Case Button.Key
        Case "Open"
            'ToDo: Add 'Open' button code.
            MsgBox "Add 'Open' button code."
        Case "Cut"
            mnuEditCut_Click
        Case "Copy"
            mnuEditCopy_Click
        Case "Paste"
            mnuEditPaste_Click
        Case "Golden Disk"
            'ToDo: Add 'Golden Disk' button code.
            MsgBox "Add 'Golden Disk' button code."
        Case "Lazorbeak"
            'ToDo: Add 'Lazorbeak' button code.
            MsgBox "Add 'Lazorbeak' button code."
        Case "Max3"
            'ToDo: Add 'Max3' button code.
            MsgBox "Add 'Max3' button code."
        Case "Megatron"
            'ToDo: Add 'Megatron' button code.
            MsgBox "Add 'Megatron' button code."
        Case "Student"
            'ToDo: Add 'Student' button code.
            MsgBox "Add 'Student' button code."
        Case "Teacher"
            'ToDo: Add 'Teacher' button code.
            MsgBox "Add 'Teacher' button code."
        Case "Waspinator"
            'ToDo: Add 'Waspinator' button code.
            MsgBox "Add 'Waspinator' button code."
        Case "Curriculum"
            'ToDo: Add 'Curriculum' button code.
            MsgBox "Add 'Curriculum' button code."
    End Select
End Sub

Private Sub mnuCurriculumCurriculumMaintain_Click()
    'ToDo: Add 'mnuCurriculumCurriculumMaintain_Click' code.
    MsgBox "Add 'mnuCurriculumCurriculumMaintain_Click' code."
End Sub

Private Sub mnuCurrentSubjectRemoveSection_Click()
    'ToDo: Add 'mnuCurrentSubjectRemoveSection_Click' code.
    MsgBox "Add 'mnuCurrentSubjectRemoveSection_Click' code."
End Sub

Private Sub mnuCurrentSubjectAddSection_Click()
    'ToDo: Add 'mnuCurrentSubjectAddSection_Click' code.
    MsgBox "Add 'mnuCurrentSubjectAddSection_Click' code."
End Sub

Private Sub mnuCurrentSubjectRemoveSubject_Click()
    'ToDo: Add 'mnuCurrentSubjectRemoveSubject_Click' code.
    MsgBox "Add 'mnuCurrentSubjectRemoveSubject_Click' code."
End Sub

Private Sub mnuCurrentSubjectOpenSubject_Click()
    'ToDo: Add 'mnuCurrentSubjectOpenSubject_Click' code.
    MsgBox "Add 'mnuCurrentSubjectOpenSubject_Click' code."
End Sub

Private Sub mnuTeacherInfoTeacherMaintain_Click()
    'ToDo: Add 'mnuTeacherInfoTeacherMaintain_Click' code.
    'MsgBox "Add 'mnuTeacherInfoTeacherMaintain_Click' code."
    frmTeacher.Show (1)
End Sub

Private Sub mnuStdInfoStdMaintain_Click()
    'ToDo: Add 'mnuStdInfoStdMaintain_Click' code.
    'MsgBox "Add 'mnuStdInfoStdMaintain_Click' code."
    frmKmitlStudent2.Show (1)
    
End Sub

Private Sub mnuRegistrationChangeSubject_Click()
    'ToDo: Add 'mnuRegistrationChangeSubject_Click' code.
    'MsgBox "Add 'mnuRegistrationChangeSubject_Click' code."
    frmRegisterChange.Show 1
End Sub

Private Sub mnuRegistrationRemoveSubject_Click()
    'ToDo: Add 'mnuRegistrationRemoveSubject_Click' code.
    'MsgBox "Add 'mnuRegistrationRemoveSubject_Click' code."
    frmRegisterDrop.Show 1
End Sub

Private Sub mnuRegistrationAddSubject_Click()
    'ToDo: Add 'mnuRegistrationAddSubject_Click' code.
    'MsgBox "Add 'mnuRegistrationAddSubject_Click' code."
    frmRegisterAdd.Show (1)
End Sub

Private Sub mnuRegistrationRegister_Click()
    'ToDo: Add 'mnuRegistrationRegister_Click' code.
    'MsgBox "Add 'mnuRegistrationRegister_Click' code."
    frmRegister.Show (1)
End Sub

Private Sub mnuViewStatusBar_Click()
    mnuViewStatusBar.Checked = Not mnuViewStatusBar.Checked
    sbStatusBar.Visible = mnuViewStatusBar.Checked
End Sub

Private Sub mnuViewToolbar_Click()
    mnuViewToolbar.Checked = Not mnuViewToolbar.Checked
    tbToolBar.Visible = mnuViewToolbar.Checked
End Sub

Private Sub mnuEditPaste_Click()
    'ToDo: Add 'mnuEditPaste_Click' code.
    MsgBox "Add 'mnuEditPaste_Click' code."
End Sub

Private Sub mnuEditCopy_Click()
    'ToDo: Add 'mnuEditCopy_Click' code.
    MsgBox "Add 'mnuEditCopy_Click' code."
End Sub

Private Sub mnuEditCut_Click()
    frmSubjectItem.Show (1)
    'ToDo: Add 'mnuEditCut_Click' code.
    'MsgBox "Add 'mnuEditCut_Click' code."
End Sub

Private Sub mnuEditUndo_Click()
    'ToDo: Add 'mnuEditUndo_Click' code.
    MsgBox "Add 'mnuEditUndo_Click' code."
End Sub

Private Sub mnuFileExit_Click()
    'unload the form
    Unload Me

End Sub

