VERSION 5.00
Object = "{C37EFBE6-BC76-11D2-B65D-0000F87C2780}#1.0#0"; "CacheQuery.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form frmStudentRegistrationHistory 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "StudentRegistrationHistory"
   ClientHeight    =   2964
   ClientLeft      =   4440
   ClientTop       =   4788
   ClientWidth     =   6636
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3049.066
   ScaleMode       =   0  'User
   ScaleWidth      =   6601.126
   Begin VB.Frame fra_Main 
      BorderStyle     =   0  'None
      Caption         =   "fra_Main"
      Height          =   2895
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   6660
      Begin VB.CommandButton cmd__Exit 
         Caption         =   "E&xit"
         Height          =   385
         Left            =   5410
         TabIndex        =   18
         Top             =   2370
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Close 
         Caption         =   "&Close"
         Height          =   385
         Left            =   5410
         TabIndex        =   17
         Top             =   1980
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Delete 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   5410
         TabIndex        =   16
         Top             =   1500
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Save 
         Caption         =   "&Save"
         Height          =   385
         Left            =   5410
         TabIndex        =   15
         Top             =   1110
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Find 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   5410
         TabIndex        =   14
         Top             =   630
         Width           =   1095
      End
      Begin VB.CommandButton cmd__New 
         Caption         =   "&New"
         Height          =   385
         Left            =   5410
         TabIndex        =   13
         Top             =   240
         Width           =   1095
      End
      Begin VB.TextBox txtFaculty 
         Height          =   316
         Left            =   1176
         TabIndex        =   12
         Text            =   "txtFaculty"
         Top             =   1985
         Width           =   4021
      End
      Begin VB.TextBox txtMajorName 
         Height          =   316
         Left            =   1176
         TabIndex        =   10
         Text            =   "txtMajorName"
         Top             =   1635
         Width           =   4021
      End
      Begin VB.TextBox txtStdSurname 
         Height          =   316
         Left            =   1176
         TabIndex        =   8
         Text            =   "txtStdSurname"
         Top             =   1285
         Width           =   4021
      End
      Begin VB.TextBox txtStdName 
         Height          =   316
         Left            =   1176
         TabIndex        =   6
         Text            =   "txtStdName"
         Top             =   934
         Width           =   4021
      End
      Begin VB.TextBox txtPreName 
         Height          =   316
         Left            =   1176
         TabIndex        =   4
         Text            =   "txtPreName"
         Top             =   584
         Width           =   4021
      End
      Begin VB.TextBox txtStdCode 
         Height          =   316
         Left            =   1176
         TabIndex        =   2
         Text            =   "txtStdCode"
         Top             =   234
         Width           =   4021
      End
      Begin VB.Label lblStdCode 
         Alignment       =   1  'Right Justify
         Caption         =   "StdCode"
         Height          =   325
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   930
      End
      Begin VB.Label lblPreName 
         Alignment       =   1  'Right Justify
         Caption         =   "PreName"
         Height          =   325
         Left            =   120
         TabIndex        =   3
         Top             =   600
         Width           =   930
      End
      Begin VB.Label lblStdName 
         Alignment       =   1  'Right Justify
         Caption         =   "StdName"
         Height          =   325
         Left            =   120
         TabIndex        =   5
         Top             =   960
         Width           =   930
      End
      Begin VB.Label lblStdSurname 
         Alignment       =   1  'Right Justify
         Caption         =   "StdSurname"
         Height          =   325
         Left            =   120
         TabIndex        =   7
         Top             =   1320
         Width           =   930
      End
      Begin VB.Label lblMajorName 
         Alignment       =   1  'Right Justify
         Caption         =   "MajorName"
         Height          =   325
         Left            =   120
         TabIndex        =   9
         Top             =   1680
         Width           =   930
      End
      Begin VB.Label lblFaculty 
         Alignment       =   1  'Right Justify
         Caption         =   "Faculty"
         Height          =   325
         Left            =   120
         TabIndex        =   11
         Top             =   2040
         Width           =   930
      End
   End
   Begin VB.PictureBox picPatch 
      BorderStyle     =   0  'None
      Height          =   248
      Left            =   0
      ScaleHeight     =   252
      ScaleWidth      =   252
      TabIndex        =   21
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.VScrollBar VSCroll 
      Height          =   1168
      LargeChange     =   24
      Left            =   6660
      TabIndex        =   20
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.HScrollBar HSCroll 
      Height          =   248
      LargeChange     =   24
      Left            =   0
      TabIndex        =   19
      Top             =   2895
      Visible         =   0   'False
      Width           =   1206
   End
   Begin CACHEQUERYLib.CacheQuery CacheQuery1 
      Left            =   2736
      Top             =   1200
      _Version        =   65536
      _ExtentX        =   677
      _ExtentY        =   677
      _StockProps     =   0
      ClassName       =   ""
      QueryName       =   ""
   End
   Begin MSComDlg.CommonDialog dlgCommon 
      Left            =   2730
      Top             =   1200
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuObject 
      Caption         =   "&Object"
      Begin VB.Menu mnu__New 
         Caption         =   "&New"
      End
      Begin VB.Menu mnu__Find 
         Caption         =   "&Find..."
      End
      Begin VB.Menu mnu__Bar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Save 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnu__Delete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnu__Close 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnu__Bar2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Exit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "frmStudentRegistrationHistory"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const m_classname = "Registration.StudentRegistrationHistory"

Private m_factory As Object
Private m_object As Object
Private m_modified As Boolean
Private m_WaitFlag As Integer
Private id As Variant
Private disableclick As Boolean

Private Sub cmd__Close_Click()
    actionClose

End Sub

Private Sub cmd__Delete_Click()
    actionDelete

End Sub

Private Sub cmd__Exit_Click()
    actionExit

End Sub

Private Sub cmd__Find_Click()
    actionFind

End Sub

Private Sub cmd__New_Click()
    actionNew

End Sub

Private Sub cmd__Save_Click()
    actionSave

End Sub

Private Sub Form_Load()
    Dim sdir As String
    actionClose
    Set m_factory = CacheForm.Factory
'    sdir = m_factory.ConnectDlg
'    If sdir <> "" Then
'        m_factory.connect sdir
'    Else
'        End
'    End If
End Sub

Private Sub Form_Resize()
picPatch.Visible = False
If Me.ScaleWidth < fra_Main.Width Then
    HSCroll.Top = Me.ScaleHeight - HSCroll.Height
    HSCroll.Width = Me.ScaleWidth
    HSCroll.max = (fra_Main.Width - Me.ScaleWidth) \ 15
    HSCroll.Visible = True
    HSCroll.ZOrder
    If Me.ScaleHeight - HSCroll.Height < fra_Main.Height Then
        HSCroll.Width = Me.ScaleWidth - VSCroll.Width
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight - HSCroll.Height
        HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        picPatch.Top = HSCroll.Top
        picPatch.Left = HSCroll.Width
        picPatch.Visible = True
        picPatch.ZOrder
    Else
        VSCroll.Visible = False
    End If
Else
   HSCroll.Visible = False
    If Me.ScaleHeight < fra_Main.Height Then
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        If Me.ScaleWidth - VSCroll.Width < fra_Main.Width Then
            VSCroll.Height = Me.ScaleHeight - HSCroll.Height
            HSCroll.Top = Me.ScaleHeight - HSCroll.Height
            HSCroll.Width = Me.ScaleWidth - VSCroll.Width
            VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
            HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
            HSCroll.Visible = True
            HSCroll.ZOrder
            picPatch.Top = HSCroll.Top
            picPatch.Left = HSCroll.Width
            picPatch.Visible = True
            picPatch.ZOrder
        End If
    Else
        VSCroll.Visible = False
    End If
End If
End Sub

Private Sub HScroll_Change()
    fra_Main.Left = -HSCroll.Value * 15
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

Private Sub mnu__Close_Click()
    actionClose

End Sub

Private Sub mnu__Delete_Click()
    actionDelete

End Sub

Private Sub mnu__Exit_Click()
    actionExit

End Sub

Private Sub mnu__Find_Click()
    actionFind

End Sub

Private Sub mnu__New_Click()
    actionNew

End Sub

Private Sub mnu__Save_Click()
    actionSave

End Sub

Private Sub txtFaculty_Change()
    m_modified = True

End Sub

Private Sub txtMajorName_Change()
    m_modified = True

End Sub

Private Sub txtPreName_Change()
    m_modified = True

End Sub

Private Sub txtStdCode_Change()
    m_modified = True

End Sub

Private Sub txtStdName_Change()
    m_modified = True

End Sub

Private Sub txtStdSurname_Change()
    m_modified = True

End Sub

Private Sub VScroll_Change()
    fra_Main.Top = -VSCroll.Value * 15
End Sub

Private Sub VScroll_Scroll()
    VScroll_Change
End Sub

Private Sub actionNew()
    actionClose
    Set m_object = m_factory.New(m_classname)
    If m_object Is Nothing Then
         MsgBox "Cannot create new object."
         actionClose
    Else
         EnableScreen True
         SyncObjectToScreen
         m_modified = True
         cmd__Delete.Enabled = False
         mnu__Delete.Enabled = False
    End If
End Sub

Private Sub actionFind()
    actionClose
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = m_classname
    id = CacheQuery1.FindId
    If id = "" Then Exit Sub
    Set m_object = m_factory.OpenId(m_classname, id)
    If m_object Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableScreen True
        SyncObjectToScreen
        m_modified = False
    End If
End Sub

Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDelete()
    If id = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObject
    On Error GoTo actionDeleteError
    BeginWait
    m_object.sys_DeleteId (id)
    actionClose
    EndWait
    m_modified = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_object Is Nothing Then
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    id = ""
    m_modified = False
End Sub

Private Sub actionExit()
    actionClose
    Unload Me
End Sub

Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

Private Function minmax(val As Long, min As Long, max As Long)
    minmax = val
    If min <> -1 And val < min Then minmax = min
    If max <> -1 And val > max Then minmax = max
End Function

Public Sub ListView_ColumnClick(hList As ListView, ByVal ColumnHeader As MSComctlLib.ColumnHeader)
    'Handle any listview
    If hList.Sorted = False Then
       hList.Sorted = True
       hList.SortKey = ColumnHeader.Index - 1
       hList.SortOrder = lvwAscending
       Exit Sub
    End If
    If hList.SortKey = (ColumnHeader.Index - 1) Then
        If hList.SortOrder = lvwAscending Then
            hList.SortOrder = lvwDescending
        Else
            hList.SortOrder = lvwAscending
        End If
    Else
        hList.SortKey = ColumnHeader.Index - 1
    End If
End Sub
Private Sub EnableScreen(Enabled As Boolean)
    lblStdCode.Enabled = Enabled
    txtStdCode.Enabled = Enabled
    lblPreName.Enabled = Enabled
    txtPreName.Enabled = Enabled
    lblStdName.Enabled = Enabled
    txtStdName.Enabled = Enabled
    lblStdSurname.Enabled = Enabled
    txtStdSurname.Enabled = Enabled
    lblMajorName.Enabled = Enabled
    txtMajorName.Enabled = Enabled
    lblFaculty.Enabled = Enabled
    txtFaculty.Enabled = Enabled
    mnu__Save.Enabled = Enabled
    mnu__Close.Enabled = Enabled
    mnu__Delete.Enabled = Enabled
    cmd__Save.Enabled = Enabled
    cmd__Close.Enabled = Enabled
    cmd__Delete.Enabled = Enabled
End Sub

Private Sub EraseScreen()
    txtStdCode.Text = ""
    txtPreName.Text = ""
    txtStdName.Text = ""
    txtStdSurname.Text = ""
    txtMajorName.Text = ""
    txtFaculty.Text = ""
End Sub

Private Sub SyncObjectToScreen()
    Dim obj As Object
    Dim i As Integer
    Dim Item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtStdCode.Text = m_object.StdCode
    txtPreName.Text = m_object.PreName
    txtStdName.Text = m_object.StdName
    txtStdSurname.Text = m_object.StdSurname
    txtMajorName.Text = m_object.MajorName
    txtFaculty.Text = m_object.Faculty
End Sub

Private Sub SyncScreenToObject()
    m_object.StdCode = txtStdCode.Text
    m_object.PreName = txtPreName.Text
    m_object.StdName = txtStdName.Text
    m_object.StdSurname = txtStdSurname.Text
    m_object.MajorName = txtMajorName.Text
    m_object.Faculty = txtFaculty.Text
End Sub

