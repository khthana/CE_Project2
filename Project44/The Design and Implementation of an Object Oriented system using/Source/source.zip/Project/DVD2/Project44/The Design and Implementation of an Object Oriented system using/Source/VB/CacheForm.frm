VERSION 5.00
Begin VB.Form CacheForm 
   Caption         =   "Cache VB Application"
   ClientHeight    =   3195
   ClientLeft      =   5145
   ClientTop       =   4545
   ClientWidth     =   4680
   Icon            =   "CacheForm.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
End
Attribute VB_Name = "CacheForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Template Cache VB Project
Option Explicit

' variables used by Cache connection
' Factory is the connection to the Cache Server
Public Factory As CacheObject.Factory

' m_WaitFlag is used for managing the hourglass cursor
Private m_WaitFlag As Integer

Private Sub Form_Load()

    'initialize variables
    m_WaitFlag = 0
   
    ' If no factory, connect to Cache Server
    If Factory Is Nothing Then
        If ConnectToCache("") = False Then
            MsgBox "Unable to connect to Cache Server.", vbCritical
            Exit Sub
        End If
    End If
    
    ' User FormLoad code
    Me.Hide
    frmMain.Show (1)
    Unload Me
End Sub

Function ConnectToCache(connect As String) As Boolean
    
    ' Establish connection to Cache Database using Factory object
    Set Factory = CreateObject("CacheObject.Factory")

    If connect = "" Then
        connect = Factory.ConnectDlg("Choose Cache System to Connect to:")
        If connect = "" Then
            ConnectToCache = False
            Exit Function
        End If
    End If

    ' Change mouse pointer to hourglass during connect
    BeginWait
    
    ' Connect
    If (Factory.connect(connect) = False) Then
        ' Return mouse pointer to normal.
        EndWait

        ConnectToCache = False
        Exit Function
    End If
    
    ' Return mouse pointer to normal.
    EndWait

    ConnectToCache = True

End Function

Private Sub BeginWait()

    ' turn on the hourglass cursor;
    ' you can nest calls to BeginWait-the cursor is restored
    ' after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    ' Turn off hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub
    
    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

