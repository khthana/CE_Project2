VERSION 5.00
Object = "{C37EFBE6-BC76-11D2-B65D-0000F87C2780}#1.0#0"; "CacheQuery.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form frmPerson 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Person"
   ClientHeight    =   4248
   ClientLeft      =   4692
   ClientTop       =   4140
   ClientWidth     =   6948
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4320
   ScaleMode       =   0  'User
   ScaleWidth      =   6910
   Begin VB.Frame fra_Main 
      BorderStyle     =   0  'None
      Caption         =   "fra_Main"
      Height          =   4245
      Left            =   0
      TabIndex        =   3
      Top             =   0
      Width           =   6945
      Begin VB.CommandButton cmd__Exit 
         Caption         =   "Cancel"
         Height          =   385
         Left            =   5695
         TabIndex        =   31
         Top             =   2370
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Close 
         Caption         =   "&Close"
         Height          =   385
         Left            =   5695
         TabIndex        =   30
         Top             =   1980
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Delete 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   5695
         TabIndex        =   29
         Top             =   1500
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Save 
         Caption         =   "&Save"
         Height          =   385
         Left            =   5695
         TabIndex        =   28
         Top             =   1110
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Find 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   5695
         TabIndex        =   27
         Top             =   630
         Width           =   1095
      End
      Begin VB.CommandButton cmd__New 
         Caption         =   "&New"
         Height          =   385
         Left            =   5695
         TabIndex        =   26
         Top             =   240
         Width           =   1095
      End
      Begin VB.TextBox txtReligion 
         Height          =   319
         Left            =   1462
         TabIndex        =   25
         Text            =   "txtReligion"
         Top             =   3773
         Width           =   4020
      End
      Begin VB.TextBox txtNation 
         Height          =   319
         Left            =   1462
         TabIndex        =   23
         Text            =   "txtNation"
         Top             =   3420
         Width           =   4020
      End
      Begin VB.TextBox txtCitizen 
         Height          =   319
         Left            =   1462
         TabIndex        =   21
         Text            =   "txtCitizen"
         Top             =   3066
         Width           =   4020
      End
      Begin VB.TextBox txtBlood 
         Height          =   319
         Left            =   1462
         TabIndex        =   19
         Text            =   "txtBlood"
         Top             =   2712
         Width           =   4020
      End
      Begin VB.TextBox txtWeight 
         Height          =   319
         Left            =   1462
         TabIndex        =   17
         Text            =   "txtWeight"
         Top             =   2358
         Width           =   1176
      End
      Begin VB.TextBox txtHight 
         Height          =   319
         Left            =   1462
         TabIndex        =   15
         Text            =   "txtHight"
         Top             =   2005
         Width           =   1176
      End
      Begin VB.TextBox txtBirthDay 
         Height          =   319
         Left            =   1462
         TabIndex        =   13
         Text            =   "txtBirthDay"
         Top             =   1651
         Width           =   1176
      End
      Begin VB.TextBox txtSurname 
         Height          =   319
         Left            =   1462
         TabIndex        =   11
         Text            =   "txtSurname"
         Top             =   1297
         Width           =   4020
      End
      Begin VB.TextBox txtName 
         Height          =   319
         Left            =   1462
         TabIndex        =   9
         Text            =   "txtName"
         Top             =   943
         Width           =   4020
      End
      Begin VB.TextBox txtGender 
         Height          =   319
         Left            =   1462
         TabIndex        =   7
         Text            =   "txtGender"
         Top             =   590
         Width           =   4020
      End
      Begin VB.TextBox txtIdentifierNumber 
         Height          =   319
         Left            =   1462
         TabIndex        =   5
         Text            =   "txtIdentifierNumber"
         Top             =   236
         Width           =   4020
      End
      Begin VB.Label lblIdentifierNumber 
         Caption         =   "IdentifierNumber"
         Height          =   325
         Left            =   120
         TabIndex        =   4
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label lblGender 
         Caption         =   "Gender"
         Height          =   325
         Left            =   120
         TabIndex        =   6
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label lblName 
         Caption         =   "Name"
         Height          =   325
         Left            =   120
         TabIndex        =   8
         Top             =   960
         Width           =   1215
      End
      Begin VB.Label lblSurname 
         Caption         =   "Surname"
         Height          =   325
         Left            =   120
         TabIndex        =   10
         Top             =   1320
         Width           =   1215
      End
      Begin VB.Label lblBirthDay 
         Caption         =   "BirthDay"
         Height          =   325
         Left            =   120
         TabIndex        =   12
         Top             =   1680
         Width           =   1215
      End
      Begin VB.Label lblHight 
         Caption         =   "Hight"
         Height          =   325
         Left            =   120
         TabIndex        =   14
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label lblWeight 
         Caption         =   "Weight"
         Height          =   325
         Left            =   120
         TabIndex        =   16
         Top             =   2400
         Width           =   1215
      End
      Begin VB.Label lblBlood 
         Caption         =   "Blood"
         Height          =   325
         Left            =   120
         TabIndex        =   18
         Top             =   2760
         Width           =   1215
      End
      Begin VB.Label lblCitizen 
         Caption         =   "Citizen"
         Height          =   325
         Left            =   120
         TabIndex        =   20
         Top             =   3120
         Width           =   1215
      End
      Begin VB.Label lblNation 
         Caption         =   "Nation"
         Height          =   325
         Left            =   120
         TabIndex        =   22
         Top             =   3480
         Width           =   1215
      End
      Begin VB.Label lblReligion 
         Caption         =   "Religion"
         Height          =   325
         Left            =   120
         TabIndex        =   24
         Top             =   3840
         Width           =   1215
      End
   End
   Begin VB.PictureBox picPatch 
      BorderStyle     =   0  'None
      Height          =   251
      Left            =   0
      ScaleHeight     =   252
      ScaleWidth      =   252
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.VScrollBar VSCroll 
      Height          =   1179
      LargeChange     =   24
      Left            =   6945
      TabIndex        =   1
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.HScrollBar HSCroll 
      Height          =   251
      LargeChange     =   24
      Left            =   0
      TabIndex        =   0
      Top             =   4245
      Visible         =   0   'False
      Width           =   1206
   End
   Begin CACHEQUERYLib.CacheQuery CacheQuery1 
      Left            =   2868
      Top             =   1872
      _Version        =   65536
      _ExtentX        =   677
      _ExtentY        =   677
      _StockProps     =   0
      ClassName       =   ""
      QueryName       =   ""
   End
   Begin MSComDlg.CommonDialog dlgCommon 
      Left            =   2865
      Top             =   1875
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuObject 
      Caption         =   "&Object"
      Begin VB.Menu mnu__New 
         Caption         =   "&New"
      End
      Begin VB.Menu mnu__Find 
         Caption         =   "&Find..."
      End
      Begin VB.Menu mnu__Bar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Save 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnu__Delete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnu__Close 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnu__Bar2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Exit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "frmPerson"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const m_classname = "PersonInfo.Person"

Private m_factory As Object
Private m_object As Object
Private m_modified As Boolean
Private m_WaitFlag As Integer
Private id As Variant
Private disableclick As Boolean

Private Sub cmd__Close_Click()
    actionClose

End Sub

Private Sub cmd__Delete_Click()
    actionDelete

End Sub

Private Sub cmd__Exit_Click()
    actionExit

End Sub

Private Sub cmd__Find_Click()
    actionFind

End Sub

Private Sub cmd__New_Click()
    actionNew

End Sub

Private Sub cmd__Save_Click()
    actionSave

End Sub

Private Sub Form_Load()
    Dim sdir As String
    actionClose
    Set m_factory = CacheForm.Factory
'    sdir = m_factory.ConnectDlg
'    If sdir <> "" Then
'        m_factory.connect sdir
'    Else
'        End
'    End If
End Sub

Private Sub Form_Resize()
picPatch.Visible = False
If Me.ScaleWidth < fra_Main.Width Then
    HSCroll.Top = Me.ScaleHeight - HSCroll.Height
    HSCroll.Width = Me.ScaleWidth
    HSCroll.max = (fra_Main.Width - Me.ScaleWidth) \ 15
    HSCroll.Visible = True
    HSCroll.ZOrder
    If Me.ScaleHeight - HSCroll.Height < fra_Main.Height Then
        HSCroll.Width = Me.ScaleWidth - VSCroll.Width
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight - HSCroll.Height
        HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        picPatch.Top = HSCroll.Top
        picPatch.Left = HSCroll.Width
        picPatch.Visible = True
        picPatch.ZOrder
    Else
        VSCroll.Visible = False
    End If
Else
   HSCroll.Visible = False
    If Me.ScaleHeight < fra_Main.Height Then
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        If Me.ScaleWidth - VSCroll.Width < fra_Main.Width Then
            VSCroll.Height = Me.ScaleHeight - HSCroll.Height
            HSCroll.Top = Me.ScaleHeight - HSCroll.Height
            HSCroll.Width = Me.ScaleWidth - VSCroll.Width
            VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
            HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
            HSCroll.Visible = True
            HSCroll.ZOrder
            picPatch.Top = HSCroll.Top
            picPatch.Left = HSCroll.Width
            picPatch.Visible = True
            picPatch.ZOrder
        End If
    Else
        VSCroll.Visible = False
    End If
End If
End Sub

Private Sub HScroll_Change()
    fra_Main.Left = -HSCroll.Value * 15
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

Private Sub mnu__Close_Click()
    actionClose

End Sub

Private Sub mnu__Delete_Click()
    actionDelete

End Sub

Private Sub mnu__Exit_Click()
    actionExit

End Sub

Private Sub mnu__Find_Click()
    actionFind

End Sub

Private Sub mnu__New_Click()
    actionNew

End Sub

Private Sub mnu__Save_Click()
    actionSave

End Sub

Private Sub txtBirthDay_Change()
    m_modified = True

End Sub

Private Sub txtBlood_Change()
    m_modified = True

End Sub

Private Sub txtCitizen_Change()
    m_modified = True

End Sub

Private Sub txtGender_Change()
    m_modified = True

End Sub

Private Sub txtHight_Change()
    m_modified = True

End Sub

Private Sub txtIdentifierNumber_Change()
    m_modified = True

End Sub

Private Sub txtName_Change()
    m_modified = True

End Sub

Private Sub txtNation_Change()
    m_modified = True

End Sub

Private Sub txtReligion_Change()
    m_modified = True

End Sub

Private Sub txtSurname_Change()
    m_modified = True

End Sub

Private Sub txtWeight_Change()
    m_modified = True

End Sub

Private Sub VScroll_Change()
    fra_Main.Top = -VSCroll.Value * 15
End Sub

Private Sub VScroll_Scroll()
    VScroll_Change
End Sub

Private Sub actionNew()
    actionClose
    Set m_object = m_factory.New(m_classname)
    If m_object Is Nothing Then
         MsgBox "Cannot create new object."
         actionClose
    Else
         EnableScreen True
         SyncObjectToScreen
         m_modified = True
         cmd__Delete.Enabled = False
         mnu__Delete.Enabled = False
    End If
End Sub

Private Sub actionFind()
    actionClose
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = m_classname
    id = CacheQuery1.FindId
    If id = "" Then Exit Sub
    Set m_object = m_factory.OpenId(m_classname, id)
    If m_object Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableScreen True
        SyncObjectToScreen
        m_modified = False
    End If
End Sub

Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDelete()
    If id = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObject
    On Error GoTo actionDeleteError
    BeginWait
    m_object.sys_DeleteId (id)
    actionClose
    EndWait
    m_modified = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_object Is Nothing Then
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    id = ""
    m_modified = False
End Sub

Private Sub actionExit()
    actionClose
    Unload Me
End Sub

Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

Private Function minmax(val As Long, min As Long, max As Long)
    minmax = val
    If min <> -1 And val < min Then minmax = min
    If max <> -1 And val > max Then minmax = max
End Function

Public Sub ListView_ColumnClick(hList As ListView, ByVal ColumnHeader As MSComctlLib.ColumnHeader)
    'Handle any listview
    If hList.Sorted = False Then
       hList.Sorted = True
       hList.SortKey = ColumnHeader.Index - 1
       hList.SortOrder = lvwAscending
       Exit Sub
    End If
    If hList.SortKey = (ColumnHeader.Index - 1) Then
        If hList.SortOrder = lvwAscending Then
            hList.SortOrder = lvwDescending
        Else
            hList.SortOrder = lvwAscending
        End If
    Else
        hList.SortKey = ColumnHeader.Index - 1
    End If
End Sub
Private Sub EnableScreen(Enabled As Boolean)
    lblIdentifierNumber.Enabled = Enabled
    txtIdentifierNumber.Enabled = Enabled
    lblGender.Enabled = Enabled
    txtGender.Enabled = Enabled
    lblName.Enabled = Enabled
    txtName.Enabled = Enabled
    lblSurname.Enabled = Enabled
    txtSurname.Enabled = Enabled
    lblBirthDay.Enabled = Enabled
    txtBirthDay.Enabled = Enabled
    lblHight.Enabled = Enabled
    txtHight.Enabled = Enabled
    lblWeight.Enabled = Enabled
    txtWeight.Enabled = Enabled
    lblBlood.Enabled = Enabled
    txtBlood.Enabled = Enabled
    lblCitizen.Enabled = Enabled
    txtCitizen.Enabled = Enabled
    lblNation.Enabled = Enabled
    txtNation.Enabled = Enabled
    lblReligion.Enabled = Enabled
    txtReligion.Enabled = Enabled
    mnu__Save.Enabled = Enabled
    mnu__Close.Enabled = Enabled
    mnu__Delete.Enabled = Enabled
    cmd__Save.Enabled = Enabled
    cmd__Close.Enabled = Enabled
    cmd__Delete.Enabled = Enabled
End Sub

Private Sub EraseScreen()
    txtIdentifierNumber.Text = ""
    txtGender.Text = ""
    txtName.Text = ""
    txtSurname.Text = ""
    txtBirthDay.Text = ""
    txtHight.Text = ""
    txtWeight.Text = ""
    txtBlood.Text = ""
    txtCitizen.Text = ""
    txtNation.Text = ""
    txtReligion.Text = ""
End Sub

Private Sub SyncObjectToScreen()
    Dim obj As Object
    Dim i As Integer
    Dim Item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtIdentifierNumber.Text = m_object.IdentifierNumber
    txtGender.Text = m_object.Gender
    txtName.Text = m_object.Name
    txtSurname.Text = m_object.Surname
    If m_object.BirthDay <> 0 Then
       txtBirthDay.Text = m_object.BirthDay
    Else
       txtBirthDay.Text = ""
    End If
    txtHight.Text = m_object.Hight
    txtWeight.Text = m_object.Weight
    txtBlood.Text = m_object.Blood
    txtCitizen.Text = m_object.Citizen
    txtNation.Text = m_object.Nation
    txtReligion.Text = m_object.Religion
End Sub

Private Sub SyncScreenToObject()
    m_object.IdentifierNumber = txtIdentifierNumber.Text
    m_object.Gender = txtGender.Text
    m_object.Name = txtName.Text
    m_object.Surname = txtSurname.Text
    m_object.BirthDay = txtBirthDay.Text
    m_object.Hight = txtHight.Text
    m_object.Weight = txtWeight.Text
    m_object.Blood = txtBlood.Text
    m_object.Citizen = txtCitizen.Text
    m_object.Nation = txtNation.Text
    m_object.Religion = txtReligion.Text
End Sub

