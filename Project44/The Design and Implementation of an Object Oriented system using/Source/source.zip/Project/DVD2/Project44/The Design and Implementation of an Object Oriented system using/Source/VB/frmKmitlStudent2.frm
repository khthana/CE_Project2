VERSION 5.00
Object = "{C37EFBE6-BC76-11D2-B65D-0000F87C2780}#1.0#0"; "CACHEQUERY.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form frmKmitlStudent2 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "KmitlStudent"
   ClientHeight    =   5040
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   12120
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5122.085
   ScaleMode       =   0  'User
   ScaleWidth      =   12078.09
   StartUpPosition =   2  'CenterScreen
   Begin TabDlg.SSTab SSTab1 
      Height          =   4815
      Left            =   120
      TabIndex        =   10
      Top             =   120
      Width           =   10455
      _ExtentX        =   18441
      _ExtentY        =   8493
      _Version        =   393216
      Style           =   1
      Tabs            =   6
      Tab             =   4
      TabsPerRow      =   6
      TabHeight       =   520
      TabCaption(0)   =   "Private"
      TabPicture(0)   =   "frmKmitlStudent2.frx":0000
      Tab(0).ControlEnabled=   0   'False
      Tab(0).Control(0)=   "lblBirthDay"
      Tab(0).Control(1)=   "lblBlood"
      Tab(0).Control(2)=   "lblCitizen"
      Tab(0).Control(3)=   "lblGender"
      Tab(0).Control(4)=   "lblGenderEng"
      Tab(0).Control(5)=   "lblHight"
      Tab(0).Control(6)=   "lblIdentifierNumber"
      Tab(0).Control(7)=   "lblName"
      Tab(0).Control(8)=   "lblNameEng"
      Tab(0).Control(9)=   "lblNation"
      Tab(0).Control(10)=   "lblReligion"
      Tab(0).Control(11)=   "lblStdCode"
      Tab(0).Control(12)=   "lblSurNameEng"
      Tab(0).Control(13)=   "lblSurname"
      Tab(0).Control(14)=   "lblWeight"
      Tab(0).Control(15)=   "lblDegreeName"
      Tab(0).Control(16)=   "lblMajorNameEng"
      Tab(0).Control(17)=   "lblMajorNameThai"
      Tab(0).Control(18)=   "lblSchoolName"
      Tab(0).Control(19)=   "txtStdCode"
      Tab(0).Control(20)=   "txtWeight"
      Tab(0).Control(21)=   "txtSurname"
      Tab(0).Control(22)=   "txtSurNameEng"
      Tab(0).Control(23)=   "txtReligion"
      Tab(0).Control(24)=   "txtNation"
      Tab(0).Control(25)=   "txtNameEng"
      Tab(0).Control(26)=   "txtName"
      Tab(0).Control(27)=   "txtIdentifierNumber"
      Tab(0).Control(28)=   "txtHight"
      Tab(0).Control(29)=   "txtGenderEng"
      Tab(0).Control(30)=   "txtGender"
      Tab(0).Control(31)=   "txtCitizen"
      Tab(0).Control(32)=   "txtBlood"
      Tab(0).Control(33)=   "txtBirthDay"
      Tab(0).Control(34)=   "txtMajorNameThai"
      Tab(0).Control(35)=   "txtMajorNameEng"
      Tab(0).Control(36)=   "txtDegreeName"
      Tab(0).Control(37)=   "txtSchoolName"
      Tab(0).ControlCount=   38
      TabCaption(1)   =   "StdData"
      TabPicture(1)   =   "frmKmitlStudent2.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "txtDateOfAdmission"
      Tab(1).Control(1)=   "txtPreDegreeName"
      Tab(1).Control(2)=   "txtPreTotalUnit"
      Tab(1).Control(3)=   "txtCurrentStatus"
      Tab(1).Control(4)=   "txtDateOfGraduation"
      Tab(1).Control(5)=   "txtGPA"
      Tab(1).Control(6)=   "txtPreGPA"
      Tab(1).Control(7)=   "txtPreSchoolName"
      Tab(1).Control(8)=   "txtPreSchoolProvince"
      Tab(1).Control(9)=   "txtSchoolProvince"
      Tab(1).Control(10)=   "txtStudiedUnit"
      Tab(1).Control(11)=   "txtTotalUnit"
      Tab(1).Control(12)=   "txtTransferUnit"
      Tab(1).Control(13)=   "txtYearEnter"
      Tab(1).Control(14)=   "txtYearGraduate"
      Tab(1).Control(15)=   "lblPreDegreeName"
      Tab(1).Control(16)=   "lblYearGraduate"
      Tab(1).Control(17)=   "lblYearEnter"
      Tab(1).Control(18)=   "lblTransferUnit"
      Tab(1).Control(19)=   "lblTotalUnit"
      Tab(1).Control(20)=   "lblStudiedUnit"
      Tab(1).Control(21)=   "lblSchoolProvince"
      Tab(1).Control(22)=   "lblPreTotalUnit"
      Tab(1).Control(23)=   "lblPreSchoolProvince"
      Tab(1).Control(24)=   "lblPreSchoolName"
      Tab(1).Control(25)=   "lblPreGPA"
      Tab(1).Control(26)=   "lblGPA"
      Tab(1).Control(27)=   "lblDateOfGraduation"
      Tab(1).Control(28)=   "lblDateOfAdmission"
      Tab(1).Control(29)=   "lblCurrentStatus"
      Tab(1).ControlCount=   30
      TabCaption(2)   =   "Address"
      TabPicture(2)   =   "frmKmitlStudent2.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "txtAddressSubdivision"
      Tab(2).Control(1)=   "txtAddressSoy"
      Tab(2).Control(2)=   "txtAddressProvince"
      Tab(2).Control(3)=   "txtAddressRd"
      Tab(2).Control(4)=   "txtAddressPostzip"
      Tab(2).Control(5)=   "txtAddressMoo"
      Tab(2).Control(6)=   "txtAddressEmailAddr"
      Tab(2).Control(7)=   "txtAddressAddrDetail"
      Tab(2).Control(8)=   "lblAddressSubdivision"
      Tab(2).Control(9)=   "lblAddressSoy"
      Tab(2).Control(10)=   "lblAddressProvince"
      Tab(2).Control(11)=   "lblAddressRd"
      Tab(2).Control(12)=   "lblAddressPostzip"
      Tab(2).Control(13)=   "lblAddressMoo"
      Tab(2).Control(14)=   "lblAddressEmailAddr"
      Tab(2).Control(15)=   "lblAddressAddrDetail"
      Tab(2).ControlCount=   16
      TabCaption(3)   =   "Father"
      TabPicture(3)   =   "frmKmitlStudent2.frx":0054
      Tab(3).ControlEnabled=   0   'False
      Tab(3).Control(0)=   "txtIdentifierNumberFather"
      Tab(3).Control(1)=   "txtGenderFather"
      Tab(3).Control(2)=   "txtNameFather"
      Tab(3).Control(3)=   "txtSurnameFather"
      Tab(3).Control(4)=   "txtBirthDayFather"
      Tab(3).Control(5)=   "txtHightFather"
      Tab(3).Control(6)=   "txtWeightFather"
      Tab(3).Control(7)=   "txtBloodFather"
      Tab(3).Control(8)=   "txtCitizenFather"
      Tab(3).Control(9)=   "txtNationFather"
      Tab(3).Control(10)=   "txtReligionFather"
      Tab(3).Control(11)=   "cmd__NewFather"
      Tab(3).Control(12)=   "cmd__FindFather"
      Tab(3).Control(13)=   "cmd__SaveFather"
      Tab(3).Control(14)=   "cmd__DeleteFather"
      Tab(3).Control(15)=   "cmd__CloseFather"
      Tab(3).Control(16)=   "lblReligionFather"
      Tab(3).Control(17)=   "lblNationFather"
      Tab(3).Control(18)=   "lblCitizenFather"
      Tab(3).Control(19)=   "lblBloodFather"
      Tab(3).Control(20)=   "lblWeightFather"
      Tab(3).Control(21)=   "lblHightFather"
      Tab(3).Control(22)=   "lblBirthDayFather"
      Tab(3).Control(23)=   "lblSurnameFather"
      Tab(3).Control(24)=   "lblNameFather"
      Tab(3).Control(25)=   "lblGenderFather"
      Tab(3).Control(26)=   "lblIdentifierNumberFather"
      Tab(3).ControlCount=   27
      TabCaption(4)   =   "Mother"
      TabPicture(4)   =   "frmKmitlStudent2.frx":0070
      Tab(4).ControlEnabled=   -1  'True
      Tab(4).Control(0)=   "lblIdentifierNumberMother"
      Tab(4).Control(0).Enabled=   0   'False
      Tab(4).Control(1)=   "lblGenderMother"
      Tab(4).Control(1).Enabled=   0   'False
      Tab(4).Control(2)=   "lblNameMother"
      Tab(4).Control(2).Enabled=   0   'False
      Tab(4).Control(3)=   "lblSurnameMother"
      Tab(4).Control(3).Enabled=   0   'False
      Tab(4).Control(4)=   "lblBirthDayMother"
      Tab(4).Control(4).Enabled=   0   'False
      Tab(4).Control(5)=   "lblHightMother"
      Tab(4).Control(5).Enabled=   0   'False
      Tab(4).Control(6)=   "lblWeightMother"
      Tab(4).Control(6).Enabled=   0   'False
      Tab(4).Control(7)=   "lblBloodMother"
      Tab(4).Control(7).Enabled=   0   'False
      Tab(4).Control(8)=   "lblCitizenMother"
      Tab(4).Control(8).Enabled=   0   'False
      Tab(4).Control(9)=   "lblNationMother"
      Tab(4).Control(9).Enabled=   0   'False
      Tab(4).Control(10)=   "lblReligionMother"
      Tab(4).Control(10).Enabled=   0   'False
      Tab(4).Control(11)=   "cmd__CloseMother"
      Tab(4).Control(11).Enabled=   0   'False
      Tab(4).Control(12)=   "cmd__DeleteMother"
      Tab(4).Control(12).Enabled=   0   'False
      Tab(4).Control(13)=   "cmd__SaveMother"
      Tab(4).Control(13).Enabled=   0   'False
      Tab(4).Control(14)=   "cmd__FindMother"
      Tab(4).Control(14).Enabled=   0   'False
      Tab(4).Control(15)=   "cmd__NewMother"
      Tab(4).Control(15).Enabled=   0   'False
      Tab(4).Control(16)=   "txtReligionMother"
      Tab(4).Control(16).Enabled=   0   'False
      Tab(4).Control(17)=   "txtNationMother"
      Tab(4).Control(17).Enabled=   0   'False
      Tab(4).Control(18)=   "txtCitizenMother"
      Tab(4).Control(18).Enabled=   0   'False
      Tab(4).Control(19)=   "txtBloodMother"
      Tab(4).Control(19).Enabled=   0   'False
      Tab(4).Control(20)=   "txtWeightMother"
      Tab(4).Control(20).Enabled=   0   'False
      Tab(4).Control(21)=   "txtHightMother"
      Tab(4).Control(21).Enabled=   0   'False
      Tab(4).Control(22)=   "txtBirthDayMother"
      Tab(4).Control(22).Enabled=   0   'False
      Tab(4).Control(23)=   "txtSurnameMother"
      Tab(4).Control(23).Enabled=   0   'False
      Tab(4).Control(24)=   "txtNameMother"
      Tab(4).Control(24).Enabled=   0   'False
      Tab(4).Control(25)=   "txtGenderMother"
      Tab(4).Control(25).Enabled=   0   'False
      Tab(4).Control(26)=   "txtIdentifierNumberMother"
      Tab(4).Control(26).Enabled=   0   'False
      Tab(4).ControlCount=   27
      TabCaption(5)   =   "Guardian"
      TabPicture(5)   =   "frmKmitlStudent2.frx":008C
      Tab(5).ControlEnabled=   0   'False
      Tab(5).Control(0)=   "cmd__CloseGuardian"
      Tab(5).Control(1)=   "cmd__DeleteGuardian"
      Tab(5).Control(2)=   "cmd__SaveGuardian"
      Tab(5).Control(3)=   "cmd__FindGuardian"
      Tab(5).Control(4)=   "cmd__NewGuardian"
      Tab(5).Control(5)=   "txtReligionGuardian"
      Tab(5).Control(6)=   "txtNationGuardian"
      Tab(5).Control(7)=   "txtCitizenGuardian"
      Tab(5).Control(8)=   "txtBloodGuardian"
      Tab(5).Control(9)=   "txtWeightGuardian"
      Tab(5).Control(10)=   "txtHightGuardian"
      Tab(5).Control(11)=   "txtBirthDayGuardian"
      Tab(5).Control(12)=   "txtSurnameGuardian"
      Tab(5).Control(13)=   "txtNameGuardian"
      Tab(5).Control(14)=   "txtGenderGuardian"
      Tab(5).Control(15)=   "txtIdentifierNumberGuardian"
      Tab(5).Control(16)=   "lblReligionGuardian"
      Tab(5).Control(17)=   "lblNationGuardian"
      Tab(5).Control(18)=   "lblCitizenGuardian"
      Tab(5).Control(19)=   "lblBloodGuardian"
      Tab(5).Control(20)=   "lblWeightGuardian"
      Tab(5).Control(21)=   "lblHightGuardian"
      Tab(5).Control(22)=   "lblBirthDayGuardian"
      Tab(5).Control(23)=   "lblSurnameGuardian"
      Tab(5).Control(24)=   "lblNameGuardian"
      Tab(5).Control(25)=   "lblGenderGuardian"
      Tab(5).Control(26)=   "lblIdentifierNumberGuardian"
      Tab(5).ControlCount=   27
      Begin VB.CommandButton cmd__CloseGuardian 
         Caption         =   "&Clean"
         Height          =   385
         Left            =   -68700
         TabIndex        =   175
         Top             =   2340
         Width           =   1095
      End
      Begin VB.CommandButton cmd__DeleteGuardian 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   -68700
         TabIndex        =   174
         Top             =   1860
         Width           =   1095
      End
      Begin VB.CommandButton cmd__SaveGuardian 
         Caption         =   "&Save"
         Height          =   385
         Left            =   -68700
         TabIndex        =   173
         Top             =   1470
         Width           =   1095
      End
      Begin VB.CommandButton cmd__FindGuardian 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   -68700
         TabIndex        =   172
         Top             =   990
         Width           =   1095
      End
      Begin VB.CommandButton cmd__NewGuardian 
         Caption         =   "&New"
         Height          =   385
         Left            =   -68700
         TabIndex        =   171
         Top             =   600
         Width           =   1095
      End
      Begin VB.TextBox txtReligionGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   170
         Text            =   "txtReligion"
         Top             =   4140
         Width           =   4020
      End
      Begin VB.TextBox txtNationGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   168
         Text            =   "txtNation"
         Top             =   3780
         Width           =   4020
      End
      Begin VB.TextBox txtCitizenGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   166
         Text            =   "txtCitizen"
         Top             =   3435
         Width           =   4020
      End
      Begin VB.TextBox txtBloodGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   164
         Text            =   "txtBlood"
         Top             =   3075
         Width           =   4020
      End
      Begin VB.TextBox txtWeightGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   162
         Text            =   "txtWeight"
         Top             =   2715
         Width           =   1176
      End
      Begin VB.TextBox txtHightGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   160
         Text            =   "txtHight"
         Top             =   2370
         Width           =   1176
      End
      Begin VB.TextBox txtBirthDayGuardian 
         Height          =   319
         Left            =   -72960
         TabIndex        =   158
         Text            =   "txtBirthDay"
         Top             =   2010
         Width           =   1176
      End
      Begin VB.TextBox txtSurnameGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   156
         Text            =   "txtSurname"
         Top             =   1665
         Width           =   4020
      End
      Begin VB.TextBox txtNameGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   154
         Text            =   "txtName"
         Top             =   1305
         Width           =   4020
      End
      Begin VB.TextBox txtGenderGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   152
         Text            =   "txtGender"
         Top             =   960
         Width           =   4020
      End
      Begin VB.TextBox txtIdentifierNumberGuardian 
         Height          =   319
         Left            =   -72945
         TabIndex        =   150
         Text            =   "txtIdentifierNumber"
         Top             =   600
         Width           =   4020
      End
      Begin VB.TextBox txtIdentifierNumberMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   137
         Text            =   "txtIdentifierNumber"
         Top             =   600
         Width           =   4020
      End
      Begin VB.TextBox txtGenderMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   136
         Text            =   "txtGender"
         Top             =   960
         Width           =   4020
      End
      Begin VB.TextBox txtNameMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   135
         Text            =   "txtName"
         Top             =   1305
         Width           =   4020
      End
      Begin VB.TextBox txtSurnameMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   134
         Text            =   "txtSurname"
         Top             =   1665
         Width           =   4020
      End
      Begin VB.TextBox txtBirthDayMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   133
         Text            =   "txtBirthDay"
         Top             =   2010
         Width           =   1176
      End
      Begin VB.TextBox txtHightMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   132
         Text            =   "txtHight"
         Top             =   2370
         Width           =   1176
      End
      Begin VB.TextBox txtWeightMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   131
         Text            =   "txtWeight"
         Top             =   2715
         Width           =   1176
      End
      Begin VB.TextBox txtBloodMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   130
         Text            =   "txtBlood"
         Top             =   3075
         Width           =   4020
      End
      Begin VB.TextBox txtCitizenMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   129
         Text            =   "txtCitizen"
         Top             =   3435
         Width           =   4020
      End
      Begin VB.TextBox txtNationMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   128
         Text            =   "txtNation"
         Top             =   3780
         Width           =   4020
      End
      Begin VB.TextBox txtReligionMother 
         Height          =   319
         Left            =   2055
         TabIndex        =   127
         Text            =   "txtReligion"
         Top             =   4140
         Width           =   4020
      End
      Begin VB.CommandButton cmd__NewMother 
         Caption         =   "&New"
         Height          =   385
         Left            =   6300
         TabIndex        =   126
         Top             =   600
         Width           =   1095
      End
      Begin VB.CommandButton cmd__FindMother 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   6300
         TabIndex        =   125
         Top             =   990
         Width           =   1095
      End
      Begin VB.CommandButton cmd__SaveMother 
         Caption         =   "&Save"
         Height          =   385
         Left            =   6300
         TabIndex        =   124
         Top             =   1470
         Width           =   1095
      End
      Begin VB.CommandButton cmd__DeleteMother 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   6300
         TabIndex        =   123
         Top             =   1860
         Width           =   1095
      End
      Begin VB.CommandButton cmd__CloseMother 
         Caption         =   "&Clean"
         Height          =   385
         Left            =   6300
         TabIndex        =   122
         Top             =   2340
         Width           =   1095
      End
      Begin VB.TextBox txtIdentifierNumberFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   110
         Text            =   "txtIdentifierNumber"
         Top             =   600
         Width           =   4020
      End
      Begin VB.TextBox txtGenderFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   109
         Text            =   "txtGender"
         Top             =   960
         Width           =   4020
      End
      Begin VB.TextBox txtNameFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   108
         Text            =   "txtName"
         Top             =   1305
         Width           =   4020
      End
      Begin VB.TextBox txtSurnameFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   107
         Text            =   "txtSurname"
         Top             =   1665
         Width           =   4020
      End
      Begin VB.TextBox txtBirthDayFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   106
         Text            =   "txtBirthDay"
         Top             =   2010
         Width           =   1176
      End
      Begin VB.TextBox txtHightFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   105
         Text            =   "txtHight"
         Top             =   2370
         Width           =   1176
      End
      Begin VB.TextBox txtWeightFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   104
         Text            =   "txtWeight"
         Top             =   2715
         Width           =   1176
      End
      Begin VB.TextBox txtBloodFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   103
         Text            =   "txtBlood"
         Top             =   3075
         Width           =   4020
      End
      Begin VB.TextBox txtCitizenFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   102
         Text            =   "txtCitizen"
         Top             =   3435
         Width           =   4020
      End
      Begin VB.TextBox txtNationFather 
         Height          =   319
         Left            =   -72960
         TabIndex        =   101
         Text            =   "txtNation"
         Top             =   3780
         Width           =   4020
      End
      Begin VB.TextBox txtReligionFather 
         Height          =   319
         Left            =   -72945
         TabIndex        =   100
         Text            =   "txtReligion"
         Top             =   4140
         Width           =   4020
      End
      Begin VB.CommandButton cmd__NewFather 
         Caption         =   "&New"
         Height          =   385
         Left            =   -68700
         TabIndex        =   99
         Top             =   600
         Width           =   1095
      End
      Begin VB.CommandButton cmd__FindFather 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   -68700
         TabIndex        =   98
         Top             =   990
         Width           =   1095
      End
      Begin VB.CommandButton cmd__SaveFather 
         Caption         =   "&Save"
         Height          =   385
         Left            =   -68700
         TabIndex        =   97
         Top             =   1470
         Width           =   1095
      End
      Begin VB.CommandButton cmd__DeleteFather 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   -68700
         TabIndex        =   96
         Top             =   1860
         Width           =   1095
      End
      Begin VB.CommandButton cmd__CloseFather 
         Caption         =   "&Clean"
         Height          =   385
         Left            =   -68700
         TabIndex        =   95
         Top             =   2340
         Width           =   1095
      End
      Begin VB.TextBox txtDateOfAdmission 
         Height          =   375
         Left            =   -74640
         TabIndex        =   94
         Text            =   "txtDateOfAdmission"
         Top             =   860
         Width           =   2895
      End
      Begin VB.TextBox txtAddressSubdivision 
         Height          =   375
         Left            =   -71100
         TabIndex        =   93
         Text            =   "txtAddressSubdivision"
         Top             =   860
         Width           =   2895
      End
      Begin VB.TextBox txtAddressSoy 
         Height          =   375
         Left            =   -74640
         TabIndex        =   91
         Text            =   "txtAddressSoy"
         Top             =   2876
         Width           =   2895
      End
      Begin VB.TextBox txtAddressProvince 
         Height          =   375
         Left            =   -71100
         TabIndex        =   89
         Text            =   "txtAddressProvince"
         Top             =   1532
         Width           =   2895
      End
      Begin VB.TextBox txtAddressRd 
         Height          =   375
         Left            =   -74640
         TabIndex        =   87
         Text            =   "txtAddressRd"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtAddressPostzip 
         Height          =   375
         Left            =   -71100
         TabIndex        =   85
         Text            =   "txtAddressPostzip"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtAddressMoo 
         Height          =   375
         Left            =   -74640
         TabIndex        =   83
         Text            =   "txtAddressMoo"
         Top             =   1532
         Width           =   2895
      End
      Begin VB.TextBox txtAddressEmailAddr 
         Height          =   375
         Left            =   -71100
         TabIndex        =   81
         Text            =   "txtAddressEmailAddr"
         Top             =   2876
         Width           =   2895
      End
      Begin VB.TextBox txtAddressAddrDetail 
         Height          =   375
         Left            =   -74640
         TabIndex        =   79
         Text            =   "txtAddressAddrDetail"
         Top             =   860
         Width           =   2895
      End
      Begin VB.TextBox txtPreDegreeName 
         Height          =   375
         Left            =   -71100
         TabIndex        =   77
         Text            =   "txtPreDegreeName"
         Top             =   3548
         Width           =   2895
      End
      Begin VB.TextBox txtPreTotalUnit 
         Height          =   375
         Left            =   -71100
         TabIndex        =   75
         Text            =   "txtPreTotalUnit"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtCurrentStatus 
         Height          =   375
         Left            =   -74640
         TabIndex        =   60
         Text            =   "txtCurrentStatus"
         Top             =   2876
         Width           =   2895
      End
      Begin VB.TextBox txtDateOfGraduation 
         Height          =   375
         Left            =   -74640
         TabIndex        =   59
         Text            =   "txtDateOfGraduation"
         Top             =   1532
         Width           =   2895
      End
      Begin VB.TextBox txtGPA 
         Height          =   375
         Left            =   -74640
         TabIndex        =   58
         Text            =   "txtGPA"
         Top             =   3548
         Width           =   1174
      End
      Begin VB.TextBox txtPreGPA 
         Height          =   375
         Left            =   -72919
         TabIndex        =   57
         Text            =   "txtPreGPA"
         Top             =   3548
         Width           =   1174
      End
      Begin VB.TextBox txtPreSchoolName 
         Height          =   375
         Left            =   -67680
         TabIndex        =   56
         Text            =   "txtPreSchoolName"
         Top             =   860
         Width           =   2895
      End
      Begin VB.TextBox txtPreSchoolProvince 
         Height          =   375
         Left            =   -67680
         TabIndex        =   55
         Text            =   "txtPreSchoolProvince"
         Top             =   1532
         Width           =   2895
      End
      Begin VB.TextBox txtSchoolProvince 
         Height          =   375
         Left            =   -74640
         TabIndex        =   54
         Text            =   "txtSchoolProvince"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtStudiedUnit 
         Height          =   375
         Left            =   -69379
         TabIndex        =   53
         Text            =   "txtStudiedUnit"
         Top             =   860
         Width           =   1174
      End
      Begin VB.TextBox txtTotalUnit 
         Height          =   375
         Left            =   -71100
         TabIndex        =   52
         Text            =   "txtTotalUnit"
         Top             =   860
         Width           =   1174
      End
      Begin VB.TextBox txtTransferUnit 
         Height          =   375
         Left            =   -71100
         TabIndex        =   51
         Text            =   "txtTransferUnit"
         Top             =   2876
         Width           =   1174
      End
      Begin VB.TextBox txtYearEnter 
         Height          =   375
         Left            =   -71100
         TabIndex        =   50
         Text            =   "txtYearEnter"
         Top             =   1532
         Width           =   2895
      End
      Begin VB.TextBox txtYearGraduate 
         Height          =   375
         Left            =   -74640
         TabIndex        =   49
         Text            =   "txtYearGraduate"
         Top             =   4220
         Width           =   2895
      End
      Begin VB.TextBox txtSchoolName 
         Height          =   375
         Left            =   -67680
         TabIndex        =   47
         Text            =   "txtSchoolName"
         Top             =   2876
         Width           =   2895
      End
      Begin VB.TextBox txtDegreeName 
         Height          =   375
         Left            =   -67680
         TabIndex        =   43
         Text            =   "txtDegreeName"
         Top             =   860
         Width           =   2895
      End
      Begin VB.TextBox txtMajorNameEng 
         Height          =   375
         Left            =   -67680
         TabIndex        =   42
         Text            =   "txtMajorNameEng"
         Top             =   1532
         Width           =   2895
      End
      Begin VB.TextBox txtMajorNameThai 
         Height          =   375
         Left            =   -67680
         TabIndex        =   41
         Text            =   "txtMajorNameThai"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtBirthDay 
         Height          =   375
         Left            =   -71100
         TabIndex        =   25
         Text            =   "txtBirthDay"
         Top             =   4220
         Width           =   2895
      End
      Begin VB.TextBox txtBlood 
         Height          =   375
         Left            =   -67680
         TabIndex        =   24
         Text            =   "txtBlood"
         Top             =   4220
         Width           =   1338
      End
      Begin VB.TextBox txtCitizen 
         Height          =   375
         Left            =   -74640
         TabIndex        =   23
         Text            =   "txtCitizen"
         Top             =   3548
         Width           =   2895
      End
      Begin VB.TextBox txtGender 
         Height          =   375
         Left            =   -74640
         TabIndex        =   22
         Text            =   "txtGender"
         Top             =   1532
         Width           =   1338
      End
      Begin VB.TextBox txtGenderEng 
         Height          =   375
         Left            =   -71100
         TabIndex        =   21
         Text            =   "txtGenderEng"
         Top             =   1532
         Width           =   1338
      End
      Begin VB.TextBox txtHight 
         Height          =   375
         Left            =   -67680
         TabIndex        =   20
         Text            =   "txtHight"
         Top             =   3548
         Width           =   1338
      End
      Begin VB.TextBox txtIdentifierNumber 
         Height          =   375
         Left            =   -71100
         TabIndex        =   19
         Text            =   "txtIdentifierNumber"
         Top             =   860
         Width           =   2895
      End
      Begin VB.TextBox txtName 
         Height          =   375
         Left            =   -74640
         TabIndex        =   18
         Text            =   "txtName"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtNameEng 
         Height          =   375
         Left            =   -71100
         TabIndex        =   17
         Text            =   "txtNameEng"
         Top             =   2204
         Width           =   2895
      End
      Begin VB.TextBox txtNation 
         Height          =   375
         Left            =   -74640
         TabIndex        =   16
         Text            =   "txtNation"
         Top             =   4220
         Width           =   2895
      End
      Begin VB.TextBox txtReligion 
         Height          =   375
         Left            =   -71100
         TabIndex        =   15
         Text            =   "txtReligion"
         Top             =   3548
         Width           =   2895
      End
      Begin VB.TextBox txtSurNameEng 
         Height          =   375
         Left            =   -71100
         TabIndex        =   14
         Text            =   "txtSurNameEng"
         Top             =   2876
         Width           =   2895
      End
      Begin VB.TextBox txtSurname 
         Height          =   375
         Left            =   -74640
         TabIndex        =   13
         Text            =   "txtSurname"
         Top             =   2876
         Width           =   2895
      End
      Begin VB.TextBox txtWeight 
         Height          =   375
         Left            =   -66120
         TabIndex        =   12
         Text            =   "txtWeight"
         Top             =   3548
         Width           =   1338
      End
      Begin VB.TextBox txtStdCode 
         Height          =   375
         Left            =   -74640
         TabIndex        =   11
         Text            =   "txtStdCode"
         Top             =   860
         Width           =   2895
      End
      Begin VB.Label lblReligionGuardian 
         Caption         =   "Religion"
         Height          =   330
         Left            =   -74280
         TabIndex        =   169
         Top             =   4200
         Width           =   1215
      End
      Begin VB.Label lblNationGuardian 
         Caption         =   "Nation"
         Height          =   330
         Left            =   -74280
         TabIndex        =   167
         Top             =   3840
         Width           =   1215
      End
      Begin VB.Label lblCitizenGuardian 
         Caption         =   "Citizen"
         Height          =   330
         Left            =   -74280
         TabIndex        =   165
         Top             =   3480
         Width           =   1215
      End
      Begin VB.Label lblBloodGuardian 
         Caption         =   "Blood"
         Height          =   330
         Left            =   -74280
         TabIndex        =   163
         Top             =   3120
         Width           =   1215
      End
      Begin VB.Label lblWeightGuardian 
         Caption         =   "Weight"
         Height          =   330
         Left            =   -74280
         TabIndex        =   161
         Top             =   2760
         Width           =   1215
      End
      Begin VB.Label lblHightGuardian 
         Caption         =   "Hight"
         Height          =   330
         Left            =   -74280
         TabIndex        =   159
         Top             =   2400
         Width           =   1215
      End
      Begin VB.Label lblBirthDayGuardian 
         Caption         =   "BirthDay"
         Height          =   330
         Left            =   -74280
         TabIndex        =   157
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label lblSurnameGuardian 
         Caption         =   "Surname"
         Height          =   330
         Left            =   -74280
         TabIndex        =   155
         Top             =   1680
         Width           =   1215
      End
      Begin VB.Label lblNameGuardian 
         Caption         =   "Name"
         Height          =   330
         Left            =   -74280
         TabIndex        =   153
         Top             =   1320
         Width           =   1215
      End
      Begin VB.Label lblGenderGuardian 
         Caption         =   "Gender"
         Height          =   330
         Left            =   -74280
         TabIndex        =   151
         Top             =   960
         Width           =   1215
      End
      Begin VB.Label lblIdentifierNumberGuardian 
         Caption         =   "IdentifierNumber"
         Height          =   330
         Left            =   -74280
         TabIndex        =   149
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label lblReligionMother 
         Caption         =   "Religion"
         Height          =   330
         Left            =   720
         TabIndex        =   148
         Top             =   4200
         Width           =   1215
      End
      Begin VB.Label lblNationMother 
         Caption         =   "Nation"
         Height          =   330
         Left            =   720
         TabIndex        =   147
         Top             =   3840
         Width           =   1215
      End
      Begin VB.Label lblCitizenMother 
         Caption         =   "Citizen"
         Height          =   330
         Left            =   720
         TabIndex        =   146
         Top             =   3480
         Width           =   1215
      End
      Begin VB.Label lblBloodMother 
         Caption         =   "Blood"
         Height          =   330
         Left            =   720
         TabIndex        =   145
         Top             =   3120
         Width           =   1215
      End
      Begin VB.Label lblWeightMother 
         Caption         =   "Weight"
         Height          =   330
         Left            =   720
         TabIndex        =   144
         Top             =   2760
         Width           =   1215
      End
      Begin VB.Label lblHightMother 
         Caption         =   "Hight"
         Height          =   330
         Left            =   720
         TabIndex        =   143
         Top             =   2400
         Width           =   1215
      End
      Begin VB.Label lblBirthDayMother 
         Caption         =   "BirthDay"
         Height          =   330
         Left            =   720
         TabIndex        =   142
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label lblSurnameMother 
         Caption         =   "Surname"
         Height          =   330
         Left            =   720
         TabIndex        =   141
         Top             =   1680
         Width           =   1215
      End
      Begin VB.Label lblNameMother 
         Caption         =   "Name"
         Height          =   330
         Left            =   720
         TabIndex        =   140
         Top             =   1320
         Width           =   1215
      End
      Begin VB.Label lblGenderMother 
         Caption         =   "Gender"
         Height          =   330
         Left            =   720
         TabIndex        =   139
         Top             =   960
         Width           =   1215
      End
      Begin VB.Label lblIdentifierNumberMother 
         Caption         =   "IdentifierNumber"
         Height          =   330
         Left            =   720
         TabIndex        =   138
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label lblReligionFather 
         Caption         =   "Religion"
         Height          =   330
         Left            =   -74280
         TabIndex        =   121
         Top             =   4200
         Width           =   1215
      End
      Begin VB.Label lblNationFather 
         Caption         =   "Nation"
         Height          =   330
         Left            =   -74280
         TabIndex        =   120
         Top             =   3840
         Width           =   1215
      End
      Begin VB.Label lblCitizenFather 
         Caption         =   "Citizen"
         Height          =   330
         Left            =   -74280
         TabIndex        =   119
         Top             =   3480
         Width           =   1215
      End
      Begin VB.Label lblBloodFather 
         Caption         =   "Blood"
         Height          =   330
         Left            =   -74280
         TabIndex        =   118
         Top             =   3120
         Width           =   1215
      End
      Begin VB.Label lblWeightFather 
         Caption         =   "Weight"
         Height          =   330
         Left            =   -74280
         TabIndex        =   117
         Top             =   2760
         Width           =   1215
      End
      Begin VB.Label lblHightFather 
         Caption         =   "Hight"
         Height          =   330
         Left            =   -74280
         TabIndex        =   116
         Top             =   2400
         Width           =   1215
      End
      Begin VB.Label lblBirthDayFather 
         Caption         =   "BirthDay"
         Height          =   330
         Left            =   -74280
         TabIndex        =   115
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label lblSurnameFather 
         Caption         =   "Surname"
         Height          =   330
         Left            =   -74280
         TabIndex        =   114
         Top             =   1680
         Width           =   1215
      End
      Begin VB.Label lblNameFather 
         Caption         =   "Name"
         Height          =   330
         Left            =   -74280
         TabIndex        =   113
         Top             =   1320
         Width           =   1215
      End
      Begin VB.Label lblGenderFather 
         Caption         =   "Gender"
         Height          =   330
         Left            =   -74280
         TabIndex        =   112
         Top             =   960
         Width           =   1215
      End
      Begin VB.Label lblIdentifierNumberFather 
         Caption         =   "IdentifierNumber"
         Height          =   330
         Left            =   -74280
         TabIndex        =   111
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label lblAddressSubdivision 
         Caption         =   "Address Subdivision"
         Height          =   330
         Left            =   -71040
         TabIndex        =   92
         Top             =   620
         Width           =   2010
      End
      Begin VB.Label lblAddressSoy 
         Caption         =   "Address Soy"
         Height          =   330
         Left            =   -74640
         TabIndex        =   90
         Top             =   2660
         Width           =   2010
      End
      Begin VB.Label lblAddressProvince 
         Caption         =   "Address Province"
         Height          =   330
         Left            =   -71100
         TabIndex        =   88
         Top             =   1300
         Width           =   2010
      End
      Begin VB.Label lblAddressRd 
         Caption         =   "Address Rd"
         Height          =   330
         Left            =   -74640
         TabIndex        =   86
         Top             =   1980
         Width           =   2010
      End
      Begin VB.Label lblAddressPostzip 
         Caption         =   "Address Postzip"
         Height          =   330
         Left            =   -71100
         TabIndex        =   84
         Top             =   1980
         Width           =   2010
      End
      Begin VB.Label lblAddressMoo 
         Caption         =   "Address Moo"
         Height          =   330
         Left            =   -74640
         TabIndex        =   82
         Top             =   1300
         Width           =   2010
      End
      Begin VB.Label lblAddressEmailAddr 
         Caption         =   "Address EmailAddr"
         Height          =   330
         Left            =   -71100
         TabIndex        =   80
         Top             =   2660
         Width           =   2010
      End
      Begin VB.Label lblAddressAddrDetail 
         Caption         =   "Address AddrDetail"
         Height          =   330
         Left            =   -74640
         TabIndex        =   78
         Top             =   620
         Width           =   2010
      End
      Begin VB.Label lblPreDegreeName 
         Caption         =   "PreDegreeName"
         Height          =   330
         Left            =   -71100
         TabIndex        =   76
         Top             =   3308
         Width           =   1425
      End
      Begin VB.Label lblYearGraduate 
         Caption         =   "YearGraduate"
         Height          =   330
         Left            =   -74640
         TabIndex        =   74
         Top             =   3980
         Width           =   1185
      End
      Begin VB.Label lblYearEnter 
         Caption         =   "YearEnter"
         Height          =   330
         Left            =   -71100
         TabIndex        =   73
         Top             =   1300
         Width           =   1185
      End
      Begin VB.Label lblTransferUnit 
         Caption         =   "TransferUnit"
         Height          =   330
         Left            =   -71100
         TabIndex        =   72
         Top             =   2660
         Width           =   1185
      End
      Begin VB.Label lblTotalUnit 
         Caption         =   "TotalUnit"
         Height          =   330
         Left            =   -71100
         TabIndex        =   71
         Top             =   620
         Width           =   1185
      End
      Begin VB.Label lblStudiedUnit 
         Caption         =   "StudiedUnit"
         Height          =   330
         Left            =   -69379
         TabIndex        =   70
         Top             =   620
         Width           =   1185
      End
      Begin VB.Label lblSchoolProvince 
         Caption         =   "SchoolProvince"
         Height          =   330
         Left            =   -74640
         TabIndex        =   69
         Top             =   1964
         Width           =   1185
      End
      Begin VB.Label lblPreTotalUnit 
         Caption         =   "PreTotalUnit"
         Height          =   330
         Left            =   -71100
         TabIndex        =   68
         Top             =   1980
         Width           =   1425
      End
      Begin VB.Label lblPreSchoolProvince 
         Caption         =   "PreSchoolProvince"
         Height          =   330
         Left            =   -67680
         TabIndex        =   67
         Top             =   1340
         Width           =   1425
      End
      Begin VB.Label lblPreSchoolName 
         Caption         =   "PreSchoolName"
         Height          =   330
         Left            =   -67680
         TabIndex        =   66
         Top             =   620
         Width           =   1425
      End
      Begin VB.Label lblPreGPA 
         Caption         =   "PreGPA"
         Height          =   330
         Left            =   -72720
         TabIndex        =   65
         Top             =   3308
         Width           =   1425
      End
      Begin VB.Label lblGPA 
         Caption         =   "GPA"
         Height          =   330
         Left            =   -74640
         TabIndex        =   64
         Top             =   3308
         Width           =   1350
      End
      Begin VB.Label lblDateOfGraduation 
         Caption         =   "DateOfGraduation"
         Height          =   330
         Left            =   -74640
         TabIndex        =   63
         Top             =   1292
         Width           =   1350
      End
      Begin VB.Label lblDateOfAdmission 
         Caption         =   "DateOfAdmission"
         Height          =   330
         Left            =   -74640
         TabIndex        =   62
         Top             =   620
         Width           =   1350
      End
      Begin VB.Label lblCurrentStatus 
         Caption         =   "CurrentStatus"
         Height          =   330
         Left            =   -74640
         TabIndex        =   61
         Top             =   2660
         Width           =   1350
      End
      Begin VB.Label lblSchoolName 
         Caption         =   "SchoolName"
         Height          =   330
         Left            =   -67680
         TabIndex        =   48
         Top             =   2636
         Width           =   1425
      End
      Begin VB.Label lblMajorNameThai 
         Caption         =   "MajorNameThai"
         Height          =   330
         Left            =   -67680
         TabIndex        =   46
         Top             =   1964
         Width           =   1425
      End
      Begin VB.Label lblMajorNameEng 
         Caption         =   "MajorNameEng"
         Height          =   330
         Left            =   -67680
         TabIndex        =   45
         Top             =   1292
         Width           =   1425
      End
      Begin VB.Label lblDegreeName 
         Caption         =   "DegreeName"
         Height          =   330
         Left            =   -67680
         TabIndex        =   44
         Top             =   620
         Width           =   1350
      End
      Begin VB.Label lblWeight 
         Caption         =   "Weight"
         Height          =   330
         Left            =   -66120
         TabIndex        =   40
         Top             =   3308
         Width           =   1185
      End
      Begin VB.Label lblSurname 
         Caption         =   "Surname"
         Height          =   330
         Left            =   -74640
         TabIndex        =   39
         Top             =   2636
         Width           =   1185
      End
      Begin VB.Label lblSurNameEng 
         Caption         =   "SurNameEng"
         Height          =   330
         Left            =   -71100
         TabIndex        =   38
         Top             =   2636
         Width           =   1185
      End
      Begin VB.Label lblStdCode 
         Caption         =   "StdCode"
         Height          =   330
         Left            =   -74640
         TabIndex        =   37
         Top             =   620
         Width           =   855
      End
      Begin VB.Label lblReligion 
         Caption         =   "Religion"
         Height          =   330
         Left            =   -71100
         TabIndex        =   36
         Top             =   3308
         Width           =   1425
      End
      Begin VB.Label lblNation 
         Caption         =   "Nation"
         Height          =   330
         Left            =   -74640
         TabIndex        =   35
         Top             =   3980
         Width           =   1425
      End
      Begin VB.Label lblNameEng 
         Caption         =   "NameEng"
         Height          =   330
         Left            =   -71100
         TabIndex        =   34
         Top             =   1964
         Width           =   1425
      End
      Begin VB.Label lblName 
         Caption         =   "Name"
         Height          =   330
         Left            =   -74640
         TabIndex        =   33
         Top             =   1964
         Width           =   1425
      End
      Begin VB.Label lblIdentifierNumber 
         Caption         =   "IdentifierNumber"
         Height          =   330
         Left            =   -71100
         TabIndex        =   32
         Top             =   620
         Width           =   1350
      End
      Begin VB.Label lblHight 
         Caption         =   "Hight"
         Height          =   330
         Left            =   -67680
         TabIndex        =   31
         Top             =   3308
         Width           =   1350
      End
      Begin VB.Label lblGenderEng 
         Caption         =   "GenderEng"
         Height          =   330
         Left            =   -71100
         TabIndex        =   30
         Top             =   1292
         Width           =   1350
      End
      Begin VB.Label lblGender 
         Caption         =   "Gender"
         Height          =   330
         Left            =   -74640
         TabIndex        =   29
         Top             =   1292
         Width           =   1350
      End
      Begin VB.Label lblCitizen 
         Caption         =   "Citizen"
         Height          =   330
         Left            =   -74640
         TabIndex        =   28
         Top             =   3308
         Width           =   1350
      End
      Begin VB.Label lblBlood 
         Caption         =   "Blood"
         Height          =   330
         Left            =   -67680
         TabIndex        =   27
         Top             =   3980
         Width           =   1350
      End
      Begin VB.Label lblBirthDay 
         Caption         =   "BirthDay"
         Height          =   330
         Left            =   -71100
         TabIndex        =   26
         Top             =   3980
         Width           =   1350
      End
   End
   Begin VB.PictureBox picPatch 
      BorderStyle     =   0  'None
      Height          =   251
      Left            =   0
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.VScrollBar VSCroll 
      Height          =   1181
      LargeChange     =   24
      Left            =   12120
      TabIndex        =   1
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.HScrollBar HSCroll 
      Height          =   251
      LargeChange     =   24
      Left            =   120
      TabIndex        =   0
      Top             =   5040
      Visible         =   0   'False
      Width           =   1204
   End
   Begin CACHEQUERYLib.CacheQuery CacheQuery1 
      Left            =   1440
      Top             =   1560
      _Version        =   65536
      _ExtentX        =   847
      _ExtentY        =   847
      _StockProps     =   0
      ClassName       =   ""
      QueryName       =   ""
   End
   Begin MSComDlg.CommonDialog dlgCommon 
      Left            =   1920
      Top             =   1560
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Frame fra_Main 
      BorderStyle     =   0  'None
      Caption         =   "fra_Main"
      Height          =   4965
      Left            =   0
      TabIndex        =   3
      Top             =   0
      Width           =   12045
      Begin VB.CommandButton cmd__Delete 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   10725
         TabIndex        =   7
         Top             =   1260
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Save 
         Caption         =   "&Save"
         Height          =   385
         Left            =   10725
         TabIndex        =   6
         Top             =   870
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Exit 
         Caption         =   "Cancel"
         Height          =   385
         Left            =   10725
         TabIndex        =   9
         Top             =   2130
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Close 
         Caption         =   "&Close"
         Height          =   385
         Left            =   10725
         TabIndex        =   8
         Top             =   1740
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Find 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   10725
         TabIndex        =   5
         Top             =   390
         Width           =   1095
      End
      Begin VB.CommandButton cmd__New 
         Caption         =   "&New"
         Height          =   385
         Left            =   10725
         TabIndex        =   4
         Top             =   0
         Width           =   1095
      End
   End
   Begin VB.Menu mnuObject 
      Caption         =   "&Object"
      Begin VB.Menu mnu__New 
         Caption         =   "&New"
      End
      Begin VB.Menu mnu__Find 
         Caption         =   "&Find..."
      End
      Begin VB.Menu mnu__Bar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Save 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnu__Delete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnu__Close 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnu__Bar2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Exit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "frmKmitlStudent2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const m_classname = "PersonInfo.KmitlStudent"

Private m_Father As Object
Private idFather As Variant
Private m_Mother As Object
Private idMother As Variant
Private m_Guardian As Object
Private idGuardian As Variant

Private m_factory As Object
Private m_object As Object
Private m_modified As Boolean
Private m_modifiedf As Boolean
Private m_modifiedm As Boolean
Private m_modifiedg As Boolean

Private m_WaitFlag As Integer
Private id As Variant
Private disableclick As Boolean

Private Sub cmd__Close_Click()
    actionClose
    DisableAll

End Sub


Private Sub cmd__Delete_Click()
    actionDelete
    DisableAll

End Sub

Private Sub cmd__Exit_Click()
    actionExit

End Sub

Private Sub cmd__Find_Click()
    actionFind
End Sub

Private Sub cmd__New_Click()
    actionNew
    EnableAll
End Sub

Private Sub cmd__Save_Click()
    actionSave

End Sub
Private Sub DisableAll()
    cmd__NewGuardian.Enabled = False
    cmd__FindGuardian.Enabled = False
    cmd__SaveGuardian.Enabled = False
    cmd__DeleteGuardian.Enabled = False
    cmd__CloseGuardian.Enabled = False
    
    cmd__NewFather.Enabled = False
    cmd__FindFather.Enabled = False
    cmd__SaveFather.Enabled = False
    cmd__DeleteFather.Enabled = False
    cmd__CloseFather.Enabled = False
    
    cmd__NewMother.Enabled = False
    cmd__FindMother.Enabled = False
    cmd__SaveMother.Enabled = False
    cmd__DeleteMother.Enabled = False
    cmd__CloseMother.Enabled = False
    
End Sub
Private Sub EnableAll()
    cmd__NewGuardian.Enabled = True
    cmd__FindGuardian.Enabled = True
    cmd__NewFather.Enabled = True
    cmd__FindFather.Enabled = True
    cmd__NewMother.Enabled = True
    cmd__FindMother.Enabled = True
End Sub


Private Sub Form_Load()
    Dim sdir As String
    actionClose
    EraseScreenFather
    EnableScreenFather False
    EraseScreenMother
    EnableScreenMother False
    EraseScreenGuardian
    EnableScreenGuardian False
    DisableAll
    m_modifiedf = False
    m_modifiedm = False
    m_modifiedg = False

    
    Set m_factory = CacheForm.Factory
'    sdir = m_factory.ConnectDlg
'    If sdir <> "" Then
'        m_factory.connect sdir
'    Else
'        End
'    End If
End Sub

Private Sub Form_Resize()
picPatch.Visible = False
If Me.ScaleWidth < fra_Main.Width Then
    HSCroll.Top = Me.ScaleHeight - HSCroll.Height
    HSCroll.Width = Me.ScaleWidth
    HSCroll.max = (fra_Main.Width - Me.ScaleWidth) \ 15
    HSCroll.Visible = True
    HSCroll.ZOrder
    If Me.ScaleHeight - HSCroll.Height < fra_Main.Height Then
        HSCroll.Width = Me.ScaleWidth - VSCroll.Width
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight - HSCroll.Height
        HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        picPatch.Top = HSCroll.Top
        picPatch.Left = HSCroll.Width
        picPatch.Visible = True
        picPatch.ZOrder
    Else
        VSCroll.Visible = False
    End If
Else
   HSCroll.Visible = False
    If Me.ScaleHeight < fra_Main.Height Then
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        If Me.ScaleWidth - VSCroll.Width < fra_Main.Width Then
            VSCroll.Height = Me.ScaleHeight - HSCroll.Height
            HSCroll.Top = Me.ScaleHeight - HSCroll.Height
            HSCroll.Width = Me.ScaleWidth - VSCroll.Width
            VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
            HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
            HSCroll.Visible = True
            HSCroll.ZOrder
            picPatch.Top = HSCroll.Top
            picPatch.Left = HSCroll.Width
            picPatch.Visible = True
            picPatch.ZOrder
        End If
    Else
        VSCroll.Visible = False
    End If
End If
End Sub

Private Sub HScroll_Change()
    fra_Main.Left = -HSCroll.Value * 15
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

Private Sub mnu__Close_Click()
    actionClose

End Sub

Private Sub mnu__Delete_Click()
    actionDelete

End Sub

Private Sub mnu__Exit_Click()
    actionExit

End Sub

Private Sub mnu__Find_Click()
    actionFind

End Sub

Private Sub mnu__New_Click()
    actionNew

End Sub

Private Sub mnu__Save_Click()
    actionSave

End Sub

Private Sub txtBirthDay_Change()
    m_modified = True

End Sub

Private Sub txtBlood_Change()
    m_modified = True

End Sub

Private Sub txtCitizen_Change()
    m_modified = True

End Sub

Private Sub txtCurrentStatus_Change()
    m_modified = True

End Sub

Private Sub txtDateOfAdmission_Change()
    m_modified = True

End Sub

Private Sub txtDateOfGraduation_Change()
    m_modified = True

End Sub

Private Sub txtDegreeName_Change()
    m_modified = True

End Sub

Private Sub txtGender_Change()
    m_modified = True

End Sub

Private Sub txtGenderEng_Change()
    m_modified = True

End Sub

Private Sub txtGPA_Change()
    m_modified = True

End Sub

Private Sub txtHight_Change()
    m_modified = True

End Sub

Private Sub txtIdentifierNumber_Change()
    m_modified = True

End Sub

Private Sub txtMajorNameEng_Change()
    m_modified = True

End Sub

Private Sub txtMajorNameThai_Change()
    m_modified = True

End Sub

Private Sub txtName_Change()
    m_modified = True

End Sub

Private Sub txtNameEng_Change()
    m_modified = True

End Sub

Private Sub txtNation_Change()
    m_modified = True

End Sub

Private Sub txtPreDegreeName_Change()
    m_modified = True

End Sub

Private Sub txtPreGPA_Change()
    m_modified = True

End Sub

Private Sub txtPreSchoolName_Change()
    m_modified = True

End Sub

Private Sub txtPreSchoolProvince_Change()
    m_modified = True

End Sub

Private Sub txtPreTotalUnit_Change()
    m_modified = True

End Sub

Private Sub txtReligion_Change()
    m_modified = True

End Sub

Private Sub txtSchoolName_Change()
    m_modified = True

End Sub

Private Sub txtSchoolProvince_Change()
    m_modified = True

End Sub

Private Sub txtStdCode_Change()
    m_modified = True

End Sub


Private Sub txtStudiedUnit_Change()
    m_modified = True

End Sub

Private Sub txtSurname_Change()
    m_modified = True

End Sub

Private Sub txtSurNameEng_Change()
    m_modified = True

End Sub

Private Sub txtTotalUnit_Change()
    m_modified = True

End Sub

Private Sub txtTransferUnit_Change()
    m_modified = True

End Sub

Private Sub txtWeight_Change()
    m_modified = True

End Sub

Private Sub txtYearEnter_Change()
    m_modified = True

End Sub

Private Sub txtYearGraduate_Change()
    m_modified = True

End Sub


Private Sub txtAddressAddrDetail_Change()
    m_modified = True

End Sub

Private Sub txtAddressEmailAddr_Change()
    m_modified = True

End Sub

Private Sub txtAddressMoo_Change()
    m_modified = True

End Sub

Private Sub txtAddressPostzip_Change()
    m_modified = True

End Sub

Private Sub txtAddressProvince_Change()
    m_modified = True

End Sub

Private Sub txtAddressRd_Change()
    m_modified = True

End Sub

Private Sub txtAddressSoy_Change()
    m_modified = True

End Sub

Private Sub txtAddressSubdivision_Change()
    m_modified = True

End Sub


Private Sub VScroll_Change()
    fra_Main.Top = -VSCroll.Value * 15
End Sub

Private Sub VScroll_Scroll()
    VScroll_Change
End Sub

Private Sub actionNew()
    actionClose
    Set m_object = m_factory.New(m_classname)
    If m_object Is Nothing Then
         MsgBox "Cannot create new object."
         actionClose
    Else
         EnableScreen True
         SyncObjectToScreen
         m_modified = True
         cmd__Delete.Enabled = False
         mnu__Delete.Enabled = False
    End If
End Sub

Private Sub actionFind()
    actionClose
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = m_classname
    id = CacheQuery1.FindId
    If id = "" Then Exit Sub
    Set m_object = m_factory.OpenId(m_classname, id)
    If m_object Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableAll
        EnableScreen True
        SyncObjectToScreen
        If m_object.FatherID <> "" Then
            Set m_Father = m_factory.OpenId("PersonInfo.Person", m_object.FatherID)
        EnableScreenFather True
        SyncObjectToScreenFather
        End If
        If m_object.MotherID <> "" Then
            Set m_Mother = m_factory.OpenId("PersonInfo.Person", m_object.MotherID)
        EnableScreenMother True
        SyncObjectToScreenMother
        End If
        If m_object.GuardianID <> "" Then
            Set m_Guardian = m_factory.OpenId("PersonInfo.Person", m_object.GuardianID)
        EnableScreenGuardian True
        SyncObjectToScreenGuardian
        End If
        m_modified = False
        m_modifiedf = False
        m_modifiedm = False
        m_modifiedg = False
    End If
End Sub

Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDelete()
    If id = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObject
    On Error GoTo actionDeleteError
    BeginWait
    m_object.sys_DeleteId (id)
    actionClose
    EndWait
    m_modified = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    
    If Not m_Father Is Nothing And m_modifiedf Then
      If MsgBox("Do you want to save change father?", vbYesNo) = vbYes Then actionSaveFather
    End If
    
    If Not m_Mother Is Nothing And m_modifiedm Then
      If MsgBox("Do you want to save change mother?", vbYesNo) = vbYes Then actionSaveMother
    End If
    
    If Not m_Guardian Is Nothing And m_modifiedg Then
      If MsgBox("Do you want to save change guardian?", vbYesNo) = vbYes Then actionSaveGuardian
    End If

    If Not m_object Is Nothing Then
      If Not m_Father Is Nothing Then
        m_Father.SYS_Close
        Set m_Father = Nothing
      End If
      If Not m_Mother Is Nothing Then
        m_Mother.SYS_Close
        Set m_Mother = Nothing
      End If
      If Not m_Guardian Is Nothing Then
        m_Guardian.SYS_Close
        Set m_Guardian = Nothing
      End If
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    EraseScreenFather
    EnableScreenFather False
    EraseScreenMother
    EnableScreenMother False
    EraseScreenGuardian
    EnableScreenGuardian False
    
    id = ""
    idFather = ""
    idMother = ""
    idGuardian = ""
    m_modified = False
    m_modifiedf = False
    m_modifiedg = False
    m_modifiedm = False
    
End Sub

Private Sub actionExit()
    actionClose
    Unload Me
End Sub

Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

Private Function minmax(val As Long, min As Long, max As Long)
    minmax = val
    If min <> -1 And val < min Then minmax = min
    If max <> -1 And val > max Then minmax = max
End Function

Public Sub ListView_ColumnClick(hList As ListView, ByVal ColumnHeader As MSComctlLib.ColumnHeader)
    'Handle any listview
    If hList.Sorted = False Then
       hList.Sorted = True
       hList.SortKey = ColumnHeader.Index - 1
       hList.SortOrder = lvwAscending
       Exit Sub
    End If
    If hList.SortKey = (ColumnHeader.Index - 1) Then
        If hList.SortOrder = lvwAscending Then
            hList.SortOrder = lvwDescending
        Else
            hList.SortOrder = lvwAscending
        End If
    Else
        hList.SortKey = ColumnHeader.Index - 1
    End If
End Sub
Private Sub EnableScreen(Enabled As Boolean)
    
    lblBirthDay.Enabled = Enabled
    txtBirthDay.Enabled = Enabled
    lblBlood.Enabled = Enabled
    txtBlood.Enabled = Enabled
    lblCitizen.Enabled = Enabled
    txtCitizen.Enabled = Enabled
    lblCurrentStatus.Enabled = Enabled
    txtCurrentStatus.Enabled = Enabled
    lblDateOfAdmission.Enabled = Enabled
    txtDateOfAdmission.Enabled = Enabled
    lblDateOfGraduation.Enabled = Enabled
    txtDateOfGraduation.Enabled = Enabled
    lblDegreeName.Enabled = Enabled
    txtDegreeName.Enabled = Enabled
    lblGPA.Enabled = Enabled
    txtGPA.Enabled = Enabled
    lblGender.Enabled = Enabled
    txtGender.Enabled = Enabled
    lblGenderEng.Enabled = Enabled
    txtGenderEng.Enabled = Enabled
    lblHight.Enabled = Enabled
    txtHight.Enabled = Enabled
    lblIdentifierNumber.Enabled = Enabled
    txtIdentifierNumber.Enabled = Enabled
    lblMajorNameEng.Enabled = Enabled
    txtMajorNameEng.Enabled = Enabled
    lblMajorNameThai.Enabled = Enabled
    txtMajorNameThai.Enabled = Enabled
    lblName.Enabled = Enabled
    txtName.Enabled = Enabled
    lblNameEng.Enabled = Enabled
    txtNameEng.Enabled = Enabled
    lblNation.Enabled = Enabled
    txtNation.Enabled = Enabled
    lblPreDegreeName.Enabled = Enabled
    txtPreDegreeName.Enabled = Enabled
    lblPreGPA.Enabled = Enabled
    txtPreGPA.Enabled = Enabled
    lblPreSchoolName.Enabled = Enabled
    txtPreSchoolName.Enabled = Enabled
    lblPreSchoolProvince.Enabled = Enabled
    txtPreSchoolProvince.Enabled = Enabled
    lblPreTotalUnit.Enabled = Enabled
    txtPreTotalUnit.Enabled = Enabled
    lblReligion.Enabled = Enabled
    txtReligion.Enabled = Enabled
    lblSchoolName.Enabled = Enabled
    txtSchoolName.Enabled = Enabled
    lblSchoolProvince.Enabled = Enabled
    txtSchoolProvince.Enabled = Enabled
    lblStdCode.Enabled = Enabled
    txtStdCode.Enabled = Enabled
    lblStudiedUnit.Enabled = Enabled
    txtStudiedUnit.Enabled = Enabled
    lblSurNameEng.Enabled = Enabled
    txtSurNameEng.Enabled = Enabled
    lblSurname.Enabled = Enabled
    txtSurname.Enabled = Enabled
    lblTotalUnit.Enabled = Enabled
    txtTotalUnit.Enabled = Enabled
    lblTransferUnit.Enabled = Enabled
    txtTransferUnit.Enabled = Enabled
    lblWeight.Enabled = Enabled
    txtWeight.Enabled = Enabled
    lblYearEnter.Enabled = Enabled
    txtYearEnter.Enabled = Enabled
    lblYearGraduate.Enabled = Enabled
    txtYearGraduate.Enabled = Enabled
    ' move form kmitl strdent
    lblAddressAddrDetail.Enabled = Enabled
    txtAddressAddrDetail.Enabled = Enabled
    lblAddressEmailAddr.Enabled = Enabled
    txtAddressEmailAddr.Enabled = Enabled
    lblAddressMoo.Enabled = Enabled
    txtAddressMoo.Enabled = Enabled
    lblAddressPostzip.Enabled = Enabled
    txtAddressPostzip.Enabled = Enabled
    lblAddressRd.Enabled = Enabled
    txtAddressRd.Enabled = Enabled
    lblAddressProvince.Enabled = Enabled
    txtAddressProvince.Enabled = Enabled
    lblAddressSoy.Enabled = Enabled
    txtAddressSoy.Enabled = Enabled
    lblAddressSubdivision.Enabled = Enabled
    txtAddressSubdivision.Enabled = Enabled

    
    mnu__Save.Enabled = Enabled
    mnu__Close.Enabled = Enabled
    mnu__Delete.Enabled = Enabled
    cmd__Save.Enabled = Enabled
    cmd__Close.Enabled = Enabled
    cmd__Delete.Enabled = Enabled
End Sub

Private Sub EraseScreen()
    txtBirthDay.Text = ""
    txtBlood.Text = ""
    txtCitizen.Text = ""
    txtCurrentStatus.Text = ""
    txtDateOfAdmission.Text = ""
    txtDateOfGraduation.Text = ""
    txtDegreeName.Text = ""
    txtGPA.Text = ""
    txtGender.Text = ""
    txtGenderEng.Text = ""
    txtHight.Text = ""
    txtIdentifierNumber.Text = ""
    txtMajorNameEng.Text = ""
    txtMajorNameThai.Text = ""
    txtName.Text = ""
    txtNameEng.Text = ""
    txtNation.Text = ""
    txtPreDegreeName.Text = ""
    txtPreGPA.Text = ""
    txtPreSchoolName.Text = ""
    txtPreSchoolProvince.Text = ""
    txtPreTotalUnit.Text = ""
    txtReligion.Text = ""
    txtSchoolName.Text = ""
    txtSchoolProvince.Text = ""
    txtStdCode.Text = ""
    txtStudiedUnit.Text = ""
    txtSurNameEng.Text = ""
    txtSurname.Text = ""
    txtTotalUnit.Text = ""
    txtTransferUnit.Text = ""
    txtWeight.Text = ""
    txtYearEnter.Text = ""
    txtYearGraduate.Text = ""
    ' move form kmitlstudent
    txtAddressAddrDetail.Text = ""
    txtAddressEmailAddr.Text = ""
    txtAddressMoo.Text = ""
    txtAddressPostzip.Text = ""
    txtAddressRd.Text = ""
    txtAddressProvince.Text = ""
    txtAddressSoy.Text = ""
    txtAddressSubdivision.Text = ""

End Sub

Private Sub SyncObjectToScreen()
    Dim obj As Object
    Dim i As Integer
    Dim item As String
    Dim cnt As String
    Dim itemX As ListItem
    If m_object.BirthDay <> 0 Then
       txtBirthDay.Text = m_object.BirthDay
    Else
       txtBirthDay.Text = ""
    End If
    txtBlood.Text = m_object.Blood
    txtCitizen.Text = m_object.Citizen
    txtCurrentStatus.Text = m_object.CurrentStatus
    If m_object.DateOfAdmission <> 0 Then
       txtDateOfAdmission.Text = m_object.DateOfAdmission
    Else
       txtDateOfAdmission.Text = ""
    End If
    If m_object.DateOfGraduation <> 0 Then
       txtDateOfGraduation.Text = m_object.DateOfGraduation
    Else
       txtDateOfGraduation.Text = ""
    End If
    txtDegreeName.Text = m_object.DegreeName
    txtGPA.Text = m_object.GPA
    txtGender.Text = m_object.Gender
    txtGenderEng.Text = m_object.GenderEng
    txtHight.Text = m_object.Hight
    txtIdentifierNumber.Text = m_object.IdentifierNumber
    txtMajorNameEng.Text = m_object.MajorNameEng
    txtMajorNameThai.Text = m_object.MajorNameThai
    txtName.Text = m_object.Name
    txtNameEng.Text = m_object.NameEng
    txtNation.Text = m_object.Nation
    txtPreDegreeName.Text = m_object.PreDegreeName
    txtPreGPA.Text = m_object.PreGPA
    txtPreSchoolName.Text = m_object.PreSchoolName
    txtPreSchoolProvince.Text = m_object.PreSchoolProvince
    txtPreTotalUnit.Text = m_object.PreTotalUnit
    txtReligion.Text = m_object.Religion
    txtSchoolName.Text = m_object.SchoolName
    txtSchoolProvince.Text = m_object.SchoolProvince
    txtStdCode.Text = m_object.StdCode
    txtStudiedUnit.Text = m_object.StudiedUnit
    txtSurNameEng.Text = m_object.SurNameEng
    txtSurname.Text = m_object.Surname
    txtTotalUnit.Text = m_object.TotalUnit
    txtTransferUnit.Text = m_object.TransferUnit
    txtWeight.Text = m_object.Weight
    txtYearEnter.Text = m_object.YearEnter
    txtYearGraduate.Text = m_object.YearGraduate
    ' move form kmitlstudent
    txtAddressAddrDetail.Text = m_object.Address.AddrDetail
    txtAddressEmailAddr.Text = m_object.Address.EmailAddr
    txtAddressMoo.Text = m_object.Address.Moo
    txtAddressPostzip.Text = m_object.Address.Postzip
    txtAddressRd.Text = m_object.Address.Rd
    txtAddressProvince.Text = m_object.Address.Province
    txtAddressSoy.Text = m_object.Address.Soy
    txtAddressSubdivision.Text = m_object.Address.Subdivision

End Sub

Private Sub SyncScreenToObject()
    m_object.BirthDay = txtBirthDay.Text
    m_object.Blood = txtBlood.Text
    m_object.Citizen = txtCitizen.Text
    m_object.CurrentStatus = txtCurrentStatus.Text
    m_object.DateOfAdmission = txtDateOfAdmission.Text
    m_object.DateOfGraduation = txtDateOfGraduation.Text
    m_object.DegreeName = txtDegreeName.Text
    m_object.GPA = txtGPA.Text
    m_object.Gender = txtGender.Text
    m_object.GenderEng = txtGenderEng.Text
    m_object.Hight = txtHight.Text
    m_object.IdentifierNumber = txtIdentifierNumber.Text
    m_object.MajorNameEng = txtMajorNameEng.Text
    m_object.MajorNameThai = txtMajorNameThai.Text
    m_object.Name = txtName.Text
    m_object.NameEng = txtNameEng.Text
    m_object.Nation = txtNation.Text
    m_object.PreDegreeName = txtPreDegreeName.Text
    m_object.PreGPA = txtPreGPA.Text
    m_object.PreSchoolName = txtPreSchoolName.Text
    m_object.PreSchoolProvince = txtPreSchoolProvince.Text
    m_object.PreTotalUnit = txtPreTotalUnit.Text
    m_object.Religion = txtReligion.Text
    m_object.SchoolName = txtSchoolName.Text
    m_object.SchoolProvince = txtSchoolProvince.Text
    m_object.StdCode = txtStdCode.Text
    m_object.StudiedUnit = txtStudiedUnit.Text
    m_object.SurNameEng = txtSurNameEng.Text
    m_object.Surname = txtSurname.Text
    m_object.TotalUnit = txtTotalUnit.Text
    m_object.TransferUnit = txtTransferUnit.Text
    m_object.Weight = txtWeight.Text
    m_object.YearEnter = txtYearEnter.Text
    m_object.YearGraduate = txtYearGraduate.Text
    
    ' move form kmitlstudent
    m_object.Address.AddrDetail = txtAddressAddrDetail.Text
    m_object.Address.EmailAddr = txtAddressEmailAddr.Text
    m_object.Address.Moo = txtAddressMoo.Text
    m_object.Address.Postzip = txtAddressPostzip.Text
    m_object.Address.Rd = txtAddressRd.Text
    m_object.Address.Province = txtAddressProvince.Text
    m_object.Address.Soy = txtAddressSoy.Text
    m_object.Address.Subdivision = txtAddressSubdivision.Text

End Sub

'form the person form part of father

Private Sub cmd__CloseFather_Click()
    actionCloseFather
End Sub

Private Sub cmd__DeleteFather_Click()
    actionDeleteFather

End Sub


Private Sub cmd__FindFather_Click()
    actionFindFather

End Sub

Private Sub cmd__NewFather_Click()
    actionNewFather

End Sub

Private Sub cmd__SaveFather_Click()
    actionSaveFather

End Sub


Private Sub txtBirthDayFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtBloodFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtCitizenFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtGenderFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtHightFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtIdentifierNumberFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtNameFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtNationFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtReligionFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtSurnameFather_Change()
    m_modifiedf = True

End Sub

Private Sub txtWeightFather_Change()
    m_modifiedf = True

End Sub


Private Sub actionNewFather()
    actionCloseFather
    Set m_Father = m_factory.New("PersonInfo.Person")
    If m_Father Is Nothing Then
         MsgBox "Cannot create new Person object."
         actionCloseFather
    Else
         EnableScreenFather True
         SyncObjectToScreenFather
         m_modifiedf = True
         cmd__DeleteFather.Enabled = False
    End If
End Sub

Private Sub actionFindFather()
    actionCloseFather
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = "PersonInfo.Person"
    idFather = CacheQuery1.FindId
    If idFather = "" Then Exit Sub
    Set m_Father = m_factory.OpenId("PersonInfo.Person", idFather)
    If m_Father Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableScreenFather True
        SyncObjectToScreenFather
        m_object.FatherID = idFather
        m_modifiedf = False
    End If
End Sub

Private Sub actionSaveFather()
    SyncScreenToObjectFather
    On Error GoTo actionSaveError
    BeginWait
    m_Father.sys_Save
    EndWait
    m_modifiedf = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDeleteFather()
    If idFather = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete father record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObjectFather
    On Error GoTo actionDeleteError
    BeginWait
    m_Father.sys_DeleteId (idFather)
    Set m_object.FatherID = ""
    actionCloseFather
    EndWait
    m_modifiedf = False
    m_modified = True
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionCloseFather()
    If Not m_Father Is Nothing And m_modifiedf Then
      If MsgBox("Do you want to save chang father?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_Father Is Nothing Then
      m_Father.SYS_Close
      Set m_Father = Nothing
    End If
    EnableScreenFather False
    EraseScreenFather
    idFather = ""
   
    If Not m_object Is Nothing Then
      m_object.FatherID = ""
      m_modified = True
      Set m_Father = Nothing
    End If
    
     m_modifiedf = False
End Sub
Private Sub EnableScreenFather(Enabled As Boolean)
    lblIdentifierNumberFather.Enabled = Enabled
    txtIdentifierNumberFather.Enabled = Enabled
    lblGenderFather.Enabled = Enabled
    txtGenderFather.Enabled = Enabled
    lblNameFather.Enabled = Enabled
    txtNameFather.Enabled = Enabled
    lblSurnameFather.Enabled = Enabled
    txtSurnameFather.Enabled = Enabled
    lblBirthDayFather.Enabled = Enabled
    txtBirthDayFather.Enabled = Enabled
    lblHightFather.Enabled = Enabled
    txtHightFather.Enabled = Enabled
    lblWeightFather.Enabled = Enabled
    txtWeightFather.Enabled = Enabled
    lblBloodFather.Enabled = Enabled
    txtBloodFather.Enabled = Enabled
    lblCitizenFather.Enabled = Enabled
    txtCitizenFather.Enabled = Enabled
    lblNationFather.Enabled = Enabled
    txtNationFather.Enabled = Enabled
    lblReligionFather.Enabled = Enabled
    txtReligionFather.Enabled = Enabled
    cmd__SaveFather.Enabled = Enabled
    cmd__CloseFather.Enabled = Enabled
    cmd__DeleteFather.Enabled = Enabled
End Sub

Private Sub EraseScreenFather()
    txtIdentifierNumberFather.Text = ""
    txtGenderFather.Text = ""
    txtNameFather.Text = ""
    txtSurnameFather.Text = ""
    txtBirthDayFather.Text = ""
    txtHightFather.Text = ""
    txtWeightFather.Text = ""
    txtBloodFather.Text = ""
    txtCitizenFather.Text = ""
    txtNationFather.Text = ""
    txtReligionFather.Text = ""
End Sub

Private Sub SyncObjectToScreenFather()
    Dim obj As Object
    Dim i As Integer
    Dim item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtIdentifierNumberFather.Text = m_Father.IdentifierNumber
    txtGenderFather.Text = m_Father.Gender
    txtNameFather.Text = m_Father.Name
    txtSurnameFather.Text = m_Father.Surname
    If m_Father.BirthDay <> 0 Then
       txtBirthDayFather.Text = m_Father.BirthDay
    Else
       txtBirthDayFather.Text = ""
    End If
    txtHightFather.Text = m_Father.Hight
    txtWeightFather.Text = m_Father.Weight
    txtBloodFather.Text = m_Father.Blood
    txtCitizenFather.Text = m_Father.Citizen
    txtNationFather.Text = m_Father.Nation
    txtReligionFather.Text = m_Father.Religion
End Sub

Private Sub SyncScreenToObjectFather()
    m_Father.IdentifierNumber = txtIdentifierNumberFather.Text
    m_Father.Gender = txtGenderFather.Text
    m_Father.Name = txtNameFather.Text
    m_Father.Surname = txtSurnameFather.Text
'    m_Father.BirthDay = txtBirthDay.Text
    m_Father.Hight = txtHightFather.Text
    m_Father.Weight = txtWeightFather.Text
    m_Father.Blood = txtBloodFather.Text
    m_Father.Citizen = txtCitizenFather.Text
    m_Father.Nation = txtNationFather.Text
    m_Father.Religion = txtReligionFather.Text
End Sub

'dech put mother code here
Private Sub cmd__CloseMother_Click()
    actionCloseMother
End Sub

Private Sub cmd__DeleteMother_Click()
    actionDeleteMother

End Sub


Private Sub cmd__FindMother_Click()
    actionFindMother

End Sub

Private Sub cmd__NewMother_Click()
    actionNewMother

End Sub

Private Sub cmd__SaveMother_Click()
    actionSaveMother

End Sub


Private Sub txtBirthDayMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtBloodMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtCitizenMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtGenderMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtHightMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtIdentifierNumberMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtNameMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtNationMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtReligionMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtSurnameMother_Change()
    m_modifiedm = True

End Sub

Private Sub txtWeightMother_Change()
    m_modifiedm = True

End Sub


Private Sub actionNewMother()
    actionCloseMother
    Set m_Mother = m_factory.New("PersonInfo.Person")
    If m_Mother Is Nothing Then
         MsgBox "Cannot create new Person object."
         actionCloseMother
    Else
         EnableScreenMother True
         SyncObjectToScreenMother
         m_modifiedm = True
         m_modified = True
         
         cmd__DeleteMother.Enabled = False
    End If
End Sub

Private Sub actionFindMother()
    actionCloseMother
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = "PersonInfo.Person"
    idMother = CacheQuery1.FindId
    If idMother = "" Then Exit Sub
    Set m_Mother = m_factory.OpenId("PersonInfo.Person", idMother)
    If m_Mother Is Nothing Then
        MsgBox "Can not open object."
        actionCloseMother
    Else
        EnableScreenMother True
        SyncObjectToScreenMother
        m_object.MotherID = idMother
        m_modified = True
        m_modifiedm = False
    End If
End Sub

Private Sub actionSaveMother()
    SyncScreenToObjectMother
    On Error GoTo actionSaveError
    BeginWait
    m_Mother.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDeleteMother()
    If idMother = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObjectMother
    On Error GoTo actionDeleteError
    BeginWait
    m_Mother.sys_DeleteId (idMother)
    actionCloseMother
    EndWait
    m_modified = True
    m_modifiedm = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionCloseMother()
    If Not m_Mother Is Nothing And m_modifiedm Then
      If MsgBox("Do you want to save change mother?", vbYesNo) = vbYes Then actionSaveMother
    End If
    If Not m_Mother Is Nothing Then
      m_Mother.SYS_Close
      Set m_Mother = Nothing
    End If
    EnableScreenMother False
    EraseScreenMother
    idMother = ""
    If Not m_object Is Nothing Then
      m_object.MotherID = ""
      m_modified = True
      Set m_Mother = Nothing
    End If
    m_modifiedm = False
End Sub
Private Sub EnableScreenMother(Enabled As Boolean)
    lblIdentifierNumberMother.Enabled = Enabled
    txtIdentifierNumberMother.Enabled = Enabled
    lblGenderMother.Enabled = Enabled
    txtGenderMother.Enabled = Enabled
    lblNameMother.Enabled = Enabled
    txtNameMother.Enabled = Enabled
    lblSurnameMother.Enabled = Enabled
    txtSurnameMother.Enabled = Enabled
    lblBirthDayMother.Enabled = Enabled
    txtBirthDayMother.Enabled = Enabled
    lblHightMother.Enabled = Enabled
    txtHightMother.Enabled = Enabled
    lblWeightMother.Enabled = Enabled
    txtWeightMother.Enabled = Enabled
    lblBloodMother.Enabled = Enabled
    txtBloodMother.Enabled = Enabled
    lblCitizenMother.Enabled = Enabled
    txtCitizenMother.Enabled = Enabled
    lblNationMother.Enabled = Enabled
    txtNationMother.Enabled = Enabled
    lblReligionMother.Enabled = Enabled
    txtReligionMother.Enabled = Enabled
    cmd__SaveMother.Enabled = Enabled
    cmd__CloseMother.Enabled = Enabled
    cmd__DeleteMother.Enabled = Enabled
End Sub

Private Sub EraseScreenMother()
    txtIdentifierNumberMother.Text = ""
    txtGenderMother.Text = ""
    txtNameMother.Text = ""
    txtSurnameMother.Text = ""
    txtBirthDayMother.Text = ""
    txtHightMother.Text = ""
    txtWeightMother.Text = ""
    txtBloodMother.Text = ""
    txtCitizenMother.Text = ""
    txtNationMother.Text = ""
    txtReligionMother.Text = ""
End Sub

Private Sub SyncObjectToScreenMother()
    Dim obj As Object
    Dim i As Integer
    Dim item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtIdentifierNumberMother.Text = m_Mother.IdentifierNumber
    txtGenderMother.Text = m_Mother.Gender
    txtNameMother.Text = m_Mother.Name
    txtSurnameMother.Text = m_Mother.Surname
    If m_Mother.BirthDay <> 0 Then
       txtBirthDayMother.Text = m_Mother.BirthDay
    Else
       txtBirthDayMother.Text = ""
    End If
    txtHightMother.Text = m_Mother.Hight
    txtWeightMother.Text = m_Mother.Weight
    txtBloodMother.Text = m_Mother.Blood
    txtCitizenMother.Text = m_Mother.Citizen
    txtNationMother.Text = m_Mother.Nation
    txtReligionMother.Text = m_Mother.Religion
End Sub

Private Sub SyncScreenToObjectMother()
    m_Mother.IdentifierNumber = txtIdentifierNumberMother.Text
    m_Mother.Gender = txtGenderMother.Text
    m_Mother.Name = txtNameMother.Text
    m_Mother.Surname = txtSurnameMother.Text
'    m_Mother.BirthDay = txtBirthDay.Text
    m_Mother.Hight = txtHightMother.Text
    m_Mother.Weight = txtWeightMother.Text
    m_Mother.Blood = txtBloodMother.Text
    m_Mother.Citizen = txtCitizenMother.Text
    m_Mother.Nation = txtNationMother.Text
    m_Mother.Religion = txtReligionMother.Text
End Sub

'dech put guardian code here
Private Sub cmd__CloseGuardian_Click()
    actionCloseGuardian
End Sub

Private Sub cmd__DeleteGuardian_Click()
    actionDeleteGuardian

End Sub


Private Sub cmd__FindGuardian_Click()
    actionFindGuardian

End Sub

Private Sub cmd__NewGuardian_Click()
    actionNewGuardian

End Sub

Private Sub cmd__SaveGuardian_Click()
    actionSaveGuardian

End Sub


Private Sub txtBirthDayGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtBloodGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtCitizenGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtGenderGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtHightGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtIdentifierNumberGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtNameGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtNationGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtReligionGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtSurnameGuardian_Change()
    m_modifiedg = True

End Sub

Private Sub txtWeightGuardian_Change()
    m_modifiedg = True

End Sub


Private Sub actionNewGuardian()
    actionCloseGuardian
    Set m_Guardian = m_factory.New("PersonInfo.Person")
    If m_Guardian Is Nothing Then
         MsgBox "Cannot create new Person object."
         actionCloseGuardian
    Else
         EnableScreenGuardian True
         SyncObjectToScreenGuardian
         m_modified = True
         m_modifiedg = True
         cmd__DeleteGuardian.Enabled = False
    End If
End Sub

Private Sub actionFindGuardian()
    actionCloseGuardian
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = "PersonInfo.Person"
    idGuardian = CacheQuery1.FindId
    If idGuardian = "" Then Exit Sub
    Set m_Guardian = m_factory.OpenId("PersonInfo.Person", idGuardian)
    If m_Guardian Is Nothing Then
        MsgBox "Can not open object."
        actionCloseGuardian
    Else
        EnableScreenGuardian True
        SyncObjectToScreenGuardian
        m_object.GuardianID = idGuardian
        m_modified = True
        m_modifiedg = True
        
    End If
End Sub

Private Sub actionSaveGuardian()
    SyncScreenToObjectGuardian
    On Error GoTo actionSaveError
    BeginWait
    m_Guardian.sys_Save
    EndWait
    m_modifiedg = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDeleteGuardian()
    If idGuardian = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete guardian record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObjectGuardian
    On Error GoTo actionDeleteError
    BeginWait
    Set m_object.GuardianID = ""
    m_Guardian.sys_DeleteId (idGuardian)
    actionCloseGuardian
    EndWait
    m_modifiedg = False
    m_modified = True
    
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionCloseGuardian()
    If Not m_Guardian Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSaveGuardian
    End If
    If Not m_Guardian Is Nothing Then
      m_Guardian.SYS_Close
      Set m_Guardian = Nothing
    End If
    EnableScreenGuardian False
    EraseScreenGuardian
    idGuardian = ""
    If Not m_object Is Nothing Then
      m_object.GuardianID = ""
      m_modified = True
      Set m_Guardian = Nothing
    End If
    m_modifiedg = False
End Sub
Private Sub EnableScreenGuardian(Enabled As Boolean)
    lblIdentifierNumberGuardian.Enabled = Enabled
    txtIdentifierNumberGuardian.Enabled = Enabled
    lblGenderGuardian.Enabled = Enabled
    txtGenderGuardian.Enabled = Enabled
    lblNameGuardian.Enabled = Enabled
    txtNameGuardian.Enabled = Enabled
    lblSurnameGuardian.Enabled = Enabled
    txtSurnameGuardian.Enabled = Enabled
    lblBirthDayGuardian.Enabled = Enabled
    txtBirthDayGuardian.Enabled = Enabled
    lblHightGuardian.Enabled = Enabled
    txtHightGuardian.Enabled = Enabled
    lblWeightGuardian.Enabled = Enabled
    txtWeightGuardian.Enabled = Enabled
    lblBloodGuardian.Enabled = Enabled
    txtBloodGuardian.Enabled = Enabled
    lblCitizenGuardian.Enabled = Enabled
    txtCitizenGuardian.Enabled = Enabled
    lblNationGuardian.Enabled = Enabled
    txtNationGuardian.Enabled = Enabled
    lblReligionGuardian.Enabled = Enabled
    txtReligionGuardian.Enabled = Enabled
    cmd__SaveGuardian.Enabled = Enabled
    cmd__CloseGuardian.Enabled = Enabled
    cmd__DeleteGuardian.Enabled = Enabled
End Sub

Private Sub EraseScreenGuardian()
    txtIdentifierNumberGuardian.Text = ""
    txtGenderGuardian.Text = ""
    txtNameGuardian.Text = ""
    txtSurnameGuardian.Text = ""
    txtBirthDayGuardian.Text = ""
    txtHightGuardian.Text = ""
    txtWeightGuardian.Text = ""
    txtBloodGuardian.Text = ""
    txtCitizenGuardian.Text = ""
    txtNationGuardian.Text = ""
    txtReligionGuardian.Text = ""
End Sub

Private Sub SyncObjectToScreenGuardian()
    Dim obj As Object
    Dim i As Integer
    Dim item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtIdentifierNumberGuardian.Text = m_Guardian.IdentifierNumber
    txtGenderGuardian.Text = m_Guardian.Gender
    txtNameGuardian.Text = m_Guardian.Name
    txtSurnameGuardian.Text = m_Guardian.Surname
    If m_Guardian.BirthDay <> 0 Then
       txtBirthDayGuardian.Text = m_Guardian.BirthDay
    Else
       txtBirthDayGuardian.Text = ""
    End If
    txtHightGuardian.Text = m_Guardian.Hight
    txtWeightGuardian.Text = m_Guardian.Weight
    txtBloodGuardian.Text = m_Guardian.Blood
    txtCitizenGuardian.Text = m_Guardian.Citizen
    txtNationGuardian.Text = m_Guardian.Nation
    txtReligionGuardian.Text = m_Guardian.Religion
End Sub

Private Sub SyncScreenToObjectGuardian()
    m_Guardian.IdentifierNumber = txtIdentifierNumberGuardian.Text
    m_Guardian.Gender = txtGenderGuardian.Text
    m_Guardian.Name = txtNameGuardian.Text
    m_Guardian.Surname = txtSurnameGuardian.Text
'    m_Guardian.BirthDay = txtBirthDay.Text
    m_Guardian.Hight = txtHightGuardian.Text
    m_Guardian.Weight = txtWeightGuardian.Text
    m_Guardian.Blood = txtBloodGuardian.Text
    m_Guardian.Citizen = txtCitizenGuardian.Text
    m_Guardian.Nation = txtNationGuardian.Text
    m_Guardian.Religion = txtReligionGuardian.Text
End Sub







