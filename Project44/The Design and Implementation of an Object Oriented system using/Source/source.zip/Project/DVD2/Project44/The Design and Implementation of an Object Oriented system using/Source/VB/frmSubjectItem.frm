VERSION 5.00
Object = "{C37EFBE6-BC76-11D2-B65D-0000F87C2780}#1.0#0"; "CACHEQUERY.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmSubjectItem 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "SubjectItem"
   ClientHeight    =   6075
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   8400
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6242.877
   ScaleMode       =   0  'User
   ScaleWidth      =   8358.209
   StartUpPosition =   1  'CenterOwner
   Begin VB.PictureBox picPatch 
      BorderStyle     =   0  'None
      Height          =   248
      Left            =   0
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.VScrollBar VSCroll 
      Height          =   1168
      LargeChange     =   24
      Left            =   7035
      TabIndex        =   1
      Top             =   0
      Visible         =   0   'False
      Width           =   256
   End
   Begin VB.HScrollBar HSCroll 
      Height          =   248
      LargeChange     =   24
      Left            =   0
      TabIndex        =   0
      Top             =   5640
      Visible         =   0   'False
      Width           =   1206
   End
   Begin MSComctlLib.ListView ListViewPre 
      Height          =   1215
      Left            =   1560
      TabIndex        =   23
      Top             =   2880
      Width           =   5295
      _ExtentX        =   9340
      _ExtentY        =   2143
      View            =   3
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   2
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Code"
         Object.Width           =   4432
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "Name"
         Object.Width           =   4432
      EndProperty
   End
   Begin VB.Frame fra_Main 
      BorderStyle     =   0  'None
      Caption         =   "fra_Main"
      Height          =   5655
      Left            =   0
      TabIndex        =   3
      Top             =   0
      Width           =   7035
      Begin VB.TextBox txtPreCode 
         Height          =   316
         Left            =   1560
         TabIndex        =   26
         Text            =   "Text3"
         Top             =   4440
         Width           =   2775
      End
      Begin VB.CommandButton CmdAddPre 
         Caption         =   "Add"
         Height          =   385
         Left            =   1560
         TabIndex        =   25
         Top             =   5040
         Width           =   1095
      End
      Begin VB.CommandButton CmdDelPre 
         Caption         =   "Del"
         Height          =   385
         Left            =   2880
         TabIndex        =   24
         Top             =   5040
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Exit 
         Caption         =   "Cancel"
         Height          =   385
         Left            =   5785
         TabIndex        =   21
         Top             =   2370
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Close 
         Caption         =   "&Close"
         Height          =   385
         Left            =   5785
         TabIndex        =   20
         Top             =   1980
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Delete 
         Caption         =   "&Delete"
         Height          =   385
         Left            =   5785
         TabIndex        =   19
         Top             =   1500
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Save 
         Caption         =   "&Save"
         Height          =   385
         Left            =   5785
         TabIndex        =   18
         Top             =   1110
         Width           =   1095
      End
      Begin VB.CommandButton cmd__Find 
         Caption         =   "&Find..."
         Height          =   385
         Left            =   5785
         TabIndex        =   17
         Top             =   630
         Width           =   1095
      End
      Begin VB.CommandButton cmd__New 
         Caption         =   "&New"
         Height          =   385
         Left            =   5785
         TabIndex        =   16
         Top             =   240
         Width           =   1095
      End
      Begin VB.TextBox txtSubjectDesc 
         Height          =   316
         Left            =   1553
         TabIndex        =   15
         Text            =   "txtSubjectDesc"
         Top             =   1985
         Width           =   4020
      End
      Begin VB.TextBox txtTheoryUnit 
         Height          =   316
         Left            =   1553
         TabIndex        =   13
         Text            =   "txtTheoryUnit"
         Top             =   1635
         Width           =   1176
      End
      Begin VB.TextBox txtLabUnit 
         Height          =   316
         Left            =   1553
         TabIndex        =   11
         Text            =   "txtLabUnit"
         Top             =   1285
         Width           =   1176
      End
      Begin VB.TextBox txtSubjectNameEng 
         Height          =   316
         Left            =   1553
         TabIndex        =   9
         Text            =   "txtSubjectNameEng"
         Top             =   934
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectName 
         Height          =   316
         Left            =   1553
         TabIndex        =   7
         Text            =   "txtSubjectName"
         Top             =   584
         Width           =   4020
      End
      Begin VB.TextBox txtSubjectCode 
         Height          =   316
         Left            =   1553
         TabIndex        =   5
         Text            =   "txtSubjectCode"
         Top             =   234
         Width           =   4020
      End
      Begin VB.Label lblPreCode 
         Caption         =   "PrerequisiteCode"
         Height          =   255
         Left            =   1560
         TabIndex        =   27
         Top             =   4200
         Width           =   2055
      End
      Begin VB.Label lblPrerequisite 
         Caption         =   "PreRequisite"
         Height          =   330
         Left            =   1560
         TabIndex        =   22
         Top             =   2520
         Width           =   1305
      End
      Begin VB.Label lblSubjectCode 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectCode"
         Height          =   325
         Left            =   120
         TabIndex        =   4
         Top             =   240
         Width           =   1305
      End
      Begin VB.Label lblSubjectName 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectName"
         Height          =   325
         Left            =   120
         TabIndex        =   6
         Top             =   600
         Width           =   1305
      End
      Begin VB.Label lblSubjectNameEng 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectNameEng"
         Height          =   325
         Left            =   120
         TabIndex        =   8
         Top             =   960
         Width           =   1305
      End
      Begin VB.Label lblLabUnit 
         Alignment       =   1  'Right Justify
         Caption         =   "LabUnit"
         Height          =   325
         Left            =   120
         TabIndex        =   10
         Top             =   1320
         Width           =   1305
      End
      Begin VB.Label lblTheoryUnit 
         Alignment       =   1  'Right Justify
         Caption         =   "TheoryUnit"
         Height          =   325
         Left            =   120
         TabIndex        =   12
         Top             =   1680
         Width           =   1305
      End
      Begin VB.Label lblSubjectDesc 
         Alignment       =   1  'Right Justify
         Caption         =   "SubjectDesc"
         Height          =   325
         Left            =   120
         TabIndex        =   14
         Top             =   2040
         Width           =   1305
      End
   End
   Begin CACHEQUERYLib.CacheQuery CacheQuery1 
      Left            =   3840
      Top             =   1440
      _Version        =   65536
      _ExtentX        =   847
      _ExtentY        =   847
      _StockProps     =   0
      ClassName       =   ""
      QueryName       =   ""
   End
   Begin MSComDlg.CommonDialog dlgCommon 
      Left            =   3600
      Top             =   1320
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuObject 
      Caption         =   "&Object"
      Begin VB.Menu mnu__New 
         Caption         =   "&New"
      End
      Begin VB.Menu mnu__Find 
         Caption         =   "&Find..."
      End
      Begin VB.Menu mnu__Bar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Save 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnu__Delete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnu__Close 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnu__Bar2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu__Exit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "frmSubjectItem"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const m_classname = "Curriculum.SubjectItem"

Private m_factory As Object
Private m_object As Object
Private m_modified As Boolean
Private ff As Boolean
Private m_WaitFlag As Integer
Private id As Variant
Private disableclick As Boolean

Private Sub cmd__Close_Click()
    actionClose

End Sub

Private Sub cmd__Delete_Click()
    actionDelete

End Sub

Private Sub cmd__Exit_Click()
    actionExit

End Sub

Private Sub cmd__Find_Click()
    actionFind

End Sub

Private Sub cmd__New_Click()
    actionNew

End Sub

Private Sub cmd__Save_Click()
    actionSave

End Sub

Private Sub CmdAddPre_Click()
   Dim objectID As Long
   Dim subobject As Object
   objectID = val(frmLookup.Lookup(m_factory, "Curriculum.SubjectItem", "ByCode", _
      "Select Subject", , , False, 2, txtPreCode.Text))
    If objectID = 0 Then Exit Sub
    Set subobject = m_factory.OpenId("Curriculum.SubjectItem", objectID)
    If subobject Is Nothing Then
        MsgBox "Can not open object of subject ."
        actionClose
    Else
    Dim dd As Boolean
        dd = m_object.SetPrerequire(subobject.SubjectCode, subobject.SubjectName)
        m_modified = True
        Dim itmX As ListItem
        Set itmX = ListViewPre.ListItems.Add(, , subobject.SubjectCode)
            itmX.SubItems(1) = subobject.SubjectName
        subobject.SYS_Close
  
        ListViewPre.Refresh
    End If
End Sub

Private Sub CmdDelPre_Click()
    Dim dd As Boolean
    Dim ii As Integer
    m_modified = True
    ii = ListViewPre.SelectedItem.Index
    ListViewPre.ListItems.Remove (ii)
    m_object.RemoveAt (ii)
    ListViewPre.Refresh

End Sub

Private Sub Form_Load()
    Dim sdir As String
    actionClose
    Set m_factory = CacheForm.Factory
End Sub

Private Sub Form_Resize()
picPatch.Visible = False
If Me.ScaleWidth < fra_Main.Width Then
    HSCroll.Top = Me.ScaleHeight - HSCroll.Height
    HSCroll.Width = Me.ScaleWidth
    HSCroll.max = (fra_Main.Width - Me.ScaleWidth) \ 15
    HSCroll.Visible = True
    HSCroll.ZOrder
    If Me.ScaleHeight - HSCroll.Height < fra_Main.Height Then
        HSCroll.Width = Me.ScaleWidth - VSCroll.Width
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight - HSCroll.Height
        HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        picPatch.Top = HSCroll.Top
        picPatch.Left = HSCroll.Width
        picPatch.Visible = True
        picPatch.ZOrder
    Else
        VSCroll.Visible = False
    End If
Else
   HSCroll.Visible = False
    If Me.ScaleHeight < fra_Main.Height Then
        VSCroll.Left = Me.ScaleWidth - VSCroll.Width
        VSCroll.Height = Me.ScaleHeight
        VSCroll.max = (fra_Main.Height - Me.ScaleHeight) \ 15
        VSCroll.Visible = True
        VSCroll.ZOrder
        If Me.ScaleWidth - VSCroll.Width < fra_Main.Width Then
            VSCroll.Height = Me.ScaleHeight - HSCroll.Height
            HSCroll.Top = Me.ScaleHeight - HSCroll.Height
            HSCroll.Width = Me.ScaleWidth - VSCroll.Width
            VSCroll.max = (fra_Main.Height - Me.ScaleHeight + HSCroll.Height) \ 15
            HSCroll.max = (fra_Main.Width - Me.ScaleWidth + VSCroll.Width) \ 15
            HSCroll.Visible = True
            HSCroll.ZOrder
            picPatch.Top = HSCroll.Top
            picPatch.Left = HSCroll.Width
            picPatch.Visible = True
            picPatch.ZOrder
        End If
    Else
        VSCroll.Visible = False
    End If
End If
End Sub

Private Sub HScroll_Change()
    fra_Main.Left = -HSCroll.Value * 15
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

Private Sub mnu__Close_Click()
    actionClose

End Sub

Private Sub mnu__Delete_Click()
    actionDelete

End Sub

Private Sub mnu__Exit_Click()
    actionExit

End Sub

Private Sub mnu__Find_Click()
    actionFind

End Sub

Private Sub mnu__New_Click()
    actionNew

End Sub

Private Sub mnu__Save_Click()
    actionSave

End Sub

Private Sub txtLabUnit_Change()
    m_modified = True

End Sub

Private Sub txtPreCode_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = 13 Then
       CmdAddPre_Click
    End If

End Sub

Private Sub txtSubjectCode_Change()
    m_modified = True

End Sub

Private Sub txtSubjectDesc_Change()
    m_modified = True

End Sub

Private Sub txtSubjectName_Change()
    m_modified = True

End Sub

Private Sub txtSubjectNameEng_Change()
    m_modified = True

End Sub

Private Sub txtTheoryUnit_Change()
    m_modified = True

End Sub

Private Sub VScroll_Change()
    fra_Main.Top = -VSCroll.Value * 15
End Sub

Private Sub VScroll_Scroll()
    VScroll_Change
End Sub

Private Sub actionNew()
    actionClose
    Set m_object = m_factory.New(m_classname)
    If m_object Is Nothing Then
         MsgBox "Cannot create new object."
         actionClose
    Else
         EnableScreen True
         SyncObjectToScreen
         m_modified = True
         cmd__Delete.Enabled = False
         mnu__Delete.Enabled = False
    End If
End Sub

Private Sub actionFind()
    actionClose
    Set CacheQuery1.Factory = m_factory
    CacheQuery1.ClassName = m_classname
    id = CacheQuery1.FindId
    If id = "" Then Exit Sub
    Set m_object = m_factory.OpenId(m_classname, id)
    If m_object Is Nothing Then
        MsgBox "Can not open object."
        actionClose
    Else
        EnableScreen True
        SyncObjectToScreen
        m_modified = False
        Dim fy, Index As Integer
        fy = m_object.GetNumPre
        Index = 0
        ListViewPre.FullRowSelect = True
        Dim itmX As ListItem
        While (fy > Index)
            Index = Index + 1
            Set itmX = ListViewPre.ListItems.Add(, , m_object.GetPreCodeAt(Index))
            itmX.SubItems(1) = m_object.GetPreNameAt(Index)
        Wend
    End If
End Sub

Private Sub actionSave()
    SyncScreenToObject
    On Error GoTo actionSaveError
    BeginWait
    m_object.sys_Save
    EndWait
    m_modified = False
    Exit Sub
actionSaveError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionDelete()
    If id = "" Then
        MsgBox "Unable to delete record (ID unknown).", vbInformation
        Exit Sub
    End If
    If MsgBox("Are you sure that you want to delete this record?", vbYesNo) = vbNo Then Exit Sub
    SyncScreenToObject
    On Error GoTo actionDeleteError
    BeginWait
    m_object.sys_DeleteId (id)
    actionClose
    EndWait
    m_modified = False
    Exit Sub
actionDeleteError:
    EndWait
    MsgBox Err.Description
End Sub

Private Sub actionClose()
    If Not m_object Is Nothing And m_modified Then
      If MsgBox("Do you want to save?", vbYesNo) = vbYes Then actionSave
    End If
    If Not m_object Is Nothing Then
      m_object.SYS_Close
      Set m_object = Nothing
    End If
    EnableScreen False
    EraseScreen
    id = ""
    m_modified = False
End Sub

Private Sub actionExit()
    actionClose
    Unload Me
End Sub

Private Sub BeginWait()
    'turn on the hourglass cursor;
    'you can nest calls to BeginWait-the cursor is restored
    'after the same number of calls to EndWait

    m_WaitFlag = m_WaitFlag + 1

    Screen.MousePointer = vbHourglass
End Sub

Private Sub EndWait()
    'turn off the hourglass cursor

    If m_WaitFlag <= 0 Then Exit Sub

    m_WaitFlag = m_WaitFlag - 1

    If m_WaitFlag = 0 Then
        Screen.MousePointer = vbDefault
    End If
End Sub

Private Function minmax(val As Long, min As Long, max As Long)
    minmax = val
    If min <> -1 And val < min Then minmax = min
    If max <> -1 And val > max Then minmax = max
End Function

Public Sub ListView_ColumnClick(hList As ListView, ByVal ColumnHeader As MSComctlLib.ColumnHeader)
    'Handle any listview
    If hList.Sorted = False Then
       hList.Sorted = True
       hList.SortKey = ColumnHeader.Index - 1
       hList.SortOrder = lvwAscending
       Exit Sub
    End If
    If hList.SortKey = (ColumnHeader.Index - 1) Then
        If hList.SortOrder = lvwAscending Then
            hList.SortOrder = lvwDescending
        Else
            hList.SortOrder = lvwAscending
        End If
    Else
        hList.SortKey = ColumnHeader.Index - 1
    End If
End Sub
Private Sub EnableScreen(Enabled As Boolean)
    lblSubjectCode.Enabled = Enabled
    txtSubjectCode.Enabled = Enabled
    lblSubjectName.Enabled = Enabled
    txtSubjectName.Enabled = Enabled
    lblSubjectNameEng.Enabled = Enabled
    txtSubjectNameEng.Enabled = Enabled
    lblLabUnit.Enabled = Enabled
    txtLabUnit.Enabled = Enabled
    lblTheoryUnit.Enabled = Enabled
    txtTheoryUnit.Enabled = Enabled
    lblSubjectDesc.Enabled = Enabled
    txtSubjectDesc.Enabled = Enabled
    ListViewPre.Enabled = Enabled
    lblPrerequisite.Enabled = Enabled
    txtPreCode.Enabled = Enabled
    lblPreCode.Enabled = Enabled
    
    mnu__Save.Enabled = Enabled
    mnu__Close.Enabled = Enabled
    mnu__Delete.Enabled = Enabled
    cmd__Save.Enabled = Enabled
    cmd__Close.Enabled = Enabled
    cmd__Delete.Enabled = Enabled
    CmdAddPre.Enabled = Enabled
    CmdDelPre.Enabled = Enabled
End Sub

Private Sub EraseScreen()
    txtSubjectCode.Text = ""
    txtSubjectName.Text = ""
    txtSubjectNameEng.Text = ""
    txtLabUnit.Text = ""
    txtTheoryUnit.Text = ""
    txtSubjectDesc.Text = ""
    txtPreCode.Text = ""
    Dim num As Integer
    num = ListViewPre.ListItems.Count
    While num > 0
        ListViewPre.ListItems.Remove (num)
        num = ListViewPre.ListItems.Count
    Wend
End Sub

Private Sub SyncObjectToScreen()
    Dim obj As Object
    Dim i As Integer
    Dim Item As String
    Dim cnt As String
    Dim itemX As ListItem
    txtSubjectCode.Text = m_object.SubjectCode
    txtSubjectName.Text = m_object.SubjectName
    txtSubjectNameEng.Text = m_object.SubjectNameEng
    txtLabUnit.Text = m_object.LabUnit
    txtTheoryUnit.Text = m_object.TheoryUnit
    txtSubjectDesc.Text = m_object.SubjectDesc
End Sub

Private Sub SyncScreenToObject()
    m_object.SubjectCode = txtSubjectCode.Text
    m_object.SubjectName = txtSubjectName.Text
    m_object.SubjectNameEng = txtSubjectNameEng.Text
    m_object.LabUnit = txtLabUnit.Text
    m_object.TheoryUnit = txtTheoryUnit.Text
    m_object.SubjectDesc = txtSubjectDesc.Text
End Sub

