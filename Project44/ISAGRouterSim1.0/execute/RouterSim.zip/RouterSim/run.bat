set path=D:\jbuilder6\jdk1.3.1\bin\;%path%
java -jar RouterSim.jar