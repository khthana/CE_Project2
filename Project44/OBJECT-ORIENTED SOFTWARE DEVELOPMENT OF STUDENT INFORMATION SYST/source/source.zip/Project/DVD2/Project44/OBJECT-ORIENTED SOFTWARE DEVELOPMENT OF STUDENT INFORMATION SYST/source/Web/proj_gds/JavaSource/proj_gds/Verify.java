package proj_gds;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (5/3/2002 14:36:27)
 * @author: Administrator
 */
public class Verify extends HttpServlet {
    /**
     * Process incoming HTTP POST requests 
     * 
     * @param request Object that encapsulates the request to the servlet 
     * @param response Object that encapsulates the response from the servlet
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        performTask(request, response);

    }
    /**
     * Returns the servlet info string.
     */
    public String getServletInfo() {

        return super.getServletInfo();

    }
    /**
     * Initializes the servlet.
     */
    public void init() {
        // insert code to initialize the servlet here

    }
    /**
     * Process incoming requests for information
     * 
     * @param request Object that encapsulates the request to the servlet 
     * @param response Object that encapsulates the response from the servlet
     */
    public void performTask(
        HttpServletRequest request,
        HttpServletResponse response) {

        try {
            response.setContentType("text/html");

            PrintWriter out = response.getWriter();
            HttpSession session = request.getSession(true);

            String id = request.getParameter("id");
            String password = request.getParameter("password");

            Connection dbconn;
            Statement statement;

            String msgout = "";
            String fname = null, lname = null;
            try {
                String userid = "Administrator";
                String passwd = "maspong";
                String url = "jdbc:db2://192.168.0.13/Graduate";
                Class.forName("COM.ibm.db2.jdbc.net.DB2Driver").newInstance();
                dbconn = DriverManager.getConnection(url, userid, passwd);
                statement = dbconn.createStatement();
                String query =
                    "SELECT NameT,FamilyT "
                        + "FROM  Student "
                        + "WHERE StuId= '"
                        + id
                        + "'"
                        + "and Password = '"
                        + password
                        + "'";
                ResultSet resultset = statement.executeQuery(query);
                while (resultset.next()) {
                    fname = resultset.getString(1);
                    lname = resultset.getString(2);
                }
                if (fname == null || lname == null)
                    response.sendRedirect("../jsp/proj_gds/LoginPage.jsp");
                else {
                    session.setAttribute("ID", id);
                    session.setAttribute("PASSWORD", password);
                    session.setAttribute("ISLOGIN", "true");
                    session.setAttribute("Statement", statement);
                    proj_gds.StudentBean student = new StudentBean();
                    student.setAllData(
                        (Statement) session.getAttribute("Statement"),
                        (String) session.getAttribute("ID"));
                    session.setAttribute("Student", student);
                    response.sendRedirect("../jsp/proj_gds/MainPage.jsp");
                }

            } catch (ClassNotFoundException cnfex) {
                cnfex.printStackTrace();
                msgout = "Connection unsuccessful\n" + cnfex.toString();
            } catch (SQLException sqlex) {
                sqlex.printStackTrace();
                msgout = "Connection unsuccessful\n" + sqlex.toString();
                out.println(sqlex);
            } catch (Exception excp) {
                excp.printStackTrace();
                msgout = excp.toString();
            }
            out.println(msgout);
        } catch (Throwable theException) {
            // uncomment the following line when unexpected exceptions
            // are occuring to aid in debugging the problem.
            //theException.printStackTrace();
        }
    }
}
