<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<% student = (StudentBean)session.getAttribute("Student");%>
<div align="center">
  <p>&nbsp;</p>
  <p align="center"><span class="HEAD2DETAIL">ŧ����¹</span><br>
    <br>
    <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="preNT"/>
    <jsp:getProperty name="student" property="nameT"/>
    &nbsp;&nbsp; 
    <jsp:getProperty name="student" property="familyT"/>
    </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="stuId"/>
    </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="subCourse"/>
    </font> <br>
    <span class="HEAD1DETAIL">�Ң��Ԫ�</span><font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="major"/>
    &nbsp;</font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="department"/>
    </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="faculty"/>
    </font><br>
  </p>
  <table width="600" border="0" align="center" height="203">
    <tr> 
      <td height="247" valign="top"> 
        <div align="center"><span class="HEAD1DETAIL">����Ԫҷ��������ŧ����¹</span><br>
          <br>
        </div>
        <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="100" class="NORMALDETAIL">
          <tr bgcolor="#FFFF99" align="center"> 
            <td width="12%" align="center" height="30"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="56%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">˹��¡Ԩ</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�͹</font></div>
              </font></td>
            <td width="12%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">������</font></div>
              </font></td>
          </tr>
 <% 
 			int i=0;	
			RegisBean regisBean = new RegisBean();
			CurTime cur = new CurTime();
			String msgout = "";
			String query;
			ResultSet resultset;
			try {
		    cur.bind((Statement)session.getAttribute("Statement"));
			query ="SELECT SUBJECT.SUBID , SUBJECT.ENAME , SUBJECT.CREDIT ,"+
											"SECTION.SEC , REGISTER.TYPE  "+
							"FROM  STUDENT,  REGISTER, SECTION, SUBJECT "+
							"WHERE ((STUDENT.STUID = REGISTER.STUID AND "+
												" SECTION.SECID = REGISTER.SECID AND "+
												"SUBJECT.SUBID = SECTION.SUBID ) AND "+
												"(( STUDENT.STUID = '"+(String)session.getAttribute("ID")+"' ) AND "+
												"( REGISTER.STATUS = 'P' )AND (REGISTER.SEM = "+cur.getSemister()+")"+
												"AND ( REGISTER.YEAR = '"+cur.getTEduYear()+"' )"+
												"AND (SECTION.STATUS = 'A')))";
			resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
			while (resultset.next()) {
				regisBean.SubjectRegis[i][0] = resultset.getString(1);
				regisBean.SubjectRegis[i][1] = resultset.getString(2);
				regisBean.SubjectRegis[i][2] = resultset.getString(3);
				regisBean.SubjectRegis[i][3] = resultset.getString(4);
				regisBean.SubjectRegis[i][4] = resultset.getString(5);
				i++;
			}
			int j=0;
			String Cancel = (String)session.getAttribute("Cancel");
			if (Cancel.equals("have")){
			while(i<regisBean.SubjectRegis.length&&j<3) {
				regisBean.SubjectRegis[i][0]=request.getParameter("subId"+Integer.toString(j+1));
				regisBean.SubjectRegis[i][1]=request.getParameter("subName"+Integer.toString(j+1));
				regisBean.SubjectRegis[i][2]=request.getParameter("subCredit"+Integer.toString(j+1));
				regisBean.SubjectRegis[i][3]=request.getParameter("subSec"+Integer.toString(j+1));
				regisBean.SubjectRegis[i][4]=request.getParameter("subType"+Integer.toString(j+1));
				j++;
				i++;
			}
			}
		if(!regisBean.checkAll((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID")))
				response.sendRedirect("RegistrationPage1.jsp");
		i=0;
		while(i<regisBean.SubjectRegis.length & !regisBean.SubjectRegis[i][0].equals(""))  {
			if (regisBean.SubjectRegis[i][1].equals("") | regisBean.SubjectRegis[i][2].equals("") |
				 regisBean.SubjectRegis[i][3].equals("") | regisBean.SubjectRegis[i][4].equals("") )   {
						response.sendRedirect("RegistrationPage1.jsp");
						break;
					}
			out.println("<tr> "+
            "<td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\">"+
			regisBean.SubjectRegis[i][0]+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\">"+
			regisBean.SubjectRegis[i][1]+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
            " <div align=\"center\">"+regisBean.SubjectRegis[i][2]+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+regisBean.SubjectRegis[i][3]+"</div>"+
            "</td>");
			String Type="Ordit";
			if(regisBean.SubjectRegis[i][4].equals("C")) Type = "\u0E1B\u0E01\u0E15\u0E34";
            out.println("<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+Type+"</div>"+
            "</td>"+
          "</tr>");
			i++; 
		  }
		  session.setAttribute("RegisBean",regisBean);
			} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			msgout = "Connection unsuccessful\n" + sqlex.toString();
			} catch (Exception excp) {
			excp.printStackTrace();
			msgout = excp.toString();
		}  
		%>
          <tr bordercolor="#FFFFCC"> 
            <td align="center" bgcolor="#FFFFCC" valign="top" colspan="2" height="30"> 
              <div align="right">���</div>
            </td>
            <td bgcolor="#FFFFCC" valign="top" colspan="3" height="30"> 
              <div align="center"><%=regisBean.TotalCredit%> ˹��¡Ե</div>
           </td>
          </tr>
        </table>
        <div align="right">
<form name="form1" method="post" action="RegistrationPage3.jsp">
            <input type="submit" name="Submit" value="����">
            <br>
            <span class="HEAD1DETAIL">&gt;&gt;<a href="RegistrationPage1.jsp">��Ѻ����</a></span><br>
          </form>
        </div>
      </td>
    </tr>
  </table>
  <p> <%@ include file = "footer.inc" %><br>
  </p>
</div>
</body>
</html>
