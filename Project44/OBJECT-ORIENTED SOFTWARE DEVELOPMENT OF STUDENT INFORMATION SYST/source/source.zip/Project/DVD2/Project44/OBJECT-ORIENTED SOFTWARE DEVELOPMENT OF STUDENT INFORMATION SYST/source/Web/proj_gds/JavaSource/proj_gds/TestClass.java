package proj_gds;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.io.*;

/**
 * Insert the type's description here.
 * Creation date: (3/3/2002 13:42:35)
 * @author: Administrator
 */
public class TestClass extends JPanel {
	private JTextField ivjJTextField1 = null;
	private JTextField ivjJTextField2 = null;
    private Statement statement;
	private JTextArea ivjJTextArea1 = null;
	private JScrollPane ivjJScrollPane1 = null;
    /**
     * TestClass constructor comment.
     */
    public TestClass() {
        super();
        initialize();
    }
    /**
     * TestClass constructor comment.
     * @param layout java.awt.LayoutManager
     */
    public TestClass(java.awt.LayoutManager layout) {
        super(layout);
    }
    /**
     * TestClass constructor comment.
     * @param layout java.awt.LayoutManager
     * @param isDoubleBuffered boolean
     */
    public TestClass(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
        super(layout, isDoubleBuffered);
    }
    /**
     * TestClass constructor comment.
     * @param isDoubleBuffered boolean
     */
    public TestClass(boolean isDoubleBuffered) {
        super(isDoubleBuffered);
    }
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			ivjJScrollPane1.setBounds(39, 68, 378, 120);
			getJScrollPane1().setViewportView(getJTextArea1());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1");
			ivjJTextArea1.setBounds(0, 0, 371, 117);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
    /**
     * Return the JTextField1 property value.
     * @return javax.swing.JTextField
     */
    /* WARNING: THIS METHOD WILL BE REGENERATED. */
    private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1");
			ivjJTextField1.setFont(new java.awt.Font("sansserif", 0, 12));
			ivjJTextField1.setText("ter");
			ivjJTextField1.setBounds(121, 34, 144, 20);
			ivjJTextField1.setColumns(0);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
    /**
     * Return the JTextField2 property value.
     * @return javax.swing.JTextField
     */
    /* WARNING: THIS METHOD WILL BE REGENERATED. */
    private javax.swing.JTextField getJTextField2() {
	if (ivjJTextField2 == null) {
		try {
			ivjJTextField2 = new javax.swing.JTextField();
			ivjJTextField2.setName("JTextField2");
			ivjJTextField2.setFont(new java.awt.Font("sansserif", 0, 12));
			ivjJTextField2.setBounds(110, 218, 151, 18);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJTextField2;
}
    /**
     * Called whenever the part throws an exception.
     * @param exception java.lang.Throwable
     */
    private void handleException(java.lang.Throwable exception) {

        /* Uncomment the following lines to print uncaught exceptions to stdout */
        // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
        // exception.printStackTrace(System.out);
    }
    /**
     * Initialize the class.
     */
    /* WARNING: THIS METHOD WILL BE REGENERATED. */
    private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("TestClass");
		setFont(new java.awt.Font("sansserif", 0, 12));
		setLayout(null);
		setAlignmentY(java.awt.Component.BOTTOM_ALIGNMENT);
		setSize(535, 346);
		add(getJTextField1(), getJTextField1().getName());
		add(getJTextField2(), getJTextField2().getName());
		add(getJScrollPane1(), getJScrollPane1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}


        Connection dbconn;
        String msgout = "";
        String fname = null, lname = null;
        try {
            String userid = "Administrator";
            String passwd = "maspong";
            String url = "jdbc:db2://192.168.0.13/Graduate";
            Class.forName("COM.ibm.db2.jdbc.net.DB2Driver").newInstance();
            dbconn = DriverManager.getConnection(url, userid, passwd);
            statement = dbconn.createStatement();
         } catch (ClassNotFoundException cnfex) {
            cnfex.printStackTrace();
            //           msgout = "Connection unsuccessful\n" + cnfex.toString();
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
            //            msgout = "Connection unsuccessful\n" + sqlex.toString();
            //            out.println(sqlex);
        } catch (Exception excp) {
            excp.printStackTrace();
            //           msgout = excp.toString();
        }

        MsgAlert M1 = new MsgAlert();
        try {
        M1.bind(statement,"42015313");

        getJTextArea1().setText(M1.getMsg());
       	getJTextField1().setText(M1.getSem() +M1.getSem() +M1.getSem() +M1.getSem());
     //   getJTextField2().setText(Integer.toString(M1.getBd().compareTo(new java.util.Date())));        
        }catch (SQLException sqlex) {
            sqlex.printStackTrace();}
     // user code end
}
    /**
     * main entrypoint - starts the part when it is run as an application
     * @param args java.lang.String[]
     */
    public static void main(java.lang.String[] args) {
        try {
            javax.swing.JFrame frame = new javax.swing.JFrame();
            TestClass aTestClass;
            aTestClass = new TestClass();
            frame.setContentPane(aTestClass);
            frame.setSize(aTestClass.getSize());
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent e) {
                    System.exit(0);
                };
            });
            frame.show();
            java.awt.Insets insets = frame.getInsets();
            frame.setSize(
                frame.getWidth() + insets.left + insets.right,
                frame.getHeight() + insets.top + insets.bottom);
            frame.setVisible(true);

        } catch (Throwable exception) {
            System.err.println("Exception occurred in main() of javax.swing.JPanel");
            exception.printStackTrace(System.out);
        }
    }
}
