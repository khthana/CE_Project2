<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ��������ǹ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
 <body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page import="java.sql.*, java.util.*, java.io.*,java.lang.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<% student = (proj_gds.StudentBean)session.getAttribute("Student");%>
<%	String address1 = proj_gds.CharsetConverter.MS874ToUnicode(request.getParameter("address1"));
		String address2 = proj_gds.CharsetConverter.MS874ToUnicode(request.getParameter("address2"));
		String tel1 = request.getParameter("tel1");
		String tel2 = request.getParameter("tel2");
		String email = request.getParameter("email");
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		%>
		<% 
			if ( password1.equals("") & password2.equals("")) 
					password1=(String)session.getAttribute("PASSWORD");
			else if (password1.equals("") | password2.equals("")) {
					response.sendRedirect("PersonalDataPage.jsp");
					password1=(String)session.getAttribute("PASSWORD");
				}
					else if (!password2.equals((String)session.getAttribute("PASSWORD"))) {
								response.sendRedirect("PersonalDataPage.jsp");
								password1=(String)session.getAttribute("PASSWORD");
							}
		%>
		<%
			String id = student.getStuId();
			String msgout = "";
		try
      {        
			Statement	statement = (Statement)session.getAttribute("Statement");
			String query = "UPDATE  Student "+
										"SET  Addr1 = '"+address1+"',Addr2 = '"+address2+"', Tel1 = '"+tel1+"', Tel2 = '"+tel2+"', Email = '"+email+"' , Password = '"+password1+"' "+
										"WHERE StuId= '"+id+"'" ;
			int result = statement.executeUpdate(query);
			session.setAttribute("PASSWORD", password1);
	      }
            catch ( SQLException sqlex )
      {    
			sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp )
      {    
            excp.printStackTrace();
            msgout = excp.toString();
      }
out.println(msgout);
%>
<jsp:setProperty name="student" property="addr1" value='<%=address1%>'/>
<jsp:setProperty name="student" property="addr2" value='<%=address2%>'/>
<jsp:setProperty name="student" property="tel1" value='<%=tel1%>'/>
<jsp:setProperty name="student" property="tel2" value='<%=tel2%>'/>
<jsp:setProperty name="student" property="email" value='<%=email%>'/>
<%session.setAttribute("Student",student);%>
<div align="center">
  <p>&nbsp;</p>
  <p><font size="5" class="HEAD2DETAIL">��������ǹ���</font></p>
    
  <table width="600" border="0" cellspacing="1" cellpadding="5" class="NORMALDETAIL">
    <tr> 
      <td colspan="2"> 
        <div align="center"> <font color="#FF9900" size="3" class="HEAD1DETAIL_C">
          <jsp:getProperty name="student" property="preNT"/>
          <jsp:getProperty name="student" property="nameT"/>
          &nbsp;&nbsp; 
          <jsp:getProperty name="student" property="familyT"/>
          </font> <font size="3"> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> 
          <font color="#FF9900" class="HEAD1DETAIL_C"> 
          <jsp:getProperty name="student" property="stuId" />
          </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
          <jsp:getProperty name="student" property="subCourse" />
          </font> <br>
          <span class="HEAD1DETAIL">�Ң��Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
          <jsp:getProperty name="student" property="major"/>
          </font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
          <jsp:getProperty name="student" property="department"/>
          </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
          <jsp:getProperty name="student" property="faculty"/>
          </font></font></div>
      </td>
    </tr>
    <tr> 
      <td width="33%" valign="top"> 
        <div align="right">���������������</div>
      </td>
      <td width="67%" class="NORMALDETAIL_C"> 
        <jsp:getProperty name="student" property="addr2"/>
      </td>
    </tr>
    <tr> 
      <td width="33%" height="30"> 
        <div align="right">�������Ѿ������������</div>
      </td>
      <td width="67%" height="30" class="NORMALDETAIL_C"> 
        <jsp:getProperty name="student" property="tel2"/>
      </td>
    </tr>
    <tr> 
      <td width="33%" valign="top"> 
        <div align="right">�������Ѩ�غѹ</div>
      </td>
      <td width="67%" class="NORMALDETAIL_C"> 
        <jsp:getProperty name="student" property="addr1"/>
      </td>
    </tr>
    <tr> 
      <td width="33%" height="30"> 
        <div align="right">�������Ѿ��Ѩ�غѹ</div>
      </td>
      <td width="67%" height="30" class="NORMALDETAIL_C"> 
        <jsp:getProperty name="student" property="tel1"/>
      </td>
    </tr>
    <tr> 
      <td width="33%" height="30"> 
        <div align="right">�������</div>
      </td>
      <td width="67%" height="30" class="NORMALDETAIL_C"> 
        <jsp:getProperty name="student" property="email"/>
      </td>
    </tr>
  </table>
</div>
  <br>
  <div align="center"><A HREF="MainPage.jsp"><font color="#FF0000" class="NORMALDETAIL_C">˹����ѡ</font></A></div>
	<%@ include file = "footer.inc" %>
</body>
</html>
