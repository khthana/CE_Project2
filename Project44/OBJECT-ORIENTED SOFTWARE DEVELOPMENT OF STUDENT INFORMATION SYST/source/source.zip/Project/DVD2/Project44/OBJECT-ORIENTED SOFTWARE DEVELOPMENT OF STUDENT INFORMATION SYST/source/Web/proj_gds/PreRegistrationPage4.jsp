<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,java.text.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<%student = (proj_gds.StudentBean)session.getAttribute("Student");%>
<%
	if(!student.checkRegis((Statement)session.getAttribute("Statement"),"P")) {
		RegisBean regisBean = (RegisBean)session.getAttribute("RegisBean");
		regisBean.putDB((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"),"P");
	}
	java.util.Date PBedate = new java.util.Date();
	java.util.Date PExdate = new java.util.Date();
	java.util.Date Bedate = new java.util.Date();
	java.util.Date Exdate = new java.util.Date();
	String msgout;
	try{
		String query = "SELECT BEDATE,EXDATE "+
									"FROM TIMESCH "+
									"WHERE NAME='\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32'  ";
		ResultSet resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
		if (resultset.next()) {
			PBedate = resultset.getDate(1);
			PExdate = resultset.getDate(2);
		}
		query = "SELECT BEDATE,EXDATE "+
									"FROM TIMESCH "+
									"WHERE 						NAME='\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19'"	;
		resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
		if (resultset.next()) {
			Bedate = resultset.getDate(1);
			Exdate = resultset.getDate(2);
		}
	 } catch (SQLException sqlex) {
        sqlex.printStackTrace();
        msgout = "Connection unsuccessful\n" + sqlex.toString();
    } catch (Exception excp) {
        excp.printStackTrace();
        msgout = excp.toString();
    }
%>
<body bgcolor="#FFFFCC" text="#0066FF">
<p align="center">&nbsp;</p>
<p align="center"><font size="5" class="HEAD2DETAIL">��й��س��ŧ����¹��ǧ˹����������ó�����<br>
  </font><font size="5" class="HEAD2DETAIL">��ѧ�ҡ���ࢵŧ����¹��ǧ˹��(<font color="#FF9900" class="HEAD2DETAIL_C"><%=DateFormat.getDateInstance().format(PBedate)%> - 
  <%=DateFormat.getDateInstance().format(PExdate)%></font><span class="HEAD2DETAIL">)<br>
  �س���繵�ͧ��Ǩ�ͺ�š��ŧ����¹��ԧ�ա����<br>
  </span></font><font size="5" class="HEAD2DETAIL"><b>���� <font color="#FF9900" class="HEAD2DETAIL_C"><%=DateFormat.getDateInstance().format(Bedate)%> - 
  <%=DateFormat.getDateInstance().format(Exdate)%></font></b></font></p>
<p align="center"><a href="MainPage.jsp"><font color="#FF6600"><span class="HEAD1DETAIL_C">��Ѻ�˹���á</span></font></a><br>
  <%@ include file = "footer.inc" %> </p>
</body>
</html>
