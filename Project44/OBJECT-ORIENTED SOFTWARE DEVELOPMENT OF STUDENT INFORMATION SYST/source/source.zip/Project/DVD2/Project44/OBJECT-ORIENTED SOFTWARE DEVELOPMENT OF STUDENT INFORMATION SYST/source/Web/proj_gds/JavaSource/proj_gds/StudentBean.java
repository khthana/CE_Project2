package proj_gds;

import java.sql.*;
/**
 * Insert the type's description here.
 * Creation date: (29/1/2002 9:50:37)
 * @author: Administrator
 */
public class StudentBean {
    private String stuId,
        preNT,
        nameT,
        familyT,
        addr1,
        addr2,
        tel1,
        tel2,
        mobile,
        email,
        subCourse,
        course,
        major,
        department,
        faculty;
    public StudentBean() {
        super();
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @return String
     */
    public String getAddr1() {
        return addr1;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @return String
     */
    public String getAddr2() {
        return addr2;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @return String
 */
public String getCourse() {
	return course;
}
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @return String
 */
public String getDepartment() {
	return department;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @return String
     */
    public String getEmail() {
        return email;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @return String
 */
public String getFaculty() {
	return faculty;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @return String
     */
    public String getFamilyT() {
        return familyT;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @return String
 */
public String getMajor() {
	return major;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @return String
     */
    public String getMobile() {
        return mobile;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @return String
     */
    public String getNameT() {
        return nameT;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @return String
     */
    public String getPreNT() {
        return preNT;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @return String
     */
    public String getStuId() {
        return stuId;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @return String
 */
public String getSubCourse() {
	return subCourse;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @return String
     */
    public String getTel1() {
        return tel1;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @return String
     */
    public String getTel2() {
        return tel2;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @param newAddr1 String
     */
    public void setAddr1(String newAddr1) {
        addr1 = newAddr1;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @param newAddr2 String
     */
    public void setAddr2(String newAddr2) {
        addr2 = newAddr2;
    }
/**
 * Insert the method's description here.
 * Creation date: (3/3/2002 14:50:07)
 * @param state java.sql.Statement
 * @param stuId java.lang.String
 */
public void setAllData(java.sql.Statement statement, String stuId) {
    String msgout = "";
    try {
        String query =
            "SELECT  S.PRENT ,NAMET,FAMILYT,ADDR1,ADDR2,TEL1,TEL2,MOBILE,EMAIL,"
                + "U.TNAME AS UNAME,C.TNAME  AS CNAME,M.TNAME AS MNAME,D.TNAME AS DNAME,F.TNAME  AS FNAME "
                + "FROM  STUDENT S,"
                + "SUBCOURSE U,"
                + "COURSE C,"
                + "MAJOR M,"
                + "DEPARTMENT D,"
                + "FACULTY F "
                + "WHERE U.SCID = S.SCID AND "
                + "C.COID = U.COID AND "
                + "M.MAID = C.MAID AND "
                + "D.DEPID = M.DEPID AND "
                + "F.FACID = D.FACID "
                + "AND STUID = '"
                + stuId
                + "'";
        ResultSet resultset = statement.executeQuery(query);
        while (resultset.next()) {
            this.setPreNT(resultset.getString("PRENT"));
            this.setNameT(resultset.getString("NAMET"));
            this.setFamilyT(resultset.getString("FAMILYT"));
            this.setAddr1(resultset.getString("ADDR1"));
            this.setAddr2(resultset.getString("ADDR2"));
            this.setTel1(resultset.getString("TEL1"));
            this.setTel2(resultset.getString("TEL2"));
            this.setMobile(resultset.getString("MOBILE"));
            this.setEmail(resultset.getString("EMAIL"));
            this.setSubCourse(resultset.getString("UNAME"));
            this.setCourse(resultset.getString("CNAME"));
            this.setMajor(resultset.getString("MNAME"));
            this.setDepartment(resultset.getString("DNAME"));
            this.setFaculty(resultset.getString("FNAME"));
        }
        this.setStuId(stuId);
        //dbconn.close();
  
}  catch (Exception excp) {
        excp.printStackTrace();
        msgout = excp.toString();
        System.out.println(msgout);
    }
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @param newCourse String
 */
public void setCourse(String newCourse) {
	course = newCourse;
}
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @param newDepartment String
 */
public void setDepartment(String newDepartment) {
	department = newDepartment;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @param newEmail String
     */
    public void setEmail(String newEmail) {
        email = newEmail;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @param newFaculty String
 */
public void setFaculty(String newFaculty) {
	faculty = newFaculty;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:19)
     * @param newFamilyT String
     */
    public void setFamilyT(String newFamilyT) {
        familyT = newFamilyT;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @param newMajor String
 */
public void setMajor(String newMajor) {
	major = newMajor;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @param newMobile String
     */
    public void setMobile(String newMobile) {
        mobile = newMobile;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @param newNameT String
     */
    public void setNameT(String newNameT) {
        nameT = newNameT;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @param newPreNT String
     */
    public void setPreNT(String newPreNT) {
        preNT = newPreNT;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @param newStuId String
     */
    public void setStuId(String newStuId) {
        stuId = newStuId;
    }
/**
 * Insert the method's description here.
 * Creation date: (28/2/2002 14:56:59)
 * @param newSubCourse String
 */
public void setSubCourse(String newSubCourse) {
	subCourse = newSubCourse;
}
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @param newTel1 String
     */
    public void setTel1(String newTel1) {
        tel1 = newTel1;
    }
    /**
     * Insert the method's description here.
     * Creation date: (28/2/2002 1:01:20)
     * @param newTel2 String
     */
    public void setTel2(String newTel2) {
        tel2 = newTel2;
    }
}
