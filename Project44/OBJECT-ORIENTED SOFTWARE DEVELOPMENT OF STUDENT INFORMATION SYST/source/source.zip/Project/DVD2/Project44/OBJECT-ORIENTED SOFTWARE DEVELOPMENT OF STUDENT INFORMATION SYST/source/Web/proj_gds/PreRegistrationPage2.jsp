<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<% student = (StudentBean)session.getAttribute("Student");%>
<div align="center">
  <p>&nbsp;</p>
  <p align="center"><span class="HEAD2DETAIL">ŧ����¹</span><br>
    <br>
    <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="preNT"/>
    <jsp:getProperty name="student" property="nameT"/>
    &nbsp;&nbsp; 
    <jsp:getProperty name="student" property="familyT"/>
    </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="stuId"/>
    </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="subCourse"/>
    </font> <br>
    <span class="HEAD1DETAIL">�Ң��Ԫ�</span><font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="major"/>
    &nbsp;</font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="department"/>
    </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="faculty"/>
    </font><br>
  </p>
  <table width="600" border="0" align="center" height="203">
    <tr> 
      <td height="247"> 
        <div align="center"><span class="HEAD1DETAIL">����Ԫҷ��������ŧ����¹</span><br>
        </div>
        <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="100" class="NORMALDETAIL">
          <tr bgcolor="#FFFF99" align="center"> 
            <td width="12%" align="center" height="30"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="56%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">˹��¡Ԩ</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�͹</font></div>
              </font></td>
            <td width="12%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">������</font></div>
              </font></td>
          </tr>
 <% 
 		int i=0;	
		RegisBean regisBean = new RegisBean();
		for ( i = 0;i <regisBean.SubjectRegis.length;i++){
			regisBean.SubjectRegis[i][0]=request.getParameter("subId"+Integer.toString(i+1));
			regisBean.SubjectRegis[i][1]=request.getParameter("subName"+Integer.toString(i+1));
			regisBean.SubjectRegis[i][2]=request.getParameter("subCredit"+Integer.toString(i+1));
			regisBean.SubjectRegis[i][3]=request.getParameter("subSec"+Integer.toString(i+1));
			regisBean.SubjectRegis[i][4]=request.getParameter("subType"+Integer.toString(i+1));
		}
		if(!regisBean.checkAll((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID")))
			response.sendRedirect("PreRegistrationPage1.jsp");
		i=0;
		while(i<regisBean.SubjectRegis.length & !regisBean.SubjectRegis[i][0].equals(""))  {
			if (regisBean.SubjectRegis[i][1].equals("") | regisBean.SubjectRegis[i][2].equals("") |
				 regisBean.SubjectRegis[i][3].equals("") | regisBean.SubjectRegis[i][4].equals("") )   {
						response.sendRedirect("PreRegistration1.jsp");
						break;
					}
			out.println("<tr> "+
            "<td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\">"+
			regisBean.SubjectRegis[i][0]+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\">"+
			regisBean.SubjectRegis[i][1]+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
            " <div align=\"center\">"+regisBean.SubjectRegis[i][2]+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+regisBean.SubjectRegis[i][3]+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+regisBean.SubjectRegis[i][4]+"</div>"+
            "</td>"+
          "</tr>");
			i++; 
		  }
		  session.setAttribute("RegisBean",regisBean);
		  %>
          <tr bordercolor="#FFFFCC"> 
            <td align="center" bgcolor="#FFFFCC" valign="top" colspan="2" height="30"> 
              <div align="right">���</div>
            </td>
            <td bgcolor="#FFFFCC" valign="top" colspan="3" height="30"> 
              <div align="center"><%=regisBean.TotalCredit%> ˹��¡Ե</div>
              <div align="center"></div>
              <div align="center"></div>
            </td>
          </tr>
        </table>
        <div align="right">
<form name="form1" method="post" action="PreRegistrationPage3.jsp">
            <input type="submit" name="Submit" value="����">
            <br>
            <span class="HEAD1DETAIL">&gt;&gt;<a href="PreRegistrationPage1.jsp">��Ѻ����</a></span><br>
          </form>
        </div>
      </td>
    </tr>
  </table>
  <p> <%@ include file = "footer.inc" %><br>
  </p>
</div>
</body>
</html>
