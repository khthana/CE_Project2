package proj_gds;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Insert the type's description here.
 * Creation date: (8/3/2002 4:56:31)
 * @author: Administrator
 */
public class DataSub {
    private String subId;
    private String subName;
    private String subCredit;
    /**
     * DataSub constructor comment.
     */
    public DataSub() {
        super();
    }
    /**
     * Insert the method's description here.
     * Creation date: (8/3/2002 5:04:44)
     * @param statement com.ibm.db.Statement
     * @param Id java.lang.String
     * @exception java.sql.SQLException The exception description.
     */
    public void bind(Statement statement, String Id) throws SQLException {
        String col1 = "", col2 = "", col3 = "";
        String msgout="";
        try {
            String query =
                "SELECT S.SUBID,S.ENAME,S.CREDIT "
                    + "FROM  STUDENT S,SUBCOURSE U,COURSE C,SECTION T,SUBJECT J "
                    + "WHERE ((U.SCID = S.SCID AND C.COID = U.COID AND T.COID = C.COID AND "
                    + "J.SUBID = T.SUBID)  AND (( S.STUID = '"
                    + Id
                    + "' ))) "
                    + "GROUP BY S.SUBID,S.ENAME, S.CREDIT";
            ResultSet resultset = statement.executeQuery(query);
            while (resultset.next()) {
                col1 = resultset.getString(1);
                col2 = resultset.getString(2);
                col3 = resultset.getString(3);
                subId = subId + "," + col1;
                subName = subName + "," + col2;
                subCredit = subCredit + "," + col3;
            }
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString();
        } catch (Exception excp) {
            excp.printStackTrace();
            msgout = excp.toString();
        }
    }

/**
 * Insert the method's description here.
 * Creation date: (8/3/2002 5:19:08)
 * @return java.lang.String
 */
public java.lang.String getSubCredit() {
	return subCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (8/3/2002 5:19:08)
 * @return java.lang.String
 */
public java.lang.String getSubId() {
	return subId;
}

/**
 * Insert the method's description here.
 * Creation date: (8/3/2002 5:19:08)
 * @return java.lang.String
 */
public java.lang.String getSubName() {
	return subName;
}

/**
 * Insert the method's description here.
 * Creation date: (8/3/2002 5:19:08)
 * @param newSubCredit java.lang.String
 */
public void setSubCredit(java.lang.String newSubCredit) {
	subCredit = newSubCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (8/3/2002 5:19:08)
 * @param newSubId java.lang.String
 */
public void setSubId(java.lang.String newSubId) {
	subId = newSubId;
}

/**
 * Insert the method's description here.
 * Creation date: (8/3/2002 5:19:08)
 * @param newSubName java.lang.String
 */
public void setSubName(java.lang.String newSubName) {
	subName = newSubName;
}
}