<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ����Ԫҷ���Դ�͹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,java.text.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<p>&nbsp;</p><table width="600" border="1" bordercolor="#FFFFCC" align="center" cellpadding="5" class="NORMALDETAIL">
  <%
		String id = request.getParameter("id");
		String msgout="";

		String col1=null,col2=null,col3=null,col4=null,col5=null,col6=null,col7=null,col8=null;
		try
		{        
		Statement	statement = (Statement)session.getAttribute("Statement");
			String query = "SELECT SUBID,ENAME,TNAME,CREDIT,LECTURE, PRACTICE,OUTLINEE,"+
															"OUTLINET "+
										"FROM SUBJECT "+
										"WHERE (( SUBID = '"+ id+"' ))" ;
                ResultSet resultset = statement.executeQuery(query);
	               while (resultset.next()) {
						col1=resultset.getString(1);
						col2=resultset.getString(2);
						col3=resultset.getString(3);
						col4=resultset.getString(4);
						col5=resultset.getString(5);
						col6=resultset.getString(6);
						col7=resultset.getString(7);
						col8=resultset.getString(8);
				}	
				%>
  <tr> 
    <td width="46%"> 
      <p align="right"><span class="HEAD1DETAIL">����Ԫ�(�ѧ���) :</span> <br>
        <span class="HEAD1DETAIL">����Ԫ�(��) :</span> <br>
        <span class="HEAD1DETAIL">�����Ԫ� :</span><br>
        <span class="HEAD1DETAIL">�ӹǹ˹��¡Ե(��ɮ�-��Ժѵ�) :</span> </p>
    </td>
    <td width="54%"><font color="#FF9900" class="HEAD1DETAIL_C"><%=col2%></font><br>
      <font color="#FF9900" class="HEAD1DETAIL_C"><%=col3%></font> <font color="#FF9900" class="HEAD1DETAIL_C"><br>
      <%=col1%><br>
      <%=col4%> (<%=col5%>-<%=col6%>)</font></td>
  </tr>
  <%
	  java.sql.Time time5= new java.sql.Time(0,0,0);
	  java.sql.Time time6= new java.sql.Time(0,0,0);
	  java.sql.Time time10= new java.sql.Time(0,0,0);
	  java.sql.Time time11= new java.sql.Time(0,0,0);
	  java.util.Date date9 = new java.util.Date();
	String fil1=null,fil2=null,fil3=null,fil4=null,fil5=null,fil6=null,fil7=null,fil8=null;
	String fil9=null,fil10=null,fil11=null,fil12=null,fil13=null,fil14=null,fil15=null;
	query = "SELECT   S.SEC , T.PRENT , T.NAMET ,  T.FAMILYT , S.STDBTIME , S.STDETIME ,"+
										"S.STDROOM , S.STDDAY , S.EXDATE , S.EXBTIME , S.EXETIME , S.EXROOM ,"+
										"S.MAXSTU , S.CURSTU,C.TNAME "+
					"FROM SECTION S,TEACHER T,SUBCOURSE C "+
					"WHERE  ((T.TCHID = S.TCHID) AND  ( S.SUBID = '"+col1+"' ) AND (S.SCID=C.SCID))";
	   resultset = statement.executeQuery(query);
   while (resultset.next()) {
						fil1=resultset.getString(1);
						fil2=resultset.getString(2);
						fil3=resultset.getString(3);
						fil4=resultset.getString(4);
						time5=resultset.getTime(5);
						time6=resultset.getTime(6);
						fil7=resultset.getString(7);
						fil8=resultset.getString(8);
						date9=resultset.getDate(9);
						time10=resultset.getTime(10);
						time11=resultset.getTime(11);
						fil12=resultset.getString(12);
						fil13=resultset.getString(13);
						fil14=resultset.getString(14);
						fil15=resultset.getString(15);
						if(date9!=null)
						fil9 =   new SimpleDateFormat().getDateInstance().format(date9);
			out.println("<tr> "+
								"<td colspan=\"2\" bgcolor=\"#FFFF99\"><b>Section  "+fil1+"   "+fil15+"</b></td>"+
								"</tr>"+
								"<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"
								+"\u0E1C\u0E39\u0E49\u0E2A\u0E2D\u0E19</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil2+" "+fil3+"  "+fil4+"</font> </td>"+
								"</tr>"+
								"<tr>"+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
						"\u0E27\u0E31\u0E19\u0E40\u0E27\u0E25\u0E32\u0E17\u0E35\u0E48\u0E2A\u0E2D\u0E19</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil8+"  " + time5+"-"+time6 +" \u0E19.</font></td>"+
								"</tr>"+
								"<tr>"+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
					"\u0E2B\u0E49\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E2A\u0E2D\u0E19</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil7+"</font></td>"+
								"</tr>"+
								"<tr>"+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
						"\u0E27\u0E31\u0E19\u0E40\u0E27\u0E25\u0E32\u0E17\u0E35\u0E48\u0E2A\u0E2D\u0E1A</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil9+"     " + time10 +" - "+ time11+" \u0E19.</font></td>"+
								"</tr>"+
								"<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
						"\u0E2B\u0E49\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E2A\u0E2D\u0E1A</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil12+"</font></td>"+
								"</tr>"+
								"<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
						"\u0E08\u0E33\u0E19\u0E27\u0E19\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32\u0E17\u0E35\u0E48\u0E23\u0E31\u0E1A</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil13+"</font></td>"+
								"</tr>"+
								"<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
						"\u0E08\u0E33\u0E19\u0E27\u0E19\u0E19\u0E31\u0E01\u0E28\u0E36\u0E01\u0E29\u0E32\u0E17\u0E35\u0E48\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+fil14+"</font></td>"+
								"</tr>"+
								"<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
								"\u0E2A\u0E16\u0E32\u0E19\u0E30</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+"A"+"</font></td>"+
								"</tr>");
				}
	%>
  <tr> 
    <td colspan="2" bgcolor="#FFFF99" class="HEAD1DETAIL"><b>Prerequisite</b></td>
  </tr>
  <%
		String val1= "none";
		String val2 = "none";
		query = "SELECT  P.PREID, S.ENAME "+
						"FROM PREREQUISITE P,SUBJECT S "+
						"WHERE ((S.SUBID = P.PREID) AND  ( P.SUBID = '"+col1+"' ))";
		resultset = statement.executeQuery(query);
		while(resultset.next()){
			val1=resultset.getString(1);
			val2=resultset.getString(2);
			out.println("<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">\u0E27\u0E34\u0E0A\u0E32<br>"+
								"</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+val2+"</font></td>"+
								"</tr>"+
								"<tr>"+ 
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
								"\u0E23\u0E2B\u0E31\u0E2A\u0E27\u0E34\u0E0A\u0E32</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">"+val1+"</font></td>"+
								"</tr>");
			}
			if(val1.equals("none")&val2.equals("none")) 
				out.println("<tr> "+
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">\u0E27\u0E34\u0E0A\u0E32<br>"+
								"</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">\u0E44\u0E21\u0E48\u0E21\u0E35</font></td>"+
								"</tr>"+
								"<tr>"+ 
								"<td bordercolor=\"#CCCCCC\" width=\"46%\">"+
								"\u0E23\u0E2B\u0E31\u0E2A\u0E27\u0E34\u0E0A\u0E32</td>"+
								"<td bordercolor=\"#CCCCCC\" width=\"54%\">"+
								"<font color=\"#FF9900\">\u0E44\u0E21\u0E48\u0E21\u0E35</font></td>"+
								"</tr>");
		}
           catch ( Exception excp )
      {    
            excp.printStackTrace();
            msgout = excp.toString();
      }
	out.println(msgout);
 %>
  <tr> 
    <td colspan="2" bgcolor="#FFFF99" class="HEAD1DETAIL"><b>Course - outline</b></td>
  </tr>
  <tr> 
    <td bordercolor="#CCCCCC" colspan="2"><font color="#FF9900"><%=col8%></font></td>
  </tr><tr> 
    <td bordercolor="#CCCCCC" colspan="2"><font color="#FF9900"><%=col7%></font></td>
  </tr>  
</table>
<br>
  <%@ include file = "footer.inc" %>
</body>
</html>
