<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ����Ԫҷ���Դ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<jsp:useBean id="cTime" class="proj_gds.CurTime"  scope="session"/>
<%
		student = (proj_gds.StudentBean)session.getAttribute("Student");
		cTime = (CurTime)session.getAttribute("CTime");
%>
<div align="center"><br><br>
  <font size="4"><span class="HEAD2DETAIL">�Ҥ����֡�� ��� </span> <span class="HEAD2DETAIL_C"><%=cTime.getSemister()%></span> 
  <span class="HEAD2DETAIL">�ա���֡��</span> <span class="HEAD2DETAIL_C"><%=cTime.getTEduYear()%></span></font><br>
  <br>
</div>
<table width="570" border="0" align="center" cellpadding="5" class="NORMALDETAIL">
  <tr>
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="NORMALDETAIL">
        <tr> 
          <td colspan="3" class="HEAD1DETAIL"> 
            <%
		String id = request.getParameter("id"); 
		String fac ="";
		Statement	statement= (Statement)session.getAttribute("Statement");
		String query;
		ResultSet resultset;

		String msgout="";
		String FROM_ALL="FROM FACULTY F,DEPARTMENT D,MAJOR M,COURSE C,SUBJECT J "+
												"WHERE ((D.FACID = F.FACID AND M.DEPID = D.DEPID AND "+
																	"C.MAID = M.MAID AND   J.COID = C.COID )  AND "+
																	"(( F.FACID = '"+id+"' )))";
		if (id.equals("00"))
					FROM_ALL="FROM STUDENT S, SUBCOURSE U,SUBJECT J "+
												"WHERE  ((U.SCID = S.SCID AND J.COID = U.COID)"+
												"AND (( S.STUID = '"+(String)session.getAttribute("ID")+"' )))";

		try
		{        
			 query = "SELECT  TNAME FROM FACULTY WHERE FACID='"+id+"'";
              resultset = statement.executeQuery(query);
	               while (resultset.next()) {
						fac=resultset.getString(1);
					  }
			if(id.equals("00"))
				out.println(" <div align=\"center\">"+
		"\u0E23\u0E32\u0E22\u0E27\u0E34\u0E0A\u0E32\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E2D\u0E19\u0E43\u0E19<br>"+
			student.getCourse()+"</div>");
			else
				out.println("<div align=\"center\">"+
		"\u0E23\u0E32\u0E22\u0E27\u0E34\u0E0A\u0E32\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E2D\u0E19\u0E43\u0E19\u0E04\u0E13\u0E30"+fac+"</div>");
			%>
            <br>
          </td>
        </tr>
        <tr bgcolor="#FFFF99"> 
          <td width="13%" height="25"> 
            <div align="center">�����Ԫ�</div>
          </td>
          <td width="63%" height="25"> 
            <div align="center">�����Ԫ�</div>
          </td>
          <td width="24%" height="25"> 
            <div align="center">˹��¡Ԩ<br>
              (������-��Ժѵ�)</div>
          </td>
        </tr>
        <%
		    	query = "SELECT  J.SUBID, J.TNAME, J.CREDIT,J.LECTURE,J.PRACTICE "+
								FROM_ALL;
                resultset = statement.executeQuery(query);
	               while (resultset.next()) {
					out.println("<tr>"+ 
												"<td width=\"18%\" height=\"25\">"+ 
												"<div align=\"center\">"+resultset.getString(1)+"</div>"+
												"</td>"+
												"<td width=\"59%\" ><a href=\"ReviewSubjectPage.jsp?id="+ resultset.getString(1)+"\" target=\"_blank\">"+
												resultset.getString(2)+
												"</a></td>"+
												"<td width=\"23%\"><div align=\"center\">"+
												resultset.getInt(3)+"("+resultset.getInt(4)+"-"+resultset.getInt(5)+
												")</div></td></tr>");				
				}	
				%>
      </table>
      <br>
	<ul>
	<% 
			query = "SELECT FACID FROM FACULTY WHERE TNAME	 = '"+
												student.getFaculty()+"'";
			resultset = statement.executeQuery(query);
			while (resultset.next()) {
			out.println("<li><a href=\"ReviewCoursePage.jsp?id="+resultset.getString(1)+"\" target=\"_blank\">"+
		"\u0E23\u0E32\u0E22\u0E27\u0E34\u0E0A\u0E32\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E2D\u0E19\u0E02\u0E2D\u0E07\u0E04\u0E13\u0E30"
						+student.getFaculty()+"</a></li>");
				}
	   }
           catch ( Exception excp )
      {    
            excp.printStackTrace();
            msgout = excp.toString();
      }
	out.println(msgout);
%>
	</ul>
     </td>
  </tr>
</table>
<br>
<%@ include file = "footer.inc" %>
</body>
</html>
