<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ��������ǹ���</title>
<script language="JavaScript">
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<% student = (proj_gds.StudentBean)session.getAttribute("Student");%>
<div align="center">
  <p>&nbsp;</p>
  <p><font size="5"><span class="HEAD2DETAIL">��������ǹ���</span></font><span class="HEAD2DETAIL"><font size="4"></font></span><font size="4"><br>
    <span class="HEAD1DETAIL">(��سҡ�͡��������繨�ԧ)</span></font></p>
<FORM METHOD=POST  ACTION="PersonalDataPage1.jsp">
    <table width="600" border="0" cellspacing="1" cellpadding="5" class="NORMALDETAIL" >
      <tr> 
        <td colspan="2"> 
          <div align="center"> <font color="#FF9900" size="3" class="HEAD1DETAIL_C"> 
            <jsp:getProperty name="student" property="preNT"/>
            <jsp:getProperty name="student" property="nameT"/>
            &nbsp;&nbsp; 
            <jsp:getProperty name="student" property="familyT"/>
            </font> <font size="3"> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> 
            <font color="#FF9900" class="HEAD1DETAIL_C"> 
            <jsp:getProperty name="student" property="stuId" />
            </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
            <jsp:getProperty name="student" property="subCourse" />
            </font> <br>
            <span class="HEAD1DETAIL">�Ң��Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
            <jsp:getProperty name="student" property="major"/>
            </font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
            <jsp:getProperty name="student" property="department"/>
            </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
            <jsp:getProperty name="student" property="faculty"/>
            </font></font></div>
        </td>
      </tr>
      <tr> 
        <td width="33%" valign="top"> 
          <div align="right">���������������</div>
        </td>
        <td width="67%"> 
          <textarea name="address2" rows="5" cols="40"><jsp:getProperty name="student" property="addr2"/></textarea>
        </td>
      </tr>
      <tr> 
        <td width="33%" height="30"> 
          <div align="right">�������Ѿ������������</div>
        </td>
        <td width="67%" height="30"> 
          <input type="text" name="tel2"
		value ="<%=student.getTel2()%>">
        </td>
      </tr>
      <tr> 
        <td width="33%" valign="top"> 
          <div align="right">�������Ѩ�غѹ</div>
        </td>
        <td width="67%" height="30"> 
          <textarea name="address1" rows="5" cols="40"><jsp:getProperty name="student" property="addr1"/></textarea>
        </td>
      </tr>
      <tr> 
        <td width="33%" height="30"> 
          <div align="right">�������Ѿ��Ѩ�غѹ</div>
        </td>
        <td width="67%" height="30"> 
          <input type="text" name="tel1"
		value ="<%=student.getTel1()%>">
        </td>
      </tr>
      <tr> 
        <td width="33%" height="30"> 
          <div align="right">�������</div>
        </td>
        <td width="67%" height="30"> 
          <input type="text" name="email" 
		value="<%=student.getEmail()%>">
        </td>
      </tr>
      <tr> 
        <td width="33%" height="30"> 
          <div align="right">����¹��������</div>
        </td>
        <td width="67%" height="30"> 
          <input type="password" name="password1" value="">
        </td>
      </tr>
      <tr> 
        <td width="33%" height="30"> 
          <div align="right">�׹�ѹ�����������</div>
        </td>
        <td width="67%" height="30"> 
          <input type="password" name="password2" value="">
          (���������� ����͵�ͧ�������¹����)</td>
      </tr>
      <tr> 
        <td colspan="2"> 
          <div align="center"> 
            <input type="submit" name="Submit" value="��ŧ">
            <input type="reset" name="Reset" value="¡��ԡ">
          </div>
        </td>
      </tr>
    </table>
  </FORM>
  <p><br>
  <div align="center"><A HREF="MainPage.jsp"><font color="#FF0000" class="NORMALDETAIL_C">˹����ѡ</font></A></div>
    <%@ include file = "footer.inc" %>
</div>
</body>
</html>
