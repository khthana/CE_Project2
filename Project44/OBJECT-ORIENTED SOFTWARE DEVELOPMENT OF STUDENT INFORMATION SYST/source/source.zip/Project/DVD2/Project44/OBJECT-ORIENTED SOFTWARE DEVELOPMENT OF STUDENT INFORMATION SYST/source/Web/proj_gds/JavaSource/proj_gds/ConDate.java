package proj_gds;

import java.lang.*;
import java.text.*;
import java.util.*;
/**
 * Insert the type's description here.
 * Creation date: (4/3/2002 7:14:53)
 * @author: Administrator
 */
public class ConDate {
    public String Result;
    public String CDate;
    public String CMonth;
    public String CYear;
    
    /**
    * ConDate constructor comment.
    */
    public ConDate() {
        super();
        String CuDate =
            new SimpleDateFormat().getDateInstance(3).format(new java.util.Date());
        StringTokenizer st = new StringTokenizer(CuDate, "/");
        CuDate = st.nextToken();
        CuDate = st.nextToken() + "-" + CuDate;
        CuDate = st.nextToken() + "-" + CuDate;
        Result = CuDate;
    }
/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 7:17:31)
 * @return java.lang.String
 */
public java.lang.String getResult() {
	return Result;
}
/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 7:17:31)
 * @param newResult java.lang.String
 */
public void setResult(java.lang.String newResult) {
	Result = newResult;
}
}
