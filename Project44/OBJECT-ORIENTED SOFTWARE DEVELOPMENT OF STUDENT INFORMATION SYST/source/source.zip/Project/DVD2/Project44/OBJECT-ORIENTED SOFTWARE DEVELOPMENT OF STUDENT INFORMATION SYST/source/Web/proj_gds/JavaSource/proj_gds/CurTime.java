package proj_gds;

import java.sql.*;
import java.util.*;
import java.lang.*;
import java.text.*;


/**
 * Insert the type's description here.
 * Creation date: (4/3/2002 2:48:55)
 * @author: Administrator
 */
public class CurTime {
    private String Semister;
    private String EduYear;
    private String TEduYear;
    /**
     * CurTime constructor comment.
     */
    public CurTime() {
        super();
    }
    public void bind(Statement stm) throws SQLException {
	    ConDate cd = new ConDate();
		String CuDate = new String(cd.getResult());	
	    String query =
            "SELECT * FROM  TimeSch WHERE (BeDate <= '"
                + CuDate 
                + "')  and (ExDate >= '"
                + CuDate
                + "') and TiID<=3";
                    ResultSet resultset = stm.executeQuery(query);
                   resultset.next();
                  Semister = Integer.toString(resultset.getInt("TiID"));
		query = "SELECT * FROM  TimeSch WHERE TiID =1";
        resultset = stm.executeQuery(query);
        resultset.next();
		CuDate = new SimpleDateFormat().getDateInstance(3).format(resultset.getDate("BeDate"));
        StringTokenizer st = new StringTokenizer(CuDate,"/");
		CuDate = st.nextToken();
		CuDate = st.nextToken() +"-"+CuDate;
		EduYear = st.nextToken();	
		TEduYear = Integer.toString(Integer.parseInt(EduYear) + 543);	
		
    }
    /**
     * Insert the method's description here.
     * Creation date: (4/3/2002 2:57:51)
     * @return java.lang.String
     */
    public java.lang.String getEduYear() {
        return EduYear;
    }
    /**
     * Insert the method's description here.
     * Creation date: (4/3/2002 2:57:51)
     * @return java.lang.String
     */
    public java.lang.String getSemister() {
        return Semister;
    }
/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 6:49:43)
 * @return java.lang.String
 */
public java.lang.String getTEduYear() {
	return TEduYear;
}
}
