package proj_gds;

import java.lang.*;
import java.sql.*;
import java.util.*;
/**
 * Insert the type's description here.
 * Creation date: (3/3/2002 13:32:24)
 * @author: Administrator
 */
public class MsgAlert {
    /**
     * MsgAlert constructor comment.
     */

    private String Msg;
    private boolean PreRegis = false;
    private boolean Regis = false;
    private Vector  V1;
    private Vector  V2;    
    private int i=0;

    public MsgAlert() {
        super();

    }
    public void bind(Statement stm, String StuID) throws SQLException {
        ConDate cd = new ConDate();
        String query =
            "SELECT * FROM  TimeSch WHERE (BeDate <= '"
                + cd.getResult()
                + "')  and (ExDate >= '"
                + cd.getResult()
                + "') and TiID=4";
        ResultSet resultset = stm.executeQuery(query);
        if (resultset.next()) {

            CurTime cu = new CurTime();
            cu.bind(stm);
            query =
                "SELECT * FROM  Register WHERE (Year = '"
                    + cu.getTEduYear()
                    + "') and (sem='"
                    + cu.getSemister()
                    + "') and (StuID='"
                    + StuID
                    + "') and (Status='P')";
            if (resultset.next()) {

                Msg =
                    "\u0E04\u0E38\u0E13\u0E44\u0E14\u0E49\u0E17\u0E33\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E41\u0E25\u0E49\u0E27\u0E42\u0E1B\u0E23\u0E14\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E43\u0E19\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48";
            } else {
                PreRegis = true;
                Msg =
                    "\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E0A\u0E48\u0E27\u0E07\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32";
            }
        } else
            Msg =
                "\u0E2A\u0E34\u0E49\u0E19\u0E2A\u0E38\u0E14\u0E0A\u0E48\u0E27\u0E07\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32";

        query =
            "SELECT * FROM  TimeSch WHERE (BeDate <= '"
                + cd.getResult()
                + "')  and (ExDate >= '"
                + cd.getResult()
                + "') and TiID=5";
        resultset = stm.executeQuery(query);
        if (resultset.next()) {
            Regis = true;
            Msg =
                "\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19";
        } else
            Msg =
                "\u0E2A\u0E34\u0E49\u0E19\u0E2A\u0E38\u0E14\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19";

                query =  "SELECT Year,Sem FROM  Register WHERE StuID='"+StuID+"' group by Year,Sem order by Year,Sem" ;
                resultset  = stm.executeQuery(query);
				V1 = new Vector();
				V2 = new Vector();
                while(resultset.next()){
                	V1.addElement(resultset.getString("Sem"));
                	V2.addElement(resultset.getString("Year"));
                }
                i = 0;
         


    }
    /**
     * Insert the method's description here.
     * Creation date: (3/3/2002 13:50:36)
     * @return String
     */
    public String getMsg() {
        return Msg;
    }
    public String getSem(){
	     if (i<V1.size())
	     	return (String) V1.elementAt(i)  ;
	     else
	    	return "EOF";
    }
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 19:03:28)
 * @return java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public String getSem_Year() {
	     if (i<V1.size()){
	     	String str = new String(	(String) V1.elementAt(i) + "/" +  (String) V2.elementAt(i) );
		     return str;		     
	     }
	     else
	    	return "EOF";
}
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 19:02:57)
 * @return java.lang.String
 * @exception java.sql.SQLException The exception description.
 */
public String getYear()  {
	     if (i<V1.size())
	     	return (String) V2.elementAt(i) ;
	     else
	    	return "EOF";
}

public void next(){
	  if (i<V1.size())
	  	i++;
}
/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 13:47:34)
 * @return boolean
 */
public boolean isPreRegis() {
	return PreRegis;
}
/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 13:47:34)
 * @return boolean
 */
public boolean isRegis() {
	return Regis;
}
}
