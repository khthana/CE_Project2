<!-- 
   Simple error page for reporting application errors.
   This error page is called when a servlet throws an Exception, or by calling
   response.sendError().  Error pages can use the request-scoped bean named
   "error" to get more information about the error.
--->
<%@  page isErrorPage="true"  %>
<html>
<head><title>Error </title></head>
<body>

<H1>Error  </H1>
<H4>An error has occured while processing request: </H4>

<B>Message: </B><BR>
<B>StackTrace: </B>

</html>
