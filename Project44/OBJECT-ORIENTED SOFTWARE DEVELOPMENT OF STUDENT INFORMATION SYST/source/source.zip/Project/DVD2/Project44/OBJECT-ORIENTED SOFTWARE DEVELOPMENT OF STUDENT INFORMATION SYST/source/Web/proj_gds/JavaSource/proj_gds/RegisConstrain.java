package proj_gds;

/**
 * Insert the type's description here.
 * Creation date: (3/2/2002 1:08:44)
 * @author: Administrator
 */
public class RegisConstrain {
/**
 * RegisConstrain constructor comment.
 */
 private int minCredit = 9;
 private int maxCredit = 15;
 private int sumCredit = 6;
 private double minGPA = 3.00;
 private String minGrade = "C+";
 private String minGrade2 = "S";
 
public RegisConstrain() {
	super();
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @return int
 */
public int getMaxCredit() {
	return maxCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @return int
 */
public int getMinCredit() {
	return minCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @return double
 */
public double getMinGPA() {
	return minGPA;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @return java.lang.String
 */
public java.lang.String getMinGrade() {
	return minGrade;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @return int
 */
public int getSumCredit() {
	return sumCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @param newMaxCredit int
 */
public void setMaxCredit(int newMaxCredit) {
	maxCredit = newMaxCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @param newMinCredit int
 */
public void setMinCredit(int newMinCredit) {
	minCredit = newMinCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @param newMinGPA double
 */
public void setMinGPA(double newMinGPA) {
	minGPA = newMinGPA;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @param newMinGrade java.lang.String
 */
public void setMinGrade(java.lang.String newMinGrade) {
	minGrade = newMinGrade;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:16:40)
 * @param newSumCredit int
 */
public void setSumCredit(int newSumCredit) {
	sumCredit = newSumCredit;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:20:54)
 * @return java.lang.String
 */
public java.lang.String getMinGrade2() {
	return minGrade2;
}

/**
 * Insert the method's description here.
 * Creation date: (3/2/2002 11:20:54)
 * @param newMinGrade2 java.lang.String
 */
public void setMinGrade2(java.lang.String newMinGrade2) {
	minGrade2 = newMinGrade2;
}
}
