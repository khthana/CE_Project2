<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ��ª��ͼ��ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="cTime" class="proj_gds.CurTime"  scope="session"/>
<%cTime = (CurTime)session.getAttribute("CTime");%>
<body bgcolor="#FFFFCC" text="#0066FF">
<div align="center"><br>
  <span class="HEAD2DETAIL"> 
  <%
		String time="";
		String fac ="";
		String id = request.getParameter("id"); 
		String Status = request.getParameter("time");
		String query;
		String msgout="";
		String col1=null,col2=null,col3=null,col4=null;
		
		MsgAlert msg = (MsgAlert)session.getAttribute("Msg");
			if (msg.isPreRegis()) time = "\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32";
		Statement	statement= (Statement)session.getAttribute("Statement");
		ResultSet resultset;

		String FROM_ALL="FROM REGISTER R,STUDENT S,SUBCOURSE U,COURSE C,"+
																"MAJOR M,DEPARTMENT D,FACULTY F "+
												"WHERE  (( S.STUID = R.STUID AND U.SCID = S.SCID AND "+
																	"C.COID = U.COID AND  M.MAID = C.MAID AND "+
																	"D.DEPID = M.DEPID AND F.FACID = D.FACID) AND "+
																	"R.YEAR = '"+cTime.getTEduYear()+"' AND R.SEM = "+cTime.getSemister()
																	+" AND "+
																	"(( R.STUID = '"+(String)session.getAttribute("ID")+"' ) AND"+
																	"( F.FACID = '"+id+"' ) AND "+
																	"(R.STATUS = '"+Status+"')))";
		if (id.equals("00"))
					FROM_ALL="FROM REGISTER R,STUDENT S,SUBCOURSE C "+
												"WHERE ((S.STUID = R.STUID AND C.SCID = S.SCID) AND "+
																	"R.YEAR = '"+cTime.getTEduYear()+"' AND R.SEM = "+
																	cTime.getSemister()+
																	" AND (( R.STUID = '"+(String)session.getAttribute("ID")+"' ) AND " + 
																	"(R.STATUS = '"+Status+"'))) ";
		try
		{        
			 query = "SELECT  TNAME FROM FACULTY WHERE FACID='"+id+"'";
              resultset = statement.executeQuery(query);
	          while (resultset.next()) {
						fac=resultset.getString(1);
					  }
			fac="\u0E02\u0E2D\u0E07\u0E04\u0E13\u0E30"+fac;
			if(id.equals("00")) fac="";
%>
  </span><font size="5"><span class="HEAD2DETAIL">��ª��ͼ����ŧ����¹</span></font><font size="5"><span class="HEAD2DETAIL"><%=time%></span></font><font size="5"><span class="HEAD2DETAIL">����ó�</span></font><font size="5"><span class="HEAD2DETAIL"><%=fac%></span></font><br>
  <br>
</div>
<table width="500" border="1" cellspacing="1" cellpadding="5" align="center" bordercolor="#FFFFCC" class="NORMALDETAIL">
  <tr bordercolor="#CCCCCC" bgcolor="#FFFF99"> 
    <td width="18%"> 
      <div align="center">���ʹѡ�֡��</div>
    </td>
    <td width="82%"> 
      <div align="center">���� - ���ʡ��</div>
    </td>
  </tr>
  <%
			query = "SELECT DISTINCT S.STUID,S.PRENT, S.NAMET,S.FAMILYT "+
										FROM_ALL;
            resultset = statement.executeQuery(query);
	         while (resultset.next()) {
				 col1=resultset.getString(1);
				 col2=resultset.getString(2);
				 col3=resultset.getString(3);
				 col4=resultset.getString(4);
				out.println("<tr bordercolor=\"#CCCCCC\"> "+
									"<td width=\"18%\">"+col1+"</td>"+
									"<td width=\"82%\"> "+col2+" "+col3+"    "+col4+"</td> </tr>");
			 }
				%>
   <tr bordercolor="#FFFFCC"> 
    <td colspan="2"> 
		<ul>
	<% 
			query = "SELECT FACID,TNAME FROM FACULTY";
			resultset = statement.executeQuery(query);
			while (resultset.next()) {
			out.println("<li><a href=\"RegisteredListPage.jsp?id="+resultset.getString(1)+"\" target = \"_blank\">"+
	"\u0E23\u0E32\u0E22\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E02\u0E2D\u0E07" +
								resultset.getString(2)+"</a></li>");
				}
	   }
           catch ( Exception excp )
      {    
            excp.printStackTrace();
            msgout = excp.toString();
      }
	out.println(msgout);
%>
      </ul>
    </td>
  </tr>
</table>
<br>
<%@ include file = "footer.inc" %>
</body>
</html>
