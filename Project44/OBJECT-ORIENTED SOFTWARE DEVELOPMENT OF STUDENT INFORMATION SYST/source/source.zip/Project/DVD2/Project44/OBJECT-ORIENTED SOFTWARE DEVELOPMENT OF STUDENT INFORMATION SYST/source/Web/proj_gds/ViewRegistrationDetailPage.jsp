<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<% student = (StudentBean)session.getAttribute("Student");%>
<div align="center">
  <p>&nbsp;</p>
  <p align="center"><span class="HEAD2DETAIL">ŧ����¹</span><br>
    <br>
    <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="preNT"/>
    <jsp:getProperty name="student" property="nameT"/>
    &nbsp;&nbsp; 
    <jsp:getProperty name="student" property="familyT"/>
    </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="stuId"/>
    </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="subCourse"/>
    </font> <br>
    <span class="HEAD1DETAIL">�Ң��Ԫ�</span><font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="major"/>
    &nbsp;</font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="department"/>
    </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="faculty"/>
    </font><br>
  </p>
  <table width="600" border="0" align="center" height="203">
    <tr> 
      <td height="247"> 
        <div align="center"><span class="HEAD1DETAIL">����Ԫҷ��������ŧ����¹</span><br>
          <br>
        </div>
        <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="100" class="NORMALDETAIL">
          <tr bgcolor="#FFFF99" align="center"> 
            <td width="12%" align="center" height="30"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="56%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">˹��¡Ԩ</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�͹</font></div>
              </font></td>
            <td width="12%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">������</font></div>
              </font></td>
          </tr>
 <% 
		String Status = request.getParameter("time");
		CurTime time = new CurTime();
		String msgout = "",col1="",col2="",col3="",col4="",col5="";
		String query;
		ResultSet resultset;
		int TotalCredit=0;
		int TotalCost=0;
		  try {
		  time.bind((Statement)session.getAttribute("Statement"));
		  query =	"SELECT  SUBJECT.SUBID, SUBJECT.ENAME , SUBJECT.CREDIT ,"+
									    "SECTION.SEC , REGISTER.TYPE "+
							"FROM REGISTER, SECTION, SUBJECT "+
							"WHERE ((SECTION.SECID = REGISTER.SECID AND "+
												"SUBJECT.SUBID = SECTION.SUBID)  AND "+
												"(( REGISTER.STUID = '"+(String)session.getAttribute("ID")+"' ) AND "+
												"( REGISTER.SEM = "+time.getSemister()+" ) AND "+
												"( REGISTER.YEAR = '"+time.getTEduYear()+"' ) AND "+
												"( REGISTER.STATUS = '"+Status+"')))";
		  resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
		  while(resultset.next()) {
			col1=resultset.getString(1);
			col2=resultset.getString(2);
			col3=resultset.getString(3);
			col4=resultset.getString(4);
			col5=resultset.getString(5);
 			out.println("<tr> "+
            "<td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\">"+
			col1+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\">"+
			col2+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
            " <div align=\"center\">"+col3+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+col4+"</div>"+
            "</td>");
			String Type="Ordit";
			if(col5.equals("C")) Type = "\u0E1B\u0E01\u0E15\u0E34";
            out.println("<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+Type+"</div>"+
            "</td>"+
          "</tr>");
			TotalCredit += Integer.parseInt(col3);
		  }
		  if(col1.equals(""))
			 out.println("<tr> "+
            "<td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\">"+
			col1+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\">"+
			col2+"</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
            " <div align=\"center\">"+col3+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+col4+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
              "<div align=\"center\">"+col5+"</div>"+
            "</td>"+
          "</tr>");
		 %>
          <tr bordercolor="#FFFFCC"> 
            <td align="center" bgcolor="#FFFFCC" valign="top" colspan="2" height="30"> 
              <div align="right">���</div>
            </td>
            <td bgcolor="#FFFFCC" valign="top" colspan="3" height="30"> 
              <div align="center"><%=TotalCredit%> ˹��¡Ե</div>
              <div align="center"></div>
              <div align="center"></div>
            </td>
          </tr>
        </table>
        <div align="right">
          <table width="450" border="0" align="center" height="193">
            <tr> 
              <td height="215"> 
                <div align="center"><span class="HEAD1DETAIL"><br>
                  ��������´��������</span><br>
                  <br>
                </div>
                <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="132" class="NORMALDETAIL">
                  <tr bgcolor="#FFFF99"> 
                    <td align="center" height="30"> 
                      <div align="center"><font size="2" color="#0066FF">��������´</font></div>
                    </td>
                    <td width="9%" height="40" align="center"> 
                      <div align="center"><font size="2" color="#0066FF">���</font></div>
                    </td>
                  </tr>
          <%    
		  int col6=0;
		  CurStudy cur = new CurStudy();
		  cur.bind((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"));
		  query =	"SELECT  COST.NAME , COST.VALUE "+
										"FROM  STUDENT, SUBCOURSE, COURSE, COST "+
										"WHERE ((STUDENT.SCID = SUBCOURSE.SCID AND "+
															"COURSE.COID = SUBCOURSE.COID ) AND "+
															"((COST.DEGREE = COURSE.DEGREE) OR (COST.DEGREE = 'A'))"+ 
															" AND "+
															"(( STUDENT.STUID = '"+(String)session.getAttribute("ID")+"' )"+
															" AND (( COST.SEM = '"+cur.getCurSem()+"' ) OR (COST.SEM = 'A'))))";
		  resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
		  while(resultset.next()) {
				col1=resultset.getString(1);
				 col6=resultset.getInt(2);
			out.println("<tr> "+
            "<td bgcolor=\"#FFFFCC\" height=\"27\"> "+
              "<div align=\"left\">"+col1+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"9%\" height=\"27\"> "+
              "<div align=\"center\">"+Integer.toString(col6)+"</div>"+
            "</td>"+
          "</tr>");
		  TotalCost += col6;
		  }
			float valueCredit=0.00f;
			query =	"SELECT VALUE FROM COST WHERE NAME='\u0E04\u0E48\u0E32\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E15'";
			resultset =  ((Statement)session.getAttribute("Statement")).executeQuery(query);
			if (resultset.next())
				 valueCredit = resultset.getFloat(1);
			out.println("<tr> "+
            "<td bgcolor=\"#FFFFCC\" height=\"27\"> "+
              "<div align=\"left\">\u0E04\u0E48\u0E32\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E15</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"9%\" height=\"27\"> "+
              "<div align=\"center\">"+Float.toString(valueCredit*TotalCredit)+"</div>"+
            "</td>"+
          "</tr>");
			  TotalCost += valueCredit*TotalCredit;
	} catch (SQLException sqlex) {
        sqlex.printStackTrace();
        msgout = "Connection unsuccessful\n" + sqlex.toString();
    } catch (Exception excp) {
        excp.printStackTrace();
        msgout = excp.toString();
    }
          %>
                  <tr> 
                    <td align="center" bgcolor="#FFFFCC" height="27"> 
                      <div align="right">���</div>
                    </td>
                    <td bgcolor="#FFFFCC" width="9%" height="27"> 
                      <div align="center"><%=TotalCost%></div>
                    </td>
                  </tr>
                </table>
                <div align="right"> </div>
              </td>
            </tr>
          </table>
        </div>
      </td>
    </tr>
  </table>
  <p> <%@ include file = "footer.inc" %><br>
  </p>
</div>
</body>
</html>
