<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹��ǧ˹��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</style>
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<%
		student = (proj_gds.StudentBean)session.getAttribute("Student");
		if(student.checkRegis((Statement)session.getAttribute("Statement"),"P")) 
			response.sendRedirect("PreRegistrationPage4.jsp");
		DataSub dat = new DataSub();
		dat.bind((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"));
		String subId = dat.getSubId();
		String subName = dat.getSubName();
		String subCredit = dat.getSubCredit();
	%>
<script language="JavaScript">
<%
//to Develope Registration Page(-Type ID to List Subject Name-)
%>
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>

<body bgcolor="#FFFFCC" text="#0066FF">
<p>&nbsp;</p>
<p align="center"><span class="HEAD2DETAIL">ŧ����¹</span><br>
  <br>
  <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="preNT"/>
  <jsp:getProperty name="student" property="nameT"/>
  &nbsp;&nbsp; 
  <jsp:getProperty name="student" property="familyT"/>
  </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="stuId"/>
  </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="subCourse"/>
  </font> <br>
  <span class="HEAD1DETAIL">�Ң��Ԫ�</span><font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="major"/>
  &nbsp;</font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="department"/>
  </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="faculty"/>
  </font><br>
</p>
<FORM METHOD=POST  ACTION="PreRegistrationPage2.jsp">
  <table width="600" border="0" align="center" class="NORMALDETAIL">
    <tr>
    <td height="243"> 
        <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="155">
          <tr bgcolor="#FFFF99" align="center"> 
            <td width="12%" align="center" height="30"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="56%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">˹��¡Ԩ</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�͹</font></div>
              </font></td>
            <td width="12%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">������</font></div>
              </font></td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId1" maxlength="8" size="8" value = "<%=dat.CourseWork[0][0]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName1" size="60" value = "<%=dat.CourseWork[0][1]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit1" size="5"value = "<%=dat.CourseWork[0][2]%>">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec1">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType1">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId2" size="8" maxlength="8"value = "<%=dat.CourseWork[1][0]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName2" size="60"value = "<%=dat.CourseWork[1][1]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit2" size="5"value = "<%=dat.CourseWork[1][2]%>">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec2">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType2">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId3" size="8" maxlength="8" value = "<%=dat.CourseWork[2][0]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName3" size="60"value = "<%=dat.CourseWork[2][1]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit3" size="5"value = "<%=dat.CourseWork[2][2]%>">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec3">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType3">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId4" size="8" maxlength="8"value = "<%=dat.CourseWork[3][0]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName4" size="60"value = "<%=dat.CourseWork[3][1]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit4" size="5"value = "<%=dat.CourseWork[3][2]%>">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec4">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType4">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId5" size="8" maxlength="8"value = "<%=dat.CourseWork[4][0]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName5" size="60"value = "<%=dat.CourseWork[4][1]%>">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit5" size="5"value = "<%=dat.CourseWork[4][2]%>">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec5">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType5">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId6" size="8" maxlength="8">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName6" size="60">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit6" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="ssubSec6">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType6">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId7" size="8" maxlength="8">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName7" size="60">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit7" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec7">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType7">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="12%" height="30"> 
              <input type="text" name="subId8" size="8" maxlength="8">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="56%" height="30"> 
              <input type="text" name="subName8" size="60">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="10%" height="30"> 
              <input type="text" name="subCredit8" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="10%" height="30" valign="bottom"> 
              <select name="subSec8">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </td>
            <td bgcolor="#FFFFCC" width="12%" height="30" valign="bottom"> 
              <select name="subType8">
                <option value="����">����</option>
                <option value="Ordit">Ordit</option>
              </select>
            </td>
          </tr>
        </table>
      <div align="right"><br>
          <input type="submit" name="Submit" value="����">
          <input type="reset" name="Reset" value="¡��ԡ">
        <br>
        <a href="ReviewCoursePage.jsp?id=00" target="_blank"><font color="#FF9900"><br>
        ����Ԫҷ���Դ�͹</font></a> 
		<a href="RegisConstraint.htm" target="_blank"><font color="#FF9900"><br>
        ���͹䢡��ŧ����¹</font></a>
		</div>
    </td>
  </tr>
</table>
</FORM>
<p align="center"><%@ include file = "footer.inc" %></p>
</body>
</html>
