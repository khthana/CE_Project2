<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ˹����ѡ</title>
<script language="JavaScript">
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<% 
	MsgAlert msg= new MsgAlert();
	msg.bind((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"));

	CurTime cTime=new CurTime();
	cTime.bind((Statement)session.getAttribute("Statement"));
		
	session.setAttribute("Msg",msg);
	session.setAttribute("CTime",cTime);
	student = (proj_gds.StudentBean)session.getAttribute("Student");
	%>
<div align="center">
  <p>&nbsp;</p>
  <p><span class="HEAD1DETAIL">�к����ʹ�ȹѡ�֡�� <br>
    ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</span><br>
  </p>
</div>
<table width="550" border="1" cellspacing="3" cellpadding="5" align="center" bordercolor="#FFFFCC">
  <tr> 
    <td bordercolor="#CCCCCC" bgcolor="#FFFF99" > 
      <div align="center"><font  class="HEAD1DETAIL_C" ><%=msg.getMsg()%></font></div>
    </td>
  </tr>
</table>
<br>
<table width="550" border="1" cellspacing="3" cellpadding="3" align="center" bordercolor="#FFFFCC" class="NORMALDETAIL" >
  <tr> 
    <td bordercolor="#CCCCCC" bgcolor="#FFFF99"> 
      <div align="center"><font size="3" class="HEAD1DETAIL">���� - ��С��</font></div>
    </td>
  </tr>
  <tr> 
    <td bordercolor="#FFFFCC"> 
      <ul>
        <li><a href="#">��鹵͹���ŧ����¹��ǧ˹��</a> - �ѳ�Ե�Է�����</li>
        <li><a href="#">��õ�Ǩ�ͺ�Է�����ŧ����¹�ͧ�ѡ�֡�������</a> - �ѳ�Ե�֡�� 
          ��������</li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td bordercolor="#CCCCCC" bgcolor="#FFFF99"> 
      <div align="center" class="HEAD1DETAIL">��ǹ���ʹ�ȹѡ�֡�� </div>
    </td>
  </tr>
  <tr> 
    <td bordercolor="#FFFFCC"> 
      <ul>
        <li><A HREF="PersonalDataPage.jsp">��������ǹ���</A></li>
        <li>�š���֡�� 
          <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
            <option value="#" selected>���͡�Ҥ����֡��</option>
            <%  
						String sem_year = msg.getSem_Year();
						String sem = msg.getSem();
						String year = msg.getYear();
						while(sem_year!="EOF") {
								out.println("<option value=\"ReviewGradePage.jsp?sem="+sem+"&year="+year+"\">"+ 							sem_year+"</otpion>");
								msg.next();
								sem_year = msg.getSem_Year();
								sem = msg.getSem();
								year = msg.getYear();
						}
				%>
            <option value="ReviewGradePage.jsp?sem=all" >������</option>
          </select>
        </li>
        <li><A HREF="ReviewSchedulePage.jsp">���ҧ���¹ ��� ���ҧ�ͺ</A></li>
        <li><A HREF="ReviewCoursePage.jsp?id=00 " target="_blank">����Ԫҷ���Դ�͹</A></li>
        <% 
if (msg.isPreRegis()) 
	out.println( "<li><A HREF=\"PreRegistrationPage1.jsp\">"+
"\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32</A></li>"+
                   	   "<li><A HREF=\"ViewRegistrationDetailPage.jsp?time=P\"target=\"_blank\">"+
"\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32</A></li>"+
					  "<li><A HREF=\"RegisteredListPage.jsp?id=00&time=P\" target=\"_blank\">"+  
"\u0E23\u0E32\u0E22\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32</A> </li>");
else if (msg.isRegis())
	out.println("<li><A HREF=\"RegistrationPage1.jsp\">"+
"\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19</A></li>"+
                     	   "<li><A HREF=\"ViewRegistrationDetailPage.jsp?time=C\"target=\"_blank\">"+
"\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19</A></li>"+
						  "<li><A HREF=\"RegisteredListPage.jsp?id=00&time=C\" target=\"_blank\">"+
"\u0E23\u0E32\u0E22\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19</A> </li>");
%>
        <li><A HREF="ViewFormPage.jsp">Ẻ���������ͧ</A> 
          <select name="menu2" onChange="MM_jumpMenu('parent',this,0)">
            <option selected  value="#">���͡Ẻ���������ͧ</option>
			<option value="FillForm.jsp">����ͧ�����</option>
          </select>
        </li>
        <li><a href="LoginPage.jsp">��ԡ�����ҹ</a></li>
      </ul>
    </td>
  </tr>
</table>

<table width="550" border="0" cellspacing="0" cellpadding="0" align="center" >
  <tr> 
    <td> 
      <table border="1" cellspacing="3" cellpadding="5" bordercolor="#FFFFCC" align="center" class="NORMALDETAIL">
        <tr> 
          <td bgcolor="#FFFFCC"> 
            <div align="right"> ����颳й����<span class="NORMALDETAIL_C"> 
              <jsp:getProperty name="student" property="preNT"/>
              <jsp:getProperty name="student" property="nameT"/>
              <jsp:getProperty name="student" property="familyT"/>
              </span> ���� <span class="NORMALDETAIL_C"> 
              <jsp:getProperty name="student" property="stuId" />
              </span> <br>
              �Ҥ�Ԫ� <span class="NORMALDETAIL_C"> 
              <jsp:getProperty name="student" property="department" /></span>
              ��� <span class="NORMALDETAIL_C"> 
              <jsp:getProperty name="student" property="faculty" /></span>
            </div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<jsp:include page= "footer.inc" flush="true" />
<br>
</body>
</html>
