<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - �š���֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,java.text.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
 <jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
 <% student = (proj_gds.StudentBean)session.getAttribute("Student");%>
<div align="center"><br>
  <span class="HEAD1DETAIL">�š���֡�Ңͧ</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="preNT"/>
  <jsp:getProperty name="student" property="nameT"/>
  &nbsp;&nbsp; 
  <jsp:getProperty name="student" property="familyT"/>
  </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="stuId"/>
  </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="subCourse"/>
  </font> <br>
  <span class="HEAD1DETAIL">�Ң��Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="major"/>
  &nbsp; </font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="department"/>
  </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="faculty"/>
  </font> <br>
  <br>
  <br>
  <%
		String sem = request.getParameter("sem");
		String year = request.getParameter("year");
		boolean all=true;
		String compare = "<=";
		
		DecimalFormat twoDigits = new DecimalFormat( "0.00" );
		double TotalPoint_inTerm=0.00f,TotalPoint_All=0.00f,GPA=0.00f,GPS=0.00f;
		int TotalCredit_inTerm=0,TotalCredit_All=0;
		String msgout="";

		String col1=null,col2=null,col3=null,col4=null,col5=null,col6=null;
		float col7;

		MsgAlert msg= new MsgAlert();
		msg.bind((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"));

		 Statement statement;
		 ResultSet resultset;
		 String query;
		 
		try
		{   
		while (!msg.getSem().equals("EOF") && all){
					   col1=msg.getSem();
					   col2=msg.getYear();
					   msg.next();
				if (!sem.equals("all")) {
					  col1= sem;
					  col2 = year;
					  all = false;
				}	
				out.println("<table width=\"460\" border=\"1\" cellspacing=\"1\" cellpadding=\"5\" align=\"center\" 						bordercolor=\"#FFFFCC\" class=\"NORMALDETAIL\">"+
									"<tr> "+
									"<td colspan=\"4\">"+
			"\u0E20\u0E32\u0E04\u0E01\u0E32\u0E23\u0E40\u0E23\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48<font color=\"#FF9900\"> "+ col1 +" </font>"+
								"\u0E1B\u0E35\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32"+ 
								"<font color=\"#FF9900\"> "+ col2 +" </font></td></tr>"+
								"<tr>"+ 
									"<td width=\"16%\" bgcolor=\"#FFFF99\" bordercolor=\"#CCCCCC\"> "+
									"<div align=\"center\">"+ "\u0E23\u0E2B\u0E31\u0E2A\u0E27\u0E34\u0E0A\u0E32</div>"+
									"</td>"+
									"<td width=\"53%\" bgcolor=\"#FFFF99\" bordercolor=\"#CCCCCC\"> "+
									"<div align=\"center\">\u0E23\u0E32\u0E22\u0E27\u0E34\u0E0A\u0E32</div>"+
									"</td>"+
									"<td width=\"12%\" bgcolor=\"#FFFF99\" bordercolor=\"#CCCCCC\"> "+
									"<div align=\"center\">\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E08</div>"+
									"</td>"+
									"<td width=\"19%\" bgcolor=\"#FFFF99\" bordercolor=\"#CCCCCC\">"+
									"<div align=\"center\">"+ "\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E28\u0E36\u0E01\u0E29\u0E32</div>"+
									"</td>"+
									"</tr>");
				query = "SELECT  J.SUBID,J.ENAME,J.CREDIT,R.GRADE,G.POINT "+
											"FROM REGISTER R ,SECTION S,SUBJECT J ,GRADE G "+
											"WHERE ((S.SECID = R.SECID AND J.SUBID = S.SUBID) AND "+
													"(G.GRADE = R.GRADE ) AND "+
												   "(( R.STUID = '"+session.getAttribute("ID")+"' ) "+
												   "AND ( R.SEM = "+col1+" ) "+
												   "AND ( R.YEAR = '"+col2+"' )))";
				statement = (Statement)session.getAttribute("Statement");
				 resultset = statement.executeQuery(query);
				while (resultset.next()) {
						col3=resultset.getString(1);
						col4=resultset.getString(2);
						col5=resultset.getString(3);
						col6=resultset.getString(4);
						col7 = resultset.getFloat(5);
				if (col6.equals("X"))  
					col6="&nbsp;"; 
				else 
					TotalPoint_inTerm = (Integer.parseInt(col5)*col7) + TotalPoint_inTerm; 
				TotalCredit_inTerm = Integer.parseInt(col5) + TotalCredit_inTerm;
				out.println("<tr> "+
									"<td width=\"16%\" bordercolor=\"#CCCCCC\"> "+
									"<div align=\"center\"><font color=\"#FF9900\">"+col3+"</font></div>"+
									"</td>"+
									"<td width=\"53%\" bordercolor=\"#CCCCCC\"><font color=\"#FF9900\">"+
									col4+" </font></td>"+
									"<td width=\"12%\" bordercolor=\"#CCCCCC\"> "+
									"<div align=\"center\"><font color=\"#FF9900\">"+col5+"</font></div>"+
									"</td>"+
									"<td width=\"19%\" bordercolor=\"#CCCCCC\"> "+
									"<div align=\"center\"><font color=\"#FF9900\">"+col6+"</font></div>"+
									"</td></tr>"); 
					}
					if (col1.equals("1")) compare = "<";
					else compare="<=";
					query = "SELECT  J.CREDIT,R.GRADE,G.POINT "+
									"FROM REGISTER R ,SECTION S,SUBJECT J ,GRADE G "+
									"WHERE ((S.SECID = R.SECID AND J.SUBID = S.SUBID) AND "+
													"(G.GRADE = R.GRADE) AND "+
												   "(( R.STUID = '"+session.getAttribute("ID")+"' ) "+
												   "AND ( R.YEAR "+compare+ "'"+col2+"'))) "+
									"ORDER BY R.YEAR";
				statement = (Statement)session.getAttribute("Statement");
				 resultset = statement.executeQuery(query);
				 while (resultset.next()) {
						col3=resultset.getString(1);
						col6=resultset.getString(2);
						col7=resultset.getFloat(3);
						if (!col6.equals("X")) {
						TotalCredit_All = Integer.parseInt(col3) + TotalCredit_All;
						TotalPoint_All = (Integer.parseInt(col3)*col7) + TotalPoint_All;
						}
				 }
				 GPS=TotalPoint_inTerm/TotalCredit_inTerm;
				 if (col1.equals("1")) {
					TotalPoint_All = TotalPoint_inTerm+TotalPoint_All;
					TotalCredit_All = TotalCredit_inTerm+TotalCredit_All;
					 }
				GPA=TotalPoint_All/TotalCredit_All;
				out.println("<tr bordercolor=\"#CCCCCC\"> "+
									"<td colspan=\"4\"> "+
									"<div align=\"center\"> "+
									"\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E15\u0E23\u0E27\u0E21 "+
									"= "+Integer.toString(TotalCredit_inTerm)+
									" \u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E15<br>"+
									"GPS = "+twoDigits.format(GPS)+
									"<br>"+
									"GPA = "+twoDigits.format(GPA)+
									"</div>"+
									"</td></tr></table> <br><br>");
					TotalPoint_inTerm=0.00f;
					TotalPoint_All=0.00f;
					TotalCredit_inTerm = 0;
					TotalCredit_All = 0;
				}
	}
           catch ( Exception excp )
      {    
            excp.printStackTrace();
            msgout = excp.toString();
      }
	out.println(msgout);
	%>
</div>
<br>
<div align="center"><A HREF="MainPage.jsp"><font color="#FF0000" class="NORMALDETAIL_C">˹����ѡ</font></A></div>
<%@ include file = "footer.inc" %>
</body>
</html>
