package proj_gds;

/**
 * Insert the type's description here.
 * Creation date: (4/3/2002 20:48:44)
 * @author: Administrator
 */
public class RegisBean {
	private String subId1;
	private int subSec1;
	private String subId2;
	private int subSec2;
	private String subId3;
	private int subSec3;
	private String subId4;
	private int subSec4;
	private String subId5;
	private int subSec5;
	private String subId6;
	private int subSec6;
/**
 * RegisBean constructor comment.
 */
public RegisBean() {
	super();
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return java.lang.String
 */
public java.lang.String getSubId1() {
	return subId1;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return java.lang.String
 */
public java.lang.String getSubId2() {
	return subId2;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return java.lang.String
 */
public java.lang.String getSubId3() {
	return subId3;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return java.lang.String
 */
public java.lang.String getSubId4() {
	return subId4;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return java.lang.String
 */
public java.lang.String getSubId5() {
	return subId5;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return java.lang.String
 */
public java.lang.String getSubId6() {
	return subId6;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return int
 */
public int getSubSec1() {
	return subSec1;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return int
 */
public int getSubSec2() {
	return subSec2;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return int
 */
public int getSubSec3() {
	return subSec3;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return int
 */
public int getSubSec4() {
	return subSec4;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return int
 */
public int getSubSec5() {
	return subSec5;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @return int
 */
public int getSubSec6() {
	return subSec6;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubId1 java.lang.String
 */
public void setSubId1(java.lang.String newSubId1) {
	subId1 = newSubId1;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubId2 java.lang.String
 */
public void setSubId2(java.lang.String newSubId2) {
	subId2 = newSubId2;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubId3 java.lang.String
 */
public void setSubId3(java.lang.String newSubId3) {
	subId3 = newSubId3;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubId4 java.lang.String
 */
public void setSubId4(java.lang.String newSubId4) {
	subId4 = newSubId4;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubId5 java.lang.String
 */
public void setSubId5(java.lang.String newSubId5) {
	subId5 = newSubId5;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubId6 java.lang.String
 */
public void setSubId6(java.lang.String newSubId6) {
	subId6 = newSubId6;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubSec1 int
 */
public void setSubSec1(int newSubSec1) {
	subSec1 = newSubSec1;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubSec2 int
 */
public void setSubSec2(int newSubSec2) {
	subSec2 = newSubSec2;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubSec3 int
 */
public void setSubSec3(int newSubSec3) {
	subSec3 = newSubSec3;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubSec4 int
 */
public void setSubSec4(int newSubSec4) {
	subSec4 = newSubSec4;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubSec5 int
 */
public void setSubSec5(int newSubSec5) {
	subSec5 = newSubSec5;
}

/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 20:54:11)
 * @param newSubSec6 int
 */
public void setSubSec6(int newSubSec6) {
	subSec6 = newSubSec6;
}
}
