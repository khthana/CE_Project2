<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<%
		student = (proj_gds.StudentBean)session.getAttribute("Student");
		if(student.checkRegis((Statement)session.getAttribute("Statement"),"C")) 
			response.sendRedirect("RegistrationPage4.jsp");
		DataSub dat = new DataSub();
		dat.bind((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"));
		String subId = dat.getSubId();
		String subName = dat.getSubName();
		String subCredit = dat.getSubCredit();
	%>
<script language="JavaScript">
<%
	out.println("");//////////////////////////////////////////////////////////////////////////
%>
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>

<body bgcolor="#FFFFCC" text="#0066FF">
<p>&nbsp;</p>
<p align="center"><span class="HEAD2DETAIL">ŧ����¹</span><br>
  <br>
  <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="preNT"/>
  <jsp:getProperty name="student" property="nameT"/>
  &nbsp;&nbsp; 
  <jsp:getProperty name="student" property="familyT"/>
  </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="stuId"/>
  </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="subCourse"/>
  </font> <br>
  <span class="HEAD1DETAIL">�Ң��Ԫ�</span><font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="major"/>
  &nbsp;</font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="department"/>
  </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
  <jsp:getProperty name="student" property="faculty"/>
  </font><br>
</p>
<FORM METHOD=POST  ACTION="RegistrationPage2.jsp">
  <table width="600" border="0" align="center" class="NORMALDETAIL" height="161">
    <tr>
      <td valign="top"> 
        <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="46" class="NORMALDETAIL">
          <tr bgcolor="#FFFF99" align="center"> 
            <td width="12%" align="center" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="54%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="12%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">˹��¡Ԩ</font></div>
              </font></td>
            <td width="10%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�͹</font></div>
              </font></td>
            <td width="12%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">������</font></div>
              </font></td>
          </tr>
		  <%
		   CurTime cur = new CurTime();
			String msgout = "";
			String query;
			ResultSet resultset;
			try {
		    cur.bind((Statement)session.getAttribute("Statement"));
			query ="SELECT SUBJECT.SUBID , SUBJECT.ENAME , SUBJECT.CREDIT ,"+
											"SECTION.SEC , REGISTER.TYPE  "+
							"FROM  STUDENT,  REGISTER, SECTION, SUBJECT "+
							"WHERE ((STUDENT.STUID = REGISTER.STUID AND "+
												" SECTION.SECID = REGISTER.SECID AND "+
												"SUBJECT.SUBID = SECTION.SUBID ) AND "+
												"(( STUDENT.STUID = '"+(String)session.getAttribute("ID")+"' ) AND "+
												"( REGISTER.STATUS = 'P' )AND (REGISTER.SEM = "+cur.getSemister()+")"+
												"AND ( REGISTER.YEAR = '"+cur.getTEduYear()+"' )"+
												"AND (SECTION.STATUS = 'A')))";
			resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
			while (resultset.next()) {
			out.println("<tr> "+
           " <td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\"> "+
              resultset.getString(1)+
			 " </td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\"> "+
				resultset.getString(2)+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
              "<div align=\"center\">"+resultset.getString(3)+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
          "<div align=\"center\">"+resultset.getString(4)+"</div>"+
			"</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
			"<div align=\"center\">"+resultset.getString(5)+"</div>"+
			"</td>"+
          "</tr>");
			}

			query ="SELECT SUBJECT.SUBID , SUBJECT.ENAME , SUBJECT.CREDIT "+
							"FROM  STUDENT,  REGISTER, SECTION, SUBJECT "+
							"WHERE ((STUDENT.STUID = REGISTER.STUID AND "+
												" SECTION.SECID = REGISTER.SECID AND "+
												"SUBJECT.SUBID = SECTION.SUBID ) AND "+
												"(( STUDENT.STUID = '"+(String)session.getAttribute("ID")+"' ) AND "+
												"( REGISTER.STATUS = 'P' )AND (REGISTER.SEM = "+cur.getSemister()+")"+
												"AND ( REGISTER.YEAR = '"+cur.getTEduYear()+"' )"+
												"AND (SECTION.STATUS = 'C')))";
			resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
			int i = 1;
			while (resultset.next()) {
				out.println("<tr> "+
        " <td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\"> "+
        "<input type=\"text\" name=\"subId"+Integer.toString(i)+"\" size=\"8\" maxlength=\"8\"value = \""+
			resultset.getString(1)+"\">"+
		 " </td>"+
        "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\"> "+
		"<input type=\"text\" name=\"subName"+Integer.toString(i)+"\" size=\"60\"value = \""+
			resultset.getString(2)+"\">"+
         "</td>"+
         "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
        "<input type=\"text\" name=\"subCredit"+Integer.toString(i)+"\" size=\"5\" value = \""+
			resultset.getString(3)+"\">"+
         "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
			"<select name=\"subSec"+Integer.toString(i)+"\">"+
                "<option value=\"1\">1</option>"+
                "<option value=\"2\">2</option>"+
                "<option value=\"3\">3</option>"+
                "<option value=\"4\">4</option>"+
              "</select>"+
			"</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
			"<select name=\"subType"+Integer.toString(i)+"\">"+
                "<option value=\"\u0E1B\u0E01\u0E15\u0E34\">\u0E1B\u0E01\u0E15\u0E34</option>"+
                "<option value=\"Ordit\">Ordit</option>"+
			"</td>"+
          "</tr>");
			i++;
			}
			int k = 4-i;
			session.setAttribute("Cancel","have") ;
			if (i==1) {session.setAttribute("Cancel","none") ;}
			else {
			for(int c=0;c<k;c++){
				out.println("<tr> "+
        " <td align=\"center\" bgcolor=\"#FFFFCC\" valign=\"top\" width=\"12%\" height=\"30\"> "+
        "<input type=\"text\" name=\"subId"+Integer.toString(i)+"\" size=\"8\" maxlength=\"8\"value = \"\">"+
		 " </td>"+
        "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"56%\" height=\"30\"> "+
		"<input type=\"text\" name=\"subName"+Integer.toString(i)+"\" size=\"60\"value = \"\">"+
         "</td>"+
         "<td bgcolor=\"#FFFFCC\" valign=\"top\" width=\"10%\" height=\"30\"> "+
        "<input type=\"text\" name=\"subCredit"+Integer.toString(i)+"\" size=\"5\" value = \"\">"+
         "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"10%\" height=\"30\" valign=\"bottom\"> "+
			"<select name=\"subSec"+Integer.toString(i)+"\">"+
                "<option value=\"1\">1</option>"+
                "<option value=\"2\">2</option>"+
                "<option value=\"3\">3</option>"+
                "<option value=\"4\">4</option>"+
              "</select>"+
			"</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"12%\" height=\"30\" valign=\"bottom\"> "+
			"<select name=\"subType"+Integer.toString(i)+"\">"+
                "<option value=\"\u0E1B\u0E01\u0E15\u0E34\">\u0E1B\u0E01\u0E15\u0E34</option>"+
                "<option value=\"Ordit\">Ordit</option>"+
			"</td>"+
          "</tr>");
				i++;
			}
			}
          } catch (SQLException sqlex) {
			sqlex.printStackTrace();
			msgout = "Connection unsuccessful\n" + sqlex.toString();
			} catch (Exception excp) {
			excp.printStackTrace();
			msgout = excp.toString();
		}  
		    %>
         </table>
      <div align="right"><br>
          <input type="submit" name="Submit" value="����">
          <input type="reset" name="Reset" value="¡��ԡ">
        <br>
        <a href="ReviewCoursePage.jsp?id=00" target="_blank"><font color="#FF9900"><br>
        ����Ԫҷ���Դ�͹</font></a> 
		<a href="RegisConstraint.htm" target="_blank"><font color="#FF9900"><br>
        ���͹䢡��ŧ����¹</font></a>
		</div>
    </td>
  </tr>
</table>
</FORM>
<p align="center"><%@ include file = "footer.inc" %></p>
</body>
</html>
