<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<%student = (proj_gds.StudentBean)session.getAttribute("Student");%>
<div align="center">
  <p>&nbsp;</p>
 <p align="center">ŧ����¹<br>
  <br>
 <font color="#FF9900">
			<jsp:getProperty name="student" property="preNT"/>
			<jsp:getProperty name="student" property="nameT"/>&nbsp;&nbsp;  
			<jsp:getProperty name="student" property="familyT"/></font>
			���ʹѡ�֡�� <font color="#FF9900">
			<jsp:getProperty name="student" property="stuId"/></font> 
			��ѡ�ٵ� <font color="#FF9900">
			<jsp:getProperty name="student" property="subCourse"/></font>
			�Ң��Ԫ�<font color="#FF9900"> 
			<jsp:getProperty name="student" property="major"/><br>&nbsp;</font>
			�Ҥ�Ԫ� <font color="#FF9900">
			<jsp:getProperty name="student" property="department"/> </font>
			��� <font color="#FF9900">
			<jsp:getProperty name="student" property="faculty"/> 
  </font>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>
</p>
  <table width="56%" border="0" align="center" height="203">
    <tr> 
      <td height="247"> 
        <div align="center"><font color="#FF0000">* * �պҧ����ԪҼԴ��Ҵ</font><font color="#FF0000">* 
          </font><font color="#FF0000">* </font>,<font color="#FF0000">* * ���������Ԫҷ���ͧ���* 
          * </font>,<font color="#FF0000">* *ŧ����¹��ӡ��������ҡ�Թ�* * 
          </font><br>
        </div>
        <table width="94%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="155">
          <tr bgcolor="#FFFF99" align="center"> 
            <td width="25%" align="center" height="30"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="55%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">�����Ԫ�</font></div>
              </font></td>
            <td width="11%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">˹��¡Ԩ</font></div>
              </font></td>
            <td width="9%" height="40"><font color='white'> 
              <div align="center"><font size="2" color="#0066FF">Sec</font></div>
              </font></td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="25%" height="30"> 
              <input type="text" name="subId1" size="20">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="55%" height="30"> 
              <input type="text" name="subName1" size="50">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="11%" height="30"> 
              <input type="text" name="subCredit1" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="30" valign="bottom"> 
              <select name="subSec1" onChange="MM_jumpMenu('parent',this,0)">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="25%" height="30"> 
              <input type="text" name="subId2" size="20">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="55%" height="30"> 
              <input type="text" name="subName2" size="50">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="11%" height="30"> 
              <input type="text" name="subCredit2" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="30" valign="bottom"> 
              <select name="subSec2" onChange="MM_jumpMenu('parent',this,0)">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="25%" height="30"> 
              <input type="text" name="subId3" size="20">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="55%" height="30"> 
              <input type="text" name="subName3" size="50">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="11%" height="30"> 
              <input type="text" name="subCredit3" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="30" valign="bottom"> 
              <select name="subSec3" onChange="MM_jumpMenu('parent',this,0)">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="25%" height="30"> 
              <input type="text" name="subId4" size="20">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="55%" height="30"> 
              <input type="text" name="subName4" size="50">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="11%" height="30"> 
              <input type="text" name="subCredit4" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="30" valign="bottom"> 
              <select name="subSec4" onChange="MM_jumpMenu('parent',this,0)">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="25%" height="30"> 
              <input type="text" name="subId5" size="20">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="55%" height="30"> 
              <input type="text" name="subName5" size="50">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="11%" height="30"> 
              <input type="text" name="subCredit5" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="30" valign="bottom"> 
              <select name="subSec5" onChange="MM_jumpMenu('parent',this,0)">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td align="center" bgcolor="#FFFFCC" valign="top" width="25%" height="30"> 
              <input type="text" name="subId6" size="20">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="55%" height="30"> 
              <input type="text" name="subName6" size="50">
            </td>
            <td bgcolor="#FFFFCC" valign="top" width="11%" height="30"> 
              <input type="text" name="subCredit6" size="5">
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="30" valign="bottom"> 
              <select name="subSec6" onChange="MM_jumpMenu('parent',this,0)">
                <option selected>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </td>
          </tr>
        </table>
        <div align="right"> 
          <input type="submit" name="Submit" value="����">
          <input type="submit" name="Submit2" value="��Ѻ�">
          <br>
          <a href="ReviewCourse.jsp"><font color="#FF9900">����Ԫҷ���Դ�͹ </font></a><br>
          <a href="constrain"><font color="#FF9900">���͹䢡��ŧ����¹</font></a> 
        </div>
      </td>
    </tr>
  </table></div>
 <%@ include file = "footer.inc" %>
</body>
</html>
