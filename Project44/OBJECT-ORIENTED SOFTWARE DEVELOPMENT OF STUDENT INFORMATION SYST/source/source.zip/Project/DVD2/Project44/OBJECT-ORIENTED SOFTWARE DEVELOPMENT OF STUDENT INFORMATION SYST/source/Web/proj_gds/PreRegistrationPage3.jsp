<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� - ŧ����¹��ǧ˹��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="StyeSheet/style.css" type="text/css">
</head>
<body bgcolor="#FFFFCC" text="#0066FF">
<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,proj_gds.*"  %>
<%@  include file ="checksession.inc" %>
<jsp:useBean id="student" class="proj_gds.StudentBean"  scope="session"/>
<%student = (proj_gds.StudentBean)session.getAttribute("Student");
		RegisBean regisBean = (RegisBean)session.getAttribute("RegisBean");%>
<div align="center">
  <p>&nbsp;</p>
  <p align="center"><span class="HEAD2DETAIL">ŧ����¹</span><br>
    <br>
    <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="preNT"/>
    <jsp:getProperty name="student" property="nameT"/>
    &nbsp;&nbsp; 
    <jsp:getProperty name="student" property="familyT"/>
    </font> <span class="HEAD1DETAIL">���ʹѡ�֡��</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="stuId"/>
    </font> <span class="HEAD1DETAIL">��ѡ�ٵ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="subCourse"/>
    </font> <br>
    <span class="HEAD1DETAIL">�Ң��Ԫ�</span><font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="major"/>
    &nbsp;</font> <span class="HEAD1DETAIL">�Ҥ�Ԫ�</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="department"/>
    </font> <span class="HEAD1DETAIL">���</span> <font color="#FF9900" class="HEAD1DETAIL_C"> 
    <jsp:getProperty name="student" property="faculty"/>
    </font><br>
  </p>
  <table width="56%" border="0" align="center" height="203">
    <tr> 
      <td height="247"> 
        <div align="center"><span class="HEAD1DETAIL">��������´��������</span><br>
          <br>
        </div>
        <table width="100%" border="2" cellspacing="3" cellpadding="5" bordercolor="#CCCCCC" align="center" height="132" class="NORMALDETAIL">
          <tr bgcolor="#FFFF99"> 
            <td align="center" height="30"> 
              <div align="center"><font size="2" color="#0066FF">��������´</font></div>
            </td>
            <td width="9%" height="40" align="center"> 
              <div align="center"><font size="2" color="#0066FF">���</font></div>
            </td>
          </tr>
          <%    
		  String msgout = "",col1="";
		  int TotalCost=0,col2=0;
		  CurStudy cur = new CurStudy();
		  cur.bind((Statement)session.getAttribute("Statement"),(String)session.getAttribute("ID"));
		  try {
		  String query =	"SELECT  COST.NAME , COST.VALUE "+
										"FROM  STUDENT, SUBCOURSE, COURSE, COST "+
										"WHERE ((STUDENT.SCID = SUBCOURSE.SCID AND "+
															"COURSE.COID = SUBCOURSE.COID ) AND "+
															"((COST.DEGREE = COURSE.DEGREE) OR (COST.DEGREE = 'A'))"+ 
															" AND "+
															"(( STUDENT.STUID = '"+(String)session.getAttribute("ID")+"' )"+
															" AND (( COST.SEM = '"+cur.getCurSem()+"' ) OR (COST.SEM = 'A'))))";
		  ResultSet resultset = ((Statement)session.getAttribute("Statement")).executeQuery(query);
		  while(resultset.next()) {
				col1=resultset.getString(1);
				 col2=resultset.getInt(2);
			out.println("<tr> "+
            "<td bgcolor=\"#FFFFCC\" height=\"27\"> "+
              "<div align=\"left\">"+col1+"</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"9%\" height=\"27\"> "+
              "<div align=\"center\">"+Integer.toString(col2)+"</div>"+
            "</td>"+
          "</tr>");
		  TotalCost += col2;
		  }
		  float valueCredit=0.00f;
			query =	"SELECT VALUE FROM COST WHERE NAME='\u0E04\u0E48\u0E32\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E15'";
			resultset =  ((Statement)session.getAttribute("Statement")).executeQuery(query);
			if (resultset.next())
				 valueCredit = resultset.getFloat(1);
			out.println("<tr> "+
            "<td bgcolor=\"#FFFFCC\" height=\"27\"> "+
              "<div align=\"left\">\u0E04\u0E48\u0E32\u0E2B\u0E19\u0E48\u0E27\u0E22\u0E01\u0E34\u0E15</div>"+
            "</td>"+
            "<td bgcolor=\"#FFFFCC\" width=\"9%\" height=\"27\"> "+
              "<div align=\"center\">"+Float.toString(valueCredit*regisBean.TotalCredit)+"</div>"+
            "</td>"+
          "</tr>");
			  TotalCost += valueCredit*regisBean.TotalCredit;
	} catch (SQLException sqlex) {
        sqlex.printStackTrace();
        msgout = "Connection unsuccessful\n" + sqlex.toString();
    } catch (Exception excp) {
        excp.printStackTrace();
        msgout = excp.toString();
    }
          %>
		  <tr> 
            <td align="center" bgcolor="#FFFFCC" height="27"> 
              <div align="right">���</div>
            </td>
            <td bgcolor="#FFFFCC" width="9%" height="27"> 
              <div align="center"><%=TotalCost%></div>
            </td>
          </tr>
        </table>
        <div align="right"> 
          <form name="form1" method="post" action="PreRegistrationPage4.jsp">
            <p>
<input type="submit" name="Submit" value="��ŧ">
              <br>
              <span class="HEAD1DETAIL">&gt;&gt;<a href="RegistrationPage1.jsp">��Ѻ����</a></span> 
            </p>
            </form>
        </div>
      </td>
    </tr>
  </table>
  <p> <%@ include file = "footer.inc" %><br>
  </p>
</div>
</body>
</html>
