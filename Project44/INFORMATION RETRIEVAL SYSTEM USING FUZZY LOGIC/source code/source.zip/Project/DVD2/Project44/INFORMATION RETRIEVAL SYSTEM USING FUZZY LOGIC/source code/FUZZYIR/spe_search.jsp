<html>
<head>
<title> SPECIFIC SEARCH </title>
<Style>
a:link { Color:blue; TEXT-DECORATION: none }
a:visited { Color:blue; TEXT-DECORATION: none } 
a:hover { Color:red; TEXT-DECORATION: none }
a:active { TEXT-DECORATION: none }

</Style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF" background="pic/background.jpg">
<%@ page contentType = "text/html;charset=MS874" %> 
<%@ page language="java" errorPage="error.jsp"  import="java.sql.*,java.util.*"%> 
<%
	String author = new String();
	String pname = new String();
	String description = new String();
	//Vector vector_author = new Vector();
	author = request.getParameter("author");
	pname = request.getParameter("pname");
	description = request.getParameter("description");
%> 
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="16%"><img src="pic/logo_min.jpg" width="163" height="101"></td>
    <td width="84%"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td>&nbsp;</td>
        </tr>
        <tr bordercolor="#FFFFFF" bgcolor="#3333FF"> 
          <td nowrap> 
            <div align="center"><font color="#FFFF33"><b>Spicific Search</b></font></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <form name="form1">
        <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
          <option value="search.jsp" selected>Fuzzy normal search</option>
          <option value="adv_search.jsp">Advance search</option>
        </select>
      </form>
    </td>
  </tr>
  <tr>
    <td>
<%
	Connection dbconn;
	String msgout = "";
      // Set up database connection
	try {// ��ǹ�Դ��͡Ѻ��ҹ������ �¡���� JDBC-ODBC
		String url = "jdbc:odbc:FUZZYIR";
		Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
		dbconn = DriverManager.getConnection(url,"Administrator","fuzzyir");
		Statement statement = dbconn.createStatement();
		if(((pname!=null)&&(pname.length()>0))||((description!=null)&&(description.length()>0))||((author!=null)&&(author.length()>0))){
			String query = "Select * from PAPER ";
			if(((pname!=null)&&(pname.length()>0))||((description!=null)&&(description.length()>0))){
				query = query+"where ";
				if((pname!=null)&&(pname.length()>0)){
					query = query+"PName Like '%"+pname+"%' and ";
				}
				if((description!=null)&&(description.length()>0)){
					query = query+"Description Like '%"+description+"%' and ";
				}
				query=query.substring(0,query.length()-5);
			}
			ResultSet  resultset_show = statement.executeQuery(query);


			while(resultset_show.next()){ 
				String tmp_pnumber=resultset_show.getString("PNumber");
				String tmp_pname=resultset_show.getString("PName");
				String tmp_description=resultset_show.getString("Description");
				String tmp_location=resultset_show.getString("Location");
				String tmp_size=resultset_show.getString("FileSize");
				if((author!=null)&&(author.length()>0)){
					Statement statement2= dbconn.createStatement();
					String sql_author="select AuthorName from AUTHOR where AuthorName Like '%"+author+"%' and PNumber='"+tmp_pnumber+"'";
					ResultSet  resultset_author = statement2.executeQuery(sql_author);
					if(resultset_author.next()){%>
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
          <td><b>Title :</b> <%=tmp_pname%></td>
        </tr>
						<tr>
          <td><b>Abstract :</b> <font size="-1"><%=tmp_description%></font></td>
        </tr>
						<tr>
          <td><b>Author :</b> <font size="-1"><%=resultset_author.getString("AuthorName")%> ,</font></td>
        </tr>
						<%while(resultset_author.next()){%>
							<tr><td><font size="-1"><%=resultset_author.getString("AuthorName")%> ,</font></td></tr>
						<%}%>
						<tr>
          <td><a href=../upload/<%=tmp_location%>><font size="-1">Download&nbsp;</font></a><font size="-1"> 
            size : <%=tmp_size%></font></td>
        </tr>
						</table>
						<br>
					<%}
			
				}
	
				if((author==null)||(author.length()==0)){
					Statement statement2= dbconn.createStatement();
					String sql_author="select AuthorName from AUTHOR where PNumber='"+tmp_pnumber+"'";
					ResultSet  resultset_author = statement2.executeQuery(sql_author);
					if(resultset_author.next()){%>
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
          <td><b>Title :</b> <%=tmp_pname%></td>
        </tr>
						<tr>
          <td><b>Abstract :</b> <font size="-1"><%=tmp_description%></font></td>
        </tr>
						<tr>
          <td><b>Author :</b> <font size="-1"><%=resultset_author.getString("AuthorName")%> ,</font></td>
        </tr>
						<%while(resultset_author.next()){%>
							<tr><td><font size="-1"><%=resultset_author.getString("AuthorName")%> ,</font></td></tr>
						<%}%>
						<tr>
          <td><a href=../upload/<%=tmp_location%>><font size="-1">Download</font></a><font size="-2"> 
            &nbsp;size : <%=tmp_size%></font></td>
        </tr>
						</table>
						<br>
					<%}
				}
			}	
		}%>
  	</td></tr></table>
	<%dbconn.close();
	}
	catch ( ClassNotFoundException cnfex ) 
	{
            // �ѡ�Ѻ�ó��������ö���¡��ҹ��������Ѻ�Դ��Ͱҹ��������
            cnfex.printStackTrace();
            msgout =  "Connection unsuccessful\n" + cnfex.toString() ;		
	}
	catch ( SQLException sqlex ) 
	{// �ѡ�Ѻ�ó����� SQL �Դ��Ҵ
            sqlex.printStackTrace();
            msgout = "Connection unsuccessful\n" + sqlex.toString() ;
		   out.println(sqlex);
      }
      catch ( Exception excp ) 
      {    // �ѡ�Ѻ�ó�����
            excp.printStackTrace();
            msgout = excp.toString() ;
      }
%>
</body>
</html>
