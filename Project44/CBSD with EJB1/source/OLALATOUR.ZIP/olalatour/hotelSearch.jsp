<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.sql.Date" %>
<%@ page import = "java.util.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "java.text.DateFormat" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private final String TARGET_PAGE = "index.jsp";

    private olala.tour.BookingServiceHome bookingServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/TourBookingService");

            //cast to Home interface
            bookingServiceHome = (olala.tour.BookingServiceHome) PortableRemoteObject.narrow(ref, olala.tour.BookingServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
	String countryParam = request.getParameter("country");
	String stateParam = request.getParameter("state");
	String cityParam = request.getParameter("city");
	String hotelNameParam = request.getParameter("hotelName");
	String roomModelNameParam = request.getParameter("roomModelName");
	int amountOfRoom = Integer.parseInt(request.getParameter("amountOfRoom"));
	String checkInDate = request.getParameter("checkInDate")+ " 00:00:00";
	String checkOutDate = request.getParameter("checkOutDate")+ " 00:00:00";
	int minPrice = Integer.parseInt(request.getParameter("minPrice"));
	int maxPrice = Integer.parseInt(request.getParameter("maxPrice"));
	int minStar = Integer.parseInt(request.getParameter("minStar"));
	int maxStar = Integer.parseInt(request.getParameter("maxStar"));

	olala.tour.BookingService bookingService = bookingServiceHome.create();
	Collection hsrCollection = bookingService.SearchHotel(
														countryParam,
														stateParam,
														cityParam,
														hotelNameParam,
														minStar,
														maxStar,
														roomModelNameParam,
														amountOfRoom,
														minPrice,
														maxPrice,
														checkInDate,
														checkOutDate);
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<%
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail");
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" -->
<title>OLaLa Tour-Hotel Search Result</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr>
    <td height="112" colspan="2">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr>
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr>
          <td width="500"><img src="images/spaceit.gif" width="3" height="30">
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top">
    <td>
      <table width="100%" border=0>
        <tr>
          <td width="128">&nbsp;</td>
        </tr>
        <tr>
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align="center"><b><font face="Courier New, Courier, mono">L
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %>
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt;
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email
                            Address &gt;&gt;</b></font>
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password
                            &gt;&gt;</b></font>
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M
                        e m b e r</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/AcctInfo.gif"
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/Profile.gif"
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit
                        profile </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr>
                      <td valign="top">
                        <table>
                          <tbody>
                          <tr>
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033">
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td width="128" valign="top">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top" >
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your
                        booked entry</b></a></font></td>
                    </tr>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View
                        history </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td valign="top">
            <table cellspacing=0 cellpadding=1 width=174 align=right
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top">
                  <table cellspacing=0 cellpadding=4 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="ffffff">
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img
                  height=28
                  src="images/icon_delivers.gif"
                  width=30 align=left border=0>Subscribe with us to catch up all
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20
                  name=email>
                          <input type=image height=23 width=71
                  src="images/subscribe.gif"
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font
                  face=verdana,arial,helvetica size=-1><br
                  clear=all>
                          </font>
                        </form>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" border="0">
        <tr>
          <td colspan="3"><iframe style="display:none;position:absolute;width:136;height:300;z-index=100;border-style:solid;border-width:1" id="CalFrame" marginheight=0 marginwidth=0 NORESIZE frameborder=0 scrolling=NO src="detailPrice.htm">
            </iframe>
            <script language=javascript src=detail.js></script>
            <script for=document event="onclick()">document.all.CalFrame.style.display="none";</script>
          </td>
        </tr>
        <tr>
          <td width="5%">&nbsp;</td>
          <td>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Search
                    Result</font></b></font></div>
                </td>
              </tr>
            </table>
            <table width="100%" border="0">
              <tr>
                <td width="20%"><img src="images/large_hotels.gif" width="78" height="47"></td>
                <td width="40%"><font face="Courier New, Courier, mono"><b>H o
                  t e l</b></font></td>
                <td width="40%" valign="bottom" align="right"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><a href="cart.jsp">Check
                  Out </a></b></font>&nbsp;</td>
              </tr>
            </table>
<%
        if (hsrCollection.isEmpty()) {
			%>
            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                <td colspan="3" bgcolor="#FFD7D7"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr>
                <td width=10>&nbsp;</td>
                <td>Search not found </td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
			<%
        }
        else {
            Iterator iterator = hsrCollection.iterator();
            while (iterator.hasNext()) {
	            Object obj = iterator.next();
		        olala.hotel.HotelSearchResult hsr = (olala.hotel.HotelSearchResult) obj;
        	    olala.hotel.RoomModelPrice[] roomModelPrice = hsr.getColRoomModelPrice();
            	olala.hotel.HotelVO hotelVO = hsr.getObjHotel();
	            String hotelName = hotelVO.getHotelName();
				int hotelID = hotelVO.getHotelID();
				System.out.println("hotelID = "+hotelID);
    	        String city = hotelVO.getCity();
        	    String country = hotelVO.getCountry();
            	String imagePath = hotelVO.getImageMapPath();
    	        int star = hotelVO.getStar();
%>
            <table width="100%" border="0" bgcolor="#F7F3F5" cellpadding="0" cellspacing="0">
              <tr>
                <td bgcolor="#FFD7D7" colspan="2"><img src="images/spaceit.gif" width="30" height=10><b><font face="MS Sans Serif, Microsoft Sans Serif"><%= hotelName %></font></b></td>
                <td bgcolor="#FFD7D7" width="100"><img src="images/spaceit.gif" width="10" height="1"></td>
                <td bgcolor="#FFD7D7" width="100" align="right">
				<%
					for (int i=0; i<star; i++) {
						out.println("<img src=\"images/icon_star.gif\" width=\"20\" height=\"20\">");
					}
				%>
				</td>
              </tr>
              <tr bgcolor="#EDDCF1">
                <td><font face="MS Sans Serif, Microsoft Sans Serif"><img src="images/spaceit.gif" width="30" height=10><%= city %>, <%= country %></font></td>
                <td width="80"><font face="MS Sans Serif, Microsoft Sans Serif"><%= amountOfRoom %>
                  Room</font></td>
                <td colspan="2" align="right"><font face="MS Sans Serif, Microsoft Sans Serif"><%= checkInDate %> to <%= checkOutDate %></font></td>
              </tr>
              <tr valign="middle">
                <td colspan="4"> <img src="images/spaceit.gif" width="30" height="1"><img src="images/hotel_ex.jpg" width="70" height="70">
                </td>
              </tr>
            </table>
<%
				double avgPrice = 0;
				double totalPrice = 0;
	            for(int i=0; i<roomModelPrice.length; i++) {
    	          String roomModelID = roomModelPrice[i].getRoomModelID();
        	      String roomModelName = roomModelPrice[i].getRoomModelName();
            	  olala.hotel.PricePerDay pricePerDay[] = roomModelPrice[i].getColPricePerDay();
%>
            <table width="100%" border="0" bgcolor="#F7F3F5" cellpadding="0" cellspacing="0">
              <tr>
                <td colspan="15" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
              </tr>
              <tr>
                <td width="21" rowspan="2"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td nowrap rowspan="2" width="255"><img src="images/spaceit.gif" width="10" height="1"><img src="images/spaceit.gif" width="10" height="3"><img src="images/spaceit.gif" width="10" height="3"><font face="MS Sans Serif, Microsoft Sans Serif"color="#990066"><b>Room
                  Model</b></font></td>
                <td width="10" rowspan="2"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td width="64"> <font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Avg
                  rate</font> </td>
                <td width="10" rowspan="2"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td width="69"> <font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Total
                  price</font> </td>
                <td width="10" rowspan="2"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td rowspan="2" width="64"></td>
                <td width="10" rowspan="2"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td rowspan="2" width="19"></td>
                <td width="13" rowspan="2"><img src="images/spaceit.gif" width="10" height="3"></td>
              </tr>
              <tr>
                <td width="64"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">(per
                  night)</font></td>
                <td width="69"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">(per
                  room) </font></td>
              </tr>
              <tr>
                <td width="21"><img src="images/spaceit.gif" width=1 height=3></td>
                <td nowrap colspan="9"><img src="images/spaceit.gif" width=1 height=5></td>
                <td width="13"><img src="images/spaceit.gif" width=1 height=3></td>
              </tr>
              <tr>
                <td width="21"><img src="images/spaceit.gif" width=1 height=1></td>
                <td nowrap colspan="9" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                <td width="13"><img src="images/spaceit.gif" width=1 height=1></td>
              </tr>
              <tr>
                <td width="21"><img src="images/spaceit.gif" width=1 height=3></td>
                <td nowrap colspan="9"><img src="images/spaceit.gif" width=1 height=5></td>
                <td width="13"><img src="images/spaceit.gif" width=1 height=3></td>
              </tr>
              <%
	              for (int j=0; j<pricePerDay.length; j++) {
    	            	java.util.Date day = pricePerDay[j].getDay();
        	        	double price = pricePerDay[j].getPrice();
						totalPrice += price;
				  } // pricePerDay
				  avgPrice = totalPrice / pricePerDay.length;
%>
              <tr>
                <td width="21" align="center"><img src="images/ybullet.gif" width="6" height="6"></td>
                <td width="255"><%= roomModelName %></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td width="64"><%= avgPrice %></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td width="69"><%= totalPrice %></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td id='d11' width="64" onmouseover="style.cursor='hand';" onclick="javascript:showdetail('d11');event.cancelBubble=true;" style="POSITION: relative">Detailed
                  Price</td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td width="19">
                  <form name="addToCart" method="post" action="servlet/HotelAddToCartServlet">
                    <input type="image" name="Submit2" value="Submit" src="images/leave.gif" width="19" height="13">
					<input type="hidden" name="hotelID" value="<%= hotelID %>">
					<input type="hidden" name="hotelName" value="<%= hotelName %>">
					<input type="hidden" name="roomModelID" value="<%= roomModelID %>">
					<input type="hidden" name="checkInDate" value="<%= checkInDate %>">
					<input type="hidden" name="checkOutDate" value="<%= checkOutDate %>">
					<input type="hidden" name="amountOfRoom" value="<%= amountOfRoom %>">
					<input type="hidden" name="price" value="<%= totalPrice %>">
                  </form>

                </td>
                <td width="13"><img src="images/spaceit.gif" width="10" height="3" ></td>
              </tr>
              <%
				}  // roomModelPrice
%>
            </table>
            <br>
            <%
			} // while
		} // else
%>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
