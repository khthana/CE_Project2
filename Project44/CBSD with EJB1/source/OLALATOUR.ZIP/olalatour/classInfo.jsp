<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
    try {
        String classID = request.getParameter("classID");
        AirlineService airlineService = airlineServiceHome.create();
        AircraftClassVO classVO = airlineService.GetAircraftClass(classID);
        %>
        
<html>
<head>
<title>OLaLa Tour-Aircraft Class Information - <%= classVO.getClassID() %></title>
</head>
<body>  
<h1>Aircraft Class Information</h1>
<table border="1" cellspacing="1" cellpadding="1">
  <tr> 
    <td align="center" bgcolor="fff5ee"> <font size="-1"><b>Class ID</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Class Name</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Comment</b></font></td>
  </tr>
  <tr> 
    <td align="center"><font size="-1" color="#800000"><b><%= classVO.getClassID() %></b></font></td>
    <td rowspan="1" align="center"><font size="-1"><%= classVO.getClassName() %></font></td>
    <td align="center"><font size="-1"></font></td>
  </tr>
</table>
<p><a href="javascript:window.close();">&gt;&gt;&gt; �Դ˹�ҵ�ҧ��� &lt;&lt;&lt;</a></p>
</body>
</html>  

        <%
    }
    catch (Exception e) {
        out.println("��辺 Aircraft Class ����к�");
    }
%>
