<%@ page import = "java.sql.*" %>
<%@ page import = "java.io.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.ejb.*" %>
<%@ page import = "java.util.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.hotel.*" %>
<%@ page import = "olala.airlinesystem.ViewBookInfo" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	boolean confirm = false;

	private BookingServiceHome bookingServiceHome = null;

    /* ======================= lookup component ======================= */
	public void jspInit() {
    	    try {
         	 	//get naming context
          		Context ctx = new InitialContext();

      	    	//cast to Home interface
          		bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/TourBookingService"), BookingServiceHome.class);

    		}
        	catch(Exception e) {
    			System.out.println("Cannot locate component!!");
	    		e.printStackTrace();
        	}
	}
%>
<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<%
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail");
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" -->
<title>OLaLa Tour-Payment</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr>
    <td height="112" colspan="2">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr>
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr>
          <td width="500"><img src="images/spaceit.gif" width="3" height="30">
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top">
    <td>
      <table width="100%" border=0>
        <tr>
          <td width="128">&nbsp;</td>
        </tr>
        <tr>
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align="center"><b><font face="Courier New, Courier, mono">L
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %>
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt;
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email
                            Address &gt;&gt;</b></font>
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password
                            &gt;&gt;</b></font>
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M
                        e m b e r</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/AcctInfo.gif"
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/Profile.gif"
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit
                        profile </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr>
                      <td valign="top">
                        <table>
                          <tbody>
                          <tr>
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033">
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td width="128" valign="top">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top" >
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your
                        booked entry</b></a></font></td>
                    </tr>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View
                        history </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td valign="top">
            <table cellspacing=0 cellpadding=1 width=174 align=right
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top">
                  <table cellspacing=0 cellpadding=4 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="ffffff">
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img
                  height=28
                  src="images/icon_delivers.gif"
                  width=30 align=left border=0>Subscribe with us to catch up all
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20
                  name=email>
                          <input type=image height=23 width=71
                  src="images/subscribe.gif"
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font
                  face=verdana,arial,helvetica size=-1><br
                  clear=all>
                          </font>
                        </form>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <%
	olala.tour.BookingService bookingService = bookingServiceHome.create();
	String bookingID = request.getParameter("bookingID");
	olala.tour.BookingVO tourbVO = bookingService.GetBooking(bookingID);
        String airlineBookingID = tourbVO.getAirlineBookingID();
        Collection colViewAir = bookingService.ViewAirlineBooking(airlineBookingID);
        Iterator itercolView = colViewAir.iterator();
        int colsize=colViewAir.size();

%>
      <table width="100%" border="0">
        <tr>
          <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
          <td width="5%">&nbsp;</td>
          <td> <font class="hidden"> <b> �����Ţ��èͧ : <%= bookingID %></b></font><br>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Booked
                    Item </font></b></font></div>
                </td>
              </tr>
            </table>
<%
		int totalSeats = 0;
		int totalPrice = 0;
                double grandPrice = 0;

		while (itercolView.hasNext())
                {
			ViewBookInfo booking = (ViewBookInfo) itercolView.next();
			// ��ҹ��ҵ�ҧ � �ҡ ViewBookInfo
			int itemNo = booking.getItemNo();
			String flightID = booking.getFlightID();
			String classID = booking.getClassID();
			Timestamp departDateTime = booking.getDepartDateTime();
			Timestamp arriveDateTime = booking.getArriveDateTime();
			String airportSrcID = booking.getAirportSrcID();
			String airportSrcName = booking.getAirportSrcName();
			String airportDesID = booking.getAirportDesID();
			String airportDesName = booking.getAirportDesName();
			int seats = booking.getTotalSeat();
			double price = booking.getPrice();

			// �ӹǳ�ӹǹ�Ҥ� ��Шӹǹ��������
			totalSeats += seats;
			totalPrice += (price * seats);
%>
            <table width="100%" border="0">
              <tr>
                <td valign="top">
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height=10></td>
                    </tr>
                    <tr>
                      <td> <b><font face="MS Sans Serif, Microsoft Sans Serif"><img src="images/spaceit.gif" width="30" height="1">Item
                        #<%= itemNo %></font></b> </td>
                    </tr>
                  </table>
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td colspan="17" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="1"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Date</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Time</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Flight</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Class</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td nowrap colspan="15" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Depart</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= airportSrcName %> (<%= airportSrcID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departDateTime) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= DateFormat.getTimeInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departDateTime) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="flightInfo.jsp?flightID=<%= flightID %>" target="_blank"><%= flightID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="classInfo.jsp?classID=<%= classID %>" target="_blank"><%= classID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Arrive</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= airportDesName %> (<%= airportDesID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(arriveDateTime) %>
                      </td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= DateFormat.getTimeInstance(DateFormat.MEDIUM, java.util.Locale.US).format(arriveDateTime) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                  </table>
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height=5></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width=10 height=8></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Amount
                        of ticket :</b></font></td>
                      <td colspan="2"><%= seats %></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="8" height=8></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Price
                        per ticket :</b></font></td>
                      <td width="89"><font face="MS Sans Serif, Microsoft Sans Serif"><%= price %></font></td>
                      <td width="152"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="8" height=8></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Total
                        price :</b></font></td>
                      <td width="89"><%= seats * price %></td>
                      <td width="152"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="8" height="8"></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><a href="listTraveller.jsp?bookingID=<%= airlineBookingID %>&itemNo=<%= itemNo %>" target="_blank">Traveller
                        information :</a></b></font></td>
                      <td colspan="2"> </td>
                      <td width="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="242">&nbsp;</td>
                      <td align="right" colspan="2" valign="bottom"> </td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <%
		} // while
                grandPrice = totalPrice;
            %>
            <%
            // Start    GetHotelReserveDetail
            int hotelBookingID = tourbVO.getHotelBookingID().intValue();
            Collection c = null;
            if (hotelBookingID != 0) {
              // Collection of HotelBookingDetail
             HotelBookingDetailVO[] hotelBookingDetailArr = bookingService.GetHotelBookingDetail(hotelBookingID);
              double hotelTotalPrice = 0;
              for(int i=0; i<hotelBookingDetailArr.length; i++) {
                HotelBookingDetailVO hbdVO = (HotelBookingDetailVO) hotelBookingDetailArr[i];

                // init variable
                java.util.Date hotelBookCheckIn = hbdVO.getBookCheckIn();
                java.util.Date hotelBookCheckOut = hbdVO.getBookCheckOut();
                int hotelID = hbdVO.getHotelID();
                String hotelName = hbdVO.getHotelName();
                String hotelRoomNo = hbdVO.getRoomNo();
                String hotelRoomModelName = hbdVO.getRoomModelName();
                int hotelItemNo = hbdVO.getItemNo();
                int hotelprice = hbdVO.getBookingPrice();
                hotelTotalPrice = hotelTotalPrice + hotelprice;
            %>
            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                <td bgcolor="#E1C9E4"><img src="images/spaceit.gif" width="30" height=10></td>
              </tr>
              <tr>
                <td> <b><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/spaceit.gif" width="30" height="8">item
                  #<%= hotelItemNo%></font></b> </td>
              </tr>
            </table>
            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                <td colspan="15" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
              </tr>
              <tr>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Hotel</font></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Room</font></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Check-in</font></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Check-out</font></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Avg
                  rate</font></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
              </tr>
              <tr>
                <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                <td nowrap colspan="9"><img src="images/spaceit.gif" width=1 height=5></td>
                <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
              </tr>
              <tr>
                <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                <td nowrap colspan="9" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
              </tr>
              <tr>
                <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                <td nowrap colspan="9"><img src="images/spaceit.gif" width=1 height=5></td>
                <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
              </tr>
              <tr>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><b><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066"><%=  hotelName %></font></b></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><%= hotelRoomModelName %> ,<%= hotelRoomNo %> </td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><%= hotelBookCheckIn %></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><%= hotelBookCheckOut %></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                <td><%= "--Average--" %></td>
                <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
              </tr>
            </table>
            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                <td colspan="3"><img src="images/spaceit.gif" width="1" height=5></td>
                <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
              </tr>

              <tr>
                <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>price
                  :</b></font></td>
                <td width="87"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><%= hotelprice %></font></td>
                <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Baht</font></td>
                <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
              </tr>

              <tr>
                <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                <td width="246">&nbsp;</td>
                <td colspan="2" valign="bottom">&nbsp; </td>
                <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
              </tr>
            </table>
	<%
            } // end for
%>
Total Price: <%= hotelTotalPrice %>
<%
  grandPrice = totalPrice + hotelTotalPrice;
          }
          else {
        %>
              No Hotel Booking Available
        <%
          }  // end if
	%>
	<br>
            <table width="100%" border="0" bgcolor="#CBBACD">
              <tr>
                <td>
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width=15 height=3></td>
                      <td width="243"><font face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#990066" size="-1">Grand
                        Total :</font></b></font></td>
                      <td width="88"><%= new DecimalFormat("0.00").format(grandPrice) %></td>
                      <td width="158"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Baht</font></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <br>
            <form name="purchase" method="post" action="servlet/ConfirmBookingServlet">
              <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr>
                  <td bgcolor="#990066">
                    <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Payment</font></b></font></div>
                  </td>
                </tr>
              </table>
              <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr bgcolor="#FFD7D7">
                  <td colspan="3"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">*
                    Name and address must be the same as appear on your credit
                    card</font></td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Email address :</font></td>
                  <td width="57%">
                    <input type="text" name="email" size="35">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Confirm Email address :</font></td>
                  <td width="57%">
                    <input type="text" name="email2" size="35">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Firstname :</font></td>
                  <td width="57%">
                    <input type="text" name="firstname" size="35">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Lastname :</font></td>
                  <td width="57%">
                    <input type="text" name="lastname" size="35">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font size="-1"><img src="images/asterisk.gif" width="16" height="16"><font face="MS Sans Serif, Microsoft Sans Serif">
                    Address :</font></font></td>
                  <td width="57%">
                    <input type="text" name="address" size="35">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    District/Province/City :</font></td>
                  <td width="57%">
                    <input type="text" name="city" size="35">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    State :</font></td>
                  <td width="57%">
                    <select name="state" size="1">
                      <option value="00" selected>Select if Appropriate
                      <option value="AL">Alabama
                      <option value="AK">Alaska
                      <option value="AS">American Samoa
                      <option value="AZ">Arizona
                      <option value="AR">Arkansas
                      <option value="AE">Armed Forces
                      <option value="AA">Armed Forces Americas
                      <option value="AP">Armed Forces Pacific
                      <option value="CA">California
                      <option value="CO">Colorado
                      <option value="CT">Connecticut
                      <option value="DE">Delaware
                      <option value="DC">District of Columbia
                      <option value="FM">Federated States of Micronesia
                      <option value="FL">Florida
                      <option value="GA">Georgia
                      <option value="GU">Guam
                      <option value="HI">Hawaii
                      <option value="ID">Idaho
                      <option value="IL">Illinois
                      <option value="IN">Indiana
                      <option value="IA">Iowa
                      <option value="KS">Kansas
                      <option value="KY">Kentucky
                      <option value="LA">Louisiana
                      <option value="ME">Maine
                      <option value="MH">Marshall Islands
                      <option value="MD">Maryland
                      <option value="MA">Massachusetts
                      <option value="MI">Michigan
                      <option value="MN">Minnesota
                      <option value="MS">Mississippi
                      <option value="MO">Missouri
                      <option value="MT">Montana
                      <option value="NE">Nebraska
                      <option value="NV">Nevada
                      <option value="NH">New Hampshire
                      <option value="NJ">New Jersey
                      <option value="NM">New Mexico
                      <option value="NY">New York
                      <option value="NC">North Carolina
                      <option value="ND">North Dakota
                      <option value="MP">Northern Mariana Islands
                      <option value="OH">Ohio
                      <option value="OK">Oklahoma
                      <option value="OR">Oregon
                      <option value="PW">Palau
                      <option value="PA">Pennsylvania
                      <option value="PR">Puerto Rico
                      <option value="RI">Rhode Island
                      <option value="SC">South Carolina
                      <option value="SD">South Dakota
                      <option value="TN">Tennessee
                      <option value="TX">Texas
                      <option value="UT">Utah
                      <option value="VT">Vermont
                      <option value="VI">Virgin Islands
                      <option value="VA">Virginia
                      <option value="WA">Washington
                      <option value="WV">West Virginia
                      <option value="WI">Wisconsin
                      <option value="WY">Wyoming
                      <option value="  ">
                      <option value="AB">Alberta
                      <option value="BC">British Columbia
                      <option value="MB">Manitoba
                      <option value="NB">New Brunswick
                      <option value="NF">Newfoundland
                      <option value="NT">Northwest Territory
                      <option value="NS">Nova Scotia
                      <option value="ON">Ontario
                      <option value="PE">Prince Edward Island
                      <option value="PQ">Quebec
                      <option value="SP">St. Pierre & Miguelon
                      <option value="SK">Saskatchewan
                      <option value="YU">Yukon
                      <option value="  ">
                      <option value="AC">Australian
                      <option value="NW">New South Wales
                      <option value="NO">Northern Territory
                      <option value="QL">Queensland
                      <option value="SA">South Australia
                      <option value="TS">Tasmania
                      <option value="VC">Victoria
                      <option value="WT">Western Australia
                    </select>
                    <br>
                    for USA. , Canada &amp; Australia only</td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Zip code :</font></td>
                  <td width="57%">
                    <input type="text" name="zipcode" maxlength="10" size="10">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Country :</font></td>
                  <td width="57%">
                    <select name="country">
                      <option value="AF">Afghanistan
                      <option value="AL">Albania
                      <option value="DZ">Algeria
                      <option value="AS">American Samoa
                      <option value="AD">Andorra
                      <option value="AO">Angola
                      <option value="AI">Anguilla
                      <option value="AQ">Antarctica
                      <option value="AG">Antigua And Barbuda
                      <option value="AR">Argentina
                      <option value="AM">Armenia
                      <option value="AW">Aruba
                      <option value="AU">Australia
                      <option value="AT">Austria
                      <option value="AZ">Azerbaijan
                      <option value="BS">Bahamas
                      <option value="BH">Bahrain
                      <option value="BD">Bangladesh
                      <option value="BB">Barbados
                      <option value="BY">Belarus
                      <option value="BE">Belgium
                      <option value="BZ">Belize
                      <option value="BJ">Benin
                      <option value="BM">Bermuda
                      <option value="BT">Bhutan
                      <option value="BO">Bolivia
                      <option value="BA">Bosnia And Herzegovinia
                      <option value="BW">Botswana
                      <option value="BV">Bouvet Island
                      <option value="BR">Brazil
                      <option value="IO">British Indian Ocean Territory
                      <option value="BN">Brunei Darussalam
                      <option value="BG">Bulgaria
                      <option value="BF">Burkina Faso
                      <option value="BI">Burundi
                      <option value="KH">Cambodia
                      <option value="CM">Cameroon
                      <option value="CA">Canada
                      <option value="CV">Cape Verde
                      <option value="KY">Cayman Islands
                      <option value="CF">Central African Republic
                      <option value="TD">Chad
                      <option value="CL">Chile
                      <option value="CN">China
                      <option value="CX">Christmas Island
                      <option value="CC">Cocos (Keeling) Islands
                      <option value="CO">Colombia
                      <option value="KM">Comoros
                      <option value="CG">Congo
                      <option value="CD">Congo, DR Of The
                      <option value="CK">Cook Islands
                      <option value="CR">Costa Rica
                      <option value="CI">Cote D'ivoire
                      <option value="HR">Croatia
                      <option value="CU">Cuba
                      <option value="CY">Cyprus
                      <option value="CZ">Czech Republic
                      <option value="DK">Denmark
                      <option value="DJ">Djibouti
                      <option value="DM">Dominica
                      <option value="DO">Dominican Republic
                      <option value="TP">East Timor
                      <option value="EC">Ecuador
                      <option value="EG">Egypt
                      <option value="SV">El Salvador
                      <option value="GQ">Equatorial Guinea
                      <option value="ER">Eritrea
                      <option value="EE">Estonia
                      <option value="ET">Ethiopia
                      <option value="FK">Falkland Islands
                      <option value="FO">Faroe Islands
                      <option value="FJ">Fiji
                      <option value="FI">Finland
                      <option value="FR">France
                      <option value="FX">France, Metropolitan
                      <option value="GF">French Guiana
                      <option value="PF">French Polynesia
                      <option value="TF">French Southern Territories
                      <option value="GA">Gabon
                      <option value="GM">Gambia
                      <option value="GE">Georgia
                      <option value="DE">Germany
                      <option value="GH">Ghana
                      <option value="GI">Gibraltar
                      <option value="GR">Greece
                      <option value="GL">Greenland
                      <option value="GD">Grenada
                      <option value="GP">Guadeloupe
                      <option value="GU">Guam
                      <option value="GT">Guatemala
                      <option value="GN">Guinea
                      <option value="GW">Guinea-Bissau
                      <option value="GY">Guyana
                      <option value="HT">Haiti
                      <option value="HM">Heard And Mcdonald Islands
                      <option value="HN">Honduras
                      <option value="HK">Hong Kong
                      <option value="HU">Hungary
                      <option value="IS">Iceland
                      <option value="IN">India
                      <option value="ID">Indonesia
                      <option value="IR">Iran
                      <option value="IQ">Iraq
                      <option value="IE">Ireland
                      <option value="IL">Israel
                      <option value="IT">Italy
                      <option value="JM">Jamaica
                      <option value="JP">Japan
                      <option value="JO">Jordan
                      <option value="KZ">Kazakhstan
                      <option value="KE">Kenya
                      <option value="KI">Kiribati
                      <option value="KP">Korea, DPR Of
                      <option value="KR">Korea, Republic Of
                      <option value="KW">Kuwait
                      <option value="KG">Kyrgyzstan
                      <option value="LA">Laos
                      <option value="LV">Latvia
                      <option value="LB">Lebanon
                      <option value="LS">Lesotho
                      <option value="LR">Liberia
                      <option value="LY">Libyan Arab Jamahiriya
                      <option value="LI">Liechtenstein
                      <option value="LT">Lithuania
                      <option value="LU">Luxembourg
                      <option value="MO">Macau
                      <option value="MK">Macedonia, FYR Of
                      <option value="MG">Madagascar
                      <option value="MW">Malawi
                      <option value="MY">Malaysia
                      <option value="MV">Maldives
                      <option value="ML">Mali
                      <option value="MT">Malta
                      <option value="MH">Marshall Islands
                      <option value="MQ">Martinique
                      <option value="MR">Mauritania
                      <option value="MU">Mauritius
                      <option value="YT">Mayotte
                      <option value="MX">Mexico
                      <option value="FM">Micronesia, FS Of
                      <option value="MD">Moldova, Republic Of
                      <option value="MC">Monaco
                      <option value="MN">Mongolia
                      <option value="MS">Montserrat
                      <option value="MA">Morocco
                      <option value="MZ">Mozambique
                      <option value="MM">Myanmar
                      <option value="NA">Namibia
                      <option value="NR">Nauru
                      <option value="NP">Nepal
                      <option value="NL">Netherlands
                      <option value="AN">Netherlands Antilles
                      <option value="NC">New Caledonia
                      <option value="NZ">New Zealand
                      <option value="NI">Nicaragua
                      <option value="NE">Niger
                      <option value="NG">Nigeria
                      <option value="NU">Niue
                      <option value="NF">Norfolk Island
                      <option value="MP">Northern Mariana Islands
                      <option value="NO">Norway
                      <option value="OM">Oman
                      <option value="PK">Pakistan
                      <option value="PW">Palau
                      <option value="PA">Panama
                      <option value="PG">Papua New Guinea
                      <option value="PY">Paraguay
                      <option value="PE">Peru
                      <option value="PH">Philippines
                      <option value="PN">Pitcairn
                      <option value="PL">Poland
                      <option value="PT">Portugal
                      <option value="PR">Puerto Rico
                      <option value="QA">Qatar
                      <option value="RE">Reunion
                      <option value="RO">Romania
                      <option value="RU">Russian Federation
                      <option value="RW">Rwanda
                      <option value="KN">Saint Kitts And Nevis
                      <option value="LC">Saint Lucia
                      <option value="WS">Samoa
                      <option value="SM">San Marino
                      <option value="ST">Sao Tome And Principe
                      <option value="SA">Saudi Arabia
                      <option value="SN">Senegal
                      <option value="SC">Seychelles
                      <option value="SL">Sierra Leone
                      <option value="SG">Singapore
                      <option value="SK">Slovakia (Slovak Republic)
                      <option value="SI">Slovenia
                      <option value="SB">Solomon Islands
                      <option value="SO">Somalia
                      <option value="ZA">South Africa
                      <option value="GS">South Georgia
                      <option value="ES">Spain
                      <option value="LK">Sri Lanka
                      <option value="VC">St Vincent And The Grenadines
                      <option value="SH">St. Helena
                      <option value="PM">St. Pierre And Miquelon
                      <option value="SD">Sudan
                      <option value="SR">Suriname
                      <option value="SJ">Svalbard And Jan Mayen Islands
                      <option value="SZ">Swaziland
                      <option value="SE">Sweden
                      <option value="CH">Switzerland
                      <option value="SY">Syrian Arab Republic
                      <option value="TW">Taiwan
                      <option value="TJ">Tajikistan
                      <option value="TZ">Tanzania
                      <option value="TH" selected>Thailand
                      <option value="TG">Togo
                      <option value="TK">Tokelau
                      <option value="TO">Tonga
                      <option value="TT">Trinidad And Tobago
                      <option value="TN">Tunisia
                      <option value="TR">Turkey
                      <option value="TM">Turkmenistan
                      <option value="TC">Turks And Caicos Islands
                      <option value="TV">Tuvalu
                      <option value="UG">Uganda
                      <option value="UA">Ukraine
                      <option value="AE">United Arab Emirates
                      <option value="GB">United Kingdom
                      <option value="US" >United States
                      <option value="UY">Uruguay
                      <option value="UM">US Minor Outlying Islands
                      <option value="UZ">Uzbekistan
                      <option value="VU">Vanuatu
                      <option value="VA">Vatican City State
                      <option value="VE">Venezuela
                      <option value="VN">Viet Nam
                      <option value="VG">Virgin Islands - British
                      <option value="VI">Virgin Islands - U.S.
                      <option value="WF">Wallis And Futuna Islands
                      <option value="EH">Western Sahara
                      <option value="YE">Yemen
                      <option value="YU">Yugoslavia
                      <option value="ZM">Zambia
                      <option value="ZW">Zimbabwe
                    </select>
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Phone# (Home) :</font></td>
                  <td width="57%">
                    <input type="text" name="homephone" size="25">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Phone# (Work) :</font></td>
                  <td width="57%">
                    <input type="text" name="workphone" size="25">
                    ext.
                    <input type="text" name="extension" size="5">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Fax#
                    :</font></td>
                  <td width="57%">
                    <input type="text" name="fax" size="25">
                  </td>
                </tr>
                <tr>
                  <td width="6%">&nbsp;</td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Company
                    name :</font></td>
                  <td width="57%">
                    <input type="text" name="company" size="35">
                  </td>
                </tr>
              </table>
              <br>
              <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr>
                  <td bgcolor="#990066">
                    <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Credit
                      card </font></b></font></div>
                  </td>
                </tr>
              </table>
              <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr bgcolor="#FFD7D7">
                  <td colspan="4">
                    <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">*
                      To make your reservation complete, every field about your
                      credit card below here is needed to be filled.</font></p>
                    <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">*
                      The information you filled below here will be computed with
                      name and address above and sent to the bank for verification.</font></p>
                    <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">*
                      Please re-check name and address above , they must be the
                      same as your credit card.</font></p>
                    <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">*
                      Every payment must be done in limited period, otherwise
                      your reservation will be canceled automatically.</font></p>
                  </td>
                </tr>
                <tr>
                  <td width="5%">&nbsp;</td>
                  <td width="36%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img src="images/asterisk.gif" width="16" height="16">
                    Credit card type :</font></td>
                  <td colspan="2">
                    <select name="creditCardType">
                      <option value="CA">MASTER CARD
                      <option value="AX">AMERICAN EXPRESS
                      <option value="CB">CARTE BLANCHE
                      <option value="DC">DINERS CLUB
                      <option value="DS">DISCOVER
                      <option value="JC">JAPAN CREDIT BUREAU
                      <option value="VI">VISA
                    </select>
                  </td>
                </tr>
                <tr>
                  <td width="5%">&nbsp;</td>
                  <td width="36%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Credit card# :</font></td>
                  <td colspan="2">
                    <input type="text" name="credircardno" maxlength="20" size="20">
                  </td>
                </tr>
                <tr>
                  <td width="5%">&nbsp;</td>
                  <td width="36%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16">
                    Expired date :</font></td>
                  <td colspan="2">
                    <select name="creditCardExpirationMonth">
                      <option>01
                      <option>02
                      <option>03
                      <option>04
                      <option>05
                      <option>06
                      <option>07
                      <option>08
                      <option>09
                      <option>10
                      <option>11
                      <option>12
                    </select>
                    <select name="creditCardExpirationYear">
                      <option>2001
                      <option>2002
                      <option>2003
                      <option>2004
                      <option>2005
                      <option>2006
                      <option>2007
                      <option>2008
                      <option>2009
                      <option>2010
                      <option>2011
                    </select>
                  </td>
                </tr>
                <tr>
                  <td width="5%">&nbsp;</td>
                  <td width="36%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Total
                    price :</font></td>
                  <td width="22%"><%= new DecimalFormat("0.00").format(totalPrice) %></td>
                  <td width="37%"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Baht</font></td>
                </tr>
                <tr>
                  <td width="5%">&nbsp;</td>
                  <td colspan="3"><font color="#FF3366" face="MS Sans Serif, Microsoft Sans Serif" size="-1">*
                    Credit card owner name must be the same as the name you filled
                    above.</font></td>
                </tr>
              </table>
              <br>
              <table width="100%" border="0">
                <tr>
                  <td align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066"><b>By
                    continuing on, please re-check again</b></font></td>
                </tr>
                <tr>
                  <td><img src="images/spaceit.gif" width="1" height=10></td>
                </tr>
                <tr>
                  <td align="center">
                    <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Purchase name=submitted>
                    <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=reset value=Reset name=reset>
                    <input type="hidden" name="bookingID" value="<%= bookingID %>">
                  </td>
                </tr>
              </table>
            </form>
            <br>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
