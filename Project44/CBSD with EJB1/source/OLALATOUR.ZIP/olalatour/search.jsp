<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.sql.Date" %>
<%@ page import = "java.util.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "java.text.DateFormat" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private final String TARGET_PAGE = "index.jsp";

    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
    String departureAirportID = request.getParameter("departureAirport").toUpperCase();
    String destinationAirportID = request.getParameter("destinationAirport").toUpperCase();
    if (departureAirportID.equals("") || destinationAirportID.equals("")
		|| departureAirportID == null || destinationAirportID == null)
	{
        response.sendRedirect(response.encodeURL(TARGET_PAGE+"?errCode=0"));
    }
    AirlineService airlineService = airlineServiceHome.create();
	AirportVO departureAirportVO = null;
	AirportVO destinationAirportVO = null;
	try {
	   	departureAirportVO = airlineService.GetAirport(departureAirportID);
		destinationAirportVO = airlineService.GetAirport(destinationAirportID);
    }
    catch (Exception e) {
        response.sendRedirect(response.encodeURL(TARGET_PAGE+"?errCode=1"));
    }
	
    /* ================== �ѹ�Թ�ҧ� / ��Ѻ ================== */
	String departureDateString = request.getParameter("departureDate");
	java.sql.Date departureDate = java.sql.Date.valueOf(departureDateString);
	String returnDateString = request.getParameter("returnDate");
	java.sql.Date returnDate = java.sql.Date.valueOf(returnDateString);

    /* ================== ���˹觷�����ٺ������������˹�ҵ�ҧ ================== */
    boolean window = true;
    boolean smoking = true;
    boolean directFlight = true;
    if (request.getParameter("window") == null)    { window = false; }
    if (request.getParameter("smoking") == null)    { smoking = false; }
    if (request.getParameter("directFlight") == null)    { directFlight = false; }

    /* ================== �����Թ�ҧ� / ��Ѻ================== */
	java.sql.Time departureTime = null;
	java.sql.Time returnTime = null;
	String departureTimeString = request.getParameter("departureTime");
	String returnTimeString = request.getParameter("returnTime");
	if (!departureTimeString.equals("0")) {
		departureTime = java.sql.Time.valueOf(departureTimeString);
	}
	if (!returnTimeString.equals("0")) {
		returnTime = java.sql.Time.valueOf(returnTimeString);
	}

	String tripType = request.getParameter("tripType");
    int seats = Integer.parseInt(request.getParameter("seats"));
    String aircraftClass = request.getParameter("class");
    if (aircraftClass.equals("")) { aircraftClass = null; }
    String airline = request.getParameter("airline");
    if (airline.equals("")) { airline = null; }
    
    Collection searchResultCollection = null;
	searchResultCollection = airlineService.Search(
        departureAirportID,
        destinationAirportID,
        seats,
        departureDate,
        departureTime,
        aircraftClass,
        airline,
        smoking,
        window,
        directFlight);
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" --> 
<title>OLaLa Tour-Flight Search Result</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr> 
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr> 
    <td height="112" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr> 
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr> 
          <td width="500"><img src="images/spaceit.gif" width="3" height="30"> 
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top"> 
    <td> 
      <table width="100%" border=0>
        <tr> 
          <td width="128">&nbsp;</td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><b><font face="Courier New, Courier, mono">L 
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email 
                            Address &gt;&gt;</b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password 
                            &gt;&gt;</b></font> 
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M 
                        e m b e r</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/AcctInfo.gif" 
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign 
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/Profile.gif" 
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit 
                        profile </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG 
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr> 
                      <td valign="top"> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You 
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033"> 
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td width="128" valign="top"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top" > 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody> 
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your 
                        booked entry</b></a></font></td>
                    </tr>
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View 
                        history </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top"> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa 
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0>Subscribe with us to catch up all 
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font 
                  face=verdana,arial,helvetica size=-1><br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" border="0">
        <tr> 
          <td colspan="3"><iframe style="display:none;position:absolute;width:136;height:300;z-index=100;border-style:solid;border-width:1" id="CalFrame" marginheight=0 marginwidth=0 NORESIZE frameborder=0 scrolling=NO src="detailPrice.htm"> 
            </iframe> 
            <script language=javascript src=detail.js></script>
            <script for=document event="onclick()">document.all.CalFrame.style.display="none";</script>
          </td>
        </tr>
        <tr> 
          <td width="5%">&nbsp;</td>
          <td>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Search 
                    Result</font></b></font></div>
                </td>
              </tr>
            </table>
			<table width="100%" border="0">
              <tr> 
                <td width="20%"><img src="images/flight.gif" width="78" height="41"></td>
                <td width="40%"><font face="Courier New, Courier, mono"><b>O u 
                  t g o i n g</b></font></td>
                <td width="40%" align="right" valign="bottom"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><a href="cart.jsp">Check 
                  Out </a></b></font>&nbsp;</td>
              </tr>
            </table>
<%
    if (searchResultCollection.isEmpty()) {
        %>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr> 
                <td colspan="3" bgcolor="#FFD7D7"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr> 
                <td width=10>&nbsp;</td>
                <td>Search not found </td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
        <%
    }
    else {
    int itemNo = 0;
    Iterator i = searchResultCollection.iterator();
    while(i.hasNext()) {
        itemNo++;
        AirSeatSearchResult assr = (AirSeatSearchResult) i.next();
        %>
            <br>
            <table width="100%" border="0">
              <tr>
			    <td valign="top"> 
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height=10></td>
                    </tr>
                    <tr> 
                      <td>
                        <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b>Item 
                          #<%= itemNo %> </b></font></blockquote>
                      </td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="1"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Date</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Time</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Flight</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Class</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td nowrap colspan="15" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Depart</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= departureAirportVO.getAirportName() %> (<%= departureAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departureDate) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= assr.getDepartTime().toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="flightInfo.jsp?flightID=<%= assr.getFlightID() %>" target="_blank"><%= assr.getFlightID() %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="classInfo.jsp?classID=<%= assr.getClassID() %>" target="_blank"><%= assr.getClassID() %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Arrive</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= destinationAirportVO.getAirportName() %> (<%= destinationAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= assr.getArriveTime().toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td colspan="2"><img src="images/spaceit.gif" width="1" height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="244"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Available 
                        seat :</b></font></td>
                      <td width="249"><%= seats %></td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10" height="23"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="244" height="23"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Price 
                        per seat :</b></font></td>
                      <td width="249" height="23"><font face="MS Sans Serif, Microsoft Sans Serif"><%= new DecimalFormat("0.00").format(assr.getPrice()) %> Baht</font></td>
                      <td width="10" height="23"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="10">&nbsp;</td>
                      <td width="244"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Subtotal 
                        : </b></font></td>
                      <td width="249"><font face="MS Sans Serif, Microsoft Sans Serif"><%= new DecimalFormat("0.00").format(assr.getPrice() * seats) %> Baht</font></td>
                      <td width="10">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="244">&nbsp;</td>
                      <td width="249" align="right"> 
                        <form name="add" action="servlet/AirAddToCartServlet" method="post" >
                          <INPUT class=airBookitButton style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value="Add to Cart" name=submitted>
                          <input type="hidden" name="flightID" value="<%= assr.getFlightID() %>">
                          <input type="hidden" name="classID" value="<%= assr.getClassID() %>">
                          <input type="hidden" name="seats" value="<%= seats %>">
                          <input type="hidden" name="srcidx" value="<%= assr.getSrcIdx() %>">
                          <input type="hidden" name="desidx" value="<%= assr.getDesIdx() %>">
                          <input type="hidden" name="unitPrice" value="<%= assr.getPrice() %>">
                          <input type="hidden" name="smoking" value="<%= smoking %>">
                          <input type="hidden" name="window" value="<%= window %>">
                          <input type="hidden" name="departDate" value="<%= departureDateString %>">
                          <input type="hidden" name="departureAirportID" value="<%= departureAirportID %>">
                          <input type="hidden" name="destinationAirportID" value="<%= destinationAirportID %>">
                          <input type="hidden" name="departureTime" value="<%= assr.getDepartTime().toString() %>">
                          <input type="hidden" name="arriveTime" value="<%= assr.getArriveTime().toString() %>">
                        </form>
                      </td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                  </table>
                </td>
			  </tr>
			</table>
			<br>
        <%
    	} // while
    } // else

	if (tripType.equals("R")) {
	searchResultCollection = airlineService.Search(
        destinationAirportID,
        departureAirportID,
        seats,
        returnDate,
        returnTime,
        aircraftClass,
        airline,
        smoking,
        window,
        directFlight);
%>
			<table width="100%" border="0">
              <tr> 
                <td width="20%"><img src="images/flightbk.gif" width="56" height="45"></td>
                <td width="40%"><font face="Courier New, Courier, mono"><b>I n 
                  c o m i n g</b></font></td>
                <td width="40%" align="right" valign="bottom"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><a href="cart.jsp">Check 
                  Out </a></b></font>&nbsp;</td>
              </tr>
            </table>
<%
    if (searchResultCollection.isEmpty()) {
        %>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr> 
                <td colspan="3" bgcolor="#FFD7D7"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr> 
                <td width=10>&nbsp;</td>
                <td>Search not found </td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
        <%
    }
    else {
    int itemNo = 0;
    Iterator i = searchResultCollection.iterator();
    while(i.hasNext()) {
        itemNo++;
        AirSeatSearchResult assr = (AirSeatSearchResult) i.next();
        %>
            <br>
            <table width="100%" border="0">
              <tr>
			    <td valign="top"> 
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height=10></td>
                    </tr>
                    <tr> 
                      <td>
                        <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>Item 
                          #<%= itemNo %> </b></font></blockquote>
                      </td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr> 
                      <td colspan="17" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="1"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Date</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Time</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Flight</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Class</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td nowrap colspan="15" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Depart</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= destinationAirportVO.getAirportName() %> (<%= destinationAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(returnDate) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= assr.getDepartTime().toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="flightInfo.jsp?flightID=<%= assr.getFlightID() %>" target="_blank"><%= assr.getFlightID() %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="classInfo.jsp?classID=<%= assr.getClassID() %>" target="_blank"><%= assr.getClassID() %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Arrive</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= departureAirportVO.getAirportName() %> (<%= departureAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= assr.getArriveTime().toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td colspan="2"><img src="images/spaceit.gif" width="1" height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="244"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Available 
                        seat :</b></font></td>
                      <td width="249"><%= seats %></td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="244"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Price 
                        per seat :</b></font></td>
                      <td width="249"><font face="MS Sans Serif, Microsoft Sans Serif"><%= new DecimalFormat("0.00").format(assr.getPrice()) %> Baht</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="10">&nbsp;</td>
                      <td width="244"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Subtotal 
                        : </b></font></td>
                      <td width="249"><font face="MS Sans Serif, Microsoft Sans Serif"><%= new DecimalFormat("0.00").format(assr.getPrice() * seats) %> Baht</font></td>
                      <td width="10">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="244">&nbsp;</td>
                      <td width="249" align="right">
					  	<form name="add" action="servlet/AirAddToCartServlet" method="post" >
                          <INPUT class=airBookitButton style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value="Add to Cart" name=submitted>
                        <input type="hidden" name="flightID" value="<%= assr.getFlightID() %>">
                        <input type="hidden" name="classID" value="<%= assr.getClassID() %>">
                        <input type="hidden" name="seats" value="<%= seats %>">
                        <input type="hidden" name="srcidx" value="<%= assr.getSrcIdx() %>">
                        <input type="hidden" name="desidx" value="<%= assr.getDesIdx() %>">
                        <input type="hidden" name="unitPrice" value="<%= assr.getPrice() %>">
                        <input type="hidden" name="smoking" value="<%= smoking %>">
                        <input type="hidden" name="window" value="<%= window %>">
                        <input type="hidden" name="departDate" value="<%= returnDateString %>">
						<input type="hidden" name="departureAirportID" value="<%= destinationAirportID %>">
						<input type="hidden" name="destinationAirportID" value="<%= departureAirportID %>">
						<input type="hidden" name="departureTime" value="<%= assr.getDepartTime().toString() %>">
						<input type="hidden" name="arriveTime" value="<%= assr.getArriveTime().toString() %>">
						</form>	
                      </td>
                      <td width="10"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                  </table>
                </td>
			  </tr>
			</table>
			<br>
            <%
			}
		}
	}
%>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
