<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
    try {
        String flightID = request.getParameter("flightID");
        AirlineService airlineService = airlineServiceHome.create();
        FlightVO flightVO = airlineService.GetFlight(flightID);
        %>
        
<html>
<head>
<title>OLaLa Tour-Flight Information - <%= flightVO.getFlightID() %></title>
</head>
<body>  
<h1>Flight Information</h1>
<p>Flight : <b><%= flightVO.getFlightID() %></b></p>
<table border="1" cellspacing="1" cellpadding="1">
  <tr> 
    <td align="center" bgcolor="fff5ee"> <font size="-1"><b>Flight</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Airline</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Model</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Comment�</b></font></td>
  </tr>
  <tr> 
    <td align="center"><font size="-1" color="#800000"><b><%= flightVO.getDescription() %></b></font></td>
    <td align="center"><font size="-1"><a href="airlineInfo.jsp?airlineID=<%= flightVO.getAirlineID() %>" target="_blank"><%= flightVO.getAirlineID() %></font></td>
    <td align="center"><font size="-1"><a href="modelInfo.jsp?modelID=<%= flightVO.getModelID() %>" target="_blank"><%= flightVO.getModelID() %></a></font></td>
    <td align="center"><font size="-1"></font></td>
  </tr>
</table>
<p><a href="javascript:window.close();">&gt;&gt;&gt; Close this window &lt;&lt;&lt;</a></p>
</body>
</html>  

        <%
    }
    catch (Exception e) {
        out.println("��辺����ǺԹ����к�");
    }
%>
