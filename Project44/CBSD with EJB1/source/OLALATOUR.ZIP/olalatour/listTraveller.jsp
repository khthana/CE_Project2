<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.util.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private BookingServiceHome bookingServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/BookingService");

            //cast to Home interface
            bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ref, BookingServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>OLaLa Tour-Traveller Listing</title>
</head>

<body>

<h1>Traveller Information</h1>
    
<table>
  <tr bgcolor="#d0ccd0"> 
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">No</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">Firstname</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">Lastname</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">Seat#</font></b></div>
    </td>
  </tr>
  <%
	String bookingID = request.getParameter("bookingID");
	int itemNo = Integer.parseInt(request.getParameter("itemNo"));

    String bgcolor = null;
    int row = 0;
    BookingService bookingService = bookingServiceHome.create();
    Collection travellerSeatsCollection = bookingService.GetSeatBookings(bookingID, itemNo);
    Iterator i = travellerSeatsCollection.iterator();
    while (i.hasNext()) {
        row++;
        if ((row % 2) == 0) {
            bgcolor = "#f8f8f8";
        }
        else {
            bgcolor = "#fff0d8";
        }
        TravellerSeat travellerSeat = (TravellerSeat) i.next();
		TravellerVO travellerVO = travellerSeat.getTravellerVO();
        %>
  <tr bgcolor="<%= bgcolor %>"> 
    <td><font face="MS Sans Serif" size="2"><%= row %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= travellerVO.getFirstName() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= travellerVO.getLastName() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= travellerSeat.getSeatNo() %></font></td>
  </tr>
  <%
    }
%>
</table>

<p><a href="javascript:window.close();">&gt;&gt;&gt; Close this window &lt;&lt;&lt;</a></p>
</body>
</html>
