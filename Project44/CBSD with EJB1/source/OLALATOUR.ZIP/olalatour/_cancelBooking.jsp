<%@ page import = "java.sql.*" %>
<%@ page import = "java.io.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.ejb.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.BookingServiceHome" %>
<%@ page import = "olala.tour.BookingService" %>
<%@ page import = "olala.tour.BookingVO" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	boolean confirm = false;

	private BookingServiceHome bookingServiceHome = null;
	private BookingHome bookingHome = null;
    /* ======================= lookup component ======================= */
	public void jspInit() {
    	    try {
         	 	//get naming context
          		Context ctx = new InitialContext();

      	    	//cast to Home interface
          		bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/BookingService"), BookingServiceHome.class);
				bookingHome = (BookingHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Booking"), BookingHome.class);
    		}
        	catch(Exception e) {
    			System.out.println("Cannot locate component!!");
	    		e.printStackTrace();
        	}
	}
%>
<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<%
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail");
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" -->
<title>OLaLa Tour-Payment</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr>
    <td height="112" colspan="2">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr>
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr>
          <td width="500"><img src="images/spaceit.gif" width="3" height="30">
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top">
    <td>
      <table width="100%" border=0>
        <tr>
          <td width="128">&nbsp;</td>
        </tr>
        <tr>
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align="center"><b><font face="Courier New, Courier, mono">L
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %>
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt;
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email
                            Address &gt;&gt;</b></font>
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password
                            &gt;&gt;</b></font>
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M
                        e m b e r</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/AcctInfo.gif"
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/Profile.gif"
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit
                        profile </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr>
                      <td valign="top">
                        <table>
                          <tbody>
                          <tr>
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033">
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td width="128" valign="top">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top" >
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your
                        booked entry</b></a></font></td>
                    </tr>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View
                        history </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td valign="top">
            <table cellspacing=0 cellpadding=1 width=174 align=right
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top">
                  <table cellspacing=0 cellpadding=4 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="ffffff">
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img
                  height=28
                  src="images/icon_delivers.gif"
                  width=30 align=left border=0>Subscribe with us to catch up all
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20
                  name=email>
                          <input type=image height=23 width=71
                  src="images/subscribe.gif"
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font
                  face=verdana,arial,helvetica size=-1><br
                  clear=all>
                          </font>
                        </form>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <%
	BookingService bookingService = bookingServiceHome.create();
	String bookingID = request.getParameter("bookingID");
	Collection bookingCollection = bookingService.ViewBooking(bookingID);
%>

      <table width="100%" border="0">
        <tr>
          <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
          <td width="5%">&nbsp;</td>
          <td>
            <font class="hidden"><b>�����Ţ��èͧ : <%= bookingID %></b></font><br>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Cancel
                    Booking</font></b></font></div>
                </td>
              </tr>
            </table>
            <%
	String errorMessage = null;
	BookingPK bookingPK = new BookingPK(bookingID);
	try {
		Booking _booking = bookingHome.findByPrimaryKey(bookingPK);
		BookingVO bookingVO = _booking.getBooking();
		if (bookingVO.getConfirmation() == 1) {
			confirm = true;
		}
		if (!customer.getCustomerID().equals(bookingVO.getCustomerID())) {
			errorMessage = "�������¡�á�èͧ�ͧ�س";
		}
		// ����� Collection ��ҧ
		else if (bookingCollection.size() == 0) {
			errorMessage = "��辺�����Ţ��èͧ����к�";
		}
	}
	catch (FinderException fe) {
		errorMessage = "��辺�����Ţ��èͧ����к�";
	}

	if (errorMessage != null) {
		%>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                <td colspan="3" bgcolor="#FFD7D7"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr>
                <td width=10>&nbsp;</td>
                <td><%= errorMessage %></td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
            <%
	}
	else {
		Iterator i = bookingCollection.iterator();
		int totalSeats = 0;
		int totalPrice = 0;
		while (i.hasNext()) {
			ViewBookInfo booking = (ViewBookInfo) i.next();
			// ��ҹ��ҵ�ҧ � �ҡ ViewBookInfo
			int itemNo = booking.getItemNo();
			String flightID = booking.getFlightID();
			String classID = booking.getClassID();
			Timestamp departDateTime = booking.getDepartDateTime();
			Timestamp arriveDateTime = booking.getArriveDateTime();
			String airportSrcID = booking.getAirportSrcID();
			String airportSrcName = booking.getAirportSrcName();
			String airportDesID = booking.getAirportDesID();
			String airportDesName = booking.getAirportDesName();
			int seats = booking.getTotalSeat();
			double price = booking.getPrice();

			// �ӹǳ�ӹǹ�Ҥ� ��Шӹǹ��������
			totalSeats += seats;
			totalPrice += (price * seats);
		%>

			<table width="100%" border="0">
              <tr>
			    <td valign="top">
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height=10></td>
                    </tr>
                    <tr>
                      <td> <b><font face="MS Sans Serif, Microsoft Sans Serif"><img src="images/spaceit.gif" width="30" height="1">Item
                        #<%= itemNo %></font></b> </td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td colspan="17" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="1"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Date</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Time</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Flight</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Class</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td nowrap colspan="15" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Depart</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= airportSrcName %> (<%= airportSrcID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departDateTime) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= DateFormat.getTimeInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departDateTime) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="flightInfo.jsp?flightID=<%= flightID %>" target="_blank"><%= flightID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="classInfo.jsp?classID=<%= classID %>" target="_blank"><%= classID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Arrive</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= airportDesName %> (<%= airportDesID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(arriveDateTime) %> </td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= DateFormat.getTimeInstance(DateFormat.MEDIUM, java.util.Locale.US).format(arriveDateTime) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height=5></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width=10 height=8></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Amount
                        of ticket :</b></font></td>
                      <td colspan="2"><%= seats %></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="8" height=8></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Price
                        per ticket :</b></font></td>
                      <td width="89"><font face="MS Sans Serif, Microsoft Sans Serif"><%= price %></font></td>
                      <td width="152"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="8" height=8></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Total
                        price :</b></font></td>
                      <td width="89"><%= seats * price %></td>
                      <td width="152"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="8" height="8"></td>
                      <td width="242"><font face="MS Sans Serif, Microsoft Sans Serif"><b><a href="listTraveller.jsp?bookingID=<%= bookingID %>&itemNo=<%= itemNo %>" target="_blank">Traveller
                        information :</a></b></font></td>
                      <td colspan="2">
					  </td>
                      <td width="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="242">&nbsp;</td>
                      <td align="right" colspan="2" valign="bottom">
                      </td>
                      <td width="2"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                  </table>
                </td>
			  </tr>
			</table>
            <%
		} // while
	%>


                <table width="100%" border="0" bgcolor="#F7F3F5">
                  <tr>
                      <td bgcolor="#E1C9E4"><img src="images/spaceit.gif" width="30" height=10></td>
                   </tr>
                    <tr>
                          <td> <b><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/spaceit.gif" width="30" height="8">item
                            #1</font></b> </td>
                    </tr>
                  </table>

                <table width="100%" border="0" bgcolor="#F7F3F5">
                  <tr>
                    <td colspan="15" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Hotel</font></td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Room
                      Model</font></td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Check-in</font></td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Check-out</font></td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Avg rate</font></td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    <td nowrap colspan="9"><img src="images/spaceit.gif" width=1 height=5></td>
                    <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    <td nowrap colspan="9" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                    <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    <td nowrap colspan="9"><img src="images/spaceit.gif" width=1 height=5></td>
                    <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td><b><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066">Asia</font></b></td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td>Twin (Double) Occupancy - Two Guest Maximum sleeps 2</td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td>Mon 25-Mar-02</td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td>Sat 30-Mar-02</td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    <td>2,540</td>
                    <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                  </tr>
                </table>

            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                    <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                    <td colspan="3"><img src="images/spaceit.gif" width="1" height=5></td>
                    <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width=10 height=8></td>
                    <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>Amount
                      of room :</b></font></td>
                    <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">2</font></td>
                    <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                    <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>Price
                      per room:</b></font></td>
                    <td width="87"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">12,700</font></td>
                    <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Baht</font></td>
                    <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                  </tr>
                  <tr>
                    <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                    <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>Total
                      price :</b></font></td>
                    <td width="87"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">25,400</font></td>
                    <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Baht</font></td>
                    <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                  </tr>
                  <tr>
                    <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                    <td width="246">&nbsp;</td>

                <td colspan="2" valign="bottom">&nbsp; </td>
                    <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                  </tr>
                </table>
			<br>
			<table width="100%" border="0" bgcolor="#CBBACD">
              <tr>
			<td>
			      <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td width="24"><img src="images/spaceit.gif" width=15 height=3></td>
                      <td width="243"><font face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#990066" size="-1">Grand
                        Total :</font></b></font></td>
                      <td width="88"><%= new DecimalFormat("0.00").format(totalPrice) %></td>
                      <td width="158"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Baht</font></td>
              </tr>
            </table>
			</td>
			</tr>
			</table>
			<br>
            <form name="cancel" method="post" action="servlet/CancelBookingServlet">
              <table width="100%" border="0">
                <tr>
                  <td align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1" color="#990066"><b>Click
                    submit to confirm cancellation</b></font></td>
                </tr>
                <tr>
                  <td><img src="images/spaceit.gif" width="1" height=10></td>
                </tr>
                <tr align="center">
                  <td>
                    <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Submit name=submitted>
        		  <input type="hidden" name="bookingID" value="<%= bookingID %>">
                  </td>
                </tr>
              </table>
            </form>
            <br>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
	<%
	}
%>
      <!-- #EndEditable --></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
