<%@ page import = "java.sql.*" %>
<%@ page import = "java.io.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.BookingServiceHome" %>
<%@ page import = "olala.tour.BookingService" %>
<%@ page import = "olala.tour.BookingVO" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private String[] msgCodeArray = {
		"Cancel booking completed",				// 0
		"Confirm booking completed"
	};
	private String[] errCodeArray = {
		"�������ö¡��ԡ��¡���� ���ͧ�ҡ�׹�ѹ��èͧ�����",		// 0
		"�������ö�ӡ�èͧ�� ���ͧ�ҡ�Թ�������ҷ���˹�"
	};

	private BookingServiceHome bookingServiceHome = null;
    /* ======================= lookup component ======================= */
	public void jspInit() {
    	    try {
         	 	//get naming context
          		Context ctx = new InitialContext();

          		//look up jndi name
          		Object ref = ctx.lookup("java:comp/env/ejb/TourBookingService");

      	    	//cast to Home interface
          		bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ref, BookingServiceHome.class);
    		}
        	catch(Exception e) {
    			System.out.println("Cannot locate component!!");
	    		e.printStackTrace();
        	}
	}
%>
<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<%
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail");
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" -->
<title>OLaLa Tour-Booking List</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr>
    <td height="112" colspan="2">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr>
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr>
          <td width="500"><img src="images/spaceit.gif" width="3" height="30">
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top">
    <td>
      <table width="100%" border=0>
        <tr>
          <td width="128">&nbsp;</td>
        </tr>
        <tr>
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align="center"><b><font face="Courier New, Courier, mono">L
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %>
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt;
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email
                            Address &gt;&gt;</b></font>
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password
                            &gt;&gt;</b></font>
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M
                        e m b e r</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/AcctInfo.gif"
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/Profile.gif"
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit
                        profile </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr>
                      <td valign="top">
                        <table>
                          <tbody>
                          <tr>
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033">
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td width="128" valign="top">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top" >
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your
                        booked entry</b></a></font></td>
                    </tr>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View
                        history </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td valign="top">
            <table cellspacing=0 cellpadding=1 width=174 align=right
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top">
                  <table cellspacing=0 cellpadding=4 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="ffffff">
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img
                  height=28
                  src="images/icon_delivers.gif"
                  width=30 align=left border=0>Subscribe with us to catch up all
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20
                  name=email>
                          <input type=image height=23 width=71
                  src="images/subscribe.gif"
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font
                  face=verdana,arial,helvetica size=-1><br
                  clear=all>
                          </font>
                        </form>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
		<br>
            <table width="90%" border="0" align="center">
        <tr>
          <td>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Booking
                    List </font></b></font></div>
                </td>
              </tr>
            </table>
			<blockquote>
            <%
	if (customer == null) {
		out.println("<font class=\"errormsg\">Please login</font>");
	}
	else {
		String msgCode = request.getParameter("msgCode");
		String errCode = request.getParameter("errCode");
		if (msgCode != null) { %>
            <font class="msg"><%= msgCodeArray[Integer.parseInt(msgCode)] %></font>
            <%
		}
		if (errCode != null) { %>
            <font class="errormsg"><%= errCodeArray[Integer.parseInt(errCode)] %></font>
            <%
		}
		%>
			</blockquote>
            Bookings of <b><%= customer.getFirstName() %> <%= customer.getLastName() %></b><br>
            <font class="hidden">Customer# <b><%= customer.getCustomerID() %></b></font> <br>
            <%
    String bgcolor = null;
    int row = 0;
	String customerID = customer.getCustomerID();

    BookingService bookingService = bookingServiceHome.create();
    Collection bookingCollection = bookingService.GetCustomerBookings(customerID);
    Iterator i = bookingCollection.iterator();

	if (!i.hasNext()) {
		out.println("<font class=\"errormsg\">No booking found.</font>");
	}
	else {
		%>
            <table width="100%">
              <tr bgcolor="#F7F3F5"> 
                <td width="10%"> 
                  <div align="center"><b><font face="MS Sans Serif" size="2" color="#990066">No</font></b></div>
                </td>
                <td width="21%"> 
                  <div align="center"><b><font face="MS Sans Serif" size="2" color="#990066">Booking#</font></b></div>
                </td>
                <td width="18%"> 
                  <div align="center"><b><font face="MS Sans Serif" size="2" color="#990066">Book 
                    Date </font></b></div>
                </td>
                <td width="16%"> 
                  <div align="center"><b><font face="MS Sans Serif" size="2" color="#990066">Due 
                    Date </font></b></div>
                </td>
                <td width="17%"> 
                  <div align="center"><b><font face="MS Sans Serif" size="2" color="#990066">Confirmed</font></b></div>
                </td>
                <td width="18%">&nbsp;</td>
                <td width="18%">&nbsp;</td>
                <td width="18%"> 
                  <div align="center"><b><font face="MS Sans Serif" size="2" color="#990066">Obsoleted</font></b></div>
                </td>
              </tr>
              <%
    while (i.hasNext()) {
        row++;
        if ((row % 2) == 0) {
            bgcolor = "#f8f8f8";
        }
        else {
            bgcolor = "#fff0d8";
        }

        BookingVO bookingVO = (BookingVO) i.next();
        %>
              <tr> 
                <td bgcolor="<%= bgcolor %>" width="10%"><font face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp; 
                  <%= row %> &nbsp;&nbsp;&nbsp;</font></td>
                <td bgcolor="<%= bgcolor %>" width="21%"><font face="MS Sans Serif" size="2"><%= bookingVO.getBookingID() %></font></td>
                <td bgcolor="<%= bgcolor %>" width="18%"><font face="MS Sans Serif" size="2"><%= DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(bookingVO.getTransactionDate()) %></font></td>
                <td bgcolor="<%= bgcolor %>" width="16%"><font face="MS Sans Serif" size="2"><%= DateFormat.getDateInstance(DateFormat.SHORT).format(bookingVO.getConfirmDeadline()) %></font></td>
                <td align="center" bgcolor="<%= bgcolor %>" width="17%"><font face="MS Sans Serif" size="2"> 
                  <% if(bookingVO.getConfirmation() == 1) { out.println("<img src=\"images/tu.gif\">"); } %>
                  </font></td>
                <td align="center" bgcolor="<%= bgcolor %>" width="18%" valign="middle"> 
                  <form name="form3" method="post" action="confirmBooking.jsp">
                    <input type="submit" name="Submit2" value="Confirm">
					<input type="hidden" name="bookingID" value="<%= bookingVO.getBookingID() %>">
                  </form>
                </td>
                <td align="center" bgcolor="<%= bgcolor %>" width="18%" valign="middle"> 
                  <form name="form4" method="post" action="cancelBooking.jsp">
                    <input type="submit" name="Submit3" value="Cancel">
					<input type="hidden" name="bookingID" value="<%= bookingVO.getBookingID() %>">
                  </form>
                </td>
                <td align="center" bgcolor="<%= bgcolor %>" width="18%"><font face="MS Sans Serif" size="2"> 
                  <% if(bookingVO.isObsoleted()) { out.println("<img src=\"images/tu.gif\">"); } %>
                  </font></td>
              </tr>
              <%
    } // while
%>
            </table>
            <%
} // else
}
%>
          </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
