<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.util.*" %>
<%@ page import = "java.text.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private String[] errCodeArray = {
		"��سҡ�͡���������ú��ǹ���¤�Ѻ",		// 0
		"����ʹ���Թ���١��ͧ ��س��������������ա����"
	};
	
    private AirlineServiceHome airlineServiceHome = null;
	private AirlineService airlineService = null;
	private Collection airportCollection = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();
            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");
            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
			// Create remote interface
			airlineService = airlineServiceHome.create();
			// Cache airline and airport collection
    		airportCollection = airlineService.GetAllAirport();
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    } // jspInit()
%>

<%
    String errCode = request.getParameter("errCode");
    Calendar calendar = Calendar.getInstance();
    int today = calendar.get(Calendar.DATE);
    int month = calendar.get(Calendar.MONTH);
    int year = calendar.get(Calendar.YEAR);
	String _today = null;
	String _month = null;
	String _year = null;
	// ------------------------ Parse Date ------------------------ //
	if (today < 10) {
		_today = "0" + today;
	}
	else {
		_today = "" + today;
	}
	// ------------------------ Parse Month ------------------------ //
	month += 1;
	if (month < 10) {
		_month = "0" + month;
	}
	else {
		_month = "" + month;
	}
	// ------------------------ Parse Year ------------------------ //
	_year = "" + year;
	// ------------------ Construct Date String ----------------- //
	String currentDate = _year+"-"+_month+"-"+_today;
	System.out.println("index.jsp - Current Date : " + currentDate);
	
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" --> 
<title>OLaLa Tour</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr> 
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr> 
    <td height="112" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr> 
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr> 
          <td width="500"><img src="images/spaceit.gif" width="3" height="30"> 
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top"> 
    <td> 
      <table width="100%" border=0>
        <tr> 
          <td width="128">&nbsp;</td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><b><font face="Courier New, Courier, mono">L 
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email 
                            Address &gt;&gt;</b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password 
                            &gt;&gt;</b></font> 
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M 
                        e m b e r</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/AcctInfo.gif" 
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign 
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/Profile.gif" 
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit 
                        profile </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG 
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr> 
                      <td valign="top"> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You 
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033"> 
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td width="128" valign="top"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top" > 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody> 
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your 
                        booked entry</b></a></font></td>
                    </tr>
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View 
                        history </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top"> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa 
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0>Subscribe with us to catch up all 
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font 
                  face=verdana,arial,helvetica size=-1><br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" height="100%" border="0">
        <tr> 
          <td colspan="3" height="15" > 
		  <IFRAME STYLE="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="datev2.htm">
		  </IFRAME>
		  <SCRIPT language=javascript src=calendar.js></SCRIPT>
		  <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>

          </td>
        </tr>
        <tr> 
          <td width="5%" rowspan="2" >&nbsp;</td>
  
          <td width="90%" rowspan="2" valign="top" align="left" > 
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066"> 
                  <div align="center"><b><font color="#FFF9AE" face="Courier New, Courier, mono">Express 
                    Search</font></b></div>
                </td>
              </tr>
            </table>
            
              <TABLE width="100%" border=0>
             <TBODY>
              <TR>
               <TD vAlign=top colSpan=7>
              	<DIV id=flt>
                    <table width="100%" border="0">
                      <tr> 
                        <td width="20%"><img src="images/flight.gif" width="78" height="41"></td>
                        <td width="40%"><font face="Courier New, Courier, mono"><b>A 
                          i r l i n e</b></font></td>
                        <td width="40%" align="right" valign="bottom">&nbsp;</td>
                      </tr>
                    </table>
                    <FORM name=Wiz method=post action=search.jsp>
            	 <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              	   <TBODY>
              		 <TR>
                          <TD align=left width=130> <font class="size11" face=Arial size="1"> 
                            <LABEL for=idFcity1>Departing from:</LABEL> <BR>
                            <select name="departureAirport" class="smallform">
                              <%
    Iterator iterator = airportCollection.iterator();
    while (iterator.hasNext()) {
        AirportVO airportVO = (AirportVO) iterator.next();
		%>
                              <option value="<%= airportVO.getAirportID() %>"><%= airportVO.getAirportName() %> 
                              (<%= airportVO.getAirportID() %>)</option>
                              <%
	}
%>
                            </select>
                            </font> </TD>
                      <TD align=left width=10>&nbsp;</TD>
                      <TD align=left>
					   <FONT class=size11 face=Arial  size=1>Depart:<BR>
					        <INPUT class=text3 maxLength=12 size=9   value='<%= currentDate %>' onchange="javascript:cbfloadmefirst('Wiz', 'departureDate');" name=departureDate>
                          <A onclick="javascript:cbfshowcalendar('Wiz', 'departureDate', 'dimg1');event.cancelBubble=true;">
						   <IMG  id=dimg1 style="POSITION: relative" height=21 src="images/calendar.gif" width=34 align=top  border=0>
						  </A> 
                            <SELECT class=text5 id=FltTime1 name=departureTime face="Arial">
						  	<option value="0">No Preference</option>
<%
    String timeOption = null;
    for(int i = 0; i <= 23; i++) {
        if (i >= 0 && i <= 9) { timeOption = "0"+i+":00:00"; }
        else { timeOption = i+":00:00"; }
        %>
                            <option value="<%= timeOption %>"><%= timeOption %></option>
        <%
    }
%>
                            </SELECT> 
                        </FONT>
					 </TD>
                     <TD align=right width=65>
					  <FONT class=size11 face=Arial size=1>Adults: <BR>
				        <SELECT class=size11 id=FcAdu name=seats>
                              <OPTION value=1 selected>1&nbsp;
					   <OPTION value=2>2
					   <OPTION value=3>3
					   <OPTION value=4>4
					   <OPTION value=5>5
					   <OPTION value=6>6
					   </OPTION>
					   </SELECT> 
					  </FONT>
					 </TD>
					</TR>
                    <TR>
                      <TD><IMG height=5 src="images/spaceit.gif"  width=1 border=0>
					  </TD>
                     </TR>
					</TBODY>
				 </TABLE>
               <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              	  <TBODY>
                   <TR>
                            <TD align=left width=130> <FONT class=size11 face=Arial size=1> 
                              <LABEL for=idFcitd1>Going to: </LABEL><BR>
                            <select name="destinationAirport" class="smallform">
                              <%
    iterator = airportCollection.iterator();
    while (iterator.hasNext()) {
        AirportVO airportVO = (AirportVO) iterator.next();
		%>
                              <option value="<%= airportVO.getAirportID() %>"><%= airportVO.getAirportName() %> 
                              (<%= airportVO.getAirportID() %>)</option>
                              <%
	}
%>
                            </select>
                              </FONT> </TD>
                  	 <TD align=left width=10>&nbsp;</TD>
                	 <TD>
					  <FONT class=size11 face=Arial size=1>Return:<BR>
					          <INPUT  class=text3 maxLength=12 size=9 value='<%= currentDate %>' onchange="javascript:cbfloadmefirst('Wiz', 'returnDate');" name=returnDate>
                        <A  onclick="javascript:cbfshowcalendar('Wiz', 'returnDate', 'dimg2');event.cancelBubble=true;">
						 <IMG  id=dimg2 style="POSITION: relative" height=21 src="images/calendar.gif" width=34 align=top border=0>
						</A> 
                              <SELECT class=text5 id=FltTime2 name=returnTime  face="Arial">
						  	<option value="0">No Preference</option>
<%
    timeOption = null;
    for(int i = 0; i <= 23; i++) {
        if (i >= 0 && i <= 9) { timeOption = "0"+i+":00:00"; }
        else { timeOption = i+":00:00"; }
        %>
                            <option value="<%= timeOption %>"><%= timeOption %></option>
        <%
    }
%>
                              </SELECT> 
                      </FONT>
					 </TD>
                	        <TD vAlign=bottom align=right width=65> <FONT class=size11 face=Arial size=1> 
                              <BR>
					  </FONT>
                            <INPUT class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Search name=submitted> 
					 </TD>
					</TR>
				   </TBODY>
			    </TABLE>
			  <input type="hidden" name="tripType" value="O">
			  <input type="hidden" name="class" value="">
			  <input type="hidden" name="airline" value="">
                      <br>
                      <img src="images/miniarrow.gif" width="20" height="20"> 
                      <a href="airSearchAdv.jsp"> More Fligh search options. </a> 
                    </FORM>
			</DIV>
			      <DIV id=hot>
<table width="100%" border="0">
                      <tr> 
                        <td width="20%"><img src="images/large_hotels.gif" width="78" height="47"></td>
                        <td width="40%"><font face="Courier New, Courier, mono"><b>H 
                          o t e l</b></font></td>
                        <td width="40%" valign="bottom" align="right">&nbsp;</td>
                      </tr>
                    </table>
                    <form name="Wiz2" method="post" action="hotelSearch.jsp">
                      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                        <TBODY> 
                        <TR> 
                          <TD align=left width=130> <FONT class=size11 face=Arial size=1>Destination 
                            country:<BR>
                            <select class=text1B name="country" size="1">
                              <option value="Canada">Canada</option>
                              <option value="China">China</option>
                              <option value="England">England</option>
                              <option value="Singapore">Singapore</option>
                              <option value="��" selected>Thailand</option>
                              <option value="U.S.A.">U.S.A.</option>
                              <option>Australia</option>
                              <option>Hongkong</option>
                              <option>Indonesia</option>
                              <option>Malaysia</option>
                            </select>
                            </FONT> </TD>
                          <TD align=left width=130></TD>
                          <TD align="left"> <FONT class=size11 face=Arial size=1>Check-in 
                            date:<BR>
                            <INPUT class=text3 maxLength=12 size=9 value='' onchange="javascript:cbfloadmefirst('Wiz2', 'checkInDate');" name=checkInDate>
                            <A onclick="javascript:cbfshowcalendar('Wiz2', 'date3', 'checkInDate');event.cancelBubble=true;"> 
                            <IMG id=dimg3 style="POSITION: relative" height=21 src="images/calendar.gif" width=34 align=top  border=0> 
                            </A> </FONT> </TD>
                          <TD align="right" width="65"><FONT class=size11 face=Arial size=1>Rooms : <BR>
                            <input type="text" name="amountOfRoom" value="1" size="5">
                            </FONT> </TD>
                        </TR>
                        <TR> 
                          <TD><IMG height=5 src="images/spaceit.gif"  width=1 border=0> 
                          </TD>
                        </TR>
                        </TBODY> 
                      </TABLE>
                      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
                        <TBODY> 
                        <TR> 
                          <TD align=left width=130>
							<FONT class=size11 face=Arial size=1>Location 
                            province/state:<BR>
                            <select class=text1B name="city" size="1">
                              <option value="" selected>No preference</option>
                              <option>California</option>
                              <option value="��ا෾"><font size="-1">Bangkok</font></option>
                              <option><font size="-1">Chaingmai</font></option>
                              <option><font size="-1">Chaingrai</font></option>
                              <option><font size="-1">Khonkan</font></option>
                              <option><font size="-1">Ubonratchatanee</font></option>
                              <option><font size="-1">Chonburi</font></option>
                              <option><font size="-1">Trad</font></option>
                              <option><font size="-1">Kanjanaburi</font></option>
                              <option><font size="-1">Petchaburi</font></option>
                              <option><font size="-1">Yala</font></option>
                              <option><font size="-1">Narathivas</font></option>
                              <option>Ohio</option>
                            </select>
                            </FONT> 
						  </TD>
                          <TD align=left width=130>&nbsp; </TD>
                          <TD align="left"> <FONT class=size11 face=Arial size=1>Check-out 
                            date:<BR>
                            <INPUT class=text3 maxLength=12 size=9 value='' onchange="javascript:cbfloadmefirst('Wiz2', 'checkOutDate');" name=checkOutDate>
                            <A onclick="javascript:cbfshowcalendar('Wiz2', 'checkOutDate', 'dimg4');event.cancelBubble=true;"> 
                            <IMG id=dimg4 style="POSITION: relative" height=21 src="images/calendar.gif" width=34 align=top  border=0> 
                            </A> </FONT> </TD>
                          <TD vAlign=bottom align=right width="65"> 
                            <INPUT class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Search name=submitted>
                          </TD>
                        </TR>
                        </TBODY> 
                      </TABLE>
						<input type="hidden" name="state" value="">
						<input type="hidden" name="hotelName" value="">
						<input type="hidden" name="minStar" value="1">
						<input type="hidden" name="maxStar" value="5">
						<input type="hidden" name="minPrice" value="0">
						<input type="hidden" name="maxPrice" value="1000000">
						<input type="hidden" name="roomModelName" value="">
					  	</form>
		 </DIV>
                    <TABLE width="100%" border=0>
                      <TR> 
                        <TD vAlign=top colspan="6"><img src="images/spaceit.gif" width="1" height=5></TD>
                      </TR>
                      <TBODY> 
                      <TR> 
                        <TD vAlign=top width="1%"> 
                          <DIV id=arrow></DIV>
                        </TD>
                        <TD vAlign=top align=left width="70%" colSpan=5> <FONT  class=size13> 
                          <DIV  id=wizopts></DIV>
                          </FONT> </TD>
                      </TR>
                      </TBODY> 
                    </TABLE>
					
                  <table width="100%" border="0">
                    <tr> 
                      <td width="20%"><img src="images/car.gif" width="68" height="55"></td>
                      <td width="40%"><font face="Courier New, Courier, mono"><b>B 
                        u s</b></font></td>
                      <td width="40%" valign="bottom" align="right">&nbsp;</td>
                    </tr>
                  </table>
					<div id='bus'>
                      <table width="100%" border="0" cellpadding="0" cellspacing="0">
                        <tr> 
                          <td bgcolor="#FFCC66" colspan="4"><img src="images/spaceit.gif" width="1" height="1"></td>
                        </tr>
                        <tr> 
                          <td rowspan="7" width="130"><img src="images/carmap.jpg" width="130" height="130"></td>
                          <td width="20">&nbsp;</td>
                          <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>Busses</b></font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Find 
                            and reserve a bus seat for individual travellers.</font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Make 
                            on-line bus-rental reservation for an agency or a 
                            group tour.</font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Searching 
                            by certain depart and destination city, date, amount 
                            and amenity.</font> </td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Payment 
                            and cancellation also available through this page.</font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Always 
                            update to offer you the most complete information.</font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Absolute 
                            lowest published rates you ever found.</font></td>
                        </tr>
					</table>
					<br>
					  <table  width="100%" border="0" >
                        <tr> 
                          <td width="30">&nbsp;<img src="images/miniarrow.gif" width="20" height="20"></td>
                          <td>&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Click-it to find out !</font></td>
                        </tr>
                      </table>
					</div>
                </TR>
			   </TBODY>
  			  </TABLE>
			<table width="100%" border="0">
              <tr> 
                <td bgcolor="#75A3D0" colspan="2"><img src="images/spaceit.gif" width="1" height="1"></td>
              </tr>
              <tr> 
                <td width=15% align="left"><img src="images/ted.gif" width="72" height="61"></td>
                <td align="left"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>Recommended 
                  spots and activities for your great vacation.</b></font></td>
              </tr>
              <tr> 
                <td colspan="2"><img src="images/bluedot_i.GIF" width="168" height="4"><img src="images/bluedot_i.GIF" width="168" height="4"><img src="images/bluedot_ii.GIF" width="40" height="4"><img src="images/bluedot_ii.GIF" width="40" height="4"><img src="images/bluedot_ii.GIF" width="40" height="4"><img src="images/bluedot_ii.GIF" width="40" height="4"><img src="images/bluedot_ii.GIF" width="40" height="4"></td>
              </tr>
              <tr> 
                <td colspan="2">
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                          
                      <td rowspan="7" width="80"><img src="images/sunset.gif" width="78" height="56"></td>
                          <td width="20">&nbsp;</td>
                          
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Summer 
                        time</font></b></font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                          
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Exclusive 
                        place for honey moon, lover couples at <b>Phuket, Thailand.</b></font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Many 
                        beaches, clear water and white sand at <b>Samed island, 
                        Rayong, Thailand.</b></font></td>
                        </tr>
                        <tr> 
                          <td>&nbsp;</td>
                          <td><img src="images/ybullet.gif" width="6" height="6"></td>
                          
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2"><b>Similan 
                        islands, </b>the paradise underwater world as the best 
                        spot for scuba diving.</font></td>
                        </tr>
					</table>
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td rowspan="8" width="80"><img src="images/family_icon.gif" width="50" height="50"></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="20">&nbsp;</td>
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Family</font></b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">A 
                        lot of activities in Military Camp at <b>Nakorn Nayok 
                        ,Thailand.</b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Well-known 
                        place with a lot of facililties <b>Pattaya, Cholburi, 
                        Thailand. </b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Family 
                        trip and delicious northern style food at <b>Chiangmai, 
                        Thailand. </b></font></td>
                    </tr>
                  </table>
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td rowspan="8" width="80"><img src="images/sightseeing.gif" width="70" height="70"></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="20">&nbsp;</td>
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Sightseeing</font></b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Experience 
                        old Morn traditional, river-side living at <b>Khoh Kred, 
                        Nontaburi ,Thailand.</b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Bus 
                        tour around <b>Khoh Rattanakhosin, Bangkok ,Thailand.</b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Visit 
                        a hundred of old Buddha temples at <b>Ayudthaya ,Thailand.</b></font></td>
                    </tr>
                  </table>
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td rowspan="8" width="80"><img src="images/coconut.gif" width="49" height="56"></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="20">&nbsp;</td>
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Island</font></b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Famous 
                        <b>P P island, Krabi, Thailand, </b>especially for snorkelling 
                        and scuba diving.</font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Find 
                        real peace and relax at <b>Mun-Nork island, Rayong, Thailand.</b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2"><b>Maldives</b>, 
                        praised to be the dream of the world for natural beach 
                        lover.</font></td>
                    </tr>
                  </table>
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td rowspan="8" width="80"><img src="images/ski_icon.gif" width="56" height="56"></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="20">&nbsp;</td>
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Mountain</font></b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2"><b>Khao 
                        Sok, </b>rich national park with many beautiful waterfall, 
                        <b>Suratthani, Thailand.</b> </font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">See 
                        thousand kinds of animal life at <b>Khao Yai, Nakornratchasrima, 
                        Thailand. </b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Foggy 
                        table-top mountain at <b>Phu Kradueng, Loey, Thailand, 
                        </b>worth for hard hiking.</font></td>
                    </tr>
                  </table>
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td rowspan="8" width="80"><img src="images/camera360.gif" width="50" height="45"></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="20">&nbsp;</td>
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Memorable 
                        place</font></b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Old 
                        traditional dish maker, many ancient stories and places 
                        at <b>Sukhotai, Thailand.</b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">The 
                        statue of braved Thai's heroin, Ya-mo at <b>Nakornratchasrima, 
                        Thailand. </b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Tragidy 
                        remaining of World War II ,<b>Kware River Bridge,Karnchanaburi,Thailand.</b></font></td>
                    </tr>
                  </table>
                      
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td rowspan="8" width="80"><img src="images/golf_icon.gif" width="50" height="50"></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="20">&nbsp;</td>
                      <td colspan="2"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><font color="#990066">Fun 
                        Stuff </font></b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">All 
                        beach activities you ever wanted, <b>Cha-um beach, Petchaburi, 
                        Thailand.</b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Get 
                        extremely loose with full-moon party at <b>Khoh Pa-Ngan, 
                        Suratthani, Thailand. </b></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><img src="images/ybullet.gif" width="6" height="6"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" size="-2">Try 
                        vegetarian Chinese style food, shop very low price, <b>Hadyai, 
                        Songkhla, Thailand.</b></font> </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td width="5%" >&nbsp;</td>
        </tr>
      </table>
<!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
