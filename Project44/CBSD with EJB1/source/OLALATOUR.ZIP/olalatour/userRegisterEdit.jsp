<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>
<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" --> 
<title>OLaLa Tour-Edit profile</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr> 
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr> 
    <td height="112" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr> 
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr> 
          <td width="500"><img src="images/spaceit.gif" width="3" height="30"> 
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top"> 
    <td> 
      <table width="100%" border=0>
        <tr> 
          <td width="128">&nbsp;</td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><b><font face="Courier New, Courier, mono">L 
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email 
                            Address &gt;&gt;</b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password 
                            &gt;&gt;</b></font> 
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M 
                        e m b e r</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/AcctInfo.gif" 
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign 
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/Profile.gif" 
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit 
                        profile </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG 
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr> 
                      <td valign="top"> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You 
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033"> 
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td width="128" valign="top"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top" > 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody> 
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your 
                        booked entry</b></a></font></td>
                    </tr>
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View 
                        history </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top"> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa 
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0>Subscribe with us to catch up all 
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font 
                  face=verdana,arial,helvetica size=-1><br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" border="0">
        <tr> 
          <td colspan="3">&nbsp;</td>
        </tr>
        <tr> 
          <td width="5%">&nbsp;</td>
          <td valign="top"> 
		    <form name="Register" action= "userRegisterEdit.jsp" method="post">
              <%
	// ��Ǩ�ͺ����ա�� Submit Form �������
	String submit = request.getParameter("submitted");
	CustomerServiceHome customerServiceHome = null;

    // 㹡óշ���ա�� Submit Form
	if (submit != null) {
        String customerID = request.getParameter("customerID");
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String gender = request.getParameter("gender");
		String address = request.getParameter("address");
		String telephone = request.getParameter("telephone");
		String emailAddress = request.getParameter("emailAddress");
		String password = request.getParameter("password");
		String newPassword = request.getParameter("newPassword");
		String newPassword2 = request.getParameter("newPassword2");

		if ((firstName.equals("")) || (lastName.equals("")) || (gender.equals("")) || (address.equals(""))
                || (telephone.equals("")) || (password.equals("")))
        {
            out.println("<font class=\"errormsg\">��سҡ�͡���������ú��ǹ���¤�Ѻ</font>");
        }

        else if (!password.equals(customer.getPassword())) {
            out.println("<font class=\"errormsg\">���ʼ�ҹ���١��ͧ</font>");
        }

        else if (!newPassword.equals(newPassword2)) {
            out.println("<font class=\"errormsg\">���ʼ�ҹ�������ͧ�������ç�ѹ</font>");
        }

      	else
        {

	        // ����ա����������㹿�Ŵ� New Password ��ͧ㴪�ͧ˹��
    	    if (!(newPassword.equals("") || newPassword2.equals(""))) {
        	        password = newPassword;
	        }

    	    try {
         	 	//get naming context
          		Context ctx = new InitialContext();

          		//look up jndi name
          		Object ref = ctx.lookup("java:comp/env/ejb/CustomerService");

      	    	//cast to Home interface
          		customerServiceHome = (CustomerServiceHome) PortableRemoteObject.narrow(ref, CustomerServiceHome.class);
    		} // try
        	catch(Exception e) {
    			out.println("Cannot locate component!!");
	    		e.printStackTrace();
        	} // catch

		    CustomerService cs = customerServiceHome.create();
    		try {
                cs.EditCustomer(customerID, firstName, lastName, gender, address,
                    telephone, emailAddress, password, false);
    			%>
              <font class="msg">Your informations have been updated.<BR>
              Thank you.</font> 
              <%

        	CustomerVO customerDetail = cs.getCustomer(customerID);
	        session.setAttribute("customerDetail", customerDetail);
			customer = customerDetail;
    		} // try
	    	catch (Exception e) {
    			out.println("Caught unexpected exception in EditCustomer");
	    		e.printStackTrace();
    		} // catch

        } // else
	} // if (submit)

%>
              <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                    <div align="center"><font color="#FFF9AE" face="Courier New, Courier, mono"><b>Edit 
                      Profile</b></font></div>
                </td>
              </tr>
            </table>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
    			  <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height="3"><b><font face="MS Sans Serif, Microsoft Sans Serif">Personal 
                    Information</font></b></td>
			  </tr>
			</table>
			  <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr> 
                  <td width="48%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">First 
                      name :</font></b></font></blockquote>
                  </td>
                  <td width="52%"> 
                    <input type="text" name="firstName" value="<%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %>">
                  </td>
                </tr>
                <tr> 
                  <td> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">Last 
                      name :</font></b></font></blockquote>
                  </td>
                  <td> 
                    <input type="text" name="lastName" value="<%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %>">
                  </td>
                </tr>
                <tr> 
                  <td> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">Gender 
                      :</font></b></font></blockquote>
                  </td>
                  <td> 
                    <%
        String M_flag = "";
        String F_flag = "";
        if (customer.getGender().equals("M")) { M_flag = "checked"; }
        if (customer.getGender().equals("F")) { F_flag = "checked"; }
    %>
                    <input type="radio" name="gender" value="M" <%= M_flag %>>
                    <font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Male</font> 
                    <input type="radio" name="gender" value="F" <%= F_flag %>>
                    <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"> 
                    Female</font></td>
                </tr>
                <tr> 
                  <td> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">Address 
                      :</font></b></font></blockquote>
                  </td>
                  <td> 
                    <textarea name="address" wrap="VIRTUAL"><%= CharsetConverter.MS874ToUnicode(new String(customer.getAddress())) %></textarea>
                  </td>
                </tr>
                <tr> 
                  <td> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">Phone 
                      number :</font></b></font></blockquote>
                  </td>
                  <td> 
                    <input type="text" name="telephone" value="<%= CharsetConverter.MS874ToUnicode(new String(customer.getTelephone())) %>">
                  </td>
                </tr>
                <tr> 
                  <td valign="top" align="left" colspan="2"><img height="10" src="images/spaceit.gif"> 
                  </td>
                </tr>
              </table>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
			      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height="3"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Member 
                    Login </b></font></td>
			  </tr>
			</table>
			  <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr> 
                  <td width="48%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">Email 
                      address :</font></b></font></blockquote>
                  </td>
				  <td colspan="2"><b><%= CharsetConverter.MS874ToUnicode(new String(customer.getEmailAddress())) %></b></td>
                </tr>
                <tr> 
                  <td width="48%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16"> 
                      <b>New password : </b></font></blockquote>
                  </td>
                  <td colspan="2"> 
                    <input type="password" name="newPassword">
                  </td>
                </tr>
                <tr> 
                  <td width="48%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16"> 
                      <b>Confirm new password :</b></font></blockquote>
                  </td>
                  <td colspan="2"> 
                    <input type="password" name="newPassword2">
                  </td>
                </tr>
                <tr> 
                  <td colspan="3"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><img src="images/asterisk.gif" width="16" height="16"> 
                      <b>For changing password only</b></font></blockquote>
                  </td>
                </tr>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="48%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="-1">Password 
                      :</font></b></font></blockquote>
                  </td>
                  <td colspan="2"> 
                    <input type="password" name="password">
                  </td>
                </tr>
                <tr> 
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="48%">&nbsp; </td>
                  <td width="23%">&nbsp;</td>
                  <td align="left" width="29%"> 
                    <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Submit name=submitted>
                    <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=reset value=Reset name=submitted2>
                  </td>
                </tr>
              </table>
			<input type="hidden" name="customerID" value="<%= customer.getCustomerID() %>">
			<input type="hidden" name="emailAddress" value="<%= CharsetConverter.MS874ToUnicode(new String(customer.getEmailAddress())) %>">
		  </form>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
