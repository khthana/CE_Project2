<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.util.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private String[] errCodeArray = {
		"��سҡ�͡���������ú��ǹ���¤�Ѻ",		// 0
		"����ʹ���Թ���١��ͧ ��س��������������ա����"
	};
	
    private AirlineServiceHome airlineServiceHome = null;
	private AirlineService airlineService = null;
	private Collection airportCollection = null;
	private Collection airlineCollection = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();
            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");
            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
			// Create remote interface
			airlineService = airlineServiceHome.create();
			// Cache airline and airport collection
    		airportCollection = airlineService.GetAllAirport();
			airlineCollection = airlineService.GetAllAirline();
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    } // jspInit()
%>

<%
    String errCode = request.getParameter("errCode");
    Calendar calendar = Calendar.getInstance();
    int today = calendar.get(Calendar.DATE);
    int month = calendar.get(Calendar.MONTH);
    int year = calendar.get(Calendar.YEAR);
	String _today = null;
	String _month = null;
	String _year = null;
	// ------------------------ Parse Date ------------------------ //
	if (today < 10) {
		_today = "0" + today;
	}
	else {
		_today = "" + today;
	}
	// ------------------------ Parse Month ------------------------ //
	month += 1;
	if (month < 10) {
		_month = "0" + month;
	}
	else {
		_month = "" + month;
	}
	// ------------------------ Parse Year ------------------------ //
	_year = "" + year;
	// ------------------ Construct Date String ----------------- //
	String currentDate = _year+"-"+_month+"-"+_today;
	System.out.println("airsearchAdv.jsp - Current Date : " + currentDate);
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" --> 
<title>OLaLa Tour-Flight Advance Search</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr> 
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr> 
    <td height="112" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr> 
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr> 
          <td width="500"><img src="images/spaceit.gif" width="3" height="30"> 
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top"> 
    <td> 
      <table width="100%" border=0>
        <tr> 
          <td width="128">&nbsp;</td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><b><font face="Courier New, Courier, mono">L 
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email 
                            Address &gt;&gt;</b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password 
                            &gt;&gt;</b></font> 
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M 
                        e m b e r</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/AcctInfo.gif" 
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign 
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/Profile.gif" 
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit 
                        profile </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG 
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr> 
                      <td valign="top"> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You 
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033"> 
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td width="128" valign="top"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top" > 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody> 
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your 
                        booked entry</b></a></font></td>
                    </tr>
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View 
                        history </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top"> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa 
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0>Subscribe with us to catch up all 
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font 
                  face=verdana,arial,helvetica size=-1><br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" height="100%" border="0">
        <tr> 
          <td height="15" colspan="3">
		  	<iframe style="display:none;position:absolute;width:167;height:200;z-index=100;border-style:solid;border-width:1" id="CalFrame" marginheight=0 marginwidth=0 NORESIZE frameborder=0 scrolling=NO src="datev2.htm"> 
            </iframe>
		  <SCRIPT language=javascript src=calendar.js></SCRIPT>
		  <SCRIPT FOR=document EVENT="onclick()">document.all.CalFrame.style.display="none";</SCRIPT>
			
		</td>
        </tr>
        <tr> 
          <td width="5%">&nbsp;</td>
          <td valign="top">
		    <form name="Wiz" action=search.jsp method=post>
              <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066" align="center"><font color="#FFF9AE" face="Courier New, Courier, mono"><b>Flight 
                  Search</b></font></td>
              </tr>
            </table>
              <table width="100%" border="0">
                <TR vAlign=center> 
                  <TD width="26%" align="right"><IMG height=15 src="images/oneway.gif" width=24 border=0> 
                  </TD>
                  <TD width="22%"> 
                    <INPUT id=idOne type=radio value=O name=tripType checked>
                    <LABEL for=idOne>One way</LABEL> </TD>
                  <TD width="4%">&nbsp;&nbsp;&nbsp;&nbsp;</TD>
                  <TD width="12%" align="right"><IMG height=22 src="images/roundtrip.gif" width=23 border=0> 
                  </TD>
                  <TD width="36%"> 
                    <INPUT id=idRnd type=radio  value=R name=tripType>
                    <LABEL for=idRnd>Roundtrip</LABEL> </TD>
                </TR>
              </table>
            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr> 
                  <td bgcolor="#FFD7D7"> <b><font face="JasmineUPC" size="+1"><img src="images/spaceit.gif" width="30" height="8"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Where 
                    do you want to travel ?</font></font></b></td>
              </tr>
            </table>
              <table width="100%" border="0" cellpadding="0" bgcolor="#F7F3F5">
                <tr> 
                  <td valign="top" align="left" colspan="2"><img height=5 src="images/spaceit.gif"> 
                  </td>
              </tr>
              <tr> 
                <td align="left" valign="top" width="38%" nowrap> 
                    <blockquote> <font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Leaving 
                      from :</font></blockquote>
                </td>
                <td align="left" valign="top" width="60%" nowrap> 
                            <select name="departureAirport" class="smallform">
                              <%
    Iterator iterator = airportCollection.iterator();
    while (iterator.hasNext()) {
        AirportVO airportVO = (AirportVO) iterator.next();
		%>
                              <option value="<%= airportVO.getAirportID() %>"><%= airportVO.getAirportName() %> 
                              (<%= airportVO.getAirportID() %>)</option>
                              <%
	}
%>
                            </select>
                </td>
              </tr>
              <tr> 
                <td align="left" valign="top" nowrap> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Going 
                      to :</font></blockquote>
                </td>
                  <td align="left" valign="top" width="60%" nowrap> 
                            <select name="destinationAirport" class="smallform">
                              <%
    iterator = airportCollection.iterator();
    while (iterator.hasNext()) {
        AirportVO airportVO = (AirportVO) iterator.next();
		%>
                              <option value="<%= airportVO.getAirportID() %>"><%= airportVO.getAirportName() %> 
                              (<%= airportVO.getAirportID() %>)</option>
                              <%
	}
%>
                            </select>
                  </td>
              </tr>
                <tr align="left"> 
                  <td valign="middle" colspan="2"><img height=5 src="images/spaceit.gif" width="30"><a href="listAirport.jsp" target="_blank"><img src="images/bearlightblue.gif" width="16" height="16" border="0"></a> 
                    <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><a href="listAirport.jsp" target="_blank"><b>See 
                    all airport codes and details</b></a></font></td>
              </tr>
              <tr> 
                <td colspan="2" bgcolor="#FFFFFF"><img height="3" src="images/spaceit.gif"> 
                </td>
              </tr>
            </table>
			<table width="100%" bgcolor="#F7F3F5">
              <tr>					
                  <td bgcolor="#FFD7D7" height="6"><b><font face="JasmineUPC" size="+1"><img src="images/spaceit.gif" width="30" height="8"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">When 
                    do you want to go? </font></font></b></td>
				</tr>
			</table>			
            <table width="100%" border="0" bgcolor="#F7F3F5">
              <tr> 
                  <td valign="top" align="left" colspan="2"><img height=5 src="images/spaceit.gif"> 
                  </td>
              </tr>
              <tr> 
                <td width="39%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Departing 
                      :</font></blockquote>
                </td>
                <td width="61%">					    
					<INPUT class=text3 maxLength=12 size=9   value='<%= currentDate %>' onchange="javascript:cbfloadmefirst('Wiz', 'departureDate');" name=departureDate>
                          <A onclick="javascript:cbfshowcalendar('Wiz', 'departureDate', 'dimg1');event.cancelBubble=true;">
						   <IMG  id=dimg1 style="POSITION: relative" height=21 src="images/calendar.gif" width=34 align=top  border=0>
						  </A>
                    <select name="departureTime" size="1">
                      <option value="0" selected>No Preference</option>
<%
    String timeOption = null;
    for(int i = 0; i <= 23; i++) {
        if (i >= 0 && i <= 9) { timeOption = "0"+i+":00:00"; }
        else { timeOption = i+":00:00"; }
        %>
                            <option value="<%= timeOption %>"><%= timeOption %></option>
        <%
    }
%>                    </select>
                  </td>
              </tr>
              <tr> 
                <td width="39%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Returning 
                      :</font></blockquote>
                </td>
                <td width="61%">					    
					<INPUT class=text3 maxLength=12 size=9   value='<%= currentDate %>' onchange="javascript:cbfloadmefirst('Wiz', 'returnDate');" name=returnDate>
                          <A onclick="javascript:cbfshowcalendar('Wiz', 'returnDate', 'dimg2');event.cancelBubble=true;">
						   <IMG  id=dimg2 style="POSITION: relative" height=21 src="images/calendar.gif" width=34 align=top  border=0>
						  </A>
                    <select name="returnTime" size="1">
                      <option value="0" selected>No Preference</option>
<%
    timeOption = null;
    for(int i = 0; i <= 23; i++) {
        if (i >= 0 && i <= 9) { timeOption = "0"+i+":00:00"; }
        else { timeOption = i+":00:00"; }
        %>
                            <option value="<%= timeOption %>"><%= timeOption %></option>
        <%
    }
%>
                    </select>
                  </td>
              </tr>
              <tr> 
                  <td valign="top" align="left" colspan="2"><img height=5 src="images/spaceit.gif" width="30"> 
                    <font face="MS Sans Serif, Microsoft Sans Serif" size="-1">* 
                    Returning date is for Roundtrip only.</font></td>
              </tr>
              <tr> 
                <td colspan="2" bgcolor="#FFFFFF"><img height="3" src="images/spaceit.gif"> 
                </td>
              </tr>			  	
            </table>
			  <table width="100%" border="0" bgcolor="#F7F3F5">
                <tr>
    				
                  <td bgcolor="#FFD7D7"><b><font face="JasmineUPC" size="+1"><img src="images/spaceit.gif" width="30" height="8"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Do 
                    you have any preferences ?</font></font></b></td>
			  	</tr>
			</table>
              <table width="100%" border="0" cellpadding="0" bgcolor="#F7F3F5">
                <tr> 
                  <td valign="top" align="left" colspan="3"><img height=5 src="images/spaceit.gif"> 
                  </td>
                </tr>
                <tr> 
                  <td align="left" valign="top" nowrap width="22%"> 
                    <blockquote> <font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Adults 
                      :</font></blockquote>
                  </td>
                  <td align="left" valign="top" nowrap colspan="2"> 
                    <select name="seats" size="1">
                      <option value="1" selected>1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                    </select>
                  </td>
                </tr>
                <tr> 
                  <td align="left" valign="top" nowrap width="22%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Airline 
                      :</font></blockquote>
                  </td>
                  <td align="left" valign="top" nowrap colspan="2"> 
                    <select name="airline" size="0" class="smallform">
                      <option value="" selected>No preference</option>
                      <%
    Iterator i = airlineCollection.iterator();
    while (i.hasNext()) {
        AirlineVO airlineVO = (AirlineVO) i.next();
        %>
                      <option value="<%= airlineVO.getAirlineID() %>"><%= airlineVO.getAirlineName() %></option>
                      <%
    }
%>
                    </select>
                  </td>
                </tr>
                <tr> 
                  <td align="left" valign="top" nowrap width="22%"> 
                    <blockquote><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">&nbsp;Class 
                      :</font></blockquote>
                  </td>
                  <td align="left" valign="top" nowrap colspan="2"> 
                    <select name="class" size="1">
                      <option value="E" selected>Economy Class</option>
                      <option value="B">Business Class</option>
                      <option value="F">First Class</option>
                    </select>
                  </td>
                </tr>
                <tr> 
                  <td width="22%"> <img src="images/spaceit.gif" width="45" height="8"><img src="images/cyan_di.gif" width="19" height="19"></td>
                  <td width="58%"> 
                    <input type="checkbox" name="window" value="true">
                    <font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Window 
                    side </font></td>
                  <td width="20%"></td>
                </tr>
                <tr> 
                  <td width="22%"><img src="images/spaceit.gif" width="40" height="8"> 
                    <img src="images/smredpush.gif" width="21" height="21"><label></label> 
                  </td>
                  <td width="58%"> 
                    <input type="checkbox" name="smoking" value="true">
                    <label><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Smoking 
                    area</font></label></td>
                  <td width="20%"></td>
                </tr>
                <tr> 
                  <td valign="top" align="left" width="22%" > <img src="images/spaceit.gif" width="40" height="8" > 
                    <img height="13" src="images/mult.gif" width="32"></td>
                  <td valign="top" align="left" width="58%" > 
                    <input type="checkbox" name="directFlight" value="true">
                    <label><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">nonstop 
                    flights only</font></label> </td>
                  <td align="center" width="20%"> 
                    <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Search name=submitted>
                  </td>
                </tr>
              </table>
			</form>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
