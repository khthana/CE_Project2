function findPosX(obj)
{
	var curleft = 0;
	if (document.getElementById || document.all)
	{
		while (obj.offsetParent)
		{
			curleft += obj.offsetLeft
			obj = obj.offsetParent;
		}
	}
	else if (document.layers)
		curleft += obj.x;
	return curleft;
}

//-----------------------------------------------------------------------------------------------------------
function findPosY(obj)
{
	var curtop = 0;
	if (document.getElementById || document.all)
	{
		while (obj.offsetParent)
		{
			curtop += obj.offsetTop
			obj = obj.offsetParent;
		}
	}
	else if (document.layers)
		curtop += obj.y;
	return curtop;
}
function showdetail(imgname)
{
	//var x=eval("document.all." + imgname + ".offsetLeft");
	//var y=eval("document.all." + imgname + ".offsetTop");
	var x=findPosX(eval("document.all." + imgname));
	var y=findPosY(eval("document.all." + imgname));
	var max_x = window.screen.width;
	var max_y = window.screen.height-100;
	
	if ((max_y-y<200) && (max_x-x<167))
	{
	document.all.CalFrame.style.top=y-200;
	document.all.CalFrame.style.left=x-167+eval("document.all." + imgname + ".offsetWidth");
	}
	else if (max_y-y<200) 
	{
	document.all.CalFrame.style.top=y-200;
	document.all.CalFrame.style.left=x;
	}
	else if (max_x-x<167)
	{
	document.all.CalFrame.style.top=y+eval("document.all." + imgname + ".offsetHeight");
	document.all.CalFrame.style.left=x-167+eval("document.all." + imgname + ".offsetWidth");
	}
	else
	{
	document.all.CalFrame.style.top=y+eval("document.all." + imgname + ".offsetHeight");
	document.all.CalFrame.style.left=x;
	}

	document.all.CalFrame.style.display="block";
}
