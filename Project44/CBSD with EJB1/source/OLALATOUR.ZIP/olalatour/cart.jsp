<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "java.sql.Date" %>
<%@ page import = "java.util.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "java.text.DateFormat" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
	AirlineService airlineService = airlineServiceHome.create();
%>
<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<%
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail");
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" -->
<title>OLaLa Tour-Shopping Cart</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr>
    <td height="112" colspan="2">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr>
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr>
          <td width="500"><img src="images/spaceit.gif" width="3" height="30">
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top">
    <td>
      <table width="100%" border=0>
        <tr>
          <td width="128">&nbsp;</td>
        </tr>
        <tr>
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align="center"><b><font face="Courier New, Courier, mono">L
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %>
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt;
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email
                            Address &gt;&gt;</b></font>
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password
                            &gt;&gt;</b></font>
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M
                        e m b e r</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/AcctInfo.gif"
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top>
                      <td><img
                        height=18 alt=Icon
                        src="images/Profile.gif"
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit
                        profile </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr valign="top" align="left">
          <td width="128">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td>
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="#ffcc66">
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr>
                      <td valign="top">
                        <table>
                          <tbody>
                          <tr>
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033">
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td width="128" valign="top">
            <table cellspacing=0 cellpadding=1 width=173 align=right
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top" >
                  <table cellspacing=0 cellpadding=3 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody>
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%"
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your
                        booked entry</b></a></font></td>
                    </tr>
                    <tr>
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img
                        height=18 alt=Icon
                        src="images/small-blue-toys-icon.gif"
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View
                        history </a></font></td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr align="left">
          <td valign="top">
            <table cellspacing=0 cellpadding=1 width=174 align=right
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody>
              <tr>
                <td valign="top">
                  <table cellspacing=0 cellpadding=4 width="100%"
                  bgcolor=#ffffff border=0>
                    <tbody>
                    <tr bgcolor=#ffcc66>
                      <td bgcolor="ffffff">
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img
                  height=28
                  src="images/icon_delivers.gif"
                  width=30 align=left border=0>Subscribe with us to catch up all
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20
                  name=email>
                          <input type=image height=23 width=71
                  src="images/subscribe.gif"
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font
                  face=verdana,arial,helvetica size=-1><br
                  clear=all>
                          </font>
                        </form>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" border="0">
        <tr>
          <td colspan="3">

            <script language=JavaScript>
<!--
function chkBrowser(){this.ver=navigator.appVersion;this.dom=document.getElementById?1:0;this.ie5=(this.ver.indexOf("MSIE 5")>-1 && this.dom)?1:0;this.ie4=(document.all && !this.dom)?1:0;
this.ns5=(this.dom && parseInt(this.ver) >= 5) ?1:0;this.ns4=(document.layers && !this.dom)?1:0;this.bVer=(this.ie5 || this.ie4 || this.ns4 || this.ns5);return this;}
bVer=new chkBrowser();ns4 = (document.layers)? true:false;ie4 = (document.all)? true:false;function AttB(f){if(bVer.ie4)f.style.display='block';}function AttN(f){if(bVer.ie4)f.style.display='none';}

function show(idLayer,idParent){cLayer=bVer.dom?document.getElementById(idLayer).style:bVer.ie4?document.all[idLayer].style:bVer.ns4?idParent?document[idParent].document[idLayer]:document[idLayer]:0;
cLayer.display='block';divLinksForm=(ns4)?document.divLinks.document.divLinks:document.divLinks;
var d=document.Wiz;
if (idLayer=='hot'){d.srch[2].status='true';}
else if (idLayer=='flt'){d.srch[1].status='true';}
else {d.srch[0].status='true';}}

function hide(idLayer,idParent){cLayer=bVer.dom?document.getElementById(idLayer).style:bVer.ie4?document.all[idLayer].style:bVer.ns4?idParent?document[idParent].document[idLayer]:document[idLayer]:0;
var d=document.Wiz;
if(idLayer!='flt')AttN(d.FcAdu);AttN(d.Hcadt);AttN(d.Hckid);AttN(d.CKind);AttN(d.Ctime1);AttN(d.Ctime2);cLayer.display='none'}


//-->
</script>
            <script language=JavaScript event=onload for=window>
  <!--
	var f=document.Wiz;
	if(f.srch[1].checked)
	   f.srch[1].click();
                     else if(f.srch[2].checked)
                        f.srch[2].click();
	else f.srch[0].click();
	//-->

</script>
          </td>
        </tr>
        <tr>
          <td width="5%">&nbsp;</td>
          <td>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Shopping
                    Cart</font></b></font></div>
                </td>
              </tr>
            </table>
<table width="100%" border="0">
              <tr>
                <td><img src="images/spaceit.gif" width="10" height="10"></td>
              </tr>
              <tr>
                <td><img src="images/stamp1.gif" width="82" height="10"><img src="images/spaceit.gif" width="8" height="1"><img src="images/stamp1.gif" width="82" height="10"><img src="images/spaceit.gif" width="8" height="1"><img src="images/stamp1.gif" width="82" height="10"><img src="images/spaceit.gif" width="8" height="1"><img src="images/stamp1.gif" width="82" height="10"><img src="images/spaceit.gif" width="8" height="1"><img src="images/stamp1.gif" width="82" height="10"><img src="images/spaceit.gif" width="8" height="1"><img src="images/stamp1.gif" width="82" height="10"></td>
              </tr>
              <tr>
                <td><img src="images/spaceit.gif" width="10" height="10"></td>
              </tr>
            </table>

            <table width="100%" border="0">
              <tr> 
                <td width="20%"><img src="images/flight.gif" width="78" height="41"></td>
                <td width="40%"><font face="Courier New, Courier, mono"><b>A i 
                  r l i n e</b></font></td>
                <td width="40%" align="right" valign="bottom">&nbsp;</td>
              </tr>
            </table>
            <%
    if (shoppingCart.airSize() == 0) {
        %>
			<div id='flt_hot'>
			<div id='flt'>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr>
                <td colspan="3" bgcolor="#FFD7D7"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr>
                <td width=10>&nbsp;</td>
                    <td>No items in your shopping cart..</td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
                <br>
                <%
    }
    else {
	for (int i = 0; i < shoppingCart.airSize(); i++) {
        olala.airlinesystem.CartItem item = shoppingCart.getAirItem(i);

		/* ================== ��ҹ�����Ũҡ Shopping Cart � Session ================== */
		String departureAirportID = item.getDepartureAirportID();
		String destinationAirportID = item.getDestinationAirportID();
		String flightID = item.getFlightID();
		int seats = item.getSeats();
		boolean window = item.getWindow();
		boolean smoking = item.getSmoking();
		String classID = item.getClassID();
		double unitPrice = item.getPrice();
		int srcIdx = item.getSrcIdx();
		int desIdx = item.getDesIdx();
		Date departureDate = item.getDepartDate();
		java.sql.Time departureTime = item.getDepartureTime();
		java.sql.Time arriveTime = item.getArriveTime();
        boolean valid = item.isValid();

		/* ================= ��Ǣ�������� � �����繨ҡ��������ҷ�������� ================= */
		AirportVO departureAirportVO = airlineService.GetAirport(departureAirportID);
		AirportVO destinationAirportVO = airlineService.GetAirport(destinationAirportID);
        %>
                <table width="100%" border="0">
              <tr>
			    <td valign="top">
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height=10></td>
                    </tr>
                    <tr>
                          <td> <b><font face="MS Sans Serif, Microsoft Sans Serif"><img src="images/spaceit.gif" width="30" height="8">Item
                            #<%= i + 1%></font></b> </td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td colspan="17" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="1"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Date</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                          <td colspan="5"><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Time</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Flight</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                          <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Class</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td nowrap colspan="15" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                          <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Depart</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= departureAirportVO.getAirportName() %> (<%=departureAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departureDate) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= departureTime.toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="flightInfo.jsp?flightID=<%= flightID %>" target="_blank"><%= flightID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="classInfo.jsp?classID=<%= classID %>" target="_blank"><%= classID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                          <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Arrive</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= destinationAirportVO.getAirportName() %> (<%= destinationAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><!-- Arrival Time --></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= arriveTime.toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height=5></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width=10 height=8></td>
                          <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Amount
                            of seat :</b></font></td>
                      <td colspan="2"><%= seats %></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                          <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Price
                            per seat :</b></font></td>
                      <td width="87"><font face="MS Sans Serif, Microsoft Sans Serif"><%= new DecimalFormat("0.00").format(unitPrice) %></font></td>
                          <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                          <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Subtotal
                            :</b></font></td>
                      <td width="87"><%= new DecimalFormat("0.00").format(unitPrice * seats) %></td>
                          <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr>
                      <td width="10"><img src="images/spaceit.gif" width="8" height="8"></td>
                          <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b><a href="travellerInfo.jsp?itemNo=<%= i %>">Traveller
                            information :</a></b></font></td>
                      <td colspan="2">
					  <%
					    if (valid) { out.println("<b><font color=\"#3366CC\">Complete</font></b>"); }
					    else { out.println("<b><font color=\"#FF0000\">Incomplete</font></b>"); }
					  %>
					  </td>
                      <td width="6">&nbsp;</td>
                    </tr>
                    <tr>
                      <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="246">&nbsp;</td>
                      <td align="right" colspan="2" valign="bottom">
                            <form name="remove" action="servlet/RemoveFromCartServlet" method="post" >
                              <INPUT class=airBookitButton style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value="Remove" name=submitted>
		                <input type="hidden" name="type" value="air">
                        <input type="hidden" name="index" value="<%= i %>">
		                </form>
                      </td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                  </table>
                </td>
			  </tr>
			</table>
			</div>
              <%
	    } // for
	} // if
%>
              <br>
              <table width="100%" border="0">
                <tr> 
                  <td width="20%"><img src="images/large_hotels.gif" width="78" height="47"></td>
                  <td width="40%"><font face="Courier New, Courier, mono"><b>H 
                    o t e l</b></font></td>
                  <td width="40%" valign="bottom" align="right">&nbsp;</td>
                </tr>
              </table>
              <%
    if (shoppingCart.hotelSize() == 0) {
        %>
              <br>
              <div id='hot'>
			<table width="100%" border="0" bgcolor="#F7F3F5">
                  <tr bgcolor="#E1C9E4">
                    <td colspan="3"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr>
                <td width=10>&nbsp;</td>
                <td>No item in your shopping cart..</td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
                <br>
                <%
    }
    else {
		%>
                <table width="100%" border="0" cellspacing="1" cellpadding="0" align="center">
                    <tr bgcolor="#E1C9E4">
                      <td width="4%" height="17">
                        <div align="center"><font size="-1"><b>ź</b></font></div>
                      </td>
                      <td width="8%" height="17">
                        <div align="center"><font size="-1"><b>��¡�� </b></font></div>
                      </td>
                      <td width="22%" height="17">
                        <div align="center"><font size="-1"><b>�ѹ�ѡ</b></font></div>
                      </td>
                      <td width="22%" height="17">
                        <div align="center"><font size="-1"><b>�ç���</b></font></div>
                      </td>
                      <td width="24%" height="17">
                        <div align="center"><font size="-1"><b>��ͧ�ѡ</b></font></div>
                      </td>
                      <td width="8%" height="17">
                        <div align="center"><font size="-1"><b>�ӹǹ</b></font></div>
                      </td>
                      <td width="12%" height="17">
                        <div align="center"><font size="-1"><b>�Ҥ�(�ҷ)</b></font></div>
                      </td>
                    </tr>
<%
	double totalPrice = 0;
	for (int i = 0; i < shoppingCart.hotelSize(); i++) {
        olala.hotel.ReserveHotelDetail hotelItem = shoppingCart.getHotelItem(i);

		/* ================== ��ҹ�����Ũҡ Shopping Cart � Session ================== */
        String hotelID = hotelItem.getHotelID();
        String hotelName = hotelItem.getHotelName();
        String roomModelID = hotelItem.getRoomModelID();
        java.util.Date bookCheckIn = hotelItem.getBookCheckIn();
        java.util.Date bookCheckOut = hotelItem.getBookCheckOut();
        int amountOfRoom = hotelItem.getAmountOfRoom();
        double bookingPrice = hotelItem.getBookingPrice();
		totalPrice += bookingPrice;
%>
                    <tr align=center  class="text1"  >
                      <td width="4%">
                      <form name="form3" method="post" action="servlet/RemoveFromCartServlet">
					    <input type="hidden" name="type" value="hotel">
  					    <input type="hidden" name="index" value="<%= i %>">
                        <input type="submit" name="Submit2" value="ź">
                      </form>
                    </td>
                      <td width="8%"><%= i+1 %></td>
                      <td width="22%"><%= DateFormat.getDateInstance(DateFormat.SHORT, java.util.Locale.US).format(bookCheckIn) %> - <%= DateFormat.getDateInstance(DateFormat.SHORT, java.util.Locale.US).format(bookCheckOut) %></td>
                      <td width="22%"><%= hotelName %></td>
                      <td width="24%"><%= roomModelID %></td>
                      <td width="8%"><%= amountOfRoom %></td>
                      <td width="12%"><%= new DecimalFormat("#,##0.00").format(bookingPrice) %></td>
                    </tr>
<%
	} // for
%>
                    <tr>
                      <td colspan="6">
                        <div align="right"><font size="-1"><b><font color="#0D549B">�Ҥ����������</font></b></font></div>
                      </td>
                      <td width="12%">
                        <div align="center"><font size="-1"><b><font color="#FF3399"><%= new DecimalFormat("#,##0.00").format(totalPrice) %></font></b></font></div>
                      </td>
                    </tr>
                  </table>
<%
	}
%>
                  <div align="right">
                    
                  <p>&nbsp; </p>
                  </div>
                
              </div>
			</div>
			<br>

			<table width="100%" border="0" bgcolor="#CBBACD">
              <tr>
			<td>
			      <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                <td width="15"><img src="images/spaceit.gif" width=15 height=3></td>
                      <td width="240"><font face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#990066">Grand
                        Total :</font></b></font></td>
                      <td width="85"><%= new DecimalFormat("#,##0.00").format(shoppingCart.getTotalPrice()) %></td>
                      <td width="173"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
              </tr>
            </table>
			</td>
			</tr>
			</table>
			<table width="100%" border="0">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td align="right">
                  <div align="center"><b><a href="airSearchAdv.jsp">Search for
                    other flights</a></b> |<b> <a href="hotelSearchAdv.jsp">Search
                    for other hotels</a> </b>|<b> <a href="reserve.jsp"><font color="#990099">Booking
                    all</font></a></b>&nbsp;</div>
                </td>
              </tr>
            </table>
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
