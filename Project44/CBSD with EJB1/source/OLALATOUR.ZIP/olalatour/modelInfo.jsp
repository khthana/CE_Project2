<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
    try {
        String modelID = request.getParameter("modelID");
        AirlineService airlineService = airlineServiceHome.create();
        AircraftModelVO modelVO = airlineService.GetAircraftModel(modelID);
        %>
        
<html>
<head>
<title>OLaLa Tour-Aircraft Model Information - <%= modelVO.getModelID() %></title>
</head>
<body>  
<h1>Aircraft Model Information</h1>
<table border="1" cellspacing="1" cellpadding="1">
  <tr> 
    <td align="center" bgcolor="fff5ee"> <font size="-1"><b>Model ID</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Model name</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>Total seats</b></font></td>
  </tr>
  <tr> 
    <td align="center"><font size="-1" color="#800000"><b><%= modelVO.getModelID() %></b></font></td>
    <td align="center"><font size="-1"><%= modelVO.getModelName() %></font></td>
    <td align="center"><font size="-1"><%= modelVO.getTotalSeat() %></font></td>
  </tr>
</table>
<p><a href="javascript:window.close();">&gt;&gt;&gt; Close this window &lt;&lt;&lt;</a></p>
</body>
</html>  

        <%
    }
    catch (Exception e) {
        out.println("Aircraft model not found");
    }
%>
