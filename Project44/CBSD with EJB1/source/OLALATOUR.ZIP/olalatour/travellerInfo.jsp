<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "java.sql.Date" %>
<%@ page import = "java.util.*" %>
<%@ page import = "java.text.*" %>

<%@ page import = "olala.tour.ShoppingCart" %>
<%@ page import = "olala.tour.*" %>
<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
	AirlineService airlineService = airlineServiceHome.create();
%>
<html><!-- #BeginTemplate "/Templates/Home.dwt" -->
<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>
<head>
<!-- #BeginEditable "doctitle" --> 
<title>OLaLa Tour-Traveller Information</title>
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF">
<div id="Layer1" style="position:absolute; left:541px; top:94px; width:342px; height:30px; z-index:1"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr> 
      <td width="30" align="right"><a href="index.jsp"><img src="images/icon_home.gif" width="30" height="30" alt="Home" border="0"></a></td>
      <td width="30" align="right"><a href="airSearchAdv.jsp"><img src="images/globe.gif" width="30" height="30" alt="Flight Search" border="0"></a></td>
      <td width="30" align="right"><a href="hotelSearchAdv.htm"><img src="images/icon_build.gif" width="30" height="30" border="0" alt="Hotel Search"></a></td>
      <td width="30" align="right"><a href="cart.jsp"><img src="images/icon_cart.gif" width="30" height="30" alt="Shopping Cart" border="0"></a></td>
      <td width="30" align="right"><a href="viewBooking.jsp"><img src="images/Icon_packages.gif" width="30" height="30" alt="Reservation" border="0"></a></td>
      <td width="30" align="right"><img src="images/ins_icon.gif" width="30" height="30" alt="Sign Out"></td>
    </tr>
  </table>
</div>
<table width="800" border="0" cellspacing="3" cellpadding="0" height="100%" align="center">
  <tr> 
    <td height="112" colspan="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
        <tr> 
          <td bgcolor="#FFFFFF" colspan="12"><img src="images/titlebar_iii.jpg" width="749" height="85"></td>
        </tr>
        <tr> 
          <td width="500"><img src="images/spaceit.gif" width="3" height="30"> 
          </td>
          <td width="10"><img src="images/spaceit.gif" width=10 height="8"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr valign="top"> 
    <td> 
      <table width="100%" border=0>
        <tr> 
          <td width="128">&nbsp;</td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><b><font face="Courier New, Courier, mono">L 
                          o G i N</font></b></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">Welcome<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          Logout &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Email 
                            Address &gt;&gt;</b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b>&nbsp;Password 
                            &gt;&gt;</b></font> 
                            <input type="password" name="password">
                            <br>
                            <br>
                            <input type="image" width="107" height="28" src="images/submit01.gif"  value="Submit" border=0 name="Submit" align="right">
                            &nbsp;</p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">M 
                        e m b e r</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/AcctInfo.gif" 
                        width=20 border=0></td>
                      <td><a href="userRegister.jsp"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><b>Sign 
                        up here!!</b></font></a></td>
                    </tr>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/Profile.gif" 
                        width=20 border=0></td>
                      <td><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="userRegisterEdit.jsp">Edit 
                        profile </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr valign="top" align="left"> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 dwcopytype="CopyTableRow">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align=center><b><font face="Courier New, Courier, mono">ShoPPinG 
                          Cart</font></b> </div>
                      </td>
                    </tr>
                    <tr> 
                      <td valign="top"> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><a href="cart.htm"><img height=25 alt="Shopping Cart" src="images/shopping-cart-small.gif" width=25 align=left border=0></a></td>
                            <td valign=top> <font size="-1" face="MS Sans Serif, Microsoft Sans Serif">You 
                              have got <font class="varhighlight"><%= shoppingCart.size() %></font> items in your <font color="#CC0033"> 
                              </font><a href="cart.jsp"><b> shopping cart</b></a></font></td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td width="128" valign="top"> 
            <table cellspacing=0 cellpadding=1 width=173 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top" > 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small align="center"><b><font face="Courier New, Courier, mono">Reservation</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tr> </tr>
                    <tbody> 
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="listBooking.jsp"><b>Your 
                        booked entry</b></a></font></td>
                    </tr>
                    <tr> 
                      <td valign=top align=left width="15%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></font></td>
                      <td valign=top width="85%"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><a href="viewPurchased.jsp">View 
                        history </a></font></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr align="left"> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td valign="top"> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color"><font size="-1" face="MS Sans Serif, Microsoft Sans Serif">OLaLa 
                          Tour News</font></span></b><font size="-1" face="MS Sans Serif, Microsoft Sans Serif"><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0>Subscribe with us to catch up all 
                          update information you can't missed.<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          Touring news<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          Travel news<br>
                          <span class="h3color">E-mail Address :</span><br>
                          <input maxlength=60 size=20 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=right value="Sign up" border=0 name="Sign up">
                          </font><font 
                  face=verdana,arial,helvetica size=-1><br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="6"><!-- #BeginEditable "center" -->
      <table width="100%" border="0">
        <tr> 
          <td colspan="3">&nbsp;</td>
        </tr>
        <tr> 
          <td width="5%">&nbsp;</td>
          <td>
            <table width="100%" border="0">
              <tr>
                <td bgcolor="#990066">
                  <div align="center"><font color="#FFF9AE"><b><font face="Courier New, Courier, mono">Traveller 
                    Information</font></b></font></div>
                </td>
              </tr>
            </table>
<%
    int itemNo = Integer.parseInt(request.getParameter("itemNo"));
    olala.airlinesystem.CartItem cartItem = (olala.airlinesystem.CartItem) shoppingCart.getAirItem(itemNo);
    if (cartItem == null) {
        %>
			<table width="100%" border="0" bgcolor="#F7F3F5">
              <tr> 
                <td colspan="3" bgcolor="#FFD7D7"><img src="images/spaceit.gif" width=10 height=10></td>
              </tr>
              <tr> 
                <td width=10>&nbsp;</td>
                <td>No item in your shopping cart..</td>
                <td width=10>&nbsp;</td>
              </tr>
            </table>
        <%
    }
    else {
        olala.airlinesystem.CartItem item = shoppingCart.getAirItem(itemNo);

		/* ================== ��ҹ�����Ũҡ Shopping Cart � Session ================== */
		String departureAirportID = item.getDepartureAirportID();
		String destinationAirportID = item.getDestinationAirportID();
		String flightID = item.getFlightID();
		int seats = item.getSeats();
		boolean window = item.getWindow();
		boolean smoking = item.getSmoking();
		String classID = item.getClassID();
		double unitPrice = item.getPrice();
		int srcIdx = item.getSrcIdx();
		int desIdx = item.getDesIdx();
		Date departureDate = item.getDepartDate();
		java.sql.Time departureTime = item.getDepartureTime();
		java.sql.Time arriveTime = item.getArriveTime();
        boolean valid = item.isValid();

        Collection travellerCollection = cartItem.getAllTraveller();
        int numrow = cartItem.getSeats();

		/* ================= ��Ǣ�������� � �����繨ҡ��������ҷ�������� ================= */
		AirportVO departureAirportVO = airlineService.GetAirport(departureAirportID);
		AirportVO destinationAirportVO = airlineService.GetAirport(destinationAirportID);
        %>
			<table width="100%" border="0">
              <tr>
			    <td valign="top"> 
                  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr>
                      <td bgcolor="#FFD7D7"><img src="images/spaceit.gif" width="30" height=10></td>
                    </tr>
                    <tr> 
                      <td>
                        <blockquote><b><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Item 
                          #<%= itemNo + 1%></font></b></blockquote>
                      </td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr> 
                      <td colspan="17" height="10"><img src="images/spaceit.gif" width="30" height="10"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="1"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td nowrap><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Date</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Time</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font  face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Flight</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Class</font></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td nowrap colspan="15" bgcolor="#990066"><img src="images/spaceit.gif" width=1 height=1></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=1></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                      <td nowrap colspan="15"><img src="images/spaceit.gif" width=1 height=5></td>
                      <td width="10"><img src="images/spaceit.gif" width=1 height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Depart</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= departureAirportVO.getAirportName() %> (<%=departureAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= DateFormat.getDateInstance(DateFormat.MEDIUM, java.util.Locale.US).format(departureDate) %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= departureTime.toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="flightInfo.jsp?flightID=<%= flightID %>" target="_blank"><%= flightID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><a href="classInfo.jsp?classID=<%= classID %>" target="_blank"><%= classID %></a></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><b><font face="MS Sans Serif, Microsoft Sans Serif" color="#990066">Arrive</font></b></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td><%= destinationAirportVO.getAirportName() %> (<%= destinationAirportID %>)</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td colspan="5"><%= arriveTime.toString() %></td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                      <td>&nbsp;</td>
                      <td width="10"><img src="images/spaceit.gif" width="10" height="3"></td>
                    </tr>
                  </table>
				  <table width="100%" border="0" bgcolor="#F7F3F5">
                    <tr> 
                      <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td colspan="3"><img src="images/spaceit.gif" width="1" height=5></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width=10 height=8></td>
                      <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Amount 
                        of seat :</b></font></td>
                      <td colspan="2"><%= seats %></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                      <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Price 
                        per seat :</b></font></td>
                      <td width="87"><font face="MS Sans Serif, Microsoft Sans Serif"><%= new DecimalFormat("0.00").format(unitPrice) %></font></td>
                      <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="10"><img src="images/spaceit.gif" width="8" height=8></td>
                          <td width="246"><font face="MS Sans Serif, Microsoft Sans Serif"><b>Subtotal 
                            :</b></font></td>
                      <td width="87"><%= new DecimalFormat("0.00").format(unitPrice * seats) %></td>
                          <td width="162"><font face="MS Sans Serif, Microsoft Sans Serif">Baht</font></td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                    <tr> 
                      <td width="8"><img src="images/spaceit.gif" width="1" height=3></td>
                      <td width="246">&nbsp;</td>
                      <td align="right" colspan="2" valign="bottom"> 
                      </td>
                      <td width="6"><img src="images/spaceit.gif" width="1" height=3></td>
                    </tr>
                  </table>
                </td>
			  </tr>
			</table>
            <br>
            <form name="editTraveller" action="servlet/EditTravellerServlet" method="post">
			  <table width="95%" border="0" bgcolor="#C9ABCB">
                <tr>
                <td valign="top"> 
                    <table width="100%" border="0" bgcolor="#C9ABCB">
                      <tr> 
                        <td height="15"> <font face="MS Sans Serif, Microsoft Sans Serif" size="-1"><b><img src="images/spaceit.gif" width="40" height=15>Traveller  List
                          </b></font></td>
                    </tr>
                  </table>
				    <table width="100%" border="0" bgcolor="#EFE8F0">
<%
    int row = 0;
    Iterator i = travellerCollection.iterator();
    for (int count = 0; count < numrow; count++) {
        row++;
        String firstName = "";
        String lastName = "";
        if (i.hasNext()) {
            TravellerVO travellerVO = (TravellerVO) i.next();
            firstName = travellerVO.getFirstName();
            lastName = travellerVO.getLastName();
        }
        %>
                      <tr> 
                      <td colspan="6"><img src="images/spaceit.gif" width="1" height=10></td>
                    </tr>
                    <tr> 
                        <td width="10"><%= row %></td>
                        <td align="right" width="54"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Firstname:</font></td>
                      <td width="172"> 
              <input type="text" name="firstname<%= row %>" value="<%= firstName %>">
                      </td>
                        <td align="right" width="75"><font face="MS Sans Serif, Microsoft Sans Serif" size="-1">Lastname:</font></td>
                      <td colspan="2"> 
              <input type="text" name="lastname<%= row %>" value="<%= lastName %>">
                      </td>
                    </tr>
        <%
        }
%>
                    <tr> 
                      <td colspan="6"><img src="images/spaceit.gif" width="1" height=10></td>
                    </tr>
                    <tr> 
                      <td colspan="4">&nbsp; </td>
                      <td width="87" align="right"> 
                        <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=submit value=Submit name=submitted>
                      </td>
                      <td width="109"> 
                        <input class=smGoBtn style="BORDER-RIGHT: #0054A6 thin solid; BORDER-TOP: #9ABBDB thin solid; BORDER-LEFT: #9ABBDB thin solid; COLOR: #ffffff; BORDER-BOTTOM: #0054A6 thin solid; BACKGROUND-COLOR: #5191CF" type=reset value=Reset name=submitted2>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
    		  <input type="hidden" name="itemNo" value="<%= itemNo %>">
			</form>
<%
    }
%>
            
          </td>
          <td width="5%">&nbsp;</td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td align="left" valign="top">&nbsp; </td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
