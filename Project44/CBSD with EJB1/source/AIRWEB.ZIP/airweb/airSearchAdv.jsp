<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.util.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
    String error = request.getParameter("error");
    if (error == null) {
        error = "";
    }
    Calendar calendar = Calendar.getInstance();
    int today = calendar.get(Calendar.DATE);
    int month = calendar.get(Calendar.MONTH);
    int year = calendar.get(Calendar.YEAR);

    AirlineService airlineService = airlineServiceHome.create();
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>

<head>
<!-- #BeginEditable "doctitle" -->
<title>OLALA Transport</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<table width="800" border="0" cellspacing="3" cellpadding="0">
  <tr> 
    <td height="83" colspan="2"> 
      <div align="center"><img src="images/title_index3.gif" width="795" height="88" align="right"></div>
      <div align="center"> </div>
    </td>
  </tr>
  <tr valign="top"> 
    <td width="128"> 
      <table width="100%" border="0">
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>S E R V I C E S</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td><b><font size="-1">+</font><font size="-1">&nbsp;</font><font size="-1"><a href="index.jsp">��������ǺԹ</a><br>
                        +<font color=#003399>&nbsp;</font><a href="listBooking.jsp">��������´��èͧ</a><br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        �׹�ѹ��èͧ<br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        ¡��ԡ��èͧ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>L O G I N</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">���ʴդ�Ѻ �س<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          �͡�ҡ�к� &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font size="-1"><b>Email Address: </b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <b><font size="-1">���ʼ�ҹ: </font></b> 
                            <input type="password" name="password">
                            <br>
                            <input type="submit" name="Submit" value="��ŧ">
                            <input type="reset" name="Submit2" value="¡��ԡ">
                          </p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="22"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1><span class=small><b class="h3color">�س����Ҫԡ�Ѻ��������ѧ?</b><br>
                          �س��ͧ��Ѥ�����Ҫԡ�Ѻ��� ���ͷӡ�èͧ��������� 
                          ��Ҥس�ѧ�������Ѥ���Ҫԡ ����ö��Ѥ� ��<br>
                          <a href="userRegister.jsp">&gt;&gt;&gt; ������Ѻ 
                          &lt;&lt;&lt;</a></span><br>
                          </font></div>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="107"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0" height="76">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"><font face=verdana,arial,helvetica size=-1><b>Your 
                        Shopping Cart</b></font> </td>
                    </tr>
                    <tr> 
                      <td> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><img 
                              height=25 alt="Shopping Cart" 
                              src="images/shopping-cart-small.gif" 
                              width=25 align=left border=0></td>
                            <td valign=top><font size="-1">�س���Թ��ҷ����� 
                              <font class="varhighlight"><%= shoppingCart.size() %></font> 
                              ��� � <a href="cart.jsp">ö�繢ͧ�س</a></font><br>
                            </td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small><b><font size="-1">��ԡ����Ҫԡ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <%
    if (customer == null) {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegister.jsp">��Ѥ���Ҫԡ����</a></font></td>
                    </tr>
                    <%
    }
    else {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegisterEdit.jsp">��䢢����š��ŧ����¹</a></font></td>
                    </tr>
                    <%
    }
%>
                    </tbody> 
                  </table>
                  
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color">������� Olala Transport</span></b><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0> <font size=-1>�س����ö��Ѥ���Ҫԡ 
                          �����Ѻ������èҡ����繻�Ш����Ѻ �Ѻ�ͧ����������<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          �����������ǡѺ��÷�ͧ�����<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          �����������ǡѺ����Թ�ҧ<br>
                          <span class="h3color">E-mail Address �ͧ�س:</span></font><span class="h3color"><font 
                  face=verdana,arial,helvetica size=-1></font></span><font 
                  face=verdana,arial,helvetica size=-1><br>
                          <input maxlength=60 size=15 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=absMiddle value="Sign up" border=0 name="Sign up">
                          <br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="2"> <!-- #BeginEditable "Center" -->
      <table width="480" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr>
          <td>
            <form name=AvailRequester action=search.jsp method=post>
              <br>
              <br>
<% 
    if (error.equals("NullInput")) {
        out.println("<font class=\"errormsg\">��سҡ�͡���������ú��ǹ���¤�Ѻ</font>");
    }
    else if (error.equals("InvalidAirport")) {
        out.println("<font class=\"errormsg\">����ʹ���Թ���١��ͧ ��س��������������ա����</font>");
    }
%>
              <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#34208b><img height=20
            src="images/lt_blue_corner.gif" width=18 border=0></td>
                  <td class=rateheader align=left width=440
          background=images/dk_blue_bg.gif><font color=#fefefe><b>��������ǺԹ</b></font></td>
                  <td align=right bgcolor=#34208b><img height=20
            src="images/rt_blue_corner.gif" width=18
        border=0></td>
                </tr>
                </tbody>
              </table>
			  <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td><img height=6 src="images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor=#34208b><img height=1 src="images/1x1.gif"
          width=1></td>
                </tr>
                <tr>
                  <td class=searchinstruct bgcolor=#f0f0f0><b>&nbsp;ʶҹ����Թ�ҧ</b></td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=1 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#f0f0f0>
                    <table cellspacing=0 cellpadding=0 width="100%" bgcolor=#fefefe
            border=0>
                      <tbody>
                      <tr bgcolor=#fefefe width="100%">
                        <td width=20><img height=10 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3
                  src="D:\tmp\TravelNow Airfare Reservations_files\search_files\1x1(1).gif"
                  width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                        <td class=airsearchexample3 rowspan=3> 
                          <p><font color="#888888"> <br>
                            ��س�������ʹ���Թ㹡�ä����� BKK ����Ѻ Bangkok</font></p>
                          <p align="center"><font color="#888888"><a href="listAirport.jsp" target="_blank">&gt;&gt;&gt; 
                            �ʴ�����ʹ���Թ������ &lt;&lt;&lt;</a></font></p>
                          </td>
                        <td width=10 rowspan=3><img height=3
                  src="images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td class=airFieldTitle noWrap width=120 ><font color="#34208b">ʹ���Թ�鹷ҧ:</font></td>
                        <td class=airField noWrap align=left>
                          <input class=smallform
                  name=departureAirport>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td class=airFieldTitle noWrap width=120 ><font color="#34208b">ʹ���Թ���·ҧ:</font></td>
                        <td class=airField noWrap align=left>
                          <input class=smallform
                  name=destinationAirport>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=3 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                      </tr>
                      <tr bgcolor=#fefefe>
                        <td>&nbsp;</td>
                        <td class=airsearchexample3 noWrap colspan=2><font
                  color=#888888></font></td>
                      </tr>
                      <tr>
                        <td width=20><img height=7 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                        <td><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="images/1x1.gif"
                width=1></td>
                      </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td><img height=6 src="images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor=#34208b><img height=1 src="images/1x1.gif"
          width=1></td>
                </tr>
                <tr>
                  <td class=searchinstruct bgcolor=#f0f0f0><font color="#000000"><b>&nbsp;�ѹ���
                    ��������Թ�ҧ</b> </font></td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=1 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#f0f0f0>
                    <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                      <tr>
                        <td width=20><img height=8 src="/images/1x1.gif" width=20></td>
                        <td noWrap><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=5><img height=3 src="/images/1x1.gif" width=1></td>
                        <td colspan="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td noWrap class="airFieldTitle"><font class="airFieldTitle" color="#34208B">�͡�ҡʹ���Թ�鹷ҧ:</font></td>
                        <td width=5>&nbsp;</td>
                        <td noWrap colspan="7" valign="middle" class="airField">
                          <select name="departureDay"  class="smallform">
<% 
    String select = null;
    String dateOption = null;
    for(int i = 1; i <= 31; i++) {
        if (i == today) {
            select = "selected";
        }
        else{
            select = "";
        }
        if (i >= 0 && i <= 9) { dateOption = "0"+i; }
        else { dateOption = ""+i; }
        %>
                            <option value="<%= dateOption %>" <%= select %>><%= i %>
        <%
    }
%>
                          </select>
                          <select name="departureMonth"  class="smallform">
                            <option value="01" <% if (month == 0) out.print("selected"); %>>���Ҥ�</option>
                            <option value="02" <% if (month == 1) out.print("selected"); %>>����Ҿѹ��</option>
                            <option value="03" <% if (month == 2) out.print("selected"); %>>�չҤ�</option>
                            <option value="04" <% if (month == 3) out.print("selected"); %>>����¹</option>
                            <option value="05" <% if (month == 4) out.print("selected"); %>>����Ҥ�</option>
                            <option value="06" <% if (month == 5) out.print("selected"); %>>�Զع�¹</option>
                            <option value="07" <% if (month == 6) out.print("selected"); %>>�á�Ҥ�</option>
                            <option value="08" <% if (month == 7) out.print("selected"); %>>�ԧ�Ҥ�</option>
                            <option value="09" <% if (month == 8) out.print("selected"); %>>�ѹ��¹</option>
                            <option value="10" <% if (month == 9) out.print("selected"); %>>���Ҥ�</option>
                            <option value="11" <% if (month == 10) out.print("selected"); %>>��Ȩԡ�¹</option>
                            <option value="12" <% if (month == 11) out.print("selected"); %>>�ѹ�Ҥ�</option>
                          </select>
                          <select name="departureYear"  class="smallform">
                            <option value="2002" selected>2002
                            <option value="2003">2003
                          </select>
                          <select name="departureTime" class="smallform">
<%
    String timeOption = null;
    for(int i = 0; i <= 23; i++) {
        if (i >= 0 && i <= 9) { timeOption = "0"+i+":00:00"; }
        else { timeOption = i+":00:00"; }
        %>
                            <option value="<%= timeOption %>"><%= timeOption %></option>
        <%
    }
%>
                          </select>
                        </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=5 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=5><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="117"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=22><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="22"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="22"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width="65"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td noWrap class="airFieldTitle"><font class="airFieldTitle" color="#34208B">�͡�ҡʹ���Թ���·ҧ:</font></td>
                        <td width=5>&nbsp;</td>
                        <td colspan="7" class="airField">
                          <select name="returnDay"  class="smallform">
  <% 
    select = null;
    dateOption = null;
    for(int i = 1; i <= 31; i++) {
        if (i == today + 1) {
            select = "selected";
        }
        else{
            select = "";
        }
        if (i >= 0 && i <= 9) { dateOption = "0"+i; }
        else { dateOption = ""+i; }
        %>
                            <option value="<%= dateOption %>" <%= select %>><%= i %>
        <%
    }
%>
                          </select>
                          <select name="returnMonth"  class="smallform">
                            <option value="01" <% if (month == 0) out.print("selected"); %>>���Ҥ�</option>
                            <option value="02" <% if (month == 1) out.print("selected"); %>>����Ҿѹ��</option>
                            <option value="03" <% if (month == 2) out.print("selected"); %>>�չҤ�</option>
                            <option value="04" <% if (month == 3) out.print("selected"); %>>����¹</option>
                            <option value="05" <% if (month == 4) out.print("selected"); %>>����Ҥ�</option>
                            <option value="06" <% if (month == 5) out.print("selected"); %>>�Զع�¹</option>
                            <option value="07" <% if (month == 6) out.print("selected"); %>>�á�Ҥ�</option>
                            <option value="08" <% if (month == 7) out.print("selected"); %>>�ԧ�Ҥ�</option>
                            <option value="09" <% if (month == 8) out.print("selected"); %>>�ѹ��¹</option>
                            <option value="10" <% if (month == 9) out.print("selected"); %>>���Ҥ�</option>
                            <option value="11" <% if (month == 10) out.print("selected"); %>>��Ȩԡ�¹</option>
                            <option value="12" <% if (month == 11) out.print("selected"); %>>�ѹ�Ҥ�</option>
                          </select>
                          <select name="returnYear"  class="smallform">
                            <option value="2002" selected>2002
                            <option value="2003">2003
                          </select>
                          <select name="returnTime" class="smallform">
<%
    timeOption = null;
    for(int i = 0; i <= 23; i++) {
        if (i >= 0 && i <= 9) { timeOption = "0"+i+":00:00"; }
        else { timeOption = i+":00:00"; }
        %>
                            <option value="<%= timeOption %>"><%= timeOption %></option>
        <%
    }
%>
                          </select>
                        </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=8 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=5><img height=3 src="/images/1x1.gif" width=1></td>
                        <td colspan="7"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td colspan="9" class="searchexample"><font
                  color=#888888><b>�����˵�: ��Ҥس��ͧ��õ����Թ�ҧ��������� 
                          ����ͧ�к��ѹ��� ��������Թ�ҧ�ҡʹ���Թ���·ҧ��Ѻ</b></font></td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=5 src="/images/1x1.gif" width=1></td>
                        <td colspan="9" class="searchexample"> <img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                </tbody>
              </table>
              <table border=0 cellpadding=0 cellspacing=0 width=480>
                <tr>
                  <td><img height=6 src="/images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor="#34208B"><img height=1 src="/images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor="#F0F0F0"class=searchinstruct> <font color="#000000"><b>&nbsp;�������ͧ����ǺԹ
                    �����¡�úԹ</b> </font></td>
                </tr>
              </table>
              <table border=0 cellpadding=1 cellspacing=0 width=480>
                <tr>
                  <td bgcolor="#F0F0F0">
                    <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                      <tr>
                        <td width=14><img height=8 src="/images/1x1.gif" width=20></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=20></td>
                      </tr>
                      <tr>
                        <td width=14>&nbsp;</td>
                        <td class="airFieldTitle" align="right">
                          <p><font class="airFieldTitle" color="#34208B"> ���������</font> 
                            <input type="radio" value="O" name="tripType" CHECKED>
                            <br>
                            <font class="airFieldTitle" color="#34208B"> �-��Ѻ</font> 
                            <input type="radio" value="R" name="tripType" >
                          </p>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="airFieldTitle" align="right"> <img height=3 src="/images/1x1.gif" width=50>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="airFieldTitle" align="center"> <font class="airFieldTitle" color="#34208B">
                          �ӹǹ��������</font> <font color="#34208B">
                          <select name="seats" class="smallform">
                            <option value="1" selected >1
                            <option value="2">2
                            <option value="3">3
                            <option value="4">4
                            <option value="5">5
                            <option value="6">6
                          </select>
                          �� </font></td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr>
                        <td colspan=7><img height=5 src="/images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                    <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                      <tr> 
                        <td width=14><img height=1 src="images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=20></td>
                      </tr>
                      <tr> 
                        <td width=14>&nbsp;</td>
                        <td class="airFieldTitle" align="right" width="100"> 
                          <p><font class="airFieldTitle" color="#34208B">��¡�úԹ����ͧ���</font></p>
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="airField" align="left" colspan="3"> 
                          <select name="airline" size="0" class="smallform">
                            <option value="">����к�</option>
                            <%
    Collection allAirlineCollection = airlineService.GetAllAirline();
    Iterator i = allAirlineCollection.iterator();
    while (i.hasNext()) {
        AirlineVO airlineVO = (AirlineVO) i.next();
        %>
                            <option value="<%= airlineVO.getAirlineID() %>"><%= airlineVO.getAirlineName() %></option>
                            <%
    }
%>
                          </select>
                        </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width=14>&nbsp;</td>
                        <td align="right" width="100" class="airFieldTitle"><font color="#34208B">�����������</font></td>
                        <td width=10>&nbsp;</td>
                        <td align="left" colspan="3"> 
                          <select name="class" class="smallform">
                            <option value="E" selected>Economy Class</option>
                            <option value="B">Business Class</option>
                            <option value="F">First Class</option>
                          </select>
                        </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width=14><img height=1 src="images/1x1.gif" width=1></td>
                        <td align="right" width="100"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                        <td align="left" colspan="3"><img height=3 src="/images/1x1.gif" width=1></td>
                        <td width=10><img height=3 src="/images/1x1.gif" width=1></td>
                      </tr>
                      <tr> 
                        <td width=14>&nbsp;</td>
                        <td align="right" width="100">
                          <input type="checkbox" name="window" value="true">
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="infocopy" align="left" colspan="3">��������˹�ҵ�ҧ</td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width=14>&nbsp;</td>
                        <td align="right" width="100">
                          <input type="checkbox" name="smoking" value="true">
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="infocopy" align="left" colspan="3">������ٺ������</td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width=14>&nbsp;</td>
                        <td align="right" width="100"> 
                          <input type="checkbox" name="directFlight" value="true">
                        </td>
                        <td width=10>&nbsp;</td>
                        <td class="infocopy" align="left" colspan="3">����ͧ��õ������ǺԹ</td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width=14>&nbsp;</td>
                        <td width="100">&nbsp;</td>
                        <td width=10>&nbsp;</td>
                        <td class="searchexample" align="left" colspan="3"> <font class="airFieldTitle" color="#888888"> 
                          <b> ������͡������͡��� �Ҩ�����ӹǹ������͡Ŵ����ŧ</b> 
                          </font> </td>
                        <td width=10>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td colspan=7><img height=5 src="/images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr bgcolor="#FEFEFE">
                        <td align="right"><img height=1 src="/images/1x1.gif" width=450></td>
                        <td><img height=1 src="images/1x1.gif" width=1></td>
                      </tr>
                      <tr bgcolor="#FEFEFE">
                        <td align="right">
                          <input type="submit" name="submitted" value="��������ǺԹ" class="blueGoBtn" style="border-bottom:thin solid #000000
      ;border-right:thin solid #000000;border-top:thin solid
      #D7D7D7;border-left:thin solid #D7D7D7;background-color:#34208B;color:#FFFFFF">
      <input type="hidden" name="referringPage" value="airSearchAdv.jsp">
                          &nbsp; </td>
                        <td><img height=1 src="images/1x1.gif" width=1></td>
                      </tr>
                      <tr bgcolor="#FEFEFE">
                        <td align="right"><img height=5 src="/images/1x1.gif" width=3></td>
                        <td><img height=1 src="images/1x1.gif" width=1></td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              <p>&nbsp;
            </form>
          </td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
