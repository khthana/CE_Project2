<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.util.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>:: OLALA AIR :: ��¡��ʹ���Թ</title>
</head>

<body>

    
<table>
  <tr bgcolor="#d0ccd0"> 
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">����ʹ���Թ</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">����ʹ���Թ</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">���ͧ</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">�ѧ��Ѵ / �Ѱ</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">�����</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">�����˵�</font></b></div>
    </td>
  </tr>
  <%
    String bgcolor = null;
    int row = 0;
    AirlineService airlineService = airlineServiceHome.create();
    Collection airlineCollection = airlineService.GetAllAirport();
    Iterator i = airlineCollection.iterator();
    while (i.hasNext()) {
        row++;
        if ((row % 2) == 0) {
            bgcolor = "#f8f8f8";
        }
        else {
            bgcolor = "#fff0d8";
        }
        AirportVO airportVO = (AirportVO) i.next();
        %>
  <tr bgcolor="<%= bgcolor %>"> 
    <td><font face="MS Sans Serif" size="2"><%= airportVO.getAirportID() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= airportVO.getAirportName() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= airportVO.getCity() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= airportVO.getState() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= airportVO.getCountry() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= airportVO.getDescription() %></font></td>
  </tr>
  <%
    }
%>
</table>

<p><a href="javascript:window.close();">&gt;&gt;&gt; �Դ˹�ҵ�ҧ��� &lt;&lt;&lt;</a></p>
</body>
</html>
