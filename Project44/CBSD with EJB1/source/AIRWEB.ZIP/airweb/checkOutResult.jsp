<%@ page contentType="text/html; charset=MS874"%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>

<head>
<!-- #BeginEditable "doctitle" --> 
<title>������鹡�èͧ</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<table width="800" border="0" cellspacing="3" cellpadding="0">
  <tr> 
    <td height="83" colspan="2"> 
      <div align="center"><img src="images/title_index3.gif" width="795" height="88" align="right"></div>
      <div align="center"> </div>
    </td>
  </tr>
  <tr valign="top"> 
    <td width="128"> 
      <table width="100%" border="0">
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>S E R V I C E S</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td><b><font size="-1">+</font><font size="-1">&nbsp;</font><font size="-1"><a href="index.jsp">��������ǺԹ</a><br>
                        +<font color=#003399>&nbsp;</font><a href="listBooking.jsp">��������´��èͧ</a><br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        �׹�ѹ��èͧ<br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        ¡��ԡ��èͧ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>L O G I N</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">���ʴդ�Ѻ �س<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          �͡�ҡ�к� &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font size="-1"><b>Email Address: </b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <b><font size="-1">���ʼ�ҹ: </font></b> 
                            <input type="password" name="password">
                            <br>
                            <input type="submit" name="Submit" value="��ŧ">
                            <input type="reset" name="Submit2" value="¡��ԡ">
                          </p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="22"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1><span class=small><b class="h3color">�س����Ҫԡ�Ѻ��������ѧ?</b><br>
                          �س��ͧ��Ѥ�����Ҫԡ�Ѻ��� ���ͷӡ�èͧ��������� 
                          ��Ҥس�ѧ�������Ѥ���Ҫԡ ����ö��Ѥ� ��<br>
                          <a href="userRegister.jsp">&gt;&gt;&gt; ������Ѻ 
                          &lt;&lt;&lt;</a></span><br>
                          </font></div>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="107"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0" height="76">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"><font face=verdana,arial,helvetica size=-1><b>Your 
                        Shopping Cart</b></font> </td>
                    </tr>
                    <tr> 
                      <td> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><img 
                              height=25 alt="Shopping Cart" 
                              src="images/shopping-cart-small.gif" 
                              width=25 align=left border=0></td>
                            <td valign=top><font size="-1">�س���Թ��ҷ����� 
                              <font class="varhighlight"><%= shoppingCart.size() %></font> 
                              ��� � <a href="cart.jsp">ö�繢ͧ�س</a></font><br>
                            </td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small><b><font size="-1">��ԡ����Ҫԡ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <%
    if (customer == null) {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegister.jsp">��Ѥ���Ҫԡ����</a></font></td>
                    </tr>
                    <%
    }
    else {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegisterEdit.jsp">��䢢����š��ŧ����¹</a></font></td>
                    </tr>
                    <%
    }
%>
                    </tbody> 
                  </table>
                  
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color">������� Olala Transport</span></b><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0> <font size=-1>�س����ö��Ѥ���Ҫԡ 
                          �����Ѻ������èҡ����繻�Ш����Ѻ �Ѻ�ͧ����������<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          �����������ǡѺ��÷�ͧ�����<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          �����������ǡѺ����Թ�ҧ<br>
                          <span class="h3color">E-mail Address �ͧ�س:</span></font><span class="h3color"><font 
                  face=verdana,arial,helvetica size=-1></font></span><font 
                  face=verdana,arial,helvetica size=-1><br>
                          <input maxlength=60 size=15 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=absMiddle value="Sign up" border=0 name="Sign up">
                          <br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="2"> <!-- #BeginEditable "Center" --> 
      <p>&nbsp;</p>
      <table width="90%" border="0" align="center">
        <tr>
          <td>
            <table cellspacing=0 cellpadding=0 width="100%" border=0>
              <tbody> 
              <tr> 
                <td bgcolor=#34208b><img height=20 
            src="search_files/lt_blue_corner.gif" width=18 border=0></td>
                <td class=rateheader align=left width=440 
          background=search_files/dk_blue_bg.gif><font color=#fefefe><b>������鹡�â����Թ</b></font></td>
                <td align=right bgcolor=#34208b><img height=20 
            src="search_files/rt_blue_corner.gif" width=18 
        border=0></td>
              </tr>
              </tbody> 
            </table>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="131"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%" height="100%">
                    <tr> 
                      <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                      <td bgcolor="#F0F0F0" height="1"></td>
                      <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td></td>
                      <td color="#FEFEFE" class="airFieldTitleGray"> 
                        <p>��ê����Թ����Ѻ��èͧ�����Ţ <b><font color="#FF6600">A331133</font></b> 
                          ��������ó�<br>
                          �ͺ�س������ԡ�ä�Ѻ<br>
                          �����ʹء�Ѻ����Թ�ҧ </p>
                        </td>
                      <td></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
