<%@ page contentType="text/html; charset=MS874"%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>

<head>
<!-- #BeginEditable "doctitle" --> 
<title>Check Out</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<table width="800" border="0" cellspacing="3" cellpadding="0">
  <tr> 
    <td height="83" colspan="2"> 
      <div align="center"><img src="images/title_index3.gif" width="795" height="88" align="right"></div>
      <div align="center"> </div>
    </td>
  </tr>
  <tr valign="top"> 
    <td width="128"> 
      <table width="100%" border="0">
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>S E R V I C E S</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td><b><font size="-1">+</font><font size="-1">&nbsp;</font><font size="-1"><a href="index.jsp">��������ǺԹ</a><br>
                        +<font color=#003399>&nbsp;</font><a href="listBooking.jsp">��������´��èͧ</a><br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        �׹�ѹ��èͧ<br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        ¡��ԡ��èͧ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>L O G I N</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">���ʴդ�Ѻ �س<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          �͡�ҡ�к� &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font size="-1"><b>Email Address: </b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <b><font size="-1">���ʼ�ҹ: </font></b> 
                            <input type="password" name="password">
                            <br>
                            <input type="submit" name="Submit" value="��ŧ">
                            <input type="reset" name="Submit2" value="¡��ԡ">
                          </p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="22"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1><span class=small><b class="h3color">�س����Ҫԡ�Ѻ��������ѧ?</b><br>
                          �س��ͧ��Ѥ�����Ҫԡ�Ѻ��� ���ͷӡ�èͧ��������� 
                          ��Ҥس�ѧ�������Ѥ���Ҫԡ ����ö��Ѥ� ��<br>
                          <a href="userRegister.jsp">&gt;&gt;&gt; ������Ѻ 
                          &lt;&lt;&lt;</a></span><br>
                          </font></div>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="107"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0" height="76">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"><font face=verdana,arial,helvetica size=-1><b>Your 
                        Shopping Cart</b></font> </td>
                    </tr>
                    <tr> 
                      <td> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><img 
                              height=25 alt="Shopping Cart" 
                              src="images/shopping-cart-small.gif" 
                              width=25 align=left border=0></td>
                            <td valign=top><font size="-1">�س���Թ��ҷ����� 
                              <font class="varhighlight"><%= shoppingCart.size() %></font> 
                              ��� � <a href="cart.jsp">ö�繢ͧ�س</a></font><br>
                            </td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small><b><font size="-1">��ԡ����Ҫԡ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <%
    if (customer == null) {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegister.jsp">��Ѥ���Ҫԡ����</a></font></td>
                    </tr>
                    <%
    }
    else {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegisterEdit.jsp">��䢢����š��ŧ����¹</a></font></td>
                    </tr>
                    <%
    }
%>
                    </tbody> 
                  </table>
                  
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color">������� Olala Transport</span></b><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0> <font size=-1>�س����ö��Ѥ���Ҫԡ 
                          �����Ѻ������èҡ����繻�Ш����Ѻ �Ѻ�ͧ����������<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          �����������ǡѺ��÷�ͧ�����<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          �����������ǡѺ����Թ�ҧ<br>
                          <span class="h3color">E-mail Address �ͧ�س:</span></font><span class="h3color"><font 
                  face=verdana,arial,helvetica size=-1></font></span><font 
                  face=verdana,arial,helvetica size=-1><br>
                          <input maxlength=60 size=15 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=absMiddle value="Sign up" border=0 name="Sign up">
                          <br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="2"> <!-- #BeginEditable "Center" -->

      <p>&nbsp;</p><table width="90%" border="0" align="center">
        <tr> 
          <td> 
            <table bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
              <tr>
                <td bgcolor="#F0F0F0"> 
                  <table cellspacing=0 cellpadding=0 width="100%" border=0>
                    <tbody> 
                    <tr> 
                      <td bgcolor=#34208b><img height=20 
            src="search_files/lt_blue_corner.gif" width=18 border=0></td>
                      <td class=rateheader align=left width=440 
          background=search_files/dk_blue_bg.gif><font color=#fefefe><b>�׹�ѹ��èͧ</b></font></td>
                      <td align=right bgcolor=#34208b><img height=20 
            src="search_files/rt_blue_corner.gif" width=18 
        border=0></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table border=0 cellpadding=1 cellspacing=0 width=100%>
                    <tr> 
                      <td bgcolor="#F0F0F0" height="131"> 
                        <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                          <tr> 
                            <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                            <td colspan="2" bgcolor="#F0F0F0" height="1"></td>
                            <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                          </tr>
                          <tr> 
                            <td></td>
                            <td width="230" color="#FEFEFE" class="airFieldTitleGray"><font color="#888888"><b>��¡�� 
                              #<%= itemNo %></b></font></td>
                            <td width="230" bgcolor="#FEFEFE"></td>
                            <td></td>
                          </tr>
                        </table>
                        <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                          <!-- begin date/header info //-->
                          <tr bgcolor=#FEFEFE> 
                            <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td added bgcolor to tr for displaying the table row></td>
                            <td added bgcolor to tr for displaying the table row> 
                              <p><img height=3 src="images/1x1.gif" width=1></p>
                            </td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                          </tr>
                          <tr bgcolor=#FEFEFE> 
                            <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td added bgcolor to tr for displaying the table row></td>
                            <td added bgcolor to tr for displaying the table row> 
                              <p><img height=3 src="images/1x1.gif" width=1></p>
                            </td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                          </tr>
                          <tr bgcolor=#FEFEFE> 
                            <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                            <td noWrap><img height=1 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                            <td class="airsearchexample3" align="center"><font color="#888888"><b>AIRPORT</b></font></td>
                            <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                            <td class="airsearchexample3" align="center"><font color="#888888"><b>CLASS</b></font></td>
                            <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                            <td NOWRAP class="airsearchexample2" align="center"><b> 
                              <font color=#888888>ARRIVE</font></b></td>
                            <td width=10></td>
                            <td class="airsearchexample2" align="center"><b> <font color=#888888>DEPART</font></b></td>
                            <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                            <td class="airsearchexample2" align="center"><b> <font color="#888888">����ǺԹ 
                              #</font></b><font color="#888888"></font></td>
                            <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                          </tr>
                          <tr> 
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                          </tr>
                          <tr> 
                            <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                            <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                            <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                          </tr>
                          <tr> 
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                          </tr>
                          <!-- end  date/header info //-->
                          <tr bgcolor=#FEFEFE> 
                            <td width=10></td>
                            <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                            <td width=10></td>
                            <td nowrap class="infocopy"><%= airportSrcName %> 
                              (<%= airportSrcID %>)</td>
                            <td width=10></td>
                            <td nowrap class="infocopy"><a href="classInfo.jsp?classID=<%= classID %>" target="_blank"><%= classID %></a></td>
                            <td width=10></td>
                            <td width=10></td>
                            <td width=10></td>
                            <td nowrap class="infocopy"> <b><%= DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(departDateTime) %></b></td>
                            <td width=10></td>
                            <td nowrap class="infocopy"><a href="flightInfo.jsp?flightID=<%= flightID %>" target="_blank"><%= flightID %></a></td>
                            <td width=10></td>
                          </tr>
                          <tr bgcolor=#FEFEFE> 
                            <td width=10></td>
                            <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                            <td width=10></td>
                            <td class="infocopy"><%= airportDesName %> (<%= airportDesID %>)</td>
                            <td width=10></td>
                            <td width=10></td>
                            <td nowrap class="infocopy"></td>
                            <td nowrap class="infocopy"> <b><%= DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(arriveDateTime) %></b></td>
                            <td width=10></td>
                            <td nowrap class="infocopy"> </td>
                            <td width=10></td>
                            <td nowrap class="infocopy"> </td>
                            <td width=10></td>
                          </tr>
                        </table>
                        <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                          <tr> 
                            <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                            <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                          </tr>
                          <tr> 
                            <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                            <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                          </tr>
                          <tr> 
                            <td width=10></td>
                            <td width="230" align="right"><a href="listTraveller.jsp?bookingID=<%= bookingID %>&itemNo=<%= itemNo %>" target="_blank">&gt;&gt;&gt; 
                              ��������´����Թ�ҧ &lt;&lt;&lt;</a></td>
                            <td width="230" bgcolor="#FEFEFE" align="right"> 
                              <table width="230" border="0" cellspacing="0" cellpadding="1">
                                <tr> 
                                  <td bgcolor="#34208B"> 
                                    <table width="231" border="0" cellspacing="0" cellpadding="2">
                                      <tr> 
                                        <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���� 
                                          <%= seats * price %> �ҷ ����Ѻ <%= seats %> 
                                          �����</font></td>
                                      </tr>
                                    </table>
                                  </td>
                                </tr>
                              </table>
                            </td>
                            <td width=10></td>
                          </tr>
                          <tr> 
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                            <td colspan="2"><img height=7 src="images/1x1.gif" width=1></td>
                            <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                          </tr>
                          <tr> 
                            <td width=10></td>
                            <td width="230"><b> </b> </td>
                            <td width="230" bgcolor="#FEFEFE" align="right"> </td>
                            <td width=10></td>
                          </tr>
                          <tr> 
                            <td width=10 height="2"><img height=10 src="images/1x1.gif" width=10></td>
                            <td colspan="2" height="2"><img height=3 src="images/1x1.gif" width=1></td>
                            <td width=10 colspan="2" height="2"><img height=3 src="images/1x1.gif" width=10></td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>

</tr>
</table>		

            <p>&nbsp;</p>
            <table width="230" align="right" border="0" cellspacing="0" cellpadding="1">
              <tr> 
                <td bgcolor="#34208B"> 
                  <table width="231" border="0" cellspacing="0" cellpadding="2" align="right">
                    <tr> 
                      <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���������� 
                        51,576.00 �ҷ ����Ѻ </font> <font color="#34208B"> 1 
                        �����</font></td>
                    </tr>
                  </table>
              </tr>
            </table>

			<p>&nbsp;</p>
            <p>&nbsp;</p>
            <form name="form2" method="post" action="checkOutResult.htm">
              <table border="0" width="500" cellspacing="0" cellpadding="2">
                <tr bgcolor="#34208B"> 
                  <td colspan="3"> <b><font color="#FFFFFF">�����š�ê����Թ</font></b></td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td colspan="2" bgcolor="#F0F0F0"> <font size="-1"><img src="images/rtri.gif" width="10"
        height="10" align="BOTTOM" border="0" naturalsizeflag="3"> �����źѧ�Ѻ 
                    <img src="images/btri.gif" width="10" height="10" align="BOTTOM"
        border="0" naturalsizeflag="3"> ���������ѧ�Ѻ<br>
                    <i>������з����������㹡�èѴ���Թ �е�ͧ�ç�Ѻ�����Ţͧ�ѵ��ôԵ���س��㹡�ê����Թ</i></font></td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">Email Address: 
                    <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input type="text" name="email" value="" size=35>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">�׹�ѹ Email 
                    Address</font><font size="-1" face="Arial,Helvetica">: <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input type="text" name="email2" value="" size=35>
                  </td>
                </tr>
                <input type="hidden" name="email2" value="">
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">����</font><font size="-1">: 
                    <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input type="text" name="firstName" value="" size=35>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">���ʡ��</font><font size="-1">: 
                    <img src="images/rtri.gif" width="10"
        height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input type="text" name="lastName" value="" size=35>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> &nbsp;<font size="-1">�������</font><font size="-1">: 
                    <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input name="address1" type="text" value="" size=35>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> &nbsp;<font size="-1">����� / 
                    ࢵ / �ѧ��Ѵ</font><font size="-1">: <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input name="city" type="text" value="" size=35>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td valign=top width="28%" align="RIGHT" NOWRAP> <font size="-1">�Ѱ:</font> 
                    <font face="Arial,Helvetica size=-1"><img src="images/rtri.gif" width="10" height="10"></font> 
                  </td>
                  <td width="54%" NOWRAP> 
                    <select name="stateProvince" size="1">
                      <option value="00" selected>Select if Appropriate 
                      <option value="AL">Alabama 
                      <option value="AK">Alaska 
                      <option value="AS">American Samoa 
                      <option value="AZ">Arizona 
                      <option value="AR">Arkansas 
                      <option value="AE">Armed Forces 
                      <option value="AA">Armed Forces Americas 
                      <option value="AP">Armed Forces Pacific 
                      <option value="CA">California 
                      <option value="CO">Colorado 
                      <option value="CT">Connecticut 
                      <option value="DE">Delaware 
                      <option value="DC">District of Columbia 
                      <option value="FM">Federated States of Micronesia 
                      <option value="FL">Florida 
                      <option value="GA">Georgia 
                      <option value="GU">Guam 
                      <option value="HI">Hawaii 
                      <option value="ID">Idaho 
                      <option value="IL">Illinois 
                      <option value="IN">Indiana 
                      <option value="IA">Iowa 
                      <option value="KS">Kansas 
                      <option value="KY">Kentucky 
                      <option value="LA">Louisiana 
                      <option value="ME">Maine 
                      <option value="MH">Marshall Islands 
                      <option value="MD">Maryland 
                      <option value="MA">Massachusetts 
                      <option value="MI">Michigan 
                      <option value="MN">Minnesota 
                      <option value="MS">Mississippi 
                      <option value="MO">Missouri 
                      <option value="MT">Montana 
                      <option value="NE">Nebraska 
                      <option value="NV">Nevada 
                      <option value="NH">New Hampshire 
                      <option value="NJ">New Jersey 
                      <option value="NM">New Mexico 
                      <option value="NY">New York 
                      <option value="NC">North Carolina 
                      <option value="ND">North Dakota 
                      <option value="MP">Northern Mariana Islands 
                      <option value="OH">Ohio 
                      <option value="OK">Oklahoma 
                      <option value="OR">Oregon 
                      <option value="PW">Palau 
                      <option value="PA">Pennsylvania 
                      <option value="PR">Puerto Rico 
                      <option value="RI">Rhode Island 
                      <option value="SC">South Carolina 
                      <option value="SD">South Dakota 
                      <option value="TN">Tennessee 
                      <option value="TX">Texas 
                      <option value="UT">Utah 
                      <option value="VT">Vermont 
                      <option value="VI">Virgin Islands 
                      <option value="VA">Virginia 
                      <option value="WA">Washington 
                      <option value="WV">West Virginia 
                      <option value="WI">Wisconsin 
                      <option value="WY">Wyoming 
                      <option value="  "> 
                      <option value="AB">Alberta 
                      <option value="BC">British Columbia 
                      <option value="MB">Manitoba 
                      <option value="NB">New Brunswick 
                      <option value="NF">Newfoundland 
                      <option value="NT">Northwest Territory 
                      <option value="NS">Nova Scotia 
                      <option value="ON">Ontario 
                      <option value="PE">Prince Edward Island 
                      <option value="PQ">Quebec 
                      <option value="SP">St. Pierre & Miguelon 
                      <option value="SK">Saskatchewan 
                      <option value="YU">Yukon 
                      <option value="  "> 
                      <option value="AC">Australian 
                      <option value="NW">New South Wales 
                      <option value="NO">Northern Territory 
                      <option value="QL">Queensland 
                      <option value="SA">South Australia 
                      <option value="TS">Tasmania 
                      <option value="VC">Victoria 
                      <option value="WT">Western Australia 
                    </select>
                    <br>
                    <font size="-2">* ੾�л�������Ѱ����ԡ�, ᤹Ҵ�, ��������������ҹ��</font></td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp;</td>
                  <td width=28% nowrap align=right> <font size="-1">������ɳ���</font><font size="-1" face="Arial,Helvetica">: 
                    </font><img src="images/rtri.gif" width="10" height="10"></td>
                  <td nowrap width="54%"> 
                    <input name="postalCode" type="text" value="" size=7 maxlength=10>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp;</td>
                  <td width="28%" align="RIGHT"> &nbsp;<font size="-1">�����</font><font size="-1">: 
                    <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font> 
                  </td>
                  <td width="54%"> 
                    <select name="country">
                      <option value="AF">Afghanistan 
                      <option value="AL">Albania 
                      <option value="DZ">Algeria 
                      <option value="AS">American Samoa 
                      <option value="AD">Andorra 
                      <option value="AO">Angola 
                      <option value="AI">Anguilla 
                      <option value="AQ">Antarctica 
                      <option value="AG">Antigua And Barbuda 
                      <option value="AR">Argentina 
                      <option value="AM">Armenia 
                      <option value="AW">Aruba 
                      <option value="AU">Australia 
                      <option value="AT">Austria 
                      <option value="AZ">Azerbaijan 
                      <option value="BS">Bahamas 
                      <option value="BH">Bahrain 
                      <option value="BD">Bangladesh 
                      <option value="BB">Barbados 
                      <option value="BY">Belarus 
                      <option value="BE">Belgium 
                      <option value="BZ">Belize 
                      <option value="BJ">Benin 
                      <option value="BM">Bermuda 
                      <option value="BT">Bhutan 
                      <option value="BO">Bolivia 
                      <option value="BA">Bosnia And Herzegovinia 
                      <option value="BW">Botswana 
                      <option value="BV">Bouvet Island 
                      <option value="BR">Brazil 
                      <option value="IO">British Indian Ocean Territory 
                      <option value="BN">Brunei Darussalam 
                      <option value="BG">Bulgaria 
                      <option value="BF">Burkina Faso 
                      <option value="BI">Burundi 
                      <option value="KH">Cambodia 
                      <option value="CM">Cameroon 
                      <option value="CA">Canada 
                      <option value="CV">Cape Verde 
                      <option value="KY">Cayman Islands 
                      <option value="CF">Central African Republic 
                      <option value="TD">Chad 
                      <option value="CL">Chile 
                      <option value="CN">China 
                      <option value="CX">Christmas Island 
                      <option value="CC">Cocos (Keeling) Islands 
                      <option value="CO">Colombia 
                      <option value="KM">Comoros 
                      <option value="CG">Congo 
                      <option value="CD">Congo, DR Of The 
                      <option value="CK">Cook Islands 
                      <option value="CR">Costa Rica 
                      <option value="CI">Cote D'ivoire 
                      <option value="HR">Croatia 
                      <option value="CU">Cuba 
                      <option value="CY">Cyprus 
                      <option value="CZ">Czech Republic 
                      <option value="DK">Denmark 
                      <option value="DJ">Djibouti 
                      <option value="DM">Dominica 
                      <option value="DO">Dominican Republic 
                      <option value="TP">East Timor 
                      <option value="EC">Ecuador 
                      <option value="EG">Egypt 
                      <option value="SV">El Salvador 
                      <option value="GQ">Equatorial Guinea 
                      <option value="ER">Eritrea 
                      <option value="EE">Estonia 
                      <option value="ET">Ethiopia 
                      <option value="FK">Falkland Islands 
                      <option value="FO">Faroe Islands 
                      <option value="FJ">Fiji 
                      <option value="FI">Finland 
                      <option value="FR">France 
                      <option value="FX">France, Metropolitan 
                      <option value="GF">French Guiana 
                      <option value="PF">French Polynesia 
                      <option value="TF">French Southern Territories 
                      <option value="GA">Gabon 
                      <option value="GM">Gambia 
                      <option value="GE">Georgia 
                      <option value="DE">Germany 
                      <option value="GH">Ghana 
                      <option value="GI">Gibraltar 
                      <option value="GR">Greece 
                      <option value="GL">Greenland 
                      <option value="GD">Grenada 
                      <option value="GP">Guadeloupe 
                      <option value="GU">Guam 
                      <option value="GT">Guatemala 
                      <option value="GN">Guinea 
                      <option value="GW">Guinea-Bissau 
                      <option value="GY">Guyana 
                      <option value="HT">Haiti 
                      <option value="HM">Heard And Mcdonald Islands 
                      <option value="HN">Honduras 
                      <option value="HK">Hong Kong 
                      <option value="HU">Hungary 
                      <option value="IS">Iceland 
                      <option value="IN">India 
                      <option value="ID">Indonesia 
                      <option value="IR">Iran 
                      <option value="IQ">Iraq 
                      <option value="IE">Ireland 
                      <option value="IL">Israel 
                      <option value="IT">Italy 
                      <option value="JM">Jamaica 
                      <option value="JP">Japan 
                      <option value="JO">Jordan 
                      <option value="KZ">Kazakhstan 
                      <option value="KE">Kenya 
                      <option value="KI">Kiribati 
                      <option value="KP">Korea, DPR Of 
                      <option value="KR">Korea, Republic Of 
                      <option value="KW">Kuwait 
                      <option value="KG">Kyrgyzstan 
                      <option value="LA">Laos 
                      <option value="LV">Latvia 
                      <option value="LB">Lebanon 
                      <option value="LS">Lesotho 
                      <option value="LR">Liberia 
                      <option value="LY">Libyan Arab Jamahiriya 
                      <option value="LI">Liechtenstein 
                      <option value="LT">Lithuania 
                      <option value="LU">Luxembourg 
                      <option value="MO">Macau 
                      <option value="MK">Macedonia, FYR Of 
                      <option value="MG">Madagascar 
                      <option value="MW">Malawi 
                      <option value="MY">Malaysia 
                      <option value="MV">Maldives 
                      <option value="ML">Mali 
                      <option value="MT">Malta 
                      <option value="MH">Marshall Islands 
                      <option value="MQ">Martinique 
                      <option value="MR">Mauritania 
                      <option value="MU">Mauritius 
                      <option value="YT">Mayotte 
                      <option value="MX">Mexico 
                      <option value="FM">Micronesia, FS Of 
                      <option value="MD">Moldova, Republic Of 
                      <option value="MC">Monaco 
                      <option value="MN">Mongolia 
                      <option value="MS">Montserrat 
                      <option value="MA">Morocco 
                      <option value="MZ">Mozambique 
                      <option value="MM">Myanmar 
                      <option value="NA">Namibia 
                      <option value="NR">Nauru 
                      <option value="NP">Nepal 
                      <option value="NL">Netherlands 
                      <option value="AN">Netherlands Antilles 
                      <option value="NC">New Caledonia 
                      <option value="NZ">New Zealand 
                      <option value="NI">Nicaragua 
                      <option value="NE">Niger 
                      <option value="NG">Nigeria 
                      <option value="NU">Niue 
                      <option value="NF">Norfolk Island 
                      <option value="MP">Northern Mariana Islands 
                      <option value="NO">Norway 
                      <option value="OM">Oman 
                      <option value="PK">Pakistan 
                      <option value="PW">Palau 
                      <option value="PA">Panama 
                      <option value="PG">Papua New Guinea 
                      <option value="PY">Paraguay 
                      <option value="PE">Peru 
                      <option value="PH">Philippines 
                      <option value="PN">Pitcairn 
                      <option value="PL">Poland 
                      <option value="PT">Portugal 
                      <option value="PR">Puerto Rico 
                      <option value="QA">Qatar 
                      <option value="RE">Reunion 
                      <option value="RO">Romania 
                      <option value="RU">Russian Federation 
                      <option value="RW">Rwanda 
                      <option value="KN">Saint Kitts And Nevis 
                      <option value="LC">Saint Lucia 
                      <option value="WS">Samoa 
                      <option value="SM">San Marino 
                      <option value="ST">Sao Tome And Principe 
                      <option value="SA">Saudi Arabia 
                      <option value="SN">Senegal 
                      <option value="SC">Seychelles 
                      <option value="SL">Sierra Leone 
                      <option value="SG">Singapore 
                      <option value="SK">Slovakia (Slovak Republic) 
                      <option value="SI">Slovenia 
                      <option value="SB">Solomon Islands 
                      <option value="SO">Somalia 
                      <option value="ZA">South Africa 
                      <option value="GS">South Georgia 
                      <option value="ES">Spain 
                      <option value="LK">Sri Lanka 
                      <option value="VC">St Vincent And The Grenadines 
                      <option value="SH">St. Helena 
                      <option value="PM">St. Pierre And Miquelon 
                      <option value="SD">Sudan 
                      <option value="SR">Suriname 
                      <option value="SJ">Svalbard And Jan Mayen Islands 
                      <option value="SZ">Swaziland 
                      <option value="SE">Sweden 
                      <option value="CH">Switzerland 
                      <option value="SY">Syrian Arab Republic 
                      <option value="TW">Taiwan 
                      <option value="TJ">Tajikistan 
                      <option value="TZ">Tanzania 
                      <option value="TH" selected>Thailand 
                      <option value="TG">Togo 
                      <option value="TK">Tokelau 
                      <option value="TO">Tonga 
                      <option value="TT">Trinidad And Tobago 
                      <option value="TN">Tunisia 
                      <option value="TR">Turkey 
                      <option value="TM">Turkmenistan 
                      <option value="TC">Turks And Caicos Islands 
                      <option value="TV">Tuvalu 
                      <option value="UG">Uganda 
                      <option value="UA">Ukraine 
                      <option value="AE">United Arab Emirates 
                      <option value="GB">United Kingdom 
                      <option value="US" >United States 
                      <option value="UY">Uruguay 
                      <option value="UM">US Minor Outlying Islands 
                      <option value="UZ">Uzbekistan 
                      <option value="VU">Vanuatu 
                      <option value="VA">Vatican City State 
                      <option value="VE">Venezuela 
                      <option value="VN">Viet Nam 
                      <option value="VG">Virgin Islands - British 
                      <option value="VI">Virgin Islands - U.S. 
                      <option value="WF">Wallis And Futuna Islands 
                      <option value="EH">Western Sahara 
                      <option value="YE">Yemen 
                      <option value="YU">Yugoslavia 
                      <option value="ZM">Zambia 
                      <option value="ZW">Zimbabwe 
                    </select>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> &nbsp;<font size="-1">�����Ţ���Ѿ�� 
                    (��ҹ) : <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input name="homePhone" type="text" value="" size=25>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">�����Ţ���Ѿ�� 
                    (���ӧҹ) </font><font size="-1">: <img src="images/rtri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input name="workPhone" type="text" value="" size=15>
                    <font size="-1">���</font> <font size="-1">.<img src="images/btri.gif" width="10" height="10" align="BOTTOM"
        border="0" naturalsizeflag="3"></font> 
                    <input name="extension" type="text"
                value="" size=3>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">ῡ��</font><font size="-1">: 
                    <img src="images/btri.gif" width="10"
        height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input name="faxPhone" type="text" value="" size=35>
                  </td>
                </tr>
                <tr> 
                  <td width="18%">&nbsp; </td>
                  <td width="28%" align="RIGHT"> <font size="-1">���ͺ���ѷ</font><font size="-1">: 
                    <img src="images/btri.gif"
        width="10" height="10" align="BOTTOM" border="0" naturalsizeflag="3"></font></td>
                  <td width="54%"> 
                    <input type="text" name="company" value="" size=35>
                  </td>
                </tr>
                <!--
<TR><TD COLSPAN=2>
<B><FONT FACE="Arial">
International Airfare:</FONT></B>
<IMG SRC="pingreen.gif" WIDTH=20 HEIGHT=16>
<BR>
If you are travelling abroad, check below for an email quote for
discounted International Airfare.  Please include a quote to beat.<br>
<INPUT TYPE=CHECKBOX NAME="consolidator"> Send an airfare quote<br>
Quote to beat <INPUT TYPE=TEXT SIZE=10 NAME="quote">
</TD></TR>
-->
              </table>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <table border="0" width="500" cellspacing="0" cellpadding="2">
                <tr> 
                  <td colspan="3" bgcolor="#34208B"> <b><font color="#FFFFFF">�����źѵ��ôԵ</font></b></td>
                </tr>
                <tr> 
                  <td width="17%">&nbsp; </td>
                  <td colspan="2" bgcolor="#F0F0F0" width="83%"> <font size="-1">�س��ͧ�кآ����źѵ��ôԵ�ͧ�س㹡�èͧ��������� 
                    ������������Ѻ�����Ź�� ��Ҩзӡ�èͧ������������س�����</font> 
                    <p><font size="-1"> �����Ţͧ�ѵ��ôԵ �ж١�����ż�����Ѻ������з���·��س�к������ǹ�ͧ�����š�ê����Թ 
                      ���º��º�Ѻ�����Ũҡ����͡�ѵ�</font> 
                    <p><font size="-1">�ô��Ǩ�ͺ��� ������з�������ҹ�� �ç�Ѻ�����źѵ��ôԵ���س��㹡�ê����Թ</font> 
                    <p><font size="-1"> ��Ҥس�������Թ�����������ҷ���˹� 
                      ��èͧ�ͧ�س�ж١¡��ԡ���ѵ��ѵ� </font> 
                  </td>
                </tr>
                <tr> 
                  <td width="17%">&nbsp; </td>
                  <td width="29%" align="RIGHT"> �������ѵ��ôԵ: <img src="images/rtri.gif" width="10" height="10"> 
                  </td>
                  <td width="54%" NOWRAP> 
                    <select name="creditCardType">
                      <option value="CA">MASTER CARD 
                      <option value="AX">AMERICAN EXPRESS 
                      <option value="CB">CARTE BLANCHE 
                      <option value="DC">DINERS CLUB 
                      <option value="DS">DISCOVER 
                      <option value="JC">JAPAN CREDIT BUREAU 
                      <option value="VI">VISA 
                    </select>
                  </td>
                </tr>
                <tr> 
                  <td width="17%">&nbsp; </td>
                  <td width="29%" align="RIGHT"> �����Ţ�ѵ��ôԵ: <img src="images/rtri.gif" width="10" height="10"> 
                  </td>
                  <td width="54%"> 
                    <input name="creditCardNumber" type="text" value="" size=20 maxlength="20">
                  </td>
                </tr>
                <tr> 
                  <td width="17%">&nbsp; </td>
                  <td width="29%" align="RIGHT"> �ѹ�������: <img src="images/rtri.gif" width="10" height="10"> 
                  </td>
                  <td width="54%"> 
                    <select name="creditCardExpirationMonth">
                      <option>01 
                      <option>02 
                      <option>03 
                      <option>04 
                      <option>05 
                      <option>06 
                      <option>07 
                      <option>08 
                      <option>09 
                      <option>10 
                      <option>11 
                      <option>12 
                    </select>
                    <select name="creditCardExpirationYear">
                      <option>2001 
                      <option>2002 
                      <option>2003 
                      <option>2004 
                      <option>2005 
                      <option>2006 
                      <option>2007 
                      <option>2008 
                      <option>2009 
                      <option>2010 
                      <option>2011 
                    </select>
                  </td>
                </tr>
                <tr> 
                  <td width="17%">&nbsp;</td>
                  <td align="CENTER">�س�ж١�Ѵ���Թ�繨ӹǹ:</td>
                  <td align="CENTER">
                    <div align="left"><b>&nbsp;<font color="#FF6600">51,576.00</font> 
                      �ҷ</b></div>
                  </td>
                </tr>
                <tr> 
                  <td width="17%">&nbsp; </td>
                  <td align="CENTER" colspan=2> <font size="2"><b>���ͼ���ͺѵ��ôԵ 
                    �е�ͧ�ç�Ѻ���ͷ���к�㹢����š�èѴ���Թ</b></font></td>
                </tr>
              </table>
              <p>&nbsp;</p>
              <p align="center"><font color="#FF0000"><b>��سҵ�Ǩ�ͺ���������١��ͧ��Фú��ǹ 
                ��͹��ԡ Submit</b></font><br>
                <input type="submit" name="Submit3" value="Submit">
                <input type="reset" name="Submit4" value="Reset">
              </p>
            </form>
            </td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
