<%@ page import = "java.sql.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.sql.*" %>
<%@ page import = "javax.ejb.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private DataSource dataSource;
    private Connection conn = null;
    public void jspInit() {
        try {
            Context ctx = new InitialContext();
            dataSource = (DataSource) ctx.lookup("java:comp/env/jdbc/DataSource");
            conn = dataSource.getConnection();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>:: OLALA AIR :: listCustomer</title>
</head>

<body>
<h1>Show All Customer </h1>
<table width="90%" border="1">
  <tr>
    <td>
      <div align="center">CustomerID</div>
    </td>
    <td>
      <div align="center">firstName</div>
    </td>
    <td>
      <div align="center">lastName</div>
    </td>
    <td>
      <div align="center">Gender</div>
    </td>
    <td>
      <div align="center">Address</div>
    </td>
    <td>
      <div align="center">Telephone</div>
    </td>
    <td>
      <div align="center">emailAddress</div>
    </td>
    <td>
      <div align="center">Password</div>
    </td>
    <td>
      <div align="center">Agency</div>
    </td>
  </tr>

<%
    PreparedStatement pstmt = null;
    try {
      pstmt = conn.prepareStatement("SELECT * FROM Customer");
      ResultSet rs = pstmt.executeQuery();
      while(rs.next()) {

          %>

  <tr>
    <td><%= rs.getString("customerID") %></td>
    <td><%= CharsetConverter.MS874ToUnicode(new String(rs.getString("firstName"))) %></td>
    <td><%= rs.getString("lastName") %></td>
    <td><%= rs.getString("gender") %></td>
    <td><%= rs.getString("address") %></td>
    <td><%= rs.getString("telephone") %></td>
    <td><%= rs.getString("emailAddress") %></td>
    <td><%= rs.getString("password") %></td>
    <td><%= rs.getBoolean("agency") %></td>
  </tr>

        <%
        }
    }
    catch (Exception e) {
        e.printStackTrace();
    }
%>
</table>
</body>
</html>
