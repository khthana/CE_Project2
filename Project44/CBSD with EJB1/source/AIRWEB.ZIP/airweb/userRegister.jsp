<%@ page import = "java.sql.*" %>
<%@ page import = "java.io.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private CustomerServiceHome customerServiceHome = null;
    	
	public void jspInit() {
    	    try {
         	 	//get naming context
          		Context ctx = new InitialContext();

          		//look up jndi name
          		Object ref = ctx.lookup("java:comp/env/ejb/CustomerService");

      	    	//cast to Home interface
          		customerServiceHome = (CustomerServiceHome) PortableRemoteObject.narrow(ref, CustomerServiceHome.class);
    		}
        	catch(Exception e) {
    			System.out.println("Cannot locate component!!");
	    		e.printStackTrace();
        	}
	}
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>

<head>
<!-- #BeginEditable "doctitle" -->
<title>:: OLALA AIR :: ŧ����¹��Ҫԡ����</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<table width="800" border="0" cellspacing="3" cellpadding="0">
  <tr> 
    <td height="83" colspan="2"> 
      <div align="center"><img src="images/title_index3.gif" width="795" height="88" align="right"></div>
      <div align="center"> </div>
    </td>
  </tr>
  <tr valign="top"> 
    <td width="128"> 
      <table width="100%" border="0">
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>S E R V I C E S</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td><b><font size="-1">+</font><font size="-1">&nbsp;</font><font size="-1"><a href="index.jsp">��������ǺԹ</a><br>
                        +<font color=#003399>&nbsp;</font><a href="listBooking.jsp">��������´��èͧ</a><br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        �׹�ѹ��èͧ<br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        ¡��ԡ��èͧ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>L O G I N</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">���ʴդ�Ѻ �س<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          �͡�ҡ�к� &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font size="-1"><b>Email Address: </b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <b><font size="-1">���ʼ�ҹ: </font></b> 
                            <input type="password" name="password">
                            <br>
                            <input type="submit" name="Submit" value="��ŧ">
                            <input type="reset" name="Submit2" value="¡��ԡ">
                          </p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="22"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1><span class=small><b class="h3color">�س����Ҫԡ�Ѻ��������ѧ?</b><br>
                          �س��ͧ��Ѥ�����Ҫԡ�Ѻ��� ���ͷӡ�èͧ��������� 
                          ��Ҥس�ѧ�������Ѥ���Ҫԡ ����ö��Ѥ� ��<br>
                          <a href="userRegister.jsp">&gt;&gt;&gt; ������Ѻ 
                          &lt;&lt;&lt;</a></span><br>
                          </font></div>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="107"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0" height="76">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"><font face=verdana,arial,helvetica size=-1><b>Your 
                        Shopping Cart</b></font> </td>
                    </tr>
                    <tr> 
                      <td> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><img 
                              height=25 alt="Shopping Cart" 
                              src="images/shopping-cart-small.gif" 
                              width=25 align=left border=0></td>
                            <td valign=top><font size="-1">�س���Թ��ҷ����� 
                              <font class="varhighlight"><%= shoppingCart.size() %></font> 
                              ��� � <a href="cart.jsp">ö�繢ͧ�س</a></font><br>
                            </td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small><b><font size="-1">��ԡ����Ҫԡ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <%
    if (customer == null) {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegister.jsp">��Ѥ���Ҫԡ����</a></font></td>
                    </tr>
                    <%
    }
    else {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegisterEdit.jsp">��䢢����š��ŧ����¹</a></font></td>
                    </tr>
                    <%
    }
%>
                    </tbody> 
                  </table>
                  
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color">������� Olala Transport</span></b><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0> <font size=-1>�س����ö��Ѥ���Ҫԡ 
                          �����Ѻ������èҡ����繻�Ш����Ѻ �Ѻ�ͧ����������<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          �����������ǡѺ��÷�ͧ�����<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          �����������ǡѺ����Թ�ҧ<br>
                          <span class="h3color">E-mail Address �ͧ�س:</span></font><span class="h3color"><font 
                  face=verdana,arial,helvetica size=-1></font></span><font 
                  face=verdana,arial,helvetica size=-1><br>
                          <input maxlength=60 size=15 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=absMiddle value="Sign up" border=0 name="Sign up">
                          <br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="2"> <!-- #BeginEditable "Center" -->
      <table width="480" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr>
          <td>

<%
	// ��Ǩ�ͺ����ա�� Submit Form �������
	String submit = request.getParameter("submitted");

    // 㹡óշ���ա�� Submit Form
	if (submit != null) {
/*
		String firstName = CharsetConverter.UnicodeToMS874(new String(request.getParameter("firstName")));
		String lastName = CharsetConverter.UnicodeToMS874(new String(request.getParameter("lastName")));
		String gender = CharsetConverter.UnicodeToMS874(new String(request.getParameter("sex")));
		String address = CharsetConverter.UnicodeToMS874(new String(request.getParameter("address")));
		String telephone = CharsetConverter.UnicodeToMS874(new String(request.getParameter("telephone")));
		String emailAddress = CharsetConverter.UnicodeToMS874(new String(request.getParameter("email")));
		String password = CharsetConverter.UnicodeToMS874(new String(request.getParameter("password")));
		String password2 = CharsetConverter.UnicodeToMS874(new String(request.getParameter("password2")));
*/
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String gender = request.getParameter("sex");
		String address = request.getParameter("address");
		String telephone = request.getParameter("telephone");
		String emailAddress = request.getParameter("email");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");

		if ((firstName.equals("")) || (lastName.equals("")) || (gender.equals("")) || (address.equals(""))
                || (telephone.equals("")) || (emailAddress.equals("")) || (password.equals("")) || (password2.equals("")))
        {
            out.println("<br><font class=\"errormsg\">��سҡ�͡���������ú��ǹ���¤�Ѻ</font>");
        }

        else if (!password.equals(password2)) {
            out.println("<br><font class=\"errormsg\">���ʼ�ҹ����ͧ�������ç�ѹ</font>");
        }

        else
        {
		    CustomerService cs = customerServiceHome.create();
    		try {
		    	cs.AddCustomer(firstName, lastName, gender,
	    			address, telephone, emailAddress, password, false);
    			%>
				    	<br>
			    		���ŧ����¹�������º����<BR>
		    			�س����ö Login ��ҡ���ٷҧ��ҹ������ͤ�Ѻ
	    		<%
	      String customerID = cs.Login(emailAddress, password);

    		}
			catch(DuplicateEmailException dee) {
				out.println("<br><font class=\"errormsg\">Email Address �����������к����Ǥ�Ѻ</font>");
			}
	    	catch (Exception e) {
    			out.println("Caught unexpected exception in addCustomer");
	    		e.printStackTrace();
    		}

        }
	} // if (submit)

%>
		<br>
            <form name=AvailRequester action="" method="POST">
              <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#34208b><img height=20
            src="images/lt_blue_corner.gif" width=18 border=0></td>
                  <td class=rateheader align=left width=440
          background=images/dk_blue_bg.gif><font color=#fefefe><b>ŧ����¹��Ҫԡ����</b></font></td>
                  <td align=right bgcolor=#34208b><img height=20
            src="images/rt_blue_corner.gif" width=18
        border=0></td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                <tr>
                  <td><img height=6 src="images/1x1.gif" width=1></td>
                </tr>
                <tr>
                  <td bgcolor=#34208b><img height=1 src="images/1x1.gif"
          width=1></td>
                </tr>
                <tr>
                  <td class=searchinstruct bgcolor=#f0f0f0><b>��سҡ�͡�����ŵ�ҧ
                    � ���ú��ǹ���¤�Ѻ</b></td>
                </tr>
                </tbody>
              </table>
              <table cellspacing=0 cellpadding=1 width="100%" border=0>
                <tbody>
                <tr>
                  <td bgcolor=#f0f0f0>
                    <table cellspacing=0 cellpadding=0 width="100%" bgcolor=#fefefe
            border=0>
                      <tbody>
                      <tr width="100%">
                        <td width=20 bgcolor="#fefefe"><img height=10 src="images/1x1.gif"
                width=1></td>
                        <td width="170" bgcolor="#fefefe"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=185 bgcolor="#fefefe"><img height=3
                  src="D:\tmp\TravelNow Airfare Reservations_files\search_files\1x1(1).gif"
                  width=1></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td class=airFieldTitle noWrap width=150 ><font><font color="#34208b">����:</font></font></td>
                        <td class=airField noWrap align=left width="200">
                          <input class=smallform
                  name=firstName>
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td class=airFieldTitle noWrap ><font><font color="#34208b">���ʡ��:</font></font></td>
                        <td class=airField noWrap align=left>
                          <input class=smallform
                  name=lastName>
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td><font color="#34208b">��:</font></td>
                        <td>
                          <input type="radio" name="sex" value="M" checked>
                          ���
                          <input type="radio" name="sex" value="F">
                          ˭ԧ </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td><font color="#34208b">�������:</font></td>
                        <td>
                          <textarea name="address"></textarea>
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td><font color="#34208b">�����Ţ���Ѿ��:</font></td>
                        <td>
                          <input type="text" name="telephone">
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td colspan="3" bgcolor="#f0f0f0"><b>�����ŵ��仹�� �繢���������Ѻ����������к�</b></td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td><font color="#34208b">Email Address:</font></td>
                        <td>
                          <input type="text" name="email">
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td><font color="#34208b">���ʼ�ҹ:</font></td>
                        <td>
                          <input type="password" name="password">
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td><font color="#34208b">�׹�ѹ���ʼ�ҹ:</font></td>
                        <td>
                          <input type="password" name="password2">
                        </td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td colspan=2>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20>&nbsp;</td>
                        <td colspan=2>
                          <div align="center">
                            <input class=smGoBtn style="BORDER-RIGHT: #000000 thin solid; BORDER-TOP: #d7d7d7 thin solid; BORDER-LEFT: #d7d7d7 thin solid; COLOR: #ffffff; BORDER-BOTTOM: #000000 thin solid; BACKGROUND-COLOR: #34208b" type=submit value=Submit name=submitted>
                            <input class=smGoBtn style="BORDER-RIGHT: #000000 thin solid; BORDER-TOP: #d7d7d7 thin solid; BORDER-LEFT: #d7d7d7 thin solid; COLOR: #ffffff; BORDER-BOTTOM: #000000 thin solid; BACKGROUND-COLOR: #34208b" type=reset value=Reset name=submitted2>
                          </div>
                        </td>
                        <!--
				  <TD colspan = 5 align = right>
                    <input class=airBookButton name=submitted style="BACKGROUND-COLOR: #34208B; BORDER-BOTTOM: #000000 thin solid; BORDER-LEFT: #d7d7d7 thin solid; BORDER-RIGHT: #000000 thin solid; BORDER-TOP: #d7d7d7 thin solid; COLOR: #FEFEFE" type=submit value="Search Available Flights">
					<input type = "hidden" name = validateCity value = true>
                  </TD>
				  -->
                      </tr>
                      <tr>
                        <td width="20" bgcolor="#fefefe">&nbsp;</td>
                        <td class=airsearchexample3 noWrap colspan=2 bgcolor="#fefefe">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width=20><img height=7 src="images/1x1.gif"
                width=1></td>
                        <td width="170"><img height=3 src="images/1x1.gif" width=1></td>
                        <td width=185><img height=3 src="images/1x1.gif"
                width=1></td>
                      </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
                </tbody>
              </table>
              <p>&nbsp;
            </form>
          </td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
