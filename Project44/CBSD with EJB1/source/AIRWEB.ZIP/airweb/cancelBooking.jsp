<%@ page import = "java.sql.*" %>
<%@ page import = "java.io.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.ejb.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	boolean confirm = false;

	private BookingServiceHome bookingServiceHome = null;
	private BookingHome bookingHome = null;
    /* ======================= lookup component ======================= */
	public void jspInit() {
    	    try {
         	 	//get naming context
          		Context ctx = new InitialContext();

      	    	//cast to Home interface
          		bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/BookingService"), BookingServiceHome.class);
				bookingHome = (BookingHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Booking"), BookingHome.class);
    		}
        	catch(Exception e) {
    			System.out.println("Cannot locate component!!");
	    		e.printStackTrace();
        	}
	}
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>

<head>
<!-- #BeginEditable "doctitle" --> 
<title>:: OLALA AIR :: ¡��ԡ��èͧ</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<table width="800" border="0" cellspacing="3" cellpadding="0">
  <tr> 
    <td height="83" colspan="2"> 
      <div align="center"><img src="images/title_index3.gif" width="795" height="88" align="right"></div>
      <div align="center"> </div>
    </td>
  </tr>
  <tr valign="top"> 
    <td width="128"> 
      <table width="100%" border="0">
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>S E R V I C E S</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td><b><font size="-1">+</font><font size="-1">&nbsp;</font><font size="-1"><a href="index.jsp">��������ǺԹ</a><br>
                        +<font color=#003399>&nbsp;</font><a href="listBooking.jsp">��������´��èͧ</a><br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        �׹�ѹ��èͧ<br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        ¡��ԡ��èͧ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>L O G I N</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">���ʴդ�Ѻ �س<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          �͡�ҡ�к� &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font size="-1"><b>Email Address: </b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <b><font size="-1">���ʼ�ҹ: </font></b> 
                            <input type="password" name="password">
                            <br>
                            <input type="submit" name="Submit" value="��ŧ">
                            <input type="reset" name="Submit2" value="¡��ԡ">
                          </p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="22"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1><span class=small><b class="h3color">�س����Ҫԡ�Ѻ��������ѧ?</b><br>
                          �س��ͧ��Ѥ�����Ҫԡ�Ѻ��� ���ͷӡ�èͧ��������� 
                          ��Ҥس�ѧ�������Ѥ���Ҫԡ ����ö��Ѥ� ��<br>
                          <a href="userRegister.jsp">&gt;&gt;&gt; ������Ѻ 
                          &lt;&lt;&lt;</a></span><br>
                          </font></div>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="107"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0" height="76">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"><font face=verdana,arial,helvetica size=-1><b>Your 
                        Shopping Cart</b></font> </td>
                    </tr>
                    <tr> 
                      <td> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><img 
                              height=25 alt="Shopping Cart" 
                              src="images/shopping-cart-small.gif" 
                              width=25 align=left border=0></td>
                            <td valign=top><font size="-1">�س���Թ��ҷ����� 
                              <font class="varhighlight"><%= shoppingCart.size() %></font> 
                              ��� � <a href="cart.jsp">ö�繢ͧ�س</a></font><br>
                            </td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small><b><font size="-1">��ԡ����Ҫԡ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <%
    if (customer == null) {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegister.jsp">��Ѥ���Ҫԡ����</a></font></td>
                    </tr>
                    <%
    }
    else {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegisterEdit.jsp">��䢢����š��ŧ����¹</a></font></td>
                    </tr>
                    <%
    }
%>
                    </tbody> 
                  </table>
                  
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color">������� Olala Transport</span></b><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0> <font size=-1>�س����ö��Ѥ���Ҫԡ 
                          �����Ѻ������èҡ����繻�Ш����Ѻ �Ѻ�ͧ����������<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          �����������ǡѺ��÷�ͧ�����<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          �����������ǡѺ����Թ�ҧ<br>
                          <span class="h3color">E-mail Address �ͧ�س:</span></font><span class="h3color"><font 
                  face=verdana,arial,helvetica size=-1></font></span><font 
                  face=verdana,arial,helvetica size=-1><br>
                          <input maxlength=60 size=15 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=absMiddle value="Sign up" border=0 name="Sign up">
                          <br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="2"> <!-- #BeginEditable "Center" --> 
      <%
	BookingService bookingService = bookingServiceHome.create();
	String bookingID = request.getParameter("bookingID");
	Collection bookingCollection = bookingService.ViewBooking(bookingID);
%>
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
            <font class="hidden"><b>�����Ţ��èͧ : <%= bookingID %></b></font><br>
            <table cellspacing=0 cellpadding=0 width="100%" border=0>
              <tbody> 
              <tr> 
                <td bgcolor=#34208b><img height=20 
            src="images/lt_blue_corner.gif" width=18 border=0></td>
                <td class=rateheader align=left width=440 
          background=images/dk_blue_bg.gif><font color=#fefefe><b>��������´��èͧ</b></font></td>
                <td align=right bgcolor=#34208b><img height=20 
            src="images/rt_blue_corner.gif" width=18 
        border=0></td>
              </tr>
              </tbody> 
            </table>
            <%
	String errorMessage = null;
	BookingPK bookingPK = new BookingPK(bookingID);
	try {
		Booking _booking = bookingHome.findByPrimaryKey(bookingPK);
		BookingVO bookingVO = _booking.getBooking();
		if (bookingVO.getConfirmation() == 1) {
			confirm = true;
		}
		if (!customer.getCustomerID().equals(bookingVO.getCustomerID())) {
			errorMessage = "�������¡�á�èͧ�ͧ�س";
		}
		// ����� Collection ��ҧ
		else if (bookingCollection.size() == 0) {
			errorMessage = "��辺�����Ţ��èͧ����к�";
		}
	}
	catch (FinderException fe) {
		errorMessage = "��辺�����Ţ��èͧ����к�";
	}

	if (errorMessage != null) {
		%>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="100"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%" height="100%">
                    <tr> 
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                      <td bgcolor="#F0F0F0" height="1"></td>
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td class="airFieldTitleGray"></td>
                      <td class="airFieldTitleGray"><%= errorMessage %> </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <%		
	}
	else {
		Iterator i = bookingCollection.iterator();
		int totalSeats = 0;
		int totalPrice = 0;
		while (i.hasNext()) {
			ViewBookInfo booking = (ViewBookInfo) i.next();
			// ��ҹ��ҵ�ҧ � �ҡ ViewBookInfo
			int itemNo = booking.getItemNo();
			String flightID = booking.getFlightID();
			String classID = booking.getClassID();
			Timestamp departDateTime = booking.getDepartDateTime();
			Timestamp arriveDateTime = booking.getArriveDateTime();
			String airportSrcID = booking.getAirportSrcID();
			String airportSrcName = booking.getAirportSrcName();
			String airportDesID = booking.getAirportDesID();
			String airportDesName = booking.getAirportDesName();
			int seats = booking.getTotalSeat();
			double price = booking.getPrice();
			
			// �ӹǳ�ӹǹ�Ҥ� ��Шӹǹ��������
			totalSeats += seats;
			totalPrice += (price * seats);
		%>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="131"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" bgcolor="#F0F0F0" height="1"></td>
                      <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td></td>
                      <td width="230" color="#FEFEFE" class="airFieldTitleGray"><font color="#888888"><b>��¡�� 
                        #<%= itemNo %></b></font></td>
                      <td width="230" bgcolor="#FEFEFE"></td>
                      <td></td>
                    </tr>
                  </table>
                  <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                    <!-- begin date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3" align="center"><font color="#888888"><b>AIRPORT</b></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3" align="center"><font color="#888888"><b>CLASS</b></font></td>
                      <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                      <td NOWRAP class="airsearchexample2" align="center"><b> 
                        <font color=#888888>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="airsearchexample2" align="center"><b> <font color=#888888>DEPART</font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample2" align="center"><b> <font color="#888888">����ǺԹ 
                        #</font></b><font color="#888888"></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <!-- end  date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= airportSrcName %> (<%= airportSrcID %>)</td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="classInfo.jsp?classID=<%= classID %>" target="_blank"><%= classID %></a></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> <b><%= DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(departDateTime) %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="flightInfo.jsp?flightID=<%= flightID %>" target="_blank"><%= flightID %></a></td>
                      <td width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="infocopy"><%= airportDesName %> (<%= airportDesID %>)</td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"></td>
                      <td nowrap class="infocopy"> <b><%= DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(arriveDateTime) %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                    </tr>
                  </table>
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230" align="right"><a href="listTraveller.jsp?bookingID=<%= bookingID %>&itemNo=<%= itemNo %>&flightID=<%= flightID %>" target="_blank">&gt;&gt;&gt; 
                        ��������´����Թ�ҧ &lt;&lt;&lt;</a></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <table width="230" border="0" cellspacing="0" cellpadding="1">
                          <tr> 
                            <td bgcolor="#34208B"> 
                              <table width="231" border="0" cellspacing="0" cellpadding="2">
                                <tr> 
                                  <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���� 
                                    <%= new DecimalFormat("#,##0.00").format(seats * price) %> �ҷ ����Ѻ <%= seats %> 
                                    �����</font></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td colspan="2"><img height=7 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"><b> </b> </td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10 height="2"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" height="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2" height="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <br>
            <%
		} // while
	%>
            <table width="250" border="0" align="right">
              <tr> 
                <td bgcolor="#34208B"> 
                  <table width="250" border="0" cellspacing="0" cellpadding="2">
                    <tr> 
                      <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���������� 
                        <%= totalPrice %> �ҷ ����Ѻ <%= totalSeats %> �����</font></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <p>&nbsp;</p>
          </td>
        </tr>
      </table>
      <p align="center">&nbsp;</p>
      <form name="form4" method="post" action="servlet/CancelBookingServlet">
        <div align="center">¡��ԡ��¡�á�èͧ���<br>
          <input type="submit" name="Submit5" value="��ŧ">
          <input type="hidden" name="bookingID" value="<%= bookingID %>">
        </div>
      </form>
      <%
	} // if .. else
%>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
