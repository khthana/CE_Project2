<%@ page import = "javax.rmi.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
    try {
        String airlineID = request.getParameter("airlineID");
        AirlineService airlineService = airlineServiceHome.create();
        AirlineVO airlineVO = airlineService.GetAirline(airlineID);
        %>
        
<html>
<head>
<title>:: OLALA AIR :: ��������¡�úԹ - <%= airlineVO.getAirlineID() %></title>
</head>
<body>  
<h1>��������¡�úԹ</h1>
<table border="1" cellspacing="1" cellpadding="1">
  <tr> 
    <td align="center" bgcolor="fff5ee"> <font size="-1"><b>������¡�úԹ</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>������¡�úԹ</b></font></td>
    <td align="center" bgcolor="fff5ee"><font size="-1"><b>�����˵�</b></font></td>
  </tr>
  <tr> 
    <td align="center"><font size="-1" color="#800000"><b><%= airlineVO.getAirlineID() %></b></font></td>
    <td align="center"><font size="-1"><%= airlineVO.getAirlineName() %></font></td>
    <td align="center"><font size="-1"><%= airlineVO.getDescription() %></font></td>
  </tr>
</table>
<p><a href="javascript:window.close();">&gt;&gt;&gt; �Դ˹�ҵ�ҧ��� &lt;&lt;&lt;</a></p>
</body>
</html>  

        <%
    }
    catch (Exception e) {
        out.println("��辺 Aircraft Class ����к�");
    }
%>
