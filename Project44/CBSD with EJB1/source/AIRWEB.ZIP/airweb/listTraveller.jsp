<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.util.*" %>
<%@ page import = "javax.naming.*" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
    private BookingServiceHome bookingServiceHome = null;
	private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object bookingServiceRef = ctx.lookup("java:comp/env/ejb/BookingService");
            Object airlineServiceRef = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(bookingServiceRef, BookingServiceHome.class);
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(airlineServiceRef, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>:: OLALA AIR :: ��������´����Թ�ҧ</title>
</head>

<body>

    
<table>
  <tr bgcolor="#d0ccd0"> 
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">�ӴѺ���</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">����</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">���ʡ��</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">�����Ţ�����</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">������ٺ������</font></b></div>
    </td>
    <td> 
      <div align="center"><b><font face="MS Sans Serif" size="2">��������˹�ҵ�ҧ</font></b></div>
    </td>
  </tr>
  <%
	String bookingID = request.getParameter("bookingID");
	int itemNo = Integer.parseInt(request.getParameter("itemNo"));

    String bgcolor = null;
    int row = 0;
    BookingService bookingService = bookingServiceHome.create();
    Collection travellerSeatsCollection = bookingService.GetSeatBookings(bookingID, itemNo);
    Iterator i = travellerSeatsCollection.iterator();

	String flightID = request.getParameter("flightID");
	AirlineService airlineService = airlineServiceHome.create();
	FlightVO flightVO = airlineService.GetFlight(flightID);
	String modelID = flightVO.getModelID();

    while (i.hasNext()) {
        row++;
        if ((row % 2) == 0) {
            bgcolor = "#f8f8f8";
        }
        else {
            bgcolor = "#fff0d8";
        }
        TravellerSeat travellerSeat = (TravellerSeat) i.next();
		TravellerVO travellerVO = travellerSeat.getTravellerVO();
        %>
  <tr bgcolor="<%= bgcolor %>"> 
    <td><font face="MS Sans Serif" size="2"><%= row %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= travellerVO.getFirstName() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= travellerVO.getLastName() %></font></td>
    <td><font face="MS Sans Serif" size="2"><%= travellerSeat.getSeatNo() %></font></td>
<% 
	SeatVO seatVO = airlineService.GetSeat(travellerSeat.getSeatNo(), modelID); 
	boolean window = seatVO.getWindow();
	boolean smoking = seatVO.getSmoking();
%>
    <td align="center"><font face="MS Sans Serif" size="2"><input type="checkbox" name="checkbox" value="checkbox" <% if (smoking) { out.println("checked"); } %> disabled></font></td>
    <td align="center"><font face="MS Sans Serif" size="2"><input type="checkbox" name="checkbox" value="checkbox" <% if (window) { out.println("checked"); } %> disabled></font></td>
  </tr>
  <%
    }
%>
</table>

<p><a href="javascript:window.close();">&gt;&gt;&gt; �Դ˹�ҵ�ҧ��� &lt;&lt;&lt;</a></p>
</body>
</html>
