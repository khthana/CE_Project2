<%@ page import = "javax.rmi.*" %>
<%@ page import = "java.sql.Date" %>
<%@ page import = "java.util.*" %>
<%@ page import = "java.text.*" %>
<%@ page import = "javax.naming.*" %>
<%@ page import = "java.text.DateFormat" %>

<%@ page import = "olala.airlinesystem.*" %>
<%@ page import = "olala.util.*" %>
<%@ page import = "olala.*" %>

<%@ page contentType="text/html; charset=MS874"%>

<%!
	private final String TARGET_PAGE = "index.jsp";
	private final int bookingLength = 14;
	
    private AirlineServiceHome airlineServiceHome = null;
    /* ======================= lookup component ======================= */
    public void jspInit() {
        try {
            //get naming context
            Context ctx = new InitialContext();

            //look up jndi name
            Object ref = ctx.lookup("java:comp/env/ejb/AirlineService");

            //cast to Home interface
            airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
        } // try
        catch(Exception e) {
            System.out.println("Cannot locate component!!");
            e.printStackTrace();
        } // catch
    }
%>

<%
	String errorMsg = null;

    String departureAirportID = request.getParameter("departureAirport").toUpperCase();
    String destinationAirportID = request.getParameter("destinationAirport").toUpperCase();
    if (departureAirportID.equals("") || destinationAirportID.equals("")
		|| departureAirportID == null || destinationAirportID == null)
	{
        response.sendRedirect(response.encodeURL(TARGET_PAGE+"?errCode=0"));
    }
    AirlineService airlineService = airlineServiceHome.create();
	AirportVO departureAirportVO = null;
	AirportVO destinationAirportVO = null;
	try {
	   	departureAirportVO = airlineService.GetAirport(departureAirportID);
		destinationAirportVO = airlineService.GetAirport(destinationAirportID);
    }
    catch (Exception e) {
        response.sendRedirect(response.encodeURL(TARGET_PAGE+"?errCode=1"));
    }
	
    /* ================== �ѹ�Թ�ҧ� / ��Ѻ ================== */
	String departureDay = request.getParameter("departureDay");
	String departureMonth = request.getParameter("departureMonth");
	String departureYear = request.getParameter("departureYear");
	String departureDateString = departureYear+"-"+departureMonth+"-"+departureDay;
	java.sql.Date departureDate = java.sql.Date.valueOf(departureDateString);
	String returnDay = request.getParameter("returnDay");
	String returnMonth = request.getParameter("returnMonth");
	String returnYear = request.getParameter("returnYear");
	String returnDateString = returnYear+"-"+returnMonth+"-"+returnDay;
	java.sql.Date returnDate = java.sql.Date.valueOf(returnDateString);

    Calendar calendar = Calendar.getInstance();
    int today = calendar.get(Calendar.DATE);
    int month = calendar.get(Calendar.MONTH);
    int year = calendar.get(Calendar.YEAR);
	String currentDateString = year+"-"+(month+1)+"-"+today;
	java.sql.Date currentDate = java.sql.Date.valueOf(currentDateString);

	int bookingDeadlineDay = today + bookingLength;
	String bookingDeadlineString = year+"-"+(month+1)+"-"+bookingDeadlineDay;
	java.sql.Date bookingDeadline = java.sql.Date.valueOf(bookingDeadlineString);

    /* ================== Log ================== */
	System.out.println("search.jsp - Current Date : " + currentDate);
	System.out.println("search.jsp - Departure Date : " + departureDate);
	System.out.println("search.jsp - Return Date : " + returnDate);
	System.out.println("search.jsp - Booking Deadline : " + bookingDeadline);
	
    /* ================== ���˹觷�����ٺ������������˹�ҵ�ҧ ================== */
    boolean window = true;
    boolean smoking = true;
    boolean directFlight = true;
    if (request.getParameter("window") == null)    { window = false; }
    if (request.getParameter("smoking") == null)    { smoking = false; }
    if (request.getParameter("directFlight") == null)    { directFlight = false; }

    /* ================== �����Թ�ҧ� / ��Ѻ================== */
	java.sql.Time departureTime = null;
	java.sql.Time returnTime = null;
	String departureTimeString = request.getParameter("departureTime");
	String returnTimeString = request.getParameter("returnTime");
	if (!departureTimeString.equals("0")) {
		departureTime = java.sql.Time.valueOf(departureTimeString);
	}
	if (!returnTimeString.equals("0")) {
		returnTime = java.sql.Time.valueOf(returnTimeString);
	}

	boolean roundTrip = false;
	String tripType = request.getParameter("tripType");
	if (tripType.equals("R")) {
		roundTrip = true;
	}

    int seats = Integer.parseInt(request.getParameter("seats"));
    String aircraftClass = request.getParameter("class");
    String airline = request.getParameter("airline");
    if (airline.equals("")) { airline = null; }
    
    Collection searchResultCollection = null;
    Collection searchResultCollection2 = null;
	boolean foundResult = true;
	
	searchResultCollection = airlineService.Search(
        departureAirportID,
        destinationAirportID,
        seats,
        departureDate,
        departureTime,
        aircraftClass,
        airline,
        smoking,
        window,
        directFlight);
	if(searchResultCollection.isEmpty()) {
		foundResult = false;
	}

	if (roundTrip) {
		searchResultCollection2 = airlineService.Search(
    	    destinationAirportID,
	        departureAirportID,
    	    seats,
        	returnDate,
	        returnTime,
    	    aircraftClass,
        	airline,
	        smoking,
    	    window,
        	directFlight);
		if(searchResultCollection2.isEmpty()) {
			foundResult = false;
		}
	}
%>

<html><!-- #BeginTemplate "/Templates/Home.dwt" -->

<% 
	CustomerVO customer = (CustomerVO)session.getAttribute("customerDetail"); 
	ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
	if(shoppingCart == null) {
		shoppingCart = new ShoppingCart();
	}
%>

<head>
<!-- #BeginEditable "doctitle" --> 
<title>:: OLALA AIR :: ���Ѿ���ä���</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<link rel="stylesheet" href="styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<table width="800" border="0" cellspacing="3" cellpadding="0">
  <tr> 
    <td height="83" colspan="2"> 
      <div align="center"><img src="images/title_index3.gif" width="795" height="88" align="right"></div>
      <div align="center"> </div>
    </td>
  </tr>
  <tr valign="top"> 
    <td width="128"> 
      <table width="100%" border="0">
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>S E R V I C E S</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td><b><font size="-1">+</font><font size="-1">&nbsp;</font><font size="-1"><a href="index.jsp">��������ǺԹ</a><br>
                        +<font color=#003399>&nbsp;</font><a href="listBooking.jsp">��������´��èͧ</a><br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        �׹�ѹ��èͧ<br>
                        &nbsp;&nbsp;&nbsp;</font><font size="-1">�</font><font size="-1"> 
                        ¡��ԡ��èͧ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"> 
                        <div align="center"><font size=-1><b>L O G I N</b></font></div>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <%
    if (customer != null) {
        %>
                        <p align="center">���ʴդ�Ѻ �س<br>
                          <font class="varhighlight"><%= CharsetConverter.MS874ToUnicode(new String(customer.getFirstName())) %> 
                          <%= CharsetConverter.MS874ToUnicode(new String(customer.getLastName())) %></font><br>
                        </p>
                        <p align="center"><a href="servlet/LogoutServlet">&gt;&gt;&gt; 
                          �͡�ҡ�к� &lt;&lt;&lt;</a></p>
                        <%
    }
    else {
        %>
                        <form name="form1" method="post" action="login.jsp">
                          <p><font size="-1"><b>Email Address: </b></font> 
                            <input type="text" name="emailAddress">
                            <br>
                            <b><font size="-1">���ʼ�ҹ: </font></b> 
                            <input type="password" name="password">
                            <br>
                            <input type="submit" name="Submit" value="��ŧ">
                            <input type="reset" name="Submit2" value="¡��ԡ">
                          </p>
                        </form>
                        <%
    }
%>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="22"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1><span class=small><b class="h3color">�س����Ҫԡ�Ѻ��������ѧ?</b><br>
                          �س��ͧ��Ѥ�����Ҫԡ�Ѻ��� ���ͷӡ�èͧ��������� 
                          ��Ҥس�ѧ�������Ѥ���Ҫԡ ����ö��Ѥ� ��<br>
                          <a href="userRegister.jsp">&gt;&gt;&gt; ������Ѻ 
                          &lt;&lt;&lt;</a></span><br>
                          </font></div>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td width="128" valign="top" height="107"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#990000 border=0 vspace="0" valign="top" hspace="0" height="76">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="#ffcc66"><font face=verdana,arial,helvetica size=-1><b>Your 
                        Shopping Cart</b></font> </td>
                    </tr>
                    <tr> 
                      <td> 
                        <table>
                          <tbody> 
                          <tr> 
                            <td valign=top><img 
                              height=25 alt="Shopping Cart" 
                              src="images/shopping-cart-small.gif" 
                              width=25 align=left border=0></td>
                            <td valign=top><font size="-1">�س���Թ��ҷ����� 
                              <font class="varhighlight"><%= shoppingCart.size() %></font> 
                              ��� � <a href="cart.jsp">ö�繢ͧ�س</a></font><br>
                            </td>
                          </tr>
                          </tbody> 
                        </table>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=3 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td class=small><b><font size="-1">��ԡ����Ҫԡ</font></b></td>
                    </tr>
                    </tbody> 
                  </table>
                  <table cellspacing=0 cellpadding=2 width="100%" 
                  bgcolor=#ffffff border=0 vspace="0">
                    <tbody> 
                    <%
    if (customer == null) {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegister.jsp">��Ѥ���Ҫԡ����</a></font></td>
                    </tr>
                    <%
    }
    else {
        %>
                    <tr valign=top> 
                      <td><img 
                        height=18 alt=Icon 
                        src="images/small-blue-toys-icon.gif" 
                        width=18 border=0></td>
                      <td><font size="-1"><a href="userRegisterEdit.jsp">��䢢����š��ŧ����¹</a></font></td>
                    </tr>
                    <%
    }
%>
                    </tbody> 
                  </table>
                  
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
        <tr> 
          <td valign="top"> 
            <table cellspacing=0 cellpadding=1 width=174 align=right 
            bgcolor=#CCCC99 border=0 vspace="0" valign="top" hspace="0">
              <tbody> 
              <tr> 
                <td> 
                  <table cellspacing=0 cellpadding=4 width="100%" 
                  bgcolor=#ffffff border=0>
                    <tbody> 
                    <tr bgcolor=#ffcc66> 
                      <td bgcolor="ffffff"> 
                        <div align="center"><font size=-1></font></div>
                        <form name="form2" method="post" action="">
                          <b><span class="h3color">������� Olala Transport</span></b><span class="h3color"><br>
                          </span> <img 
                  height=28 
                  src="images/icon_delivers.gif" 
                  width=30 align=left border=0> <font size=-1>�س����ö��Ѥ���Ҫԡ 
                          �����Ѻ������èҡ����繻�Ш����Ѻ �Ѻ�ͧ����������<br>
                          <input type=checkbox CHECKED value=bizarre 
                  name=group>
                          �����������ǡѺ��÷�ͧ�����<br>
                          <input type=checkbox CHECKED 
                  value=great-stuff-for-kids name=group>
                          �����������ǡѺ����Թ�ҧ<br>
                          <span class="h3color">E-mail Address �ͧ�س:</span></font><span class="h3color"><font 
                  face=verdana,arial,helvetica size=-1></font></span><font 
                  face=verdana,arial,helvetica size=-1><br>
                          <input maxlength=60 size=15 
                  name=email>
                          <input type=image height=23 width=71 
                  src="images/subscribe.gif" 
                  align=absMiddle value="Sign up" border=0 name="Sign up">
                          <br 
                  clear=all>
                          </font> 
                        </form>
                      </td>
                    </tr>
                    </tbody> 
                  </table>
                </td>
              </tr>
              </tbody> 
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td height="311" width="663" rowspan="2"> <!-- #BeginEditable "Center" --> 
      <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
		  <br>
            <table cellspacing=0 cellpadding=0 width="100%" border=0>
              <tbody> 
              <tr> 
                <td bgcolor=#34208b><img height=20 
            src="images/lt_blue_corner.gif" width=18 border=0></td>
                <td class=rateheader align=left width=440 
          background=images/dk_blue_bg.gif><font color=#fefefe><b>���Ѿ���ä�������ǺԹ</b></font></td>
                <td align=right bgcolor=#34208b><img height=20 
            src="images/rt_blue_corner.gif" width=18 
        border=0></td>
              </tr>
              </tbody> 
            </table>
<%
	if (departureDate.before(bookingDeadline)) {
		errorMsg = "��سҷӡ�ä�������ǺԹ��ѧ�ҡ�ѹ���Ѩ�غѹ " + bookingLength + " �ѹ��Ѻ";
	}
	else if (roundTrip && departureDate.after(returnDate)) {
		errorMsg = "�ѹ����Թ�ҧ��Ѻ ��ͧ���ѹ��ѧ�ҡ�ѹ�Թ�ҧ��Ѻ";
	}
    else if (!foundResult) {
		errorMsg = "��辺����ǺԹ���ç�Ѻ������ͧ��âͧ�س";
	}
	if (errorMsg != null) {
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="100"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%" height="100%">
                    <tr> 
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                      <td bgcolor="#F0F0F0" height="1"></td>
                      <td width="10" bgcolor="#F0F0F0" height="1"><img height=10 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td class="airFieldTitleGray"></td>
                      <td class="airFieldTitleGray"><blockquote><font class="errormsg"><%= errorMsg %></font></blockquote>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
        <%
    }
    else if (!roundTrip) {
    int itemNo = 0;
    Iterator i = searchResultCollection.iterator();
    while(i.hasNext()) {
        itemNo++;
        AirSeatSearchResult assr = (AirSeatSearchResult) i.next();
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="131"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" bgcolor="#F0F0F0" height="1"></td>
                      <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td></td>
                      <td width="230" color="#FEFEFE" class="airFieldTitleGray"><font color="#888888"><b>��¡�� #<%= itemNo %></b></font></td>
                      <td width="230" bgcolor="#FEFEFE"></td>
                      <td></td>
                    </tr>
                  </table>
                  <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                    <!-- begin date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap class="airsearchexample"><b><font color=#34208B><%= DateFormat.getDateInstance(DateFormat.MEDIUM).format(departureDate) %></font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3"><font color="#888888"><b>CLASS</b></font></td>
                      <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                      <td NOWRAP class="airsearchexample2"><b> <font color=#888888>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="airsearchexample2"><b> <font color=#888888>DEPART</font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample2"><b> <font color="#888888">����ǺԹ 
                        #</font></b><font color="#888888"></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <!-- end  date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= departureAirportVO.getAirportName() %> 
                        (<%= departureAirportID %>)</td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="classInfo.jsp?classID=<%= assr.getClassID() %>" target="_blank"><%= assr.getClassID() %></a></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> <b><%= assr.getDepartTime().toString() %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="flightInfo.jsp?flightID=<%= assr.getFlightID() %>" target="_blank"><%= assr.getFlightID() %></a></td>
                      <td width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="infocopy"><%= destinationAirportVO.getAirportName() %> 
                        (<%= destinationAirportID %>)</td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"></td>
                      <td nowrap class="infocopy"> <b><%= assr.getArriveTime().toString() %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                    </tr>
                  </table>
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230">
                        <input type="checkbox" name="checkbox" value="checkbox" <% if (smoking) { out.println("checked"); } %> disabled>
                        ������ٺ������<br>
                        <input type="checkbox" name="checkbox2" value="checkbox" <% if (window) { out.println("checked"); } %> disabled>
                        ��������˹�ҵ�ҧ<br>
					  </td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <table width="230" border="0" cellspacing="0" cellpadding="1">
                          <tr> 
                            <td bgcolor="#34208B"> 
                              <table width="230" border="0" cellspacing="0" cellpadding="2">
                                <tr> 
                                  <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���� 
                                    <%= new DecimalFormat("#,##0.00").format(assr.getPrice() * seats) %> �ҷ ����Ѻ <%= seats %> �����</font></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td colspan="2"><img height=7 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <form method="POST" name="RezRequester" action="servlet/AddToCartServlet">
                          <input class=airBookitButton type="submit" name="Submit3" value="Add to cart" style="border-bottom:thin solid #000000
      ;border-right:thin solid #000000;border-top:thin solid
      #D7D7D7;border-left:thin solid #D7D7D7;background-color:#34208B;color:#FFFFFF">
                        <input type="hidden" name="flightID" value="<%= assr.getFlightID() %>">
                        <input type="hidden" name="classID" value="<%= assr.getClassID() %>">
                        <input type="hidden" name="seats" value="<%= seats %>">
                        <input type="hidden" name="srcidx" value="<%= assr.getSrcIdx() %>">
                        <input type="hidden" name="desidx" value="<%= assr.getDesIdx() %>">
                        <input type="hidden" name="unitPrice" value="<%= assr.getPrice() %>">
                        <input type="hidden" name="smoking" value="<%= smoking %>">
                        <input type="hidden" name="window" value="<%= window %>">
                        <input type="hidden" name="departDate" value="<%= departureDateString %>">
						<input type="hidden" name="departureAirportID" value="<%= departureAirportID %>">
						<input type="hidden" name="destinationAirportID" value="<%= destinationAirportID %>">
						<input type="hidden" name="departureTime" value="<%= assr.getDepartTime().toString() %>">
						<input type="hidden" name="arriveTime" value="<%= assr.getArriveTime().toString() %>">
						<input type="hidden" name="tripType" value="O">
                        </form>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10 height="2"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" height="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2" height="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <br>
        <%
    	} // while
    } // else if
	else if (roundTrip) {

    int itemNo = 1;
    Iterator i = searchResultCollection.iterator();
    AirSeatSearchResult assr = (AirSeatSearchResult) i.next();
        %>
            <table border=0 cellpadding=1 cellspacing=0 width=100%>
              <tr> 
                <td bgcolor="#F0F0F0" height="131"> 
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10 bgcolor="#F0F0F0" height="11"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" bgcolor="#F0F0F0" height="1"></td>
                      <td width=10 colspan="2" bgcolor="#F0F0F0" height="11"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td></td>
                      <td width="230" color="#FEFEFE" class="airFieldTitleGray"><font color="#888888"><b>��¡�� #<%= itemNo %></b></font></td>
                      <td width="230" bgcolor="#FEFEFE"></td>
                      <td></td>
                    </tr>
                  </table>
                  <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                    <!-- begin date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap><img height=1 src="images/1x1.gif" width=1>������</td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap class="airsearchexample"><b><font color=#34208B><%= DateFormat.getDateInstance(DateFormat.MEDIUM).format(departureDate) %></font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3"><font color="#888888"><b>CLASS</b></font></td>
                      <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                      <td NOWRAP class="airsearchexample2"><b> <font color=#888888>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="airsearchexample2"><b> <font color=#888888>DEPART</font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample2"><b> <font color="#888888">����ǺԹ 
                        #</font></b><font color="#888888"></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <!-- end  date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= departureAirportVO.getAirportName() %> 
                        (<%= departureAirportID %>)</td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="classInfo.jsp?classID=<%= assr.getClassID() %>" target="_blank"><%= assr.getClassID() %></a></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> <b><%= assr.getDepartTime().toString() %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="flightInfo.jsp?flightID=<%= assr.getFlightID() %>" target="_blank"><%= assr.getFlightID() %></a></td>
                      <td width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="infocopy"><%= destinationAirportVO.getAirportName() %> 
                        (<%= destinationAirportID %>)</td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"></td>
                      <td nowrap class="infocopy"> <b><%= assr.getArriveTime().toString() %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                    </tr>
                  </table>
<%
	i = searchResultCollection2.iterator();
    AirSeatSearchResult assr2 = (AirSeatSearchResult) i.next();
%>
                  <table  bgcolor="#FEFEFE" width=100% border=0 cellpadding=0 cellspacing=0>
                    <!-- begin date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td added bgcolor to tr for displaying the table row></td>
                      <td added bgcolor to tr for displaying the table row> 
                        <p><img height=3 src="images/1x1.gif" width=1></p>
                      </td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap><img height=1 src="images/1x1.gif" width=1>����ǡ�Ѻ</td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap class="airsearchexample"><b><font color=#34208B><%= DateFormat.getDateInstance(DateFormat.MEDIUM).format(returnDate) %></font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample3"><font color="#888888"><b>CLASS</b></font></td>
                      <td width=10 class="airsearchexample2"><img height=1 src="images/1x1.gif" width=1></td>
                      <td NOWRAP class="airsearchexample2"><b> <font color=#888888>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="airsearchexample2"><b> <font color=#888888>DEPART</font></b></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                      <td class="airsearchexample2"><b> <font color="#888888">����ǺԹ 
                        #</font></b><font color="#888888"></font></td>
                      <td width=10><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan="11" bgcolor=#34208B><img height=1 src="images/1x1.gif" width=1></td>
                      <td width=10 bgcolor=#FEFEFE><img height=1 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td noWrap colspan=11><img height=5 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <!-- end  date/header info //-->
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>DEPART</font></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><%= destinationAirportVO.getAirportName() %> 
                        (<%= destinationAirportID %>)</td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="classInfo.jsp?classID=<%= assr2.getClassID() %>" target="_blank"><%= assr2.getClassID() %></a></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> <b><%= assr2.getDepartTime().toString() %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"><a href="flightInfo.jsp?flightID=<%= assr2.getFlightID() %>" target="_blank"><%= assr2.getFlightID() %></a></td>
                      <td width=10></td>
                    </tr>
                    <tr bgcolor=#FEFEFE> 
                      <td width=10></td>
                      <td noWrap> <b><font class="airsearchexample" color=#34208B>ARRIVE</font></b></td>
                      <td width=10></td>
                      <td class="infocopy"><%= departureAirportVO.getAirportName() %> 
                        (<%= departureAirportID %>)</td>
                      <td width=10></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"></td>
                      <td nowrap class="infocopy"> <b><%= assr2.getArriveTime().toString() %></b></td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                      <td nowrap class="infocopy"> </td>
                      <td width=10></td>
                    </tr>
                  </table>
                  <table bgcolor="#FEFEFE" border=0 cellpadding=0 cellspacing=0 width="100%">
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230">
                        <input type="checkbox" name="checkbox" value="checkbox" <% if (smoking) { out.println("checked"); } %> disabled>
                        ������ٺ������<br>
                        <input type="checkbox" name="checkbox2" value="checkbox" <% if (window) { out.println("checked"); } %> disabled>
                        ��������˹�ҵ�ҧ<br>
					  </td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <table width="230" border="0" cellspacing="0" cellpadding="1">
                          <tr> 
                            <td bgcolor="#34208B"> 
                              <table width="230" border="0" cellspacing="0" cellpadding="2">
                                <tr> 
                                  <td bgcolor="#FEFEFE" class="airPrice" align="center"><font color="#34208B">�Ҥ���� 
                                    <%= new DecimalFormat("#,##0.00").format((assr.getPrice() * seats) + (assr2.getPrice() * seats)) %> �ҷ ����Ѻ <%= seats * 2 %> �����</font></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                      <td colspan="2"><img height=7 src="images/1x1.gif" width=1></td>
                      <td width=10><img height=3 src="images/1x1.gif" width=1></td>
                    </tr>
                    <tr> 
                      <td width=10></td>
                      <td width="230"></td>
                      <td width="230" bgcolor="#FEFEFE" align="right"> 
                        <form method="POST" name="RezRequester" action="servlet/AddToCartServlet">
                          <input class=airBookitButton type="submit" name="Submit3" value="Add to cart" style="border-bottom:thin solid #000000
      ;border-right:thin solid #000000;border-top:thin solid
      #D7D7D7;border-left:thin solid #D7D7D7;background-color:#34208B;color:#FFFFFF">
                        <input type="hidden" name="flightID" value="<%= assr.getFlightID() %>">
                        <input type="hidden" name="classID" value="<%= assr.getClassID() %>">
                        <input type="hidden" name="seats" value="<%= seats %>">
                        <input type="hidden" name="srcidx" value="<%= assr.getSrcIdx() %>">
                        <input type="hidden" name="desidx" value="<%= assr.getDesIdx() %>">
                        <input type="hidden" name="unitPrice" value="<%= assr.getPrice() %>">
                        <input type="hidden" name="smoking" value="<%= smoking %>">
                        <input type="hidden" name="window" value="<%= window %>">
                        <input type="hidden" name="departDate" value="<%= departureDateString %>">
						<input type="hidden" name="departureAirportID" value="<%= departureAirportID %>">
						<input type="hidden" name="destinationAirportID" value="<%= destinationAirportID %>">
						<input type="hidden" name="departureTime" value="<%= assr.getDepartTime().toString() %>">
						<input type="hidden" name="arriveTime" value="<%= assr.getArriveTime().toString() %>">

                        <input type="hidden" name="flightID2" value="<%= assr2.getFlightID() %>">
                        <input type="hidden" name="classID2" value="<%= assr2.getClassID() %>">
                        <input type="hidden" name="seats2" value="<%= seats %>">
                        <input type="hidden" name="srcidx2" value="<%= assr2.getSrcIdx() %>">
                        <input type="hidden" name="desidx2" value="<%= assr2.getDesIdx() %>">
                        <input type="hidden" name="unitPrice2" value="<%= assr2.getPrice() %>">
                        <input type="hidden" name="smoking2" value="<%= smoking %>">
                        <input type="hidden" name="window2" value="<%= window %>">
                        <input type="hidden" name="departDate2" value="<%= returnDateString %>">
						<input type="hidden" name="departureAirportID2" value="<%= destinationAirportID %>">
						<input type="hidden" name="destinationAirportID2" value="<%= departureAirportID %>">
						<input type="hidden" name="departureTime2" value="<%= assr2.getDepartTime().toString() %>">
						<input type="hidden" name="arriveTime2" value="<%= assr2.getArriveTime().toString() %>">
						<input type="hidden" name="tripType" value="R">
                        </form>
                      </td>
                      <td width=10></td>
                    </tr>
                    <tr> 
                      <td width=10 height="2"><img height=10 src="images/1x1.gif" width=10></td>
                      <td colspan="2" height="2"><img height=3 src="images/1x1.gif" width=1></td>
                      <td width=10 colspan="2" height="2"><img height=3 src="images/1x1.gif" width=10></td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            <br>
<%
	}
%>

          </td>
        </tr>
      </table>
      <!-- #EndEditable --></td>
  </tr>
  <tr> 
    <td height="2">&nbsp;</td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
