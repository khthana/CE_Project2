java olala.hotel.HotelService
