SELECT T1.BusID, T1.CompanyID, T1.ModelID, T4.RentCost
FROM   Bus T1, BusModel T2, BusFee T4
WHERE  T2.ModelID = T1.ModelID
AND T4.ModelID = T1.ModelID
AND T4.CompanyID = T1.CompanyID
AND NOT EXISTS
( SELECT *
FROM   BusRenting T5
WHERE  T5.BusID = T1.BusID
AND T5.UsingDate BETWEEN '2002-3-16' AND '2002-3-16')
ORDER BY T1.CompanyID, T1.ModelID, T4.RentCost