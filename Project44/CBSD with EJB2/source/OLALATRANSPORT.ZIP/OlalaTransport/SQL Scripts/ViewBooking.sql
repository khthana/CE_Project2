SELECT T2.ItemNo, T2.FlightID, MIN( T10.ClassID ), MIN( T3.DepartDate + T8.DepartTime ), MAX( T3.DepartDate + T8.ArriveTime ), 
	COUNT( DISTINCT T10.SeatNo ), T2.Price, 
 T4.AirportID, T4.AirportName, T5.AirportID, T5.AirportName 
FROM   Booking T1, BookingDetail T2, SeatBooking T3, 
     Airport T4, Airport T5, 
      SubRoute T6, SubRoute T7, 
      FlightSchedule T8, FlightSchedule T9, Seat T10, Flight T11
WHERE  T1.BookingID = 3 
  AND  T2.BookingID = T1.BookingID 
  AND  T3.BookingID = T2.BookingID 
  AND  T3.ItemNo = T2.ItemNo 
  AND  T4.AirportID = T6.AirportID1 
  AND  T5.AirportID = T7.AirportID2 
  AND  T6.SubRouteID = T8.SubRouteID 
	AND  T7.SubRouteID = T9.SubRouteID 
		 AND  T8.FlightID = T2.FlightID 
			AND  T9.FlightID = T2.FlightID 
	 AND  T8.idx = T2.SrcIdx 
AND  T9.idx = T2.DesIdx 
AND  T10.ModelID = T11.ModelID 
   AND  T10.SeatNo = T3.SeatNo
   AND  T11.FlightID = T2.FlightID 
 GROUP BY T2.ItemNo, T2.FlightID, T2.Price, T4.AirportID, T4.AirportName, T5.AirportID, T5.AirportName
ORDER By T2.ItemNo