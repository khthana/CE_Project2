SELECT SC.*
FROM FlightSchedule SC, SubRoute sr1
WHERE 	3 <= (
	SELECT Count(*)
	FROM Flight F, Seat S
	WHERE	(F.FlightID = SC.FlightID) AND 
		(F.ModelID = S.ModelID) AND
		(F.AirlineID = 'AA') AND
	 	(S.Smoking = 0) AND 
		(S.Window = 0) AND
		(S.ClassID = 'E') AND 
		S.SeatNo NOT IN	(
				SELECT SB.SeatNo 
				FROM BookingDetail BD, SeatBooking SB, Booking B
				WHERE	(BD.BookingID = B.BookingID) AND
					(SB.BookingID = BD.BookingID) AND 
					(SB.ItemNo = BD.ItemNo)AND
					(SB.SubItem = BD.SubItem) AND
					(BD.FlightID = SC.FlightID) AND
					(BD.SubRouteID = SC.SubRouteID) AND
					(BD.DepartDate = '1/1/2002') AND
					(B.ObSoleted = 0)
				)
	) AND 
	(sr1.AirportID1 = 'YVR') AND 
	(sr1.AirportID2 = 'DFW')  AND
	(SC.DepartTime BETWEEN '1899/12/30 12:00:00.000' AND '1899/12/30 14:00:00.000')