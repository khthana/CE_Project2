SELECT SC.*
FROM FlightSchedule SC, SubRoute sr1
WHERE 	0 < (
	SELECT COUNT(*)
	FROM Flight F, Seat S
	WHERE	(F.FlightID = SC.FlightID) AND 
		(F.ModelID = S.ModelID) AND
		(F.AirlineID = '0') AND
	 	(S.Smoking = 0) AND 
		(S.Window = 0) AND
		(S.ClassID = '0') AND 
		S.SeatNo NOT IN	(
				SELECT SB.SeatNo 
				FROM BookingDetail BD, SeatBooking SB, Booking B
				WHERE	(BD.BookingID = B.BookingID) AND
					(SB.BookingID = BD.BookingID) AND 
					(SB.ItemNo = BD.ItemNo)AND
					(SB.SubItem = BD.SubItem) AND
					(BD.FlightID = SC.FlightID) AND
					(BD.SubRouteID = SC.SubRouteID) AND
					(BD.DepartDate = ?) AND
					(B.ObSoleted = 0)
				)
	) AND 
	(sr1.AirportID1 = '0') AND 
	(sr1.AirportID2 = '0')