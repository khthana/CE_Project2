SELECT  T1.CompanyName, T14.ModelID, T14.ModelName, T3.DepartTime, 
	T4.ArriveTime, T3.RouteID, T7.Description, T3.Idx, T4.Idx, (SUM(T12.Distance)),            
	(SUM(T12.Distance * T13.PricePerKm)) + T13.Fee 
FROM    Company T1, BusSchedule T3, BusSchedule T4, BusSchedule T11,
	SubRoute T5, SubRoute T6, SubRoute T12, Route T7, BusModel T14, BusFee T13 
WHERE   T5.StationID1 = 'YVR' 
    AND T6.StationID2 = 'DFW' 
    AND T5.SubRouteID = T3.SubRouteID  
    AND T6.SubRouteID = T4.SubRouteID
    AND T12.SubRouteID = T11.SubRouteID  
    AND T3.RouteID = T4.RouteID  
    AND T11.RouteID = T3.RouteID  
    AND T7.RouteID = T3.RouteID  
    AND T11.Idx BETWEEN T3.Idx AND T4.Idx  
    AND T3.Idx <= T4.Idx  
    AND T1.CompanyID = T7.CompanyID  
    AND T13.CompanyID = T1.CompanyID  
    AND T14.ModelID = T7.ModelID  
    AND T14.ModelID = T13.ModelID  
    AND 0 <=   (SELECT COUNT(DISTINCT T8.SeatNo)            
		FROM     Seat T8
		WHERE    T7.ModelID = T8.ModelID
	              AND T8.SeatNo NOT IN (SELECT	DISTINCT T20.SeatNo                
					    FROM SeatBooking T20, BusSchedule T10
					    WHERE   (T20.DepartDate - T10.DepartDay + T3.DepartDay) = '2002-05-15'               
						AND T20.RouteID = T7.RouteID
				                AND T20.RouteID = T10.RouteID
				                AND T20.SubRouteID = T10.SubRouteID
					        AND T10.Idx >= T3.Idx
				                AND T10.Idx <= T4.Idx ) )
GROUP BY T1.CompanyName, T14.ModelID, T14.ModelName,
	 T3.DepartTime, T4.ArriveTime, T3.RouteID, T7.Description,
         T3.Idx, T4.Idx, T13.PricePerKm, T13.Fee