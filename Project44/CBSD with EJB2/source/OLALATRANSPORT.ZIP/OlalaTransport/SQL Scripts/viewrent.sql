SELECT T1.BusID, T1.CompanyID, T1.ModelID, T3.UsingDate, T4.RentCost
FROM   Bus T1, BusModel T2, BusRenting T3, BusFee T4
WHERE  T2.ModelID = T1.ModelID 
AND T4.ModelID = T1.ModelID 
AND T4.CompanyID = T1.CompanyID 
AND T3.BusID = T1.BusID
AND T3.BookingID = '52aa43d9-a1f6-05f2-000a-4d7c6dadd982'