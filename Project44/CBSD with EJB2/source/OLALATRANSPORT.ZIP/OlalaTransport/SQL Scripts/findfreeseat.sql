SELECT SeatNo
	FROM Flight F, Seat S
	WHERE	(F.FlightID = 'AA330') AND 
		(F.ModelID = S.ModelID) AND
		(F.AirlineID = 'AA') AND
	 	(S.Smoking = 0) AND 
		(S.Window = 0) AND
		(S.ClassID = 'F') AND 
		 S.SeatNo NOT IN (
				SELECT SeatNo
				FROM BookingDetail BD, SeatBooking SB, Booking B
				WHERE	(BD.BookingID = B.BookingID) AND
					(SB.BookingID = BD.BookingID) AND 
					(SB.ItemNo = BD.ItemNo)AND
					(SB.SubItem = BD.SubItem) AND
					(BD.FlightID = F.FlightID) AND
					(BD.SubRouteID = 6) AND
					(BD.DepartDate = '1/1/2002') AND
					(B.ObSoleted = 0)
				)
	
