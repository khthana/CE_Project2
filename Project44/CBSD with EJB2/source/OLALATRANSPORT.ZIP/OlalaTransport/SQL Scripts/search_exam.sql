// Search Statement of #36
SELECT		T1.CompanyName, T2.ClassName, T3.DepartTime, T4.ArriveTime, T3.RouteID, T3.Idx, T4.Idx, (SUM(T12.Distance) * T2.PricePerKm) + T13.Fee
FROM		BusCompany T1, BusClass T2, 
		RouteSubRoute T3,	RouteSubRoute T4,	RouteSubRoute T11, 
		SubRoute T5,		SubRoute T6,		SubRoute T12,
		Route T7, BusFee T13
WHERE		T5.SrcStation = ? AND T6.DstStation = ? AND 
		T5.SubRouteID = T3.SubRouteID AND 
		T6.SubRouteID = T4.SubRouteID AND 
		T12.SubRouteID = T11.SubRouteID AND 
		T3.RouteID = T4.RouteID AND 
		T11.RouteID = T3.RouteID AND
		T7.RouteID = T3.RouteID AND 
		T11.Idx BETWEEN T3.Idx AND T4.Idx AND 
		T3.Idx <= T4.Idx AND 
		T1.CompanyID = T7.CompanyID AND 
		T2.ClassID = T7.ClassID AND 
		T13.CompanyID = T1.CompanyID AND 
		T13.ClassID = T2.ClassID AND 
		T7.CompanyID = ?  AND 
		T7.ClassID = ? AND 
		TotalSeat <=	(SELECT COUNT(DISTINCT T8.SeatNo)
				 FROM      Seat T8 
				 WHERE   T7.ModelID = T8.ModelID AND
				 strSelectedSeatType AND 
				 T8.SeatNo NOT IN  (SELECT	DISTINCT T9.SeatNo
						    FROM	SubRouteBooking T9, RouteSubRoute T10
						    WHERE	T9.DepartDate = NewDepartDate AND 
								T9.RouteID = T7.RouteID AND 
								T9.RouteID = T10.RouteID AND 
								T9.SubRouteID = T10.SubRouteID AND
								T10.Idx >= T3.Idx AND 
								T10.Idx <=  T4.Idx 
						   )
				)
GROUP BY     T1.CompanyName, T2.ClassName, T3.DepartTime, T4.ArriveTime, T3.RouteID , T3.Idx, T4.Idx, T2.PricePerKm, T13.Fee 
