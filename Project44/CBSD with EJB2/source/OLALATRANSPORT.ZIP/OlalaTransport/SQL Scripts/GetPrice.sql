SELECT     MIN(T1.SeatNo) 
FROM       Seat T1, Flight T2 
WHERE      T2.FlightID = ?
       AND T2.ModelID = T1.ModelID 
       AND (T1.ClassID = ?) 
       AND (T1.Window | 1) = 1
       AND (T1.Smoking | 1) = 1
       AND T1.SeatNo NOT IN ( 
			SELECT     DISTINCT T3.SeatNo 
			FROM       SeatBooking T3, FlightSchedule T4 
			WHERE      T3.DepartDate = ? 
			       T4.FlightID = T2.FlightID 
			       AND T3.FlightID = T4.FlightID
			       AND T3.SubRouteID = T4.SubRouteID
			       AND T4.Idx >= 5 
			       AND T4.Idx <= 5 )

