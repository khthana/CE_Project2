SELECT		T1.AirlineName, T2.ClassID, T2.ClassName, T14.ModelName,
		T3.DepartTime, T4.ArriveTime, T3.FlightID, T7.Description, T3.Idx, T4.Idx, (SUM(T12.Distance)), (SUM(T12.Distance * T13.PricePerKm)) + T13.Fee
FROM		Airline T1, AircraftClass T2, 
		FlightSchedule T3, FlightSchedule T4, FlightSchedule T11, 
		SubRoute T5, SubRoute T6, SubRoute T12,
		Flight T7, ClassFee T13, AircraftModel T14

WHERE		T5.AirportID1 = 'YVR' AND T6.AirportID2 = 'DFW' AND 
		T5.SubRouteID = T3.SubRouteID AND 
		T6.SubRouteID = T4.SubRouteID AND 
		T12.SubRouteID = T11.SubRouteID AND 
		T3.FlightID = T4.FlightID AND 
		T11.FlightID = T3.FlightID AND
		T7.FlightID = T3.FlightID AND 
		T11.Idx BETWEEN T3.Idx AND T4.Idx AND 
		T3.Idx <= T4.Idx AND 
		T1.AirlineID = T7.AirlineID AND 
		T13.AirlineID = T1.AirlineID AND 
		T14.ModelID = T7.ModelID AND
		T13.ClassID = T2.ClassID AND
		T7.AirlineID = 'AA'  AND 
		3 <=	(SELECT COUNT(DISTINCT T8.SeatNo)
			 FROM      Seat T8 
			 WHERE   T7.ModelID = T8.ModelID AND
				 T8.ClassID = T13.ClassID AND
				 --strSelectedSeatType AND 
				 T8.SeatNo NOT IN  (SELECT	DISTINCT T20.SeatNo
						    FROM	BookingDetail T9, SeatBooking T20, FlightSchedule T10
						    WHERE	T20.BookingID = T9.BookingID AND
								T20.ItemNo =  T9.ItemNo AND
								T20.SubItem = T9.SubItem AND
								T9.DepartDate = '2002.12.30 at ' AND 
								T9.FlightID = T7.FlightID AND 
								T9.FlightID = T10.FlightID AND 
								T9.SubRouteID = T10.SubRouteID AND
								T10.Idx >= T3.Idx AND 
								T10.Idx <= T4.Idx 
						   )
			)
GROUP BY     T1.AirlineName, T2.ClassID,T2.ClassName, T14.ModelName, T3.DepartTime, T4.ArriveTime, T3.FlightID , T7.Description, T3.Idx, T4.Idx, T13.PricePerKm, T13.Fee 