SELECT SB.SeatNo 
				FROM BookingDetail BD, SeatBooking SB, Booking B
				WHERE	(BD.BookingID = B.BookingID) AND
					(SB.BookingID = BD.BookingID) AND 
					(SB.ItemNo = BD.ItemNo)AND
					(SB.SubItem = BD.SubItem) AND
					(BD.FlightID = 'AA330') AND
					(BD.SubRouteID = 6) AND
					(BD.DepartDate = '1/1/2002') AND
					(B.ObSoleted = 0)