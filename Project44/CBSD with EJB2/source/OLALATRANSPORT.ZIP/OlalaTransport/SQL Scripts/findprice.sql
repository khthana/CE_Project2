SELECT T1.FlightID, T2.ClassID, 
	SUM(T4.Distance) * T2.PriceperKm + T2.Fee 
FROM Flight T1, ClassFee T2, FlightSchedule T3, SubRoute T4
WHERE T2.AirlineID = T1.AirlineID 
  /*AND T2.ClassID = 'E' 
  AND T1.FlightID = 'AA330'*/
  AND T3.FlightID = T1.FlightID 
  AND T3.SubrouteID = T4.SubrouteID 
  AND T3.idx >= 1 
  AND T3.idx <= 1 
GROUP BY T1.FlightID, T2.ClassID, T2.PricePerKm, T2.Fee