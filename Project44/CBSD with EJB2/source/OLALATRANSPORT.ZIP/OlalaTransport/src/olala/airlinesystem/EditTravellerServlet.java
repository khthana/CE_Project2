package olala.airlinesystem;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Title:         EditTravellerServlet.java
 * Description:   Edit traveller information in shopping cart
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class EditTravellerServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String CART_PAGE = "../cart.jsp";

  /**Initialize global variables*/
  public void init() throws ServletException {
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    String referringPage = (String)request.getHeaders("Referer").nextElement();
    HttpSession session = request.getSession(true);
    int itemNo = Integer.parseInt(request.getParameter("itemNo"));
    String hasDepartPair = request.getParameter("hasDepartPair");
    System.out.println("EditTravellerServlet - Get session, request parameters, and referring page ... Done");

    ShoppingCart shoppingCart = (ShoppingCart) session.getAttribute("ShoppingCart");
    CartItem item = shoppingCart.itemAt(itemNo);

    item.RemoveAllTraveller();
    System.out.println("EditTravellerServlet - Remove old traveller informations ... Done");

    CartItem item2 = null;
    if (hasDepartPair.equals("T")) {
      item2 = shoppingCart.itemAt(itemNo-1);
      item2.RemoveAllTraveller();
    }

    int seats = item.getSeats();
    TravellerVO travellerVO = null;
    for (int i = 1; i <= seats; i++) {
      String firstname = request.getParameter("firstname" + i);
      String lastname = request.getParameter("lastname" + i);
      if (firstname == null) { firstname = ""; }
      if (lastname == null)  { lastname = ""; }
      travellerVO = new TravellerVO("", firstname, lastname);
      item.AddTraveller(travellerVO);

      // -------------- If Roundtrip, have to set extra CartItem too -------------- //
      if (hasDepartPair.equals("T")) {
        item2.AddTraveller(travellerVO);
        System.out.println("loop# : " + i);
        System.out.println(firstname + " " + lastname);
      }
    }

    System.out.println("EditTravellerServlet - Add new traveller informations ... Done");

    session.setAttribute("ShoppingCart", shoppingCart);
    System.out.println("EditTravellerServlet - Store new cart back to session ... Done");

    response.sendRedirect(response.encodeURL(CART_PAGE));
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}
