package olala.airlinesystem;
import java.sql.Date;
import java.util.*;
import java.io.*;


public class ReserveItem implements Serializable{
  private static final int TIS = 1;
  private static final int RSRIS = 1;

  private String flightID;
  private String classID;
  private int seats;
  private int srcIdx;
  private int desIdx;
  private boolean smoking;
  private boolean window;
  private Date departDate;
  private Collection travellers = null;

  public ReserveItem() {
	travellers = new ArrayList(RSRIS);
  }

  public ReserveItem( String flightID,
                      String classID,
                      int seats,
		              int srcIdx,
                      int desIdx,
                      boolean smoking,
                      boolean window,
                      Date departDate)
  {
    travellers = new ArrayList(RSRIS);
    this.flightID = flightID;
    this.classID = classID;
    this.seats = seats;
    this.srcIdx = srcIdx;
    this.desIdx = desIdx;
    this.smoking = smoking;
    this.window = window;
    this.departDate = departDate;
  }

  public void AddTraveller(TravellerVO tv) {
    travellers.add(tv);
    // update total seat
//    totalseat = travellers.size();
  }
  public Collection getAllTraveller() {
    return travellers;
  }
  public void RemoveAllTraveller() {
    travellers = new ArrayList();
  }
  public boolean isValid() {
    boolean valid = true;
    if (travellers.size() != this.seats) {
      valid = false;
    }
    else {
      Iterator i = travellers.iterator();
      while(i.hasNext()) {
        TravellerVO travellerVO = (TravellerVO) i.next();
        if (travellerVO == null)                    { valid = false; }
        if (travellerVO.getFirstName().equals(""))  { valid = false; }
        if (travellerVO.getLastName().equals(""))   { valid = false; }
      }
    }
    return(valid);
  }
  public String getFlightID() {
    return flightID;
  }
  public String getClassID() {
    return classID;
  }
  public int getSeats() {
    return seats;
  }
  public int getSrcIdx() {
    return srcIdx;
  }
  public int getDesIdx() {
    return desIdx;
  }
  public boolean getSmoking() {
    return smoking;
  }
  public boolean getWindow() {
    return window;
  }
  public Date getDepartDate() {
    return departDate;
  }
  public void setFlightID(String flightID) {
    this.flightID = flightID;
  }
  public void setClassID(String classID) {
    this.classID = classID;
  }
  public void setSeats(int seats) {
    this.seats = seats;
  }
  public void setSrcIdx(int srcIdx) {
    this.srcIdx = srcIdx;
  }
  public void setDesIdx(int desIdx) {
    this.desIdx = desIdx;
  }
  public void setSmoking(boolean smoking) {
    this.smoking = smoking;
  }
  public void setWindow(boolean window) {
    this.window = window;
  }
  public void setDepartDate(Date departDate) {
    this.departDate = departDate;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}