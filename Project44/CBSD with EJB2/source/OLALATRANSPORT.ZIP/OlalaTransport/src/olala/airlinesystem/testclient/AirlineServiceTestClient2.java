package olala.airlinesystem.testclient;

import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.*;

import olala.airlinesystem.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirlineServiceTestClient2 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private AirlineServiceHome airlineServiceHome = null;
  private AirlineService airlineService = null;

  /**Construct the EJB test client*/
  public AirlineServiceTestClient2() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("AirlineService");

      //cast to Home interface
      airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public AirlineService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      airlineService = airlineServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + airlineService + ".");
    }
    return airlineService;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public void AddAirport(String airportID, String airportName, String city, String state, String country, String description, String imagePath) {
    if (airlineService == null) {
      System.out.println("Error in AddAirport(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddAirport(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddAirport(airportID, airportName, city, state, country, description, imagePath);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddAirport(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddAirport(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteAirport(String airportID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteAirport(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteAirport(" + airportID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteAirport(airportID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteAirport(" + airportID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteAirport(" + airportID + ")");
      }
      e.printStackTrace();
    }
  }

  public AirportVO GetAirport(String airportID) {
    AirportVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAirport(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAirport(" + airportID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAirport(airportID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAirport(" + airportID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAirport(" + airportID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAirport(" + airportID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllAirport() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllAirport(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllAirport()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllAirport();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllAirport()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllAirport()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllAirport(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void AddAirline(String airlineID, String airlineName, String description) {
    if (airlineService == null) {
      System.out.println("Error in AddAirline(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddAirline(" + airlineID + ", " + airlineName + ", " + description + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddAirline(airlineID, airlineName, description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddAirline(" + airlineID + ", " + airlineName + ", " + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddAirline(" + airlineID + ", " + airlineName + ", " + description + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteAirline(String airlineID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteAirline(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteAirline(" + airlineID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteAirline(airlineID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteAirline(" + airlineID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteAirline(" + airlineID + ")");
      }
      e.printStackTrace();
    }
  }

  public AirlineVO GetAirline(String airlineID) {
    AirlineVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAirline(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAirline(" + airlineID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAirline(airlineID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAirline(" + airlineID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAirline(" + airlineID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAirline(" + airlineID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllAirline() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllAirline(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllAirline()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllAirline();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllAirline()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllAirline()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllAirline(): " + returnValue + ".");
    }
    return returnValue;
  }

  public FlightVO GetFlight(String flightID) {
    FlightVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetFlight(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetFlight(" + flightID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetFlight(flightID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetFlight(" + flightID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetFlight(" + flightID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetFlight(" + flightID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllFlight() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllFlight(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllFlight()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllFlight();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllFlight()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllFlight()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllFlight(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void DeleteFlight(String flightID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteFlight(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteFlight(" + flightID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteFlight(flightID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteFlight(" + flightID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteFlight(" + flightID + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddFlight(String flightID, String description, String airlineID, String aircraftID, int flightDay) {
    if (airlineService == null) {
      System.out.println("Error in AddFlight(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddFlight(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddFlight(flightID, description, airlineID, aircraftID, flightDay);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddFlight(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddFlight(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + ")");
      }
      e.printStackTrace();
    }
  }

  public SubrouteVO GetSubroute(int subrouteID) {
    SubrouteVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetSubroute(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetSubroute(" + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetSubroute(subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetSubroute(" + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetSubroute(" + subrouteID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetSubroute(" + subrouteID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllSubroute() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllSubroute(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllSubroute()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllSubroute();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllSubroute()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllSubroute()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllSubroute(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void DeleteSubroute(int subrouteID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteSubroute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteSubroute(" + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteSubroute(subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteSubroute(" + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteSubroute(" + subrouteID + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddSubroute(int subrouteID, double distance, String airportID1, String airportID2) {
    if (airlineService == null) {
      System.out.println("Error in AddSubroute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddSubroute(" + subrouteID + ", " + distance + ", " + airportID1 + ", " + airportID2 + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddSubroute(subrouteID, distance, airportID1, airportID2);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddSubroute(" + subrouteID + ", " + distance + ", " + airportID1 + ", " + airportID2 + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddSubroute(" + subrouteID + ", " + distance + ", " + airportID1 + ", " + airportID2 + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddSubroute(double distance, String airportID1, String airportID2) {
    if (airlineService == null) {
      System.out.println("Error in AddSubroute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddSubroute(" + distance + ", " + airportID1 + ", " + airportID2 + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddSubroute(distance, airportID1, airportID2);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddSubroute(" + distance + ", " + airportID1 + ", " + airportID2 + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddSubroute(" + distance + ", " + airportID1 + ", " + airportID2 + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddFlightSchedule(String flightID, String subrouteID, String arriveTime, String departTime, int idx) {
    if (airlineService == null) {
      System.out.println("Error in AddFlightSchedule(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddFlightSchedule(" + flightID + ", " + subrouteID + ", " + arriveTime + ", " + departTime + ", " + idx + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddFlightSchedule(flightID, subrouteID, arriveTime, departTime, idx);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddFlightSchedule(" + flightID + ", " + subrouteID + ", " + arriveTime + ", " + departTime + ", " + idx + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddFlightSchedule(" + flightID + ", " + subrouteID + ", " + arriveTime + ", " + departTime + ", " + idx + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteFlightSchedule(String flightID, String subrouteID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteFlightSchedule(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteFlightSchedule(" + flightID + ", " + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteFlightSchedule(flightID, subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteFlightSchedule(" + flightID + ", " + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteFlightSchedule(" + flightID + ", " + subrouteID + ")");
      }
      e.printStackTrace();
    }
  }

  public Collection GetAllFlightSchedule() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllFlightSchedule(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllFlightSchedule()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllFlightSchedule();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllFlightSchedule()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllFlightSchedule()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllFlightSchedule(): " + returnValue + ".");
    }
    return returnValue;
  }

  public FlightScheduleVO GetFlightSchedule(String flightID, String subrouteID) {
    FlightScheduleVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetFlightSchedule(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetFlightSchedule(" + flightID + ", " + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetFlightSchedule(flightID, subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetFlightSchedule(" + flightID + ", " + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetFlightSchedule(" + flightID + ", " + subrouteID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetFlightSchedule(" + flightID + ", " + subrouteID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public void AddAircraftClass(String classID, String className, String description) {
    if (airlineService == null) {
      System.out.println("Error in AddAircraftClass(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddAircraftClass(" + classID + ", " + className + ", " + description + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddAircraftClass(classID, className, description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddAircraftClass(" + classID + ", " + className + ", " + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddAircraftClass(" + classID + ", " + className + ", " + description + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteAircraftClass(String classID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteAircraftClass(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteAircraftClass(" + classID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteAircraftClass(classID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteAircraftClass(" + classID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteAircraftClass(" + classID + ")");
      }
      e.printStackTrace();
    }
  }

  public AircraftClassVO GetAircraftClass(String classID) {
    AircraftClassVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAircraftClass(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAircraftClass(" + classID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAircraftClass(classID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAircraftClass(" + classID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAircraftClass(" + classID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAircraftClass(" + classID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllAircraftClass() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllAircraftClass(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllAircraftClass()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllAircraftClass();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllAircraftClass()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllAircraftClass()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllAircraftClass(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void AddAircraftModel(String modelID, String modelName, int totalSeat) {
    if (airlineService == null) {
      System.out.println("Error in AddAircraftModel(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddAircraftModel(" + modelID + ", " + modelName + ", " + totalSeat + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddAircraftModel(modelID, modelName, totalSeat);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddAircraftModel(" + modelID + ", " + modelName + ", " + totalSeat + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddAircraftModel(" + modelID + ", " + modelName + ", " + totalSeat + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteAircraftModel(String modelID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteAircraftModel(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteAircraftModel(" + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteAircraftModel(modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteAircraftModel(" + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteAircraftModel(" + modelID + ")");
      }
      e.printStackTrace();
    }
  }

  public AircraftModelVO GetAircraftModel(String modelID) {
    AircraftModelVO returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAircraftModel(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAircraftModel(" + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAircraftModel(modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAircraftModel(" + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAircraftModel(" + modelID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAircraftModel(" + modelID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllAircraftModel() {
    Collection returnValue = null;
    if (airlineService == null) {
      System.out.println("Error in GetAllAircraftModel(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllAircraftModel()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineService.GetAllAircraftModel();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllAircraftModel()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllAircraftModel()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllAircraftModel(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void testRemoteCallsWithDefaultArguments() {
    if (airlineService == null) {
      System.out.println("Error in testRemoteCallsWithDefaultArguments(): " + ERROR_NULL_REMOTE);
      return ;
    }
    AddAirport("" ,"" ,"" ,"" ,"" ,"" ,"");
    DeleteAirport("");
    GetAirport("");
    GetAllAirport();
    AddAirline("" ,"" ,"");
    DeleteAirline("");
    GetAirline("");
    GetAllAirline();
    GetFlight("");
    GetAllFlight();
    DeleteFlight("");
    AddFlight("" ,"" ,"" ,"" ,0);
    GetSubroute(0);
    GetAllSubroute();
    DeleteSubroute(0);
    AddSubroute(0 ,0f ,"" ,"");
    AddSubroute(0f ,"" ,"");
    AddFlightSchedule("" ,"" ,"" ,"" ,0);
    DeleteFlightSchedule("" ,"");
    GetAllFlightSchedule();
    GetFlightSchedule("" ,"");
    AddAircraftClass("" ,"" ,"");
    DeleteAircraftClass("");
    GetAircraftClass("");
    GetAllAircraftClass();
    AddAircraftModel("" ,"" ,0);
    DeleteAircraftModel("");
    GetAircraftModel("");
    GetAllAircraftModel();
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AirlineServiceTestClient2 client = new AirlineServiceTestClient2();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.

    try {
      Object ref;
      AirlineService as = client.create();
//      as.AddAirport("LON","London","","London","England","","");
//      as.AddSubroute(1342,"AKL", "CHC");
//      as.AddSubroute(25301,"SYD", "MEL");


      long startTime = 0;
      startTime = System.currentTimeMillis();

      Collection airportCollection = as.GetAllAirport();
      Iterator i = airportCollection.iterator();
      while(i.hasNext()) {
        AirportVO avo = (AirportVO) i.next();
        System.out.println(avo.getAirportID());
        System.out.println(avo.getAirportName());
        System.out.println(avo.getCity());
        System.out.println(avo.getState());
        System.out.println(avo.getCountry());
        System.out.println(avo.getDescription());
        System.out.println(avo.getImagePath());
        System.out.println("=================");
      }

      Collection airlineCollection = as.GetAllAirline();
      i = airlineCollection.iterator();
      while(i.hasNext()) {
        AirlineVO airlineVO = (AirlineVO) i.next();
        System.out.println(airlineVO.getAirlineID());
        System.out.println(airlineVO.getAirlineName());
        System.out.println(airlineVO.getDescription());
        System.out.println("=================");
      }

      Collection flightCollection = as.GetAllFlight();
      i = flightCollection.iterator();
      while(i.hasNext()) {
        FlightVO flightVO = (FlightVO) i.next();
        System.out.println(flightVO.getFlightID());
        System.out.println(flightVO.getDescription());
        System.out.println(flightVO.getAirlineID());
        System.out.println(flightVO.getModelID());
        System.out.println(flightVO.getFlightDay());
        System.out.println("=================");
      }

      Collection subrouteCollection = as.GetAllSubroute();
      i = subrouteCollection.iterator();
      while(i.hasNext()) {
        SubrouteVO subrouteVO = (SubrouteVO) i.next();
        System.out.println(subrouteVO.getSubrouteID());
        System.out.println(subrouteVO.getDistance());
        System.out.println(subrouteVO.getAirportID1());
        System.out.println(subrouteVO.getAirportID2());
        System.out.println("=================");
      }

      Collection flightScheduleCollection = as.GetAllFlightSchedule();
      i = flightScheduleCollection.iterator();
      while(i.hasNext()) {
        FlightScheduleVO flightScheduleVO = (FlightScheduleVO) i.next();
        System.out.println(flightScheduleVO.getFlightID());
        System.out.println(flightScheduleVO.getSubrouteID());
        System.out.println(flightScheduleVO.getArriveTime());
        System.out.println(flightScheduleVO.getDepartTime());
        System.out.println(flightScheduleVO.getIdx());
        System.out.println("=================");
      }

      Collection aircraftClassCollection = as.GetAllAircraftClass();
      i = aircraftClassCollection.iterator();
      while(i.hasNext()) {
        AircraftClassVO aircraftClassVO = (AircraftClassVO) i.next();
        System.out.println(aircraftClassVO.getClassID());
        System.out.println(aircraftClassVO.getClassName());
        System.out.println(aircraftClassVO.getDescription());
        System.out.println("=================");
      }

      Collection aircraftModelCollection = as.GetAllAircraftModel();
      i = aircraftModelCollection.iterator();
      while(i.hasNext()) {
        AircraftModelVO amVO = (AircraftModelVO) i.next();
        System.out.println(amVO.getModelID());
        System.out.println(amVO.getModelName());
        System.out.println(amVO.getTotalSeat());
        System.out.println("=================");
      }

      long endTime = System.currentTimeMillis();
      System.out.println("Execution time: " + (endTime - startTime) + " ms.");

    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

  }
}