package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface FlightScheduleHome extends EJBHome {
  public FlightSchedule create(String flightID, int subrouteID, Time departTime, Time arriveTime, int departDay, int arriveDay, int idx) throws CreateException, RemoteException;
  public FlightSchedule create(String flightID, int subrouteID) throws RemoteException, CreateException;
  public FlightSchedule findByPrimaryKey(FlightSchedulePK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
