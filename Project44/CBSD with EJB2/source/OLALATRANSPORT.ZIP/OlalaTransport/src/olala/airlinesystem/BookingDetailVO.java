package olala.airlinesystem;
import java.sql.Date;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingDetailVO implements java.io.Serializable {
  private int itemNo;
  private String flightID;
  private Date departDate;
  private double price;
  private int srcIdx;
  private int desIdx;
  private int totalSeat;
  private String bookingID;

  public BookingDetailVO() {
  }
  public void setBookingID(String bookingID) {
    this.bookingID = bookingID;
  }
  public String getBookingID() {
    return bookingID;
  }
  public void setItemNo(int itemNo) {
	this.itemNo = itemNo;
  }

  public int getItemNo() {
    return itemNo;
  }
  public String getFlightID() {
    return flightID;
  }
  public void setFlightID(String flightID) {
    this.flightID = flightID;
  }
  public Date getDepartDate() {
    return departDate;
  }
  public void setDepartDate(Date departDate) {
    this.departDate = departDate;
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public int getSrcIdx() {
    return srcIdx;
  }
  public void setSrcIdx(int srcIdx) {
    this.srcIdx = srcIdx;
  }
  public int getDesIdx() {
    return desIdx;
  }
  public void setDesIdx(int desIdx) {
    this.desIdx = desIdx;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }
}