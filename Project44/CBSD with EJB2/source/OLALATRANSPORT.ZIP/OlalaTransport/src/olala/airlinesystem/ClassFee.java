package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;

public interface ClassFee extends EJBObject {
  public String getClassID() throws RemoteException;
  public String getAirlineID() throws RemoteException;
  public double getPricePerKm() throws RemoteException;
  public void setPricePerKm(double pricePerKm) throws RemoteException;
  public double getFee() throws RemoteException;
  public void setFee(double fee) throws RemoteException;
  public ClassFeeVO getClassFee() throws RemoteException;
}