package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

public interface TravellerHome extends EJBHome {
  public Traveller create(String travellerID, String firstName, String lastName) throws CreateException, RemoteException;
  public Traveller create(String travellerID) throws RemoteException, CreateException;
  public Traveller findByPrimaryKey(TravellerPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
