package olala.airlinesystem.testclient;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.Enumeration;

import olala.airlinesystem.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirportTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private AirportHome airportHome = null;
  private Airport airport = null;

  /**Construct the EJB test client*/
  public AirportTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("Airport");

      //cast to Home interface
      airportHome = (AirportHome) PortableRemoteObject.narrow(ref, AirportHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public Airport create(String airportID, String airportName, String city, String state, String country, String description, String imagePath) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      airport = airportHome.create(airportID, airportName, city, state, country, description, imagePath);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + "): " + airport + ".");
    }
    return airport;
  }

  public Airport create(String airportID) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + airportID + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      airport = airportHome.create(airportID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + airportID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + airportID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + airportID + "): " + airport + ".");
    }
    return airport;
  }

  public Airport findByPrimaryKey(String primaryKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primaryKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      airport = airportHome.findByPrimaryKey(primaryKey);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByPrimaryKey(" + primaryKey + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByPrimaryKey(" + primaryKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primaryKey + "): " + airport + ".");
    }
    return airport;
  }

  public Collection findAll() {
    Collection returnValue = null;
    long startTime = 0;
    if (logging) {
      log("Calling findAll()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airportHome.findAll();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findAll()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findAll()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findAll(): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getAirportID() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getAirportID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAirportID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getAirportID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAirportID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAirportID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAirportID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getAirportName() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getAirportName(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAirportName()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getAirportName();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAirportName()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAirportName()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAirportName(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAirportName(String airportName) {
    if (airport == null) {
      System.out.println("Error in setAirportName(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAirportName(" + airportName + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airport.setAirportName(airportName);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAirportName(" + airportName + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAirportName(" + airportName + ")");
      }
      e.printStackTrace();
    }
  }

  public String getCity() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getCity(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getCity()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getCity();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getCity()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getCity()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getCity(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setCity(String city) {
    if (airport == null) {
      System.out.println("Error in setCity(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setCity(" + city + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airport.setCity(city);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setCity(" + city + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setCity(" + city + ")");
      }
      e.printStackTrace();
    }
  }

  public String getState() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getState(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getState()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getState();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getState()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getState()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getState(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setState(String state) {
    if (airport == null) {
      System.out.println("Error in setState(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setState(" + state + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airport.setState(state);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setState(" + state + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setState(" + state + ")");
      }
      e.printStackTrace();
    }
  }

  public String getCountry() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getCountry(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getCountry()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getCountry();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getCountry()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getCountry()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getCountry(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setCountry(String country) {
    if (airport == null) {
      System.out.println("Error in setCountry(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setCountry(" + country + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airport.setCountry(country);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setCountry(" + country + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setCountry(" + country + ")");
      }
      e.printStackTrace();
    }
  }

  public String getDescription() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getDescription(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getDescription()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getDescription();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getDescription()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getDescription()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getDescription(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setDescription(String description) {
    if (airport == null) {
      System.out.println("Error in setDescription(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setDescription(" + description + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airport.setDescription(description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setDescription(" + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setDescription(" + description + ")");
      }
      e.printStackTrace();
    }
  }

  public String getImagePath() {
    String returnValue = "";
    if (airport == null) {
      System.out.println("Error in getImagePath(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getImagePath()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airport.getImagePath();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getImagePath()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getImagePath()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getImagePath(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setImagePath(String imagePath) {
    if (airport == null) {
      System.out.println("Error in setImagePath(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setImagePath(" + imagePath + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airport.setImagePath(imagePath);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setImagePath(" + imagePath + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setImagePath(" + imagePath + ")");
      }
      e.printStackTrace();
    }
  }

  public void testRemoteCallsWithDefaultArguments() {
    if (airport == null) {
      System.out.println("Error in testRemoteCallsWithDefaultArguments(): " + ERROR_NULL_REMOTE);
      return ;
    }
    getAirportID();
    getAirportName();
    setAirportName("");
    getCity();
    setCity("");
    getState();
    setState("");
    getCountry();
    setCountry("");
    getDescription();
    setDescription("");
    getImagePath();
    setImagePath("");
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }

  public void executeFindAll() {
    executeCollectionFinder(findAll());
  }

  public void executeCollectionFinder(Collection all) {
    try {
      Iterator iterator = all.iterator();
      while (iterator.hasNext()) {
        Object object = iterator.next();
        Airport airport = (Airport) PortableRemoteObject.narrow(object, Airport.class);
        log(airport.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void executeEnumerationFinder(Enumeration all) {
    try {
      while (all.hasMoreElements()) {
        Object object = all.nextElement();
        Airport airport = (Airport) PortableRemoteObject.narrow(object, Airport.class);
        log(airport.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AirportTestClient1 client = new AirportTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    // For quick access to all available records, you can use the
    // executeFindAll() method in this class.
    try {
      Airport a1 = client.findByPrimaryKey("BKK");
//      System.out.println(a1.getAirportName());

      AirportVO avo = a1.getAirport();
      System.out.println(avo.getAirportID());
      System.out.println(avo.getAirportName());
      System.out.println(avo.getCountry());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}