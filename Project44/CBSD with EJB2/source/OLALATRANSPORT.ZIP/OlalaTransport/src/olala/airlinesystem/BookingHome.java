package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

public interface BookingHome extends EJBHome {
  public Booking create(String bookingID, Integer transactionID, Timestamp transactionDate, String customerID, int confirmation, Timestamp confirmDeadline, boolean obsoleted) throws CreateException, RemoteException;
  public Booking findByPrimaryKey(BookingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
  public Collection findByCustomerID(String CustomerID) throws RemoteException, FinderException;
}
