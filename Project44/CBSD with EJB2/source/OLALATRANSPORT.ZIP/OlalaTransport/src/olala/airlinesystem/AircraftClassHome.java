package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AircraftClassHome extends EJBHome {
  public AircraftClass create(String classID, String className, String description) throws CreateException, RemoteException;
  public AircraftClass create(String classID) throws RemoteException, CreateException;
  public AircraftClass findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
