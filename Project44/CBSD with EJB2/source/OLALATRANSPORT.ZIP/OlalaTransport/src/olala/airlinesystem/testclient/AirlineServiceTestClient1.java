package olala.airlinesystem.testclient;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.*;

import olala.airlinesystem.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirlineServiceTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private AirlineServiceHome airlineServiceHome = null;
  private AirlineService airlineService = null;

  /**Construct the EJB test client*/
  public AirlineServiceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("AirlineService");

      //cast to Home interface
      airlineServiceHome = (AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public AirlineService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      airlineService = airlineServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + airlineService + ".");
    }
    return airlineService;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public void AddAirport(String airportID, String airportName, String city, String state, String country, String description, String imagePath) {
    if (airlineService == null) {
      System.out.println("Error in AddAirport(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddAirport(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.AddAirport(airportID, airportName, city, state, country, description, imagePath);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddAirport(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddAirport(" + airportID + ", " + airportName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteAirport(String airportID) {
    if (airlineService == null) {
      System.out.println("Error in DeleteAirport(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteAirport(" + airportID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airlineService.DeleteAirport(airportID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteAirport(" + airportID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteAirport(" + airportID + ")");
      }
      e.printStackTrace();
    }
  }

  public void testRemoteCallsWithDefaultArguments() {
    if (airlineService == null) {
      System.out.println("Error in testRemoteCallsWithDefaultArguments(): " + ERROR_NULL_REMOTE);
      return ;
    }
    AddAirport("" ,"" ,"" ,"" ,"" ,"" ,"");
    DeleteAirport("");
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AirlineServiceTestClient1 client = new AirlineServiceTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.

    try {
      Object ref;
      AirlineService as = client.create();
//      as.AddAirport("LON","London","","London","England","","");
//      as.AddSubroute(1342,"AKL", "CHC");
//      as.AddSubroute(25301,"SYD", "MEL");


      long startTime = 0;
      startTime = System.currentTimeMillis();

      Collection airportCollection = as.GetAllAirport();
      Iterator i = airportCollection.iterator();
      while(i.hasNext()) {
        AirportVO avo = (AirportVO) i.next();
        System.out.println(avo.getAirportID());
        System.out.println(avo.getAirportName());
        System.out.println(avo.getCity());
        System.out.println(avo.getState());
        System.out.println(avo.getCountry());
        System.out.println(avo.getDescription());
        System.out.println(avo.getImagePath());
        System.out.println("=================");
      }

      Collection airlineCollection = as.GetAllAirline();
      i = airlineCollection.iterator();
      while(i.hasNext()) {
        AirlineVO airlineVO = (AirlineVO) i.next();
        System.out.println(airlineVO.getAirlineID());
        System.out.println(airlineVO.getAirlineName());
        System.out.println(airlineVO.getDescription());
        System.out.println("=================");
      }

      Collection flightCollection = as.GetAllFlight();
      i = flightCollection.iterator();
      while(i.hasNext()) {
        FlightVO flightVO = (FlightVO) i.next();
        System.out.println(flightVO.getFlightID());
        System.out.println(flightVO.getDescription());
        System.out.println(flightVO.getAirlineID());
        System.out.println(flightVO.getModelID());
        System.out.println(flightVO.getFlightDay());
        System.out.println("=================");
      }

      Collection subrouteCollection = as.GetAllSubroute();
      i = subrouteCollection.iterator();
      while(i.hasNext()) {
        SubrouteVO subrouteVO = (SubrouteVO) i.next();
        System.out.println(subrouteVO.getSubrouteID());
        System.out.println(subrouteVO.getDistance());
        System.out.println(subrouteVO.getAirportID1());
        System.out.println(subrouteVO.getAirportID2());
        System.out.println("=================");
      }

      Collection flightScheduleCollection = as.GetAllFlightSchedule();
      i = flightScheduleCollection.iterator();
      while(i.hasNext()) {
        FlightScheduleVO flightScheduleVO = (FlightScheduleVO) i.next();
        System.out.println(flightScheduleVO.getFlightID());
        System.out.println(flightScheduleVO.getSubrouteID());
        System.out.println(flightScheduleVO.getArriveTime());
        System.out.println(flightScheduleVO.getDepartTime());
        System.out.println(flightScheduleVO.getIdx());
        System.out.println("=================");
      }

      Collection aircraftClassCollection = as.GetAllAircraftClass();
      i = aircraftClassCollection.iterator();
      while(i.hasNext()) {
        AircraftClassVO aircraftClassVO = (AircraftClassVO) i.next();
        System.out.println(aircraftClassVO.getClassID());
        System.out.println(aircraftClassVO.getClassName());
        System.out.println(aircraftClassVO.getDescription());
        System.out.println("=================");
      }

      Collection aircraftModelCollection = as.GetAllAircraftModel();
      i = aircraftModelCollection.iterator();
      while(i.hasNext()) {
        AircraftModelVO amVO = (AircraftModelVO) i.next();
        System.out.println(amVO.getModelID());
        System.out.println(amVO.getModelName());
        System.out.println(amVO.getTotalSeat());
        System.out.println("=================");
      }

      long endTime = System.currentTimeMillis();
      System.out.println("Execution time: " + (endTime - startTime) + " ms.");

    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}