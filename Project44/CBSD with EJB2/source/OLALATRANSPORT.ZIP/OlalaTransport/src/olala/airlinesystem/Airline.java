package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Airline extends EJBObject {
  public String getAirlineID() throws RemoteException;
  public String getAirlineName() throws RemoteException;
  public void setAirlineName(String airlineName) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public AirlineVO getAirline() throws RemoteException;
}
