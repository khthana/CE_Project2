package olala.airlinesystem;
import java.util.*;

/**
 * Title:         ShoppingCart.java
 * Description:   Shopping Cart
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class ShoppingCart {
  private Vector cartItem;

  public ShoppingCart() {
    cartItem = new Vector();
  }
  public CartItem itemAt(int index) {
    if (index >= cartItem.size()) {
      return null;
    }
    else {
      return (CartItem)cartItem.elementAt(index);
    }
  }
  public void add(CartItem item) {
    cartItem.addElement(item);
  }
  public void remove(int index) {
    cartItem.remove(index);
  }
/*
  public void setSeats(int index, int seats) {
    CartItem item = (CartItem) cartItem.elementAt(index);
    item.setSeats(seats);
  }
*/
  public int getTotalSeats() {
    int totalSeats = 0;
    Iterator i = cartItem.iterator();
    while (i.hasNext()) {
      CartItem item = (CartItem) i.next();
      totalSeats += item.getSeats();
    }
    return totalSeats;
  }
  public double getTotalPrice() {
    double totalPrice = 0;
    Iterator i = cartItem.iterator();
    while (i.hasNext()) {
      CartItem item = (CartItem) i.next();
      totalPrice += (item.getSeats() * item.getPrice());
    }
    return totalPrice;
  }
  public int size() {
    return cartItem.size();
  }
  public Collection toReserveItemCollection() {
    Vector reserveItemCollection = new Vector();
    Iterator i = cartItem.iterator();
    while (i.hasNext()) {
      // Downcast CartItem to ReserveItem
      ReserveItem reserveItem = (ReserveItem) i.next();
      reserveItemCollection.addElement(reserveItem);
    }
    return reserveItemCollection;
  }
  public boolean isValid() {
    boolean valid = true;
    Iterator i = cartItem.iterator();
    while (i.hasNext()) {
      CartItem item = (CartItem) i.next();
      if (!item.isValid()) {
        valid = false;
      }
    }
    return valid;
  }
}