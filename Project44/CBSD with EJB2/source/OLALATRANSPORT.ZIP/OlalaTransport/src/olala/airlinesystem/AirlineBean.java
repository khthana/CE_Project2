package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirlineBean implements EntityBean {
  EntityContext entityContext;
  public String airlineID;
  public String airlineName;
  public String description;
  public String ejbCreate(String airlineID, String airlineName, String description) throws CreateException, RemoteException {
    this.airlineID = airlineID;
    this.airlineName = airlineName;
    this.description = description;
    return null;
  }
  public String ejbCreate(String airlineID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(airlineID, null, null);
  }
  public void ejbPostCreate(String airlineID, String airlineName, String description) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String airlineID) throws CreateException, RemoteException {
    ejbPostCreate(airlineID, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }

  public String getAirlineID() {
    return airlineID;
  }
  public String getAirlineName() {
    return airlineName;
  }
  public void setAirlineName(String airlineName) {
    this.airlineName = airlineName;
  }
  public String getDescription() {
    return description;
  }

  public AirlineVO getAirline() {
    AirlineVO airlineVO = new AirlineVO();
    airlineVO.setAirlineID(this.airlineID);
    airlineVO.setAirlineName(this.airlineName);
    airlineVO.setDescription(this.description);
    return(airlineVO);
  }

  public void setDescription(String description) {
    this.description = description;
  }
}
