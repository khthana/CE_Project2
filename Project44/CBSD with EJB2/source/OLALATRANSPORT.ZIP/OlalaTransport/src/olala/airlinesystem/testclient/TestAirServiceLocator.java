package olala.airlinesystem.testclient;

import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import javax.naming.*;

import olala.util.*;
import olala.airlinesystem.*;
import olala.airlinesystem.testclient.*;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class TestAirServiceLocator {

  public static long starttime, stoptime;

  public static void start() {
	starttime = System.currentTimeMillis();
  }
  public static void stop() {
	stoptime = System.currentTimeMillis();
  }
  public static void reporttime() {
	System.out.println("Ellapse times = " + (stoptime - starttime));
  }
  public static void log(String msg) {
	//System.out.println(msg);
  }

  public static void main (String args[]) throws Exception
  {
	try {
	  System.out.println("Creating new Instance of AirServiceLocator");
	  start();
	  AirServiceLocator asl = AirServiceLocator.getInstance();


	  System.out.println(asl);
	  System.out.println(asl.getContext());
	  stop();
	  reporttime();

	  System.out.println("Lookup EJBHome(s) from ServiceLocator");
	  start();
	  AirlineServiceHome asHome = asl.getAirlineServiceHome();
	  BookingServiceHome bsHome = asl.getBookingServiceHome();
	  CustomerServiceHome csHome = asl.getCustomerServiceHome();
	  stop();
	  reporttime();

      // Create Instace of Remote Object
	  System.out.println("Test Create Remote Object, EJBHome.create()");
	  start();
	  log(csHome.create().toString());
	  log(bsHome.create().toString());
	  log(asHome.create().toString());
	  stop();
	  reporttime();

	  for (int i=0; i<20; i++) {
	      //System.out.println("Trying to locate Home again..");
		start();
	    asHome = asl.getAirlineServiceHome();
	    bsHome = asl.getBookingServiceHome();
	    csHome = asl.getCustomerServiceHome();

		log("AirlineServiceHome = " + asHome);
	    log("BookingServiceHome = " + bsHome);
	    log("CustomerServiceHome = " + csHome);
		stop();
		reporttime();
	  }
	}
	catch (RemoteException re) {
	  System.out.println("Remote Exception ...");
	  re.printStackTrace();
	}
	catch (CreateException ce) {
	  System.out.println("Create Exception ...");
	  ce.printStackTrace();
	}
	catch (ServiceLocatorException sle) {
	  throw new Exception("Service Locator Error");
	}
  }
}