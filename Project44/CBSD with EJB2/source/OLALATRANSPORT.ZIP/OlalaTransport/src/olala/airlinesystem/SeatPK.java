package olala.airlinesystem;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SeatPK implements Serializable {

  public String seatNo;
  public String modelID;

  public SeatPK() {
  }

  public SeatPK(String seatNo, String modelID) {
    this.seatNo = seatNo;
    this.modelID = modelID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      SeatPK that = (SeatPK) obj;
      return this.seatNo.equals(that.seatNo) && this.modelID.equals(that.modelID);
    }
    return false;
  }
  public int hashCode() {
    return (seatNo + modelID).hashCode();
  }
}
