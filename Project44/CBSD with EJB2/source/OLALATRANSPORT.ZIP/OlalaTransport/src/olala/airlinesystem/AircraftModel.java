package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AircraftModel extends EJBObject {
  public String getModelID() throws RemoteException;
  public String getModelName() throws RemoteException;
  public void setModelName(String modelName) throws RemoteException;
  public int getTotalSeat() throws RemoteException;
  public void setTotalSeat(int totalSeat) throws RemoteException;
  public AircraftModelVO getAircraftModel() throws RemoteException;
}
