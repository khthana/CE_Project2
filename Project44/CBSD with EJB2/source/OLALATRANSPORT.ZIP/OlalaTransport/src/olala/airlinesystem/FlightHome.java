package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface FlightHome extends EJBHome {
  public Flight create(String flightID, String description, String airlineID, String modelID, int flightDay) throws CreateException, RemoteException;
  public Flight create(String flightID) throws RemoteException, CreateException;
  public Flight findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
