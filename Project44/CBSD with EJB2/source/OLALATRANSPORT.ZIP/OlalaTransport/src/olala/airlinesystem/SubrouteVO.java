package olala.airlinesystem;


import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SubrouteVO implements Serializable {

  private int subrouteID;
  private double distance;
  private String airportID1;
  private String airportID2;

  public SubrouteVO() {
  }
  public void setSubrouteID(int subrouteID) {
    this.subrouteID = subrouteID;
  }
  public int getSubrouteID() {
    return subrouteID;
  }
  public void setDistance(double distance) {
    this.distance = distance;
  }
  public double getDistance() {
    return distance;
  }
  public void setAirportID1(String airportID1) {
    this.airportID1 = airportID1;
  }
  public String getAirportID1() {
    return airportID1;
  }
  public void setAirportID2(String airportID2) {
    this.airportID2 = airportID2;
  }
  public String getAirportID2() {
    return airportID2;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}