package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface SubrouteHome extends EJBHome {
  public Subroute create(Integer subrouteID, double distance, String airportID1, String airportID2) throws CreateException, RemoteException;
  public Subroute create(Integer subrouteID) throws RemoteException, CreateException;
  public Subroute findByPrimaryKey(Integer primaryKey) throws RemoteException, FinderException;
  public Subroute findMaxID() throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
