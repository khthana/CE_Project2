package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.sql.Time;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FlightScheduleBean implements EntityBean {
  EntityContext entityContext;
  public String flightID;
  public Time arriveTime;
  public Time departTime;
  public int departDay;
  public int arriveDay;
  public int idx;
  public int subrouteID;
  public FlightSchedulePK ejbCreate(String flightID, int subrouteID, Time departTime, Time arriveTime, int departDay, int arriveDay, int idx) throws CreateException, RemoteException {
    this.flightID = flightID;
    this.subrouteID = subrouteID;
    this.arriveTime = arriveTime;
    this.departTime = departTime;
    this.departDay = departDay;
    this.arriveDay = arriveDay;
    this.idx = idx;
    return null;
  }
  public FlightSchedulePK ejbCreate(String flightID, int subrouteID) throws RemoteException, CreateException {
    return ejbCreate(flightID, subrouteID, null, null, 0, 0, 0);
  }
  public void ejbPostCreate(String flightID, int subrouteID, Time departTime, Time arriveTime, int departDay, int arriveDay, int idx) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String flightID, int subrouteID) throws CreateException, RemoteException {
    ejbPostCreate(flightID, subrouteID, null, null, 0, 0, 0);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getFlightID() {
    return flightID;
  }
  public int getSubrouteID() {
    return subrouteID;
  }
  public Time getArriveTime() {
    return arriveTime;
  }
  public void setArriveTime(Time arriveTime) {
    this.arriveTime = arriveTime;
  }
  public Time getDepartTime() {
    return departTime;
  }
  public void setDepartTime(Time departTime) {
    this.departTime = departTime;
  }
  public int getDepartDay() {
    return departDay;
  }
  public void setDepartDay(int departDay) {
    this.departDay = departDay;
  }
  public int getArriveDay() {
    return arriveDay;
  }
  public void setArriveDay(int arriveDay) {
    this.arriveDay = arriveDay;
  }
  public int getIdx() {
    return idx;
  }
  public void setIdx(int idx) {
    this.idx = idx;
  }

  public FlightScheduleVO getFlightSchedule() {
    FlightScheduleVO flightScheduleVO = new FlightScheduleVO();
    flightScheduleVO.setFlightID(this.flightID);
    flightScheduleVO.setSubrouteID(this.subrouteID);
    flightScheduleVO.setArriveTime(this.arriveTime);
    flightScheduleVO.setDepartTime(this.departTime);
    flightScheduleVO.setIdx(this.idx);
    return(flightScheduleVO);
  }
}
