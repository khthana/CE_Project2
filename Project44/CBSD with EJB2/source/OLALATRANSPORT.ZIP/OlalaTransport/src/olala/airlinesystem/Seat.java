package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Seat extends EJBObject {
  public String getSeatNo() throws RemoteException;
  public String getModelID() throws RemoteException;
  public boolean getSmoking() throws RemoteException;
  public void setSmoking(boolean smoking) throws RemoteException;
  public boolean getWindow() throws RemoteException;
  public void setWindow(boolean window) throws RemoteException;
  public String getClassID() throws RemoteException;
  public void setClassID(String classID) throws RemoteException;
  public SeatVO getSeat() throws RemoteException;
}
