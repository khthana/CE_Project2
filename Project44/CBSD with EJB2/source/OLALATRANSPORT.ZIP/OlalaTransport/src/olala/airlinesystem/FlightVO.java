package olala.airlinesystem;


import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FlightVO implements Serializable {

  private String flightID;
  private String description;
  private String airlineID;
  private String modelID;
  private int flightDay;

  public FlightVO() {
  }

  public void setFlightID(String flightID) {
    this.flightID = flightID;
  }
  public String getFlightID() {
    return flightID;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getDescription() {
    return description;
  }
  public  void setAirlineID(String airlineID) {
    this.airlineID = airlineID;
  }
  public String getAirlineID() {
    return airlineID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public String getModelID() {
    return modelID;
  }
  public void setFlightDay(int flightDay) {
    this.flightDay = flightDay;
  }
  public int getFlightDay() {
    return flightDay;
  }


  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
}