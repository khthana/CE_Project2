package olala.airlinesystem.testclient;


import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.Enumeration;

import olala.airlinesystem.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FlightTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private FlightHome flightHome = null;
  private Flight flight = null;

  /**Construct the EJB test client*/
  public FlightTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("Flight");

      //cast to Home interface
      flightHome = (FlightHome) PortableRemoteObject.narrow(ref, FlightHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public Flight create(String flightID, String description, String airlineID, String aircraftID, int flightDay) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      flight = flightHome.create(flightID, description, airlineID, aircraftID, flightDay);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + flightID + ", " + description + ", " + airlineID + ", " + aircraftID + ", " + flightDay + "): " + flight + ".");
    }
    return flight;
  }

  public Flight create(String flightID) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + flightID + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      flight = flightHome.create(flightID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + flightID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + flightID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + flightID + "): " + flight + ".");
    }
    return flight;
  }

  public Flight findByPrimaryKey(String primaryKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primaryKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      flight = flightHome.findByPrimaryKey(primaryKey);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByPrimaryKey(" + primaryKey + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByPrimaryKey(" + primaryKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primaryKey + "): " + flight + ".");
    }
    return flight;
  }

  public Collection findAll() {
    Collection returnValue = null;
    long startTime = 0;
    if (logging) {
      log("Calling findAll()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flightHome.findAll();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findAll()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findAll()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findAll(): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getFlightID() {
    String returnValue = "";
    if (flight == null) {
      System.out.println("Error in getFlightID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getFlightID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flight.getFlightID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getFlightID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getFlightID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getFlightID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getDescription() {
    String returnValue = "";
    if (flight == null) {
      System.out.println("Error in getDescription(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getDescription()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flight.getDescription();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getDescription()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getDescription()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getDescription(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setDescription(String description) {
    if (flight == null) {
      System.out.println("Error in setDescription(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setDescription(" + description + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      flight.setDescription(description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setDescription(" + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setDescription(" + description + ")");
      }
      e.printStackTrace();
    }
  }

  public String getAirlineID() {
    String returnValue = "";
    if (flight == null) {
      System.out.println("Error in getAirlineID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAirlineID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flight.getAirlineID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAirlineID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAirlineID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAirlineID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAirlineID(String airlineID) {
    if (flight == null) {
      System.out.println("Error in setAirlineID(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAirlineID(" + airlineID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      flight.setAirlineID(airlineID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAirlineID(" + airlineID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAirlineID(" + airlineID + ")");
      }
      e.printStackTrace();
    }
  }

  public String getAircraftID() {
    String returnValue = "";
    if (flight == null) {
      System.out.println("Error in getAircraftID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAircraftID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flight.getAircraftID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAircraftID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAircraftID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAircraftID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAircraftID(String aircraftID) {
    if (flight == null) {
      System.out.println("Error in setAircraftID(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAircraftID(" + aircraftID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      flight.setAircraftID(aircraftID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAircraftID(" + aircraftID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAircraftID(" + aircraftID + ")");
      }
      e.printStackTrace();
    }
  }

  public int getFlightDay() {
    int returnValue = 0;
    if (flight == null) {
      System.out.println("Error in getFlightDay(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getFlightDay()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flight.getFlightDay();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getFlightDay()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getFlightDay()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getFlightDay(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setFlightDay(int flightDay) {
    if (flight == null) {
      System.out.println("Error in setFlightDay(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setFlightDay(" + flightDay + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      flight.setFlightDay(flightDay);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setFlightDay(" + flightDay + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setFlightDay(" + flightDay + ")");
      }
      e.printStackTrace();
    }
  }

  public FlightVO getFlight() {
    FlightVO returnValue = null;
    if (flight == null) {
      System.out.println("Error in getFlight(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getFlight()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = flight.getFlight();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getFlight()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getFlight()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getFlight(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void testRemoteCallsWithDefaultArguments() {
    if (flight == null) {
      System.out.println("Error in testRemoteCallsWithDefaultArguments(): " + ERROR_NULL_REMOTE);
      return ;
    }
    getFlightID();
    getDescription();
    setDescription("");
    getAirlineID();
    setAirlineID("");
    getAircraftID();
    setAircraftID("");
    getFlightDay();
    setFlightDay(0);
    getFlight();
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }

  public void executeFindAll() {
    executeCollectionFinder(findAll());
  }

  public void executeCollectionFinder(Collection all) {
    try {
      Iterator iterator = all.iterator();
      while (iterator.hasNext()) {
        Object object = iterator.next();
        Flight flight = (Flight) PortableRemoteObject.narrow(object, Flight.class);
        log(flight.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void executeEnumerationFinder(Enumeration all) {
    try {
      while (all.hasMoreElements()) {
        Object object = all.nextElement();
        Flight flight = (Flight) PortableRemoteObject.narrow(object, Flight.class);
        log(flight.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    FlightTestClient1 client = new FlightTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    // For quick access to all available records, you can use the
    // executeFindAll() method in this class.

    try {
      Collection flightCollection = client.findAll();
      Iterator i = flightCollection.iterator();
      while(i.hasNext()) {
        Flight flight = (Flight) PortableRemoteObject.narrow(i.next(), Flight.class);
        FlightVO flightVO = flight.getFlight();
        System.out.println(flightVO.getFlightID());
        System.out.println(flightVO.getFlightDay());
      }

      Flight flight = client.findByPrimaryKey("TG030");
      System.out.println(flight.getFlightID());
      System.out.println(flight.getFlightDay());

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}