package olala.airlinesystem;
import java.io.*;

public class BookingPK implements Serializable {

  public String bookingID;

  public BookingPK() {
  }

  public BookingPK(String bookingID) {
    this.bookingID = bookingID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      BookingPK that = (BookingPK) obj;
      return this.bookingID.equals(that.bookingID);
    }
    return false;
  }
  public int hashCode() {
    return bookingID.hashCode();
  }
}
