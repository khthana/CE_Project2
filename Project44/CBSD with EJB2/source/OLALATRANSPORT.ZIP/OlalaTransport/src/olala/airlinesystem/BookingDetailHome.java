package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

public interface BookingDetailHome extends EJBHome {
  public BookingDetail create(String bookingID, int itemNo, String flightID, Date departDate, double price, int srcIdx, int desIdx, int totalSeat) throws CreateException, RemoteException;
  public BookingDetail create(String bookingID, int itemNo) throws RemoteException, CreateException;
  public BookingDetail findByPrimaryKey(BookingDetailPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
  public Collection findByBookingID(String bookingID) throws RemoteException, FinderException;
}
