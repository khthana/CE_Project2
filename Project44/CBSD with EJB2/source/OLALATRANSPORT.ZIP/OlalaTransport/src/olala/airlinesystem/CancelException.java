package olala.airlinesystem;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CancelException extends Exception {
  public CancelException() {
  }
  public CancelException(String msg) {
	super(msg);
  }
}