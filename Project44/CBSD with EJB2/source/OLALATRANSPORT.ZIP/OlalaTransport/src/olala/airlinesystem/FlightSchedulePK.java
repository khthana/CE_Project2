package olala.airlinesystem;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FlightSchedulePK implements Serializable {

  public String flightID;
  public int subrouteID;

  public FlightSchedulePK() {
  }

  public FlightSchedulePK(String flightID, int subrouteID) {
    this.flightID = flightID;
    this.subrouteID = subrouteID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      FlightSchedulePK that = (FlightSchedulePK) obj;
      return this.flightID.equals(that.flightID) && this.subrouteID == subrouteID;
    }
    return false;
  }
  public int hashCode() {
    return (flightID + subrouteID).hashCode();
  }
}
