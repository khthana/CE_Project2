package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

public interface ClassFeeHome extends EJBHome {
  public ClassFee create(String classID, String airlineID, double pricePerKm, double fee) throws CreateException, RemoteException;
  public ClassFee create(String classID, String airlineID) throws RemoteException, CreateException;
  public ClassFee findByPrimaryKey(ClassFeePK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}