package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AircraftClass extends EJBObject {
  public String getClassID() throws RemoteException;
  public String getClassName() throws RemoteException;
  public void setClassName(String className) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public AircraftClassVO getAircraftClass() throws RemoteException;
}
