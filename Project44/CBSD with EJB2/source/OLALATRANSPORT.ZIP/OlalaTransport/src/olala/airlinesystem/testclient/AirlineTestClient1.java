package olala.airlinesystem.testclient;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.Enumeration;

import olala.airlinesystem.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirlineTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private AirlineHome airlineHome = null;
  private Airline airline = null;

  /**Construct the EJB test client*/
  public AirlineTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("Airline");

      //cast to Home interface
      airlineHome = (AirlineHome) PortableRemoteObject.narrow(ref, AirlineHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public Airline create(String airlineID, String airlineName, String description) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + airlineID + ", " + airlineName + ", " + description + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      airline = airlineHome.create(airlineID, airlineName, description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + airlineID + ", " + airlineName + ", " + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + airlineID + ", " + airlineName + ", " + description + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + airlineID + ", " + airlineName + ", " + description + "): " + airline + ".");
    }
    return airline;
  }

  public Airline create(String airlineID) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + airlineID + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      airline = airlineHome.create(airlineID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + airlineID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + airlineID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + airlineID + "): " + airline + ".");
    }
    return airline;
  }

  public Airline findByPrimaryKey(String primaryKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primaryKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      airline = airlineHome.findByPrimaryKey(primaryKey);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByPrimaryKey(" + primaryKey + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByPrimaryKey(" + primaryKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primaryKey + "): " + airline + ".");
    }
    return airline;
  }

  public Collection findAll() {
    Collection returnValue = null;
    long startTime = 0;
    if (logging) {
      log("Calling findAll()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airlineHome.findAll();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findAll()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findAll()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findAll(): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getAirlineID() {
    String returnValue = "";
    if (airline == null) {
      System.out.println("Error in getAirlineID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAirlineID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airline.getAirlineID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAirlineID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAirlineID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAirlineID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getAirlineName() {
    String returnValue = "";
    if (airline == null) {
      System.out.println("Error in getAirlineName(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAirlineName()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airline.getAirlineName();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAirlineName()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAirlineName()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAirlineName(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAirlineName(String airlineName) {
    if (airline == null) {
      System.out.println("Error in setAirlineName(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAirlineName(" + airlineName + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airline.setAirlineName(airlineName);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAirlineName(" + airlineName + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAirlineName(" + airlineName + ")");
      }
      e.printStackTrace();
    }
  }

  public String getDescription() {
    String returnValue = "";
    if (airline == null) {
      System.out.println("Error in getDescription(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getDescription()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airline.getDescription();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getDescription()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getDescription()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getDescription(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setDescription(String description) {
    if (airline == null) {
      System.out.println("Error in setDescription(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setDescription(" + description + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      airline.setDescription(description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setDescription(" + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setDescription(" + description + ")");
      }
      e.printStackTrace();
    }
  }

  public AirlineVO getAirline() {
    AirlineVO returnValue = null;
    if (airline == null) {
      System.out.println("Error in getAirline(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAirline()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = airline.getAirline();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAirline()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAirline()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAirline(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void testRemoteCallsWithDefaultArguments() {
    if (airline == null) {
      System.out.println("Error in testRemoteCallsWithDefaultArguments(): " + ERROR_NULL_REMOTE);
      return ;
    }
    getAirlineID();
    getAirlineName();
    setAirlineName("");
    getDescription();
    setDescription("");
    getAirline();
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }

  public void executeFindAll() {
    executeCollectionFinder(findAll());
  }

  public void executeCollectionFinder(Collection all) {
    try {
      Iterator iterator = all.iterator();
      while (iterator.hasNext()) {
        Object object = iterator.next();
        Airline airline = (Airline) PortableRemoteObject.narrow(object, Airline.class);
        log(airline.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void executeEnumerationFinder(Enumeration all) {
    try {
      while (all.hasMoreElements()) {
        Object object = all.nextElement();
        Airline airline = (Airline) PortableRemoteObject.narrow(object, Airline.class);
        log(airline.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AirlineTestClient1 client = new AirlineTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    // For quick access to all available records, you can use the
    // executeFindAll() method in this class.

    try {
      Airline airline = client.findByPrimaryKey("TG");
//      System.out.println(airline.getAirlineID());
//      System.out.println(airline.getAirlineName());
//      System.out.println(airline.getDescription());

      Collection airlineCollection = client.findAll();
      Iterator i = airlineCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        airline = (Airline) PortableRemoteObject.narrow(obj, Airline.class);
        AirlineVO airlineVO = airline.getAirline();
        System.out.println(airlineVO.getAirlineID());
        System.out.println(airlineVO.getAirlineName());
        System.out.println(airlineVO.getDescription());
      }

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}