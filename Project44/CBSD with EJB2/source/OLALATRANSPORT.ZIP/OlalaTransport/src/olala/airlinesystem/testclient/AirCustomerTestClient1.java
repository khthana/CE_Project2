package olala.airlinesystem.testclient;

import olala.*;
import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.Enumeration;

public class AirCustomerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private CustomerHome customerHome = null;
  private Customer customer = null;

  /**Construct the EJB test client*/
  public AirCustomerTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("AirCustomer");

      //cast to Home interface
      customerHome = (CustomerHome) PortableRemoteObject.narrow(ref, CustomerHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public Customer create(String customerID, String firstName, String lastName, String gender, String address, String telephone, String emailAddress, String password, boolean agency) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      customer = customerHome.create(customerID, firstName, lastName, gender, address, telephone, emailAddress, password, agency);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + "): " + customer + ".");
    }
    return customer;
  }

  public Customer create(String customerID) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + customerID + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      customer = customerHome.create(customerID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + customerID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + customerID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + customerID + "): " + customer + ".");
    }
    return customer;
  }

  public Customer findByPrimaryKey(String primaryKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primaryKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      customer = customerHome.findByPrimaryKey(primaryKey);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByPrimaryKey(" + primaryKey + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByPrimaryKey(" + primaryKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primaryKey + "): " + customer + ".");
    }
    return customer;
  }

  public Collection findAll() {
    Collection returnValue = null;
    long startTime = 0;
    if (logging) {
      log("Calling findAll()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerHome.findAll();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findAll()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findAll()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findAll(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection findByEmailAddress(String emailAddress) {
    Collection returnValue = null;
    long startTime = 0;
    if (logging) {
      log("Calling findByEmailAddress(" + emailAddress + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerHome.findByEmailAddress(emailAddress);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByEmailAddress(" + emailAddress + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByEmailAddress(" + emailAddress + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByEmailAddress(" + emailAddress + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getCustomerID() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getCustomerID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getCustomerID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getCustomerID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getCustomerID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getCustomerID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getCustomerID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getFirstName() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getFirstName(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getFirstName()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getFirstName();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getFirstName()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getFirstName()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getFirstName(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setFirstName(String firstName) {
    if (customer == null) {
      System.out.println("Error in setFirstName(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setFirstName(" + firstName + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setFirstName(firstName);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setFirstName(" + firstName + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setFirstName(" + firstName + ")");
      }
      e.printStackTrace();
    }
  }

  public String getLastName() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getLastName(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getLastName()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getLastName();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getLastName()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getLastName()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getLastName(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setLastName(String lastName) {
    if (customer == null) {
      System.out.println("Error in setLastName(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setLastName(" + lastName + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setLastName(lastName);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setLastName(" + lastName + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setLastName(" + lastName + ")");
      }
      e.printStackTrace();
    }
  }

  public String getGender() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getGender(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getGender()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getGender();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getGender()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getGender()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getGender(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setGender(String gender) {
    if (customer == null) {
      System.out.println("Error in setGender(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setGender(" + gender + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setGender(gender);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setGender(" + gender + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setGender(" + gender + ")");
      }
      e.printStackTrace();
    }
  }

  public String getAddress() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getAddress(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAddress()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getAddress();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAddress()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAddress()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAddress(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAddress(String address) {
    if (customer == null) {
      System.out.println("Error in setAddress(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAddress(" + address + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setAddress(address);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAddress(" + address + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAddress(" + address + ")");
      }
      e.printStackTrace();
    }
  }

  public String getTelephone() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getTelephone(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getTelephone()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getTelephone();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getTelephone()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getTelephone()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getTelephone(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setTelephone(String telephone) {
    if (customer == null) {
      System.out.println("Error in setTelephone(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setTelephone(" + telephone + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setTelephone(telephone);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setTelephone(" + telephone + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setTelephone(" + telephone + ")");
      }
      e.printStackTrace();
    }
  }

  public String getEmailAddress() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getEmailAddress(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getEmailAddress()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getEmailAddress();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getEmailAddress()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getEmailAddress()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getEmailAddress(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setEmailAddress(String emailAddress) {
    if (customer == null) {
      System.out.println("Error in setEmailAddress(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setEmailAddress(" + emailAddress + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setEmailAddress(emailAddress);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setEmailAddress(" + emailAddress + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setEmailAddress(" + emailAddress + ")");
      }
      e.printStackTrace();
    }
  }

  public String getPassword() {
    String returnValue = "";
    if (customer == null) {
      System.out.println("Error in getPassword(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getPassword()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getPassword();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getPassword()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getPassword()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getPassword(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setPassword(String password) {
    if (customer == null) {
      System.out.println("Error in setPassword(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setPassword(" + password + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setPassword(password);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setPassword(" + password + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setPassword(" + password + ")");
      }
      e.printStackTrace();
    }
  }

  public boolean getAgency() {
    boolean returnValue = false;
    if (customer == null) {
      System.out.println("Error in getAgency(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAgency()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getAgency();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAgency()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAgency()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAgency(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAgency(boolean agency) {
    if (customer == null) {
      System.out.println("Error in setAgency(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAgency(" + agency + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setAgency(agency);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAgency(" + agency + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAgency(" + agency + ")");
      }
      e.printStackTrace();
    }
  }

  public CustomerVO getCustomer() {
    CustomerVO returnValue = null;
    if (customer == null) {
      System.out.println("Error in getCustomer(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getCustomer()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customer.getCustomer();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getCustomer()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getCustomer()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getCustomer(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setCustomer(CustomerVO cusVO) {
    if (customer == null) {
      System.out.println("Error in setCustomer(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setCustomer(" + cusVO + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      customer.setCustomer(cusVO);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setCustomer(" + cusVO + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setCustomer(" + cusVO + ")");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }

  public void executeFindAll() {
    executeCollectionFinder(findAll());
  }

  public void executeCollectionFinder(Collection all) {
    try {
      Iterator iterator = all.iterator();
      while (iterator.hasNext()) {
        Object object = iterator.next();
        Customer customer = (Customer) PortableRemoteObject.narrow(object, Customer.class);
        log(customer.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void executeEnumerationFinder(Enumeration all) {
    try {
      while (all.hasMoreElements()) {
        Object object = all.nextElement();
        Customer customer = (Customer) PortableRemoteObject.narrow(object, Customer.class);
        log(customer.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AirCustomerTestClient1 client = new AirCustomerTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    // For quick access to all available records, you can use the
    // executeFindAll() method in this class.
	//client.findByEmailAddress("tinnnapat@yahoo.com");
	/*CustomerVO cVO = */
	client.findByPrimaryKey("1");
	CustomerVO cVO = client.getCustomer();
	System.out.println("CustomerID : " + cVO.getCustomerID());
	System.out.println("FirstName : " + cVO.getFirstName());
	System.out.println("LastName :" +  cVO.getLastName());
	System.out.println("Address : " + cVO.getAddress());
	System.out.println("Telephone :" + cVO.getTelephone());
	System.out.println("EmailAddress :" +client.getEmailAddress());
  }
}