package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;

public class ClassFeeBean implements EntityBean {
  EntityContext entityContext;
  public String classID;
  public String airlineID;
  public double pricePerKm;
  public double fee;
  public ClassFeePK ejbCreate(String classID, String airlineID, double pricePerKm, double fee) throws CreateException, RemoteException {
    this.classID = classID;
    this.airlineID = airlineID;
    this.pricePerKm = pricePerKm;
    this.fee = fee;
    return null;
  }
  public ClassFeePK ejbCreate(String classID, String airlineID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(classID, airlineID, 0.0, 0.0);
  }
  public void ejbPostCreate(String classID, String airlineID, double pricePerKm, double fee) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String classID, String airlineID) throws CreateException, RemoteException {
    ejbPostCreate(classID, airlineID, 0.0, 0.0);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getClassID() {
    return classID;
  }
  public String getAirlineID() {
    return airlineID;
  }
  public double getPricePerKm() {
    return pricePerKm;
  }
  public void setPricePerKm(double pricePerKm) {
    this.pricePerKm = pricePerKm;
  }
  public double getFee() {
    return fee;
  }
  public void setFee(double fee) {
    this.fee = fee;
  }

  public ClassFeeVO getClassFee() {
	return new ClassFeeVO(classID, airlineID, pricePerKm, fee);
  }
}