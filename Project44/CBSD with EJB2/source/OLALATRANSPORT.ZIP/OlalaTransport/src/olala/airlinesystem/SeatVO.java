package olala.airlinesystem;


import java.io.*;
/**
 * Title:       Seat Value Object
 * Description: Helper class to hold all field in Entity Seat
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SeatVO implements Serializable {

  private String seatNo;
  private String modelID;
  private boolean smoking;
  private boolean window;
  private String classID;

  public SeatVO() {
  }
  // Member initialize Contructor
  public SeatVO(String seatNo, String modelID, boolean smoking, boolean window, String classID) {
    this.seatNo = seatNo;
    this.modelID = modelID;
    this.smoking = smoking;
    this.window = window;
    this.classID = classID;
  }

  public String getSeatNo() {
    return seatNo;
  }
  public void setSeatNo(String seatNo) {
    this.seatNo = seatNo;
  }
  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public boolean getSmoking() {
    return smoking;
  }
  public void setSmoking(boolean smoking) {
    this.smoking = smoking;
  }
  public boolean getWindow() {
    return window;
  }
  public void setWindow(boolean window) {
    this.window = window;
  }
  public String getClassID() {
    return classID;
  }
  public void setClassID(String classID) {
    this.classID = classID;
  }

  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
}