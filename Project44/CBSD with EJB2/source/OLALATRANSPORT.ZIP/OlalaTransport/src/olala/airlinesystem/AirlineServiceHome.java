package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AirlineServiceHome extends EJBHome {
  public AirlineService create() throws RemoteException, CreateException;
}
