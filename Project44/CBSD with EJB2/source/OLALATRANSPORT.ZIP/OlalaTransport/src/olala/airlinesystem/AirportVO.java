package olala.airlinesystem;

import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirportVO implements Serializable {

  private String airportID;
  private String airportName;
  private String city;
  private String state;
  private String country;
  private String description;
  private String imagePath;

  public AirportVO() {
  }

  public void setAirportID(String airportID) {
    this.airportID = airportID;
  }

  public String getAirportID() {
    return airportID;
  }

  public void setAirportName(String airportName) {
    this.airportName = airportName;
  }

  public String getAirportName() {
    return airportName;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getCity() {
    return city;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getState() {
    return state;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getCountry() {
    return country;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getDescription() {
    return description;
  }

  public void setImagePath(String imagePath) {
    this.imagePath = imagePath;
  }

  public String getImagePath() {
    return imagePath;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}