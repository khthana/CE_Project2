package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SeatBean implements EntityBean {
  EntityContext entityContext;
  public String seatNo;
  public String modelID;
  public boolean smoking;
  public boolean window;
  public String classID;
  public SeatPK ejbCreate(String seatNo, String modelID, boolean smoking, boolean window, String classID) throws CreateException, RemoteException {
    this.seatNo = seatNo;
    this.modelID = modelID;
    this.smoking = smoking;
    this.window = window;
    this.classID = classID;
    return null;
  }
  public SeatPK ejbCreate(String seatNo, String modelID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(seatNo, modelID, false, false, null);
  }
  public void ejbPostCreate(String seatNo, String modelID, boolean smoking, boolean window, String classID) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String seatNo, String modelID) throws CreateException, RemoteException {
    ejbPostCreate(seatNo, modelID, false, false, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getSeatNo() {
    return seatNo;
  }
  public String getModelID() {
    return modelID;
  }
  public boolean getSmoking() {
    return smoking;
  }
  public void setSmoking(boolean smoking) {
    this.smoking = smoking;
  }
  public boolean getWindow() {
    return window;
  }
  public void setWindow(boolean window) {
    this.window = window;
  }
  public String getClassID() {
    return classID;
  }
  public void setClassID(String classID) {
    this.classID = classID;
  }

  public SeatVO getSeat() {
	return new SeatVO(seatNo, modelID, smoking, window, classID);
  }
}
