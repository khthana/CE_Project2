package olala.airlinesystem;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class LogoutServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String REDIR_PAGE = "../index.jsp";
  /**Initialize global variables*/
  public void init() throws ServletException {
  }
  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);

    // Get session then invalidate
    HttpSession session = request.getSession(true);
    session.invalidate();

    // Send back to referring page
    String referringPage = (String)request.getHeaders("Referer").nextElement();
    response.sendRedirect(response.encodeURL(REDIR_PAGE));

  }

  /**Process the HTTP Post request*/
  // Handle GET and POST requests identically
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}
