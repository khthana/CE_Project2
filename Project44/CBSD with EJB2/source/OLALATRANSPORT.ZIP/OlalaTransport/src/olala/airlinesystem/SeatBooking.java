package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

public interface SeatBooking extends EJBObject {
  public String getBookingID() throws RemoteException;
  public void setBookingID(String bookingID) throws RemoteException;
  public int getItemNo() throws RemoteException;
  public void setItemNo(int itemNo) throws RemoteException;
  public String getFlightID() throws RemoteException;
  public int getSubRouteID() throws RemoteException;
  public String getSeatNo() throws RemoteException;
  public Date getDepartDate() throws RemoteException;
  public String getTravellerID() throws RemoteException;
  public void setTravellerID(String travellerID) throws RemoteException;
}
