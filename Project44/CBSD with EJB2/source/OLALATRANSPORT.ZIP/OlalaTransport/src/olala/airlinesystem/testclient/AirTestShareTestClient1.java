package olala.airlinesystem.testclient;

import olala.testshare.*;
import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.Enumeration;

public class AirTestShareTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private TestShareHome testShareHome = null;
  private TestShare testShare = null;

  /**Construct the EJB test client*/
  public AirTestShareTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BusTestShare");

      //cast to Home interface
      testShareHome = (TestShareHome) PortableRemoteObject.narrow(ref, TestShareHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public TestShare create(Integer personID, String address) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + personID + ", " + address + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      testShare = testShareHome.create(personID, address);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + personID + ", " + address + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + personID + ", " + address + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + personID + ", " + address + "): " + testShare + ".");
    }
    return testShare;
  }

  public TestShare create(Integer personID) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + personID + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      testShare = testShareHome.create(personID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + personID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + personID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + personID + "): " + testShare + ".");
    }
    return testShare;
  }

  public TestShare findByPrimaryKey(Integer primaryKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primaryKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      testShare = testShareHome.findByPrimaryKey(primaryKey);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByPrimaryKey(" + primaryKey + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByPrimaryKey(" + primaryKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primaryKey + "): " + testShare + ".");
    }
    return testShare;
  }

  public Collection findAll() {
    Collection returnValue = null;
    long startTime = 0;
    if (logging) {
      log("Calling findAll()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = testShareHome.findAll();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findAll()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findAll()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findAll(): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public Integer getPersonID() {
    Integer returnValue = null;
    if (testShare == null) {
      System.out.println("Error in getPersonID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getPersonID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = testShare.getPersonID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getPersonID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getPersonID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getPersonID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getAddress() {
    String returnValue = "";
    if (testShare == null) {
      System.out.println("Error in getAddress(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAddress()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = testShare.getAddress();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAddress()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAddress()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAddress(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAddress(String address) {
    if (testShare == null) {
      System.out.println("Error in setAddress(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAddress(" + address + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      testShare.setAddress(address);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: setAddress(" + address + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: setAddress(" + address + ")");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }

  public void executeFindAll() {
    executeCollectionFinder(findAll());
  }

  public void executeCollectionFinder(Collection all) {
    try {
      Iterator iterator = all.iterator();
      while (iterator.hasNext()) {
        Object object = iterator.next();
        TestShare testShare = (TestShare) PortableRemoteObject.narrow(object, TestShare.class);
        log(testShare.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void executeEnumerationFinder(Enumeration all) {
    try {
      while (all.hasMoreElements()) {
        Object object = all.nextElement();
        TestShare testShare = (TestShare) PortableRemoteObject.narrow(object, TestShare.class);
        log(testShare.toString());
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AirTestShareTestClient1 client = new AirTestShareTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    // For quick access to all available records, you can use the
    // executeFindAll() method in this class.
	client.create(new Integer(3), "Ladkrabang");
  }

  }