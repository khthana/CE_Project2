package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import javax.rmi.*;
import javax.naming.*;
import java.util.*;
import java.util.Date;
import javax.sql.*;
import java.sql.*;
import java.text.DateFormat;

/**
 * Title:         AirlineServiceBean.java
 * Description:   Airline Service Session Bean
 * Copyright:     Copyright (c) 2001
 * Company:       Kmit'L
 * @author        EJB Group
 * @version 1.0
 */

public class AirlineServiceBean implements SessionBean {
  // Caches the EJBHome in the Service Session Bean
  private SessionContext sessionContext;
  private AirportHome airportHome;
  private AirlineHome airlineHome;
  private FlightHome flightHome;
  private SubrouteHome subrouteHome;
  private FlightScheduleHome flightScheduleHome;
  private AircraftClassHome aircraftClassHome;
  private AircraftModelHome aircraftModelHome;
  private ClassFeeHome classFeeHome;
  private SeatHome seatHome;
  // The DataSouce object, use to connect to the Database through JDBC API
  private DataSource datasource;

  public void AddAirport(String airportID,
						 String airportName,
						 String city, String state,
						 String country,
						 String description,
						 String imagePath) throws RemoteException {
	try {
	  Airport airport = airportHome.create(airportID, airportName, city, state, country, description, imagePath);
	}
	catch (CreateException e) {
	  System.out.println("Error at airlineHome.create()");
      e.printStackTrace();
	  throw new EJBException();
	}
  }

  public void AddAirline(String airlineID, String airlineName, String description) throws RemoteException {
    try {
      Airline airline = airlineHome.create(airlineID, airlineName, description);
    }
    catch (CreateException e) {
      System.out.println("Error at airlineHome.create()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddFlight(String flightID, String description, String airlineID, String aircraftID, int flightDay) throws RemoteException {
    try {
      Flight flight = flightHome.create(flightID, description, airlineID, aircraftID, flightDay);
    }
    catch (CreateException e) {
      System.out.println("Error at flightHome.create()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddSubroute(int subrouteID, double distance, String airportID1, String airportID2) throws RemoteException {
    try {
      Subroute subroute = subrouteHome.create(new Integer(subrouteID), distance, airportID1, airportID2);
    }
    catch (CreateException ce) {
      System.out.println("Error at subrouteHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddSubroute(double distance, String airportID1, String airportID2) throws RemoteException {
    try {
      Subroute lastSubroute = subrouteHome.findMaxID();
      int maxID = lastSubroute.getSubrouteID().intValue();

      Subroute subroute = subrouteHome.create(new Integer(maxID + 1), distance, airportID1, airportID2);
    }
    catch (FinderException fe) {
      throw new EJBException();
    }
    catch (CreateException ce) {
      System.out.println("Error at subrouteHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddFlightSchedule(String flightID, int subrouteID, Time arriveTime, Time departTime, int arriveDay, int departDay, int idx) throws RemoteException {
    try {
      FlightSchedule flightSchedule = flightScheduleHome.create(flightID, subrouteID, departTime, arriveTime, departDay, arriveDay, idx);
    }
    catch (CreateException ce) {
      System.out.println("Error flightScheduleHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddAircraftClass(String classID, String className, String description) throws RemoteException {
    try {
      AircraftClass aircraftClass = aircraftClassHome.create(classID, className, description);
    }
    catch (CreateException ce) {
      System.out.println("Error aircraftClassHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddAircraftModel(String modelID, String modelName, int totalSeat) throws RemoteException {
    try {
      AircraftModel aircraftModel = aircraftModelHome.create(modelID, modelName, totalSeat);
    }
    catch (CreateException ce) {
      System.out.println("Error aircraftModelHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddClassFee(String classID, String airlineID, double pricePerKm, double fee) throws RemoteException {
	try {
	  ClassFee classFee = classFeeHome.create(classID, airlineID, pricePerKm, fee);
	}
	catch (CreateException ce) {
	  System.out.println("Error classFeeHome.create()");
	  ce.printStackTrace();
	  throw new EJBException();
	}
  }

  public void AddSeat( String seatNo, String modelID,
					   boolean smoking, boolean window, String classID) throws RemoteException {
	try {
	  Seat seat = seatHome.create(seatNo, modelID, smoking, window, classID);
	}
	catch (CreateException ce) {
	  System.out.println("Error seatHome.create()");
	  ce.printStackTrace();
	  throw new EJBException();
	}
  }

  public void DeleteAirport(String airportID) throws RemoteException {
    try {
      airportHome.remove(airportID);
    }
	catch (RemoveException e) {
      System.out.println("Error at airline.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteAirline(String airlineID) throws RemoteException {
    try {
      airlineHome.remove(airlineID);
    }
    catch (RemoveException e) {
      System.out.println("Error at airline.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteFlight(String flightID) throws RemoteException {
    try {
      flightHome.remove(flightID);
    }
    catch (RemoveException e) {
      System.out.println("Error at airline.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteSubroute(int subrouteID) throws RemoteException {
    try {
      subrouteHome.remove(new Integer(subrouteID));
    }
    catch (RemoveException e) {
      System.out.println("Error at subroute.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteFlightSchedule(String flightID, int subrouteID) throws RemoteException {
    try {
      FlightSchedulePK primaryKey = new FlightSchedulePK(flightID, subrouteID);
      flightScheduleHome.remove(primaryKey);
    }
    catch (RemoveException e) {
      System.out.println("Error at subroute.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteAircraftClass(String classID) throws RemoteException {
    try {
      aircraftClassHome.remove(classID);
    }
    catch (RemoveException e) {
      System.out.println("Error at aircraftClass.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteAircraftModel(String modelID) throws RemoteException {
    try {
      aircraftModelHome.remove(modelID);

    }
    catch (RemoveException e) {
      System.out.println("Error at aircraftModel.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteClassFee(String classID, String airlineID) throws RemoteException {
	try {
	  classFeeHome.remove(new ClassFeePK(classID, airlineID));
	}
	catch (RemoveException e) {
	  System.out.println("Error at removing a ClassFee");
	  e.printStackTrace();
	  throw new EJBException();
	}
  }

  public void DeleteSeat(String seatNo, String modelID) throws RemoteException {
	try {
	  seatHome.remove(new SeatPK(seatNo, modelID));
	}
	catch (RemoveException e) {
	  System.out.println("Error at removing a Seat");
	  e.printStackTrace();
	  throw new EJBException();
	}
  }

  public AirportVO GetAirport(String airportID) throws RemoteException {
    try {
      Airport airport = airportHome.findByPrimaryKey(airportID);
      return(airport.getAirport());
    }
    catch (FinderException e) {
      throw new EJBException();
    }
  }

  public AirlineVO GetAirline(String airlineID) throws RemoteException {
    try {
      Airline airline = airlineHome.findByPrimaryKey(airlineID);
      return(airline.getAirline());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public FlightVO GetFlight(String flightID) throws RemoteException {
    try {
      Flight flight = flightHome.findByPrimaryKey(flightID);
      return(flight.getFlight());
    }
    catch(FinderException e) {
	  throw new EJBException();
    }
  }

  public SubrouteVO  GetSubroute(int subrouteID) throws RemoteException {
    try {
      Subroute subroute = subrouteHome.findByPrimaryKey(new Integer(subrouteID));
      return(subroute.getSubroute());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public FlightScheduleVO GetFlightSchedule(String flightID, int subrouteID) throws RemoteException {
    try {
      FlightSchedulePK primaryKey = new FlightSchedulePK(flightID, subrouteID);
      FlightSchedule flightSchedule = flightScheduleHome.findByPrimaryKey(primaryKey);
      return(flightSchedule.getFlightSchedule());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public AircraftClassVO GetAircraftClass(String classID) throws RemoteException {
    try {
      AircraftClass aircraftClass = aircraftClassHome.findByPrimaryKey(classID);
      return(aircraftClass.getAircraftClass());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public AircraftModelVO GetAircraftModel(String modelID) throws RemoteException {
    try {
      AircraftModel aircraftModel = aircraftModelHome.findByPrimaryKey(modelID);
      return(aircraftModel.getAircraftModel());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public ClassFeeVO GetClassFee(String classID, String airlineID) throws RemoteException {
	try {
	  ClassFee classFee = classFeeHome.findByPrimaryKey(new ClassFeePK(classID, airlineID));
	  return ( classFee.getClassFee() );
	}
	catch (FinderException e) {
      throw new EJBException();
    }
  }
  public SeatVO GetSeat(String seatNo, String modelID) throws RemoteException {
	try {
	  Seat seat = seatHome.findByPrimaryKey(new SeatPK(seatNo, modelID));
	  return seat.getSeat();
	}
	catch (FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllAirport() throws RemoteException {
    Vector allAirportCollection = new Vector();
    try {
      Collection airportCollection = airportHome.findAll();
      Iterator i = airportCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        Airport airport = (Airport) PortableRemoteObject.narrow(obj, Airport.class);
        AirportVO airportVO = airport.getAirport();
        allAirportCollection.addElement(airportVO);
      }
      return(allAirportCollection);
    }
    catch (FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllAirline() throws RemoteException {
    System.out.println("GetAllAirline()");
    Vector allAirlineCollection = new Vector();
    try {
      Collection airlineCollection = airlineHome.findAll();
      Iterator i = airlineCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        Airline airline = (Airline) PortableRemoteObject.narrow(obj, Airline.class);
        AirlineVO airlineVO = airline.getAirline();
        allAirlineCollection.addElement(airlineVO);
      }
      return(allAirlineCollection);
    }
    catch (FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllFlight() throws RemoteException {
    Vector allFlightCollection = new Vector();
    try {
      Collection flightCollection = flightHome.findAll();
      Iterator i = flightCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        Flight flight = (Flight) PortableRemoteObject.narrow(obj, Flight.class);
        FlightVO flightVO = flight.getFlight();
        allFlightCollection.addElement(flightVO);
      }
      return(allFlightCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllSubroute() throws RemoteException {
    Vector allSubrouteCollection = new Vector();
    try {
      Collection subrouteCollection = subrouteHome.findAll();
      Iterator i = subrouteCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        Subroute subroute = (Subroute) PortableRemoteObject.narrow(obj, Subroute.class);
        SubrouteVO subrouteVO = subroute.getSubroute();
        allSubrouteCollection.addElement(subrouteVO);
      }
      return(allSubrouteCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllFlightSchedule() throws RemoteException {
    Vector allFlightScheduleCollection = new Vector();
    try {
      Collection flightScheduleCollection = flightScheduleHome.findAll();
      Iterator i = flightScheduleCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        FlightSchedule flightSchedule = (FlightSchedule) PortableRemoteObject.narrow(obj, FlightSchedule.class);
        FlightScheduleVO flightScheduleVO = flightSchedule.getFlightSchedule();
        allFlightScheduleCollection.addElement(flightScheduleVO);
      }
      return(allFlightScheduleCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllAircraftClass() throws RemoteException {
    Vector allAircraftClassCollection = new Vector();
    try {
      Collection aircraftClassCollection = aircraftClassHome.findAll();
      Iterator i = aircraftClassCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        AircraftClass aircraftClass = (AircraftClass) PortableRemoteObject.narrow(obj, AircraftClass.class);
        AircraftClassVO aircraftClassVO = aircraftClass.getAircraftClass();
        allAircraftClassCollection.addElement(aircraftClassVO);
      }
      return(allAircraftClassCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllAircraftModel() throws RemoteException {
    Vector allAircraftModelCollection = new Vector();
    try {
      Collection aircraftModelCollection = aircraftModelHome.findAll();
      Iterator i = aircraftModelCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        AircraftModel aircraftModel = (AircraftModel) PortableRemoteObject.narrow(obj, AircraftModel.class);
        AircraftModelVO amVO = aircraftModel.getAircraftModel();
        allAircraftModelCollection.addElement(amVO);
      }
      return(allAircraftModelCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllClassFee() throws RemoteException {
	Vector allClassFeeCollection = new Vector();
    try {
      Collection classFeeCollection = classFeeHome.findAll();
      Iterator i = classFeeCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        ClassFee classFee = (ClassFee) PortableRemoteObject.narrow(obj, ClassFee.class);
        ClassFeeVO cfVO = classFee.getClassFee();
        allClassFeeCollection.addElement(cfVO);
      }
      return(allClassFeeCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllSeat() throws RemoteException {
	Vector allSeatCollection = new Vector();
    try {
      Collection seatCollection = seatHome.findAll();
      Iterator i = seatCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        Seat seat = (Seat) PortableRemoteObject.narrow(obj, Seat.class);
        SeatVO stVO = seat.getSeat();
        allSeatCollection.addElement(stVO);
      }
      return(allSeatCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }

  }
  // This is new Method, Not implemented yet...
  // Search the Flight, Subroute, Date combination that suitable for you
  public Collection Search( String airportsrcID,
							String airportdesID,
							int totalseat,
							java.sql.Date departdate,
							java.sql.Time departtime,
							String airclass,
							String airline,
							boolean smoking,
							boolean window,
							boolean nonstoponly	)

  {
  	Connection connection = null;
    Statement statement = null;
	ResultSet rs = null;
    try {
      connection = datasource.getConnection();
	  System.out.println("Connected to DataSource");

	  // generate time querty condition

	  String strselectClass = null;
	  String strselectAirline = null;
	  String strselectWindow = null;
	  String strselectSmoking = null;
	  String strDepartDate = null;
	  String strselectDepartTime = null;
	  String strOrderBy = null;
	  String strCondition = null;

	  // generate departdate query string
	  java.util.Date today = new java.util.Date();
	  System.out.println("Current Date : " + today.toString() );
	  long k = today.getTime();
	  java.sql.Date dt= new java.sql.Date(k);
	  System.out.println("Current Date (SQL) : " + dt.toString());
	  if (departdate == null) {
		System.out.println("Date too Old");
	    throw new EJBException("Missing depart date");
	  }
	  else if (departdate.before(dt)){
		System.out.println("To late to search ... : the flight has gone!");
		return new ArrayList(); // return No result ..
	  }

	  strDepartDate = departdate.toString();

	  if (airportsrcID == null || airportdesID == null ) {
	    throw new EJBException("Missing Airport ID");
	  }
	  else if (airportsrcID.equals("") || airportdesID.equals("")) {
		throw new EJBException("Missing Airport ID");
	  }
	  // generate departtime query string
	  if (departtime == null) {
	    strselectDepartTime = "";
	  }
	  else {
		Time timeperiod = Time.valueOf("08:00:00");
		String strTime1 = departtime.toString();
		String strTime2 = new Time(departtime.getTime() + timeperiod.getTime()).toString();
	    strselectDepartTime = " AND T3.DepartTime BETWEEN " +
		"'1899-12-30 " + strTime1 + "' AND '1899-12-30 " + strTime2 + "' ";
	  }
	  System.out.println("StrSelectTime = " + strselectDepartTime);
	  // generate Class query string
	  if (airclass == null) {
	    strselectClass = "";
	  }
	  else if (airclass.equals("")) {
		strselectClass = "";
	  }
	  else {
		strselectClass = " AND T2.ClassID = '" + airclass + "' ";
	  }
	  System.out.println("StrSelectClass = " + strselectClass);
	  // generate Airline query string
	  if (airline == null ) {
	    strselectAirline = "";
	  }
	  else if (airline.equals("")) {
		strselectAirline = "";
	  }
	  else {
	    strselectAirline = " AND T7.AirlineID = '" + airline + "' ";
	  }
	  System.out.println("StrSelectAirline = " + strselectAirline);

	  if (window) {
		strselectWindow = " AND T8.Window = 1 ";
	  }
	  else {
		strselectWindow = "";
	  }
	  System.out.println("StrSelectWindow = " + strselectWindow);
	  // generate can smoking? query string
	  if (smoking) {
		strselectSmoking = " AND T8.Smoking = 1 ";
	  }
	  else {
		strselectSmoking = "";
	  }
	  System.out.println("StrSelectSmoking = " + strselectSmoking);
	  if (nonstoponly) {
	    strCondition = " HAVING  COUNT(DISTINCT T12.SubRouteID) = 1 ";
	  }
	  else {
	    strCondition = "";
	  }

	  System.out.println("StrCondition = " + strCondition);

	  strOrderBy = "";

	  System.out.println("StrOrderBy = " + strOrderBy);

	  String strStatement =
"SELECT	    T1.AirlineName, T2.ClassID, T2.ClassName, T14.ModelName, T3.DepartTime, T4.ArriveTime, " +
"           T3.FlightID, T7.Description, T3.Idx, T4.Idx, " +
"			(SUM(T12.Distance)), " +
"           (SUM(T12.Distance * T13.PricePerKm)) + T13.Fee " +
"FROM	    Airline T1, AircraftClass T2, " +
"           FlightSchedule T3, FlightSchedule T4, FlightSchedule T11, " +
"		    SubRoute T5, SubRoute T6, SubRoute T12, " +
"		    Flight T7, AircraftModel T14, ClassFee T13 " +
"WHERE	    T5.AirportID1 = '" + airportsrcID + "'" +
	  " AND T6.AirportID2 = '" + airportdesID + "'" +
	  " AND T5.SubRouteID = T3.SubRouteID " +
	  " AND T6.SubRouteID = T4.SubRouteID " +
	  " AND T12.SubRouteID = T11.SubRouteID " +
	  " AND T3.FlightID = T4.FlightID " +
	  " AND T11.FlightID = T3.FlightID " +
	  " AND T7.FlightID = T3.FlightID " +
	  " AND T11.Idx BETWEEN T3.Idx AND T4.Idx " +
	  " AND T3.Idx <= T4.Idx " +
	  strselectDepartTime +
	  " AND T1.AirlineID = T7.AirlineID " +
	  " AND T13.AirlineID = T1.AirlineID " +
	  " AND T14.ModelID = T7.ModelID " +
	  " AND T13.ClassID = T2.ClassID " +
	  strselectAirline + strselectClass +
	  " AND " + totalseat;

	  strStatement = strStatement +
				" <=	(SELECT COUNT(DISTINCT T8.SeatNo) " +
			    "	     FROM     Seat T8 " +
				"		 WHERE    T7.ModelID = T8.ModelID " +
				"             AND T8.ClassID = T2.ClassID " +
				strselectSmoking + strselectWindow +
				"             AND T8.SeatNo NOT IN  " +
				"              (SELECT	DISTINCT T20.SeatNo " +
				"               FROM	SeatBooking T20, FlightSchedule T10 " +
				"               WHERE	(T20.DepartDate - T10.DepartDay + T3.DepartDay) = '" + strDepartDate +"'" +
				"               AND T20.FlightID = T7.FlightID " +
				"               AND T20.FlightID = T10.FlightID " +
				"               AND T20.SubRouteID = T10.SubRouteID " +
				"               AND T10.Idx >= T3.Idx " +
				"               AND T10.Idx <= T4.Idx ) ) " +
" GROUP BY     T1.AirlineName, T2.ClassID, T2.ClassName, T14.ModelName, " +
"              T3.DepartTime, T4.ArriveTime, T3.FlightID, T7.Description, " +
"              T3.Idx, T4.Idx, T13.PricePerKm, T13.Fee " + strCondition + strOrderBy;

	  if (strStatement != null) {
	    System.out.println(strStatement);
	  }
	  else {
	    System.out.println("Error with statement string");
	  }
	  statement = connection.createStatement();
	  rs = statement.executeQuery(strStatement);
	  Collection searchresults = new ArrayList();
	  while (rs.next()) {
		  System.out.println("Found next Result!");
		 String _airlinename = rs.getString(1);
		 String _classid = rs.getString(2);
		 String _classname = rs.getString(3);
		 String _modelname = rs.getString(4);
		 java.sql.Time _departtime = rs.getTime(5);
		 java.sql.Time _arrivetime = rs.getTime(6);
		 String _flightid = rs.getString(7);
		 String _flightdescription = rs.getString(8);
		 int _srcidx = rs.getInt(9);
		 int _desidx = rs.getInt(10);
		 double _totaldistance = rs.getFloat(11);
		 double _totalprice = rs.getDouble(12);

		 AirSeatSearchResult sr = new AirSeatSearchResult(_airlinename,
														  _flightid,
														  _flightdescription,
														  _classid,
														  _classname,
														  _modelname,
														  _departtime,
														  _arrivetime,
														  _srcidx,
														  _desidx,
														  _totaldistance,
														  _totalprice );

		 // add new result row
		 System.out.println("Adding to Result Collection..");
		 searchresults.add(sr);
	  }
	  System.out.println("Finish all result");
	  return searchresults;
    }
    catch(SQLException e) {
	  e.printStackTrace();
      throw new EJBException("Error executing SQL SELECT");
    }
	finally {
	  try {
	    if (rs != null) { rs.close(); }
		if (statement != null) { statement.close();	}
		if (connection != null) { connection.close(); }
	  }
	  catch (SQLException e) { }
	}
  }
  public void ejbCreate() {
  }
  public void ejbRemove() throws RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setSessionContext(SessionContext sessionContext) throws RemoteException {
    this.sessionContext = sessionContext;

    try {
      Context ctx = new InitialContext();

      //look up jndi name and cast to Home interface
	  System.out.println("Looking up Component(s) Naming");
      airportHome         = (AirportHome)       PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Airport"), AirportHome.class);
      airlineHome         = (AirlineHome)       PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Airline"), AirlineHome.class);
      flightHome          = (FlightHome)        PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Flight"), FlightHome.class);
      subrouteHome        = (SubrouteHome)      PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Subroute"), SubrouteHome.class);
      flightScheduleHome  = (FlightScheduleHome)PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/FlightSchedule"), FlightScheduleHome.class);
      aircraftClassHome   = (AircraftClassHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/AircraftClass"), AircraftClassHome.class);
      aircraftModelHome   = (AircraftModelHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/AircraftModel"), AircraftModelHome.class);
	  classFeeHome        = (ClassFeeHome)      PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/ClassFee"), ClassFeeHome.class);
	  seatHome            = (SeatHome)          PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Seat"), SeatHome.class);
      datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/DataSource");
	  System.out.println("Done looking all Component(s)");
    }
    catch (javax.naming.NamingException ne) {
	  ne.printStackTrace();
      throw new RemoteException();
    }
  }
}
