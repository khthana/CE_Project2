package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AircraftModelHome extends EJBHome {
  public AircraftModel create(String modelID, String modelName, int totalSeat) throws CreateException, RemoteException;
  public AircraftModel create(String modelID) throws RemoteException, CreateException;
  public AircraftModel findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
