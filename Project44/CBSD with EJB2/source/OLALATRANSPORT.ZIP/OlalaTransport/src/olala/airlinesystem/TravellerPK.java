package olala.airlinesystem;
import java.io.*;

public class TravellerPK implements Serializable {

  public String travellerID;

  public TravellerPK() {
  }

  public TravellerPK(String travellerID) {
    this.travellerID = travellerID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      TravellerPK that = (TravellerPK) obj;
      return this.travellerID.equals(that.travellerID);
    }
    return false;
  }
  public int hashCode() {
    return travellerID.hashCode();
  }
}
