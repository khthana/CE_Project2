package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

public interface SeatBookingHome extends EJBHome {
  public SeatBooking create(String bookingID, int itemNo, String flightID, int subRouteID, String seatNo, Date departDate, String travellerID) throws CreateException, RemoteException;
  public SeatBooking create(String flightID, int subRouteID, String seatNo, Date departDate) throws RemoteException, CreateException;
  public SeatBooking findByPrimaryKey(SeatBookingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
