package olala.airlinesystem;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CartItem extends ReserveItem {
  private String departureAirportID;
  private String destinationAirportID;
  private Time departureTime;
  private Time arriveTime;
  private double unitprice;
  private boolean hasReturnPair;
  private boolean hasDepartPair;

  public CartItem(String flightID,
                  String classID,
                  int totalseat,
		  int srcidx,
                  int desidx,
                  boolean smoking,
		  boolean window,
                  Date departdate,
                  double unitprice,
                  // Shopping Cart Added..
                  String departureAirportID,
                  String destinationAirportID,
                  Time departureTime,
                  Time arriveTime,
                  boolean hasReturnPair,
                  boolean hasDepartPair)
                  {
    super(flightID, classID, totalseat, srcidx, desidx,
          smoking, window, departdate);
    this.departureAirportID = departureAirportID;
    this.destinationAirportID = destinationAirportID;
    this.departureTime = departureTime;
    this.arriveTime = arriveTime;
	this.unitprice = unitprice;
    this.hasReturnPair = hasReturnPair;
    this.hasDepartPair = hasDepartPair;
  }

  public String getDepartureAirportID() {
    return departureAirportID;
  }
  public String getDestinationAirportID() {
    return destinationAirportID;
  }
  public Time getDepartureTime() {
    return departureTime;
  }
  public Time getArriveTime() {
    return arriveTime;
  }
  public double getPrice() {
	return unitprice;
  }
  public boolean hasReturnPair() {
    return this.hasReturnPair;
  }
  public boolean hasDepartPair() {
    return this.hasDepartPair;
  }
  public void setReturnPair(boolean hasReturnPair) {
    this.hasReturnPair = hasReturnPair;
  }
  public void setDepartPair(boolean hasDepartPair) {
    this.hasDepartPair = hasDepartPair;
  }
}