package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

public interface Booking extends EJBObject {
  public String getBookingID() throws RemoteException;
  public Integer getTransactionID() throws RemoteException;
  public void setTransactionID(Integer transactionID) throws RemoteException;
  public Timestamp getTransactionDate() throws RemoteException;
  public void setTransactionDate(Timestamp transactionDate) throws RemoteException;
  public String getCustomerID() throws RemoteException;
  public void setCustomerID(String customerID) throws RemoteException;
  public int getConfirmation() throws RemoteException;
  public void setConfirmation(int confirmation) throws RemoteException;
  public boolean getObsoleted() throws RemoteException;
  public void setObsoleted(boolean obsoleted) throws RemoteException;
  public BookingVO getBooking() throws RemoteException;
}
