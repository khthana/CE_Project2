package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Subroute extends EJBObject {
  public Integer getSubrouteID() throws RemoteException;
  public double getDistance() throws RemoteException;
  public void setDistance(double distance) throws RemoteException;
  public String getAirportID1() throws RemoteException;
  public void setAirportID1(String airportID1) throws RemoteException;
  public String getAirportID2() throws RemoteException;
  public void setAirportID2(String airportID2) throws RemoteException;
  public SubrouteVO getSubroute() throws RemoteException;
}
