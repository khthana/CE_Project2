package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

public class SeatBookingBean implements EntityBean {
  EntityContext entityContext;
  public int itemNo;
  public String flightID;
  public int subRouteID;
  public String seatNo;
  public Timestamp departDate;
  public String bookingID;
  public String travellerID;
  public SeatBookingPK ejbCreate(String bookingID, int itemNo, String flightID, int subRouteID, String seatNo, Date departDate, String travellerID) throws CreateException, RemoteException {
    this.bookingID = bookingID;
    this.itemNo = itemNo;
    this.flightID = flightID;
    this.subRouteID = subRouteID;
    this.seatNo = seatNo;
    this.departDate = new Timestamp(departDate.getTime());
    this.travellerID = travellerID;
    return null;
  }
  public SeatBookingPK ejbCreate(String flightID, int subRouteID, String seatNo, Date departDate) throws RemoteException, CreateException, RemoteException {
    return ejbCreate("", 0, flightID, subRouteID, seatNo, departDate, null);
  }
  public void ejbPostCreate(String bookingID, int itemNo, String flightID, int subRouteID, String seatNo, Date departDate, String travellerID) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String flightID, int subRouteID, String seatNo, Date departDate) throws CreateException, RemoteException {
    ejbPostCreate("", 0, flightID, subRouteID, seatNo, departDate, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getBookingID() {
    return bookingID;
  }
  public void setBookingID(String newBookingID) {
    this.bookingID = bookingID;
  }
  public int getItemNo() {
    return itemNo;
  }
  public void setItemNo(int itemNo) {
    this.itemNo = itemNo;
  }
  public String getFlightID() {
    return flightID;
  }
  public int getSubRouteID() {
    return subRouteID;
  }
  public String getSeatNo() {
    return seatNo;
  }
  public Date getDepartDate() {
    return new Date(departDate.getTime());
  }
  public String getTravellerID() {
    return travellerID;
  }
  public void setTravellerID(String newTravellerID) {
    this.travellerID = travellerID;
  }
}
