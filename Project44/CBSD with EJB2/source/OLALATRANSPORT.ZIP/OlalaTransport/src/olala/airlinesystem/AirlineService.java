package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AirlineService extends EJBObject {

  public void AddAircraftClass(String classID, String className, String description) throws RemoteException;
  public void AddAircraftModel(String modelID, String modelName, int totalSeat) throws RemoteException;
  public void AddAirline(String airlineID, String airlineName, String description) throws RemoteException;
  public void AddAirport(String airportID, String airportName, String city, String state, String country, String description, String imagePath) throws RemoteException;
  public void AddClassFee(String classID, String airlineID, double pricePerKm, double fee) throws RemoteException;
  public void AddFlight(String flightID, String description, String airlineID, String aircraftID, int flightDay) throws RemoteException;
  public void AddFlightSchedule(String flightID, int subrouteID, java.sql.Time arriveTime, java.sql.Time departTime, int arriveDay, int departDay, int idx) throws RemoteException;
  public void AddSeat(String seatNo, String modelID, boolean smoking, boolean window, String classID) throws RemoteException;
  public void AddSubroute(double distance, String airportID1, String airportID2) throws RemoteException;
  public void AddSubroute(int subrouteID, double distance, String airportID1, String airportID2) throws RemoteException;

  public void DeleteAircraftClass(String classID) throws RemoteException;
  public void DeleteAircraftModel(String modelID) throws RemoteException;
  public void DeleteAirline(String airlineID) throws RemoteException;
  public void DeleteAirport(String airportID) throws RemoteException, RemoveException;
  public void DeleteClassFee(String classID, String airlineID) throws RemoteException;
  public void DeleteFlight(String flightID) throws RemoteException;
  public void DeleteFlightSchedule(String flightID, int subrouteID) throws RemoteException;
  public void DeleteSeat(String seatNo, String modelID) throws RemoteException;
  public void DeleteSubroute(int subrouteID) throws RemoteException;

  public AircraftClassVO GetAircraftClass(String classID) throws RemoteException;
  public AircraftModelVO GetAircraftModel(String modelID) throws RemoteException;
  public AirlineVO GetAirline(String airlineID) throws RemoteException;
  public AirportVO GetAirport(String airportID) throws RemoteException;
  public ClassFeeVO GetClassFee(String classID, String airlineID) throws RemoteException;
  public FlightVO GetFlight(String flightID) throws RemoteException;
  public FlightScheduleVO GetFlightSchedule(String flightID, int subrouteID) throws RemoteException;
  public SeatVO GetSeat(String seatNo, String modelID) throws RemoteException;
  public SubrouteVO GetSubroute(int subrouteID) throws RemoteException;

  public Collection GetAllAircraftClass() throws RemoteException;
  public Collection GetAllAircraftModel() throws RemoteException;
  public Collection GetAllAirline() throws RemoteException;
  public Collection GetAllAirport() throws RemoteException;
  public Collection GetAllClassFee() throws RemoteException;
  public Collection GetAllFlight() throws RemoteException;
  public Collection GetAllFlightSchedule() throws RemoteException;
  public Collection GetAllSeat() throws RemoteException;
  public Collection GetAllSubroute() throws RemoteException;

  public Collection Search(String airportsrcID, String airportdesID, int totalseat, java.sql.Date departdate, java.sql.Time departtime, String airclass, String airline, boolean smoking, boolean window, boolean nonstoponly) throws EJBException, RemoteException;

}
