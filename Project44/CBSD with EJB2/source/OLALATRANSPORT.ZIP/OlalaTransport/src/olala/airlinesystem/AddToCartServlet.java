package olala.airlinesystem;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.Date;
import java.sql.Time;
import java.util.*;

/**
 * Title:         AddToCartServlet.java
 * Description:   Add search result item to shopping cart.
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class AddToCartServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String CART_PAGE = "../cart.jsp";

  private CartItem item = null;
  private CartItem item2 = null;

  /**Initialize global variables*/
  public void init() throws ServletException {
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    /* ========================= Get Request Parameters ========================= */
    String flightID = request.getParameter("flightID");
    String classID = request.getParameter("classID");
    int seats = Integer.parseInt(request.getParameter("seats"));
    int srcIdx = Integer.parseInt(request.getParameter("srcidx"));
    int desIdx = Integer.parseInt(request.getParameter("desidx"));
    double unitPrice = Double.parseDouble(request.getParameter("unitPrice"));
    boolean smoking = (new Boolean(request.getParameter("smoking"))).booleanValue();
    boolean window = (new Boolean(request.getParameter("window"))).booleanValue();
    Date departDate = Date.valueOf(request.getParameter("departDate"));
    String departureAirportID = request.getParameter("departureAirportID");
    String destinationAirportID = request.getParameter("destinationAirportID");
    Time departureTime = Time.valueOf(request.getParameter("departureTime"));
    Time arriveTime = Time.valueOf(request.getParameter("arriveTime"));
    System.out.println("AddToCartServlet - Get all request parameters ... Done");

    /* ========================= Construct Shopping Cart ========================= */
    item = new CartItem(
                          flightID,
                          classID,
                          seats,
                          srcIdx,
                          desIdx,
                          smoking,
                          window,
                          departDate,
                          unitPrice,
                          departureAirportID,
                          destinationAirportID,
                          departureTime,
                          arriveTime,
                          false,
                          false);

    String tripType = request.getParameter("tripType");
    if (tripType.equals("R")) {
      String flightID2 = request.getParameter("flightID2");
      String classID2 = request.getParameter("classID2");
      int seats2 = Integer.parseInt(request.getParameter("seats2"));
      int srcIdx2 = Integer.parseInt(request.getParameter("srcidx2"));
      int desIdx2 = Integer.parseInt(request.getParameter("desidx2"));
      double unitPrice2 = Double.parseDouble(request.getParameter("unitPrice2"));
      boolean smoking2 = (new Boolean(request.getParameter("smoking2"))).booleanValue();
      boolean window2 = (new Boolean(request.getParameter("window2"))).booleanValue();
      Date departDate2 = Date.valueOf(request.getParameter("departDate2"));
      String departureAirportID2 = request.getParameter("departureAirportID2");
      String destinationAirportID2 = request.getParameter("destinationAirportID2");
      Time departureTime2 = Time.valueOf(request.getParameter("departureTime2"));
      Time arriveTime2 = Time.valueOf(request.getParameter("arriveTime2"));
      System.out.println("AddToCartServlet - Get all second request parameters ... Done");

      item2 = new CartItem(
                          flightID2,
                          classID2,
                          seats2,
                          srcIdx2,
                          desIdx2,
                          smoking2,
                          window2,
                          departDate2,
                          unitPrice2,
                          departureAirportID2,
                          destinationAirportID2,
                          departureTime2,
                          arriveTime2,
                          false,        // hasReturnPair
                          true);        // hasDepartPair
      item.setReturnPair(true);         // item has item2 as ReturnPair
    }

    HttpSession session = request.getSession(true);
    ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("AddToCartServlet - Get shopping cart session ... Done");

    if (shoppingCart == null) {
      shoppingCart = new ShoppingCart();
      System.out.println("AddToCartServlet - Construct new shopping cart ... Done");
    }

    shoppingCart.add(item);
    if (tripType.equals("R")) {
      shoppingCart.add(item2);
    }
    session.setAttribute("ShoppingCart", shoppingCart);
    System.out.println("AddToCartServlet - Add more item to shopping cart ... Done");

    shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("AddToCartServlet - Reget shopping cart session ... Done");
    System.out.println("AddToCartServlet - Redirecting to shopping cart ...");
    response.sendRedirect(CART_PAGE);
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}