package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AircraftClassBean implements EntityBean {
  EntityContext entityContext;
  public String classID;
  public String className;
  public String description;
  public String ejbCreate(String classID, String className, String description) throws CreateException, RemoteException {
    this.classID = classID;
    this.className = className;
    this.description = description;
    return null;
  }
  public String ejbCreate(String classID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(classID, null, null);
  }
  public void ejbPostCreate(String classID, String className, String description) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String classID) throws CreateException, RemoteException {
    ejbPostCreate(classID, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getClassID() {
    return classID;
  }
  public String getClassName() {
    return className;
  }
  public void setClassName(String className) {
    this.className = className;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public AircraftClassVO getAircraftClass() {
    AircraftClassVO aircraftClassVO = new AircraftClassVO();
    aircraftClassVO.setClassID(this.classID);
    aircraftClassVO.setClassName(this.className);
    aircraftClassVO.setDescription(this.description);
    return(aircraftClassVO);
  }
}
