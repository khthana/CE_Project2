package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FlightBean implements EntityBean {
  EntityContext entityContext;
  public String flightID;
  public String description;
  public String airlineID;
  public String modelID;
  public int flightDay;
  public String ejbCreate(String flightID, String description, String airlineID, String modelID, int flightDay) throws CreateException, RemoteException {
    this.flightID = flightID;
    this.description = description;
    this.airlineID = airlineID;
    this.modelID = modelID;
    this.flightDay = flightDay;
    return null;
  }
  public String ejbCreate(String flightID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(flightID, null, null, null, 0);
  }
  public void ejbPostCreate(String flightID, String description, String airlineID, String modelID, int flightDay) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String flightID) throws CreateException, RemoteException {
    ejbPostCreate(flightID, null, null, null, 0);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getFlightID() {
    return flightID;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getAirlineID() {
    return airlineID;
  }
  public void setAirlineID(String airlineID) {
    this.airlineID = airlineID;
  }
  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public int getFlightDay() {
    return flightDay;
  }
  public void setFlightDay(int flightDay) {
    this.flightDay = flightDay;
  }

  public FlightVO getFlight() {
    FlightVO flightVO = new FlightVO();
    flightVO.setFlightID(this.flightID);
    flightVO.setDescription(this.description);
    flightVO.setAirlineID(this.airlineID);
    flightVO.setModelID(this.modelID);
    flightVO.setFlightDay(this.flightDay);
    return(flightVO);
  }
}
