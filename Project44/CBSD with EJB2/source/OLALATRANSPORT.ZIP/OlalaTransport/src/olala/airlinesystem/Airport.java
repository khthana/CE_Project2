package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Airport extends EJBObject {
  public String getAirportID() throws RemoteException;
  public String getAirportName() throws RemoteException;
  public void setAirportName(String airportName) throws RemoteException;
  public String getCity() throws RemoteException;
  public void setCity(String city) throws RemoteException;
  public String getState() throws RemoteException;
  public void setState(String state) throws RemoteException;
  public String getCountry() throws RemoteException;
  public void setCountry(String country) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getImagePath() throws RemoteException;
  public void setImagePath(String imagePath) throws RemoteException;
  public AirportVO getAirport() throws RemoteException;
  public void setAirport(AirportVO airportVO) throws RemoteException;
}
