package olala.airlinesystem;

import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirlineVO implements Serializable {

  private String airlineID;
  private String airlineName;
  private String description;


  public AirlineVO() {
  }

  public void setAirlineID(String airlineID) {
    this.airlineID = airlineID;
  }
  public String getAirlineID() {
    return airlineID;
  }
  public void setAirlineName(String airlineName) {
    this.airlineName = airlineName;
  }
  public String getAirlineName() {
    return airlineName;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getDescription() {
    return description;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}