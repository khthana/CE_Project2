package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AirlineHome extends EJBHome {
  public Airline create(String airlineID, String airlineName, String description) throws CreateException, RemoteException;
  public Airline create(String airlineID) throws RemoteException, CreateException;
  public Airline findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
