package olala.airlinesystem;

import java.io.*;
public class TravellerVO implements Serializable{

  private String firstname;
  private String lastname;
  private String travellerID;

  public TravellerVO() {
  }
  public TravellerVO(String travellerID, String firstname, String lastname) {
    this.travellerID = travellerID;
    this.firstname = firstname;
    this.lastname = lastname;
  }

  public void setTravellerID(String travellerID) {
    this.travellerID = travellerID;
  }
  public void setFirstName(String firstname) {
    this.firstname = firstname;
  }
  public void setLastName(String lastname) {
    this.lastname = lastname;
  }
  public String getTravellerID() {
    return travellerID;
  }
  public String getFirstName() {
    return firstname;
  }
  public String getLastName() {
    return lastname;
  }

}