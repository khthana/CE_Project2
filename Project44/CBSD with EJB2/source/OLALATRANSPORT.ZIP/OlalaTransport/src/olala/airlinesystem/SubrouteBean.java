package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SubrouteBean implements EntityBean {
  EntityContext entityContext;
  public Integer subrouteID;
  public double distance;
  public String airportID1;
  public String airportID2;
  public Integer ejbCreate(Integer subrouteID, double distance, String airportID1, String airportID2) throws CreateException, RemoteException {
    this.subrouteID = subrouteID;
    this.distance = distance;
    this.airportID1 = airportID1;
    this.airportID2 = airportID2;
    return null;
  }
  public Integer ejbCreate(Integer subrouteID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(subrouteID, 0.0, null, null);
  }
  public void ejbPostCreate(Integer subrouteID, double distance, String airportID1, String airportID2) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(Integer subrouteID) throws CreateException, RemoteException {
    ejbPostCreate(subrouteID, 0.0, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public Integer getSubrouteID() {
    return subrouteID;
  }
  public double getDistance() {
    return distance;
  }
  public void setDistance(double distance) {
    this.distance = distance;
  }
  public String getAirportID1() {
    return airportID1;
  }
  public void setAirportID1(String airportID1) {
    this.airportID1 = airportID1;
  }
  public String getAirportID2() {
    return airportID2;
  }
  public void setAirportID2(String airportID2) {
    this.airportID2 = airportID2;
  }

  public SubrouteVO getSubroute() {
    SubrouteVO subrouteVO = new SubrouteVO();
    subrouteVO.setSubrouteID(this.subrouteID.intValue());
    subrouteVO.setDistance(this.distance);
    subrouteVO.setAirportID1(this.airportID1);
    subrouteVO.setAirportID2(this.airportID2);
    return(subrouteVO);
  }
}
