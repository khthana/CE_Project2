package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirportBean implements EntityBean {
  EntityContext entityContext;
  public String airportID;
  public String airportName;
  public String city;
  public String state;
  public String country;
  public String description;
  public String imagePath;
  public String ejbCreate(String airportID, String airportName, String city, String state, String country, String description, String imagePath) throws CreateException, RemoteException {
    this.airportID = airportID;
    this.airportName = airportName;
    this.city = city;
    this.state = state;
    this.country = country;
    this.description = description;
    this.imagePath = imagePath;
    return null;
  }
  public String ejbCreate(String airportID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(airportID, null, null, null, null, null, null);
  }
  public void ejbPostCreate(String airportID, String airportName, String city, String state, String country, String description, String imagePath) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String airportID) throws CreateException, RemoteException {
    ejbPostCreate(airportID, null, null, null, null, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getAirportID() {
    return airportID;
  }
  public String getAirportName() {
    return airportName;
  }
  public void setAirportName(String airportName) {
    this.airportName = airportName;
  }
  public String getCity() {
    return city;
  }
  public void setCity(String city) {
    this.city = city;
  }
  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }
  public String getCountry() {
    return country;
  }
  public void setCountry(String country) {
    this.country = country;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getImagePath() {
    return imagePath;
  }
  public void setImagePath(String imagePath) {
    this.imagePath = imagePath;
  }

  public AirportVO getAirport() {
    AirportVO airportVO = new AirportVO();

    airportVO.setAirportID(this.airportID);
    airportVO.setAirportName(this.airportName);
    airportVO.setCity(this.city);
    airportVO.setState(this.state);
    airportVO.setCountry(this.country);
    airportVO.setDescription(this.description);
    airportVO.setImagePath(this.imagePath);

    return (airportVO);
  }

  public void setAirport(AirportVO airportVO) {
    this.airportID = airportVO.getAirportID();
    this.airportName = airportVO.getAirportName();
    this.city = airportVO.getCity();
    this.state = airportVO.getState();
    this.country = airportVO.getCountry();
    this.description = airportVO.getDescription();
    this.imagePath = airportVO.getImagePath();
  }
}
