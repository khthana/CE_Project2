package olala.airlinesystem.testclient;

import java.util.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;

import olala.*;
import olala.airlinesystem.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CustomerServiceTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private CustomerServiceHome customerServiceHome = null;
  private CustomerService customerService = null;

  /**Construct the EJB test client*/
  public CustomerServiceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("AirCustomerService");

      //cast to Home interface
      customerServiceHome = (CustomerServiceHome) PortableRemoteObject.narrow(ref, CustomerServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public CustomerService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      customerService = customerServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + customerService + ".");
    }
    return customerService;
  }

  public void testRemoteCallsWithDefaultArguments() {
    if (customerService == null) {
      System.out.println("Error in testRemoteCallsWithDefaultArguments(): " + ERROR_NULL_REMOTE);
      return ;
    }
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) throws Exception {
    CustomerServiceTestClient1 client = new CustomerServiceTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.

    CustomerService cs = client.create();
    //cs.AddCustomer("Tankyjang", "ButterBomb", "M", "Ladkrabang", "1111111", "tankyjang@thaimail.com", "xxxxxx", false);
	String customerID = cs.Login("tinnapat@yahoo.com", "password");
	long starttime = System.currentTimeMillis();
	/*for (int i=0; i< 100; i++) {
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	}*/

	CustomerVO cVO = cs.getCustomer(customerID);
	System.out.println("CustomerID : " + cVO.getCustomerID());
	System.out.println("FirstName : " + cVO.getFirstName());
	System.out.println("LastName :" +  cVO.getLastName());
	System.out.println("Address : " + cVO.getAddress());
	System.out.println("Telephone :" + cVO.getTelephone());
	System.out.println("EmailAddress :" +cVO.getEmailAddress());

	long stoptime = System.currentTimeMillis();
	System.out.println("Total times : " + (stoptime - starttime) + " ms.");


//    CustomerVO cus = cs.getCustomer(1);
//    System.out.println(cus.getFirstName());
    /*
	try {
      System.out.println("getCustomer");
      CustomerVO cvo = cs.getCustomer(1);
      System.out.println("getFirstName");
      System.out.println(cvo.getFirstName());

      // Test CUSTOMER entity bean.
      Context ctx = new InitialContext();
      Object ref = ctx.lookup("Customer");
      CustomerHome customerHome = (CustomerHome) PortableRemoteObject.narrow(ref, CustomerHome.class);
      Collection customerCollection = customerHome.findByEmailAddress("atinnapat@yahoo.com");
      Iterator i = customerCollection.iterator();
//      Customer customer = (Customer) i.next();
      Customer customer = (Customer) PortableRemoteObject.narrow(i.next(), Customer.class);
      System.out.println(customer.getEmailAddress());

    }
    catch (Exception e) {
      e.printStackTrace();
    }
*/
/*
    try {
      System.out.println(cs.Login("tinnapat@thaimail.com", "password"));
      cs.AddCustomer("Kevin", "Chai", "M", "Ladkrabang", "tel", "email", "password", new Boolean(true));
    }
    catch (InvalidPasswordException e) {
      System.out.println("Invalid Password");
      e.printStackTrace();
    }
    catch (InvalidUserException e) {
      System.out.println("Invalid User");
      e.printStackTrace();
    }
*/
  }
}