package olala.airlinesystem;
import java.io.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ViewBookInfo implements Serializable{
  private int itemNo;
  private String  flightID;
  private String classID;
  private Timestamp departDateTime;
  private Timestamp arriveDateTime;
  private String airportSrcID;
  private String airportSrcName;
  private String airportDesName;
  private String airportDesID;
  private int totalSeat;
  private double price;

  public ViewBookInfo() {
  }

  public ViewBookInfo(int itemNo, String flightID, String classID, String airportSrcID, String airportSrcName, String airportDesID, String airportDesName, Timestamp departDateTime, Timestamp arriveDateTime, int totalSeat, double price) {
	this.itemNo = itemNo;
	this.flightID = flightID;
	this.classID = classID;
	this.departDateTime = departDateTime;
	this.arriveDateTime = arriveDateTime;
	this.airportSrcID   = airportSrcID;
	this.airportSrcName = airportSrcName;
	this.airportDesID   = airportDesID;
	this.airportDesName = airportDesName;
	this.totalSeat      = totalSeat;
	this.price          = price;
  }
  public String getAirportDesID() {
    return airportDesID;
  }
  public String getAirportDesName() {
    return airportDesName;
  }
  public String getAirportSrcID() {
    return airportSrcID;
  }
  public String getAirportSrcName() {
    return airportSrcName;
  }
  public Timestamp getArriveDateTime() {
    return arriveDateTime;
  }
  public String getClassID() {
    return classID;
  }
  public Timestamp getDepartDateTime() {
    return departDateTime;
  }
  public String getFlightID() {
    return flightID;
  }
  public int getItemNo() {
    return itemNo;
  }
  public double getPrice() {
    return price;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setAirportDesID(String airportDesID) {
    this.airportDesID = airportDesID;
  }
  public void setAirportDesName(String airportDesName) {
    this.airportDesName = airportDesName;
  }
  public void setAirportSrcID(String airportSrcID) {
    this.airportSrcID = airportSrcID;
  }
  public void setAirportSrcName(String airportSrcName) {
    this.airportSrcName = airportSrcName;
  }
  public void setArriveDateTime(Timestamp arriveDateTime) {
    this.arriveDateTime = arriveDateTime;
  }
  public void setClassID(String classID) {
    this.classID = classID;
  }
  public void setDepartDateTime(Timestamp departDateTime) {
    this.departDateTime = departDateTime;
  }
  public void setFlightID(String flightID) {
    this.flightID = flightID;
  }
  public void setItemNo(int itemNo) {
    this.itemNo = itemNo;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}