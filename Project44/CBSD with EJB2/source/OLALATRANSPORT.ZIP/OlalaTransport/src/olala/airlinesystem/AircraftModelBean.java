package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AircraftModelBean implements EntityBean {
  EntityContext entityContext;
  public String modelID;
  public String modelName;
  public int totalSeat;
  public String ejbCreate(String modelID, String modelName, int totalSeat) throws CreateException, RemoteException {
    this.modelID = modelID;
    this.modelName = modelName;
    this.totalSeat = totalSeat;
    return null;
  }
  public String ejbCreate(String modelID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(modelID, null, 0);
  }
  public void ejbPostCreate(String modelID, String modelName, int totalSeat) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String modelID) throws CreateException, RemoteException {
    ejbPostCreate(modelID, null, 0);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getModelID() {
    return modelID;
  }
  public String getModelName() {
    return modelName;
  }
  public void setModelName(String modelName) {
    this.modelName = modelName;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }
  public AircraftModelVO getAircraftModel() {
    AircraftModelVO amVO = new AircraftModelVO();
    amVO.setModelID(this.modelID);
    amVO.setModelName(this.modelName);
    amVO.setTotalSeat(this.totalSeat);
    return(amVO);
  }
}
