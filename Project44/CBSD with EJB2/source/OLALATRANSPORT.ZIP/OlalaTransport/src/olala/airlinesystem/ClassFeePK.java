package olala.airlinesystem;

import java.io.*;

public class ClassFeePK implements Serializable {

  public String classID;
  public String airlineID;

  public ClassFeePK() {
  }

  public ClassFeePK(String classID, String airlineID) {
    this.classID = classID;
    this.airlineID = airlineID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      ClassFeePK that = (ClassFeePK) obj;
      return this.classID.equals(that.classID) && this.airlineID.equals(that.airlineID);
    }
    return false;
  }
  public int hashCode() {
    return (classID + airlineID).hashCode();
  }
}