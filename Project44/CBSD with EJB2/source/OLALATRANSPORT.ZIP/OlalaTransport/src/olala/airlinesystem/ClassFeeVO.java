package olala.airlinesystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ClassFeeVO implements Serializable {
  private String classID;
  private String airlineID;
  private double pricePerKm;
  private double fee;

  public ClassFeeVO() {
  }

  public ClassFeeVO(String classID, String airlineID, double pricePerKm, double fee) {
	this.classID = classID;
	this.airlineID = airlineID;
	this.pricePerKm = pricePerKm;
	this.fee = fee;
  }
  public String getAirlineID() {
    return airlineID;
  }
  public void setAirlineID(String airlineID) {
    this.airlineID = airlineID;
  }
  public String getClassID() {
    return classID;
  }
  public void setClassID(String classID) {
    this.classID = classID;
  }
  public double getFee() {
    return fee;
  }
  public void setFee(double fee) {
    this.fee = fee;
  }
  public double getPricePerKm() {
    return pricePerKm;
  }
  public void setPricePerKm(double pricePerKm) {
    this.pricePerKm = pricePerKm;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}