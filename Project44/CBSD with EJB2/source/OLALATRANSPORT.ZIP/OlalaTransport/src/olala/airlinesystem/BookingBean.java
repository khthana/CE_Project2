package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

public class BookingBean implements EntityBean {
  EntityContext entityContext;
  public Integer transactionID;
  public Timestamp transactionDate;
  public int confirmation;
  public Timestamp confirmDeadline;
  public boolean obsoleted;
  public String bookingID;
  public String customerID;

  public BookingPK ejbCreate(String bookingID, Integer transactionID, Timestamp transactionDate, String customerID, int confirmation, Timestamp confirmDeadline, boolean obsoleted) throws CreateException, RemoteException {
    this.bookingID = bookingID;
    this.transactionID = transactionID;
    this.transactionDate = transactionDate;
    this.customerID = customerID;
    this.confirmation = confirmation;
	this.confirmDeadline = confirmDeadline;
    this.obsoleted = obsoleted;
    return null;
  }
  public void ejbPostCreate(String bookingID, Integer transactionID, Timestamp transactionDate, String customerID, int confirmation, Timestamp confirmDeadline, boolean obsoleted) throws CreateException, RemoteException {
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getBookingID() {
    return bookingID;
  }
  public Integer getTransactionID() {
    return transactionID;
  }
  public void setTransactionID(Integer transactionID) {
    this.transactionID = transactionID;
  }
  public Timestamp getTransactionDate() {
    return transactionDate;
  }
  public void setTransactionDate(Timestamp transactionDate) {
    this.transactionDate = transactionDate;
  }
  public String getCustomerID() {
    return customerID;
  }
  public void setCustomerID(String newCustomerID) {
    this.customerID = customerID;
  }
  public int getConfirmation() {
    return confirmation;
  }
  public void setConfirmation(int confirmation) {
    this.confirmation = confirmation;
  }
  public boolean getObsoleted() {
    return obsoleted;
  }
  public void setObsoleted(boolean obsoleted) {
    this.obsoleted = obsoleted;
  }
  public Timestamp getConfirmDeadline() {
    return confirmDeadline;
  }
  public void setConfirmDeadline(Timestamp confirmDeadline) {
    this.confirmDeadline = confirmDeadline;
  }
  public BookingVO getBooking() {
    BookingVO bookingVO = new BookingVO();
	bookingVO.setBookingID(bookingID);
	bookingVO.setTransactionID(transactionID);
	bookingVO.setTransactionDate(transactionDate);
	bookingVO.setCustomerID(customerID);
	bookingVO.setConfirmation(confirmation);
	bookingVO.setConfirmDeadline(confirmDeadline);
	bookingVO.setObsoleted(obsoleted);
	return bookingVO;
  }

}
