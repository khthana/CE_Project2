package olala.airlinesystem;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class TravellerSeat implements java.io.Serializable {
  private TravellerVO travellerVO;
  private String seatNo;

  public TravellerSeat() {
  }
  public TravellerSeat(TravellerVO tv, String seatNo) {
	this.travellerVO = tv;
	this.seatNo = seatNo;
  }
  public TravellerVO getTravellerVO() {
	return travellerVO;
  }
  public String getSeatNo() {
    return seatNo;
  }
  public void setSeatNo(String seatNo) {
    this.seatNo = seatNo;
  }
  public void setTravellerVO(TravellerVO travellerVO) {
    this.travellerVO = travellerVO;
  }

}