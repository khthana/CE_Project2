package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface AirportHome extends EJBHome {
  public Airport create(String airportID, String airportName, String city, String state, String country, String description, String imagePath) throws CreateException, RemoteException;
  public Airport create(String airportID) throws RemoteException, CreateException;
  public Airport findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
