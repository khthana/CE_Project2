package olala.airlinesystem.testclient;

import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import javax.naming.*;

import olala.util.*;
import olala.airlinesystem.*;

/**
 * Title: Airline Service Locator
 * Description: Extends the Baser Service Locator, with Type specific service
 * Copyright:    Copyright (c) 2001
 * Company:      KMITL
 * @author       Prakit Engkakitti
 * @version 1.0
 */

public class AirServiceLocator extends ServiceLocator {

  AirlineServiceHome airlineServiceHome = null;
  BookingServiceHome bookingServiceHome = null;
  CustomerServiceHome customerServiceHome = null;

  // To implement Singleton Pattern ...
  static AirServiceLocator airServiceLocator = null;

  public static final String SVR_AIRLINESERVICE = "AirlineService";
  public static final String SVR_BOOKINGSERVICE = "AirBookingService";
  public static final String SVR_CUSTOMERSERVICE = "AirCustomerService";

  public AirServiceLocator() throws ServiceLocatorException {
	super();
  }

  public AirlineServiceHome getAirlineServiceHome()
  {
	// if the home interface have not been looked up, then look up it
	if (airlineServiceHome == null) {
	  airlineServiceHome = (AirlineServiceHome) lookupByName(SVR_AIRLINESERVICE, AirlineServiceHome.class);
	}
	return airlineServiceHome;
  }
  public BookingServiceHome getBookingServiceHome()
  {
    // if the home interface have not been looked up, then look up it
	if (bookingServiceHome == null) {
	  bookingServiceHome = (BookingServiceHome) lookupByName(SVR_BOOKINGSERVICE, BookingServiceHome.class);
	}
	return bookingServiceHome;
  }
  public CustomerServiceHome getCustomerServiceHome()
  {
	// if the home interface have not been looked up, then look up it
	if (customerServiceHome == null) {
	  customerServiceHome = (CustomerServiceHome) lookupByName(SVR_CUSTOMERSERVICE, CustomerServiceHome.class);
	}
	return customerServiceHome;
  }
  // Singleton manager, to locate Single Instance of this method, use this ...
  public static AirServiceLocator getInstance() throws ServiceLocatorException {
	if (airServiceLocator == null) {
	  airServiceLocator = new AirServiceLocator();
	}
	return airServiceLocator;
  }
}