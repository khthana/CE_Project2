package olala.airlinesystem;


import java.io.*;
import java.sql.Time;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FlightScheduleVO implements Serializable {

  private String flightID;
  private Time arriveTime;
  private Time departTime;
  private int departDay;
  private int arriveDay;
  private int idx;
  private int subrouteID;

  public FlightScheduleVO() {
  }

  public String getFlightID() {
    return flightID;
  }
  public void setFlightID(String flightID) {
    this.flightID = flightID;
  }
  public int getSubrouteID() {
    return subrouteID;
  }
  public void setSubrouteID(int newSubrouteID) {
    this.subrouteID = subrouteID;
  }
  public Time getArriveTime() {
    return arriveTime;
  }
  public void setArriveTime(Time arriveTime) {
    this.arriveTime = arriveTime;
  }
  public Time getDepartTime() {
    return departTime;
  }
  public void setDepartTime(Time departTime) {
    this.departTime = departTime;
  }
  public int getDepartDay() {
    return departDay;
  }
  public void setDepartDay(int departDay) {
    this.departDay = departDay;
  }
  public int getArriveDay() {
    return arriveDay;
  }
  public void setArriveDay(int arriveDay) {
    this.arriveDay = arriveDay;
  }
  public int getIdx() {
    return idx;
  }
  public void setIdx(int idx) {
    this.idx = idx;
  }

  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }

}