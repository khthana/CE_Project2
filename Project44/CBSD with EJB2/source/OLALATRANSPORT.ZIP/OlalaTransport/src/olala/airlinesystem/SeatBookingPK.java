package olala.airlinesystem;
import java.io.*;
import java.sql.*;

public class SeatBookingPK implements Serializable {

  public String flightID;
  public int subRouteID;
  public String seatNo;
  public Timestamp departDate;

  public SeatBookingPK() {
  }

  public SeatBookingPK(String flightID, int subRouteID, String seatNo, Timestamp departDate) {
    this.flightID = flightID;
    this.subRouteID = subRouteID;
    this.seatNo = seatNo;
    this.departDate = departDate;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      SeatBookingPK that = (SeatBookingPK) obj;
      return this.flightID.equals(that.flightID) && this.subRouteID == that.subRouteID && this.seatNo.equals(that.seatNo) && this.departDate.equals(that.departDate);
    }
    return false;
  }
  public int hashCode() {
    return (flightID + subRouteID + "" +seatNo + departDate).hashCode();
  }
}
