package olala.airlinesystem;

import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirSeatSearchResult implements java.io.Serializable {
  String airlineName;
  String flightID;
  String flightDescription;
  String classID;
  String className;
  String modelName;
  Time departTime;
  Time arriveTime;
  int srcIdx;
  int desIdx;
  double totalDistance;
  double price;

  public AirSeatSearchResult() {
  }

  public AirSeatSearchResult( String airlineName,
					   String flightID, String flightDescription,
					   String classID,
					   String className,
					   String modelName,
					   Time departTime, Time arriveTime,
					   int srcIdx, int desIdx,
					   double totalDistance,
					   double price )
  {
	this.airlineName = airlineName;
	this.flightID = flightID;
	this.flightDescription = flightDescription;
	this.classID = classID;
	this.className = className;
	this.modelName = modelName;
    this.departTime = departTime;
    this.arriveTime = arriveTime;
    this.srcIdx = srcIdx;
    this.desIdx = desIdx;
	this.totalDistance = totalDistance;
    this.price = price;
  }
  public String getAirlineName() { return airlineName; }
  public String getFlightID()    { return flightID; };
  public String getFlightDescription() { return flightDescription; }
  public String getClassID()     { return classID; }
  public String getClassName()   { return className; };
  public String getModelName()   { return modelName; }
  public Time getDepartTime()    { return departTime; };
  public Time getArriveTime()    { return arriveTime; };
  public int getSrcIdx()         { return srcIdx; }
  public int getDesIdx()         { return desIdx; }
  public double getTotalDistance()  { return totalDistance; };
  public double getPrice()       { return price; };

  public void setAirlineName(String airlineName) { this.airlineName = airlineName; }
  public void setFlightID(String flightID)       { this.flightID = flightID; }
  public void setFlightDescription(String flightDescription)   { this.flightDescription = flightDescription; }
  public void setClassID(String classID)         { this.classID = classID; }
  public void setClassName(String className)     { this.className = className; }
  public void setModelName(String modelName)     { this.modelName = modelName; }
  public void setDepartTime(Time departTime)     { this.departTime = departTime; }
  public void setArriveTime(Time arriveTime)     { this.arriveTime = arriveTime; }
  public void setSrcIdx(int srcIdx)              { this.srcIdx = srcIdx; }
  public void setDesIdx(int desIdx)              { this.desIdx = desIdx; }
  public void setTotalDistance(double totalDistance)           { this.totalDistance = totalDistance; }
  public void setPrice(double price)             { this.price = price; }




}