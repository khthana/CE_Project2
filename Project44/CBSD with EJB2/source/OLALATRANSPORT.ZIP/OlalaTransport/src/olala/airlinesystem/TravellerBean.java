package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

public class TravellerBean implements EntityBean {
  EntityContext entityContext;
  public String firstName;
  public String lastName;
  public String travellerID;
  public TravellerPK ejbCreate(String travellerID, String firstName, String lastName) throws CreateException, RemoteException {
    this.travellerID = travellerID;
    this.firstName = firstName;
    this.lastName = lastName;
    return null;
  }
  public TravellerPK ejbCreate(String travellerID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(travellerID, null, null);
  }
  public void ejbPostCreate(String travellerID, String firstName, String lastName) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String travellerID) throws CreateException, RemoteException {
    ejbPostCreate(travellerID, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getTravellerID() {
    return travellerID;
  }
  public String getFirstName() {
    return firstName;
  }
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  public String getLastName() {
    return lastName;
  }
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
}
