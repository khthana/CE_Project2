package olala.airlinesystem;

import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AircraftModelVO implements Serializable {

  private String modelID;
  private String modelName;
  private int totalSeat;

  public AircraftModelVO() {
  }

  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public String getModelName() {
    return modelName;
  }
  public void setModelName(String modelName) {
    this.modelName = modelName;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }

  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
}