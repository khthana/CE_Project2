package olala.airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface SeatHome extends EJBHome {
  public Seat create(String seatNo, String modelID, boolean smoking, boolean window, String classID) throws CreateException, RemoteException;
  public Seat create(String seatNo, String modelID) throws RemoteException, CreateException;
  public Seat findByPrimaryKey(SeatPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
