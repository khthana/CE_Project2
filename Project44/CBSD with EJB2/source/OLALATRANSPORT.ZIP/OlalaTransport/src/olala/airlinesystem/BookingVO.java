package olala.airlinesystem;
import java.sql.Timestamp;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingVO implements  java.io.Serializable {
  private Integer transactionID;
  private Timestamp transactionDate;
  private Timestamp confirmDeadline;
  private int confirmation;
  private boolean obsoleted;
  private String bookingID;
  private String customerID;

  public BookingVO() {
  }
  public void setBookingID(String bookingID) {
    this.bookingID = bookingID;
  }
  public String getBookingID() {
    return bookingID;
  }
  public Integer getTransactionID() {
    return transactionID;
  }
  public void setTransactionID(Integer transactionID) {
    this.transactionID = transactionID;
  }
  public Timestamp getTransactionDate() {
    return transactionDate;
  }
  public void setTransactionDate(Timestamp transactionDate) {
    this.transactionDate = transactionDate;
  }
  public Timestamp getConfirmDeadline() {
	return confirmDeadline;
  }
  public void setConfirmDeadline(Timestamp confirmDeadline) {
	this.confirmDeadline = confirmDeadline;
  }
  public String getCustomerID() {
    return customerID;
  }
  public void setCustomerID(String customerID) {
    this.customerID = customerID;
  }
  public int getConfirmation() {
    return confirmation;
  }
  public void setConfirmation(int confirmation) {
    this.confirmation = confirmation;
  }
  public boolean getObsoleted() {
    return obsoleted;
  }
  public void setObsoleted(boolean obsoleted) {
    this.obsoleted = obsoleted;
  }
}