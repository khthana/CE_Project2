package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface FlightSchedule extends EJBObject {
  public String getFlightID() throws RemoteException;
  public int getSubrouteID() throws RemoteException;
  public Time getArriveTime() throws RemoteException;
  public void setArriveTime(Time arriveTime) throws RemoteException;
  public Time getDepartTime() throws RemoteException;
  public void setDepartTime(Time departTime) throws RemoteException;
  public int getIdx() throws RemoteException;
  public void setIdx(int idx) throws RemoteException;
  public FlightScheduleVO getFlightSchedule() throws RemoteException;
  public int getArriveDay() throws RemoteException;
  public int getDepartDay() throws RemoteException;
  public void setArriveDay(int arriveDay) throws RemoteException;
  public void setDepartDay(int departDay) throws RemoteException;
}
