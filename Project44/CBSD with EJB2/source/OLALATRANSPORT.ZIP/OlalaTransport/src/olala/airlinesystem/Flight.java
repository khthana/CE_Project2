package olala.airlinesystem;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Flight extends EJBObject {
  public String getFlightID() throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getAirlineID() throws RemoteException;
  public void setAirlineID(String airlineID) throws RemoteException;
  public String getModelID() throws RemoteException;
  public void setModelID(String modelID) throws RemoteException;
  public int getFlightDay() throws RemoteException;
  public void setFlightDay(int flightDay) throws RemoteException;
  public FlightVO getFlight() throws RemoteException;
}
