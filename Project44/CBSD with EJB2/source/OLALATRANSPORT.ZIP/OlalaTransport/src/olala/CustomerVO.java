package olala;


/**
 * Title:        Customer Value Object
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Kmit'L
 * @author
 * @version 1.0
 */

public class CustomerVO implements java.io.Serializable {

  private String customerID;
  private String firstName;
  private String lastName;
  private String gender;
  private String address;
  private String telephone;
  private String emailAddress;
  private String password;
  private boolean agency;

  public CustomerVO() {
  }

  public CustomerVO(String customerID, String firstName, String lastName, String gender,
		            String address, String telephone, String emailAddress, String password,
					boolean agency )
  {
	this.customerID = customerID;
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
	this.address = address;
	this.telephone = telephone;
	this.emailAddress = emailAddress;
	this.password = password;
	this.agency = agency;
  }

  public String getCustomerID() {
    return customerID;
  }
  public void setCustomerID(String customerID) {
    this.customerID = customerID;
  }
  public String getFirstName() {
    return firstName;
  }
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  public String getLastName() {
    return lastName;
  }
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
  public String getGender() {
    return gender;
  }
  public void setGender(String gender) {
    this.gender = gender;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getTelephone() {
    return telephone;
  }
  public void setTelephone(String telephone) {
    this.telephone = telephone;
  }
  public String getEmailAddress() {
    return emailAddress;
  }
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public boolean getAgency() {
    return agency;
  }
  public void setAgency(boolean agency) {
    this.agency = agency;
  }

}