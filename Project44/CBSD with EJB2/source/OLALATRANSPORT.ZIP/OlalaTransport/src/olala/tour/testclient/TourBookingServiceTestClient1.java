package olala.tour.testclient;

import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import olala.airlinesystem.*;

import olala.tour.BookingService;
import olala.tour.BookingServiceHome;
import olala.tour.BookingVO;

import olala.hotel.HotelBookingVO;
import olala.hotel.HotelBookingDetailVO;

public class TourBookingServiceTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private BookingServiceHome bookingServiceHome = null;
  private BookingService bookingService = null;

  /**Construct the EJB test client*/
  public TourBookingServiceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("TourBookingService");

      //cast to Home interface
      bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ref, BookingServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public BookingService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      bookingService = bookingServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + bookingService + ".");
    }
    return bookingService;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public Collection SearchHotel(String Country, String State, String City, String HotelName, int MinStar, int MaxStar, String RoomModelName, int AmountOfRoom, int MinPrice, int MaxPrice, String CheckInDate, String CheckOutDate) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in SearchHotel(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchHotel(" + Country + ", " + State + ", " + City + ", " + HotelName + ", " + MinStar + ", " + MaxStar + ", " + RoomModelName + ", " + AmountOfRoom + ", " + MinPrice + ", " + MaxPrice + ", " + CheckInDate + ", " + CheckOutDate + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.SearchHotel(Country, State, City, HotelName, MinStar, MaxStar, RoomModelName, AmountOfRoom, MinPrice, MaxPrice, CheckInDate, CheckOutDate);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchHotel(" + Country + ", " + State + ", " + City + ", " + HotelName + ", " + MinStar + ", " + MaxStar + ", " + RoomModelName + ", " + AmountOfRoom + ", " + MinPrice + ", " + MaxPrice + ", " + CheckInDate + ", " + CheckOutDate + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchHotel(" + Country + ", " + State + ", " + City + ", " + HotelName + ", " + MinStar + ", " + MaxStar + ", " + RoomModelName + ", " + AmountOfRoom + ", " + MinPrice + ", " + MaxPrice + ", " + CheckInDate + ", " + CheckOutDate + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchHotel(" + Country + ", " + State + ", " + City + ", " + HotelName + ", " + MinStar + ", " + MaxStar + ", " + RoomModelName + ", " + AmountOfRoom + ", " + MinPrice + ", " + MaxPrice + ", " + CheckInDate + ", " + CheckOutDate + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public String Reserve(String CustomerID, Collection airReserveItems, Collection hotelReserveItems) {
    String returnValue = "";
    if (bookingService == null) {
      System.out.println("Error in Reserve(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Reserve(" + CustomerID + ", " + airReserveItems + ", " + hotelReserveItems + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.Reserve(CustomerID, airReserveItems, hotelReserveItems);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Reserve(" + CustomerID + ", " + airReserveItems + ", " + hotelReserveItems + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Reserve(" + CustomerID + ", " + airReserveItems + ", " + hotelReserveItems + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from Reserve(" + CustomerID + ", " + airReserveItems + ", " + hotelReserveItems + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetCustomerBookings(String customerID) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetCustomerBookings(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetCustomerBookings(" + customerID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetCustomerBookings(customerID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetCustomerBookings(" + customerID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetCustomerBookings(" + customerID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetCustomerBookings(" + customerID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public BookingVO GetBooking(String bookingID) {
    BookingVO returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBooking(" + bookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public olala.airlinesystem.BookingVO GetAirlineBooking(String airBookingID) {
    olala.airlinesystem.BookingVO returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetAirlineBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAirlineBooking(" + airBookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetAirlineBooking(airBookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAirlineBooking(" + airBookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAirlineBooking(" + airBookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAirlineBooking(" + airBookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection ViewAirlineBooking(String airBookingID) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in ViewAirlineBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling ViewAirlineBooking(" + airBookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.ViewAirlineBooking(airBookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: ViewAirlineBooking(" + airBookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: ViewAirlineBooking(" + airBookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from ViewAirlineBooking(" + airBookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public HotelBookingVO GetHotelBooking(int hotelBookingID) {
    HotelBookingVO returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetHotelBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetHotelBooking(" + hotelBookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetHotelBooking(hotelBookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetHotelBooking(" + hotelBookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetHotelBooking(" + hotelBookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetHotelBooking(" + hotelBookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public HotelBookingDetailVO[] GetHotelBookingDetail(int hotelBooking) {
    HotelBookingDetailVO[] returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetHotelBookingDetail(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetHotelBookingDetail(" + hotelBooking + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetHotelBookingDetail(hotelBooking);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetHotelBookingDetail(" + hotelBooking + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetHotelBookingDetail(" + hotelBooking + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetHotelBookingDetail(" + hotelBooking + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public void CancelBooking(String bookingID) {
    if (bookingService == null) {
      System.out.println("Error in CancelBooking(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }
  }

  public void CancelAirlineBooking(String bookingID) {
    if (bookingService == null) {
      System.out.println("Error in CancelAirlineBooking(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelAirlineBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelAirlineBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelAirlineBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelAirlineBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }
  }

  public void CancelAirlineBookingDetail(String airlineBookingID, int itemNo) {
    if (bookingService == null) {
      System.out.println("Error in CancelAirlineBookingDetail(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelAirlineBookingDetail(" + airlineBookingID + ", " + itemNo + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelAirlineBookingDetail(airlineBookingID, itemNo);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelAirlineBookingDetail(" + airlineBookingID + ", " + itemNo + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelAirlineBookingDetail(" + airlineBookingID + ", " + itemNo + ")");
      }
      e.printStackTrace();
    }
  }

  public void CancelHotelBooking(String bookingID) {
    if (bookingService == null) {
      System.out.println("Error in CancelHotelBooking(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelHotelBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelHotelBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelHotelBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelHotelBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }
  }

  public void CancelHotelBookingDetail(int hotelBookingID, int itemNo) {
    if (bookingService == null) {
      System.out.println("Error in CancelHotelBookingDetail(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelHotelBookingDetail(" + hotelBookingID + ", " + itemNo + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelHotelBookingDetail(hotelBookingID, itemNo);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelHotelBookingDetail(" + hotelBookingID + ", " + itemNo + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelHotelBookingDetail(" + hotelBookingID + ", " + itemNo + ")");
      }
      e.printStackTrace();
    }
  }

  public void ConfirmBooking(String bookingID) {
    if (bookingService == null) {
      System.out.println("Error in ConfirmBooking(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling ConfirmBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.ConfirmBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: ConfirmBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: ConfirmBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    TourBookingServiceTestClient1 client = new TourBookingServiceTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
	client.create();
	//client.SearchHotel("\u0E44\u0E17\u0E22","","\u0E01\u0E23\u0E38\u0E07\u0E40\u0E17\u0E1E","",1,5,"",2,1,10000,"2001-12-12 00:00:00","2001-15-12 00:00:00");
	//client.CancelHotelBooking();
	client.CancelBooking("cc008ce9-7f00-0001-001d-221ebc60f0c1");
  }
}