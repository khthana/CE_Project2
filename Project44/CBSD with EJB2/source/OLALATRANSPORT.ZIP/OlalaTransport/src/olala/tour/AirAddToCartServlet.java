package olala.tour;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.Date;
import java.sql.Time;
import java.util.*;

import olala.airlinesystem.*;

/**
 * Title:         AirAddToCartServlet.java
 * Description:   Add search result item to shopping cart.
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class AirAddToCartServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String CART_PAGE = "../cart.jsp";

  /**Initialize global variables*/
  public void init() throws ServletException {
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    /* ========================= Get Request Parameters ========================= */
    String flightID = request.getParameter("flightID");
    String classID = request.getParameter("classID");
    int seats = Integer.parseInt(request.getParameter("seats"));
    int srcIdx = Integer.parseInt(request.getParameter("srcidx"));
    int desIdx = Integer.parseInt(request.getParameter("desidx"));
    double unitPrice = Double.parseDouble(request.getParameter("unitPrice"));
    boolean smoking = Boolean.getBoolean(request.getParameter("smoking"));
    boolean window = Boolean.getBoolean(request.getParameter("window"));
    Date departDate = Date.valueOf(request.getParameter("departDate"));
    String departureAirportID = request.getParameter("departureAirportID");
    String destinationAirportID = request.getParameter("destinationAirportID");
    Time departureTime = Time.valueOf(request.getParameter("departureTime"));
    Time arriveTime = Time.valueOf(request.getParameter("arriveTime"));
    System.out.println("AirAddToCartServlet - Get all request parameters ... Done");

    /* ========================= Construct Shopping Cart ========================= */
    olala.airlinesystem.CartItem item = new olala.airlinesystem.CartItem(
                          flightID,
                          classID,
                          seats,
                          srcIdx,
                          desIdx,
                          smoking,
                          window,
                          departDate,
                          unitPrice,
                          departureAirportID,
                          destinationAirportID,
                          departureTime,
                          arriveTime,
						  false,
						  false
						  );
    HttpSession session = request.getSession(true);
    ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("AirAddToCartServlet - Get shopping cart session ... Done");

    if (shoppingCart == null) {
      shoppingCart = new ShoppingCart();
      System.out.println("AirAddToCartServlet - Construct new shopping cart ... Done");
    }

    shoppingCart.addAirItem(item);
    session.setAttribute("ShoppingCart", shoppingCart);
    System.out.println("AirAddToCartServlet - Add more item to shopping cart ... Done");

    shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("AirAddToCartServlet - Reget shopping cart session ... Done");
    System.out.println("AirAddToCartServlet - Redirecting to shopping cart ...");
    response.sendRedirect(CART_PAGE);
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}