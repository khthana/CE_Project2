package olala.tour;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import java.rmi.*;

import olala.airlinesystem.*;
import olala.util.*;

/**
 * Title:         ConfirmBookingServlet.java
 * Description:   Confirm a booking
 * Copyright:     Copyright (c) 2001
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class ConfirmBookingServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String TARGET_PAGE = "../listBooking.jsp";

  private olala.tour.BookingServiceHome bookingServiceHome;
  private olala.tour.BookingService bookingService;

  /**Initialize global variables*/
  public void init() throws ServletException {
    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("java:comp/env/ejb/TourBookingService");

      //cast to Home interface
      bookingServiceHome = (olala.tour.BookingServiceHome) PortableRemoteObject.narrow(ref, olala.tour.BookingServiceHome.class);
    }
    catch(Exception e) {
      System.out.println("==> Exception in ConfirmBookingServlet.init() <==");
      e.printStackTrace();
    }
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    String bookingID = request.getParameter("bookingID");
    try {
      bookingService = bookingServiceHome.create();
      System.out.println("ConfirmBookingServlet - Creating remote object ... Done");
      bookingService.ConfirmBooking(bookingID);
      System.out.println("ConfirmBookingServlet - Confirming booking ID " + bookingID + " ... Done");
      response.sendRedirect(TARGET_PAGE+"?msgCode=1");
    }
    catch (ReserveException rse) {
      rse.printStackTrace();
      response.sendRedirect(TARGET_PAGE+"?errCode=1");
    }
    catch (RemoteException re) {
      System.out.println("==> RemoteException in ConfirmBookingServlet <==");
      re.printStackTrace();
    }
    catch (Exception e) {
      System.out.println("==> Exception in ConfirmBookingServlet <==");
      e.printStackTrace();
    }
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}
