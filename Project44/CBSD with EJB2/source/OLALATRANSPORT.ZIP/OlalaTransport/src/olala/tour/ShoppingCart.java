package olala.tour;
import java.util.*;

/**
 * Title:         ShoppingCart.java
 * Description:   Shopping Cart
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class ShoppingCart {
  private Vector airCartItem;
  private Vector hotelReserveItem;

  public ShoppingCart() {
    airCartItem = new Vector();
    hotelReserveItem = new Vector();
  }
  public olala.airlinesystem.CartItem getAirItem(int index) {
    if (index >= airCartItem.size()) {
      return null;
    }
    else {
      return (olala.airlinesystem.CartItem)airCartItem.elementAt(index);
    }
  }
  public olala.hotel.ReserveHotelDetail getHotelItem(int index) {
    if (index >= hotelReserveItem.size()) {
      return null;
    }
    else {
      return (olala.hotel.ReserveHotelDetail)hotelReserveItem.elementAt(index);
    }
  }
  public Collection getHotelReserveItem() {
    return (hotelReserveItem);
  }
  public void addAirItem(olala.airlinesystem.CartItem item) {
    airCartItem.addElement(item);
  }
  public void addHotelItem(olala.hotel.ReserveHotelDetail item) {
    hotelReserveItem.addElement(item);
  }
  public void removeAirItem(int index) {
    airCartItem.remove(index);
  }
  public void removeHotelItem(int index) {
    hotelReserveItem.remove(index);
  }
/*
  public void setSeats(int index, int seats) {
    CartItemAir item = (CartItemAir) airCartItem.elementAt(index);
    item.setSeats(seats);
  }
*/
  public int getTotalSeats() {
    int totalSeats = 0;
    Iterator i = airCartItem.iterator();
    while (i.hasNext()) {
      olala.airlinesystem.CartItem item = (olala.airlinesystem.CartItem) i.next();
      totalSeats += item.getSeats();
    }
    return totalSeats;
  }
  public int getTotalRooms() {
    int totalRooms = 0;
    Iterator i = hotelReserveItem.iterator();
    while (i.hasNext()) {
      olala.hotel.ReserveHotelDetail item = (olala.hotel.ReserveHotelDetail) i.next();
      totalRooms += item.getAmountOfRoom();
    }
    return totalRooms;
  }
  public double getTotalPrice() {
    double totalPrice = 0;
    Iterator i = airCartItem.iterator();
    while (i.hasNext()) {
      olala.airlinesystem.CartItem item = (olala.airlinesystem.CartItem) i.next();
      totalPrice += (item.getSeats() * item.getPrice());
    }
    return totalPrice;
  }
  public int size() {
    return (airSize() + hotelSize());
  }
  public int airSize() {
    return airCartItem.size();
  }
  public int hotelSize() {
    return hotelReserveItem.size();
  }
  public Collection toAirReserveItemCollection() {
    Vector airReserveItemCollection = new Vector();
    Iterator i = airCartItem.iterator();
    while (i.hasNext()) {
      // Downcast CartItem to ReserveItem
      olala.airlinesystem.ReserveItem airReserveItem = (olala.airlinesystem.ReserveItem) i.next();
      airReserveItemCollection.addElement(airReserveItem);
    }
    return airReserveItemCollection;
  }
  public boolean isValid() {
    boolean valid = true;
    Iterator i = airCartItem.iterator();
    while (i.hasNext()) {
      olala.airlinesystem.CartItem item = (olala.airlinesystem.CartItem) i.next();
      if (!item.isValid()) {
        valid = false;
      }
    }
    return valid;
  }
}