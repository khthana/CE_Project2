package olala.tour;

import java.rmi.*;
import javax.ejb.*;

import java.util.*;
import olala.util.*;

/** Tour Booking Service
 *
 */

public interface BookingService extends EJBObject {
  // Collection of HotelSearchResult
  public Collection SearchHotel(String Country, String State, String City, String HotelName,
								int MinStar, int MaxStar, String RoomModelName, int AmountOfRoom,
								int MinPrice, int MaxPrice, String CheckInDate, String CheckOutDate) throws RemoteException;

  public String Reserve(String CustomerID, Collection airReserveItems, Collection hotelReserveItems) throws RemoteException, ReserveException, Exception;
  // Collection of olala.tour.bookingVO
  public Collection GetCustomerBookings(String customerID) throws RemoteException;
  public olala.tour.BookingVO GetBooking(String bookingID) throws RemoteException;
  public olala.airlinesystem.BookingVO GetAirlineBooking(String airBookingID) throws RemoteException;
  // Collection of olala.airlinesystem.ViewBookInfo
  public Collection ViewAirlineBooking(String airBookingID) throws RemoteException;
  public olala.hotel.HotelBookingVO GetHotelBooking(int hotelBookingID) throws RemoteException;
  public olala.hotel.HotelBookingDetailVO[] GetHotelBookingDetail(int hotelBooking) throws RemoteException;

  public void CancelBooking(String bookingID) throws ReserveException, Exception, RemoteException;
  public void CancelAirlineBooking(String bookingID) throws ReserveException, RemoteException;
  public void CancelAirlineBookingDetail(String airlineBookingID, int itemNo) throws ReserveException, RemoteException;
  public void CancelHotelBooking(String bookingID) throws RemoteException;
  public void CancelHotelBookingDetail(int hotelBookingID, int itemNo) throws RemoteException;
  public void ConfirmBooking(String bookingID) throws ReserveException, RemoteException;
}