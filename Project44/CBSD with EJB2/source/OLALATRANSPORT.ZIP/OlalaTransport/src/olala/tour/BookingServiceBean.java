package olala.tour;

import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.DataSource;
import java.util.*;

// import business service
import olala.airlinesystem.*;
import olala.hotel.*;
import olala.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingServiceBean implements SessionBean {
  private SessionContext sessionContext;
  private olala.airlinesystem.BookingService airBookingService = null;
  private HotelService hotelService;
  private UUID uuid = null;
  private DataSource dataSource = null;

  private String TOUR_AIR_CUSTOMERID = "111";
  private int TOUR_HOTEL_CUSTOMERID = 222;

  public Collection SearchHotel(String Country, String State, String City,
										 String HotelName, int MinStar, int MaxStar,
										 String RoomModelName, int AmountOfRoom,
										 int MinPrice,int MaxPrice,
										 String CheckInDate,String CheckOutDate)
  {
	Collection result = new ArrayList();
	System.out.println("Sending SOAP Message.. SearchHotel()");
	try {
	  HotelSearchResult[] hsresult = hotelService.SearchHotel(Country, State, City, HotelName, MinStar, MaxStar,
							 RoomModelName, AmountOfRoom, MinPrice, MaxPrice,
							 CheckInDate, CheckOutDate);
      for (int i=0; i<hsresult.length; i++) {
		result.add(hsresult[i]);
      }
	  return result;
	}
	catch (Exception e) {
	  throw new EJBException("[OlalaTour] Reserve() : Exception, May be SOAP Error");
	}

  }

  public String Reserve(String CustomerID, Collection airReserveItems, Collection hotelReserveItems) throws RemoteException, ReserveException, Exception {
	Connection conn = null;
	String newTourBookingID = null;
	String newAirlineBookingID = null;
	int newHotelBookingID = 0;

	boolean reserveAirOK = false;
	boolean reserveHotelOK = false;

	try {
	  conn = dataSource.getConnection();
	  newTourBookingID = (String)uuid.getUUID();

	  // Reserve Airline
	  if (airReserveItems != null) {
		if (airReserveItems.size() != 0) {
		  newAirlineBookingID = airBookingService.Reserve(TOUR_AIR_CUSTOMERID, airReserveItems);
		  reserveAirOK = true;
		}
	  }

	  // Reserve Airline
	  if (hotelReserveItems != null) {
		if (hotelReserveItems.size() != 0) {
		  newHotelBookingID = hotelService.Reserve( TOUR_HOTEL_CUSTOMERID, (ReserveHotelDetail[] )hotelReserveItems.toArray() );
		  reserveHotelOK = true;
		}
	  }

	  // Find  nearest confirm deadline
	  java.util.Date cnfDeadline = null;

	  if (reserveAirOK) {
		java.util.Date airDeadline = airBookingService.GetBooking(newAirlineBookingID).getConfirmDeadline();
		System.out.println("Done reserve for Air : Confirm Deadline = " + airDeadline);
		cnfDeadline = airDeadline;
	  }

	  if (reserveHotelOK) {
		java.util.Date hotelDeadline = this.GetHotelBooking(newHotelBookingID).getConfirmDeadline();
		System.out.println("Done reserve for Hotel : Confirm Deadline = " + cnfDeadline);
		if (cnfDeadline == null) {
		  cnfDeadline = hotelDeadline;
		}
		else if (cnfDeadline.after(hotelDeadline)) {
		  cnfDeadline = hotelDeadline;
		}
	  }

	  System.out.println("Total Tour Confirm Deadline = " + cnfDeadline);

	  // if nothing to reserve
	  if (hotelReserveItems == null && airReserveItems == null) {
		 throw new ReserveException("No Item to Reserve");
	  }

	  BookingVO bVO = new BookingVO(newTourBookingID,
									newAirlineBookingID,
									new Integer(newHotelBookingID),
									CustomerID,
									0,
									new java.sql.Timestamp(cnfDeadline.getTime()),
									false,
									new Integer(0),
									new java.sql.Timestamp(System.currentTimeMillis()));


	  System.out.println("Insert new Row to Tour Booking : ID#" + newTourBookingID);
	  insertBooking(conn, bVO);
	  System.out.println("Insert Done");
	  conn.close();
	  return newTourBookingID;
	}
	catch (Exception e) {
	  // Roll back all operation
	  if (reserveAirOK) {
		// Cancel Air
		airBookingService.CancelBooking( newAirlineBookingID );
	  }
	  if (reserveHotelOK) {
		// Cancel Hotel
		hotelService.CancelBooking( newHotelBookingID );
	  }
	  throw new EJBException("[OlalaTour] Error with Reserve");
	}
	finally {
	  closeConnection(conn);
	}
  }
  public void CancelBooking( String bookingID ) throws ReserveException, Exception {
	Connection conn = null;
	PreparedStatement prstmt = null;
	try {
	  conn = dataSource.getConnection();
	  conn.setAutoCommit(false);
	  BookingVO bVO = loadBooking(conn, bookingID);
	  String airBookingID = bVO.getAirlineBookingID();
	  int hotelBookingID = bVO.getHotelBookingID().intValue();

	  // Cancel Airline booking
	  if (airBookingID != null) {
		System.out.print("[OlalaTour] Cancelling Airline Booking ID#" + airBookingID);
		airBookingService.CancelBooking(airBookingID);
		System.out.println("Done");
	  }

	  // Cancel Hotel Booking
	  if (hotelBookingID != 0) {
		System.out.print("[OlalaTour] Cancelling Hotel Booking ID#" + hotelBookingID);
		hotelService.CancelBooking(hotelBookingID);
		System.out.println("Done");
	  }

	  // Delete from Tour Booking
	  prstmt = conn.prepareStatement("DELETE FROM Booking WHERE BookingID = ?");
	  prstmt.setString(1, bookingID);
	  prstmt.executeUpdate();
	  prstmt.close();

	  conn.commit();
	  conn.close();

	}
	catch (SQLException e) {
	  System.out.println("SQLException occured , Rolling back");
	  conn.rollback();
	  e.printStackTrace();
	  throw new EJBException("[OlalaTour] CancelBooking : Error with SQL");
	}
	catch (RemoteException re) {
	  System.out.println("RemoteException occured , Rolling back");
	  conn.rollback();
	  throw new EJBException("[OlalaTour] CancelBooking : Internal Remote Error");
	}
	finally {
	  closeConnection(conn);
	}
  }

  // Recieve tour's bookingID
  public void CancelAirlineBooking(String bookingID) throws ReserveException
  {
	System.out.println("[OlalaTour] CancelAirlineBooking() was called");
	Connection conn = null;
	try {
	  conn = dataSource.getConnection();
	  BookingVO bVO = loadBooking(conn, bookingID);
	  String airBookingID = bVO.getAirlineBookingID();
	  if (airBookingID != null) {
		airBookingService.CancelBooking(airBookingID);
	  }
	  // if done cancel airline, Update the database
	  bVO.setAirlineBookingID(null);
	  storeBooking(conn, bVO);
	  conn.close();
	}
	catch (SQLException se) {
	  throw new EJBException("[OlalaTour] CancelAirlineBooking : SQL Error");
	}
	catch (RemoteException re) {
	  throw new EJBException("[OlalaTour] CancelAirlineBooking : Internal Remote Error");
	}
	catch (Exception e) {
	  throw new EJBException("[OlalaTour] CancelAirlineBooking : Exception, May be SOAP Error");
	}
	finally {
	  closeConnection(conn);
	}
  }

  // Recieve tour's bookingID
  public void CancelHotelBooking(String bookingID) {
	System.out.println("[OlalaTour] CancelHotelBooking was called");
	Connection conn = null;
	try {
	  conn = dataSource.getConnection();
	  BookingVO bVO = loadBooking(conn, bookingID);
	  int hotelBookingID = bVO.getHotelBookingID().intValue();
	  hotelService.CancelBooking(hotelBookingID);
	  // Clear Old HotelBookingID Reference
	  bVO.setHotelBookingID(new Integer(0));
	  // Update Result.
	  storeBooking(conn, bVO);
	  conn.close();
	}
	catch (SQLException se) {
	  throw new EJBException("[Olala] CancelHotelBooking() : SQL Error");
	}
	catch (Exception e) {
	  throw new EJBException("[Olala] CancelHotelBooking() : Exception, May be SOAP Error");
	}
  }

  //private void CancelBooking(String booking)
  public void CancelAirlineBookingDetail(String airlineBookingID, int itemNo) throws ReserveException {
	System.out.println("CancelAirlineBookingDetail");
	try {
	  airBookingService.CancelBookingDetail(airlineBookingID, itemNo);
	}
	catch (RemoteException re) {
	  throw new EJBException("[Olala] CancelHotelBookingDetail() : Internal Remote Error");
	}
	catch (Exception e) {
	  throw new EJBException("[Olala] CancelHotelBookingDetail() : Exception");
	}
  }

  public void CancelHotelBookingDetail(int hotelBookingID, int itemNo) {
	System.out.println("CancelHotelBookingDetail");
	try {
	  hotelService.CancelBookingDetail(hotelBookingID, itemNo);
	}
	catch (Exception re) {
	  throw new EJBException("[OlalaTour] CancelHotelBookingDetail");
	}
  }

  public void ConfirmBooking(String bookingID) throws ReserveException{
	// We Must Confirm all, AirlineBooking and HotelBooking
	Connection conn = null;
	try {
	  conn = dataSource.getConnection();
	  System.out.print("Loading Tour Booking ID = \"" + bookingID + "\"");
	  BookingVO bVO = loadBooking( conn, bookingID );
	  System.out.println("Done with bookingVO = " + bVO);

	  java.sql.Date today = new java.sql.Date(System.currentTimeMillis());
	  if (bVO.getConfirmDeadline().before(today)) {
		 System.out.println("[OlalaTour] Cannot Confirm : Date Expired");
		 throw new ReserveException();
	  }
	  String airBookingID = bVO.getAirlineBookingID();
	  System.out.println("AirlineBookingID of Tour = \"" + airBookingID + "\"");
	  Integer hotelBookingID = bVO.getHotelBookingID();
	  System.out.println("HotelBookingID of Tour = \"" + hotelBookingID + "\"");

	  // Confirm Airline
	  if (airBookingID != null) {
		airBookingService.Confirm( airBookingID.trim() );
	  }

	  // Confirm Hotel
	  if (hotelBookingID != null) {
		if (hotelBookingID.intValue() != 0) {
		 hotelService.ConfirmBooking( hotelBookingID.intValue() );
		}
	  }
	  // Set Confirmation Flag of Tour Booking
	  bVO.setConfirmation(1);
	  // Update Result
	  System.out.print("Connection of Tour is " + conn + ", try to store updated row...");
	  System.out.println("BookingID : " + bVO.getBookingID());
	  System.out.println("AirlineBookingID : " + bVO.getAirlineBookingID());
	  System.out.println("HotelBookingID : " + bVO.getHotelBookingID());
	  System.out.println("CustomerID : " + bVO.getCustomerID());
	  System.out.println("Confirmation : " + bVO.getConfirmation());
	  System.out.println("ConfirmDeadline : " + bVO.getConfirmDeadline());
	  System.out.println("Obsoleted : " + bVO.isObsoleted());
	  System.out.println("Tx ID : " + bVO.getTransactionID());
	  System.out.println("Tx Date : " + bVO.getTransactionDate());
	  storeBooking(conn, bVO);
	  System.out.println("Done");
	  conn.close();
	}
	catch (ReserveException re) {
	  re.printStackTrace();
	  throw new EJBException ("[OlalaTour] ConfirmBooking() : Cannot Reserve Airline");
	}
	catch (SQLException se) {
	  se.printStackTrace();
	  throw new EJBException ("[OlalaTour] ConfirmBooking() : Cannot Load Booking ID#" + bookingID);
	}
	catch (Exception e) {
	  e.printStackTrace();
	  throw new EJBException ("[OlalaTour] ConfirmBooking() : Exception");
	}
	finally {
	  closeConnection(conn);
	}
  }

  public HotelBookingVO GetHotelBooking(int hotelBookingID) {
	try {
	  HotelBookingVO[] hotelBookings = hotelService.GetHotelBooking(TOUR_HOTEL_CUSTOMERID);
	  for (int i=0; i<hotelBookings.length; i++) {
		if (hotelBookingID == (hotelBookings[i].getHotelBookingID())) {
		   return hotelBookings[i];
	    }
	  }
	  return null; // not found
	}
	catch (Exception e) {
	  throw new EJBException ("[OlalaTour] GetHotelBooking() : Exception");
	}
  }

  public olala.airlinesystem.BookingVO GetAirlineBooking(String airBookingID) throws RemoteException {
	try {
	  return airBookingService.GetBooking(airBookingID);
	}
	catch (RemoteException re)  {
	  throw new EJBException("[OlalaTour] GetAirlineBooking()");
	}
  }

  public Collection ViewAirlineBooking(String airBookingID) {
	try {
	  return airBookingService.ViewBooking(airBookingID);
	}
	catch (RemoteException re) {
	  throw new EJBException("[OlalaTour] ViewAirlineBooking()");
	}
  }

  public HotelBookingDetailVO[] GetHotelBookingDetail(int hotelBooking) {
	try {
	  return hotelService.GetHotelBookingDetail(hotelBooking);
	}
	catch (Exception e) {
	  throw new EJBException ("[OlalaTour] GetHotelBookingDetail() : Exception");
	}
  }

  public Collection GetCustomerBookings(String customerID) {
    Connection conn = null;
	PreparedStatement stmt = null;
	String strSelCustomerBooking = "SELECT BookingID, AirlineBookingID, HotelBookingID, CustomerID, Confirmation, ConfirmDeadline, Obsoleted, TransactionID, TransactionDate FROM Booking WHERE CustomerID = ?";
	Collection result = new ArrayList();
	try {
	  conn = dataSource.getConnection();
	  stmt = conn.prepareStatement(strSelCustomerBooking);
	  stmt.setString(1, customerID);
	  ResultSet rs = stmt.executeQuery();
	  while (rs.next()) {
		String bookingID                   = rs.getString(1);
		String airlineBookingID            = rs.getString(2);
		int hotelBookingID                 = rs.getInt(3);
		//String customerID                  = rs.getString(4);
		int confirmation                   = rs.getInt(5);
		java.sql.Timestamp confirmDeadline = rs.getTimestamp(6);
		boolean obsoleted                  = rs.getBoolean(7);
		int transactionID                  = rs.getInt(8);
		java.sql.Timestamp transactionDate = rs.getTimestamp(9);

		result.add(new BookingVO(bookingID, airlineBookingID, new Integer(hotelBookingID),
					             customerID, confirmation, confirmDeadline,
							obsoleted, new Integer(transactionID), transactionDate));
	  }
	  conn.close();
	  return result;
	}
	catch (SQLException e) {
	  e.printStackTrace();
	  throw new EJBException("[OlalaTour] GetCustomerBookings : SQL Error");
	}
	finally {
	  closeConnection(conn);
	}
  }

  public BookingVO GetBooking(String bookingID) {
	Connection conn = null;
	try {
	  conn = dataSource.getConnection();
	  BookingVO bVO = loadBooking(conn, bookingID);
	  conn.close();
	  return bVO;
	}
	catch (SQLException se) {
	  throw new EJBException ("[OlalaTour] GetBooking() : Cannot load booking ID#"+bookingID);
	}
	finally {
	  closeConnection(conn);
	}
  }

  // Data Access Part
  private BookingVO loadBooking(Connection conn, String tourBookingID) throws SQLException {
	PreparedStatement stmt = null;

	String strSelectBooking = "SELECT BookingID, AirlineBookingID, HotelBookingID, CustomerID, Confirmation, ConfirmDeadline, Obsoleted, TransactionID, TransactionDate " +
							  "FROM Booking  WHERE BookingID = ?";

	stmt = conn.prepareStatement(strSelectBooking);
	stmt.setString(1, tourBookingID);

	ResultSet rs = stmt.executeQuery();
	if (rs.next()) {
	   String bookingID                   = rs.getString(1);
	   String airlineBookingID            = rs.getString(2);
	   int hotelBookingID                 = rs.getInt(3);
	   String customerID                  = rs.getString(4);
	   int confirmation                   = rs.getInt(5);
	   java.sql.Timestamp confirmDeadline = rs.getTimestamp(6);
	   boolean obsoleted                  = rs.getBoolean(7);
	   int transactionID                  = rs.getInt(8);
	   java.sql.Timestamp transactionDate = rs.getTimestamp(9);
	   //conn.close();
	   return new BookingVO(bookingID, airlineBookingID, new Integer(hotelBookingID), customerID, confirmation, confirmDeadline,
							obsoleted, new Integer(transactionID), transactionDate);
	}
	else {
	  //conn.close();
	  return null;
	}
  }

  private void storeBooking(Connection conn, BookingVO bVO) throws SQLException {
	PreparedStatement stmt = null;

	String strInsBooking = "UPDATE Booking SET AirlineBookingID=?, HotelBookingID=?, CustomerID=?, Confirmation=?,ConfirmDeadline=?,Obsoleted=?,TransactionID=?,TransactionDate=? WHERE BookingID = ?";

	stmt = conn.prepareStatement(strInsBooking);

	stmt.setString(1, bVO.getAirlineBookingID());
	stmt.setInt(2, bVO.getHotelBookingID().intValue());
	stmt.setString(3, bVO.getCustomerID());
	stmt.setInt(4, bVO.getConfirmation());
	stmt.setTimestamp(5, bVO.getConfirmDeadline());
	stmt.setBoolean(6, bVO.isObsoleted());
	stmt.setInt(7, bVO.getTransactionID().intValue());
	stmt.setTimestamp(8, bVO.getTransactionDate());
	stmt.setString(9, bVO.getBookingID());

	stmt.executeUpdate();
	stmt.close();
	//conn.close();
  }

  private void closeConnection(Connection conn) {
	try {
	  if (conn != null) { conn.close(); }
	}
	catch (Exception e) {}
  }

  private void insertBooking(Connection conn, BookingVO bVO) throws SQLException {
	PreparedStatement stmt = null;

	String strInsBooking = "INSERT INTO Booking VALUES (?,?,?,?,?,?,?,?,?)";

	stmt = conn.prepareStatement(strInsBooking);
	stmt.setString(1, bVO.getBookingID());
	stmt.setString(2, bVO.getAirlineBookingID());
	stmt.setInt(3, bVO.getHotelBookingID().intValue());
	stmt.setString(4, bVO.getCustomerID());
	stmt.setInt(5, bVO.getConfirmation());
	stmt.setTimestamp(6, bVO.getConfirmDeadline());
	stmt.setBoolean(7, bVO.isObsoleted());
	stmt.setInt(8, bVO.getTransactionID().intValue());
	stmt.setTimestamp(9, bVO.getTransactionDate());

	stmt.executeUpdate();
	stmt.close();
	conn.close();
  }

  public void ejbCreate() {
  }
  public void ejbRemove() throws RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setSessionContext(SessionContext sessionContext) throws RemoteException {

	this.sessionContext = sessionContext;
	System.out.println("[OlalaTour] BookingService setSessionContext() was called");
	Context ctx = null;
	try {
	  ctx = new InitialContext();
	  // Initializing Hotel Service
	  String url = (String)ctx.lookup("java:comp/env/HotelServiceURL");
	  System.out.println("Found Environment variable \"java:comp/env/HotelServiceURL\"");
	  Integer tour_hotel_customerID = (Integer)ctx.lookup("java:comp/env/TOUR_HOTEL_CUSTOMERID");
	  if (tour_hotel_customerID != null) {
		TOUR_HOTEL_CUSTOMERID = tour_hotel_customerID.intValue();

	  }
	  System.out.print("Initializing HotelService....");
	  System.out.println("URL : " + url);
	  hotelService = new HotelService(url);
	  System.out.println("Done");

	  // Initializing Airline Service
	  // Lookup Home
	  System.out.print("Initializing Airline BookingService....");
	  String tour_air_customerID = (String)ctx.lookup("java:comp/env/TOUR_AIR_CUSTOMERID");

	  if (tour_air_customerID != null) {
		System.out.println("Found TOUR_AIR_CUSTOMERID = " + tour_air_customerID);
		TOUR_AIR_CUSTOMERID = tour_air_customerID;
	  }

	  olala.airlinesystem.BookingServiceHome airBookingServiceHome =
	        (olala.airlinesystem.BookingServiceHome)
			PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/AirBookingService"), olala.airlinesystem.BookingServiceHome.class);
	  // Create Remote
	  airBookingService = airBookingServiceHome.create();
	  System.out.println("Done");

	  // Initializing UUID Generator
	  // Lookup Home
	  System.out.print("Initializing UUID Generator....");
	  olala.util.UUIDHome uuidHome = (olala.util.UUIDHome)
			PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/UUID"), olala.util.UUIDHome.class);
	  // Create Remote
	  uuid = uuidHome.create();
	  System.out.println("Done");

	  // Initializing DataSource
	  System.out.print("Initializing DataSource...");
	  dataSource = (DataSource) ctx.lookup("java:comp/env/jdbc/DataSource");
	  System.out.println("Done");
	}
	catch (NamingException e){
	  e.printStackTrace();
	  throw new RemoteException("NamingException occured");
	}
	catch (CreateException ce) {
	  ce.printStackTrace();
	  throw new RemoteException("CreateException with internal Component");
	}
  }
}