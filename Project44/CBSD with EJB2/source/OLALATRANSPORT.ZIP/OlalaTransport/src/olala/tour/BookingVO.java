package olala.tour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingVO implements Serializable {
  private String bookingID;
  private String airlineBookingID;
  private Integer hotelBookingID;
  private String customerID;
  private int confirmation;
  private java.sql.Timestamp confirmDeadline;
  private boolean obsoleted;
  private Integer transactionID;
  private java.sql.Timestamp transactionDate;

  public BookingVO() {
  }
  public BookingVO(String bookingID, String airlineBookingID, Integer hotelBookingID,
		           String customerID, int confirmation,
				   java.sql.Timestamp confirmDeadline,
				   boolean obsoleted, Integer transactionID, java.sql.Timestamp transactionDate)
  {
	this.bookingID = bookingID;
	this.airlineBookingID = airlineBookingID;
	this.hotelBookingID = hotelBookingID;
	this.customerID = customerID;
	this.confirmation = confirmation;
	this.confirmDeadline = confirmDeadline;
	this.obsoleted = obsoleted;
	this.transactionID = transactionID;
	this.transactionDate = transactionDate;
  }
  public String getBookingID() {
    return bookingID;
  }
  public String getAirlineBookingID() {
    return airlineBookingID;
  }
  public Integer getHotelBookingID() {
    return hotelBookingID;
  }
  public String getCustomerID() {
    return customerID;
  }
  public int getConfirmation() {
    return confirmation;
  }
  public java.sql.Timestamp getConfirmDeadline() {
    return confirmDeadline;
  }
  public boolean isObsoleted() {
    return obsoleted;
  }
  public Integer getTransactionID() {
    return transactionID;
  }
  public java.sql.Timestamp getTransactionDate() {
    return transactionDate;
  }
  public void setBookingID(String bookingID) {
    this.bookingID = bookingID;
  }
  public void setAirlineBookingID(String airlineBookingID) {
    this.airlineBookingID = airlineBookingID;
  }
  public void setHotelBookingID(Integer hotelBookingID) {
    this.hotelBookingID = hotelBookingID;
  }
  public void setCustomerID(String customerID) {
    this.customerID = customerID;
  }
  public void setConfirmation(int confirmation) {
    this.confirmation = confirmation;
  }
  public void setConfirmDeadline(java.sql.Timestamp confirmDeadline) {
    this.confirmDeadline = confirmDeadline;
  }
  public void setObsoleted(boolean obsoleted) {
    this.obsoleted = obsoleted;
  }
  public void setTransactionID(Integer transactionID) {
    this.transactionID = transactionID;
  }
  public void setTransactionDate(java.sql.Timestamp transactionDate) {
    this.transactionDate = transactionDate;
  }
}