package olala.tour;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.Date;
import java.sql.Time;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class HotelAddToCartServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String CART_PAGE = "../cart.jsp";

  /**Initialize global variables*/
  public void init() throws ServletException {
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    /* ========================= Get Request Parameters ========================= */
    String hotelID = request.getParameter("hotelID");
    String hotelName = request.getParameter("hotelName");
    String roomModelID = request.getParameter("roomModelID");
    java.util.Date checkInDate = olala.util.convert.StringToDate(request.getParameter("checkInDate"));
    java.util.Date checkOutDate = olala.util.convert.StringToDate(request.getParameter("checkOutDate"));
    int amountOfRoom = Integer.parseInt(request.getParameter("amountOfRoom"));
    double price = Double.parseDouble(request.getParameter("price"));

    /* ========================= Construct Shopping Cart ========================= */
    olala.hotel.ReserveHotelDetail item = new olala.hotel.ReserveHotelDetail(hotelID,
                                                roomModelID,
                                                hotelName,
                                                checkInDate,
                                                checkOutDate,
                                                amountOfRoom,
                                                (int) price);

    HttpSession session = request.getSession(true);
    ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("HotelAddToCartServlet - Get shopping cart session ... Done");

    if (shoppingCart == null) {
      shoppingCart = new ShoppingCart();
      System.out.println("HotelAddToCartServlet - Construct new shopping cart ... Done");
    }

    shoppingCart.addHotelItem(item);
    session.setAttribute("ShoppingCart", shoppingCart);
    System.out.println("HotelAddToCartServlet - Add more item to shopping cart ... Done");

    shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("HotelAddToCartServlet - Reget shopping cart session ... Done");
    System.out.println("HotelAddToCartServlet - Redirecting to shopping cart ...");
    response.sendRedirect(CART_PAGE);
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}