package olala.tour;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.ejb.*;
import java.rmi.*;
import javax.rmi.*;
import javax.naming.*;

import olala.airlinesystem.*;
import olala.util.*;

/**
 * Title:         CancelBookingServlet.java
 * Description:   Cancel a whole booking and all details.
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class CancelBookingServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String TARGET_PAGE = "../listBooking.jsp";

  private olala.tour.BookingServiceHome bookingServiceHome;
  private olala.tour.BookingService bookingService;

  /**Initialize global variables*/
  public void init() throws ServletException {
    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("java:comp/env/ejb/TourBookingService");

      //cast to Home interface
      bookingServiceHome = (olala.tour.BookingServiceHome) PortableRemoteObject.narrow(ref, olala.tour.BookingServiceHome.class);
    }
    catch(Exception e) {
      System.out.println("==> Exception in CancelBookingServlet.init() <==");
      e.printStackTrace();
    }
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    try {
      bookingService = bookingServiceHome.create();
      String bookingID = request.getParameter("bookingID").trim();
      System.out.println("CancelBookingServlet - Cancelling booking ID " + bookingID);
      bookingService.CancelBooking(bookingID);
      response.sendRedirect(TARGET_PAGE + "?msgCode=0");
    }
    catch (CreateException ce) {
      ce.printStackTrace();
    }
    catch (ReserveException rse) {
      rse.printStackTrace();
    }
    catch (RemoteException re) {
      re.printStackTrace();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}