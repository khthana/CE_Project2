package olala.tour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public interface BookingServiceHome extends EJBHome {
  public BookingService create() throws RemoteException, CreateException;
}