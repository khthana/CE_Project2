package olala.tour;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Title:         RemoveFromCartServlet.java
 * Description:   Remove an item from shopping cart
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class RemoveFromCartServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  private static final String CART_PAGE = "../cart.jsp";

  /**Initialize global variables*/
  public void init() throws ServletException {
  }

  /**Process the HTTP Get request*/
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    HttpSession session = request.getSession(true);
    String type = request.getParameter("type");
    int index = Integer.parseInt(request.getParameter("index"));
    System.out.println("RemoveFromCartServlet - Get all request parameters ... Done");

    ShoppingCart shoppingCart = (ShoppingCart)session.getAttribute("ShoppingCart");
    System.out.println("RemoveFromCartServlet - Get shopping cart session ... Done");

    if (type.equals("air")) {
      shoppingCart.removeAirItem(index);
    }
    else if (type.equals("hotel")) {
      shoppingCart.removeHotelItem(index);
    }
    System.out.println("RemoveFromCartServlet - Remove an item from cart ... Done");

    session.setAttribute("ShoppingCart", shoppingCart);
    System.out.println("RemoveFromCartServlet - Store new cart back to session ... Done");

    System.out.println("RemoveFromCartServlet - Redirecting to shopping cart ...");
    response.sendRedirect(CART_PAGE);
  }

  /**Process the HTTP Post request*/
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  /**Clean up resources*/
  public void destroy() {
  }
}
