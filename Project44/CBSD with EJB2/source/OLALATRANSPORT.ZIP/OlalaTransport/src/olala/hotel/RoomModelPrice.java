package olala.hotel;

import java.io.*;

public class RoomModelPrice implements Serializable
{

  private String roomModelID;
  private String roomModelName;
  private PricePerDay[] colPricePerDay;
  public RoomModelPrice()
  {
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException
  {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException
  {
    oos.defaultWriteObject();
  }
  public PricePerDay[] getColPricePerDay()
  {
    return colPricePerDay;
  }
  public String getRoomModelID()
  {
    return roomModelID;
  }
  public String getRoomModelName()
  {
    return roomModelName;
  }
  public void setColPricePerDay(PricePerDay[] colPricePerDay)
  {
    this.colPricePerDay = colPricePerDay;
  }
  public void setRoomModelID(String roomModelID)
  {
    this.roomModelID = roomModelID;
  }
  public void setRoomModelName(String roomModelName)
  {
    this.roomModelName = roomModelName;
  }
}