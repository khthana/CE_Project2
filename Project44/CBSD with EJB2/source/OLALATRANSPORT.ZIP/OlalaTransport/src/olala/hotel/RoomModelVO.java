package olala.hotel;

import java.io.*;

public class RoomModelVO implements Serializable
{

  private String roomModelName;
  private int maxGuest;
  private int numOfBedroom;
  private int numOfCoupleBed;
  private int numOflivingroom;
  private int numOfSingleBed;
  private int numOfToilet;
  private boolean aircondition;
  private boolean terrace;
  private boolean telephone;
  private int roomModelID;

  public RoomModelVO()
  {
  }
  public boolean isAircondition() {
    return aircondition;
  }
  public int getMaxGuest() {
    return maxGuest;
  }
  public int getNumOfBedroom() {
    return numOfBedroom;
  }
  public int getNumOfCoupleBed() {
    return numOfCoupleBed;
  }
  public int getNumOflivingroom() {
    return numOflivingroom;
  }
  public int getNumOfSingleBed() {
    return numOfSingleBed;
  }
  public int getNumOfToilet() {
    return numOfToilet;
  }
  public int getRoomModelID() {
    return roomModelID;
  }
  public String getRoomModelName() {
    return roomModelName;
  }
  public boolean isTelephone() {
    return telephone;
  }
  public boolean isTerrace() {
    return terrace;
  }
  public void setAircondition(boolean aircondition) {
    this.aircondition = aircondition;
  }
  public void setMaxGuest(int maxGuest) {
    this.maxGuest = maxGuest;
  }
  public void setNumOfBedroom(int numOfBedroom) {
    this.numOfBedroom = numOfBedroom;
  }
  public void setNumOfCoupleBed(int numOfCoupleBed) {
    this.numOfCoupleBed = numOfCoupleBed;
  }
  public void setNumOflivingroom(int numOflivingroom) {
    this.numOflivingroom = numOflivingroom;
  }
  public void setNumOfSingleBed(int numOfSingleBed) {
    this.numOfSingleBed = numOfSingleBed;
  }
  public void setNumOfToilet(int numOfToilet) {
    this.numOfToilet = numOfToilet;
  }
  public void setRoomModelID(int roomModelID) {
    this.roomModelID = roomModelID;
  }
  public void setRoomModelName(String roomModelName) {
    this.roomModelName = roomModelName;
  }
  public void setTelephone(boolean telephone) {
    this.telephone = telephone;
  }
  public void setTerrace(boolean terrace) {
    this.terrace = terrace;
  }
}