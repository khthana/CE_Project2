package olala.hotel;

import java.io.*;
import java.util.*;

public class HotelBookingVO implements Serializable
{
  private int hotelBookingID;
  private int customerID;
  private boolean confirmation;
  private boolean obsoleted;
  private java.util.Date confirmDeadline;
  private int totalPrice;
  public HotelBookingVO()
  {
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException
  {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException
  {
    oos.defaultWriteObject();
  }
  public boolean isConfirmation()
  {
    return confirmation;
  }
  public java.util.Date getConfirmDeadline()
  {
    return confirmDeadline;
  }
  public int getCustomerID()
  {
    return customerID;
  }
  public int getHotelBookingID()
  {
    return hotelBookingID;
  }
  public boolean isObsoleted()
  {
    return obsoleted;
  }
  public int getTotalPrice()
  {
    return totalPrice;
  }
  public void setConfirmation(boolean confirmation)
  {
    this.confirmation = confirmation;
  }
  public void setConfirmDeadline(java.util.Date confirmDeadline)
  {
    this.confirmDeadline = confirmDeadline;
  }
  public void setCustomerID(int customerID)
  {
    this.customerID = customerID;
  }
  public void setHotelBookingID(int hotelBookingID)
  {
    this.hotelBookingID = hotelBookingID;
  }
  public void setObsoleted(boolean obsoleted)
  {
    this.obsoleted = obsoleted;
  }
  public void setTotalPrice(int totalPrice)
  {
    this.totalPrice = totalPrice;
  }
}