package olala.hotel;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.util.*;

public class HotelBookingVOSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    HotelBookingVO src2 = (HotelBookingVO)src;
    Parameter param;

    param = new Parameter("HotelBookingID", Integer.class,new Integer(src2.getHotelBookingID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("CustomerID", Integer.class,new Integer(src2.getCustomerID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("Confirmation", Boolean.class,new Boolean(src2.isConfirmation()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("Obsoleted", Boolean.class,new Boolean(src2.isObsoleted()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("ConfirmDeadline", String.class,convert.DateToString(src2.getConfirmDeadline()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("TotalPrice", Integer.class,new Integer(src2.getTotalPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    HotelBookingVO target;

    try
    {
      target =(HotelBookingVO)HotelBookingVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("HotelBookingID"))
      {
        target.setHotelBookingID(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("CustomerID"))
      {
        target.setCustomerID(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("Confirmation"))
      {
        target.setConfirmation(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("Obsoleted"))
      {
        target.setObsoleted(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("ConfirmDeadline"))
      {
        target.setConfirmDeadline(convert.StringToDate((String)param.getValue()));
      }
      if (tagName.equals("TotalPrice"))
      {
        target.setTotalPrice(((Integer)param.getValue()).intValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(HotelBookingVO.class, target);

  }
}