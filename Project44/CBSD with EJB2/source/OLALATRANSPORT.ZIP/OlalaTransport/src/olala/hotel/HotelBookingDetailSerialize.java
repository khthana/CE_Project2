package olala.hotel;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.util.*;
public class HotelBookingDetailSerialize  implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    HotelBookingDetailVO src2 = (HotelBookingDetailVO)src;
    Parameter param;

    param = new Parameter("RoomNo", String.class,src2.getRoomNo(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("HotelName", String.class,src2.getHotelName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("RoomModelName", String.class,src2.getRoomModelName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("ItemNo", Integer.class,new Integer(src2.getItemNo()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("HotelBookingID", Integer.class,new Integer(src2.getHotelBookingID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("HotelID", Integer.class,new Integer(src2.getHotelID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("BookCheckIn", String.class,convert.DateToString(src2.getBookCheckIn()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("BookCheckOut", String.class,convert.DateToString(src2.getBookCheckOut()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("BookingPrice", Integer.class,new Integer(src2.getBookingPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("Obsoleted", Boolean.class,new Boolean(src2.isObsoleted()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    HotelBookingDetailVO target;

    try
    {
      target =(HotelBookingDetailVO)HotelBookingDetailVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("RoomNo"))
      {
        target.setRoomNo(((String)param.getValue()));
      }
      if (tagName.equals("HotelName"))
      {
        target.setHotelName(((String)param.getValue()));
      }
      if (tagName.equals("RoomModelName"))
      {
        target.setRoomModelName(((String)param.getValue()));
      }
      if (tagName.equals("ItemNo"))
      {
        target.setItemNo(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("HotelBookingID"))
      {
        target.setHotelBookingID(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("HotelID"))
      {
        target.setHotelID(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("BookCheckIn"))
      {
        target.setBookCheckIn(convert.StringToDate((String)param.getValue()));
      }
      if (tagName.equals("BookCheckOut"))
      {
        target.setBookCheckOut(convert.StringToDate((String)param.getValue()));
      }
      if (tagName.equals("BookingPrice"))
      {
        target.setBookingPrice(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("Obsoleted"))
      {
        target.setObsoleted(((Boolean)param.getValue()).booleanValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(HotelBookingDetailVO.class, target);

  }
}