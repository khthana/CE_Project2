package olala.hotel;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
public class RoomModelVOSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    RoomModelVO src2 = (RoomModelVO)src;
    Parameter param;

    param = new Parameter("RoomModelName", String.class,src2.getRoomModelName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("MaxGuest", Integer.class,new Integer(src2.getMaxGuest()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("MaxGuest", Integer.class,new Integer(src2.getMaxGuest()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("NumOfBedroom", Integer.class,new Integer(src2.getNumOfBedroom()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("NumOfCoupleBed", Integer.class,new Integer(src2.getNumOfCoupleBed()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("NumOflivingroom", Integer.class,new Integer(src2.getNumOflivingroom()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("NumOfSingleBed", Integer.class,new Integer(src2.getNumOfSingleBed()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("NumOfToilet", Integer.class,new Integer(src2.getNumOfToilet()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("Aircondition", Boolean.class,new Boolean(src2.isAircondition()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("Terrace", Boolean.class,new Boolean(src2.isTerrace()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("Telephone", Boolean.class,new Boolean(src2.isTelephone()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("RoomModelID", Integer.class,new Integer(src2.getRoomModelID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    RoomModelVO target;

    try
    {
      target =(RoomModelVO)RoomModelVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("RoomModelName"))
      {
        target.setRoomModelName(((String)param.getValue()));
      }
      if (tagName.equals("MaxGuest"))
      {
        target.setMaxGuest(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("NumOfBedroom"))
      {
        target.setNumOfBedroom(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("NumOfCoupleBed"))
      {
        target.setNumOfCoupleBed(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("NumOflivingroom"))
      {
        target.setNumOflivingroom(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("NumOfSingleBed"))
      {
        target.setNumOfSingleBed(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("NumOfToilet"))
      {
        target.setNumOfToilet(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("Aircondition"))
      {
        target.setAircondition(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("Terrace"))
      {
        target.setTerrace(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("Telephone"))
      {
        target.setTelephone(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("RoomModelID"))
      {
        target.setRoomModelID(((Integer)param.getValue()).intValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(RoomModelVO.class, target);

  }

}