package olala.hotel;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.util.*;
public class ReserveHotelDetailSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    ReserveHotelDetail src2 = (ReserveHotelDetail)src;
    Parameter param;

    param = new Parameter("HotelID", String.class,src2.getHotelID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("RoomModelID", String.class,src2.getRoomModelID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("HotelName", String.class,src2.getHotelName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("BookCheckIn", String.class,convert.DateToString(src2.getBookCheckIn()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("BookCheckOut", String.class,convert.DateToString(src2.getBookCheckOut()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("AmountOfRoom", Integer.class, new Integer(src2.getAmountOfRoom()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("BookingPrice", Integer.class, new Integer(src2.getBookingPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    ReserveHotelDetail target;

    try
    {
      target =(ReserveHotelDetail)ReserveHotelDetail.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("HotelID"))
      {
        target.setHotelID(((String)param.getValue()));
      }
      if (tagName.equals("RoomModelID"))
      {
        target.setRoomModelID(((String)param.getValue()));
      }
      if (tagName.equals("HotelName"))
      {
        target.setHotelName(((String)param.getValue()));
      }
      if (tagName.equals("BookCheckIn"))
      {
        target.setBookCheckIn(convert.StringToDate((String)param.getValue()));
      }
      if (tagName.equals("BookingCheckOut"))
      {
        target.setBookCheckOut(convert.StringToDate((String)param.getValue()));
      }
      if (tagName.equals("AmountOfRoom"))
      {
        target.setAmountOfRoom(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("BookingPrice"))
      {
        target.setBookingPrice(((Integer)param.getValue()).intValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(ReserveHotelDetail.class, target);

  }
}