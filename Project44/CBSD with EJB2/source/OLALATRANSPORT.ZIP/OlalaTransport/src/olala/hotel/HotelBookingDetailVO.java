package olala.hotel;

import java.io.*;

public class HotelBookingDetailVO implements Serializable
{

  private String roomNo;
  private String hotelName;
  private String roomModelName;
  private int itemNo;
  private int hotelBookingID;
  private int hotelID;
  private java.util.Date bookCheckIn;
  private java.util.Date bookCheckOut;
  private int bookingPrice;
  private boolean obsoleted;
  public HotelBookingDetailVO()
  {
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException
  {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException
  {
    oos.defaultWriteObject();
  }
  public java.util.Date getBookCheckIn()
  {
    return bookCheckIn;
  }
  public java.util.Date getBookCheckOut()
  {
    return bookCheckOut;
  }
  public int getBookingPrice()
  {
    return bookingPrice;
  }
  public int getHotelBookingID()
  {
    return hotelBookingID;
  }
  public int getHotelID()
  {
    return hotelID;
  }
  public String getHotelName()
  {
    return hotelName;
  }
  public int getItemNo()
  {
    return itemNo;
  }
  public boolean isObsoleted()
  {
    return obsoleted;
  }
  public String getRoomModelName()
  {
    return roomModelName;
  }
  public String getRoomNo()
  {
    return roomNo;
  }
  public void setBookCheckIn(java.util.Date bookCheckIn)
  {
    this.bookCheckIn = bookCheckIn;
  }
  public void setBookCheckOut(java.util.Date bookCheckOut)
  {
    this.bookCheckOut = bookCheckOut;
  }
  public void setBookingPrice(int bookingPrice)
  {
    this.bookingPrice = bookingPrice;
  }
  public void setHotelBookingID(int hotelBookingID)
  {
    this.hotelBookingID = hotelBookingID;
  }
  public void setHotelID(int hotelID)
  {
    this.hotelID = hotelID;
  }
  public void setHotelName(String hotelName)
  {
    this.hotelName = hotelName;
  }
  public void setItemNo(int itemNo)
  {
    this.itemNo = itemNo;
  }
  public void setObsoleted(boolean obsoleted)
  {
    this.obsoleted = obsoleted;
  }
  public void setRoomModelName(String roomModelName)
  {
    this.roomModelName = roomModelName;
  }
  public void setRoomNo(String roomNo)
  {
    this.roomNo = roomNo;
  }
}