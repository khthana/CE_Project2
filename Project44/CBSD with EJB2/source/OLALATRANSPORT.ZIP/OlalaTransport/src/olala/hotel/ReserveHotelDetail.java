package olala.hotel;

import java.io.*;

public class ReserveHotelDetail implements Serializable
{
  private String hotelID;
  private String roomModelID;
  private String hotelName;
  private java.util.Date bookCheckIn;
  private java.util.Date bookCheckOut;
  private int amountOfRoom;
  private int bookingPrice;
  public ReserveHotelDetail()
  {
  }

  public ReserveHotelDetail(String hotelID, String roomModelID, String hotelName,
		                    java.util.Date bookCheckIn, java.util.Date bookCheckOut,
							int amountOfRoom, int bookingPrice )
  {
	this.hotelID = hotelID;
	this.roomModelID = roomModelID;
	this.hotelName = hotelName;
	this.bookCheckIn = bookCheckIn;
	this.bookCheckOut = bookCheckOut;
	this.amountOfRoom = amountOfRoom;
	this.bookingPrice = bookingPrice;
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException
  {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException
  {
    oos.defaultWriteObject();
  }
  public int getAmountOfRoom()
  {
    return amountOfRoom;
  }
  public java.util.Date getBookCheckIn()
  {
    return bookCheckIn;
  }
  public java.util.Date getBookCheckOut()
  {
    return bookCheckOut;
  }
  public int getBookingPrice()
  {
    return bookingPrice;
  }
  public String getHotelID()
  {
    return hotelID;
  }
  public String getHotelName()
  {
    return hotelName;
  }
  public String getRoomModelID()
  {
    return roomModelID;
  }
  public void setAmountOfRoom(int amountOfRoom)
  {
    this.amountOfRoom = amountOfRoom;
  }
  public void setBookCheckIn(java.util.Date bookCheckIn)
  {
    this.bookCheckIn = bookCheckIn;
  }
  public void setBookCheckOut(java.util.Date bookCheckOut)
  {
    this.bookCheckOut = bookCheckOut;
  }
  public void setBookingPrice(int bookingPrice)
  {
    this.bookingPrice = bookingPrice;
  }
  public void setHotelID(String hotelID)
  {
    this.hotelID = hotelID;
  }
  public void setHotelName(String hotelName)
  {
    this.hotelName = hotelName;
  }
  public void setRoomModelID(String roomModelID)
  {
    this.roomModelID = roomModelID;
  }
}