package olala.hotel;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PricePerDay implements Serializable {
  private double price;
  private java.util.Date day;

  public PricePerDay() {
  }
  public java.util.Date getDay() {
    return day;
  }
  public void setDay(java.util.Date day) {
    this.day = day;
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}