package olala.hotel;

import java.io.*;

public class HotelVO implements Serializable
{
  int hotelID;
  String hotelName;
  String city;
  String country;
  String imageMapPath;
  int star;
  public HotelVO()
  {
  }
  public String getCity()
  {
    return city;
  }
  public String getCountry()
  {
    return country;
  }
  public int getHotelID()
  {
    return hotelID;
  }
  public String getHotelName()
  {
    return hotelName;
  }
  public String getImageMapPath()
  {
    return imageMapPath;
  }
  public int getStar()
  {
    return star;
  }
  public void setCity(String city)
  {
    this.city = city;
  }
  public void setCountry(String country)
  {
    this.country = country;
  }
  public void setHotelID(int hotelID)
  {
    this.hotelID = hotelID;
  }
  public void setHotelName(String hotelName)
  {
    this.hotelName = hotelName;
  }
  public void setImageMapPath(String imageMapPath)
  {
    this.imageMapPath = imageMapPath;
  }
  public void setStar(int star)
  {
    this.star = star;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException
  {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException
  {
    ois.defaultReadObject();
  }

}