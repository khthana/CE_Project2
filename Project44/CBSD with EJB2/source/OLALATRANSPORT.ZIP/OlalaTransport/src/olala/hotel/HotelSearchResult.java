package olala.hotel;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class HotelSearchResult implements Serializable
{
  private HotelVO objHotel;
  private RoomModelPrice[] colRoomModelPrice;
  HotelSearchResult()
  {}
  public RoomModelPrice[] getColRoomModelPrice()
  {
    return colRoomModelPrice;
  }
  public HotelVO getObjHotel()
  {
    return objHotel;
  }
  public void setColRoomModelPrice(RoomModelPrice[] colRoomModelPrice)
  {
    this.colRoomModelPrice = colRoomModelPrice;
  }
  public void setObjHotel(HotelVO objHotel)
  {
    this.objHotel = objHotel;
  }
}