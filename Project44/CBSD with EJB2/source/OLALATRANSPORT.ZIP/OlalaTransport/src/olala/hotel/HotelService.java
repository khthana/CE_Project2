package olala.hotel;

import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import org.apache.soap.util.*;
import org.apache.soap.util.xml.*;

import org.w3c.dom.*;

import java.net.URL;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

public class HotelService
{
  SOAPMappingRegistry smr = new SOAPMappingRegistry(Constants.NS_URI_CURRENT_SCHEMA_XSD);

  // Serializers-Deserializers of Primitive type
  IntDeserializer      intDser    = new IntDeserializer();
  DoubleDeserializer    doubleDser  = new DoubleDeserializer();
  StringDeserializer   stringDser = new StringDeserializer();
  ArraySerializer      arraySer   = new ArraySerializer();
  BooleanDeserializer    boolDser    = new BooleanDeserializer();

  // Serializers-Deserializers of Hotel Service
  HotelVOSerialize                hotelVOSer              = new HotelVOSerialize();
  HotelBookingVOSerialize         hotelBookingVOSer       = new HotelBookingVOSerialize();
  HotelBookingDetailSerialize     hotelBookingDetailSer   = new HotelBookingDetailSerialize();
  HotelSearchResultSerialize      hotelSearchResultSer    = new HotelSearchResultSerialize();
  ReserveHotelDetailSerialize     reserveHotelDetailSer   = new ReserveHotelDetailSerialize();
  RoomModelPriceSerialize         roomModelPriceSer       = new RoomModelPriceSerialize();
  RoomModelVOSerialize            roomModelVOSer          = new RoomModelVOSerialize();
  PricePerDaySerialize pricePerDaySer = new PricePerDaySerialize();

  public static final String DEFAULT_URL = "http://161.246.5.241:80/hotelservice/service1.asmx";
  public static final String ACTION_URI =  "http://tempuri.org/";
  public static final String OBJECT_URI =  "http://tempuri.org/encodedTypes";
  public Header header = null;

  java.net.URL url = null;
  Call call = new Call();

  // Init SOAP Mapping Registry
  private void initSmr() {
	/**
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "Hotel"),
											HotelVO.class, hotelVOSer, hotelVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "HotelBooking"),
											HotelBookingVO.class, hotelBookingVOSer, hoteBookingVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "HotelBookingDetail"),
											HotelBookingDetailVO.class, hotelBookingDetailVOSer, hotelBookingDetailVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "HotelSearchResult"),
											HotelSearchResult.class, hotelSearchResultSer, hotelSearchResultSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "ReserveHotelDetail"),
											ReserveHotelDetail.class, reserveHotelDetailSer, reserveHotelDetailSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "RoomModelPrice"),
											RoomModelPrice.class, roomModelPriceSer, roomModelPriceSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "RoomModel"),
											RoomModelVO.class, roomModelVOSer, roomModelVOSer);
	*/
	SmrMapType("Hotel", HotelVO.class, hotelVOSer, hotelVOSer);
	SmrMapType("HotelBooking", HotelBookingVO.class, hotelBookingVOSer, hotelBookingVOSer);
	SmrMapType("HotelBookingDetail", HotelBookingDetailVO.class, hotelBookingDetailSer, hotelBookingDetailSer);
	SmrMapType("HotelSearchResult", HotelSearchResult.class, hotelSearchResultSer, hotelSearchResultSer);
	SmrMapType("ReserveHotelDetail", ReserveHotelDetail.class, reserveHotelDetailSer, reserveHotelDetailSer);
	SmrMapType("RoomModelPrice", RoomModelPrice.class, roomModelPriceSer, roomModelPriceSer);
	SmrMapType("RoomModel", RoomModelVO.class, roomModelVOSer, roomModelVOSer);
	SmrMapType("PricePerDay",PricePerDay.class,pricePerDaySer,pricePerDaySer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "colRoomModelPrice"), null,null, arraySer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "colPricePerDay"), null , null, arraySer);
  }

  private void SmrMapType(String name, Class c, Serializer s, Deserializer d) {
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, name), c, s, d);
  }

  public HotelService(String defaultURL) {
	try {
	  url = new java.net.URL(defaultURL);
	}
	catch (java.net.MalformedURLException mfe) {
	  mfe.printStackTrace();
	}
	// Initialize SOAP Mapping Registry
	initSmr();
	call.setSOAPMappingRegistry(smr);
	call.setTargetObjectURI(ACTION_URI);
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
  }



  public HotelVO[] GetHotel(int HotelID)  throws Exception
  {
    // Begin Code
	Vector params = new Vector();
	params.addElement(new Parameter("HotelID", Integer.class, new Integer(HotelID), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "GetHotelResult"), null, null, arraySer);
	return (HotelVO[])doCall(url, "GetHotel", params);
  }

  public RoomModelVO[] GetRoomModel(int RoomModelID)  throws Exception
  {
    // Begin Code
	Vector params = new Vector();
	params.addElement(new Parameter("RoomModelID", Integer.class, new Integer(RoomModelID), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "GetRoomModelResult"), null, null, arraySer);
	return (RoomModelVO[]) doCall(url, "GetRoomModel", params);
  }

  public HotelSearchResult[] SearchHotel(String Country, String State, String City,
										 String HotelName, int MinStar, int MaxStar,
										 String RoomModelName, int AmountOfRoom,
										 int MinPrice,int MaxPrice,
										 String CheckInDate,String CheckOutDate) throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("Country", String.class, Country, null));
	params.addElement(new Parameter("State", String.class, State, null));
	params.addElement(new Parameter("City", String.class, City, null));
	params.addElement(new Parameter("HotelName", String.class, HotelName, null));
	params.addElement(new Parameter("MinStar", Integer.class, new Integer(MinStar), null));
	params.addElement(new Parameter("MaxStar", Integer.class, new Integer(MaxStar), null));
	params.addElement(new Parameter("RoomModelName", String.class, RoomModelName, null));
	params.addElement(new Parameter("AmountOfRoom", Integer.class, new Integer(AmountOfRoom), null));
	params.addElement(new Parameter("MinPrice", Double.class, new Double(MinPrice), null));
	params.addElement(new Parameter("MaxPrice", Double.class, new Double(MaxPrice), null));
	params.addElement(new Parameter("CheckInDate", String.class, CheckInDate, null));
	params.addElement(new Parameter("CheckOutDate", String.class, CheckOutDate, null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "SearchHotelResult"), null, null, arraySer);
	return (HotelSearchResult[]) doCall(url, "SearchHotel", params);
  }

  public HotelBookingVO[] GetHotelBooking(int CustomerID) throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("CustomerID", Integer.class, new Integer(CustomerID), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "GetHotelBookingResult"), null, null, arraySer);
	return (HotelBookingVO[]) doCall(url, "GetHotelBooking", params);
  }

  public int Reserve(int CustomerID, ReserveHotelDetail[] ReserveHotelDetails)  throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("CustomerID", Integer.class, new Integer(CustomerID), null));
	params.addElement(new Parameter("ReserveHotelDetails", ReserveHotelDetail[].class, ReserveHotelDetails, null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Reservesult"), null, null, intDser);
	return ((Integer) doCall(url, "Reserve", params)).intValue();
  }

  public HotelBookingDetailVO[] GetHotelBookingDetail(int HotelBookingID)  throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("HotelBookingID", Integer.class, new Integer(HotelBookingID), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "GetHotelBookingDetailResult"), null, null, arraySer);
	return (HotelBookingDetailVO[]) doCall(url, "GetHotelBookingDetail", params);
  }

  public boolean CancelBooking(int HotelBookingID)  throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("HotelBookingID", Integer.class, new Integer(HotelBookingID), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "CancelBookingResult"), null, null, boolDser);
	return ((Boolean)doCall(url, "CancelBooking", params)).booleanValue();
  }

  public boolean CancelBookingDetail(int HotelBookingID,int ItemNo)  throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("HotelBookingID", Integer.class, new Integer(HotelBookingID), null));
	params.addElement(new Parameter("ItemNo", Integer.class, new Integer(ItemNo), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "CancelBookingDetailResult"), null, null, boolDser);
	return ((Boolean)doCall(url, "CancelBookingDetail", params)).booleanValue();
  }

  public boolean ConfirmBooking(int HotelBookingID)  throws Exception
  {
    Vector params = new Vector();
	params.addElement(new Parameter("HotelBookingID", Integer.class, new Integer(HotelBookingID), null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "ConfirmBookingResult"), null, null, boolDser);
	return ((Boolean)doCall(url, "ConfirmBooking", params)).booleanValue();
  }

  // Internal Method
  private Object doCall(URL url, String methodName, Vector params) throws Exception
  {
    try {
      call.setMethodName(methodName);
      call.setParams(params);
      if (header != null)
        call.setHeader(header);

      String soapAction = ACTION_URI;
      if (true) {
        soapAction = soapAction + methodName;
      }

      Response resp = call.invoke(url, soapAction);

      // check response
      if (!resp.generatedFault()) {
        Parameter ret = resp.getReturnValue();
        Object output = ret.getValue();
//        Object input = param.getValue();
/*
        if (equals(input,output)) {
          System.out.println(methodName + "\t OK");
        } else {
          System.out.println(methodName + "\t FAIL: " + output);
        }
		*/
		return output;
	  }
      else {
        Fault fault = resp.getFault ();
        System.err.println (methodName + " generated fault: ");
        System.out.println ("  Fault Code   = " + fault.getFaultCode());
        System.out.println ("  Fault String = " + fault.getFaultString());
		throw new Exception("SOAP Generate Fault");
      }

    }
	catch (Exception e) {
      e.printStackTrace();
	  throw new Exception("SOAP Exception");
    }
  }

  // Test Unit of HotelService
  public static void main(String args[]) throws Exception
  {
	HotelService hotelService;
	try {
	  hotelService = new HotelService(DEFAULT_URL);
	}
	catch (Exception e) {
	  System.out.println("Error: URL Mulformed.");
	  throw new Exception();
	}
	/*
	System.out.println("-- GetHotel()");
	HotelVO[] hotels = hotelService.GetHotel(0);
	System.out.println("Number of Hotel = " + hotels.length);
	System.out.println(hotels[0].getImageMapPath());

	System.out.println("-- GetRoomModel()");
	RoomModelVO[] roomModels = hotelService.GetRoomModel(0);
	System.out.println("Number of RoomModel = " + roomModels.length);
	*/
	/*
	System.out.println("-- SearchHotel()");
	HotelSearchResult[] hsr = hotelService.SearchHotel("", "", "", "", 1, 5, "", 1, 0, 5000, "2002-1-10", "2002-1-10");
	System.out.println("Number of Result = " + hsr.length);
	*/
	/*
	System.out.println("-- GetHotelBooking()");
	int CustomerID = 1540;
	HotelBookingVO[] hotelBookings = hotelService.GetHotelBooking(CustomerID);
	System.out.println("Number of Hotel Bookings of Customer # = " + hotelBookings.length);


	System.out.println("-- GetHotelBookingDetail()");
	HotelBookingDetailVO[] hotelBookingDetails = hotelService.GetHotelBookingDetail(909);
	System.out.println("Number of Booking Detail = " + hotelBookingDetails.length);
	*/
	/*
	System.out.println("-- Reserve()");
	RoomModelVO[] roomModels = hotelService.GetRoomModel(0);
	System.out.println("Number of RoomModel = " + roomModels.length);

	System.out.println("-- CancelBookingDetail");
	boolean result = hotelService.CancelBookingDetail(909, 1);
	System.out.println("result = " + result);
	*/
	/*
	System.out.println("-- CancelBooking #992");
	boolean result = hotelService.CancelBooking(992);
	System.out.println("result = " + result);
	*/

	/*
	System.out.println("-- ConfirmBooking()");
	boolean result = hotelService.ConfirmBooking(909);
	System.out.println("result = " + result);
	*/

	/*
	System.out.println("SearchHotel()");
	HotelSearchResult[] result=hotelService.SearchHotel("\u0E44\u0E17\u0E22","","\u0E01\u0E23\u0E38\u0E07\u0E40\u0E17\u0E1E","",1,5,"",2,1,10000,"2001-12-12 00:00:00","2001-15-12 00:00:00");
	for (int i=0;i<result.length;i++)
	{
		HotelVO hvo=result[i].getObjHotel();
		System.out.print("Hotel ID :"+hvo.getHotelID());
		System.out.print("HotelName :"+hvo.getHotelName());
		System.out.print("City : "+hvo.getCity());
		System.out.print("Country : "+hvo.getCountry());
		System.out.print("ImageMapPath : "+hvo.getImageMapPath());
		System.out.println("Star : "+hvo.getStar());
		RoomModelPrice[] rmodel=result[i].getColRoomModelPrice();
		for (int k=0;k<rmodel.length;k++)
		{
		  System.out.print("RoomModelID : "+rmodel[k].getRoomModelID());
		  System.out.println("RoomModelName : "+rmodel[k].getRoomModelName());
		  PricePerDay[] pr=rmodel[k].getColPricePerDay();
		  for (int j=0;j<pr.length;j++)
		  {
		    System.out.print("Price : "+pr[j].getPrice());
		    System.out.println("Day : "+pr[j].getDay());
		  }
		}
	}
	*/

	/*
	System.out.println("Reserve");
	ReserveHotelDetail[] hdetail;
	hdetail=new ReserveHotelDetail[1];
	System.out.println(hdetail.length);
	hdetail[0]=new ReserveHotelDetail();
	hdetail[0].setAmountOfRoom(2);
	java.util.Date chin=new java.util.Date(100,12,7);
	java.util.Date chout=new java.util.Date(100,12,7);
	hdetail[0].setBookCheckIn(chin);
	hdetail[0].setBookCheckOut(chout);
	hdetail[0].setBookingPrice(5000);
	hdetail[0].setHotelID("10");
	hdetail[0].setHotelName("Eva n Soniva");
	hdetail[0].setRoomModelID("1");

	int result=hotelService.Reserve(1561,hdetail);

	System.out.println(result);
	*/
  }
}