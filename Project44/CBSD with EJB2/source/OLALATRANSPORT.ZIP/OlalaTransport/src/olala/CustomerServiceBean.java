package olala;

import java.rmi.*;
import javax.ejb.*;
import javax.rmi.*;
import javax.naming.*;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import olala.util.*;

/**
 * Title:         CustomerServiceBean.java
 * Description:   Customer Service Component
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version 1.0
 */

public class CustomerServiceBean implements SessionBean {
  private SessionContext sessionContext;
  private CustomerHome customerHome;
  private DataSource dataSource;
  private UUID uuidgen;

  public String AddCustomer(String customerID, String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) throws RemoteException {
    try {
      Customer cus = customerHome.create(customerID, firstName, lastName, gender, Address, telephone, emailAddress, password, agency);
	  return customerID;
    }
    catch (CreateException ce) {
      System.out.println("==> CreateException in CustomerServiceBean - AddCustomer <==");
      ce.printStackTrace();
      throw new RemoteException();
    }
  }

  public String AddCustomer(String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) throws DuplicateEmailException {
    try {

      // If email already exist -> throw out DuplicateKeyException
      if (isEmailExist(emailAddress)) {
        throw new DuplicateEmailException();
      }

      //int customerID = getMaxID("CustomerID", "Customer") + 1;
	  String customerID = getNewCustomerID();
      Customer cus = customerHome.create(customerID, firstName, lastName, gender, Address, telephone, emailAddress, password, agency);
	  return customerID;
    }
    catch (CreateException ce) {
      System.out.println("==> CreateException in CustomerServiceBean - AddCustomer <==");
      ce.printStackTrace();
      throw new EJBException();
    }
    catch (RemoteException re) {
      System.out.println("==> RemoteException in CustomerServiceBean - AddCustomer <==");
      re.printStackTrace();
      throw new EJBException();
    }
  }

  public boolean EditCustomer(String customerID, String firstName, String lastName, String gender, String address, String telephone, String emailAddress, String password, boolean agency) throws RemoteException {
    try {
      Customer cus = customerHome.findByPrimaryKey(customerID);
      System.out.println("After customerHome.findByPrimaryKey(" + customerID + ") of EditCustomer");
      CustomerVO cusVO = new CustomerVO(customerID, firstName, lastName, gender,
						                address, telephone, emailAddress, password, agency);
      cus.setCustomer(cusVO);
    }
    catch (FinderException e) {
      throw new RemoteException();
    }
    return(true);
  }

  public String Login(String  emailAddress, String password) throws InvalidPasswordException, InvalidUserException, RemoteException {
    String customerID;

    try {
      Iterator i = customerHome.findByEmailAddress(emailAddress).iterator();

      if (i.hasNext()) {
        Customer customer = (Customer) PortableRemoteObject.narrow(i.next(), Customer.class);
        if (password.equals(customer.getPassword())) {
          return (customer.getCustomerID());
        }
        else {
          throw new InvalidPasswordException();
        } // else
      } // if
      else {
        throw new InvalidUserException();
      }
    }
    catch (FinderException fEx) {
      throw new RemoteException();
    }
  }

  public CustomerVO getCustomer(String customerID) throws RemoteException {
    try {
      Customer cus = customerHome.findByPrimaryKey(customerID);
      return cus.getCustomer();
    }
    catch (FinderException e) {
      throw new RemoteException();
    }
  }
  public void ejbCreate() {
  }
  public void ejbRemove() throws RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setSessionContext(SessionContext sessionContext) throws RemoteException {
    this.sessionContext = sessionContext;
    try {
      Context ctx = new InitialContext();

      // look up jndi name and cast to Home interface
      customerHome = (CustomerHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Customer"), CustomerHome.class);
	  // Look up and create primary key generator
	  UUIDHome uuidHome = (UUIDHome) PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/UUID"), UUIDHome.class);
	  uuidgen = uuidHome.create();

      // Use DD editor to map this reference to JNDI name of real DataSource
      dataSource = (DataSource)ctx.lookup("java:comp/env/jdbc/DataSource");

    }
	catch (CreateException ce) {
	  System.out.println("==> CreateException in CustomerServiceBean - setSessionContext <==");
	  throw new RemoteException();
	}
    catch (javax.naming.NamingException ne) {
      System.out.println("==> NamingException in CustomerServiceBean - setSessionContext <==");
      ne.printStackTrace();
      throw new RemoteException();
    }
  }

  /* ============================= HELPER FUCTIONS ================================ */

  private String getNewCustomerID() {
	String newCustomerID = null;
	try {
	  newCustomerID = uuidgen.getUUID();
	}
	catch (RemoteException re) {
	}
	return newCustomerID;
  }

  private boolean isEmailExist(String emailAddress) throws RemoteException{
    try {
      Collection coll = customerHome.findByEmailAddress(emailAddress);
      Iterator i = coll.iterator();
      if (i.hasNext()) {
        return (true);
      }
      else {
        return (false);
      }
    }
    catch (FinderException fe) {
      throw new RemoteException();
    }
  }
}
