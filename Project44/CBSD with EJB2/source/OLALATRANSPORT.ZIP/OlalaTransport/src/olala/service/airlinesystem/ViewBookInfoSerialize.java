package olala.service.airlinesystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import java.sql.Timestamp;
import java.util.Date;
import olala.airlinesystem.*;
import olala.util.*;
public class ViewBookInfoSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    ViewBookInfo src2 = (ViewBookInfo)src;
    Parameter param;

    param = new Parameter("itemNo", Integer.class,new Integer(src2.getItemNo()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("flightID", java.lang.String.class,src2.getFlightID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("classID", String.class,src2.getClassID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departDateTime", String.class,convert.DateToString(new java.util.Date (src2.getDepartDateTime().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveDateTime", String.class,convert.DateToString(new java.util.Date (src2.getArriveDateTime().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("airportSrcID", String.class,src2.getAirportSrcID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("airportSrcName", String.class,src2.getAirportSrcName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("airportDesName", String.class,src2.getAirportDesName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("airportDesID", String.class,src2.getAirportDesID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("totalSeat", Integer.class,new Integer(src2.getTotalSeat()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("price", Double.class,new Double(src2.getPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    ViewBookInfo target;

    try
    {
      target =(ViewBookInfo)ViewBookInfo.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("itemNo"))
      {
        target.setItemNo(((Integer)param.getValue()).intValue());
      }

      if (tagName.equals("flightID"))
      {
        target.setFlightID((String)param.getValue());
      }
      if (tagName.equals("classID"))
      {
        target.setClassID(((String)param.getValue()));
      }
      if (tagName.equals("departDateTime"))
      {
        target.setDepartDateTime(new java.sql.Timestamp(convert.StringToDate((String)param.getValue()).getTime()));
      }
      if (tagName.equals("arriveDateTime"))
      {
        target.setArriveDateTime(new java.sql.Timestamp(convert.StringToDate((String)param.getValue()).getTime()));
      }
      if (tagName.equals("airportSrcID"))
      {
        target.setAirportSrcID(((String)param.getValue()));
      }
      if (tagName.equals("airportSrcName"))
      {
        target.setAirportSrcName(((String)param.getValue()));
      }
      if (tagName.equals("airportDesName"))
      {
        target.setAirportDesName(((String)param.getValue()));
      }
      if (tagName.equals("airportDesID"))
      {
        target.setAirportDesID(((String)param.getValue()));
      }
      if (tagName.equals("totalSeat"))
      {
        target.setTotalSeat(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("price"))
      {
        target.setPrice(((Double)param.getValue()).doubleValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(ViewBookInfo.class, target);

  }

}