package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
import olala.util.*;

public class BusScheduleVOSerialize  implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    BusScheduleVO src2 = (BusScheduleVO)src;
    Parameter param;

    param = new Parameter("routeID", String.class,src2.getRouteID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("subrouteID", Integer.class,new Integer(src2.getSubrouteID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveTime", String.class,convert.TimeToString(src2.getArriveTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departTime", String.class,convert.TimeToString(src2.getDepartTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departDay", int.class, new Integer(src2.getDepartDay()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveDay",int.class, new Integer(src2.getArriveDay()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("idx", int.class, new Integer(src2.getIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    BusScheduleVO target;

    try
    {
      target =(BusScheduleVO)BusScheduleVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("routeID"))
      {
        target.setRouteID(((String)param.getValue()));
      }

      if (tagName.equals("subrouteID"))
      {
        target.setSubrouteID(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("arriveTime"))
      {
        target.setArriveTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("departTime"))
      {
        target.setDepartTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("departDay"))
      {
        target.setDepartDay(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("arriveDay"))
      {
        target.setArriveDay(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("idx"))
      {
        target.setIdx(((Integer)param.getValue()).intValue());
      }


      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(BusScheduleVO.class, target);

  }
}