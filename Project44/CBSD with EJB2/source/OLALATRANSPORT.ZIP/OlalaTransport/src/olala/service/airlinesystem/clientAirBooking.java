package olala.service.airlinesystem;

import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.airlinesystem.*;
import java.util.*;


public class clientAirBooking
{
  SOAPMappingRegistry smr = new SOAPMappingRegistry(Constants.NS_URI_CURRENT_SCHEMA_XSD);

  public static final String DEFAULT_URL = "http://localhost:8090/soap/servlet/rpcrouter";
  public static final String ACTION_URI = "http://olala/AirBooking10/";
  public static final String OBJECT_URI = "http://soapinterop.org/xsd";
  public Header header = null;

  public static void main(String args[])
  {
    URL url = null;

    try {
      if (args.length > 0) {
        url = new URL(args[0]);
      } else {
        url = new URL(DEFAULT_URL);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    clientAirBooking eTest = new clientAirBooking();
    eTest.doWork(url);
  }
  public void doWork(URL url)
  {
    IntDeserializer intDser = new IntDeserializer();
    FloatDeserializer floatDser = new FloatDeserializer();
    StringDeserializer stringDser = new StringDeserializer();
    ArraySerializer arraySer = new ArraySerializer();
//    AircraftClassVOSerialize AircraftClassVOSer = new AircraftClassVOSerialize();
    ViewBookInfoSerialize ViewBookInfoSer = new ViewBookInfoSerialize();
	TravellerSeatSerialize TravellerSeatSer = new TravellerSeatSerialize();
	BookingDetailVOSerialize BookingDetailVOSer = new BookingDetailVOSerialize();
	BookingVOSerialize BookingVOSer = new BookingVOSerialize();
	ReserveItemSerialize ReserveItemSer = new ReserveItemSerialize();
	TravellerVOSerialize TravellerVOSer = new TravellerVOSerialize();
	AirportVOSerialize AirportVOSer = new AirportVOSerialize();
	//AirSeatSearchResultSerialize AirSeatSearchResultSer = new AirSeatSearchResultSerialize();



    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "ViewBookInfo"), ViewBookInfo.class, ViewBookInfoSer, ViewBookInfoSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "TravellerSeat"), TravellerSeat.class, TravellerSeatSer, TravellerSeatSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "BookingDetailVO"), BookingDetailVO.class, BookingDetailVOSer, BookingDetailVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "BookingVO"), BookingVO.class, BookingVOSer, BookingVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "ReserveItem"), ReserveItem.class, ReserveItemSer, ReserveItemSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "TravellerVO"), TravellerVO.class, TravellerVOSer, TravellerVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "AirportVO"), AirportVO.class, AirportVOSer, AirportVOSer);
	//smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "AirSeatSearchResult"), AirSeatSearchResult.class, AirSeatSearchResultSer, AirSeatSearchResultSer);

	Vector params = new Vector();
	String customerID="1";
    Parameter p = new Parameter("customerID", String.class, customerID, null);
	params.addElement(p);
	ReserveItem[] reservelist = new ReserveItem[1];
//	ReserveItem( String flightID, String classID, int totalseat, int srcidx, int desidx,boolean smoking, boolean window, Date departdate)
	reservelist[0]=new ReserveItem("AA330","E",1,1,1,false,false,java.sql.Date.valueOf("2002-7-12"));
	//reservelist[1]=new ReserveItem("003","002",1,4,5,false,true,new java.sql.Date(System.currentTimeMillis()));
	//reservelist[2]=new ReserveItem("003","002",1,4,5,false,true,new java.sql.Date(System.currentTimeMillis()));
	// TravellerVO(String travellerID, String firstname, String lastname)
	TravellerVO tvo=new TravellerVO("","KING","TEAM");
	reservelist[0].AddTraveller(tvo);
	System.out.println("ReserveItem[] Class = " + ReserveItem[].class);
	System.out.println("int[] class = " + int[].class);
	System.out.println("ReserveItem class = " + ReserveItem.class);
	p = new Parameter("reservelist", ReserveItem[].class, reservelist, null);
	params.addElement(p);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Return"), null, null, stringDser);

	// Now call reserve to do that
	System.out.println("Calling Reserve()");
	String bookingID = null;
	//doCall(url, "Reserve", params);
	//System.out.println("Reserve Done with BookingID = " + bookingID);

	bookingID = "9";
	params = new Vector();
	p = new Parameter("bookingID",String.class,bookingID,null);
	params.addElement(p);
	doCall(url, "Confirm", params);

	params = new Vector();
	//customerID="41014252";
	p = new Parameter("customerID",String.class,customerID,null);
	params.addElement(p);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC,new QName("","Return"),null,null,arraySer);
	doCall(url, "GetBookings", params);

	// Now Test Search method
    /*
	java.util.Date departdate = new java.util.Date((new java.sql.Date(102, 7, 5)).getTime());
	java.util.Date departtime = new java.util.Date((new java.sql.Time(13,0,0)).getTime());
	params = new Vector();
	params.addElement(new Parameter("airportsrcID",  String.class,         "YVR", null));
	params.addElement(new Parameter("airportdesID",  String.class,         "DFW", null));
	params.addElement(new Parameter("totalseat",     Integer.class,        new Integer(1), null));
	params.addElement(new Parameter("departdate",    java.util.Date.class, departdate, null));
	params.addElement(new Parameter("departtime",    java.util.Date.class, departtime, null));
	params.addElement(new Parameter("airclass",      String.class,         "E", null));
	params.addElement(new Parameter("airline",       String.class,         "AA", null));
	params.addElement(new Parameter("smoking",       Boolean.class,        new Boolean(false), null));
	params.addElement(new Parameter("window",        Boolean.class,        new Boolean(false), null));
	params.addElement(new Parameter("nonstoponly",   Boolean.class,        new Boolean(false), null));
	//smr.mapTypes
	//params.addElement(new Paramenter("departTime", java.util.Date.class, "YVR", null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Return"), null, null, arraySer);
	doCall(url, "Search", params);
	*/

	params = new Vector();
	params.addElement(new Parameter("airportID", String.class, "YVR", null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Return"), null, null, AirportVOSer);
	doCall(url, "GetAirport", params);
  }

  public void doCall(URL url, String methodName, Vector params)
  {
    try {
      Call call = new Call();


      call.setSOAPMappingRegistry(smr);
      call.setTargetObjectURI(ACTION_URI);
      call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
      call.setMethodName(methodName);
      call.setParams(params);
      if (header != null)
        call.setHeader(header);

      String soapAction = ACTION_URI;
      if (true) {
        soapAction = soapAction + methodName;
      }

      Response resp = call.invoke(url, soapAction);

      // check response
      if (!resp.generatedFault()) {
        Parameter ret = resp.getReturnValue();
        Object output = ret.getValue();
//        Object input = param.getValue();
/*
        if (equals(input,output)) {
          System.out.println(methodName + "\t OK");
        } else {
          System.out.println(methodName + "\t FAIL: " + output);
        }
		*/
	  }
      else {
        Fault fault = resp.getFault ();
        System.err.println (methodName + " generated fault: ");
        System.out.println ("  Fault Code   = " + fault.getFaultCode());
        System.out.println ("  Fault String = " + fault.getFaultString());
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}