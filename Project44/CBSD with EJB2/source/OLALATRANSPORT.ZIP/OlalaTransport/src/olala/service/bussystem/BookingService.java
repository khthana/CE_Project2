package olala.service.bussystem;
import java.util.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import olala.bussystem.*;
import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import olala.util.*;

public class BookingService
{
  public BookingService()
  {
    Initial();
  }
  private olala.bussystem.BookingServiceHome bookServiceHome = null;
  private olala.bussystem.BookingService bookRemote=null;

  /**Construct the EJB test client*/
  private void Initial()
  {
    try
    {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BusBookingService");

      //cast to Home interface
      bookServiceHome = (olala.bussystem.BookingServiceHome) PortableRemoteObject.narrow(ref, BookingServiceHome.class);
      bookRemote = (olala.bussystem.BookingService) bookServiceHome.create();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  private Context getInitialContext() throws Exception
  {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try
    {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null)
      {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e)
    {
      System.out.println("Unable to connect to WebLogic server at " + url);
      System.out.println("Please make sure that the server is running.");
      throw e;
    }
  }
  public String Reserve( String customerID, ReserveItem[] reservelist ) throws Exception
  {
    int size=reservelist.length;
    Vector reserve=new Vector();
    for (int i=0;i<size;i++)
    {
      reserve.addElement(reservelist[i]);
    }
    try
    {
      return (bookRemote.Reserve(customerID,reserve));
    }
    catch (RemoteException ex)
    {
      System.out.println("Reserver error");
    }
    throw new Exception("Reserver error");
  }
  public String Rent( String customerID, RentItem[] rentItems ) throws Exception
  {
    int size=rentItems.length;
    Vector reserve=new Vector();
    for (int i=0;i<size;i++)
    {
      reserve.addElement(rentItems[i]);
    }
    try
    {
      return (bookRemote.Rent(customerID,reserve));
    }
    catch (RemoteException ex)
    {
      System.out.println("Rent error");
    }
    throw new Exception("Rent error");
  }
  public void Confirm( String bookingID )
  {
    try
    {
      bookRemote.Confirm(bookingID);
    }
    catch (RemoteException ex)
    {
      System.out.println("Confirm error");
    }
    catch (ReserveException re)
    {
      System.out.println("Confirm error");
    }
  }
  public void CancelBooking( String bookingID )
  {
    try
    {
      bookRemote.CancelBooking(bookingID);
    }
    catch (RemoteException ex)
    {
      System.out.println("Cancel error");
    }
    catch (ReserveException re)
    {
      System.out.println("Cancel error");
    }
    catch (Exception ex)
    {
      System.out.println("Cancel error");
    }
  }
  public void CancelBookingDetail( String bookingID, int ItemNo )
  {
    try
    {
      bookRemote.CancelBookingDetail(bookingID,ItemNo);
    }
    catch (RemoteException ex)
    {
      System.out.println("Cancel Booking Detail error");
    }
    catch (Exception ex)
    {
      System.out.println("Cancel Booking Detail error");
    }
  }

  public BookingVO  GetBooking( String bookingID )
  {
    try
    {
      return (bookRemote.GetBooking(bookingID));
    }
    catch (RemoteException ex)
    {
      System.out.println("Get Booking error");
    }
    return null;
  }
  public BookingVO[] GetBookings( String customerID )
  {
    try
    {
      Collection col=bookRemote.GetBookings(customerID);
      int size=col.size();
      BookingVO[] bvo=new BookingVO[size];
      Iterator iter=col.iterator();
      Object obj;
      int count=0;
      while (iter.hasNext())
      {
        obj=iter.next();
        bvo[count]=(BookingVO)obj;
        count++;
      }
      return bvo;
    }
    catch (RemoteException re)
    {
      System.out.println("get Booking error");
    }
    return null;
  }
  public BookingDetailVO[] GetBookingDetails( String bookingID )
  {
    try
    {
      Collection col=bookRemote.GetBookingDetails(bookingID);
      int size=col.size();
      BookingDetailVO[] bvo=new BookingDetailVO[size];
      Iterator iter=col.iterator();
      Object obj;
      int count=0;
      while (iter.hasNext())
      {
        obj=iter.next();
        bvo[count]=(BookingDetailVO)obj;
        count++;
      }
      return bvo;
    }
    catch (RemoteException re)
    {
      System.out.println("get Booking Detail error");
    }
    return null;
  }
  public TravellerSeat[] GetSeatBookings( String bookingID, int itemNo )
  {
    try
    {
      Collection col=bookRemote.GetSeatBookings(bookingID,itemNo);
      int size=col.size();
      TravellerSeat[] bvo=new TravellerSeat[size];
      Iterator iter=col.iterator();
      Object obj;
      int count=0;
      while (iter.hasNext())
      {
        obj=iter.next();
        bvo[count]=(TravellerSeat)obj;
        count++;
      }
      return bvo;
    }
    catch (RemoteException re)
    {
      System.out.println("get Seat Booking error");
    }
    return null;
  }
  public ViewBookInfo[] ViewBooking( String bookingID )
  {
    try
    {
      Collection col=bookRemote.ViewBooking(bookingID);
      int size=col.size();
      ViewBookInfo[] bvo=new ViewBookInfo[size];
      Iterator iter=col.iterator();
      Object obj;
      int count=0;
      while (iter.hasNext())
      {
        obj=iter.next();
        bvo[count]=(ViewBookInfo)obj;
        count++;
      }
      return bvo;
    }
    catch (RemoteException re)
    {
      System.out.println("View Booking error");
    }
    return null;
  }
  public ViewRentBookInfo[] ViewRentBooking( String bookingID )
  {
    try
    {
      Collection col=bookRemote.ViewRentBooking(bookingID);
      int size=col.size();
      ViewRentBookInfo[] bvo=new ViewRentBookInfo[size];
      Iterator iter=col.iterator();
      Object obj;
      int count=0;
      while (iter.hasNext())
      {
        obj=iter.next();
        bvo[count]=(ViewRentBookInfo)obj;
        count++;
      }
      return bvo;
    }
    catch (RemoteException re)
    {
      System.out.println("View Rent Booking error");
    }
    return null;
  }

}