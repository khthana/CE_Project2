package olala.service.airlinesystem;
import java.util.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import olala.airlinesystem.*;
import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import olala.util.*;


public class AirlineService
{
  public AirlineService()
  {
    Initial();
  }
  private olala.airlinesystem.AirlineServiceHome airlineServiceHome = null;
  private olala.airlinesystem.AirlineService airRemote=null;

  /**Construct the EJB test client*/
  private void Initial()
  {
    try
    {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("AirlineService");

      //cast to Home interface
      airlineServiceHome = (olala.airlinesystem.AirlineServiceHome) PortableRemoteObject.narrow(ref, AirlineServiceHome.class);
      airRemote = (olala.airlinesystem.AirlineService) airlineServiceHome.create();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception
  {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try
    {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null)
      {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e)
    {
      System.out.println("Unable to connect to WebLogic server at " + url);
      System.out.println("Please make sure that the server is running.");
      throw e;
    }
  }
  /*
  public void AddAircraftClass(String classID, String className, String description)
  {
    try
    {
      airRemote.AddAircraftClass(classID,className,description);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Aircraft Class error");
    }
  }
  public void AddAircraftModel(String modelID, String modelName, int totalSeat)
  {
    try
    {
      airRemote.AddAircraftModel(modelID,modelName,totalSeat);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Aircraft Model error");
    }
  }
  public void AddAirline(String airlineID, String airlineName, String description)
  {
    try
    {
      airRemote.AddAirline(airlineID,airlineName,description);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Airline error");
    }
  }
  public void AddAirport(String airportID, String airportName, String city, String state, String country, String description, String imagePath)
  {
    try
    {
      airRemote.AddAirport(airportID,airportName,city,state,country,description,imagePath);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Airport error");
    }
  }
  public void AddClassFee(String classID, String airlineID, double pricePerKm, double fee)
  {
    try
    {
      airRemote.AddClassFee(classID,airlineID,pricePerKm,fee);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Class Fee error");
    }
  }
  public void AddFlight(String flightID, String description, String airlineID, String aircraftID, int flightDay)
  {
    try
    {
      airRemote.AddFlight(flightID,description,airlineID,aircraftID,flightDay);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Flight error");
    }
  }
  public void AddFlightSchedule(String flightID, int subrouteID, java.sql.Time arriveTime, java.sql.Time departTime, int arriveDay, int departDay, int idx)
  {
    try
    {
      airRemote.AddFlightSchedule(flightID,subrouteID,arriveTime,departTime,arriveDay,departDay,idx);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Flight Schedule error");
    }
  }
  public void AddSeat(String seatNo, String modelID, boolean smoking, boolean window, String classID)
  {
    try
    {
      airRemote.AddSeat(seatNo,modelID,smoking,window,classID);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Seat error");
    }
  }
  public void AddSubroute(double distance, String airportID1, String airportID2)
  {
    try
    {
      airRemote.AddSubroute(distance,airportID1,airportID2);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Subroute error");
    }
  }
  public void AddSubroute1(int subrouteID, double distance, String airportID1, String airportID2)
  {
    try
    {
      airRemote.AddSubroute(subrouteID,distance,airportID1,airportID2);
    }
    catch (RemoteException ex)
    {
      System.out.println("add Subroute error");
    }
  }
  public void DeleteAircraftClass(String classID)
  {
    try
    {
      airRemote.DeleteAircraftClass(classID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Aircraft Class error");
    }
  }
  public void DeleteAircraftModel(String modelID)
  {
    try
    {
      airRemote.DeleteAircraftModel(modelID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Aircraft Model error");
    }
  }
  public void DeleteAirline(String airlineID)
  {
    try
    {
      airRemote.DeleteAirline(airlineID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Airline error");
    }
  }
  public void DeleteAirport(String airportID)
  {
    try
    {
      airRemote.DeleteAirport(airportID);
    }
    catch (RemoteException ex)
    {

    }
    catch (RemoveException ex)
    {
      System.out.println("delete Airport  error");
    }
  }
  public void DeleteClassFee(String classID, String airlineID)
  {
    try
    {
      airRemote.DeleteClassFee(classID,airlineID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Class Fee  error");
    }
  }
  public void DeleteFlight(String flightID)
  {
    try
    {
      airRemote.DeleteFlight(flightID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Flight error");
    }
  }
  public void DeleteFlightSchedule(String flightID, int subrouteID)
  {
    try
    {
      airRemote.DeleteFlightSchedule(flightID,subrouteID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Flight Schedule error");
    }
  }
  public void DeleteSeat(String seatNo, String modelID)
  {
    try
    {
      airRemote.DeleteSeat(seatNo,modelID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Seat error");
    }
  }
  public void DeleteSubroute(int subrouteID)
  {
    try
    {
      airRemote.DeleteSubroute(subrouteID);
    }
    catch (RemoteException ex)
    {
      System.out.println("delete Subroute  error");
    }
  }
  */
  public AircraftClassVO GetAircraftClass(String classID)
  {
    try
    {
      return (airRemote.GetAircraftClass(classID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Aircraft Class error");
    }
    return null;
  }
  public AircraftModelVO GetAircraftModel(String modelID)
  {
    try
    {
      return (airRemote.GetAircraftModel(modelID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Aircraft Model error");
    }
    return null;
  }
  public AirlineVO GetAirline(String airlineID)
  {
    try
    {
      return (airRemote.GetAirline(airlineID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Airline error");
    }
    return null;
  }
  public AirportVO GetAirport(String airportID)
  {
    try
    {
      return (airRemote.GetAirport(airportID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Airport error");
    }
    return null;
  }
  public ClassFeeVO GetClassFee(String classID, String airlineID)
  {
    try
    {
      return (airRemote.GetClassFee(classID,airlineID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Class Fee error");
    }
    return null;
  }
  public FlightVO GetFlight(String flightID)
  {
    try
    {
      return (airRemote.GetFlight(flightID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Flight error");
    }
    return null;
  }
  public FlightScheduleVO GetFlightSchedule(String flightID, int subrouteID)
  {
    try
    {
      return (airRemote.GetFlightSchedule(flightID,subrouteID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Flight Schedule error");
    }
    return null;
  }
  public SeatVO GetSeat(String seatNo, String modelID)
  {
    try
    {
      return (airRemote.GetSeat(seatNo,modelID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Seat error");
    }
    return null;
  }
  public SubrouteVO GetSubroute(int subrouteID)
  {
    try
    {
      return (airRemote.GetSubroute(subrouteID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Subroute error");
    }
    return null;
  }
  public AircraftClassVO[] GetAllAircraftClass()
  {
    try
    {
      Collection col=airRemote.GetAllAircraftClass();
      AircraftClassVO[] result=new AircraftClassVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        AircraftClassVO aircraftClassVO = (AircraftClassVO) PortableRemoteObject.narrow(obj, AircraftClassVO.class);
        result[count]=aircraftClassVO;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Aircraft Class error");
    }
    return null;
  }
  public AircraftModelVO[] GetAllAircraftModel()
  {
    try
    {
      Collection col=airRemote.GetAllAircraftModel();
      AircraftModelVO[] result=new AircraftModelVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        AircraftModelVO aircraftModelVO = (AircraftModelVO) PortableRemoteObject.narrow(obj, AircraftModelVO.class);
        result[count]=aircraftModelVO;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Aircraft Model error");
    }
    return null;
  }
  public AirlineVO[] GetAllAirline()
  {
    try
    {
      Collection col=airRemote.GetAllAirline();
      AirlineVO[] result=new AirlineVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        AirlineVO airlineVO = (AirlineVO) PortableRemoteObject.narrow(obj, AirlineVO.class);
        result[count]=airlineVO;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Airline error");
    }
    return null;
  }
  public AirportVO[] GetAllAirport()
  {
    try
    {
      Collection col=airRemote.GetAllAirport();
      AirportVO[] result=new AirportVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        AirportVO vo = (AirportVO) PortableRemoteObject.narrow(obj, AirportVO.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Airport error");
    }
    return null;
  }
  public ClassFeeVO[] GetAllClassFee()
  {
    try
    {
      Collection col=airRemote.GetAllClassFee();
      ClassFeeVO[] result=new ClassFeeVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        ClassFeeVO vo = (ClassFeeVO) PortableRemoteObject.narrow(obj, ClassFeeVO.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Class Fee error");
    }
    return null;
  }
  public FlightVO[] GetAllFlight()
  {
    try
    {
      Collection col=airRemote.GetAllFlight();
      FlightVO[] result=new FlightVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        FlightVO vo = (FlightVO) PortableRemoteObject.narrow(obj, FlightVO.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Flight error");
    }
    return null;
  }
  public FlightScheduleVO[] GetAllFlightSchedule()
  {
    try
    {
      Collection col=airRemote.GetAllFlightSchedule();
      FlightScheduleVO[] result=new FlightScheduleVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        FlightScheduleVO vo = (FlightScheduleVO) PortableRemoteObject.narrow(obj, FlightScheduleVO.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Flight Schedule error");
    }
    return null;
  }
  public SeatVO[] GetAllSeat()
  {
    try
    {
      Collection col=airRemote.GetAllSeat();
      SeatVO[] result=new SeatVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        SeatVO vo = (SeatVO) PortableRemoteObject.narrow(obj, SeatVO.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Seat error");
    }
    return null;
  }
  public SubrouteVO[] GetAllSubroute()
  {
    try
    {
      Collection col=airRemote.GetAllSubroute();
      SubrouteVO[] result=new SubrouteVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        SubrouteVO vo = (SubrouteVO) PortableRemoteObject.narrow(obj, SubrouteVO.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Subroute error");
    }
    return null;
  }
  public AirSeatSearchResult[] Search(String airportsrcID, String airportdesID, int totalseat, String departdate, String departtime, String airclass, String airline, boolean smoking, boolean window, boolean nonstoponly)
  {
    java.sql.Date ddepart = new java.sql.Date(convert.StringToDate(departdate).getTime());
	java.sql.Time  tdepart;
	// Convert Date
	try {
	  tdepart = convert.StringToTime(departtime);
	}
	catch (Exception e) {
	  tdepart = null;
	}

    try
    {
      Collection col = airRemote.Search(airportsrcID, airportdesID, totalseat, ddepart, tdepart, airclass, airline, smoking, window, nonstoponly);
      AirSeatSearchResult[] result=new AirSeatSearchResult[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        AirSeatSearchResult vo = (AirSeatSearchResult) PortableRemoteObject.narrow(obj, AirSeatSearchResult.class);
        result[count]=vo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("Search error");
    }
    return null;
  }

}