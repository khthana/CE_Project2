package olala.service.bussystem;
import java.util.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import olala.bussystem.*;
import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import olala.util.*;
import java.sql.*;

public class BusService
{
  public BusService()
  {
    Initial();
  }
  private olala.bussystem.BusServiceHome busHome = null;
  private olala.bussystem.BusService busRemote=null;

  /**Construct the EJB test client*/
  private void Initial()
  {
    try
    {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BusService");

      //cast to Home interface
      busHome = (olala.bussystem.BusServiceHome) PortableRemoteObject.narrow(ref, BusServiceHome.class);
      busRemote = (olala.bussystem.BusService) busHome.create();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  private Context getInitialContext() throws Exception
  {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try
    {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null)
      {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e)
    {
      System.out.println("Unable to connect to WebLogic server at " + url);
      System.out.println("Please make sure that the server is running.");
      throw e;
    }
  }
  /*
  public void AddBus( String busID, String companyID, String modelID, boolean forRent )
  {
  }
  public void AddBusModel( String modelID, String modelName, int totalSeat, String description, boolean toilet )
  {
  }
  public void AddBusSchedule( String routeID, int subrouteID, Time arriveTime, Time departTime, int arriveDay, int departDay, int idx )
  {
  }
  public void AddCompany( String companyID, String companyName, String description )
  {
  }
  public void AddRoute( String routeID, String description, String companyID, String modelID )
  {
  }
  public void AddStation( String stationID, String stationName, String city, String state, String country, String description, String imagePath )
  {
  }
  public void AddSubroute( double distance, String stationID1, String stationID2 )
  {
  }
  public void AddSubroute( int subrouteID, double distance, String stationID1, String stationID2 )
  {
  }
  public void AddBusFee( String modelID, String companyID, double pricePerKm, double fee, double rentCost )
  {
  }
  public void AddSeat( String seatNo, String modelID, boolean smoking, boolean window )
  {
  }
  public void DeleteBus( String busID )
  {
  }
  public void DeleteBusModel( String modelID )
  {
  }
  public void DeleteBusSchedule( String routeID, int subrouteID )
  {
  }
  public void DeleteCompany( String companyID )
  {
  }
  public void DeleteRoute( String routeID )
  {
  }
  public void DeleteStation( String stationID )
  {
  }
  public void DeleteSubroute( int subrouteID )
  {
  }
  public void DeleteBusFee( String modelID, String companyID )
  {
  }
  public void DeleteSeat( String seatNo, String modelID )
  {
  }
  */


  public BusVO GetBus( String busID ) throws Exception
  {
    try
    {
	  System.out.println("call Getbus with bus ID = " + busID);
	  BusVO retVal = busRemote.GetBus(busID);
	  System.out.println("End call Getbus with bus ID = " + busID);
      return retVal;
    }
    catch (RemoteException ex)
    {
      System.out.println("get Bus error");
    }
    return null;
  }
  public BusModelVO GetBusModel( String modelID )
  {
    try
    {
      return (busRemote.GetBusModel(modelID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Bus Model error");
    }
    return null;
  }
  public BusScheduleVO GetBusSchedule( String routeID, int subrouteID )
  {
    try
    {
      return (busRemote.GetBusSchedule(routeID,subrouteID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Bus Schedule error");
    }
    return null;
  }
  public CompanyVO GetCompany( String companyID )
  {
    try
    {
      return (busRemote.GetCompany(companyID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Company error");
    }
    return null;
  }
  public RouteVO GetRoute( String routeID )
  {
    try
    {
      return (busRemote.GetRoute(routeID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Route error");
    }
    return null;
  }
  public StationVO GetStation( String stationID)
  {
    try
    {
      return (busRemote.GetStation(stationID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Station error");
    }
    return null;
  }
  public SubrouteVO GetSubroute( int subrouteID )
  {
    try
    {
      return (busRemote.GetSubroute(subrouteID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Subroute error");
    }
    return null;
  }
  public BusFeeVO GetBusFee( String modelID, String companyID )
  {
    try
    {
      return (busRemote.GetBusFee(modelID,companyID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Bus Fee error");
    }
    return null;
  }
  public SeatVO GetSeat( String seatNo, String modelID )
  {
    try
    {
      return (busRemote.GetSeat(seatNo,modelID));
    }
    catch (RemoteException ex)
    {
      System.out.println("get Seat error");
    }
    return null;
  }
  public BusVO[] GetAllBus()
  {
    try
    {
      Collection col=busRemote.GetAllBus();
      BusVO[] result=new BusVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        BusVO bvo = (BusVO) PortableRemoteObject.narrow(obj, BusVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Bus error");
    }
    return null;
  }
  public BusModelVO[] GetAllBusModel()
  {
    try
    {
      Collection col=busRemote.GetAllBusModel();
      BusModelVO[] result=new BusModelVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        BusModelVO bvo = (BusModelVO) PortableRemoteObject.narrow(obj, BusModelVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Bus Model error");
    }
    return null;
  }
  public BusScheduleVO[] GetAllBusSchedule()
  {
    try
    {
      Collection col=busRemote.GetAllBusSchedule();
      BusScheduleVO[] result=new BusScheduleVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        BusScheduleVO bvo = (BusScheduleVO) PortableRemoteObject.narrow(obj, BusScheduleVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Bus Schedule error");
    }
    return null;
  }
  public CompanyVO[] GetAllCompany()
  {
    try
    {
      Collection col=busRemote.GetAllCompany();
      CompanyVO[] result=new CompanyVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        CompanyVO bvo = (CompanyVO) PortableRemoteObject.narrow(obj, CompanyVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Bus Company error");
    }
    return null;
  }
  public RouteVO[] GetAllRoute()
  {
    try
    {
      Collection col=busRemote.GetAllRoute();
      RouteVO[] result=new RouteVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        RouteVO bvo = (RouteVO) PortableRemoteObject.narrow(obj, RouteVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Route error");
    }
    return null;
  }
  public StationVO[] GetAllStation()
  {
    try
    {
      Collection col=busRemote.GetAllStation();
      StationVO[] result=new StationVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        StationVO bvo = (StationVO) PortableRemoteObject.narrow(obj, StationVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Station error");
    }
    return null;
  }
  public SubrouteVO[] GetAllSubroute()
  {
    try
    {
      Collection col=busRemote.GetAllSubroute();
      SubrouteVO[] result=new SubrouteVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        SubrouteVO bvo = (SubrouteVO) PortableRemoteObject.narrow(obj, SubrouteVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Subroute error");
    }
    return null;
  }
  public BusFeeVO[] GetAllBusFee()
  {
    try
    {
      Collection col=busRemote.GetAllBusFee();
      BusFeeVO[] result=new BusFeeVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        BusFeeVO bvo = (BusFeeVO) PortableRemoteObject.narrow(obj, BusFeeVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Bus Fee error");
    }
    return null;
  }
  public SeatVO[] GetAllSeat()
  {
    try
    {
      Collection col=busRemote.GetAllSeat();
      SeatVO[] result=new SeatVO[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        SeatVO bvo = (SeatVO) PortableRemoteObject.narrow(obj, SeatVO.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get All Seat error");
    }
    return null;
  }
  public BusSeatSearchResult[] Search( String stationsrcID, String stationdesID,
		                       int totalseat,
							   String departdate,//java.sql.Date departdate,
							   String departtime,//Time departtime,
							   String company, boolean toilet, boolean smoking, boolean window, boolean nonstoponly )
  {
	java.sql.Date dd = new java.sql.Date(convert.StringToDate(departdate).getTime());
	java.sql.Time dt;
	try {
	  dt = convert.StringToTime(departtime);
	}
	catch ( Exception e ) {
	  dt = null;
	}
    try
    {
      Collection col = busRemote.Search( stationsrcID, stationdesID, totalseat, dd, dt,
					                     company, toilet, smoking, window, nonstoponly);
      BusSeatSearchResult[] result = new BusSeatSearchResult[col.size()];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        BusSeatSearchResult bvo = (BusSeatSearchResult) PortableRemoteObject.narrow(obj, BusSeatSearchResult.class);
        result[count]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get search error");
    }
    return null;
  }
  public BusRentSearchResult[] SearchForRent(String startdate, String stopdate, boolean toilet, String companyID)
  {
	java.sql.Date dstart = new java.sql.Date(convert.StringToDate(startdate).getTime());
	java.sql.Date sstart = new java.sql.Date(convert.StringToDate(stopdate).getTime());
    try
    {
      Collection col = busRemote.SearchForRent(dstart, sstart, toilet, companyID);
      BusRentSearchResult[] result = new BusRentSearchResult[ col.size() ];
      int count=0;
      Iterator i = col.iterator();
      Object obj;
      while(i.hasNext())
      {
        obj = i.next();
        BusRentSearchResult bvo = (BusRentSearchResult) PortableRemoteObject.narrow(obj, BusRentSearchResult.class);
        result[ count ]=bvo;
        count++;
      }
      return (result);
    }
    catch (RemoteException ex)
    {
      System.out.println("get search error");
    }
    return null;
  }

}