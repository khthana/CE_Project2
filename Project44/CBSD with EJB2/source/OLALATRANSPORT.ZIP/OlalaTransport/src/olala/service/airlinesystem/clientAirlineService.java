package olala.service.airlinesystem;

import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.airlinesystem.*;
import java.util.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class clientAirlineService {

  public clientAirlineService() {

  }
    SOAPMappingRegistry smr = new SOAPMappingRegistry(Constants.NS_URI_CURRENT_SCHEMA_XSD);

  public static final String DEFAULT_URL = "http://localhost:8090/soap/servlet/rpcrouter";
  public static final String ACTION_URI = "http://olala/AirlineService/";
  public static final String OBJECT_URI = "http://soapinterop.org/xsd";
  public Header header = null;

  public static void main(String args[])
  {
    URL url = null;

    try {
      if (args.length > 0) {
        url = new URL(args[0]);
      } else {
        url = new URL(DEFAULT_URL);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    clientAirlineService eTest = new clientAirlineService();
    eTest.doWork(url);
  }
  public void doWork(URL url)
  {
    IntDeserializer intDser = new IntDeserializer();
    FloatDeserializer floatDser = new FloatDeserializer();
    StringDeserializer stringDser = new StringDeserializer();
    ArraySerializer arraySer = new ArraySerializer();
//    AircraftClassVOSerialize AircraftClassVOSer = new AircraftClassVOSerialize();
	AirportVOSerialize AirportVOSer = new AirportVOSerialize();
	//AirSeatSearchResultSerialize AirSeatSearchResultSer = new AirSeatSearchResultSerialize();
	AirSeatSearchResultSerialize AirSeatSearchResultSer = new AirSeatSearchResultSerialize();
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "AirportVO"), AirportVO.class, AirportVOSer, AirportVOSer);
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "AirSeatSearchResult"), AirSeatSearchResult.class, AirSeatSearchResultSer, AirSeatSearchResultSer);
	Vector params;
	// Now Test Search method


	java.util.Date departdate = new java.util.Date((new java.sql.Date(102, 7, 5)).getTime());
	java.util.Date departtime = new java.util.Date((new java.sql.Time(13, 0, 0)).getTime());
	params = new Vector();
	params.addElement(new Parameter("airportsrcID",  String.class,         "YVR", null));
	params.addElement(new Parameter("airportdesID",  String.class,         "DFW", null));
	params.addElement(new Parameter("totalseat",     Integer.class,        new Integer(1), null));
	params.addElement(new Parameter("departdate",    String.class,         departdate.toString(), null));
	params.addElement(new Parameter("departtime",    String.class,         "", null));
	params.addElement(new Parameter("airclass",      String.class,         "E", null));
	params.addElement(new Parameter("airline",       String.class,         "AA", null));
	params.addElement(new Parameter("smoking",       Boolean.class,        new Boolean(false), null));
	params.addElement(new Parameter("window",        Boolean.class,        new Boolean(false), null));
	params.addElement(new Parameter("nonstoponly",   Boolean.class,        new Boolean(false), null));
	//smr.mapTypes
	//params.addElement(new Paramenter("departTime", java.util.Date.class, "YVR", null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Return"), null, null, arraySer);
	doCall(url, "Search", params);

	params = new Vector();
	params.addElement(new Parameter("airportID", String.class, "YVR", null));
	smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Return"), null, null, AirportVOSer);
	doCall(url, "GetAirport", params);
  }

  public void doCall(URL url, String methodName, Vector params)
  {
    try {
      Call call = new Call();

      call.setSOAPMappingRegistry(smr);
      call.setTargetObjectURI(ACTION_URI);
      call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
      call.setMethodName(methodName);
      call.setParams(params);
      if (header != null)
        call.setHeader(header);

      String soapAction = ACTION_URI;
      if (true) {
        soapAction = soapAction + methodName;
      }

      Response resp = call.invoke(url, soapAction);

      // check response
      if (!resp.generatedFault()) {
        Parameter ret = resp.getReturnValue();
        Object output = ret.getValue();
//        Object input = param.getValue();
/*
        if (equals(input,output)) {
          System.out.println(methodName + "\t OK");
        } else {
          System.out.println(methodName + "\t FAIL: " + output);
        }
		*/
	  }
      else {
        Fault fault = resp.getFault ();
        System.err.println (methodName + " generated fault: ");
        System.out.println ("  Fault Code   = " + fault.getFaultCode());
        System.out.println ("  Fault String = " + fault.getFaultString());
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}