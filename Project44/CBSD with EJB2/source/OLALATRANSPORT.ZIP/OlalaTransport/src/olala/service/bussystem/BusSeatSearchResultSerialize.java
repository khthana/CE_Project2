package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
import olala.util.*;
public class BusSeatSearchResultSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    BusSeatSearchResult src2 = (BusSeatSearchResult)src;
    Parameter param;

    param = new Parameter("companyName", String.class,src2.getCompanyName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("routeID",String.class,src2.getRouteID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("routeDescription",String.class,src2.getRouteDescription(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("modelID", String.class,src2.getModelID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("modelName", String.class,src2.getModelName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departTime",String.class,convert.TimeToString(src2.getDepartTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveTime",String.class,convert.TimeToString(src2.getArriveTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("srcIdx", int.class,new Integer(src2.getSrcIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("desIdx", int.class,new Integer(src2.getDesIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("totalDistance", Double.class,new Double(src2.getTotalDistance()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("price", Double.class,new Double(src2.getPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    BusSeatSearchResult target;

    try
    {
      target =(BusSeatSearchResult)BusSeatSearchResult.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("companyName"))
      {
        target.setCompanyName(((String)param.getValue()));
      }

      if (tagName.equals("routeID"))
      {
        target.setRouteID(((String)param.getValue()));
      }
      if (tagName.equals("routeDescription"))
      {
        target.setRouteDescription((String)param.getValue());
      }
      if (tagName.equals("modelID"))
      {
        target.setModelID((String)param.getValue());
      }
      if (tagName.equals("modelName"))
      {
        target.setModelName(((String)param.getValue()));
      }
      if (tagName.equals("departTime"))
      {
        target.setDepartTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("arriveTime"))
      {
        target.setArriveTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("srcIdx"))
      {
        target.setSrcIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("desIdx"))
      {
        target.setDesIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("totalDistance"))
      {
        target.setTotalDistance(((Double)param.getValue()).doubleValue());
      }
      if (tagName.equals("price"))
      {
        target.setPrice(((Double)param.getValue()).doubleValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(BusSeatSearchResult.class, target);

  }
}