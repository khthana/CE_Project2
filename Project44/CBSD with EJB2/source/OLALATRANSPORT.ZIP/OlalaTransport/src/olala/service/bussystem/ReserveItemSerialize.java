package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
import olala.util.*;

public class ReserveItemSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    ReserveItem src2 = (ReserveItem)src;
    Parameter param;

    param = new Parameter("routeID", String.class,src2.getRouteID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("seats",int.class,new Integer(src2.getSeats()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("srcIdx",int.class,new Integer(src2.getSrcIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("desIdx",int.class,new Integer(src2.getDesIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("toilet", Boolean.class,new Boolean(src2.getToilet()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);
    param = new Parameter("smoking", Boolean.class,new Boolean(src2.getSmoking()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);
    param = new Parameter("window", Boolean.class,new Boolean(src2.getWindow()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);
    param = new Parameter("departDate",String.class,convert.DateToString(new java.util.Date(src2.getDepartDate().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);
    java.util.Collection col=src2.getAllTraveller();
    TravellerVO[] tvo=new TravellerVO[col.size()];
    int count=0;
    java.util.Iterator iter=col.iterator();
    Object obj;
    while (iter.hasNext())
    {
      obj=iter.next();
      tvo[count]=(TravellerVO)obj;
      count++;
    }
    param = new Parameter("travellers", TravellerVO[].class,tvo, null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    ReserveItem target;

    try
    {
      target =(ReserveItem)ReserveItem.class.newInstance();
	  if (target == null) {
		System.out.println("ReserveItem[Target] is null");
	  }
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: ~~~"
        + e.getMessage());
    }
	System.out.println("Unmarshalling ReserveItem[Bus]");
    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

	  System.out.println("tagName = " + tagName);
      if (tagName.equals("routeID"))
      {
        target.setRouteID(((String)param.getValue()));
      }

      if (tagName.equals("seats"))
      {
        target.setSeats(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("srcIdx"))
      {
        target.setSrcIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("desIdx"))
      {
        target.setDesIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("toilet"))
      {
        target.setToilet(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("smoking"))
      {
        target.setSmoking(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("window"))
      {
        target.setWindow(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("departDate"))
      {
        target.setDepartDate(new java.sql.Date((convert.StringToDate((String)param.getValue()).getTime())));
      }
      if (tagName.equals("travellers"))
      {
        TravellerVO[] tvo= (TravellerVO[])param.getValue();
        if (tvo == null) {
		  System.out.println("TravellerVO[] is null!");
        }
		int size=tvo.length;
        //Vector v=new Vector();
        for (int i=0;i<size;i++)
        {
		  System.out.println("Next Traveller");
		  System.out.println("Traveller Object #" + i + " = " + tvo[i]);
          target.AddTraveller(tvo[i]);
		  //v.addElement(tvo[i]);
        }
      }


      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(ReserveItem.class, target);

  }
}