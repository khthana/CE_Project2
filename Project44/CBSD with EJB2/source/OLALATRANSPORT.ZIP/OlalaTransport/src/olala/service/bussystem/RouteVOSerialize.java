package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;

public class RouteVOSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    RouteVO src2 = (RouteVO)src;
    Parameter param;

    param = new Parameter("routeID", String.class,src2.getRouteID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("description",String.class,src2.getDescription(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("companyID",String.class,src2.getCompanyID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("modelID",String.class,src2.getModelID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    RouteVO target;

    try
    {
      target =(RouteVO)RouteVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("routeID"))
      {
        target.setRouteID(((String)param.getValue()));
      }

      if (tagName.equals("description"))
      {
        target.setDescription(((String)param.getValue()));
      }
      if (tagName.equals("companyID"))
      {
        target.setCompanyID(((String)param.getValue()));
      }
      if (tagName.equals("modelID"))
      {
        target.setModelID(((String)param.getValue()));
      }


      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(RouteVO.class, target);

  }
}