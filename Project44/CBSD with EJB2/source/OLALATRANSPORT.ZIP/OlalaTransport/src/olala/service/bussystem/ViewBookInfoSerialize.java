package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
import olala.util.*;
public class ViewBookInfoSerialize implements Serializer, Deserializer
{
 public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    ViewBookInfo src2 = (ViewBookInfo)src;
    Parameter param;

    param = new Parameter("itemNo", int.class,new Integer(src2.getItemNo()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("routeID", java.lang.String.class,src2.getRouteID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departDateTime", String.class,convert.DateToString(new java.util.Date(src2.getDepartDateTime().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveDateTime", String.class,convert.DateToString(new java.util.Date(src2.getArriveDateTime().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("stationSrcID", String.class,src2.getStationSrcID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("stationSrcName", String.class,src2.getStationSrcName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("stationDesName", String.class,src2.getStationDesName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("stationDesID", java.lang.String.class,src2.getStationDesID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("totalSeat", int.class,new Integer(src2.getTotalSeat()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("price", double.class,new Double(src2.getPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);
    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    ViewBookInfo target;

    try
    {
      target =(ViewBookInfo)ViewBookInfo.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("itemNo"))
      {
        target.setItemNo(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("routeID"))
      {
        target.setRouteID((String)param.getValue() );
      }
      if (tagName.equals("departDateTime"))
      {
        java.sql.Timestamp date1=new java.sql.Timestamp((convert.StringToDate((String)param.getValue())).getTime());
        target.setDepartDateTime(date1);
      }
      if (tagName.equals("arriveDateTime"))
      {
        java.sql.Timestamp date2=new java.sql.Timestamp((convert.StringToDate((String)param.getValue())).getTime());
        target.setArriveDateTime(date2);
      }
      if (tagName.equals("stationSrcID"))
      {
        target.setStationSrcID(((String)param.getValue()));
      }
      if (tagName.equals("stationSrcName"))
      {
        target.setStationSrcName(((String)param.getValue()));
      }
      if (tagName.equals("stationDesName"))
      {
        target.setStationDesName(((String)param.getValue()));
      }
      if (tagName.equals("stationDesID"))
      {
        target.setStationDesID((String)param.getValue());
      }
      if (tagName.equals("totalSeat"))
      {
        target.setTotalSeat(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("price"))
      {
        target.setPrice(((Double)param.getValue()).doubleValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(ViewBookInfo.class, target);

  }

}