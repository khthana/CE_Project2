package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
import olala.util.*;
public class BookingVOSerialize implements Serializer, Deserializer
{
 public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    BookingVO src2 = (BookingVO)src;
    Parameter param;

    param = new Parameter("transaction", Integer.class,src2.getTransactionID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("transactionDate", String.class,convert.DateToString(new java.util.Date(src2.getTransactionDate().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("confirmDeadline",String.class,convert.DateToString(new java.util.Date(src2.getConfirmDeadline().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("confirmation", int.class,new Integer(src2.getConfirmation()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("obsoleted", java.lang.Boolean.class,new Boolean(src2.getObsoleted()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("bookingID", java.lang.String.class,src2.getBookingID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("customerID", String.class,src2.getCustomerID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    BookingVO target;

    try
    {
      target =(BookingVO)BookingVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("transactionID"))
      {
        target.setTransactionID(((Integer)param.getValue()));
      }

      if (tagName.equals("transactionDate"))
      {
        target.setTransactionDate(new java.sql.Timestamp((convert.StringToDate((String)param.getValue())).getTime()));
      }
      if (tagName.equals("confirmDeadline"))
      {
        target.setConfirmDeadline(new java.sql.Timestamp((convert.StringToDate((String)param.getValue())).getTime()));
      }
      if (tagName.equals("confirmation"))
      {
        target.setConfirmation(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("obsoleted"))
      {
        target.setObsoleted(((Boolean)param.getValue()).booleanValue());
      }
      if (tagName.equals("bookingID"))
      {
        target.setBookingID((String)param.getValue());
      }
      if (tagName.equals("customerID"))
      {
        target.setCustomerID((String)param.getValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(BookingVO.class, target);

  }
}