package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
import olala.util.*;
public class BookingDetailVOSerialize  implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    BookingDetailVO src2 = (BookingDetailVO)src;
    Parameter param;

    param = new Parameter("itemNo", int.class,new Integer(src2.getItemNo()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("routeID", java.lang.String.class,src2.getrouteID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departDate", String.class,convert.DateToString(new java.util.Date(src2.getDepartDate().getTime())), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("price", java.lang.Double.class,new Double(src2.getPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("srcIdx", int.class,new Integer(src2.getSrcIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("desIdx", int.class,new Integer(src2.getDesIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("totalSeat", int.class,new Integer(src2.getTotalSeat()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("bookingID", java.lang.String.class,src2.getBookingID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);
    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    BookingDetailVO target;

    try
    {
      target =(BookingDetailVO)BookingDetailVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("itemNo"))
      {
        target.setItemNo(((Integer)param.getValue()).intValue());
      }

      if (tagName.equals("routeID"))
      {
        target.setrouteID((String)param.getValue() );
      }
      if (tagName.equals("departDate"))
      {
        java.sql.Date date1 = new java.sql.Date((convert.StringToDate((String)param.getValue())).getTime() );
        target.setDepartDate(date1);
      }
      if (tagName.equals("price"))
      {
        target.setPrice(((Double)param.getValue()).doubleValue());
      }
      if (tagName.equals("srcIdx"))
      {
        target.setSrcIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("desIdx"))
      {
        target.setDesIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("totalSeat"))
      {
        target.setTotalSeat(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("bookingID"))
      {
        target.setBookingID((String)param.getValue() );
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(BookingDetailVO.class, target);

  }

}