package olala.service.airlinesystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.airlinesystem.*;

public class AircraftClassVOSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    AircraftClassVO src2 = (AircraftClassVO)src;
    Parameter param;

    param = new Parameter("classID", String.class,src2.getClassID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("className", java.lang.String.class,src2.getClassName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("description", java.lang.String.class,src2.getDescription(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    AircraftClassVO target;

    try
    {
      target =(AircraftClassVO)AircraftClassVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("classID"))
      {
        target.setClassID(((String)param.getValue()));
      }

      if (tagName.equals("className"))
      {
        target.setClassName((String)param.getValue());
      }
      if (tagName.equals("description"))
      {
        target.setDescription((String)param.getValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(AircraftClassVO.class, target);

  }

}