package olala.service.bussystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.bussystem.*;
public class BusFeeVOSerialize implements Serializer, Deserializer
{
 public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    BusFeeVO src2 = (BusFeeVO)src;
    Parameter param;

    param = new Parameter("companyID", String.class,src2.getCompanyID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("pricePerKm", Double.class,new Double(src2.getPricePerKm()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("fee",Double.class,new Double(src2.getFee()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("rentCost", Double.class,new Double(src2.getRentCost()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    BusFeeVO target;

    try
    {
      target =(BusFeeVO)BusFeeVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("companyID"))
      {
        target.setCompanyID(((String)param.getValue()));
      }

      if (tagName.equals("pricePerKm"))
      {
        target.setPricePerKm((((Double)param.getValue()).doubleValue()));
      }
      if (tagName.equals("fee"))
      {
        target.setFee(((Double)param.getValue()).doubleValue());
      }
      if (tagName.equals("rentCost"))
      {
        target.setRentCost(((Double)param.getValue()).doubleValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(BusFeeVO.class, target);

  }
}