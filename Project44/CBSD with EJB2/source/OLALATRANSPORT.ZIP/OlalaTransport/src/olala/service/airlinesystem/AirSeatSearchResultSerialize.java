package olala.service.airlinesystem;

import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import olala.airlinesystem.*;
import java.util.Date;
import java.sql.Time;
import olala.util.*;

public class AirSeatSearchResultSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    AirSeatSearchResult src2 = (AirSeatSearchResult)src;
    Parameter param;

    param = new Parameter("airlineName", String.class,src2.getAirlineName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("flightID", java.lang.String.class,src2.getFlightID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("flightDescription", String.class,src2.getFlightDescription(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("classID", String.class,src2.getClassID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("className", String.class,src2.getClassName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("modelName", String.class,src2.getModelName(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departTime", String.class,convert.TimeToString(src2.getDepartTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveTime", String.class,convert.TimeToString(src2.getArriveTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("srcIdx", Integer.class,new Integer(src2.getSrcIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("desIdx", Integer.class,new Integer(src2.getDesIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("totalDistance", Double.class,new Double(src2.getTotalDistance()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("price", Double.class,new Double(src2.getPrice()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);



    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    AirSeatSearchResult target;

    try
    {
      target =(AirSeatSearchResult)AirSeatSearchResult.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("airlineName"))
      {
        target.setAirlineName(((String)param.getValue()));
      }

      if (tagName.equals("flightID"))
      {
        target.setFlightID((String)param.getValue());
      }
      if (tagName.equals("flightDescription"))
      {
        target.setFlightDescription(((String)param.getValue()));
      }
      if (tagName.equals("classID"))
      {
        target.setClassID(((String)param.getValue()));
      }
      if (tagName.equals("className"))
      {
        target.setClassName(((String)param.getValue()));
      }
      if (tagName.equals("modelName"))
      {
        target.setModelName(((String)param.getValue()));
      }
      if (tagName.equals("departTime"))
      {
        target.setDepartTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("arriveTime"))
      {
        target.setArriveTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("srcIdx"))
      {
        target.setSrcIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("desIdx"))
      {
        target.setDesIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("totalDistance"))
      {
        target.setTotalDistance(((Double)param.getValue()).doubleValue());
      }
      if (tagName.equals("price"))
      {
        target.setPrice(((Double)param.getValue()).doubleValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(AirSeatSearchResult.class, target);

  }


}