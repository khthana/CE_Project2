package olala.service.airlinesystem;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import java.util.Date;
import java.sql.Time;
import olala.airlinesystem.*;
import olala.util.*;
public class FlightScheduleVOSerialize implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType,
  Object src, Object context, Writer sink,
  NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  throws IllegalArgumentException, IOException
  {
    nsStack.pushScope();

    SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context,
      sink, nsStack, xjmr);

    sink.write(StringUtils.lineSeparator);

    FlightScheduleVO src2 = (FlightScheduleVO)src;
    Parameter param;

    param = new Parameter("flightID", String.class,src2.getFlightID(), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveTime", java.lang.String.class,convert.TimeToString(src2.getArriveTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departTime", String.class,convert.TimeToString(src2.getDepartTime()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("departDay", Integer.class,new Integer(src2.getDepartDay()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("arriveDay", Integer.class,new Integer(src2.getArriveDay()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("idx", Integer.class,new Integer(src2.getIdx()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    param = new Parameter("subrouteID", Integer.class,new Integer(src2.getSubrouteID()), null);
    xjmr.marshall(inScopeEncStyle, Parameter.class, param, null,
    sink, nsStack, ctx);
    sink.write(StringUtils.lineSeparator);

    sink.write("</" + context + '>');

    nsStack.popScope();
  }
  public Bean unmarshall(String inSp,QName eleType,Node src,XMLJavaMappingRegistry xjmr,SOAPContext ctx)
  throws java.lang.IllegalArgumentException
  {
    Element root = (Element)src;
    Element tempEl = DOMUtils.getFirstChildElement(root);
    FlightScheduleVO target;

    try
    {
      target =(FlightScheduleVO)FlightScheduleVO.class.newInstance();
    }
    catch (Exception e)
    {
      throw new IllegalArgumentException("Problem instantiating bean: "
        + e.getMessage());
    }

    while (tempEl != null)
    {

      Bean paramBean = xjmr.unmarshall(inSp,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
      Parameter param = (Parameter)paramBean.value;
      String tagName = tempEl.getTagName();

      if (tagName.equals("flightID"))
      {
        target.setFlightID(((String)param.getValue()));
      }

      if (tagName.equals("arriveTime"))
      {
        target.setArriveTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("departTime"))
      {
        target.setDepartTime(convert.StringToTime((String)param.getValue()));
      }
      if (tagName.equals("departDay"))
      {
        target.setDepartDay(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("arriveDay"))
      {
        target.setArriveDay(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("idx"))
      {
        target.setIdx(((Integer)param.getValue()).intValue());
      }
      if (tagName.equals("subrouteID"))
      {
        target.setSubrouteID(((Integer)param.getValue()).intValue());
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

    return new Bean(FlightScheduleVO.class, target);

  }

}