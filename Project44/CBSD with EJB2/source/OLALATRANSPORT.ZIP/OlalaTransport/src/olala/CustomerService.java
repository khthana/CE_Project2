package olala;

import java.rmi.*;
import javax.ejb.*;
import olala.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface CustomerService extends EJBObject {
  public String Login(String emailAddress, String password) throws InvalidPasswordException, InvalidUserException, RemoteException;
  public CustomerVO getCustomer(String customerID) throws RemoteException;
  public boolean EditCustomer(String customerID, String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) throws RemoteException;
  public String AddCustomer(String customerID, String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) throws RemoteException;
  public String AddCustomer(String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) throws DuplicateEmailException, RemoteException;
}
