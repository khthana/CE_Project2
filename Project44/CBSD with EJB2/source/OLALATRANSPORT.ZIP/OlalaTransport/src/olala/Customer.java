package olala;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Customer extends EJBObject {
  public String getCustomerID() throws RemoteException;
  public String getFirstName() throws RemoteException;
  public void setFirstName(String firstName) throws RemoteException;
  public String getLastName() throws RemoteException;
  public void setLastName(String lastName) throws RemoteException;
  public String getGender() throws RemoteException;
  public void setGender(String gender) throws RemoteException;
  public String getAddress() throws RemoteException;
  public void setAddress(String address) throws RemoteException;
  public String getTelephone() throws RemoteException;
  public void setTelephone(String telephone) throws RemoteException;
  public String getEmailAddress() throws RemoteException;
  public void setEmailAddress(String emailAddress) throws RemoteException;
  public String getPassword() throws RemoteException;
  public void setPassword(String password) throws RemoteException;
  public boolean getAgency() throws RemoteException;
  public void setAgency(boolean agency) throws RemoteException;
  public CustomerVO getCustomer() throws RemoteException;
  public void setCustomer(CustomerVO cusVO) throws RemoteException;
}
