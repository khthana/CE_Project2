package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CompanyBean implements EntityBean {
  EntityContext entityContext;
  public String companyID;
  public String companyName;
  public String description;
  public String ejbCreate(String companyID, String companyName, String description) throws CreateException, RemoteException {
    this.companyID = companyID;
    this.companyName = companyName;
    this.description = description;
    return null;
  }
  public String ejbCreate(String companyID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(companyID, null, null);
  }
  public void ejbPostCreate(String companyID, String companyName, String description) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String companyID) throws CreateException, RemoteException {
    ejbPostCreate(companyID, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getCompanyID() {
    return companyID;
  }
  public String getCompanyName() {
    return companyName;
  }
  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public CompanyVO getCompany() {
    CompanyVO companyVO = new CompanyVO();
    companyVO.setCompanyID(this.companyID);
    companyVO.setCompanyName(this.companyName);
    companyVO.setDescription(this.description);
    return (companyVO);
  }
}