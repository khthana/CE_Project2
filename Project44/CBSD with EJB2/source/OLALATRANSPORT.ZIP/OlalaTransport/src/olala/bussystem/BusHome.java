package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

public interface BusHome extends EJBHome {
  public Bus create(String busID, String companyID, String modelID, boolean forRent) throws CreateException, RemoteException;
  public Bus create(String busID) throws RemoteException, CreateException;
  public Bus findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}