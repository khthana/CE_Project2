package olala.bussystem;

import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class TravellerSeat implements Serializable{
  private TravellerVO travellerVO;
  private String seatNo;

  public TravellerSeat(TravellerVO tv, String seatNo) {
	this.travellerVO = tv;
	this.seatNo = seatNo;
  }
  public TravellerVO getTravellerVO() {
	return travellerVO;
  }
  public String getSeatNo() {
    return seatNo;
  }
  public void setSeatNo(String seatNo) {
    this.seatNo = seatNo;
  }
  public void setTravellerVO(TravellerVO travellerVO) {
    this.travellerVO = travellerVO;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}