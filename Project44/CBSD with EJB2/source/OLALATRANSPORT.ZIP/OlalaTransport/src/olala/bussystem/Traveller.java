package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public interface Traveller extends EJBObject {
  public String getTravellerID() throws RemoteException;
  public String getFirstName() throws RemoteException;
  public void setFirstName(String firstName) throws RemoteException;
  public String getLastName() throws RemoteException;
  public void setLastName(String lastName) throws RemoteException;
}