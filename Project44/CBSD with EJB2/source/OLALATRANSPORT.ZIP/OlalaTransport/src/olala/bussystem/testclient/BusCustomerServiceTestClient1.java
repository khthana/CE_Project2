package olala.bussystem.testclient;


import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;

import olala.*;
import olala.bussystem.*;

public class BusCustomerServiceTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private CustomerServiceHome customerServiceHome = null;
  private CustomerService customerService = null;

  /**Construct the EJB test client*/
  public BusCustomerServiceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BusCustomerService");

      //cast to Home interface
      customerServiceHome = (CustomerServiceHome) PortableRemoteObject.narrow(ref, CustomerServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public CustomerService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      customerService = customerServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + customerService + ".");
    }
    return customerService;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String Login(String emailAddress, String password) {
    String returnValue = "";
    if (customerService == null) {
      System.out.println("Error in Login(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Login(" + emailAddress + ", " + password + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService.Login(emailAddress, password);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Login(" + emailAddress + ", " + password + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Login(" + emailAddress + ", " + password + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from Login(" + emailAddress + ", " + password + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public CustomerVO getCustomer(String customerID) {
    CustomerVO returnValue = null;
    if (customerService == null) {
      System.out.println("Error in getCustomer(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getCustomer(" + customerID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService.getCustomer(customerID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getCustomer(" + customerID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getCustomer(" + customerID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getCustomer(" + customerID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public boolean EditCustomer(String customerID, String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) {
    boolean returnValue = false;
    if (customerService == null) {
      System.out.println("Error in EditCustomer(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling EditCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService.EditCustomer(customerID, firstName, lastName, gender, Address, telephone, emailAddress, password, agency);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: EditCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: EditCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from EditCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public String AddCustomer(String customerID, String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) {
    String returnValue = "";
    if (customerService == null) {
      System.out.println("Error in AddCustomer(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService.AddCustomer(customerID, firstName, lastName, gender, Address, telephone, emailAddress, password, agency);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from AddCustomer(" + customerID + ", " + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public String AddCustomer(String firstName, String lastName, String gender, String Address, String telephone, String emailAddress, String password, boolean agency) {
    String returnValue = "";
    if (customerService == null) {
      System.out.println("Error in AddCustomer(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddCustomer(" + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService.AddCustomer(firstName, lastName, gender, Address, telephone, emailAddress, password, agency);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddCustomer(" + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddCustomer(" + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from AddCustomer(" + firstName + ", " + lastName + ", " + gender + ", " + Address + ", " + telephone + ", " + emailAddress + ", " + password + ", " + agency + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    BusCustomerServiceTestClient1 client = new BusCustomerServiceTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
	client.create();
	//client.AddCustomer( "Prakit", "Engkakitti", "M", "Ladkrabang", "1234567", "tanky@hotmail.com", "xxxx", false );
		String customerID = client.Login("tinnapat@yahoo.com", "password");
	long starttime = System.currentTimeMillis();
	/*for (int i=0; i< 100; i++) {
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	  cs.Login("tinnapat@yahoo.com", "password");
	}*/

	CustomerVO cVO = client.getCustomer(customerID);
	System.out.println("CustomerID : " + cVO.getCustomerID());
	System.out.println("FirstName : " + cVO.getFirstName());
	System.out.println("LastName :" +  cVO.getLastName());
	System.out.println("Address : " + cVO.getAddress());
	System.out.println("Telephone :" + cVO.getTelephone());
	System.out.println("EmailAddress :" +cVO.getEmailAddress());

  }
}