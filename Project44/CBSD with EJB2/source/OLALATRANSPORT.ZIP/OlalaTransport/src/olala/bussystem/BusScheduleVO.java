package olala.bussystem;

import java.sql.*;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusScheduleVO implements Serializable {

  private String routeID;
  private int subrouteID;
  private Time arriveTime;
  private Time departTime;
  private int departDay;
  private int arriveDay;
  private int idx;

  public BusScheduleVO() {
  }

  public String getRouteID() {
    return routeID;
  }
  public void setRouteID(String routeID) {
    this.routeID = routeID;
  }
  public int getSubrouteID() {
    return subrouteID;
  }
  public void setSubrouteID(int subrouteID) {
    this.subrouteID = subrouteID;
  }
  public Time getArriveTime() {
    return arriveTime;
  }
  public void setArriveTime(Time arriveTime) {
    this.arriveTime = arriveTime;
  }
  public Time getDepartTime() {
    return departTime;
  }
  public void setDepartTime(Time departTime) {
    this.departTime = departTime;
  }
  public int getDepartDay() {
    return departDay;
  }
  public void setDepartDay(int departDay) {
    this.departDay = departDay;
  }
  public int getArriveDay() {
    return arriveDay;
  }
  public void setArriveDay(int arriveDay) {
    this.arriveDay = arriveDay;
  }
  public int getIdx() {
    return idx;
  }
  public void setIdx(int idx) {
    this.idx = idx;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}