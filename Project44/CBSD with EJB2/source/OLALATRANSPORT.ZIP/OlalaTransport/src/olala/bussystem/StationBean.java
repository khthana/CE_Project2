package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class StationBean implements EntityBean {
  EntityContext entityContext;
  public String stationID;
  public String stationName;
  public String city;
  public String state;
  public String country;
  public String description;
  public String imagePath;
  public String ejbCreate(String stationID, String stationName, String city, String state, String country, String description, String imagePath) throws CreateException, RemoteException {
    this.stationID = stationID;
    this.stationName = stationName;
    this.city = city;
    this.state = state;
    this.country = country;
    this.description = description;
    this.imagePath = imagePath;
    return null;
  }
  public String ejbCreate(String stationID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(stationID, null, null, null, null, null, null);
  }
  public void ejbPostCreate(String stationID, String stationName, String city, String state, String country, String description, String imagePath) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String stationID) throws CreateException, RemoteException {
    ejbPostCreate(stationID, null, null, null, null, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getStationID() {
    return stationID;
  }
  public String getStationName() {
    return stationName;
  }
  public void setStationName(String stationName) {
    this.stationName = stationName;
  }
  public String getCity() {
    return city;
  }
  public void setCity(String city) {
    this.city = city;
  }
  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }
  public String getCountry() {
    return country;
  }
  public void setCountry(String country) {
    this.country = country;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getImagePath() {
    return imagePath;
  }
  public void setImagePath(String imagePath) {
    this.imagePath = imagePath;
  }

  public StationVO getStation() {
    StationVO stationVO = new StationVO();

    stationVO.setStationID(this.stationID);
    stationVO.setStationName(this.stationName);
    stationVO.setCity(this.city);
    stationVO.setState(this.state);
    stationVO.setCountry(this.country);
    stationVO.setDescription(this.description);
    stationVO.setImagePath(this.imagePath);

    return (stationVO);
  }

  public void setStation(StationVO stationVO) {
    this.stationID = stationVO.getStationID();
    this.stationName = stationVO.getStationName();
    this.city = stationVO.getCity();
    this.state = stationVO.getState();
    this.country = stationVO.getCountry();
    this.description = stationVO.getDescription();
    this.imagePath = stationVO.getImagePath();
  }

}