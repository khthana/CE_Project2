package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author EJB Group
 * @version 1.0
 */

public class BusModelVO implements Serializable {

  private String modelID;
  private String modelName;
  private int totalSeat;
  private String description;
  private boolean toilet;

  public BusModelVO() {
  }

  public BusModelVO(String modelID, String modelName, int totalSeat, String description, boolean toilet) {
    this.modelID = modelID;
    this.modelName = modelName;
    this.totalSeat = totalSeat;
	this.description = description;
	this.toilet = toilet;
  }

  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public String getModelName() {
    return modelName;
  }
  public void setModelName(String modelName) {
    this.modelName = modelName;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  public String getDescription() {
    return description;
  }
  public void setToilet(boolean toilet) {
    this.toilet = toilet;
  }
  public boolean isToilet() {
    return toilet;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}