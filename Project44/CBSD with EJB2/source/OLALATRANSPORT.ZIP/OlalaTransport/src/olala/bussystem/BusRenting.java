package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

public interface BusRenting extends EJBObject {
  public Timestamp getUsingDate() throws RemoteException;
  public String getBusID() throws RemoteException;
  public String getBookingID() throws RemoteException;
  public void setBookingID(String bookingID) throws RemoteException;
}