package olala.bussystem;
import java.sql.Date;
import java.util.*;
import java.io.*;


public class ReserveItem implements Serializable {
  private static final int TIS = 1;
  private static final int RSRIS = 1;

  private String routeID;
  private int seats;
  private int srcIdx;
  private int desIdx;
  private boolean toilet;
  private boolean smoking;
  private boolean window;
  private Date departDate;
  private Collection travellers = null;

  public ReserveItem() {
	travellers = new ArrayList(RSRIS);
  }

  public ReserveItem( String routeID,
                      int seats,
		              int srcIdx,
                      int desIdx,
					  boolean toilet,
                      boolean smoking,
                      boolean window,
                      Date departDate)
  {
    travellers = new ArrayList(RSRIS);
    this.routeID = routeID;
    this.seats = seats;
    this.srcIdx = srcIdx;
    this.desIdx = desIdx;
	this.toilet = toilet;
    this.smoking = smoking;
    this.window = window;
    this.departDate = departDate;
  }
  public Collection getAllTravellerData() {
    return travellers;
  }
  public void AddTraveller(TravellerVO tv) {
    travellers.add(tv);
  }
  public Collection getAllTraveller() {
    return travellers;
  }
  public void RemoveAllTraveller() {
    travellers = new ArrayList();
  }
  public boolean isValid() {
    boolean valid = true;
    if (travellers.size() != this.seats) {
      valid = false;
    }
    else {
      Iterator i = travellers.iterator();
      while(i.hasNext()) {
        TravellerVO travellerVO = (TravellerVO) i.next();
        if (travellerVO == null)                    { valid = false; }
        if (travellerVO.getFirstName().equals(""))  { valid = false; }
        if (travellerVO.getLastName().equals(""))   { valid = false; }
      }
    }
    return(valid);
  }
  public String getRouteID() {
    return routeID;
  }
  public int getSeats() {
    return seats;
  }
  public int getSrcIdx() {
    return srcIdx;
  }
  public int getDesIdx() {
    return desIdx;
  }
  public boolean getToilet() {
    return toilet;
  }
  public boolean getSmoking() {
    return smoking;
  }
  public boolean getWindow() {
    return window;
  }
  public Date getDepartDate() {
    return departDate;
  }
  public void setRouteID(String routeID) {
    this.routeID = routeID;
  }
  public void setSeats(int seats) {
    this.seats = seats;
  }
  public void setSrcIdx(int srcIdx) {
    this.srcIdx = srcIdx;
  }
  public void setDesIdx(int desIdx) {
    this.desIdx = desIdx;
  }
  public void setToilet(boolean toilet) {
    this.toilet = toilet;
  }
  public void setSmoking(boolean smoking) {
    this.smoking = smoking;
  }
  public void setWindow(boolean window) {
    this.window = window;
  }
  public void setDepartDate(Date departDate) {
    this.departDate = departDate;
  }
}