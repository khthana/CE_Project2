package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public interface Seat extends EJBObject {
  public String getSeatNo() throws RemoteException;
  public String getModelID() throws RemoteException;
  public boolean getSmoking() throws RemoteException;
  public void setSmoking(boolean smoking) throws RemoteException;
  public boolean getWindow() throws RemoteException;
  public void setWindow(boolean window) throws RemoteException;
  public SeatVO getSeat() throws RemoteException;
}