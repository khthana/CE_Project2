package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

public class BusRentingBean implements EntityBean {
  EntityContext entityContext;
  public Timestamp usingDate;
  public String busID;
  public String bookingID;
  public double price;
  public BusRentingPK ejbCreate(Timestamp usingDate, String busID, String bookingID, double price) throws CreateException, RemoteException {
    this.usingDate = usingDate;
    this.busID = busID;
    this.bookingID = bookingID;
	this.price = price;
    return null;
  }

  public void ejbPostCreate(Timestamp usingDate, String busID, String bookingID, double price) throws CreateException, RemoteException {
  }

  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public Timestamp getUsingDate() {
    return usingDate;
  }
  public String getBusID() {
    return busID;
  }
  public String getBookingID() {
    return bookingID;
  }
  public void setBookingID(String bookingID) {
    this.bookingID = bookingID;
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public BusRentingVO getBusRenting() {
	return new BusRentingVO(usingDate, busID, bookingID, price);
  }
}