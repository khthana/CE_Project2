package olala.bussystem.admin;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import olala.bussystem.testclient.*;
import olala.bussystem.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;

public class BusMainFrm extends JFrame {
  JPanel contentPane;
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JMenuItem jMenuFileExit = new JMenuItem();
  JMenu jMenuHelp = new JMenu();
  JMenuItem jMenuHelpAbout = new JMenuItem();

  BusServiceTestClient1 busClient = new BusServiceTestClient1();
  JButton jButtongetRoute = new JButton();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JButton jButtongetCompany = new JButton();
  JButton jButtongetStation = new JButton();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;

  /**Construct the frame*/
  public BusMainFrm() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(BusMainFrm.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    contentPane.setLayout(verticalFlowLayout1);
    this.setSize(new Dimension(400, 300));
    this.setTitle("Bus System Admin");
    jMenuFile.setText("File");
    jMenuFileExit.setText("Exit");
    jMenuFileExit.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuFileExit_actionPerformed(e);
      }
    });
    jMenuHelp.setText("Help");
    jMenuHelpAbout.setText("About");
    jMenuHelpAbout.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpAbout_actionPerformed(e);
      }
    });
    jButtongetRoute.setBorder(titledBorder1);
    jButtongetRoute.setText("Get Route Info");
    jButtongetRoute.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtongetRoute_actionPerformed(e);
      }
    });
    jButtongetCompany.setBorder(titledBorder2);
    jButtongetCompany.setText("Get Company Info");
    jButtongetCompany.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtongetCompany_actionPerformed(e);
      }
    });
    jButtongetStation.setBorder(titledBorder3);
    jButtongetStation.setText("Get Station Info");
    jButtongetStation.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtongetStation_actionPerformed(e);
      }
    });
    jMenuFile.add(jMenuFileExit);
    jMenuHelp.add(jMenuHelpAbout);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuHelp);
    contentPane.add(jButtongetRoute, null);
    contentPane.add(jButtongetCompany, null);
    contentPane.add(jButtongetStation, null);

	// init the test client
	busClient.create();

    this.setJMenuBar(jMenuBar1);
  }
  /**File | Exit action performed*/
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
  /**Help | About action performed*/
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
    BusMainFrm_AboutBox dlg = new BusMainFrm_AboutBox(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.show();
  }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }

  void jButtongetRoute_actionPerformed(ActionEvent e) {
	//JOpitionPane joptpane = new JOptionPane("Get Route Info", JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_OPTION);
	String routeID = JOptionPane.showInputDialog(this, "Enter the Route ID:" , "Get Route Info" , JOptionPane.QUESTION_MESSAGE);
	RouteVO rVO = busClient.GetRoute(routeID);
	JOptionPane.showMessageDialog(this, rVO.getDescription(), "Route Description", JOptionPane.INFORMATION_MESSAGE);
  }

  void jButtongetCompany_actionPerformed(ActionEvent e) {
	String companyID = JOptionPane.showInputDialog(this, "Enter the Company ID:" , "Get Company Info" , JOptionPane.QUESTION_MESSAGE);
	CompanyVO cVO = busClient.GetCompany(companyID);
	JOptionPane.showMessageDialog(this, cVO.getCompanyName(), "Company Name", JOptionPane.INFORMATION_MESSAGE);

  }

  void jButtongetStation_actionPerformed(ActionEvent e) {
	String stationID = JOptionPane.showInputDialog(this, "Enter the Station ID:" , "Get Station Info" , JOptionPane.QUESTION_MESSAGE);
	StationVO cVO = busClient.GetStation(stationID);
	JOptionPane.showMessageDialog(this, cVO.getStationName(), "Station Name", JOptionPane.INFORMATION_MESSAGE);

  }
}