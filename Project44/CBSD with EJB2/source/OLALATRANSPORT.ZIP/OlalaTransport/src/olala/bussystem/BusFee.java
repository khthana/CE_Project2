package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public interface BusFee extends EJBObject {
  public String getModelID() throws RemoteException;
  public String getCompanyID() throws RemoteException;
  public double getPricePerKm() throws RemoteException;
  public void setPricePerKm(double pricePerKm) throws RemoteException;
  public double getFee() throws RemoteException;
  public void setFee(double fee) throws RemoteException;
  public double getRentCost() throws RemoteException;
  public void setRentCost(double rentCost) throws RemoteException;
  public BusFeeVO getBusFee() throws RemoteException;
}