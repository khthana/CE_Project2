package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingDetailHome extends EJBHome {
  public BookingDetail create(String bookingID, int itemNo, String routeID, Date departDate, double price, int srcIdx, int desIdx, int totalSeat) throws CreateException, RemoteException;
  public BookingDetail findByPrimaryKey(BookingDetailPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
  public Collection findByBookingID(String bookingID) throws RemoteException, FinderException;
}
