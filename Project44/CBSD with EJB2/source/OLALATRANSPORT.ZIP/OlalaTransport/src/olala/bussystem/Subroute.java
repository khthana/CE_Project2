package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Subroute extends EJBObject {
  public Integer getSubrouteID() throws RemoteException;
  public double getDistance() throws RemoteException;
  public void setDistance(double distance) throws RemoteException;
  public String getStationID1() throws RemoteException;
  public void setStationID1(String stationID1) throws RemoteException;
  public String getStationID2() throws RemoteException;
  public void setStationID2(String stationID2) throws RemoteException;
  public SubrouteVO getSubroute() throws RemoteException;
}