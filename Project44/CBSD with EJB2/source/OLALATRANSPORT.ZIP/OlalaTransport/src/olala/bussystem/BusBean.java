package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public class BusBean implements EntityBean {
  EntityContext entityContext;
  public String busID;
  public String companyID;
  public String modelID;
  public boolean forRent;
  public String ejbCreate(String busID, String companyID, String modelID, boolean forRent) throws CreateException, RemoteException {
    this.busID = busID;
    this.companyID = companyID;
    this.modelID = modelID;
    this.forRent = forRent;
    return null;
  }
  public String ejbCreate(String busID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(busID, null, null, false);
  }
  public void ejbPostCreate(String busID, String companyID, String modelID, boolean forRent) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String busID) throws CreateException, RemoteException {
    ejbPostCreate(busID, null, null, false);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getBusID() {
    return busID;
  }
  public String getCompanyID() {
    return companyID;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public boolean getForRent() {
    return forRent;
  }
  public void setForRent(boolean forRent) {
    this.forRent = forRent;
  }
  public BusVO getBus() {
	return new BusVO(busID, companyID, modelID, forRent);
  }
}