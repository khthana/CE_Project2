package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public interface BookingServiceHome extends EJBHome {
  public BookingService create() throws RemoteException, CreateException;
}