package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public interface Bus extends EJBObject {
  public String getBusID() throws RemoteException;
  public String getCompanyID() throws RemoteException;
  public void setCompanyID(String companyID) throws RemoteException;
  public String getModelID() throws RemoteException;
  public void setModelID(String modelID) throws RemoteException;
  public boolean getForRent() throws RemoteException;
  public void setForRent(boolean forRent) throws RemoteException;
  public BusVO getBus() throws RemoteException;
}