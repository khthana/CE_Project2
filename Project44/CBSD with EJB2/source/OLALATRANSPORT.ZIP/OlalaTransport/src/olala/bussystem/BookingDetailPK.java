package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingDetailPK implements Serializable {

  public String bookingID;
  public int itemNo;

  public BookingDetailPK() {
  }

  public BookingDetailPK(String bookingID, int itemNo) {
    this.bookingID = bookingID;
    this.itemNo = itemNo;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      BookingDetailPK that = (BookingDetailPK) obj;
      return this.bookingID.equals(that.bookingID) && this.itemNo == that.itemNo;
    }
    return false;
  }
  public int hashCode() {
    return bookingID.hashCode() | itemNo;
  }
}