package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

public interface BusRentingHome extends EJBHome {
  public BusRenting create(Timestamp usingDate, String busID, String bookingID, double price) throws CreateException, RemoteException;
  public BusRenting findByPrimaryKey(BusRentingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}