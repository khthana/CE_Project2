package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusFeeVO implements Serializable {

  private String companyID;
  private double pricePerKm;
  private double fee;
  private double rentCost;

  public BusFeeVO() {
  }

  public BusFeeVO(String companyID, double pricePerKm, double fee, double rentCost) {
	this.companyID = companyID;
	this.pricePerKm = pricePerKm;
	this.fee = fee;
	this.rentCost = rentCost;
  }
  public String getCompanyID() {
    return companyID;
  }
  public double getFee() {
    return fee;
  }
  public double getPricePerKm() {
    return pricePerKm;
  }
  public double getRentCost() {
    return rentCost;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public void setFee(double fee) {
    this.fee = fee;
  }
  public void setPricePerKm(double pricePerKm) {
    this.pricePerKm = pricePerKm;
  }
  public void setRentCost(double rentCost) {
    this.rentCost = rentCost;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}