package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:         Booking Detail
 * Description:   Details of each booking
 * Copyright:     Copyright (c) 2001
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class BookingDetailBean implements EntityBean {
  EntityContext entityContext;
  public int itemNo;
  public String routeID;
  public Timestamp departDate;
  public double price;
  public int srcIdx;
  public int desIdx;
  public int totalSeat;
  public String bookingID;

  public BookingDetailPK ejbCreate(String bookingID, int itemNo, String routeID, Date departDate, double price, int srcIdx, int desIdx, int totalSeat) throws CreateException, RemoteException {
    this.bookingID = bookingID;
    this.itemNo = itemNo;
    this.routeID = routeID;
    this.departDate = new Timestamp(departDate.getTime());
    this.price = price;
    this.srcIdx = srcIdx;
    this.desIdx = desIdx;
    this.totalSeat = totalSeat;
    return null;
  }
  public void ejbPostCreate(String bookingID, int itemNo, String routeID, Date departDate, double price, int srcIdx, int desIdx, int totalSeat) throws CreateException, RemoteException {
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getBookingID() {
    return bookingID;
  }
  public int getItemNo() {
    return itemNo;
  }
  public String getRouteID() {
    return routeID;
  }
  public void setRouteID(String routeID) {
    this.routeID = routeID;
  }
  public Date getDepartDate() {
    return new Date(departDate.getTime());
  }
  public void setDepartDate(Date departDate) {
    this.departDate = new Timestamp(departDate.getTime());
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public int getSrcIdx() {
    return srcIdx;
  }
  public void setSrcIdx(int srcIdx) {
    this.srcIdx = srcIdx;
  }
  public int getDesIdx() {
    return desIdx;
  }
  public void setDesIdx(int desIdx) {
    this.desIdx = desIdx;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }
  public BookingDetailVO getBookingDetail() {
    BookingDetailVO bookingdetailVO = new BookingDetailVO();
	bookingdetailVO.setBookingID(bookingID);
	bookingdetailVO.setItemNo(itemNo);
	bookingdetailVO.setrouteID(routeID);
	bookingdetailVO.setDepartDate(new Date(departDate.getTime()));
	bookingdetailVO.setSrcIdx(srcIdx);
	bookingdetailVO.setDesIdx(desIdx);
	bookingdetailVO.setTotalSeat(totalSeat);
	bookingdetailVO.setPrice(price);
	return bookingdetailVO;
  }
}
