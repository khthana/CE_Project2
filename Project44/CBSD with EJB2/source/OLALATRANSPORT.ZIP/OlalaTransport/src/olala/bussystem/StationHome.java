package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface StationHome extends EJBHome {
  public Station create(String stationID, String stationName, String city, String state, String country, String description, String imagePath) throws CreateException, RemoteException;
  public Station create(String stationID) throws RemoteException, CreateException;
  public Station findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}