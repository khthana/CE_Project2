package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Booking extends EJBObject {

  public String getBookingID() throws RemoteException;
  public Timestamp getTransactionDate() throws RemoteException;
  public Timestamp getConfirmDeadline() throws RemoteException;
  public Integer getTransactionID() throws RemoteException;
  public int getConfirmation() throws RemoteException;
  public String getCustomerID() throws RemoteException;
  public boolean getObsoleted() throws RemoteException;
  public BookingVO getBooking() throws RemoteException;

  public void setConfirmDeadline(Timestamp confirmDeadline) throws RemoteException;
  public void setConfirmation(int confirmation) throws RemoteException;
  public void setObsoleted(boolean obsoleted) throws RemoteException;
  public void setTransactionDate(Timestamp transactionDate) throws RemoteException;
  public void setTransactionID(Integer transactionID) throws RemoteException;
  public void setCustomerID(String CustomerID) throws RemoteException;
}