package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SeatVO implements Serializable {

  private String seatNo;
  private String modelID;
  private boolean smoking;
  private boolean window;

  public SeatVO() {
  }
  public SeatVO(String seatNo, String modelID, boolean smoking, boolean window) {
	this.seatNo = seatNo;
	this.modelID = modelID;
	this.smoking = smoking;
	this.window = window;
  }
  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public void setSeatNo(String seatNo) {
    this.seatNo = seatNo;
  }
  public String getSeatNo() {
    return seatNo;
  }
  public boolean isSmoking() {
    return smoking;
  }
  public void setSmoking(boolean smoking) {
    this.smoking = smoking;
  }
  public void setWindow(boolean window) {
    this.window = window;
  }
  public boolean isWindow() {
    return window;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}