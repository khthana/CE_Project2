package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SubrouteBean implements EntityBean {
  EntityContext entityContext;
  public Integer subrouteID;
  public double distance;
  public String stationID1;
  public String stationID2;
  public Integer ejbCreate(Integer subrouteID, double distance, String stationID1, String stationID2) throws CreateException, RemoteException {
    this.subrouteID = subrouteID;
    this.distance = distance;
    this.stationID1 = stationID1;
    this.stationID2 = stationID2;
    return null;
  }
  public Integer ejbCreate(Integer subrouteID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(subrouteID, 0.0, null, null);
  }
  public void ejbPostCreate(Integer subrouteID, double distance, String stationID1, String stationID2) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(Integer subrouteID) throws CreateException, RemoteException {
    ejbPostCreate(subrouteID, 0.0, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public Integer getSubrouteID() {
    return subrouteID;
  }
  public double getDistance() {
    return distance;
  }
  public void setDistance(double distance) {
    this.distance = distance;
  }
  public String getStationID1() {
    return stationID1;
  }
  public void setStationID1(String stationID1) {
    this.stationID1 = stationID1;
  }
  public String getStationID2() {
    return stationID2;
  }
  public void setStationID2(String stationID2) {
    this.stationID2 = stationID2;
  }

  public SubrouteVO getSubroute() {
    SubrouteVO subrouteVO = new SubrouteVO();
    subrouteVO.setSubrouteID(this.subrouteID.intValue());
    subrouteVO.setDistance(this.distance);
    subrouteVO.setStationID1(this.stationID1);
    subrouteVO.setStationID2(this.stationID2);
    return(subrouteVO);
  }
}