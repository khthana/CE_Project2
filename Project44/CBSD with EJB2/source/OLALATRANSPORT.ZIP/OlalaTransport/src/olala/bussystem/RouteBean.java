package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class RouteBean implements EntityBean {
  EntityContext entityContext;
  public String routeID;
  public String description;
  public String companyID;
  public String modelID;
  public String ejbCreate(String routeID, String description, String companyID, String modelID) throws CreateException, RemoteException {
    this.routeID = routeID;
    this.description = description;
    this.companyID = companyID;
    this.modelID = modelID;
    return null;
  }
  public String ejbCreate(String routeID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(routeID, null, null, null);
  }
  public void ejbPostCreate(String routeID, String description, String companyID, String modelID) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String routeID) throws CreateException, RemoteException {
    ejbPostCreate(routeID, null, null, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getRouteID() {
    return routeID;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getCompanyID() {
    return companyID;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public RouteVO getRoute() {
    RouteVO routeVO = new RouteVO(routeID, description, companyID, modelID);
    return (routeVO);
  }
}