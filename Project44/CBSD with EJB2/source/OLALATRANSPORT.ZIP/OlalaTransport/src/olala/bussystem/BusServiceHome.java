package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public interface BusServiceHome extends EJBHome {
  public BusService create() throws RemoteException, CreateException;
}