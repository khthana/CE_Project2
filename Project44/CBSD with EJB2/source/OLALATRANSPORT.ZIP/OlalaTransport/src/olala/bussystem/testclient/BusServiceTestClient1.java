package olala.bussystem.testclient;

import olala.bussystem.*;
import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.sql.Time;
import java.util.Collection;
import java.sql.Date;

public class BusServiceTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private BusServiceHome busServiceHome = null;
  private BusService busService = null;

  /**Construct the EJB test client*/
  public BusServiceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BusService");

      //cast to Home interface
      busServiceHome = (BusServiceHome) PortableRemoteObject.narrow(ref, BusServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public BusService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      busService = busServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + busService + ".");
    }
    return busService;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public void AddBus(String busID, String companyID, String modelID, boolean forRent) {
    if (busService == null) {
      System.out.println("Error in AddBus(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddBus(" + busID + ", " + companyID + ", " + modelID + ", " + forRent + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddBus(busID, companyID, modelID, forRent);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddBus(" + busID + ", " + companyID + ", " + modelID + ", " + forRent + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddBus(" + busID + ", " + companyID + ", " + modelID + ", " + forRent + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddBusModel(String modelID, String modelName, int totalSeat, String description, boolean toilet) {
    if (busService == null) {
      System.out.println("Error in AddBusModel(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddBusModel(" + modelID + ", " + modelName + ", " + totalSeat + ", " + description + ", " + toilet + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddBusModel(modelID, modelName, totalSeat, description, toilet);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddBusModel(" + modelID + ", " + modelName + ", " + totalSeat + ", " + description + ", " + toilet + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddBusModel(" + modelID + ", " + modelName + ", " + totalSeat + ", " + description + ", " + toilet + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddBusSchedule(String routeID, int subrouteID, Time arriveTime, Time departTime, int arriveDay, int departDay, int idx) {
    if (busService == null) {
      System.out.println("Error in AddBusSchedule(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddBusSchedule(" + routeID + ", " + subrouteID + ", " + arriveTime + ", " + departTime + ", " + arriveDay + ", " + departDay + ", " + idx + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddBusSchedule(routeID, subrouteID, arriveTime, departTime, arriveDay, departDay, idx);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddBusSchedule(" + routeID + ", " + subrouteID + ", " + arriveTime + ", " + departTime + ", " + arriveDay + ", " + departDay + ", " + idx + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddBusSchedule(" + routeID + ", " + subrouteID + ", " + arriveTime + ", " + departTime + ", " + arriveDay + ", " + departDay + ", " + idx + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddCompany(String companyID, String companyName, String description) {
    if (busService == null) {
      System.out.println("Error in AddCompany(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddCompany(" + companyID + ", " + companyName + ", " + description + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddCompany(companyID, companyName, description);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddCompany(" + companyID + ", " + companyName + ", " + description + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddCompany(" + companyID + ", " + companyName + ", " + description + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddRoute(String routeID, String description, String companyID, String modelID) {
    if (busService == null) {
      System.out.println("Error in AddRoute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddRoute(" + routeID + ", " + description + ", " + companyID + ", " + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddRoute(routeID, description, companyID, modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddRoute(" + routeID + ", " + description + ", " + companyID + ", " + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddRoute(" + routeID + ", " + description + ", " + companyID + ", " + modelID + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddStation(String stationID, String stationName, String city, String state, String country, String description, String imagePath) {
    if (busService == null) {
      System.out.println("Error in AddStation(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddStation(" + stationID + ", " + stationName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddStation(stationID, stationName, city, state, country, description, imagePath);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddStation(" + stationID + ", " + stationName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddStation(" + stationID + ", " + stationName + ", " + city + ", " + state + ", " + country + ", " + description + ", " + imagePath + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddSubroute(double distance, String stationID1, String stationID2) {
    if (busService == null) {
      System.out.println("Error in AddSubroute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddSubroute(" + distance + ", " + stationID1 + ", " + stationID2 + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddSubroute(distance, stationID1, stationID2);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddSubroute(" + distance + ", " + stationID1 + ", " + stationID2 + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddSubroute(" + distance + ", " + stationID1 + ", " + stationID2 + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddSubroute(int subrouteID, double distance, String stationID1, String stationID2) {
    if (busService == null) {
      System.out.println("Error in AddSubroute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddSubroute(" + subrouteID + ", " + distance + ", " + stationID1 + ", " + stationID2 + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddSubroute(subrouteID, distance, stationID1, stationID2);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddSubroute(" + subrouteID + ", " + distance + ", " + stationID1 + ", " + stationID2 + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddSubroute(" + subrouteID + ", " + distance + ", " + stationID1 + ", " + stationID2 + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddBusFee(String modelID, String companyID, double pricePerKm, double fee, double rentCost) {
    if (busService == null) {
      System.out.println("Error in AddBusFee(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddBusFee(" + modelID + ", " + companyID + ", " + pricePerKm + ", " + fee + ", " + rentCost + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddBusFee(modelID, companyID, pricePerKm, fee, rentCost);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddBusFee(" + modelID + ", " + companyID + ", " + pricePerKm + ", " + fee + ", " + rentCost + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddBusFee(" + modelID + ", " + companyID + ", " + pricePerKm + ", " + fee + ", " + rentCost + ")");
      }
      e.printStackTrace();
    }
  }

  public void AddSeat(String seatNo, String modelID, boolean smoking, boolean window) {
    if (busService == null) {
      System.out.println("Error in AddSeat(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling AddSeat(" + seatNo + ", " + modelID + ", " + smoking + ", " + window + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.AddSeat(seatNo, modelID, smoking, window);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: AddSeat(" + seatNo + ", " + modelID + ", " + smoking + ", " + window + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: AddSeat(" + seatNo + ", " + modelID + ", " + smoking + ", " + window + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteBus(String busID) {
    if (busService == null) {
      System.out.println("Error in DeleteBus(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteBus(" + busID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteBus(busID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteBus(" + busID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteBus(" + busID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteBusModel(String modelID) {
    if (busService == null) {
      System.out.println("Error in DeleteBusModel(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteBusModel(" + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteBusModel(modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteBusModel(" + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteBusModel(" + modelID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteBusSchedule(String routeID, int subrouteID) {
    if (busService == null) {
      System.out.println("Error in DeleteBusSchedule(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteBusSchedule(" + routeID + ", " + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteBusSchedule(routeID, subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteBusSchedule(" + routeID + ", " + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteBusSchedule(" + routeID + ", " + subrouteID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteCompany(String companyID) {
    if (busService == null) {
      System.out.println("Error in DeleteCompany(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteCompany(" + companyID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteCompany(companyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteCompany(" + companyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteCompany(" + companyID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteRoute(String routeID) {
    if (busService == null) {
      System.out.println("Error in DeleteRoute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteRoute(" + routeID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteRoute(routeID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteRoute(" + routeID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteRoute(" + routeID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteStation(String stationID) {
    if (busService == null) {
      System.out.println("Error in DeleteStation(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteStation(" + stationID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteStation(stationID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteStation(" + stationID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteStation(" + stationID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteSubroute(int subrouteID) {
    if (busService == null) {
      System.out.println("Error in DeleteSubroute(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteSubroute(" + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteSubroute(subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteSubroute(" + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteSubroute(" + subrouteID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteBusFee(String modelID, String companyID) {
    if (busService == null) {
      System.out.println("Error in DeleteBusFee(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteBusFee(" + modelID + ", " + companyID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteBusFee(modelID, companyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteBusFee(" + modelID + ", " + companyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteBusFee(" + modelID + ", " + companyID + ")");
      }
      e.printStackTrace();
    }
  }

  public void DeleteSeat(String seatNo, String modelID) {
    if (busService == null) {
      System.out.println("Error in DeleteSeat(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling DeleteSeat(" + seatNo + ", " + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      busService.DeleteSeat(seatNo, modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: DeleteSeat(" + seatNo + ", " + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: DeleteSeat(" + seatNo + ", " + modelID + ")");
      }
      e.printStackTrace();
    }
  }

  public Collection GetAllBus() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllBus(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllBus()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllBus();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllBus()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllBus()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllBus(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllBusModel() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllBusModel(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllBusModel()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllBusModel();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllBusModel()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllBusModel()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllBusModel(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllBusSchedule() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllBusSchedule(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllBusSchedule()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllBusSchedule();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllBusSchedule()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllBusSchedule()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllBusSchedule(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllCompany() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllCompany(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllCompany()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllCompany();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllCompany()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllCompany()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllCompany(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllRoute() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllRoute(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllRoute()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllRoute();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllRoute()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllRoute()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllRoute(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllStation() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllStation(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllStation()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllStation();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllStation()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllStation()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllStation(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllSubroute() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllSubroute(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllSubroute()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllSubroute();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllSubroute()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllSubroute()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllSubroute(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllBusFee() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllBusFee(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllBusFee()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllBusFee();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllBusFee()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllBusFee()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllBusFee(): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetAllSeat() {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetAllSeat(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetAllSeat()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetAllSeat();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetAllSeat()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetAllSeat()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetAllSeat(): " + returnValue + ".");
    }
    return returnValue;
  }

  public BusVO GetBus(String busID) {
    BusVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetBus(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBus(" + busID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetBus(busID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBus(" + busID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBus(" + busID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBus(" + busID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public BusModelVO GetBusModel(String modelID) {
    BusModelVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetBusModel(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBusModel(" + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetBusModel(modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBusModel(" + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBusModel(" + modelID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBusModel(" + modelID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public BusScheduleVO GetBusSchedule(String routeID, int subrouteID) {
    BusScheduleVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetBusSchedule(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBusSchedule(" + routeID + ", " + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetBusSchedule(routeID, subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBusSchedule(" + routeID + ", " + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBusSchedule(" + routeID + ", " + subrouteID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBusSchedule(" + routeID + ", " + subrouteID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public CompanyVO GetCompany(String companyID) {
    CompanyVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetCompany(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetCompany(" + companyID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetCompany(companyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetCompany(" + companyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetCompany(" + companyID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetCompany(" + companyID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public RouteVO GetRoute(String routeID) {
    RouteVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetRoute(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetRoute(" + routeID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetRoute(routeID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetRoute(" + routeID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetRoute(" + routeID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetRoute(" + routeID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public StationVO GetStation(String stationID) {
    StationVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetStation(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetStation(" + stationID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetStation(stationID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetStation(" + stationID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetStation(" + stationID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetStation(" + stationID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public SubrouteVO GetSubroute(int subrouteID) {
    SubrouteVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetSubroute(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetSubroute(" + subrouteID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetSubroute(subrouteID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetSubroute(" + subrouteID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetSubroute(" + subrouteID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetSubroute(" + subrouteID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public BusFeeVO GetBusFee(String modelID, String companyID) {
    BusFeeVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetBusFee(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBusFee(" + modelID + ", " + companyID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetBusFee(modelID, companyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBusFee(" + modelID + ", " + companyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBusFee(" + modelID + ", " + companyID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBusFee(" + modelID + ", " + companyID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public SeatVO GetSeat(String seatNo, String modelID) {
    SeatVO returnValue = null;
    if (busService == null) {
      System.out.println("Error in GetSeat(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetSeat(" + seatNo + ", " + modelID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.GetSeat(seatNo, modelID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetSeat(" + seatNo + ", " + modelID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetSeat(" + seatNo + ", " + modelID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetSeat(" + seatNo + ", " + modelID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection Search(String stationsrcID, String stationdesID, int totalseat, Date departdate, Time departtime, String company, boolean toilet, boolean smoking, boolean window, boolean nonstoponly) {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in Search(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Search(" + stationsrcID + ", " + stationdesID + ", " + totalseat + ", " + departdate + ", " + departtime + ", " + company + ", " + toilet + ", " + smoking + ", " + window + ", " + nonstoponly + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.Search(stationsrcID, stationdesID, totalseat, departdate, departtime, company, toilet, smoking, window, nonstoponly);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Search(" + stationsrcID + ", " + stationdesID + ", " + totalseat + ", " + departdate + ", " + departtime + ", " + company + ", " + toilet + ", " + smoking + ", " + window + ", " + nonstoponly + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Search(" + stationsrcID + ", " + stationdesID + ", " + totalseat + ", " + departdate + ", " + departtime + ", " + company + ", " + toilet + ", " + smoking + ", " + window + ", " + nonstoponly + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from Search(" + stationsrcID + ", " + stationdesID + ", " + totalseat + ", " + departdate + ", " + departtime + ", " + company + ", " + toilet + ", " + smoking + ", " + window + ", " + nonstoponly + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection SearchForRent(Date startdate, Date stopdate, boolean toilet, String companyID) {
    Collection returnValue = null;
    if (busService == null) {
      System.out.println("Error in SearchForRent(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchForRent(" + startdate + ", " + stopdate + ", " + toilet + ", " + companyID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = busService.SearchForRent(startdate, stopdate, toilet, companyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchForRent(" + startdate + ", " + stopdate + ", " + toilet + ", " + companyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchForRent(" + startdate + ", " + stopdate + ", " + toilet + ", " + companyID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchForRent(" + startdate + ", " + stopdate + ", " + toilet + ", " + companyID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  public void ShowOneResult(BusSeatSearchResult bsr)
  {
    System.out.println("Route   : " + bsr.getRouteID());
	System.out.println("Company : " + bsr.getCompanyName());
	System.out.println("ModelID : " + bsr.getModelID());
	System.out.println("Price   : " + bsr.getPrice());
  }

  public void ShowOneRentResult(BusRentSearchResult brsr)
  {
    System.out.println("BusID     : " + brsr.getBusID());
	System.out.println("ModelID   : " + brsr.getModelID());
	System.out.println("CompanyID : " + brsr.getCompanyID());
	System.out.println("RentCost  : " + brsr.getRentCost());
  }

  /**Main method*/

  public static void main(String[] args) {
    BusServiceTestClient1 client = new BusServiceTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.

	// Create new Instance of Remote Object
	client.create();
	// Search the Bus Seat
	System.out.println("Test BusService.Search() ");
	Collection sr = client.Search("YVR", "DFW", 1, java.sql.Date.valueOf("2002-5-15"), null, null, false, false, false, false );

	java.util.Iterator i = sr.iterator();
	while (i.hasNext()) {
	  BusSeatSearchResult bsr = (BusSeatSearchResult) i.next();
	  System.out.println("======== Start Entry ========");
	  client.ShowOneResult(bsr);
	  System.out.println("========= End Entry =========");
	}

	System.out.println("Test BusService.SearchForRent()");
	sr = client.SearchForRent(java.sql.Date.valueOf("2002-10-15"), java.sql.Date.valueOf("2002-10-17"), false, null);
	i = sr.iterator();
	while (i.hasNext()) {
	  BusRentSearchResult brsr = (BusRentSearchResult) i.next();
	  System.out.println("======== Start Entry ========");
	  client.ShowOneRentResult(brsr);
	  System.out.println("========= End Entry =========");
	}

	client.DeleteBusFee("757", "AA");
	BusModelVO bmVO = client.GetBusModel("747");
	System.out.println("Bus Description = " + bmVO.getDescription());
  }
}