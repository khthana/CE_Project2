package olala.bussystem;

import java.io.*;
import java.sql.Date;

/**
 * Title:         BookingDetailVO.java
 * Description:   Booking Detail Data Object
 * Copyright:     Copyright (c) 2001
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class BookingDetailVO implements Serializable {
  private int itemNo;
  private String routeID;
  private Date departDate;
  private double price;
  private int srcIdx;
  private int desIdx;
  private int totalSeat;
  private String bookingID;

  public BookingDetailVO() {
  }

  public void setBookingID(String bookingID) {
    this.bookingID = bookingID;
  }
  public String getBookingID() {
    return bookingID;
  }
  public void setItemNo(int itemNo) {
	this.itemNo = itemNo;
  }

  public int getItemNo() {
    return itemNo;
  }
  public String getrouteID() {
    return routeID;
  }
  public void setrouteID(String routeID) {
    this.routeID = routeID;
  }
  public Date getDepartDate() {
    return departDate;
  }
  public void setDepartDate(Date departDate) {
    this.departDate = departDate;
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public int getSrcIdx() {
    return srcIdx;
  }
  public void setSrcIdx(int srcIdx) {
    this.srcIdx = srcIdx;
  }
  public int getDesIdx() {
    return desIdx;
  }
  public void setDesIdx(int desIdx) {
    this.desIdx = desIdx;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}