package olala.bussystem;

import olala.bussystem.*;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author EJB Group
 * @version 1.0
 */

public interface BusModel extends EJBObject {
  public String getModelID() throws RemoteException;
  public String getModelName() throws RemoteException;
  public void setModelName(String modelName) throws RemoteException;
  public int getTotalSeat() throws RemoteException;
  public void setTotalSeat(int totalSeat) throws RemoteException;
  public BusModelVO getBusModel() throws RemoteException;
  public String getDescription() throws RemoteException;
  public boolean isToilet() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public void setToilet(boolean toilet) throws RemoteException;
}