package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Station extends EJBObject {
  public String getStationID() throws RemoteException;
  public String getStationName() throws RemoteException;
  public void setStationName(String stationName) throws RemoteException;
  public String getCity() throws RemoteException;
  public void setCity(String city) throws RemoteException;
  public String getState() throws RemoteException;
  public void setState(String state) throws RemoteException;
  public String getCountry() throws RemoteException;
  public void setCountry(String country) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getImagePath() throws RemoteException;
  public void setImagePath(String imagePath) throws RemoteException;
  public olala.bussystem.StationVO getStation() throws RemoteException;
  public void setStation(StationVO stationVO) throws RemoteException;
}