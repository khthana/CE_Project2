package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface RouteHome extends EJBHome {
  public Route create(String routeID, String description, String companyID, String modelID) throws CreateException, RemoteException;
  public Route create(String routeID) throws RemoteException, CreateException;
  public Route findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}