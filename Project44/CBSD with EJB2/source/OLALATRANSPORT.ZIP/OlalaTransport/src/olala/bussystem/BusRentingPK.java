package olala.bussystem;

import java.io.*;
import java.sql.*;

public class BusRentingPK implements Serializable {

  public Timestamp usingDate;
  public String busID;

  public BusRentingPK() {
  }

  public BusRentingPK(Timestamp usingDate, String busID) {
    this.usingDate = usingDate;
    this.busID = busID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      BusRentingPK that = (BusRentingPK) obj;
      return this.usingDate.equals(that.usingDate) && this.busID.equals(that.busID);
    }
    return false;
  }
  public int hashCode() {
    return (usingDate + "" +busID).hashCode();
  }
}