package olala.bussystem;

import java.io.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public class SeatBookingPK implements Serializable {

  public String routeID;
  public int subRouteID;
  public String seatNo;
  public Timestamp departDate;

  public SeatBookingPK() {
  }

  public SeatBookingPK(String routeID, int subRouteID, String seatNo, Timestamp departDate) {
    this.routeID = routeID;
    this.subRouteID = subRouteID;
    this.seatNo = seatNo;
    this.departDate = departDate;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      SeatBookingPK that = (SeatBookingPK) obj;
      return this.routeID.equals(that.routeID) && this.subRouteID == that.subRouteID && this.seatNo.equals(that.seatNo) && this.departDate.equals(that.departDate);
    }
    return false;
  }
  public int hashCode() {
    return (routeID + subRouteID + "" +seatNo + departDate).hashCode();
  }
}