package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class RouteVO implements Serializable {

  private String routeID;
  private String description;
  private String companyID;
  private String modelID;

  public RouteVO() {
  }

  public RouteVO(
      String routeID,
      String description,
      String companyID,
      String modelID) {

    this.routeID = routeID;
    this.description = description;
    this.companyID = companyID;
    this.modelID = modelID;
  }
  public String getRouteID() {
    return routeID;
  }
  public void setRouteID(String routeID) {
    this.routeID = routeID;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getCompanyID() {
    return companyID;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public String getModelID() {
    return modelID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}