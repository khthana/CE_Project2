package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

public interface BusService extends EJBObject {

  public void AddBus( String busID, String companyID, String modelID, boolean forRent ) throws RemoteException;
  public void AddBusModel( String modelID, String modelName, int totalSeat, String description, boolean toilet ) throws RemoteException;
  public void AddBusSchedule( String routeID, int subrouteID, Time arriveTime, Time departTime, int arriveDay, int departDay, int idx ) throws RemoteException;
  public void AddCompany( String companyID, String companyName, String description ) throws RemoteException;
  public void AddRoute( String routeID, String description, String companyID, String modelID ) throws RemoteException;
  public void AddStation( String stationID, String stationName, String city, String state, String country, String description, String imagePath ) throws CreateException, RemoteException;
  public void AddSubroute( double distance, String stationID1, String stationID2 ) throws RemoteException;
  public void AddSubroute( int subrouteID, double distance, String stationID1, String stationID2 ) throws RemoteException;
  public void AddBusFee( String modelID, String companyID, double pricePerKm, double fee, double rentCost ) throws RemoteException;
  public void AddSeat( String seatNo, String modelID, boolean smoking, boolean window ) throws RemoteException;

  public void DeleteBus( String busID ) throws RemoteException;
  public void DeleteBusModel( String modelID ) throws RemoteException;
  public void DeleteBusSchedule( String routeID, int subrouteID ) throws RemoteException;
  public void DeleteCompany( String companyID ) throws RemoteException;
  public void DeleteRoute( String routeID ) throws RemoteException;
  public void DeleteStation( String stationID ) throws RemoteException, RemoveException;
  public void DeleteSubroute( int subrouteID ) throws RemoteException;
  public void DeleteBusFee( String modelID, String companyID ) throws RemoteException;
  public void DeleteSeat( String seatNo, String modelID ) throws RemoteException;

  public Collection GetAllBus() throws RemoteException;
  public Collection GetAllBusModel() throws RemoteException;
  public Collection GetAllBusSchedule() throws RemoteException;
  public Collection GetAllCompany() throws RemoteException;
  public Collection GetAllRoute() throws RemoteException;
  public Collection GetAllStation() throws RemoteException;
  public Collection GetAllSubroute() throws RemoteException;
  public Collection GetAllBusFee() throws RemoteException;
  public Collection GetAllSeat() throws RemoteException;

  public BusVO         GetBus( String busID ) throws RemoteException;
  public BusModelVO    GetBusModel( String modelID ) throws RemoteException;
  public BusScheduleVO GetBusSchedule( String routeID, int subrouteID ) throws RemoteException;
  public CompanyVO     GetCompany( String companyID ) throws RemoteException;
  public RouteVO       GetRoute( String routeID ) throws RemoteException;
  public StationVO     GetStation( String stationID ) throws RemoteException;
  public SubrouteVO    GetSubroute( int subrouteID ) throws RemoteException;
  public BusFeeVO      GetBusFee( String modelID, String companyID ) throws RemoteException;
  public SeatVO        GetSeat( String seatNo, String modelID ) throws RemoteException;

  public Collection Search( String stationsrcID, String stationdesID, int totalseat, Date departdate,
	Time departtime, String company, boolean toilet, boolean smoking, boolean window, boolean nonstoponly ) throws EJBException, RemoteException;
  public Collection SearchForRent(Date startdate, Date stopdate, boolean toilet, String companyID)
    throws RemoteException;
}