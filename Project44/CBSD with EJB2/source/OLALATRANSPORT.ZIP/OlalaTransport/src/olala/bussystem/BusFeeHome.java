package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

public interface BusFeeHome extends EJBHome {
  public BusFee create(String modelID, String companyID, double pricePerKm, double fee, double rentCost) throws CreateException, RemoteException;
  public BusFee create(String modelID, String companyID) throws RemoteException, CreateException;
  public BusFee findByPrimaryKey(BusFeePK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}