package olala.bussystem;

import java.io.*;

public class BusFeePK implements Serializable {

  public String modelID;
  public String companyID;

  public BusFeePK() {
  }

  public BusFeePK(String modelID, String companyID) {
    this.modelID = modelID;
    this.companyID = companyID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      BusFeePK that = (BusFeePK) obj;
      return this.modelID.equals(that.modelID) && this.companyID.equals(that.companyID);
    }
    return false;
  }
  public int hashCode() {
    return (modelID + companyID).hashCode();
  }
}