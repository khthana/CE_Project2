package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingDetail extends EJBObject {
  public String getBookingID() throws RemoteException;
  public int getItemNo() throws RemoteException;
  public String getRouteID() throws RemoteException;
  public void setRouteID(String routeID) throws RemoteException;
  public Date getDepartDate() throws RemoteException;
  public void setDepartDate(Date departDate) throws RemoteException;
  public double getPrice() throws RemoteException;
  public void setPrice(double price) throws RemoteException;
  public int getSrcIdx() throws RemoteException;
  public void setSrcIdx(int srcIdx) throws RemoteException;
  public int getDesIdx() throws RemoteException;
  public void setDesIdx(int desIdx) throws RemoteException;
  public int getTotalSeat() throws RemoteException;
  public void setTotalSeat(int totalSeat) throws RemoteException;
  public BookingDetailVO getBookingDetail() throws RemoteException;
}
