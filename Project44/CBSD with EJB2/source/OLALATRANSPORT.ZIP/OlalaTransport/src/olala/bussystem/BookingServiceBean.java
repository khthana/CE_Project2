package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import javax.rmi.*;
import javax.naming.*;
import javax.sql.*;
import java.sql.*;
import java.util.*;
import olala.util.*;

/**
 * Title: Bus Booking Service
 * Description: Booking Service of Bus System , responsibility of management
 * in booking such as Reserve, Confirm, Cancel, Rent
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingServiceBean implements SessionBean {
  private int CONFIRMATION_DATES = 7; // 7 day before depart by default
  private int BOOKING_DATES      = 14;
  private final String DATASOURCE_NAME = "java:comp/env/jdbc/DataSource";

  private SessionContext sessionContext = null;
  private BookingHome bookingHome = null;
  private BookingDetailHome bookingDetailHome = null;
  private SeatBookingHome seatBookingHome = null;
  private BusHome busHome = null;
  private BusRentingHome busRentingHome = null;
  private TravellerHome travellerHome = null;
  private UUID uuidgen = null;
  private DataSource datasource = null;

  public BookingVO GetBooking(String bookingID) throws RemoteException {
	BookingVO bookingVO = null;
	try {
	  Booking booking = bookingHome.findByPrimaryKey(new BookingPK(bookingID));
	  bookingVO = booking.getBooking();
	}
	catch (FinderException fe) {
	  throw new RemoteException();
	}
	return bookingVO;
  }

  public Collection GetBookings(String customerID) throws RemoteException {
    Vector allBookingsCollection = new Vector();
    try {
      Collection bookingsCollection = bookingHome.findByCustomerID(customerID);
      Iterator i = bookingsCollection.iterator();
      Object obj;

      while(i.hasNext()) {
        obj = i.next();
        Booking booking = (Booking) PortableRemoteObject.narrow(obj, Booking.class);
        BookingVO bookingVO = booking.getBooking();
        allBookingsCollection.addElement(bookingVO);
      }
      return(allBookingsCollection);
    }
    catch(FinderException fe) {
      throw new RemoteException();
    }
  }

  public Collection GetBookingDetails(String bookingID) throws RemoteException {
    Vector allBookingDetailCollection = new Vector();
    try {
      Collection bookingDetailCollection = bookingDetailHome.findByBookingID(bookingID);
      Iterator i = bookingDetailCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        BookingDetail bookingDetail = (BookingDetail) PortableRemoteObject.narrow(obj, BookingDetail.class);
        BookingDetailVO bdVO = bookingDetail.getBookingDetail();
        allBookingDetailCollection.addElement(bdVO);
      }
      return(allBookingDetailCollection);
    }
    catch(FinderException fe) {
      throw new RemoteException();
    }
  }

  public Collection GetSeatBookings( String bookingID, int itemNo) {

	Collection traveller_seat_collection = null;
	Connection conn = null;
	PreparedStatement prstmt = null;
	ResultSet rs = null;
	String strCommand = "SELECT DISTINCT S.SeatNo, T.TravellerID, T.FirstName, T.LastName " +
						"FROM SeatBooking S, Traveller T " +
						"WHERE S.TravellerID = T.TravellerID " +
						"AND BookingID = ? AND ItemNo = ? ;";
	try {
	  conn = datasource.getConnection();
	  prstmt = conn.prepareStatement(strCommand);
	  prstmt.setString(1, bookingID);
	  prstmt.setInt(2, itemNo);
	  rs = prstmt.executeQuery();
	  traveller_seat_collection = new ArrayList(1);
	  while (rs.next()) {
		String seatNo = rs.getString(1);
		TravellerVO travellerVO = new TravellerVO(rs.getString(2), rs.getString(3), rs.getString(4));
		TravellerSeat ts = new TravellerSeat(travellerVO, seatNo);
	    traveller_seat_collection.add(ts);
	  }
	  rs.close();
	}
	catch (SQLException se) {
	  throw new EJBException ("[BookingService][getSeatBookings] Cannot Execute SQL Statement");
	}
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(prstmt, conn);
	}
    return traveller_seat_collection;
  }

/* Not yet implemented */
  public Collection ViewBooking(String bookingID) {

	String strCommand = " SELECT T2.ItemNo, T2.RouteID, MIN( T3.DepartDate + T8.DepartTime + 2), MAX( T3.DepartDate + T8.ArriveTime + 2), " +
					    "        COUNT( DISTINCT T10.SeatNo ), T2.Price, " +
						"		 T4.StationID, T4.StationName, T5.StationID, T5.StationName " +
					    " FROM   Booking T1, BookingDetail T2, SeatBooking T3, " +
						"	     Station T4, Station T5, " +
						"        SubRoute T6, SubRoute T7, " +
						"        BusSchedule T8, BusSchedule T9, Seat T10, Route T11" +
						" WHERE  T1.BookingID = ? " +
						"   AND  T2.BookingID = T1.BookingID "+
						"   AND  T3.BookingID = T2.BookingID "+
						"   AND  T3.ItemNo = T2.ItemNo " +
						"   AND  T4.StationID = T6.StationID1 " +
						"   AND  T5.StationID = T7.StationID2 " +
						"   AND  T6.SubRouteID = T8.SubRouteID " +
						"   AND  T7.SubRouteID = T9.SubRouteID " +
						"   AND  T8.RouteID = T2.RouteID " +
						"   AND  T9.RouteID = T2.RouteID " +
						"   AND  T8.idx = T2.SrcIdx " +
						"   AND  T9.idx = T2.DesIdx " +
						"   AND  T10.ModelID = T11.ModelID " +
						"   AND  T10.SeatNo = T3.SeatNo" +
						"   AND  T11.RouteID = T2.RouteID " +
						" GROUP BY T2.ItemNo, T2.RouteID, T2.Price, T4.StationID, T4.StationName, T5.StationID, T5.StationName " +
						" ORDER BY T2.ItemNo ;" ;

	Connection conn = null;
	PreparedStatement prstmt = null;
	Collection viewbookresult = null;
	try {
	  conn = datasource.getConnection();
	  prstmt = conn.prepareStatement(strCommand);

	  prstmt.setString(1, bookingID);
	  ResultSet rs_viewbooking = prstmt.executeQuery();
	  viewbookresult = new ArrayList();

	  while (rs_viewbooking.next()) {
		int       _itemNo           = rs_viewbooking.getInt(1);
		String    _routeID          = rs_viewbooking.getString(2);
		Timestamp _departdt         = rs_viewbooking.getTimestamp(3);
		Timestamp _arrivedt         = rs_viewbooking.getTimestamp(4);
		int       _totalseat        = rs_viewbooking.getInt(5);
		double    _price            = rs_viewbooking.getDouble(6);
		String    _stationsrcID     = rs_viewbooking.getString(7);
		String    _stationsrcName   = rs_viewbooking.getString(8);
		String    _stationdesID     = rs_viewbooking.getString(9);
		String    _stationdesName   = rs_viewbooking.getString(10);

		ViewBookInfo vbi = new ViewBookInfo(_itemNo,
											_routeID,
											_stationsrcID,
											_stationsrcName,
											_stationdesID,
											_stationdesName,
											_departdt,
											_arrivedt,
											_totalseat,
											_price);
		viewbookresult.add(vbi);
	  }
	  // Not implement ed yet , just test querying
	  rs_viewbooking.close();
	}
	catch (SQLException se) {
	  throw new EJBException("[BookingService][ViewBooking] Cannot Execute SQL statement");
	}
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(prstmt, conn);
	}
	return viewbookresult;
  }

  public Collection ViewRentBooking(String bookingID) {
	String strCommand = " SELECT T1.BusID, T1.CompanyID, T1.ModelID, T2.UsingDate, T2.Price " +
						" FROM   Bus T1, BusRenting T2 " +
						" WHERE  T2.BusID = T1.BusID " +
						"    AND T2.BookingID = ? ";

	Connection conn = null;
	PreparedStatement prstmt = null;
	Collection viewrentbookresult = null;
	try {
	  conn = datasource.getConnection();
	  prstmt = conn.prepareStatement(strCommand);

	  prstmt.setString(1, bookingID);
	  ResultSet rs_viewrentbooking = prstmt.executeQuery();
	  viewrentbookresult = new ArrayList();

	  while (rs_viewrentbooking.next()) {
		String _busID = rs_viewrentbooking.getString(1);
		String _companyID = rs_viewrentbooking.getString(2);
		String _modelID = rs_viewrentbooking.getString(3);
		Timestamp _usingdate = rs_viewrentbooking.getTimestamp(4);
		double _rentcost = rs_viewrentbooking.getDouble(5);

		ViewRentBookInfo vbi = new ViewRentBookInfo(_busID, _companyID, _modelID, _usingdate, _rentcost);
		viewrentbookresult.add(vbi);
	  }
	  // Not implement ed yet , just test querying
	  rs_viewrentbooking.close();
	}
	catch (SQLException se) {
	  throw new EJBException("[BookingService][ViewBooking] Cannot Execute SQL statement");
	}
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(prstmt, conn);
	}
	return viewrentbookresult;
  }

  private String getNewBookingID(Connection conn) throws SQLException {
	// Encapsulate finding new booking ID method here
	String newBookingID = null;
	try {
	  newBookingID = uuidgen.getUUID();
	}
	catch(RemoteException re) {
	  System.out.println("Fail to call UUID generator, use NULL value");
	}
	return newBookingID;
  }

  private String getNewTravellerID(Connection conn) throws SQLException {
    // Encapsulate finding new Traveller ID method here
	String newTravellerID = null;
	try {
	  newTravellerID = uuidgen.getUUID();
	}
	catch(RemoteException re) {
	  System.out.println("Fail to call UUID generator, use NULL value");
	}
	return newTravellerID;
  }

  public void Confirm(String bookingID) throws ReserveException {
	Connection conn = null;
	ResultSet rs = null;
	Statement stmt = null;
	try {
	  java.util.Date today = new java.util.Date();

	  // check if confirmable
	  Booking booking = (Booking) bookingHome.findByPrimaryKey(new BookingPK(bookingID));
	  System.out.println("Finding Booking #:" + bookingID);
	  BookingVO bookingVO = booking.getBooking();
	  Timestamp cnfdeadline = bookingVO.getConfirmDeadline();

	  if ( today.before(cnfdeadline) ) {
		// set confirm status
		booking.setConfirmation(1);
      }
	  else
	    throw new ReserveException("[BookingService][Confirm] Cannot Confirm : Date Expired, But the server did not remove your booking yet");
    }
	catch (RemoteException re) {
	  throw new EJBException("[BookingService][Confirm] Remote Exception with bookingHome");
	}
    catch (FinderException fe) {
      throw new EJBException("[BookingService][Confirm] Cannot Find the Booking to Confirm");
    }
  }

  private void InsertTraveller(Connection conn, String travellerID, String firstName, String lastName) throws SQLException {
	String strCmdInsTraveller = " INSERT INTO Traveller VALUES (?,?,?)";
	PreparedStatement prstmt_insTraveller  = conn.prepareStatement( strCmdInsTraveller );
	prstmt_insTraveller.setString(1, travellerID);
	prstmt_insTraveller.setString(2, firstName);
	prstmt_insTraveller.setString(3, lastName);
	prstmt_insTraveller.executeUpdate();
	prstmt_insTraveller.close();
  }

  private void InsertBooking(Connection conn, String bookingID,
							 int txID, Timestamp txDate,
							 String customerID,
							 int confirmation, Timestamp confirmDeadline, boolean obsoleted ) throws SQLException
  {
	String strCmdInsBooking = " INSERT INTO Booking VALUES (?,?,?,?,?,?,?)";
	PreparedStatement prstmt_insBooking = conn.prepareStatement( strCmdInsBooking );
	prstmt_insBooking.setString(1, bookingID);
	prstmt_insBooking.setInt(2, txID);
	prstmt_insBooking.setTimestamp(3, txDate);
	prstmt_insBooking.setString(4, customerID);
	prstmt_insBooking.setInt(5, confirmation);
	prstmt_insBooking.setTimestamp(6, confirmDeadline);
	prstmt_insBooking.setBoolean(7, obsoleted);
	prstmt_insBooking.executeUpdate();
	prstmt_insBooking.close();
  }

  private void InsertBookingDetail(Connection conn,
								   String bookingID, int itemNo,
								   String routeID, Timestamp departDate,
								   double unitPrice,
								   int srcIdx, int desIdx,
								   int totalSeat ) throws SQLException
  {
	String strCmdInsBookingDetail = " INSERT INTO BookingDetail VALUES (?,?,?,?,?,?,?,?)";
	PreparedStatement prstmt_insBookingDetail  = conn.prepareStatement( strCmdInsBookingDetail );
	prstmt_insBookingDetail.setString(1, bookingID);
	prstmt_insBookingDetail.setInt(2, itemNo);
	prstmt_insBookingDetail.setString(3, routeID);
	prstmt_insBookingDetail.setTimestamp(4, departDate);
	prstmt_insBookingDetail.setDouble(5, unitPrice);
	prstmt_insBookingDetail.setInt(6, srcIdx);
	prstmt_insBookingDetail.setInt(7, desIdx);
	prstmt_insBookingDetail.setInt(8, totalSeat);
	prstmt_insBookingDetail.executeUpdate();
	prstmt_insBookingDetail.close();
  }

  private void InsertSeatBooking(Connection conn, String bookingID, int itemNo, String routeID,
											      int subrouteID, String seatNo,
											      Timestamp departDate,
											      String travellerID) throws SQLException
  {
	String strCmdInsSeatBooking = " INSERT INTO SeatBooking VALUES (?,?,?,?,?,?,?)";
	PreparedStatement prstmt_insSeatBooking  = conn.prepareStatement( strCmdInsSeatBooking );

	prstmt_insSeatBooking.setString(1, bookingID);
	prstmt_insSeatBooking.setInt(2, itemNo);
	prstmt_insSeatBooking.setString(3, routeID);
	prstmt_insSeatBooking.setInt(4, subrouteID);
	prstmt_insSeatBooking.setString(5, seatNo);
	prstmt_insSeatBooking.setTimestamp(6, departDate);
	prstmt_insSeatBooking.setString(7, travellerID);
	prstmt_insSeatBooking.executeUpdate();
	prstmt_insSeatBooking.close();
  }

  private void InsertBusRenting(Connection conn, Timestamp usingDate, String busID, String bookingID, double price) throws SQLException {
	String strCmdInsBusRenting = "INSERT INTO BusRenting VALUES(?,?,?,?)";
	PreparedStatement prstmt_insBusRenting = conn.prepareStatement(strCmdInsBusRenting);

	prstmt_insBusRenting.setTimestamp(1, usingDate);
	prstmt_insBusRenting.setString(2, busID);
	prstmt_insBusRenting.setString(3, bookingID);
	prstmt_insBusRenting.setDouble(4, price);
	prstmt_insBusRenting.executeUpdate();
	prstmt_insBusRenting.close();
  }
  private int[][] QuerySubroute(Connection conn, String routeID, int srcIdx, int desIdx) throws SQLException
  {
	// String strCmdSelSubroute = "SELECT T.SubrouteID, T.DepartDay FROM ...
	String strCmdSelSubroute =  "SELECT T.SubrouteID FROM BusSchedule T WHERE (T.RouteID = ?) AND (T.Idx >= ?) AND (T.Idx <= ?) ORDER BY T.Idx";
	PreparedStatement prstmt_selSubroute = conn.prepareStatement( strCmdSelSubroute );
	prstmt_selSubroute.setString(1, routeID);
	prstmt_selSubroute.setInt(2, srcIdx);
	prstmt_selSubroute.setInt(3, desIdx);
	prstmt_selSubroute.executeQuery();
	ResultSet rs = prstmt_selSubroute.executeQuery();
	int[][] _allsubroute = new int[20][2];
	int count_subroute = 0;
	while (rs.next()) {
	  int subrouteID = rs.getInt(1);
	  // int departdayrel = rs.getInt(2);
	  int departdayrel = 0;
	  _allsubroute[count_subroute][0] = subrouteID;
	  _allsubroute[count_subroute][1] = departdayrel;
	  count_subroute++;
	}
	int allsubroute[][] = new int[count_subroute][2];
	for (int i = 0; i < count_subroute; i++) {
	    allsubroute[i][0] = _allsubroute[i][0];
		allsubroute[i][1] = _allsubroute[i][1];
	}
	rs.close();
	prstmt_selSubroute.close();
	return allsubroute;
  }

  private String QueryFreeSeat(Connection conn, String routeID, boolean toilet,
                               boolean window, boolean smoking,
							   Timestamp departDate,
							   int srcIdx, int desIdx) throws SQLException, InsufficientSeatException
  {
	String strCmdSelSeatNo =
	  "SELECT     T1.SeatNo " +
	  "FROM       Seat T1, Route T2, BusModel T5 " +
	  "WHERE      T2.RouteID = ?" +
	  "       AND T2.ModelID = T1.ModelID " +
	  "       AND T5.ModelID = T1.ModelID " +
	  "       AND (T5.Toilet | ?) = 1" +
	  "       AND (T1.Window | ?) = 1" +
	  "       AND (T1.Smoking | ?) = 1" +
	  "       AND T1.SeatNo NOT IN ( " +
				"SELECT     DISTINCT T3.SeatNo " +
				"FROM       SeatBooking T3, BusSchedule T4 " +
				"WHERE      T3.DepartDate = ? " +
				"       AND T4.RouteID = T2.RouteID " +
				"       AND T3.RouteID = T4.RouteID " +
				"       AND T3.SubrouteID = T4.SubrouteID "  +
				"       AND T4.Idx >= ? " +
				"       AND T4.Idx <= ? ) " +
	  " ORDER BY T1.SeatNo";

	PreparedStatement  prstmt_selSeatNo = conn.prepareStatement( strCmdSelSeatNo );

	prstmt_selSeatNo.setString( 1, routeID );
  	prstmt_selSeatNo.setBoolean( 2, toilet );
	prstmt_selSeatNo.setBoolean( 3, window );
	prstmt_selSeatNo.setBoolean( 4, smoking );
	prstmt_selSeatNo.setTimestamp( 5, departDate);
	prstmt_selSeatNo.setInt( 6, srcIdx );
	prstmt_selSeatNo.setInt( 7, desIdx );
	String freeSeatNo = null;
	ResultSet rs = prstmt_selSeatNo.executeQuery();
	if (rs.next()) {
	   freeSeatNo = rs.getString(1);
	}
	else {
	  throw new InsufficientSeatException("No available seat to reserve ");
	}
	rs.close();
	prstmt_selSeatNo.close();
	return freeSeatNo;
  }

  private double QueryPrice(Connection conn, String routeID, int srcIdx, int desIdx) throws SQLException, ReserveException
  {
	String strCmdSelUnitPrice =
	  " SELECT SUM(T4.Distance) * T2.PricePerKm + T2.Fee " +
	  " FROM Route T1, BusFee T2, BusSchedule T3, Subroute T4 " +
	  " WHERE T2.CompanyID = T1.CompanyID "  +
	  "   AND T2.ModelID = T1.ModelID " +
	  "   AND T1.RouteID = ? " +
	  "   AND T3.RouteID = T1.RouteID " +
	  "   AND T3.SubrouteID = T4.SubrouteID " +
	  "   AND T3.idx >= ? " +
	  "   AND T3.idx <= ? " +
	  " GROUP BY T2.PricePerKm, T2.Fee";

	PreparedStatement prstmt_selUnitPrice = conn.prepareStatement( strCmdSelUnitPrice );
	prstmt_selUnitPrice.setString(1, routeID);
	prstmt_selUnitPrice.setInt(2, srcIdx);
	prstmt_selUnitPrice.setInt(3, desIdx);

	ResultSet rs_unitprice = prstmt_selUnitPrice.executeQuery();
	double unitprice = 0;
	if (rs_unitprice.next()) {
	  unitprice = rs_unitprice.getDouble(1);
	}
	else {
	  throw new ReserveException("[BookingService][Reserve] Price for these seats are NOT AVAILABLE");
	}
	rs_unitprice.close();
	prstmt_selUnitPrice.close();
	return unitprice;
  }

  private double QueryRentCost(Connection conn, String busID) throws SQLException, ReserveException {
	String strCmdSelRentCost = "SELECT T2.RentCost " +
							   "FROM Bus T1, BusFee T2 " +
							   "WHERE T1.BusID = ? AND T2.CompanyID = T1.CompanyID AND T2.ModelID = T1.ModelID ";

	PreparedStatement prstmt_selRentCost = conn.prepareStatement(strCmdSelRentCost);
	prstmt_selRentCost.setString(1, busID);
	ResultSet rs = prstmt_selRentCost.executeQuery();
	double rentCost = 0;
	if (rs.next()) {
	  rentCost = rs.getDouble(1);
	}
	else {
	  throw new ReserveException("[BookingService][Rent] Rent Cost is NOT AVAILABLE");
	}
	prstmt_selRentCost.close();
	return  rentCost;
  }

  private Timestamp QueryConfirmDeadline(Connection conn, String bookingID) throws SQLException {
	String strCmdSelConfirmDeadline = "SELECT MIN (DepartDate - ?)" +
									  "FROM SeatBooking T2 " +
									  "WHERE BookingID = ? ";

	PreparedStatement prstmt_selCnfDeadline = conn.prepareStatement(strCmdSelConfirmDeadline);
	prstmt_selCnfDeadline.setInt(1, CONFIRMATION_DATES);
	prstmt_selCnfDeadline.setString(2, bookingID);
	ResultSet rs_cnfdeadline = prstmt_selCnfDeadline.executeQuery();
	Timestamp cnfdeadline;
	if (rs_cnfdeadline.next()) {
	  cnfdeadline = rs_cnfdeadline.getTimestamp(1);
	}
	else {
	  cnfdeadline = null;
	}
	rs_cnfdeadline.close();
	prstmt_selCnfDeadline.close();
	return cnfdeadline;
  }

  private void UpdateConfirmDeadline (Connection conn, String bookingID, Timestamp confirmDeadline) throws SQLException {
	String strCmdUpdateCnfDeadline = "UPDATE Booking SET ConfirmDeadline = ? " +
									 "WHERE BookingID = ? ";
    PreparedStatement prstmt_updCnfDeadline = conn.prepareStatement(strCmdUpdateCnfDeadline);
	if (confirmDeadline == null) {
	  prstmt_updCnfDeadline.setNull(1, Types.TIMESTAMP);//PreparedStatement.
	}
	else {
	  prstmt_updCnfDeadline.setTimestamp(1, confirmDeadline);
	}
	prstmt_updCnfDeadline.setString(2, bookingID);
	prstmt_updCnfDeadline.executeUpdate();
	prstmt_updCnfDeadline.close();
  }
  // Reserve()
  // return : BookingID of new created Booking
  public String Reserve( String customerID, Collection reservelist ) throws InsufficientSeatException, ReserveException, Exception  // ReserveException
  {
	Connection conn = null;
	try {
	  System.out.println("Create Connection");
	  conn = datasource.getConnection();
	  conn.setAutoCommit(false);

	  java.sql.Timestamp txdate = new java.sql.Timestamp( System.currentTimeMillis() );
	  System.out.println("Today timestamp : " + txdate.toString());

	  String bookingID = getNewBookingID(conn);

	  // ============ Insert New Booking ============
	  System.out.println("Try to call BookingHome.create(): new BookingID = " + bookingID);
	  Integer transactionID = new Integer(0); // initialize variable
	  System.out.println("Prepare Statement InsertBooking");
	  InsertBooking(conn, bookingID, transactionID.intValue(), txdate, customerID, 0, null, false);
	  System.out.println("Create Booking Success");
	  // ============ End Insert New Booking ========

	  int ItemNo = 0;
	  Iterator iterReserveItem = reservelist.iterator();
	  while ( iterReserveItem.hasNext() ) {
		ItemNo = ItemNo + 1; // next item number
	    ReserveItem ri = (ReserveItem) iterReserveItem.next();

		if (!ri.isValid()) {
		  throw new ReserveException("There are some invalid Parameter..");
		}

		String _routeID = ri.getRouteID();
		java.sql.Date _departDate = ri.getDepartDate();
		java.sql.Timestamp _departDateTS = new java.sql.Timestamp(_departDate.getTime());
		int _srcIdx = ri.getSrcIdx();
		int _desIdx = ri.getDesIdx();
		int _totalSeat = ri.getSeats();
		boolean _toilet = ri.getToilet();
		boolean _window = ri.getWindow();
		boolean _smoking = ri.getSmoking();


		System.out.println("Begin Reserve Item# : " + ItemNo);
		// Debugging  : Display sender information
		System.out.println("RouteID: " + _routeID);
		System.out.println("DepartDate: " + _departDate);
		System.out.println("SrcIdx: " + _srcIdx);
		System.out.println("DesIdx: " + _desIdx);
		System.out.println("Toilet: " + _toilet);
		System.out.println("Window: " + _window);
		System.out.println("Smoking: " + _smoking);
		System.out.println("TotalSeat: " + _totalSeat);

		// Check Dates, is it valid for reserve, must be in BOOKING_DATES days before earliest depart date
		long bookinglength = new java.sql.Date(70, 0, BOOKING_DATES).getTime();
		java.sql.Timestamp lastbookabledate = new java.sql.Timestamp(_departDate.getTime() - bookinglength);
		System.out.println("Last bookable date = " + lastbookabledate.toString());
		if (txdate.after(lastbookabledate)) {
		   // Too late to reserve, raise some exception
		   throw new ReserveException("[BookingService][Reserve] Date expired, you must reserve within " + BOOKING_DATES + " day(s) before depart date");
		}
		// =========Finding all subroute===========
		System.out.println("Prepare Statement SelectSubroute");
		// Find ResultSet
		System.out.println("Execute Statement SelSubRoute :");
		int[][] allsubrouteid = QuerySubroute(conn, _routeID, _srcIdx, _desIdx);
		int count_subroute = allsubrouteid.length;
		System.out.println("Done Statement SelSubroute");
		System.out.println("Number of Subroute : " + count_subroute);

		// ===============End finding All subroute=============
		// Finding Unit Price / Traveller
		System.out.println("Prepare Statement SelectUnitPrice");
		System.out.println("Execute Statement Select UnitPrice :");
		double unitprice = QueryPrice(conn, _routeID, _srcIdx, _desIdx);
		System.out.println("Unit Price = " + unitprice);

		// =============== End finding Unit Price ==================

		// ============== Insert New Booking Detail =================
		System.out.println("Creating BookingDetail");
		System.out.println("BookingID = " + bookingID);
		System.out.println("ItemNo = " + ItemNo);
		System.out.println("Route = " + _routeID);
		System.out.println("Depart Date = " + _departDate);
		System.out.println("Total Seat = " + _totalSeat);

		System.out.println("Execute Statement InsertBookingDetail");
	 	InsertBookingDetail(conn, bookingID, ItemNo, _routeID, _departDateTS, unitprice, _srcIdx, _desIdx, _totalSeat);
		System.out.println("Create BookingDetail Done ");
		// ============== End Insert Booking detail =================

		// For Each Traveller
		Iterator iterTraveller = ri.getAllTraveller().iterator();
		while( iterTraveller.hasNext() ) {
		  // Find next seat number
		  // Set Statement Parameter of Select Free Seat
		  System.out.println("Execute Statement Select SeatNo :");
		  String freeSeatNo = QueryFreeSeat(conn, _routeID, !_toilet, !_window, !_smoking, _departDateTS, _srcIdx, _desIdx );
		  System.out.println("Done Excecute Query");
		  // End Statement

		  TravellerVO currTraveller = (TravellerVO)iterTraveller.next();
		  String firstName = currTraveller.getFirstName();
		  String lastName  = currTraveller.getLastName();

		  System.out.println("Trying to reserve / 1 Traveller");
		  System.out.println("Traveller FirstName : " + firstName);
 		  System.out.println("Traveller LastName : " + lastName);
  		  System.out.println("Seat No : " + freeSeatNo);
		  // now we have got seat number, get new Traveller ID
		  // Done Insert New Traveller
		  // for each subroute.., mark the traveller in
		  String travellerID = getNewTravellerID(conn);
		  //Integer newTravellerID = new Integer(travellerID);
		  //make new Traveller Record
		  System.out.println("Trying to create new traveller ID = " + travellerID);
		  // Insert New Traveller Using SQL
		  System.out.println("Prepare Statement InsertTraveller");
		  InsertTraveller(conn, travellerID, firstName, lastName );
		  System.out.println("Create new Traveller Success");

		  for( int i = 0; i < count_subroute; i++ ) {
		    // Create new row in SeatBooking
		    int subrouteID = allsubrouteid[i][0];
			System.out.println("    Create new SeatBooking");
			System.out.println("Prepare Statement InsertSeatBooking");
			java.sql.Date subroutedepartdate = new java.sql.Date(_departDate.getYear(),
						  _departDate.getMonth(),
						  _departDate.getDate() + allsubrouteid[i][1] - allsubrouteid[0][1]);
						  // plus relative depart day
			java.sql.Timestamp _subroutedepartdateTS = new java.sql.Timestamp(subroutedepartdate.getTime());
			InsertSeatBooking(conn, bookingID, ItemNo, _routeID, subrouteID, freeSeatNo, _subroutedepartdateTS, travellerID);
			System.out.println("    End SeatBooking");
			// Done create new row of SeatBooking
		  }
		  System.out.println("End Reservation for One Traveller");
		}
	    System.out.println("End Reserve Item # " + ItemNo);
	    // End of An ReserveItem
	  }
	  System.out.println("End Reservation with BookingID = " + bookingID);

	  // now update the confirm deadline of Booking
	  System.out.println("Finding Confirm Deadline..");
	  Timestamp cnfdeadline = QueryConfirmDeadline(conn, bookingID);
	  System.out.println("Confirm Deadline = " + cnfdeadline.toString());
	  System.out.println("Updating Booking.. ");
	  UpdateConfirmDeadline(conn, bookingID, cnfdeadline);
	  System.out.println("Update Booking confirm deadline success");
	  System.out.println("End Reservation with BookingID = " + bookingID);

	  // Commit all changes
	  conn.commit();
	  return bookingID;
	}
	catch (SQLException sqle) {
	  sqle.printStackTrace();
	  conn.rollback();
	  throw new EJBException("Cannot Execute SQL Statement");
	}
	catch (ReserveException re) {
	  System.out.println("Cannot Reserve ... Some Error occurred");
	  conn.rollback();
	  throw re;
	}
	catch (InsufficientSeatException ise) {
	  System.out.println("Seat not Available");
	  conn.rollback();
	  throw ise;
	}
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(null, conn);
	}
  }

  // Rent the Bus, for using all of the day
  public String Rent(String customerID, Collection rentItems) throws ReserveException, Exception {
	PreparedStatement prepstmt = null;
	Connection conn = null;
	Booking booking = null;
	try {
	  System.out.println("Create Connection");
	  conn = datasource.getConnection();
	  conn.setAutoCommit(false);
	  java.sql.Timestamp txdate = new java.sql.Timestamp( System.currentTimeMillis() );
	  System.out.println("Today timestamp : " + txdate.toString());

	  // Obtain new booking ID from UUID generator
	  String bookingID = getNewBookingID(conn);

	  // ============ Insert New Booking ============
	  System.out.println("Try to call BookingHome.create(): new BookingID = " + bookingID);
	  Integer transactionID = new Integer(0); // initialize variable
	  System.out.println("Prepare Statement InsertBooking");
	  InsertBooking(conn, bookingID, transactionID.intValue(), txdate, customerID, 0, null, false);
	  System.out.println("Create Booking Success");
	  // ============ End Insert New Booking ========

	  Iterator iterRentItem = rentItems.iterator();
	  // length of one day, in millisecond
	  long oneday = 86400000;
	  System.out.println("Oneday long = " + oneday + " ms.");
	  Timestamp recentstartdate = null;

	  while (iterRentItem.hasNext()) {
		RentItem ri = (RentItem) iterRentItem.next();
		System.out.println("=====Next Rent Item=====");
		String busID = ri.getBusID();
		Timestamp startTS = ri.getStartDate();
		Timestamp stopTS  = ri.getStopDate();
		System.out.println("BusID : " + busID +  "start:" + startTS + " stop:" + stopTS);

		// check validity of Reserving Dates
		if (startTS.after(stopTS)) {
		  throw new ReserveException("[BookingService][Rent] Invalid using Date : Stop date must be after start Date");
		}

		// Update recently Start Date
		if (recentstartdate == null) {
		  recentstartdate = startTS;
		}
		else if ( recentstartdate.after(startTS) ) {
		  recentstartdate = startTS;
		}

		// Check Dates, is it valid for reserve, must be in BOOKING_DATES days before earliest depart date
		long bookinglength = new java.sql.Date(70, 0, BOOKING_DATES).getTime();
		java.sql.Timestamp lastbookabledate = new java.sql.Timestamp(startTS.getTime() - bookinglength);
		System.out.println("Last bookable date = " + lastbookabledate.toString());
		if (txdate.after(lastbookabledate)) {
		   // Too late to reserve, raise some exception
		   throw new ReserveException("[BookingService][Rent] Date expired, you must reserve within " + BOOKING_DATES + " day(s) before depart date");
		}

		// check existing of Bus Rent Cost
		double price;
		try {
		  System.out.print("Finding Rent Cost of BusID# : " + busID);
		  price = QueryRentCost(conn, busID);
		  System.out.println(" Found.");
		}
		catch (ReserveException re) {
		  re.printStackTrace();
		  throw new ReserveException("[BookingService][Rent] Cannot find the Rent Cost of BusID# : " + busID);
		}
		// generate new Booking
		// Iterate to all day
		String strStartDate = "" + (1900 + startTS.getYear()) + "-" + startTS.getMonth() + "-" + startTS.getDate();
		String strStopDate  = "" + (1900 + stopTS.getYear())  + "-" + stopTS.getMonth()  + "-" + stopTS.getDate();
		long startdate_round = java.sql.Date.valueOf(strStartDate).getTime();
		long stopdate_round = java.sql.Date.valueOf(strStopDate).getTime();

		System.out.println("Start date : " + startdate_round + " ; Stop date : " + stopdate_round);
		System.out.println("Looping all date");

		for (long time = startdate_round; time <= stopdate_round; time += oneday) {
		  Timestamp ts = new Timestamp(time);
		  System.out.println("Date : " + ts);
		  // Insert new BusRenting Row to Database
		  //busRentingHome.create(ts, busID, bookingID);
		  InsertBusRenting(conn, ts, busID, bookingID, price);
		}
	  }

	  // Update Confirm Deadline of Booking
	  // now update the confirm deadline of Booking

	  System.out.println("Finding Confirm Deadline..");
	  long cnfdatelength = new java.sql.Date(70, 0, CONFIRMATION_DATES).getTime();
	  Timestamp cnfdeadline = new java.sql.Timestamp(recentstartdate.getTime() - cnfdatelength);
	  System.out.println("Confirm Deadline = " + cnfdeadline.toString());
	  System.out.println("Updating Booking.. ");
	  UpdateConfirmDeadline(conn, bookingID, cnfdeadline);
	  System.out.println("Update Booking confirm deadline success");
	  System.out.println("End Reservation with BookingID = " + bookingID);

	  // Commit all changes
	  conn.commit();
	  // Release the resouce
	  conn.close();
	  return bookingID;
	}
	catch (SQLException re) {
	  re.printStackTrace();
	  conn.rollback();
	  throw new EJBException("Cannot Execute SQL Statement, may be Duplicate Key or Connection Error");
	}
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(null, conn);
	}
  }

  public void CancelBooking(String bookingID) throws RemoteException, ReserveException, Exception {
    /*  for each row in bookingdetail, delete them
        and then remove master row in Booking  */
	PreparedStatement prepstmt = null;
	Connection conn = null;
    try {
      Booking booking = bookingHome.findByPrimaryKey(new BookingPK(bookingID));
      if (booking.getObsoleted() == true) {
        throw new ReserveException("[BookingService][CancelBooking] Cannot cancel booking detail :Booking Obsoleted]");
      }
	  else if (booking.getConfirmation() == 1) {
        throw new ReserveException("[BookingService][CancelBooking] Cannot remove booking detail :Booking Confirmed]");
      }
      // not yet implemented, still do not delete corresponding Traveller
      conn = datasource.getConnection();
	  conn.setAutoCommit(false);
      // Delete all corresponding booking
      prepstmt = conn.prepareStatement("DELETE FROM SeatBooking WHERE BookingID = ?");
      prepstmt.setString(1, bookingID);
      prepstmt.executeUpdate();

      prepstmt = conn.prepareStatement("DELETE FROM BookingDetail WHERE BookingID = ?");
      prepstmt.setString(1, bookingID);
      prepstmt.executeUpdate();

	  prepstmt = conn.prepareStatement("DELETE FROM BusRenting WHERE BookingID = ?");
	  prepstmt.setString(1, bookingID);
	  prepstmt.executeUpdate();

	  prepstmt = conn.prepareStatement("DELETE FROM Booking WHERE BookingID = ?");
	  prepstmt.setString(1, bookingID);
	  prepstmt.executeUpdate();

	  conn.commit();
    }
    catch (FinderException fe) {
      throw new EJBException("Cannot find booking to cancel");
    }
    catch (SQLException re) {
	  conn.rollback();
      throw new EJBException("SQL Error : Can't remove booking");
    }
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(prepstmt, conn);
	}
  }

  public void CancelBookingDetail(String bookingID, int ItemNo) throws ReserveException, Exception
  {
    Connection conn = null;
	PreparedStatement prepstmt = null;

	// for each row in CancelBookingDetail, Delete them
    try {
      Booking booking = bookingHome.findByPrimaryKey(new BookingPK(bookingID));
      if (booking.getObsoleted() == true) {
        throw new ReserveException("[BookingService][CancelBookingDetail] Cannot cancel booking detail :Booking Obsoleted");
      }
      else if (booking.getConfirmation() == 1) {
        throw new ReserveException("[BookingService][CancelBookingDetail] Cannot remove booking detail :Booking Confirmed");
      }
      // not yet implemented, still do not delete corresponding Traveller
      conn = datasource.getConnection();
	  conn.setAutoCommit(false);
      // Delete all corresponding booking
      prepstmt = conn.prepareStatement("DELETE FROM SeatBooking WHERE BookingID = ? AND ItemNo = ?");
      prepstmt.setString(1, bookingID);
      prepstmt.setInt(2, ItemNo);
      prepstmt.executeUpdate();

      prepstmt = conn.prepareStatement("DELETE FROM BookingDetail WHERE BookingID = ? AND ItemNo = ?");
      prepstmt.setString(1, bookingID);
      prepstmt.setInt(2, ItemNo);
      prepstmt.executeUpdate();
	  conn.commit();
    }
    catch (FinderException fe) {
      throw new EJBException("Cannot find booking to delete");
    }
    catch (SQLException fe) {
	  conn.rollback();
      throw new EJBException("SQL Error : Cannot remove booking");
    }
	catch (RemoteException re) {
	  throw new EJBException("Remote Error with Booking Entity");
	}
	finally {
	  System.out.println("Closing Connection");
	  closeConnection(prepstmt, conn);
	}
  }

  public void ejbCreate() {
  }
  public void ejbRemove() throws RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setSessionContext(SessionContext sessionContext) throws RemoteException {
    this.sessionContext = sessionContext;
	try {
      Context ctx = new InitialContext();
      //look up jndi name and cast to Home interface
      bookingHome         = (BookingHome)       PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/Booking" ), BookingHome.class);
      bookingDetailHome   = (BookingDetailHome) PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/BookingDetail" ), BookingDetailHome.class);
      seatBookingHome     = (SeatBookingHome)   PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/SeatBooking" ), SeatBookingHome.class);
	  busHome             = (BusHome)           PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/Bus" ), BusHome.class);
	  busRentingHome      = (BusRentingHome)    PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/BusRenting" ), BusRentingHome.class);
	  travellerHome       = (TravellerHome)     PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/Traveller"), TravellerHome.class);
	  UUIDHome uuidHome   = (UUIDHome)          PortableRemoteObject.narrow(ctx.lookup( "java:comp/env/ejb/UUID"), UUIDHome.class);
	  uuidgen = uuidHome.create();
      datasource = (DataSource)ctx.lookup( DATASOURCE_NAME );
	  // Init Some Business Variable
	  Integer cnfdates = (Integer)ctx.lookup("java:comp/env/confirmLength");
	  System.out.print("Found java:comp/env/confirmLength :");
	  System.out.println("value = " + CONFIRMATION_DATES);
	  CONFIRMATION_DATES = cnfdates.intValue();
	  Integer bkkdates = (Integer)ctx.lookup("java:comp/env/bookingLength");
	  System.out.print("Found java:comp/env/bookingLength :");
	  System.out.println("value = " + BOOKING_DATES);
	  BOOKING_DATES    = bkkdates.intValue();
	}
	catch (javax.naming.NamingException ne) {
	  System.out.println("Some JNDI Name is not visible..");
	  ne.printStackTrace();
	  throw new RemoteException();
    }
	catch (CreateException ce) {
	  System.out.println("Cannot create UUID Generator instance..");
	  ce.printStackTrace();
	  throw new RemoteException();

	}
  }
  private void closeConnection(Statement stmt, Connection conn) {
    try {
      if (stmt != null) { stmt.close(); }
	  if (conn != null) { conn.close(); }
	}
	catch (SQLException se)	{
	}
  }
}