package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author EJB Group
 * @version 1.0
 */

public class BusModelBean implements EntityBean {
  EntityContext entityContext;
  public String modelID;
  public String modelName;
  public int totalSeat;
  public String description;
  public boolean toilet;
  public String ejbCreate(String modelID, String modelName, int totalSeat, String description, boolean toilet) throws CreateException, RemoteException {
    this.modelID = modelID;
    this.modelName = modelName;
    this.totalSeat = totalSeat;
	this.description = description;
	this.toilet = toilet;
    return null;
  }
  public void ejbPostCreate(String modelID, String modelName, int totalSeat, String description, boolean toilet) throws CreateException, RemoteException {
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getModelID() {
    return modelID;
  }
  public String getModelName() {
    return modelName;
  }
  public void setModelName(String modelName) {
    this.modelName = modelName;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }

  public boolean isToilet() {
    return toilet;
  }
  public void setToilet(boolean toilet) {
    this.toilet = toilet;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public BusModelVO getBusModel() {
    BusModelVO busModelVO = new BusModelVO(modelID, modelName, totalSeat, description, toilet);
    return (busModelVO);
  }
}