package olala.bussystem;


import java.io.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SubrouteVO implements Serializable {

  private int subrouteID;
  private double distance;
  private String stationID1;
  private String stationID2;

  public SubrouteVO() {
  }

  public void setSubrouteID(int subrouteID) {
    this.subrouteID = subrouteID;
  }
  public int getSubrouteID() {
    return subrouteID;
  }
  public void setDistance(double distance) {
    this.distance = distance;
  }
  public double getDistance() {
    return distance;
  }
  public void setStationID1(String stationID1) {
    this.stationID1 = stationID1;
  }
  public String getStationID1() {
    return stationID1;
  }
  public void setStationID2(String stationID2) {
    this.stationID2 = stationID2;
  }
  public String getStationID2() {
    return stationID2;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}