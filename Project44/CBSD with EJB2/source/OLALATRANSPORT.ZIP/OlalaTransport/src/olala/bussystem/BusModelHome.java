package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author EJB Group
 * @version 1.0
 */

public interface BusModelHome extends EJBHome {
  public BusModel create(String modelID, String modelName, int totalSeat, String description, boolean toilet) throws CreateException, RemoteException;
  public BusModel findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}