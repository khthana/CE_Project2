package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface BusScheduleHome extends EJBHome {
  public BusSchedule create(String routeID, int subrouteID, Time arriveTime, Time departTime, int departDay, int arriveDay, int idx) throws CreateException, RemoteException;
  public BusSchedule create(String routeID, int subrouteID) throws RemoteException, CreateException;
  public BusSchedule findByPrimaryKey(BusSchedulePK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}