package olala.bussystem;

import java.io.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public class BusSchedulePK implements Serializable {

  public String routeID;
  public int subrouteID;

  public BusSchedulePK() {
  }

  public BusSchedulePK(String routeID, int subrouteID) {
    this.routeID = routeID;
    this.subrouteID = subrouteID;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      BusSchedulePK that = (BusSchedulePK) obj;
      return this.routeID.equals(that.routeID) && this.subrouteID == that.subrouteID;
    }
    return false;
  }
  public int hashCode() {
    return (routeID + subrouteID).hashCode();
  }
}