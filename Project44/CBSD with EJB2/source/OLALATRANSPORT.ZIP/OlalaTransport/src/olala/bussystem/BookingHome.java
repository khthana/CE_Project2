package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingHome extends EJBHome {
  public Booking create(String bookingID, Integer transactionID, Timestamp transactionDate, String customerID, int confirmation, Timestamp confirmDeadline, boolean obsoleted) throws CreateException, RemoteException;
  public Booking findByPrimaryKey(BookingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
  public Collection findByCustomerID(String CustomerID) throws RemoteException, FinderException;
}