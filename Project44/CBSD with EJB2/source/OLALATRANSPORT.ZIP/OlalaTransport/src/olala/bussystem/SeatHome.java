package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

public interface SeatHome extends EJBHome {
  public Seat create(String seatNo, String modelID, boolean smoking, boolean window) throws CreateException, RemoteException;
  public Seat create(String seatNo, String modelID) throws RemoteException, CreateException;
  public Seat findByPrimaryKey(SeatPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}