package olala.bussystem;

import java.sql.Timestamp;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusRentingVO implements Serializable {
  private Timestamp usingDate;
  private String busID;
  private String bookingID;
  private double price;

  public BusRentingVO() {
  }
  public BusRentingVO(Timestamp usingDate, String busID, String bookingID, double price) {
	this.usingDate = usingDate;
    this.busID = busID;
    this.bookingID = bookingID;
	this.price = price;
  }
  public String getBookingID() {
    return bookingID;
  }
  public String getBusID() {
    return busID;
  }
  public Timestamp getUsingDate() {
    return usingDate;
  }
  public void setBookingID(String bookingID) {
    this.bookingID = bookingID;
  }
  public void setBusID(String busID) {
    this.busID = busID;
  }
  public void setUsingDate(Timestamp usingDate) {
    this.usingDate = usingDate;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public double getPrice() {
    return price;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}