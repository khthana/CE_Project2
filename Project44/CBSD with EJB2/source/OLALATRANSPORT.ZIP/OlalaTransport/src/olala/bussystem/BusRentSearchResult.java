package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusRentSearchResult implements Serializable {
  private String busID;
  private String companyID;
  private String modelID;
  private double rentCost;

  public BusRentSearchResult() {
  }

  public BusRentSearchResult(String busID, String companyID, String modelID, double rentCost) {
	this.busID = busID;
	this.companyID = companyID;
	this.modelID = modelID;
	this.rentCost = rentCost;
  }
  public String getBusID() {
    return busID;
  }
  public String getCompanyID() {
    return companyID;
  }
  public String getModelID() {
    return modelID;
  }
  public double getRentCost() {
    return rentCost;
  }
  public void setBusID(String busID) {
    this.busID = busID;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public void setRentCost(double rentCost) {
    this.rentCost = rentCost;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}