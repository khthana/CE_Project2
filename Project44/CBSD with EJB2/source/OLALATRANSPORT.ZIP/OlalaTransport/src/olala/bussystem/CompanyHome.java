package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface CompanyHome extends EJBHome {
  public Company create(String companyID, String companyName, String description) throws CreateException, RemoteException;
  public Company create(String companyID) throws RemoteException, CreateException;
  public Company findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}