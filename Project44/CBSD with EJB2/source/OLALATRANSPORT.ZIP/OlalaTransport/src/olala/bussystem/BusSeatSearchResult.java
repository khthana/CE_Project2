package olala.bussystem;

import java.io.*;
import java.sql.*;

/**
 * Title: Helper Class to store the Result of Seat searching
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusSeatSearchResult implements Serializable {
  String companyName;
  String routeID;
  String routeDescription;
  String modelID;
  String modelName;
  Time departTime;
  Time arriveTime;
  int srcIdx;
  int desIdx;
  double totalDistance;
  double price;

  public BusSeatSearchResult() {
  }
  public BusSeatSearchResult(String companyName, String routeID,
		                     String routeDescription,
							 String modelID, String modelName,
							 Time departTime, Time arriveTime,
							 int srcIdx, int desIdx,
							 double totalDistance, double price )
  {
  this.companyName = companyName;
  this.routeID = routeID;
  this.routeDescription = routeDescription;
  this.modelID = modelID;
  this.modelName = modelName;
  this.departTime = departTime;
  this.arriveTime = arriveTime;
  this.srcIdx = srcIdx;
  this.desIdx = desIdx;
  this.totalDistance = totalDistance;
  this.price = price;
  }
  public Time getArriveTime() {
    return arriveTime;
  }
  public String getCompanyName() {
    return companyName;
  }
  public Time getDepartTime() {
    return departTime;
  }
  public int getDesIdx() {
    return desIdx;
  }
  public String getModelID() {
	return modelID;
  }
  public String getModelName() {
    return modelName;
  }
  public double getPrice() {
    return price;
  }
  public String getRouteDescription() {
    return routeDescription;
  }
  public String getRouteID() {
    return routeID;
  }
  public int getSrcIdx() {
    return srcIdx;
  }
  public double getTotalDistance() {
    return totalDistance;
  }

  public void setArriveTime(Time arriveTime) {
    this.arriveTime = arriveTime;
  }
  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }
  public void setDepartTime(Time departTime) {
    this.departTime = departTime;
  }
  public void setDesIdx(int desIdx) {
    this.desIdx = desIdx;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public void setModelName(String modelName) {
    this.modelName = modelName;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public void setRouteDescription(String routeDescription) {
    this.routeDescription = routeDescription;
  }
  public void setRouteID(String routeID) {
    this.routeID = routeID;
  }
  public void setSrcIdx(int srcIdx) {
    this.srcIdx = srcIdx;
  }
  public void setTotalDistance(double totalDistance) {
    this.totalDistance = totalDistance;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}