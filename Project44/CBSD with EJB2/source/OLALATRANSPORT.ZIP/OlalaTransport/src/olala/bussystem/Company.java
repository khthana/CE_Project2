package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Company extends EJBObject {
  public String getCompanyID() throws RemoteException;
  public String getCompanyName() throws RemoteException;
  public void setCompanyName(String companyName) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public olala.bussystem.CompanyVO getCompany() throws RemoteException;
}