package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusScheduleBean implements EntityBean {
  EntityContext entityContext;
  public String routeID;
  public int subrouteID;
  public Time arriveTime;
  public Time departTime;
  public int departDay;
  public int arriveDay;
  public int idx;
  public BusSchedulePK ejbCreate(String routeID, int subrouteID, Time arriveTime, Time departTime, int departDay, int arriveDay, int idx) throws CreateException, RemoteException {
    this.routeID = routeID;
    this.subrouteID = subrouteID;
    this.arriveTime = arriveTime;
    this.departTime = departTime;
    this.departDay = departDay;
    this.arriveDay = arriveDay;
    this.idx = idx;
    return null;
  }
  public BusSchedulePK ejbCreate(String routeID, int subrouteID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(routeID, subrouteID, null, null, 0, 0, 0);
  }
  public void ejbPostCreate(String routeID, int subrouteID, Time arriveTime, Time departTime, int departDay, int arriveDay, int idx) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String routeID, int subrouteID) throws CreateException, RemoteException {
    ejbPostCreate(routeID, subrouteID, null, null, 0, 0, 0);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getRouteID() {
    return routeID;
  }
  public int getSubrouteID() {
    return subrouteID;
  }
  public Time getArriveTime() {
    return arriveTime;
  }
  public void setArriveTime(Time arriveTime) {
    this.arriveTime = arriveTime;
  }
  public Time getDepartTime() {
    return departTime;
  }
  public void setDepartTime(Time departTime) {
    this.departTime = departTime;
  }
  public int getDepartDay() {
    return departDay;
  }
  public void setDepartDay(int departDay) {
    this.departDay = departDay;
  }
  public int getArriveDay() {
    return arriveDay;
  }
  public void setArriveDay(int arriveDay) {
    this.arriveDay = arriveDay;
  }
  public int getIdx() {
    return idx;
  }
  public void setIdx(int idx) {
    this.idx = idx;
  }

  public BusScheduleVO getBusSchedule() {
    BusScheduleVO busScheduleVO = new BusScheduleVO();
    busScheduleVO.setRouteID(this.routeID);
    busScheduleVO.setSubrouteID(this.subrouteID);
    busScheduleVO.setArriveTime(this.arriveTime);
    busScheduleVO.setDepartTime(this.departTime);
    busScheduleVO.setIdx(this.idx);
    return(busScheduleVO);
  }
}