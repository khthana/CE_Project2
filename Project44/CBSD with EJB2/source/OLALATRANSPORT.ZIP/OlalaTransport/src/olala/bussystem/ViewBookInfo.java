package olala.bussystem;
import java.io.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ViewBookInfo implements Serializable{
  private int itemNo;
  private String  routeID;
  private Timestamp departDateTime;
  private Timestamp arriveDateTime;
  private String stationSrcID;
  private String stationSrcName;
  private String stationDesName;
  private String stationDesID;
  private int totalSeat;
  private double price;

  public ViewBookInfo() {
  }

  public ViewBookInfo(int itemNo, String routeID, String stationSrcID, String stationSrcName, String stationDesID, String stationDesName, Timestamp departDateTime, Timestamp arriveDateTime, int totalSeat, double price) {
	this.itemNo = itemNo;
	this.routeID = routeID;
	this.departDateTime = departDateTime;
	this.arriveDateTime = arriveDateTime;
	this.stationSrcID   = stationSrcID;
	this.stationSrcName = stationSrcName;
	this.stationDesID   = stationDesID;
	this.stationDesName = stationDesName;
	this.totalSeat      = totalSeat;
	this.price = price;
  }
  public Timestamp getArriveDateTime() {
    return arriveDateTime;
  }
  public Timestamp getDepartDateTime() {
    return departDateTime;
  }
  public int getItemNo() {
    return itemNo;
  }
  public double getPrice() {
    return price;
  }
  public String getRouteID() {
    return routeID;
  }
  public String getStationDesID() {
    return stationDesID;
  }
  public String getStationDesName() {
    return stationDesName;
  }
  public String getStationSrcID() {
    return stationSrcID;
  }
  public String getStationSrcName() {
    return stationSrcName;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setArriveDateTime(Timestamp arriveDateTime) {
    this.arriveDateTime = arriveDateTime;
  }
  public void setDepartDateTime(Timestamp departDateTime) {
    this.departDateTime = departDateTime;
  }
  public void setItemNo(int itemNo) {
    this.itemNo = itemNo;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public void setRouteID(String routeID) {
    this.routeID = routeID;
  }
  public void setStationDesID(String stationDesID) {
    this.stationDesID = stationDesID;
  }
  public void setStationDesName(String stationDesName) {
    this.stationDesName = stationDesName;
  }
  public void setStationSrcID(String stationSrcID) {
    this.stationSrcID = stationSrcID;
  }
  public void setStationSrcName(String stationSrcName) {
    this.stationSrcName = stationSrcName;
  }
  public void setTotalSeat(int totalSeat) {
    this.totalSeat = totalSeat;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}