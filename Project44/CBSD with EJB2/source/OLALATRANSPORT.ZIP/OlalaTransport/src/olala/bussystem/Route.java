package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface Route extends EJBObject {
  public String getRouteID() throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getCompanyID() throws RemoteException;
  public void setCompanyID(String companyID) throws RemoteException;
  public String getModelID() throws RemoteException;
  public void setModelID(String modelID) throws RemoteException;
  public olala.bussystem.RouteVO getRoute() throws RemoteException;
}