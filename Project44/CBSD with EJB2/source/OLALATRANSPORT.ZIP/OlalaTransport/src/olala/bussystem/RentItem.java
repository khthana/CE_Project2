package olala.bussystem;

import java.io.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class RentItem implements Serializable {
  private String busID;
  private Timestamp startDate;
  private Timestamp stopDate;

  public RentItem() {
  }

  public RentItem(String busID, Timestamp startDate, Timestamp stopDate) {
	this.busID = busID;
	this.startDate = startDate;
	this.stopDate = stopDate;
  }

  public String getBusID() {
    return busID;
  }
  public Timestamp getStartDate() {
    return startDate;
  }
  public Timestamp getStopDate() {
    return stopDate;
  }
  public void setBusID(String busID) {
    this.busID = busID;
  }
  public void setStartDate(Timestamp startDate) {
    this.startDate = startDate;
  }
  public void setStopDate(Timestamp stopDate) {
    this.stopDate = stopDate;
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }

}