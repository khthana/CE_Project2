package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class TravellerVO implements Serializable {

  private String travellerID;
  private String firstname;
  private String lastname;


  public TravellerVO() {
  }

  public TravellerVO(String travellerID, String firstname, String lastname) {
    this.travellerID = travellerID;
    this.firstname = firstname;
    this.lastname = lastname;
  }

  public void setTravellerID(String travellerID) {
    this.travellerID = travellerID;
  }
  public void setFirstName(String firstname) {
    this.firstname = firstname;
  }
  public void setLastName(String lastname) {
    this.lastname = lastname;
  }
  public String getTravellerID() {
    return travellerID;
  }
  public String getFirstName() {
    return firstname;
  }
  public String getLastName() {
    return lastname;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}