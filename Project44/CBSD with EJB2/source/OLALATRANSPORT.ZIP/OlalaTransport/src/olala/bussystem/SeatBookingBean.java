package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SeatBookingBean implements EntityBean {
  EntityContext entityContext;
  public int itemNo;
  public String routeID;
  public int subRouteID;
  public String seatNo;
  public Timestamp departDate;
  public String bookingID;
  public String travellerID;

  public SeatBookingPK ejbCreate(String bookingID, int itemNo, String routeID, int subRouteID, String seatNo, Timestamp departDate, String travellerID) throws CreateException, RemoteException {
    this.bookingID = bookingID;
    this.itemNo = itemNo;
    this.routeID = routeID;
    this.subRouteID = subRouteID;
    this.seatNo = seatNo;
    this.departDate = departDate;
    this.travellerID = travellerID;
    return null;
  }
  public SeatBookingPK ejbCreate(String routeID, int subRouteID, String seatNo, Timestamp departDate) throws RemoteException, CreateException, RemoteException {
    return ejbCreate("", 0, routeID, subRouteID, seatNo, departDate, null);
  }
  public void ejbPostCreate(String bookingID, int itemNo, String routeID, int subRouteID, String seatNo, Timestamp departDate, String travellerID) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String routeID, int subRouteID, String seatNo, Timestamp departDate) throws CreateException, RemoteException {
    ejbPostCreate("", 0, routeID, subRouteID, seatNo, departDate, null);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getBookingID() {
    return bookingID;
  }
  public void setBookingID(String newBookingID) {
    this.bookingID = bookingID;
  }
  public int getItemNo() {
    return itemNo;
  }
  public void setItemNo(int itemNo) {
    this.itemNo = itemNo;
  }
  public String getRouteID() {
    return routeID;
  }
  public int getSubRouteID() {
    return subRouteID;
  }
  public String getSeatNo() {
    return seatNo;
  }
  public Timestamp getDepartDate() {
    return departDate;
  }
  public String getTravellerID() {
    return travellerID;
  }
  public void setTravellerID(String newTravellerID) {
    this.travellerID = travellerID;
  }
}