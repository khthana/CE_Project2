package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface SeatBooking extends EJBObject {
  public String getBookingID() throws RemoteException;
  public void setBookingID(String bookingID) throws RemoteException;
  public int getItemNo() throws RemoteException;
  public void setItemNo(int itemNo) throws RemoteException;
  public String getRouteID() throws RemoteException;
  public int getSubRouteID() throws RemoteException;
  public String getSeatNo() throws RemoteException;
  public Timestamp getDepartDate() throws RemoteException;
  public String getTravellerID() throws RemoteException;
  public void setTravellerID(String travellerID) throws RemoteException;
}