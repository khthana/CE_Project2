package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import olala.util.*;

public interface BookingService extends EJBObject {
  public String Reserve( String customerID, Collection reservelist ) throws InsufficientSeatException, ReserveException, Exception, RemoteException;
  public String Rent( String customerID, Collection rentItems ) throws ReserveException, Exception, RemoteException;
  public void Confirm( String bookingID ) throws ReserveException, RemoteException;
  public void CancelBooking( String bookingID ) throws RemoteException, ReserveException, Exception;
  public void CancelBookingDetail( String bookingID, int ItemNo ) throws ReserveException, Exception, RemoteException;

  public BookingVO  GetBooking( String bookingID ) throws RemoteException;
  public Collection GetBookings( String customerID ) throws RemoteException;
  public Collection GetBookingDetails( String bookingID ) throws RemoteException;
  public Collection GetSeatBookings( String bookingID, int itemNo ) throws RemoteException;
  public Collection ViewBooking( String bookingID ) throws RemoteException;
  public Collection ViewRentBooking( String bookingID ) throws RemoteException;

}