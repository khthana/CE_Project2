package olala.bussystem;

import java.sql.Timestamp;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ViewRentBookInfo implements Serializable{
  private String busID;
  private String companyID;
  private String modelID;
  private Timestamp usingDate;
  private double rentCost;

  public ViewRentBookInfo() {
  }
  public ViewRentBookInfo(String busID, String companyID, String modelID, Timestamp usingDate, double rentCost) {
	this.busID = busID;
	this.companyID = companyID;
	this.modelID = modelID;
	this.usingDate = usingDate;
	this.rentCost = rentCost;
  }
  public String getBusID() {
    return busID;
  }
  public String getCompanyID() {
    return companyID;
  }
  public String getModelID() {
    return modelID;
  }
  public double getRentCost() {
    return rentCost;
  }
  public Timestamp getUsingDate() {
    return usingDate;
  }
  public void setBusID(String busID) {
    this.busID = busID;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }
  public void setRentCost(double rentCost) {
    this.rentCost = rentCost;
  }
  public void setUsingDate(Timestamp usingDate) {
    this.usingDate = usingDate;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }

}