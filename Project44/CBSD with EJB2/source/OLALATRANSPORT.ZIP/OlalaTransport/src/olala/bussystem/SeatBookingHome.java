package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface SeatBookingHome extends EJBHome {
  public SeatBooking create(String bookingID, int itemNo, String routeID, int subRouteID, String seatNo, Timestamp departDate, String travellerID) throws CreateException, RemoteException;
  public SeatBooking create(String routeID, int subRouteID, String seatNo, Timestamp departDate) throws RemoteException, CreateException;
  public SeatBooking findByPrimaryKey(SeatBookingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}