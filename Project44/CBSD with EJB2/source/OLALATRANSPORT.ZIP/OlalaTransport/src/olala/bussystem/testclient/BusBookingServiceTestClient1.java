package olala.bussystem.testclient;

import olala.bussystem.*;
import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;

public class BusBookingServiceTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private BookingServiceHome bookingServiceHome = null;
  private BookingService bookingService = null;

  /**Construct the EJB test client*/
  public BusBookingServiceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BusBookingService");

      //cast to Home interface
      bookingServiceHome = (BookingServiceHome) PortableRemoteObject.narrow(ref, BookingServiceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://localhost:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public BookingService create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      bookingService = bookingServiceHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + bookingService + ".");
    }
    return bookingService;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public void CancelBooking(String bookingID) {
    if (bookingService == null) {
      System.out.println("Error in CancelBooking(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }
  }

  public void CancelBookingDetail(String bookingID, int ItemNo) {
    if (bookingService == null) {
      System.out.println("Error in CancelBookingDetail(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelBookingDetail(" + bookingID + ", " + ItemNo + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.CancelBookingDetail(bookingID, ItemNo);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelBookingDetail(" + bookingID + ", " + ItemNo + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelBookingDetail(" + bookingID + ", " + ItemNo + ")");
      }
      e.printStackTrace();
    }
  }

  public void Confirm(String bookingID) {
    if (bookingService == null) {
      System.out.println("Error in Confirm(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Confirm(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingService.Confirm(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Confirm(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Confirm(" + bookingID + ")");
      }
      e.printStackTrace();
    }
  }

  public Collection GetBookingDetails(String bookingID) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetBookingDetails(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBookingDetails(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetBookingDetails(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBookingDetails(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBookingDetails(" + bookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBookingDetails(" + bookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetBookings(String customerID) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetBookings(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetBookings(" + customerID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetBookings(customerID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetBookings(" + customerID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetBookings(" + customerID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetBookings(" + customerID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection GetSeatBookings(String bookingID, int itemNo) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in GetSeatBookings(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling GetSeatBookings(" + bookingID + ", " + itemNo + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.GetSeatBookings(bookingID, itemNo);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: GetSeatBookings(" + bookingID + ", " + itemNo + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: GetSeatBookings(" + bookingID + ", " + itemNo + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from GetSeatBookings(" + bookingID + ", " + itemNo + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public String Reserve(String customerID, Collection reservelist) {
    String returnValue = "";
    if (bookingService == null) {
      System.out.println("Error in Reserve(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Reserve(" + customerID + ", " + reservelist + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.Reserve(customerID, reservelist);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Reserve(" + customerID + ", " + reservelist + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Reserve(" + customerID + ", " + reservelist + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from Reserve(" + customerID + ", " + reservelist + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection ViewBooking(String bookingID) {
    Collection returnValue = null;
    if (bookingService == null) {
      System.out.println("Error in ViewBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling ViewBooking(" + bookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingService.ViewBooking(bookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: ViewBooking(" + bookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: ViewBooking(" + bookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from ViewBooking(" + bookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  void PrintViewBooking(Collection c) {
	java.util.Iterator i = c.iterator();
	while (i.hasNext()) {
	  ViewBookInfo vb = (ViewBookInfo) i.next();
	  System.out.println("StationSrcName" + vb.getStationSrcName() );
	  System.out.println("StationDesName" + vb.getStationDesName() );
	}
  }
  /**Main method*/

  public static void main(String[] args) {
    BusBookingServiceTestClient1 client = new BusBookingServiceTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
	client.create();
	Collection c = client.ViewBooking("9684c7ff-a1f6-05f2-0028-198c959b73ba");
	client.PrintViewBooking(c);
	Collection reservecol = new java.util.ArrayList();
	ReserveItem ri = new ReserveItem("AA330", 1, 1, 1, false, false, false, java.sql.Date.valueOf("2002-9-30"));
	ri.AddTraveller(new TravellerVO(null, "TName1", "TLastName1"));
	reservecol.add(ri);
	String bookingID = client.Reserve("4d908595-a1f6-05f2-007e-04c63bd97ab4", reservecol);
	System.out.println("Call Reserve() from Booking Done, BookingID = " + bookingID);
  }
}