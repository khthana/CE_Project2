package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;
import javax.rmi.*;
import javax.naming.*;
import java.util.*;
import java.util.Date;
import javax.sql.*;
import java.sql.*;
import java.text.DateFormat;

/**
 * Title:         BusServiceBean.java
 * Description:   Bus Service Session Bean
 * Copyright:     Copyright (c) 2001
 * Company:       Kmit'L
 * @author        EJB Group
 * @version 1.0
 */

public class BusServiceBean implements SessionBean {
  // Caches EJBHome
  private SessionContext sessionContext;
  private StationHome stationHome;
  private CompanyHome companyHome;
  private RouteHome routeHome;
  private SubrouteHome subrouteHome;
  private BusHome busHome;
  private BusScheduleHome busScheduleHome;
  private BusModelHome busModelHome;
  private BusFeeHome busFeeHome;
  private SeatHome seatHome;

  // DataSource Object
  private DataSource datasource;

  public void AddStation(String stationID,
						 String stationName,
						 String city, String state,
						 String country,
						 String description,
						 String imagePath) throws CreateException, RemoteException {
    System.out.println("Calling - stationHome.create(" + stationID + ", ...);");
    Station station = stationHome.create(stationID, stationName, city, state, country, description, imagePath);
  }

  public void AddCompany(String companyID, String companyName, String description) throws RemoteException {
    try {
      Company company = companyHome.create(companyID, companyName, description);
    }
    catch (CreateException e) {
      System.out.println("Error at companyHome.create()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddRoute(String routeID, String description, String companyID, String modelID) throws RemoteException {
    try {
      Route route = routeHome.create(routeID, description, companyID, modelID);
    }
    catch (CreateException e) {
      System.out.println("Error at routeHome.create()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddSubroute(int subrouteID, double distance, String stationID1, String stationID2) throws RemoteException {
    try {
      Subroute subroute = subrouteHome.create(new Integer(subrouteID), distance, stationID1, stationID2);
    }
    catch (CreateException ce) {
      System.out.println("Error at subrouteHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddSubroute(double distance, String stationID1, String stationID2) throws RemoteException {
    try {
      Subroute lastSubroute = subrouteHome.findMaxID();
      int maxID = lastSubroute.getSubrouteID().intValue();

      Subroute subroute = subrouteHome.create(new Integer(maxID + 1), distance, stationID1, stationID2);
    }
    catch (FinderException fe) {
      throw new EJBException();
    }
    catch (CreateException ce) {
      System.out.println("Error at subrouteHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddBus(String busID, String companyID, String modelID, boolean forRent) throws RemoteException {
	try {
      Bus bus = busHome.create(busID, companyID, modelID, forRent);
    }
    catch (CreateException ce) {
      System.out.println("Error busScheduleHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddBusSchedule(String routeID, int subrouteID, Time arriveTime, Time departTime, int arriveDay, int departDay, int idx) throws RemoteException {
    try {
      BusSchedule busSchedule = busScheduleHome.create(routeID, subrouteID, arriveTime, departTime, departDay, arriveDay, idx);
    }
    catch (CreateException ce) {
      System.out.println("Error busScheduleHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddBusModel(String modelID, String modelName, int totalSeat, String description, boolean toilet) throws RemoteException {
    try {
      BusModel busModel = busModelHome.create(modelID, modelName, totalSeat, description, toilet);
    }
    catch (CreateException ce) {
      System.out.println("Error busModelHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddBusFee(String modelID, String companyID, double pricePerKm, double fee, double rentCost) throws RemoteException {
	try {
      BusFee busFee = busFeeHome.create(modelID, companyID, pricePerKm, fee, rentCost);
    }
    catch (CreateException ce) {
      System.out.println("Error busFeeHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void AddSeat(String seatNo, String modelID, boolean smoking, boolean window) throws RemoteException {
	try {
      Seat seat = seatHome.create(seatNo, modelID, smoking, window);
    }
    catch (CreateException ce) {
      System.out.println("Error SeatHome.create()");
      ce.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteStation(String stationID) throws RemoteException, RemoveException {
    try {
      stationHome.remove(stationID);
    }
    catch (RemoveException e) {
	  System.out.println("Error at stationHome.remove()");
	  e.printStackTrace();
      throw new EJBException();
    }
  }

  public void DeleteCompany(String companyID) throws RemoteException {
    try {
      companyHome.remove(companyID);
    }
    catch (RemoveException e) {
      System.out.println("Error at companyHome.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteRoute(String routeID) throws RemoteException {
    try {
      routeHome.remove(routeID);
    }
    catch (RemoveException e) {
      System.out.println("Error at routeHome.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteSubroute(int subrouteID) throws RemoteException {
    try {
	  subrouteHome.remove(new Integer(subrouteID));
    }
    catch (RemoveException e) {
      System.out.println("Error at subrouteHome.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteBus(String busID) throws RemoteException {
	try {
	  busHome.remove(busID);
	}
    catch (RemoveException e) {
      System.out.println("Error at subroute.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteBusSchedule(String routeID, int subrouteID) throws RemoteException {
    try {
	  BusSchedulePK primaryKey = new BusSchedulePK(routeID, subrouteID);
      busScheduleHome.remove(primaryKey);
    }
    catch (RemoveException e) {
      System.out.println("Error at busScheduleHome.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteBusModel(String modelID) throws RemoteException {
    try {
	  busModelHome.remove(modelID);
    }
    catch (RemoveException e) {
      System.out.println("Error at busModelHome.remove()");
      e.printStackTrace();
	  throw new EJBException();
    }
  }

  public void DeleteBusFee(String modelID, String companyID) throws RemoteException {
	try {
	  busFeeHome.remove(new BusFeePK(modelID, companyID));
	}
	catch (RemoveException ex) {
	  System.out.println("Error at BusFeeHome.remove()");
	  ex.printStackTrace();
	  throw new EJBException();
	}
  }
  public void DeleteSeat(String seatNo, String modelID) throws RemoteException {
	try {
	  seatHome.remove(new SeatPK(seatNo, modelID));
	}
	catch (RemoveException ex) {
	  System.out.println("Error at seatHome.remove()");
	  ex.printStackTrace();
	  throw new EJBException();
	}
  }

  public StationVO GetStation(String stationID) throws RemoteException {
    try {
      Station station = stationHome.findByPrimaryKey(stationID);
      return(station.getStation());
    }
    catch (FinderException e) {
      throw new EJBException();
    }
  }

  public CompanyVO GetCompany(String companyID) throws RemoteException {
    try {
      System.out.println("Calling - companyHome.findByPrimaryKey(\"" + companyID + "\");");
      Company company = companyHome.findByPrimaryKey(companyID);
      System.out.println("Calling - return(company.getStation());");
      return(company.getCompany());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public RouteVO GetRoute(String routeID) throws RemoteException {
    try {
      Route route = routeHome.findByPrimaryKey(routeID);
      return(route.getRoute());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public SubrouteVO  GetSubroute(int subrouteID) throws RemoteException {
    try {
      Subroute subroute = subrouteHome.findByPrimaryKey(new Integer(subrouteID));
      return(subroute.getSubroute());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public BusVO GetBus(String busID) throws RemoteException {
	try {
      Bus bus = busHome.findByPrimaryKey(busID);
      return(bus.getBus());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public BusScheduleVO GetBusSchedule(String routeID, int subrouteID) throws RemoteException {
    try {
      BusSchedulePK primaryKey = new BusSchedulePK(routeID, subrouteID);
      BusSchedule busSchedule = busScheduleHome.findByPrimaryKey(primaryKey);
      return(busSchedule.getBusSchedule());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public BusModelVO GetBusModel(String modelID) throws RemoteException {
    try {
      BusModel busModel = busModelHome.findByPrimaryKey(modelID);
      return(busModel.getBusModel());
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public BusFeeVO GetBusFee(String modelID, String companyID) throws RemoteException {
	try {
	  BusFee busFee = busFeeHome.findByPrimaryKey(new BusFeePK(modelID, companyID));
	  return busFee.getBusFee();
	}
	catch (FinderException e) {
      throw new EJBException();
    }
  }
  public SeatVO GetSeat(String seatNo, String modelID) throws RemoteException {
	try {
	  Seat seat = seatHome.findByPrimaryKey(new SeatPK(seatNo, modelID));
	  return seat.getSeat();
	}
	catch (FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllStation() throws RemoteException {
    Vector allStationCollection = new Vector();
    try {
      Collection stationCollection = stationHome.findAll();
      Iterator i = stationCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        Station station = (Station) PortableRemoteObject.narrow(obj, Station.class);
        StationVO stationVO = station.getStation();
        allStationCollection.addElement(stationVO);
      }
      return(allStationCollection);
    }
    catch (FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllCompany() throws RemoteException {
    System.out.println("GetAllCompany()");
    Vector allCompanyCollection = new Vector();
    try {
      Collection companyCollection = companyHome.findAll();
      Iterator i = companyCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        Company company = (Company) PortableRemoteObject.narrow(obj, Company.class);
        CompanyVO companyVO = company.getCompany();
        allCompanyCollection.addElement(companyVO);
      }
      return(allCompanyCollection);
    }
    catch (FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllRoute() throws RemoteException {
    Vector allRouteCollection = new Vector();
    try {
      Collection routeCollection = routeHome.findAll();
      Iterator i = routeCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        Route route = (Route) PortableRemoteObject.narrow(obj, Route.class);
        RouteVO routeVO = route.getRoute();
        allRouteCollection.addElement(routeVO);
      }
      return(allRouteCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllSubroute() throws RemoteException {
    Vector allSubrouteCollection = new Vector();
    try {
      Collection subrouteCollection = subrouteHome.findAll();
      Iterator i = subrouteCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        Subroute subroute = (Subroute) PortableRemoteObject.narrow(obj, Subroute.class);
        SubrouteVO subrouteVO = subroute.getSubroute();
        allSubrouteCollection.addElement(subrouteVO);
      }
      return(allSubrouteCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllBus() throws RemoteException {
    Vector allBusCollection = new Vector();
    try {
      Collection busCollection = busHome.findAll();
      Iterator i = busCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        Bus bus = (Bus) PortableRemoteObject.narrow(obj, Bus.class);
        BusVO busVO = bus.getBus();
        allBusCollection.addElement(busVO);
      }
      return(allBusCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllBusSchedule() throws RemoteException {
    Vector allBusScheduleCollection = new Vector();
    try {
      Collection busScheduleCollection = busScheduleHome.findAll();
      Iterator i = busScheduleCollection.iterator();
      Object obj;
      while (i.hasNext()) {
        obj = i.next();
        BusSchedule busSchedule = (BusSchedule) PortableRemoteObject.narrow(obj, BusSchedule.class);
        BusScheduleVO busScheduleVO = busSchedule.getBusSchedule();
        allBusScheduleCollection.addElement(busScheduleVO);
      }
      return(allBusScheduleCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllBusModel() throws RemoteException {
    Vector allBusModelCollection = new Vector();
    try {
      Collection busModelCollection = busModelHome.findAll();
      Iterator i = busModelCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        BusModel busModel = (BusModel) PortableRemoteObject.narrow(obj, BusModel.class);
        BusModelVO amVO = busModel.getBusModel();
        allBusModelCollection.addElement(amVO);
      }
      return(allBusModelCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }

  public Collection GetAllBusFee() throws RemoteException {
    Vector allBusFeeCollection = new Vector();
    try {
      Collection busFeeCollection = busFeeHome.findAll();
      Iterator i = busFeeCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        BusFee busFee = (BusFee) PortableRemoteObject.narrow(obj, BusFee.class);
        BusFeeVO bfVO = busFee.getBusFee();
        allBusFeeCollection.addElement(bfVO);
      }
      return(allBusFeeCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }
  public Collection GetAllSeat() throws RemoteException {
    Vector allSeatCollection = new Vector();
    try {
      Collection seatCollection = busModelHome.findAll();
      Iterator i = seatCollection.iterator();
      Object obj;
      while(i.hasNext()) {
        obj = i.next();
        Seat seat = (Seat) PortableRemoteObject.narrow(obj, Seat.class);
        SeatVO amVO = seat.getSeat();
        allSeatCollection.addElement(amVO);
      }
      return(allSeatCollection);
    }
    catch(FinderException e) {
      throw new EJBException();
    }
  }
  // This is new Method, Not implemented yet...
  // Search the Route, Subroute, Date combination that suitable for you
  public Collection Search( String stationsrcID,
							String stationdesID,
							int totalseat,
							java.sql.Date departdate,
							java.sql.Time departtime,
							String company,
							boolean toilet,
							boolean smoking,
							boolean window,
							boolean nonstoponly	)
  {
  	Connection connection = null;
    Statement statement = null;
	ResultSet rs = null;
    try {
      connection = datasource.getConnection();
	  System.out.println("Connected to DataSource");

	  /* This is newer version of search ... */
	  // generate time querty condition

	  String strselectCompany = null;
	  String strselectToilet = null;
	  String strselectWindow = null;
	  String strselectSmoking = null;
	  String strDepartDate = null;
	  String strselectDepartTime = null;
	  String strOrderBy = null;
	  String strCondition = null;

	  // generate departdate query string
	  java.util.Date today = new java.util.Date();
	  System.out.println("Current Date : " + today.toString() );
	  long k = today.getTime();
	  java.sql.Date dt= new java.sql.Date(k);
	  System.out.println("Current Date (SQL) : " + dt.toString());
	  if (departdate == null) {
		System.out.println("Date too Old");
	    throw new EJBException("Missing depart date");
	  }
	  else if (departdate.before(dt)){
		System.out.println("To late to search ... : the flight has gone!");
		return new ArrayList(); // return No result ..
	  }

	  strDepartDate = departdate.toString();

	  if (stationsrcID == null || stationdesID == null ) {
	    throw new EJBException("Missing Station ID");
	  }
	  else if (stationsrcID.equals("") || stationdesID.equals("")) {
		throw new EJBException("Missing Station ID");
	  }

	  // generate departtime query string
	  if (departtime == null) {
	    strselectDepartTime = "";
	  }
	  else {
		Time timeperiod = Time.valueOf("08:00:00");
		String strTime1 = departtime.toString();
		String strTime2 = new Time(departtime.getTime() + timeperiod.getTime()).toString();
	    strselectDepartTime = " AND T3.DepartTime BETWEEN " +
		"'1899-12-30 " + strTime1 + "' AND '1899-12-30 " + strTime2 + "' ";
	  }
	  System.out.println("StrSelectTime = " + strselectDepartTime);

	  // generate Company query string
	  if (company == null ) {
	    strselectCompany = "";
	  }
	  else if (company.equals("")) {
		  strselectCompany = "";
	  }
	  else {
	    strselectCompany = " AND T7.CompanyID = '" + company + "' ";
	  }
	  System.out.println("StrSelectCompany = " + strselectCompany);

	  if (toilet) {
		strselectToilet = " AND T14.Toilet = 1 ";
	  }
	  else {
		strselectToilet = "";
	  }
	  System.out.println("StrSelectToilet = " + strselectToilet);

	  if (window) {
		strselectWindow = " AND T8.Window = 1 ";
	  }
	  else {
		strselectWindow = "";
	  }
	  System.out.println("StrSelectWindow = " + strselectWindow);

	  // generate can smoking? query string
	  if (smoking) {
		strselectSmoking = " AND T8.Smoking = 1 ";
	  }
	  else {
		strselectSmoking = "";
	  }
	  System.out.println("StrSelectSmoking = " + strselectSmoking);

	  if (nonstoponly) {
	    strCondition = " HAVING  COUNT(DISTINCT T12.SubRouteID) = 1 ";
	  }
	  else {
	    strCondition = "";
	  }

	  System.out.println("StrCondition = " + strCondition);

	  strOrderBy = "";

	  System.out.println("StrOrderBy = " + strOrderBy);

	  String strStatement =
"SELECT	    T1.CompanyName, T14.ModelID, T14.ModelName, T3.DepartTime, T4.ArriveTime, " +
"           T3.RouteID, T7.Description, T3.Idx, T4.Idx, " +
"			(SUM(T12.Distance)), " +
"           (SUM(T12.Distance * T13.PricePerKm)) + T13.Fee " +
"FROM	    Company T1, " +
"           BusSchedule T3, BusSchedule T4, BusSchedule T11, " +
"		    SubRoute T5, SubRoute T6, SubRoute T12, " +
"		    Route T7, BusModel T14, BusFee T13 " +
"WHERE	    T5.StationID1 = '" + stationsrcID + "'" +
	  " AND T6.StationID2 = '" + stationdesID + "'" +
	  " AND T5.SubRouteID = T3.SubRouteID " +
	  " AND T6.SubRouteID = T4.SubRouteID " +
	  " AND T12.SubRouteID = T11.SubRouteID " +
	  " AND T3.RouteID = T4.RouteID " +
	  " AND T11.RouteID = T3.RouteID " +
	  " AND T7.RouteID = T3.RouteID " +
	  " AND T11.Idx BETWEEN T3.Idx AND T4.Idx " +
	  " AND T3.Idx <= T4.Idx " +
	  strselectDepartTime +
	  " AND T1.CompanyID = T7.CompanyID " +
	  " AND T13.CompanyID = T1.CompanyID " +
	  " AND T14.ModelID = T7.ModelID " +
	  " AND T14.ModelID = T13.ModelID " +
	  strselectToilet +
	  strselectCompany +
	  " AND " + totalseat;

	  strStatement = strStatement +
				" <=	(SELECT COUNT(DISTINCT T8.SeatNo) " +
			    "	     FROM     Seat T8 " +
				"		 WHERE    T7.ModelID = T8.ModelID " +
				strselectSmoking + strselectWindow +
				"             AND T8.SeatNo NOT IN  " +
				"              (SELECT	DISTINCT T20.SeatNo " +
				"               FROM	SeatBooking T20, BusSchedule T10 " +
				"               WHERE	(T20.DepartDate - T10.DepartDay + T3.DepartDay) = '" + strDepartDate +"'" +
				"               AND T20.RouteID = T7.RouteID " +
				"               AND T20.RouteID = T10.RouteID " +
				"               AND T20.SubRouteID = T10.SubRouteID " +
				"               AND T10.Idx >= T3.Idx " +
				"               AND T10.Idx <= T4.Idx ) ) " +
" GROUP BY     T1.CompanyName, T14.ModelID, T14.ModelName, " +
"              T3.DepartTime, T4.ArriveTime, T3.RouteID, T7.Description, " +
"              T3.Idx, T4.Idx, T13.PricePerKm, T13.Fee " + strCondition + strOrderBy;

	  if (strStatement != null) {
	    System.out.println(strStatement);
	  }
	  else {
	    System.out.println("Error with statement string");
	  }

	  statement = connection.createStatement();
	  rs = statement.executeQuery(strStatement);
	  Collection searchresults = new ArrayList();
	  while (rs.next()) {
		 System.out.println("Found next Result!");
		 String _companyname = rs.getString(1);
		 String _modelid = rs.getString(2);
		 String _modelname = rs.getString(3);
		 java.sql.Time _departtime = rs.getTime(4);
		 java.sql.Time _arrivetime = rs.getTime(5);
		 String _routeid = rs.getString(6);
		 String _routedescription = rs.getString(7);
		 int _srcidx = rs.getInt(8);
		 int _desidx = rs.getInt(9);
		 double _totaldistance = rs.getFloat(10);
		 double _totalprice = rs.getDouble(11);

		 BusSeatSearchResult sr = new BusSeatSearchResult(_companyname,
														  _routeid,
														  _routedescription,
														  _modelid,
														  _modelname,
														  _departtime,
														  _arrivetime,
														  _srcidx,
														  _desidx,
														  _totaldistance,
														  _totalprice );

		 // add new result row
		 System.out.println("Adding to Result Collection..");
		 searchresults.add(sr);
	  }
	  System.out.println("Finish all result");
	  return searchresults;
    }
    catch(SQLException e) {
	  e.printStackTrace();
      throw new EJBException("Error executing SQL SELECT");
    }
	finally {
	  closeConnection(statement, connection);
	}
  }

  public Collection SearchForRent(java.sql.Date startdate, java.sql.Date stopdate, boolean toilet, String companyID) {
	Connection connection = null;
    Statement statement = null;
	ResultSet rs = null;

	String strSelectToilet = null;
	String strSelectCompany = null;
	String strStartDate = null;
	String strStopDate = null;

	if (companyID == null) {
	  strSelectCompany = "";
	}
	else if (companyID.equals("")) {
	  strSelectCompany = "";
	}
	else {
	  strSelectCompany = " AND T1.CompanyID = \'" + companyID + "\' ";
	}

	if (toilet == true) {
	  strSelectToilet = " AND T2.Toilet = 1 ";
	}
	else {
	  strSelectToilet = "";
	}

	if (startdate != null) {
	  strStartDate = "" + (1900 + startdate.getYear()) + "-" + startdate.getMonth() + "-" + startdate.getDate();
	}
	else {
	  throw new EJBException("Invalid parameter, missing start date");
	}

	if (stopdate != null) {
	  strStopDate = "" + (1900 + stopdate.getYear()) + "-" + stopdate.getMonth() + "-" + stopdate.getDate();
	}
	else {
	  throw new EJBException("Invalid parameter, missing stop date");
	}

	String strSearchRent =
		   " SELECT T1.BusID, T1.CompanyID, T1.ModelID, T4.RentCost " +
		   " FROM   Bus T1, BusModel T2, BusFee T4 " +
		   " WHERE  T2.ModelID = T1.ModelID " +
		   "    AND T4.ModelID = T1.ModelID " +
		   strSelectToilet +
		   "    AND T4.CompanyID = T1.CompanyID " +
		   strSelectCompany +
		   "    AND NOT EXISTS " +
				" ( SELECT T5.UsingDate " +
				"   FROM   BusRenting T5" +
				"   WHERE  T5.BusID = T1.BusID " +
				"      AND T5.UsingDate BETWEEN \'" + strStartDate + "\' AND \'" + strStopDate + "\' )" +
		  "  ORDER BY T1.CompanyID, T1.ModelID, T4.RentCost";

	Collection resultCollection = new ArrayList();

    try {
      connection = datasource.getConnection();
	  System.out.println("Connected to DataSource");
	  statement = connection.createStatement();
	  System.out.println("Try to Execute SQL Statement...");
	  System.out.println(strSearchRent);
	  rs = statement.executeQuery(strSearchRent);
	  System.out.println("Done SQL Statement");
	  while (rs.next()) {
		String _busID      = rs.getString(1);
		String _companyID  = rs.getString(2);
		String _modelID    = rs.getString(3);
		double _rentCost   = rs.getDouble(4);

		BusRentSearchResult brsr = new BusRentSearchResult(_busID, _companyID, _modelID, _rentCost);
		resultCollection.add(brsr);
	  }

	  connection.close();
    }
	catch (SQLException se) {
	  se.printStackTrace();
	  throw new EJBException("Cannot execute SQL Statement ");
	}
	finally {
	  closeConnection(statement, connection);
	}
	return resultCollection;
  }
  public void ejbCreate() {
  }
  public void ejbRemove() throws RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setSessionContext(SessionContext sessionContext) throws RemoteException {
    this.sessionContext = sessionContext;

    try {
      Context ctx = new InitialContext();

      //look up jndi name and cast to Home interface
      stationHome         = (StationHome)    PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Station"), StationHome.class);
      companyHome         = (CompanyHome)    PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Company"), CompanyHome.class);
      routeHome           = (RouteHome)      PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Route"), RouteHome.class);
      subrouteHome        = (SubrouteHome)   PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Subroute"), SubrouteHome.class);
	  busHome             = (BusHome)        PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Bus"), BusHome.class);
      busScheduleHome     = (BusScheduleHome)PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/BusSchedule"), BusScheduleHome.class);
      busModelHome        = (BusModelHome)   PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/BusModel"), BusModelHome.class);
      busFeeHome          = (BusFeeHome)     PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/BusFee"), BusFeeHome.class);
	  seatHome            = (SeatHome)       PortableRemoteObject.narrow(ctx.lookup("java:comp/env/ejb/Seat"), SeatHome.class);
	  datasource          = (DataSource) ctx.lookup("java:comp/env/jdbc/DataSource");
    }
    catch (javax.naming.NamingException ne) {
      throw new RemoteException();
    }
  }
  private void closeConnection(Statement stmt, Connection conn) {
	try {
	  if (stmt!= null) { stmt.close(); }
	  if (conn != null) { conn.close(); }
	}
	catch (SQLException e) {
	}
  }
}