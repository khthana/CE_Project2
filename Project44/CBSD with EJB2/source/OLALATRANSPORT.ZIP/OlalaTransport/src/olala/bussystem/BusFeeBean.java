package olala.bussystem;

import java.rmi.*;
import javax.ejb.*;

public class BusFeeBean implements EntityBean {
  EntityContext entityContext;
  public String modelID;
  public String companyID;
  public double pricePerKm;
  public double fee;
  public double rentCost;
  public BusFeePK ejbCreate(String modelID, String companyID, double pricePerKm, double fee, double rentCost) throws CreateException, RemoteException {
    this.modelID = modelID;
    this.companyID = companyID;
    this.pricePerKm = pricePerKm;
    this.fee = fee;
    this.rentCost = rentCost;
    return null;
  }
  public BusFeePK ejbCreate(String modelID, String companyID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(modelID, companyID, 0.0, 0.0, 0.0);
  }
  public void ejbPostCreate(String modelID, String companyID, double pricePerKm, double fee, double rentCost) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String modelID, String companyID) throws CreateException, RemoteException {
    ejbPostCreate(modelID, companyID, 0.0, 0.0, 0.0);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getModelID() {
    return modelID;
  }
  public String getCompanyID() {
    return companyID;
  }
  public double getPricePerKm() {
    return pricePerKm;
  }
  public void setPricePerKm(double pricePerKm) {
    this.pricePerKm = pricePerKm;
  }
  public double getFee() {
    return fee;
  }
  public void setFee(double fee) {
    this.fee = fee;
  }
  public double getRentCost() {
    return rentCost;
  }
  public void setRentCost(double rentCost) {
    this.rentCost = rentCost;
  }
  public BusFeeVO getBusFee() {
	return new BusFeeVO(companyID, pricePerKm, fee, rentCost);
  }
}