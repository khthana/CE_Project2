package olala.bussystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BusVO implements Serializable {

  private String busID;
  private String companyID;
  private String modelID;
  private boolean forRent;

  public BusVO() {
  }

  public BusVO(String busID, String companyID, String modelID, boolean forRent ) {
	this.busID = busID;
	this.companyID = companyID;
	this.modelID = modelID;
	this.forRent = forRent;
  }

  public String getBusID() {
    return busID;
  }
  public String getCompanyID() {
    return companyID;
  }
  public boolean isForRent() {
    return forRent;
  }
  public String getModelID() {
    return modelID;
  }
  public void setBusID(String busID) {
    this.busID = busID;
  }
  public void setCompanyID(String companyID) {
    this.companyID = companyID;
  }
  public void setForRent(boolean forRent) {
    this.forRent = forRent;
  }
  public void setModelID(String modelID) {
    this.modelID = modelID;
  }

  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }

}