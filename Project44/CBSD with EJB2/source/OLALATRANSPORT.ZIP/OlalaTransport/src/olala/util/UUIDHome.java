package olala.util;

import java.rmi.*;
import javax.ejb.*;

public interface UUIDHome extends EJBHome {
  public UUID create() throws RemoteException, CreateException;
}