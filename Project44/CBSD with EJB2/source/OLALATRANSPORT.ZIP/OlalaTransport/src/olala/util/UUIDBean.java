package olala.util;

import java.net.InetAddress;
import java.rmi.RemoteException;
import java.security.SecureRandom;
import java.util.Random;
import javax.ejb.*;

public class UUIDBean implements SessionBean {

  private SessionContext sessionContext;

  private SecureRandom seeder;
  private String midValue;
  private String midValueUnformated;
  private long checkTime;

  public UUIDBean()
  {
  }

  public void ejbCreate() throws CreateException
  {
	try	{
	  StringBuffer stringbuffer = new StringBuffer();
      StringBuffer stringbuffer1 = new StringBuffer();
      seeder = new SecureRandom();
      InetAddress inetaddress = InetAddress.getLocalHost();
      byte abyte0[] = inetaddress.getAddress();
      String s = hexFormat(getInt(abyte0), 8);
      String s1 = hexFormat(hashCode(), 8);
      stringbuffer.append("-");
      stringbuffer1.append(s.substring(0, 4));
      stringbuffer.append(s.substring(0, 4));
      stringbuffer.append("-");
      stringbuffer1.append(s.substring(4));
      stringbuffer.append(s.substring(4));
      stringbuffer.append("-");
      stringbuffer1.append(s1.substring(0, 4));
      stringbuffer.append(s1.substring(0, 4));
      stringbuffer.append("-");
      stringbuffer1.append(s1.substring(4));
      stringbuffer.append(s1.substring(4));
      midValue = stringbuffer.toString();
      midValueUnformated = stringbuffer1.toString();
      checkTime = System.currentTimeMillis();
      int i = seeder.nextInt();
    }
    catch(Exception exception) {
	  throw new CreateException("error - failure to create bean " + exception);
    }
  }

  public void setSessionContext(SessionContext sessioncontext)
  	 throws EJBException, RemoteException
  {
  }

  public void ejbRemove()
     throws EJBException, RemoteException
  {
  }

    public void ejbActivate()
        throws EJBException, RemoteException
    {
    }

    public void ejbPassivate()
        throws EJBException, RemoteException
    {
    }

    private String getVal(String s)
        throws RemoteException
    {
        long l = System.currentTimeMillis();
        /*
        if(l > checkTime + 0x1499700L)
        {
            return "Demo Bean has Expired - redeploy demo or contact www.activescript.co.uk for full version";
        } else
        {
        */
            int i = (int)l & -1;
            int j = seeder.nextInt();
            return hexFormat(i, 8) + s + hexFormat(j, 8);
        //}
    }

    public String getUnformatedUUID()
        throws RemoteException
    {
        return getVal(midValueUnformated);
    }

    public String getUUID()
        throws RemoteException
    {
        return getVal(midValue);
    }

    private int getInt(byte abyte0[])
    {
        int i = 0;
        int j = 24;
        for(int k = 0; j >= 0; k++)
        {
            int l = abyte0[k] & 0xff;
            i += l << j;
            j -= 8;
        }

        return i;
    }

    private String hexFormat(int i, int j)
    {
        String s = Integer.toHexString(i);
        return padHex(s, j) + s;
    }

    private String padHex(String s, int i)
    {
        StringBuffer stringbuffer = new StringBuffer();
        if(s.length() < i)
        {
            for(int j = 0; j < i - s.length(); j++)
                stringbuffer.append("0");

        }
        return stringbuffer.toString();
    }
}